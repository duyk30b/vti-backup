import { GetHoldedItemListRequestDto } from '@components/holded-item/dto/request/get-holded-item-list.request.dto';
import { HoldedItemRepositoryInterface } from '@components/holded-item/interface/holded-item.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { getRegexByValue } from '@utils/common';
import { isEmpty } from 'lodash';
import * as moment from 'moment';
import { Model } from 'mongoose';
import { HoldedItemModel } from 'src/models/holded-item/holded-item.model';
@Injectable()
export class HoldedItemRepository
  extends BaseAbstractRepository<HoldedItemModel>
  implements HoldedItemRepositoryInterface
{
  constructor(
    @InjectModel('HoldedItemModel')
    private readonly holdedItemModel: Model<HoldedItemModel>,
  ) {
    super(holdedItemModel);
  }

  createDocument(request: any, document?: any): HoldedItemModel {
    let newDocument = new this.holdedItemModel();
    if (!isEmpty(document)) {
      newDocument = document;
    }

    if (request._id) newDocument._id = request._id;
    newDocument.warehouseId = request.warehouseId;
    newDocument.itemId = request.itemId;
    newDocument.stockQuantity = request.stockQuantity;
    newDocument.holdedQuantity = request.holdedQuantity;

    return newDocument;
  }

  async getList(request: GetHoldedItemListRequestDto): Promise<any> {
    const { keyword, sort, filter, take, skip } = request;
    let sortObj = {};
    let filterObj = {};

    if (!isEmpty(keyword)) {
      filterObj = {
        ...filterObj,
        $or: [
          { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          { name: getRegexByValue(keyword) },
        ],
      };
    }
    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order;
        switch (item.column) {
          case 'createdAt':
            sortObj = { createdAt: order };
            break;
          case 'updatedAt':
            sortObj = { updatedAt: order };
            break;
            break;
        }
      });
    } else {
      sortObj = { createdAt: -1 };
    }

    const result = await this.holdedItemModel
      .aggregate()
      .lookup({
        from: 'holdedItemLots',
        localField: '_id',
        foreignField: 'holdedItemId',
        as: 'holdedItemLots',
      })
      .match(filterObj)
      .sort(sortObj)
      .skip(skip)
      .limit(take)
      .exec();

    const total: number = await this.holdedItemModel
      .find({ ...filterObj, deletedAt: null })
      .countDocuments()
      .exec();

    return { data: result, count: total };
  }
}
