import { HoldedItemLotRepositoryInterface } from '@components/holded-item/interface/holded-item-lot.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { isEmpty } from 'lodash';
import * as moment from 'moment';
import { Model } from 'mongoose';
import { HoldedItemLotModel } from 'src/models/holded-item-lot/holded-item-lot.model';
import { HoldedItemModel } from 'src/models/holded-item/holded-item.model';
@Injectable()
export class HoldedItemLotRepository
  extends BaseAbstractRepository<HoldedItemLotModel>
  implements HoldedItemLotRepositoryInterface
{
  constructor(
    @InjectModel('HoldedItemLotModel')
    private readonly holdedItemLotModel: Model<HoldedItemLotModel>,
  ) {
    super(holdedItemLotModel);
  }

  createDocument(request: any, document?: any): HoldedItemLotModel {
    let newDocument = new this.holdedItemLotModel();
    if (!isEmpty(document)) {
      newDocument = document;
    }

    if (request._id) newDocument._id = request._id;
    newDocument.holdedItemId = request.holdedItemId;
    newDocument.stockQuantity = request.stockQuantity;
    newDocument.holdedQuantity = request.holdedQuantity;
    newDocument.lotNumber = request.lotNumber;
    newDocument.mfg = request.mfg;

    return newDocument;
  }
}
