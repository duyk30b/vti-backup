export enum APIPrefix {
  Version = 'api/v1/item-stock-plannings',
}
