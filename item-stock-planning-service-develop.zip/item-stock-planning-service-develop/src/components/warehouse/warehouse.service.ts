import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { keyBy } from 'lodash';
import { ResponseCodeEnum } from './../../constant/response-code.enum';
import { WarehouseServiceInterface } from './interface/warehouse.service.interface';

@Injectable()
export class WarehouseService implements WarehouseServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async getListByIDs(ids: number[], serilize?: boolean): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        'get_warehouses_by_ids',
        {
          warehouseIds: ids,
        },
      );

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }
      if (serilize) {
        return keyBy(response.data, 'id');
      }
      return response.data;
    } catch (err) {
      console.log(err);
      return [];
    }
  }

  async getWarehouseListByConditions(
    request: any,
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'get_warehouses_by_conditions',
      request,
    );

    if (serilize) {
      const serilizeWarehouses = [];
      if (!response) return [];
      response.forEach((warehouse) => {
        serilizeWarehouses[warehouse.id] = warehouse;
      });
      return serilizeWarehouses;
    }

    return response;
  }

  async getItemWarehouseListByConditions(
    request: any,
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'get_item_warehouses_by_conditions',
      request,
    );

    if (serilize) {
      const serilizeItemWarehouses = [];
      if (!response) return [];
      response.forEach((itemWarehouse) => {
        serilizeItemWarehouses[itemWarehouse.itemId] = itemWarehouse;
      });
      return serilizeItemWarehouses;
    }

    return response;
  }
}
