export interface WarehouseServiceInterface {
  getListByIDs(ids: number[], serialize?: boolean): Promise<any>;
  getWarehouseListByConditions(request: any, serilize?: boolean): Promise<any>;
  getItemWarehouseListByConditions(
    request: any,
    serilize?: boolean,
  ): Promise<any>;
}
