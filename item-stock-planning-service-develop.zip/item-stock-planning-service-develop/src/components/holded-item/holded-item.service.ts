import { HoledItemServiceInterface } from './interface/holded-item.service.interface';
import { Inject, Injectable } from '@nestjs/common';
import { HoldedItemRepositoryInterface } from './interface/holded-item.repository.interface';
import { UpdateHoldedItemRequestDto } from './dto/request/update-holded-item.request.dto';
import { isEmpty, map } from 'lodash';
import * as moment from 'moment';
import { FORMAT_DATE_NUMBER } from '@utils/constant';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { keyBy } from 'lodash';
import { HoldedItemLotRepositoryInterface } from './interface/holded-item-lot.repository.interface';
import { HOLDED_ITEM_UPDATE_ACTION_ENUM } from './holded-item.constant';
import { minus, plus } from '@utils/helper';
import { HoldedItemModel } from 'src/models/holded-item/holded-item.model';
import { HoldedItemLotModel } from 'src/models/holded-item-lot/holded-item-lot.model';
import { GetHoldedItemListRequestDto } from './dto/request/get-holded-item-list.request.dto';
import { plainToInstance } from 'class-transformer';
import { GetHoldedItemListResponseDto } from './dto/response/get-holded-item-list.response.dto';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';

@Injectable()
export class HoledItemService implements HoledItemServiceInterface {
  constructor(
    @Inject('HoldedItemRepositoryInterface')
    private readonly holdedItemRepository: HoldedItemRepositoryInterface,

    @Inject('HoldedItemLotRepositoryInterface')
    private readonly holdedItemLotRepository: HoldedItemLotRepositoryInterface,

    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    protected readonly i18n: I18nRequestScopeService,
  ) {}

  async updateHoldedItem(request: UpdateHoldedItemRequestDto): Promise<any> {
    const { holdedItems } = request;

    const objKeys = map(holdedItems, (i) => {
      return {
        itemId: i.itemId,
        warehouseId: i.warehouseId,
      };
    });

    const normalizedRequestData = this.normalizeHoldedItems(holdedItems);
    const normalizedExistingData = this.normalizeHoldedItems(
      await this.holdedItemRepository.findAllWithPopulate(
        {
          $or: objKeys,
        },
        ['holdedItemLots'],
      ),
      true,
    );

    const [holdedItemDocuments, holdedItemLotDocuments] = this.handleAction(
      normalizedRequestData,
      normalizedExistingData,
    );

    const holdedItemBulkOps = holdedItemDocuments.map((holdedItemDocument) => ({
      updateOne: {
        filter: { _id: holdedItemDocument._id },
        update: {
          ...holdedItemDocument['_doc'],
        },
        upsert: true,
      },
    }));
    const holdedItemLotBulkOps = holdedItemLotDocuments.map(
      (holdedItemLot) => ({
        updateOne: {
          filter: { _id: holdedItemLot._id },
          update: {
            ...holdedItemLot['_doc'],
          },
          upsert: true,
        },
      }),
    );

    try {
      await this.holdedItemRepository.bulkWrite(holdedItemBulkOps);
      await this.holdedItemLotRepository.bulkWrite(holdedItemLotBulkOps);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(request: GetHoldedItemListRequestDto): Promise<any> {
    const { data } = await this.holdedItemRepository.getList(request);

    const [serializedItem, serializedWarehouse] = await Promise.all([
      this.warehouseService.getListByIDs(map(data, 'itemId'), true),
      this.warehouseService.getListByIDs(map(data, 'warehouseId'), true),
    ]);

    const resData = plainToInstance(
      GetHoldedItemListResponseDto,
      map(data, (holdedItem) => {
        return {
          ...holdedItem,
          item: serializedItem[holdedItem.itemId],
          warehouse: serializedWarehouse[holdedItem.warehouseId],
        };
      }),
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(resData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /* add 'key' property into object */
  private normalizeHoldedItems(holdedItems: any, isKeyBy?: boolean): any {
    const data = map(holdedItems, (holdedItem) => {
      return {
        ...holdedItem,
        key: [holdedItem.itemId, holdedItem.warehouseId].join('-'),
        holdedItemLots: (() => {
          const holdedItemLots = map(
            holdedItem.holdedItemLots,
            (holdedItemLot) => {
              return {
                ...holdedItemLot,
                key: [
                  moment(holdedItemLot.mfg).format(FORMAT_DATE_NUMBER),
                  holdedItemLot.lotNumber,
                ].join('-'),
              };
            },
          );
          if (isKeyBy) {
            return keyBy(holdedItemLots, 'key');
          }
          return holdedItemLots;
        })(),
      };
    });

    if (isKeyBy) {
      return keyBy(data, 'key');
    }
    return data;
  }

  private handleAction(
    requestData: any,
    existingData: any,
  ): [HoldedItemModel[], HoldedItemLotModel[]] {
    const holdedItemDocuments: HoldedItemModel[] = [];
    const holdedItemLotDocuments: HoldedItemLotModel[] = [];
    for (const i of requestData) {
      if (existingData[i.key]) {
        //to update
        const holdedItemDocument = this.holdedItemRepository.createDocument(
          existingData[i.key],
        );

        switch (i.action) {
          case HOLDED_ITEM_UPDATE_ACTION_ENUM.PLUS:
            holdedItemDocument.stockQuantity = plus(
              i.stockQuantity,
              holdedItemDocument.stockQuantity,
            );
            holdedItemDocument.holdedQuantity = plus(
              i.holdedQuantity,
              holdedItemDocument.holdedQuantity,
            );
            break;
          case HOLDED_ITEM_UPDATE_ACTION_ENUM.MINUS:
            holdedItemDocument.stockQuantity = minus(
              holdedItemDocument.stockQuantity,
              i.stockQuantity,
            );
            holdedItemDocument.holdedQuantity = minus(
              holdedItemDocument.holdedQuantity,
              i.holdedQuantity,
            );
            break;
          default:
            break;
        }
        holdedItemDocuments.push(holdedItemDocument);

        if (i.holdedItemLots) {
          for (const e of i.holdedItemLots) {
            if (existingData[i.key].holdedItemLots[e.key]) {
              //to update
              const holdedItemLotDocument =
                this.holdedItemLotRepository.createDocument(
                  existingData[i.key].holdedItemLots[e.key],
                );

              switch (i.action) {
                case HOLDED_ITEM_UPDATE_ACTION_ENUM.PLUS:
                  holdedItemLotDocument.stockQuantity = plus(
                    holdedItemLotDocument.stockQuantity,
                    e.stockQuantity,
                  );
                  holdedItemLotDocument.holdedQuantity = plus(
                    holdedItemLotDocument.holdedQuantity,
                    e.holdedQuantity,
                  );
                  break;
                case HOLDED_ITEM_UPDATE_ACTION_ENUM.MINUS:
                  holdedItemLotDocument.stockQuantity = minus(
                    holdedItemLotDocument.stockQuantity,
                    e.stockQuantity,
                  );
                  holdedItemLotDocument.holdedQuantity = minus(
                    holdedItemLotDocument.holdedQuantity,
                    e.holdedQuantity,
                  );
                  break;
                default:
                  break;
              }

              holdedItemLotDocuments.push(holdedItemLotDocument);
            } else {
              //to create
              const holdedItemLotDocument =
                this.holdedItemLotRepository.createDocument({
                  ...e,
                  holdedItemId: holdedItemDocument._id,
                });
              holdedItemLotDocuments.push(holdedItemLotDocument);
            }
          }
        }
      } else {
        //to create
        const holdedItemDocument = this.holdedItemRepository.createDocument(i);
        holdedItemDocuments.push(holdedItemDocument);
        if (i.holdedItemLots) {
          for (const e of i.holdedItemLots) {
            const holdedItemLotDocument =
              this.holdedItemLotRepository.createDocument({
                ...e,
                holdedItemId: holdedItemDocument._id,
              });
            holdedItemLotDocuments.push(holdedItemLotDocument);
          }
        }
      }
    }
    return [holdedItemDocuments, holdedItemLotDocuments];
  }
}
