import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { Expose, Type } from 'class-transformer';

class HoldedItemLotResponseDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  holdedQuantity: number;

  @ApiProperty()
  @Expose()
  stockQuantity: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  mfg: string;
}

class ItemUnitResponseDto extends BasicResponseDto {}

class ItemTypeResponseDto extends BasicResponseDto {}

class ItemResponseDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => ItemTypeResponseDto)
  itemType: ItemTypeResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => ItemUnitResponseDto)
  itemUnit: ItemUnitResponseDto;
}

class WarehouseResponseDto extends BasicResponseDto {}

export class GetHoldedItemListResponseDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => WarehouseResponseDto)
  warehouse: WarehouseResponseDto;

  @ApiProperty()
  @Expose()
  holdedQuantity: number;

  @ApiProperty()
  @Expose()
  stockQuantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => HoldedItemLotResponseDto)
  holdedItemLots: HoldedItemLotResponseDto[];
}
