import { HOLDED_ITEM_UPDATE_ACTION_ENUM } from '@components/holded-item/holded-item.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsDateString,
  IsEnum,
  IsInt,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';

class HoldedItemLotRequestDto {
  @ApiProperty({ example: 1 })
  @IsOptional()
  @IsNumber()
  stockQuantity: number;

  @ApiProperty({ example: 1 })
  @IsOptional()
  @IsNumber()
  holdedQuantity: number;

  @ApiProperty({ example: 1 })
  @IsOptional()
  @IsNumber()
  confirmedQuantity: number;

  @ApiProperty({ example: 'Lô 1' })
  @IsOptional()
  @MaxLength(50)
  @IsString()
  lotNumber: string;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  mfg: Date;
}

class HoldedItemRequestDto {
  @ApiProperty({ example: 1 })
  @IsEnum(HOLDED_ITEM_UPDATE_ACTION_ENUM)
  action: any;

  @ApiProperty({ example: 1 })
  @Transform(({ value }) => Number(value))
  itemId: number;

  @ApiProperty({ example: 1 })
  @Transform(({ value }) => Number(value))
  warehouseId: number;

  @ApiProperty({ example: 1 })
  //@IsNumber()
  stockQuantity: number;

  @ApiProperty({ example: 1 })
  @IsNumber()
  holdedQuantity: number;

  @ApiProperty()
  @IsOptional()
  @Type(() => HoldedItemLotRequestDto)
  @ValidateNested()
  holdedItemLots: HoldedItemLotRequestDto[];
}

export class UpdateHoldedItemRequestDto extends BaseDto {
  @ApiProperty({ type: HoldedItemRequestDto })
  @ValidateNested()
  @Type(() => HoldedItemRequestDto)
  @ArrayNotEmpty()
  holdedItems: HoldedItemRequestDto[];
}
