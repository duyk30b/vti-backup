import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { Transform } from 'class-transformer';
import { IsEnum, IsOptional } from 'class-validator';

export class GetHoldedItemListRequestDto extends PaginationQuery {}
