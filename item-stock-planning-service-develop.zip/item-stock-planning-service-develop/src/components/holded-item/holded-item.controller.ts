import { Body, Controller, Get, Inject, Post, Query } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { isEmpty } from 'lodash';
import { GetHoldedItemListRequestDto } from './dto/request/get-holded-item-list.request.dto';
import { UpdateHoldedItemRequestDto } from './dto/request/update-holded-item.request.dto';
import { HoledItemServiceInterface } from './interface/holded-item.service.interface';

@Controller('holded-items')
export class HoledItemController {
  constructor(
    @Inject('HoledItemServiceInterface')
    private readonly holdedItemService: HoledItemServiceInterface,
  ) {}

  @MessagePattern('update_holded_items')
  @ApiOperation({
    tags: ['Holded item'],
    summary: 'Update holded item',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  public async update(@Body() body: UpdateHoldedItemRequestDto): Promise<any> {
    const { request, responseError } = body;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.holdedItemService.updateHoldedItem(request);
  }

  @Get('/list')
  @ApiOperation({
    tags: ['Holded item'],
    summary: 'Get holded item',
  })
  @ApiResponse({
    status: 200,
    description: 'get successfully',
  })
  public async getList(
    @Query() query: GetHoldedItemListRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.holdedItemService.getList(request);
  }

  @MessagePattern('get_holded_item_list')
  @ApiOperation({
    tags: ['Holded item'],
    summary: 'Get holded item',
  })
  @ApiResponse({
    status: 200,
    description: 'get successfully',
  })
  public async getListTcp(
    @Body() body: GetHoldedItemListRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.holdedItemService.getList(request);
  }
}
