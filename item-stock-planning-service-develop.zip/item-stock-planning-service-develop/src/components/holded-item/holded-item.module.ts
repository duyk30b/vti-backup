import { ItemService } from '@components/item/item.service';
import { WarehouseService } from '@components/warehouse/warehouse.service';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { HoldedItemLotSchema } from 'src/models/holded-item-lot/holded-item-lot.schema';
import { HoldedItemSchema } from 'src/models/holded-item/holded-item.schema';
import { HoldedItemLotRepository } from 'src/repository/holded-item/holded-item-lot.repository';
import { HoldedItemRepository } from 'src/repository/holded-item/holded-item.repository';
import { HoledItemController } from './holded-item.controller';
import { HoledItemService } from './holded-item.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'HoldedItemModel', schema: HoldedItemSchema },
      { name: 'HoldedItemLotModel', schema: HoldedItemLotSchema },
    ]),
  ],
  controllers: [HoledItemController],
  providers: [
    {
      provide: 'HoledItemServiceInterface',
      useClass: HoledItemService,
    },
    {
      provide: 'HoldedItemRepositoryInterface',
      useClass: HoldedItemRepository,
    },
    {
      provide: 'HoldedItemLotRepositoryInterface',
      useClass: HoldedItemLotRepository,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
  ],
  exports: [],
})
export class HoledItemModule {}
