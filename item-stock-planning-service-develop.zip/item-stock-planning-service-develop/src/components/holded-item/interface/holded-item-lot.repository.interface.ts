import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { HoldedItemLotModel } from 'src/models/holded-item-lot/holded-item-lot.model';
import { HoldedItemModel } from 'src/models/holded-item/holded-item.model';

export interface HoldedItemLotRepositoryInterface
  extends BaseInterfaceRepository<HoldedItemLotModel> {
  createDocument(request: any, document?: any): HoldedItemLotModel;
}
