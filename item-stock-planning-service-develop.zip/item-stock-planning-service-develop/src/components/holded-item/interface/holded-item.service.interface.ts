import { GetHoldedItemListRequestDto } from '../dto/request/get-holded-item-list.request.dto';
import { UpdateHoldedItemRequestDto } from '../dto/request/update-holded-item.request.dto';

export interface HoledItemServiceInterface {
  updateHoldedItem(request: UpdateHoldedItemRequestDto): Promise<any>;
  getList(request: GetHoldedItemListRequestDto): Promise<any>;
}
