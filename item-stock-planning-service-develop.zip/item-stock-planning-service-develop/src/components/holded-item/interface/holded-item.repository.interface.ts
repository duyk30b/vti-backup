import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { HoldedItemModel } from 'src/models/holded-item/holded-item.model';
import { GetHoldedItemListRequestDto } from '../dto/request/get-holded-item-list.request.dto';

export interface HoldedItemRepositoryInterface
  extends BaseInterfaceRepository<HoldedItemModel> {
  createDocument(request: any, document?: any): HoldedItemModel;
  getList(request: GetHoldedItemListRequestDto): Promise<any>;
}
