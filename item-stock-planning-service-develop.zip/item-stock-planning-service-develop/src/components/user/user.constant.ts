export const USER_ROLE_SETTING_CONSTANT = {
  ADMIN: '01',
  LEADER: '02',
  MEMBER: '03',
};

export const DEPARTMENT_SETTING_CONSTANT = {
  ADMIN: 'ADMIN',
  ME: 'ME',
  OTHER: 'OTHER',
};
