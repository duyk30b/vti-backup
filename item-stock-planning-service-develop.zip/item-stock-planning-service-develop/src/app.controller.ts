import { NATS_ITEM_STOCK_PLANNING, NATS_USER } from '@config/nats.config';
import { Public } from '@core/decorator/set-public.decorator';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Body, Controller, Get, Put } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiBearerAuth } from '@nestjs/swagger';
import { ResponseBuilder } from '@utils/response-builder';
import { AppService } from './app.service';

@Controller()
@ApiBearerAuth('access-token')
export class AppController {
  constructor(
    private readonly appService: AppService,
    private readonly natsClientService: NatsClientService,
  ) {}

  @Get('/ping')
  @MessagePattern('ping')
  async ping(): Promise<any> {
    return await this.appService.ping();
  }

  @Public()
  @Get('health')
  getHealth(): string {
    return this.appService.getHealth();
  }

  @Put('update-permission')
  updatePermission(): Promise<void> {
    return this.appService.updatePermissions();
  }

  @MessagePattern(`${NATS_ITEM_STOCK_PLANNING}.ping`)
  pingServer(@Body() body: any) {
    return new ResponseBuilder()
      .withData({ msg: `${NATS_ITEM_STOCK_PLANNING}: pong`, data: body })
      .build();
  }

  @Get('ping-nats')
  async pingNats(): Promise<any> {
    const pingUser = await this.natsClientService.send(`${NATS_USER}.ping`, {
      msg: 'ping',
      queue: NATS_USER,
    });
    const pingSelf = await this.natsClientService.send(
      `${NATS_ITEM_STOCK_PLANNING}.ping`,
      {
        msg: 'ping',
        queue: NATS_ITEM_STOCK_PLANNING,
      },
    );
    return new ResponseBuilder()
      .withData({ data: { pingSelf, pingUser } })
      .build();
  }
}
