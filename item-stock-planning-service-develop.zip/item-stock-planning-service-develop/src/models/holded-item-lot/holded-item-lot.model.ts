import { BaseModel } from '@core/model/base.model';

export interface HoldedItemLotModel extends BaseModel {
  holdedItemId: string;
  holdedQuantity: number;
  stockQuantity: number;
  lotNumber: string;
  mfg: Date;
}
