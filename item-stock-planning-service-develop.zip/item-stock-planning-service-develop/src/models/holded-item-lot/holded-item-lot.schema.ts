import { DEFAULT_COLLATION } from '@constant/common';
import * as mongoose from 'mongoose';

export const HoldedItemLotSchema = new mongoose.Schema(
  {
    holdedItemId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'HoldedItem',
    },
    holdedQuantity: {
      type: Number,
      default: null,
    },
    stockQuantity: {
      type: Number,
      default: null,
    },
    lotNumber: {
      type: String,
      default: null,
    },
    mfg: {
      type: Date,
      default: null,
    },
  },
  {
    collection: 'holdedItemLots',
    id: true,
    timestamps: true,
    collation: DEFAULT_COLLATION,
  },
);
