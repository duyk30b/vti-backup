import { DEFAULT_COLLATION } from '@constant/common';
import * as mongoose from 'mongoose';

export const HoldedItemSchema = new mongoose.Schema(
  {
    itemId: {
      type: Number,
      required: true,
    },
    warehouseId: {
      type: Number,
      required: true,
    },
    holdedQuantity: {
      type: Number,
      default: null,
    },
    stockQuantity: {
      type: Number,
      default: null,
    },
  },
  {
    collection: 'holdedItems',
    id: true,
    timestamps: true,
    collation: DEFAULT_COLLATION,
  },
);

HoldedItemSchema.virtual('holdedItemLots', {
  ref: 'HoldedItemLotModel',
  localField: '_id',
  foreignField: 'holdedItemId',
  justOne: false,
});
