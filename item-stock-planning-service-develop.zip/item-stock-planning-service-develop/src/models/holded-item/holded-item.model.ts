import { BaseModel } from '@core/model/base.model';

export interface HoldedItemModel extends BaseModel {
  itemId: number;
  warehouseId: number;
  holdedQuantity: number;
  stockQuantity: number;
}
