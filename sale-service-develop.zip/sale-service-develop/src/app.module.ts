import { PurchasedOrderModule } from '@components/purchased-order/purchased-order.module';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AuthModule } from './components/auth/auth.module';
import { CoreModule } from './core/core.module';
import { ProductionOrderModule } from '@components/production-order/production-order.module';
import { SaleOrderModule } from '@components/sale-order/sale-order.module';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { I18nJsonLoader, I18nModule } from 'nestjs-i18n';
import * as path from 'path';
import { APP_GUARD, APP_PIPE } from '@nestjs/core';
import { ValidationPipe } from '@core/pipe/validation.pipe';
import { StaticModule } from '@components/static/static.module';
import { ProduceModule } from '@components/produce/produce.module';
import { SaleOrderExportModule } from '@components/sale-order-export/sale-order-export.module';
import { AuthorizationGuard } from '@core/guards/authorization.guard';
import { ConfigService } from '@config/config.service';
import { ClientProxyFactory } from '@nestjs/microservices';
import { PurchasedOrderImportModule } from '@components/purchased-order-import/purchased-order-import.module';
import { QueryResolver } from './i18n/query-resolver';
import { ImporOrderModule } from '@components/import-order/import-order.module';
import { ExportModule } from '@components/export/export.module';
import { InitDataModule } from '@components/init-data/init-data.module';
import { FileModule } from '@components/file/file.module';
import { ReturnOrderModule } from '@components/return-order/return-order.module';
import { BootModule } from '@nestcloud/boot';
import { resolve } from 'path';
import { ConsulModule } from '@nestcloud/consul';
import { BOOT, CONSUL } from '@nestcloud/common';
import { ServiceModule } from '@nestcloud/service';
import { HttpClientModule } from '@core/components/http-client/http-client.module';
import { KongGatewayModule } from '@core/components/kong-gateway/kong-gateway.module';
import { SnakeNamingStrategy } from 'typeorm-naming-strategies';
import { SourceModule } from '@components/source/source.module';
import { ReasonModule } from '@components/reason/reason.module';
import { ConstructionModule } from '@components/construcion/construction.module';
import { CategoryContructionModule } from '@components/category-contruction/category-contruction.module';
import { BullModule } from '@nestjs/bull';
import { ReceiptModule } from '@components/receipt/receipt.module';
import { OrganizationPaymentModule } from '@components/organization-payment/organization-payment.module';
import { CostTypeModule } from '@components/cost-type/cost-type.module';
import { SyncDataFromHqModule } from '@components/sync-from-hq/sync-data-from-hq.module';
import { isDevMode } from '@utils/helper';
import { DashboardModule } from '@components/dashboard/dashboard.module';
import { DatasyncModule } from '@components/datasync/datasync.module';
import { SettingModule } from '@components/setting/setting.module';
import { WarehouseLayoutModule } from '@components/warehouse-layout/warehouse-layout.module';
import { NatsClientModule } from '@core/transporter/nats-transporter/nats-client.module';
import { TcpClientModule } from '@core/transporter/tcp-transporter/tcp-client.module';
import { TicketModule } from '@components/ticket/ticket.module';
import { VendorCriteriaModule } from '@components/vendor-criteria/vendor-criteria.module';
import { CodeGenerationModule } from '@components/code-generation/code-generation.module';
import { RequestModule } from '@components/request/request.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    I18nModule.forRoot({
      fallbackLanguage: 'vi',
      loader: I18nJsonLoader,
      loaderOptions: {
        path: path.join(__dirname, '/i18n/'),
        watch: true,
      },
      resolvers: [{ use: QueryResolver, options: ['lang', 'locale', 'l'] }],
    }),
    BootModule.forRoot({
      filePath: resolve(__dirname, '../config.yaml'),
    }),
    ConsulModule.forRootAsync({ inject: [BOOT] }),
    ServiceModule.forRootAsync({ inject: [BOOT, CONSUL] }),
    HttpClientModule,
    KongGatewayModule.forRootAsync(),
    EventEmitterModule.forRoot(),
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: process.env.DATABASE_POSTGRES_HOST,
      port: parseInt(process.env.DATABASE_POSTGRES_PORT),
      username: process.env.DATABASE_POSTGRES_USERNAME,
      password: process.env.DATABASE_POSTGRES_PASSWORD,
      database: process.env.DATABASE_NAME,
      logging: true || isDevMode(),
      entities: [path.join(__dirname, '/entities/**/*.entity.{ts,js}')],
      migrations: [path.join(__dirname, '/database/migrations/*.{ts,js}')],
      subscribers: ['dist/observers/subscribers/*.subscriber.{ts,js}'],
      // We are using migrations, synchronize should be set to false.
      synchronize: false,
      // Run migrations automatically,
      // you can disable this if you prefer running migration manually.
      migrationsRun: !isDevMode(),
      extra: {
        max: parseInt(process.env.DATABASE_MAX_POOL) || 20,
      },
      namingStrategy: new SnakeNamingStrategy(),
    }),
    BullModule.forRoot({
      redis: {
        host: process.env.REDIS_HOST,
        port: Number(process.env.REDIS_PORT),
        password: process.env.REDIS_PASSWORD,
      },
    }),
    CoreModule,
    AuthModule,
    PurchasedOrderModule,
    PurchasedOrderImportModule,
    ProductionOrderModule,
    SaleOrderModule,
    ReturnOrderModule,
    StaticModule,
    ProduceModule,
    SaleOrderExportModule,
    ImporOrderModule,
    ExportModule,
    InitDataModule,
    FileModule,
    SourceModule,
    ReasonModule,
    CategoryContructionModule,
    ConstructionModule,
    ReceiptModule,
    OrganizationPaymentModule,
    CostTypeModule,
    SyncDataFromHqModule,
    DashboardModule,
    DatasyncModule,
    SettingModule,
    WarehouseLayoutModule,
    NatsClientModule,
    TcpClientModule.register('userService'),
    TicketModule,
    VendorCriteriaModule,
    CodeGenerationModule,
    RequestModule,
  ],
  controllers: [AppController],
  providers: [
    {
      provide: APP_PIPE,
      useClass: ValidationPipe,
    },
    {
      provide: APP_GUARD,
      useClass: AuthorizationGuard,
    },
    {
      provide: 'ConfigServiceInterface',
      useClass: ConfigService,
    },
    ConfigService,
    AppService,
  ],
})
export class AppModule {}
