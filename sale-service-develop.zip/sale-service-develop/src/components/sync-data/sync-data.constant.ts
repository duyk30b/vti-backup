export const NUMBER_RETRY_QUEUE = 5;

export enum StatusSyncEnum {
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR',
}

export enum UrlSyncDataEnum {
  Source = 'sources',
  PoImport = 'reports/sync/orders/purchased-order-import',
  SoExport = 'reports/sync/orders/sale-order-export',
  Receipt = 'reports/sync/receipt',
}

export enum RepositorySyncDataEnum {
  Source = 'Source',
  PoImport = 'PoImport',
  SoExport = 'SoExport',
}

export enum ProcessSyncDataEnum {
  CreateSource = 'sync_data-create_source',
  UpdateSource = 'sync_data-update_source',
  DeleteSource = 'sync_data-delete_source',
  ConfirmSource = 'sync_data-confirm_source',
  RejectSource = 'sync_data-reject_source',

  UpdatePoImport = 'sync_data-update_puchased-order-import',
  UpdatePoImportHQ = 'sync_data_hq-update_puchased-order-import',
  DeletePoImport = 'sync_data-delete_puchased-order-import',
  DeletePoImportHQ = 'sync_data_hq-delete_puchased-order-import',

  UpdateSoExport = 'sync_data-update_sale-order-export',
  UpdateSoExportHQ = 'sync_data_hq-update_sale-order-export',
  DeleteSoExport = 'sync_data-delete_sale-order-export',
  DeleteSoExportHQ = 'sync_data_hq-delete_sale-order-export',

  UpdateReceipt = 'sync_data-update_receipt',
  UpdateReceiptHQ = 'sync_data_hq-update_receipt',
}

export enum RequestMethodEnum {
  POST = 'POST',
  PUT = 'PUT',
  DELETE = 'DELETE',
}
export enum OrderType {
  EXPORT = 0,
  IMPORT = 1,
  INVENTORY = 2,
  TRANSFER = 3,
}

export enum TypeTransactionDataSyncEnum {
  WAREHOUSE_TRANSFER = 'Chuyển kho',
  PO_IMPORT = 'Phiếu nhập kho',
  SO_EXPORT = 'Phiếu xuất kho',
  TRANSACTION = 'Giao dịch',
  MASTER_DATA_WAREHOUSE = 'Kho',
}

export enum SYNC_TO_SYSTEM_ENUM {
  COMPANY_HQ = 'Tổng công ty',
  COMPANY = 'Công ty con',
  EBS = 'EBS',
  ECAT = 'ECAT',
}

export enum SYNC_FROM_SYSTEM_ENUM {
  COMPANY_HQ = 'Tổng công ty',
  WMS = 'WMS',
}
