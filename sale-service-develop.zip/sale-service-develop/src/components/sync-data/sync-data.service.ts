import { I18nService } from 'nestjs-i18n';
import { ApiError } from '@utils/api.error';
import { ConfigService } from '@config/config.service';
import { APIPrefix, StatusSyncOrderToEbsEnum } from '@constant/common';
import { HttpClientCronService } from '@core/components/http-client/http-client.cron.service';
import { Inject, Logger } from '@nestjs/common';
import { SyncDataServiceInterface } from './interface/sync-data.interface';
import { UrlSyncDataEnum } from './sync-data.constant';
import Job from 'bull';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { isEmpty } from 'lodash';
import {
  ActionTypeEnum,
  CompanyCreatedEnum,
  MasterDataTypeEnum,
  OrderType,
} from '@components/sync-from-hq/sync-data-from-hq.constant';
import { PurchasedOrderImportRepository } from '@repositories/purchased-order-import/purchased-order-import.repository';
import { SaleOrderExportRepository } from '@repositories/sale-order-export/sale-order-export.repository';
import { ResponseBuilder } from '@utils/response-builder';
import { Workbook } from 'exceljs';
import { ROW, SHEET } from '@components/export/export.constant';
import * as moment from 'moment';
import * as FormData from 'form-data';
import { JOB_SYNC_STATUS_ENUM } from '@components/datasync/datasync.constant';
import { DatasyncServiceInterface } from '@components/datasync/interface/datasync.service.interface';
import { STATUS_SYNC_ACCEPT_SYNC_PURCHASED_ORDER_IMPORT_TO_EBS } from '@components/purchased-order-import/purchased-order-import.contant';
import { STATUS_SYNC_ACCEPT_SYNC_SALE_ORDER_EXPORT_TO_EBS } from '@components/sale-order-export/sale-order-export.contant';

export class SyncDataService implements SyncDataServiceInterface {
  private readonly logger = new Logger(SyncDataService.name);
  constructor(
    @Inject('ConfigServiceInterface')
    private configService: ConfigService,
    private readonly httpClientService: HttpClientCronService,

    @Inject(PurchasedOrderImportRepository)
    private readonly purchasedOrderImportRepository: PurchasedOrderImportRepository,

    @Inject(SaleOrderExportRepository)
    private readonly saleOrderExportRepository: SaleOrderExportRepository,
    private readonly i18n: I18nService,

    @Inject('DatasyncServiceInterface')
    private datasyncService: DatasyncServiceInterface,
  ) {}
  protected readonly urlConfig = this.configService.get('hqService');
  protected readonly url = `http://${
    this.urlConfig.options.host + ':' + this.urlConfig.options.port
  }`;

  private getURL(url): string {
    return `${this.url}/${APIPrefix.Version}/reports/sync/${url}`;
  }

  async postRequest(request, url): Promise<any> {
    return await this.httpClientService.post(this.getURL(url), request, {
      sync: true,
      maxRetryAttempts: 1,
    });
  }

  async putRequest(request, url): Promise<any> {
    return await this.httpClientService.put(this.getURL(url), request);
  }

  async deleteRequest(request, url): Promise<any> {
    return await this.httpClientService.delete(this.getURL(url), request);
  }

  // Đồng bộ tài khoản kế toán
  async syncCreateSource(job: Job): Promise<any> {
    const { data } = job;
    const response = await this.postRequest(data.data, UrlSyncDataEnum.Source);
    await this.updateStatusSync(job, response);
  }

  async syncMasterData(
    job: Job,
    urlSyncData: UrlSyncDataEnum,
    actionTypeEnum: ActionTypeEnum,
  ): Promise<any> {
    const data = await this.getDataJob(job);
    let masterDataType;
    let orderType;
    switch (urlSyncData) {
      case UrlSyncDataEnum.Source:
        masterDataType = MasterDataTypeEnum.REASON;
        break;
      case UrlSyncDataEnum.PoImport:
        orderType = OrderType.IMPORT;
        break;
      case UrlSyncDataEnum.SoExport:
        orderType = OrderType.EXPORT;
      default:
        break;
    }
    let response = {};
    response = await this.postRequest(
      {
        actionType: actionTypeEnum,
        masterDataType,
        orderType,
        createdFrom: CompanyCreatedEnum.BUON_KUOP,
        data: data.data,
      },
      urlSyncData,
    );
    return await this.updateStatusSync(job, response);
  }

  async syncReportHQ(
    job: Job,
    urlSyncData: UrlSyncDataEnum,
    actionTypeEnum: ActionTypeEnum,
  ): Promise<any> {
    const data = await this.getDataJob(job);
    let orderType;
    switch (urlSyncData) {
      case UrlSyncDataEnum.PoImport:
        orderType = OrderType.IMPORT;
        break;
      case UrlSyncDataEnum.SoExport:
        orderType = OrderType.EXPORT;
      default:
        break;
    }
    let response = {};
    const reportService = this.configService.get('hqService');
    const urlReport = `http://${
      reportService.options.host + ':' + reportService.options.port
    }/${APIPrefix.Version}/${urlSyncData}`;
    console.error(
      `URL SYNC HQ http://${
        reportService.options.host + ':' + reportService.options.port
      }/${APIPrefix.Version}/${urlSyncData}`,
    );
    response = await this.httpClientService.post(
      urlReport,
      {
        actionType: actionTypeEnum,
        orderType,
        createdFrom: CompanyCreatedEnum.BUON_KUOP,
        data: data.data,
        callInternalService: false,
      },
      {
        sync: true,
      },
    );

    console.error(`RESPONSE SYNC HQ`, response);
    return await this.updateStatusSync(job, response);
  }

  async syncReport(
    job: Job,
    urlSyncData: UrlSyncDataEnum,
    actionTypeEnum: ActionTypeEnum,
  ): Promise<any> {
    const data = await this.getDataJob(job);
    let orderType;
    switch (urlSyncData) {
      case UrlSyncDataEnum.PoImport:
        orderType = OrderType.IMPORT;
        break;
      case UrlSyncDataEnum.SoExport:
        orderType = OrderType.EXPORT;
      default:
        break;
    }
    let response = {};
    const reportService = this.configService.get('reportService');
    const urlReport = `http://${
      reportService.options.host + ':' + reportService.options.port
    }/${APIPrefix.Version}/${urlSyncData}`;
    console.error(
      `URL SYNC http://${
        reportService.options.host + ':' + reportService.options.port
      }/${APIPrefix.Version}/${urlSyncData}`,
    );
    response = await this.httpClientService.post(
      urlReport,
      {
        actionType: actionTypeEnum,
        orderType,
        createdFrom: CompanyCreatedEnum.BUON_KUOP,
        data: data.data,
        callInternalService: false,
      },
      {
        sync: true,
      },
    );
    console.error(`RESPONSE SYNC`, response);
    return await this.updateStatusSync(job, response);
  }

  async syncPoImportToEbs(
    poImportId: number,
    data: any,
    headers: any,
    isUpdateHeader = false,
  ): Promise<any> {
    let sync, file, fileName;
    const order = await this.purchasedOrderImportRepository.findOneById(
      poImportId,
    );

    if (
      !STATUS_SYNC_ACCEPT_SYNC_PURCHASED_ORDER_IMPORT_TO_EBS.includes(
        order.syncStatus,
      )
    ) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.PURCHASE_ORDER_STATUS_IS_INVALID'),
      ).toResponse();
    }
    try {
      const configEndpointEbs = this.configService.get('endpointSyncEbs');
      const urlSyncEbs = `http://${configEndpointEbs.endpointEbs}/${configEndpointEbs.poImport}`;
      fileName =
        isUpdateHeader && !isEmpty(order.ebsId)
          ? `[Up]AccountAliasReceiptIN_${poImportId}_${moment().unix()}`
          : `AccountAliasReceiptIN_${poImportId}_${moment().unix()}`;
      file = await this.createBufferCsv(data, headers);
      const form = new FormData();
      form.append('file', file, fileName);
      sync = await this.httpClientService.post(urlSyncEbs, form, {
        callInternalService: false,
        headers: {
          'Content-type': 'text/csv',
          apiKey: configEndpointEbs.apiKey,
          siteid: configEndpointEbs.siteId,
          fileName: fileName,
        },
      });
      const infoLog = {
        fileName,
      };
      this.logger.log(
        `SYNC PO IMPORT TO EBS. Request: ${JSON.stringify(
          infoLog,
        )} Response: ${JSON.stringify(sync)}`,
      );
    } catch (error) {
      console.log(error);
      this.logger.error(`SYNC PO IMPORT TO EBS ERROR: ${error?.message}`);

      // order.syncStatus = StatusSyncOrderToEbsEnum.SYNC_WSO2_ERROR;
      // await this.purchasedOrderImportRepository.create(order);
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.INTERNAL_ERROR'),
      );
    }

    try {
      const form = new FormData();
      form.append('file', file, `${fileName}.csv`);
      form.append('service', 'sale-service');
      form.append('resource', 'sync-po');
      const configFileService = this.configService.get('fileService');
      const urlFile = `http://${configFileService.options.host}:${configFileService.options.port}/api/v1/files/single-file`;
      await this.httpClientService.post(urlFile, form, {
        callInternalService: false,
        sync: true,
      });
    } catch (error) {
      this.logger.error('Upload File Template Ebs Error');
    }

    order.syncStatus =
      sync?.code === ResponseCodeEnum.SUCCESS
        ? StatusSyncOrderToEbsEnum.SYNC_WSO2_SUCCESS
        : order.syncStatus;

    await this.purchasedOrderImportRepository.create(order);
    if (sync?.code === ResponseCodeEnum.SUCCESS) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } else {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(sync.message)
        .build();
    }
  }

  async syncSoExportToEbs(
    orderId: number,
    data: any,
    headers: any,
    isUpdateHeader: boolean,
  ): Promise<any> {
    let sync, file, fileName;
    const order = await this.saleOrderExportRepository.findOneById(orderId);
    if (
      !STATUS_SYNC_ACCEPT_SYNC_SALE_ORDER_EXPORT_TO_EBS.includes(
        order.syncStatus,
      )
    ) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.SALE_ORDER_EXPORT_STATUS_IS_INVALID'),
      ).toResponse();
    }
    try {
      const configEndpointEbs = this.configService.get('endpointSyncEbs');
      const urlSyncEbs = `http://${configEndpointEbs.endpointEbs}/${configEndpointEbs.soExport}`;
      fileName =
        isUpdateHeader && !isEmpty(order.ebsId)
          ? `[Up]AccountAliasIssueIN_${orderId}_${moment().unix()}`
          : `AccountAliasIssueIN_${orderId}_${moment().unix()}`;
      file = await this.createBufferCsv(data, headers);
      const form = new FormData();
      form.append('file', file, fileName);
      sync = await this.httpClientService.post(urlSyncEbs, form, {
        callInternalService: false,
        headers: {
          'Content-type': 'text/csv',
          apiKey: configEndpointEbs.apiKey,
          siteid: configEndpointEbs.siteId,
          fileName: fileName,
        },
      });
      const infoLog = {
        fileName,
      };
      this.logger.log(
        `SYNC SO EXPORT TO EBS. Request: ${JSON.stringify(
          infoLog,
        )} Response: ${JSON.stringify(sync)}`,
      );
    } catch (error) {
      console.log(error);
      this.logger.error(`SYNC SO EXPORT TO EBS ERROR: ${error?.message}`);

      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.INTERNAL_ERROR'),
      );
    }

    try {
      const form = new FormData();
      form.append('file', file, `${fileName}.csv`);
      form.append('service', 'sale-service');
      form.append('resource', 'sync-so');
      const configFileService = this.configService.get('fileService');
      const urlFile = `http://${configFileService.options.host}:${configFileService.options.port}/api/v1/files/single-file`;
      await this.httpClientService.post(urlFile, form, {
        callInternalService: false,
        sync: true,
      });
    } catch (error) {
      console.log(error);
    }

    order.syncStatus =
      sync?.code === ResponseCodeEnum.SUCCESS
        ? StatusSyncOrderToEbsEnum.SYNC_WSO2_SUCCESS
        : order.syncStatus;
    await this.saleOrderExportRepository.create(order);

    if (sync?.code === ResponseCodeEnum.SUCCESS) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } else {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(sync.message)
        .build();
    }
  }

  private async createBufferCsv(
    data: any,
    headers: any,
  ): Promise<Buffer | any> {
    const workbook = new Workbook();
    let countRowData = ROW.COUNT_START_ROW;
    let countSheet = SHEET.START_SHEET;
    data.forEach((element) => {
      let worksheet = workbook.getWorksheet(SHEET.NAME + countSheet);
      if (countRowData == ROW.COUNT_START_ROW) {
        worksheet = workbook.addWorksheet(SHEET.NAME + countSheet);
        const headerRow = worksheet.getRow(1);
        headerRow.values = headers.map((header) => header.title);
      }
      worksheet.columns = headers;
      worksheet.addRow({
        ...element,
      });

      countRowData++;
      if (countRowData == ROW.COUNT_END_ROW) {
        countSheet++;
        countRowData = ROW.COUNT_START_ROW;
      }
    });
    return await workbook.csv.writeBuffer();
  }

  // Update trạng thái đồng bộ master data
  async updateStatusSync(job: Job, response): Promise<any> {
    this.logger.log(
      `SYNC: JobID (${job?.data?.jobSyncId}), Response (${JSON.stringify(
        response,
      )})`,
    );
    await this.datasyncService.updateJobStatus(
      job.data?.jobSyncId,
      this.getStatusByResponse(response),
    );
  }

  private getStatusByResponse(response): JOB_SYNC_STATUS_ENUM {
    let status;
    switch (response.statusCode) {
      case ResponseCodeEnum.SUCCESS:
        status = JOB_SYNC_STATUS_ENUM.SUCCESS;
        break;
      default:
        status = JOB_SYNC_STATUS_ENUM.ERROR_SYNC;
        break;
    }
    return status;
  }

  private async getDataJob(job: Job): Promise<any> {
    const data = await this.datasyncService.getDetailJob(job.data.jobSyncId);
    return data?.object;
  }

  private getMessageByResponse(response): string {
    return response.message;
  }
}
