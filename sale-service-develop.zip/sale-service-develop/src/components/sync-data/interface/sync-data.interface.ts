import { ActionTypeEnum } from '@components/sync-from-hq/sync-data-from-hq.constant';
import Job from 'bull';
import { UrlSyncDataEnum } from '../sync-data.constant';

export interface SyncDataServiceInterface {
  syncCreateSource(job: Job): Promise<any>;
  syncMasterData(
    job: Job,
    urlSyncData: UrlSyncDataEnum,
    actionTypeEnum: ActionTypeEnum,
  ): Promise<any>;
  syncReport(
    job: Job,
    urlSyncData: UrlSyncDataEnum,
    actionTypeEnum: ActionTypeEnum,
  ): Promise<any>;
  syncReportHQ(
    job: Job,
    urlSyncData: UrlSyncDataEnum,
    actionTypeEnum: ActionTypeEnum,
  ): Promise<any>;
  updateStatusSync(job: Job, response): Promise<any>;
  syncPoImportToEbs(
    poImportId: number,
    data: any,
    headers: any,
    isUpdateHeader: boolean,
  ): Promise<any>;
  syncSoExportToEbs(
    orderId: number,
    data: any,
    headers: any,
    isUpdateHeader: boolean,
  ): Promise<any>;
}
