import { JOB_SYNC_STATUS_ENUM } from '@components/datasync/datasync.constant';
import { DatasyncServiceInterface } from '@components/datasync/interface/datasync.service.interface';
import { ActionTypeEnum } from '@components/sync-from-hq/sync-data-from-hq.constant';
import { QUEUES_NAME_ENUM } from '@constant/common';
import {
  OnQueueActive,
  OnQueueCompleted,
  OnQueueError,
  OnQueueFailed,
  Process,
  Processor,
} from '@nestjs/bull';
import { Inject, Logger } from '@nestjs/common';
import { Job } from 'bull';
import { StatusSyncResponseDto } from './dto/response/status-sync.response.dto';
import { SyncDataServiceInterface } from './interface/sync-data.interface';
import {
  ProcessSyncDataEnum,
  StatusSyncEnum,
  UrlSyncDataEnum,
} from './sync-data.constant';

@Processor(QUEUES_NAME_ENUM.SYNC_DATA_QUEUE)
export class SyncDataConsumer {
  private logger = new Logger(SyncDataConsumer.name);
  constructor(
    @Inject('SyncDataServiceInterface')
    private readonly syncDataService: SyncDataServiceInterface,

    @Inject('DatasyncServiceInterface')
    private datasyncService: DatasyncServiceInterface,
  ) {}
  //Purchased Order Import
  @Process(ProcessSyncDataEnum.UpdatePoImport)
  async syncUpdatePoImport(job: Job) {
    await this.syncDataService.syncReport(
      job,
      UrlSyncDataEnum.PoImport,
      ActionTypeEnum.UPDATE,
    );
  }

  @Process(ProcessSyncDataEnum.UpdatePoImportHQ)
  async syncUpdatePoImportHQ(job: Job) {
    await this.syncDataService.syncReportHQ(
      job,
      UrlSyncDataEnum.PoImport,
      ActionTypeEnum.UPDATE,
    );
  }

  @Process(ProcessSyncDataEnum.DeletePoImport)
  async syncDeletePoImport(job: Job) {
    await this.syncDataService.syncReport(
      job,
      UrlSyncDataEnum.PoImport,
      ActionTypeEnum.DELETE,
    );
  }

  @Process(ProcessSyncDataEnum.DeletePoImportHQ)
  async syncDeletePoImportHQ(job: Job) {
    await this.syncDataService.syncReportHQ(
      job,
      UrlSyncDataEnum.PoImport,
      ActionTypeEnum.DELETE,
    );
  }

  //Sale order export
  @Process(ProcessSyncDataEnum.UpdateSoExport)
  async syncUpdateSoExport(job: Job) {
    await this.syncDataService.syncReport(
      job,
      UrlSyncDataEnum.SoExport,
      ActionTypeEnum.UPDATE,
    );
  }

  @Process(ProcessSyncDataEnum.UpdateSoExportHQ)
  async syncUpdateSoExportHQ(job: Job) {
    await this.syncDataService.syncReportHQ(
      job,
      UrlSyncDataEnum.SoExport,
      ActionTypeEnum.UPDATE,
    );
  }

  @Process(ProcessSyncDataEnum.DeleteSoExport)
  async syncDeleteSoExport(job: Job) {
    await this.syncDataService.syncReport(
      job,
      UrlSyncDataEnum.SoExport,
      ActionTypeEnum.DELETE,
    );
  }

  @Process(ProcessSyncDataEnum.DeleteSoExportHQ)
  async syncDeleteSoExportHQ(job: Job) {
    await this.syncDataService.syncReportHQ(
      job,
      UrlSyncDataEnum.SoExport,
      ActionTypeEnum.DELETE,
    );
  }
  @Process(ProcessSyncDataEnum.UpdateReceipt)
  async syncUpdateReceipt(job: Job) {
    await this.syncDataService.syncReport(
      job,
      UrlSyncDataEnum.Receipt,
      ActionTypeEnum.UPDATE,
    );
  }

  @Process(ProcessSyncDataEnum.UpdateReceiptHQ)
  async syncUpdateReceiptHQ(job: Job) {
    await this.syncDataService.syncReportHQ(
      job,
      UrlSyncDataEnum.Receipt,
      ActionTypeEnum.UPDATE,
    );
  }

  @OnQueueActive()
  async onActive(job: Job) {
    await this.datasyncService.updateJobStatus(
      job.data?.jobSyncId,
      JOB_SYNC_STATUS_ENUM.IN_PROGRESS,
    );
    this.logger.log('Active Job sync data: ' + job.data?.jobSyncId);
  }

  @OnQueueCompleted()
  async onCompleted(job: Job) {
    await this.datasyncService.updateJobStatus(
      job.data?.jobSyncId,
      JOB_SYNC_STATUS_ENUM.SUCCESS,
    );
    this.logger.log('Complete Job sync data: ' + job.data?.jobSyncId);
  }

  @OnQueueFailed()
  async onFailed(job: Job) {
    const response = {
      status: StatusSyncEnum.ERROR,
      message: 'Failed',
    } as StatusSyncResponseDto;
    await this.syncDataService.updateStatusSync(job, response);
    this.logger.warn('Failed Job sync data: ' + job.data?.jobSyncId);
  }

  @OnQueueError()
  onError(error: Error) {
    this.logger.error('Error job sync data: ' + error.message);
  }
}
