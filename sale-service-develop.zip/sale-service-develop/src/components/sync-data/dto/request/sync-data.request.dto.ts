import { RepositorySyncDataEnum } from '@components/sync-data/sync-data.constant';
import { IsEnum, IsInt, IsString } from 'class-validator';

export class SyncDataRequestDto {
  @IsString()
  @IsEnum(RepositorySyncDataEnum)
  masterData: string;

  @IsInt()
  id: number;

  data: any;

  jobSyncId: string;
}
