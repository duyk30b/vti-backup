import { StatusSyncEnum } from '@components/sync-data/sync-data.constant';

export class StatusSyncResponseDto {
  jobId?: number;
  status?: StatusSyncEnum;
  message?: string;
  createdAt: Date;
}
