import { DatasyncModule } from '@components/datasync/datasync.module';
import { ConfigService } from '@config/config.service';
import { QUEUES_NAME_ENUM } from '@constant/common';
import { PurchasedOrderImportEntity } from '@entities/purchased-order-import/purchased-order-import.entity';
import { SaleOrderExport } from '@entities/sale-order-export/sale-order-export.entity';
import { SourceEntity } from '@entities/source/source.entity';
import { BullModule } from '@nestjs/bull';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PurchasedOrderImportRepository } from '@repositories/purchased-order-import/purchased-order-import.repository';
import { SaleOrderExportRepository } from '@repositories/sale-order-export/sale-order-export.repository';
import { SourceRepository } from '@repositories/source/source.repository';
import { SyncDataConsumer } from './sync-data.consumer';
import { SyncDataService } from './sync-data.service';

@Module({
  imports: [
    BullModule.registerQueue({
      name: QUEUES_NAME_ENUM.SYNC_DATA_QUEUE,
    }),
    TypeOrmModule.forFeature([
      SourceEntity,
      PurchasedOrderImportEntity,
      SaleOrderExport,
      DatasyncModule,
    ]),
  ],
  providers: [
    {
      provide: 'SyncDataServiceInterface',
      useClass: SyncDataService,
    },
    {
      provide: 'ConfigServiceInterface',
      useClass: ConfigService,
    },
    SourceRepository,
    PurchasedOrderImportRepository,
    SaleOrderExportRepository,
    SyncDataConsumer,
  ],
  exports: [
    {
      provide: 'SyncDataServiceInterface',
      useClass: SyncDataService,
    },
    {
      provide: 'ConfigServiceInterface',
      useClass: ConfigService,
    },
    SyncDataConsumer,
  ],
  controllers: [],
})
export class SyncDataModule {}
