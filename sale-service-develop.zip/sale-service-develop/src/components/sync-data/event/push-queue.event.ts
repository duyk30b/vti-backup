export class PushQueueEvent {
  process: string;
  resourceCode?: string;
  typeTransaction?: string;
  toSystem?: string;
}
