import { DatasyncServiceInterface } from '@components/datasync/interface/datasync.service.interface';
import { QUEUES_NAME_ENUM } from '@constant/common';
import { InjectQueue } from '@nestjs/bull';
import { Inject, Injectable } from '@nestjs/common';
import Queue from 'bull';
import { SyncDataRequestDto } from '../dto/request/sync-data.request.dto';
import { PushQueueEvent } from '../event/push-queue.event';
import { NUMBER_RETRY_QUEUE } from '../sync-data.constant';

@Injectable()
export class SyncDataToHQListener {
  constructor(
    @InjectQueue(QUEUES_NAME_ENUM.SYNC_DATA_QUEUE)
    protected queue: Queue,

    @Inject('DatasyncServiceInterface')
    protected datasyncService: DatasyncServiceInterface,
  ) {}

  async pushQueue(info: PushQueueEvent, data: SyncDataRequestDto) {
    let jobSyncId = data.jobSyncId;
    if (!jobSyncId) {
      const jobSync = await this.datasyncService.createJob(info, data);
      jobSyncId = jobSync?.id;
    }
    await this.queue.add(
      info.process,
      { jobSyncId: jobSyncId },
      {
        attempts: NUMBER_RETRY_QUEUE,
        removeOnComplete: true,
        removeOnFail: true,
      },
    );
  }
}
