import { Public } from '@core/decorator/set-public.decorator';
import { Body, Controller, Inject, Post } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { InsertDataRequestDto } from './dto/request/insert-data.request.dto';
import { InitDataServiceInterface } from './interface/init-data.service.interface';

@Controller('init-insert-data')
export class InitDataController {
  constructor(
    @Inject('InitDataServiceInterface')
    private readonly initDataService: InitDataServiceInterface,
  ) {}

  @Public()
  @Post('/')
  @ApiOperation({
    tags: ['Items'],
    summary: 'init insert data',
    description: 'init insert data',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: null,
  })
  // @MessagePattern('sale_service_insert_data')
  public async createSector(
    @Body() payload: InsertDataRequestDto[],
  ): Promise<any> {
    return await this.initDataService.insertData(payload);
  }
}
