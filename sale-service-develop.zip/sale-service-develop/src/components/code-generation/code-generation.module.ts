import { Module } from '@nestjs/common';
import { CodeGenerationController } from './code-generation.controller';
import { CodeGenerationService } from './code-generation.service';
import { ConfigModule } from '@nestjs/config';

@Module({
  imports: [ConfigModule],
  providers: [
    {
      provide: 'CodeGenerationServiceInterface',
      useClass: CodeGenerationService,
    },
  ],
  controllers: [CodeGenerationController],
})
export class CodeGenerationModule {}
