import { CodeGenerationRequestDto } from '../dto/request/code-generation.request.dto';

export interface CodeGenerationServiceInterface {
  generateCode(request: CodeGenerationRequestDto): Promise<any>;
}
