import { isEmpty } from 'lodash';
import { Controller, Get, Inject, Query } from '@nestjs/common';
import { CodeGenerationServiceInterface } from './interface/code-generation.service.interface';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { CodeGenerationRequestDto } from './dto/request/code-generation.request.dto';

@Controller('generate-codes')
export class CodeGenerationController {
  constructor(
    @Inject('CodeGenerationServiceInterface')
    private readonly generateCodeService: CodeGenerationServiceInterface,
  ) {}

  @Get('/')
  @ApiOperation({
    tags: ['GenerateCode'],
    summary: 'Generate code',
    description: 'Generate code',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully',
    type: null,
  })
  public async generateCode(
    @Query() payload: CodeGenerationRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.generateCodeService.generateCode(request);
  }
}
