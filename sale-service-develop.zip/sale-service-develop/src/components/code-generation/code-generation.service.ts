import { isEmpty, first } from 'lodash';
import { Injectable } from '@nestjs/common';
import { CodeGenerationRequestDto } from './dto/request/code-generation.request.dto';
import { CodeGenerationServiceInterface } from './interface/code-generation.service.interface';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { CODE_GEN_PRIFIX, CODE_GEN_TABLE } from '@constant/common';
import { generateCode } from '@utils/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { CodeGenerationTypeEnum } from './code-generation.constant';

@Injectable()
export class CodeGenerationService implements CodeGenerationServiceInterface {
  constructor(
    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async generateCode(request: CodeGenerationRequestDto): Promise<any> {
    const { type } = request;

    let prefix;
    let tableName;

    switch (type) {
      case CodeGenerationTypeEnum.VENDOR:
        prefix = CODE_GEN_PRIFIX.VENDOR;
        tableName = CODE_GEN_TABLE.VENDOR;
        break;
      case CodeGenerationTypeEnum.SALE_ORDER:
        prefix = CODE_GEN_PRIFIX.SALE_ORDER;
        tableName = CODE_GEN_TABLE.SALE_ORDER;
        break;
      default:
        break;
    }

    if (!tableName) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const queryRunner = await this.connection.createQueryRunner();
    try {
      const query = `SELECT "tbl"."code" FROM ${tableName} "tbl" WHERE "tbl"."deleted_at" IS NULL ORDER BY "tbl"."created_at" DESC LIMIT 1;`;

      const lastCode = await queryRunner.query(query);

      const generatedCode = isEmpty(lastCode)
        ? generateCode(prefix)
        : generateCode(prefix, first(lastCode).code);

      return new ResponseBuilder({
        code: generatedCode,
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
  }
}
