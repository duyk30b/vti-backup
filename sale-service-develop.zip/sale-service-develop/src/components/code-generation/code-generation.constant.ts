export enum CodeGenerationTypeEnum {
  VENDOR = 0,
  SALE_ORDER = 1,
}
