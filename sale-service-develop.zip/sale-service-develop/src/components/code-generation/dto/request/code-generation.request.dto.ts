import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt } from 'class-validator';

export class CodeGenerationRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  @Transform((v) => +v.value)
  type: number;
}
