import { ConfirmCostTypeRequestDto } from '../dto/request/confirm-cost-type.request.dto';
import { CreateCostTypeRequestDto } from '../dto/request/create-cost-type.request.dto';
import { DeleteCostTypeRequestDto } from '../dto/request/delete-cost-type.request.dto';
import { GetCostTypeRequestDto } from '../dto/request/get-cost-type-detail.request.dto';
import { GetCostTypeListRequestDto } from '../dto/request/get-cost-type-list.request.dto';
import { UpdateCostTypeRequestDto } from '../dto/request/update-cost-type.request.dto';

export interface CostTypeServiceInterface {
  getDetail(request: GetCostTypeRequestDto): Promise<any>;
  getList(request: GetCostTypeListRequestDto): Promise<any>;
  create(request: CreateCostTypeRequestDto): Promise<any>;
  update(request: UpdateCostTypeRequestDto): Promise<any>;
  delete(request: DeleteCostTypeRequestDto): Promise<any>;
  confirm(request: ConfirmCostTypeRequestDto): Promise<any>;
  reject(request: ConfirmCostTypeRequestDto): Promise<any>;
  getCostTypeByIds(ids: number[]): Promise<any>;
}
