import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { CostTypeEntity } from '@entities/cost-type/cost-type.entity';
import { CreateCostTypeRequestDto } from '../dto/request/create-cost-type.request.dto';
import { GetCostTypeListRequestDto } from '../dto/request/get-cost-type-list.request.dto';
import { UpdateCostTypeRequestDto } from '../dto/request/update-cost-type.request.dto';

export interface CostTypeRepositoryInterface
  extends BaseInterfaceRepository<CostTypeEntity> {
  createEntity(request: CreateCostTypeRequestDto): CostTypeEntity;
  updateEntity(
    entity: CostTypeEntity,
    request: UpdateCostTypeRequestDto,
  ): CostTypeEntity;
  getList(request: GetCostTypeListRequestDto): Promise<any>;
}
