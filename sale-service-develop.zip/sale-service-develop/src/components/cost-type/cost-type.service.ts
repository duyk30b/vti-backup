import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { CostTypeEntity } from '@entities/cost-type/cost-type.entity';
import { Injectable, Inject } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, ILike, In, Not } from 'typeorm';
import {
  CONFIRMABLE_COST_TYPE_STATUSES,
  CostTypeStatus,
  REJECTABLE_COST_TYPE_STATUSES,
} from './cost-type.constants';
import { ConfirmCostTypeRequestDto } from './dto/request/confirm-cost-type.request.dto';
import { CreateCostTypeRequestDto } from './dto/request/create-cost-type.request.dto';
import { DeleteCostTypeRequestDto } from './dto/request/delete-cost-type.request.dto';
import { GetCostTypeRequestDto } from './dto/request/get-cost-type-detail.request.dto';
import { GetCostTypeListRequestDto } from './dto/request/get-cost-type-list.request.dto';
import { UpdateCostTypeRequestDto } from './dto/request/update-cost-type.request.dto';
import { CostTypeResponseDto } from './dto/response/cost-type.response.dto';
import { CostTypeRepositoryInterface } from './interface/cost-type.repository.interface';
import { CostTypeServiceInterface } from './interface/cost-type.service.interface';
@Injectable()
export class CostTypeService implements CostTypeServiceInterface {
  constructor(
    @InjectDataSource()
    private readonly connection: DataSource,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('CostTypeRepositoryInterface')
    private readonly costTypeRepository: CostTypeRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateCostTypeRequestDto): Promise<any> {
    const existingCostTypeEntity =
      await this.costTypeRepository.findOneByCondition({
        code: ILike(request.code),
      });
    if (existingCostTypeEntity) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('message.defineCostType.codeExist'),
        )
        .build();
    }
    const costType = this.costTypeRepository.createEntity(request);
    return await this.save(costType);
  }

  async update(request: UpdateCostTypeRequestDto): Promise<any> {
    const existingCostTypeEntity = await this.costTypeRepository.findOneById(
      request.id,
    );

    if (!existingCostTypeEntity) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const existingCode = await this.costTypeRepository.findOneByCondition({
      code: ILike(request.code),
      id: Not(request.id),
    });
    if (existingCode) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.message.defineCostType.codeExist'),
        )
        .build();
    }

    const costType = this.costTypeRepository.updateEntity(
      existingCostTypeEntity,
      request,
    );
    return await this.save(costType, true);
  }

  async delete(request: DeleteCostTypeRequestDto): Promise<any> {
    const costType = await this.costTypeRepository.findOneById(request.id);
    if (!costType) {
      return new ResponseBuilder(costType)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    costType.deletedAt = new Date();
    costType.deletedBy = request.userId;
    await this.costTypeRepository.create(costType);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(
        await this.i18n.translate('message.defineCostType.deleteSuccess'),
      )
      .build();
  }

  async confirm(request: ConfirmCostTypeRequestDto): Promise<any> {
    const costType = await this.costTypeRepository.findOneById(request.id);
    if (!costType) {
      return new ResponseBuilder(costType)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CONFIRMABLE_COST_TYPE_STATUSES.includes(costType.status)) {
      return new ResponseBuilder(costType)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CONFIRM'))
        .build();
    }
    costType.status = CostTypeStatus.ACTIVE;
    await this.costTypeRepository.create(costType);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(
        await this.i18n.translate('message.defineCostType.confirmSuccess'),
      )
      .build();
  }

  async reject(request: ConfirmCostTypeRequestDto): Promise<any> {
    const costType = await this.costTypeRepository.findOneById(request.id);
    if (!costType) {
      return new ResponseBuilder(costType)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!REJECTABLE_COST_TYPE_STATUSES.includes(costType.status)) {
      return new ResponseBuilder(costType)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.CAN_NOT_REJECT'))
        .build();
    }
    costType.status = CostTypeStatus.CREATED;
    await this.costTypeRepository.create(costType);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(
        await this.i18n.translate('message.defineCostType.rejectSuccess'),
      )
      .build();
  }

  async getDetail(request: GetCostTypeRequestDto): Promise<any> {
    const costType = await this.costTypeRepository.findOneById(request.id);

    if (!costType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const response = await this.generateRespone(costType);
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(request: GetCostTypeListRequestDto): Promise<any> {
    const { page } = request;
    const [data, count] = await this.costTypeRepository.getList(request);
    const creatorIds = data.map((item) => item.createdBy);
    const updaterIds = data.map((item) => item.updatedBy);
    const userIds = uniq([...creatorIds, ...updaterIds]);
    if (userIds.length > 0) {
      const users = await this.userService.getUsers(uniq(userIds), true);
      data.forEach((item) => {
        item.createdBy = users[item.createdBy];
        item.updatedBy = users[item.updatedBy];
      });
    }

    const dataReturn = plainToInstance(CostTypeResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getCostTypeByIds(ids: number[]): Promise<any> {
    const costTypes = await this.costTypeRepository.findByCondition({
      id: In(ids),
    });

    if (!costTypes) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const response = plainToInstance(CostTypeResponseDto, costTypes, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async save(
    costTypeEntity: CostTypeEntity,
    isUpdate = false,
  ): Promise<ResponsePayload<any> | any> {
    try {
      const result = await this.costTypeRepository.create(costTypeEntity);
      const response = await this.generateRespone(result);
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            isUpdate
              ? 'message.defineCostType.updateSuccess'
              : 'message.defineCostType.createSuccess',
          ),
        )
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder(error)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .build();
    }
  }

  private async generateRespone(
    costTypeEntity: CostTypeEntity,
  ): Promise<CostTypeResponseDto> {
    const userIds = [costTypeEntity.createdBy, costTypeEntity.updatedBy];
    const users = await this.userService.getUsers(uniq(userIds), true);
    costTypeEntity.createdBy = users[costTypeEntity.createdBy];
    costTypeEntity.updatedBy = users[costTypeEntity.updatedBy];
    const response = plainToInstance(CostTypeResponseDto, costTypeEntity, {
      excludeExtraneousValues: true,
    });
    return response;
  }
}
