import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { CostTypeEntity } from '@entities/cost-type/cost-type.entity';
import { OrganizationPaymentEntity } from '@entities/organization-payment/organization-payment.entity';
import { SourceEntity } from '@entities/source/source.entity';
import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CostTypeRepository } from '@repositories/cost-type/cost-type.repository';
import { OrganizationPaymentRepository } from '@repositories/organization-payment/organization-payment.repository';
import { SourceRepository } from '@repositories/source/source.repository';
import { CostTypeController } from './cost-type.controller';
import { CostTypeService } from './cost-type.service';

@Global()
@Module({
  imports: [
    TypeOrmModule.forFeature([
      CostTypeEntity,
      SourceEntity,
      OrganizationPaymentEntity,
    ]),
    UserModule,
  ],
  providers: [
    {
      provide: 'CostTypeRepositoryInterface',
      useClass: CostTypeRepository,
    },
    {
      provide: 'SourceRepositoryInterface',
      useClass: SourceRepository,
    },
    {
      provide: 'OrganizationPaymentRepositoryInterface',
      useClass: OrganizationPaymentRepository,
    },
    {
      provide: 'CostTypeServiceInterface',
      useClass: CostTypeService,
    },
  ],
  controllers: [CostTypeController],
  exports: [
    {
      provide: 'CostTypeServiceInterface',
      useClass: CostTypeService,
    },
    {
      provide: 'CostTypeRepositoryInterface',
      useClass: CostTypeRepository,
    },
  ],
})
export class CostTypeModule {}
0;
