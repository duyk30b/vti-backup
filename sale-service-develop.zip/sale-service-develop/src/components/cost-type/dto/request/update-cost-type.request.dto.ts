import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt } from 'class-validator';
import { CreateCostTypeRequestDto } from './create-cost-type.request.dto';

export class UpdateCostTypeBodyDto extends CreateCostTypeRequestDto {}
export class UpdateCostTypeRequestDto extends UpdateCostTypeBodyDto {
  @ApiProperty({ example: '', description: '' })
  @Transform(({ value }) => Number(value))
  @IsInt()
  id: number;
}
