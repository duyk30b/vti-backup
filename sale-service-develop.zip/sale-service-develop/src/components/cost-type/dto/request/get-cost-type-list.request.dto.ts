import { PaginationQuery } from '@utils/pagination.query';

export class GetCostTypeListRequestDto extends PaginationQuery {}
