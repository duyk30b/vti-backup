import {
  ORGANIZATION_PAYMENT_RULES,
  Warehouse,
} from '@components/organization-payment/organization-payment.constants';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsEnum,
  IsInt,
  IsOptional,
  IsString,
  Matches,
  MaxLength,
} from 'class-validator';

export class CreateCostTypeRequestDto extends BaseDto {
  @ApiProperty({ example: '', description: '' })
  @IsString()
  @MaxLength(ORGANIZATION_PAYMENT_RULES.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: '', description: '' })
  @IsString()
  @Matches(ORGANIZATION_PAYMENT_RULES.CODE.REGEX)
  code: string;

  @ApiProperty({ example: '', description: '' })
  @IsString()
  @MaxLength(ORGANIZATION_PAYMENT_RULES.DESCRIPTION.MAX_LENGTH)
  description: string;
}
