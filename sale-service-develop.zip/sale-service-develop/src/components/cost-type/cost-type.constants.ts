export const COST_TYPE_RULES = {
  NAME: {
    MAX_LENGTH: 255,
  },
  CODE: {
    MAX_LENGTH: 20,
    REGEX: /^[0-9a-zA-Z]{1,20}$/,
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
};

export enum Warehouse {
  AVENUE = '0',
}

export enum CostTypeStatus {
  CREATED = 0,
  ACTIVE = 1,
}

export const CONFIRMABLE_COST_TYPE_STATUSES = [CostTypeStatus.CREATED];
export const REJECTABLE_COST_TYPE_STATUSES = [CostTypeStatus.ACTIVE];
