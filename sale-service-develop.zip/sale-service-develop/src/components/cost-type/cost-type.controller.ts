import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  Controller,
  Inject,
  Post,
  Body,
  Put,
  Param,
  ParseIntPipe,
  Delete,
  Get,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import {
  CONFIRM_COST_TYPE_PERMISSION,
  CREATE_COST_TYPE_PERMISSION,
  DELETE_COST_TYPE_PERMISSION,
  DETAIL_COST_TYPE_PERMISSION,
  LIST_COST_TYPE_PERMISSION,
  REJECT_COST_TYPE_PERMISSION,
  UPDATE_COST_TYPE_PERMISSION,
} from '@utils/permissions/cost-type';
import { isEmpty } from 'lodash';
import { ConfirmCostTypeRequestDto } from './dto/request/confirm-cost-type.request.dto';
import { CreateCostTypeRequestDto } from './dto/request/create-cost-type.request.dto';
import { DeleteCostTypeRequestDto } from './dto/request/delete-cost-type.request.dto';
import { getCostTypeByIdsRequestDto } from './dto/request/get-cost-type-by-ids.request.dto';
import { GetCostTypeRequestDto } from './dto/request/get-cost-type-detail.request.dto';
import { GetCostTypeListRequestDto } from './dto/request/get-cost-type-list.request.dto';
import { UpdateCostTypeBodyDto } from './dto/request/update-cost-type.request.dto';
import { CostTypeResponseDto } from './dto/response/cost-type.response.dto';
import { CostTypeServiceInterface } from './interface/cost-type.service.interface';

@Controller('cost-types')
export class CostTypeController {
  constructor(
    @Inject('CostTypeServiceInterface')
    private readonly costTypeService: CostTypeServiceInterface,
  ) {}

  @PermissionCode(CREATE_COST_TYPE_PERMISSION.code)
  @Post('create')
  @ApiOperation({
    tags: ['CostType'],
    summary: 'Create new loại chi phí',
    description: 'Tạo 1 loại chi phí mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async create(@Body() body: CreateCostTypeRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.costTypeService.create(request);
  }

  @PermissionCode(UPDATE_COST_TYPE_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['CostType'],
    summary: 'Update loại chi phí',
    description: 'Sửa loại chi phí',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async update(
    @Body() body: UpdateCostTypeBodyDto,
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.costTypeService.update({ ...request, id });
  }

  @PermissionCode(DELETE_COST_TYPE_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['CostType'],
    summary: 'Delete loại chi phí',
    description: 'Xóa loại chi phí',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async delete(@Param() param: DeleteCostTypeRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.costTypeService.delete(request);
  }

  @PermissionCode(DETAIL_COST_TYPE_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['CostType'],
    summary: 'Get loại chi phí',
    description: 'Lấy loại chi phí',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: CostTypeResponseDto,
  })
  public async getDetail(@Param() param: GetCostTypeRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.costTypeService.getDetail(request);
  }

  @PermissionCode(CONFIRM_COST_TYPE_PERMISSION.code)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['CostType'],
    summary: 'Confirm loại chi phí',
    description: 'Xác nhận loại chi phí',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: CostTypeResponseDto,
  })
  public async confirm(
    @Param() param: ConfirmCostTypeRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.costTypeService.confirm(request);
  }

  @PermissionCode(REJECT_COST_TYPE_PERMISSION.code)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['CostType'],
    summary: 'Reject loại chi phí',
    description: 'Từ chối loại chi phí',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: CostTypeResponseDto,
  })
  public async reject(@Param() param: ConfirmCostTypeRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.costTypeService.reject(request);
  }

  @PermissionCode(LIST_COST_TYPE_PERMISSION.code)
  @Get('list')
  @ApiOperation({
    tags: ['CostType'],
    summary: 'Get list loại chi phí',
    description: 'Lấy danh sách loại chi phí',
  })
  @ApiResponse({
    status: 200,
    description: 'Get list successfully',
    type: null,
  })
  public async getList(
    @Query() query: GetCostTypeListRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.costTypeService.getList(request);
  }

  @MessagePattern('get_cost_type_by_ids')
  public async getCostTypeByIds(
    @Body() body: getCostTypeByIdsRequestDto
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.costTypeService.getCostTypeByIds(request.ids);
  }
}
