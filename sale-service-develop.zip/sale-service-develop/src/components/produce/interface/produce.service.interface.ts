import { CreateMoForQcRejectQuantity } from '../dto/request/create-mo-for-qc-reject-quantity.request.dto';

export interface ProduceServiceInterface {
  getBoqByIds(ids: number[], serilize?: boolean): Promise<any>;
  getMoByIds(ids: number[], serilize?: boolean): Promise<any>;
  getMoItemLots(id: number, serilize?: boolean): Promise<any>;
  getMOBySaleOrderId(id: number, serilize?: boolean): Promise<any>;
  createMoForQcReject(
    data: CreateMoForQcRejectQuantity,
    getResponse?: boolean,
  ): Promise<any>;
  getAllManufacturingOrder(payload: any): Promise<any>;
  getMoByCodes(codes: string[], serilize?: boolean);
  getBoqByCodes(codes: string[], serilize?: boolean): Promise<any>;
  getBomByItemIds(itemIds: number[]): Promise<any>;
  getMaterialImportWorkCenter(moId: number, itemIds: number[]): Promise<any>;
  getExportWorkCenter(moId: number, itemIds: number[]): Promise<any>;
  getFinishedItemLots(moId: number, itemIds: number[]): Promise<any>;
  getMoGroupBySo(payload: any): Promise<any>
}
