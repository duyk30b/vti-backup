import { CODE_TO_MO_REWORK, NAME_TO_MO_REWORK } from '@constant/order.constant';
import { BaseDto } from '@core/dto/base.dto';
import { Expose, Transform } from 'class-transformer';
import {
  IsNotEmpty,
  IsInt,
  IsString,
  IsDateString,
  ArrayNotEmpty,
  ArrayUnique,
  ValidateNested,
} from 'class-validator';

class MoItemRequest {
  @Expose()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @Expose()
  @IsNotEmpty()
  @IsInt()
  quantity: number;
}

export class CreateMoForQcRejectQuantity extends BaseDto {
  @Expose()
  @IsNotEmpty()
  @IsString()
  @Transform((data) => `${NAME_TO_MO_REWORK} ${data.obj.saleOrderExportId}`)
  name: string;

  @Expose()
  @IsNotEmpty()
  @IsString()
  @Transform(
    (data) =>
      `${(+new Date()).toString().slice(5)}_${data.obj.saleOrderExportId}`,
  )
  code: string;

  @Expose()
  @IsNotEmpty()
  @IsInt()
  factoryId: number;

  @Expose()
  @IsNotEmpty()
  @IsInt()
  saleOrderId: number;

  @Expose()
  @IsNotEmpty()
  @IsDateString()
  @Transform(() => new Date())
  planFrom: Date;

  @Expose()
  @IsNotEmpty()
  @IsDateString()
  @Transform((data) => data.obj.deadline)
  planTo: Date;

  @Expose()
  @ValidateNested()
  @ArrayNotEmpty()
  @ArrayUnique()
  @Transform((data) => [
    {
      id: data.obj.itemId,
      quantity: data.obj.qcRejectQuantity,
    },
  ])
  moItems: MoItemRequest[];

  @Expose()
  @IsNotEmpty()
  @IsInt()
  @Transform((data) => data.obj.userId)
  createdByUserId: number;
}
