import { ProduceService } from '@components/produce/produce.service';
import { ConfigService } from '@config/config.service';
import { NatsClientModule } from '@core/transporter/nats-transporter/nats-client.module';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';

@Global()
@Module({
  imports: [ConfigModule, NatsClientModule],
  exports: [
    {
      provide: 'ProduceServiceInterface',
      useClass: ProduceService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'ProduceServiceInterface',
      useClass: ProduceService,
    },
  ],
  controllers: [],
})
export class ProduceModule {}
