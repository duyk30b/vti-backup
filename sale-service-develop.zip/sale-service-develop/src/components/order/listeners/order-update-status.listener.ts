import { Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { OrderUpdateStatusEvent } from '../events/order-update-status.event';

@Injectable()
export class OrderUpdateStatusListener {
  @OnEvent('order.updateStatus')
  handleOrderCreatedEvent(event: OrderUpdateStatusEvent) {
    // handle and process "OrderCreatedEvent" event
    // console.log(event);
  }
}
