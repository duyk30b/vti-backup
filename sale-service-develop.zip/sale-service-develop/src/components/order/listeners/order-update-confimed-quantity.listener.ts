import { OrderUpdateConfirmedQuantityEvent } from '../events/order-update-confirmed-quantity.event';
import { Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';

@Injectable()
export class OrderUpdateConfirmedQuantityListener {
  @OnEvent('order.updateConfirmedQuantity')
  handleOrderCreatedEvent(event: OrderUpdateConfirmedQuantityEvent) {
    // handle and process "OrderCreatedEvent" event
    // console.log(event);
  }
}
