import {
  CAN_UPDATE_STATUS_ORDER_TO_IN_PROGRESS,
  OrderStatusEnum,
} from '@constant/common';
import { Injectable } from '@nestjs/common';

@Injectable()
export class OrderUpdateActualQuantityListener {
  public async checkAndUpdateInProgessOrderStatus(order) {
    if (!order) return;
    if (!CAN_UPDATE_STATUS_ORDER_TO_IN_PROGRESS.includes(order.status)) return;
    order.status = OrderStatusEnum.InProgress;
    return await this.updateInProgessOrderStatus(order);
  }

  public async updateInProgessOrderStatus(order): Promise<any> {
    return null;
  }
}
