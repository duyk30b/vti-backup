import { Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { OrderUpdateReturnQuantityEvent } from '../events/order-update-return-quantity.event';

@Injectable()
export class OrderUpdateReturnQuantityListener {
  @OnEvent('order.updateReturnQuantity')
  handleOrderCreatedEvent(event: OrderUpdateReturnQuantityEvent) {
    // handle and process "OrderCreatedEvent" event
    // console.log(event);
  }
}
