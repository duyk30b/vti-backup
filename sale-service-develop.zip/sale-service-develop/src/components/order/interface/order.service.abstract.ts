import { WarehouseServiceInterface } from './../../warehouse/interface/warehouse.service.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { OrderServiceInterface } from '@components/order/interface/order.service.interface';
import { Inject } from '@nestjs/common';
import { CreateOrderRequestDto } from '../dto/request/create-order-resquest.dto';
import { GetOrderDetailRequestDto } from '../dto/request/get-order-detail.request.dto';
import { GetOrderListRequest } from '../dto/request/get-order-list.request.dto';
import { UpdateOrderDetailActualQuantityRequestDto } from '../dto/request/update-actual-quantity-order-detail.request.dto';
import { UpdateOrderDetailConfirmQuantityRequestDto } from '../dto/request/update-confirm-quantity-order-detail.request.dto';
import { SetOrderStatusRequestDto } from '../dto/request/set-order-status-request.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { DeleteOrderRequestDto } from '../dto/request/delete-order.request.dto';
import { GetListOrderByIdsRequestDto } from '../dto/request/get-list-order-by-ids.request.dto';
import { GetOrderDetailByWarehouseRequestDto } from '../dto/request/get-order-detail-by-warehouse.request.dto';
import { GetOrderWarehouseRequest } from '../dto/request/get-order-warehouse.request.dto';
import { isEmpty } from '../../../utils/object.util';
import { find } from 'lodash';
import { UpdateOrderDetailReturnQuantityRequestDto } from '../dto/request/update-return-quantity-order-detail.request.dto';
import { SourceRepositoryInterface } from '@components/source/interface/sources.repository.interface';
import { ReasonRepositoryInterface } from '@components/reason/interface/reason.repository.interface';

export class OrderServiceAbstract implements OrderServiceInterface {
  constructor(
    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('SourceRepositoryInterface')
    protected readonly sourceRepository?: SourceRepositoryInterface,

    @Inject('ReasonRepositoryInterface')
    protected readonly reasonRepository?: ReasonRepositoryInterface,
  ) {}
  getDetailByWarehouseId(
    payload: GetOrderDetailByWarehouseRequestDto,
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }
  getListOrderWarehouse(request: GetOrderWarehouseRequest): Promise<any> {
    throw new Error('Method not implemented.');
  }
  getListByIds(payload: GetListOrderByIdsRequestDto): Promise<any> {
    throw new Error('Method not implemented.');
  }
  delete(payload: DeleteOrderRequestDto): Promise<any> {
    throw new Error('Method not implemented.');
  }
  confirm(payload: SetOrderStatusRequestDto): Promise<any> {
    throw new Error('Method not implemented.');
  }

  reject(payload: SetOrderStatusRequestDto): Promise<any> {
    throw new Error('Method not implemented.');
  }
  approve(ipayload: SetOrderStatusRequestDto): Promise<any> {
    throw new Error('Method not implemented.');
  }
  update(payload: CreateOrderRequestDto): Promise<any> {
    throw new Error('Method not implemented.');
  }
  create(payload: CreateOrderRequestDto): Promise<any> {
    throw new Error('Method not implemented.');
  }
  getWarehouseDetails(
    id: number,
    warehouseId: number,
    type: number,
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }
  updateOrderDetailActualQuantity(
    payload: UpdateOrderDetailActualQuantityRequestDto,
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }
  updateOrderDetailConfirmQuantity(
    payload: UpdateOrderDetailConfirmQuantityRequestDto,
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }
  updateOrderDetailReturnQuantity(
    payload: UpdateOrderDetailReturnQuantityRequestDto,
  ): Promise<any> {
    throw new Error('Method not implemented.');
  }
  getList(payload: GetOrderListRequest): Promise<any> {
    throw new Error('Method not implemented.');
  }
  getDetail(payload: GetOrderDetailRequestDto): Promise<any> {
    throw new Error('Method not implemented.');
  }
  /**
   * Get list items and warehouses
   * @param itemIds number[]
   * @param warehouseIds number[]
   * @param userIds number[]
   * @returns
   */
  protected async getOrderExtraInfo(
    itemIds: number[],
    warehouseIds: number[],
    userIds: number[],
    basicInfor?: boolean,
    sourceId?: number,
    reasonId?: number
  ): Promise<any> {
    const data = await Promise.all([
      this.itemService.getItems(itemIds, basicInfor),
      this.warehouseService.getWarehouses(warehouseIds),
      this.userService.getUsers(userIds),
      sourceId ? this.sourceRepository.findOneById(sourceId) : {},
      reasonId ? this.reasonRepository.findOneById(reasonId) : {},
    ]);

    return {
      items: data[0],
      warehouses: data[1],
      users: data[2],
      source: data[3],
      reason: data[4],
    };
  }

  /**
   *
   * @param userId
   * @param warehouseId
   * @returns
   */
  protected async validateWarehouseIsOfUser(
    userId: number,
    warehouseId: number,
  ): Promise<boolean> {
    const warehouses = await this.userService.getUserWarehousesById(userId);
    if (isEmpty(warehouses)) {
      return false;
    }

    if (
      !find(warehouses, (userWarehouse) => userWarehouse.id === warehouseId)
    ) {
      return false;
    }

    return true;
  }
}
