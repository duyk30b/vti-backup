import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { GetOrderListRequest } from '../dto/request/get-order-list.request.dto';

export interface OrderRepositoryInterface<T>
  extends BaseInterfaceRepository<T> {
  getWarehouseDetails(
    id: number,
    warehouseId: number,
    type: number,
  ): Promise<any>;

  getList(
    request: GetOrderListRequest,
    manufacturingOrders?: any[],
    saleOrders?: any[],
    saleOrderIds?: number[],
  ): Promise<any>;
  getListByIds(ids: number[], withDetail?: boolean): Promise<any>;
  getDetail(id: number): Promise<any>;
  getDetailByWarehouseId(
    id: number,
    warehouseIds: number[],
    withCompletedOrder?: number,
    orderType?: number,
    withOrderDefault?: number,
  ): Promise<any>;
  delete(id: number): Promise<any>;
  checkReadyToComplete(id: number): Promise<any>;
  setCompleted(id: number): Promise<T>;
}
