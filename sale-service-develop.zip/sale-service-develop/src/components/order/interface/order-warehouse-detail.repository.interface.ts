import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { GetOrderWarehouseRequest } from '../dto/request/get-order-warehouse.request.dto';
import { UpdateWarehouseOrderDetailActualQuantity } from '../dto/request/update-actual-quantity-order-detail.request.dto';
import { UpdateWarehouseOrderDetailConfirmQuantity } from '../dto/request/update-confirm-quantity-order-detail.request.dto';
export interface OrderWarehouseDetailRepositoryInterface<T>
  extends BaseInterfaceRepository<T> {
  getUpdateOrderWarehouseDetailActualQuantityByIds(
    orderId: number,
    data: UpdateWarehouseOrderDetailActualQuantity[],
  ): Promise<T[]>;
  getUpdateOrderWarehouseDetailConfirmQuantityByIds(
    orderId: number,
    data: UpdateWarehouseOrderDetailConfirmQuantity[],
  ): Promise<T[]>;
  getListOrderWarehouse(
    request: GetOrderWarehouseRequest,
    warehouseIds: number[],
  ): Promise<any>;
}
