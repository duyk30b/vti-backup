import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { UpdateOrderDetailActualQuantity } from '../dto/request/update-actual-quantity-order-detail.request.dto';
import { UpdateOrderDetailConfirmQuantity } from '../dto/request/update-confirm-quantity-order-detail.request.dto';
export interface OrderDetailRepositoryInterface<T>
  extends BaseInterfaceRepository<T> {
  getUpdateOrderDetailActualQuantityByIds(
    orderId: number,
    data: UpdateOrderDetailActualQuantity[],
  ): Promise<T[]>;

  getUpdateOrderDetailConfirmQuantityByIds(
    orderId: number,
    data: UpdateOrderDetailConfirmQuantity[],
  ): Promise<T[]>;
}
