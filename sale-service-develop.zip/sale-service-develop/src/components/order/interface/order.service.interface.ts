import { GetOrderDetailByWarehouseRequestDto } from './../dto/request/get-order-detail-by-warehouse.request.dto';
import { GetListOrderByIdsRequestDto } from './../dto/request/get-list-order-by-ids.request.dto';
import { SetOrderStatusRequestDto } from './../dto/request/set-order-status-request.dto';
import { GetOrderDetailRequestDto } from './../dto/request/get-order-detail.request.dto';
import { GetOrderListRequest } from './../dto/request/get-order-list.request.dto';
import { CreateOrderRequestDto } from '../dto/request/create-order-resquest.dto';
import { UpdateOrderDetailActualQuantityRequestDto } from '../dto/request/update-actual-quantity-order-detail.request.dto';
import { UpdateOrderDetailConfirmQuantityRequestDto } from '../dto/request/update-confirm-quantity-order-detail.request.dto';
import { DeleteOrderRequestDto } from '../dto/request/delete-order.request.dto';
import { GetOrderWarehouseRequest } from '../dto/request/get-order-warehouse.request.dto';
import { UpdateOrderDetailReturnQuantityRequestDto } from '../dto/request/update-return-quantity-order-detail.request.dto';

export interface OrderServiceInterface {
  create(payload: CreateOrderRequestDto): Promise<any>;
  update(payload: CreateOrderRequestDto): Promise<any>;
  confirm(payload: SetOrderStatusRequestDto): Promise<any>;
  reject(payload: SetOrderStatusRequestDto): Promise<any>;
  approve(payload: SetOrderStatusRequestDto): Promise<any>;
  delete(payload: DeleteOrderRequestDto): Promise<any>;
  getListByIds(payload: GetListOrderByIdsRequestDto): Promise<any>;

  getWarehouseDetails(
    id: number,
    warehouseId: number,
    type: number,
  ): Promise<any>;

  updateOrderDetailActualQuantity(
    payload: UpdateOrderDetailActualQuantityRequestDto,
  ): Promise<any>;

  updateOrderDetailConfirmQuantity(
    payload: UpdateOrderDetailConfirmQuantityRequestDto,
  ): Promise<any>;

  updateOrderDetailReturnQuantity(
    payload: UpdateOrderDetailReturnQuantityRequestDto,
  ): Promise<any>;

  getList(payload: GetOrderListRequest): Promise<any>;
  getDetail(payload: GetOrderDetailRequestDto): Promise<any>;
  getDetailByWarehouseId(
    payload: GetOrderDetailByWarehouseRequestDto,
  ): Promise<any>;
  getListOrderWarehouse(request: GetOrderWarehouseRequest): Promise<any>;
}
