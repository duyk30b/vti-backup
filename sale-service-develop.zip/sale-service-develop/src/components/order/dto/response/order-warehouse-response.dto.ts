import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

export class ItemLotResponse {
  @ApiProperty()
  @Expose()
  lotNumber: string;
}

export class ItemIdResponse {
  @ApiProperty()
  @Expose({ name: 'id' })
  id: number;

  @ApiProperty({ isArray: true })
  @Expose()
  @Type(() => ItemLotResponse)
  lots: ItemLotResponse[];
}

export class OrderWarehouseResponse {
  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  warehouseName: string;

  @ApiProperty()
  @Expose()
  warehouseCode: string;

  @ApiProperty()
  @Expose()
  factoryId: number;

  @ApiProperty()
  @Expose()
  factoryName: string;

  @ApiProperty({ isArray: true, type: ItemIdResponse })
  @Expose()
  @Type(() => ItemIdResponse)
  items: ItemIdResponse[];
}

export class FactoryResponse {
  @ApiProperty()
  @Expose({ name: 'id' })
  factoryId: number;

  @ApiProperty()
  @Expose({ name: 'name' })
  factoryName: string;
}
