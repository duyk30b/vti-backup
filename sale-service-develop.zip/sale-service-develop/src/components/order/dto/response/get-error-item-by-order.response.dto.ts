import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Transform, Type } from 'class-transformer';

class ErrorLot {
  @Expose()
  lotNumber: string;

  @Expose()
  @Transform((data) => data.obj.qcRejectQuantity || 0)
  quantity: number;
}

export class ErrorItem {
  @Expose()
  itemId: number;

  @Expose()
  @Type(() => ErrorLot)
  lots: ErrorLot[];
}

export class ErrorItemByOrderResponseDto extends SuccessResponse {
  @Expose()
  @Type(() => ErrorItem)
  items: ErrorItem[];
}
