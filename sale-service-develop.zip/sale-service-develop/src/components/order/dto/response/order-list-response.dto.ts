import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class OrderListResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  deadline: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  confirmedAt: Date;

  @ApiProperty()
  @Expose()
  approvedAt: Date;

  @ApiProperty()
  @Expose()
  purchasedOrderId: number;
}
