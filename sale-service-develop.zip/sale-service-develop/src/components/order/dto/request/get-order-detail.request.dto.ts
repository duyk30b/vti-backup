import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';

export class GetOrderDetailQueryRequestDto extends BaseDto {}

export class GetOrderDetailRequestDto extends GetOrderDetailQueryRequestDto {
  @IsNotEmpty()
  @IsInt()
  @Transform(({ value }) => Number(value))
  id: number;
}
