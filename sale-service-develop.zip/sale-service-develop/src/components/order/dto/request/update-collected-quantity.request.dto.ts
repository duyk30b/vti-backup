import { ApiProperty } from '@nestjs/swagger';
import {
  IsDecimal,
  IsInt,
  IsNotEmpty,
  IsObject,
  IsOptional,
  IsString,
} from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';

export class UpdateOrderDetailCollectedQuantity {
  @IsInt()
  @IsNotEmpty()
  id: number;

  @IsDecimal()
  @IsNotEmpty()
  quantity: number;
}

export class ItemLot {
  @IsInt()
  @IsNotEmpty()
  itemId: number;

  @IsInt()
  @IsNotEmpty()
  warehouseId: number;

  @IsString()
  @IsNotEmpty()
  lotNumber: string;

  @IsDecimal()
  @IsNotEmpty()
  quantity: number;
}

export class UpdateWarehouseOrderDetailCollectedQuantity {
  @IsInt()
  @IsNotEmpty()
  id: number;

  @IsDecimal()
  @IsNotEmpty()
  quantity: number;
}
export class UpdateCollectedQuantityRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  orderId: number;

  @ApiProperty()
  @IsObject()
  @IsNotEmpty()
  orderDetails: UpdateOrderDetailCollectedQuantity[];

  @ApiProperty()
  @IsObject()
  @IsNotEmpty()
  warehouseOrderDetails: UpdateWarehouseOrderDetailCollectedQuantity[];

  @ApiProperty()
  @IsOptional()
  @IsNotEmpty()
  itemLots: ItemLot[];
}
