import { IsInt, IsNotEmpty, IsOptional } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { Transform } from 'class-transformer';

export class GetOrderDetailByWarehouseQueryDto extends BaseDto {
  @IsOptional()
  user: any;

  @IsOptional()
  @IsInt()
  @Transform(({ value }) => Number(value))
  warehouseShelfFloorId: number;

  @IsOptional()
  @IsInt()
  @Transform(({ value }) => Number(value))
  withCompletedOrder: number;

  @IsOptional()
  @IsInt()
  @Transform(({ value }) => Number(value))
  withOrderDefault: number;

  @IsOptional()
  @IsInt()
  @Transform(({ value }) => Number(value))
  orderType: number;
}

export class GetOrderDetailByWarehouseRequestDto extends GetOrderDetailByWarehouseQueryDto {
  @IsNotEmpty()
  @IsInt()
  id: number;

  @IsNotEmpty()
  @IsInt()
  warehouseId: number;
}
