import { PaginationQuery } from '@utils/pagination.query';
import { Transform } from 'class-transformer';
import { IsNotEmpty, IsInt } from 'class-validator';

export class GetOrderWarehouseQueryRequest extends PaginationQuery {
  @IsNotEmpty()
  user: any;
}

export class GetOrderWarehouseRequest extends GetOrderWarehouseQueryRequest {
  @IsNotEmpty()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: string;
}
