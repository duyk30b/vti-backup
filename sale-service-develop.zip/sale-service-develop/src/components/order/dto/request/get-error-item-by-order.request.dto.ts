import { BaseDto } from '@core/dto/base.dto';
import { IsNotEmpty } from 'class-validator';

export class GetErrorItemByOrderQueryDto extends BaseDto {}

export class GetErrorItemByOrderRequestDto extends GetErrorItemByOrderQueryDto {
  @IsNotEmpty()
  id: number;
}
