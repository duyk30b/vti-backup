import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import {
  IsOptional,
  IsNotEmpty,
  IsString,
  IsArray,
  IsIn,
  IsEnum,
} from 'class-validator';

class Sort {
  @IsString()
  @IsNotEmpty()
  column: string;

  @IsString()
  @IsNotEmpty()
  @IsIn(['ASC', 'DESC'])
  order: any;
}

class Filter {
  @IsString()
  @IsNotEmpty()
  column: string;

  @IsString()
  @IsNotEmpty()
  text: string;
}
export class GetOrderListRequest extends PaginationQuery {
  @IsOptional()
  keyword: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll: string;

  @IsOptional()
  user: any;

  @IsOptional()
  @IsArray()
  filter: Filter[];

  @IsOptional()
  @IsArray()
  sort: Sort[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  onlyCreatedFromMo: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isWarehouse: string;
}
