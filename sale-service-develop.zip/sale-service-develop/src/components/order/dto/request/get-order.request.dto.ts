import { OrderTypeEnum } from '@constant/common';
import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsInt, IsNotEmpty } from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';

export class GetOrderRequestBodyDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  warehouseId: number;

  @ApiProperty()
  @IsEnum(OrderTypeEnum)
  @IsNotEmpty()
  type: OrderTypeEnum;
}

export class GetOrderRequestDto extends GetOrderRequestBodyDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  id: number;
}
