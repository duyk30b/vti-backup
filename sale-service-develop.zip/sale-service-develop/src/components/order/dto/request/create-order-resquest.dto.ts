import { OrderTypeEnum } from '@constant/common';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsArray,
  IsDateString,
  IsDecimal,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  Length,
} from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';

class ItemRequest {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsDecimal()
  quantity: number;
}

export class CreateOrderRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @IsInt()
  createdByUserId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @Length(1, 255)
  name: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @Length(0, 255)
  description: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(OrderTypeEnum)
  type: OrderTypeEnum;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @Length(1, 24)
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  deadline: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  items: ItemRequest[];

  @ApiProperty()
  @IsOptional()
  @IsString()
  @Length(1, 255)
  requestId: string;
}
