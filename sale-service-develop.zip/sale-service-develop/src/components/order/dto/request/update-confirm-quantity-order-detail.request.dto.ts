import { ApiProperty } from '@nestjs/swagger';
import { IsDecimal, IsInt, IsNotEmpty, IsObject } from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';

export class UpdateOrderDetailConfirmQuantity {
  @IsInt()
  @IsNotEmpty()
  id: number;

  @IsDecimal()
  @IsNotEmpty()
  quantity: number;
}

export class UpdateWarehouseOrderDetailConfirmQuantity {
  @IsInt()
  @IsNotEmpty()
  id: number;

  @IsDecimal()
  @IsNotEmpty()
  quantity: number;
}
export class UpdateOrderDetailConfirmQuantityRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  orderId: number;

  @ApiProperty()
  @IsObject()
  @IsNotEmpty()
  orderDetails: UpdateOrderDetailConfirmQuantity[];

  @ApiProperty()
  @IsObject()
  @IsNotEmpty()
  warehouseOrderDetails: UpdateWarehouseOrderDetailConfirmQuantity[];

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  userId: number;
}
