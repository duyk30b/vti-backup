import { BaseDto } from '@core/dto/base.dto';
import { IsInt, IsNotEmpty, IsOptional } from 'class-validator';

export class GetOrderByWarehouseItemRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsInt()
  id: number;

  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @IsOptional()
  @IsInt()
  withCompletedOrder: number;
}
