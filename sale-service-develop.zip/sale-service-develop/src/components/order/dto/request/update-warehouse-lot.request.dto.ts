import { ApiProperty } from '@nestjs/swagger';
import { BaseDto } from 'src/core/dto/base.dto';
import {
  IsString,
  IsNotEmpty,
  IsDecimal,
  IsInt,
  IsArray,
} from 'class-validator';

export class ItemLot {
  @IsString()
  @IsNotEmpty()
  lotNumber: string;

  @IsDecimal()
  @IsNotEmpty()
  quantity: number;
}

export class ItemLotOrderDetailActualQuantity {
  @IsInt()
  @IsNotEmpty()
  itemId: number;

  @ApiProperty()
  @IsArray()
  @IsNotEmpty()
  lots: ItemLot[];
}

export class UpdateWarehouseLotRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  orderId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  warehouseId: number;

  @ApiProperty()
  @IsArray()
  @IsNotEmpty()
  itemLotOrderDetails: ItemLotOrderDetailActualQuantity[];
}
