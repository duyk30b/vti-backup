import { Transform } from 'class-transformer';
import { IsNotEmpty, IsInt, IsOptional, Allow } from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';

export class SetOrderStatusBodyDto extends BaseDto {
  @IsOptional()
  createdByUserId: number;
}

export class SetOrderStatusRequestDto extends SetOrderStatusBodyDto {
  @IsNotEmpty()
  @IsInt()
  @Transform(({ value }) => Number(value))
  id: number;
}
