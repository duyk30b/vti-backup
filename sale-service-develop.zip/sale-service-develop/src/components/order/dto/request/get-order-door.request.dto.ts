import { GetOrderWarehouseRequest } from "./get-order-warehouse.request.dto";

export class GetOrderDoorRequestDto extends GetOrderWarehouseRequest {}