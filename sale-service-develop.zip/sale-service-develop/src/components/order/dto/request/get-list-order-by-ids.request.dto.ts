import { Expose, Transform } from 'class-transformer';
import { IsArray, IsBoolean, IsNotEmpty, IsOptional } from 'class-validator';
import { isJson } from 'src/helper/string.helper';
import { BaseDto } from './../../../../core/dto/base.dto';
export class GetListOrderByIdsRequestDto extends BaseDto {
  @Expose()
  @IsNotEmpty()
  @Transform(({ value }) => {
    if (value instanceof Array) {
      return value;
    }
    
    if (value && value.includes('\\"')) value = value.replace(/\\/g, '');

    if (isJson(value) && JSON.parse(value) instanceof Array) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    } else {
      return value.split(',');
    }
  })
  @IsArray()
  ids: number[];

  @Expose()
  @IsOptional()
  @IsBoolean()
  withDetail: boolean;
}
