export class OrderUpdateConfirmedQuantityEvent {
  constructor({ id, orderType }) {
    this.id = id;
    this.orderType = orderType;
  }
  id: number;
  orderType: number;
  userId?: number;
}
