export class OrderUpdateActualQuantityEvent {
  constructor({ id, orderType }) {
    this.id = id;
    this.orderType = orderType;
  }
  id: number;
  orderType: number;
}
