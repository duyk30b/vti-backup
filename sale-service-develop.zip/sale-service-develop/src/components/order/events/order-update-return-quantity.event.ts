export class OrderUpdateReturnQuantityEvent {
  constructor({ id, orderType }) {
    this.id = id;
    this.orderType = orderType;
  }
  id: number;
  orderType: number;
}
