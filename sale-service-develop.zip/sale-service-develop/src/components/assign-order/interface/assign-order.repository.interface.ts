import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { AssignOrderEntity } from '@entities/assign-order/assign-order.entity';

export interface AssignOrderRepositoryInterface
  extends BaseInterfaceRepository<AssignOrderEntity> {
  createEntity(request: any): AssignOrderEntity;
}
