import { NATS_PLAN } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { keyBy } from 'lodash';
import { PlanServiceInterface } from './interface/plan.service.interface';

@Injectable()
export class PlanService implements PlanServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async getMasterPlans(request: any, serialize?: false): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PLAN}.get_master_plans`,
      {
        ...request,
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return {};
    }

    if (serialize) {
      return keyBy(response.data.masterPlans, 'id');
    }
    return response.data.masterPlans;
  }
}
