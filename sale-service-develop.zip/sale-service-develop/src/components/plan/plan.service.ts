import { Inject, Injectable } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { PlanServiceInterface } from './interface/plan.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { keyBy } from 'lodash';
import { ItemManufacturingOrderResponseDto } from './dto/response/item-manufacturing-order.response.dto';

@Injectable()
export class PlanService implements PlanServiceInterface {
  constructor(
    @Inject('PLAN_SERVICE_CLIENT')
    private readonly planServiceClient: ClientProxy, // @Inject(REQUEST) private readonly req: Request,
  ) {}

  async getMasterPlans(request: any, serialize?: false): Promise<any> {
    const response = await this.planServiceClient
      .send('get_master_plans', {
        ...request,
      })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return {};
    }

    if(serialize) {
      return keyBy(response.data.masterPlans, 'id')
    }
    return response.data.masterPlans;
  }
}
