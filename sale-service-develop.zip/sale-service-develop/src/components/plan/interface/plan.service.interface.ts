import { ItemManufacturingOrderResponseDto } from '../dto/response/item-manufacturing-order.response.dto';

export interface PlanServiceInterface {
  getMasterPlans(request: any, serialize?: boolean): Promise<any>;
}
