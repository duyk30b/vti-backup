import { ConfigService } from '@config/config.service';
import { NatsClientModule } from '@core/transporter/nats-transporter/nats-client.module';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PlanService } from './plan.service';

@Global()
@Module({
  imports: [ConfigModule, NatsClientModule],
  exports: [
    {
      provide: 'PlanServiceInterface',
      useClass: PlanService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'PlanServiceInterface',
      useClass: PlanService,
    },
  ],
  controllers: [],
})
export class PlanModule {}
