import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ClientProxyFactory } from '@nestjs/microservices';
import { ConfigService } from '@config/config.service';
import { PlanService } from './plan.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    'PLAN_SERVICE_CLIENT',
    {
      provide: 'PlanServiceInterface',
      useClass: PlanService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'PLAN_SERVICE_CLIENT',
      useFactory: (configService: ConfigService) => {
        const planServiceOptions = configService.get('planService');
        return ClientProxyFactory.create(planServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'PlanServiceInterface',
      useClass: PlanService,
    },
  ],
  controllers: [],
})
export class PlanModule {}
