import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ClientProxyFactory } from '@nestjs/microservices';
import { ConfigService } from '@config/config.service';
import { QualityControlService } from './quality-control.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    'QMSX_SERVICE_CLIENT',
    {
      provide: 'QualityControlServiceInterface',
      useClass: QualityControlService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'QMSX_SERVICE_CLIENT',
      useFactory: (configService: ConfigService) => {
        const qmsxServiceOptions = configService.get('qmsxService');
        return ClientProxyFactory.create(qmsxServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'QualityControlServiceInterface',
      useClass: QualityControlService,
    },
  ],
  controllers: [],
})
export class QmsxModule {}
