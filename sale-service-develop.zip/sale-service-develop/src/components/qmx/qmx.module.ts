import { ConfigService } from '@config/config.service';
import { NatsClientModule } from '@core/transporter/nats-transporter/nats-client.module';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { QualityControlService } from './quality-control.service';

@Global()
@Module({
  imports: [ConfigModule, NatsClientModule],
  exports: [
    {
      provide: 'QualityControlServiceInterface',
      useClass: QualityControlService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'QualityControlServiceInterface',
      useClass: QualityControlService,
    },
  ],
  controllers: [],
})
export class QmsxModule {}
