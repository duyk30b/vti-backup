import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty, IsArray } from 'class-validator';

class Order {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  qcStageId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  orderId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  actualQuantity: number;
}

export class UpdateActualQuantityPlanIoQcRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  data: Order[];
}
