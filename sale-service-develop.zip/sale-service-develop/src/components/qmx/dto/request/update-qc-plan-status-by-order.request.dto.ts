import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsInt } from 'class-validator';
import { QCPlanStatus } from '@components/qmx/qmsx.constant';

export class UpdateQcPlanStatusByOrderIdRequestDto {
  @ApiProperty()
  @IsInt()
  orderId: number;

  @ApiProperty()
  @IsEnum(QCPlanStatus)
  status: number;
}
