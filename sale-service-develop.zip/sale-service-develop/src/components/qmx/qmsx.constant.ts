export enum QCPlanStatus {
  Awaiting,
  Confirmed,
  InProgress,
  Completed,
}
