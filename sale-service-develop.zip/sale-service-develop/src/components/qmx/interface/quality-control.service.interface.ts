import { UpdateQcPlanStatusByOrderIdRequestDto } from '../dto/request/update-qc-plan-status-by-order.request.dto';

export interface QualityControlServiceInterface {
  getQualityPointById(id: number): Promise<any>;
  getQualityPoints(ids: number[]): Promise<any>;
  getQualityPointByCodes(codes: string[]): Promise<any>;
  updateQcPlanStatusByOrderId(
    payload: UpdateQcPlanStatusByOrderIdRequestDto,
  ): Promise<any>;
}
