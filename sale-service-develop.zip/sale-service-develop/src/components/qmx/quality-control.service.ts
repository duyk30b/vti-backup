import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { UpdateQcPlanStatusByOrderIdRequestDto } from './dto/request/update-qc-plan-status-by-order.request.dto';
import { QualityControlServiceInterface } from './interface/quality-control.service.interface';

@Injectable()
export class QualityControlService implements QualityControlServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async getQualityPointById(id: number): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        'detail_quality_point',
        id,
      );
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return null;
      }
      return response.data;
    } catch (error) {
      return [];
    }
  }

  async getQualityPoints(ids: number[]): Promise<any> {
    try {
      const params = {
        filter: [{ column: 'id', text: `[${ids}]` }],
      };
      const response = await this.natsClientService.send(
        'quality_point_list',
        params,
      );
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }
      return response.data;
    } catch {
      return [];
    }
  }

  async getQualityPointByCodes(codes: string[]): Promise<any> {
    try {
      const params = {
        filter: [{ column: 'codes', text: codes.join(',') }],
      };
      const response = await this.natsClientService.send(
        'quality_point_list',
        params,
      );
      if (
        response.statusCode !== ResponseCodeEnum.SUCCESS ||
        response.data.length === 0
      ) {
        return [];
      }
      return response.data.items;
    } catch (error) {
      return [];
    }
  }

  async updateQcPlanStatusByOrderId(
    payload: UpdateQcPlanStatusByOrderIdRequestDto,
  ): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        'update_qc_plan_status_by_order',
        payload,
      );
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }
      return response.data;
    } catch (error) {
      return [];
    }
  }
}
