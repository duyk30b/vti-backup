import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { UpdateQcPlanStatusByOrderIdRequestDto } from './dto/request/update-qc-plan-status-by-order.request.dto';
import { QualityControlServiceInterface } from './interface/quality-control.service.interface';

@Injectable()
export class QualityControlService implements QualityControlServiceInterface {
  constructor(
    @Inject('QMSX_SERVICE_CLIENT')
    private readonly qmsxServiceClient: ClientProxy,
  ) {}

  async getQualityPointById(id: number): Promise<any> {
    try {
      const response = await this.qmsxServiceClient
        .send('detail_quality_point', id)
        .toPromise();
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return null;
      }
      return response.data;
    } catch (error) {
      return [];
    }
  }

  async getQualityPoints(ids: number[]): Promise<any> {
    try {
      const params = {
        filter: [{ column: 'id', text: `[${ids}]` }],
      };
      const response = await this.qmsxServiceClient
        .send('quality_point_list', params)
        .toPromise();
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }
      return response.data;
    } catch {
      return [];
    }
  }

  async getQualityPointByCodes(codes: string[]): Promise<any> {
    try {
      const params = {
        filter: [{ column: 'codes', text: codes.join(',') }],
      };
      const response = await this.qmsxServiceClient
        .send('quality_point_list', params)
        .toPromise();
      if (
        response.statusCode !== ResponseCodeEnum.SUCCESS ||
        response.data.length === 0
      ) {
        return [];
      }
      return response.data.items;
    } catch (error) {
      return [];
    }
  }

  async updateQcPlanStatusByOrderId(
    payload: UpdateQcPlanStatusByOrderIdRequestDto,
  ): Promise<any> {
    try {
      const response = await this.qmsxServiceClient
        .send('update_qc_plan_status_by_order', payload)
        .toPromise();
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }
      return response.data;
    } catch (error) {
      return [];
    }
  }
}
