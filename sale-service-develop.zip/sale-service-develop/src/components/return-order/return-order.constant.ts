import {
  OrderTypeEnum as SaleOrderType,
  OrderWarehouseActionTypeEnum,
  ReturnTypeEnum,
} from '@constant/order.constant';

export const ORDER_TYPE_BY_RETURN_TYPE = {
  [ReturnTypeEnum.Vendor]: SaleOrderType.PO,
  [ReturnTypeEnum.Customer]: SaleOrderType.SO,
};

export const ACTION_TYPE_BY_RETURN_TYPE = {
  [ReturnTypeEnum.Vendor]: OrderWarehouseActionTypeEnum.EXPORT,
  [ReturnTypeEnum.Customer]: OrderWarehouseActionTypeEnum.IMPORT,
};
