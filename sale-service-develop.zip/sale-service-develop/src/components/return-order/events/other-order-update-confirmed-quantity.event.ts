export class OtherOrderUpdateConfirmedQuantityEvent {
  constructor({ id, orderType, userId, type }) {
    this.id = id;
    this.orderType = orderType;
    this.userId = userId;
    this.type = type;
  }
  id: number;
  orderType: number;
  userId?: number;
  type?: number;
}
