import { IsArray } from 'class-validator';
import { OrderResponseDto } from '@components/order/dto/response/order-response.dto';
import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

class LotDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  detailId: number;

  @ApiProperty()
  @Expose()
  warehouseDetailId: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  mfg: string;

  @ApiProperty({ description: 'Số lượng cần nhập còn lại' })
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  qcPassQuantity: number;

  @ApiProperty()
  @Expose()
  qcRejectQuantity: number;

  @ApiProperty({ description: 'Số lượng KH' })
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  remainStockQuantity: number;

  @ApiProperty({ description: 'Số lượng cần nhập còn lại' })
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  isExpired: boolean;
}

class Warehouse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}

class Detail {
  @ApiProperty()
  @Expose({ name: 'itemDetailSettingId' })
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty({})
  @Expose({ name: 'itemDetailQuantity' })
  quantity: number;
}
class IOItem {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  warehouseDetailId: number;

  @ApiProperty()
  @Expose()
  detailId: number;
  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty({ description: 'Số lượng thực tế đã nhập' })
  @Expose()
  actualQuantity: number;

  @ApiProperty({ description: 'Số lượng cần nhập còn lại' })
  @Expose()
  quantity: number;

  @ApiProperty({ description: 'Số lượng cần nhập theo kế hoạch' })
  @Expose()
  planQuantity: number;

  @ApiProperty({ description: 'Số lươgnj đã xác nhận' })
  @Expose()
  confirmQuantity: number;

  @ApiProperty()
  @Expose()
  qcCheck: number;

  @ApiProperty()
  @Expose()
  qcCriteriaId: number;

  @ApiProperty({
    description: 'Danh sách chi tiết',
    type: () => Detail,
    isArray: true,
  })
  @Expose()
  @Type(() => Detail)
  details: Detail[];

  @ApiProperty({
    description: 'Danh sách số lô',
    type: () => LotDetail,
    isArray: true,
  })
  @Expose()
  @Type(() => LotDetail)
  lots: LotDetail[];
}

export class ReturnOrderWarehouseDetailResponseDto extends OrderResponseDto {
  @ApiProperty()
  @Expose()
  vendorId: number;

  @ApiProperty({
    type: () => Warehouse,
    description: 'Chi tiết kho theo user - chỉ kho thuộc user mới hiển thị',
  })
  @Expose()
  @Type(() => Warehouse)
  warehouse: Warehouse;

  @ApiProperty({
    type: () => IOItem,
    isArray: true,
    description: 'Danh sách item',
  })
  @Expose()
  @Type(() => IOItem)
  @IsArray()
  items: IOItem[];
}
