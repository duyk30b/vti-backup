import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { WarehouseResponseDto } from '@components/warehouse/dto/response/warehouse.dto.response';
import { UserResponseDto } from '@components/user/dto/response/user.dto.response';

export class ItemResponseDto {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  itemUnit: string;
}

class PackageResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ReturnOrderDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  returnOrderId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  confirmQuantity: number;

  @ApiProperty({ type: ItemResponseDto })
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;
}

class ReturnOrderWarehouseLot {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  returnOrderId: number;

  @ApiProperty()
  @Expose()
  returnOrderWarehouseDetailId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  packageId: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  mfg: Date;

  @ApiProperty()
  @Expose()
  qcCriteriaId: number;

  @ApiProperty()
  @Expose()
  confirmQuantity: number;

  @ApiProperty()
  @Expose()
  isEven: number;

  @ApiProperty({ type: ItemResponseDto })
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;

  @ApiProperty({ type: PackageResponseDto })
  @Type(() => PackageResponseDto)
  @Expose()
  package: PackageResponseDto;

  @ApiProperty({ type: PackageResponseDto })
  @Type(() => PackageResponseDto)
  @Expose()
  pallet: PackageResponseDto;

  @ApiProperty({ type: PackageResponseDto })
  @Type(() => PackageResponseDto)
  @Expose()
  suggestItemLocation: PackageResponseDto;

  @ApiProperty({ type: WarehouseResponseDto })
  @Type(() => WarehouseResponseDto)
  @Expose()
  warehouse: WarehouseResponseDto;
}

class ReturnOrderWarehouseDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  returnOrderId: number;

  @ApiProperty()
  @Expose()
  returnOrderDetailId: number;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  confirmQuantity: number;

  @ApiProperty()
  @Expose()
  qcCheck: number;

  @ApiProperty()
  @Expose()
  qcCriteriaId: number;

  @ApiProperty({ type: ItemResponseDto })
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;

  @ApiProperty({ type: WarehouseResponseDto })
  @Type(() => WarehouseResponseDto)
  @Expose()
  warehouse: WarehouseResponseDto;
}

export class RequestResponse {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}
export class Vendor {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}
export class Customer {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}
export class Order {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  @Type(() => Vendor)
  vendor: Vendor;

  @ApiProperty()
  @Expose()
  @Type(() => Customer)
  customer: Customer;
}

export class OrderDetail {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

export class ReturnOrderResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  requestId: string;

  @ApiProperty()
  @Expose()
  returnType: number;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  deadline: Date;

  @ApiProperty()
  @Expose()
  planAt: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty()
  @Expose()
  approvedAt: Date;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  warehouseName: string;

  @ApiProperty({ type: ReturnOrderDetail, isArray: true })
  @Expose()
  @Type(() => ReturnOrderDetail)
  returnOrderDetails: ReturnOrderDetail[];

  @ApiProperty({ type: ReturnOrderWarehouseLot, isArray: true })
  @Expose()
  @Type(() => ReturnOrderWarehouseLot)
  returnOrderWarehouseLots: ReturnOrderWarehouseLot[];

  @ApiProperty({ type: ReturnOrderWarehouseDetail, isArray: true })
  @Expose()
  @Type(() => ReturnOrderWarehouseDetail)
  returnOrderWarehouseDetails: ReturnOrderWarehouseDetail[];

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  approver: UserResponseDto;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  createdByUser: UserResponseDto;

  @ApiProperty({ type: Order })
  @Expose()
  @Type(() => Order)
  order: Order;

  @ApiProperty({ type: OrderDetail })
  @Expose()
  @Type(() => OrderDetail)
  orderDetail: OrderDetail;
}

export class ReturnOrderDataResponseDto extends SuccessResponse {
  @ApiProperty({ type: ReturnOrderResponseDto })
  @Expose()
  @Type(() => ReturnOrderResponseDto)
  data: ReturnOrderResponseDto;
}
