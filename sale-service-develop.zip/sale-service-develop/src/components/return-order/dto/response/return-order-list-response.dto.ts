import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { ReturnOrderResponseDto } from './return-order-response.dto';
import { SuccessResponse } from '@utils/success.response.dto';

class MetaImportOrder {
  @ApiProperty({ example: 1 })
  @Expose()
  total: number;

  @ApiProperty({ example: 1 })
  @Expose()
  page: number;
}

export class ReturnOrderList {
  @ApiProperty({ type: ReturnOrderResponseDto, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => ReturnOrderResponseDto)
  items: ReturnOrderResponseDto[];

  @ApiProperty({ type: MetaImportOrder })
  @Expose()
  @Type(() => MetaImportOrder)
  meta: MetaImportOrder;
}

export class ReturnOrderListResponseDto extends SuccessResponse {
  @ApiProperty({ type: ReturnOrderList })
  @Expose()
  @Type(() => ReturnOrderList)
  data: ReturnOrderList;
}
