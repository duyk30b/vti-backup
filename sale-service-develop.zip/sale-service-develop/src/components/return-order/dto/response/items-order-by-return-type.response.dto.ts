import { OrderResponseDto } from '@components/order/dto/response/order-response.dto';
import { Expose, Type } from 'class-transformer';

class ItemOrder {
  @Expose()
  itemId: number;

  @Expose()
  quantity: number;

  @Expose()
  actualQuantity: number;

  @Expose()
  lotNumber: string;

  @Expose()
  mfg: Date;

  @Expose()
  packageId: number;
}

export class ItemsOrderByReturnTypeResponseDto extends OrderResponseDto {
  @Expose()
  @Type(() => ItemOrder)
  items: ItemOrder[];
}
