import { OrderResponseDto } from '@components/order/dto/response/order-response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { ReturnOrderResponseDto } from './return-order-response.dto';

class ItemLotsPoImport {
  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose({ name: 'quantity' })
  storedQuantity: number;
}

class LocationPoImport {
  @ApiProperty()
  @Expose()
  locationName: string;

  @ApiProperty()
  @Expose()
  warehouseShelfFloorId: number;

  @ApiProperty({ type: ItemLotsPoImport, isArray: true })
  @Expose()
  @Type(() => ItemLotsPoImport)
  lots: ItemLotsPoImport[];
}

class Detail {
  @ApiProperty()
  @Expose({ name: 'itemDetailSettingId' })
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty({})
  @Expose({ name: 'itemDetailQuantity' })
  quantity: number;
}
class ItemsPurchasedOrderImport {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  storedQuantity: number;

  @ApiProperty()
  @Expose()
  remainingQuantity: number;

  @ApiProperty({ type: LocationPoImport, isArray: true })
  @Expose()
  @Type(() => LocationPoImport)
  locations: LocationPoImport[];

  @ApiProperty({
    description: 'Danh sách chi tiết',
    type: () => Detail,
    isArray: true,
  })
  @Expose()
  @Type(() => Detail)
  details: Detail[];
}

export class SuggestStoredReturnOrderImportResponseDto extends ReturnOrderResponseDto {
  @ApiProperty()
  @Expose()
  vendorName: string;

  @ApiProperty()
  @Expose()
  warehouseName: string;

  @ApiProperty({ type: ItemsPurchasedOrderImport, isArray: true })
  @Expose()
  @Type(() => ItemsPurchasedOrderImport)
  items: ItemsPurchasedOrderImport[];
}
