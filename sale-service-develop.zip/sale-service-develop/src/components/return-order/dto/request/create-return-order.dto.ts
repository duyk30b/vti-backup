import { Type } from 'class-transformer';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsDateString,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Length,
  Min,
  ValidateNested,
} from 'class-validator';
import { CreateOrderRequestDto } from '@components/order/dto/request/create-order-resquest.dto';
import { ReturnTypeEnum } from '@constant/order.constant';

class ReturnOrderItemRequest {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  quantity: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @Length(10)
  lotNumber: string;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  packageId: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  palletId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  mfg: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @IsEnum(['0', '1'])
  isEven: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  suggestItemLocationId: number;
}
export class CreateReturnOrderRequestDto extends CreateOrderRequestDto {
  @ApiProperty()
  @IsOptional()
  @IsInt()
  userId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  @IsEnum(ReturnTypeEnum)
  returnType: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  orderId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @ApiProperty({ type: ReturnOrderItemRequest, isArray: true })
  @ArrayUnique<ReturnOrderItemRequest>()
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => ReturnOrderItemRequest)
  items: ReturnOrderItemRequest[];

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  deadline: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  assignUserIds: number[];
}
