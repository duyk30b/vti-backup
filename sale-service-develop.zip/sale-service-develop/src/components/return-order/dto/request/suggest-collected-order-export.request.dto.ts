import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayUnique,
  IsArray,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

class Lot {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  lotNumber: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  quantity: number;
}

class ItemLots {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @ArrayUnique((lot: Lot) => lot.lotNumber)
  @ValidateNested()
  @Type(() => Lot)
  lots: Lot[];
}
export class SuggestCollectedOrderExportBodyDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @ArrayUnique((item: ItemLots) => item.itemId)
  @ValidateNested()
  @Type(() => ItemLots)
  items: ItemLots[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  locatorIds: number[];
}

export class SuggestCollectedOrderExportRequestDto extends SuggestCollectedOrderExportBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;
}
