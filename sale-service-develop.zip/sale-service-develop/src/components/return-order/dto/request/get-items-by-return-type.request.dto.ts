import { ReturnTypeEnum } from '@constant/order.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsInt, IsNotEmpty } from 'class-validator';

export class GetItemsByReturnTypeQueryDto extends BaseDto {}
export class GetItemsByReturnTypeRequestDto extends GetItemsByReturnTypeQueryDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(ReturnTypeEnum)
  returnType: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  orderId: number;
}
