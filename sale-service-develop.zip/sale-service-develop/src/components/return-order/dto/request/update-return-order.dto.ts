import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CreateReturnOrderRequestDto } from './create-return-order.dto';

export class UpdateReturnOrderBodyDto extends CreateReturnOrderRequestDto {}
export class UpdateReturnOrderRequestDto extends UpdateReturnOrderBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
