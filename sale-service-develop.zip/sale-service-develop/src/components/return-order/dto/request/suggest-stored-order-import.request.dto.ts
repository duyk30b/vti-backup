import { ApiProperty, PickType } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { Type } from 'class-transformer';
import {
  ArrayUnique,
  IsArray,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

class ItemLots {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  quantity: number;
}

export class SuggestStoredOrderImportBodyDto extends PickType(PaginationQuery, [
  'filter',
  'responseError',
  'request',
]) {
  @ApiProperty()
  @IsNotEmpty()
  @ArrayUnique((item: ItemLots) => item.itemId)
  @ValidateNested()
  @Type(() => ItemLots)
  items: ItemLots[];

  @ApiProperty()
  @IsOptional()
  @IsArray()
  locatorIds: number[];
}
export class SuggestStoredOrderImportRequestDto extends SuggestStoredOrderImportBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;
}
