import { ItemService } from '@components/item/item.service';
import { ProduceService } from '@components/produce/produce.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { WarehouseCronService } from '@components/warehouse/warehouse.cron.service';
import { ConfigService } from '@config/config.service';
import { AssignOrderEntity } from '@entities/assign-order/assign-order.entity';
import { PurchasedOrderImportEntity } from '@entities/purchased-order-import/purchased-order-import.entity';
import { ReturnOrderDetailEntity } from '@entities/return-order/return-order-detail.entity';
import { ReturnOrderWarehouseDetailEntity } from '@entities/return-order/return-order-warehouse-detail.entity';
import { ReturnOrderWarehouseLotEntity } from '@entities/return-order/return-order-warehouse-lot.entity';
import { ReturnOrderEntity } from '@entities/return-order/return-order.entity';
import { SaleOrderExport } from '@entities/sale-order-export/sale-order-export.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AssignOrderRepository } from '@repositories/assign-order/assign-order.repository';
import { PurchasedOrderImportRepository } from '@repositories/purchased-order-import/purchased-order-import.repository';
import { ReturnOrderDetailRepository } from '@repositories/return-order/return-order-detail.repository';
import { ReturnOrderWarehouseDetailRepository } from '@repositories/return-order/return-order-warehouse-detail.repository';
import { ReturnOrderWarehouseLotRepository } from '@repositories/return-order/return-order-warehouse-lot.repository';
import { ReturnOrderRepository } from '@repositories/return-order/return-order.repository';
import { SaleOrderExportRepository } from '@repositories/sale-order-export/sale-order-export.repository';
import { WarehouseModule } from '../warehouse/warehouse.module';
import { WarehouseService } from '../warehouse/warehouse.service';
import { ReturnOrderUpdateConfirmedQuantityListener } from './listeners/return-order-import-update-confimed-quantity.listener';
import { ReturnOrderUpdateActualQuantityListener } from './listeners/return-order-update-actual-quantity.listener';
import { ReturnOrderController } from './return-order.controller';
import { ReturnOrderService } from './return-order.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      ReturnOrderEntity,
      ReturnOrderDetailEntity,
      ReturnOrderWarehouseDetailEntity,
      ReturnOrderWarehouseLotEntity,
      PurchasedOrderImportEntity,
      SaleOrderExport,
      AssignOrderEntity,
    ]),
    WarehouseModule,
    UserModule,
  ],
  providers: [
    {
      provide: 'ReturnOrderRepositoryInterface',
      useClass: ReturnOrderRepository,
    },
    {
      provide: 'ReturnOrderDetailRepositoryInterface',
      useClass: ReturnOrderDetailRepository,
    },
    {
      provide: 'ReturnOrderWarehouseDetailRepositoryInterface',
      useClass: ReturnOrderWarehouseDetailRepository,
    },
    {
      provide: 'ReturnOrderWarehouseLotRepositoryInterface',
      useClass: ReturnOrderWarehouseLotRepository,
    },
    {
      provide: 'PurchasedOrderImportRepositoryInterface',
      useClass: PurchasedOrderImportRepository,
    },
    {
      provide: 'SaleOrderExportRepositoryInterface',
      useClass: SaleOrderExportRepository,
    },
    {
      provide: 'ReturnOrderServiceInterface',
      useClass: ReturnOrderService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'WarehouseCronServiceInterface',
      useClass: WarehouseCronService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'ProduceServiceInterface',
      useClass: ProduceService,
    },
    {
      provide: 'AssignOrderRepositoryInterface',
      useClass: AssignOrderRepository,
    },
    ConfigService,
    ReturnOrderUpdateActualQuantityListener,
    ReturnOrderUpdateConfirmedQuantityListener,
  ],
  controllers: [ReturnOrderController],
})
export class ReturnOrderModule {}
