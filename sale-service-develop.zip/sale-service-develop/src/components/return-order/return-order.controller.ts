import { ImportOrderResponseDto } from '@components/import-order/dto/response/import-order-response.dto';
import { DeleteOrderRequestDto } from '@components/order/dto/request/delete-order.request.dto';
import { GetListOrderByIdsRequestDto } from '@components/order/dto/request/get-list-order-by-ids.request.dto';
import {
  GetOrderDetailByWarehouseQueryDto,
  GetOrderDetailByWarehouseRequestDto,
} from '@components/order/dto/request/get-order-detail-by-warehouse.request.dto';
import { GetOrderDetailRequestDto } from '@components/order/dto/request/get-order-detail.request.dto';
import { SetOrderStatusBodyDto } from '@components/order/dto/request/set-order-status-request.dto';
import { UpdateOrderDetailActualQuantityRequestDto } from '@components/order/dto/request/update-actual-quantity-order-detail.request.dto';
import { UpdateOrderDetailConfirmQuantityRequestDto } from '@components/order/dto/request/update-confirm-quantity-order-detail.request.dto';
import { SuggestStoredPurchasedOrderImportResponseDto } from '@components/purchased-order-import/dto/response/suggest-stored-purchased-order-import.response.dto';
import { NATS_SALE } from '@config/nats.config';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import {
  APPROVE_IMPORT_ORDER_PERMISSION,
  CONFIRM_IMPORT_ORDER_PERMISSION,
  CREATE_IMPORT_ORDER_PERMISSION,
  DELETE_IMPORT_ORDER_PERMISSION,
  DETAIL_IMPORT_ORDER_PERMISSION,
  LIST_IMPORT_ORDER_PERMISSION,
  REJECT_IMPORT_ORDER_PERMISSION,
  UPDATE_IMPORT_ORDER_PERMISSION,
} from '@utils/permissions/import-order';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateReturnOrderRequestDto } from './dto/request/create-return-order.dto';
import { GetItemsByReturnTypeQueryDto } from './dto/request/get-items-by-return-type.request.dto';
import { GetReturnOrderListRequestDto } from './dto/request/get-return-order-list.request.dto';
import { GetSuggestByRoIdRequestDto } from './dto/request/get-suggest-by-ro-id.request.dto';
import { SuggestCollectedOrderExportBodyDto } from './dto/request/suggest-collected-order-export.request.dto';
import { SuggestStoredOrderImportBodyDto } from './dto/request/suggest-stored-order-import.request.dto';
import { UpdateReturnOrderBodyDto } from './dto/request/update-return-order.dto';
import { ReturnOrderListResponseDto } from './dto/response/return-order-list-response.dto';
import { ReturnOrderResponseDto } from './dto/response/return-order-response.dto';
import { ReturnOrderWarehouseDetailResponseDto } from './dto/response/return-order-warehouse-detail-response.dto';
import { ReturnOrderServiceInterface } from './interface/return-order.service.interface';

@Controller()
export class ReturnOrderController {
  constructor(
    @Inject('ReturnOrderServiceInterface')
    private readonly returnOrderService: ReturnOrderServiceInterface,
  ) {}

  @Post('return-orders/create')
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ImportOrderResponseDto,
  })
  @PermissionCode(CREATE_IMPORT_ORDER_PERMISSION.code)
  // @MessagePattern('create_return_order')
  public async create(
    @Body() payload: CreateReturnOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.returnOrderService.create(request);
  }

  @Put('return-orders/:id')
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: ImportOrderResponseDto,
  })
  @PermissionCode(UPDATE_IMPORT_ORDER_PERMISSION.code)
  // @MessagePattern('update_return_order')
  public async update(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateReturnOrderBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.returnOrderService.update(request);
  }

  @Delete('return-orders/:id')
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  @PermissionCode(DELETE_IMPORT_ORDER_PERMISSION.code)
  // @MessagePattern('delete_return_order')
  public async delete(@Param() param: DeleteOrderRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.returnOrderService.delete(request);
  }

  @Get('return-orders/:id')
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ReturnOrderResponseDto,
  })
  @PermissionCode(DETAIL_IMPORT_ORDER_PERMISSION.code)
  // @MessagePattern('detail_return_order')
  public async getReturnOrderDetail(
    @Param() param: GetOrderDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.returnOrderService.getDetail(request);
  }

  @Get('return-orders/list')
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ReturnOrderListResponseDto,
  })
  @PermissionCode(LIST_IMPORT_ORDER_PERMISSION.code)
  // @MessagePattern('list_return_order')
  public async getReturnOrderList(
    @Query() payload: GetReturnOrderListRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    // if (isEmpty(find(request.filter, (f) => f.column === 'type'))) {
    //   request.filter = request.filter || [];
    //   request.filter.push({
    //     column: 'type',
    //     text: OrderTypeEnum.Import.toString(),
    //   });
    // }
    return await this.returnOrderService.getList(request);
  }

  @PermissionCode(CONFIRM_IMPORT_ORDER_PERMISSION.code)
  @Put('return-orders/:id/confirm')
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ReturnOrderResponseDto,
  })
  // @MessagePattern('confirm_return_order')
  public async confirm(
    @Param('id', new ParseIntPipe()) id,
    @Query() query: SetOrderStatusBodyDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.returnOrderService.confirm(request);
  }

  @Put('return-orders/:id/reject')
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: ReturnOrderResponseDto,
  })
  @PermissionCode(REJECT_IMPORT_ORDER_PERMISSION.code)
  // @MessagePattern('reject_return_order')
  public async reject(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: SetOrderStatusBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;
    return await this.returnOrderService.reject(request);
  }

  @Put('return-orders/:id/approve')
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: ReturnOrderResponseDto,
  })
  @PermissionCode(APPROVE_IMPORT_ORDER_PERMISSION.code)
  // @MessagePattern('approve_return_order')
  public async approve(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: SetOrderStatusBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.returnOrderService.approve(request);
  }

  @MessagePattern(`${NATS_SALE}.update_return_order_actual_quantity`)
  public async updateActualQuantity(
    @Body() payload: UpdateOrderDetailActualQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.returnOrderService.updateOrderDetailActualQuantity(
      request,
    );
  }

  @MessagePattern(`${NATS_SALE}.update_return_order_confirm_quantity`)
  public async updateConfirmQuantity(
    @Body() payload: UpdateOrderDetailConfirmQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.returnOrderService.updateOrderDetailConfirmQuantity(
      request,
    );
  }

  @Get('return-orders/:id/warehouses/:warehouseId')
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ReturnOrderWarehouseDetailResponseDto,
  })
  // @MessagePattern(`${NATS_ITEM}.get_return_order_warehouse`)
  public async getDetailByWarehouseId(
    @Param('id', new ParseIntPipe()) id,
    @Param('warehouseId', new ParseIntPipe()) warehouseId,
    @Query() payload: GetOrderDetailByWarehouseQueryDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    request.warehouseId = warehouseId;
    return await this.returnOrderService.getDetailByWarehouseId(request);
  }

  // @MessagePattern('suggest_stored_by_return_order_id')
  @Post('return-order/:id/suggest/stored')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import', 'suggest', 'stored'],
    summary: 'Suggest Purchased Order Import Stored',
    description: 'Suggest import item by order',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully',
    type: SuggestStoredPurchasedOrderImportResponseDto,
  })
  public async suggestStoredByOrderId(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: SuggestStoredOrderImportBodyDto,
    @Query() query: PaginationQuery,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;
    return await this.returnOrderService.suggestStoredByOrderId({
      ...request,
      ...query,
    });
  }

  // @MessagePattern('suggest_collect_by_return_order_id')
  @Post('return-order/:id/suggest/collected')
  @ApiOperation({
    tags: ['Sales', 'suggest', 'Collect'],
    summary: 'Suggest SO export collect',
    description: 'Suggest export item by order',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully',
    type: null,
  })
  public async suggestCollectedByOrderId(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: SuggestCollectedOrderExportBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.returnOrderService.suggestCollectedByOrderId(request);
  }
  // @MessagePattern('get_items_by_return_type')
  @Get('return-orders/order/:orderId/return-type/:returnType')
  @ApiOperation({
    tags: ['Sales', 'Return Order'],
    summary: 'Create Return Order',
    description: 'Tạo lệnh trả hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ReturnOrderResponseDto,
  })
  public async getItemsOrderByReturnType(
    @Param('orderId', new ParseIntPipe()) orderId,
    @Param('returnType', new ParseIntPipe()) returnType,
    @Query() payload: GetItemsByReturnTypeQueryDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.orderId = orderId;
    request.returnType = returnType;
    return await this.returnOrderService.getItemsOrderByReturnType(request);
  }

  // TO DO: remove after refactor done
  @MessagePattern(`${NATS_SALE}.get_return_order_by_ids`)
  public async getPurchasedOrderImportByIdsTcp(
    @Body() payload: GetListOrderByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.returnOrderService.getListByIds(request);
  }

  @MessagePattern(`${NATS_SALE}.get_return_order_warehouse`)
  public async getDetailByWarehouseIdTcp(
    @Body() payload: GetOrderDetailByWarehouseRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.returnOrderService.getDetailByWarehouseId(request);
  }

  @MessagePattern(`${NATS_SALE}.get_suggest_by_ro_id`)
  public async getSuggestByRoIdTcp(
    @Body() payload: GetSuggestByRoIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.returnOrderService.getSuggestByRoId(request);
  }
}
