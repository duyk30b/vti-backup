import { EventEmitter2 } from '@nestjs/event-emitter';
import { Inject, Injectable } from '@nestjs/common';
import { ReturnOrderServiceInterface } from './interface/return-order.service.interface';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, Not, In } from 'typeorm';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { OrderServiceAbstract } from '@components/order/interface/order.service.abstract';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { CreateReturnOrderRequestDto } from './dto/request/create-return-order.dto';
import { UpdateReturnOrderRequestDto } from './dto/request/update-return-order.dto';
import { ReturnOrderRepositoryInterface } from './interface/return-order.repository.interface';
import {
  OrderTypeEnum,
  OrderTypeEnum as SaleOrderTypeEnum,
  STATUS_TO_APPROVE_ORDER_STATUS,
  STATUS_TO_CONFIRM_ORDER_STATUS,
  STATUS_TO_DELETE_ORDER_STATUS,
  STATUS_TO_REJECT_ORDER_STATUS,
} from '@constant/order.constant';
import { ReturnOrderEntity } from '@entities/return-order/return-order.entity';
import {
  compact,
  find,
  first,
  groupBy,
  has,
  isEmpty,
  isNull,
  keyBy,
  map,
  sumBy,
  uniq,
  values,
} from 'lodash';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { PurchasedOrderImportRepository } from '@repositories/purchased-order-import/purchased-order-import.repository';
import { SaleOrderExportRepository } from '@repositories/sale-order-export/sale-order-export.repository';
import {
  ACTION_TYPE_BY_RETURN_TYPE,
  ORDER_TYPE_BY_RETURN_TYPE,
} from './return-order.constant';
import { ReturnOrderDetailRepositoryInterface } from './interface/return-order-detail.repository.interface';
import { ReturnOrderWarehouseDetailRepositoryInterface } from './interface/return-order-warehouse-detail.repository.interface';
import { ReturnOrderWarehouseLotRepositoryInterface } from './interface/return-order-warehouse-lot.repository.interface';
import { ReturnOrderDetailEntity } from '@entities/return-order/return-order-detail.entity';
import { ReturnOrderWarehouseDetailEntity } from '@entities/return-order/return-order-warehouse-detail.entity';
import { ReturnOrderWarehouseLotEntity } from '@entities/return-order/return-order-warehouse-lot.entity';
import { DeleteOrderRequestDto } from '@components/order/dto/request/delete-order.request.dto';
import { GetOrderDetailRequestDto } from '@components/order/dto/request/get-order-detail.request.dto';
import { plainToInstance } from 'class-transformer';
import {
  Order,
  OrderDetail,
  ReturnOrderResponseDto,
} from './dto/response/return-order-response.dto';
import { ResponsePayload } from '@utils/response-payload';
import { ReturnOrderListResponseDto } from './dto/response/return-order-list-response.dto';
import { GetReturnOrderListRequestDto } from './dto/request/get-return-order-list.request.dto';
import { PagingResponse } from '@utils/paging.response';
import { OrderStatusEnum } from '@constant/common';
import { SetOrderStatusRequestDto } from '@components/order/dto/request/set-order-status-request.dto';
import { UpdateOrderDetailActualQuantityRequestDto } from '@components/order/dto/request/update-actual-quantity-order-detail.request.dto';
import { getInnerJoinElements, minus, plus } from '@utils/common';
import { OrderUpdateActualQuantityEvent } from '@components/order/events/order-update-actual-quantity.event';
import { UpdateOrderDetailConfirmQuantityRequestDto } from '@components/order/dto/request/update-confirm-quantity-order-detail.request.dto';
import { OtherOrderUpdateConfirmedQuantityEvent } from './events/other-order-update-confirmed-quantity.event';
import { GetOrderDetailByWarehouseRequestDto } from '@components/order/dto/request/get-order-detail-by-warehouse.request.dto';
import { GetPositionItemsByConditionsRequestDto } from '@components/item/dto/request/filter-position-items-by-conditions.request.dto';
import { ReturnOrderWarehouseDetailResponseDto } from './dto/response/return-order-warehouse-detail-response.dto';
import { SuggestStoredOrderImportRequestDto } from './dto/request/suggest-stored-order-import.request.dto';
import { SuggestImportItemToWarehouseShelfFloorRequestDto } from '@components/warehouse/dto/request/suggest-import-item-to-warehouse-shelf-floor.request.dto';
import { SuggestStoredReturnOrderImportResponseDto } from './dto/response/suggest-stored-return-order-import.response.dto';
import { SuggestCollectReturnOrderExportResponseDto } from './dto/response/suggest-collect-return-order-export.response.dto';
import { SuggestCollectedOrderExportRequestDto } from './dto/request/suggest-collected-order-export.request.dto';
import { SuggestExportItemToWarehouseShelfFloorRequestDto } from '@components/warehouse/dto/request/suggest-export-item-to-warehouse-shelf-floor.request.dto';
import { GetItemsByReturnTypeRequestDto } from './dto/request/get-items-by-return-type.request.dto';
import { ItemsOrderByReturnTypeResponseDto } from './dto/response/items-order-by-return-type.response.dto';
import { GetListOrderByIdsRequestDto } from '@components/order/dto/request/get-list-order-by-ids.request.dto';
import { generateLocationName } from '@utils/helper';
import {
  EVEN,
  EVEN_PACKAGE_PALLET,
} from '@components/sale-order-export/sale-order-export.contant';
import { ApiError } from '@utils/api.error';
import { AssignOrderRepositoryInterface } from '@components/assign-order/interface/assign-order.repository.interface';
import { AssignOrderEntity } from '@entities/assign-order/assign-order.entity';
import { GetSuggestByRoIdRequestDto } from './dto/request/get-suggest-by-ro-id.request.dto';
import { OrderTypeEnum as ReturnOrderTypeEnum } from '@constant/common';

@Injectable()
export class ReturnOrderService
  extends OrderServiceAbstract
  implements ReturnOrderServiceInterface
{
  constructor(
    @Inject('ReturnOrderRepositoryInterface')
    private readonly returnOrderRepository: ReturnOrderRepositoryInterface,

    @Inject('ReturnOrderDetailRepositoryInterface')
    private readonly returnOrderDetailRepository: ReturnOrderDetailRepositoryInterface,

    @Inject('ReturnOrderWarehouseDetailRepositoryInterface')
    private readonly returnOrderWarehouseDetailRepository: ReturnOrderWarehouseDetailRepositoryInterface,

    @Inject('ReturnOrderWarehouseLotRepositoryInterface')
    private readonly returnOrderWarehouseLotRepository: ReturnOrderWarehouseLotRepositoryInterface,

    @Inject('PurchasedOrderImportRepositoryInterface')
    private readonly purchasedOrderImportRepository: PurchasedOrderImportRepository,

    @Inject('SaleOrderExportRepositoryInterface')
    private readonly saleOrderExportRepository: SaleOrderExportRepository,

    @Inject('AssignOrderRepositoryInterface')
    private readonly assignOrderRepository: AssignOrderRepositoryInterface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nRequestScopeService,

    private eventEmitter: EventEmitter2,
  ) {
    super(itemService, warehouseService, userService);
  }

  public async create(payload: CreateReturnOrderRequestDto): Promise<any> {
    const { returnType } = payload;

    const orderType = this.getOrderTypeByReturnType(returnType);

    const orderEntity = await this.returnOrderRepository.createEntity(
      payload,
      orderType,
      this.getActionTypeByOrderType(returnType),
    );

    return await this.save(orderEntity, payload);
  }

  public async update(payload: UpdateReturnOrderRequestDto): Promise<any> {
    const { returnType, id } = payload;

    const orderType = this.getOrderTypeByReturnType(returnType);
    const order = await this.returnOrderRepository.findOneById(id);
    if (isEmpty(order)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const orderEntity = await this.returnOrderRepository.updateEntity(
      payload,
      order,
      orderType,
      this.getActionTypeByOrderType(returnType),
    );

    return await this.save(orderEntity, payload);
  }

  private async save(
    orderEntity: ReturnOrderEntity,
    payload: CreateReturnOrderRequestDto,
  ): Promise<any> {
    const { orderId, items, warehouseId, assignUserIds } = payload;

    const isUpdate = !!orderEntity.id;
    const conditionCheckExistCode = {
      code: orderEntity.code,
    } as any;
    if (isUpdate) {
      conditionCheckExistCode.id = Not(orderEntity.id);
    }
    const isExistCode = await this.returnOrderRepository.findOneByCondition(
      conditionCheckExistCode,
    );
    if (!isEmpty(isExistCode)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.CODE_IS_EXIST'))
        .build();
    }

    const evenPackagePallet = items.filter(
      (item) =>
        item.isEven === EVEN.IS_EVEN && (item.packageId || item.palletId),
    );
    const notEvenPackagePallet = items.filter(
      (item) => item.isEven === EVEN.IS_NOT_EVEN,
    );
    if (
      evenPackagePallet.length + notEvenPackagePallet.length !==
      items.length
    ) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.EVEN_PACKAGE_PALLET_NOT_EMPTY'),
      );
    }
    const users = await this.userService.getUsers(assignUserIds);
    if (users.length !== assignUserIds.length) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.USER_NOT_FOUND'),
      );
    }

    const packageIds = compact(uniq(map(items, 'packageId')));
    const packages = await this.itemService.getPackageByIds(packageIds);

    if (packageIds.length !== packages.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PACKAGE_NOT_FOUND'))
        .build();
    }

    const palletIds = compact(uniq(map(items, 'palletId')));
    let isCheckPackagePallet = false;
    const packagePalletCondition = compact(
      uniq(
        items.map((i) => {
          if (i.packageId && i.palletId) {
            isCheckPackagePallet = true;
            return {
              packageId: i.packageId,
              palletId: i.palletId,
            };
          }
        }),
      ),
    );

    const pallets = await this.itemService.getPalletByIds(
      palletIds,
      packagePalletCondition,
    );

    if (isCheckPackagePallet)
      for (let i = 0; i < pallets.length; i++) {
        for (let j = 0; j < pallets[i].packages.length; j++) {
          if (!packageIds.includes(pallets[i].packages[j].packageId)) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate('error.PACKAGE_NOT_REMEMBER_PALLET'),
              )
              .build();
          }
        }
      }

    if (palletIds.length !== pallets.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PALLET_NOT_FOUND'))
        .build();
    }

    const packageMap = keyBy(packages, 'id');
    const palletMap = keyBy(pallets, 'id');

    for (let i = 0; i < evenPackagePallet.length; i++) {
      const element = evenPackagePallet[i];
      if (
        packageMap[element.packageId]?.packageItems.length !==
        EVEN_PACKAGE_PALLET.ONLY
      ) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.ONLY_ITEM_IN_PACKAGE_PALLET_ERROR'),
        ).toResponse();
      }
      for (let j = 0; j < palletMap[element.palletId].packages.length; j++) {
        const packag = palletMap[element.palletId].packages[j];
        if (packag.items.length !== EVEN_PACKAGE_PALLET.ONLY)
          return new ApiError(
            ResponseCodeEnum.BAD_REQUEST,
            await this.i18n.translate(
              'error.ONLY_ITEM_IN_PACKAGE_PALLET_ERROR',
            ),
          ).toResponse();
      }
    }
    const listCondition = compact(
      items.map((i) => {
        if (i.suggestItemLocationId)
          return {
            locationId: i.suggestItemLocationId,
            warehouseId: warehouseId,
            itemId: i.id,
          };
      }),
    );

    const suggestItemLocations =
      await this.warehouseService.getSuggestItemLocationByListCondition(
        listCondition,
      );

    if (suggestItemLocations.length < listCondition.length)
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.LOCATOR_ERROR'),
      ).toResponse();

    const orderByType = (await this.getDetailOrderByType(
      orderId,
      orderEntity.orderType,
    )) as any;

    if (isEmpty(orderByType)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.ORDER_NOT_FOUND'))
        .build();
    }

    const serializeItemLotOrderType = keyBy(orderByType.items, (item) =>
      [item.itemId, item.lotNumber.toUpperCase()].join('-'),
    );

    const itemByType = first(orderByType.items) as any;
    if (itemByType?.warehouseId !== warehouseId) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
        .build();
    }

    const invalidQuantity = [];
    const invalidItems = [];
    for (let indexItem = 0; indexItem < items.length; indexItem++) {
      const item = items[indexItem];
      const key = [item.id, item.lotNumber.toUpperCase()].join('-');
      if (!has(serializeItemLotOrderType, key)) {
        invalidItems.push(item);
        continue;
      }
      if (serializeItemLotOrderType[key]?.actualQuantity < item.quantity) {
        invalidQuantity.push(item);
      }
    }

    if (!isEmpty(invalidItems)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }

    if (!isEmpty(invalidQuantity)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.QUANTITY_INVALID'))
        .build();
    }

    const groupByItemRequestByItemId = groupBy(items, 'id');

    const orderDetailEntities: ReturnOrderDetailEntity[] = [];
    const orderDetailWarehouseEntities: ReturnOrderWarehouseDetailEntity[] = [];
    const orderWarehouseLotEntities: ReturnOrderWarehouseLotEntity[] = [];
    Object.keys(groupByItemRequestByItemId).map((itemId) => {
      const groupItem = groupByItemRequestByItemId[itemId];
      const quantity = sumBy(groupItem, 'quantity');
      const returnOrderDetailEntity =
        this.returnOrderDetailRepository.createEntity({
          itemId,
          quantity,
        });

      const returnOrderDetailWarehouseEntity =
        this.returnOrderWarehouseDetailRepository.createEntity({
          itemId,
          warehouseId,
          quantity,
        });
      orderDetailWarehouseEntities.push(returnOrderDetailWarehouseEntity);
      groupItem.forEach((lot) => {
        const key = [itemId, lot.lotNumber.toUpperCase()].join('-');
        const orderWarehouseLotEntity =
          this.returnOrderWarehouseLotRepository.createEntity({
            itemId,
            lotNumber: lot.lotNumber,
            quantity: lot.quantity,
            packageId: lot.packageId,
            palletId: lot.palletId,
            suggestItemLocationId: lot.suggestItemLocationId,
            isEven: lot.isEven,
            mfg: serializeItemLotOrderType[key]?.mfg,
            warehouseId,
          });
        orderWarehouseLotEntities.push(orderWarehouseLotEntity);
      });

      orderDetailEntities.push(returnOrderDetailEntity);
    });

    let findAssignOrderOld, assignOrderOld;
    if (orderEntity.id) {
      findAssignOrderOld = {
        orderId: orderEntity.id,
        type: OrderTypeEnum.RO,
      };
      assignOrderOld = await this.assignOrderRepository.findByCondition(
        findAssignOrderOld,
      );
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (isUpdate) {
        await queryRunner.manager.delete(ReturnOrderDetailEntity, {
          returnOrderId: orderEntity.id,
        });
        await queryRunner.manager.delete(ReturnOrderWarehouseDetailEntity, {
          returnOrderId: orderEntity.id,
        });
        await queryRunner.manager.delete(ReturnOrderWarehouseLotEntity, {
          returnOrderId: orderEntity.id,
        });
      }
      const returnOrder = await queryRunner.manager.save(
        ReturnOrderEntity,
        orderEntity,
      );

      // save assignOrder
      const assignOrderEntitys = assignUserIds.map((userId) => {
        return this.assignOrderRepository.createEntity({
          orderId: returnOrder.id,
          type: OrderTypeEnum.SO,
          userId: userId,
        });
      });

      if (assignOrderOld?.length)
        await queryRunner.manager.delete(AssignOrderEntity, assignOrderOld);
      await queryRunner.manager.save(assignOrderEntitys);

      orderDetailEntities.forEach((orderDetailEntitiy) => {
        orderDetailEntitiy.returnOrderId = returnOrder.id;
      });
      const returnOrderDetails = await queryRunner.manager.save(
        orderDetailEntities,
      );
      orderDetailWarehouseEntities.forEach((orderWarehouseEntitiy) => {
        const orderDetailId = returnOrderDetails.find(
          (returnOrderDetail) =>
            returnOrderDetail.itemId === orderWarehouseEntitiy.itemId,
        );
        orderWarehouseEntitiy.returnOrderId = returnOrder.id;
        orderWarehouseEntitiy.returnOrderDetailId = orderDetailId.id;
      });
      const returnOrderWarehouse = await queryRunner.manager.save(
        orderDetailWarehouseEntities,
      );

      orderWarehouseLotEntities.forEach((orderWarehouseLotEntitiy) => {
        const orderWarehouse = returnOrderWarehouse.find(
          (returnOrderWarehouseDetail) =>
            returnOrderWarehouseDetail.itemId ===
              orderWarehouseLotEntitiy.itemId &&
            returnOrderWarehouseDetail.warehouseId ===
              orderWarehouseLotEntitiy.warehouseId,
        );
        orderWarehouseLotEntitiy.returnOrderId = returnOrder.id;
        orderWarehouseLotEntitiy.returnOrderWarehouseDetailId =
          orderWarehouse.id;
      });

      await queryRunner.manager.save(orderWarehouseLotEntities);
      await queryRunner.commitTransaction();

      return new ResponseBuilder(returnOrder)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  private async getDetailOrderByType(orderId: number, orderType): Promise<any> {
    let order;
    switch (orderType) {
      case SaleOrderTypeEnum.PO:
        const purchasedOrderImport =
          await this.purchasedOrderImportRepository.findOneWithRelations({
            where: {
              id: orderId,
            },
            relations: ['purchasedOrderImportWarehouseLots', 'purchasedOrder'],
          });
        order = !isEmpty(purchasedOrderImport)
          ? {
              ...purchasedOrderImport,
              items: purchasedOrderImport.purchasedOrderImportWarehouseLots,
              order: purchasedOrderImport.purchasedOrder,
            }
          : {};
        break;
      default:
        const saleOrderExport =
          await this.saleOrderExportRepository.findOneWithRelations({
            where: {
              id: orderId,
            },
            relations: ['saleOrderExportWarehouseLots', 'saleOrder'],
          });
        order = !isEmpty(saleOrderExport)
          ? {
              ...saleOrderExport,
              items: saleOrderExport.saleOrderExportWarehouseLots,
              order: saleOrderExport.saleOrder,
            }
          : {};
        break;
    }
    return order;
  }

  private async getDetailOrderByOrderIdsAndType(
    orderIds: number[],
    orderType,
  ): Promise<any> {
    let orders;
    switch (orderType) {
      case SaleOrderTypeEnum.PO:
        const purchasedOrderImports =
          await this.purchasedOrderImportRepository.findWithRelations({
            where: {
              id: In(orderIds),
            },
            relations: [
              // 'purchasedOrderImportWarehouseLots',
              'purchasedOrder',
              'purchasedOrder.vendor',
            ],
          });
        orders = !isEmpty(purchasedOrderImports)
          ? purchasedOrderImports.map((purchasedOrderImport) => ({
              ...purchasedOrderImport,
              // items: purchasedOrderImport.purchasedOrderImportWarehouseLots,
              order: purchasedOrderImport.purchasedOrder,
              vendor: purchasedOrderImport.purchasedOrder?.vendor,
            }))
          : [];
        break;
      default:
        const saleOrderExports =
          await this.saleOrderExportRepository.findWithRelations({
            where: {
              id: In(orderIds),
            },
            relations: [
              // 'saleOrderExportWarehouseLots',
              'saleOrder',
              'saleOrder.customer',
            ],
          });
        orders = !isEmpty(saleOrderExports)
          ? saleOrderExports.map((saleOrderExport) => ({
              ...saleOrderExport,
              // items: saleOrderExport.saleOrderExportWarehouseLots,
              order: saleOrderExport.saleOrder,
              customer: saleOrderExport.saleOrder?.customer,
            }))
          : [];
        break;
    }
    return orders;
  }

  public getOrderTypeByReturnType(returnType: number) {
    return ORDER_TYPE_BY_RETURN_TYPE[returnType] ?? null;
  }

  public getActionTypeByOrderType(returnType: number) {
    return ACTION_TYPE_BY_RETURN_TYPE[returnType] ?? null;
  }

  public async delete(payload: DeleteOrderRequestDto): Promise<any> {
    const { id } = payload;
    const order = await this.returnOrderRepository.findOneById(id);
    if (!order) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_DELETE_ORDER_STATUS.includes(order.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.remove(ReturnOrderEntity, order);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }
    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getDetail(payload: GetOrderDetailRequestDto): Promise<any> {
    const { id } = payload;
    const order = await this.returnOrderRepository.getDetail(id);
    if (!order) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const orderDetail = await this.getDetailOrderByType(
      order.orderId,
      order.orderType,
    );
    const packageIds = uniq(map(order.returnOrderWarehouseLots, 'packageId'));

    const palletIds = uniq(map(order.returnOrderWarehouseLots, 'palletId'));
    const suggestItemLocationIds = uniq(
      map(order.returnOrderWarehouseLots, 'suggestItemLocationId'),
    );

    const itemIds = uniq(map(order.returnOrderWarehouseLots, 'itemId'));
    const userIds = uniq([
      order.confirmerId,
      order.approverId,
      order.createdBy,
    ]).filter((id) => !isNull(id));
    const warehouseIds = uniq(
      map(order.returnOrderWarehouseLots, 'warehouseId'),
    );
    const [items, warehouses, users, packages, pallets, suggestItemLocations] =
      await Promise.all([
        this.itemService.getItems(itemIds),
        this.warehouseService.getWarehouses(warehouseIds),
        this.userService.getUsers(userIds),
        this.itemService.getPackageByIds(packageIds),
        this.itemService.getPalletByIds(palletIds),
        this.warehouseService.getLocationByIds(suggestItemLocationIds),
      ]);

    const normalizePackages = keyBy(packages, 'id');
    const normalizePallets = keyBy(pallets, 'id');
    const normalizeSuggestItemLocations = keyBy(suggestItemLocations, 'id');
    const normalizeItems = keyBy(items, 'itemId');
    const normalizeWarehouses = keyBy(warehouses, 'id');
    const normalizeUsers = keyBy(users, 'id');

    order.approver = normalizeUsers[order.approverId];
    order.confirmer = normalizeUsers[order.confirmerId];
    order.createdByUser = normalizeUsers[order.createdBy];
    order.returnOrderDetails = order.returnOrderDetails.map(
      (importOrderDetail) => ({
        ...importOrderDetail,
        item: normalizeItems[importOrderDetail.itemId]
          ? normalizeItems[importOrderDetail.itemId]
          : {},
      }),
    );

    order.returnOrderWarehouseLots = order.returnOrderWarehouseLots.map(
      (orderWarehouseLot) => {
        return {
          ...orderWarehouseLot,
          package: normalizePackages[orderWarehouseLot.packageId]
            ? normalizePackages[orderWarehouseLot.packageId]
            : {},
          pallet: normalizePallets[orderWarehouseLot.palletId]
            ? normalizePallets[orderWarehouseLot.palletId]
            : {},
          suggestItemLocation: normalizeSuggestItemLocations[
            orderWarehouseLot.suggestItemLocationId
          ]
            ? normalizeSuggestItemLocations[
                orderWarehouseLot.suggestItemLocationId
              ]
            : {},
          item: normalizeItems[orderWarehouseLot.itemId]
            ? normalizeItems[orderWarehouseLot.itemId]
            : {},
          warehouse: normalizeWarehouses[orderWarehouseLot.warehouseId]
            ? normalizeWarehouses[orderWarehouseLot.warehouseId]
            : {},
        };
      },
    );

    order.returnOrderWarehouseDetails = order.returnOrderWarehouseDetails.map(
      (orderWarehouseDetail) => ({
        ...orderWarehouseDetail,
        item: normalizeItems[orderWarehouseDetail.itemId]
          ? normalizeItems[orderWarehouseDetail.itemId]
          : {},
        warehouse: normalizeWarehouses[orderWarehouseDetail.warehouseId]
          ? normalizeWarehouses[orderWarehouseDetail.warehouseId]
          : {},
      }),
    );

    order.orderDetail = plainToInstance(Order, orderDetail, {
      excludeExtraneousValues: true,
    });
    order.order = plainToInstance(OrderDetail, orderDetail.order, {
      excludeExtraneousValues: true,
    });
    const dataReturn = plainToInstance(ReturnOrderResponseDto, order, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getList(
    payload: GetReturnOrderListRequestDto,
  ): Promise<ResponsePayload<ReturnOrderListResponseDto | any>> {
    const { page, user } = payload;
    if (!payload.filter) payload.filter = [];
    const userWarehouses = await this.userService.getUserWarehousesById(
      user.id,
    );
    if (isEmpty(userWarehouses)) {
      return new ResponseBuilder<PagingResponse>({
        items: [],
        meta: { total: 0, page: 1 },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    const filterWarehouseId = payload.filter.find(
      (filter) => filter.column === 'warehouseId',
    );
    let warehouseIds = map(
      userWarehouses,
      (userWarehouse) => +userWarehouse.id,
    );
    if (filterWarehouseId) {
      warehouseIds = getInnerJoinElements(
        warehouseIds,
        filterWarehouseId.text.split(',').map((warehouseId) => +warehouseId),
      );
      if (isEmpty(warehouseIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
      }
    }
    payload.filter.push({
      column: 'warehouseId',
      text: warehouseIds.join(','),
    });
    const [data, count] = await this.returnOrderRepository.getList(payload);
    const returnOrderSo = data.filter(
      (item) => item.orderType === SaleOrderTypeEnum.SO,
    );
    const returnOrderPo = data.filter(
      (item) => item.orderType === SaleOrderTypeEnum.PO,
    );
    const soexpIds = uniq(
      map(returnOrderSo, 'orderId')?.filter((id) => !isNull(id)),
    );
    const pomipIds = uniq(
      map(returnOrderPo, 'orderId').filter((id) => !isNull(id)),
    );
    const createdUserIds = uniq(
      map(data, 'createdBy')?.filter((id) => !isNull(id)),
    );
    let warehouses = [];
    if (!isEmpty(warehouseIds)) {
      warehouses = await this.warehouseService.getWarehouses(warehouseIds);
    }
    const soexps = await this.getDetailOrderByOrderIdsAndType(
      soexpIds,
      SaleOrderTypeEnum.SO,
    );
    const poimps = await this.getDetailOrderByOrderIdsAndType(
      pomipIds,
      SaleOrderTypeEnum.PO,
    );
    const users = await this.userService.getUsers(createdUserIds);
    const normalizeWarehouses = keyBy(warehouses, 'id');
    const normalizeUsers = keyBy(users, 'id');
    const nomalizeSoexps = keyBy(soexps, 'id');
    const nomalizePoimps = keyBy(poimps, 'id');

    const res = data.map((orderData) => {
      let order;
      if (orderData.orderType === SaleOrderTypeEnum.SO) {
        order = nomalizeSoexps[orderData.orderId];
      }
      if (orderData.orderType === SaleOrderTypeEnum.PO) {
        order = nomalizePoimps[orderData.orderId];
      }
      const warehouseId =
        orderData?.returnOrderWarehouseDetails[0]?.warehouseId;
      return {
        ...orderData,
        order: order.order,
        orderDetail: order,
        createdByUser: normalizeUsers[order.createdByUserId],
        warehouseId: warehouseId,
        warehouseName: normalizeWarehouses[warehouseId]?.name,
      };
    });

    const dataReturn = plainToInstance(ReturnOrderResponseDto, res, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async confirm(
    payload: SetOrderStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, createdByUserId } = payload;
    const order = await this.returnOrderRepository.findOneById(id);
    if (!order) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_CONFIRM_ORDER_STATUS.includes(order.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }
    order.status = OrderStatusEnum.Confirmed;
    order.confirmerId = createdByUserId;
    order.confirmedAt = new Date();
    try {
      await this.returnOrderRepository.create(order);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }
  public async reject(
    payload: SetOrderStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id } = payload;
    const order = await this.returnOrderRepository.findOneById(id);
    if (!order) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_REJECT_ORDER_STATUS.includes(order.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }
    order.status = OrderStatusEnum.Reject;
    const result = await this.returnOrderRepository.create(order);

    const dataReturn = plainToInstance(ReturnOrderResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async approve(
    payload: SetOrderStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, createdByUserId } = payload;
    const order = await this.returnOrderRepository.findOneById(id);
    if (!order) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_APPROVE_ORDER_STATUS.includes(order.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }
    order.status = OrderStatusEnum.Approved;
    order.approvedAt = new Date();
    order.approverId = createdByUserId;

    const result = await this.returnOrderRepository.create(order);

    const dataReturn = plainToInstance(ReturnOrderResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async updateOrderDetailActualQuantity(
    payload: UpdateOrderDetailActualQuantityRequestDto,
  ): Promise<any> {
    const { orderId, orderDetails, warehouseOrderDetails, itemLots } = payload;

    const importOrder = await this.returnOrderRepository.findOneById(orderId);

    if (isEmpty(importOrder)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    let message;
    let code = ResponseCodeEnum.SUCCESS;

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const orderWarehouseLotEntities =
        await this.returnOrderWarehouseLotRepository.getLotsByItems(
          map(itemLots, 'itemId'),
          map(itemLots, 'lotNumber'),
          map(itemLots, 'warehouseId'),
          orderId,
        );

      const updateOrderDetailEntities =
        await this.returnOrderDetailRepository.getUpdateOrderDetailActualQuantityByIds(
          orderId,
          orderDetails,
        );

      const updateOrderWarehouseDetailEntities =
        await this.returnOrderWarehouseDetailRepository.getUpdateOrderWarehouseDetailActualQuantityByIds(
          orderId,
          warehouseOrderDetails,
        );

      orderWarehouseLotEntities.forEach(
        (orderWarehouseLotEntity: ReturnOrderWarehouseLotEntity) => {
          const itemLot = find(
            itemLots,
            (iL) =>
              iL.itemId === orderWarehouseLotEntity.itemId &&
              iL.lotNumber.toUpperCase() ===
                orderWarehouseLotEntity.lotNumber.toUpperCase(),
          );
          if (itemLot) {
            orderWarehouseLotEntity.actualQuantity = plus(
              orderWarehouseLotEntity.actualQuantity,
              itemLot.quantity,
            );
          }
        },
      );

      await queryRunner.manager.save(updateOrderDetailEntities);
      await queryRunner.manager.save(updateOrderWarehouseDetailEntities);
      await queryRunner.manager.save(orderWarehouseLotEntities);

      await queryRunner.commitTransaction();
    } catch (error) {
      message = error;
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      await queryRunner.rollbackTransaction();
    }
    await queryRunner.release();
    this.eventEmitter.emit(
      'order.updateActualQuantity',
      new OrderUpdateActualQuantityEvent({
        id: orderId,
        orderType: SaleOrderTypeEnum.RO,
      }),
    );

    return new ResponseBuilder()
      .withCode(code)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  public async updateOrderDetailConfirmQuantity(
    payload: UpdateOrderDetailConfirmQuantityRequestDto,
  ): Promise<any> {
    const { orderId, orderDetails, warehouseOrderDetails, userId } = payload;
    const order = await this.returnOrderRepository.findOneById(orderId);
    let message;
    let code = ResponseCodeEnum.SUCCESS;
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const updateReturnOrderDetailEntities =
        await this.returnOrderDetailRepository.getUpdateOrderDetailConfirmQuantityByIds(
          orderId,
          orderDetails,
        );

      const updateReturnOrderWarehouseDetailEntities =
        await this.returnOrderWarehouseDetailRepository.getUpdateOrderWarehouseDetailConfirmQuantityByIds(
          orderId,
          warehouseOrderDetails,
        );

      await queryRunner.manager.save(updateReturnOrderDetailEntities);
      await queryRunner.manager.save(updateReturnOrderWarehouseDetailEntities);
      await queryRunner.commitTransaction();
    } catch (error) {
      message = error;
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      await queryRunner.rollbackTransaction();
    } finally {
      await queryRunner.release();
      this.eventEmitter.emit(
        'order.updateConfirmedQuantity',
        new OtherOrderUpdateConfirmedQuantityEvent({
          id: orderId,
          orderType: SaleOrderTypeEnum.RO,
          userId,
          type: order.type,
        }),
      );
    }
    return new ResponseBuilder()
      .withCode(code)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  public async getDetailByWarehouseId(
    payload: GetOrderDetailByWarehouseRequestDto,
  ): Promise<any> {
    const { id, warehouseId, user, warehouseShelfFloorId } = payload;
    const isWarehouseOfUser = await this.userService.getUserWarehousesById(
      user.id,
    );

    if (!isWarehouseOfUser) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const order = await this.returnOrderRepository.getDetailByWarehouseId(id, [
      warehouseId,
    ]);

    if (!order) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const itemIds = map(order.items, 'id');
    const userIds = uniq([
      order.createdByUserId,
      order.confirmerId,
      order.approverId,
    ]).filter((id) => !isNull(id));

    const { items, warehouses, users } = await super.getOrderExtraInfo(
      itemIds,
      [warehouseId],
      userIds,
    );
    const normalizeItems = {};
    const normalizeUsers = {};
    const normalizeWarehouses = {};

    items.forEach((item) => {
      normalizeItems[item.itemId] = item;
    });
    warehouses.forEach((warehouse) => {
      normalizeWarehouses[warehouse.id] = warehouse;
    });
    users.forEach((user) => {
      normalizeUsers[user.id] = user;
    });
    order.createdByUser = normalizeUsers[order.createdByUserId];
    order.approver = normalizeUsers[order.approverId];
    order.confirmer = normalizeUsers[order.confirmerId];
    order.warehouse = normalizeWarehouses[warehouseId];
    let itemStockLots = [];
    if (order.type === order.Export) {
      const requestFilterPositionItems =
        new GetPositionItemsByConditionsRequestDto();
      requestFilterPositionItems.conditions = [];
      order.items.forEach((item) => {
        item.lots.forEach((lot) => {
          requestFilterPositionItems.conditions.push({
            itemId: item.id,
            lotNumber: lot.lotNumber,
            warehouseShelfFloorId,
          });
        });
      });

      itemStockLots = await this.itemService.getPositionItemsByCondition(
        requestFilterPositionItems,
      );
    }

    order.items = order.items.map((item) => ({
      ...normalizeItems[item.id],
      ...item,
      lots:
        order.type === order.Export
          ? item.lots
              .map((lot) => {
                const location = itemStockLots.find(
                  (itemStock) =>
                    (itemStock.itemId =
                      item.id &&
                      itemStock.lotNumber.toUpperCase() ===
                        lot.lotNumber.toUpperCase() &&
                      itemStock.warehouseShelfFloorId ===
                        warehouseShelfFloorId),
                );
                return location
                  ? {
                      ...location,
                      ...lot,
                      id: location.id,
                      remainStockQuantity: location.quantity,
                    }
                  : {};
              })
              .filter((l) => !isEmpty(l))
          : item.lots,
    }));

    const dataReturn = plainToInstance(
      ReturnOrderWarehouseDetailResponseDto,
      order,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async suggestStoredByOrderId(
    request: SuggestStoredOrderImportRequestDto,
  ): Promise<any> {
    const { id, items, locatorIds } = request;
    const order = await this.returnOrderRepository.findOneWithRelations({
      where: {
        id,
      },
      relations: ['returnOrderDetails', 'returnOrderWarehouseLots'],
    });
    if (isEmpty(order) || isEmpty(order.returnOrderDetails)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const warehouseId = first(order.returnOrderWarehouseLots).warehouseId;
    const warehouse = await this.warehouseService.getDetailById(warehouseId);

    const checkItemsExist = items.filter(
      (item) => !map(order.returnOrderDetails, 'itemId').includes(item.itemId),
    );

    const orderByReturn = first(
      await this.getDetailOrderByOrderIdsAndType(
        [order.orderId],
        order.orderType,
      ),
    ) as any;

    if (!isEmpty(checkItemsExist)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    const serializeReturnOrderDetail = keyBy(
      order.returnOrderDetails,
      'itemId',
    );

    const mapItemSuggest = [];

    items.forEach((receiveItem) => {
      mapItemSuggest.push({
        quantity: receiveItem.quantity,
        itemId: receiveItem.itemId,
      });
    });
    const requestSuggest =
      new SuggestImportItemToWarehouseShelfFloorRequestDto();
    requestSuggest.warehouseId = warehouseId;
    requestSuggest.locatorIds = locatorIds;
    requestSuggest.items = mapItemSuggest;
    requestSuggest.filter = request.filter;
    const suggestStored =
      await this.warehouseService.suggestItemImportToWarehouseShelfFloor(
        requestSuggest,
      );
    const itemsSuggest = {};
    suggestStored?.data?.forEach((suggest) => {
      const itemId = suggest.itemId;
      if (!has(itemsSuggest, itemId)) {
        itemsSuggest[itemId] = {
          itemId: itemId,
          name: suggest.name,
          code: suggest.code,
          details: suggest?.details,
          actualQuantity: serializeReturnOrderDetail[itemId]?.actualQuantity,
          planQuantity: serializeReturnOrderDetail[itemId]?.quantity,
          remainingQuantity: minus(
            serializeReturnOrderDetail[itemId]?.quantity || 0,
            serializeReturnOrderDetail[itemId]?.actualQuantity || 0,
          ),
          locations: [],
        };
      }

      suggest.positions.forEach((position) => {
        itemsSuggest[itemId].locations.push({
          warehouseShelfFloorId: position.warehouseShelfFloor?.id,
          locationName: generateLocationName([
            position?.warehouseShelfFloor?.warehouse?.name,
            position?.warehouseShelfFloor?.warehouseShelf?.warehouseSector
              ?.name,
            position?.warehouseShelfFloor?.warehouseShelf?.name,
            position?.warehouseShelfFloor?.name,
          ]),
          lots: position.lots,
        });
      });
    });

    const response = plainToInstance(
      SuggestStoredReturnOrderImportResponseDto,
      {
        ...order,
        order: orderByReturn.order,
        orderDetail: orderByReturn,
        warehouseName: warehouse?.name,
        items: values(itemsSuggest),
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async suggestCollectedByOrderId(
    request: SuggestCollectedOrderExportRequestDto,
  ): Promise<any> {
    const { id, items, locatorIds } = request;
    const order = await this.returnOrderRepository.findOneWithRelations({
      where: {
        id,
      },
      relations: ['returnOrderWarehouseLots'],
    });

    if (isEmpty(order) || isEmpty(order.returnOrderWarehouseLots)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const checkItemsExist = items.filter(
      (item) =>
        !map(order.returnOrderWarehouseLots, 'itemId').includes(item.itemId),
    );

    const orderByReturn = first(
      await this.getDetailOrderByOrderIdsAndType(
        [order.orderId],
        order.orderType,
      ),
    ) as any;

    if (!isEmpty(checkItemsExist)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    const warehouseIds = map(order.returnOrderWarehouseLots, 'warehouseId');
    const requestSuggest =
      new SuggestExportItemToWarehouseShelfFloorRequestDto();
    requestSuggest.warehouseId = first(warehouseIds);
    requestSuggest.locatorIds = locatorIds;
    requestSuggest.items = items.map((item) => {
      return {
        quantity: sumBy(item.lots, 'quantity'),
        itemId: item.itemId,
        lots: item.lots,
      };
    });

    const suggestStored =
      await this.warehouseService.suggestItemExportToWarehouseShelfFloor(
        requestSuggest,
      );

    const orderItemLotsSerialize = keyBy(
      order.returnOrderWarehouseLots,
      (lot) => `${lot.lotNumber}-${lot.itemId}`,
    );
    const itemsSuggest = {};
    let warehouseName = '';
    const objIndexLocation = {};
    suggestStored.forEach((suggest) => {
      warehouseName = suggest?.warehouseShelfFloor?.warehouse?.name;
      const itemId = suggest.itemId;
      const keyOrderItem = `${suggest.lotNumber}-${suggest.itemId}`;
      if (!has(itemsSuggest, itemId)) {
        itemsSuggest[itemId] = {
          itemId: itemId,
          name: suggest.item.name,
          code: suggest.item.code,
          details: suggest.item?.details,
          actualQuantity: 0,
          planQuantity: 0,
          collectedQuantity: 0,
          locations: {},
        };
      }
      itemsSuggest[itemId].actualQuantity = plus(
        itemsSuggest[itemId].actualQuantity,
        orderItemLotsSerialize[keyOrderItem]?.actualQuantity || 0,
      );
      itemsSuggest[itemId].planQuantity = plus(
        itemsSuggest[itemId].planQuantity,
        orderItemLotsSerialize[keyOrderItem]?.quantity || 0,
      );
      if (!has(itemsSuggest[itemId].locations, suggest.warehouseShelfFloorId)) {
        const keyIndexLocation = `${suggest.warehouseShelfFloorId}-${itemId}`;
        if (!has(objIndexLocation, keyIndexLocation)) {
          objIndexLocation[keyIndexLocation] =
            Object.keys(objIndexLocation).length || 0;
        }
        itemsSuggest[itemId].locations[suggest.warehouseShelfFloorId] = {
          id: objIndexLocation[keyIndexLocation],
          locationName: generateLocationName([
            suggest?.warehouseShelfFloor?.warehouse?.name,
            suggest?.warehouseShelfFloor?.warehouseShelf?.warehouseSector?.name,
            suggest?.warehouseShelfFloor?.warehouseShelf?.name,
            suggest?.warehouseShelfFloor?.name,
          ]),
          lots: [],
        };
      }
      itemsSuggest[itemId].locations[suggest.warehouseShelfFloorId].lots.push({
        locationId: suggest.locationId,
        collectedQuantity: suggest.quantity,
        lotNumber: suggest.lotNumber,
      });
    });

    const dataReturn = [];
    Object.keys(itemsSuggest).forEach((itemIndex) => {
      const item = itemsSuggest[itemIndex];
      dataReturn.push({
        ...item,
        locations: values(item.locations),
      });
    });

    if (!warehouseName) {
      const warehouse = await this.warehouseService.getDetailById(
        first(order.returnOrderWarehouseLots)?.warehouseId,
      );
      warehouseName = warehouse?.name;
    }

    const response = plainToInstance(
      SuggestCollectReturnOrderExportResponseDto,
      {
        ...order,
        order: orderByReturn.order,
        orderDetail: orderByReturn,
        warehouseName,
        items: dataReturn,
      },
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getItemsOrderByReturnType(
    request: GetItemsByReturnTypeRequestDto,
  ): Promise<any> {
    const { returnType, orderId } = request;
    const orderType = this.getOrderTypeByReturnType(returnType);
    const orderByType = await this.getDetailOrderByType(orderId, orderType);
    if (isEmpty(orderByType)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const response = plainToInstance(
      ItemsOrderByReturnTypeResponseDto,
      orderByType,
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getListByIds(payload: GetListOrderByIdsRequestDto): Promise<any> {
    const { ids } = payload;
    const data = await this.returnOrderRepository.getListByIds(ids);

    const returnOrderSo = data.filter(
      (item) => item.orderType === SaleOrderTypeEnum.SO,
    );
    const returnOrderPo = data.filter(
      (item) => item.orderType === SaleOrderTypeEnum.PO,
    );
    const soexpIds = uniq(
      map(returnOrderSo, 'orderId')?.filter((id) => !isNull(id)),
    );
    const pomipIds = uniq(
      map(returnOrderPo, 'orderId').filter((id) => !isNull(id)),
    );
    const soexps = await this.getDetailOrderByOrderIdsAndType(
      soexpIds,
      SaleOrderTypeEnum.SO,
    );
    const poimps = await this.getDetailOrderByOrderIdsAndType(
      pomipIds,
      SaleOrderTypeEnum.PO,
    );
    const nomalizeSoexps = keyBy(soexps, 'id');
    const nomalizePoimps = keyBy(poimps, 'id');
    const res = data.map((orderData) => {
      let order;
      if (orderData.orderType === SaleOrderTypeEnum.SO) {
        order = nomalizeSoexps[orderData.orderId];
      }
      if (orderData.orderType === SaleOrderTypeEnum.PO) {
        order = nomalizePoimps[orderData.orderId];
      }
      return {
        ...orderData,
        vendor: order.vendor,
        customer: order.customer,
      };
    });
    return new ResponseBuilder(res)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getSuggestByRoId(request: GetSuggestByRoIdRequestDto): Promise<any> {
    const { roId, itemId } = request;

    const returnOrder = await this.returnOrderRepository.findOneById(roId);

    let response;
    const itemLots =
      await this.returnOrderWarehouseLotRepository.getItemLotsByRoId(
        roId,
        itemId,
      );
    switch (returnOrder.type) {
      case ReturnOrderTypeEnum.Import:
        const suggestStoredRequest = new SuggestStoredOrderImportRequestDto();
        suggestStoredRequest.id = roId;
        suggestStoredRequest.items = itemLots;
        response = await this.suggestStoredByOrderId(suggestStoredRequest);
        break;
      case ReturnOrderTypeEnum.Export:
        const suggestCollectedRequest =
          new SuggestCollectedOrderExportRequestDto();
        suggestCollectedRequest.id = roId;
        suggestCollectedRequest.items = itemLots;
        response = await this.suggestCollectedByOrderId(
          suggestCollectedRequest,
        );
        break;
      default:
        response = await new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
          .build();
    }
    return response;
  }
}
