import { OrderTypeEnum } from '@constant/order.constant';
import { OnEvent } from '@nestjs/event-emitter';
import { OrderUpdateActualQuantityListener } from '@components/order/listeners/order-update-actual-quantity.listener';
import { Inject, Injectable } from '@nestjs/common';
import { OrderUpdateActualQuantityEvent } from '@components/order/events/order-update-actual-quantity.event';
import { ReturnOrderRepositoryInterface } from '../interface/return-order.repository.interface';

@Injectable()
export class ReturnOrderUpdateActualQuantityListener extends OrderUpdateActualQuantityListener {
  constructor(
    @Inject('ReturnOrderRepositoryInterface')
    private readonly returnOrderRepository: ReturnOrderRepositoryInterface,
  ) {
    super();
  }

  @OnEvent('order.updateActualQuantity')
  async handleOrderUpdateActualQuantityEvent(
    event: OrderUpdateActualQuantityEvent,
  ) {
    const { id, orderType } = event;
    let order;
    if (orderType === OrderTypeEnum.RO) {
      order = await this.returnOrderRepository.findOneById(id);
    }

    return await this.checkAndUpdateInProgessOrderStatus(order);
  }

  public async updateInProgessOrderStatus(order) {
    return await this.returnOrderRepository.create(order);
  }
}
