import { OrderTypeEnum as OtherOrderTypeEnum } from '@constant/order.constant';
import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { OrderUpdateConfirmedQuantityListener } from '@components/order/listeners/order-update-confimed-quantity.listener';
import { UpdateStockStatusOrderRequest } from '@components/warehouse/dto/request/update-stock-status-order.request';
import { OrderStatusEnum } from '@constant/common';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { OtherOrderUpdateConfirmedQuantityEvent } from '../events/other-order-update-confirmed-quantity.event';
import { ReturnOrderRepositoryInterface } from '../interface/return-order.repository.interface';

@Injectable()
export class ReturnOrderUpdateConfirmedQuantityListener extends OrderUpdateConfirmedQuantityListener {
  constructor(
    @Inject('ReturnOrderRepositoryInterface')
    private readonly returnOrderRepository: ReturnOrderRepositoryInterface,

    @Inject('WarehouseCronServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,
  ) {
    super();
  }

  @OnEvent('order.updateConfirmedQuantity')
  async handleOrderCreatedEvent(event: OtherOrderUpdateConfirmedQuantityEvent) {
    const { id, orderType, type } = event;
    let order;
    if (orderType === OtherOrderTypeEnum.RO) {
      order = await this.returnOrderRepository.checkReadyToComplete(id);
    }
    if (order) {
      const newOrder = await this.returnOrderRepository.setCompleted(id);

      const updateStockStatusOrder = new UpdateStockStatusOrderRequest();
      updateStockStatusOrder.id = newOrder.id;
      updateStockStatusOrder.completedAt = newOrder.completedAt;
      updateStockStatusOrder.status = OrderStatusEnum.Completed;
      updateStockStatusOrder.type = OtherOrderTypeEnum.RO;

      await this.warehouseService.updateStatusWarehouseStockMovement(
        updateStockStatusOrder,
      );
    }

    return;
  }
}
