import { OrderServiceInterface } from '@components/order/interface/order.service.interface';
import { CreateReturnOrderRequestDto } from '../dto/request/create-return-order.dto';
import { GetItemsByReturnTypeRequestDto } from '../dto/request/get-items-by-return-type.request.dto';
import { GetSuggestByRoIdRequestDto } from '../dto/request/get-suggest-by-ro-id.request.dto';
import { SuggestCollectedOrderExportRequestDto } from '../dto/request/suggest-collected-order-export.request.dto';
import { SuggestStoredOrderImportRequestDto } from '../dto/request/suggest-stored-order-import.request.dto';
import { UpdateReturnOrderRequestDto } from '../dto/request/update-return-order.dto';

export interface ReturnOrderServiceInterface extends OrderServiceInterface {
  update(payload: UpdateReturnOrderRequestDto): Promise<any>;
  create(payload: CreateReturnOrderRequestDto): Promise<any>;
  suggestStoredByOrderId(
    request: SuggestStoredOrderImportRequestDto,
  ): Promise<any>;
  suggestCollectedByOrderId(
    request: SuggestCollectedOrderExportRequestDto,
  ): Promise<any>;
  getItemsOrderByReturnType(
    request: GetItemsByReturnTypeRequestDto,
  ): Promise<any>;
  getSuggestByRoId(request: GetSuggestByRoIdRequestDto): Promise<any>;
}
