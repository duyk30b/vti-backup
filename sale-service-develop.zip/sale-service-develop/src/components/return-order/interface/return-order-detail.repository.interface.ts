import { OrderDetailRepositoryInterface } from '@components/order/interface/order-detail.repository.interface';
import { ReturnOrderDetailEntity } from '@entities/return-order/return-order-detail.entity';

export interface ReturnOrderDetailRepositoryInterface
  extends OrderDetailRepositoryInterface<ReturnOrderDetailEntity> {}
