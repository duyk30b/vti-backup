import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ReturnOrderWarehouseLotEntity } from '@entities/return-order/return-order-warehouse-lot.entity';

export interface ReturnOrderWarehouseLotRepositoryInterface
  extends BaseInterfaceRepository<ReturnOrderWarehouseLotEntity> {
  getLotsByItems(
    itemIds: number[],
    lotNumbers: string[],
    warehouseIds: number[],
    orderId: number,
  ): Promise<any>;
  getListLotNumber(
    itemIds?: number[],
    type?: number,
    importOrderId?: number,
  ): Promise<any>;
  getItemLotsByRoId(roId: number, itemId?: number): Promise<any>;
}
