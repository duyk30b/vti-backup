import { CreateReturnOrderRequestDto } from '../dto/request/create-return-order.dto';
import { OrderRepositoryInterface } from '@components/order/interface/order.repository.interface';
import { ReturnOrderEntity } from '@entities/return-order/return-order.entity';
import { UpdateReturnOrderRequestDto } from '../dto/request/update-return-order.dto';

export interface ReturnOrderRepositoryInterface
  extends OrderRepositoryInterface<ReturnOrderEntity> {
  createEntity(
    payload: CreateReturnOrderRequestDto,
    orderType?: number,
    actionType?: number,
  ): ReturnOrderEntity;
  updateEntity(
    payload: UpdateReturnOrderRequestDto,
    orderEntity: ReturnOrderEntity,
    orderType?: number,
    actionType?: number,
  ): ReturnOrderEntity;
  getDetail(id: number): Promise<any>;
  getList(request: any): Promise<any>;
  checkReturnOrderCodeExist(code: string, returnOrderId?: number);
}
