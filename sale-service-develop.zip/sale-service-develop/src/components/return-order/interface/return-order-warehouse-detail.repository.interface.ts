import { OrderWarehouseDetailRepositoryInterface } from '@components/order/interface/order-warehouse-detail.repository.interface';
import { ReturnOrderWarehouseDetailEntity } from '@entities/return-order/return-order-warehouse-detail.entity';

export interface ReturnOrderWarehouseDetailRepositoryInterface
  extends OrderWarehouseDetailRepositoryInterface<ReturnOrderWarehouseDetailEntity> {}
