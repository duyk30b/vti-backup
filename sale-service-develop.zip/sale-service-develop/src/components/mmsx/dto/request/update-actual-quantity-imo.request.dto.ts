import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsInt,
  IsNotEmpty,
  IsString,
  Min,
} from 'class-validator';

class QuantityRequest {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @Min(1)
  @IsInt()
  quantity: number;
}

export class UpdateActualQuantityImORequestDto {
  @ApiProperty()
  @ArrayNotEmpty()
  @Type(() => QuantityRequest)
  items: QuantityRequest[];

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  requestId: string;
}
