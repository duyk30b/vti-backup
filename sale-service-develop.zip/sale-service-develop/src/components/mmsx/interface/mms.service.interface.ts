import { ConfirmRequestImORequestDto } from '../dto/request/confirm-request-by-imo.request.dto';
import { UpdateActualQuantityImORequestDto } from '../dto/request/update-actual-quantity-imo.request.dto';

export interface MmsServiceInterface {
  getRequestById(id: string): Promise<any>;
  updateActualExportRequestQuantity(
    request: UpdateActualQuantityImORequestDto,
  ): Promise<any>;
  confirmRequestImO(request: ConfirmRequestImORequestDto): Promise<any>;
}
