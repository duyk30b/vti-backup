import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ClientProxyFactory } from '@nestjs/microservices';
import { ConfigService } from '@config/config.service';
import { MmsService } from './mms.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    'MMS_SERVICE_CLIENT',
    {
      provide: 'MmsServiceInterface',
      useClass: MmsService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'MMS_SERVICE_CLIENT',
      useFactory: (configService: ConfigService) => {
        const mmsServiceOptions = configService.get('mmsService');
        return ClientProxyFactory.create(mmsServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'MmsServiceInterface',
      useClass: MmsService,
    },
  ],
  controllers: [],
})
export class MmsModule {}
