import { ConfigService } from '@config/config.service';
import { NatsClientModule } from '@core/transporter/nats-transporter/nats-client.module';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { MmsService } from './mms.service';

@Global()
@Module({
  imports: [ConfigModule, NatsClientModule],
  exports: [
    {
      provide: 'MmsServiceInterface',
      useClass: MmsService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'MmsServiceInterface',
      useClass: MmsService,
    },
  ],
  controllers: [],
})
export class MmsModule {}
