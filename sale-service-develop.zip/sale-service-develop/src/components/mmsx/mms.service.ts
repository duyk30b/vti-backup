import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { ConfirmRequestImORequestDto } from './dto/request/confirm-request-by-imo.request.dto';
import { UpdateActualQuantityImORequestDto } from './dto/request/update-actual-quantity-imo.request.dto';
import { MmsServiceInterface } from './interface/mms.service.interface';

@Injectable()
export class MmsService implements MmsServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async getRequestById(id: string): Promise<any> {
    const response = await this.natsClientService.send(
      'detail_device_request_imo',
      { id: id },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return {};
    }

    return response.data;
  }

  async updateActualExportRequestQuantity(
    request: UpdateActualQuantityImORequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'update_actual_export_item_request_quantity',
      request,
    );

    return response;
  }

  async confirmRequestImO(request: ConfirmRequestImORequestDto): Promise<any> {
    const response = await this.natsClientService.send(
      'device_return_ticket_change_status',
      request,
    );

    return response;
  }
}
