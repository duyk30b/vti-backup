import { Inject, Injectable } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { MmsServiceInterface } from './interface/mms.service.interface';
import { UpdateActualQuantityImORequestDto } from './dto/request/update-actual-quantity-imo.request.dto';
import { ConfirmRequestImORequestDto } from './dto/request/confirm-request-by-imo.request.dto';

@Injectable()
export class MmsService implements MmsServiceInterface {
  constructor(
    @Inject('MMS_SERVICE_CLIENT')
    private readonly mmsServiceClient: ClientProxy,
  ) {}

  async getRequestById(id: string): Promise<any> {
    const response = await this.mmsServiceClient
      .send('detail_device_request_imo', { id: id })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return {};
    }

    return response.data;
  }

  async updateActualExportRequestQuantity(
    request: UpdateActualQuantityImORequestDto,
  ): Promise<any> {
    const response = await this.mmsServiceClient
      .send('update_actual_export_item_request_quantity', request)
      .toPromise();
    return response;
  }

  async confirmRequestImO(request: ConfirmRequestImORequestDto): Promise<any> {
    const response = await this.mmsServiceClient
      .send('device_return_ticket_change_status', request)
      .toPromise();
    return response;
  }
}
