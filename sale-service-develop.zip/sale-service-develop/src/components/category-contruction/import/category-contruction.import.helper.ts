import { ImportResponseDto } from "@core/dto/import/response/import.response.dto";
import { ImportResultDto } from "@core/dto/import/response/import.result.dto";
import { Inject } from '@nestjs/common'
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, In } from 'typeorm';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ConfigService } from '@nestjs/config';
import { ImportRequestDto } from "@core/dto/import/request/import.request.dto";
import { ResponsePayload } from "@utils/response-payload";
import { ImportFileDataAbstract } from "@core/abstracts/import-file-data.abstract";
import { isEmpty, keyBy } from "lodash";
import { CategoryContructionRepository } from "@repositories/category-contruction/category-contruction.repository";
import { ConstructionRepositoryInterface } from "@components/construcion/interface/construction.interface.repository";
import { stringFormat } from "@utils/object.util";

export class CategoryContructionImport extends ImportFileDataAbstract {

  private readonly ROW_NUMBER_START_DATA = 0;

  private readonly FIELD_TEMPLATE_ITEM_CONST = {
    CODE: {
      DB_COL_NAME: 'code',
      COL_NAME: 'Mã hạng mục',
      MAX_LENGTH: 50,
      ALLOW_NULL: false,
    },
    NAME: {
      DB_COL_NAME: 'name',
      COL_NAME: 'Tên hạng mục',
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    DESCRIPTION: {
      DB_COL_NAME: 'description',
      COL_NAME: 'Mô tả hạng mục',
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    CODE_CONTRUCTION: {
      DB_COL_NAME: 'codeContruction',
      COL_NAME: 'Mã công trình',
      MAX_LENGTH: 50,
      ALLOW_NULL: false,
    },
    NAME_CONTRUCTION: {
      DB_COL_NAME: 'nameContruction',
      COL_NAME: 'Tên công trình',
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    DESCRIPTION_CONTRUCTION: {
      DB_COL_NAME: 'descriptionContruction',
      COL_NAME: 'Mô tả',
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    REQUIRED_COL_NUM: 6,
  };

  private readonly SHEET_NAME = this.i18n.translate('file-header.SHEET_NAME_FILE_IMPORT_CATEGORY_CONSTRUCTION');

  constructor(
    @Inject('ConstructionRepositoryInterface')
    private readonly constructionRepository: ConstructionRepositoryInterface,

    @Inject('CategoryContructionRepositoryInterface')
    private readonly categoryContructionRepository: CategoryContructionRepository,

    @InjectDataSource()
    private readonly connection: DataSource,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    this.fieldsMap.groupSet(
      [1, 2, 3, 4, 5, 6],
      [
        this.FIELD_TEMPLATE_ITEM_CONST.CODE,
        this.FIELD_TEMPLATE_ITEM_CONST.NAME,
        this.FIELD_TEMPLATE_ITEM_CONST.DESCRIPTION,
        this.FIELD_TEMPLATE_ITEM_CONST.CODE_CONTRUCTION,
        this.FIELD_TEMPLATE_ITEM_CONST.NAME_CONTRUCTION,
        this.FIELD_TEMPLATE_ITEM_CONST.DESCRIPTION_CONTRUCTION,
      ]);
  }

  protected async saveImportDataDto(dataDto: any[], logs: ImportResultDto[], error: number, total: number, userId?: number): Promise<ImportResponseDto> {
    const findByCode = await this.categoryContructionRepository.findWithRelations(
      {
        where: {
          code: In(dataDto.map((cc) => cc.code)),
        },
      },
    );
    const findContructionByCode = await this.constructionRepository.findWithRelations(
      {
        where: {
          code: In(dataDto.map((cc) => cc.codeContruction))
        }
      }
    )

    findByCode.forEach((c) => Object.assign(c, { type: 'old' }));
    findContructionByCode.forEach((c) => Object.assign(c, { type: 'old' }));

    const findByCodeMap = keyBy(findByCode, 'code');
    const findContructionByCodeMap = keyBy(findContructionByCode, 'code');
    const entities = [];
    const valid = [];
    const {
      successMsg,
      unsuccessMsg,
    } = await this.getMessage();

    dataDto.forEach(async (data) => {
      if (userId) {
        data.userId = userId;
      }
      const { i, code, name, codeContruction } = data;
      const logRow = {
        id: i,
        row: i,
      } as ImportResultDto;
      const msgLogs = [];


      if (findByCodeMap[code] && findContructionByCodeMap[codeContruction] && findByCodeMap[code]?.['type'] === 'old') {
        data.constructionId = findContructionByCodeMap[codeContruction].id;
        const entity = this.categoryContructionRepository.updateEntity(
          findByCodeMap[code],
          data,
        );
        entities.push(entity);
        Object.assign(entity, { type: 'new' });
        findByCodeMap[code] = entity;
      } else {
        if (findContructionByCodeMap[codeContruction] && !findByCodeMap[code]) {
          data.constructionId = findContructionByCodeMap[codeContruction].id;
          const entity = this.categoryContructionRepository.createEntity(data);
          entities.push(entity);
          Object.assign(entity, { type: 'new' });
          findByCodeMap[code] = entity;
        } else if (!findContructionByCodeMap[codeContruction]) {
          msgLogs.push(
            stringFormat(
              await this.i18n.translate(
                'error.IMPORT_FIELD_NOT_EXIST',
                {
                  args: { colname: this.FIELD_TEMPLATE_ITEM_CONST.CODE_CONTRUCTION.COL_NAME },
                },
              ),
            )
          )
        }
      }
      if (isEmpty(msgLogs)) {
        logRow.log = [successMsg];
        valid.push(logRow);
      } else {
        logRow.log = msgLogs;
        logs.push(logRow);
      }
    })

    const response = new ImportResponseDto();
    if (!isEmpty(entities)) {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(entities);
        await queryRunner.commitTransaction();
        response.successCount = valid.length;
      } catch (error) {
        await queryRunner.rollbackTransaction();
        response.successCount = 0;
        valid.forEach((l) => (l.log = [unsuccessMsg]));
      } finally {
        await queryRunner.release();
        logs.push(...valid);
      }
    }
    response.result = logs;
    response.totalCount = total;
    response.result;
    return response;
  }

  public async importUtil(request: ImportRequestDto): Promise<ResponsePayload<any>> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_ITEM_CONST.REQUIRED_COL_NUM,
      this.SHEET_NAME,
    )
  }
}