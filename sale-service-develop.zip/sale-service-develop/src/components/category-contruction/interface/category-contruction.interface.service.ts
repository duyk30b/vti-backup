import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { ResponsePayload } from '@utils/response-payload';
import { ConfirmCategoryContructionRequestDto } from '../dto/request/confirm-category-contruction.request.dto';
import { CreateCategoryContructionRequestDto } from '../dto/request/create-category-contruction.request.dto';
import { DetailCategoryContructionRequestDto } from '../dto/request/detail-category-contruction.request.dto';
import { GetListCategoryContructionRequestDto } from '../dto/request/list-category-contruction.request.dto';
import { RejectCategoryContructionRequestDto } from '../dto/request/reject-category-contruction.request.dto';
import { UpdateCategoryContructionRequestDto } from '../dto/request/update-category-contruction.request.dto';
import { CategoryContructionResponseDto } from '../dto/response/category-contruction.response.dto';

export interface CategoryContructionServiceInterface {
  getList(request: GetListCategoryContructionRequestDto): Promise<any>;
  create(request: CreateCategoryContructionRequestDto): Promise<any>;
  detail(
    id: number,
  ): Promise<ResponsePayload<CategoryContructionResponseDto | any>>;
  update(payload: UpdateCategoryContructionRequestDto): Promise<any>;
  delete(
    request: DetailCategoryContructionRequestDto,
  ): Promise<ResponsePayload<any>>;
  confirm(request: ConfirmCategoryContructionRequestDto): Promise<any>;
  reject(request: RejectCategoryContructionRequestDto): Promise<any>;
  getCategoryContructionByIds(
    ids: number[],
  ): Promise<any>;
  importCategoryContruction(request: FileUpdloadRequestDto): Promise<any>;
}
