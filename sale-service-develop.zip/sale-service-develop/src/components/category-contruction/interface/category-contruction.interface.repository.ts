import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { CategoryContructionEntity } from '@entities/category-contruction/category-contruction.entity';
import { CreateCategoryContructionRequestDto } from '../dto/request/create-category-contruction.request.dto';
import { GetListCategoryContructionRequestDto } from '../dto/request/list-category-contruction.request.dto';
import { UpdateCategoryContructionRequestDto } from '../dto/request/update-category-contruction.request.dto';

export interface CategoryContructionRepositoryInterface
  extends BaseAbstractRepository<CategoryContructionEntity> {
  createEntities(params: any, userId: number): CategoryContructionEntity[];
  getList(request: GetListCategoryContructionRequestDto): Promise<any>;
  createEntity(
    request: CreateCategoryContructionRequestDto,
  ): CategoryContructionEntity;
  detail(id: number): Promise<any>;
  updateEntity(
    categoryUpdate: CategoryContructionEntity,
    request: UpdateCategoryContructionRequestDto,
  ): CategoryContructionEntity;
}
