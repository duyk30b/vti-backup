import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { isEmpty } from 'lodash';
import { ConstructionResponseDto } from '@components/construcion/dto/response/construction.response.dto';
import { ResponsePayload } from '@utils/response-payload';
import { UpdateCategoryBodyDto } from './dto/request/update-category-contruction.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { CREATE_CONSTRUCTION_PERMISSION } from '@utils/permissions/construction';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CONFIRM_CATEGORY_CONSTRUCTION_PERMISSION,
  DELETE_CATEGORY_CONSTRUCTION_PERMISSION,
  DETAIL_CATEGORY_CONSTRUCTION_PERMISSION,
  IMPORT_CATEGORY_CONSTRUCTION_PERMISSION,
  LIST_CATEGORY_CONSTRUCTION_PERMISSION,
  REJECT_CATEGORY_CONSTRUCTION_PERMISSION,
  UPDATE_CATEGORY_CONSTRUCTION_PERMISSION,
} from '@utils/permissions/category-construction';
import { GetListCategoryContructionRequestDto } from './dto/request/list-category-contruction.request.dto';
import { DetailCategoryContructionRequestDto } from './dto/request/detail-category-contruction.request.dto';
import { ConfirmCategoryContructionRequestDto } from './dto/request/confirm-category-contruction.request.dto';
import { CategoryContructionResponseDto } from './dto/response/category-contruction.response.dto';
import { CreateCategoryContructionRequestDto } from './dto/request/create-category-contruction.request.dto';
import { CategoryContructionServiceInterface } from './interface/category-contruction.interface.service';
import { RejectCategoryContructionRequestDto } from './dto/request/reject-category-contruction.request.dto';
import { MessagePattern } from '@nestjs/microservices';
import { GetCategoryContructionByIdsRequestDto } from './dto/request/get-category-contruction-by-ids.request.dto';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { NATS_SALE } from '@config/nats.config';

@Controller('construction-categories')
export class CategoryContructionController {
  constructor(
    @Inject('CategoryContructionServiceInterface')
    private readonly categoryContructionService: CategoryContructionServiceInterface,
  ) {}
  @PermissionCode(CREATE_CONSTRUCTION_PERMISSION.code)
  @Post('/create')
  @ApiOperation({
    tags: ['Category'],
    summary: 'Create Category Type',
    description: 'Định nghĩa  hạng mục',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: CategoryContructionResponseDto,
  })
  public async create(
    @Body() payload: CreateCategoryContructionRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.categoryContructionService.create(request);
  }

  @PermissionCode(LIST_CATEGORY_CONSTRUCTION_PERMISSION.code)
  @Get('/list')
  @ApiOperation({
    tags: ['Category'],
    summary: 'List Category Type',
    description: 'Danh sách hạng mục',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: CategoryContructionResponseDto,
  })
  public async getList(
    @Query() query: GetListCategoryContructionRequestDto,
  ): Promise<ResponsePayload<ConstructionResponseDto | any>> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.categoryContructionService.getList(request);
  }
  @PermissionCode(DETAIL_CATEGORY_CONSTRUCTION_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Category'],
    summary: 'Get Category detail',
    description: 'Get information of an Category',
  })
  @ApiResponse({
    status: 200,
    description: 'Get information successfully',
    type: CategoryContructionResponseDto,
  })
  public async detail(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    return await this.categoryContructionService.detail(id);
  }

  @PermissionCode(UPDATE_CATEGORY_CONSTRUCTION_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Construction'],
    summary: 'Update Construction Type',
    description: 'Sửa thông tin công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: ConstructionResponseDto,
  })
  public async update(
    @Body() payload: UpdateCategoryBodyDto,
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.categoryContructionService.update({
      ...request,
      id,
    });
  }

  @PermissionCode(DELETE_CATEGORY_CONSTRUCTION_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Category'],
    summary: 'Delete category Type',
    description: 'Xóa công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async delete(
    @Param() param: DetailCategoryContructionRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.categoryContructionService.delete(request);
  }

  @PermissionCode(CONFIRM_CATEGORY_CONSTRUCTION_PERMISSION.code)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Category'],
    summary: 'Confirm category',
    description: 'Confirm công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: SuccessResponse,
  })
  public async confirm(
    @Param() param: ConfirmCategoryContructionRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.categoryContructionService.confirm(request);
  }

  @PermissionCode(REJECT_CATEGORY_CONSTRUCTION_PERMISSION.code)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Category'],
    summary: 'reject category',
    description: 'reject công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'reject successfully',
    type: SuccessResponse,
  })
  public async reject(
    @Param() param: RejectCategoryContructionRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.categoryContructionService.reject(request);
  }

  @MessagePattern(`${NATS_SALE}.get_category_contruction_by_ids`)
  public async getCategoryContructionByIds(
    @Body() body: GetCategoryContructionByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.categoryContructionService.getCategoryContructionByIds(
      request.ids,
    );
  }

  @PermissionCode(IMPORT_CATEGORY_CONSTRUCTION_PERMISSION.code)
  @Post('/import')
  public async importCategoryContructions(@Body() body: FileUpdloadRequestDto) {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.categoryContructionService.importCategoryContruction(
      request,
    );
  }
}
