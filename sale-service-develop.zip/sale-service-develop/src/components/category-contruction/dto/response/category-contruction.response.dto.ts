import { UserResponseDto } from '@components/user/dto/response/user.response.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

export class ConstructionReponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'construction 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'ABCDEF', description: '' })
  @Expose()
  code: string;
}
export class CategoryContructionResponseDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'category 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'ABCDEF', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'ABCDEF', description: '' })
  @Expose()
  description: string;

  @ApiProperty({ example: '1', description: '0 inactive ; 1 active' })
  @Expose()
  status: number;

  @ApiPropertyOptional({ type: ConstructionReponse })
  @Expose()
  @Type(() => ConstructionReponse)
  construction: ConstructionReponse;

  @ApiPropertyOptional({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  createdBy: UserResponseDto;

  @ApiPropertyOptional({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  updatedBy: UserResponseDto;

  @ApiPropertyOptional({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  deletedBy: UserResponseDto;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty()
  @Expose()
  updatedAt: string;

  @ApiProperty()
  @Expose()
  deletedAt: string;
}
