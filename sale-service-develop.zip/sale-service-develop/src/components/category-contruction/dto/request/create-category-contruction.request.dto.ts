import { RULES } from '@components/construcion/construction.constants';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsString,
  IsNotEmpty,
  MaxLength,
  IsOptional,
  IsInt,
  Matches,
} from 'class-validator';

export class CreateCategoryContructionRequestDto extends BaseDto {
  @ApiProperty({ example: 'category 1', description: '' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(RULES.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: 'ABCDEF', description: '' })
  @IsString()
  @Matches(RULES.CODE.REGEX)
  @MaxLength(RULES.CODE.MAX_LENGTH)
  @IsNotEmpty()
  code: string;

  @ApiProperty({ example: 1, description: '' })
  @IsInt()
  @IsNotEmpty()
  constructionId: number;

  @ApiPropertyOptional({ example: 'category 1', description: '' })
  @IsString()
  @MaxLength(RULES.CREATEDFROM.MAX_LENGTH)
  @IsOptional()
  createdFrom: string;

  @ApiPropertyOptional({ example: 'ABCDEF', description: '' })
  @IsOptional()
  @IsString()
  @MaxLength(RULES.DESCRIPTION.MAX_LENGTH)
  description: string;
}
