import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt } from 'class-validator';
import { CreateCategoryContructionRequestDto } from './create-category-contruction.request.dto';

export class UpdateCategoryBodyDto extends CreateCategoryContructionRequestDto {}

export class UpdateCategoryContructionRequestDto extends UpdateCategoryBodyDto {
  @ApiProperty({ example: 'id:1' })
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
