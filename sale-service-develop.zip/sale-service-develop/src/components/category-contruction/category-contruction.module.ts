import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { CategoryContructionEntity } from '@entities/category-contruction/category-contruction.entity';
import { ConstructionEntity } from '@entities/construction/construction.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CategoryContructionRepository } from '@repositories/category-contruction/category-contruction.repository';
import { ConstructionRepository } from '@repositories/construction/construction.repository';
import { CategoryContructionController } from './category-contruction.controller';
import { CategoryContructionService } from './category-contruction.service';
import { CategoryContructionImport } from './import/category-contruction.import.helper';

@Module({
  imports: [
    TypeOrmModule.forFeature([CategoryContructionEntity, ConstructionEntity]),
    UserModule,
  ],
  providers: [
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'CategoryContructionRepositoryInterface',
      useClass: CategoryContructionRepository,
    },
    {
      provide: 'CategoryContructionServiceInterface',
      useClass: CategoryContructionService,
    },
    {
      provide: 'ConstructionRepositoryInterface',
      useClass: ConstructionRepository,
    },
    {
      provide: 'CategoryContructionImport',
      useClass: CategoryContructionImport,
    },
  ],
  controllers: [CategoryContructionController],
  exports: [],
})
export class CategoryContructionModule {}
