import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToClass, plainToInstance } from 'class-transformer';
import { I18nService } from 'nestjs-i18n';
import { DataSource, ILike, In, Not } from 'typeorm';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { uniq, map, keyBy } from 'lodash';
import { PagingResponse } from '@utils/paging.response';
import { ResponsePayload } from '@utils/response-payload';
import { InjectDataSource } from '@nestjs/typeorm';
import { ConstructionRepositoryInterface } from '@components/construcion/interface/construction.interface.repository';
import { ApiError } from '@utils/api.error';
import { CategoryContructionServiceInterface } from './interface/category-contruction.interface.service';
import { CategoryContructionRepositoryInterface } from './interface/category-contruction.interface.repository';
import { CreateCategoryContructionRequestDto } from './dto/request/create-category-contruction.request.dto';
import { UpdateCategoryContructionRequestDto } from './dto/request/update-category-contruction.request.dto';
import { CategoryContructionResponseDto } from './dto/response/category-contruction.response.dto';
import { GetListCategoryContructionRequestDto } from './dto/request/list-category-contruction.request.dto';
import { CategoryContructionEntity } from '@entities/category-contruction/category-contruction.entity';
import { DetailCategoryContructionRequestDto } from './dto/request/detail-category-contruction.request.dto';
import { ConfirmCategoryContructionRequestDto } from './dto/request/confirm-category-contruction.request.dto';
import {
  CAN_CONFIRM_CATEGORY_CONTRUCTION_STATUS,
  CAN_REJECT_CATEGORY_CONTRUCTION_STATUS,
  CategoryContructionStatusEnum,
} from './category-contruction.constants';
import { RejectCategoryContructionRequestDto } from './dto/request/reject-category-contruction.request.dto';
import { IMPORT_FILE_CONST } from '@constant/import.constant';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { CategoryContructionImport } from './import/category-contruction.import.helper';

@Injectable()
export class CategoryContructionService
  implements CategoryContructionServiceInterface
{
  constructor(
    @Inject('CategoryContructionRepositoryInterface')
    private readonly categoryContructionRepository: CategoryContructionRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ConstructionRepositoryInterface')
    private readonly constructionRepository: ConstructionRepositoryInterface,

    @Inject('CategoryContructionImport')
    private readonly categoryContructionImport: CategoryContructionImport,

    private readonly i18n: I18nService,

    @InjectDataSource()
    private readonly connection: DataSource,
  ) {}

  async create(request: CreateCategoryContructionRequestDto): Promise<any> {
    const construction = await this.constructionRepository.findOneByCondition({
      id: request.constructionId,
    });
    if (!construction) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CONSTRUCTION_NOT_FOUND'))
        .build();
    }
    if (!construction?.status) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CONSTRUCTION_NOT_ACTIVE'))
        .build();
    }
    const checkCodeExist =
      await this.categoryContructionRepository.findOneByCondition({
        code: ILike(request.code),
      });
    if (checkCodeExist) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_IS_EXIST'))
        .build();
    }

    const categoryEntity =
      await this.categoryContructionRepository.createEntity(request);
    return await this.save(
      categoryEntity,
      request,
      'message.defineCategoryContruction.createSuccess',
    );
  }

  public async update(
    payload: UpdateCategoryContructionRequestDto | any,
  ): Promise<any> {
    const { code, id } = payload;
    const construction = await this.constructionRepository.findOneByCondition({
      id: payload.constructionId,
    });
    if (!construction) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CONSTRUCTION_NOT_FOUND'))
        .build();
    }
    if (!construction?.status) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CONSTRUCTION_NOT_ACTIVE'))
        .build();
    }
    const category = await this.categoryContructionRepository.findOneById(id);
    if (!category) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const isExistCategory =
      await this.categoryContructionRepository.findByCondition({
        code: ILike(code),
        id: Not(id),
      });
    if (isExistCategory.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CATEGORY_IS_EXIST'))
        .build();
    }
    const categoryEntity =
      await this.categoryContructionRepository.updateEntity(category, payload);
    return await this.save(
      categoryEntity,
      payload,
      'message.defineCategoryContruction.updateSuccess',
    );
  }

  public async detail(
    id: number,
  ): Promise<ResponsePayload<CategoryContructionResponseDto | any>> {
    const construction = await this.categoryContructionRepository.detail(id);
    if (!construction) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const userIds = [construction.createdBy];

    const userResponse = await this.userService.getUsers(userIds);
    const userMap = keyBy(userResponse, 'id');
    if (construction.createdBy) {
      construction.createdBy = {
        id: userMap[construction.createdBy]?.id || '',
        username: userMap[construction.createdBy]?.username || '',
        fullName: userMap[construction.createdBy]?.fullName || '',
      };
    }
    const response = plainToClass(
      CategoryContructionResponseDto,
      construction,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  async getList(request: GetListCategoryContructionRequestDto): Promise<any> {
    const { result, count } = await this.categoryContructionRepository.getList(
      request,
    );
    const userIds = uniq(map(result, 'createdBy'));
    const users = await this.userService.getUsers(userIds);
    const userMap = keyBy(users, 'id');
    result.forEach((item) => {
      item.createdBy = userMap[item.createdBy];
    });
    const response = plainToClass(CategoryContructionResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  public async getCategoryContructionByIds(
    ids: number[],
  ): Promise<any> {
    const categoryContructions = await this.categoryContructionRepository.findByCondition({
      id: In(ids)
      });
    if (!categoryContructions) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const response = plainToInstance(
      CategoryContructionResponseDto,
      categoryContructions,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  public async save(
    categoryEntity: CategoryContructionEntity,
    payload: any,
    message?: string,
  ): Promise<ResponsePayload<CategoryContructionResponseDto> | any> {
    const result = await this.categoryContructionRepository.create(
      categoryEntity,
    );
    const response = plainToClass(CategoryContructionResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate(message || 'message.SUCCESS'))
      .withData(response)
      .build();
  }
  catch(error) {
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
      .withMessage(error?.message || error)
      .build();
  }

  public async delete(
    request: DetailCategoryContructionRequestDto,
  ): Promise<ResponsePayload<any>> {
    const category =
      await this.categoryContructionRepository.findOneByCondition({
        id: request.id,
        deletedAt: null,
      });
    if (!category) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    try {
      category.deletedAt = new Date();
      category.deletedBy = request.userId;
      await this.categoryContructionRepository.create(category);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            'message.defineCategoryContruction.deleteSuccess',
          ),
        )
        .build();
    } catch (error) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_DELETE'),
      ).toResponse();
    }
  }

  public async confirm(
    request: ConfirmCategoryContructionRequestDto,
  ): Promise<ResponsePayload<any>> {
    const category =
      await this.categoryContructionRepository.findOneByCondition({
        id: request.id,
      });
    if (!category) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CAN_CONFIRM_CATEGORY_CONTRUCTION_STATUS.includes(category.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CONFIRM'))
        .build();
    }

    try {
      category.status = CategoryContructionStatusEnum.ACTIVE;
      await this.categoryContructionRepository.create(category);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            'message.changeStatusSuccess',
          ),
        )
        .build();
    } catch (error) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_CONFIRM'),
      ).toResponse();
    }
  }

  public async reject(
    request: RejectCategoryContructionRequestDto,
  ): Promise<ResponsePayload<any>> {
    const category =
      await this.categoryContructionRepository.findOneByCondition({
        id: request.id,
      });
    if (!category) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CAN_REJECT_CATEGORY_CONTRUCTION_STATUS.includes(category.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_REJECT'))
        .build();
    }

    try {
      category.status = CategoryContructionStatusEnum.INACTIVE;
      await this.categoryContructionRepository.create(category);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            'message.changeStatusSuccess',
          ),
        )
        .build();
    } catch (error) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_REJECT'),
      ).toResponse();
    }
  }

  async importCategoryContruction(
    request: FileUpdloadRequestDto,
  ): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
      userId: request.userId,
    } as ImportRequestDto;
    const result = await this.categoryContructionImport.importUtil(
      importRequestDto,
    );
    if (result?.statusCode !== ResponseCodeEnum.SUCCESS) return result;
    const { data } = result;
    const successCount = data?.successCount ?? 0;
    const totalCount = data?.totalCount ?? 0;
    const logs = [];
    const succ = await this.i18n.translate('error.SUCCESS');
    const dataStart = IMPORT_FILE_CONST.SHEET.DATA_START_ROW;
    if (successCount < totalCount) {
      await data?.result.map(async (item) => {
        if (item.log[0] !== succ) {
          const log = item.log[0].toLowerCase();
          const row = dataStart + item.row;
          const mess = await this.i18n.translate('error.ERROR_RESPONSE', {
            args: {
              row: row,
              log: log,
            },
          });
          logs.push(mess);
        }
      });
      return new ResponseBuilder({
        successCount: successCount,
        totalCount: totalCount,
        logs: logs,
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          logs[0] ? logs[0] : await this.i18n.translate('error.BAD_REQUEST'),
        )
        .build();
    }

    return new ResponseBuilder({
      successCount: successCount,
      totalCount: totalCount,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
