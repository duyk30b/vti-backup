export interface SettingServiceInterface {
  getListSignature(typeObject: number) : Promise<any>
}