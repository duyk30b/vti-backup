import { Inject, Injectable } from '@nestjs/common';
import { SettingServiceInterface } from './interface/setting.service.interface';
import { ClientProxy } from '@nestjs/microservices';
import { ResponseCodeEnum } from '@constant/response-code.enum';

@Injectable()
export class SettingService implements SettingServiceInterface {
  constructor(
    @Inject('SETTING_SERVICE_CLIENT')
    private readonly settingServiceClient: ClientProxy,
  ) { }
  async getListSignature(typeObject: number): Promise<any> {
    try {
      const response = await this.settingServiceClient
        .send('get_list_signature_by_typeObject', {
          typeObject: typeObject,
        })
        .toPromise();
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }
      const { data } = response;
      const signatures = data.map((item) => {
        return {
          signature: item?.signature ?? '', name: item?.roleSetting ?? ''
        }
      })
      return signatures;
    } catch (error) {
      return [];
    }
  }
}