import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ConfigService } from '@config/config.service';
import { SettingService } from './setting.service';
import { ClientProxyFactory } from '@nestjs/microservices';

@Global()
@Module({
  imports: [ConfigModule],
  providers: [
    ConfigService,
    {
      provide: 'SETTING_SERVICE_CLIENT',
      useFactory: (configService: ConfigService) => {
        const settingServiceOptions = configService.get('settingService');
        return ClientProxyFactory.create(settingServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'SettingServiceInterface',
      useClass: SettingService,
    },
  ],
  exports: [
    'SETTING_SERVICE_CLIENT',
    {
      provide: 'SettingServiceInterface',
      useClass: SettingService,
    },
  ],
  controllers: [],
})
export class SettingModule {}
