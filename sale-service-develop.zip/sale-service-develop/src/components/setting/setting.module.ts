import { ConfigService } from '@config/config.service';
import { NatsClientModule } from '@core/transporter/nats-transporter/nats-client.module';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { SettingService } from './setting.service';

@Global()
@Module({
  imports: [ConfigModule, NatsClientModule],
  providers: [
    ConfigService,
    {
      provide: 'SettingServiceInterface',
      useClass: SettingService,
    },
  ],
  exports: [
    {
      provide: 'SettingServiceInterface',
      useClass: SettingService,
    },
  ],
  controllers: [],
})
export class SettingModule {}
