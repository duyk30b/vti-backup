import { OrderStatusEnum, StatusSyncOrderToEbsEnum } from '@constant/common';
export const QC_STAGE_ID = {
  INPUT_WAREHOUSE_BY_PO: 0,
  INPUT_WAREHOUSE_BY_PRO: 2,
  OUTPUT_WAREHOUSE_BY_PRO: 3,
  OUTPUT_WAREHOUSE_BY_SO: 5,
};

export const EVEN_PACKAGE_PALLET = {
  ONLY: 1,
};

export const EVEN = {
  IS_NOT_EVEN: '0',
  IS_EVEN: '1',
};
export enum OrderType {
  Import = 0,
  Export = 1,
}

export const SO_EXPORT_CODE_PREFIX = 'X';

export const SO_EXPORT_RULES = {
  RECEIVER: {
    MAX_LENGTH: 255,
  },
  EXPLAINATION: {
    MAX_LENGTH: 255,
  },
  ITEM_CODE: {
    MAX_LENGTH: 22,
  },
  LOT_NUMBER: {
    MAX_LENGTH: 10,
  },
  DEBIT_ACCOUNT: {
    MAX_LENGTH: 255,
  },
  CREDIT_ACCOUNT: {
    MAX_LENGTH: 255,
  },
};

export const STATUS_SYNC_SALE_ORDER_EXPORT_TO_EBS = [OrderStatusEnum.Completed];

export const STATUS_SALE_ORDER_EXPORT_DASHBOARD = [
  OrderStatusEnum.Confirmed,
  OrderStatusEnum.Completed,
  OrderStatusEnum.Collected,
  OrderStatusEnum.InCollecting,
];
export enum EventSyncSoExportEnum {
  Create = 'event.syncSoExport.create',
  Update = 'event.syncSoExport.update',
  Confirm = 'event.syncSoExport.confirm',
  Reject = 'event.syncSoExport.reject',
  Delete = 'event.syncSoExport.delete',
}
export const STATUS_SYNC_SALE_ORDER_EXPORT: number[] = [
  OrderStatusEnum.Collected,
];
export const DELIVERY_TICKET_ITEMS = [
  {
    name: 'stt',
    width: 0.3,
    rowSpan: 2,
  },
  {
    name: 'itemCode',
    width: 1.4,
    rowSpan: 2,
  },
  {
    name: 'itemName',
    width: 3.2,
    rowSpan: 2,
  },
  {
    name: 'itemUnit',
    width: 0.5,
    rowSpan: 2,
  },
  {
    name: 'quantity',
    width: 1.8,
    columnSpan: 2,
    child: [
      {
        name: 'request',
        width: 0.9,
      },
      {
        name: 'actual',
        width: 0.9,
      },
    ],
  },
  {
    name: 'price',
    width: 1.2,
    rowSpan: 2,
  },
  {
    name: 'intoMoney',
    width: 1.2,
    rowSpan: 2,
  },
  {
    name: 'account',
    width: 1.4,
    columnSpan: 2,
    child: [
      {
        name: 'debit',
        width: 0.7,
      },
      {
        name: 'own',
        width: 0.7,
      },
    ],
  },
];

export const LOT_NUMBER_COLUMN = {
  name: 'lotNumber',
  width: 1,
  rowSpan: 2,
};

export const SO_EXPORT_TICKET_ITEMS = [
  {
    name: 'stt',
    width: 1.5,
  },
  {
    name: 'itemCode',
    width: 2.5,
  },
  {
    name: 'itemName',
    width: 5,
  },
  {
    name: 'lotNumber',
    width: 2.5,
  },
  {
    name: 'itemUnit',
    width: 1,
  },
  {
    name: 'quantityRequest',
    width: 1.5,
  },
];

export const DELIVERY_RECORD_ITEMS = [
  {
    name: 'index',
    width: 0.5,
  },
  {
    name: 'itemCode',
    width: 2,
  },
  {
    name: 'itemName',
    width: 5.3,
  },
  {
    name: 'itemUnit',
    width: 1.2,
  },
  {
    name: 'quantity',
    width: 1.5,
  },
  {
    name: 'status',
    width: 1.8,
  },
  {
    name: 'note',
    width: 1.2,
  },
];

export const STATUS_SYNC_ACCEPT_SYNC_SALE_ORDER_EXPORT_TO_EBS = [
  StatusSyncOrderToEbsEnum.SYNC_WSO2_ERROR,
  StatusSyncOrderToEbsEnum.OUT_OF_SYNC,
  StatusSyncOrderToEbsEnum.COMPLETED,
];

export const DEFAULT_BUSINESS_TYPE = 'X0001';
