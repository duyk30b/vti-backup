import { Expose, Type } from 'class-transformer';

export class WarehouseResponseDto {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  description: string;

  @Expose()
  quantity: number;

  @Expose()
  factoryId: number;

  @Expose()
  manageByLot: boolean;
}

export class ItemResponseDto {
  @Expose()
  itemId: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  price: number;

  @Expose()
  itemUnit: string;

  @Expose()
  description: string;

  @Expose()
  quantity: number;
}

export class SoExportRelationData {
  @Expose()
  id: number;

  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  accountant: string;
}

class SaleOrderExportDetail {
  @Expose()
  id: number;

  @Expose()
  saleOrderExportId: number;

  @Expose()
  itemId: number;

  @Expose()
  itemCode: string;

  @Expose()
  unitId: number;

  @Expose()
  quantity: number;

  @Expose()
  actualQuantity: number;

  @Expose()
  debitAccount: string;

  @Expose()
  creditAccount: string;

  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @Expose()
  @Type(() => LotItems)
  lots: LotItems[];
}

class Warehouse {
  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  description: string;
}
export class LotItems {
  @Expose()
  lotNumber: string;

  @Expose()
  mfg: string;

  @Expose()
  planQuantity: number;

  @Expose()
  confirmedQuantity: number;

  @Expose()
  actualQuantity: number;

  @Expose()
  price: number;

  @Expose()
  amount: number;
}

export class Company {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  address: string;
}

export class ItemDetail {
  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  price: string;

  @Expose()
  itemUnit: string;
}

export class WarehouseExportProposal {
  @Expose()
  id: number;

  @Expose()
  code: string;
}

export class SyncSaleOrderExportRequest {
  @Expose()
  @Type(() => Company)
  company: Company;

  @Expose()
  id: number;

  @Expose()
  code: string;

  @Expose()
  receiptDate: Date;

  @Expose()
  status: number;

  @Expose()
  receiver: string;

  @Expose()
  departmentReceiptId: number;

  @Expose()
  businessTypeId: number;

  @Expose({ name: 'explaination' })
  explanation: string;

  @Expose()
  syncCode: string;

  @Expose()
  receiptNumber: string;

  @Expose()
  createdAt: Date;

  @Expose()
  updatedAt: Date;

  @Expose()
  @Type(() => SaleOrderExportDetail)
  saleOrderExportDetails: SaleOrderExportDetail[];

  @Expose()
  @Type(() => Warehouse)
  warehouse: Warehouse;

  @Expose()
  @Type(() => SoExportRelationData)
  source: SoExportRelationData;

  @Expose()
  @Type(() => SoExportRelationData)
  reason: SoExportRelationData;

  @Expose()
  @Type(() => SoExportRelationData)
  departmentReceipt: SoExportRelationData;

  @Expose()
  updatedBy: any;

  @Expose()
  @Type(() => WarehouseExportProposal)
  warehouseExportProposals: WarehouseExportProposal;

  @Expose()
  @Type(() => SoExportRelationData)
  construction: SoExportRelationData;

  @Expose({ name: 'ebsId' })
  ebsNumber: string;

  @Expose()
  qrCode: string;

  @Expose()
  transactionNumberCreated: string;
}
