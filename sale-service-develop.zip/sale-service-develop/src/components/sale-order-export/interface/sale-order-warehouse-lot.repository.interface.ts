import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { SaleOrderExportWarehouseLotEntity } from '../../../entities/sale-order-export/sale-order-export-warehouse-lot.entity';

export interface SaleOrderExportWarehouseLotRepositoryInterface
  extends BaseInterfaceRepository<SaleOrderExportWarehouseLotEntity> {
  getLotsByItems(
    itemIds: number[],
    lotNumbers: string[],
    warehouseIds: number[],
    orderId: number,
  ): Promise<any>;
  getItemLotsBySoExportId(soExportId: number, itemIds?: number[]): Promise<any>;
}
