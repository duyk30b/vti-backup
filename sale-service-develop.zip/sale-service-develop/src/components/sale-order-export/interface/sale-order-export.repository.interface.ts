import { ReportDetailOrderRequestDto } from '@components/dashboard/dto/request/report-detail-order.request.dto';
import { ReportTotalOrderRequestDto } from '@components/dashboard/dto/request/report-total-order.request.dto';
import { OrderRepositoryInterface } from '@components/order/interface/order.repository.interface';
import { GetPurchasedOrderListRequest } from '@components/purchased-order/dto/request/get-purchased-order-list-request.dto';
import { SaleOrderExport } from '@entities/sale-order-export/sale-order-export.entity';
import { GetListOpenTransactionRequestDto } from '../dto/request/get-list-open-transaction.request.dto';

export interface SaleOrderExportRepositoryInterface
  extends OrderRepositoryInterface<SaleOrderExport> {
  updateEntity(
    saleOrderExportEntity: SaleOrderExport,
    data: any,
  ): SaleOrderExport;
  checkImportOrderCodeExist(code: string, importOrderId?: number): Promise<any>;
  checkReadyToCollected(id: number): Promise<any>;
  setCollected(id: number): Promise<any>;
  checkCompletedReturn(id: number): Promise<any>;
  changeStatusOrder(id: number, status: number): Promise<SaleOrderExport>;
  reportTotalOrder(request: ReportTotalOrderRequestDto): Promise<number>;
  reportDetailOrder(request: ReportDetailOrderRequestDto): Promise<any>;
  getListOpenTransaction(
    request: GetListOpenTransactionRequestDto,
    defaultTimeZone: string,
  ): Promise<any>;
  getListToExport(request: GetPurchasedOrderListRequest): Promise<any>;
}
