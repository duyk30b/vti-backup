import { UpdateWarehouseOrderDetailCollectedQuantity } from '@components/order/dto/request/update-collected-quantity.request.dto';
import { OrderWarehouseDetailRepositoryInterface } from '@components/order/interface/order-warehouse-detail.repository.interface';
import { SaleOrderExportWarehouseDetail } from '@entities/sale-order-export/sale-order-export-warehouse-detail.entity';

export interface SaleOrderExportWarehouseDetailRepositoryInterface
  extends OrderWarehouseDetailRepositoryInterface<SaleOrderExportWarehouseDetail> {
  getListItemIdByQcStageId(type: any): Promise<any>;
  getUpdateOrderWarehouseDetailCollectedQuantityByIds(
    orderId: number,
    data: UpdateWarehouseOrderDetailCollectedQuantity[],
  ): Promise<SaleOrderExportWarehouseDetail[]>;
  getErrorItemById(id: number): Promise<any>;
}
