import { OrderServiceInterface } from '@components/order/interface/order.service.interface';
import { ResponsePayload } from '@utils/response-payload';
import { GetByItemIdRequestDto } from '@components/purchased-order/dto/request/get-by-item-id.request.dto';
import { GetOrderByWarehouseItemRequestDto } from '@components/order/dto/request/get-order-by-warehouse-item.request.dto';
import { GetAllSOExportRequest } from '../dto/request/get-all-sale-order-export.request.dto';
import { UpdateSaleOrderWarehouseQcQuantityDto } from '../dto/request/update-sale-order-warehouse-qc-quantity';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { DeleteMultipleWithUserIdDto } from '@core/dto/multiple/delete-multiple-with-user-id.dto';
import { SuggestCollectedOrderExportRequestDto } from '../dto/request/suggest-collected-order-export.request.dto';
import { SaleOrderExportConfirmExportRequestDto } from '../dto/request/sale-order-export-confirm-export.request.dto';
import { UpdateCollectedQuantityRequestDto } from '@components/order/dto/request/update-collected-quantity.request.dto';
import { GetSuggestStoredBySoExportIdRequestDto } from '../dto/request/get-suggest-stored-by-so-export-id.request.dto';
import { GetErrorItemByOrderRequestDto } from '@components/order/dto/request/get-error-item-by-order.request.dto';
import { CreateSaleOrderExportRequestDto } from '../dto/request/create-sale-order-export-request.dto';
import { UpdateSaleOrderExportDto } from '../dto/request/update-sale-order-export-request.dto';
import { GetOrderDetailRequestDto } from '@components/order/dto/request/get-order-detail.request.dto';
import { SetOrderStatusRequestDto } from '@components/order/dto/request/set-order-status-request.dto';
import { GetListOpenTransactionRequestDto } from '../dto/request/get-list-open-transaction.request.dto';
import { UpdateHeaderSaleOrderExportBodyDto } from '../dto/request/update-header-sale-order-export.request';
import { UpdateHeaderEbsInSOERequest } from '../dto/request/sync/update-header-ebs-in-poi.request.dto';

export interface SaleOrderExportServiceInterface extends OrderServiceInterface {
  getSaleOrderExports(
    request: GetAllSOExportRequest,
  ): Promise<ResponsePayload<any>>;
  checkItemHasExistOnSaleOrderExport(
    request: GetByItemIdRequestDto,
  ): Promise<any>;
  getSaleOrderExportByWarehouse(
    request: GetOrderByWarehouseItemRequestDto,
  ): Promise<any>;
  updateSaleOrderExportWarehouseQcQuantity(
    request: UpdateSaleOrderWarehouseQcQuantityDto,
  ): Promise<ResponsePayload<any>>;
  getListLotNumberByItemId(itemIds: number[]): Promise<ResponsePayload<any>>;
  getListItemIdByQcStageId(payload: any): Promise<any>;
  confirmMultiple(payload: DeleteMultipleDto): Promise<any>;
  rejectMultiple(payload: DeleteMultipleWithUserIdDto): Promise<any>;
  deleteMultiple(payload: DeleteMultipleDto): Promise<any>;
  suggestCollectedByOrderId(
    request: SuggestCollectedOrderExportRequestDto,
  ): Promise<any>;
  confirmExported(
    payload: SaleOrderExportConfirmExportRequestDto,
  ): Promise<any>;
  updateCollectedQuantity(
    payload: UpdateCollectedQuantityRequestDto,
  ): Promise<any>;
  getSuggestCollectedBySoExportId(
    request: GetSuggestStoredBySoExportIdRequestDto,
  ): Promise<any>;
  suggestReturnsByOrderId(
    request: SuggestCollectedOrderExportRequestDto,
  ): Promise<any>;
  getErrorItemsByOrder(request: GetErrorItemByOrderRequestDto): Promise<any>;
  createSoExport(payload: CreateSaleOrderExportRequestDto): Promise<any>;
  updateSoExport(payload: UpdateSaleOrderExportDto): Promise<any>;
  updateHeader(payload: UpdateHeaderSaleOrderExportBodyDto): Promise<any>;
  exportDeliveryTicket(payload: GetOrderDetailRequestDto): Promise<any>;
  exportSoExportTicket(payload: GetOrderDetailRequestDto): Promise<any>;
  exportDeliveryRecord(payload: GetOrderDetailRequestDto): Promise<any>;
  cancelSync(payload: SetOrderStatusRequestDto): Promise<any>;
  getListOpenTransaction(
    request: GetListOpenTransactionRequestDto,
  ): Promise<any>;
  return(payload: SetOrderStatusRequestDto): Promise<any>;
  updateHeaderEbsIn(payload: UpdateHeaderEbsInSOERequest): Promise<any>;
}
