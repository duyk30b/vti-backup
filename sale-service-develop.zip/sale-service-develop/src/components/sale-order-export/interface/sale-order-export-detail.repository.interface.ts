import { UpdateOrderDetailCollectedQuantity } from '@components/order/dto/request/update-collected-quantity.request.dto';
import { OrderDetailRepositoryInterface } from '@components/order/interface/order-detail.repository.interface';
import { SaleOrderExportDetail } from '@entities/sale-order-export/sale-order-export-detail.entity';

export interface SaleOrderExportDetailRepositoryInterface
  extends OrderDetailRepositoryInterface<SaleOrderExportDetail> {
  getUpdateOrderDetailCollectedQuantityByIds(
    orderId: number,
    data: UpdateOrderDetailCollectedQuantity[],
  ): Promise<SaleOrderExportDetail[]>;
}
