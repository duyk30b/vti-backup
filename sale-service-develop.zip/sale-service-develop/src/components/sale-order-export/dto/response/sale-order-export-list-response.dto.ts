import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { OrderListResponse } from '../../../order/dto/response/order-list-response.dto';

class SoExportRelationData {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}

class User {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  username: string;

  @ApiProperty()
  @Expose()
  fullName: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  email: string;
}

export class SaleOrderExportListResponse extends OrderListResponse {
  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  receiptDate: Date;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  receiver: string;

  @ApiProperty()
  @Expose()
  departmentReceiptId: number;

  @ApiProperty()
  @Expose()
  businessTypeId: number;

  @ApiProperty()
  @Expose()
  reasonId: number;

  @ApiProperty()
  @Expose()
  sourceId: number;

  @ApiProperty()
  @Expose()
  explanation: string;

  @ApiProperty()
  @Expose()
  syncCode: string;

  @ApiProperty()
  @Expose()
  syncStatus: number;

  @ApiProperty()
  @Expose()
  ebsId: string;

  @ApiProperty()
  @Expose()
  receiptNumber: string;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: SoExportRelationData })
  @Expose()
  @Type(() => SoExportRelationData)
  departmentReceipt: SoExportRelationData;

  @ApiProperty({ type: SoExportRelationData })
  @Expose()
  @Type(() => SoExportRelationData)
  businessType: SoExportRelationData;

  @ApiProperty({ type: SoExportRelationData })
  @Expose()
  @Type(() => SoExportRelationData)
  warehouse: SoExportRelationData;

  @ApiProperty()
  @Expose()
  @Type(() => User)
  user: User;
}
