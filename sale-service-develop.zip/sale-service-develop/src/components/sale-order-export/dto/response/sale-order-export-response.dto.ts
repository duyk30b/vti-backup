import { WarehouseResponseDto } from '../../../warehouse/dto/response/warehouse.dto.response';
import { ItemResponseDto } from '../../../item/dto/response/item.dto.response';
import { Expose, Transform, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { BaseDto } from '@core/dto/base.dto';

export class LotsItem {
  @ApiProperty({ description: 'số lô' })
  @Expose()
  lotNumber: string;

  @ApiProperty({ description: 'Ngày sản xuất', example: 1 })
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  mfg: string;

  @ApiProperty({ description: '', example: 1 })
  @Expose()
  quantity: number;

  @ApiProperty({ description: 'Số lượng IPC xác nhận ', example: 1 })
  @Expose()
  confirmedQuantity: number;

  @ApiProperty({ description: 'Số lượng IPC xác nhận ', example: 1 })
  @Expose()
  collectedQuantity: number;

  @ApiProperty({
    description: 'Số  lượng giao dịch(Số lượng Nv kho approve )',
    example: 1,
  })
  @Expose()
  actualQuantity: number;
}

class ItemsSaleOrderExport {
  @ApiProperty({ description: 'Id của item ', example: 1 })
  @Expose()
  id: number;

  @ApiProperty({ description: 'Code của item ', example: '02312' })
  @Expose()
  code: string;

  @ApiProperty({ description: 'Tên của item ', example: ' Vật phẩm' })
  @Expose()
  name: string;

  @ApiProperty({ description: 'Unit ', example: 'Cái' })
  @Expose()
  itemUnit: string;

  @ApiProperty()
  @Expose()
  debitAccount: string;

  @ApiProperty()
  @Expose()
  creditAccount: string;

  @ApiProperty({ description: 'Số lượng mua  ', example: 1 })
  @Expose()
  quantity: number;

  @ApiProperty({
    description: 'Số  lượng IPC xác nhận (Số lượng kiể m định )',
    example: 1,
  })
  @Expose()
  confirmedQuantity: number;

  @ApiProperty({
    description:
      'Số  lượng giao dịch(Số lượng Nv kho approve  - Số lượng nhập thực tết)',
    example: 1,
  })
  @Expose()
  actualQuantity: number;

  @ApiProperty({
    description:
      'Số  lượng giao dịch(Số lượng Nv kho approve  - Số lượng nhập thực tết)',
    example: 1,
  })
  @Expose()
  requestedQuantityWarehouseExportProposal: number;

  @ApiProperty({
    description: 'Số lượng có thể xuất)',
    example: 1,
  })
  @Expose()
  exportableQuantity: number;

  @ApiProperty({ type: ItemResponseDto })
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty({ description: 'Lô', example: 1 })
  @Expose()
  @Type(() => LotsItem)
  lots: LotsItem[];
}

class SoExportRelationData {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  address: string;

  @ApiProperty()
  @Expose()
  accountant: string;

  @ApiProperty()
  @Expose()
  manageByLot: number;
}

class SaleOrderExportWarehouseLot {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  saleOrderExportId: number;

  @ApiProperty()
  @Expose()
  saleOrderExportWarehouseDetailId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  price: number;

  @ApiProperty()
  @Expose()
  amount: number;

  @ApiProperty()
  @Expose()
  collectedQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  requestedQuantityWarehouseExportProposal: number;

  @ApiProperty()
  @Expose()
  exportableQuantity: number;

  @ApiProperty()
  @Expose()
  debitAccount: string;

  @ApiProperty()
  @Expose()
  creditAccount: string;

  @ApiProperty({ type: ItemResponseDto })
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty({ type: WarehouseResponseDto })
  @Expose()
  @Type(() => WarehouseResponseDto)
  warehouse: WarehouseResponseDto;
}

class SaleOrderExportDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  saleOrderExportId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  itemCode: string;

  @ApiProperty()
  @Expose()
  unitId: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  debitAccount: string;

  @ApiProperty()
  @Expose()
  creditAccount: string;

  @ApiProperty({ type: ItemResponseDto })
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;
}

class SaleOrderExportWarehouseDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  saleOrderExportId: number;

  @ApiProperty()
  @Expose()
  saleOrderExportDetailId: number;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  collectedQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  lots: string;

  @ApiProperty({ type: WarehouseResponseDto })
  @Expose()
  @Type(() => WarehouseResponseDto)
  warehouse: WarehouseResponseDto;

  @ApiProperty({ type: ItemResponseDto })
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;
}

class SaleOrderExportWarehouse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  factoryId: number;

  @Expose()
  manageByLot: boolean;
}

class BusinessTypeAttributes {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  fieldName: string;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  columnName: string;

  @ApiProperty()
  @Expose()
  tableName: string;

  @ApiProperty()
  @Expose()
  required: number;

  @ApiProperty()
  @Expose()
  value: any;
}

export class SaleOrderExportResponseDto extends BaseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  companyId: number;

  @ApiProperty({ type: SoExportRelationData })
  @Expose()
  @Type(() => SoExportRelationData)
  company: SoExportRelationData;

  @ApiProperty()
  @Expose()
  receiptDate: Date;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  syncStatus: number;

  @ApiProperty()
  @Expose()
  receiver: string;

  @ApiProperty()
  @Expose()
  departmentReceiptId: number;

  @ApiProperty()
  @Expose()
  businessTypeId: number;

  @ApiProperty()
  @Expose()
  explaination: string;

  @ApiProperty()
  @Expose()
  syncCode: string;

  @ApiProperty()
  @Expose()
  ebsId: string;

  @ApiProperty()
  @Expose()
  transactionNumberCreated: string;

  @ApiProperty()
  @Expose()
  oldEbsId: string;

  @ApiProperty()
  @Expose()
  oldTransactionNumberCreated: string;

  @ApiProperty()
  @Expose()
  receiptNumber: string;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty()
  @Expose()
  user: any;

  @ApiProperty()
  @Expose()
  order: any;

  @ApiProperty({ type: SaleOrderExportDetail, isArray: true })
  @Expose()
  @Type(() => SaleOrderExportDetail)
  saleOrderExportDetails: SaleOrderExportDetail[];

  @ApiProperty({ type: SaleOrderExportWarehouseLot, isArray: true })
  @Expose()
  @Type(() => SaleOrderExportWarehouseLot)
  saleOrderExportWarehouseLots: SaleOrderExportWarehouseLot[];

  @ApiProperty({ type: SaleOrderExportWarehouseDetail, isArray: true })
  @Expose()
  @Type(() => SaleOrderExportWarehouseDetail)
  saleOrderExportWarehouseDetails: SaleOrderExportWarehouseDetail[];

  @ApiProperty({ type: SaleOrderExportWarehouse })
  @Expose()
  @Type(() => SaleOrderExportWarehouse)
  warehouse: SaleOrderExportWarehouse;

  @ApiProperty({ type: SoExportRelationData })
  @Expose()
  @Type(() => SoExportRelationData)
  source: SoExportRelationData;

  @ApiProperty({ type: SoExportRelationData })
  @Expose()
  @Type(() => SoExportRelationData)
  reason: SoExportRelationData;

  @ApiProperty({ type: SoExportRelationData })
  @Expose()
  @Type(() => SoExportRelationData)
  departmentReceipt: SoExportRelationData;

  @ApiProperty({ type: SoExportRelationData })
  @Expose()
  @Type(() => SoExportRelationData)
  businessType: SoExportRelationData;

  @ApiProperty({ type: BusinessTypeAttributes, isArray: true })
  @Expose()
  @Type(() => BusinessTypeAttributes)
  attributes: BusinessTypeAttributes[];

  @ApiProperty()
  @Expose()
  createdByUser: any;

  @ApiProperty()
  @Expose()
  approvedByUser: any;

  @ApiProperty()
  @Expose()
  updatedBy: any;

  @ApiProperty({ type: ItemsSaleOrderExport, isArray: true })
  @Expose()
  @Type(() => ItemsSaleOrderExport)
  itemsSync: ItemsSaleOrderExport[];
}
