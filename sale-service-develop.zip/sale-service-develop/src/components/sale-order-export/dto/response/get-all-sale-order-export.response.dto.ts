import { Expose, Transform, Type } from 'class-transformer';

export class GetAllSOExportResponse {
  @Expose({ name: 'id' })
  id: number;

  @Expose()
  code: string;

  @Expose()
  companyId: number;

  @Expose()
  customerId: number;

  @Expose()
  name: string;

  @Expose()
  description: string;

  @Expose({ name: 'id' })
  documentNumber: number;

  @Expose()
  createdAt: Date;

  @Expose({ name: 'customer' })
  @Transform((value) => {
    return value.obj['name'];
  })
  customerName: string;

  @Expose({ name: 'saleOrderWarehouseDetails' })
  @Type(() => Item)
  items: Item[];
}

class Item {
  @Expose()
  warehouseId: number;

  @Expose()
  itemId: number;

  @Expose()
  quantity: number;

  @Expose()
  confirmedQuantity: number;
}
