import { OrderResponseDto } from '../../../order/dto/response/order-response.dto';
import { IsArray } from 'class-validator';
import { Expose, Transform, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

class Warehouse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}

class Detail {
  @ApiProperty()
  @Expose({ name: 'itemDetailSettingId' })
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty({})
  @Expose({ name: 'itemDetailQuantity' })
  quantity: number;
}

class Customer {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class LotDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  locationId: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty({ description: '' })
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  mfg: string;

  @ApiProperty({ description: 'Số lượng KH' })
  @Expose()
  planQuantity: number;

  @ApiProperty({ description: 'Số lượng cần nhập còn lại' })
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  remainStockQuantity: number;

  @ApiProperty({ description: 'Số lươgnj đã xác nhận' })
  @Expose()
  qcPassQuantity: number;

  @ApiProperty({ description: 'Số lươgnj đã xác nhận' })
  @Expose()
  qcRejectQuantity: number;

  @ApiProperty({ description: 'Số lượng cần nhập còn lại' })
  @Expose()
  actualQuantity: number;

  @ApiProperty({ description: 'Số lượng nhặt' })
  @Expose()
  collectedQuantity: number;

  @ApiProperty({ description: 'Số lượng trả' })
  @Expose()
  returnedQuantity: number;

  @ApiProperty()
  @Expose()
  isExpired: boolean;
}

class SOItem {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  detailId: number;

  @ApiProperty()
  @Expose()
  warehouseDetailId: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty({ description: 'Số lượng thực tế đã nhập' })
  @Expose()
  actualQuantity: number;

  @ApiProperty({ description: 'Số lượng thực tế đã gom' })
  @Expose()
  collectedQuantity: number;

  @ApiProperty({ description: 'Số lượng thực tế đã gom' })
  @Expose()
  returnedQuantity: number;

  @ApiProperty({ description: 'Số lượng cần nhập còn lại' })
  @Expose()
  quantity: number;

  @ApiProperty({ description: 'Số lượng cần nhập theo kế hoạch' })
  @Expose()
  planQuantity: number;

  @ApiProperty({ description: 'Số lươgnj đã xác nhận' })
  @Expose()
  confirmQuantity: number;

  @ApiProperty({ description: 'Số lươgnj đã xác nhận' })
  @Expose()
  qcPassQuantity: number;

  @ApiProperty({ description: 'Số lươgnj đã xác nhận' })
  @Expose()
  qcRejectQuantity: number;

  @ApiProperty({ description: 'Số lươgnj đã xác nhận' })
  @Expose()
  qcCheck: number;

  @ApiProperty({ description: 'Số lươgnj đã xác nhận' })
  @Expose()
  qcCriteriaId: number;

  @ApiProperty({
    description: 'Danh sách chi tiết',
    type: () => Detail,
    isArray: true,
  })
  @Expose()
  @Type(() => Detail)
  details: Detail[];

  @ApiProperty({
    description: 'Danh sách số lô',
    type: () => LotDetail,
    isArray: true,
  })
  @Expose()
  @Type(() => LotDetail)
  lots: LotDetail[];
}

export class SaleOrderExportWarehouseDetailResponseDto extends OrderResponseDto {
  @ApiProperty()
  @Expose()
  vendorId: number;

  @ApiProperty({
    type: () => Warehouse,
    description: 'Chi tiết kho theo user - chỉ kho thuộc user mới hiển thị',
  })
  @Expose()
  @Type(() => Warehouse)
  warehouse: Warehouse;

  @ApiProperty({
    type: () => Customer,
  })
  @Expose()
  @Type(() => Customer)
  customer: Customer;

  @Expose()
  departmentReceiptId: number;

  @ApiProperty({
    type: () => SOItem,
    isArray: true,
    description: 'Danh sách item',
  })
  @Expose()
  @Type(() => SOItem)
  @IsArray()
  items: SOItem[];
}
