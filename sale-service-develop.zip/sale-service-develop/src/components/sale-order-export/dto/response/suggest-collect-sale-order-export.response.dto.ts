import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { SaleOrderExportResponseDto } from './sale-order-export-response.dto';

class ItemLotSOExport {
  @ApiProperty()
  @Expose()
  locationId: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  stockQuantity: number;

  @ApiProperty()
  @Expose()
  collectedQuantity: number;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  remainQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;
}

class LocationSOExport {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  locationName: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  collectedQuantity: number;

  @ApiProperty({ type: ItemLotSOExport, isArray: true })
  @Expose()
  @Type(() => ItemLotSOExport)
  lots: ItemLotSOExport[];
}

class Detail {
  @ApiProperty()
  @Expose({ name: 'itemDetailSettingId' })
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty({})
  @Expose({ name: 'itemDetailQuantity' })
  quantity: number;
}

class ItemsSaleOrderExport {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  remainQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  collectedQuantity: number;

  @ApiProperty({ type: LocationSOExport, isArray: true })
  @Expose()
  @Type(() => LocationSOExport)
  locations: LocationSOExport[];

  @ApiProperty({
    description: 'Danh sách chi tiết',
    type: () => Detail,
    isArray: true,
  })
  @Expose()
  @Type(() => Detail)
  details: Detail[];
}
export class SuggestCollectSaleOrderExportResponseDto extends SaleOrderExportResponseDto {
  @ApiProperty()
  @Expose()
  warehouseName: string;

  @ApiProperty()
  @Expose()
  customerName: string;

  @ApiProperty({ type: ItemsSaleOrderExport, isArray: true })
  @Expose()
  @Type(() => ItemsSaleOrderExport)
  items: ItemsSaleOrderExport[];
}
