import { CreateSaleOrderExportRequestDto } from './create-sale-order-export-request.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class UpdateSaleOrderExportBodyDto extends CreateSaleOrderExportRequestDto {}

export class UpdateSaleOrderExportDto extends UpdateSaleOrderExportBodyDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  id: number;
}
