import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsDateString,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator';
import * as moment from 'moment';

class ExecuteSOEEbsItemRequest {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  item: string;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  lots: string;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  planQuantities: number;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  actualQuantities: number;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  costOfGoods: number;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  unitPrice: number;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  debt: string;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  credit: string;
}

export class ExecuteSOEEbsRequest extends BaseDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  idEbs: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  receiveId: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  username: string;

  @ApiProperty()
  @Transform((v) => moment(v.value, 'DD/MM/YYYY HH:mm:ss').toISOString())
  @IsDateString()
  @IsNotEmpty()
  dateCreated: Date;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  warehouse: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  source: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  reason: string;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  receiver: string;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  departmentReceipt: string;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  reference: string;

  @ApiProperty({
    type: ExecuteSOEEbsItemRequest,
    isArray: true,
  })
  @ArrayUnique((i: ExecuteSOEEbsItemRequest) => `${i.item}_${i.lots}`)
  @Type(() => ExecuteSOEEbsItemRequest)
  @ArrayNotEmpty()
  item: ExecuteSOEEbsItemRequest[];
}
