import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsNumber,
  IsInt,
  Min,
  IsNotEmpty,
  IsString,
  MaxLength,
  IsDateString,
} from 'class-validator';

export class UpdateSaleOrderWarehouseQcQuantityBodyDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @MaxLength(20)
  lotNumber: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  mfg: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  qcPassQuantity: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  qcRejectQuantity: number;

  @ApiProperty()
  @IsNumber()
  userId: number;
}

export class UpdateSaleOrderWarehouseQcQuantityDto extends UpdateSaleOrderWarehouseQcQuantityBodyDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  saleOrderExportId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  warehouseId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  itemId: number;
}
