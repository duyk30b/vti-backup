import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty, IsOptional } from 'class-validator';

export class SaleOrderExportConfirmExportRequestBodyDto extends BaseDto {}

export class SaleOrderExportConfirmExportRequestDto extends SaleOrderExportConfirmExportRequestBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
