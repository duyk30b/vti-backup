import { GetOrderListRequest } from '@components/order/dto/request/get-order-list.request.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional } from 'class-validator';

export class GetSaleOrderExportListRequest extends GetOrderListRequest {
  @ApiPropertyOptional({ example: '1,2,3' })
  @IsOptional()
  queryIds?: string;
}
