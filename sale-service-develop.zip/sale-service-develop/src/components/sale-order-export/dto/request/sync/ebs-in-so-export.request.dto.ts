import { BaseDto } from '@core/dto/base.dto';
import { Expose, Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsInt,
  IsNumber,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

class EbsInSoExportItem {
  @Expose({ name: 'item' })
  @IsString()
  code: string;

  @Expose({ name: 'lots' })
  @IsOptional()
  @IsString()
  lot: string;

  @Expose({ name: 'lotsWMS' })
  @IsOptional()
  @IsString()
  lotWMS: string;

  @Expose()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  @IsNumber()
  costOfGoods: number;

  // @Expose()
  // @IsOptional()
  // @Transform(({ value }) => Number(value))
  // @IsNumber()
  // unitPrice: number;

  @Expose({ name: 'debt' })
  @IsOptional()
  @IsString()
  debt: string;

  @Expose({ name: 'credit' })
  @IsOptional()
  @IsString()
  credit: string;
}

export class EbsInSoExportRequestDto extends BaseDto {
  @Expose({ name: 'idWMS' })
  @Transform(({ value }) => Number(value))
  @IsInt()
  id: number;

  @Expose()
  @Transform(({ value }) => Number(value))
  @IsInt()
  status: number;

  @Expose({ name: 'transactionIssuesCreated' })
  @IsString()
  ebsId: string;

  @Expose({ name: 'transactionNumberCreated' })
  @IsString()
  transactionNumberCreated: string;

  @Expose()
  @ArrayNotEmpty()
  @ValidateNested({ each: true })
  @Type(() => EbsInSoExportItem)
  item: EbsInSoExportItem[];
}
