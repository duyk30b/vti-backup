import { BaseDto } from '@core/dto/base.dto';
import { Expose, Transform, Type } from 'class-transformer';
import {
  IsArray,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

class EbsInSOExportItem {
  @Expose({ name: 'numberOrder' })
  @IsString()
  order: string;

  @Expose()
  @IsOptional()
  @IsString()
  debt: string;
}

export class UpdateHeaderEbsInSOERequest extends BaseDto {
  @Expose({ name: 'idWMS' })
  @Transform(({ value }) => Number(value))
  @IsInt()
  @IsNotEmpty()
  id: number;

  @Expose()
  @Transform(({ value }) => Number(value))
  @IsInt()
  @IsNotEmpty()
  status: number;

  @Expose({ name: 'transactionIssuesCreated' })
  @IsString()
  ebsId: string;

  @Expose({ name: 'transactionNumberCreated' })
  @IsString()
  transactionNumberCreated: string;

  @Expose()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => EbsInSOExportItem)
  @IsOptional()
  item: EbsInSOExportItem[];
}
