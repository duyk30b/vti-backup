import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsArray, IsInt, IsNotEmpty, IsOptional } from 'class-validator';

export class GetSuggestStoredBySoExportIdRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  soExportId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  itemIds: number[];
}
