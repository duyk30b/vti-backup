import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayUnique,
  IsArray,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

class Lot {
  @ApiProperty()
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @Transform(({ value }) => Number(value))
  quantity: number;
}

class ItemLots {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @Transform(({ value }) => Number(value))
  quantity: number;

  @ApiProperty()
  @IsOptional()
  @ArrayUnique((lot: Lot) => lot.lotNumber)
  @ValidateNested()
  @Type(() => Lot)
  lots: Lot[];
}
export class SuggestCollectedOrderExportRequestBodyDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @ArrayUnique((item: ItemLots) => item.itemId)
  @ValidateNested()
  @Type(() => ItemLots)
  items: ItemLots[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  locatorIds: number[];
}

export class SuggestCollectedOrderExportRequestDto extends SuggestCollectedOrderExportRequestBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;
}
