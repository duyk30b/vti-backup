import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayUnique,
  IsArray,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

class SuggestLotRetunItem {
  @ApiProperty()
  @IsString()
  lotNumber: string;

  @ApiProperty()
  @IsInt()
  quantity: number;
}

class ReturnItemSaleOrderExport {
  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiProperty({ type: SuggestLotRetunItem, isArray: true })
  @ValidateNested()
  @Type(() => SuggestLotRetunItem)
  lots: SuggestLotRetunItem[];
}

export class SuggestReturnsSaleOrderExportRequestBodyDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @ValidateNested()
  @ArrayUnique((item) => item.itemId)
  items: ReturnItemSaleOrderExport[];

  @ApiProperty()
  @IsOptional()
  @IsArray()
  warehouseShelfFloorIds: number[];
}

export class SuggestReturnsSaleOrderExportRequestDto extends SuggestReturnsSaleOrderExportRequestBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;
}
