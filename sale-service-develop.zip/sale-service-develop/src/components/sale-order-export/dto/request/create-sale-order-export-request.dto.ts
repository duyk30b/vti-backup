import { SO_EXPORT_RULES } from '@components/sale-order-export/sale-order-export.contant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsDateString,
  IsInt,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  Length,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';

export class ItemRequest {
  @ApiProperty()
  @IsInt()
  @Transform(({ value }) => Number(value))
  id: number;

  @ApiPropertyOptional()
  @IsString()
  @MaxLength(SO_EXPORT_RULES.ITEM_CODE.MAX_LENGTH)
  itemCode: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  @Transform(({ value }) => Number(value))
  unitId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(SO_EXPORT_RULES.LOT_NUMBER.MAX_LENGTH)
  lotNumber: string;

  @ApiProperty()
  @IsNumber()
  @Min(0)
  @Transform(({ value }) => Number(value))
  quantity: number;

  @ApiProperty()
  @IsNumber()
  @Transform(({ value }) => Number(value))
  @IsPositive()
  price: number;

  @ApiProperty()
  @IsNumber()
  @Transform(({ value }) => Number(value))
  @IsPositive()
  amount: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(SO_EXPORT_RULES.DEBIT_ACCOUNT.MAX_LENGTH)
  debitAccount: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(SO_EXPORT_RULES.CREDIT_ACCOUNT.MAX_LENGTH)
  creditAccount: string;

  @ApiProperty()
  @IsInt()
  @Transform(({ value }) => Number(value))
  warehouseId: number;
}

export class AttributeRequest {
  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  id: number;

  @ApiProperty()
  value: any;
}

export class CreateSaleOrderExportBodyDto extends BaseDto {
  @ApiProperty()
  @IsDateString()
  receiptDate: Date;

  @ApiProperty()
  @IsString()
  @MaxLength(SO_EXPORT_RULES.RECEIVER.MAX_LENGTH)
  receiver: string;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  businessTypeId: number;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  reasonId: number;

  @ApiProperty()
  @IsString()
  @IsOptional()
  @MaxLength(SO_EXPORT_RULES.EXPLAINATION.MAX_LENGTH)
  explanation: string;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  departmentReceiptId: number;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  sourceId: number;

  @ApiProperty()
  @IsInt()
  @Transform(({ value }) => Number(value))
  warehouseId: number;

  @ApiProperty()
  @Transform(({ value }) => JSON.parse(value))
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => ItemRequest)
  items: ItemRequest[];
}

export class CreateSaleOrderExportRequestDto extends CreateSaleOrderExportBodyDto {
  @ApiProperty()
  @ValidateNested()
  @Type(() => AttributeRequest)
  attributes: AttributeRequest[];
}
