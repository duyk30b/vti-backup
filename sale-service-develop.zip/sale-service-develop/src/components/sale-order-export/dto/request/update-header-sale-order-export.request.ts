import { SO_EXPORT_RULES } from '@components/sale-order-export/sale-order-export.contant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  Matches,
  MaxLength,
  ValidateIf,
  ValidateNested,
} from 'class-validator';
import { AttributeRequest } from './create-sale-order-export-request.dto';
import { isEmpty, isString } from 'lodash';

class ItemRequest {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  itemId: number;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  lotNumber: string;

  @ApiPropertyOptional()
  @ValidateIf((_, value) => !isEmpty(value))
  @Matches(
    /^[a-zA-Z0-9]{11}\.[a-zA-Z0-9]{4}\.[a-zA-Z0-9]{4}\.[a-zA-Z0-9]{3}\d+$/,
  )
  @MaxLength(SO_EXPORT_RULES.DEBIT_ACCOUNT.MAX_LENGTH)
  @IsString()
  @IsOptional()
  debitAccount: string;
}

export class UpdateHeaderSaleOrderExportBodyDto extends BaseDto {
  @ApiProperty()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  @IsOptional()
  id: number;

  @ApiProperty()
  @ValidateIf((_, value) => !isEmpty(value))
  @Matches(/^02\.[a-zA-Z0-9]+\.[a-zA-Z0-9]+\.\d+$/, {
    message: 'error.EBS_NOT_MATCHES',
  })
  @IsString()
  @IsOptional()
  ebsId: string;

  @ApiProperty()
  @ValidateIf((_, value) => !isEmpty(value))
  @Matches(/^03\.[a-zA-Z0-9]+\.[a-zA-Z0-9]+\.\d+$/, {
    message: 'error.TRANSACTION_NUMBER_EBS_NOT_MATCHES',
  })
  @IsString()
  @IsOptional()
  transactionNumberCreated: string;

  @ApiProperty()
  @IsString()
  @MaxLength(SO_EXPORT_RULES.RECEIVER.MAX_LENGTH)
  receiver: string;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  businessTypeId: number;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  reasonId: number;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsString()
  @IsOptional()
  @MaxLength(SO_EXPORT_RULES.EXPLAINATION.MAX_LENGTH)
  explaination: string;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  departmentReceiptId: number;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  sourceId: number;

  @ApiProperty()
  @ValidateNested()
  @Type(() => AttributeRequest)
  attributes: AttributeRequest[];

  @ApiProperty()
  @ValidateNested()
  @Transform(({ value }) => (isString(value) ? JSON.parse(value) : value))
  @Type(() => ItemRequest)
  @ArrayNotEmpty()
  items: ItemRequest[];
}
