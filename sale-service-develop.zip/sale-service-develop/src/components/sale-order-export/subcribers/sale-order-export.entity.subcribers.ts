import { Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, EntitySubscriberInterface, UpdateEvent } from 'typeorm';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { SaleOrderExport } from '@entities/sale-order-export/sale-order-export.entity';
import {
  EventSyncSoExportEnum,
  STATUS_SYNC_SALE_ORDER_EXPORT,
} from '../sale-order-export.contant';

@Injectable()
export class SaleOrderExportSubcriber
  implements EntitySubscriberInterface<SaleOrderExport>
{
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private eventEmitter: EventEmitter2,
  ) {
    dataSource.subscribers.push(this);
  }
  listenTo() {
    return SaleOrderExport;
  }

  afterUpdate(event: UpdateEvent<SaleOrderExport>): void | Promise<any> {
    if (STATUS_SYNC_SALE_ORDER_EXPORT.includes(+event.entity.status)) {
      this.eventEmitter.emit(EventSyncSoExportEnum.Update, event.entity.id);
    }
  }
}
