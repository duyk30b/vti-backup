import {
  SetOrderStatusBodyDto,
  SetOrderStatusRequestDto,
} from '../order/dto/request/set-order-status-request.dto';
import {
  GetOrderDetailQueryRequestDto,
  GetOrderDetailRequestDto,
} from '@components/order/dto/request/get-order-detail.request.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Res,
} from '@nestjs/common';
import { SaleOrderExportServiceInterface } from '@components/sale-order-export/interface/sale-order-export.service.interface';
import { MessagePattern } from '@nestjs/microservices';
import {
  GetOrderRequestBodyDto,
  GetOrderRequestDto,
} from '@components/order/dto/request/get-order.request.dto';
import { isEmpty } from 'lodash';
import { UpdateOrderDetailActualQuantityRequestDto } from '@components/order/dto/request/update-actual-quantity-order-detail.request.dto';
import { UpdateOrderDetailConfirmQuantityRequestDto } from '@components/order/dto/request/update-confirm-quantity-order-detail.request.dto';
import { DeleteOrderQueryRequestDto } from '@components/order/dto/request/delete-order.request.dto';
import { GetListOrderByIdsRequestDto } from '@components/order/dto/request/get-list-order-by-ids.request.dto';
import { GetByItemIdRequestDto } from '@components/purchased-order/dto/request/get-by-item-id.request.dto';
import {
  GetOrderDetailByWarehouseQueryDto,
  GetOrderDetailByWarehouseRequestDto,
} from '@components/order/dto/request/get-order-detail-by-warehouse.request.dto';
import {
  GetOrderWarehouseQueryRequest,
  GetOrderWarehouseRequest,
} from '@components/order/dto/request/get-order-warehouse.request.dto';
import { GetOrderByWarehouseItemRequestDto } from '@components/order/dto/request/get-order-by-warehouse-item.request.dto';
import { CreateSaleOrderExportBodyDto } from './dto/request/create-sale-order-export-request.dto';
import { UpdateSaleOrderExportBodyDto } from './dto/request/update-sale-order-export-request.dto';
import { GetSaleOrderExportListRequest } from './dto/request/get-sale-order-export-list-request.dto';
import { GetAllSOExportRequest } from './dto/request/get-all-sale-order-export.request.dto';
import {
  UpdateSaleOrderWarehouseQcQuantityBodyDto,
  UpdateSaleOrderWarehouseQcQuantityDto,
} from './dto/request/update-sale-order-warehouse-qc-quantity';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CREATE_SALE_ORDER_EXPORT_PERMISSION,
  UPDATE_SALE_ORDER_EXPORT_PERMISSION,
  DELETE_SALE_ORDER_EXPORT_PERMISSION,
  DETAIL_SALE_ORDER_EXPORT_PERMISSION,
  LIST_SALE_ORDER_EXPORT_PERMISSION,
  CONFIRM_SALE_ORDER_EXPORT_PERMISSION,
  REJECT_SALE_ORDER_EXPORT_PERMISSION,
  EXPORT_SALE_ORDER_EXPORT_PERMISSION,
  CANCEL_SYNC_SALE_ORDER_EXPORT_PERMISSION,
  UPDATE_HEADER_SALE_ORDER_EXPORT_PERMISSION,
  RETURN_SALE_ORDER_EXPORT_PERMISSION,
} from '@utils/permissions/sale-order-export';
import { ApiOperation, ApiParam, ApiResponse } from '@nestjs/swagger';
import { GetListLotNumberResponseDto } from '@components/import-order/dto/response/list-lot-number.response.dto';
import { GetLotNumberByItemIdRequestDto } from '@components/import-order/dto/request/list-lot-number.request.dto';
import { GetListItemIdByQcStageIdRequestDto } from './dto/request/get-list-item-id-by-qcstageid.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { SuggestCollectedOrderExportRequestBodyDto } from './dto/request/suggest-collected-order-export.request.dto';
import { SaleOrderExportConfirmExportRequestDto } from './dto/request/sale-order-export-confirm-export.request.dto';
import { UpdateCollectedQuantityRequestDto } from '@components/order/dto/request/update-collected-quantity.request.dto';
import { GetSuggestStoredBySoExportIdRequestDto } from './dto/request/get-suggest-stored-by-so-export-id.request.dto';
import { SuggestReturnsSaleOrderExportRequestBodyDto } from './dto/request/suggest-returns-sale-order-export.request.dto';
import { UpdateOrderDetailReturnQuantityRequestDto } from '@components/order/dto/request/update-return-quantity-order-detail.request.dto';
import { GetErrorItemByOrderRequestDto } from '@components/order/dto/request/get-error-item-by-order.request.dto';
import { SaleOrderExportWarehouseDetailResponseDto } from './dto/response/sale-order-export-warehouse-detail-response.dto';
import { SaleOrderExportResponseDto } from './dto/response/sale-order-export-response.dto';
import { SaleOrderExportListResponse } from './dto/response/sale-order-export-list-response.dto';
import { SuggestCollectSaleOrderExportResponseDto } from './dto/response/suggest-collect-sale-order-export.response.dto';
import { GetOrderListRequest } from '@components/order/dto/request/get-order-list.request.dto';
import { mapSplitKeyInFormDataToJson } from '@utils/helper';
import { SuccessResponse } from '@utils/success.response.dto';
import { Response } from 'express';
import * as contentDisposition from 'content-disposition';
import { Public } from '@core/decorator/set-public.decorator';
import { GetListOpenTransactionRequestDto } from './dto/request/get-list-open-transaction.request.dto';
import { UpdateHeaderSaleOrderExportBodyDto } from './dto/request/update-header-sale-order-export.request';
import { UpdateHeaderEbsInSOERequest } from './dto/request/sync/update-header-ebs-in-poi.request.dto';
import { NATS_SALE } from '@config/nats.config';

@Controller('sale-order-exports')
export class SaleOrderExportController {
  constructor(
    @Inject('SaleOrderExportServiceInterface')
    private readonly saleOrderExportService: SaleOrderExportServiceInterface,
  ) {}

  /**
   * Get data sale order by id and warehouseId
   * @param request
   * @returns
   */
  // @MessagePattern('get_sale_order_export_warehouse_details')
  public async getSaleOrderExportDetails(
    @Body() payload: GetOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderExportService.getWarehouseDetails(
      request.id,
      request.warehouseId,
      request.type,
    );
  }

  /**
   * Get data sale order by id and warehouseId
   * @param request
   * @returns
   */
  @Get('/warehouses/items/details/:id')
  @ApiOperation({
    tags: ['Sales', 'Sale Order Exports', 'Warehouse'],
    summary: 'Get Sale Order Export Warehouse Detail',
    description: 'Danh sách Item lệnh mua theo đơn bán hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: SaleOrderExportWarehouseDetailResponseDto,
  })
  // @MessagePattern('get_sale_order_export_warehouse_detail')
  public async getSaleOrderExportDetail(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: GetOrderRequestBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderExportService.getWarehouseDetails(
      id,
      request.warehouseId,
      request.type,
    );
  }

  /**
   * Update actual quantity of sale order detail
   * @param request updateOrderDetailActualQuantityRequestDto
   * @returns
   */
  // @MessagePattern('update_sale_order_export_actual_quantity')
  public async updateActualQuantity(
    @Body() payload: UpdateOrderDetailActualQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderExportService.updateOrderDetailActualQuantity(
      request,
    );
  }

  @MessagePattern(`${NATS_SALE}.update_sale_order_export_confirm_quantity`)
  public async updateConfirmQuantity(
    @Body() payload: UpdateOrderDetailConfirmQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderExportService.updateOrderDetailConfirmQuantity(
      request,
    );
  }

  @MessagePattern(`${NATS_SALE}.update_sale_order_export_return_quantity`)
  public async updateReturnQuantity(
    @Body() payload: UpdateOrderDetailReturnQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderExportService.updateOrderDetailReturnQuantity(
      request,
    );
  }

  /**
   * Create new sale order
   * @param request CreateSaleOrderExportRequestDto
   * @returns
   */
  @PermissionCode(CREATE_SALE_ORDER_EXPORT_PERMISSION.code)
  @Post('/create')
  @ApiOperation({
    tags: ['Sales', 'Sale Order Export'],
    summary: 'Create Sale Order Export',
    description: 'Tạo lệnh xuất theo đơn bán hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: SaleOrderExportResponseDto,
  })
  // @MessagePattern('create_sale_order_export')
  public async create(
    @Body() payload: CreateSaleOrderExportBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    console.log('=== DEBUG CREATE SO ===');
    console.log(payload);
    console.log('=== END DEBUG CREATE SO ===');
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    const mappedObj = mapSplitKeyInFormDataToJson(request);
    return await this.saleOrderExportService.createSoExport({
      ...request,
      ...mappedObj,
      createdByUserId: request.userId,
    });
  }

  /**
   * Update sale order
   * @param request UpdateSaleOrderExportDto
   * @returns
   */
  @PermissionCode(UPDATE_SALE_ORDER_EXPORT_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Sales', 'Sale Order Export'],
    summary: 'Update Sale Order Export',
    description: 'Cập nhật lệnh mua theo đơn bán hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SaleOrderExportResponseDto,
  })
  // @MessagePattern('update_sale_order_export')
  public async update(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateSaleOrderExportBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    const mappedObj = mapSplitKeyInFormDataToJson(request);
    return await this.saleOrderExportService.updateSoExport({
      ...request,
      ...mappedObj,
      id,
    });
  }

  @PermissionCode(UPDATE_HEADER_SALE_ORDER_EXPORT_PERMISSION.code)
  @Put('/:id/update-header')
  @ApiOperation({
    tags: ['Sales', 'Sale Order Export'],
    summary: 'Update Header Sale Order Export',
    description: 'Cập nhật header lệnh mua theo đơn bán hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SaleOrderExportResponseDto,
  })
  public async updateHeader(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateHeaderSaleOrderExportBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    const mappedObj = mapSplitKeyInFormDataToJson(request);
    return await this.saleOrderExportService.updateHeader({
      ...request,
      ...mappedObj,
      id,
    });
  }

  /**
   * Get purchased order list
   * @param request GetSaleOrderExportListRequest
   * @returns
   */
  @PermissionCode(LIST_SALE_ORDER_EXPORT_PERMISSION.code)
  @Get('/list')
  @ApiOperation({
    tags: ['Sales', 'Sale Order Export'],
    summary: 'Get List Sale Order Export',
    description: 'Danh sách lệnh xuất theo đơn bán hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: SaleOrderExportListResponse,
  })
  // @MessagePattern('get_sale_order_export_list')
  public async getList(
    @Query() payload: GetSaleOrderExportListRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderExportService.getList(request);
  }

  @Get('/:id/warehouses/list')
  @ApiOperation({
    tags: ['Sales', 'Sale Order', 'Warehouse'],
    summary: 'Get Sale Order Warehouse List',
    description: 'Danh sách kho lệnh mua theo đơn bán hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: SaleOrderExportResponseDto,
  })
  // @MessagePattern('get_sale_order_export_warehouses')
  public async getProductionOrderWarehouse(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: GetOrderWarehouseQueryRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.saleOrderExportService.getListOrderWarehouse(request);
  }

  /**
   * Get sale order detail
   * @param request GetPurchasedOrderListRequest
   * @returns
   */
  @PermissionCode(DETAIL_SALE_ORDER_EXPORT_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Sales', 'Sale Order Export'],
    summary: 'Get Sale Order Export Detail',
    description: 'Chi tiết lệnh mua theo đơn bán hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: SaleOrderExportResponseDto,
  })
  // @MessagePattern('get_sale_order_export_detail')
  public async getDetail(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: GetOrderDetailQueryRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.saleOrderExportService.getDetail(request);
  }

  /**
   * Get sale order detail by warehouse
   * @param request GetPurchasedOrderListRequest
   * @returns
   */
  @Get('/:id/warehouses/:warehouseId')
  @ApiOperation({
    tags: ['Sales', 'Sale Order Exports', 'Warehouse'],
    summary: 'Get Sale Order Export Warehouse Detail',
    description: 'Danh sách Item lệnh mua theo đơn bán hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: SaleOrderExportWarehouseDetailResponseDto,
  })
  // @MessagePattern('get_sale_order_export_warehouse')
  public async getDetailByWarehouseId(
    @Param('id', new ParseIntPipe()) id,
    @Param('warehouseId', new ParseIntPipe()) warehouseId,
    @Query() payload: GetOrderDetailByWarehouseQueryDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    request.warehouseId = warehouseId;
    return await this.saleOrderExportService.getDetailByWarehouseId(request);
  }

  @PermissionCode(CANCEL_SYNC_SALE_ORDER_EXPORT_PERMISSION.code)
  @Put('/:id/cancel-sync')
  @ApiOperation({
    tags: ['Sales', 'Sale Order Export'],
    summary: 'Cancel sync Sale Sale Order Export',
    description: 'Hủy đồng bộ lệnh mua theo đơn bán hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  public async cancelSync(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: SetOrderStatusBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    request.createdByUserId = request.userId;
    return await this.saleOrderExportService.cancelSync(request);
  }

  @PermissionCode(RETURN_SALE_ORDER_EXPORT_PERMISSION.code)
  @Put('/:id/return')
  @ApiOperation({
    tags: ['Sales', 'Sale Order Export'],
    summary: 'Return Sale Sale Order Export',
    description: 'Trả lệnh mua theo đơn bán hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  public async return(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: SetOrderStatusBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    request.createdByUserId = request.userId;
    return await this.saleOrderExportService.return(request);
  }

  /**
   * Confirm sale order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @PermissionCode(CONFIRM_SALE_ORDER_EXPORT_PERMISSION.code)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Sales', 'Sale Order Export'],
    summary: 'Confirm Sale Sale Order Export',
    description: 'Confirm lệnh mua theo đơn bán hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SaleOrderExportResponseDto,
  })
  // @MessagePattern('confirm_sale_order_export')
  public async confirm(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: SetOrderStatusBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    request.createdByUserId = request.userId;
    return await this.saleOrderExportService.confirm(request);
  }

  /**
   * Confirm sale order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @PermissionCode(CONFIRM_SALE_ORDER_EXPORT_PERMISSION.code)
  @Put('/confirm/multiple')
  @ApiOperation({
    tags: ['Sales', 'Sale Order Export'],
    summary: 'Confirm multiple Sale Order Export',
    description: 'Confirm nhiều lệnh mua theo đơn bán hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SaleOrderExportResponseDto,
  })
  // @MessagePattern('confirm_sale_order_export_multiple')
  public async confirmMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.createdByUserId = request.userId;
    return await this.saleOrderExportService.confirmMultiple(request);
  }

  /**
   * Reject sale order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @PermissionCode(REJECT_SALE_ORDER_EXPORT_PERMISSION.code)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Sales', 'Sale Order Export'],
    summary: 'Reject Sale Sale Order Export',
    description: 'Reject lệnh mua theo đơn bán hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SaleOrderExportResponseDto,
  })
  // @MessagePattern('reject_sale_order_export')
  public async reject(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: SetOrderStatusBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.saleOrderExportService.reject(request);
  }

  /**
   * Reject sale order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @PermissionCode(REJECT_SALE_ORDER_EXPORT_PERMISSION.code)
  @Put('/reject/multiple')
  @ApiOperation({
    tags: ['Sales', 'Sale Order Export'],
    summary: 'Reject multiple Sale Order Export',
    description: 'Reject nhiều lệnh mua theo đơn bán hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SaleOrderExportResponseDto,
  })
  // @MessagePattern('reject_sale_order_export_multiple')
  public async rejectMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderExportService.rejectMultiple(request);
  }

  /**
   * Approve sale order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @Put('/:id/approve')
  @ApiOperation({
    tags: ['Sales', 'Sale Order Export'],
    summary: 'Approve Sale Order Export',
    description: 'Approve lệnh xuất theo đơn bán hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SaleOrderExportResponseDto,
  })
  // @MessagePattern('approve_sale_order_export')
  public async approve(
    @Param() payload: SetOrderStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.createdByUserId = request.userId;
    return await this.saleOrderExportService.approve(request);
  }

  @Get('/all')
  @ApiOperation({
    tags: ['Sales', 'Sales Order Export'],
    summary: 'Get List Sales Order Export',
    description: 'Danh sách lệnh xuất theo đơn bán',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: null,
  })
  // @MessagePattern('get_sale_order_exports')
  public async getSalesOrderExports(
    @Query() payload: GetAllSOExportRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderExportService.getSaleOrderExports(request);
  }

  @PermissionCode(DELETE_SALE_ORDER_EXPORT_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Sales', 'Sale Order Export'],
    summary: 'Remove Sale Order Export',
    description: 'Xoá lệnh xuất theo đơn bán hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  // @MessagePattern('delete_sale_order_export')
  public async delete(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: DeleteOrderQueryRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;
    return await this.saleOrderExportService.delete(request);
  }

  @PermissionCode(DELETE_SALE_ORDER_EXPORT_PERMISSION.code)
  @Delete('/multiple')
  @ApiOperation({
    tags: ['Sales', 'Sale Order Export'],
    summary: 'Remove multiple Sale Order Export',
    description: 'Xoá nhiều lệnh xuất theo đơn bán hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  // @MessagePattern('delete_sale_order_export_multiple')
  public async deleteMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderExportService.deleteMultiple(request);
  }

  @MessagePattern(`${NATS_SALE}.get_sale_order_export_by_ids`)
  public async getSaleOrderExportByIdsTcp(
    @Body() payload: GetListOrderByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderExportService.getListByIds(request);
  }

  // @MessagePattern('check_item_has_exist_on_sale_order_export')
  public async checkItemHasExistOnSaleOrderExport(
    @Body() payload: GetByItemIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderExportService.checkItemHasExistOnSaleOrderExport(
      request,
    );
  }

  // @MessagePattern('get_sale_order_export_by_warehouse')
  public async getSaleOrderExportByWarehouseItem(
    @Body() payload: GetOrderByWarehouseItemRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderExportService.getSaleOrderExportByWarehouse(
      request,
    );
  }

  @Put('/:id/warehouses/:warehouseId/items/:itemId/quality-controls/quantities')
  @ApiOperation({
    tags: ['Sales', 'Sales Order Export'],
    summary: 'Update quality controls quantity',
    description: 'Cập nhật số lượng Qc pass và reject',
  })
  @ApiParam({
    name: 'id',
    type: Number,
    example: 11,
    required: true,
    description: 'sale order export id',
  })
  @ApiParam({
    name: 'warehouseId',
    type: Number,
    example: 13,
    required: true,
    description: 'warehouse id',
  })
  @ApiParam({
    name: 'itemId',
    type: Number,
    example: 161,
    required: true,
    description: 'item id',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  // @MessagePattern('update_sale_order_export_warehouse_qc_quantity')
  public async updateSaleOrderExportWarehouseQcQuantity(
    @Param('id', new ParseIntPipe()) saleOrderExportId,
    @Param('warehouseId', new ParseIntPipe()) warehouseId,
    @Param('itemId', new ParseIntPipe()) itemId,
    @Body() payload: UpdateSaleOrderWarehouseQcQuantityBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.saleOrderExportId = saleOrderExportId;
    request.warehouseId = warehouseId;
    request.itemId = itemId;
    return await this.saleOrderExportService.updateSaleOrderExportWarehouseQcQuantity(
      request,
    );
  }

  @Get('/items/lots')
  @ApiOperation({
    tags: ['Sales'],
    summary: 'List Lot Number',
    description: 'Danh sách số lô theo sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListLotNumberResponseDto,
  })
  // @MessagePattern('get_list_lot_number_of_item_exp')
  public async getListLotNumberByItemId(
    @Query() payload: GetLotNumberByItemIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderExportService.getListLotNumberByItemId(
      request.itemIds,
    );
  }

  // @MessagePattern('get_list_item_id_by_qcstageid')
  public async getListItemIdByQcStageId(
    @Body() payload: GetListItemIdByQcStageIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderExportService.getListItemIdByQcStageId(request);
  }

  @Post('/:id/suggest/collected')
  @ApiOperation({
    tags: ['Sales', 'suggest', 'Collect'],
    summary: 'Suggest SO export collect',
    description: 'Suggest export item by order',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully',
    type: SuggestCollectSaleOrderExportResponseDto,
  })
  // @MessagePattern('suggest_collect_by_sale_order_export_id')
  public async suggestCollectedByOrderId(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: SuggestCollectedOrderExportRequestBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;
    return await this.saleOrderExportService.suggestCollectedByOrderId(request);
  }

  @Put('/:id/confirm/export')
  @ApiOperation({
    tags: ['Sales', 'Sales Order Export'],
    summary: 'Confirm Sales Order Export',
    description: 'Xác nhập xuất đơn hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: null,
  })
  // @MessagePattern('sale_order_exports_approve')
  public async saleOrderExportApprove(
    @Param() param: SaleOrderExportConfirmExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderExportService.confirmExported(request);
  }

  @MessagePattern(`${NATS_SALE}.update_sale_order_export_collected_quantity`)
  public async updateCollectedQuantity(
    @Body() payload: UpdateCollectedQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderExportService.updateCollectedQuantity(request);
  }

  // @MessagePattern('get_suggest_collected_by_so_export_id')
  public async getSuggestCollectedBySoExportId(
    @Body() payload: GetSuggestStoredBySoExportIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderExportService.getSuggestCollectedBySoExportId(
      request,
    );
  }

  @Post('/:id/suggest/return')
  @ApiOperation({
    tags: ['Sales', 'suggest', 'returns'],
    summary: 'Suggest SO export returns',
    description: 'Suggest export item by order',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully',
    type: SuggestCollectSaleOrderExportResponseDto,
  })
  // @MessagePattern('suggest_return_by_sale_order_export_id')
  public async suggestReturnsByOrderId(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: SuggestReturnsSaleOrderExportRequestBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;
    return await this.saleOrderExportService.suggestReturnsByOrderId(request);
  }

  @MessagePattern(`${NATS_SALE}.get_error_items_by_soexp`)
  public async getErrorItemsByOrder(
    payload: GetErrorItemByOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderExportService.getErrorItemsByOrder(request);
  }

  // TO DO: remove after refactor done
  @MessagePattern(`${NATS_SALE}.get_sale_order_export_warehouse`)
  public async getDetailByWarehouseIdTcp(
    @Body() payload: GetOrderDetailByWarehouseRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderExportService.getDetailByWarehouseId(request);
  }

  @MessagePattern(`${NATS_SALE}.update_sale_order_export_actual_quantity`)
  public async updateActualQuantityTcp(
    @Body() payload: UpdateOrderDetailActualQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderExportService.updateOrderDetailActualQuantity(
      request,
    );
  }

  @MessagePattern(`${NATS_SALE}.get_sale_order_export_warehouse_details`)
  public async getSaleOrderExportDetailsTcp(
    @Body() payload: GetOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderExportService.getWarehouseDetails(
      request.id,
      request.warehouseId,
      request.type,
    );
  }

  @MessagePattern(`${NATS_SALE}.check_item_has_exist_on_sale_order_export`)
  public async checkItemHasExistOnSaleOrderExportTcp(
    @Body() payload: GetByItemIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderExportService.checkItemHasExistOnSaleOrderExport(
      request,
    );
  }

  @MessagePattern(`${NATS_SALE}.get_sale_order_export_by_warehouse`)
  public async getSaleOrderExportByWarehouseItemTcp(
    @Body() payload: GetOrderByWarehouseItemRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderExportService.getSaleOrderExportByWarehouse(
      request,
    );
  }

  @MessagePattern(`${NATS_SALE}.get_list_item_id_by_qcstageid`)
  public async getListItemIdByQcStageIdTcp(
    @Body() payload: GetListItemIdByQcStageIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderExportService.getListItemIdByQcStageId(request);
  }

  @MessagePattern(`${NATS_SALE}.get_suggest_collected_by_so_export_id`)
  public async getSuggestCollectedBySoExportIdTcp(
    @Body() payload: GetSuggestStoredBySoExportIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderExportService.getSuggestCollectedBySoExportId(
      request,
    );
  }

  @MessagePattern(`${NATS_SALE}.get_sale_order_exports`)
  public async getSalesOrderExportsTcp(
    @Body() payload: GetAllSOExportRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderExportService.getSaleOrderExports(request);
  }

  @PermissionCode(DETAIL_SALE_ORDER_EXPORT_PERMISSION.code)
  @MessagePattern(`${NATS_SALE}.get_sale_order_export_detail`)
  public async getDetailTcp(
    @Body() payload: GetOrderDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderExportService.getDetail(request);
  }

  @PermissionCode(LIST_SALE_ORDER_EXPORT_PERMISSION.code)
  @MessagePattern(`${NATS_SALE}.get_sale_order_export_list`)
  public async getListTcp(@Body() payload: GetOrderListRequest): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderExportService.getList(request);
  }

  @MessagePattern(`${NATS_SALE}.get_sale_order_export_warehouses`)
  public async getProductionOrderWarehouseTcp(
    @Body() payload: GetOrderWarehouseRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderExportService.getListOrderWarehouse(request);
  }

  @MessagePattern(`${NATS_SALE}.update_sale_order_export_warehouse_qc_quantity`)
  public async updateSaleOrderExportWarehouseQcQuantityTcp(
    @Body() payload: UpdateSaleOrderWarehouseQcQuantityDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderExportService.updateSaleOrderExportWarehouseQcQuantity(
      request,
    );
  }

  @PermissionCode(EXPORT_SALE_ORDER_EXPORT_PERMISSION.code)
  @Get('/export-delivery-ticket/:id')
  @ApiOperation({
    tags: ['Sales', 'Sale Order Export'],
    summary: 'Export Delivery Ticket',
    description: 'Xuất phiếu giao hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: SuccessResponse,
  })
  public async exportWarehouseExportTicket(
    @Res({ passthrough: true }) res: Response,
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: GetOrderDetailQueryRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;

    const result = await this.saleOrderExportService.exportDeliveryTicket(
      request,
    );
    if (!result.nameFile) {
      return result;
    }
    res.header('Content-Disposition', contentDisposition(result.nameFile));
    res.header('Access-Control-Expose-Headers', '*');
    return result.result;
  }

  @Get('/export-soexport-ticket/:id')
  @ApiOperation({
    tags: ['Sales', 'Sale Order Export'],
    summary: 'Export soexport Ticket',
    description: 'Xuất phiếu xuất kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: SuccessResponse,
  })
  public async exportSoExportTicket(
    @Res({ passthrough: true }) res: Response,
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: GetOrderDetailQueryRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;

    const result = await this.saleOrderExportService.exportSoExportTicket(
      request,
    );
    if (!result.nameFile) {
      return result;
    }
    res.header('Content-Disposition', contentDisposition(result.nameFile));
    res.header('Access-Control-Expose-Headers', '*');
    return result.result;
  }

  @Get('/export-delivery-record/:id')
  @ApiOperation({
    tags: ['Sales', 'Sale Order Export'],
    summary: 'Export Delivery Record',
    description: 'Xuất biên bản bàn giao',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: SuccessResponse,
  })
  public async exportDeliveryRecord(
    @Res({ passthrough: true }) res: Response,
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: GetOrderDetailQueryRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;

    const result = await this.saleOrderExportService.exportDeliveryRecord(
      request,
    );
    if (!result.nameFile) {
      return result;
    }
    res.header('Content-Disposition', contentDisposition(result.nameFile));
    res.header('Access-Control-Expose-Headers', '*');
    return result.result;
  }

  // TODO: Bypass auth test sync EBS

  @MessagePattern(`${NATS_SALE}.get_list_sale_order_export_open_transaction`)
  public async getListOpenTransaction(
    @Body() body: GetListOpenTransactionRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderExportService.getListOpenTransaction(request);
  }

  @Public()
  @Post('update-header/ebs-in')
  @ApiOperation({
    tags: ['SYNC', 'EBS'],
  })
  @ApiResponse({
    status: 200,
  })
  public async updateHeaderEbsIn(
    @Body() body: UpdateHeaderEbsInSOERequest,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderExportService.updateHeaderEbsIn(request);
  }
}
