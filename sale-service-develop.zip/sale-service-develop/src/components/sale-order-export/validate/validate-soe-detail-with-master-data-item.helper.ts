import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { ValidateOrderDetailAbstract } from '@core/abstracts/validate-order-detail.abstract';
import { Inject, Injectable } from '@nestjs/common';
import { keyBy, isEmpty, uniq } from 'lodash';

@Injectable()
export class ValidateSoeDetailWithMasterDataItem extends ValidateOrderDetailAbstract {
  constructor(
    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,
  ) {
    super(itemService);
  }

  public async validateItems(items: any, id: number) {
    return super.validateItems(items, id);
  }

  protected async validateOrderDetailWithBaseCondition(
    items: any,
    id: number,
  ): Promise<any> {
    const itemIds = uniq(items.map((item) => item.id));
    const itemWarehouse =
      await this.itemService.getItemWarehouseByItemIdsAndWarehouseIds({
        itemIds,
        warehouseIds: [id],
      });

    if (isEmpty(itemWarehouse) || itemIds.length !== itemWarehouse?.length) {
      return {
        success: false,
        message: 'error.ITEM_IS_NOT_EXIST_IN_WAREHOUSE',
      };
    }

    const itemWarehouseByIds = keyBy(itemWarehouse, 'itemId');
    const invalidItems = items.filter(
      (item) => itemWarehouseByIds[item.id]?.itemQuantity < item.quantity,
    );
    if (!isEmpty(invalidItems)) {
      return {
        success: false,
        message: 'error.REQUEST_ITEM_INVALID',
        data: invalidItems,
      };
    }

    return {
      success: true,
    };
  }
}
