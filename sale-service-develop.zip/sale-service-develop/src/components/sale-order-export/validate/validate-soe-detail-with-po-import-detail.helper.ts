import { ItemServiceInterface } from "@components/item/interface/item.service.interface";
import { PurchasedOrderImportDetailRepositoryInterface } from "@components/purchased-order-import/interface/purchased-order-import-detail.repository.interface";
import { ValidateOrderDetailAbstract } from "@core/abstracts/validate-order-detail.abstract";
import { Inject, Injectable } from "@nestjs/common";
import { keyBy, isEmpty } from 'lodash';

@Injectable()
export class ValidateSoeDetailWithPOImportDetail extends ValidateOrderDetailAbstract {
  constructor(
    @Inject('PurchasedOrderImportDetailRepositoryInterface')
    protected readonly purchaseOrderImportDetailRepository: PurchasedOrderImportDetailRepositoryInterface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,
  ) {
    super(itemService);
  }

  public async validateItems(items: any, id: number) {
    return super.validateItems(items, id);
  }

  protected async validateOrderDetailWithBaseCondition(
    items: any,
    id: number
  ): Promise<any> {
    const poImportDetails = await this.purchaseOrderImportDetailRepository.findByCondition({
      purchasedOrderImportId: id
    });
    if (isEmpty(poImportDetails)) {
      return {
        success: false,
        message: 'error.PURCHASED_ORDER_IMPORT_NOT_FOUND',
      };
    }

    const poImportDetailsByItemIds = keyBy(poImportDetails, 'itemId');
    const invalidItems = items.filter(item => (
      !poImportDetailsByItemIds[item.id]
      || poImportDetailsByItemIds[item.id]?.quantity < item.quantity
    ));
    if (!isEmpty(invalidItems)) {
      return {
        success: false,
        message: 'error.REQUEST_ITEM_INVALID',
        data: invalidItems,
      };
    }

    return {
      success: true
    };
  }
}