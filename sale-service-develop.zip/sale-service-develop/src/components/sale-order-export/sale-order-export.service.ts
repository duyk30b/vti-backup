import { div, divBigNumber, mulBigNumber } from '@utils/common';
import {
  UpdateItemExportedWarehouseExportProposal,
  UpdateItemExportedWarehouseExportProposalRequestDto,
} from './../warehouse/dto/request/update-item-exported-warehouse-export-proposal.request.dto';
import { generatePaddingCode, searchLikeString } from '../../utils/helper';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { SetOrderStatusRequestDto } from '../order/dto/request/set-order-status-request.dto';
import {
  STATUS_TO_CONFIRM_ORDER_STATUS,
  STATUS_TO_APPROVE_ORDER_STATUS,
  STATUS_TO_DELETE_ORDER_STATUS,
  STATUS_TO_REJECT_ORDER_STATUS,
  OrderTypeEnum,
  OrderWarehouseActionTypeEnum,
  MAPPING_MASTER_DATA_BUSSINESS_TYPE,
  STATUS_CAN_UPDATE_HEADER_SOE,
  SYNC_STATUS_CAN_UPDATE_HEADER_SOE,
} from '@constant/order.constant';
import { WarehouseServiceInterface } from '../warehouse/interface/warehouse.service.interface';
import { OrderServiceAbstract } from '../order/interface/order.service.abstract';
import { CreateSaleOrderExportRequestDto } from './dto/request/create-sale-order-export-request.dto';
import { Inject, Injectable, Logger } from '@nestjs/common';
import { UpdateOrderDetailActualQuantityRequestDto } from '@components/order/dto/request/update-actual-quantity-order-detail.request.dto';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, In, ILike, Like } from 'typeorm';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { UpdateOrderDetailConfirmQuantityRequestDto } from '@components/order/dto/request/update-confirm-quantity-order-detail.request.dto';
import { plus } from '@utils/helper';
import { plainToInstance } from 'class-transformer';
import {
  values,
  map,
  uniq,
  isEmpty,
  isNull,
  filter,
  first,
  keyBy,
  flatMap,
  flatten,
  find,
  sumBy,
  has,
  groupBy,
  orderBy,
} from 'lodash';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { PagingResponse } from '@utils/paging.response';
import {
  OrderStatusEnum,
  ROLE,
  StatusSyncOrderToEbsEnum,
  STATUS_TO_QC_ORDER,
  STATUS_WITH_QUANTITY_WAREHOUSE_EXPORT_PROPOSAL,
  TypeBussinessAttributeEnum,
  typeTicket,
  WarehouseMovementTypeEnum,
} from '@constant/common';
import { GetOrderDetailRequestDto } from '@components/order/dto/request/get-order-detail.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { DeleteOrderRequestDto } from '@components/order/dto/request/delete-order.request.dto';
import { GetListOrderByIdsRequestDto } from '@components/order/dto/request/get-list-order-by-ids.request.dto';
import { GetByItemIdRequestDto } from '@components/purchased-order/dto/request/get-by-item-id.request.dto';
import { OrderUpdateConfirmedQuantityEvent } from '@components/order/events/order-update-confirmed-quantity.event';
import { OrderUpdateActualQuantityEvent } from '@components/order/events/order-update-actual-quantity.event';
import { GetOrderDetailByWarehouseRequestDto } from '@components/order/dto/request/get-order-detail-by-warehouse.request.dto';
import { GetOrderWarehouseRequest } from '@components/order/dto/request/get-order-warehouse.request.dto';
import { OrderWarehouseResponse } from '@components/order/dto/response/order-warehouse-response.dto';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { GetOrderByWarehouseItemRequestDto } from '@components/order/dto/request/get-order-by-warehouse-item.request.dto';
import { SaleOrderExportServiceInterface } from './interface/sale-order-export.service.interface';
import { SaleOrderExportRepositoryInterface } from './interface/sale-order-export.repository.interface';
import { SaleOrderExportWarehouseDetailRepositoryInterface } from './interface/sale-order-export-warehouse-detail.repository.interface';
import { SaleOrderExportDetailRepositoryInterface } from './interface/sale-order-export-detail.repository.interface';
import { SaleOrderExportResponseDto } from './dto/response/sale-order-export-response.dto';
import { SaleOrderExportWarehouseDetailResponseDto } from './dto/response/sale-order-export-warehouse-detail-response.dto';
import { GetSaleOrderExportListRequest } from './dto/request/get-sale-order-export-list-request.dto';
import { SaleOrderExportListResponse } from './dto/response/sale-order-export-list-response.dto';
import { SaleOrderExport } from '@entities/sale-order-export/sale-order-export.entity';
import { SaleOrderExportDetail } from '@entities/sale-order-export/sale-order-export-detail.entity';
import { SaleOrderExportWarehouseDetail } from '@entities/sale-order-export/sale-order-export-warehouse-detail.entity';
import { UpdateSaleOrderExportDto } from './dto/request/update-sale-order-export-request.dto';
import { SaleOrderRepositoryInterface } from '@components/sale-order/interface/sale-order.repository.interface';
import { SaleOrderDetailRepositoryInterface } from '@components/sale-order/interface/sale-order-detail.repository.interface';
import { GetAllSOExportRequest } from './dto/request/get-all-sale-order-export.request.dto';
import { UpdateSaleOrderWarehouseQcQuantityDto } from './dto/request/update-sale-order-warehouse-qc-quantity';
import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { CreateMoForQcRejectQuantity } from '@components/produce/dto/request/create-mo-for-qc-reject-quantity.request.dto';
import { PurchasedOrderImportWarehouseLotRepositoryInterface } from '@components/purchased-order-import/interface/purchased-order-import-warehouse-lot.repository.interface';
import { ProductionOrderWarehouseDetailRepositoryInterface } from '@components/production-order/interface/production-order-warehouse-detail.repository.interface';
import { LotNumberOfItemResponseDto } from '@components/import-order/dto/response/list-lot-number.response.dto';
import * as Moment from 'moment';
import {
  DELIVERY_TICKET_ITEMS,
  OrderType,
  EventSyncSoExportEnum,
  QC_STAGE_ID,
  SO_EXPORT_CODE_PREFIX,
  SO_EXPORT_TICKET_ITEMS,
  LOT_NUMBER_COLUMN,
  DELIVERY_RECORD_ITEMS,
} from './sale-order-export.contant';
import { PurchasedOrderWarehouseDetailRepositoryInterface } from '@components/purchased-order/interface/purchased-order-warehouse-detail.repository.interface';
import { ProductionOrderWarehouseLotRepositoryInterface } from '@components/production-order/interface/production-order-warehouse-lot.repository.interface';
import { SaleOrderExportWarehouseLotRepositoryInterface } from './interface/sale-order-warehouse-lot.repository.interface';
import { SaleOrderExportWarehouseLotEntity } from '@entities/sale-order-export/sale-order-export-warehouse-lot.entity';
import { GetListWarehouseExitsFloorRequestDto } from '@components/warehouse/dto/request/get-warehouse-exits-floor.request.dto';
import { stringFormat } from '@utils/object.util';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { DeleteMultipleWithUserIdDto } from '@core/dto/multiple/delete-multiple-with-user-id.dto';
import { SaleOrderExportConfirmExportRequestDto } from './dto/request/sale-order-export-confirm-export.request.dto';
import { UpdateCollectedQuantityRequestDto } from '@components/order/dto/request/update-collected-quantity.request.dto';
import { SuggestCollectedOrderExportRequestDto } from './dto/request/suggest-collected-order-export.request.dto';
import { SuggestExportItemToWarehouseShelfFloorRequestDto } from '@components/warehouse/dto/request/suggest-export-item-to-warehouse-shelf-floor.request.dto';
import { OrderUpdateCollectedQuantityEvent } from '@components/order/events/order-update-collected-quantity.event';
import { GetSuggestStoredBySoExportIdRequestDto } from './dto/request/get-suggest-stored-by-so-export-id.request.dto';
import { SuggestCollectSaleOrderExportResponseDto } from './dto/response/suggest-collect-sale-order-export.response.dto';
import { SuggestImportItemToWarehouseShelfFloorRequestDto } from '@components/warehouse/dto/request/suggest-import-item-to-warehouse-shelf-floor.request.dto';
import { UpdateOrderDetailReturnQuantityRequestDto } from '@components/order/dto/request/update-return-quantity-order-detail.request.dto';
import { OrderUpdateReturnQuantityEvent } from '@components/order/events/order-update-return-quantity.event';
import { ErrorItem } from '@components/order/dto/response/get-error-item-by-order.response.dto';
import { GetErrorItemByOrderRequestDto } from '@components/order/dto/request/get-error-item-by-order.request.dto';
import { getInnerJoinElements, minus, mul } from '@utils/common';
import { SaleOrder } from '@entities/sale-order/sale-order.entity';
import { SaleOrderResponseDto } from '@components/sale-order/dto/response/sale-order-response.dto';
import {
  BusinessTypeAttributeDefaultEnum,
  WarehouseByLotManagementEnum,
} from '@components/warehouse/warehouse.contant';
import { ValidateSoeDetailWithMasterDataItem } from './validate/validate-soe-detail-with-master-data-item.helper';
import { ValidateSoeDetailWithPOImportDetail } from './validate/validate-soe-detail-with-po-import-detail.helper';
import { ValidateSoeDetailWithWarehouseExportProposalDetail } from './validate/validate-soe-detail-with-warehouse-export-proposal-detail.helper';
import {
  CODE_DELIMITER,
  SOURCE_RULES,
} from '@components/source/source.constants';
import { SourceRepositoryInterface } from '@components/source/interface/sources.repository.interface';
import { ReasonRepositoryInterface } from '@components/reason/interface/reason.repository.interface';
import {
  CreateItemPlanningQuantitiesRequestDto,
  CreateItemPlanningQuantityRequestDto,
} from '@components/item/dto/request/create-item-planning-quantity.request.dto';
import { GetItemStockAvailableRequestDto } from '@components/item/dto/request/get-item-stock-available.request.dto';
import { ApproveWarehouseStockMovementByOrderRequestDto } from '@components/warehouse/dto/request/approve-warehouse-stock-movement-by-order.request.dto';
import { ConfigService } from '@config/config.service';
import {
  AlignmentType,
  Document,
  Packer,
  Paragraph,
  Table,
  TableCell,
  TableRow,
  TextRun,
  VerticalAlign,
  // LevelFormat,
  // convertInchesToTwip,
} from 'docx';
import {
  formatNumber,
  getProvince,
  LENGTH_ACCOUNT_SYNC_EBS,
  readDecimal,
  setHeight,
  setWidth,
  wordFileStyle,
} from 'src/common/word-common.styles';
import {
  FONT_NAME,
  TABLE_DELIVERY_SIGNATURE,
  WORD_FILE_CONFIG,
} from '@utils/constant';
import { GetAttributeDetailValuesRequestDto } from '@components/warehouse/dto/request/get-attribute-detail-values.request.dto';
import { SettingServiceInterface } from '@components/setting/interface/setting.service.interface';
import {
  UpdateItemRemainingWarehouseExportProposal,
  UpdateItemRemainingWarehouseExportProposalRequestDto,
} from '@components/warehouse/dto/request/update-item-planning-warehouse-export-proposal.request.dto';
// import { SyncDataServiceInterface } from '@components/sync-data/interface/sync-data.interface';
// import { EbsInSoExportRequestDto } from './dto/request/sync/ebs-in-so-export.request.dto';
// import { ExecuteSOEEbsRequest } from './dto/request/execute-soe-ebs.request.dto';
// import { WarehouseResponseDto } from '@components/warehouse/dto/response/warehouse.dto.response';
// import { WarehouseExportDto } from '@components/warehouse/dto/request/warehouse-export.dto';
// import { SuggestLocatorWithItemQuantityRequest } from '@components/item/dto/request/suggest-locator-with-item-quantity.request.dto';
// import { ItemStatusEnum } from '@components/item/item.constant';
// import { ReasonStatus } from '@components/reason/reason.constants';
// import { DepartmentReceiptStatusEnum } from '@components/user/user.contant';
import { GetListOpenTransactionRequestDto } from './dto/request/get-list-open-transaction.request.dto';
import { UpdateHeaderSaleOrderExportBodyDto } from './dto/request/update-header-sale-order-export.request';
import { UpdateHeaderEbsInSOERequest } from './dto/request/sync/update-header-ebs-in-poi.request.dto';
@Injectable()
export class SaleOrderExportService
  extends OrderServiceAbstract
  implements SaleOrderExportServiceInterface
{
  private logger = new Logger(SaleOrderExportService.name);
  constructor(
    @Inject('ConfigServiceInterface')
    private configService: ConfigService,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,

    @Inject('ProduceServiceInterface')
    protected readonly produceService: ProduceServiceInterface,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('SaleOrderRepositoryInterface')
    private readonly saleOrderRepository: SaleOrderRepositoryInterface,

    @Inject('SaleOrderDetailRepositoryInterface')
    private readonly saleOrderDetailRepository: SaleOrderDetailRepositoryInterface,

    @Inject('PurchasedOrderImportWarehouseLotRepositoryInterface')
    private readonly purchasedOrderImportWarehouseLotRepository: PurchasedOrderImportWarehouseLotRepositoryInterface,

    @Inject('SaleOrderExportRepositoryInterface')
    private readonly saleOrderExportRepository: SaleOrderExportRepositoryInterface,

    @Inject('ProductionOrderWarehouseDetailRepositoryInterface')
    private readonly productionOrderWarehouseDetailRepository: ProductionOrderWarehouseDetailRepositoryInterface,

    @Inject('SaleOrderExportWarehouseDetailRepositoryInterface')
    private readonly saleOrderExportWarehouseDetailRepository: SaleOrderExportWarehouseDetailRepositoryInterface,

    @Inject('SaleOrderExportDetailRepositoryInterface')
    private readonly saleOrderExportDetailRepository: SaleOrderExportDetailRepositoryInterface,

    @Inject('SaleOrderExportWarehouseLotRepositoryInterface')
    private readonly saleOrderExportWarehouseLotRepository: SaleOrderExportWarehouseLotRepositoryInterface,

    @Inject('ProductionOrderWarehouseLotRepositoryInterface')
    private readonly productionOrderWarehouseLotRepository: ProductionOrderWarehouseLotRepositoryInterface,

    @Inject('PurchasedOrderWarehouseDetailRepositoryInterface')
    private readonly purchasedOrderWarehouseDetailRepository: PurchasedOrderWarehouseDetailRepositoryInterface,

    @Inject('ValidateSoeDetailWithMasterDataItem')
    private readonly validateSoeDetailWithMasterDataItem: ValidateSoeDetailWithMasterDataItem,

    @Inject('ValidateSoeDetailWithPOImportDetail')
    private readonly validateSoeDetailWithPOImportDetail: ValidateSoeDetailWithPOImportDetail,

    @Inject('ValidateSoeDetailWithWarehouseExportProposalDetail')
    private readonly validateSoeDetailWithWarehouseExportProposalDetail: ValidateSoeDetailWithWarehouseExportProposalDetail,

    @Inject('SourceRepositoryInterface')
    protected readonly sourceRepository: SourceRepositoryInterface,

    @Inject('ReasonRepositoryInterface')
    protected readonly reasonRepository: ReasonRepositoryInterface,

    @Inject('SettingServiceInterface')
    private readonly settingService: SettingServiceInterface,

    // @Inject('SyncDataServiceInterface')
    // private readonly syncDataService: SyncDataServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly eventEmitter: EventEmitter2,

    private readonly i18n: I18nRequestScopeService,
  ) {
    super(itemService, warehouseService, userService);
  }

  async getListOrderWarehouse(request: GetOrderWarehouseRequest): Promise<any> {
    const { user, keyword } = request;
    const userWarehouses = await this.userService.getUserWarehousesById(
      user.id,
    );
    let warehouseIds = [];
    if (!isEmpty(keyword)) {
      warehouseIds = filter(
        userWarehouses,
        (warehouse) =>
          searchLikeString(warehouse.name, keyword) ||
          searchLikeString(warehouse.code, keyword),
      ).map((w) => w.id);
    } else {
      warehouseIds = userWarehouses.map((e) => e.id);
    }

    const data =
      await this.saleOrderExportWarehouseDetailRepository.getListOrderWarehouse(
        request,
        warehouseIds,
      );

    const requestWarehouseExistFloor =
      new GetListWarehouseExitsFloorRequestDto();
    requestWarehouseExistFloor.sort = request.sort;
    requestWarehouseExistFloor.limit = request.limit;
    requestWarehouseExistFloor.page = request.page;
    requestWarehouseExistFloor.filter = [
      {
        column: 'ids',
        text: map(data, 'warehouseId').join(','),
      },
      {
        column: 'itemIds',
        text: '',
      },
    ];
    const warehousesExistFloor =
      await this.warehouseService.getListWarehouseExistFloor(
        requestWarehouseExistFloor,
      );

    const normalizeWarehouses = {};
    userWarehouses.forEach((warehouse) => {
      normalizeWarehouses[warehouse.id] = warehouse;
    });

    const importOrderWarehouseDetailData = {};
    data.forEach((item) => {
      importOrderWarehouseDetailData[item.id] = item;
    });

    //get_factory_by_ids
    let dataMaping = warehousesExistFloor.items.map((e) => ({
      warehouseId: e.id,
      warehouseName: normalizeWarehouses[e.id]?.name,
      warehouseCode: normalizeWarehouses[e.id]?.code,
      items: importOrderWarehouseDetailData[e.warehouseId]?.items,
      factoryId: normalizeWarehouses[e.id]?.factoryId,
    }));
    const factoriesNameData = await this.userService.getFactories(
      dataMaping.map((e) => e.factoryId),
    );

    dataMaping = dataMaping.map((e) => {
      const factory = factoriesNameData.find(
        (e2) => e2.factoryId === e.factoryId,
      );
      return {
        ...e,
        factoryName: factory?.factoryName,
      };
    });

    const dataReturn = plainToInstance(OrderWarehouseResponse, dataMaping, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: warehousesExistFloor.meta,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async getListByIds(payload: GetListOrderByIdsRequestDto): Promise<any> {
    const { ids, withDetail } = payload;
    const data = await this.saleOrderExportRepository.getListByIds(
      ids,
      withDetail,
    );

    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async delete(payload: DeleteOrderRequestDto): Promise<any> {
    const { id } = payload;
    let response, message;
    let code = ResponseCodeEnum.SUCCESS;
    const saleOrderExport =
      await this.saleOrderExportRepository.findOneWithRelations({
        where: { id },
        relations: [
          'saleOrderExportDetails',
          'saleOrderExportWarehouseDetails',
          'saleOrderExportWarehouseLots',
        ],
      });
    if (!saleOrderExport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_DELETE_ORDER_STATUS.includes(saleOrderExport.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    const saleOrder = await this.saleOrderRepository.findOneWithRelations({
      where: { id: saleOrderExport.saleOrderId },
      relations: ['saleOrderDetails'],
    });

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      saleOrder.deletedAt = new Date();
      saleOrder.deletedBy = payload.userId;
      await queryRunner.manager.save(saleOrder);

      saleOrderExport.deletedAt = new Date();
      saleOrderExport.deletedBy = payload.userId;
      await queryRunner.manager.save(saleOrderExport);

      const saleOrderDetailEntities = saleOrder.saleOrderDetails.map(
        (order) => {
          order.deletedAt = new Date();
          order.deletedBy = payload.userId;
          return order;
        },
      );
      await queryRunner.manager.save(saleOrderDetailEntities);

      const saleOrderExportDetailEntities = saleOrder.saleOrderDetails.map(
        (order) => {
          order.deletedAt = new Date();
          order.deletedBy = payload.userId;
          return order;
        },
      );
      await queryRunner.manager.save(saleOrderExportDetailEntities);

      const saleOrderExportWarehouseDetailEntities =
        saleOrder.saleOrderDetails.map((order) => {
          order.deletedAt = new Date();
          order.deletedBy = payload.userId;
          return order;
        });
      await queryRunner.manager.save(saleOrderExportWarehouseDetailEntities);

      const saleOrderExportWarehouseLotEntities =
        saleOrder.saleOrderDetails.map((order) => {
          order.deletedAt = new Date();
          order.deletedBy = payload.userId;
          return order;
        });
      await queryRunner.manager.save(saleOrderExportWarehouseLotEntities);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      message = error;
    }

    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(code)
      .withData(response)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const saleOrderExports =
      await this.saleOrderExportRepository.findByCondition({
        id: In(ids),
      });

    const saleOrderExportIds = saleOrderExports.map(
      (saleOrderExport) => saleOrderExport.id,
    );
    if (saleOrderExports.length !== ids.length) {
      ids.forEach((id) => {
        if (!saleOrderExportIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < saleOrderExports.length; i++) {
      const saleOrderExport = saleOrderExports[i];
      if (!STATUS_TO_DELETE_ORDER_STATUS.includes(saleOrderExport.status))
        failIdsList.push(saleOrderExport.id);
    }

    const validIds = saleOrderExports
      .filter((saleOrderExport) => !failIdsList.includes(saleOrderExport.id))
      .map((saleOrderExport) => saleOrderExport.id);

    const queryRunner = await this.connection.createQueryRunner();
    try {
      if (!isEmpty(validIds)) {
        await queryRunner.startTransaction();
        await queryRunner.manager.delete(SaleOrderExportWarehouseLotEntity, {
          saleOrderExportId: In(validIds),
        });
        await queryRunner.manager.delete(SaleOrderExportDetail, {
          saleOrderExportId: In(validIds),
        });
        await queryRunner.manager.delete(SaleOrderExportWarehouseDetail, {
          saleOrderExportId: In(validIds),
        });
        await queryRunner.manager.delete(SaleOrderExport, {
          id: In(validIds),
        });
        await queryRunner.commitTransaction();
      }
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    await queryRunner.release();
    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  /**
   * Get general sale order detail
   */
  async getDetail(payload: GetOrderDetailRequestDto): Promise<any> {
    const { id } = payload;
    const saleOrderExport = await this.saleOrderExportRepository.getDetail(id);
    if (!saleOrderExport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const itemIds = map(saleOrderExport.saleOrderExportDetails, 'itemId');
    const warehouseIds = uniq(
      map(saleOrderExport.saleOrderExportWarehouseLots, 'warehouseId'),
    );

    const itemLots = saleOrderExport.saleOrderExportWarehouseLots.map(
      (itemLot) => {
        return {
          itemId: itemLot.itemId,
          lotNumber: itemLot.lotNumber,
          warehouseId: itemLot.warehouseId,
        };
      },
    );

    const userIds = uniq([
      saleOrderExport.createdByUserId,
      saleOrderExport.updatedBy,
      saleOrderExport.approvedBy,
    ]);
    const {
      items,
      warehouses,
      users,
      businessType,
      departmentReceipt,
      itemStockWarehousePrices,
    } = await this.getSOExpExtraInfo(
      saleOrderExport.id,
      itemIds,
      warehouseIds,
      userIds,
      saleOrderExport.businessTypeId,
      saleOrderExport.departmentReceiptId,
      itemLots,
    );
    const itemStockWarehousePriceMap = keyBy(
      itemStockWarehousePrices,
      (item) => `${item.itemId}-${item.lotNumber || ''}-${item.warehouseId}`,
    );

    const normalizeItems = {};
    const normalizeWarehouses = {};
    const normalizeUsers = {};
    const normalizeQcCriterias = {};
    items.forEach((item) => {
      normalizeItems[item.itemId] = item;
    });
    warehouses.forEach((warehouse) => {
      normalizeWarehouses[warehouse.id] = warehouse;
    });
    users.forEach((user) => {
      normalizeUsers[user.id] = user;
    });
    const companyIds = [saleOrderExport.companyId];
    const companys = await this.userService.getCompanies(companyIds, true);
    saleOrderExport.createdByUser =
      normalizeUsers[saleOrderExport.createdByUserId];
    saleOrderExport.updatedBy = normalizeUsers[saleOrderExport.updatedBy];
    saleOrderExport.approvedByUser = normalizeUsers[saleOrderExport.approvedBy];
    saleOrderExport.businessType = businessType;
    saleOrderExport.attributes = businessType.bussinessTypeAttributes;
    saleOrderExport.company = companys[saleOrderExport.companyId];
    saleOrderExport.departmentReceipt = departmentReceipt;
    saleOrderExport.saleOrderExportDetails =
      saleOrderExport.saleOrderExportDetails.map((saleOrderExportDetail) => ({
        ...saleOrderExportDetail,
        item: normalizeItems[saleOrderExportDetail.itemId]
          ? normalizeItems[saleOrderExportDetail.itemId]
          : {},
      }));

    const sourceIds = flatten(
      items.map((item) => item.itemWarehouseSources.map((iws) => iws.sourceId)),
    );
    const sources = await this.sourceRepository.findByCondition({
      id: In(sourceIds),
    });
    const itemStockAvailable =
      await this.itemService.getItemStockAvailableByConditions({
        order: {
          orderId: id,
          orderType: OrderType.Export,
        },
        items: itemLots,
      });
    const itemStockAvailableByItemId = groupBy(itemStockAvailable, 'itemId');
    const sourceByIds = keyBy(
      sources.map((source) => {
        const companyCode = generatePaddingCode(
          source?.companyId,
          SOURCE_RULES.COMPANY_CODE.MAX_LENGTH,
        );
        const accountIdentifier = [
          companyCode,
          source?.branchCode,
          source?.costCenterCode,
          source?.accountant,
          source?.produceTypeCode,
          source?.productCode,
          source?.factorialCode,
          source?.internalDepartmentCode,
          source?.departmentBackupCode,
          source?.EVNBackupCode,
        ].join(CODE_DELIMITER);
        return {
          ...source,
          accountIdentifier,
        };
      }),
      'id',
    );

    const isCompleteSyncEbsIn =
      saleOrderExport.syncStatus === StatusSyncOrderToEbsEnum.COMPLETED;

    saleOrderExport.saleOrderExportWarehouseLots =
      saleOrderExport.saleOrderExportWarehouseLots.map(
        (saleOrderExportWarehouseLot) => {
          const key = `${saleOrderExportWarehouseLot.itemId}-${
            saleOrderExportWarehouseLot.lotNumber || ''
          }-${saleOrderExportWarehouseLot.warehouseId}`;
          const price = isCompleteSyncEbsIn
            ? divBigNumber(
                saleOrderExportWarehouseLot.amount,
                saleOrderExportWarehouseLot.actualQuantity || 1,
              )
            : divBigNumber(
                +itemStockWarehousePriceMap[key]?.totalAmount
                  ? itemStockWarehousePriceMap[key]?.totalAmount
                  : saleOrderExportWarehouseLot.amount || 0,
                +itemStockWarehousePriceMap[key]?.totalAmount
                  ? itemStockWarehousePriceMap[key]?.quantity
                  : saleOrderExportWarehouseLot.actualQuantity || 1,
              );
          return {
            ...saleOrderExportWarehouseLot,
            price: price,
            amount: isCompleteSyncEbsIn
              ? saleOrderExportWarehouseLot.amount
              : mulBigNumber(price, saleOrderExportWarehouseLot.actualQuantity),
            item: {
              ...normalizeItems[saleOrderExportWarehouseLot.itemId],
              itemWarehouseSources: normalizeItems[
                saleOrderExportWarehouseLot.itemId
              ]?.itemWarehouseSources?.map((iws) => ({
                ...iws,
                ...sourceByIds[iws.sourceId],
              })),
            },
            warehouse: normalizeWarehouses[
              saleOrderExportWarehouseLot.warehouseId
            ]
              ? normalizeWarehouses[saleOrderExportWarehouseLot.warehouseId]
              : {},
          };
        },
      );

    saleOrderExport.saleOrderExportWarehouseDetails =
      saleOrderExport.saleOrderExportWarehouseDetails.map(
        (saleOrderExportWarehouseDetail) => {
          const saleOrderExportWarehouseLots =
            saleOrderExport.saleOrderExportWarehouseLots.find(
              (data) =>
                data.saleOrderExportWarehouseDetailId ===
                saleOrderExportWarehouseDetail.id,
            );
          let needQcRemainingQuantity = null;
          if (saleOrderExportWarehouseDetail.qcCheck) {
            needQcRemainingQuantity =
              (saleOrderExportWarehouseDetail?.collectedQuantity || 0) -
              (saleOrderExportWarehouseDetail?.qcPassQuantity || 0) -
              (saleOrderExportWarehouseDetail?.qcRejectQuantity || 0);
          }
          return {
            ...saleOrderExportWarehouseDetail,
            item: {
              ...normalizeItems[saleOrderExportWarehouseDetail.itemId],
              itemWarehouseSources: normalizeItems[
                saleOrderExportWarehouseDetail.itemId
              ]?.itemWarehouseSources?.map((iws) => ({
                ...iws,
                ...sourceByIds[iws.sourceId],
              })),
            },
            warehouse: normalizeWarehouses[
              saleOrderExportWarehouseDetail.warehouseId
            ]
              ? normalizeWarehouses[saleOrderExportWarehouseDetail.warehouseId]
              : {},
            qcCriteria: normalizeQcCriterias[
              saleOrderExportWarehouseDetail.itemId
            ]
              ? normalizeQcCriterias[saleOrderExportWarehouseDetail.itemId]
              : {},
            lots: saleOrderExportWarehouseLots?.lotNumber,
            needQcRemainingQuantity,
          };
        },
      );

    const firstWarehouseId = first(
      map(saleOrderExport.warehouseIds, 'warehouseId'),
    );

    const soExportWarehouseDetailsByFirstWarehouseId =
      saleOrderExport.saleOrderExportWarehouseDetails.filter(
        (item) => item.warehouseId === firstWarehouseId,
      );
    const soExportDetailsByFirstWarehouseId =
      saleOrderExport.saleOrderExportDetails.filter((item) =>
        soExportWarehouseDetailsByFirstWarehouseId.some(
          (warehoueDetail) => warehoueDetail.itemId === item.itemId,
        ),
      );

    saleOrderExport.warehouse = normalizeWarehouses[firstWarehouseId] || {};

    const itemsRespone = {};

    let attributeDetailValues: any = {};
    if (!isEmpty(saleOrderExport.attributes)) {
      const attributeGroup = groupBy(saleOrderExport.attributes, 'tableName');
      const payload = new GetAttributeDetailValuesRequestDto();
      const attributeKeys = Object.keys(attributeGroup).filter(
        (el) => !el.match('null'),
      );
      payload.filter = attributeKeys.map((key) => {
        return {
          tableName: key,
          id: map(attributeGroup[key], 'value').join(','),
        };
      });
      attributeDetailValues =
        await this.warehouseService?.getAttributeDetailValuesTcp(payload);
    }
    let serializeWarehouseExportProposal = {} as any;
    let warehouseExportProposal = {} as any;
    if (
      !isEmpty(attributeDetailValues) &&
      !isEmpty(attributeDetailValues?.warehouse_export_proposals)
    ) {
      warehouseExportProposal =
        await this.warehouseService.getWarehouseExportProposalDetail(
          attributeDetailValues?.warehouse_export_proposals[0]?.id,
        );
      const warehouseExportProposalDetailChilds = map(
        warehouseExportProposal.items,
        'childrens',
      );
      serializeWarehouseExportProposal = keyBy(
        flatMap(warehouseExportProposalDetailChilds),
        (p) => `${p.itemId}-${p.warehouseExportId}-${p.lotNumber}`,
      );
    }
    const itemsSaleOrderExportWarehouseLotsSerialize = groupBy(
      saleOrderExport.saleOrderExportWarehouseLots,
      'itemId',
    );
    const itemsSaleOrderDetailSerialize = keyBy(
      saleOrderExport.saleOrderExportDetails,
      'itemId',
    );
    saleOrderExport.saleOrderExportDetails.forEach((saleOrderExportDetail) => {
      const itemId = saleOrderExportDetail.itemId;
      saleOrderExport.saleOrderExportWarehouseLots.forEach(
        (saleOrderExportWarehouse) => {
          const keySaleOrderExport = `${saleOrderExportDetail.itemId}-${saleOrderExportWarehouse.warehouseId}-${saleOrderExportWarehouse?.lotNumber}`;
          let warehouseExportProposalQuantity;
          if (saleOrderExport.status === OrderStatusEnum.Pending) {
            warehouseExportProposalQuantity =
              serializeWarehouseExportProposal[keySaleOrderExport]
                ?.requestedQuantity;
          } else if (
            STATUS_WITH_QUANTITY_WAREHOUSE_EXPORT_PROPOSAL.includes(
              saleOrderExport.status,
            )
          ) {
            warehouseExportProposalQuantity =
              serializeWarehouseExportProposal[keySaleOrderExport]
                ?.exportedQuantity;
          }
          if (!has(itemsRespone, itemId)) {
            itemsRespone[itemId] = {
              id: itemsSaleOrderDetailSerialize[itemId].itemId,
              code: normalizeItems[itemId]?.code,
              name: normalizeItems[itemId]?.name,
              itemUnit: normalizeItems[itemId]?.itemUnit,
              requestedQuantityWarehouseExportProposal:
                warehouseExportProposalQuantity
                  ? warehouseExportProposalQuantity
                  : 0,
              quantity: itemsSaleOrderDetailSerialize[itemId].quantity,
              debitAccount: itemsSaleOrderDetailSerialize[itemId].debitAccount,
              creditAccount:
                itemsSaleOrderDetailSerialize[itemId].creditAccount,
              actualQuantity:
                itemsSaleOrderDetailSerialize[itemId].actualQuantity,
              returnedQuantity:
                itemsSaleOrderDetailSerialize[itemId].returnedQuantity,
              confirmedQuantity:
                itemsSaleOrderDetailSerialize[itemId].confirmedQuantity,
              exportableQuantity: has(
                serializeWarehouseExportProposal,
                keySaleOrderExport,
              )
                ? serializeWarehouseExportProposal[keySaleOrderExport]
                    ?.exportableQuantity || 0
                : itemStockAvailableByItemId[
                    saleOrderExportDetail.itemId
                  ]?.reduce((prev, cur) => prev + Number(cur.quantity), 0),
              item: {
                ...normalizeItems[itemsSaleOrderDetailSerialize[itemId].itemId],
                itemWarehouseSources: normalizeItems[
                  itemsSaleOrderDetailSerialize[itemId].itemId
                ]?.itemWarehouseSources?.map((iws) => ({
                  ...iws,
                  ...sourceByIds[iws.sourceId],
                })),
              },
              lots: [],
            };
          }
          itemsRespone[itemId].lots.push(
            ...values(itemsSaleOrderExportWarehouseLotsSerialize[itemId]),
          );

          saleOrderExportWarehouse.requestedQuantityWarehouseExportProposal =
            warehouseExportProposalQuantity
              ? warehouseExportProposalQuantity
              : 0;

          saleOrderExportWarehouse.exportableQuantity = has(
            serializeWarehouseExportProposal,
            keySaleOrderExport,
          )
            ? serializeWarehouseExportProposal[keySaleOrderExport]
                ?.exportableQuantity || 0
            : itemStockAvailableByItemId[saleOrderExportDetail.itemId]?.reduce(
                (prev, cur) => prev + Number(cur.quantity),
                0,
              );

          saleOrderExportWarehouse.debitAccount =
            saleOrderExportWarehouse.debitAccount ||
            itemsSaleOrderDetailSerialize[itemId].debitAccount;
          saleOrderExportWarehouse.creditAccount =
            saleOrderExportWarehouse.creditAccount ||
            itemsSaleOrderDetailSerialize[itemId].creditAccount;
        },
      );
    });
    let transactionDate = '';
    if (saleOrderExport.status == OrderStatusEnum.Completed)
      transactionDate = saleOrderExport.approvedAt;
    const order = {
      transactionDate: transactionDate,
      receiptDate: saleOrderExport.receiptDate,
    };
    const dataReturn = plainToInstance(
      SaleOrderExportResponseDto,
      {
        ...saleOrderExport,
        user: normalizeUsers[saleOrderExport.createdByUserId],
        order,
        type: OrderWarehouseActionTypeEnum.EXPORT,
        warehouseId: firstWarehouseId,
        saleOrderExportWarehouseLots: orderBy(
          saleOrderExport.saleOrderExportWarehouseLots,
          ['itemId', 'lotNumber', 'quantity'],
          ['asc', 'asc', 'asc'],
        ),
        saleOrderExportWarehouseDetails:
          soExportWarehouseDetailsByFirstWarehouseId,
        saleOrderExportDetails: soExportDetailsByFirstWarehouseId.map(
          (soExpItem) => ({
            ...soExpItem,
            item: {
              ...soExpItem.item,
              itemWarehouseSources: normalizeItems[
                soExpItem.itemId
              ]?.itemWarehouseSources?.map((iws) => ({
                ...iws,
                ...sourceByIds[iws.sourceId],
              })),
            },
          }),
        ),
        itemsSync: values(itemsRespone),
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getDetailSoSync(payload: GetOrderDetailRequestDto): Promise<any> {
    const { id } = payload;
    const saleOrderExport = await this.saleOrderExportRepository.getDetail(id);
    if (!saleOrderExport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    return new ResponseBuilder(saleOrderExport)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'));
  }
  /**
   * Get Sale Order Detail By Warehouse
   */
  async getDetailByWarehouseId(
    payload: GetOrderDetailByWarehouseRequestDto,
  ): Promise<any> {
    const { id, warehouseId, user, orderType, withOrderDefault } = payload;
    const isWarehouseOfUser = await this.validateWarehouseIsOfUser(
      user.id,
      warehouseId,
    );
    if (!isWarehouseOfUser) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const saleOrderExport =
      await this.saleOrderExportRepository.getDetailByWarehouseId(
        id,
        [warehouseId],
        null,
        orderType,
        withOrderDefault,
      );
    if (!saleOrderExport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const itemIds = map(saleOrderExport.items, 'id');
    const userIds = uniq([
      saleOrderExport.createdByUserId,
      saleOrderExport.confirmerId,
      saleOrderExport.approverId,
    ]).filter((id) => !isNull(id));

    const { items, warehouses, users } = await super.getOrderExtraInfo(
      itemIds,
      [warehouseId],
      userIds,
    );
    const normalizeItems = {};
    const normalizeUsers = {};
    const normalizeWarehouses = {};

    items.forEach((item) => {
      normalizeItems[item.itemId] = item;
    });

    warehouses.forEach((warehouse) => {
      normalizeWarehouses[warehouse.id] = warehouse;
    });

    users.forEach((user) => {
      normalizeUsers[user.id] = user;
    });

    saleOrderExport.createdByUser =
      normalizeUsers[saleOrderExport.createdByUserId];
    saleOrderExport.approver = normalizeUsers[saleOrderExport.approverId];
    saleOrderExport.confirmer = normalizeUsers[saleOrderExport.confirmerId];
    saleOrderExport.warehouse = normalizeWarehouses[warehouseId];

    saleOrderExport.items = saleOrderExport.items.map((item) => ({
      ...normalizeItems[item.id],
      ...item,
    }));

    saleOrderExport.type = OrderWarehouseActionTypeEnum.EXPORT;

    const dataReturn = plainToInstance(
      SaleOrderExportWarehouseDetailResponseDto,
      saleOrderExport,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(payload: GetSaleOrderExportListRequest): Promise<any> {
    const { page, user, sort } = payload;
    if (!payload.filter) payload.filter = [];
    const userWarehouses = await this.userService.getUserWarehousesById(
      user.id,
    );

    if (isEmpty(userWarehouses)) {
      return new ResponseBuilder<PagingResponse>({
        items: [],
        meta: { total: 0, page: 1 },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    const filterWarehouseId = payload.filter.find(
      (filter) => filter.column === 'warehouseId',
    );

    let warehouseIds = map(
      userWarehouses,
      (userWarehouse) => +userWarehouse.id,
    );
    if (filterWarehouseId) {
      warehouseIds = getInnerJoinElements(
        warehouseIds,
        filterWarehouseId.text.split(',').map((warehouseId) => +warehouseId),
      );
      if (isEmpty(warehouseIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: payload.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
      }
    }

    payload.filter.push({
      column: 'warehouseId',
      text: warehouseIds.join(','),
    });

    const [data, count] = await this.saleOrderExportRepository.getList(payload);
    const warehouseExportIds = data.map((order) => order.warehouseId);
    const businessTypeIds = data.map((order) => order.businessTypeId);
    const departmentReceiptIds = data.map((order) => order.departmentReceiptId);
    const userIds = data.map((order) => order.createdBy);

    const [warehousesExport, businessTypeByIds, userByIds] = await Promise.all([
      this.warehouseService.getWarehouses(warehouseExportIds),
      this.warehouseService.getBusinessTypeByIds(businessTypeIds, true),
      this.userService.getUsers(userIds),
    ]);

    const userByIdsMap = keyBy(userByIds, 'id');
    const warehouseExportByIds = keyBy(warehousesExport, 'id');
    const departmentReceiptByIds =
      await this.userService.getDepartmentReceiptByIds(
        departmentReceiptIds,
        true,
      );
    const result =
      data.map((soExport) => ({
        ...soExport,
        warehouseId: warehouseExportByIds[soExport.warehouseId],
        businessType: businessTypeByIds[soExport.businessTypeId],
        departmentReceipt: departmentReceiptByIds[soExport.departmentReceiptId],
        user: userByIdsMap[soExport.createdBy],
      })) || [];
    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const sort = item.order === 'DESC' ? 1 : -1;
        switch (item.column) {
          case 'warehouseName':
            result.sort((a, b) => {
              const nameA = a.warehouseId.name,
                nameB = b.warehouseId.name;
              if (nameA < nameB) return sort;
              if (nameA > nameB) return -sort;
              return 0;
            });
            break;
          case 'departmentReceiptName':
            result.sort((a, b) => {
              const nameA = a.departmentReceipt.name,
                nameB = b.departmentReceipt.name;
              if (nameA < nameB) return sort;
              if (nameA > nameB) return -sort;
              return 0;
            });
            break;
          case 'businessTypeName':
            result.sort((a, b) => {
              const nameA = a.businessType.name,
                nameB = b.businessType.name;
              if (nameA < nameB) return sort;
              if (nameA > nameB) return -sort;
              return 0;
            });
            break;
          default:
            break;
        }
      });
    }
    const dataReturn = plainToInstance(SaleOrderExportListResponse, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private getBaseConditionForSaleOrderExportDetail(businessTypeAttrs) {
    const warehouseExportProposalAttr = businessTypeAttrs?.some(
      (attr) =>
        attr.code ===
          BusinessTypeAttributeDefaultEnum.WAREHOUSE_EXPORT_PROPOSAL_ID &&
        attr.required,
    );
    const poImportIdAttr = businessTypeAttrs?.some(
      (attr) =>
        attr.code === BusinessTypeAttributeDefaultEnum.PO_IMPORT_ID &&
        attr.required,
    );

    if (warehouseExportProposalAttr) {
      return BusinessTypeAttributeDefaultEnum.WAREHOUSE_EXPORT_PROPOSAL_ID;
    } else if (poImportIdAttr) {
      return BusinessTypeAttributeDefaultEnum.PO_IMPORT_ID;
    } else {
      return null;
    }
  }

  private async save(
    saleOrderExportEntity: SaleOrderExport,
    payload: CreateSaleOrderExportRequestDto,
    businessTypeAttrs,
    isEbs = false,
  ): Promise<any> {
    const { items, departmentReceiptId, warehouseId } = payload;
    const isUpdate = saleOrderExportEntity.id !== null;
    let response, message;
    let responeCode = ResponseCodeEnum.SUCCESS;
    let saleOrderExport;

    // Validate department receipt
    if (departmentReceiptId) {
      const departmentReceipt = await this.userService.getDepartmentReceiptById(
        departmentReceiptId,
      );
      if (isEmpty(departmentReceipt)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.DEPARTMENT_RECEIPT_NOT_FOUND'),
          )
          .build();
      }
    }

    // validate warehouse
    const warehouses = await this.warehouseService.getWarehouses([warehouseId]);
    if (!warehouses.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
        .build();
    }

    // validate source
    if (payload.sourceId) {
      const source = await this.sourceRepository.findOneByCondition({
        id: payload.sourceId,
        warehouseId: payload.warehouseId,
      });

      if (isEmpty(source)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.SOURCE_NOT_FOUND'))
          .build();
      }
    }

    /** Validate items
     * Step 1: Validate items existed in master data
     * Step 2: Validate items via receipt detail or warehouse export proposal detail (depend on business type)
     */
    const baseCondition =
      this.getBaseConditionForSaleOrderExportDetail(businessTypeAttrs);
    const attrByBaseCondition = businessTypeAttrs?.find(
      (attr) => attr.code === baseCondition,
    );
    let validateItemsResult;
    switch (baseCondition) {
      case BusinessTypeAttributeDefaultEnum.WAREHOUSE_EXPORT_PROPOSAL_ID:
        validateItemsResult =
          await this.validateSoeDetailWithWarehouseExportProposalDetail.validateItems(
            items,
            Number(
              payload.attributes?.find(
                (attr) => Number(attr.id) === attrByBaseCondition?.id,
              )?.value,
            ),
          );
        break;
      case BusinessTypeAttributeDefaultEnum.PO_IMPORT_ID:
        validateItemsResult =
          await this.validateSoeDetailWithPOImportDetail.validateItems(
            items,
            Number(
              payload.attributes?.find(
                (attr) => Number(attr.id) === attrByBaseCondition?.id,
              )?.value,
            ),
          );
        break;
      default:
        validateItemsResult =
          await this.validateSoeDetailWithMasterDataItem.validateItems(
            items,
            warehouseId,
          );
        break;
    }
    if (!validateItemsResult?.success) {
      return new ResponseBuilder()
        .withData(validateItemsResult.data)
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate(validateItemsResult.message))
        .build();
    }

    const arrLotNumberOfItem = [];
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      // validate lotNumber
      const lotNumberRequest = item.lotNumber;

      const key = item.id + `_` + item.warehouseId;
      if (arrLotNumberOfItem[key]) {
        arrLotNumberOfItem[key] = arrLotNumberOfItem[key].concat([
          lotNumberRequest,
        ]);
      } else {
        arrLotNumberOfItem[key] = [lotNumberRequest];
      }
    }

    let validQuantitySOExportWithWarehouseExportProposal = false;
    if (!isEmpty(payload.attributes)) {
      const warehouseExportProposalResponse =
        await this.warehouseService.getWarehouseExportProposalDetail(
          payload.attributes[0].value,
        );
      items?.forEach((item) => {
        warehouseExportProposalResponse.items?.forEach(
          (warehouseExportProposal) => {
            warehouseExportProposal.childrens?.forEach(
              (warehouseExportProposalChild) => {
                if (
                  (item.id === warehouseExportProposalChild?.itemId &&
                    item.lotNumber ===
                      warehouseExportProposalChild?.lotNumber &&
                    item.warehouseId ===
                      warehouseExportProposalChild.warehouseExportId) ||
                  item.itemCode ===
                    warehouseExportProposalChild?.itemResponse?.code
                ) {
                  if (
                    item.quantity >
                    warehouseExportProposalChild.requestedQuantity
                  ) {
                    validQuantitySOExportWithWarehouseExportProposal = true;
                  }
                }
              },
            );
          },
        );
      });
    }
    if (validQuantitySOExportWithWarehouseExportProposal) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.EXPORTED_QUANTITY_MUST_BE_LESS_THAN_REQUESTED_QUANTITY',
          ),
        )
        .build();
    }
    const saleOrderExportDetailRaws = {};
    items.forEach((item) => {
      if (saleOrderExportDetailRaws[item.id]) {
        saleOrderExportDetailRaws[item.id].quantity = plus(
          saleOrderExportDetailRaws[item.id].quantity,
          item.quantity,
        );
      } else {
        saleOrderExportDetailRaws[item.id] = {
          id: item.id,
          quantity: item.quantity,
          debitAccount: item.debitAccount,
          creditAccount: isEbs ? item.creditAccount : null,
        };
      }
    });

    const saleOrderExportWarehouseDetailRaws = {};
    items.forEach((item) => {
      const key = item.id + '_' + item.warehouseId;
      if (saleOrderExportWarehouseDetailRaws[key]) {
        saleOrderExportWarehouseDetailRaws[key].quantity = plus(
          saleOrderExportWarehouseDetailRaws[key].quantity,
          item.quantity,
        );
      } else {
        saleOrderExportWarehouseDetailRaws[key] = {
          itemId: item.id,
          quantity: item.quantity,
          warehouseId: item.warehouseId,
        };
      }
    });

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      saleOrderExportEntity.syncCode = (
        await this.userService.getCompanyDefault()
      )?.code;
      const userResponse = await this.userService.getUserById(payload.userId);
      saleOrderExportEntity.companyId = userResponse?.companyId;
      // save sale order export
      saleOrderExport = await queryRunner.manager.save(saleOrderExportEntity);
      const itemResponse = await this.itemService.getItemWarehouseStock({
        warehouseId: saleOrderExport.warehouseId,
      } as any);
      // save sale order export detail
      const saleOrderExportDetailEntities = values(
        saleOrderExportDetailRaws,
      ).map((saleOrderExportDetail: any) =>
        this.saleOrderExportDetailRepository.createEntity({
          ...saleOrderExportDetail,
          saleOrderExportId: saleOrderExport.id,
          itemId: saleOrderExportDetail.id,
          quantity: saleOrderExportDetail.quantity,
        }),
      );

      if (isUpdate) {
        await queryRunner.manager.delete(SaleOrderExportDetail, {
          saleOrderExportId: saleOrderExport.id,
        });
      }

      const itemMap = keyBy(items, 'id');
      const creditAccountByItem = {};

      if (!isEbs)
        itemResponse?.items?.forEach((itemStock) => {
          itemStock?.itemWarehouseSources?.forEach((itemWarehouse) => {
            if (
              saleOrderExport?.warehouseId === itemWarehouse?.warehouseId &&
              has(itemMap, itemStock.id)
            ) {
              creditAccountByItem[itemStock.id] = itemWarehouse?.accounting;
            }
          });
        });
      saleOrderExport.saleOrderExportDetails = await queryRunner.manager.save(
        saleOrderExportDetailEntities,
      );
      const saleOrderExportDetailMap = [];
      saleOrderExport.saleOrderExportDetails.forEach((record) => {
        const key = record.itemId;
        saleOrderExportDetailMap[key] = record;
      });

      // save sale order export warehouse detail
      const saleOrderExportWarehouseDetailEntities = values(
        saleOrderExportWarehouseDetailRaws,
      ).map((item: any) => {
        const key = item.itemId;

        const saleOrderExportDetail = saleOrderExportDetailMap[key];
        return this.saleOrderExportWarehouseDetailRepository.createEntity({
          itemId: item.itemId,
          warehouseId: item.warehouseId,
          saleOrderExportDetailId: saleOrderExportDetail.id,
          saleOrderExportId: saleOrderExportDetail.saleOrderExportId,
          quantity: item.quantity,
        });
      });

      if (isUpdate) {
        await queryRunner.manager.delete(SaleOrderExportWarehouseLotEntity, {
          saleOrderExportId: saleOrderExport.id,
        });
        await queryRunner.manager.delete(SaleOrderExportWarehouseDetail, {
          saleOrderExportId: saleOrderExport.id,
        });
      }
      saleOrderExport.saleOrderExportWarehouseDetails =
        await queryRunner.manager.save(saleOrderExportWarehouseDetailEntities);

      const saleOrderExportWarehouseDetailMap = [];
      saleOrderExport.saleOrderExportWarehouseDetails.forEach((record) => {
        const key = record.itemId + '_' + record.warehouseId;
        saleOrderExportWarehouseDetailMap[key] = record;
      });

      // save sale order export warehouse lot
      const saleOrderExportDetailLotEntities = items.map((item: any) => {
        const key = item.id + '_' + item.warehouseId;
        const saleOrderExportWarehouseDetail =
          saleOrderExportWarehouseDetailMap[key];

        return this.saleOrderExportWarehouseLotRepository.createEntity({
          saleOrderExportId: saleOrderExportWarehouseDetail.saleOrderExportId,
          saleOrderExportWarehouseDetailId: saleOrderExportWarehouseDetail.id,
          itemId: item.id,
          warehouseId: item.warehouseId,
          quantity: item.quantity,
          lotNumber: item.lotNumber,
          creditAccount:
            creditAccountByItem[item.id] || item.creditAccount || '',
          debitAccount: item.debitAccount,
        });
      });

      saleOrderExport.saleOrderExportWarehouseLots =
        await queryRunner.manager.save(saleOrderExportDetailLotEntities);

      // save bussiness type attribute values
      if (!isEmpty(payload.attributes)) {
        const saveBusinessTypeAttrValues =
          await this.warehouseService.saveBusinessTypeAttrs(
            payload.attributes.map((attr) => {
              const businessTypeAttr = businessTypeAttrs.find(
                (data) => Number(attr.id) === data.id,
              );
              return {
                orderId: saleOrderExportEntity.id,
                orderType: OrderTypeEnum.SO,
                businessTypeId: businessTypeAttr.bussinessTypeId,
                businessTypeAttributeId: attr.id,
                values: attr.value,
                type: businessTypeAttr.type,
              };
            }),
          );
        if (
          saveBusinessTypeAttrValues.statusCode !== ResponseCodeEnum.SUCCESS
        ) {
          throw new Error(saveBusinessTypeAttrValues.message);
        }
      }

      response = plainToInstance(SaleOrderExportResponseDto, saleOrderExport, {
        excludeExtraneousValues: true,
      });
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      responeCode = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      message = error;
    }
    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(responeCode)
      .withData(response)
      .withMessage(
        responeCode === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  private async createSo(payload: any): Promise<any> {
    const {
      items,
      code,
      name,
      description,
      receiptDate,
      userId,
      constructionId,
    } = payload;

    const existedSo = await this.saleOrderRepository.findOneByCondition({
      code,
    });
    if (!isEmpty(existedSo)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(existedSo)
        .withMessage(await this.i18n.translate('message.SUCCESS'))
        .build();
    }

    // Validate items
    const itemIds = uniq(items.map((e) => e.id));
    const itemsExist = await this.itemService.getItems(itemIds);
    if (!itemsExist || itemIds.length !== itemsExist.length) {
      const itemIdsExist = itemsExist ? itemsExist.map((e) => e.itemId) : [];
      return new ResponseBuilder({
        invalidItems: items.filter((e) => !itemIdsExist.includes(e.id)),
      })
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }

    const saleOrderDetailRaws = {};
    items.forEach((item) => {
      if (saleOrderDetailRaws[item.id]) {
        saleOrderDetailRaws[item.id].quantity = plus(
          saleOrderDetailRaws[item.id].quantity,
          item.quantity,
        );
      } else {
        saleOrderDetailRaws[item.id] = {
          id: item.id,
          quantity: item.quantity,
          price: item.price,
          amount: item.amount,
        };
      }
    });

    let response, responeCode;
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const saleOrderEntity = new SaleOrder();
      saleOrderEntity.name = name;
      saleOrderEntity.createdByUserId = userId;
      saleOrderEntity.description = description;
      saleOrderEntity.code = code;
      saleOrderEntity.orderedAt = receiptDate;
      saleOrderEntity.boqId = constructionId;

      const saleOrder = await queryRunner.manager.save(saleOrderEntity);

      const saleOrderDetailEntities = values(saleOrderDetailRaws).map(
        (saleOrderDetail: any) =>
          this.saleOrderDetailRepository.createEntity({
            saleOrderId: saleOrder.id,
            itemId: saleOrderDetail.id,
            quantity: saleOrderDetail.quantity,
            price: saleOrderDetail.price || 0,
          }),
      );
      const saleOrderDetails = await queryRunner.manager.save(
        saleOrderDetailEntities,
      );
      saleOrderEntity.saleOrderDetails = saleOrderDetails;

      await queryRunner.commitTransaction();
      response = plainToInstance(SaleOrderResponseDto, saleOrderEntity, {
        excludeExtraneousValues: true,
      });
      responeCode = ResponseCodeEnum.SUCCESS;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      responeCode = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
    }
    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(responeCode)
      .withData(response)
      .withMessage(
        responeCode === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('message.SUCCESS')
          : await this.i18n.translate('error.INTERNAL_SERVER_ERROR'),
      )
      .build();
  }

  private async generateSoExportCode() {
    const currentDate = Moment().utcOffset(7).format('DDMMYYYY');
    const lastSoExportInDay =
      await this.saleOrderExportRepository.findOneWithRelations({
        where: { code: Like(`${SO_EXPORT_CODE_PREFIX}${currentDate}%`) },
        withDeleted: true,
        order: { code: 'DESC' },
      });
    if (!isEmpty(lastSoExportInDay)) {
      const lastIncreaseId = Number(lastSoExportInDay.code.slice(-3));
      const newIncreaseId = lastIncreaseId + 1;
      return `${SO_EXPORT_CODE_PREFIX}${currentDate}${newIncreaseId
        .toString()
        .padStart(3, '0')}`;
    }
    return `${SO_EXPORT_CODE_PREFIX}${currentDate}000`;
  }

  public async createSoExport(
    payload: CreateSaleOrderExportRequestDto,
  ): Promise<any> {
    const { businessTypeId, attributes, sourceId } = payload;
    const businessType = await this.warehouseService.getBusinessTypeDetail(
      businessTypeId,
    );
    if (isEmpty(businessType)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.BUSINESS_TYPE_NOT_FOUND_ATTRIBUTE'),
        )
        .build();
    }
    const { bussinessTypeAttributes } = businessType;
    let businessTypeAttrsRequest = [];
    if (!isEmpty(bussinessTypeAttributes)) {
      const attributeByIds = attributes ? keyBy(attributes, 'id') : {};
      businessTypeAttrsRequest = bussinessTypeAttributes?.map((attr) => ({
        ...attr,
        value: attributeByIds[attr.id]?.value,
        attrId: Number(attr.id),
        businessTypeId,
      }));
      const validationResult =
        await this.warehouseService.validateBusinessTypeAttrs(
          businessTypeAttrsRequest,
          sourceId,
        );
      if (validationResult.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validationResult;
      }
    }

    const code = await this.generateSoExportCode();
    const createSoResult = await this.createSo({
      ...payload,
      code,
    });

    if (createSoResult.statusCode !== ResponseCodeEnum.SUCCESS) {
      return createSoResult;
    }

    const isExist =
      await this.saleOrderExportRepository.checkImportOrderCodeExist(code);

    if (isExist.length > 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ORDER_IS_EXIST'))
        .build();
    }
    const saleOrderExport = this.saleOrderExportRepository.createEntity({
      ...payload,
      code,
      saleOrderId: createSoResult.data?.id,
    });
    return await this.save(saleOrderExport, payload, bussinessTypeAttributes);
  }

  public async updateSoExport(payload: UpdateSaleOrderExportDto): Promise<any> {
    const { businessTypeId, attributes, id, sourceId } = payload;

    const saleOrderExport = await this.saleOrderExportRepository.findOneById(
      id,
    );
    if (!saleOrderExport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (saleOrderExport.status === OrderStatusEnum.Confirmed) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.SALE_ORDER_EXPORT_STATUS_IS_INVALID',
          ),
        )
        .build();
    }

    if (saleOrderExport.status === OrderStatusEnum.Reject) {
      saleOrderExport.status = OrderStatusEnum.Pending;
    }

    const businessType = await this.warehouseService.getBusinessTypeDetail(
      businessTypeId,
    );
    if (isEmpty(businessType)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.BUSINESS_TYPE_NOT_FOUND_ATTRIBUTE'),
        )
        .build();
    }

    const { bussinessTypeAttributes } = businessType;
    let businessTypeAttrsRequest = [];
    if (!isEmpty(bussinessTypeAttributes)) {
      const attributeByIds = attributes ? keyBy(attributes, 'id') : {};
      businessTypeAttrsRequest = bussinessTypeAttributes?.map((attr) => ({
        ...attr,
        value: attributeByIds[attr.id]?.value,
        attrId: Number(attr.id),
        businessTypeId,
      }));
      const validationResult =
        await this.warehouseService.validateBusinessTypeAttrs(
          businessTypeAttrsRequest,
          sourceId,
        );
      if (validationResult.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validationResult;
      }
    }
    const saleOrderExportEntity =
      await this.saleOrderExportRepository.updateEntity(
        saleOrderExport,
        payload,
      );
    return await this.save(
      saleOrderExportEntity,
      payload,
      bussinessTypeAttributes,
    );
  }

  public async updateHeader(
    payload: UpdateHeaderSaleOrderExportBodyDto,
  ): Promise<any> {
    const { businessTypeId, attributes, id, sourceId, reasonId } = payload;

    const saleOrderExport =
      await this.saleOrderExportRepository.findOneWithRelations({
        where: { id },
        relations: ['saleOrderExportDetails', 'saleOrderExportWarehouseLots'],
      });
    if (!saleOrderExport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!STATUS_CAN_UPDATE_HEADER_SOE.includes(saleOrderExport.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.SALE_ORDER_EXPORT_STATUS_IS_INVALID',
          ),
        )
        .build();
    }

    if (
      !SYNC_STATUS_CAN_UPDATE_HEADER_SOE.includes(saleOrderExport.syncStatus)
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.SALE_ORDER_EXPORT_STATUS_IS_INVALID',
          ),
        )
        .build();
    }

    const businessType = await this.warehouseService.getBusinessTypeDetail(
      businessTypeId,
      saleOrderExport.id,
      OrderTypeEnum.SO,
    );
    if (isEmpty(businessType)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.BUSINESS_TYPE_NOT_FOUND_ATTRIBUTE'),
        )
        .build();
    }

    const { bussinessTypeAttributes } = businessType;
    let businessTypeAttrsRequest = [];
    if (!isEmpty(bussinessTypeAttributes)) {
      const attributeByIds = attributes ? keyBy(attributes, 'id') : {};
      businessTypeAttrsRequest = bussinessTypeAttributes?.map((attr) => ({
        ...attr,
        value: attributeByIds[attr.id]?.value,
        attrId: Number(attr.id),
        businessTypeId,
      }));
      const validationResult =
        await this.warehouseService.validateBusinessTypeAttrs(
          businessTypeAttrsRequest,
          sourceId,
        );
      if (validationResult.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validationResult;
      }
    }

    const { departmentReceiptId } = payload;
    let response, message;
    let responeCode = ResponseCodeEnum.SUCCESS;

    // Validate department receipt
    if (departmentReceiptId) {
      const departmentReceipt = await this.userService.getDepartmentReceiptById(
        departmentReceiptId,
      );
      if (isEmpty(departmentReceipt)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.DEPARTMENT_RECEIPT_NOT_FOUND'),
          )
          .build();
      }
    }

    // validate source
    const source = await this.sourceRepository.findOneByCondition({
      id: payload.sourceId,
      warehouseId: saleOrderExport.warehouseId,
    });

    if (isEmpty(source)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.SOURCE_NOT_FOUND'))
        .build();
    }

    if (
      saleOrderExport.ebsId &&
      payload.sourceId !== saleOrderExport.sourceId
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CANNOT_CHANGE_SOURCE'))
        .build();
    }

    const reason = await this.reasonRepository.findOneById(reasonId);
    if (isEmpty(reason)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REASON_NOT_FOUND'))
        .build();
    }

    if (
      (payload?.ebsId && payload?.ebsId?.split('.')[2] !== reason.code) ||
      (payload?.transactionNumberCreated &&
        payload?.transactionNumberCreated?.split('.')[2] !== reason.code)
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.REASON_INVALID'))
        .build();
    }

    const warehouse = await this.warehouseService.getDetailById(
      payload.warehouseId,
    );
    if (isEmpty(warehouse)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
        .build();
    }

    if (
      (payload?.ebsId && payload?.ebsId?.split('.')[1] !== warehouse.code) ||
      (payload?.transactionNumberCreated &&
        payload?.transactionNumberCreated?.split('.')[1] !== warehouse.code)
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WAREHOUSE_INVALID'))
        .build();
    }

    if (saleOrderExport.businessTypeId !== payload.businessTypeId) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.CANNOT_CHANGE_BUSINESS_TYPE'),
        )
        .build();
    }

    const warehouseExportProposalAttr = bussinessTypeAttributes.find(
      (attr) =>
        attr?.code ===
        BusinessTypeAttributeDefaultEnum.WAREHOUSE_EXPORT_PROPOSAL_ID,
    );

    if (isEmpty(warehouseExportProposalAttr)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.CANNOT_CHANGE_WAREHOUSE_EXPORT_PROPOSAL_ID',
          ),
        )
        .build();
    }

    if (!saleOrderExport.ebsId) {
      payload.items.forEach((item) => {
        item.debitAccount = [
          source.accountant,
          source.produceTypeCode,
          source.productCode,
          source.factorialCode,
        ].join(CODE_DELIMITER);
      });
    } else {
      payload.items.forEach((item) => {
        item.debitAccount = [
          source.companyCode,
          source.branchCode,
          source.costCenterCode,
          item.debitAccount,
          source.internalDepartmentCode,
          source.departmentBackupCode,
          source.EVNBackupCode,
        ].join(CODE_DELIMITER);
      });
    }

    const itemMap = keyBy(
      payload.items,
      (item) => `${item.itemId}_${item.lotNumber || ''}`,
    );

    orderBy(
      saleOrderExport.saleOrderExportWarehouseLots,
      ['itemId', 'lotNumber', 'quantity'],
      ['asc', 'asc', 'asc'],
    ).forEach((item) => {
      item.debitAccount =
        itemMap[`${item.itemId}_${item.lotNumber || ''}`]?.debitAccount;
    });

    if (!saleOrderExport.oldEbsId && payload.ebsId) {
      saleOrderExport.oldEbsId = saleOrderExport.ebsId;
    }
    saleOrderExport.ebsId = payload.ebsId;
    if (
      !saleOrderExport.oldTransactionNumberCreated &&
      payload.transactionNumberCreated
    ) {
      saleOrderExport.oldTransactionNumberCreated =
        saleOrderExport.transactionNumberCreated;
    }
    saleOrderExport.transactionNumberCreated = payload.transactionNumberCreated;
    saleOrderExport.departmentReceiptId = payload.departmentReceiptId;
    saleOrderExport.reasonId = payload.reasonId;
    saleOrderExport.sourceId = payload.sourceId;
    saleOrderExport.explaination = payload.explaination;
    saleOrderExport.receiver = payload.receiver;

    saleOrderExport.syncCode = (
      await this.userService.getCompanyDefault()
    )?.code;
    const userResponse = await this.userService.getUserById(payload.userId);
    saleOrderExport.companyId = userResponse?.companyId;

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      // save sale order export
      await queryRunner.manager.save(saleOrderExport);

      // save bussiness type attribute values
      if (!isEmpty(payload.attributes)) {
        const saveBusinessTypeAttrValues =
          await this.warehouseService.saveBusinessTypeAttrs(
            payload.attributes.map((attr) => {
              const businessTypeAttr = bussinessTypeAttributes.find(
                (data) => Number(attr.id) === data.id,
              );
              return {
                orderId: saleOrderExport.id,
                orderType: OrderTypeEnum.SO,
                businessTypeId: businessTypeAttr.bussinessTypeId,
                businessTypeAttributeId: attr.id,
                values: attr.value,
                type: businessTypeAttr.type,
              };
            }),
          );
        if (
          saveBusinessTypeAttrValues.statusCode !== ResponseCodeEnum.SUCCESS
        ) {
          throw new Error(saveBusinessTypeAttrValues.message);
        }
      }

      response = plainToInstance(SaleOrderExportResponseDto, saleOrderExport, {
        excludeExtraneousValues: true,
      });
      await queryRunner.commitTransaction();

      // if (saleOrderExport.status === OrderStatusEnum.Completed) {
      //   const resEbs = await this.syncOrderToEbs(
      //     saleOrderExport.id,
      //     payload.user.id,
      //     true,
      //   );

      //   if (resEbs.statusCode !== ResponseCodeEnum.SUCCESS) {
      //     return new ResponseBuilder({
      //       ebsError: true,
      //     })
      //       .withCode(ResponseCodeEnum.BAD_REQUEST)
      //       .withMessage(await this.i18n.translate('error.ERROR_SYNC_EBS'))
      //       .build();
      //   }
      // }
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      responeCode = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      message = error;
    }
    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(responeCode)
      .withData(response)
      .withMessage(
        responeCode === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  async updateOrderDetailConfirmQuantity(
    payload: UpdateOrderDetailConfirmQuantityRequestDto,
  ): Promise<any> {
    const { orderId, orderDetails, warehouseOrderDetails } = payload;
    let message;
    let code = ResponseCodeEnum.SUCCESS;
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const updateSaleOrderExportDetailEntities =
        await this.saleOrderExportDetailRepository.getUpdateOrderDetailConfirmQuantityByIds(
          orderId,
          orderDetails,
        );

      const updateSaleOrderExportWarehouseDetailEntities =
        await this.saleOrderExportWarehouseDetailRepository.getUpdateOrderWarehouseDetailConfirmQuantityByIds(
          orderId,
          warehouseOrderDetails,
        );

      await queryRunner.manager.save(updateSaleOrderExportDetailEntities);
      await queryRunner.manager.save(
        updateSaleOrderExportWarehouseDetailEntities,
      );
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      message = error;
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
    }
    await queryRunner.release();
    this.eventEmitter.emit(
      'order.updateConfirmedQuantity',
      new OrderUpdateConfirmedQuantityEvent({
        id: orderId,
        orderType: OrderTypeEnum.SO,
      }),
    );
    return new ResponseBuilder()
      .withCode(code)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  async updateOrderDetailActualQuantity(
    payload: UpdateOrderDetailActualQuantityRequestDto,
  ): Promise<any> {
    const { orderId, orderDetails, warehouseOrderDetails, itemLots } = payload;
    let message;
    let code = ResponseCodeEnum.SUCCESS;
    const saleOrderExportWarehouseLotEntities =
      await this.saleOrderExportWarehouseLotRepository.getLotsByItems(
        map(itemLots, 'itemId'),
        map(itemLots, 'lotNumber'),
        map(itemLots, 'warehouseId'),
        orderId,
      );

    saleOrderExportWarehouseLotEntities.forEach(
      (
        saleOrderExportWarehouseLotEntity: SaleOrderExportWarehouseLotEntity,
      ) => {
        const itemLot = find(
          itemLots,
          (iL) =>
            iL.itemId === saleOrderExportWarehouseLotEntity.itemId &&
            iL.lotNumber.toUpperCase() ===
              saleOrderExportWarehouseLotEntity.lotNumber.toUpperCase(),
        );

        if (itemLot) {
          saleOrderExportWarehouseLotEntity.actualQuantity = plus(
            saleOrderExportWarehouseLotEntity.actualQuantity,
            itemLot.quantity,
          );
        }
      },
    );

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const updateSaleOrderExportDetailEntities =
        await this.saleOrderExportDetailRepository.getUpdateOrderDetailActualQuantityByIds(
          orderId,
          orderDetails,
        );

      const updateSaleOrderExportWarehouseDetailEntities =
        await this.saleOrderExportWarehouseDetailRepository.getUpdateOrderWarehouseDetailActualQuantityByIds(
          orderId,
          warehouseOrderDetails,
        );

      await queryRunner.manager.save(updateSaleOrderExportDetailEntities);
      await queryRunner.manager.save(saleOrderExportWarehouseLotEntities);
      await queryRunner.manager.save(
        updateSaleOrderExportWarehouseDetailEntities,
      );
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      message = error;
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
    } finally {
      await queryRunner.release();
    }
    this.eventEmitter.emit(EventSyncSoExportEnum.Update, orderId);
    return new ResponseBuilder()
      .withCode(code)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  async updateOrderDetailReturnQuantity(
    payload: UpdateOrderDetailReturnQuantityRequestDto,
  ): Promise<any> {
    const { orderId, orderDetails, warehouseOrderDetails, itemLots } = payload;
    let message;
    let code = ResponseCodeEnum.SUCCESS;
    const saleOrderExportWarehouseLotEntities =
      await this.saleOrderExportWarehouseLotRepository.getLotsByItems(
        map(itemLots, 'itemId'),
        map(itemLots, 'lotNumber'),
        map(itemLots, 'warehouseId'),
        orderId,
      );

    saleOrderExportWarehouseLotEntities.forEach(
      (
        saleOrderExportWarehouseLotEntity: SaleOrderExportWarehouseLotEntity,
      ) => {
        const itemLot = find(
          itemLots,
          (iL) =>
            iL.itemId === saleOrderExportWarehouseLotEntity.itemId &&
            iL.lotNumber.toUpperCase() ===
              saleOrderExportWarehouseLotEntity.lotNumber.toUpperCase(),
        );

        if (itemLot) {
          saleOrderExportWarehouseLotEntity.returnedQuantity = plus(
            saleOrderExportWarehouseLotEntity.returnedQuantity,
            itemLot.quantity,
          );
        }
      },
    );

    const orderDetailEntities =
      await this.saleOrderExportDetailRepository.findByCondition({
        id: In(Object.keys(orderDetails)),
        saleOrderExportId: orderId,
      });

    orderDetailEntities.forEach((orderDetailEntity) => {
      const id = orderDetailEntity.id;
      orderDetailEntity.returnedQuantity = plus(
        orderDetailEntity.returnedQuantity,
        orderDetails[id].quantity,
      );
    });
    const orderWarehouseDetailEntities =
      await this.saleOrderExportWarehouseDetailRepository.findByCondition({
        id: In(Object.keys(warehouseOrderDetails)),
        saleOrderExportId: orderId,
      });

    orderWarehouseDetailEntities.forEach((orderWarehouseDetailEntity) => {
      const id = orderWarehouseDetailEntity.id;
      orderWarehouseDetailEntity.returnedQuantity = plus(
        orderWarehouseDetailEntity.returnedQuantity,
        warehouseOrderDetails[id].quantity,
      );
    });

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(orderDetailEntities);
      await queryRunner.manager.save(saleOrderExportWarehouseLotEntities);
      await queryRunner.manager.save(orderWarehouseDetailEntities);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      message = error;
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
    }
    await queryRunner.release();
    this.eventEmitter.emit(
      'order.updateReturnQuantity',
      new OrderUpdateReturnQuantityEvent({
        id: orderId,
        orderType: OrderTypeEnum.SO,
      }),
    );
    return new ResponseBuilder()
      .withCode(code)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  /**
   * Get data sale order by id and warehouseId
   * @param id
   * @param warehouseId
   * @returns
   */
  async getWarehouseDetails(
    id: number,
    warehouseId: number,
    type: number,
  ): Promise<any> {
    try {
      const data = await this.saleOrderExportRepository.getWarehouseDetails(
        id,
        warehouseId,
        type,
      );

      return new ResponseBuilder(data)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async confirm(payload: SetOrderStatusRequestDto): Promise<any> {
    const { id, userId } = payload;
    const saleOrderExport =
      await this.saleOrderExportRepository.findOneWithRelations({
        where: {
          id,
        },
        relations: ['saleOrderExportWarehouseLots'],
      });

    if (isEmpty(saleOrderExport)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_CONFIRM_ORDER_STATUS.includes(saleOrderExport.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    const warehouseExportProposal =
      await this.warehouseService.getBussinessTypeWarehouseExportProposalByOrder(
        {
          orderId: id,
          orderType: OrderTypeEnum.SO,
        },
      );

    // Validate và Đồng bộ số lượng có thể xuất lên giấy đề nghị xuất vật tư
    if (!isEmpty(warehouseExportProposal)) {
      const itemsUpdateRemainQuantityWarehouseExportProposal =
        saleOrderExport.saleOrderExportWarehouseLots.map((lot) => {
          return new UpdateItemRemainingWarehouseExportProposal(
            +lot.itemId,
            lot.lotNumber,
            +saleOrderExport.warehouseId,
            +lot.quantity,
          );
        });
      const requestUpdateRemainQuantityWarehouseExportProposal =
        new UpdateItemRemainingWarehouseExportProposalRequestDto(
          +warehouseExportProposal.values,
          itemsUpdateRemainQuantityWarehouseExportProposal,
        );
      const updateRemainQuantityWarehouseExportProposal =
        await this.warehouseService.updateItemRemainingQuantityWarehouseExportProposal(
          requestUpdateRemainQuantityWarehouseExportProposal,
        );
      if (
        updateRemainQuantityWarehouseExportProposal?.statusCode !==
        ResponseCodeEnum.SUCCESS
      ) {
        return updateRemainQuantityWarehouseExportProposal;
      }
    }
    // Giữ chỗ cho vật tư phiếu xuất
    let responseCreateItemPlanning;
    if (!isEmpty(warehouseExportProposal)) {
      responseCreateItemPlanning =
        await this.createItemPlanningSOexpByWarehouseExportProposal(
          id,
          +warehouseExportProposal.values,
        );
    } else {
      responseCreateItemPlanning = await this.createItemPlanningSOexp(id);
    }
    if (responseCreateItemPlanning?.statusCode !== ResponseCodeEnum.SUCCESS) {
      return responseCreateItemPlanning;
    }

    saleOrderExport.status = OrderStatusEnum.Confirmed;
    saleOrderExport.confirmerId = userId;
    saleOrderExport.approvedAt = new Date(Date.now());
    await this.saleOrderExportRepository.create(saleOrderExport);
    this.eventEmitter.emit(EventSyncSoExportEnum.Update, saleOrderExport.id);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async cancelSync(payload: SetOrderStatusRequestDto): Promise<any> {
    const { id } = payload;
    const saleOrderExport =
      await this.saleOrderExportRepository.findOneWithRelations({
        where: {
          id,
        },
        relations: ['saleOrderExportWarehouseLots'],
      });

    if (isEmpty(saleOrderExport)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (
      saleOrderExport.syncStatus !== StatusSyncOrderToEbsEnum.SYNC_WSO2_ERROR
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    const conditions = saleOrderExport.saleOrderExportWarehouseLots.map(
      (lot) => ({
        itemId: lot.itemId,
        lotNumber: lot.lotNumber,
        warehouseId: saleOrderExport.warehouseId,
      }),
    );

    const itemsPrice = await this.itemService.getItemsPrice(conditions);

    const itemsPriceMap = keyBy(itemsPrice, 'itemId');

    const { ebsId, transactionNumberCreated } =
      await this.generateDataCancelSync(saleOrderExport);

    if (!saleOrderExport.ebsId)
      saleOrderExport.saleOrderExportWarehouseLots.forEach((lot) => {
        lot.price = div(
          itemsPriceMap[lot.itemId]?.totalAmount || 0,
          +itemsPriceMap[lot.itemId]?.quantity || 1,
        );
        lot.amount = itemsPriceMap[lot.itemId]?.totalAmount || 0;
      });

    saleOrderExport.syncStatus = StatusSyncOrderToEbsEnum.CANCEL;
    saleOrderExport.transactionNumberCreated =
      saleOrderExport.transactionNumberCreated || transactionNumberCreated;
    saleOrderExport.ebsId = saleOrderExport.ebsId || ebsId;

    await this.saleOrderExportRepository.create(saleOrderExport);
    this.eventEmitter.emit(EventSyncSoExportEnum.Update, saleOrderExport.id);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async return(payload: SetOrderStatusRequestDto): Promise<any> {
    const { id } = payload;
    const saleOrderExport =
      await this.saleOrderExportRepository.findOneWithRelations({
        where: {
          id,
        },
        relations: ['saleOrderExportWarehouseLots'],
      });

    if (isEmpty(saleOrderExport)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (saleOrderExport.status !== OrderStatusEnum.Confirmed) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    const warehouseExportProposal =
      await this.warehouseService.getBussinessTypeWarehouseExportProposalByOrder(
        {
          orderId: id,
          orderType: OrderTypeEnum.SO,
        },
      );

    // Validate và Đồng bộ số lượng có thể xuất lên giấy đề nghị xuất vật tư
    if (!isEmpty(warehouseExportProposal)) {
      const warehouseExportProposalDetail =
        await this.warehouseService.getWarehouseExportProposalDetail(
          +warehouseExportProposal.values,
        );

      if (isEmpty(warehouseExportProposalDetail)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }

      const itemKeep = {};
      const itemKeeps = [];

      warehouseExportProposalDetail.items.forEach((item) => {
        item.childrens.forEach((child) => {
          if (child.isKeepSlot) {
            itemKeep[`${child.itemId}_${child.lotNumber || ''}`] = true;
          }
        });
      });

      const itemsUpdateRemainQuantityWarehouseExportProposal =
        saleOrderExport.saleOrderExportWarehouseLots.map((lot) => {
          if (has(itemKeep, `${lot.itemId}_${lot.lotNumber || ''}`)) {
            itemKeeps.push({
              itemId: +lot.itemId,
              lotNumber: lot.lotNumber,
              quantity: +lot.quantity,
            });
          }
          return new UpdateItemRemainingWarehouseExportProposal(
            +lot.itemId,
            lot.lotNumber,
            +saleOrderExport.warehouseId,
            +lot.quantity,
          );
        });
      const requestUpdateRemainQuantityWarehouseExportProposal =
        new UpdateItemRemainingWarehouseExportProposalRequestDto(
          +warehouseExportProposal.values,
          itemsUpdateRemainQuantityWarehouseExportProposal,
          saleOrderExport.id,
          OrderTypeEnum.SO,
        );
      const updateRemainQuantityWarehouseExportProposal =
        await this.warehouseService.rollbackItemRemainingQuantityWarehouseExportProposal(
          requestUpdateRemainQuantityWarehouseExportProposal,
        );
      if (
        updateRemainQuantityWarehouseExportProposal?.statusCode !==
        ResponseCodeEnum.SUCCESS
      ) {
        return updateRemainQuantityWarehouseExportProposal;
      }

      // Rollback giữ chỗ cho vật tư phiếu đề nghị
      if (!isEmpty(itemKeeps)) {
        const responseRemoveItemPlanning =
          await this.itemService.rollbackItemPlanningQuantities(
            +warehouseExportProposal.values,
            OrderTypeEnum.PROPOSAL,
            itemKeeps,
          );

        if (
          responseRemoveItemPlanning?.statusCode !== ResponseCodeEnum.SUCCESS
        ) {
          return responseRemoveItemPlanning;
        }
      }
    }

    // Rollback giữ chỗ cho vật tư phiếu xuất
    const responseRemoveItemPlanning =
      await this.itemService.removeItemPlanningQuantities(
        saleOrderExport.id,
        OrderTypeEnum.SO,
      );

    if (responseRemoveItemPlanning?.statusCode !== ResponseCodeEnum.SUCCESS) {
      return responseRemoveItemPlanning;
    }

    saleOrderExport.status = OrderStatusEnum.Pending;
    await this.saleOrderExportRepository.create(saleOrderExport);
    this.eventEmitter.emit(EventSyncSoExportEnum.Delete, saleOrderExport.id);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async generateDataCancelSync(
    saleOrderExport: SaleOrderExport,
  ): Promise<any> {
    const warehouse = await this.warehouseService.getDetailById(
      saleOrderExport.warehouseId,
    );
    const reason = await this.reasonRepository.findOneById(
      saleOrderExport.reasonId,
    );

    const suff = `${warehouse?.code || ''}.${reason.code || ''}.0000`;
    const ebsId = `02.${suff}`;
    const transactionNumberCreated = `03.${suff}`;

    return { ebsId, transactionNumberCreated };
  }

  // Giữ số lượng với điều kiện base trên giấy đề nghị
  private async createItemPlanningSOexpByWarehouseExportProposal(
    saleOrderExportId: number,
    warehouseExportProposalId?: number,
  ): Promise<any> {
    try {
      const itemExportWarehouseLots =
        await this.saleOrderExportWarehouseLotRepository.findByCondition({
          saleOrderExportId: saleOrderExportId,
        });
      const itemPlanningWarehouseExportProposal =
        await this.itemService.getItemPlanningQuantityByOrderId(
          warehouseExportProposalId,
          OrderTypeEnum.PROPOSAL,
        );
      const itemExportNotPlan = [];
      itemExportWarehouseLots.forEach((item) => {
        const indexItemPlanning = itemPlanningWarehouseExportProposal.findIndex(
          (itemPlanningProposal) =>
            itemPlanningProposal.itemId === item.itemId &&
            itemPlanningProposal.warehouseId === item.warehouseId &&
            (itemPlanningProposal.lotNumber || null) ===
              (item.lotNumber || null),
        );
        if (indexItemPlanning !== -1) {
          itemPlanningWarehouseExportProposal[indexItemPlanning].planQuantity =
            minus(
              itemPlanningWarehouseExportProposal[indexItemPlanning]
                .planQuantity,
              item.quantity,
            );
        }
        itemExportNotPlan.push({
          itemId: item.itemId,
          warehouseId: item.warehouseId,
          planQuantity: +item.quantity,
          lotNumber: item.lotNumber || null,
          orderId: saleOrderExportId,
          orderType: OrderTypeEnum.SO,
        } as CreateItemPlanningQuantityRequestDto);
      });

      const requestGetItemAvaiable = new GetItemStockAvailableRequestDto();
      requestGetItemAvaiable.order = {
        orderId: warehouseExportProposalId,
        orderType: OrderTypeEnum.PROPOSAL,
      };
      requestGetItemAvaiable.items = itemExportNotPlan.map((itemPlan) => {
        return {
          itemId: itemPlan.itemId,
          warehouseId: itemPlan.warehouseId,
          lotNumber: itemPlan?.lotNumber || null,
        };
      });
      const itemStockAvailables =
        await this.itemService.getItemStockAvailableByConditions(
          requestGetItemAvaiable,
        );

      const attributes = ['itemId', 'warehouseId', 'lotNumber'];
      const mapItemStockAvailable = new Map();
      itemStockAvailables.forEach((itemStock) => {
        const key = {};
        attributes.forEach((attribute) => {
          key[attribute] =
            attribute === 'lotNumber'
              ? itemStock[attribute] || null
              : itemStock[attribute];
        });
        mapItemStockAvailable.set(JSON.stringify(key), itemStock);
      });
      const invalidItemStockAvaiable = [];
      itemExportNotPlan.forEach((itemPlan) => {
        const keyObj = {};
        attributes.forEach((attribute) => {
          keyObj[attribute] =
            attribute === 'lotNumber'
              ? itemPlan[attribute] || null
              : itemPlan[attribute];
        });
        const key = JSON.stringify(keyObj);
        if (!mapItemStockAvailable.has(key)) {
          invalidItemStockAvaiable.push(itemPlan);
        } else {
          const itemAvailables = mapItemStockAvailable.get(key)?.itemAvailables;
          const quantityAvaiable = itemAvailables.reduce(
            (quantity, prev) => plus(quantity, prev.quantity),
            0,
          );
          if (quantityAvaiable < itemPlan.quantity) {
            invalidItemStockAvaiable.push(itemPlan);
          }
        }
      });
      if (!isEmpty(invalidItemStockAvaiable)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(
            await this.i18n.translate(
              'error.QUANTITY_ITEM_KEEP_IN_WAREHOUSE_NOT_ENOUGHT',
            ),
          )
          .build();
      }

      const requestCreateOrUpdateItemPlanning =
        new CreateItemPlanningQuantitiesRequestDto();
      requestCreateOrUpdateItemPlanning.items = [
        ...itemExportNotPlan,
        ...itemPlanningWarehouseExportProposal,
      ];

      return await this.itemService.createItemPlanningQuantities(
        requestCreateOrUpdateItemPlanning,
      );
    } catch (error) {
      this.logger.error(
        'Error Create Item planning Sale Order Export By Warehouse Export Proposal: ' +
          error?.message,
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  // Giữ số lượng của phiếu không base trên giấy đề nghị
  private async createItemPlanningSOexp(
    saleOrderExportId: number,
  ): Promise<any> {
    try {
      const itemExportWarehouseLots =
        await this.saleOrderExportWarehouseLotRepository.findByCondition({
          saleOrderExportId: saleOrderExportId,
        });

      const requestGetItemAvaiable = new GetItemStockAvailableRequestDto();
      requestGetItemAvaiable.order = null;
      requestGetItemAvaiable.items = itemExportWarehouseLots.map((itemLot) => {
        return {
          itemId: itemLot.itemId,
          warehouseId: itemLot.warehouseId,
          lotNumber: itemLot?.lotNumber || null,
        };
      });
      const itemStockAvailables =
        await this.itemService.getItemStockAvailableByConditions(
          requestGetItemAvaiable,
        );

      const attributes = ['itemId', 'warehouseId', 'lotNumber'];
      const mapItemStockAvailable = new Map();
      itemStockAvailables.forEach((itemStock) => {
        const key = {};
        attributes.forEach((attribute) => {
          key[attribute] =
            attribute === 'lotNumber'
              ? itemStock[attribute] || null
              : itemStock[attribute];
        });
        mapItemStockAvailable.set(JSON.stringify(key), itemStock);
      });
      const invalidItemStockAvaiable = [];
      itemExportWarehouseLots.forEach((itemLot) => {
        const keyObj = {};
        attributes.forEach((attribute) => {
          keyObj[attribute] =
            attribute === 'lotNumber'
              ? itemLot[attribute] || null
              : itemLot[attribute];
        });
        const key = JSON.stringify(keyObj);
        if (!mapItemStockAvailable.has(key)) {
          invalidItemStockAvaiable.push(itemLot);
        } else {
          const itemAvailables = mapItemStockAvailable.get(key)?.itemAvailables;
          const quantityAvaiable = itemAvailables.reduce(
            (quantity, prev) => plus(quantity, prev.quantity),
            0,
          );
          if (quantityAvaiable < itemLot.quantity) {
            invalidItemStockAvaiable.push(itemLot);
          }
        }
      });
      if (!isEmpty(invalidItemStockAvaiable)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(
            await this.i18n.translate(
              'error.QUANTITY_ITEM_KEEP_IN_WAREHOUSE_NOT_ENOUGHT',
            ),
          )
          .build();
      }

      const requestCreateOrUpdateItemPlanning =
        new CreateItemPlanningQuantitiesRequestDto();
      requestCreateOrUpdateItemPlanning.items = itemExportWarehouseLots.map(
        (lot) =>
          ({
            itemId: lot.itemId,
            warehouseId: lot.warehouseId,
            lotNumber: lot.lotNumber,
            planQuantity: lot.quantity,
            orderId: lot.saleOrderExportId,
            orderType: OrderTypeEnum.SO,
            orderDetailId: lot.id,
          } as CreateItemPlanningQuantityRequestDto),
      );
      return await this.itemService.createItemPlanningQuantities(
        requestCreateOrUpdateItemPlanning,
      );
    } catch (error) {
      this.logger.error(
        'Error Create Item planning Sale Order Export By Warehouse Export Proposal: ' +
          error?.message,
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async confirmMultiple(
    payload: DeleteMultipleWithUserIdDto,
  ): Promise<any> {
    const { createdByUserId } = payload;
    const id = payload.ids;
    const failIdsList = [];
    const ids = id.split(',').map((id) => parseInt(id));

    const saleOrderExports =
      await this.saleOrderExportRepository.findByCondition({
        id: In(ids),
      });

    const saleOrderExportIds = saleOrderExports.map(
      (saleOrderExport) => saleOrderExport.id,
    );
    if (saleOrderExports.length !== ids.length) {
      ids.forEach((id) => {
        if (!saleOrderExportIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < saleOrderExports.length; i++) {
      const saleOrderExport = saleOrderExports[i];
      if (!STATUS_TO_CONFIRM_ORDER_STATUS.includes(saleOrderExport.status))
        failIdsList.push(saleOrderExport.id);
    }

    const validIds = saleOrderExports
      .filter((saleOrderExport) => !failIdsList.includes(saleOrderExport.id))
      .map((saleOrderExport) => saleOrderExport.id);

    const validSaleOrderExports = saleOrderExports.filter((saleOrderExport) =>
      validIds.includes(saleOrderExport.id),
    );

    if (!isEmpty(validSaleOrderExports)) {
      validSaleOrderExports.forEach((saleOrderExport) => {
        saleOrderExport.status = OrderStatusEnum.Confirmed;
        saleOrderExport.approverId = createdByUserId;
        saleOrderExport.approvedAt = new Date(Date.now());
      });
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(SaleOrderExport, validSaleOrderExports);
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.CONFIRM_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async reject(payload: SetOrderStatusRequestDto): Promise<any> {
    const { id, userId } = payload;

    const saleOrderExport = await this.saleOrderExportRepository.findOneById(
      id,
    );
    if (!saleOrderExport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_REJECT_ORDER_STATUS.includes(saleOrderExport.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    const result = await this.setPurchasedOrderStatus(
      saleOrderExport,
      OrderStatusEnum.Reject,
      undefined,
      userId,
    );
    return result;
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async rejectMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const saleOrderExports =
      await this.saleOrderExportRepository.findByCondition({
        id: In(ids),
      });

    const saleOrderExportIds = saleOrderExports.map(
      (saleOrderExport) => saleOrderExport.id,
    );
    if (saleOrderExports.length !== ids.length) {
      ids.forEach((id) => {
        if (!saleOrderExportIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < saleOrderExports.length; i++) {
      const saleOrderExport = saleOrderExports[i];
      if (!STATUS_TO_REJECT_ORDER_STATUS.includes(saleOrderExport.status))
        failIdsList.push(saleOrderExport.id);
    }

    const validIds = saleOrderExports
      .filter((saleOrderExport) => !failIdsList.includes(saleOrderExport.id))
      .map((saleOrderExport) => saleOrderExport.id);

    const validSaleOrderExports = saleOrderExports.filter((saleOrderExport) =>
      validIds.includes(saleOrderExport.id),
    );

    if (!isEmpty(validSaleOrderExports)) {
      validSaleOrderExports.forEach((saleOrderExport) => {
        saleOrderExport.status = OrderStatusEnum.Reject;
        saleOrderExport.approvedAt = new Date(Date.now());
      });
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(SaleOrderExport, validSaleOrderExports);
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.REJECT_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async approve(payload: SetOrderStatusRequestDto): Promise<any> {
    const { id } = payload;

    const saleOrderExport =
      await this.saleOrderExportRepository.findOneWithRelations({
        where: {
          id,
        },
        relations: [
          'saleOrderExportWarehouseDetails',
          'saleOrderExportWarehouseLots',
          'saleOrderExportDetails',
        ],
      });
    if (!saleOrderExport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_APPROVE_ORDER_STATUS.includes(saleOrderExport.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    const conditionItemStockWarehousePrices = [];
    saleOrderExport.saleOrderExportWarehouseDetails.forEach(
      (saleOrderExportWarehouseDetail) => {
        saleOrderExportWarehouseDetail.actualQuantity =
          saleOrderExportWarehouseDetail.collectedQuantity;
      },
    );

    saleOrderExport.saleOrderExportWarehouseLots.forEach(
      (saleOrderExportWarehouseLot) => {
        conditionItemStockWarehousePrices.push({
          itemId: saleOrderExportWarehouseLot.itemId,
          lotNumber: saleOrderExportWarehouseLot.lotNumber,
          warehouseId: saleOrderExportWarehouseLot.warehouseId,
        });
        saleOrderExportWarehouseLot.actualQuantity =
          saleOrderExportWarehouseLot.collectedQuantity;
      },
    );

    saleOrderExport.saleOrderExportDetails.forEach((saleOrderExportDetail) => {
      saleOrderExportDetail.actualQuantity =
        saleOrderExportDetail.collectedQuantity;
    });
    saleOrderExport.status = OrderStatusEnum.Completed;
    saleOrderExport.syncStatus = StatusSyncOrderToEbsEnum.OUT_OF_SYNC;
    saleOrderExport.approverId = payload.userId;
    saleOrderExport.approvedAt = new Date(Date.now());

    const warehouseExportProposal =
      await this.warehouseService.getBussinessTypeWarehouseExportProposalByOrder(
        {
          orderId: saleOrderExport.id,
          orderType: OrderTypeEnum.SO,
        },
      );

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(saleOrderExport);
      await queryRunner.manager.save(saleOrderExport.saleOrderExportDetails);
      await queryRunner.manager.save(
        saleOrderExport.saleOrderExportWarehouseDetails,
      );

      const itemCollectedNotExport =
        saleOrderExport.saleOrderExportWarehouseLots.filter(
          (lot) => +lot.collectedQuantity < lot.quantity,
        );

      if (!isEmpty(itemCollectedNotExport)) {
        const returnQuantitiesPlan =
          await this.returnQuantityByWarehouseExportProposal(
            saleOrderExport,
            !isEmpty(warehouseExportProposal)
              ? +warehouseExportProposal?.values
              : null,
          );

        if (returnQuantitiesPlan.statusCode !== ResponseCodeEnum.SUCCESS) {
          throw returnQuantitiesPlan.message;
        }
      }

      const resItemStockWarehousePrice =
        await this.itemService.getItemStockWarehousePrices({
          conditions: conditionItemStockWarehousePrices,
        });

      const resItemStockWarehousePriceMap = keyBy(
        resItemStockWarehousePrice,
        (item) => `${item.itemId}-${item.lotNumber || ''}-${item.warehouseId}`,
      );

      const requestApproveWarehouseStockMovement =
        new ApproveWarehouseStockMovementByOrderRequestDto(
          saleOrderExport.id,
          OrderTypeEnum.SO,
          saleOrderExport,
        );
      const resWarehouseStock =
        await this.warehouseService.approveWarehouseStockMovementByOrder(
          requestApproveWarehouseStockMovement,
        );

      if (resWarehouseStock.statusCode !== ResponseCodeEnum.SUCCESS) {
        throw resWarehouseStock.message;
      }

      saleOrderExport.saleOrderExportWarehouseLots.forEach((item) => {
        const key = `${item.itemId}-${item.lotNumber || ''}-${
          item.warehouseId
        }`;
        const price = divBigNumber(
          resItemStockWarehousePriceMap[key].totalAmount,
          resItemStockWarehousePriceMap[key].quantity,
        );
        item.price = price;
        item.amount = mulBigNumber(price, item.actualQuantity);
      });

      await queryRunner.manager.save(
        saleOrderExport.saleOrderExportWarehouseLots,
      );

      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(
          error?.message ||
            error ||
            (await this.i18n.translate('error.INTERNAL_SERVER_ERROR')),
        )
        .build();
    } finally {
      await queryRunner.release();
    }

    if (!isEmpty(warehouseExportProposal)) {
      const itemExportedWarehouseExportProposal: UpdateItemExportedWarehouseExportProposal[] =
        saleOrderExport.saleOrderExportWarehouseLots.map(
          (lot) =>
            new UpdateItemExportedWarehouseExportProposal(
              lot.itemId,
              lot.lotNumber,
              lot.warehouseId,
              +lot.collectedQuantity,
              minus(lot.quantity, lot.collectedQuantity),
            ),
        );
      const requestUpdateExportedWarehouseExportProposal =
        new UpdateItemExportedWarehouseExportProposalRequestDto(
          +warehouseExportProposal.values,
          itemExportedWarehouseExportProposal,
        );
      await this.warehouseService.updateExportedQuantityWarehouseExportProposal(
        requestUpdateExportedWarehouseExportProposal,
      );
    }
    this.eventEmitter.emit(EventSyncSoExportEnum.Update, saleOrderExport.id);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async returnQuantityByWarehouseExportProposal(
    order: SaleOrderExport,
    warehouseExportProposalId?: number,
  ): Promise<any> {
    const saleOrderExportPlanning =
      await this.itemService.getItemPlanningQuantityByOrderId(
        order.id,
        OrderTypeEnum.SO,
      );
    const diffQuantityByKey = {};
    saleOrderExportPlanning.forEach((itemPlan) => {
      if (!itemPlan.locatorId) {
        const key = JSON.stringify({
          itemId: itemPlan.itemId,
          warehouseId: itemPlan.warehouseId,
          lotNumber: itemPlan.lotNumber || '',
        });
        diffQuantityByKey[key] = itemPlan.planQuantity;
        itemPlan.planQuantity = 0;
        itemPlan.quantity = 0;
      }
    });
    let itemPlanningWarehouseExportProposal = [];
    if (warehouseExportProposalId) {
      itemPlanningWarehouseExportProposal =
        await this.itemService.getItemPlanningQuantityByOrderId(
          +warehouseExportProposalId,
          OrderTypeEnum.PROPOSAL,
        );
      itemPlanningWarehouseExportProposal.forEach((itemPlan) => {
        const key = JSON.stringify({
          itemId: itemPlan.itemId,
          warehouseId: itemPlan.warehouseId,
          lotNumber: itemPlan.lotNumber || '',
        });
        if (has(diffQuantityByKey, key)) {
          itemPlan.planQuantity = plus(
            itemPlan.planQuantity,
            diffQuantityByKey[key],
          );
          diffQuantityByKey[key] = 0;
        }
      });
    }

    const requestCreateOrUpdateItemPlanning =
      new CreateItemPlanningQuantitiesRequestDto();
    requestCreateOrUpdateItemPlanning.items = [
      ...saleOrderExportPlanning,
      ...itemPlanningWarehouseExportProposal,
    ];
    const response = await this.itemService.createItemPlanningQuantities(
      requestCreateOrUpdateItemPlanning,
    );
    return response;
  }

  /**
   *
   * @param saleOrderExportEntity
   * @param status
   * @returns
   */
  private async setPurchasedOrderStatus(
    saleOrderExportEntity: SaleOrderExport,
    status: number,
    approver?: number,
    userId?: number,
  ): Promise<any> {
    saleOrderExportEntity.status = status;
    saleOrderExportEntity.approverId = approver;
    saleOrderExportEntity.approvedAt = new Date(Date.now());
    await this.saleOrderExportRepository.create(saleOrderExportEntity);

    if (status === OrderStatusEnum.Exported) {
      this.eventEmitter.emit(
        'order.updateActualQuantity',
        new OrderUpdateActualQuantityEvent({
          id: saleOrderExportEntity.id,
          orderType: OrderTypeEnum.SO,
        }),
      );
    }

    const response = plainToInstance(
      SaleOrderExportResponseDto,
      saleOrderExportEntity,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  async getSaleOrderExports(
    request: GetAllSOExportRequest,
  ): Promise<ResponsePayload<any>> {
    try {
      const data = await this.saleOrderExportRepository.findWithRelations({
        relations: ['saleOrderExportWarehouseDetails', 'customer'],
        where: {
          status: In(request.status),
        },
      });

      const dataReturn = plainToInstance(SaleOrderExportListResponse, data, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.messgae || error)
        .build();
    }
  }

  async checkItemHasExistOnSaleOrderExport(
    request: GetByItemIdRequestDto,
  ): Promise<any> {
    return await this.saleOrderExportDetailRepository.findOneByCondition(
      request,
    );
  }

  async getSaleOrderExportByWarehouse(
    request: GetOrderByWarehouseItemRequestDto,
  ): Promise<any> {
    const { id, warehouseId } = request;
    const data = await this.saleOrderExportRepository.getDetailByWarehouseId(
      id,
      [warehouseId],
    );
    if (!isEmpty(data)) {
      data.warehouse = await this.warehouseService.getWarehouses([warehouseId]);
    }
    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async updateSaleOrderExportWarehouseQcQuantity(
    request: UpdateSaleOrderWarehouseQcQuantityDto,
  ): Promise<any> {
    const {
      saleOrderExportId,
      warehouseId,
      itemId,
      qcPassQuantity,
      qcRejectQuantity,
      userId,
      lotNumber,
      mfg,
    } = request;
    try {
      const saleOrderWarehouseDetail =
        await this.saleOrderExportWarehouseDetailRepository.findOneWithRelations(
          {
            where: {
              saleOrderExportId,
              warehouseId,
              itemId,
            },
            relations: ['saleOrderExport'],
          },
        );

      const saleOrderWarehouseLot =
        await this.saleOrderExportWarehouseLotRepository.findOneWithRelations({
          where: {
            saleOrderExportId: saleOrderExportId,
            warehouseId: warehouseId,
            itemId: itemId,
            lotNumber: ILike(lotNumber),
          },
        });

      if (!saleOrderWarehouseDetail) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate(
              'error.SALE_ORDER_WAREHOUSE_DETAIL_NOT_FOUND',
            ),
          )
          .build();
      }
      if (!saleOrderWarehouseLot) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate(
              'error.SALE_ORDER_WAREHOUSE_DETAIL_NOT_FOUND',
            ),
          )
          .build();
      }
      const { saleOrderExport } = saleOrderWarehouseDetail;
      if (!saleOrderExport) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.SALE_ORDER_EXPORT_NOT_FOUND'),
          )
          .build();
      }

      if (!STATUS_TO_QC_ORDER.includes(saleOrderExport.status)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.SALE_ORDER_EXPORT_STATUS_INVALID'),
          )
          .build();
      }

      if (qcPassQuantity < 0 || qcRejectQuantity < 0) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.QUANTITY_INVALID'))
          .build();
      }
      if (
        plus(qcPassQuantity, qcRejectQuantity) >
        saleOrderWarehouseDetail.quantity
      ) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.QUANTITY_INVALID'))
          .build();
      }
      if (qcRejectQuantity > 0) {
        const currentManufacturingOrders =
          await this.produceService.getMOBySaleOrderId(
            saleOrderExport.saleOrderId,
          );

        const mo: any = first(currentManufacturingOrders);

        if (mo) {
          await this.createMoForSoExpRejectQuantity(
            saleOrderWarehouseDetail,
            qcRejectQuantity,
            userId,
            mo.factoryId,
          );
        }

        // if (moResponse.statusCode !== ResponseCodeEnum.SUCCESS)
        //   return new ResponseBuilder()
        //     .withCode(ResponseCodeEnum.BAD_REQUEST)
        //     .withMessage(moResponse.message)
        //     .build();
      }

      saleOrderWarehouseLot.qcPassQuantity = plus(
        saleOrderWarehouseLot.qcPassQuantity || 0,
        qcPassQuantity,
      );
      saleOrderWarehouseLot.qcRejectQuantity = plus(
        saleOrderWarehouseLot.qcRejectQuantity || 0,
        qcRejectQuantity,
      );

      await this.saleOrderExportWarehouseLotRepository.create(
        saleOrderWarehouseLot,
      );

      return await this.setSaleOrderExportWarehouseQcQuantity(
        saleOrderWarehouseDetail,
        qcPassQuantity,
        qcRejectQuantity,
      );
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error)
        .build();
    }
  }

  public async getListLotNumberByItemId(
    itemIds: number[],
  ): Promise<ResponsePayload<any>> {
    const [lotNumberOfPoimp, lotNumberOfPro] = await Promise.all([
      this.purchasedOrderImportWarehouseLotRepository.getListLotNumber(itemIds),
      this.productionOrderWarehouseLotRepository.getListLotNumber(itemIds),
    ]);

    const arrLotNumber = [...lotNumberOfPoimp, ...lotNumberOfPro];
    const result = arrLotNumber.reduce((record, item) => {
      const temp = record.find((x) => x.itemId === item.itemId);
      if (!temp) {
        record.push({
          itemId: item.itemId,
          lotNumbers: [item],
        });
      } else {
        temp.lotNumbers.push(item);
      }
      return record;
    }, []);
    const dataReturn = plainToInstance(LotNumberOfItemResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param saleOrderExportWarehouseDetails
   * @param qcPassQuantity
   * @param qcRejectQuantity
   * @returns
   */
  private async setSaleOrderExportWarehouseQcQuantity(
    saleOrderExportWarehouseDetails: SaleOrderExportWarehouseDetail,
    qcPassQuantity: number,
    qcRejectQuantity: number,
  ): Promise<any> {
    saleOrderExportWarehouseDetails.qcPassQuantity = plus(
      +saleOrderExportWarehouseDetails.qcPassQuantity,
      qcPassQuantity,
    );
    saleOrderExportWarehouseDetails.qcRejectQuantity = plus(
      +saleOrderExportWarehouseDetails.qcRejectQuantity,
      qcRejectQuantity,
    );
    saleOrderExportWarehouseDetails.errorQuantity = plus(
      +saleOrderExportWarehouseDetails.errorQuantity,
      qcRejectQuantity,
    );
    await this.saleOrderExportWarehouseDetailRepository.create(
      saleOrderExportWarehouseDetails,
    );

    const response = plainToInstance(
      SaleOrderExportWarehouseDetailResponseDto,
      saleOrderExportWarehouseDetails,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  private async getSOExpExtraInfo(
    saleOrderExportId: number,
    itemIds: number[],
    warehouseIds: number[],
    userIds: number[],
    businessTypeId: number,
    departmentReceiptId: number,
    itemLots: any[],
  ): Promise<any> {
    const data = await Promise.all([
      itemIds.length > 0 ? this.itemService.getItems(itemIds) : [],
      warehouseIds.length > 0
        ? this.warehouseService.getWarehouses(warehouseIds)
        : [],
      userIds.length > 0 ? this.userService.getUsers(userIds) : [],
      this.warehouseService.getBusinessTypeDetail(
        businessTypeId,
        saleOrderExportId,
        OrderTypeEnum.SO,
      ),
      this.userService.getDepartmentReceiptById(departmentReceiptId),
      this.itemService.getItemStockWarehousePrices({
        conditions: itemLots,
      }),
    ]);

    return {
      items: data[0],
      warehouses: data[1],
      users: data[2],
      businessType: data[3],
      departmentReceipt: data[4],
      itemStockWarehousePrices: data[5],
    };
  }

  private async createMoForSoExpRejectQuantity(
    saleOrderWarehouseDetail: SaleOrderExportWarehouseDetail,
    qcRejectQuantity,
    userId,
    factoryId?,
  ) {
    const warehouse = await this.warehouseService.getDetailById(
      saleOrderWarehouseDetail.warehouseId,
    );
    const data = plainToInstance(
      CreateMoForQcRejectQuantity,
      {
        ...saleOrderWarehouseDetail,
        ...warehouse,
        ...saleOrderWarehouseDetail.saleOrderExport,
        qcRejectQuantity,
        userId,
        factoryId,
      },
      {
        excludeExtraneousValues: true,
      },
    );
    return await this.produceService.createMoForQcReject(data, true);
  }

  async getListItemIdByQcStageId(payload: any): Promise<any> {
    const { qcStageId } = payload;

    let data: any;
    if (qcStageId === QC_STAGE_ID.INPUT_WAREHOUSE_BY_PO) {
      data =
        await this.purchasedOrderWarehouseDetailRepository.getListItemIdByQcStageId(
          OrderWarehouseActionTypeEnum.IMPORT,
        );
    }
    if (qcStageId === QC_STAGE_ID.INPUT_WAREHOUSE_BY_PRO) {
      data =
        await this.productionOrderWarehouseDetailRepository.getListItemIdByQcStageId(
          OrderWarehouseActionTypeEnum.IMPORT,
        );
    }
    if (qcStageId === QC_STAGE_ID.OUTPUT_WAREHOUSE_BY_PRO) {
      data =
        await this.productionOrderWarehouseDetailRepository.getListItemIdByQcStageId(
          OrderWarehouseActionTypeEnum.EXPORT,
        );
    }
    if (qcStageId === QC_STAGE_ID.OUTPUT_WAREHOUSE_BY_SO) {
      data =
        await this.saleOrderExportWarehouseDetailRepository.getListItemIdByQcStageId(
          OrderWarehouseActionTypeEnum.EXPORT,
        );
    }
    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  async confirmExported(
    payload: SaleOrderExportConfirmExportRequestDto,
  ): Promise<any> {
    const { id, userId } = payload;

    const saleOrderExport =
      await this.saleOrderExportRepository.findOneWithRelations({
        where: {
          id,
        },
        // relations: ['saleOrderExportDetails'],
      });
    if (!saleOrderExport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (saleOrderExport.status !== OrderStatusEnum.Collected)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.SALE_ORDER_EXPORT_STATUS_INVALID'),
        )
        .build();

    return await this.setPurchasedOrderStatus(
      saleOrderExport,
      OrderStatusEnum.Exported,
      userId,
    );
  }

  async updateCollectedQuantity(
    payload: UpdateCollectedQuantityRequestDto,
  ): Promise<any> {
    const { orderId, orderDetails, warehouseOrderDetails, itemLots } = payload;
    let message;
    let code = ResponseCodeEnum.SUCCESS;
    const saleOrderExport =
      await this.saleOrderExportRepository.findOneWithRelations({
        where: {
          id: orderId,
        },
        relations: ['saleOrderExportWarehouseLots'],
      });
    const saleOrderExportWarehouseLotEntities =
      saleOrderExport.saleOrderExportWarehouseLots;

    const itemLotMap = keyBy(
      itemLots,
      (item) =>
        `${item.itemId}_${item.warehouseId}_${
          item.lotNumber?.toUpperCase() || ''
        }`,
    );

    saleOrderExportWarehouseLotEntities.forEach(
      (
        saleOrderExportWarehouseLotEntity: SaleOrderExportWarehouseLotEntity,
      ) => {
        let itemLot =
          itemLotMap[
            `${saleOrderExportWarehouseLotEntity.itemId}_${
              saleOrderExportWarehouseLotEntity.warehouseId
            }_${
              saleOrderExportWarehouseLotEntity.lotNumber?.toUpperCase() || ''
            }`
          ];
        if (
          saleOrderExportWarehouseLotEntity.lotNumber &&
          itemLot?.lotNumber?.toUpperCase() !==
            saleOrderExportWarehouseLotEntity.lotNumber.toUpperCase()
        ) {
          itemLot = undefined;
        }

        if (itemLot) {
          saleOrderExportWarehouseLotEntity.collectedQuantity = plus(
            saleOrderExportWarehouseLotEntity.collectedQuantity,
            itemLot.quantity,
          );
        }
      },
    );

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const updateSaleOrderExportDetailEntities =
        await this.saleOrderExportDetailRepository.getUpdateOrderDetailCollectedQuantityByIds(
          orderId,
          orderDetails,
        );

      const updateSaleOrderExportWarehouseDetailEntities =
        await this.saleOrderExportWarehouseDetailRepository.getUpdateOrderWarehouseDetailCollectedQuantityByIds(
          orderId,
          warehouseOrderDetails,
        );
      saleOrderExport.status = OrderStatusEnum.InCollecting;
      await queryRunner.manager.save(saleOrderExport);
      await queryRunner.manager.save(updateSaleOrderExportDetailEntities);
      await queryRunner.manager.save(saleOrderExportWarehouseLotEntities);
      await queryRunner.manager.save(
        updateSaleOrderExportWarehouseDetailEntities,
      );
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      message = error;
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
    }
    await queryRunner.release();

    this.eventEmitter.emit(
      'order.updateCollectedQuantity',
      new OrderUpdateCollectedQuantityEvent({
        id: orderId,
        orderType: OrderTypeEnum.SO,
      }),
    );
    this.eventEmitter.emit(EventSyncSoExportEnum.Update, saleOrderExport.id);
    return new ResponseBuilder()
      .withCode(code)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }
  private async getListUserByRoles(userRoleSettings: any[]): Promise<any> {
    const listCode = uniq(map(flatMap(userRoleSettings), 'code'));
    if (listCode.find((c) => c !== ROLE.EMPLOYEE)) {
      const listUserRoles = await this.userService.getUsersByRoleCodes([
        ROLE.EMPLOYEE,
      ]);
      return uniq(map(flatMap(listUserRoles, 'userId')));
    }
  }

  public async suggestCollectedByOrderId(
    request: SuggestCollectedOrderExportRequestDto,
  ): Promise<any> {
    const { id, items, locatorIds } = request;
    const order = await this.saleOrderExportRepository.findOneWithRelations({
      where: {
        id,
      },
      relations: [
        'saleOrderExportWarehouseLots',
        'saleOrderExportDetails',
        'customer',
      ],
    });

    if (isEmpty(order) || isEmpty(order.saleOrderExportWarehouseLots)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const checkItemsExist = items.filter(
      (item) =>
        !map(order.saleOrderExportWarehouseLots, 'itemId').includes(
          item.itemId,
        ),
    );

    if (!isEmpty(checkItemsExist)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    const warehouseIds = map(order.saleOrderExportWarehouseLots, 'warehouseId');
    const requestSuggest =
      new SuggestExportItemToWarehouseShelfFloorRequestDto();
    requestSuggest.warehouseId = first(warehouseIds);
    requestSuggest.locatorIds = locatorIds;
    requestSuggest.orderId = order.id;
    requestSuggest.orderType = OrderTypeEnum.SO;
    requestSuggest.items = items.map((item) => {
      const firstLot = first(item.lots);
      return {
        quantity: item.quantity || sumBy(item.lots, 'quantity'),
        itemId: item.itemId,
        lots: firstLot?.lotNumber ? item.lots : [],
      };
    });

    const suggestStored =
      await this.warehouseService.suggestItemExportToWarehouseShelfFloor(
        requestSuggest,
      );
    const orderItemLotsSerialize = keyBy(
      order.saleOrderExportWarehouseLots,
      (lot) => `${lot.lotNumber || ''}-${lot.itemId}`,
    );
    const orderItemSerialize = keyBy(order.saleOrderExportDetails, 'itemId');
    if (isEmpty(suggestStored)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }
    const itemsSuggest = {};
    suggestStored.forEach((suggest) => {
      const itemId = suggest.itemId;
      const keyOrderItem = `${suggest.lotNumber || ''}-${suggest.itemId}`;
      if (!has(itemsSuggest, itemId)) {
        itemsSuggest[itemId] = {
          itemId: itemId,
          name: suggest.item.name,
          code: suggest.item.code,
          actualQuantity: 0,
          planQuantity: 0,
          collectedQuantity: 0,
          remainQuantity: 0,
          locations: {},
        };
      }

      itemsSuggest[itemId].actualQuantity =
        orderItemSerialize[itemId]?.actualQuantity;

      itemsSuggest[itemId].planQuantity = orderItemSerialize[itemId]?.quantity;

      itemsSuggest[itemId].collectedQuantity = plus(
        itemsSuggest[itemId].collectedQuantity,
        suggest.quantity,
      );

      itemsSuggest[itemId].remainQuantity =
        minus(
          orderItemSerialize[itemId]?.quantity || 0,
          orderItemSerialize[itemId]?.collectedQuantity || 0,
        ) || 0;
      if (!has(itemsSuggest[itemId].locations, suggest.locatorId)) {
        itemsSuggest[itemId].locations[suggest.locatorId] = {
          id: suggest?.locator.locatorId,
          locationName: suggest?.locator?.name,
          code: suggest?.locator?.code,
          collectedQuantity: 0,
          lots: [],
        };
      }
      itemsSuggest[itemId].locations[suggest.locatorId].lots.push({
        collectedQuantity: suggest.quantity,
        stockQuantity: suggest?.stockQuantity,
        lotNumber: suggest.lotNumber || null,
        actualQuantity:
          orderItemLotsSerialize[keyOrderItem]?.actualQuantity || 0,
        planQuantity: orderItemLotsSerialize[keyOrderItem]?.quantity || 0,
        remainQuantity:
          minus(
            orderItemLotsSerialize[keyOrderItem]?.quantity || 0,
            orderItemLotsSerialize[keyOrderItem]?.collectedQuantity || 0,
          ) || 0,
      });
      itemsSuggest[itemId].locations[suggest.locatorId].collectedQuantity =
        plus(
          itemsSuggest[itemId].locations[suggest.locatorId].collectedQuantity,
          suggest.quantity,
        );
    });

    const dataReturn = [];
    Object.keys(itemsSuggest).forEach((itemIndex) => {
      const item = itemsSuggest[itemIndex];
      dataReturn.push({
        ...item,
        locations: values(item.locations),
      });
    });
    const warehouse = await this.warehouseService.getDetailById(
      first(order.saleOrderExportWarehouseLots)?.warehouseId,
    );
    const warehouseName = warehouse?.name;

    const response = plainToInstance(
      SuggestCollectSaleOrderExportResponseDto,
      {
        ...order,
        customerName: order?.customer?.name,
        warehouseName,
        items: dataReturn,
      },
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getSuggestCollectedBySoExportId(
    request: GetSuggestStoredBySoExportIdRequestDto,
  ): Promise<any> {
    const { soExportId, itemIds } = request;
    const itemLots =
      await this.saleOrderExportWarehouseLotRepository.getItemLotsBySoExportId(
        soExportId,
        itemIds,
      );
    if (isEmpty(itemLots)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.ITEM_NOT_IN_ORDER'))
        .build();
    }

    const invalidQuantity = flatMap(map(itemLots, 'lots')).find(
      (lot) => Number(lot.quantity) <= 0,
    );

    if (!isEmpty(invalidQuantity)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.ITEM_HAS_BEEN_COLLECTED'))
        .build();
    }

    const suggestCollectedRequest = new SuggestCollectedOrderExportRequestDto();
    suggestCollectedRequest.id = soExportId;
    suggestCollectedRequest.items = itemLots;
    return await this.suggestCollectedByOrderId(suggestCollectedRequest);
  }

  async suggestReturnsByOrderId(
    request: SuggestCollectedOrderExportRequestDto,
  ): Promise<any> {
    const { id, items, locatorIds } = request;
    const order = await this.saleOrderExportRepository.findOneWithRelations({
      where: {
        id,
      },
      relations: ['saleOrderExportWarehouseLots', 'customer'],
    });
    if (isEmpty(order)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    let itemStocks = [];
    const requestSuggestImport =
      new SuggestImportItemToWarehouseShelfFloorRequestDto();
    if (!isEmpty(items)) {
      requestSuggestImport.locatorIds = locatorIds;
      itemStocks = items?.map((item) => {
        return {
          ...item,
          quantity: sumBy(item.lots, 'quantity'),
        };
      });
    } else {
      itemStocks = await this.buildItemsReturnByOrderId(order.id);
    }
    requestSuggestImport.warehouseId = first(
      order.saleOrderExportWarehouseLots,
    ).warehouseId;
    requestSuggestImport.items = itemStocks;

    const suggest =
      await this.warehouseService.suggestItemImportToWarehouseShelfFloor(
        requestSuggestImport,
      );
    const itemsSuggest = {};
    const serializeItemLot = keyBy(order.saleOrderExportWarehouseLots, (lot) =>
      [lot.itemId, lot.lotNumber.toUpperCase()].join('-'),
    );
    const groupItemLotByItemId = groupBy(
      order.saleOrderExportWarehouseLots,
      'itemId',
    );
    suggest?.data?.forEach((suggest) => {
      const itemId = suggest.itemId;
      if (!has(itemsSuggest, itemId)) {
        itemsSuggest[itemId] = {
          itemId: itemId,
          name: suggest.name,
          code: suggest.code,
          details: suggest?.details,
          locations: [],
          quantity: 0,
          planQuantity: has(groupItemLotByItemId, itemId)
            ? sumBy(groupItemLotByItemId[itemId], 'collectedQuantity')
            : 0,
        };
      }

      suggest.positions.forEach((position) => {
        const lots = position.lots.map((lot) => {
          const keyItemLot = [itemId, lot.lotNumber.toUpperCase()].join('-');
          return {
            ...lot,
            planQuantity: serializeItemLot[keyItemLot]?.collectedQuantity ?? 0,
          };
        });
        itemsSuggest[itemId].locations.push({
          warehouseShelfFloorId: position.warehouseShelfFloor?.id,
          locationName: `${position?.warehouseShelfFloor?.warehouse?.name}-${position?.warehouseShelfFloor?.warehouseShelf?.warehouseSector?.name}-${position?.warehouseShelfFloor?.warehouseShelf?.name}-${position?.warehouseShelfFloor?.name}`,
          lots: lots,
        });
        itemsSuggest[itemId].quantity = plus(
          itemsSuggest[itemId].quantity,
          sumBy(lots, 'quantity'),
        );
      });
    });

    let warehouseName;
    if (!warehouseName) {
      const warehouse = await this.warehouseService.getDetailById(
        first(order.saleOrderExportWarehouseLots)?.warehouseId,
      );
      warehouseName = warehouse?.name;
    }

    const response = {
      ...plainToInstance(SaleOrderExportResponseDto, order, {
        excludeExtraneousValues: true,
      }),
      customerName: order?.customer?.name,
      warehouseName,
      items: values(itemsSuggest),
    };
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async buildItemsReturnByOrderId(orderId: number): Promise<any> {
    const warehouseStockMovements =
      await this.warehouseService.getWarehouseStockMovementByOrderId(
        orderId,
        WarehouseMovementTypeEnum.SO_EXPORT,
      );
    const itemStockMovements = flatMap(
      map(warehouseStockMovements, 'itemStockMovements'),
    );
    const itemsReturn = {};
    itemStockMovements.forEach((itemStockMovement) => {
      const itemId = itemStockMovement.itemId;
      const lotNumber = itemStockMovement.lotNumber.toUpperCase();
      const warehouseShelfFloorId = itemStockMovement.warehouseShelfFloorId;
      const key = `${warehouseShelfFloorId}-${lotNumber}`;
      if (!has(itemsReturn, itemId)) {
        itemsReturn[itemId] = {
          itemId: itemId,
          lots: {},
        };
      }
      const lot = {
        lotNumber: lotNumber,
        quantity: +itemStockMovement.quantity,
        warehouseShelfFloorId: warehouseShelfFloorId,
      };
      if (has(itemsReturn[itemId]['lots'], key)) {
        lot.quantity = plus(
          lot.quantity,
          itemsReturn[itemId]['lots'][key].quantity,
        );
      }
      itemsReturn[itemId]['lots'][key] = lot;
    });
    const response = values(itemsReturn).map((item: any) => {
      const lots = values(item.lots);
      return {
        ...item,
        quantity: sumBy(lots, 'quantity'),
        lots: lots,
      };
    });
    return response;
  }

  async getErrorItemsByOrder(
    request: GetErrorItemByOrderRequestDto,
  ): Promise<any> {
    const data =
      await this.saleOrderExportWarehouseDetailRepository.getErrorItemById(
        request.id,
      );
    const res = plainToInstance(ErrorItem, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(res)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async exportDeliveryTicket(request: GetOrderDetailRequestDto): Promise<any> {
    const { data } = await this.getDetail(request);
    if (!data) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    let attributeDetailValues: any = {};
    if (!isEmpty(data.attributes)) {
      const attributeGroup = groupBy(data.attributes, 'tableName');
      const payload = new GetAttributeDetailValuesRequestDto();
      const attributeKeys = Object.keys(attributeGroup).filter(
        (el) => !el.match('null'),
      );
      payload.filter = attributeKeys.map((key) => {
        return {
          tableName: key,
          id: map(attributeGroup[key], 'value').join(','),
        };
      });
      attributeDetailValues =
        await this.warehouseService?.getAttributeDetailValuesTcp(payload);
    }
    const signatures = await this.settingService.getListSignature(
      typeTicket.EXPORT_DELIVERY_RECORD,
    );
    const hasLot =
      data?.warehouse?.manageByLot === WarehouseByLotManagementEnum.LOT;
    const companyDefault = await this.userService.getCompanyDefault();
    const addressProvince = getProvince(companyDefault?.address ?? '') ?? '';
    const nameCompany = companyDefault?.name ?? '';
    const addressCompany = companyDefault?.address ?? '';
    let widthRole = 0;
    let signatureRole: any = new Paragraph({});
    let signatureBottom: any = new Paragraph({});

    if (!isEmpty(signatures)) {
      widthRole = 14 / signatures.length;
      signatureRole = new Table({
        width: setWidth(WORD_FILE_CONFIG.TABLE_WIDTH_PAGE_A35),
        borders: wordFileStyle.border_none,
        rows: [
          new TableRow({
            children: [
              ...signatures.map((item) => {
                if (item.name.includes('\n')) {
                  return new TableCell({
                    width: setWidth(widthRole),
                    children: [
                      new Paragraph({
                        alignment: AlignmentType.CENTER,
                        children: [
                          new TextRun({
                            text: item.name.split('\n')[0],
                            ...wordFileStyle.text_style_bold,
                            allCaps: true,
                          }),
                        ],
                      }),
                      new Paragraph({
                        alignment: AlignmentType.CENTER,
                        children: [
                          new TextRun({
                            text: item.name.split('\n')[1],
                            ...wordFileStyle.text_style_bold,
                            allCaps: true,
                          }),
                        ],
                      }),
                    ],
                    borders: wordFileStyle.border_none,
                    verticalAlign: VerticalAlign.CENTER,
                  });
                }
                return new TableCell({
                  width: setWidth(widthRole),
                  children: [
                    new Paragraph({
                      alignment: AlignmentType.CENTER,
                      children: [
                        new TextRun({
                          text: item.name,
                          ...wordFileStyle.text_style_bold,
                          allCaps: true,
                        }),
                      ],
                    }),
                  ],
                  borders: wordFileStyle.border_none,
                  verticalAlign: VerticalAlign.CENTER,
                });
              }),
            ],
          }),
        ],
      });

      signatureBottom = new Table({
        rows: [
          new TableRow({
            children: [
              ...signatures.map((item) => {
                return new TableCell({
                  width: setWidth(widthRole),
                  children: [
                    new Paragraph({
                      alignment: AlignmentType.CENTER,
                      children: [
                        new TextRun({
                          text: item.signature,
                          ...wordFileStyle.text_style_signature_bold,
                        }),
                      ],
                    }),
                  ],
                  borders: wordFileStyle.border_none,
                  verticalAlign: VerticalAlign.CENTER,
                });
              }),
            ],
          }),
        ],
      });
    }
    const warehouseExport = await this.i18n.translate(`export.warehouseExport`);
    const nameFile =
      `${warehouseExport.nameFilePrefix}` + `${data.code ?? ''}.docx`;
    const header = warehouseExport.item;
    const createdAt = Moment(data.receiptDate ?? '').format('DD/MM/YYYY');
    const date = this.i18n.translate('export.warehouseExport.date');
    const warehouseCode = data?.warehouse?.code
      ? `${data?.warehouse?.code}`
      : '';
    const warehouseName = data?.warehouse?.name
      ? `${data?.warehouse?.name}`
      : '';
    const reasonCode = data?.reason?.code ? '.' + data?.reason?.code : '';
    const title = warehouseExport.title;
    let number = '' + warehouseExport.prefixNumber;
    let exportTicket = '' + warehouseExport.prefixExportTicket;
    if (isEmpty(warehouseCode)) {
      exportTicket += `${warehouseCode}` + reasonCode;
      number += `${warehouseCode}` + reasonCode;
    } else {
      exportTicket += '.' + `${warehouseCode}` + reasonCode;
      number += '.' + `${warehouseCode}` + reasonCode;
    }
    const ebsId = data?.ebsId ?? '';
    const transactionNumberCreated = data?.transactionNumberCreated ?? '';
    if (!isEmpty(ebsId)) {
      number = '' + transactionNumberCreated;
      exportTicket = '' + ebsId;
    }
    const receiptName = data?.receiver ?? '';
    const reason = data?.reason?.name ?? '';
    const explanation = data?.explaination ?? '';
    const departmentAddress = data?.departmentReceipt?.name ?? '';
    let construction = '';
    const constructionCode = attributeDetailValues?.constructions?.[0]?.code;
    const constructionName = attributeDetailValues?.constructions?.[0]?.name;
    if (isEmpty(constructionCode) && isEmpty(constructionName)) {
      construction = '';
    } else {
      construction =
        attributeDetailValues?.constructions?.[0]?.code +
        '-' +
        attributeDetailValues?.constructions?.[0]?.name;
    }
    const category =
      attributeDetailValues?.category_constructions?.[0]?.code ?? '';
    let exportWarehouse = '' + warehouseCode;
    if (!isEmpty(warehouseName)) {
      exportWarehouse += '-' + data.warehouse?.name;
    }
    let total = 0;
    let intoMoney = 0;
    let item: any = {};
    const saleOrderExportDetailMap = keyBy(
      data?.saleOrderExportDetails,
      'itemId',
    );
    const itemsSync = keyBy(data?.itemsSync, 'id');
    const itemData = data?.saleOrderExportWarehouseLots?.map((el, index) => {
      item = el.item ?? {};
      if (data?.status !== OrderStatusEnum.Completed) {
        el.price = '0';
        el.amount = '0';
      }
      intoMoney = mul(el.actualQuantity ?? 0, item.price ?? 0);
      const amountFormated = Math.round(el?.amount || 0);
      total = plus(total, Number(amountFormated));
      const requestedQuantityWarehouseExportProposal =
        itemsSync[el?.itemId]?.quantity;
      const actualQuantity = itemsSync[el?.itemId]?.actualQuantity;
      let creditAccount =
        itemsSync[el?.itemId]?.creditAccount ||
        el.creditAccount ||
        itemsSync[el?.itemId]?.items?.itemWarehouseSources?.find(
          (item) => item?.warehouseId === data?.warehouseId,
        )?.accounting ||
        '';
      let debitAccount =
        saleOrderExportDetailMap[el?.itemId]?.debitAccount ||
        el?.debitAccount ||
        '';
      if (creditAccount?.length == LENGTH_ACCOUNT_SYNC_EBS)
        creditAccount = creditAccount
          .slice(18, 29)
          .replace(/^(\d*?[1-9])0+$/, '$1');
      if (debitAccount?.length == LENGTH_ACCOUNT_SYNC_EBS)
        debitAccount = debitAccount.slice(18, 43);
      const num = index + 1;
      if (hasLot) {
        return {
          stt: `${num}`,
          itemCode: item.code ?? '',
          itemName: item.name ?? '',
          lotNumber: el.lotNumber ?? '',
          itemUnit: item?.itemUnit ?? '',
          requestedQuantity:
            formatNumber(requestedQuantityWarehouseExportProposal, 2) ?? '0,00',
          actual: formatNumber(actualQuantity, 2) ?? '0,00',
          price: formatNumber(el?.price, 2) ?? '0,00',
          intoMoney: formatNumber(amountFormated) || '0',
          debit: debitAccount ?? '',
          own: creditAccount ?? '',
        };
      } else {
        return {
          stt: `${num}`,
          itemCode: item.code ?? '',
          itemName: item.name ?? '',
          itemUnit: item?.itemUnit ?? '',
          requestedQuantity:
            formatNumber(requestedQuantityWarehouseExportProposal, 2) ?? '0,00',
          actual: formatNumber(actualQuantity, 2) ?? '0,00',
          price: formatNumber(el?.price, 2) ?? '0,00',
          intoMoney: formatNumber(amountFormated) || '0',
          debit: debitAccount ?? '',
          own: creditAccount ?? '',
        };
      }
    });
    while (itemData.length < 10) {
      const num = itemData.length + 1;
      if (hasLot) {
        itemData.push({
          stt: `${num}`,
          itemCode: '',
          itemName: '',
          lotNumber: '',
          itemUnit: '',
          requestedQuantity: '',
          actual: '',
          price: '',
          intoMoney: '',
          debit: '',
          own: '',
        });
      } else {
        itemData.push({
          stt: `${num}`,
          itemCode: '',
          itemName: '',
          itemUnit: '',
          requestedQuantity: '',
          actual: '',
          price: '',
          intoMoney: '',
          debit: '',
          own: '',
        });
      }
    }
    let itemTableHeader = DELIVERY_TICKET_ITEMS as any;
    if (hasLot) {
      itemTableHeader = [
        ...DELIVERY_TICKET_ITEMS.slice(0, 3),
        LOT_NUMBER_COLUMN,
        ...DELIVERY_TICKET_ITEMS.slice(3),
      ];
    }

    const docHeader = (nameTicket: string) => {
      return new Table({
        borders: wordFileStyle.border_none,
        rows: [
          new TableRow({
            children: [
              new TableCell({
                width: setWidth(5),
                children: [
                  new Paragraph({
                    style: 'formatSpacing',
                    alignment: AlignmentType.LEFT,
                    spacing: {
                      before: WORD_FILE_CONFIG.SPACING_BEFORE,
                    },
                    children: [
                      new TextRun({
                        text: nameCompany.toUpperCase(),
                        size: WORD_FILE_CONFIG.WORD_FONT_SIZE_10,
                        bold: WORD_FILE_CONFIG.WORD_BOLD,
                        font: FONT_NAME,
                        allCaps: true,
                      }),
                    ],
                  }),
                  new Paragraph(''),
                  new Paragraph({
                    style: 'formatSpacing',
                    alignment: AlignmentType.LEFT,
                    spacing: {
                      before: WORD_FILE_CONFIG.SPACING_BEFORE,
                    },
                    children: [
                      new TextRun({
                        text: addressCompany,
                        size: WORD_FILE_CONFIG.WORD_FONT_SIZE_10,
                        bold: WORD_FILE_CONFIG.WORD_BOLD,
                        font: FONT_NAME,
                      }),
                    ],
                  }),
                ],
                borders: wordFileStyle.border_none,
              }),
              new TableCell({
                width: setWidth(4),
                children: [
                  new Paragraph({
                    style: 'formatSpacing',
                    alignment: AlignmentType.CENTER,
                    spacing: {
                      before: WORD_FILE_CONFIG.SPACING_BEFORE,
                    },
                    children: [
                      new TextRun({
                        text: title,
                        size: WORD_FILE_CONFIG.WORD_FONT_SIZE_14,
                        bold: WORD_FILE_CONFIG.WORD_BOLD,
                        font: FONT_NAME,
                        allCaps: true,
                      }),
                    ],
                  }),
                  new Paragraph({
                    style: 'formatSpacing',
                    alignment: AlignmentType.CENTER,
                    spacing: {
                      before: WORD_FILE_CONFIG.SPACING_BEFORE,
                    },
                    children: [
                      new TextRun({
                        text: warehouseExport.createdAt,
                        size: WORD_FILE_CONFIG.WORD_FONT_SIZE_10_5,
                        font: FONT_NAME,
                      }),
                      new TextRun({
                        text: createdAt,
                        size: WORD_FILE_CONFIG.WORD_FONT_SIZE_10_5,
                        font: FONT_NAME,
                      }),
                    ],
                  }),
                  new Paragraph({
                    style: 'formatSpacing',
                    alignment: AlignmentType.CENTER,
                    spacing: {
                      before: WORD_FILE_CONFIG.SPACING_BEFORE,
                    },
                    children: [
                      new TextRun({
                        text: nameTicket,
                        size: WORD_FILE_CONFIG.WORD_FONT_SIZE_10_5,
                        font: FONT_NAME,
                      }),
                    ],
                  }),
                ],
                borders: wordFileStyle.border_none,
              }),
              new TableCell({
                width: setWidth(5),
                children: [
                  new Paragraph({
                    style: 'formatSpacing',
                    alignment: AlignmentType.CENTER,
                    spacing: {
                      before: WORD_FILE_CONFIG.SPACING_BEFORE,
                    },
                    children: [
                      new TextRun({
                        text: warehouseExport.number,
                        size: WORD_FILE_CONFIG.WORD_FONT_SIZE_10_5,
                        font: FONT_NAME,
                      }),
                      new TextRun({
                        text: number,
                        size: WORD_FILE_CONFIG.WORD_FONT_SIZE_10_5,
                        bold: WORD_FILE_CONFIG.WORD_BOLD,
                        font: FONT_NAME,
                      }),
                    ],
                  }),
                  new Paragraph({
                    style: 'formatSpacing',
                    alignment: AlignmentType.CENTER,
                    spacing: {
                      before: WORD_FILE_CONFIG.SPACING_BEFORE,
                    },
                    children: [
                      new TextRun({
                        text: '',
                      }),
                    ],
                  }),
                  new Paragraph({
                    style: 'formatSpacing',
                    alignment: AlignmentType.CENTER,
                    spacing: {
                      before: WORD_FILE_CONFIG.SPACING_BEFORE,
                    },
                    children: [
                      new TextRun({
                        text: '',
                      }),
                    ],
                  }),
                ],
                borders: wordFileStyle.border_none,
              }),
            ],
          }),
        ],
      });
    };

    const tableItems = new Table({
      width: setWidth(WORD_FILE_CONFIG.TABLE_WIDTH_PAGE_A35),
      rows: [
        new TableRow({
          tableHeader: true,
          height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
          children: itemTableHeader.map((item) => {
            return new TableCell({
              rowSpan: item.rowSpan || null,
              columnSpan: item.columnSpan || null,
              width: setWidth(item.width),
              verticalAlign: VerticalAlign.CENTER,
              children: [
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  children: [
                    new TextRun({
                      text: header[item.name] ?? '',
                      ...wordFileStyle.table_item_header_style,
                    }),
                  ],
                }),
              ],
            });
          }),
        }),
        new TableRow({
          tableHeader: true,
          height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
          children: itemTableHeader
            .filter((item) => item.child && item.child.length > 0)
            .map((item) => {
              return item.child.map((child) => {
                return new TableCell({
                  width: setWidth(child.width),
                  verticalAlign: VerticalAlign.CENTER,
                  children: [
                    new Paragraph({
                      alignment: AlignmentType.CENTER,
                      children: [
                        new TextRun({
                          text: header[child.name] ?? '',
                          ...wordFileStyle.table_item_header_style,
                        }),
                      ],
                    }),
                  ],
                });
              });
            })
            .flat(),
        }),
        ...itemData.map((item) => {
          const itemValue = Object.values(item);
          return new TableRow({
            height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
            children: [
              ...itemValue?.map((text: string, index: number) => {
                let mar = {};
                let alignmentText = AlignmentType.CENTER;
                if ((index != 0 && index < 3) || index > itemValue.length - 3) {
                  mar = wordFileStyle.margin_left;
                  alignmentText = AlignmentType.LEFT;
                } else if (index == 3 || index == 0 || index == 4) {
                  mar = {};
                  alignmentText = AlignmentType.CENTER;
                } else if (index < itemValue.length - 2) {
                  mar = wordFileStyle.margin_right;
                  alignmentText = AlignmentType.RIGHT;
                }
                return new TableCell({
                  columnSpan: null,
                  verticalAlign: VerticalAlign.CENTER,
                  borders: wordFileStyle.border_item,
                  margins: mar,
                  children: [
                    new Paragraph({
                      alignment: alignmentText,
                      children: [
                        new TextRun({
                          text,
                          ...wordFileStyle.text_style,
                        }),
                      ],
                    }),
                  ],
                });
              }),
            ],
          });
        }),
        new TableRow({
          height: setHeight(mul(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT, 2)),
          children: [
            new TableCell({
              width: setWidth(8.4),
              columnSpan: 8,
              margins: wordFileStyle.margin_right,
              children: [
                new Paragraph({
                  alignment: AlignmentType.RIGHT,
                  children: [
                    new TextRun({
                      text: warehouseExport.total,
                      ...wordFileStyle.table_header_style,
                    }),
                  ],
                }),
              ],
              verticalAlign: VerticalAlign.CENTER,
            }),
            new TableCell({
              width: setWidth(1.2),
              margins: wordFileStyle.margin_right,
              children: [
                new Paragraph({
                  alignment: AlignmentType.RIGHT,
                  children: [
                    new TextRun({
                      text: formatNumber(total.toString(), 2).split(',')[0],
                      ...wordFileStyle.table_header_style,
                    }),
                  ],
                }),
              ],
              verticalAlign: VerticalAlign.CENTER,
            }),
            new TableCell({
              width: setWidth(1.2),
              columnSpan: 2,
              children: [
                new Paragraph({
                  children: [new TextRun({})],
                }),
              ],
            }),
          ],
        }),
      ],
    });

    const bodyTables = new Table({
      width: setWidth(WORD_FILE_CONFIG.TABLE_WIDTH_PAGE_A35),
      rows: [
        new TableRow({
          height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
          children: [
            new TableCell({
              children: [
                new Paragraph({
                  indent: { left: WORD_FILE_CONFIG.INDENT_BODY },
                  children: [
                    new TextRun({
                      text: warehouseExport.receiptName,
                      ...wordFileStyle.text_size10_style,
                    }),
                    new TextRun({
                      text: receiptName,
                      ...wordFileStyle.text_size10_style_bold,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
              verticalAlign: VerticalAlign.CENTER,
            }),
            new TableCell({
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: warehouseExport.departmentAddress,
                      ...wordFileStyle.text_size10_style,
                    }),
                    new TextRun({
                      text: departmentAddress,
                      ...wordFileStyle.text_size10_style_bold,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
              verticalAlign: VerticalAlign.CENTER,
            }),
          ],
        }),
        new TableRow({
          height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
          children: [
            new TableCell({
              children: [
                new Paragraph({
                  indent: { left: WORD_FILE_CONFIG.INDENT_BODY },
                  children: [
                    new TextRun({
                      text: warehouseExport.reason,
                      ...wordFileStyle.text_size10_style,
                    }),
                    new TextRun({
                      text: reason,
                      ...wordFileStyle.text_size10_style_bold,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
              verticalAlign: VerticalAlign.CENTER,
            }),
            new TableCell({
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: warehouseExport.exportTicket,
                      ...wordFileStyle.text_size10_style,
                    }),
                    new TextRun({
                      text: exportTicket,
                      ...wordFileStyle.text_size10_style_bold,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
              verticalAlign: VerticalAlign.CENTER,
            }),
          ],
        }),
        new TableRow({
          height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
          children: [
            new TableCell({
              columnSpan: 2,
              children: [
                new Paragraph({
                  indent: { left: WORD_FILE_CONFIG.INDENT_BODY },
                  children: [
                    new TextRun({
                      text: warehouseExport.explanation,
                      ...wordFileStyle.text_size10_style,
                    }),
                    new TextRun({
                      text: explanation,
                      ...wordFileStyle.text_size10_style_bold,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
              verticalAlign: VerticalAlign.CENTER,
            }),
          ],
        }),
        new TableRow({
          height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
          children: [
            new TableCell({
              columnSpan: 2,
              children: [
                new Paragraph({
                  indent: { left: WORD_FILE_CONFIG.INDENT_BODY },
                  children: [
                    new TextRun({
                      text: warehouseExport.exportWarehouse,
                      ...wordFileStyle.text_size10_style,
                    }),
                    new TextRun({
                      text: exportWarehouse,
                      ...wordFileStyle.text_size10_style_bold,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
              verticalAlign: VerticalAlign.CENTER,
            }),
          ],
        }),
        new TableRow({
          height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
          children: [
            new TableCell({
              children: [
                new Paragraph({
                  indent: { left: WORD_FILE_CONFIG.INDENT_BODY },
                  children: [
                    new TextRun({
                      text: warehouseExport.construction,
                      ...wordFileStyle.text_size10_style,
                    }),
                    new TextRun({
                      text: construction,
                      ...wordFileStyle.text_size10_style_bold,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
              verticalAlign: VerticalAlign.CENTER,
            }),
            new TableCell({
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: warehouseExport.category,
                      ...wordFileStyle.text_size10_style,
                    }),
                    new TextRun({
                      text: category,
                      ...wordFileStyle.text_size10_style_bold,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
              verticalAlign: VerticalAlign.CENTER,
            }),
          ],
        }),
        new TableRow({
          height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
          children: [
            new TableCell({
              columnSpan: 2,
              children: [tableItems],
              borders: wordFileStyle.border_right_top,
            }),
          ],
        }),
      ],
    });

    const doc = new Document({
      styles: {
        paragraphStyles: [
          {
            id: 'formatSpacing',
            name: 'Format Spacing',
            basedOn: 'Normal',
            paragraph: {
              spacing: {
                after: 12,
              },
            },
          },
        ],
      },
      sections: [
        ...Object.values(warehouseExport.ticket).map((ticketNum: string) => {
          return {
            properties: {
              page: {
                size: wordFileStyle.pagesize_a35,
              },
            },
            children: [
              docHeader(ticketNum),
              new Paragraph({
                children: [],
              }),
              bodyTables,
              new Paragraph({
                spacing: { before: WORD_FILE_CONFIG.PADDING_TOP_TABLE },
                children: [
                  new TextRun({
                    text:
                      warehouseExport.textTotal + readDecimal(total.toString()),
                    ...wordFileStyle.text_style,
                  }),
                ],
              }),
              new Paragraph({
                alignment: AlignmentType.RIGHT,
                spacing: { after: WORD_FILE_CONFIG.BREAK_ONE_ROW },
                children: [
                  new TextRun({
                    text: addressProvince + date,
                    ...wordFileStyle.text_style,
                    font: FONT_NAME,
                    italics: WORD_FILE_CONFIG.WORD_ITALIC,
                  }),
                ],
              }),
              signatureRole,
              new Paragraph({
                children: [
                  new TextRun({
                    text: '',
                  }),
                ],
              }),

              new Paragraph({
                children: [
                  new TextRun({
                    text: '',
                  }),
                ],
              }),
              signatureBottom,
              new Paragraph({
                children: [new TextRun({ break: 4 })],
              }),
            ],
          };
        }),
      ],
    });
    const result = await Packer.toBuffer(doc);
    return { result, nameFile };
  }

  async exportSoExportTicket(request: GetOrderDetailRequestDto): Promise<any> {
    const { data } = await this.getDetail(request);
    if (!data) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    let attributeDetailValues: any = {};
    if (!isEmpty(data.attributes)) {
      const attributeGroup = groupBy(data.attributes, 'tableName');
      const payload = new GetAttributeDetailValuesRequestDto();
      const attributeKeys = Object.keys(attributeGroup).filter(
        (el) => !el.match('null'),
      );
      payload.filter = attributeKeys.map((key) => {
        return {
          tableName: key,
          id: map(attributeGroup[key], 'value').join(','),
        };
      });
      attributeDetailValues =
        await this.warehouseService?.getAttributeDetailValuesTcp(payload);
    }
    const signatures = await this.settingService.getListSignature(
      typeTicket.SALE_ORDER_EXPORT,
    );
    const companyDefault = await this.userService.getCompanyDefault();
    const addressProvince = getProvince(companyDefault?.address ?? '') ?? '';
    const nameCompany = companyDefault?.name ?? '';
    const addressCompany = companyDefault?.address ?? '';
    let widthRole = 0;
    let signatureRole: any = new Paragraph({});
    let signatureBottom: any = new Paragraph({});

    if (!isEmpty(signatures)) {
      widthRole = 14 / signatures.length;
      signatureRole = new Table({
        width: setWidth(WORD_FILE_CONFIG.TABLE_WIDTH_PAGE_A35),
        borders: wordFileStyle.border_none,
        rows: [
          new TableRow({
            children: [
              ...signatures.map((item) => {
                if (item.name.includes('\n')) {
                  return new TableCell({
                    width: setWidth(widthRole),
                    children: [
                      new Paragraph({
                        alignment: AlignmentType.CENTER,
                        children: [
                          new TextRun({
                            text: item.name.split('\n')[0],
                            ...wordFileStyle.text_style_bold,
                            allCaps: true,
                          }),
                        ],
                      }),
                      new Paragraph({
                        alignment: AlignmentType.CENTER,
                        children: [
                          new TextRun({
                            text: item.name.split('\n')[1],
                            ...wordFileStyle.text_style_bold,
                            allCaps: true,
                          }),
                        ],
                      }),
                    ],
                    borders: wordFileStyle.border_none,
                    verticalAlign: VerticalAlign.CENTER,
                  });
                }
                return new TableCell({
                  width: setWidth(widthRole),
                  children: [
                    new Paragraph({
                      alignment: AlignmentType.CENTER,
                      children: [
                        new TextRun({
                          text: item.name,
                          ...wordFileStyle.text_style_bold,
                          allCaps: true,
                        }),
                      ],
                    }),
                  ],
                  borders: wordFileStyle.border_none,
                  verticalAlign: VerticalAlign.CENTER,
                });
              }),
            ],
          }),
        ],
      });

      signatureBottom = new Table({
        rows: [
          new TableRow({
            children: [
              ...signatures.map((item) => {
                return new TableCell({
                  width: setWidth(widthRole),
                  children: [
                    new Paragraph({
                      alignment: AlignmentType.CENTER,
                      children: [
                        new TextRun({
                          text: item.signature,
                          ...wordFileStyle.text_style_signature_bold,
                        }),
                      ],
                    }),
                  ],
                  borders: wordFileStyle.border_none,
                  verticalAlign: VerticalAlign.CENTER,
                });
              }),
            ],
          }),
        ],
      });
    }
    const warehouseExport = await this.i18n.translate(`export.warehouseExport`);
    const nameFile =
      `${warehouseExport.nameFileSoExport}` + `${data.code ?? ''}.docx`;
    const header = warehouseExport.headerTableSoExport;
    const createdAt = Moment(data.receiptDate ?? '').format('DD/MM/YYYY');
    const date = this.i18n.translate('export.warehouseExport.date');
    const reasonCode = data?.reason?.code ? '.' + data?.reason?.code : '';
    const warehouseCode = data?.warehouse?.code
      ? `${data?.warehouse?.code}`
      : '';
    let exportTicket = '' + warehouseExport.prefixExportTicket;
    exportTicket = data?.warehouse?.code
      ? `${exportTicket}.${data?.warehouse?.code}${reasonCode}`
      : `${exportTicket + reasonCode}`;
    const warehouseName = data?.warehouse?.name
      ? `${data?.warehouse?.name}`
      : '';
    exportTicket = data?.ebsId ? `${data?.ebsId}` : exportTicket;
    const title = warehouseExport.titleSoExport;
    const receiptName = data?.receiver ?? '';
    const reason = data?.reason?.name ?? '';
    const explanation = data?.explaination ?? '';
    const departmentAddress = data?.departmentReceipt?.name ?? '';
    let construction = '';
    const constructionCode = attributeDetailValues?.constructions?.[0]?.code;
    const constructionName = attributeDetailValues?.constructions?.[0]?.name;
    if (isEmpty(constructionCode) && isEmpty(constructionName)) {
      construction = '';
    } else {
      construction =
        attributeDetailValues?.constructions?.[0]?.code +
        '-' +
        attributeDetailValues?.constructions?.[0]?.name;
    }
    const category =
      attributeDetailValues?.category_constructions?.[0]?.code ?? '';
    let exportWarehouse = '' + warehouseCode;
    if (!isEmpty(warehouseName)) {
      exportWarehouse += '-' + data.warehouse?.name;
    }
    let item: any = {};
    const itemsSync = keyBy(data?.itemsSync, 'id');
    const itemData = data?.saleOrderExportWarehouseLots?.map((el, index) => {
      item = el.item ?? {};
      const requestedQuantityWarehouseExportProposal =
        itemsSync[el?.itemId]?.quantity;
      const num = plus(index, 1);
      return {
        stt: `${num}`,
        itemCode: item.code ?? '',
        itemName: item.name ?? '',
        lotNumber: el.lotNumber ?? '',
        itemUnit: item?.itemUnit ?? '',
        requestedQuantity:
          formatNumber(requestedQuantityWarehouseExportProposal, 2) ?? '0,00',
      };
    });
    while (itemData.length < 10) {
      const num = plus(itemData.length, 1);
      itemData.push({
        stt: `${num}`,
        itemCode: '',
        itemName: '',
        lotNumber: '',
        itemUnit: '',
        requestedQuantity: '',
      });
    }

    const docHeader = (nameTicket: string) => {
      return new Table({
        borders: wordFileStyle.border_none,
        rows: [
          new TableRow({
            children: [
              new TableCell({
                width: setWidth(5),
                children: [
                  new Paragraph({
                    style: 'formatSpacing',
                    alignment: AlignmentType.LEFT,
                    spacing: {
                      before: WORD_FILE_CONFIG.SPACING_BEFORE,
                    },
                    children: [
                      new TextRun({
                        text: nameCompany.toUpperCase(),
                        ...wordFileStyle.text_size_10_5_bold,
                        allCaps: true,
                      }),
                    ],
                  }),
                  new Paragraph(''),
                  new Paragraph({
                    style: 'formatSpacing',
                    alignment: AlignmentType.LEFT,
                    spacing: {
                      before: WORD_FILE_CONFIG.SPACING_BEFORE,
                    },
                    children: [
                      new TextRun({
                        text: addressCompany,
                        ...wordFileStyle.text_size_10_5_bold,
                      }),
                    ],
                  }),
                ],
                borders: wordFileStyle.border_none,
              }),
              new TableCell({
                width: setWidth(4),
                children: [
                  new Paragraph({
                    style: 'formatSpacing',
                    alignment: AlignmentType.CENTER,
                    spacing: {
                      before: WORD_FILE_CONFIG.SPACING_BEFORE,
                    },
                    children: [
                      new TextRun({
                        text: title,
                        ...wordFileStyle.title_style,
                        allCaps: true,
                      }),
                    ],
                  }),
                  new Paragraph({
                    style: 'formatSpacing',
                    alignment: AlignmentType.CENTER,
                    spacing: {
                      before: WORD_FILE_CONFIG.SPACING_BEFORE,
                    },
                    children: [
                      new TextRun({
                        text: warehouseExport.createdAt + createdAt,
                        ...wordFileStyle.text_size_10_5_normal,
                      }),
                    ],
                  }),
                  new Paragraph({
                    style: 'formatSpacing',
                    alignment: AlignmentType.CENTER,
                    spacing: {
                      before: WORD_FILE_CONFIG.SPACING_BEFORE,
                    },
                    children: [
                      new TextRun({
                        text: nameTicket,
                        ...wordFileStyle.text_size_10_5_normal,
                      }),
                    ],
                  }),
                ],
                borders: wordFileStyle.border_none,
              }),
              new TableCell({
                width: setWidth(5),
                children: [
                  new Paragraph({
                    style: 'formatSpacing',
                    alignment: AlignmentType.CENTER,
                    spacing: {
                      before: WORD_FILE_CONFIG.SPACING_BEFORE,
                    },
                    children: [
                      new TextRun({
                        text: warehouseExport.info.split('\n')[0],
                        ...wordFileStyle.text_size_10_5_bold,
                      }),
                    ],
                  }),
                  new Paragraph({
                    style: 'formatSpacing',
                    alignment: AlignmentType.CENTER,
                    spacing: {
                      before: WORD_FILE_CONFIG.SPACING_BEFORE,
                    },
                    children: [
                      new TextRun({
                        text: warehouseExport.info.split('\n')[1],
                        ...wordFileStyle.text_size_10_5_normal,
                      }),
                    ],
                  }),
                  new Paragraph({
                    style: 'formatSpacing',
                    alignment: AlignmentType.CENTER,
                    spacing: {
                      before: WORD_FILE_CONFIG.SPACING_BEFORE,
                    },
                    children: [
                      new TextRun({
                        text: warehouseExport.info.split('\n')[2],
                        ...wordFileStyle.text_size_10_5_normal,
                      }),
                    ],
                  }),
                  new Paragraph({
                    style: 'formatSpacing',
                    alignment: AlignmentType.CENTER,
                    spacing: {
                      before: WORD_FILE_CONFIG.SPACING_BEFORE,
                    },
                    children: [
                      new TextRun({
                        text: exportTicket,
                        ...wordFileStyle.text_size_10_5_bold,
                      }),
                    ],
                  }),
                ],
                borders: wordFileStyle.border_none,
              }),
            ],
          }),
          new TableRow({
            height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
            children: [
              new TableCell({
                children: [],
                borders: wordFileStyle.border_none,
              }),
            ],
          }),
        ],
      });
    };

    const tableItems = new Table({
      width: setWidth(WORD_FILE_CONFIG.TABLE_WIDTH_PAGE_A35),
      borders: wordFileStyle.border_right_top,
      rows: [
        new TableRow({
          tableHeader: true,
          height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
          children: SO_EXPORT_TICKET_ITEMS.map((item) => {
            return new TableCell({
              width: setWidth(item.width),
              verticalAlign: VerticalAlign.CENTER,
              children: [
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  children: [
                    new TextRun({
                      text: header[item.name] ?? '',
                      ...wordFileStyle.table_item_header_style,
                    }),
                  ],
                }),
              ],
            });
          }),
        }),
        ...itemData.map((item) => {
          const itemValue = Object.values(item);
          return new TableRow({
            height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
            children: [
              ...itemValue?.map((text: string, index: number) => {
                let mar = {};
                let alignmentText = AlignmentType.CENTER;
                switch (index) {
                  case 5:
                    mar = wordFileStyle.margin_left;
                    alignmentText = AlignmentType.RIGHT;
                    break;
                  case 1:
                  case 2:
                    mar = wordFileStyle.margin_left;
                    alignmentText = AlignmentType.LEFT;
                    break;
                  default:
                    break;
                }
                return new TableCell({
                  columnSpan: null,
                  verticalAlign: VerticalAlign.CENTER,
                  borders: wordFileStyle.border_item,
                  margins: mar,
                  children: [
                    new Paragraph({
                      alignment: alignmentText,
                      children: [
                        new TextRun({
                          text: text,
                          ...wordFileStyle.text_style,
                        }),
                      ],
                    }),
                  ],
                });
              }),
            ],
          });
        }),
      ],
    });

    const bodyTables = new Table({
      width: setWidth(WORD_FILE_CONFIG.TABLE_WIDTH_PAGE_A35),
      rows: [
        new TableRow({
          height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
          children: [
            new TableCell({
              width: setWidth(3),
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: warehouseExport.receiptName,
                      ...wordFileStyle.text_size10_style,
                    }),
                    new TextRun({
                      text: receiptName,
                      ...wordFileStyle.text_size10_style_bold,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
              verticalAlign: VerticalAlign.CENTER,
            }),
            new TableCell({
              width: setWidth(6),
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: warehouseExport.departmentAddress,
                      ...wordFileStyle.text_size10_style,
                    }),
                    new TextRun({
                      text: departmentAddress,
                      ...wordFileStyle.text_size10_style_bold,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
              verticalAlign: VerticalAlign.CENTER,
            }),
            new TableCell({
              width: setWidth(5),
              children: [new Paragraph({})],
              borders: wordFileStyle.border_none,
            }),
          ],
        }),
        new TableRow({
          height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
          children: [
            new TableCell({
              columnSpan: 3,
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: warehouseExport.reason,
                      ...wordFileStyle.text_size10_style,
                    }),
                    new TextRun({
                      text: reason,
                      ...wordFileStyle.text_size10_style_bold,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
              verticalAlign: VerticalAlign.CENTER,
            }),
          ],
        }),
        new TableRow({
          height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
          children: [
            new TableCell({
              columnSpan: 3,
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: warehouseExport.explanation,
                      ...wordFileStyle.text_size10_style,
                    }),
                    new TextRun({
                      text: explanation,
                      ...wordFileStyle.text_size10_style_bold,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
              verticalAlign: VerticalAlign.CENTER,
            }),
          ],
        }),
        new TableRow({
          height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
          children: [
            new TableCell({
              columnSpan: 3,
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: warehouseExport.exportWarehouse,
                      ...wordFileStyle.text_size10_style,
                    }),
                    new TextRun({
                      text: exportWarehouse,
                      ...wordFileStyle.text_size10_style_bold,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
              verticalAlign: VerticalAlign.CENTER,
            }),
          ],
        }),
        new TableRow({
          height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
          children: [
            new TableCell({
              width: setWidth(3),
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: warehouseExport.construction,
                      ...wordFileStyle.text_size10_style,
                    }),
                    new TextRun({
                      text: construction,
                      ...wordFileStyle.text_size10_style_bold,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
              verticalAlign: VerticalAlign.CENTER,
            }),
            new TableCell({
              width: setWidth(6),
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: warehouseExport.category,
                      ...wordFileStyle.text_size10_style,
                    }),
                    new TextRun({
                      text: category,
                      ...wordFileStyle.text_size10_style_bold,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
              verticalAlign: VerticalAlign.CENTER,
            }),
            new TableCell({
              width: setWidth(5),
              children: [new Paragraph({})],
              borders: wordFileStyle.border_none,
            }),
          ],
        }),
        new TableRow({
          height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
          children: [
            new TableCell({
              children: [],
              borders: wordFileStyle.border_none,
            }),
          ],
        }),
        new TableRow({
          height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
          children: [
            new TableCell({
              columnSpan: 3,
              children: [tableItems],
              // borders: wordFileStyle.border_right_top,
            }),
          ],
        }),
      ],
    });

    const reportDate = new Paragraph({
      style: 'formatSpacing',
      alignment: AlignmentType.RIGHT,
      spacing: {
        before: WORD_FILE_CONFIG.SPACING_BEFORE,
      },
      children: [
        new TextRun({
          text: addressProvince + date,
          size: WORD_FILE_CONFIG.WORD_FONT_SIZE_9,
          font: FONT_NAME,
          italics: WORD_FILE_CONFIG.WORD_ITALIC,
        }),
      ],
    });

    const doc = new Document({
      styles: {
        paragraphStyles: [
          {
            id: 'formatSpacing',
            name: 'Format Spacing',
            basedOn: 'Normal',
            paragraph: {
              spacing: {
                after: 12,
              },
            },
          },
        ],
      },
      sections: [
        ...Object.values(warehouseExport.ticket).map((ticketNum: string) => {
          return {
            properties: {
              page: {
                size: wordFileStyle.pagesize_a35,
              },
            },
            children: [
              docHeader(ticketNum),
              bodyTables,
              new Paragraph({
                children: [
                  new TextRun({
                    text: '',
                  }),
                ],
              }),
              reportDate,
              signatureRole,
              new Paragraph({
                children: [
                  new TextRun({
                    text: '',
                  }),
                ],
              }),
              new Paragraph({
                children: [
                  new TextRun({
                    text: '',
                  }),
                ],
              }),
              signatureBottom,
              new Paragraph({
                children: [new TextRun({ break: 4 })],
              }),
            ],
          };
        }),
      ],
    });
    const result = await Packer.toBuffer(doc);
    return { result, nameFile };
  }

  async exportDeliveryRecord(request: GetOrderDetailRequestDto): Promise<any> {
    const { data } = await this.getDetail(request);
    if (!data) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (data?.status !== OrderStatusEnum.Completed) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.SALE_ORDER_EXPORT_STATUS_IS_INVALID',
          ),
        )
        .build();
    }
    const companyDefault = await this.userService.getCompanyDefault();
    const codeCompany = companyDefault?.code || '';
    const nameCompany = companyDefault?.name ?? '';
    const addressCompany = companyDefault?.address ?? '';
    const deliveryRecordExport = await this.i18n.translate(
      `export.deliveryRecord`,
    );
    const companyAddressFooter = await this.i18n.translate(
      `export.companyAddressFooter`,
    );
    const nameFile =
      `${deliveryRecordExport.nameFile}` + `${data.code ?? ''}.docx`;
    const header = deliveryRecordExport.headerTableItem;
    const title = deliveryRecordExport.title;
    const countryHeader = deliveryRecordExport.countryHeader;
    const footerDate = companyAddressFooter[`${codeCompany}_FOOTER_DATE`];
    let item: any = {};
    const itemsSync = keyBy(data?.itemsSync, 'id');
    const itemIds = map(data?.itemsSync, 'id');
    const listItemInfo = await this.itemService.getItemsInfo(itemIds, true);
    const itemData = data?.saleOrderExportWarehouseLots?.map((el, index) => {
      item = el.item ?? {};
      const requestedQuantityWarehouseExportProposal =
        itemsSync[el?.itemId]?.quantity;
      const num = plus(index, 1);
      return {
        stt: `${num}`,
        itemCode: item.code ?? '',
        itemName: item.name ?? '',
        itemUnit: item?.itemUnit ?? '',
        requestedQuantity:
          formatNumber(requestedQuantityWarehouseExportProposal, 2) ?? '0,00',
        status: listItemInfo[el?.itemId]?.itemQuality?.name || '',
        note: el?.warehouse?.code || '',
      };
    });
    while (itemData.length < 8) {
      const num = plus(itemData.length, 1);
      itemData.push({
        stt: `${num}`,
        itemCode: '',
        itemName: '',
        itemUnit: '',
        requestedQuantity: '',
        status: '',
        note: '',
      });
    }

    const docHeader = new Table({
      borders: wordFileStyle.border_none,
      rows: [
        new TableRow({
          children: [
            new TableCell({
              width: setWidth(6),
              children: [
                new Paragraph({
                  indent: { left: WORD_FILE_CONFIG.INDENT_400 },
                  style: 'formatSpacing',
                  alignment: AlignmentType.LEFT,
                  spacing: { after: WORD_FILE_CONFIG.BREAK_ONE_ROW },
                  children: [
                    new TextRun({
                      text: nameCompany,
                      ...wordFileStyle.text_size_11_bold,
                      allCaps: true,
                    }),
                  ],
                }),
                new Paragraph({
                  indent: { right: WORD_FILE_CONFIG.INDENT_400 },
                  style: 'formatSpacing',
                  alignment: AlignmentType.CENTER,
                  spacing: { after: WORD_FILE_CONFIG.BREAK_ONE_ROW },
                  children: [
                    new TextRun({
                      text: deliveryRecordExport.itemDepartment,
                      ...wordFileStyle.text_size_11_bold,
                      underline: wordFileStyle.underline,
                    }),
                  ],
                }),
                new Paragraph({
                  indent: { left: WORD_FILE_CONFIG.INDENT_400 },
                  style: 'formatSpacing',
                  alignment: AlignmentType.LEFT,
                  spacing: { after: WORD_FILE_CONFIG.BREAK_ONE_ROW },
                  children: [
                    new TextRun({
                      text: addressCompany,
                      ...wordFileStyle.text_size_10_5_normal,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
            }),
            new TableCell({
              width: setWidth(8),
              children: [
                new Paragraph({
                  style: 'formatSpacing',
                  alignment: AlignmentType.CENTER,
                  spacing: { after: WORD_FILE_CONFIG.BREAK_ONE_ROW },
                  children: [
                    new TextRun({
                      text: countryHeader.split('\n')[0] || '',
                      ...wordFileStyle.text_style_signature_bold,
                      allCaps: true,
                    }),
                  ],
                }),
                new Paragraph({
                  style: 'formatSpacing',
                  alignment: AlignmentType.CENTER,
                  spacing: { after: WORD_FILE_CONFIG.BREAK_ONE_ROW },
                  children: [
                    new TextRun({
                      text: countryHeader.split('\n')[1] || '',
                      ...wordFileStyle.text_size_11_bold,
                      underline: wordFileStyle.underline,
                    }),
                  ],
                }),
                new Paragraph({
                  indent: { right: WORD_FILE_CONFIG.INDENT_600 },
                  style: 'formatSpacing',
                  alignment: AlignmentType.RIGHT,
                  spacing: { after: WORD_FILE_CONFIG.BREAK_ONE_ROW },
                  children: [
                    new TextRun({
                      text: footerDate || '',
                      ...wordFileStyle.text_size10_style,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
            }),
          ],
        }),
      ],
    });

    const tableItems = new Table({
      borders: wordFileStyle.border_right_top,
      rows: [
        new TableRow({
          tableHeader: true,
          height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
          children: DELIVERY_RECORD_ITEMS.map((item) => {
            return new TableCell({
              width: setWidth(item.width),
              verticalAlign: VerticalAlign.CENTER,
              children: [
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  children: [
                    new TextRun({
                      text: header[item.name] ?? '',
                      ...wordFileStyle.table_item_header_style,
                    }),
                  ],
                }),
              ],
            });
          }),
        }),
        ...itemData.map((item) => {
          const itemValue = Object.values(item);
          return new TableRow({
            height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
            children: [
              ...itemValue?.map((text: string, index: number) => {
                let mar = {};
                let alignmentText = AlignmentType.CENTER;
                switch (index) {
                  case 2:
                  case 6:
                    mar = wordFileStyle.margin_left;
                    alignmentText = AlignmentType.LEFT;
                    break;
                  default:
                    break;
                }
                return new TableCell({
                  columnSpan: null,
                  verticalAlign: VerticalAlign.CENTER,
                  margins: mar,
                  children: [
                    new Paragraph({
                      alignment: alignmentText,
                      children: [
                        new TextRun({
                          text: text,
                          ...wordFileStyle.text_style,
                        }),
                      ],
                    }),
                  ],
                });
              }),
            ],
          });
        }),
      ],
    });

    const wrapTableItem = new Table({
      rows: [
        new TableRow({
          height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
          children: [
            new TableCell({
              columnSpan: null,
              children: [
                new Paragraph({
                  indent: { left: WORD_FILE_CONFIG.INDENT_400 },
                  children: [
                    new TextRun({
                      text: deliveryRecordExport.titleTable,
                      ...wordFileStyle.text_size_11_normal,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
            }),
          ],
        }),
        new TableRow({
          height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
          children: [
            new TableCell({
              columnSpan: null,
              children: [tableItems],
            }),
          ],
        }),
        new TableRow({
          height: setHeight(WORD_FILE_CONFIG.TABLE_ROW_HEIGHT),
          children: [
            new TableCell({
              columnSpan: null,
              children: [
                new Paragraph({
                  indent: { left: WORD_FILE_CONFIG.INDENT_400 },
                  alignment: AlignmentType.LEFT,
                  spacing: {
                    before: WORD_FILE_CONFIG.PADDING_TOP_TABLE,
                  },
                  children: [
                    new TextRun({
                      text: deliveryRecordExport.textFooterTableItem,
                      ...wordFileStyle.text_size_11_normal,
                    }),
                  ],
                }),
              ],
              borders: wordFileStyle.border_none,
            }),
          ],
        }),
      ],
    });

    const bodyTable = [
      new Paragraph({
        style: 'formatSpacing',
        alignment: AlignmentType.CENTER,
        spacing: {
          before: WORD_FILE_CONFIG.SPACING_BEFORE,
        },
        children: [
          new TextRun({
            text: title.split('\n')[0],
            ...wordFileStyle.text_size_18_bold,
            allCaps: true,
          }),
        ],
      }),
      new Paragraph({
        style: 'formatSpacing',
        alignment: AlignmentType.CENTER,
        spacing: { after: WORD_FILE_CONFIG.BREAK_ONE_ROW },
        children: [
          new TextRun({
            text: title.split('\n')[1],
            ...wordFileStyle.text_style_signature_bold,
            underline: wordFileStyle.underline,
          }),
        ],
      }),
      new Paragraph(''),
      new Paragraph({
        indent: {
          left: WORD_FILE_CONFIG.INDENT_1800,
          right: WORD_FILE_CONFIG.INDENT_600,
        },
        style: 'formatSpacing',
        alignment: AlignmentType.DISTRIBUTE,
        spacing: {
          before: WORD_FILE_CONFIG.SPACING_BEFORE,
        },
        children: [
          new TextRun({
            text: deliveryRecordExport.base,
            ...wordFileStyle.text_size_11_normal,
          }),
        ],
      }),
      new Paragraph({
        indent: {
          left: WORD_FILE_CONFIG.INDENT_600,
          right: WORD_FILE_CONFIG.INDENT_600,
        },
        style: 'formatSpacing',
        alignment: AlignmentType.DISTRIBUTE,
        spacing: {
          before: WORD_FILE_CONFIG.SPACING_BEFORE,
        },
        children: [
          new TextRun({
            text: deliveryRecordExport.dotLong,
            ...wordFileStyle.text_size_11_normal,
          }),
        ],
      }),
      new Paragraph({
        indent: {
          left: WORD_FILE_CONFIG.INDENT_600,
          right: WORD_FILE_CONFIG.INDENT_600,
        },
        style: 'formatSpacing',
        alignment: AlignmentType.DISTRIBUTE,
        spacing: { after: WORD_FILE_CONFIG.BREAK_ONE_ROW },
        children: [
          new TextRun({
            text: deliveryRecordExport.dotLong,
            ...wordFileStyle.text_size_11_normal,
          }),
        ],
      }),
      new Paragraph(''),
      new Paragraph({
        style: 'formatSpacing',
        alignment: AlignmentType.LEFT,
        spacing: {
          before: WORD_FILE_CONFIG.SPACING_BEFORE,
        },
        indent: { left: WORD_FILE_CONFIG.INDENT_400 },
        children: [
          new TextRun({
            text: deliveryRecordExport.titleInfoToday,
            ...wordFileStyle.text_size_11_normal,
          }),
          new TextRun({
            text: `${nameCompany}`,
            ...wordFileStyle.text_size_11_normal,
          }),
        ],
      }),
      new Paragraph({
        indent: {
          left: WORD_FILE_CONFIG.INDENT_700,
        },
        style: 'formatSpacing',
        alignment: AlignmentType.LEFT,
        spacing: {
          after: WORD_FILE_CONFIG.SPACING_ROW_AFTER,
          before: WORD_FILE_CONFIG.SPACING_ROW_BEFORE,
        },
        children: [
          new TextRun({
            text: deliveryRecordExport.bothParties,
            ...wordFileStyle.text_size_11_bold,
          }),
        ],
      }),
      new Paragraph({
        indent: {
          left: WORD_FILE_CONFIG.INDENT_700,
          right: WORD_FILE_CONFIG.INDENT_600,
        },
        alignment: AlignmentType.DISTRIBUTE,
        children: [
          new TextRun({
            text:
              deliveryRecordExport.handoverParty + deliveryRecordExport.dotLong,
            ...wordFileStyle.text_size_11_normal,
          }),
        ],
      }),
      new Paragraph({
        indent: {
          left: WORD_FILE_CONFIG.INDENT_1000,
          right: WORD_FILE_CONFIG.INDENT_600,
        },
        alignment: AlignmentType.DISTRIBUTE,
        spacing: { after: WORD_FILE_CONFIG.BREAK_ONE_ROW },
        children: [
          new TextRun({
            text:
              deliveryRecordExport.representative +
              deliveryRecordExport.dotShort,
            ...wordFileStyle.text_size_11_normal,
          }),
          new TextRun({
            text: deliveryRecordExport.position + deliveryRecordExport.dotShort,
            ...wordFileStyle.text_size_11_normal,
          }),
        ],
      }),
      new Paragraph({
        indent: {
          left: WORD_FILE_CONFIG.INDENT_700,
          right: WORD_FILE_CONFIG.INDENT_600,
        },
        alignment: AlignmentType.DISTRIBUTE,
        children: [
          new TextRun({
            text:
              deliveryRecordExport.receiverHandoverParty +
              deliveryRecordExport.dotLong,
            ...wordFileStyle.text_size_11_normal,
          }),
        ],
      }),
      new Paragraph({
        indent: {
          left: WORD_FILE_CONFIG.INDENT_1000,
          right: WORD_FILE_CONFIG.INDENT_600,
        },
        alignment: AlignmentType.DISTRIBUTE,
        children: [
          new TextRun({
            text:
              deliveryRecordExport.representative +
              deliveryRecordExport.dotShort,
            ...wordFileStyle.text_size_11_normal,
          }),
          new TextRun({
            text: deliveryRecordExport.position + deliveryRecordExport.dotShort,
            ...wordFileStyle.text_size_11_normal,
          }),
        ],
      }),
    ];

    const signatureRole = new Table({
      borders: wordFileStyle.border_none,
      rows: [
        new TableRow({
          children: [
            ...TABLE_DELIVERY_SIGNATURE.map((item) => {
              return new TableCell({
                width: setWidth(item.width),
                children: [
                  new Paragraph({
                    alignment: AlignmentType.CENTER,
                    children: [
                      new TextRun({
                        text:
                          deliveryRecordExport.roleSignature[item.name] || '',
                        ...wordFileStyle.text_style_signature_bold,
                        allCaps: true,
                      }),
                    ],
                  }),
                ],
                borders: wordFileStyle.border_none,
                verticalAlign: VerticalAlign.CENTER,
              });
            }),
          ],
        }),
      ],
    });

    const doc = new Document({
      styles: {
        paragraphStyles: [
          {
            id: 'formatSpacing',
            name: 'Format Spacing',
            basedOn: 'Normal',
            paragraph: {
              spacing: {
                after: 15,
              },
            },
          },
        ],
      },
      sections: [
        {
          properties: {
            page: {
              size: wordFileStyle.pagesize_a46,
              margin: wordFileStyle.margin_page,
            },
          },
          children: [
            docHeader,
            new Paragraph(''),
            new Paragraph(''),
            ...bodyTable,
            new Paragraph(''),
            wrapTableItem,
            new Paragraph(''),
            new Paragraph({
              indent: { right: WORD_FILE_CONFIG.INDENT_600 },
              alignment: AlignmentType.RIGHT,
              children: [
                new TextRun({
                  text: footerDate || '',
                  ...wordFileStyle.text_style,
                  italics: true,
                }),
              ],
            }),
            new Paragraph(''),
            signatureRole,
            new Paragraph({
              children: [new TextRun({ break: 4 })],
            }),
          ],
        },
      ],
    });

    const result = await Packer.toBuffer(doc);
    return { result, nameFile };
  }

  private getValueEbsLabel(
    serializeAttribute: object,
    serializeValueAttributeTable: object,
    ebsLabel: string,
  ) {
    try {
      if (!has(serializeAttribute, ebsLabel)) {
        return '';
      }
      if (
        serializeAttribute[ebsLabel]?.tableName &&
        serializeAttribute[ebsLabel]?.value
      ) {
        const attribute = serializeAttribute[ebsLabel];
        if (has(serializeValueAttributeTable, attribute.tableName)) {
          return (
            serializeValueAttributeTable[attribute.tableName][attribute.value][
              MAPPING_MASTER_DATA_BUSSINESS_TYPE[attribute.tableName]
            ] ?? ''
          );
        } else {
          return '';
        }
      }

      if (
        serializeAttribute[ebsLabel].type === TypeBussinessAttributeEnum.DATE
      ) {
        return serializeAttribute[ebsLabel]?.value
          ? Moment(serializeAttribute[ebsLabel]?.value).format(
              'DD/MM/YYYY HH:mm:ss',
            )
          : '';
      }
      return serializeAttribute[ebsLabel]?.value;
    } catch {
      return '';
    }
  }

  async getListOpenTransaction(
    request: GetListOpenTransactionRequestDto,
  ): Promise<any> {
    const configService = new ConfigService();
    const defaultTimeZone = configService.get('defaultTimeZone');
    const data = await this.saleOrderExportRepository.getListOpenTransaction(
      request,
      defaultTimeZone,
    );

    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async updateHeaderEbsIn(
    payload: UpdateHeaderEbsInSOERequest,
  ): Promise<any> {
    const saleOrderExport =
      await this.saleOrderExportRepository.findOneWithRelations({
        where: {
          id: payload.id,
        },
        relations: ['saleOrderExportWarehouseLots'],
      });

    if (!saleOrderExport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (payload.status !== ResponseCodeEnum.SUCCESS) {
      saleOrderExport.syncStatus = StatusSyncOrderToEbsEnum.SYNC_WSO2_ERROR;
    } else {
      const debtMap = keyBy(payload.item, 'order');

      saleOrderExport.syncStatus = StatusSyncOrderToEbsEnum.COMPLETED;
      saleOrderExport.ebsId = payload.ebsId;
      saleOrderExport.oldEbsId = null;
      saleOrderExport.transactionNumberCreated =
        payload.transactionNumberCreated;
      saleOrderExport.oldTransactionNumberCreated = null;
      orderBy(
        saleOrderExport.saleOrderExportWarehouseLots,
        ['itemId', 'lotNumber', 'quantity'],
        ['asc', 'asc', 'asc'],
      ).forEach((item, index) => {
        if (has(debtMap, plus(index, 1))) {
          item.debitAccount = debtMap[plus(index, 1)]?.debt;
        }
      });
    }

    await this.saleOrderExportRepository.create(saleOrderExport);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
