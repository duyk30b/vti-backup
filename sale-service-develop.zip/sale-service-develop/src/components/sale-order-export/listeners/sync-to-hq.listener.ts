import { UserService } from './../../user/user.service';
import { plainToInstance } from 'class-transformer';
import { SaleOrderExportRepositoryInterface } from '@components/sale-order-export/interface/sale-order-export.repository.interface';
import { DatasyncServiceInterface } from '@components/datasync/interface/datasync.service.interface';
import { SyncDataRequestDto } from '@components/sync-data/dto/request/sync-data.request.dto';
import { SyncDataToHQListener } from '@components/sync-data/listeners/sync-data-to-hq.listener';
import {
  ProcessSyncDataEnum,
  RepositorySyncDataEnum,
  SYNC_TO_SYSTEM_ENUM,
  TypeTransactionDataSyncEnum,
} from '@components/sync-data/sync-data.constant';
import { QUEUES_NAME_ENUM } from '@constant/common';
import { OrderTypeEnum as SaleOrderTypeEnum } from '@constant/order.constant';
import { InjectQueue } from '@nestjs/bull';
import { Inject } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { EventSyncSoExportEnum } from '../sale-order-export.contant';
import { WarehouseCronService } from '@components/warehouse/warehouse.cron.service';
import { ConfigService } from '@config/config.service';
import Queue from 'bull';
import { isEmpty, groupBy, map, keyBy, first } from 'lodash';
import { GetAttributeDetailValuesRequestDto } from '@components/warehouse/dto/request/get-attribute-detail-values.request.dto';
import { SyncSaleOrderExportRequest } from '../events/sync-sale-order-export.request';
import { ItemService } from '@components/item/item.service';
import { ReasonRepositoryInterface } from '@components/reason/interface/reason.repository.interface';
import { SourceRepositoryInterface } from '@components/source/interface/sources.repository.interface';
import { PushQueueEvent } from '@components/sync-data/event/push-queue.event';

export class SyncSoExportToHqListener extends SyncDataToHQListener {
  constructor(
    @InjectQueue(QUEUES_NAME_ENUM.SYNC_DATA_QUEUE)
    protected queue: Queue,

    @Inject('DatasyncServiceInterface')
    protected datasyncService: DatasyncServiceInterface,

    @Inject('SaleOrderExportRepositoryInterface')
    private readonly saleOrderExportRepository: SaleOrderExportRepositoryInterface,

    @Inject('WarehouseCronServiceInterface')
    private readonly warehouseService: WarehouseCronService,

    @Inject('ReasonRepositoryInterface')
    private readonly reasonRepository: ReasonRepositoryInterface,

    @Inject('SourceRepositoryInterface')
    private readonly sourceRepository: SourceRepositoryInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemService,

    @Inject('UserServiceInterface')
    private readonly userService: UserService,

    private configService: ConfigService,
  ) {
    super(queue, datasyncService);
    this.configService = new ConfigService();
  }

  async getDetail(id: number): Promise<any> {
    const order = await this.saleOrderExportRepository.findOneWithRelations({
      where: {
        id,
      },
      relations: ['saleOrderExportDetails', 'saleOrderExportWarehouseLots'],
    });
    const itemIds = map(order.saleOrderExportDetails, 'itemId');
    const [items, warehouses, businessType] = await Promise.all([
      this.itemService.getItems(itemIds),
      this.warehouseService.getWarehouses([order.warehouseId]),
      this.warehouseService.getBusinessTypeDetail(
        order.businessTypeId,
        id,
        SaleOrderTypeEnum.SO,
      ),
    ]);

    let reason, source, departmentReceipt;
    if (order.reasonId) {
      reason = await this.reasonRepository.findOneById(order.reasonId);
    }
    if (order.sourceId) {
      source = await this.sourceRepository.findOneById(order.sourceId);
    }
    if (order.departmentReceiptId) {
      departmentReceipt = await this.userService.getDepartmentReceiptById(
        order.departmentReceiptId,
      );
    }
    const warehouse = first(warehouses);
    const serializeItem = keyBy(items, 'itemId');
    const attributes = businessType.bussinessTypeAttributes;

    let attributeDetailValues = {} as any;
    if (!isEmpty(attributes)) {
      const attributeGroup = groupBy(attributes, 'tableName');
      const payload = new GetAttributeDetailValuesRequestDto();
      const attributeKeys = Object.keys(attributeGroup).filter(
        (el) => !el.match('null'),
      );
      payload.filter = attributeKeys.map((key) => {
        return {
          tableName: key,
          id: map(attributeGroup[key], 'value').join(','),
        };
      });
      attributeDetailValues =
        await this.warehouseService?.getAttributeDetailValuesTcp(payload);
    }
    const company = await this.userService.getCompanyDefault();
    const vendor = first(attributeDetailValues?.vendors);
    const construction = first(attributeDetailValues?.constructions);
    const warehouseExportProposal = first(
      attributeDetailValues?.warehouse_export_proposals,
    );
    return plainToInstance(
      SyncSaleOrderExportRequest,
      {
        ...order,
        syncCode: company?.code,
        companyCode: company?.code,
        company: {
          name: company?.name,
          code: company?.code,
          address: company?.address,
        },
        warehouse: warehouse,
        vendor: vendor,
        construction: construction,
        source: source,
        reason: reason,
        departmentReceipt: departmentReceipt,
        warehouseExportProposals: warehouseExportProposal,
        saleOrderExportDetails: order.saleOrderExportDetails.map(
          (saleOrderExportDetail) => {
            return {
              ...saleOrderExportDetail,
              item: serializeItem[+saleOrderExportDetail.itemId],
              lots: order.saleOrderExportWarehouseLots
                .filter((lot) => lot.itemId === saleOrderExportDetail.itemId)
                .map((lot) => ({
                  ...lot,
                  planQuantity: lot.quantity,
                })),
            };
          },
        ),
      },
      { excludeExtraneousValues: true },
    );
  }

  @OnEvent(EventSyncSoExportEnum.Update)
  async updateItem(id: number) {
    const data = await this.getDetail(id);
    const request = {
      id: id,
      masterData: RepositorySyncDataEnum.SoExport,
      data: data,
    } as SyncDataRequestDto;
    await this.pushQueue(
      this.getInfoQueue(ProcessSyncDataEnum.UpdateSoExport, data),
      request,
    );

    await this.pushQueue(
      this.getInfoQueue(ProcessSyncDataEnum.UpdateSoExportHQ, data),
      request,
    );
  }
  @OnEvent(EventSyncSoExportEnum.Delete)
  async deleteItem(id: number) {
    const data = await this.getDetail(id);
    const request = {
      id: id,
      masterData: RepositorySyncDataEnum.SoExport,
      data: data,
    } as SyncDataRequestDto;
    await this.pushQueue(
      this.getInfoQueue(ProcessSyncDataEnum.DeleteSoExport, data),
      request,
    );

    await this.pushQueue(
      this.getInfoQueue(ProcessSyncDataEnum.DeleteSoExportHQ, data),
      request,
    );
  }

  private getInfoQueue(process: string, data) {
    const infoQueue = new PushQueueEvent();
    infoQueue.process = process;
    infoQueue.resourceCode = data.code;
    infoQueue.typeTransaction = TypeTransactionDataSyncEnum.SO_EXPORT;
    infoQueue.toSystem = SYNC_TO_SYSTEM_ENUM.COMPANY_HQ;
    return infoQueue;
  }
}
