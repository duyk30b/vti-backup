import { SaleOrderExportRepositoryInterface } from '../interface/sale-order-export.repository.interface';
import { OrderTypeEnum } from '../../../constant/order.constant';
import { OrderUpdateConfirmedQuantityEvent } from '@components/order/events/order-update-confirmed-quantity.event';
import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { OrderUpdateConfirmedQuantityListener } from '@components/order/listeners/order-update-confimed-quantity.listener';
import { UpdateStockStatusOrderRequest } from '@components/warehouse/dto/request/update-stock-status-order.request';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import {
  CAN_UPDATE_ACTUAL_QUANTITY_PO,
  OrderStatusEnum,
} from '@constant/common';
import { SaleOrderRepositoryInterface } from '@components/sale-order/interface/sale-order.repository.interface';
import { OrderUpdateCollectedQuantityEvent } from '@components/order/events/order-update-collected-quantity.event';
import { SaleOrder } from '@entities/sale-order/sale-order.entity';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';

@Injectable()
export class SaleOrderExportUpdateConfirmedQuantityListener extends OrderUpdateConfirmedQuantityListener {
  constructor(
    @Inject('SaleOrderExportRepositoryInterface')
    private readonly saleOrderExportRepository: SaleOrderExportRepositoryInterface,

    @Inject('SaleOrderRepositoryInterface')
    private readonly saleOrderRepository: SaleOrderRepositoryInterface,

    @Inject('WarehouseCronServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,
  ) {
    super();
  }

  @OnEvent('order.updateConfirmedQuantity')
  async handleOrderCreatedEvent(event: OrderUpdateConfirmedQuantityEvent) {
    const { id, orderType } = event;
    let order;
    if (orderType === OrderTypeEnum.SO) {
      order = await this.saleOrderExportRepository.checkReadyToComplete(id);
    }
    if (order) {
      const soexp = await this.saleOrderExportRepository.findOneById(id);
      if (CAN_UPDATE_ACTUAL_QUANTITY_PO.includes(soexp.status)) {
        soexp.status = OrderStatusEnum.Completed;
        soexp.completedAt = new Date();
      }

      const checkComplete = await this.saleOrderRepository.checkComplete(
        soexp.saleOrderId,
      );
      let so: SaleOrder;
      if (checkComplete) {
        so = await this.saleOrderRepository.findOneById(soexp.saleOrderId);
        if (CAN_UPDATE_ACTUAL_QUANTITY_PO.includes(so.status)) {
          so.status = OrderStatusEnum.Completed;
          so.completedAt = new Date();
        }
      }

      const queryRunner = await this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(soexp);
        if (so) await queryRunner.manager.save(so);
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return;
      } finally {
        await queryRunner.release();
      }

      const updateStockStatusOrder = new UpdateStockStatusOrderRequest();
      updateStockStatusOrder.id = soexp.id;
      updateStockStatusOrder.status = OrderStatusEnum.Completed;
      updateStockStatusOrder.type = OrderTypeEnum.SO;
      updateStockStatusOrder.completedAt = soexp.completedAt;

      await this.warehouseService.updateStatusWarehouseStockMovement(
        updateStockStatusOrder,
      );
    }

    return;
  }

  @OnEvent('order.updateCollectedQuantity')
  async handleOrderCollectedEvent(event: OrderUpdateCollectedQuantityEvent) {
    const { id, orderType } = event;
    let order;
    if (orderType === OrderTypeEnum.SO) {
      order = await this.saleOrderExportRepository.checkReadyToCollected(id);
    }
    if (order) {
      await this.saleOrderExportRepository.setCollected(id);
    }

    return;
  }
}
