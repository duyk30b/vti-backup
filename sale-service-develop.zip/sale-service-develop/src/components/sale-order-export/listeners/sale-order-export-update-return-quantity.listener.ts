import { SaleOrderExportRepositoryInterface } from '../interface/sale-order-export.repository.interface';
import { OrderTypeEnum } from '../../../constant/order.constant';
import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { CAN_UPDATE_STATUS_IMPORT_RETURN_ORDER_STATUS, OrderStatusEnum } from '@constant/common';
import { SaleOrderRepositoryInterface } from '@components/sale-order/interface/sale-order.repository.interface';
import { isEmpty } from 'lodash';
import { OrderUpdateReturnQuantityEvent } from '@components/order/events/order-update-return-quantity.event';
import { OrderUpdateReturnQuantityListener } from '@components/order/listeners/order-update-return-quantity.listener';

@Injectable()
export class SaleOrderExportUpdateReturnQuantityListener extends OrderUpdateReturnQuantityListener {
  constructor(
    @Inject('SaleOrderExportRepositoryInterface')
    private readonly saleOrderExportRepository: SaleOrderExportRepositoryInterface,

    @Inject('SaleOrderRepositoryInterface')
    private readonly saleOrderRepository: SaleOrderRepositoryInterface,

    @Inject('WarehouseCronServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,
  ) {
    super();
  }

  @OnEvent('order.updateReturnQuantity')
  async handleOrderCreatedEvent(event: OrderUpdateReturnQuantityEvent) {
    const { id, orderType } = event;
    if (orderType !== OrderTypeEnum.SO) {
      return;
    }
    const order = await this.saleOrderExportRepository.findOneById(id);
    if (isEmpty(order)) {
      return;
    }
    const completed = await this.saleOrderExportRepository.checkCompletedReturn(id);
    if (completed) {
      return await this.saleOrderExportRepository.changeStatusOrder(
        id,
        OrderStatusEnum.Returned,
      );
    }

    if (CAN_UPDATE_STATUS_IMPORT_RETURN_ORDER_STATUS.includes(order.status)) {
      await this.saleOrderExportRepository.changeStatusOrder(
        id,
        OrderStatusEnum.InReturning,
      );
    }

    return;
  }
}
