import { OnEvent } from '@nestjs/event-emitter';
import { OrderUpdateActualQuantityListener } from '@components/order/listeners/order-update-actual-quantity.listener';
import { Inject, Injectable } from '@nestjs/common';
import { OrderUpdateActualQuantityEvent } from '@components/order/events/order-update-actual-quantity.event';
import { OrderStatusEnum, OrderTypeEnum } from '@constant/order.constant';
import { SaleOrderExportRepositoryInterface } from '../interface/sale-order-export.repository.interface';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, In } from 'typeorm';
import { SaleOrderExportDetail } from '@entities/sale-order-export/sale-order-export-detail.entity';
import { SaleOrderExportWarehouseDetail } from '@entities/sale-order-export/sale-order-export-warehouse-detail.entity';
import { SaleOrderExportWarehouseLotEntity } from '@entities/sale-order-export/sale-order-export-warehouse-lot.entity';
import { SaleOrderExport } from '@entities/sale-order-export/sale-order-export.entity';
import { map } from 'lodash';
import { plus } from '@utils/common';
import { SaleOrderDetailRepositoryInterface } from '@components/sale-order/interface/sale-order-detail.repository.interface';

@Injectable()
export class SaleOrderExportUpdateActualQuantityListener extends OrderUpdateActualQuantityListener {
  constructor(
    @Inject('SaleOrderExportRepositoryInterface')
    protected readonly saleOrderExportRepository: SaleOrderExportRepositoryInterface,

    @Inject('SaleOrderDetailRepositoryInterface')
    protected readonly saleOrderDetailRepository: SaleOrderDetailRepositoryInterface,

    @InjectDataSource()
    private readonly connection: DataSource,
  ) {
    super();
  }

  @OnEvent('order.updateActualQuantity')
  async handleOrderCreatedEvent(event: OrderUpdateActualQuantityEvent) {
    const { id, orderType } = event;
    let order: SaleOrderExport;
    if (orderType === OrderTypeEnum.SO) {
      order = await this.saleOrderExportRepository.findOneWithRelations({
        where: {
          id,
        },
        relations: [
          'saleOrderExportDetails',
          'saleOrderExportWarehouseDetails',
          'saleOrderExportWarehouseLots',
        ],
      });
      const saleOrderId = order.saleOrderId;
      const saleOrderDetails =
        await this.saleOrderDetailRepository.findByCondition({
          saleOrderId,
          itemId: In(map(order.saleOrderExportDetails, 'itemId')),
        });
      if (order.status === OrderStatusEnum.Exported) {
        order = await this.saleOrderExportRepository.findOneWithRelations({
          where: {
            id,
          },
          relations: [
            'saleOrderExportDetails',
            'saleOrderExportWarehouseDetails',
            'saleOrderExportWarehouseLots',
          ],
        });
        order.saleOrderExportDetails = order.saleOrderExportDetails.map(
          (saleOrderExportDetail) => {
            return {
              ...saleOrderExportDetail,
              actualQuantity: saleOrderExportDetail.collectedQuantity,
            };
          },
        );
        saleOrderDetails.forEach((saleOrderDetail) => {
          const saleOrderExportDetail = order.saleOrderExportDetails.find(
            (saleOrderExportDetail) =>
              saleOrderExportDetail.itemId === saleOrderDetail.itemId,
          );
          saleOrderDetail.actualQuantity = plus(
            saleOrderDetail.actualQuantity,
            saleOrderExportDetail.actualQuantity,
          );
        });

        order.saleOrderExportWarehouseDetails =
          order.saleOrderExportWarehouseDetails.map(
            (saleOrderExportWarehouseDetail) => {
              return {
                ...saleOrderExportWarehouseDetail,
                actualQuantity:
                  saleOrderExportWarehouseDetail.collectedQuantity,
              };
            },
          );
        order.saleOrderExportWarehouseLots =
          order.saleOrderExportWarehouseLots.map(
            (saleOrderExportWarehouseLot) => {
              return {
                ...saleOrderExportWarehouseLot,
                actualQuantity: saleOrderExportWarehouseLot.collectedQuantity,
              };
            },
          );

        const queryRunner = await this.connection.createQueryRunner();
        await queryRunner.startTransaction();
        try {
          await queryRunner.manager.save(
            SaleOrderExportDetail,
            order.saleOrderExportDetails,
          );
          await queryRunner.manager.save(
            SaleOrderExportWarehouseDetail,
            order.saleOrderExportWarehouseDetails,
          );
          await queryRunner.manager.save(saleOrderDetails);
          await queryRunner.manager.save(
            SaleOrderExportWarehouseLotEntity,
            order.saleOrderExportWarehouseLots,
          );
          await queryRunner.commitTransaction();
        } catch (error) {
          await queryRunner.rollbackTransaction();
        } finally {
          await queryRunner.release();
        }
        return;
      } else {
        order = await this.saleOrderExportRepository.findOneById(id);
      }
    }

    return this.checkAndUpdateInProgessOrderStatus(order);
  }

  public async updateInProgessOrderStatus(order) {
    return await this.saleOrderExportRepository.create(order);
  }
}
