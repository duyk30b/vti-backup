import { SaleOrderExportUpdateConfirmedQuantityListener } from './listeners/sale-order-export-update-confimed-quantity.listener';
import { WarehouseService } from '../warehouse/warehouse.service';
import { WarehouseModule } from '../warehouse/warehouse.module';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ItemModule } from '@components/item/item.module';
import { ItemService } from '@components/item/item.service';
import { CustomerModule } from '@components/customer/customer.module';
import { CustomerRepository } from '@repositories/customer/customer.repository';
import { Customer } from '@entities/customer/customer.entity';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { SaleOrderExportUpdateActualQuantityListener } from './listeners/sale-order-export-update-actual-quantity.listener';
import { SaleOrderExport } from '@entities/sale-order-export/sale-order-export.entity';
import { SaleOrderExportDetail } from '@entities/sale-order-export/sale-order-export-detail.entity';
import { SaleOrderExportWarehouseDetail } from '@entities/sale-order-export/sale-order-export-warehouse-detail.entity';
import { SaleOrderExportRepository } from '@repositories/sale-order-export/sale-order-export.repository';
import { SaleOrderExportDetailRepository } from '@repositories/sale-order-export/sale-order-export-detail.repository';
import { SaleOrderExportWarehouseDetailRepository } from '@repositories/sale-order-export/sale-order-export-warehouse-detail.repository';
import { SaleOrderExportService } from './sale-order-export.service';
import { SaleOrderExportController } from './sale-order-export.controller';
import { SaleOrderRepository } from '@repositories/sale-order/sale-order.repository';
import { SaleOrder } from '@entities/sale-order/sale-order.entity';
import { QualityControlService } from '@components/qmx/quality-control.service';
import { QmsxModule } from '@components/qmx/qmx.module';
import { PurchasedOrderImportWarehouseLotEntity } from '@entities/purchased-order-import/purchased-order-import-warehouse-lot.entity';
import { PurchasedOrderImportWarehouseLotRepository } from '@repositories/purchased-order-import/purchased-order-import-warehouse-lot.repository';
import { ProductionOrderWarehouseDetailRepository } from '@repositories/production-order/production-order-warehouse-detail.repository';
import { ProductionOrderWarehouseDetail } from '@entities/production-order/production-order-warehouse-detail.entity';
import { PurchasedOrderImportDetailEntity } from '@entities/purchased-order-import/purchased-order-import-detail.entity';
import { PurchasedOrderWarehouseDetailRepository } from '@repositories/purchased-order/purchased-order-warehouse-detail.repository';
import { PurchasedOrderWarehouseDetail } from '@entities/purchased-order/purchased-order-warehouse-detail.entity';
import { ProductionOrderWarehouseLotEntity } from '@entities/production-order/production-order-warehouse-lot.entity';
import { ProductionOrderWarehouseLotRepository } from '@repositories/production-order/production-order-warehouse-lot.repository';
import { SaleOrderExportWarehouseLotEntity } from '@entities/sale-order-export/sale-order-export-warehouse-lot.entity';
import { SaleOrderExportWarehouseLotRepository } from '@repositories/sale-order-export/sale-order-export-warehouse-lot.repository';
import { WarehouseCronService } from '@components/warehouse/warehouse.cron.service';
import { SaleOrderExportUpdateReturnQuantityListener } from './listeners/sale-order-export-update-return-quantity.listener';
import { SaleOrderDetailRepository } from '@repositories/sale-order/sale-order-detail.repository';
import { SaleOrderDetail } from '@entities/sale-order/sale-order-detail.entity';
import { AssignOrderRepository } from '@repositories/assign-order/assign-order.repository';
import { AssignOrderEntity } from '@entities/assign-order/assign-order.entity';
import { ValidateSoeDetailWithMasterDataItem } from './validate/validate-soe-detail-with-master-data-item.helper';
import { ValidateSoeDetailWithPOImportDetail } from './validate/validate-soe-detail-with-po-import-detail.helper';
import { ValidateSoeDetailWithWarehouseExportProposalDetail } from './validate/validate-soe-detail-with-warehouse-export-proposal-detail.helper';
import { PurchasedOrderImportDetailRepository } from '@repositories/purchased-order-import/purchased-order-import-detail.repository';
import { SourceRepository } from '@repositories/source/source.repository';
import { ReasonRepository } from '@repositories/reason/reason.repository';
import { SourceEntity } from '@entities/source/source.entity';
import { ReasonEntity } from '@entities/reason/reason.entity';
import { QUEUES_NAME_ENUM } from '@constant/common';
import { BullModule } from '@nestjs/bull';
import { ConfigService } from '@config/config.service';
import { SaleOrderExportSubcriber } from './subcribers/sale-order-export.entity.subcribers';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      SaleOrder,
      SaleOrderExport,
      SaleOrderExportDetail,
      SaleOrderExportWarehouseLotEntity,
      SaleOrderExportWarehouseDetail,
      Customer,
      ProductionOrderWarehouseDetail,
      PurchasedOrderImportWarehouseLotEntity,
      ProductionOrderWarehouseLotEntity,
      PurchasedOrderImportDetailEntity,
      PurchasedOrderWarehouseDetail,
      SaleOrderDetail,
      AssignOrderEntity,
      SourceEntity,
      ReasonEntity,
    ]),
    BullModule.registerQueue({
      name: QUEUES_NAME_ENUM.SYNC_DATA_QUEUE,
    }),
    ItemModule,
    CustomerModule,
    WarehouseModule,
    UserModule,
    QmsxModule,
  ],
  providers: [
    {
      provide: 'SaleOrderRepositoryInterface',
      useClass: SaleOrderRepository,
    },
    {
      provide: 'SaleOrderExportRepositoryInterface',
      useClass: SaleOrderExportRepository,
    },
    {
      provide: 'PurchasedOrderImportWarehouseLotRepositoryInterface',
      useClass: PurchasedOrderImportWarehouseLotRepository,
    },
    {
      provide: 'SaleOrderExportDetailRepositoryInterface',
      useClass: SaleOrderExportDetailRepository,
    },
    {
      provide: 'SaleOrderExportWarehouseLotRepositoryInterface',
      useClass: SaleOrderExportWarehouseLotRepository,
    },
    {
      provide: 'SaleOrderExportWarehouseDetailRepositoryInterface',
      useClass: SaleOrderExportWarehouseDetailRepository,
    },
    {
      provide: 'ProductionOrderWarehouseDetailRepositoryInterface',
      useClass: ProductionOrderWarehouseDetailRepository,
    },
    {
      provide: 'CustomerRepositoryInterface',
      useClass: CustomerRepository,
    },
    {
      provide: 'PurchasedOrderImportDetailRepositoryInterface',
      useClass: PurchasedOrderImportDetailRepository,
    },
    {
      provide: 'SaleOrderExportServiceInterface',
      useClass: SaleOrderExportService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'WarehouseCronServiceInterface',
      useClass: WarehouseCronService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'QualityControlServiceInterface',
      useClass: QualityControlService,
    },
    {
      provide: 'ProductionOrderWarehouseLotRepositoryInterface',
      useClass: ProductionOrderWarehouseLotRepository,
    },
    {
      provide: 'PurchasedOrderWarehouseDetailRepositoryInterface',
      useClass: PurchasedOrderWarehouseDetailRepository,
    },
    {
      provide: 'SaleOrderDetailRepositoryInterface',
      useClass: SaleOrderDetailRepository,
    },
    {
      provide: 'AssignOrderRepositoryInterface',
      useClass: AssignOrderRepository,
    },
    {
      provide: 'ValidateSoeDetailWithMasterDataItem',
      useClass: ValidateSoeDetailWithMasterDataItem,
    },
    {
      provide: 'ValidateSoeDetailWithPOImportDetail',
      useClass: ValidateSoeDetailWithPOImportDetail,
    },
    {
      provide: 'ValidateSoeDetailWithWarehouseExportProposalDetail',
      useClass: ValidateSoeDetailWithWarehouseExportProposalDetail,
    },
    {
      provide: 'ConfigServiceInterface',
      useClass: ConfigService,
    },
    SaleOrderExportUpdateActualQuantityListener,
    SaleOrderExportUpdateConfirmedQuantityListener,
    SaleOrderExportUpdateReturnQuantityListener,
    {
      provide: 'SourceRepositoryInterface',
      useClass: SourceRepository,
    },
    {
      provide: 'ReasonRepositoryInterface',
      useClass: ReasonRepository,
    },
    SaleOrderExportSubcriber,
    ConfigService,
  ],
  controllers: [SaleOrderExportController],
})
export class SaleOrderExportModule {}
