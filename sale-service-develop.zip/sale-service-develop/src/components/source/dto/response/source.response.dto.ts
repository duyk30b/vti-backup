import { UserResponseDto } from '@components/user/dto/response/user.dto.response';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class BaseResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}
export class Company extends BaseResponse {}
export class Warehouse extends BaseResponse {}
export class SourceResponseDto {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  accountant: string;

  @ApiProperty()
  @Expose()
  companyId: number;

  @ApiProperty({
    description: 'tài khoản định danh',
  })
  @Expose()
  accountIdentifier: string;

  @ApiProperty()
  @Expose()
  effectiveDate: Date;

  @ApiProperty()
  @Expose()
  @Type(() => Company)
  company: Company;

  @ApiProperty()
  @Expose()
  @Type(() => Warehouse)
  warehouse: Warehouse;

  @ApiProperty()
  @Expose()
  branchCode: string;

  @ApiProperty()
  @Expose()
  produceTypeCode: string;

  @ApiProperty()
  @Expose()
  costCenterCode: string;

  @ApiProperty()
  @Expose()
  productCode: string;

  @ApiProperty()
  @Expose()
  factorialCode: string;

  @ApiProperty()
  @Expose()
  internalDepartmentCode: string;

  @ApiProperty()
  @Expose()
  departmentBackupCode: string;

  @ApiProperty()
  @Expose()
  EVNBackupCode: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  createdBy: UserResponseDto;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  updatedBy: UserResponseDto;
}
