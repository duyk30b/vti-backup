import { SOURCE_RULES, Warehouse } from '@components/source/source.constants';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsDateString,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  Matches,
  MaxLength,
} from 'class-validator';

export class CreateSourceRequestDto extends BaseDto {
  @ApiProperty({ example: '', description: 'tên source' })
  @IsString()
  @MaxLength(SOURCE_RULES.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: '', description: 'mã source' })
  @IsString()
  @MaxLength(SOURCE_RULES.CODE.MAX_LENGTH)
  @Matches(SOURCE_RULES.CODE.REGEX)
  code: string;

  @ApiProperty({ example: '', description: 'thời gian hiệu lực' })
  @IsDateString()
  effectiveDate: Date;

  @ApiProperty({ example: '', description: 'tài khoản kế toán' })
  @IsString()
  @MaxLength(SOURCE_RULES.ACCOUNTANT.MAX_LENGTH)
  @Matches(SOURCE_RULES.ACCOUNTANT.REGEX)
  accountant: string;

  @ApiProperty({ example: '', description: 'mã loại hình sản xuất kinh doanh' })
  @IsString()
  @MaxLength(SOURCE_RULES.PRODUCE_TYPE_CODE.MAX_LENGTH)
  @Matches(SOURCE_RULES.PRODUCE_TYPE_CODE.REGEX)
  produceTypeCode: string;

  @ApiProperty({ example: '', description: 'mô tả source' })
  @IsOptional()
  @IsString()
  @MaxLength(SOURCE_RULES.DESCRIPTION.MAX_LENGTH)
  description: string;

  @ApiProperty({ example: '', description: '' })
  @IsOptional()
  @IsEnum(Warehouse)
  createdFrom: Warehouse;

  @ApiProperty({ example: '', description: 'mã công ty' })
  @IsInt()
  companyId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  warehouseId: number;

  @ApiProperty({ example: '', description: 'mã chi nhánh' })
  @IsString()
  @MaxLength(SOURCE_RULES.BRANCH_CODE.MAX_LENGTH)
  @Matches(SOURCE_RULES.BRANCH_CODE.REGEX)
  branchCode: string;

  @ApiProperty({ example: '000', description: 'mã trung tâm chi phí' })
  @IsString()
  @MaxLength(SOURCE_RULES.COST_CENTER_CODE.MAX_LENGTH)
  @Matches(SOURCE_RULES.COST_CENTER_CODE.REGEX)
  costCenterCode: string;

  @ApiProperty({ example: '0000', description: 'mã sản phẩm' })
  @IsString()
  @MaxLength(SOURCE_RULES.PRODUCT_CODE.MAX_LENGTH)
  @Matches(SOURCE_RULES.PRODUCT_CODE.REGEX)
  productCode: string;

  @ApiProperty({ example: '000', description: 'mã tác nhân' })
  @IsString()
  @MaxLength(SOURCE_RULES.FACTORIAL_CODE.MAX_LENGTH)
  @Matches(SOURCE_RULES.FACTORIAL_CODE.REGEX)
  factorialCode: string;

  @ApiProperty({ example: '000000', description: 'mã đơn vị nội bộ' })
  @IsString()
  @MaxLength(SOURCE_RULES.INTERNAL_DEPARTMENT_CODE.MAX_LENGTH)
  @Matches(SOURCE_RULES.INTERNAL_DEPARTMENT_CODE.REGEX)
  internalDepartmentCode: string;

  @ApiProperty({ example: '0000', description: 'mã dự phòng đơn vị' })
  @IsString()
  @MaxLength(SOURCE_RULES.DEPARTMENT_BACKUP_CODE.MAX_LENGTH)
  @Matches(SOURCE_RULES.DEPARTMENT_BACKUP_CODE.REGEX)
  departmentBackupCode: string;

  @ApiProperty({ example: '0000', description: 'mã dự phòng EVN' })
  @IsString()
  @MaxLength(SOURCE_RULES.EVN_BACKUP_CODE.MAX_LENGTH)
  @Matches(SOURCE_RULES.EVN_BACKUP_CODE.REGEX)
  EVNBackupCode: string;

  companyCode?: string;
}
