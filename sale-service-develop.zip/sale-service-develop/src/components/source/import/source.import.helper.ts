import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { Inject } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, In } from 'typeorm';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ConfigService } from '@nestjs/config';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { ImportFileDataAbstract } from '@core/abstracts/import-file-data.abstract';
import { keyBy, uniq, isEmpty } from 'lodash';
import { SourceRepositoryInterface } from '../interface/sources.repository.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { CODE_DELIMITER } from '../source.constants';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';

export class SourceImport extends ImportFileDataAbstract {
  private readonly ROW_NUMBER_START_DATA = 0;

  private readonly FIELD_TEMPLATE_ITEM_CONST = {
    CODE: {
      DB_COL_NAME: 'code',
      COL_NAME: 'Mã source',
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    NAME: {
      DB_COL_NAME: 'name',
      COL_NAME: 'Tên source',
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    ACCOUNTIDENTIFIER: {
      DB_COL_NAME: 'accountIdentifer',
      COL_NAME: 'Tài khoản định danh',
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    DATE_FROM: {
      DB_COL_NAME: 'date_from',
      COL_NAME: 'Ngày hiệu lực (From)',
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    DATE_TO: {
      DB_COL_NAME: 'date_to',
      COL_NAME: 'Ngày hiệu lực (To)',
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    COMPANY: {
      DB_COL_NAME: 'companyCode',
      COL_NAME: 'Công ty',
      MAX_LENGTH: 20,
      ALLOW_NULL: false,
    },
    WAREHOUSE: {
      DB_COL_NAME: 'warehouseCode',
      COL_NAME: 'Mã kho',
      MAX_LENGTH: 20,
      ALLOW_NULL: false,
    },
    PRODUCE_TYPE_CODE: {
      DB_COL_NAME: 'produceTypeCode',
      COL_NAME: 'Loại hình SXKD',
      MAX_LENGTH: 20,
      ALLOW_NULL: false,
    },
    BRANCH_CODE: {
      DB_COL_NAME: 'branchCode',
      COL_NAME: 'Chi nhánh',
      MAX_LENGTH: 20,
      ALLOW_NULL: false,
    },
    PRODUCT_CODE: {
      DB_COL_NAME: 'productCode',
      COL_NAME: 'Sản phẩm',
      MAX_LENGTH: 20,
      ALLOW_NULL: false,
    },
    COST_CENTER_CODE: {
      DB_COL_NAME: 'costCenterCode',
      COL_NAME: 'Trung tâm chi phí',
      MAX_LENGTH: 20,
      ALLOW_NULL: false,
    },
    FACORIAL_CODE: {
      DB_COL_NAME: 'factorialCode',
      COL_NAME: 'Yếu tố',
      MAX_LENGTH: 20,
      ALLOW_NULL: false,
    },
    ACCOUNTANT: {
      DB_COL_NAME: 'accountant',
      COL_NAME: 'Tài khoản Kế toán',
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    INTERNAL_DEPARTMENT_CODE: {
      DB_COL_NAME: 'internalDepartmentCode',
      COL_NAME: 'Đơn vị nội bộ',
      MAX_LENGTH: 20,
      ALLOW_NULL: false,
    },
    DEPARTMENT_BACKUP_CODE: {
      DB_COL_NAME: 'departmentBackupCode',
      COL_NAME: 'Dự phòng đơn vị',
      MAX_LENGTH: 20,
      ALLOW_NULL: false,
    },
    ENV_BACKUP_CODE: {
      DB_COL_NAME: 'EVNBackupCode',
      COL_NAME: 'Dự phòng EVN',
      MAX_LENGTH: 20,
      ALLOW_NULL: false,
    },
    DESCRIPTION: {
      DB_COL_NAME: 'description',
      COL_NAME: 'Mô tả TKKT',
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    REQUIRED_COL_NUM: 16,
  };

  private readonly SHEET_NAME = this.i18n.translate(
    'file-header.SHEET_NAME_FILE_IMPORT_SOURCE',
  );

  constructor(
    @Inject('SourceRepositoryInterface')
    private readonly sourceRepository: SourceRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    this.fieldsMap.groupSet(
      [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17],
      [
        this.FIELD_TEMPLATE_ITEM_CONST.CODE,
        this.FIELD_TEMPLATE_ITEM_CONST.NAME,
        this.FIELD_TEMPLATE_ITEM_CONST.ACCOUNTIDENTIFIER,
        this.FIELD_TEMPLATE_ITEM_CONST.DATE_FROM,
        this.FIELD_TEMPLATE_ITEM_CONST.DATE_TO,
        this.FIELD_TEMPLATE_ITEM_CONST.WAREHOUSE,
        this.FIELD_TEMPLATE_ITEM_CONST.COMPANY,
        this.FIELD_TEMPLATE_ITEM_CONST.PRODUCE_TYPE_CODE,
        this.FIELD_TEMPLATE_ITEM_CONST.BRANCH_CODE,
        this.FIELD_TEMPLATE_ITEM_CONST.PRODUCT_CODE,
        this.FIELD_TEMPLATE_ITEM_CONST.COST_CENTER_CODE,
        this.FIELD_TEMPLATE_ITEM_CONST.FACORIAL_CODE,
        this.FIELD_TEMPLATE_ITEM_CONST.ACCOUNTANT,
        this.FIELD_TEMPLATE_ITEM_CONST.INTERNAL_DEPARTMENT_CODE,
        this.FIELD_TEMPLATE_ITEM_CONST.DEPARTMENT_BACKUP_CODE,
        this.FIELD_TEMPLATE_ITEM_CONST.ENV_BACKUP_CODE,
        this.FIELD_TEMPLATE_ITEM_CONST.DESCRIPTION,
      ],
    );
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
    error: number,
    total: number,
    userId?: number,
  ): Promise<ImportResponseDto> {
    const sourceCode = uniq(dataDto.map((s) => s.code));
    const companyCodes = uniq(dataDto.map((s) => s.companyCode.toString()));
    const warehouseCodes = uniq(dataDto.map((s) => s.warehouseCode.toString()));

    const warehouses = await this.warehouseService.getWarehouseByCodes(
      warehouseCodes,
    );
    const warehouseMap = keyBy(warehouses, 'code');

    const findCompanyByCode = await this.userService.getListCompanyByCodes(
      companyCodes,
    );
    const findCompanyByCodeMap = keyBy(findCompanyByCode, 'code');

    const findByCode = await this.sourceRepository.findWithRelations({
      where: {
        code: In(sourceCode),
      },
    });
    findByCode.forEach((c) => Object.assign(c, { type: 'old' }));
    const findByCodeMap = keyBy(findByCode, 'code');
    const entities = [];
    const valid = [];
    const { successMsg, unsuccessMsg } = await this.getMessage();

    const msgCompanyNotFound = await this.i18n.translate(
      'error.COMPANY_NOT_FOUND',
    );
    const msgAccountIdentifer = await this.i18n.translate(
      'error.ERR_ACCOUNTIDENTIFER',
    );

    dataDto.forEach((data) => {
      if (userId) {
        data.userId = userId;
      }

      const { i, code, companyCode, warehouseCode } = data;
      const logRow = {
        id: i,
        row: i,
      } as ImportResultDto;
      const msgLogs = [];

      let check = this.checkAccountIdentifer(data);
      check = true;

      if (
        findByCodeMap[code] &&
        findByCodeMap[code]?.['type'] === 'old' &&
        findCompanyByCodeMap[companyCode] &&
        check
      ) {
        data.companyId = findCompanyByCodeMap[companyCode].id;
        data.warehouseId = warehouseMap[warehouseCode]?.id;
        const entity = this.sourceRepository.updateEntity(
          findByCodeMap[code],
          data,
        );
        entities.push(entity);
        Object.assign(entity, { type: 'new' });
      } else if (
        !findByCodeMap[code] &&
        findCompanyByCodeMap[companyCode] &&
        check
      ) {
        data.companyId = findCompanyByCodeMap[companyCode].id;
        data.warehouseId = warehouseMap[warehouseCode]?.id;
        const entity = this.sourceRepository.createEntity(data);
        entities.push(entity);
        Object.assign(entity, { type: 'new' });
        findByCodeMap[code] = entity;
      } else {
        if (!findCompanyByCodeMap[companyCode])
          msgLogs.push(msgCompanyNotFound);
        if (!check) msgLogs.push(msgAccountIdentifer);
      }
      if (isEmpty(msgLogs)) {
        logRow.log = [successMsg];
        valid.push(logRow);
      } else {
        logRow.log = msgLogs;
        logs.push(logRow);
      }
    });

    const response = new ImportResponseDto();
    if (!isEmpty(entities)) {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(entities);
        await queryRunner.commitTransaction();
        response.successCount = valid.length;
      } catch (error) {
        await queryRunner.rollbackTransaction();
        response.successCount = 0;
        valid.forEach((l) => (l.log = [unsuccessMsg]));
      } finally {
        await queryRunner.release();
        logs.push(...valid);
      }
    }
    response.result = logs;
    response.totalCount = total;
    response.result;
    return response;
  }

  private checkAccountIdentifer(data: any) {
    const accountIdentiferCheck = [
      data.companyCode,
      data.branchCode,
      data.costCenterCode,
      data.accountant,
      data.produceTypeCode,
      data.productCode,
      data.factorialCode,
      data.internalDepartmentCode,
      data.departmentBackupCode,
      data.EVNBackupCode,
    ].join(CODE_DELIMITER);

    if (isEmpty(data.accountIdentifer)) {
      return true;
    } else {
      return accountIdentiferCheck === data.accountIdentifer;
    }
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<any>> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_ITEM_CONST.REQUIRED_COL_NUM,
      this.SHEET_NAME,
    );
  }
}
