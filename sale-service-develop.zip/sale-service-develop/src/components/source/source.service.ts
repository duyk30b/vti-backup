import { ResponseCodeEnum } from '@constant/response-code.enum';
import { SourceEntity } from '@entities/source/source.entity';
import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ResponsePayload } from '@utils/response-payload';
import { DataSource, In } from 'typeorm';
import { CreateSourceRequestDto } from './dto/request/create-source.request.dto';
import { SourceServiceInterface } from './interface/sources.interface.service';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { SourceRepositoryInterface } from './interface/sources.repository.interface';
import { UpdateSourceRequestDto } from './dto/request/update-source.request.dto';
import { DeleteSourceRequestDto } from './dto/request/delete-source.request.dto';
import { GetSourceRequestDto } from './dto/request/get-source-detail.request.dto';
import { SourceResponseDto } from './dto/response/source.response.dto';
import { plainToInstance } from 'class-transformer';
import { GetSourceListRequestDto } from './dto/request/get-source-list.request.dto';
import { PagingResponse } from '@utils/paging.response';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { uniq, map, keyBy } from 'lodash';
import {
  CODE_DELIMITER,
  CONFIRMABLE_STATUS,
  EventSyncSourceEnum,
  REJECTABLE_STATUS,
  SourceStatusEnum,
} from './source.constants';
import { generatePaddingCode } from '@utils/helper';
import { SOURCE_RULES } from '@components/source/source.constants';
import { ConfirmSourceRequestDto } from './dto/request/confirm-source.request.dto';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { GetSourceByIdsRequestDto } from './dto/request/get-source-ids.request.dto';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { SourceImport } from './import/source.import.helper';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { IMPORT_FILE_CONST } from '@constant/import.constant';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { isEmpty } from 'class-validator';

@Injectable()
export class SourceService implements SourceServiceInterface {
  constructor(
    @InjectDataSource()
    private readonly connection: DataSource,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,

    @Inject('SourceRepositoryInterface')
    private readonly sourceRepository: SourceRepositoryInterface,

    @Inject('SourceImport')
    private readonly sourceImport: SourceImport,

    private eventEmitter: EventEmitter2,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateSourceRequestDto): Promise<any> {
    const source = this.sourceRepository.createEntity(request);
    return await this.save(source);
  }

  async update(request: UpdateSourceRequestDto): Promise<any> {
    const existingSourceEntity = await this.sourceRepository.findOneById(
      request.id,
    );

    if (!existingSourceEntity) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const source = this.sourceRepository.updateEntity(
      existingSourceEntity,
      request,
    );
    return await this.save(source, true);
  }

  async delete(request: DeleteSourceRequestDto): Promise<any> {
    const source = await this.sourceRepository.findOneById(request.id);
    if (!source) {
      return new ResponseBuilder(source)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    source.deletedAt = new Date();
    source.deletedBy = request.userId;
    const result = await this.sourceRepository.create(source);
    this.eventEmitter.emit(EventSyncSourceEnum.Delete, result);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async confirm(request: ConfirmSourceRequestDto): Promise<any> {
    const source = await this.sourceRepository.findOneById(request.id);
    if (!source) {
      return new ResponseBuilder(source)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CONFIRMABLE_STATUS.includes(source.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CONFIRM'))
        .build();
    }
    try {
      source.status = SourceStatusEnum.ACTIVE;
      const result = await this.sourceRepository.create(source);
      this.eventEmitter.emit(EventSyncSourceEnum.Confirm, result);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async reject(request: ConfirmSourceRequestDto): Promise<any> {
    const source = await this.sourceRepository.findOneById(request.id);
    if (!source) {
      return new ResponseBuilder(source)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!REJECTABLE_STATUS.includes(source.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_REJECT'))
        .build();
    }
    try {
      source.status = SourceStatusEnum.INACTIVE;
      const result = await this.sourceRepository.create(source);
      this.eventEmitter.emit(EventSyncSourceEnum.Reject, result);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getDetail(request: GetSourceRequestDto): Promise<any> {
    const source = await this.sourceRepository.findOneById(request.id);

    if (!source) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const response = await this.generateRespone(source);
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(request: GetSourceListRequestDto): Promise<any> {
    const { page } = request;
    const [data, count] = await this.sourceRepository.getList(request);
    const warehouseIds = [];
    const creatorIds = [];
    const updaterIds = [];
    data.forEach((item) => {
      warehouseIds.push(item.warehouseId);
      creatorIds.push(item.createdBy);
      updaterIds.push(item.updatedBy);
    });
    const userIds = uniq([...creatorIds, ...updaterIds]);
    const users = await this.userService.getUsers(uniq(userIds), true);
    const warehouses = await this.warehouseService.getWarehouses(warehouseIds);
    const warehouseMap = keyBy(warehouses, 'id');
    data.forEach((item) => {
      item.createdBy = users[item.createdBy];
      item.updatedBy = users[item.updatedBy];
      item.warehouse = warehouseMap[item.warehouseId];
    });
    const companyIds = map(data, 'companyId');
    const companies = await this.userService.getCompanies(companyIds, true);
    let companyCode;
    let accountIdentifier;
    data.forEach((item) => {
      companyCode = generatePaddingCode(
        companies[item.companyId]?.code,
        SOURCE_RULES.COMPANY_CODE.MAX_LENGTH,
      );
      accountIdentifier = [
        companyCode,
        item.branchCode,
        item.costCenterCode,
        item.accountant,
        item.produceTypeCode,
        item.productCode,
        item.factorialCode,
        item.internalDepartmentCode,
        item.departmentBackupCode,
        item.EVNBackupCode,
      ].join(CODE_DELIMITER);
      item.accountIdentifier = accountIdentifier;
    });

    const dataReturn = plainToInstance(SourceResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async save(
    sourceEntity: SourceEntity,
    isUpdate = false,
  ): Promise<ResponsePayload<any> | any> {
    const warehouse = await this.warehouseService.getDetailById(
      sourceEntity.warehouseId,
    );

    if (isEmpty(warehouse)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
        .build();
    }

    const existCompany = await this.userService.getCompanyById(
      sourceEntity.companyId,
    );
    if (!existCompany) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.COMPANY_NOT_FOUND'))
        .build();
    }
    // save company code
    sourceEntity.companyCode = generatePaddingCode(
      existCompany.code,
      SOURCE_RULES.COMPANY_CODE.MAX_LENGTH,
    );
    try {
      const result = await this.sourceRepository.create(sourceEntity);
      const response = await this.generateRespone(result);
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder(error)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .build();
    }
  }

  private async generateRespone(
    sourceEntity: SourceEntity,
  ): Promise<SourceResponseDto> {
    const userIds = [sourceEntity.createdBy, sourceEntity.updatedBy];
    const users = await this.userService.getUsers(uniq(userIds), true);
    sourceEntity.createdBy = users[sourceEntity.createdBy];
    sourceEntity.updatedBy = users[sourceEntity.updatedBy];
    const company = await this.userService.getCompanyById(
      sourceEntity.companyId,
    );
    const warehouse = await this.warehouseService.getDetailById(
      sourceEntity.warehouseId,
    );
    const companyCode = generatePaddingCode(
      company.code,
      SOURCE_RULES.COMPANY_CODE.MAX_LENGTH,
    );
    const accountIdentifier = [
      companyCode,
      sourceEntity.branchCode,
      sourceEntity.costCenterCode,
      sourceEntity.accountant,
      sourceEntity.produceTypeCode,
      sourceEntity.productCode,
      sourceEntity.factorialCode,
      sourceEntity.internalDepartmentCode,
      sourceEntity.departmentBackupCode,
      sourceEntity.EVNBackupCode,
    ].join(CODE_DELIMITER);
    const response = plainToInstance(
      SourceResponseDto,
      { ...sourceEntity, accountIdentifier, company, warehouse },
      {
        excludeExtraneousValues: true,
      },
    );

    return response;
  }

  public async getSourceByIds(request: GetSourceByIdsRequestDto): Promise<any> {
    const result = await this.sourceRepository.findByCondition({
      id: In(request.sourceIds),
    });
    const response = plainToInstance(SourceResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }

  async importFileSource(request: FileUpdloadRequestDto): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
      userId: request.userId,
    } as ImportRequestDto;
    const result = await this.sourceImport.importUtil(importRequestDto);
    if (result?.statusCode !== ResponseCodeEnum.SUCCESS) return result;
    const { data } = result;
    const successCount = data?.successCount ?? 0;
    const totalCount = data?.totalCount ?? 0;
    const logs = [];
    const succ = await this.i18n.translate('error.SUCCESS');
    const dataStart = IMPORT_FILE_CONST.SHEET.DATA_START_ROW;
    if (successCount < totalCount) {
      await data?.result.map(async (item) => {
        if (item.log[0] !== succ) {
          const log = item.log[0].toLowerCase();
          const row = dataStart + item.row;
          const mess = await this.i18n.translate('error.ERROR_RESPONSE', {
            args: {
              row: row,
              log: log,
            },
          });
          logs.push(mess);
        }
      });
      return new ResponseBuilder({
        successCount: successCount,
        totalCount: totalCount,
        logs: logs,
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          logs[0] ? logs[0] : await this.i18n.translate('error.BAD_REQUEST'),
        )
        .build();
    }

    return new ResponseBuilder({
      successCount: successCount,
      totalCount: totalCount,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
