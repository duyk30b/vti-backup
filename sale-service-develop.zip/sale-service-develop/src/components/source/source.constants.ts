export enum Warehouse {
  AVENUE = '0',
}

export enum SourceStatusEnum {
  INACTIVE = 0,
  ACTIVE = 1,
}

export const CONFIRMABLE_STATUS = [SourceStatusEnum.INACTIVE];

export const REJECTABLE_STATUS = [SourceStatusEnum.ACTIVE];

export const CODE_DELIMITER = '.';

export const SOURCE_RULES = {
  NAME: {
    MAX_LENGTH: 100,
  },
  CODE: {
    MAX_LENGTH: 50,
    REGEX:
      /^[a-zA-Z0-9ÀÁÂÃÈÉÊẾÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêếìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀỀỂưăạảấầẩẫậắằẳẵặẹẻẽềềểỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợụủứừỬỮỰỲỴÝỶỸửữựỳỵỷỹ\s&,\/._]+$/,
  },
  ACCOUNTANT: {
    MAX_LENGTH: 12,
    REGEX: /^[0-9]{1,12}$/,
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
  CREATED_FROM: {
    MAX_LENGTH: 255,
  },
  BRANCH_CODE: {
    MAX_LENGTH: 6,
    REGEX: /^[0-9]{6}$/,
  },
  COST_CENTER_CODE: {
    MAX_LENGTH: 3,
    REGEX: /^[0-9]{3}$/,
  },
  PRODUCT_CODE: {
    MAX_LENGTH: 4,
    REGEX: /^[0-9]{4}$/,
  },
  PRODUCE_TYPE_CODE: {
    MAX_LENGTH: 4,
    REGEX: /^[0-9]{4}$/,
  },
  FACTORIAL_CODE: {
    MAX_LENGTH: 3,
    REGEX: /^[0-9]{3}$/,
  },
  INTERNAL_DEPARTMENT_CODE: {
    MAX_LENGTH: 6,
    REGEX: /^[0-9]{6}$/,
  },
  DEPARTMENT_BACKUP_CODE: {
    MAX_LENGTH: 4,
    REGEX: /^[0-9]{4}$/,
  },
  EVN_BACKUP_CODE: {
    MAX_LENGTH: 4,
    REGEX: /^[0-9]{4}$/,
  },
  COMPANY_CODE: {
    MAX_LENGTH: 6,
  },
};

export enum EventSyncSourceEnum {
  Create = 'event.syncSource.create',
  Update = 'event.syncSource.update',
  Confirm = 'event.syncSource.confirm',
  Reject = 'event.syncSource.reject',
  Delete = 'event.syncSource.delete',
}
