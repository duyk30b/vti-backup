import { SourceEntity } from '@entities/source/source.entity';
import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SourceController } from './source.controller';
import { SourceRepository } from '@repositories/source/source.repository';
import { SourceService } from './source.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { BullModule } from '@nestjs/bull';
import { SyncDataModule } from '@components/sync-data/sync-data.module';
import { QUEUES_NAME_ENUM } from '@constant/common';
import { SourceImport } from './import/source.import.helper';

@Global()
@Module({
  imports: [
    TypeOrmModule.forFeature([SourceEntity]),
    BullModule.registerQueue({
      name: QUEUES_NAME_ENUM.SYNC_DATA_QUEUE,
    }),
    UserModule,
    SyncDataModule,
  ],
  exports: [],
  providers: [
    {
      provide: 'SourceRepositoryInterface',
      useClass: SourceRepository,
    },
    {
      provide: 'SourcesServiceInterface',
      useClass: SourceService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'SourceImport',
      useClass: SourceImport,
    },
  ],
  controllers: [SourceController],
})
export class SourceModule {}
