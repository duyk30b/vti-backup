import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { CreateSourceRequestDto } from './dto/request/create-source.request.dto';
import { isEmpty } from 'lodash';
import { SourceServiceInterface } from './interface/sources.interface.service';
import { UpdateSourceBodyDto } from './dto/request/update-source.request.dto';
import { DeleteSourceRequestDto } from './dto/request/delete-source.request.dto';
import { GetSourceListRequestDto } from './dto/request/get-source-list.request.dto';
import { SourceResponseDto } from './dto/response/source.response.dto';
import { GetSourceRequestDto } from './dto/request/get-source-detail.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  DELETE_SOURCE_PERMISSION,
  CREATE_SOURCE_PERMISSION,
  DETAIL_SOURCE_PERMISSION,
  UPDATE_SOURCE_PERMISSION,
  LIST_SOURCE_PERMISSION,
  CONFIRM_SOURCE_PERMISSION,
  REJECT_SOURCE_PERMISSION,
} from '@utils/permissions/source';
import { ConfirmSourceRequestDto } from './dto/request/confirm-source.request.dto';
import { MessagePattern } from '@nestjs/microservices';
import { GetSourceByIdsRequestDto } from './dto/request/get-source-ids.request.dto';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { NATS_SALE } from '@config/nats.config';

@Controller('sources')
export class SourceController {
  constructor(
    @Inject('SourcesServiceInterface')
    private readonly sourceService: SourceServiceInterface,
  ) {}

  @PermissionCode(CREATE_SOURCE_PERMISSION.code)
  @Post('create')
  @ApiOperation({
    tags: ['Source'],
    summary: 'Create new source',
    description: 'Tạo 1 source mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async create(@Body() body: CreateSourceRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.sourceService.create(request);
  }

  @PermissionCode(UPDATE_SOURCE_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Source'],
    summary: 'Update source',
    description: 'Sửa source',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async update(
    @Body() body: UpdateSourceBodyDto,
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.sourceService.update({ ...request, id });
  }

  @PermissionCode(DELETE_SOURCE_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Source'],
    summary: 'Delete source',
    description: 'Xóa source',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async delete(@Param() param: DeleteSourceRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.sourceService.delete(request);
  }

  @PermissionCode(CONFIRM_SOURCE_PERMISSION.code)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Source'],
    summary: 'Confirm source',
    description: 'Xác nhận source',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: null,
  })
  public async confirm(@Param() param: ConfirmSourceRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.sourceService.confirm(request);
  }

  @PermissionCode(REJECT_SOURCE_PERMISSION.code)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Source'],
    summary: 'Reject source',
    description: 'Từ chối source',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: null,
  })
  public async reject(@Param() param: ConfirmSourceRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.sourceService.reject(request);
  }

  @PermissionCode(DETAIL_SOURCE_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Source'],
    summary: 'Get source',
    description: 'Lấy source',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: SourceResponseDto,
  })
  public async getDetail(@Param() param: GetSourceRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.sourceService.getDetail(request);
  }

  // @PermissionCode(LIST_SOURCE_PERMISSION.code)
  @Get('list')
  @ApiOperation({
    tags: ['Source'],
    summary: 'Get list source',
    description: 'Lấy danh sách source',
  })
  @ApiResponse({
    status: 200,
    description: 'Get list successfully',
    type: null,
  })
  public async getList(@Query() query: GetSourceListRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.sourceService.getList(request);
  }
  @MessagePattern(`${NATS_SALE}.get_source_detail`)
  public async getDetailTcp(@Body() param: GetSourceRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.sourceService.getDetail(request);
  }

  @PermissionCode(LIST_SOURCE_PERMISSION.code)
  @Post('/import')
  @ApiOperation({
    tags: ['Source'],
    summary: 'import list source',
    description: 'import danh sách source',
  })
  @ApiResponse({
    status: 200,
    description: 'import list successfully',
    type: null,
  })
  public async importCategoryContructions(@Body() body: FileUpdloadRequestDto) {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.sourceService.importFileSource(request);
  }

  @MessagePattern(`${NATS_SALE}.get_source_by_ids`)
  public async getSourceByIds(
    @Body() payload: GetSourceByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.sourceService.getSourceByIds(request);
  }
}
