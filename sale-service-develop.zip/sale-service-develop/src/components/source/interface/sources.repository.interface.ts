import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { SourceEntity } from '@entities/source/source.entity';
import { CreateSourceRequestDto } from '../dto/request/create-source.request.dto';
import { GetSourceListRequestDto } from '../dto/request/get-source-list.request.dto';
import { UpdateSourceRequestDto } from '../dto/request/update-source.request.dto';

export interface SourceRepositoryInterface
  extends BaseInterfaceRepository<SourceEntity> {
  createEntity(request: CreateSourceRequestDto): SourceEntity;
  updateEntity(
    source: SourceEntity,
    request: UpdateSourceRequestDto,
  ): SourceEntity;
  getList(request: GetSourceListRequestDto): Promise<any>;
}
