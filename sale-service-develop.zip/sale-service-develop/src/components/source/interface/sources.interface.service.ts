import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { ResponsePayload } from '@utils/response-payload';
import { ConfirmSourceRequestDto } from '../dto/request/confirm-source.request.dto';
import { CreateSourceRequestDto } from '../dto/request/create-source.request.dto';
import { DeleteSourceRequestDto } from '../dto/request/delete-source.request.dto';
import { GetSourceRequestDto } from '../dto/request/get-source-detail.request.dto';
import { GetSourceByIdsRequestDto } from '../dto/request/get-source-ids.request.dto';
import { GetSourceListRequestDto } from '../dto/request/get-source-list.request.dto';
import { UpdateSourceRequestDto } from '../dto/request/update-source.request.dto';
import { SourceResponseDto } from '../dto/response/source.response.dto';

export interface SourceServiceInterface {
  getDetail(request: GetSourceRequestDto): Promise<any>;
  getList(request: GetSourceListRequestDto): Promise<any>;
  create(request: CreateSourceRequestDto): Promise<any>;
  update(request: UpdateSourceRequestDto): Promise<any>;
  delete(request: DeleteSourceRequestDto): Promise<any>;
  confirm(request: ConfirmSourceRequestDto): Promise<any>;
  reject(request: ConfirmSourceRequestDto): Promise<any>;
  getSourceByIds(request: GetSourceByIdsRequestDto): Promise<any>;
  importFileSource(request: FileUpdloadRequestDto): Promise<any>;
}
