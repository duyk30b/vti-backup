import { ResponsePayload } from '@utils/response-payload';
import { GetAllSORequest } from '../dto/request/get-all-sale-order.request.dto';
import { GetByItemIdRequestDto } from '@components/purchased-order/dto/request/get-by-item-id.request.dto';
import { UpdateSaleOrderDto } from '../dto/request/update-sale-order-request.dto';
import { CreateSaleOrderRequestDto } from '../dto/request/create-sale-order-request.dto';
import { GetSaleOrderListRequest } from '../dto/request/get-sale-order-list-request.dto';
import { GetOrderDetailRequestDto } from '@components/order/dto/request/get-order-detail.request.dto';
import { SetOrderStatusRequestDto } from '@components/order/dto/request/set-order-status-request.dto';
import { DeleteOrderRequestDto } from '@components/order/dto/request/delete-order.request.dto';
import { GetListOrderByIdsRequestDto } from '@components/order/dto/request/get-list-order-by-ids.request.dto';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { UpdateSoIsHasPlanRequestDto } from '../dto/request/update-so-is-has-plan.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { UpdateProducedQuantityRequestDto } from '../dto/request/update-produced-quantity.request.dto';
import { GetStatisticProgressProductionBySoRequestDto } from '../dto/request/get-statistic-progress-production-by-so.request.dto';

export interface SaleOrderServiceInterface {
  create(payload: CreateSaleOrderRequestDto): Promise<any>;
  update(payload: UpdateSaleOrderDto): Promise<any>;
  getList(payload: GetSaleOrderListRequest): Promise<any>;
  getDetail(payload: GetOrderDetailRequestDto): Promise<any>;
  confirm(payload: SetOrderStatusRequestDto): Promise<any>;
  reject(payload: SetOrderStatusRequestDto): Promise<any>;
  approve(payload: SetOrderStatusRequestDto): Promise<any>;
  delete(payload: DeleteOrderRequestDto): Promise<any>;
  confirmMultiple(request: DeleteMultipleDto): Promise<any>
  deleteMultiple(request: DeleteMultipleDto): Promise<any>
  getSaleOrders(request: GetAllSORequest): Promise<ResponsePayload<any>>;
  checkItemHasExistOnSaleOrder(request: GetByItemIdRequestDto): Promise<any>;
  getListByIds(payload: GetListOrderByIdsRequestDto): Promise<any>;
  getSaleOrderByRelation(req: any): Promise<ResponsePayload<any>>;
  getSaleOrdersByNameKeyword(nameKeyword: any): Promise<any>;
  getSaleOrdersByCodeKeyword(codeKeyword: any): Promise<any>;
  importSalesOrder(request: FileUpdloadRequestDto): Promise<any>;
  updateSoIsHasPlan(request: UpdateSoIsHasPlanRequestDto): Promise<any>;
  updateProducedQuantity(
    request: UpdateProducedQuantityRequestDto,
  ): Promise<any>;
  getStatisticProductionProgressBySo(
    request: GetStatisticProgressProductionBySoRequestDto,
  ): Promise<any>
}
