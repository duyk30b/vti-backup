import { OrderDetailRepositoryInterface } from '@components/order/interface/order-detail.repository.interface';
import { SaleOrderDetail } from '@entities/sale-order/sale-order-detail.entity';

export interface SaleOrderDetailRepositoryInterface
  extends OrderDetailRepositoryInterface<SaleOrderDetail> {}
