import { OrderRepositoryInterface } from '@components/order/interface/order.repository.interface';
import { SaleOrder } from '@entities/sale-order/sale-order.entity';

export interface SaleOrderRepositoryInterface
  extends OrderRepositoryInterface<SaleOrder> {
  findSaleOrdersByNameKeyword(nameKeyword: any): Promise<any>;
  getCount(): Promise<any>;
  checkReadyToProduced(id: number): Promise<any>;
  checkComplete(id: number): Promise<any>;
}
