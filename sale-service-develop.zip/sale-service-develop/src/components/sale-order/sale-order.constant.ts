import { Order } from '@components/return-order/dto/response/return-order-response.dto';
import { OrderStatusEnum } from '@constant/common';

export enum LEVEL_PACKING {
  LEVEL_1 = 1,
  LEVEL_2 = 2,
}

export enum SUPPLIER {
  COMPANY = 1,
  CUSTOMER = 2,
}

export const SUPPLIER_TEXT = {
  [SUPPLIER.COMPANY]: 'Oshii',
  [SUPPLIER.CUSTOMER]: 'Khách hàng',
};

export enum ManufacturingOrderStatusEnum {
  PENDING = 0,
  CONFIRMED = 1,
  REJECTED = 2,
  IN_PROGRESS = 3,
  COMPLETED = 4,
}

export const CANNOT_PRODUCE_STATUS = [
  OrderStatusEnum.Pending,
  OrderStatusEnum.RejectReceived,
  OrderStatusEnum.Reject,
];

export const CAN_UPDATE_SALE_ORDER_STATUS: number[] = [
  OrderStatusEnum.Pending,
  OrderStatusEnum.Reject,
  OrderStatusEnum.Confirmed,
  OrderStatusEnum.Planned,
  OrderStatusEnum.InProgress,
  OrderStatusEnum.Produced,
  OrderStatusEnum.InDelivering,
];

export const STATUS_TO_COMPLETE_SALE_ORDER_STATUS: number[] = [
  OrderStatusEnum.Confirmed,
  OrderStatusEnum.Planned,
  OrderStatusEnum.InProgress,
  OrderStatusEnum.Produced,
  OrderStatusEnum.InDelivering,
];

export const UPDATE_BOM_VERSION_SALE_ORDER_STATUS = [
  OrderStatusEnum.Pending,
  OrderStatusEnum.Confirmed,
  OrderStatusEnum.Reject,
];
