import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ImportDataAbstract } from '@core/abstracts/import-data.abstract';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectDataSource } from '@nestjs/typeorm';
import { ResponsePayload } from '@utils/response-payload';
import { compact, isEmpty, keyBy, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, In } from 'typeorm';
import { SaleOrderRepositoryInterface } from '../interface/sale-order.repository.interface';
import * as Moment from 'moment';
import { extendMoment } from 'moment-range';
import { CAN_UPDATE_ORDER_STATUS } from '@constant/order.constant';
import { CustomerRepositoryInterface } from '@components/customer/interface/customer.repository.interface';
import { SaleOrder } from '@entities/sale-order/sale-order.entity';
import { Customer } from '@entities/customer/customer.entity';
const moment = extendMoment(Moment);

@Injectable()
export class SaleOrdersImport extends ImportDataAbstract {
  private readonly FIELD_TEMPLATE_SALE_ORDER_CONST = {
    SALE_ORDER_CODE: {
      DB_COL_NAME: 'saleOrderCode',
      COL_NAME: [
        'Sale order code',
        '受注書コード受注書コード受注書コード',
        'Mã đơn bán hàng',
      ],
      MAX_LENGTH: 12,
      ALLOW_NULL: false,
    },
    SALE_ORDER_NAME: {
      DB_COL_NAME: 'saleOrderName',
      COL_NAME: ['Sale order name', '受注書名', 'Tên đơn bán hàng'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    BOQ_CODE: {
      DB_COL_NAME: 'boqCode',
      COL_NAME: ['BOQ code', 'BOQコード', 'Mã công trình'],
      MAX_LENGTH: 20,
      ALLOW_NULL: true,
    },
    SALE_ORDER_AT: {
      DB_COL_NAME: 'saleOrderAt',
      COL_NAME: ['Sale date', '販売日を選択', 'Ngày bán hàng'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    COMPANY_CODE: {
      DB_COL_NAME: 'companyCode',
      COL_NAME: ['Company code', '会社コード', 'Mã công ty'],
      MAX_LENGTH: 9,
      ALLOW_NULL: false,
    },
    CUSTOMER_CODE: {
      DB_COL_NAME: 'customerCode',
      COL_NAME: ['Customer code', '顧客コード', 'Mã khách hàng'],
      MAX_LENGTH: 20,
      ALLOW_NULL: false,
    },
    SALE_ORDER_DEADLINE_AT: {
      DB_COL_NAME: 'saleOrderDeadLineAt',
      COL_NAME: ['Delivery date', '納品日', 'Ngày giao hàng'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    SALE_ORDER_DESCRIPTION: {
      DB_COL_NAME: 'saleOrderDescription',
      COL_NAME: ['Description', '受注書説明', 'Mô tả đơn bán hàng'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    REQUIRED_COL_NUM: 9,
  };

  private readonly SHEET_NAME = 'Sale order';
  private readonly ROW_NUMBER_START_DATA = 2;

  constructor(
    @Inject('CustomerRepositoryInterface')
    private readonly customerRepositoryRepository: CustomerRepositoryInterface,

    @Inject('SaleOrderRepositoryInterface')
    private readonly saleOrderRepository: SaleOrderRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ProduceServiceInterface')
    private readonly produceService: ProduceServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    const arrayField = [];
    for (const [key, value] of Object.entries(
      this.FIELD_TEMPLATE_SALE_ORDER_CONST,
    )) {
      arrayField.push(value);
    }

    this.fieldsMap.groupSet(arrayField, this.ROW_NUMBER_START_DATA);
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
    error: number,
    total: number,
    userId?: number,
  ): Promise<ImportResponseDto | any> {
    const saleOrderCodeImport = [];
    const boqCodeImport = [];
    const customerCodeImport = [];
    const companyCodeImport = [];

    for (let i = 0; i < dataDto.length; i++) {
      saleOrderCodeImport.push(dataDto[i].saleOrderCode);
      boqCodeImport.push(dataDto[i].boqCode);
      customerCodeImport.push(dataDto[i].customerCode);
      companyCodeImport.push(dataDto[i].companyCode);
    }
    const [saleOrdersFind, boqsFind, customersFind, companiesFind] =
      await Promise.all([
        this.saleOrderRepository.findByCondition({
          code: In(compact(uniq(saleOrderCodeImport))),
        }),
        this.produceService.getBoqByCodes(compact(uniq(boqCodeImport))),
        this.customerRepositoryRepository.findByCondition({
          code: In(compact(uniq(customerCodeImport))),
        }),
        this.userService.getListCompanyByCodes(
          compact(uniq(companyCodeImport)),
        ),
      ]);
    const saleOrders = keyBy(saleOrdersFind, 'code');
    const boqs = keyBy(boqsFind, 'code');
    const customers = keyBy(customersFind, 'code');
    const companies = keyBy(companiesFind, 'code');

    const messages = await this.getMessage();
    const entities = [];
    const valid = [];
    const response = new ImportResponseDto();

    dataDto.forEach((record) => {
      const {
        i,
        action,
        saleOrderCode,
        boqCode,
        customerCode,
        companyCode,
        saleOrderName,
        saleOrderAt,
        saleOrderDeadLineAt,
        saleOrderDescription,
      } = record;
      if (action !== messages.addText && action !== messages.updateText) {
        return;
      }
      const logRow = {
        id: i,
        row: i,
        action: action,
      } as ImportResultDto;
      const saleOrderOld = saleOrders[saleOrderCode]
        ? saleOrders[saleOrderCode]
        : null;
      const company = companies[companyCode] ? companies[companyCode] : null;
      const customer = customers[customerCode] ? customers[customerCode] : null;
      const boq = boqs[boqCode] ? boqs[boqCode] : null;
      let msgLog = '';
      if (action.toLowerCase() === messages.addText) {
        msgLog = this.validateDataSaleOrder(
          false,
          record,
          saleOrderOld,
          company,
          customer,
          boq,
          messages,
        );
      }
      if (action.toLowerCase() === messages.updateText) {
        msgLog = this.validateDataSaleOrder(
          true,
          record,
          saleOrderOld,
          company,
          customer,
          boq,
          messages,
        );
      }
      const sameSaleOrderNew = dataDto.filter(
        (i) => i.saleOrderCode === saleOrderCode,
      );
      if (sameSaleOrderNew.length > 1) {
        msgLog = messages.saleOrderCodeDuplicate;
      }

      if (msgLog === '') {
        const saleOrderEntity = new SaleOrder();
        saleOrderEntity.code = saleOrderCode;
        saleOrderEntity.name = saleOrderName;
        saleOrderEntity.description = saleOrderDescription;
        saleOrderEntity.boqId = boqCode !== '' ? boq.id : null;
        saleOrderEntity.companyId = company.id;
        saleOrderEntity.customerId = customer.id;
        saleOrderEntity.orderedAt = saleOrderAt;
        saleOrderEntity.deadline = saleOrderDeadLineAt;
        saleOrderEntity.createdByUserId = userId;
        if (action.toLowerCase() === messages.updateText) {
          saleOrderEntity.id = saleOrderOld.id;
        }

        entities.push(saleOrderEntity);
        logRow.log = [messages.successMsg];
        valid.push(logRow);
      } else {
        logRow.log = [msgLog];
        logs.push(logRow);
      }
    });

    if (!isEmpty(entities)) {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(SaleOrder, entities);
        await queryRunner.commitTransaction();
        response.successCount = valid.length;
      } catch (error) {
        await queryRunner.rollbackTransaction();
        response.successCount = 0;
        valid.forEach((e) => (e.log = [messages.unsuccessMsg]));
      } finally {
        await queryRunner.release();
        logs.push(...valid);
      }
    }

    response.result = logs;
    response.totalCount = total;

    return response;
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<ImportResponseDto>> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_SALE_ORDER_CONST.REQUIRED_COL_NUM,
      this.SHEET_NAME,
    );
  }

  private validateDataSaleOrder(
    isUpdate: boolean,
    saleOrderNew: any,
    saleOrderOld: SaleOrder,
    company: any,
    customer: Customer,
    boq: any,
    messages: any,
  ): any {
    const {
      saleOrderCodeNotExist,
      saleOrderCodeIsExist,
      companyCodeNotExist,
      customerCodeNotExist,
      boqCodeNotExist,
      saleOrderAtMustBeGreaterThanDeadlineAt,
      saleOrderWasConfirmed,
    } = messages;

    const {
      saleOrderCode,
      boqCode,
      customerCode,
      companyCode,
      saleOrderName,
      saleOrderAt,
      saleOrderDeadLineAt,
      saleOrderDescription,
    } = saleOrderNew;
    if (isUpdate) {
      if (!saleOrderOld) {
        return saleOrderCodeNotExist;
      }
      if (!CAN_UPDATE_ORDER_STATUS.includes(saleOrderOld.status)) {
        return saleOrderWasConfirmed;
      }
    } else {
      if (saleOrderOld) {
        return saleOrderCodeIsExist;
      }
    }
    if (!company) {
      return companyCodeNotExist;
    }
    if (!customer) {
      return customerCodeNotExist;
    }
    if (boqCode !== '' && !boq) {
      return boqCodeNotExist;
    }
    if (moment(saleOrderAt).isSameOrBefore(moment(saleOrderDeadLineAt))) {
      return saleOrderAtMustBeGreaterThanDeadlineAt;
    }
    return '';
  }
}
