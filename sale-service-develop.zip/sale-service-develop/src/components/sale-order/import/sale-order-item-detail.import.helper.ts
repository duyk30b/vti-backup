import { ImportDataAbstract } from '@core/abstracts/import-data.abstract';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectDataSource } from '@nestjs/typeorm';
import { ResponsePayload } from '@utils/response-payload';
import { compact, isEmpty, keyBy, map, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, In } from 'typeorm';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { CAN_UPDATE_ORDER_STATUS } from '@constant/order.constant';
import { SaleOrderRepositoryInterface } from '../interface/sale-order.repository.interface';
import { SaleOrderDetail } from '@entities/sale-order/sale-order-detail.entity';
import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';

@Injectable()
export class SaleOrderItemDetailsImport extends ImportDataAbstract {
  private readonly FIELD_TEMPLATE_SALE_ORDER_DETAIL_CONST = {
    SALE_ORDER_CODE: {
      DB_COL_NAME: 'saleOrderCode',
      COL_NAME: [
        'Mã đơn bán hàng',
        'Sale order code',
        '受注書コード受注書コード受注書コード',
      ],
      MAX_LENGTH: 12,
      ALLOW_NULL: false,
    },
    ITEM_CODE: {
      DB_COL_NAME: 'itemCode',
      COL_NAME: ['Item code', '商品コード', 'Mã sản phẩm'],
      MAX_LENGTH: 7,
      ALLOW_NULL: false,
    },
    SALE_ORDER_ITEM_QUANTITY: {
      DB_COL_NAME: 'saleOrderItemQuantity',
      COL_NAME: ['Số lượng', 'Quantity', '額'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    REQUIRED_COL_NUM: 4,
  };

  private readonly SHEET_NAME = 'Item detail';
  private readonly ROW_NUMBER_START_DATA = 2;

  constructor(
    @Inject('SaleOrderRepositoryInterface')
    private readonly saleOrderRepository: SaleOrderRepositoryInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    @Inject('ProduceServiceInterface')
    private readonly produceService: ProduceServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    const arrayField = [];
    for (const [key, value] of Object.entries(
      this.FIELD_TEMPLATE_SALE_ORDER_DETAIL_CONST,
    )) {
      arrayField.push(value);
    }

    this.fieldsMap.groupSet(arrayField, this.ROW_NUMBER_START_DATA);
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
    error: number,
    total: number,
    userId?: number,
  ): Promise<ImportResponseDto | any> {
    const saleOrderCodeImport = [];
    const itemCodeImport = [];

    for (let i = 0; i < dataDto.length; i++) {
      saleOrderCodeImport.push(dataDto[i].saleOrderCode);
      itemCodeImport.push(dataDto[i].itemCode);
    }
    const [saleOrderFind, itemFind] = await Promise.all([
      this.saleOrderRepository.findByCondition({
        code: In(compact(uniq(saleOrderCodeImport))),
      }),
      this.itemService.getItemByCodes(compact(uniq(itemCodeImport))),
    ]);

    const items = keyBy(itemFind, 'code');

    const boqIds = uniq(map(saleOrderFind, 'boqId'));
    const boqs =
      boqIds.length !== 0
        ? await this.produceService.getBoqByIds(boqIds, true)
        : [];

    const saleOrders = keyBy(
      saleOrderFind.map((record) => ({
        ...record,
        boq: boqs[record.boqId] ? boqs[record.boqId] : {},
      })),
      'code',
    );
    const messages = await this.getMessage();
    const entities = {
      saleOrderDetails: [],
    };
    const valid = [];
    const response = new ImportResponseDto();

    dataDto.forEach((record) => {
      const { i, action, saleOrderCode, itemCode, purchasedOrderItemQuantity } =
        record;
      const logRow = {
        id: i,
        row: i,
        action: action,
      } as ImportResultDto;
      const saleOrder = saleOrders[saleOrderCode]
        ? saleOrders[saleOrderCode]
        : null;
      const item = items[itemCode] ? items[itemCode] : null;

      let msgLog = '';
      msgLog = this.validateDataPurchasedOrderItemDetail(
        record,
        saleOrder,
        item,
        messages,
      );
      const sameItemInSaleOrder = dataDto.filter(
        (i) => i.itemCode === itemCode && i.saleOrderCode === saleOrderCode,
      );
      if (sameItemInSaleOrder.length > 1) {
        msgLog = messages.sameItemCodeInSaleOrder;
      }

      if (msgLog === '') {
        const saleOrderDetailEntity = new SaleOrderDetail();
        saleOrderDetailEntity.saleOrderId = saleOrder.id;
        saleOrderDetailEntity.itemId = item.id;
        saleOrderDetailEntity.quantity = purchasedOrderItemQuantity;

        entities.saleOrderDetails.push(saleOrderDetailEntity);

        logRow.log = [messages.successMsg];
        valid.push(logRow);
      } else {
        logRow.log = [msgLog];
        logs.push(logRow);
      }
    });

    if (!isEmpty(entities.saleOrderDetails)) {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        const saleOrderIds = uniq(
          map(entities.saleOrderDetails, 'saleOrderId'),
        );

        await queryRunner.manager.delete(SaleOrderDetail, {
          saleOrderId: In(saleOrderIds),
        });

        await queryRunner.manager.save(
          SaleOrderDetail,
          entities.saleOrderDetails,
        );

        await queryRunner.commitTransaction();
        response.successCount = valid.length;
      } catch (error) {
        await queryRunner.rollbackTransaction();
        response.successCount = 0;
        valid.forEach((e) => (e.log = [messages.unsuccessMsg]));
      } finally {
        await queryRunner.release();
        logs.push(...valid);
      }
    }

    response.result = logs;
    response.totalCount = total;

    return response;
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<ImportResponseDto>> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_SALE_ORDER_DETAIL_CONST.REQUIRED_COL_NUM,
      this.SHEET_NAME,
    );
  }

  private validateDataPurchasedOrderItemDetail(
    data: any,
    saleOrder: any,
    item: any,
    messages: any,
  ): any {
    const {
      saleOrderCodeNotExist,
      itemCodeNotExist,
      quantityMustBeGreaterThanZero,
      saleOrderWasConfirmed,
      itemCodeIsNotInBoqDetail,
      quantityItemGreaterThanQuantityBoq,
    } = messages;

    const { saleOrderCode, itemCode, saleOrderItemQuantity } = data;

    if (!saleOrder) {
      return saleOrderCodeNotExist;
    }
    if (!CAN_UPDATE_ORDER_STATUS.includes(saleOrder.status)) {
      return saleOrderWasConfirmed;
    }
    if (!item) {
      return itemCodeNotExist;
    }
    if (Number(saleOrderItemQuantity) < 0) {
      return quantityMustBeGreaterThanZero;
    }
    const itemIdInBoq = map(saleOrder.boq.boqDetails, 'itemId');

    if (itemIdInBoq.includes(item.id)) {
      const boqDetails = keyBy(saleOrder.boq.boqDetails, 'itemId');
      if (
        Number(boqDetails[item.id].quantity) < Number(saleOrderItemQuantity)
      ) {
        return quantityItemGreaterThanQuantityBoq;
      }
    } else {
      return itemCodeIsNotInBoqDetail;
    }
    return '';
  }
}
