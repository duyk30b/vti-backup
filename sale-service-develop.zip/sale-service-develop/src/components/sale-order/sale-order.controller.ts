import {
  SetOrderStatusBodyDto,
  SetOrderStatusRequestDto,
} from './../order/dto/request/set-order-status-request.dto';
import { UpdateSaleOrderBodyDto } from './dto/request/update-sale-order-request.dto';
import { GetOrderDetailRequestDto } from '@components/order/dto/request/get-order-detail.request.dto';
import { GetSaleOrderListRequest } from './dto/request/get-sale-order-list-request.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { SaleOrderServiceInterface } from '@components/sale-order/interface/sale-order.service.interface';
import { MessagePattern } from '@nestjs/microservices';
import { isEmpty } from 'lodash';
import { CreateSaleOrderRequestBodyDto } from './dto/request/create-sale-order-request.dto';
import { GetAllSORequest } from './dto/request/get-all-sale-order.request.dto';
import { DeleteOrderRequestDto } from '@components/order/dto/request/delete-order.request.dto';
import { GetListOrderByIdsRequestDto } from '@components/order/dto/request/get-list-order-by-ids.request.dto';
import { GetByItemIdRequestDto } from '@components/purchased-order/dto/request/get-by-item-id.request.dto';
import { GetSoByRelationRequest } from './dto/request/get-sale-order-by-relation.request.dto';
import {
  CREATE_SALE_ORDER_PERMISSION,
  UPDATE_SALE_ORDER_PERMISSION,
  DELETE_SALE_ORDER_PERMISSION,
  DETAIL_SALE_ORDER_PERMISSION,
  LIST_SALE_ORDER_PERMISSION,
  CONFIRM_SALE_ORDER_PERMISSION,
  REJECT_SALE_ORDER_PERMISSION,
  APPROVE_SALE_ORDER_PERMISSION,
  LIST_ALL_SALE_ORDER_PERMISSION,
} from '@utils/permissions/sale-order';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { generatePermissionCodes } from '@utils/common';
import { PRODUCTION_REPORT_PERMISSION } from '@utils/permissions/produce-service';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { UpdateSoIsHasPlanRequestDto } from './dto/request/update-so-is-has-plan.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { UpdateProducedQuantityRequestDto } from './dto/request/update-produced-quantity.request.dto';
import {
  GetStatisticProgressProductionBySoQueryDto,
  GetStatisticProgressProductionBySoRequestDto,
} from './dto/request/get-statistic-progress-production-by-so.request.dto';
import { ApiConsumes, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { SaleOrderResponseDto } from './dto/response/sale-order-response.dto';
import { SaleOrderListResponse } from './dto/response/sale-order-list-response.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { SaleOrderExportListResponse } from '@components/sale-order-export/dto/response/sale-order-export-list-response.dto';

const PERMISSION_LIST_SALE_ORDER = generatePermissionCodes([
  LIST_SALE_ORDER_PERMISSION.code,
  PRODUCTION_REPORT_PERMISSION.code,
]);

@Controller('')
export class SaleOrderController {
  constructor(
    @Inject('SaleOrderServiceInterface')
    private readonly saleOrderService: SaleOrderServiceInterface,
  ) {}

  @MessagePattern('get_sale_orders_by_name_keyword')
  public async getSaleOrdersByNameKeyword(@Body() payload: any): Promise<any> {
    return await this.saleOrderService.getSaleOrdersByNameKeyword(
      payload.nameKeyword,
    );
  }

  @MessagePattern('get_sale_orders_by_code_keyword')
  public async getSaleOrdersByCodeKeyword(@Body() payload: any): Promise<any> {
    return await this.saleOrderService.getSaleOrdersByCodeKeyword(
      payload.codeKeyword,
    );
  }

  /**
   * Create new sale order
   * @param request CreateSaleOrderRequestDto
   * @returns
   */
  @PermissionCode(CREATE_SALE_ORDER_PERMISSION.code)
  // @MessagePattern('create_sale_order')
  @Post('/sale-orders/create')
  @ApiOperation({
    tags: ['Sales', 'Sale Order'],
    summary: 'Create Sale Order',
    description: 'Tạo lệnh bán hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: SaleOrderResponseDto,
  })
  public async create(
    @Body() payload: CreateSaleOrderRequestBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderService.create({
      ...request,
      createdByUserId: request.userId,
    });
  }

  /**
   * Update sale order
   * @param request UpdateSaleOrderDto
   * @returns
   */
  @PermissionCode(UPDATE_SALE_ORDER_PERMISSION.code)
  // @MessagePattern('update_sale_order')
  @Put('/sale-orders/:id')
  @ApiOperation({
    tags: ['Sales', 'Sale Order'],
    summary: 'Update Sale Order',
    description: 'Cập nhật lệnh mua hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SaleOrderResponseDto,
  })
  public async update(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateSaleOrderBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderService.update({
      ...request,
      createdByUserId: request.userId,
      id,
    });
  }

  /**
   * Get purchased order list
   * @param request GetSaleOrderListRequest
   * @returns
   */
  @PermissionCode(PERMISSION_LIST_SALE_ORDER)
  // @MessagePattern('get_sale_order_list')
  @Get('/sale-orders/list')
  @ApiOperation({
    tags: ['Sales', 'Sale Order'],
    summary: 'Get List Sale Order',
    description: 'Danh sách lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: SaleOrderListResponse,
  })
  public async getList(
    @Query() payload: GetSaleOrderListRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderService.getList(request);
  }

  /**
   * Get sale order detail
   * @param request GetPurchasedOrderListRequest
   * @returns
   */
  @PermissionCode(DETAIL_SALE_ORDER_PERMISSION.code)
  // @MessagePattern('get_sale_order_detail')
  @Get('/sale-orders/:id')
  @ApiOperation({
    tags: ['Sales', 'Sale Order'],
    summary: 'Get Sale Order Detail',
    description: 'Chi tiết lệnh mua hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: SaleOrderResponseDto,
  })
  public async getDetail(
    @Param() param: GetOrderDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderService.getDetail(request);
  }

  /**
   * Confirm sale order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @PermissionCode(CONFIRM_SALE_ORDER_PERMISSION.code)
  // @MessagePattern('confirm_sale_order')
  @Put('/sale-orders/:id/confirm')
  @ApiOperation({
    tags: ['Sales', 'Sale Order'],
    summary: 'Confirm Sale Purchased Order',
    description: 'Confirm lệnh mua hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SaleOrderResponseDto,
  })
  public async confirm(
    @Param() payload: SetOrderStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderService.confirm({
      ...request,
      createdByUserId: request.userId,
    });
  }

  /**
   * Confirm sale order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @PermissionCode(CONFIRM_SALE_ORDER_PERMISSION.code)
  // @MessagePattern('confirm_sale_order_multiple')
  @Put('/sale-orders/confirm/multiple')
  @ApiOperation({
    tags: ['Sales', 'Sale Order'],
    summary: 'Confirm multiple Sale Purchased Order',
    description: 'Confirm nhiều lệnh mua hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SaleOrderResponseDto,
  })
  public async confirmMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderService.confirmMultiple(request);
  }

  /**
   * Reject sale order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @PermissionCode(REJECT_SALE_ORDER_PERMISSION.code)
  // @MessagePattern('reject_sale_order')
  @Put('/sale-orders/:id/reject')
  @ApiOperation({
    tags: ['Sales', 'Sale Order'],
    summary: 'Reject Sale Purchased Order',
    description: 'Reject lệnh mua hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SaleOrderResponseDto,
  })
  public async reject(
    @Param() payload: SetOrderStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderService.reject({
      ...request,
      createdByUserId: request.userId,
    });
  }

  /**
   * Approve sale order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @PermissionCode(APPROVE_SALE_ORDER_PERMISSION.code)
  // @MessagePattern('approve_sale_order')
  @Put('/sale-orders/:id/approve')
  @ApiOperation({
    tags: ['Sales', 'Sale Order'],
    summary: 'Approve Sale Purchased Order',
    description: 'Approve lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SaleOrderResponseDto,
  })
  public async approve(
    @Param() payload: SetOrderStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderService.approve({
      ...request,
      createdByUserId: request.userId,
    });
  }

  @PermissionCode(LIST_ALL_SALE_ORDER_PERMISSION.code)
  // @MessagePattern('get_sale_orders')
  @Get('/sale-orders/all')
  @ApiOperation({
    tags: ['Sales', 'Sales Order'],
    summary: 'Get List Sales Order',
    description: 'Danh sách lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: null,
  })
  public async getSalesOrders(@Query() payload: GetAllSORequest): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderService.getSaleOrders(request);
  }

  @PermissionCode(DELETE_SALE_ORDER_PERMISSION.code)
  // @MessagePattern('delete_sale_order')
  @Delete('/sale-orders/:id')
  @ApiOperation({
    tags: ['Sales', 'Sale Order'],
    summary: 'Remove Purchased Order',
    description: 'Xoá lệnh mua hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async delete(@Param() param: DeleteOrderRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderService.delete(request);
  }

  @PermissionCode(DELETE_SALE_ORDER_PERMISSION.code)
  // @MessagePattern('delete_sale_order_multiple')
  @Delete('/sale-orders/multiple')
  @ApiOperation({
    tags: ['Sales', 'Sale Order'],
    summary: 'Remove multiple Purchased Order',
    description: 'Xoá nhiều lệnh mua hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deleteMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderService.deleteMultiple(request);
  }

  // @MessagePattern('import_sale_order')
  @Post('/sale-orders/import')
  @ApiOperation({
    tags: ['Sales', 'Sales Order'],
    summary: 'Import Sales Order',
    description: 'Nhập danh sách đơn bán',
  })
  @ApiResponse({
    status: 200,
    description: 'Import list success',
    type: ImportResponseDto,
  })
  @ApiConsumes('multipart/form-data')
  public async importSalesOrder(
    @Body() body: FileUpdloadRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderService.importSalesOrder(request);
  }

  // @MessagePattern('get_sale_order_by_ids')
  @Get('/sale-orders/list-by-ids')
  @ApiOperation({
    tags: ['Sales', 'Sale Order'],
    summary: 'Get List Sale Order By Ids',
    description: 'Danh sách lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: SaleOrderResponseDto,
  })
  public async getPurchasedOrderByIds(
    @Query() payload: GetListOrderByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderService.getListByIds(request);
  }

  // TO DO: remove after refactor done
  @MessagePattern('get_sale_order_by_ids')
  public async getPurchasedOrderByIdsTcp(
    @Body() payload: GetListOrderByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderService.getListByIds(request);
  }

  @MessagePattern('check_item_has_exist_on_sale_order')
  public async checkItemHasExistOnSaleOrder(
    @Body() payload: GetByItemIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderService.checkItemHasExistOnSaleOrder(request);
  }

  @MessagePattern('get_sale_order_by_relation')
  public async getSaleOrderByRelation(
    @Body() payload: GetSoByRelationRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderService.getSaleOrderByRelation(request);
  }

  @MessagePattern('update_sale_order_is_has_plan')
  public async updateSoIsHasPlan(
    @Body() payload: UpdateSoIsHasPlanRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderService.updateSoIsHasPlan(request);
  }

  // @TODO: remove when refactor done
  @MessagePattern('update_sale_order_is_has_plan')
  public async updateSoIsHasPlanTcp(
    @Body() payload: UpdateSoIsHasPlanRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderService.updateSoIsHasPlan(request);
  }

  @MessagePattern('update_produced_quantity')
  public async updateProducedQuantity(
    @Body() payload: UpdateProducedQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderService.updateProducedQuantity(request);
  }

  @Get('/sale-order/statistic-production-progress')
  @ApiOperation({
    tags: ['Sales', 'Sale Order Statistic Production Progress'],
    summary: 'Get Statistic Of Progress Production',
    description: 'Tiến độ sản xuất theo đơn bán hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: SaleOrderExportListResponse,
  })
  // @MessagePattern('get_statistic_production_progress_by_so')
  public async getStatisticProductionProgressBySo(
    @Query() payload: GetStatisticProgressProductionBySoQueryDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderService.getStatisticProductionProgressBySo(
      request,
    );
  }

  // @TODO: remove when refactor done
  @MessagePattern('update_produced_quantity')
  public async updateProducedQuantityTcp(
    @Body() payload: UpdateProducedQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderService.updateProducedQuantity(request);
  }

  @MessagePattern('get_statistic_production_progress_by_so')
  public async getStatisticProductionProgressBySoTcp(
    @Body() payload: GetStatisticProgressProductionBySoRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderService.getStatisticProductionProgressBySo(
      request,
    );
  }
}
