import { BaseDto } from '@core/dto/base.dto';

export class GetSoByRelationRequest extends BaseDto {
  relation: any;
}
