import { CreateSaleOrderRequestBodyDto } from './create-sale-order-request.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { Transform } from 'class-transformer';
export class UpdateSaleOrderBodyDto extends CreateSaleOrderRequestBodyDto {}
export class UpdateSaleOrderDto extends UpdateSaleOrderBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
