import { CreateSaleOrderRequestBodyDto } from './create-sale-order-request.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty, IsOptional, ValidateNested } from 'class-validator';
import { plainToInstance, Transform, Type } from 'class-transformer';
import { BaseDto } from '@core/dto/base.dto';
// export class UpdateSaleOrderBodyDto extends CreateSaleOrderRequestBodyDto {}
//
// export class UpdateSaleOrderDto extends UpdateSaleOrderBodyDto {
//   @ApiProperty()
//   @IsNotEmpty()
//   @Transform((obj) => Number(obj.value))
//   @IsInt()
//   id: number;
// }

export class UpdateSaleOrderBodyDto extends CreateSaleOrderRequestBodyDto {}
export class UpdateSaleOrderDto extends UpdateSaleOrderBodyDto {
  @ApiProperty()
  @IsOptional()
  @IsInt()
  id: number;
}

export class UpdateSaleOrderFormData extends BaseDto {
  @ApiProperty()
  @ValidateNested({ each: true })
  @Transform((v) => plainToInstance(UpdateSaleOrderDto, JSON.parse(v.value)))
  @Type(() => UpdateSaleOrderDto)
  data: UpdateSaleOrderDto;

  @ApiProperty({ description: 'File' })
  @Type(() => File)
  files: File[];
}
