import { OrderStatusEnum } from '@constant/common';
import { BaseDto } from '@core/dto/base.dto';
import { Transform } from 'class-transformer';
import { ArrayNotEmpty, IsEnum } from 'class-validator';

export class GetAllSORequest extends BaseDto {
  @IsEnum(OrderStatusEnum, { each: true })
  @ArrayNotEmpty()
  @Transform((data) => {
    return data.value
      .split(',')
      .map((e) => Number(e))
      .filter((e) => Number.isInteger(e));
  })
  status: [OrderStatusEnum];
}
