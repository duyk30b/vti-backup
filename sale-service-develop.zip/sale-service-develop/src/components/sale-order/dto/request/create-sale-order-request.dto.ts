import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsNotEmpty,
  IsInt,
  IsNumber,
  Min,
  IsDateString,
  ArrayUnique,
  ArrayNotEmpty,
  ValidateNested,
  IsString,
  Length,
  IsOptional,
  IsPositive,
  Max,
} from 'class-validator';
import { decimal } from '@utils/common';

class ItemRequest {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  quantity: number;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  @IsPositive()
  @Min(0)
  @Max(decimal(15, 2))
  price: number;
}
export class CreateSaleOrderRequestBodyDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @Length(1, 255)
  name: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @Length(0, 255)
  description: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @Length(1, 9)
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  deadline: Date;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  companyId: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  boqId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  customerId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  orderedAt: Date;

  @ApiProperty()
  @ArrayUnique<ItemRequest>()
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => ItemRequest)
  items: ItemRequest[];
}

export class CreateSaleOrderRequestDto extends CreateSaleOrderRequestBodyDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  createdByUserId: number;
}
