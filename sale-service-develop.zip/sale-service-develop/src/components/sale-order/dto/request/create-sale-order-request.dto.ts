import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { plainToInstance, Transform, Type } from 'class-transformer';
import {
  IsNotEmpty,
  IsInt,
  IsNumber,
  Min,
  IsDateString,
  ArrayUnique,
  ArrayNotEmpty,
  ValidateNested,
  IsString,
  Length,
  IsOptional,
  IsPositive,
  Max,
  IsBoolean,
  IsEnum,
  IsArray,
} from 'class-validator';
import { decimal } from '@utils/common';
import {
  LEVEL_PACKING,
  SUPPLIER,
} from '@components/sale-order/sale-order.constant';

class ItemRequest {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  quantity: number;

  @ApiProperty()
  @IsOptional()
  deadline: Date;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  bomVersionId: number;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  @IsPositive()
  @Min(0)
  @Max(decimal(15, 2))
  price: number;
}

class Packing {
  @ApiProperty()
  @IsEnum(LEVEL_PACKING)
  level: LEVEL_PACKING;

  @ApiProperty()
  @IsEnum(SUPPLIER)
  supplier: SUPPLIER;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  receivedAt: Date;

  @ApiProperty()
  @IsBoolean()
  hasEnoughQuantity: boolean;
}

export class OldFile {
  id: string;
  filNameRaw: string;
  fileUrl: string;
}

export class CreateSaleOrderRequestBodyDto extends BaseDto {
  @ApiProperty()
  @IsString()
  @Length(1, 20)
  code: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @Length(0, 255)
  name: string;

  @ApiProperty()
  @IsDateString()
  orderedAt: Date;

  @ApiProperty()
  @IsBoolean()
  @IsOptional()
  hasDeposit: boolean;

  @ApiProperty()
  @IsInt()
  @IsOptional()
  moneyDeposit: number;

  @ApiProperty()
  @IsInt()
  customerId: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @Length(0, 255)
  description: string;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  deadline: Date;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  companyId: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  boqId: number;

  @ApiProperty()
  @IsOptional()
  @IsArray()
  fileIds: string[];

  @ApiProperty()
  @ArrayUnique<ItemRequest>()
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => ItemRequest)
  items: ItemRequest[];

  @ApiProperty()
  @IsOptional()
  @Type(() => OldFile)
  files: OldFile[];
}

export class CreateSaleOrderRequestDto extends CreateSaleOrderRequestBodyDto {
  @ApiProperty()
  @IsInt()
  @IsOptional()
  createdByUserId: number;
}

export class CreateSaleOrderFormData extends BaseDto {
  @ApiProperty()
  @ValidateNested({ each: true })
  @Transform((v) =>
    plainToInstance(CreateSaleOrderRequestDto, JSON.parse(v.value)),
  )
  @Type(() => CreateSaleOrderRequestDto)
  data: CreateSaleOrderRequestDto;

  @ApiProperty({ description: 'File' })
  @Type(() => File)
  files: File[];
}
