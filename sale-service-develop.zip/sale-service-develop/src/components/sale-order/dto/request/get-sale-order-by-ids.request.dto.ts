import { BaseDto } from '@core/dto/base.dto';
import { ArrayNotEmpty, IsInt, IsNotEmpty } from 'class-validator';

export class GetSaleOrdersByIdsDto extends BaseDto {
  @ArrayNotEmpty()
  soIds: number[];
}
