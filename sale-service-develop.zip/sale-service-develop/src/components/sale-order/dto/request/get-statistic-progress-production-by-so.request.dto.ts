import { PaginationQuery } from '@utils/pagination.query';
import { IsNotEmpty } from 'class-validator';

export class GetStatisticProgressProductionBySoQueryDto extends PaginationQuery {}

export class GetStatisticProgressProductionBySoRequestDto extends GetStatisticProgressProductionBySoQueryDto {
  @IsNotEmpty()
  user: any;
}
