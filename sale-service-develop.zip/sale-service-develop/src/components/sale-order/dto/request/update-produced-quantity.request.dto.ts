import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsInt,
  IsNotEmpty,
  Min,
  ValidateNested,
} from 'class-validator';

class ItemSaleOrder {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @Min(1)
  @IsInt()
  quantity: number;
}

export class UpdateProducedQuantityRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty()
  @Type(() => ItemSaleOrder)
  @ArrayNotEmpty()
  @ValidateNested()
  @ArrayUnique((item: ItemSaleOrder) => item.itemId)
  items: ItemSaleOrder[];
}
