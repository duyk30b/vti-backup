import { GetOrderListRequest } from '@components/order/dto/request/get-order-list.request.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';

export class GetSaleOrderListRequest extends GetOrderListRequest {
  @IsOptional()
  canCreateMo: string;

  @IsOptional()
  currentSaleOrderId: number;

  @ApiPropertyOptional({
    example: '[{"id": "1", "itemId": "2"}]',
  })
  @IsOptional()
  @IsString()
  queryIds?: string;
}
