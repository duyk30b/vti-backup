import { Expose, Type } from 'class-transformer';

class SaleOrder {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  status: number;

  @Expose()
  orderedAt: string;

  @Expose()
  deadline: string;

  @Expose()
  isHasPlan: boolean;
}

class MasterPlan {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  dateFrom: string;

  @Expose()
  dateTo: string;

  @Expose()
  status: number;
}

export class StatisticProgressProductionBySoResponseDto {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  planFrom: string;

  @Expose()
  planTo: string;

  @Expose()
  completedAt: string;

  @Expose()
  startedAt: string;

  @Expose()
  status: number;

  @Expose()
  planQuantity: number;

  @Expose()
  producedQuantity: number;

  @Type(() => SaleOrder)
  @Expose()
  saleOrder: SaleOrder;

  @Type(() => MasterPlan)
  @Expose()
  masterPlan: MasterPlan;
}
