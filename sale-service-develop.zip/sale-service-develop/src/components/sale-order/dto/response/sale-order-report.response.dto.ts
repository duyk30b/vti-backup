import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

export class BaseResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}

export class SaleOrderCustomer extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  email: string;

  @ApiProperty()
  @Expose()
  fax: string;

  @ApiProperty()
  @Expose()
  phone: string;
}

class SaleOrderDetailResponse {
  @ApiProperty()
  @Expose()
  saleOrderCode: string;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  itemName: string;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  produceQuantity: number;

  @ApiProperty()
  @Expose()
  exportQuantity: number;

  @ApiProperty()
  @Expose()
  remainQuantity: number;

  @ApiProperty({ type: BaseResponseDto })
  @Expose()
  @Type(() => BaseResponseDto)
  item: BaseResponseDto;
}

export class SaleOrderReportResponse extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  orderedAt: string;

  @ApiProperty()
  @Expose()
  startedAt: string;

  @ApiProperty()
  @Expose()
  deadline: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  confirmedAt: Date;

  @ApiProperty()
  @Expose()
  approvedAt: Date;

  @ApiProperty()
  @Expose()
  purchasedOrderId: number;

  @ApiProperty()
  @Expose()
  totalPrice: number;

  @ApiProperty()
  @Expose()
  isHasPlan: boolean;

  @ApiProperty()
  @Expose()
  hasDeposit: boolean;

  @ApiProperty()
  @Expose()
  moneyDeposit: number;

  @ApiProperty({ type: SaleOrderCustomer })
  @Expose()
  @Type(() => SaleOrderCustomer)
  customer: SaleOrderCustomer;

  @ApiProperty()
  @Expose()
  saleOrderDetails: SaleOrderDetailResponse[];
}
