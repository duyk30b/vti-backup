import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { OrderResponseDto } from '@components/order/dto/response/order-response.dto';
import { BasicResponseDto } from '@core/dto/basic-response.dto';

export class BoqDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ItemResponseDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  itemUnit: BasicResponseDto;
}

class SaleOrderDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  saleOrderId: number;

  @ApiProperty()
  @Expose()
  price: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  deliveredQuantity: number;

  @ApiProperty()
  @Expose()
  notDeliveredQuantity: number;

  @ApiProperty()
  @Expose()
  producedQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  deadline: Date;

  @ApiProperty()
  @Expose()
  unmanufacturedQuantity: number;

  @ApiProperty()
  @Expose()
  confirmQuantity: number;

  @ApiProperty({ type: ItemResponseDto })
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;
}

export class SaleOrderCompany {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  email: string;

  @ApiProperty()
  @Expose()
  fax: string;

  @ApiProperty()
  @Expose()
  phone: string;
}

export class SaleOrderCustomer extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  email: string;

  @ApiProperty()
  @Expose()
  fax: string;

  @ApiProperty()
  @Expose()
  phone: string;
}
export class SaleOrderResponseDto extends OrderResponseDto {
  @ApiProperty()
  @Expose()
  hasDeposit: boolean;

  @ApiProperty()
  @Expose()
  moneyDeposit: number;

  @ApiProperty()
  @Expose()
  customerId: number;

  @ApiProperty()
  @Expose()
  boqId: number;

  @ApiProperty()
  @Expose()
  orderedAt: string;

  @ApiProperty()
  @Expose()
  startedAt: string;

  @ApiProperty()
  @Expose()
  completedAt: string;

  @ApiProperty({ type: BoqDto })
  @Expose()
  @Type(() => BoqDto)
  boq: BoqDto;

  @ApiProperty({ type: SaleOrderCustomer })
  @Expose()
  @Type(() => SaleOrderCustomer)
  customer: SaleOrderCustomer;

  @ApiProperty({ type: SaleOrderCompany })
  @Expose()
  @Type(() => SaleOrderCompany)
  company: SaleOrderCompany;

  @ApiProperty({ type: SaleOrderDetail })
  @Expose()
  @Type(() => SaleOrderDetail)
  saleOrderDetails: SaleOrderDetail[];

  @ApiProperty()
  @Expose()
  itemIds: number[];

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  producedQuantity: number;

  @ApiProperty()
  @Expose()
  isHasPlan: boolean;
}
