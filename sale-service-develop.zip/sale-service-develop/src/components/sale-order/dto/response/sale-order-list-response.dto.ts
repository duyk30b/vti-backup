import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { OrderListResponse } from './../../../order/dto/response/order-list-response.dto';

export class SaleOrderListResponse extends OrderListResponse {
  @ApiProperty()
  @Expose()
  orderedAt: string;
}
