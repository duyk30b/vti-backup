export class SaleOrderRejectedEvent {
  constructor({id,name,code,createdByUserId, rejectedByUserId}) {
    this.id = id;
    this.name = name;
    this.code = code;
    this.createdByUserId = createdByUserId;
    this.rejectedByUserId = rejectedByUserId;
  }
  id: number;
  name: string;
  code: string;
  createdByUserId: number;
  rejectedByUserId: number;
}