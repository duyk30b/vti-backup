export class SaleOrderCreatedEvent {
  constructor({id,name,code,createdByUserId}) {
    this.id = id;
    this.name = name;
    this.code = code;
    this.createdByUserId = createdByUserId;
  }
  id: number;
  name: string;
  code: string;
  createdByUserId: number;
}