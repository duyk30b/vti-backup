export class SaleOrderApprovedEvent {
  constructor({id,name,code,createdByUserId, approvedByUserId}) {
    this.id = id;
    this.name = name;
    this.code = code;
    this.createdByUserId = createdByUserId;
    this.approvedByUserId = approvedByUserId;
  }
  id: number;
  name: string;
  code: string;
  createdByUserId: number;
  approvedByUserId: number;
}