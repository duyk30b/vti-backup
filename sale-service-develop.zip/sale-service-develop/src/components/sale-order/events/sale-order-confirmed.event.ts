export class SaleOrderConfirmedEvent {
  constructor({id,name,code,createdByUserId, confirmedByUserId}) {
    this.id = id;
    this.name = name;
    this.code = code;
    this.createdByUserId = createdByUserId;
    this.confirmedByUserId = confirmedByUserId;
  }
  id: number;
  name: string;
  code: string;
  createdByUserId: number;
  confirmedByUserId: number;
}