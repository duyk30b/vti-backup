import { OnEvent } from '@nestjs/event-emitter';
import { OrderUpdateActualQuantityListener } from '@components/order/listeners/order-update-actual-quantity.listener';
import { SaleOrderRepositoryInterface } from '@components/sale-order/interface/sale-order.repository.interface';
import { Inject, Injectable } from '@nestjs/common';
import { OrderUpdateActualQuantityEvent } from '@components/order/events/order-update-actual-quantity.event';
import { OrderTypeEnum } from '@constant/order.constant';
import { SaleOrderExportRepositoryInterface } from '@components/sale-order-export/interface/sale-order-export.repository.interface';

@Injectable()
export class SaleOrderUpdateActualQuantityListener extends OrderUpdateActualQuantityListener {
  constructor(
    @Inject('SaleOrderRepositoryInterface')
    protected readonly saleOrderRepository: SaleOrderRepositoryInterface,

    @Inject('SaleOrderExportRepositoryInterface')
    protected readonly saleOrderExportRepository: SaleOrderExportRepositoryInterface,
  ) {
    super();
  }

  @OnEvent('order.updateActualQuantity')
  async handleOrderCreatedEvent(event: OrderUpdateActualQuantityEvent) {
    const { id, orderType } = event;
    let order;
    // if (orderType === OrderTypeEnum.SO) {
    //   const saleOrderExport = await this.saleOrderExportRepository.findOneById(
    //     id,
    //   );
    //   if (saleOrderExport) {
    //     order = await this.saleOrderRepository.findOneById(
    //       saleOrderExport.saleOrderId,
    //     );
    //   }
    // }

    // return this.checkAndUpdateInProgessOrderStatus(order);
  }

  public async updateInProgessOrderStatus(order) {
    return await this.saleOrderRepository.create(order);
  }
}
