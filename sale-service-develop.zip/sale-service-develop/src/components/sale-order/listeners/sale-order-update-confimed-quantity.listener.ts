import { SaleOrderRepositoryInterface } from './../interface/sale-order.repository.interface';
import { OrderUpdateConfirmedQuantityEvent } from '@components/order/events/order-update-confirmed-quantity.event';
import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { OrderUpdateConfirmedQuantityListener } from '@components/order/listeners/order-update-confimed-quantity.listener';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';

@Injectable()
export class SaleOrderUpdateConfirmedQuantityListener extends OrderUpdateConfirmedQuantityListener {
  constructor(
    @Inject('SaleOrderRepositoryInterface')
    private readonly saleOrderRepository: SaleOrderRepositoryInterface,

    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,
  ) {
    super();
  }

  @OnEvent('order.updateConfirmedQuantity')
  async handleOrderCreatedEvent(event: OrderUpdateConfirmedQuantityEvent) {
    // const { id, orderType } = event;
    // let order;
    // if (orderType === OrderTypeEnum.SO) {
    //   order = await this.saleOrderRepository.checkReadyToComplete(id);
    // }
    // if (order) {
    //   const newOrder = await this.saleOrderRepository.setCompleted(id);

    //   const updateStockStatusOrder = new UpdateStockStatusOrderRequest();
    //   updateStockStatusOrder.id = newOrder.id;
    //   updateStockStatusOrder.status = OrderStatusEnum.Completed;
    //   updateStockStatusOrder.type = WarehouseMovementTypeEnum.SO;
    //   updateStockStatusOrder.completedAt = newOrder.completedAt;

    //   await this.warehouseService.updateStatusWarehouseStockMovement(
    //     updateStockStatusOrder,
    //   );
    // }

    return;
  }
}
