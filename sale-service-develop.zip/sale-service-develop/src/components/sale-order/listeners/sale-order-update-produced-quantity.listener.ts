import { OnEvent } from '@nestjs/event-emitter';
import { OrderUpdateActualQuantityListener } from '@components/order/listeners/order-update-actual-quantity.listener';
import { SaleOrderRepositoryInterface } from '@components/sale-order/interface/sale-order.repository.interface';
import { Inject, Injectable } from '@nestjs/common';
import { OrderUpdateActualQuantityEvent } from '@components/order/events/order-update-actual-quantity.event';
import { OrderTypeEnum } from '@constant/order.constant';
import {
  CAN_UPDATE_STATUS_ORDER_TO_IN_PRODUCING,
  OrderStatusEnum,
} from '@constant/common';
import { OrderUpdateProducedQuantityEvent } from '../dto/request/order-update-produced-quantity.event';

@Injectable()
export class SaleOrderUpdateActualQuantityListener extends OrderUpdateActualQuantityListener {
  constructor(
    @Inject('SaleOrderRepositoryInterface')
    protected readonly saleOrderRepository: SaleOrderRepositoryInterface,
  ) {
    super();
  }

  @OnEvent('order.updateProducedQuantity')
  async handleOrderCreatedEvent(event: OrderUpdateProducedQuantityEvent) {
    const { id, orderType } = event;
    if (orderType !== OrderTypeEnum.SO) {
      return;
    }
    const order = await this.saleOrderRepository.findOneById(id);
    if (CAN_UPDATE_STATUS_ORDER_TO_IN_PRODUCING.includes(order.status)) {
      order.status = OrderStatusEnum.InProducing;
    }
    const readyToReceived = await this.saleOrderRepository.checkReadyToProduced(
      id,
    );
    if (readyToReceived) {
      order.status = OrderStatusEnum.Produced;
    }

    return await this.updateProducingOrderStatus(order);
  }

  public async updateProducingOrderStatus(order) {
    return await this.saleOrderRepository.create(order);
  }
}
