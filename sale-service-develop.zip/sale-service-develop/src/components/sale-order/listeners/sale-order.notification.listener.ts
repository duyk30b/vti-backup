import { PushNotificationRequestDto } from '@components/notification/dto/notification.request.dto';
import { NotificationServiceInterface } from '@components/notification/interface/notification.service.interface';
import { TypeNotificationEnum, TypeNotificationUserRenderAction } from '@components/notification/notification.const';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ROLE } from '@constant/common';
import { NOTIFICATION_TEMPLATE_CONSTANT } from '@constant/notification-template.constant';
import { NotificationListenerAbstract } from '@core/abstracts/notification.listener.abstract';
import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { I18nService } from 'nestjs-i18n';
import { SaleOrderApprovedEvent } from '../events/sale-order-approved.event';
import { SaleOrderConfirmedEvent } from '../events/sale-order-confirmed.event';
import { SaleOrderCreatedEvent } from '../events/sale-order-created.event';
import { SaleOrderRejectedEvent } from '../events/sale-order-rejected.event';

@Injectable()
export class SaleOrderListener extends NotificationListenerAbstract {
  constructor(
    @Inject('NotificationServiceInterface')
    protected readonly notificationService: NotificationServiceInterface,
    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,
    
    private readonly i18n: I18nService,
  ) {
    super(notificationService);
  }

  @OnEvent('sale_order.created')
  public async createListener(event: SaleOrderCreatedEvent) {
    const webNotificationRequest = new PushNotificationRequestDto();
    const user = await this.userService.getUserById(
      event.createdByUserId,
    );
    const { fullName } = user;
    webNotificationRequest.title = `${await this.i18n.translate(
      'message.saleOrder.notificationTitle.created',
    )}`;
    webNotificationRequest.content = `${(await this.i18n.translate(
      'message.saleOrder.notification.created',
    )).replace('{username}', fullName)}`;
    webNotificationRequest.templateId = NOTIFICATION_TEMPLATE_CONSTANT.SALE_ORDER_CREATED;
    webNotificationRequest.executionDate = new Date().toISOString();
    webNotificationRequest.type = TypeNotificationEnum.WEB;
    webNotificationRequest.action = TypeNotificationUserRenderAction.ACTION_CONFIRM_VIEW_REJECT;
    webNotificationRequest.payload = {
      title: webNotificationRequest.title,
      content: webNotificationRequest.content,
    };
    const targetUsers = await this.userService.getUsersByRoleCodes([
      ROLE.ADMIN,
    ]);
    webNotificationRequest.userIds = targetUsers.map((user) => user.userId);
    const appNotificationRequest = {...webNotificationRequest, type: TypeNotificationEnum.APP};
    return [super.pushRealtimeNotification(webNotificationRequest), super.pushRealtimeNotification(appNotificationRequest)];
  }

  @OnEvent('sale_order.confirmed')
  public async confirmListener(event: SaleOrderConfirmedEvent) {
    const webNotificationRequest = new PushNotificationRequestDto();
    const user = await this.userService.getUserById(
      event.confirmedByUserId,
    );
    const { fullName } = user;
    webNotificationRequest.title = `${await this.i18n.translate(
      'message.saleOrder.notificationTitle.confirmed',
    )}`;
    webNotificationRequest.content = `${(await this.i18n.translate(
      'message.saleOrder.notification.confirmed',
    )).replace('{username}', fullName)}`;
    webNotificationRequest.templateId = NOTIFICATION_TEMPLATE_CONSTANT.SALE_ORDER_CONFIRMED;
    webNotificationRequest.executionDate = new Date().toISOString();
    webNotificationRequest.type = TypeNotificationEnum.WEB;
    webNotificationRequest.action = TypeNotificationUserRenderAction.ACTION_VIEW;
    webNotificationRequest.payload = {
      title: webNotificationRequest.title,
      content: webNotificationRequest.content,
    };
    webNotificationRequest.userIds = [event.createdByUserId];
    const appNotificationRequest = {...webNotificationRequest, type: TypeNotificationEnum.APP};
    return [super.pushRealtimeNotification(webNotificationRequest), super.pushRealtimeNotification(appNotificationRequest)]
  }

  @OnEvent('sale_order.approved')
  public async approveListener(event: SaleOrderApprovedEvent) {
    const webNotificationRequest = new PushNotificationRequestDto();
    const user = await this.userService.getUserById(
      event.approvedByUserId,
    );
    const { fullName } = user;
    webNotificationRequest.title = `${await this.i18n.translate(
      'message.saleOrder.notificationTitle.approved',
    )}`;
    webNotificationRequest.content = `${(await this.i18n.translate(
      'message.saleOrder.notification.approved',
    )).replace('{username}', fullName)}`;
    webNotificationRequest.templateId = NOTIFICATION_TEMPLATE_CONSTANT.SALE_ORDER_APPROVED;
    webNotificationRequest.executionDate = new Date().toISOString();
    webNotificationRequest.type = TypeNotificationEnum.WEB;
    webNotificationRequest.action = TypeNotificationUserRenderAction.ACTION_VIEW;
    webNotificationRequest.payload = {
      title: webNotificationRequest.title,
      content: webNotificationRequest.content,
    };
    webNotificationRequest.userIds = [event.createdByUserId];
    const appNotificationRequest = {...webNotificationRequest, type: TypeNotificationEnum.APP};
    return [super.pushRealtimeNotification(webNotificationRequest), super.pushRealtimeNotification(appNotificationRequest)]
  }

  @OnEvent('sale_order.rejected')
  public async rejectListener(event: SaleOrderRejectedEvent) {
    const webNotificationRequest = new PushNotificationRequestDto();
    const user = await this.userService.getUserById(
      event.rejectedByUserId,
    );
    const { fullName } = user;
    webNotificationRequest.title = `${await this.i18n.translate(
      'message.saleOrder.notificationTitle.rejected',
    )}`;
    webNotificationRequest.content = `${(await this.i18n.translate(
      'message.saleOrder.notification.rejected',
    )).replace('{username}', fullName)}`;
    webNotificationRequest.templateId = NOTIFICATION_TEMPLATE_CONSTANT.SALE_ORDER_REJECTED;
    webNotificationRequest.executionDate = new Date().toISOString();
    webNotificationRequest.type = TypeNotificationEnum.WEB;
    webNotificationRequest.action = TypeNotificationUserRenderAction.ACTION_VIEW;
    webNotificationRequest.payload = {
      title: webNotificationRequest.title,
      content: webNotificationRequest.content,
    };
    webNotificationRequest.userIds = [event.createdByUserId];
    const appNotificationRequest = {...webNotificationRequest, type: TypeNotificationEnum.APP};
    return [super.pushRealtimeNotification(webNotificationRequest), super.pushRealtimeNotification(appNotificationRequest)]
  }
}
