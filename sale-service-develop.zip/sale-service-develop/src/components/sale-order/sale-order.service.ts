import { EventEmitter2 } from '@nestjs/event-emitter';
import { SetOrderStatusRequestDto } from '../order/dto/request/set-order-status-request.dto';
import {
  CAN_UPDATE_ORDER_STATUS,
  STATUS_TO_CONFIRM_ORDER_STATUS,
  STATUS_TO_APPROVE_ORDER_STATUS,
  STATUS_TO_REJECT_ORDER_STATUS,
  STATUS_TO_DELETE_ORDER_STATUS,
  OrderTypeEnum,
  STATUS_TO_UPDATE_QUANTITY_PRODUCING_ORDER,
} from '../../constant/order.constant';

import { SaleOrderDetail } from '@entities/sale-order/sale-order-detail.entity';
import { WarehouseServiceInterface } from '../warehouse/interface/warehouse.service.interface';
import { GetSaleOrderListRequest } from './dto/request/get-sale-order-list-request.dto';
import { CreateSaleOrderRequestDto } from './dto/request/create-sale-order-request.dto';
import { Inject, Injectable } from '@nestjs/common';
import { SaleOrderRepositoryInterface } from '@components/sale-order/interface/sale-order.repository.interface';
import { SaleOrderServiceInterface } from '@components/sale-order/interface/sale-order.service.interface';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, ILike, In, Not } from 'typeorm';
import { SaleOrderDetailRepositoryInterface } from './interface/sale-order-detail.repository.interface';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { plus } from '@utils/helper';
import { plainToInstance } from 'class-transformer';
import { values, map, uniq, flatMap, keyBy, isEmpty, isArray } from 'lodash';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { SaleOrderResponseDto } from './dto/response/sale-order-response.dto';
import { PagingResponse } from '@utils/paging.response';
import { CustomerRepositoryInterface } from '@components/customer/interface/customer.repository.interface';
import { OrderStatusEnum } from '@constant/common';
import { GetOrderDetailRequestDto } from '@components/order/dto/request/get-order-detail.request.dto';
import { SaleOrder } from '@entities/sale-order/sale-order.entity';
import { UpdateSaleOrderDto } from './dto/request/update-sale-order-request.dto';
import { GetAllSORequest } from './dto/request/get-all-sale-order.request.dto';
import { GetAllSOResponse } from './dto/response/get-all-sale-order.response.dto';
import { ResponsePayload } from '@utils/response-payload';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { DeleteOrderRequestDto } from '@components/order/dto/request/delete-order.request.dto';
import { GetListOrderByIdsRequestDto } from '@components/order/dto/request/get-list-order-by-ids.request.dto';
import { GetByItemIdRequestDto } from '@components/purchased-order/dto/request/get-by-item-id.request.dto';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { PlanServiceInterface } from '@components/plan/interface/plan.service.interface';
import { escapeCharForSearch } from '@utils/common';
import { ClientProxy } from '@nestjs/microservices';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportSaleOrderResponseDto } from './dto/response/import-sale-order.response.dto';
import { SaleOrdersImport } from './import/sale-order.import.helper';
import { SaleOrderItemDetailsImport } from './import/sale-order-item-detail.import.helper';
import { UpdateSoIsHasPlanRequestDto } from './dto/request/update-so-is-has-plan.request.dto';
import { stringFormat } from '@utils/object.util';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { OrderUpdateActualQuantityEvent } from '@components/order/events/order-update-actual-quantity.event';
import { UpdateProducedQuantityRequestDto } from './dto/request/update-produced-quantity.request.dto';
import { GetStatisticProgressProductionBySoRequestDto } from './dto/request/get-statistic-progress-production-by-so.request.dto';
import { StatisticProgressProductionBySoResponseDto } from './dto/response/statistic-progress-production.response.dto';
import { SaleOrderCreatedEvent } from './events/sale-order-created.event';
import { SaleOrderConfirmedEvent } from './events/sale-order-confirmed.event';
import { SaleOrderApprovedEvent } from './events/sale-order-approved.event';
import { SaleOrderRejectedEvent } from './events/sale-order-rejected.event';

@Injectable()
export class SaleOrderService implements SaleOrderServiceInterface {
  constructor(
    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('ProduceServiceInterface')
    protected readonly produceService: ProduceServiceInterface,

    @Inject('SaleOrderRepositoryInterface')
    private readonly saleOrderRepository: SaleOrderRepositoryInterface,

    @Inject('SaleOrderDetailRepositoryInterface')
    private readonly saleOrderDetailRepository: SaleOrderDetailRepositoryInterface,

    @Inject('CustomerRepositoryInterface')
    private readonly customerRepository: CustomerRepositoryInterface,

    @Inject('PRODUCE_SERVICE')
    private readonly productServiceClient: ClientProxy,

    @Inject('SaleOrdersImport')
    private readonly saleOrdersImport: SaleOrdersImport,

    @Inject('SaleOrderItemDetailsImport')
    private readonly saleOrderItemDetailsImport: SaleOrderItemDetailsImport,

    @Inject('PlanServiceInterface')
    private readonly planService: PlanServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly eventEmitter: EventEmitter2,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async getSaleOrdersByNameKeyword(nameKeyword: any): Promise<any> {
    const saleOrders =
      await this.saleOrderRepository.findSaleOrdersByNameKeyword(nameKeyword);

    const dataReturn = plainToInstance(SaleOrderResponseDto, saleOrders, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getSaleOrdersByCodeKeyword(
    codeKeyword: any,
  ): Promise<ResponsePayload<SaleOrderResponseDto | any>> {
    const saleOrders = await this.saleOrderRepository.findByCondition(
      `LOWER(unaccent(code)) LIKE ` +
        `LOWER(unaccent('%${escapeCharForSearch(codeKeyword)}%')) escape '\\'`,
    );

    const dataReturn = plainToInstance(SaleOrderResponseDto, saleOrders, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getListByIds(payload: GetListOrderByIdsRequestDto): Promise<any> {
    const { ids } = payload;
    const data = await this.saleOrderRepository.getListByIds(ids);

    if (isEmpty(data)) {
      return new ResponseBuilder([])
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const manufacturingOrders =
      await this.produceService.getAllManufacturingOrder(
        data.map((so) => so.id),
      );
    const moDetails = {};
    manufacturingOrders.forEach((mo) => {
      mo.manufacturingOrderDetails.forEach((mod) => {
        moDetails[mo.id + '_' + mod.itemId] = mod;
      });
    });

    const itemIds = [];
    const companyIds = [];
    const boqIds = [];

    data.forEach((saleOrder) => {
      companyIds.push(saleOrder.companyId);
      boqIds.push(saleOrder.boqId);
      saleOrder.saleOrderDetails.forEach((detail) => {
        itemIds.push(detail.itemId);
      });
    });

    const { items, companies, boqs } = await this.getSaleOrderExtraInfo(
      itemIds,
      [],
      companyIds,
      boqIds,
    );
    const normalizeItems = {};
    const normalizeCompanies = keyBy(companies, 'id');
    const normalizeBoqs = keyBy(boqs, 'id');

    const boms = await this.produceService.getBomByItemIds(itemIds);
    const bomsSerialize = keyBy(boms, 'itemId');

    items.forEach((item) => {
      normalizeItems[item.itemId] = {
        ...item,
        bom: bomsSerialize[item.itemId] || {},
      };
    });

    data.map((saleOrder) => {
      saleOrder.company = normalizeCompanies[saleOrder.companyId];
      saleOrder.boq = normalizeBoqs[saleOrder.boqId];
      saleOrder.saleOrderDetails = saleOrder.saleOrderDetails.map(
        (saleOrderDetail) => {
          saleOrderDetail.unmanufacturedQuantity = saleOrderDetail.quantity;
          manufacturingOrders.forEach((mo) => {
            mo.manufacturingOrderDetails.forEach((mod) => {
              if (saleOrderDetail.itemId === mod.itemId) {
                saleOrderDetail.unmanufacturedQuantity -=
                  moDetails[mo.id + '_' + mod.itemId].quantity;
              }
            });
          });
          return {
            ...saleOrderDetail,
            item: normalizeItems[saleOrderDetail.itemId],
          };
        },
      );
      return saleOrder;
    });

    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async delete(payload: DeleteOrderRequestDto): Promise<any> {
    const { id } = payload;
    let response, message;
    let code = ResponseCodeEnum.SUCCESS;

    const saleOrder = await this.saleOrderRepository.findOneById(id);
    if (!saleOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const queryRunner = await this.connection.createQueryRunner();
    queryRunner.startTransaction();
    try {
      await queryRunner.manager.delete(SaleOrder, {
        id: id,
      });

      await queryRunner.manager.delete(SaleOrderDetail, {
        saleOrderId: id,
      });

      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      message = error;
    }

    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(code)
      .withData(response)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('message.saleOrder.deleteSuccess')
          : message,
      )
      .build();
  }

  /**
   * Delete
   */
  public async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const saleOrders = await this.saleOrderRepository.findByCondition({
      id: In(ids),
    });

    const saleOrderIds = saleOrders.map((saleOrder) => saleOrder.id);
    if (saleOrders.length !== ids.length) {
      ids.forEach((id) => {
        if (!saleOrderIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < saleOrders.length; i++) {
      const saleOrder = saleOrders[i];
      if (!STATUS_TO_DELETE_ORDER_STATUS.includes(saleOrder.status))
        failIdsList.push(saleOrder.id);
    }

    const validIds = saleOrders
      .filter((saleOrder) => !failIdsList.includes(saleOrder.id))
      .map((saleOrder) => saleOrder.id);

    const queryRunner = await this.connection.createQueryRunner();
    try {
      if (!isEmpty(validIds)) {
        await queryRunner.startTransaction();
        await queryRunner.manager.delete(SaleOrder, validIds);
        await queryRunner.commitTransaction();
      }
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    await queryRunner.release();
    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  /**
   * Get general sale order detail
   */
  async getDetail(payload: GetOrderDetailRequestDto): Promise<any> {
    const { id } = payload;
    const saleOrder = await this.saleOrderRepository.getDetail(id);
    if (!saleOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const manufacturingOrders = await this.produceService.getMOBySaleOrderId(
      saleOrder.id,
    );
    const moDetails = {};
    manufacturingOrders.forEach((mo) => {
      mo.manufacturingOrderDetails.forEach((mod) => {
        moDetails[mo.id + '_' + mod.itemId] = mod;
      });
    });

    const itemIds = map(saleOrder.saleOrderDetails, 'itemId');

    const companyIds = [saleOrder.companyId];
    const boqIds = [saleOrder.boqId];

    const userIds = uniq([
      saleOrder.createdByUserId,
      saleOrder.confimerId,
      saleOrder.approverId,
    ]);
    const { items, users, companies, boqs } = await this.getSaleOrderExtraInfo(
      itemIds,
      userIds,
      companyIds,
      boqIds,
    );
    const normalizeItems = {};
    const normalizeUsers = {};

    const boms = await this.produceService.getBomByItemIds(itemIds);
    const bomsSerialize = keyBy(boms, 'itemId');

    items.forEach((item) => {
      normalizeItems[item.itemId] = {
        ...item,
        bom: bomsSerialize[item.itemId] || {},
      };
    });

    users.forEach((user) => {
      normalizeUsers[user.id] = user;
    });
    saleOrder.createdByUser = normalizeUsers[saleOrder.createdByUserId];
    saleOrder.company = companies[0];
    saleOrder.boq = boqs[0];
    saleOrder.approver = normalizeUsers[saleOrder.approverId];
    saleOrder.confirmer = normalizeUsers[saleOrder.confirmerId];
    saleOrder.saleOrderDetails = saleOrder.saleOrderDetails.map(
      (saleOrderDetail) => {
        saleOrderDetail.unmanufacturedQuantity = saleOrderDetail.quantity;
        manufacturingOrders.forEach((mo) => {
          mo.manufacturingOrderDetails.forEach((mod) => {
            if (saleOrderDetail.itemId === mod.itemId) {
              saleOrderDetail.unmanufacturedQuantity -=
                moDetails[mo.id + '_' + mod.itemId].quantity;
            }
          });
        });
        return {
          ...saleOrderDetail,
          item: normalizeItems[saleOrderDetail.itemId],
        };
      },
    );

    const dataReturn = plainToInstance(SaleOrderResponseDto, saleOrder, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  async getList(payload: GetSaleOrderListRequest): Promise<any> {
    const { page, canCreateMo, currentSaleOrderId } = payload;

    const moFilter = payload.filter?.find((item) => item?.column === 'moId');

    let saleOrderIds = [];

    if (!isEmpty(moFilter)) {
      const listMo = await this.produceService.getMoByIds([+moFilter.text]);
      saleOrderIds = listMo?.map((mo) => mo.saleOrderId);
    }

    let [data, count] = await this.saleOrderRepository.getList(
      payload,
      null,
      null,
      saleOrderIds,
    );
    const companyIds = uniq(map(flatMap(data), 'companyId'));
    const companies = await this.userService.getCompanies(companyIds, true);
    const soIds = uniq(data.map((so) => so.id));
    let allManufacturingOrders = [];
    if (canCreateMo === '1')
      allManufacturingOrders =
        await this.produceService.getAllManufacturingOrder(soIds);
    const result = [];
    data.forEach((so) => {
      if (canCreateMo === '1' && so.id !== +currentSaleOrderId) {
        const manufacturingOrders = allManufacturingOrders.filter(
          (mo) => mo.saleOrderId === so.id,
        );
        const moDetails = {};
        manufacturingOrders.forEach((mo) => {
          mo.manufacturingOrderDetails.forEach((mod) => {
            moDetails[mo.id + '_' + mod.itemId] = mod;
          });
        });

        let valid = true;

        for (let index = 0; index < so.itemIds.length; index++) {
          const itemId = so.itemIds[index];
          let unmanufacturedQuantity = +so.item_quantities[index];
          manufacturingOrders.forEach((mo) => {
            mo.manufacturingOrderDetails.forEach((mod) => {
              if (itemId === mod.itemId) {
                unmanufacturedQuantity -=
                  moDetails[mo.id + '_' + mod.itemId].quantity;
              }
            });
          });
          if (unmanufacturedQuantity !== 0) {
            valid = true;
            break;
          } else valid = false;
        }

        if (valid) {
          delete so.item_quantities;
          result.push({
            ...so,
            company: companies[so.companyId],
          });
        }
      } else {
        delete so.item_quantities;
        result.push({
          ...so,
          company: companies[so.companyId],
        });
      }
    });
    if (canCreateMo === '1') count = result.length;

    const dataReturn = plainToInstance(SaleOrderResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async save(
    saleOrderEntity: SaleOrder,
    payload: CreateSaleOrderRequestDto | any,
    responseMessage?: string,
  ): Promise<any> {
    const {
      items,
      code,
      customerId,
      name,
      description,
      deadline,
      orderedAt,
      companyId,
      createdByUserId,
      boqId,
    } = payload;

    const isUpdate = saleOrderEntity.id !== undefined;
    let response, message;
    let responeCode = ResponseCodeEnum.SUCCESS;
    //Validate company
    // Validate customer
    const customer = await this.customerRepository.findOneById(customerId);
    if (!customer)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CUSTOMER_NOT_FOUND'))
        .build();

    // Validate items
    const itemIds = uniq(items.map((e) => e.id));
    const itemsExist = await this.itemService.getItems(itemIds);
    if (!itemsExist || itemIds.length !== itemsExist.length) {
      const itemIdsExist = itemsExist ? itemsExist.map((e) => e.itemId) : [];
      return new ResponseBuilder({
        invalidItems: items.filter((e) => !itemIdsExist.includes(e.id)),
      })
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }

    const saleOrderDetailRaws = {};
    items.forEach((item) => {
      if (saleOrderDetailRaws[item.id]) {
        saleOrderDetailRaws[item.id].quantity = plus(
          saleOrderDetailRaws[item.id].quantity,
          item.quantity,
        );
      } else {
        saleOrderDetailRaws[item.id] = {
          id: item.id,
          quantity: item.quantity,
          price: item.price,
        };
      }
    });
    // create sale order
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      saleOrderEntity.name = name;
      saleOrderEntity.companyId = companyId;
      saleOrderEntity.customerId = customerId;
      saleOrderEntity.createdByUserId = createdByUserId;
      saleOrderEntity.description = description;
      saleOrderEntity.code = code;
      saleOrderEntity.deadline = deadline;
      saleOrderEntity.orderedAt = orderedAt;
      saleOrderEntity.boqId = boqId;

      const saleOrder = await queryRunner.manager.save(saleOrderEntity);
      const saleOrderDetailEntities = values(saleOrderDetailRaws).map(
        (saleOrderDetail: any) =>
          this.saleOrderDetailRepository.createEntity({
            saleOrderId: saleOrder.id,
            itemId: saleOrderDetail.id,
            quantity: saleOrderDetail.quantity,
            price: saleOrderDetail.price || 0,
          }),
      );
      if (isUpdate) {
        await queryRunner.manager.delete(SaleOrderDetail, {
          saleOrderId: saleOrder.id,
        });
      }
      saleOrder.saleOrderDetails = await queryRunner.manager.save(
        saleOrderDetailEntities,
      );

      await queryRunner.commitTransaction();
      response = plainToInstance(SaleOrderResponseDto, saleOrder, {
        excludeExtraneousValues: true,
      });
    } catch (error) {
      await queryRunner.rollbackTransaction();
      responeCode = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
    }
    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(responeCode)
      .withData(response)
      .withMessage(
        responeCode === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate(responseMessage || 'message.SUCCESS')
          : message,
      )
      .build();
  }

  public async update(payload: UpdateSaleOrderDto): Promise<any> {
    const { code, id } = payload;
    const saleOrder = await this.saleOrderRepository.findOneById(id);
    if (!saleOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CAN_UPDATE_ORDER_STATUS.includes(saleOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }
    const isExistSaleOrder = await this.saleOrderRepository.findByCondition({
      code: ILike(code),
      id: Not(id),
    });
    if (isExistSaleOrder.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ORDER_IS_EXIST'))
        .build();
    }

    if (saleOrder.status === OrderStatusEnum.Reject) {
      saleOrder.status = OrderStatusEnum.Pending;
    }

    return await this.save(
      saleOrder,
      payload,
      'message.saleOrder.updateSuccess',
    );
  }

  public async create(payload: CreateSaleOrderRequestDto): Promise<any> {
    const { code } = payload;

    const isExist = await this.saleOrderRepository.findByCondition({
      code: ILike(code),
    });

    if (isExist.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ORDER_IS_EXIST'))
        .build();
    }

    const saleOrder = this.saleOrderRepository.createEntity(payload);

    const createdSaleOrder = await this.save(
      saleOrder,
      payload,
      'message.saleOrder.createSuccess',
    );
    // create notification
    if (createdSaleOrder.statusCode === ResponseCodeEnum.SUCCESS) {
      this.eventEmitter.emit(
        'sale_order.created',
        new SaleOrderCreatedEvent({
          id: createdSaleOrder.data.id,
          name: createdSaleOrder.data.name,
          code: createdSaleOrder.data.code,
          createdByUserId: createdSaleOrder.data.createdByUserId,
        }),
      );
    }
    return createdSaleOrder;
  }

  /**
   * Get data sale order by id and warehouseId
   * @param id
   * @param warehouseId
   * @returns
   */
  async getWarehouseDetails(
    id: number,
    warehouseId: number,
    type: number,
  ): Promise<any> {
    try {
      const data = await this.saleOrderRepository.getWarehouseDetails(
        id,
        warehouseId,
        type,
      );
      return new ResponseBuilder(data)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async confirm(payload: SetOrderStatusRequestDto): Promise<any> {
    const { id } = payload;

    const saleOrder = await this.saleOrderRepository.findOneById(id);
    if (!saleOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_CONFIRM_ORDER_STATUS.includes(saleOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    const confirmedOrder = await this.setPurchasedOrderStatus(
      saleOrder,
      OrderStatusEnum.Confirmed,
    );
    if (confirmedOrder.statusCode === ResponseCodeEnum.SUCCESS) {
      this.eventEmitter.emit(
        'sale_order.confirmed',
        new SaleOrderConfirmedEvent({
          id: confirmedOrder.data.id,
          name: confirmedOrder.data.name,
          code: confirmedOrder.data.code,
          createdByUserId: confirmedOrder.data.createdByUserId,
          confirmedByUserId: payload.userId,
        }),
      );
    }
    return confirmedOrder;
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async confirmMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const saleOrders = await this.saleOrderRepository.findByCondition({
      id: In(ids),
    });

    const saleOrderIds = saleOrders.map((saleOrder) => saleOrder.id);
    if (saleOrders.length !== ids.length) {
      ids.forEach((id) => {
        if (!saleOrderIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < saleOrders.length; i++) {
      const saleOrder = saleOrders[i];
      if (!STATUS_TO_CONFIRM_ORDER_STATUS.includes(saleOrder.status))
        failIdsList.push(saleOrder.id);
    }

    const validIds = saleOrders
      .filter((saleOrder) => !failIdsList.includes(saleOrder.id))
      .map((saleOrder) => saleOrder.id);

    const validSaleOrders = saleOrders.filter((saleOrder) =>
      validIds.includes(saleOrder.id),
    );

    if (!isEmpty(validSaleOrders)) {
      validSaleOrders.forEach((saleOrder) => {
        saleOrder.status = OrderStatusEnum.Confirmed;
        saleOrder.approvedAt = new Date(Date.now());
      });
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(SaleOrder, validSaleOrders);
        await queryRunner.commitTransaction();
        validSaleOrders.forEach((saleOrder) => {
          this.eventEmitter.emit(
            'sale_order.confirmed',
            new SaleOrderConfirmedEvent({
              id: saleOrder.id,
              name: saleOrder.name,
              code: saleOrder.code,
              createdByUserId: saleOrder.createdByUserId,
              confirmedByUserId: request.userId,
            }),
          );
        });
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.CONFIRM_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async reject(payload: SetOrderStatusRequestDto): Promise<any> {
    const { id } = payload;

    const saleOrder = await this.saleOrderRepository.findOneById(id);
    if (!saleOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_REJECT_ORDER_STATUS.includes(saleOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    const rejectedOrder = await this.setPurchasedOrderStatus(
      saleOrder,
      OrderStatusEnum.Reject,
    );
    if (rejectedOrder.statusCode === ResponseCodeEnum.SUCCESS) {
      this.eventEmitter.emit(
        'sale_order.rejected',
        new SaleOrderRejectedEvent({
          id: rejectedOrder.data.id,
          name: rejectedOrder.data.name,
          code: rejectedOrder.data.code,
          createdByUserId: rejectedOrder.data.createdByUserId,
          rejectedByUserId: payload.userId,
        }),
      );
    }
    return rejectedOrder;
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async approve(payload: SetOrderStatusRequestDto): Promise<any> {
    const { id } = payload;

    const saleOrder = await this.saleOrderRepository.findOneById(id);
    if (!saleOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_APPROVE_ORDER_STATUS.includes(saleOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    const approvedOrder = await this.setPurchasedOrderStatus(
      saleOrder,
      OrderStatusEnum.Completed,
    );

    if (approvedOrder.statusCode === ResponseCodeEnum.SUCCESS) {
      this.eventEmitter.emit(
        'sale_order.approved',
        new SaleOrderApprovedEvent({
          id: approvedOrder.data.id,
          name: approvedOrder.data.name,
          code: approvedOrder.data.code,
          createdByUserId: approvedOrder.data.createdByUserId,
          approvedByUserId: payload.userId,
        }),
      );
    }
    return approvedOrder;
  }

  /**
   *
   * @param saleOrderEntity
   * @param status
   * @returns
   */
  private async setPurchasedOrderStatus(
    saleOrderEntity: SaleOrder,
    status: number,
  ): Promise<any> {
    saleOrderEntity.status = status;
    await this.saleOrderRepository.create(saleOrderEntity);

    const response = plainToInstance(SaleOrderResponseDto, saleOrderEntity, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(
        await this.i18n.translate(
          status === OrderStatusEnum.Confirmed
            ? 'message.saleOrder.confirmSuccess'
            : 'message.SUCCESS',
        ),
      )
      .withData(response)
      .build();
  }

  async getSaleOrders(request: GetAllSORequest): Promise<ResponsePayload<any>> {
    try {
      const data = await this.saleOrderRepository.findWithRelations({
        relations: ['customer'],
        where: {
          status: In(request.status),
        },
      });

      const dataReturn = plainToInstance(GetAllSOResponse, data, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.messgae || error)
        .build();
    }
  }

  async getSaleOrderByRelation(req: any): Promise<ResponsePayload<any>> {
    try {
      const data = await this.saleOrderRepository.findWithRelations(
        req.relation,
      );
      return new ResponseBuilder(data)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.messgae || error)
        .build();
    }
  }

  async checkItemHasExistOnSaleOrder(
    request: GetByItemIdRequestDto,
  ): Promise<any> {
    if (isArray(request.itemId))
      return await this.saleOrderDetailRepository.findByCondition({
        itemId: In(request.itemId),
      });
    return await this.saleOrderDetailRepository.findOneByCondition({
      itemId: request.itemId,
    });
  }

  protected async getSaleOrderExtraInfo(
    itemIds: number[],
    userIds: number[],
    companyIds: number[],
    boqIds: number[],
  ): Promise<any> {
    const data = await Promise.all([
      this.itemService.getItems(itemIds),
      this.userService.getUsers(userIds),
      this.userService.getCompanies(companyIds),
      this.produceService.getBoqByIds(boqIds),
    ]);

    return {
      items: data[0],
      users: data[1],
      companies: data[2],
      boqs: data[3],
    };
  }

  public async importSalesOrder(request: FileUpdloadRequestDto): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
      userId: request.userId,
    } as ImportRequestDto;
    const importSaleOrder = await this.saleOrdersImport.importUtil(
      importRequestDto,
    );

    const result = new ImportSaleOrderResponseDto();
    if (importSaleOrder.statusCode === ResponseCodeEnum.SUCCESS) {
      const importSaleOrderDetail =
        await this.saleOrderItemDetailsImport.importUtil(importRequestDto);

      if (importSaleOrderDetail.statusCode === ResponseCodeEnum.SUCCESS) {
        result.saleOrder = importSaleOrder.data;
        result.saleOrderDetail = importSaleOrderDetail.data;
      } else {
        result.saleOrder = importSaleOrder.data;
      }
    } else {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const response = plainToInstance(ImportSaleOrderResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  async updateSoIsHasPlan(request: UpdateSoIsHasPlanRequestDto): Promise<any> {
    const { ids } = request;
    const saleOrderEntities: any[] = [];
    const saleOrders = await this.saleOrderRepository.findByCondition({
      id: In(ids),
    });
    for (let i = 0; i < saleOrders.length; i++) {
      const saleOrder = saleOrders[i];
      if (!saleOrder.isHasPlan) {
        saleOrder.isHasPlan = true;
        saleOrderEntities.push(saleOrder);
      }
    }
    //Transaction
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(saleOrderEntities);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder(error)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } finally {
      await queryRunner.release();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateProducedQuantity(
    request: UpdateProducedQuantityRequestDto,
  ): Promise<any> {
    const { id, items } = request;
    const saleOrder = await this.saleOrderRepository.findOneWithRelations({
      where: {
        id,
      },
      relations: ['saleOrderDetails'],
    });
    if (isEmpty(saleOrder)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!STATUS_TO_UPDATE_QUANTITY_PRODUCING_ORDER.includes(saleOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    const itemIds = map(items, 'itemId');

    if (
      !isEmpty(
        itemIds.filter(
          (item) => !map(saleOrder.saleOrderDetails, 'itemId').includes(item),
        ),
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }

    const serializeItemRequest = keyBy(items, 'itemId');

    const orderDetails = saleOrder.saleOrderDetails
      .filter((orderDetail) => itemIds.includes(orderDetail.itemId))
      .map((orderDetail) => {
        orderDetail.producedQuantity = plus(
          orderDetail.producedQuantity,
          serializeItemRequest[orderDetail.itemId].quantity,
        );
        return orderDetail;
      });
    const invalidQuantity = orderDetails.filter(
      (orderDetail) => orderDetail.actualQuantity > orderDetail.quantity,
    );

    if (!isEmpty(invalidQuantity)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.QUANTITY_ITEM_GREATER_THAN_QUANTITY_PURCHASE_ORDER',
          ),
        )
        .build();
    }

    try {
      if (!saleOrder.startedAt) {
        saleOrder.startedAt = new Date();
        await this.saleOrderRepository.create(saleOrder);
      }
      await this.saleOrderDetailRepository.create(orderDetails);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          error?.message
            ? error.message
            : await this.i18n.translate('error.INTERNAL_SERVER_ERROR'),
        )
        .build();
    }
    this.eventEmitter.emit(
      'order.updateProducedQuantity',
      new OrderUpdateActualQuantityEvent({
        id,
        orderType: OrderTypeEnum.SO,
      }),
    );

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  async getStatisticProductionProgressBySo(
    request: GetStatisticProgressProductionBySoRequestDto,
  ): Promise<any> {
    const { filter } = request;
    let result;
    const filterIsHasPlanFalse = filter?.find(
      (item) => item.column === 'isHasPlan' && item.text === 'false',
    );
    const filterIsHasPlanTrue = filter?.find(
      (item) => item.column === 'isHasPlan' && item.text === 'true',
    );
    const filterSoIds = filter?.find((item) => item.column === 'soIds');

    const filterSoOrderedAt = filter?.find(
      (item) => item.column === 'orderedAt',
    );
    const filterSoDeadline = filter?.find((item) => item.column === 'deadline');
    const filterMasterPlanIds = filter?.find(
      (item) => item.column === 'masterPlanIds',
    );
    const filterMpPlan = filter?.find((item) => item.column === 'planDate');
    const filterSoStatus = filter?.find((item) => item.column === 'status');

    let saleOrders;
    // isHasPlan false
    if (filterIsHasPlanFalse) {
      const requestGetListSo = new GetSaleOrderListRequest();
      requestGetListSo.user = request.user;
      requestGetListSo.filter = request.filter.map((item) => {
        if (item.column === 'soIds') {
          return {
            ...item,
            column: 'ids',
          };
        }
        return item;
      });
      requestGetListSo.sort = request.sort;
      requestGetListSo.page = request.page;
      requestGetListSo.limit = request.limit;

      saleOrders = await this.getList(requestGetListSo);
      result = saleOrders.data?.items.map((so) => {
        return {
          saleOrder: so,
          planQuantity: so.planQuantity,
          producedQuantity: so.producedQuantity,
        };
      });
      const response = plainToInstance(
        StatisticProgressProductionBySoResponseDto,
        result,
        {
          excludeExtraneousValues: true,
        },
      );
      return new ResponseBuilder<PagingResponse>({
        items: response,
        meta: { total: saleOrders.data?.meta?.total, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    // filter lv1
    if (
      filterSoOrderedAt ||
      filterSoDeadline ||
      filterSoIds ||
      filterSoStatus
    ) {
      if (filterSoIds) filterSoIds.column = 'ids';
      const requestGetListSo = new GetSaleOrderListRequest();
      requestGetListSo.user = request.user;
      requestGetListSo.filter = [
        filterSoOrderedAt,
        filterSoDeadline,
        filterSoIds,
        filterSoStatus,
      ];
      requestGetListSo.sort = request.sort;
      requestGetListSo.page = request.page;
      requestGetListSo.limit = request.limit;

      saleOrders = await this.getList(requestGetListSo);
      const { result, count } = await this.statisticProgressProductionSo(
        request,
        saleOrders,
        [filterMasterPlanIds, filterMpPlan],
        null,
      );
      const response = plainToInstance(
        StatisticProgressProductionBySoResponseDto,
        result || [],
        {
          excludeExtraneousValues: true,
        },
      );

      return new ResponseBuilder<PagingResponse>({
        items: response,
        meta: { total: count || 0, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    // no lv1 -> filter lv2
    if (filterMasterPlanIds || filterMpPlan || filterIsHasPlanTrue) {
      const masterPlans = await this.planService.getMasterPlans({
        filter: [filterMasterPlanIds, filterMpPlan],
        isGetAll: '1',
      });

      const { result, count } = await this.statisticProgressProductionSo(
        request,
        null,
        [filterMasterPlanIds, filterMpPlan],
        masterPlans,
      );
      const response = plainToInstance(
        StatisticProgressProductionBySoResponseDto,
        result,
        {
          excludeExtraneousValues: true,
        },
      );

      return new ResponseBuilder<PagingResponse>({
        items: response,
        meta: { total: count, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    // no filter
    const masterPlanMap: any = new Map(); // key: saleOrderId, value: masterPlan
    const { data, count } = await this.produceService.getMoGroupBySo(request);

    if (isEmpty(data)) {
      return new ResponseBuilder<PagingResponse>({
        items: [],
        meta: { total: count, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const soIds = uniq(data.map((mo) => mo.saleOrderId));
    const requestGetSoByIds = new GetSaleOrderListRequest();
    requestGetSoByIds.user = request.user;
    requestGetSoByIds.filter = [{ column: 'ids', text: soIds.join() }];
    requestGetSoByIds.limit = request.limit;

    saleOrders = await this.getList(requestGetSoByIds);
    const saleOrderMap = keyBy(saleOrders?.data?.items, 'id');
    const filterMasterPlan: any[] = [];
    filterMasterPlan.push({ column: 'soIds', text: soIds.join() });
    const masterPlans = await this.planService.getMasterPlans({
      filter: filterMasterPlan,
      limit: request.limit,
    });
    for (let i = 0; i < masterPlans?.length; i++) {
      const masterPlan = masterPlans[i];
      for (let j = 0; j < masterPlan.saleOrders?.length; j++) {
        const saleOrder = masterPlan.saleOrders[j];
        masterPlanMap.set(saleOrder.id, masterPlan);
      }
    }
    result = data?.map((mo) => {
      return {
        ...mo,
        planQuantity: saleOrderMap[mo.saleOrderId]?.planQuantity,
        producedQuantity: saleOrderMap[mo.saleOrderId]?.producedQuantity,
        saleOrder: saleOrderMap[mo.saleOrderId],
        masterPlan: masterPlanMap.get(mo.saleOrderId),
      };
    });

    const response = plainToInstance(
      StatisticProgressProductionBySoResponseDto,
      result || [],
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count || 0, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @param saleOrders
   * @param filter
   * @param masterPlans
   * @returns
   */
  async statisticProgressProductionSo(
    request: any,
    saleOrders: any,
    filter: any,
    masterPlans: any,
  ) {
    const masterPlanMap: any = new Map(); // key: saleOrderId, value: masterPlan
    let saleOrdersData;
    let totalSaleOrders;
    let soIds: any[] = [];

    if (
      saleOrders?.data?.items &&
      !isEmpty(saleOrders?.data?.items) &&
      !masterPlans
    ) {
      soIds = uniq(saleOrders?.data?.items.map((so) => so.id));
      saleOrdersData = saleOrders?.data?.items;
      totalSaleOrders = saleOrders?.data?.meta?.total;
      const filterMasterPlan: any[] = [];
      filterMasterPlan.push({ column: 'soIds', text: soIds.join() });
      filterMasterPlan.concat(filter);
      masterPlans = await this.planService.getMasterPlans({
        filter: filterMasterPlan,
        limit: request.limit,
      });
    }

    if (!saleOrders?.data?.items && masterPlans?.length > 0) {
      for (let i = 0; i < masterPlans?.length; i++) {
        const masterPlan = masterPlans[i];
        for (let j = 0; j < masterPlan.saleOrders?.length; j++) {
          const saleOrder = masterPlan.saleOrders[j];
          if (!soIds.includes(saleOrder.id)) soIds.push(saleOrder.id);
          masterPlanMap.set(saleOrder.id, masterPlan);
        }
      }
      const requestGetSoByIds = new GetSaleOrderListRequest();
      requestGetSoByIds.user = request.user;
      requestGetSoByIds.filter = [{ column: 'ids', text: soIds.join() }].concat(
        request.filter || {},
      );
      requestGetSoByIds.sort = request.sort;
      requestGetSoByIds.limit = request.limit;
      const saleOrders = await this.getList(requestGetSoByIds);
      saleOrdersData = saleOrders?.data?.items;
      totalSaleOrders = saleOrders?.data?.meta?.total;
    }

    for (let i = 0; i < masterPlans?.length; i++) {
      const masterPlan = masterPlans[i];
      for (let j = 0; j < masterPlan.saleOrders?.length; j++) {
        const saleOrder = masterPlan.saleOrders[j];
        masterPlanMap.set(saleOrder.id, masterPlan);
      }
    }

    let moData;
    if (!isEmpty(soIds)) {
      const requestMo = new GetStatisticProgressProductionBySoRequestDto();
      requestMo.filter = [];
      requestMo.filter.push({ column: 'soIds', text: soIds.join() });
      requestMo.user = request.user;
      moData = await this.produceService.getMoGroupBySo(requestMo);
    }
    const moBySoId = keyBy(moData?.data || [], 'saleOrderId');

    const result = saleOrdersData?.map((so) => {
      return {
        planQuantity: so.planQuantity || 0,
        producedQuantity: so.producedQuantity || 0,
        saleOrder: so,
        masterPlan: masterPlanMap.get(so.id),
        name: moBySoId[so.id]?.name,
        code: moBySoId[so.id]?.code,
      };
    });

    return { result, count: totalSaleOrders };
  }
}
