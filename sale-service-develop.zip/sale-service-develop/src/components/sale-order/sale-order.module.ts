import { SaleOrderUpdateConfirmedQuantityListener } from './listeners/sale-order-update-confimed-quantity.listener';
import { WarehouseService } from './../warehouse/warehouse.service';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SaleOrderController } from '@components/sale-order/sale-order.controller';
import { SaleOrderService } from '@components/sale-order/sale-order.service';
import { SaleOrder } from '@entities/sale-order/sale-order.entity';
import { SaleOrderRepository } from '@repositories/sale-order/sale-order.repository';
import { SaleOrderDetailRepository } from '@repositories/sale-order/sale-order-detail.repository';
import { SaleOrderDetail } from '@entities/sale-order/sale-order-detail.entity';
import { ItemModule } from '@components/item/item.module';
import { ItemService } from '@components/item/item.service';
import { CustomerModule } from '@components/customer/customer.module';
import { CustomerRepository } from '@repositories/customer/customer.repository';
import { Customer } from '@entities/customer/customer.entity';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { SaleOrderUpdateActualQuantityListener } from './listeners/sale-order-update-actual-quantity.listener';
import { ProduceService } from '@components/produce/produce.service';
import { ProduceModule } from '@components/produce/produce.module';
import { ConfigService } from '@config/config.service';
import { ClientProxyFactory } from '@nestjs/microservices';
import { SaleOrderItemDetailsImport } from './import/sale-order-item-detail.import.helper';
import { SaleOrdersImport } from './import/sale-order.import.helper';
import { SaleOrderExport } from '@entities/sale-order-export/sale-order-export.entity';
import { SaleOrderExportRepository } from '@repositories/sale-order-export/sale-order-export.repository';
import { PlanModule } from '@components/plan/plan.module';
import { PlanService } from '@components/plan/plan.service';
import { SaleOrderListener } from './listeners/sale-order.notification.listener';
import { NotificationModule } from '@components/notification/notification.module';
import { NotificationService } from '@components/notification/notification.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      SaleOrder,
      SaleOrderDetail,
      Customer,
      SaleOrderExport,
    ]),
    ItemModule,
    CustomerModule,
    UserModule,
    ProduceModule,
    PlanModule,
    NotificationModule,
  ],
  providers: [
    {
      provide: 'SaleOrderRepositoryInterface',
      useClass: SaleOrderRepository,
    },
    {
      provide: 'SaleOrderExportRepositoryInterface',
      useClass: SaleOrderExportRepository,
    },
    {
      provide: 'SaleOrderDetailRepositoryInterface',
      useClass: SaleOrderDetailRepository,
    },
    {
      provide: 'CustomerRepositoryInterface',
      useClass: CustomerRepository,
    },
    {
      provide: 'SaleOrderServiceInterface',
      useClass: SaleOrderService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'ProduceServiceInterface',
      useClass: ProduceService,
    },
    {
      provide: 'SaleOrderItemDetailsImport',
      useClass: SaleOrderItemDetailsImport,
    },
    {
      provide: 'SaleOrdersImport',
      useClass: SaleOrdersImport,
    },
    {
      provide: 'PlanServiceInterface',
      useClass: PlanService,
    },
    {
      provide: 'NotificationServiceInterface',
      useClass: NotificationService,
    },
    SaleOrderListener,
    SaleOrderUpdateActualQuantityListener,
    SaleOrderUpdateConfirmedQuantityListener,
    ConfigService,
    {
      provide: 'PRODUCE_SERVICE',
      useFactory: (configService: ConfigService) => {
        const produceServiceOptions = configService.get('produceService');
        return ClientProxyFactory.create(produceServiceOptions);
      },
      inject: [ConfigService],
    },
  ],
  controllers: [SaleOrderController],
})
export class SaleOrderModule {}
