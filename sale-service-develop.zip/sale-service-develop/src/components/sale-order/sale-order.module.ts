import { CustomerModule } from '@components/customer/customer.module';
import { ItemModule } from '@components/item/item.module';
import { ItemService } from '@components/item/item.service';
import { NotificationModule } from '@components/notification/notification.module';
import { NotificationService } from '@components/notification/notification.service';
import { PlanModule } from '@components/plan/plan.module';
import { PlanService } from '@components/plan/plan.service';
import { ProduceModule } from '@components/produce/produce.module';
import { ProduceService } from '@components/produce/produce.service';
import { RequestService } from '@components/request/request.service';
import { SaleOrderController } from '@components/sale-order/sale-order.controller';
import { SaleOrderService } from '@components/sale-order/sale-order.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { ConfigService } from '@config/config.service';
import { Customer } from '@entities/customer/customer.entity';
import { SaleOrderExport } from '@entities/sale-order-export/sale-order-export.entity';
import { SaleOrderDetail } from '@entities/sale-order/sale-order-detail.entity';
import { SaleOrder } from '@entities/sale-order/sale-order.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CustomerRepository } from '@repositories/customer/customer.repository';
import { SaleOrderExportRepository } from '@repositories/sale-order-export/sale-order-export.repository';
import { SaleOrderDetailRepository } from '@repositories/sale-order/sale-order-detail.repository';
import { SaleOrderRepository } from '@repositories/sale-order/sale-order.repository';
import { WarehouseService } from './../warehouse/warehouse.service';
import { SaleOrderItemDetailsImport } from './import/sale-order-item-detail.import.helper';
import { SaleOrdersImport } from './import/sale-order.import.helper';
import { SaleOrderUpdateActualQuantityListener } from './listeners/sale-order-update-actual-quantity.listener';
import { SaleOrderUpdateConfirmedQuantityListener } from './listeners/sale-order-update-confimed-quantity.listener';
import { SaleOrderListener } from './listeners/sale-order.notification.listener';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      SaleOrder,
      SaleOrderDetail,
      Customer,
      SaleOrderExport,
    ]),
    ItemModule,
    CustomerModule,
    UserModule,
    ProduceModule,
    PlanModule,
    NotificationModule,
  ],
  providers: [
    {
      provide: 'SaleOrderRepositoryInterface',
      useClass: SaleOrderRepository,
    },
    {
      provide: 'SaleOrderExportRepositoryInterface',
      useClass: SaleOrderExportRepository,
    },
    {
      provide: 'SaleOrderDetailRepositoryInterface',
      useClass: SaleOrderDetailRepository,
    },
    {
      provide: 'CustomerRepositoryInterface',
      useClass: CustomerRepository,
    },
    {
      provide: 'SaleOrderServiceInterface',
      useClass: SaleOrderService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'ProduceServiceInterface',
      useClass: ProduceService,
    },
    {
      provide: 'SaleOrderItemDetailsImport',
      useClass: SaleOrderItemDetailsImport,
    },
    {
      provide: 'SaleOrdersImport',
      useClass: SaleOrdersImport,
    },
    {
      provide: 'PlanServiceInterface',
      useClass: PlanService,
    },
    {
      provide: 'NotificationServiceInterface',
      useClass: NotificationService,
    },
    {
      provide: 'RequestServiceInterface',
      useClass: RequestService,
    },
    SaleOrderListener,
    SaleOrderUpdateActualQuantityListener,
    SaleOrderUpdateConfirmedQuantityListener,
    ConfigService,
  ],
  controllers: [SaleOrderController],
})
export class SaleOrderModule {}
