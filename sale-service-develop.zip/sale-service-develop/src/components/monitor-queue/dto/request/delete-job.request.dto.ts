import { FindJobRequestDto } from './find-job.request.dto';

export class DeleteJobRequestDto extends FindJobRequestDto {}
