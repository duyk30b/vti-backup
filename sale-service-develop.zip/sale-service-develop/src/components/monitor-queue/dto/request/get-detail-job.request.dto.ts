import { FindJobRequestDto } from './find-job.request.dto';

export class GetDetailJobRequestDto extends FindJobRequestDto {}
