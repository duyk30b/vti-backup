import { ApiProperty } from '@nestjs/swagger';
import { IsObject } from 'class-validator';
import { FindJobRequestDto } from './find-job.request.dto';

export class UpdateJobRequestDto extends FindJobRequestDto {
  @ApiProperty()
  @IsObject()
  data: any;
}
