import { QUEUES_NAME_ENUM } from '@constant/common';
import { BullModule } from '@nestjs/bull';
import { Global, Module } from '@nestjs/common';
import { MonitorQueueController } from './monitor-queue.controller';
import { MonitorQueueService } from './monitor-queue.service';

@Global()
@Module({
  imports: [
    BullModule.registerQueue({
      name: QUEUES_NAME_ENUM.SYNC_DATA_QUEUE,
    }),
  ],
  exports: [],
  providers: [
    {
      provide: 'MonitorQueueServiceInterface',
      useClass: MonitorQueueService,
    },
  ],
  controllers: [MonitorQueueController],
})
export class MonitorQueueModule {}
