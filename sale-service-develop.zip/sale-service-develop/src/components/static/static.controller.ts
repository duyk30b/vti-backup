import { Controller, Get, Param } from '@nestjs/common';
import { getTemplate } from '@utils/common';
import { FileStaticRequest } from './dto/file-static.request';
import { FileStaticResponse } from './dto/file-static.response';
import { FILE_NAME_ENUM, FILE_NAME_MAP } from '@constant/import.constant';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ApiOperation } from '@nestjs/swagger';

@Controller('template-import')
export class StaticController {
  constructor(private readonly i18n: I18nRequestScopeService) {}

  @Get('/:filename')
  @ApiOperation({
    tags: ['import', 'import'],
    summary: 'import ',
    description: 'lấy file mẫu import',
  })
  // @MessagePattern('item-download-file')
  public async downloadFile(
    @Param() param: FileStaticRequest
  ): Promise<any> {
    const { request } = param;

    const fileStaticResponse = new FileStaticResponse();
    const fs = require('fs');

    if (!FILE_NAME_ENUM[request.fileName]) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.FILE_NOT_EXIST'))
        .build();
    }
    const fileName = FILE_NAME_MAP[request.fileName];
    fileStaticResponse.data = await Buffer.from(
      fs.readFileSync(`${getTemplate(request.lang)}${fileName}`, {}),
    );

    return fileStaticResponse;
  }
}
