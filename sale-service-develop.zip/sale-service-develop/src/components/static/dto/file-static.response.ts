import { SuccessResponse } from '@utils/success.response.dto';

export class FileStaticResponse {
  data: any;
}

export class FileStaticBufferResponse extends SuccessResponse {
  file: Buffer;
}
