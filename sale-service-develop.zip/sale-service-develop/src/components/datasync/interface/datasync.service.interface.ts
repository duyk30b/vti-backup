import { PushQueueEvent } from '@components/sync-data/event/push-queue.event';
import { RetryJobRequestDto } from '../dto/request/retry-job.request.dto';

export interface DatasyncServiceInterface {
  createJob(event: PushQueueEvent, payload: any): Promise<any>;
  updateJobStatus(id: string, status: number): Promise<any>;
  retry(request: RetryJobRequestDto): Promise<any>;
  getDetailJob(id: string): Promise<any>;
}
