import { BaseDto } from '@core/dto/base.dto';
import { IsString } from 'class-validator';

export class RetryJobRequestDto extends BaseDto {
  @IsString()
  jobSyncId: string;

  payload: any;
}
