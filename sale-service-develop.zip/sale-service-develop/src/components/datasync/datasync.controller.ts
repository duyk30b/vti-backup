import { Body, Controller, Inject, Put } from '@nestjs/common';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty } from 'lodash';
import { RetryJobRequestDto } from './dto/request/retry-job.request.dto';
import { DatasyncServiceInterface } from './interface/datasync.service.interface';

@Controller('datasync')
export class DatasyncController {
  constructor(
    @Inject('DatasyncServiceInterface')
    private readonly datasyncService: DatasyncServiceInterface,
  ) {}

  @Put('/retry')
  public async retry(
    @Body() payload: RetryJobRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.datasyncService.retry(request);
  }
}
