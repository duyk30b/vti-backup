import { ConfigService } from '@config/config.service';
import { DatasyncServiceInterface } from '@components/datasync/interface/datasync.service.interface';
import { Injectable } from '@nestjs/common';
import { HttpClientCronService } from '@core/components/http-client/http-client.cron.service';
import { RetryJobRequestDto } from './dto/request/retry-job.request.dto';
import { InjectQueue } from '@nestjs/bull';
import Queue from 'bull';
import { QUEUES_NAME_ENUM } from '@constant/common';
import {
  NUMBER_RETRY_QUEUE,
  SYNC_FROM_SYSTEM_ENUM,
} from '@components/sync-data/sync-data.constant';
import { PushQueueEvent } from '@components/sync-data/event/push-queue.event';

@Injectable()
export class DatasyncService implements DatasyncServiceInterface {
  private endpoint = '/api/v1/datasync';
  private serviceName = 'datasync-service';

  private httpConfig = {
    scalingDuration: 10,
    excludedStatusCodes: [409, 422],
    callInternalService: true,
    serviceName: this.serviceName,
  };
  constructor(
    private readonly httpClientService: HttpClientCronService,

    private readonly configService: ConfigService,

    @InjectQueue(QUEUES_NAME_ENUM.SYNC_DATA_QUEUE)
    private queue: Queue,
  ) {
    this.configService = new ConfigService();
  }

  public async retry(request: RetryJobRequestDto): Promise<any> {
    const { jobSyncId, payload } = request;
    await this.queue.add(
      payload.event,
      {
        ...payload.object,
        jobSyncId: jobSyncId,
      },
      {
        attempts: NUMBER_RETRY_QUEUE,
      },
    );
  }

  public async updateJobStatus(id: string, status: number): Promise<any> {
    try {
      const response = await this.httpClientService.put(
        `${this.endpoint}/jobs/${id}/status`,
        {
          status: status,
        },
        this.httpConfig,
      );
      return response?.data;
    } catch (e) {
      console.error(e);
    }
  }

  public async getDetailJob(id: string): Promise<any> {
    try {
      const response = await this.httpClientService.get(
        `${this.endpoint}/jobs/${id}`,
        {},
        this.httpConfig,
      );
      return response?.data;
    } catch (e) {
      console.error(e);
      return {};
    }
  }

  public async createJob(info: PushQueueEvent, payload: any): Promise<any> {
    try {
      const response = await this.httpClientService.post(
        `${this.endpoint}/jobs`,
        {
          ...info,
          fromSystem: SYNC_FROM_SYSTEM_ENUM.WMS,
          service: 'SALE-SERVICE',
          event: info.process,
          retryMessagePattern: '/api/v1/sales/datasync/retry',
          object: payload,
          createdBy: 1,
        },
        this.httpConfig,
      );

      return response?.data;
    } catch (e) {
      console.error(e);
    }
  }
}
