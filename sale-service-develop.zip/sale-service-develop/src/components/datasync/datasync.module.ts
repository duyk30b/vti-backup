import { ConfigService } from '@config/config.service';
import { Global, Module } from '@nestjs/common';
import { DatasyncService } from './datasync.service';
import { DatasyncController } from './datasync.controller';
import { BullModule } from '@nestjs/bull';
import { QUEUES_NAME_ENUM } from '@constant/common';

@Global()
@Module({
  imports: [
    BullModule.registerQueue({
      name: QUEUES_NAME_ENUM.SYNC_DATA_QUEUE,
    }),
  ],
  providers: [
    ConfigService,
    {
      provide: 'DatasyncServiceInterface',
      useClass: DatasyncService,
    },
  ],
  exports: [
    {
      provide: 'DatasyncServiceInterface',
      useClass: DatasyncService,
    },
  ],
  controllers: [DatasyncController],
})
export class DatasyncModule {}
