import { PurchasedOrderImportRepository } from '@repositories/purchased-order-import/purchased-order-import.repository';
import { SaleOrderExportRepository } from './../../repositories/sale-order-export/sale-order-export.repository';
import { PurchasedOrderImportEntity } from '@entities/purchased-order-import/purchased-order-import.entity';
import { SaleOrderExport } from '@entities/sale-order-export/sale-order-export.entity';

import { DashboardService } from './dashboard.service';
import { Global, Module } from '@nestjs/common';
import { DashboardController } from './dashboard.controller';
import { TypeOrmModule } from '@nestjs/typeorm';

@Global()
@Module({
  imports: [
    TypeOrmModule.forFeature([SaleOrderExport, PurchasedOrderImportEntity]),
  ],
  providers: [
    {
      provide: 'SaleOrderExportRepositoryInterface',
      useClass: SaleOrderExportRepository,
    },
    {
      provide: 'PurchasedOrderImportRepositoryInterface',
      useClass: PurchasedOrderImportRepository,
    },
    {
      provide: 'DashboardServiceInterface',
      useClass: DashboardService,
    },
  ],
  controllers: [DashboardController],
})
export class DashboardModule {}
