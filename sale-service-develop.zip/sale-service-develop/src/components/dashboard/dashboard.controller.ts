import { ReportDetailOrderRequestDto } from './dto/request/report-detail-order.request.dto';
import { Body, Controller, Get, Inject, Query } from '@nestjs/common';
import { ReportTotalOrderRequestDto } from './dto/request/report-total-order.request.dto';
import { DashboardServiceInterface } from './interface/dashboard.service.interface';
import { isEmpty } from 'lodash';
import { MessagePattern } from '@nestjs/microservices';
import { NATS_SALE } from '@config/nats.config';
@Controller('dashboard')
export class DashboardController {
  constructor(
    @Inject('DashboardServiceInterface')
    private readonly dashboardService: DashboardServiceInterface,
  ) {}

  @MessagePattern(`${NATS_SALE}.sale_report_total_order`)
  public async reportTotalOrder(
    @Body() query: ReportTotalOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.dashboardService.reportTotalOrder(request);
  }

  @Get(`purchased-order-imports/total`)
  public async reportPurchasedOrderImport(
    @Query() query: ReportDetailOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.dashboardService.reportPurchasedOrderImport(request);
  }

  @Get(`sale-order-exports/total`)
  public async reportSaleOrderExport(
    @Query() query: ReportDetailOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.dashboardService.reportSaleOrderExport(request);
  }
}
