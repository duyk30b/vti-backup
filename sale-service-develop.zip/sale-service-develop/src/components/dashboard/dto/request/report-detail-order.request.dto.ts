import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsOptional } from 'class-validator';
import { ReportTotalOrderRequestDto } from './report-total-order.request.dto';
export class ReportDetailOrderRequestDto extends ReportTotalOrderRequestDto {
  @ApiProperty()
  @IsOptional()
  @Transform(({ value }) => +value)
  @IsInt()
  warehouseId: number;
}
