import { SaleOrderExportRepositoryInterface } from '@components/sale-order-export/interface/sale-order-export.repository.interface';
import { PurchasedOrderImportRepositoryInterface } from './../purchased-order-import/interface/purchased-order-import.repository.interface';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ReportTotalOrderRequestDto } from './dto/request/report-total-order.request.dto';
import { DashboardServiceInterface } from './interface/dashboard.service.interface';
import { ReportDetailOrderRequestDto } from './dto/request/report-detail-order.request.dto';

@Injectable()
export class DashboardService implements DashboardServiceInterface {
  constructor(
    private readonly i18n: I18nRequestScopeService,

    @Inject('PurchasedOrderImportRepositoryInterface')
    private readonly purchasedOrderImportRepository: PurchasedOrderImportRepositoryInterface,

    @Inject('SaleOrderExportRepositoryInterface')
    private readonly saleOrderExportRepository: SaleOrderExportRepositoryInterface,
  ) {}

  async reportTotalOrder(request: ReportTotalOrderRequestDto): Promise<any> {
    const [totalPurchasedOrderImport, totalSaleOrderExport] = await Promise.all(
      [
        this.purchasedOrderImportRepository.reportTotalOrder(request),
        this.saleOrderExportRepository.reportTotalOrder(request),
      ],
    );
    const response = {
      totalSaleOrderExport,
      totalPurchasedOrderImport,
    };
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async reportPurchasedOrderImport(
    request: ReportDetailOrderRequestDto,
  ): Promise<any> {
    const report = await this.purchasedOrderImportRepository.reportDetailOrder(
      request,
    );
    return new ResponseBuilder(report)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async reportSaleOrderExport(
    request: ReportDetailOrderRequestDto,
  ): Promise<any> {
    const report = await this.saleOrderExportRepository.reportDetailOrder(
      request,
    );
    return new ResponseBuilder(report)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
