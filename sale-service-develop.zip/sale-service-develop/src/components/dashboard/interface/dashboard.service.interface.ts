import { ReportDetailOrderRequestDto } from '../dto/request/report-detail-order.request.dto';
import { ReportTotalOrderRequestDto } from './../dto/request/report-total-order.request.dto';
export interface DashboardServiceInterface {
  reportTotalOrder(request: ReportTotalOrderRequestDto): Promise<any>;
  reportPurchasedOrderImport(
    request: ReportDetailOrderRequestDto,
  ): Promise<any>;
  reportSaleOrderExport(request: ReportDetailOrderRequestDto): Promise<any>;
}
