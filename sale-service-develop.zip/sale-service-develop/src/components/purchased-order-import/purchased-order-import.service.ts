import { SyncDataService } from './../sync-data/sync-data.service';
import {
  WarehouseReceiveRequestDto,
  WarehouseItemReceiveRequestDto,
} from './../warehouse/dto/request/warehouse-receive.dto';
import { ApiError } from '@utils/api.error';
import { UpdateOrderDetailReturnQuantityRequestDto } from '@components/order/dto/request/update-return-quantity-order-detail.request.dto';
import { GetErrorItemByOrderRequestDto } from '../order/dto/request/get-error-item-by-order.request.dto';
import { LotNumberOfItemResponseDto } from '@components/import-order/dto/response/list-lot-number.response.dto';
import {
  div,
  generatePaddingCode,
  plus,
  searchLikeString,
} from '@utils/helper';
import { PurchasedOrderImportWarehouseDetailResponseDto } from './dto/response/purchased-order-import-warehouse-detail.response.dto';
import { OrderUpdateConfirmedQuantityEvent } from '../order/events/order-update-confirmed-quantity.event';
import {
  SetOrderStatusBodyDto,
  SetOrderStatusRequestDto,
} from '../order/dto/request/set-order-status-request.dto';
import {
  CAN_UPDATE_ORDER_STATUS,
  STATUS_TO_CONFIRM_ORDER_STATUS,
  STATUS_TO_APPROVE_ORDER_STATUS,
  STATUS_TO_DELETE_ORDER_STATUS,
  STATUS_TO_REJECT_ORDER_STATUS,
  STATUS_TO_QC_ORDER,
  STATUS_TO_CREATE_ORDER_RECEIVE,
  STATUS_TO_UPDATE_PURCHASED_ORDER_IMPORT,
  STATUS_TO_REJECT_RECEIVED_PURCHASED_ORDER_INPORT,
  MAPPING_MASTER_DATA_BUSSINESS_TYPE,
  CAN_UPDATE_POI_STATUS,
  STATUS_CAN_UPDATE_HEADER_POI,
  SYNC_STATUS_CAN_UPDATE_HEADER_POI,
  OrderWarehouseActionTypeEnum,
} from '@constant/order.constant';
import { PurchasedOrderImportDetailEntity } from '@entities/purchased-order-import/purchased-order-import-detail.entity';
import { UpdatePurchasedOrderImportDto } from './dto/request/update-purchased-order-import-request.dto';
import { WarehouseServiceInterface } from '../warehouse/interface/warehouse.service.interface';
import { OrderServiceAbstract } from '../order/interface/order.service.abstract';
import { PurchasedOrderImportResponseDto } from './dto/response/purchased-order-import.response.dto';
import { PurchasedOrderImportListResponse } from './dto/response/purchased-order-import-list-response.dto';
import { PagingResponse } from '@utils/paging.response';
import { GetPurchasedOrderImportListRequest } from './dto/request/get-purchased-order-import-list-request.dto';
import { plainToInstance } from 'class-transformer';
import { Inject, Injectable, Logger } from '@nestjs/common';
import { PurchasedOrderImportRepositoryInterface } from '@components/purchased-order-import/interface/purchased-order-import.repository.interface';
import { PurchasedOrderImportServiceInterface } from '@components/purchased-order-import/interface/purchased-order-import.service.interface';
import { CreatePurchasedOrderImportDto } from '@components/purchased-order-import/dto/request/create-purchased-order-import.dto';
import { UpdateOrderDetailActualQuantityRequestDto } from '@components/order/dto/request/update-actual-quantity-order-detail.request.dto';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, In, ILike, Like, Not, IsNull } from 'typeorm';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ResponseBuilder } from '@utils/response-builder';
import { PurchasedOrderImportDetailRepositoryInterface } from './interface/purchased-order-import-detail.repository.interface';
import { PurchasedOrderImportWarehouseDetailRepositoryInterface } from './interface/purchased-order-import-warehouse-detail.repository.interface';
import { UpdateOrderDetailConfirmQuantityRequestDto } from '@components/order/dto/request/update-confirm-quantity-order-detail.request.dto';
import {
  compact,
  filter,
  find,
  first,
  flatMap,
  groupBy,
  has,
  isEmpty,
  isNull,
  keyBy,
  map,
  min,
  sumBy,
  uniq,
  values,
  flatten,
  uniqBy,
  orderBy,
} from 'lodash';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import {
  CAN_COMPLETE_PO,
  NUMBER_OF_CREDIT_ACCOUNT_SEGMENTS,
  OrderStatusEnum,
  OrderTypeEnum,
  ROLE,
  StatusSyncOrderToEbsEnum,
  TypeBussinessAttributeEnum,
  WarehouseMovementTypeEnum,
  WarehouseMovementTypeEnum as WarehouseStockMovementTypeEnum,
} from '@constant/common';
import { OrderTypeEnum as SaleOrderTypeEnum } from '@constant/order.constant';
import { GetOrderDetailRequestDto } from '@components/order/dto/request/get-order-detail.request.dto';
import { GetAllPOImportRequest } from './dto/request/get-all-po-import.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { GetAllPOImportResponse } from './dto/response/get-all-po-import.response.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { DeleteOrderRequestDto } from '@components/order/dto/request/delete-order.request.dto';
import { GetListOrderByIdsRequestDto } from '@components/order/dto/request/get-list-order-by-ids.request.dto';
import { GetByItemIdRequestDto } from '@components/purchased-order/dto/request/get-by-item-id.request.dto';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { OrderUpdateActualQuantityEvent } from '@components/order/events/order-update-actual-quantity.event';
import { GetOrderDetailByWarehouseRequestDto } from '@components/order/dto/request/get-order-detail-by-warehouse.request.dto';
import { GetOrderWarehouseRequest } from '@components/order/dto/request/get-order-warehouse.request.dto';
import { OrderWarehouseResponse } from '@components/order/dto/response/order-warehouse-response.dto';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { GetOrderByWarehouseItemRequestDto } from '@components/order/dto/request/get-order-by-warehouse-item.request.dto';
import { UpdatePurchasedOrderImportWarehouseQcQuantityDto } from './dto/request/update-purchased-order-import-warehouse-qc-quantity-request.dto';
import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { TotalQuantityItemPurchaseOrderImportResponseDto } from './dto/response/total-quantity-item-purchased-order-import.response.dto';
import { PurchasedOrderImportWarehouseLotRepositoryInterface } from './interface/purchased-order-import-warehouse-lot.repository.interface';
import { PurchasedOrderImportWarehouseLotEntity } from '@entities/purchased-order-import/purchased-order-import-warehouse-lot.entity';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { PurchasedOrderImportImport } from './import/purchased-order-import.import.helper';
import { ImportPurchasedOrderImportResponseDto } from './dto/response/import-purchased-order-import.response.dto';
import { PurchasedOrderImportEntity } from '@entities/purchased-order-import/purchased-order-import.entity';
import { PurchasedOrderImportWarehouseDetailEntity } from '@entities/purchased-order-import/purchased-order-import-warehouse-detail.entity';
import { PurchasedOrderRepositoryInterface } from '@components/purchased-order/interface/purchased-order.repository.interface';
import { UpdateWarehouseLotRequestDto } from '@components/order/dto/request/update-warehouse-lot.request.dto';
import * as Moment from 'moment';
import { GetListWarehouseExitsFloorRequestDto } from '@components/warehouse/dto/request/get-warehouse-exits-floor.request.dto';
import { stringFormat } from '@utils/object.util';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { SuggestStoredOrderImportRequestDto } from './dto/request/suggest-stored-order-import.request.dto';
import { SuggestImportItemToWarehouseShelfFloorRequestDto } from '@components/warehouse/dto/request/suggest-import-item-to-warehouse-shelf-floor.request.dto';
import {
  CreatePurchasedOrderImportReceiveItemEntityRequestDto,
  CreatePurchasedOrderImportReceiveRequestDto,
} from './dto/request/create-purchased-order-import-receive.request.dto';
import { PurchasedOrderImportReceiveItemRepositoryInterface } from './interface/purchased-order-import-receive-item.repository';
import { SubmitPOImportReceiveRequeseDto } from './dto/request/receive/submit-po-import-receive.request.dto';
import { PurchasedOrderImportReceiveRepositoryInterface } from './interface/purchased-order-import-receive.repository.interface';
import {
  ActionNotificationEnum,
  TypeNotificationEnum,
} from '@components/notification/notification.const';
import { PushNotificationRequestDto } from '@components/notification/dto/notification.request.dto';
import { PurchasedOrderImportReceiveDetailResponseDto } from './dto/response/get-purchased-order-import-receive-detail.response.dto';
import { SuggestStoredPurchasedOrderImportResponseDto } from './dto/response/suggest-stored-purchased-order-import.response.dto';
import { GetOrderDoorRequestDto } from '@components/order/dto/request/get-order-door.request.dto';
import { WarehouseDoorResponseDto } from '@components/warehouse/dto/response/warehouse-door.response.dto';
import { VendorRepositoryInterface } from '@components/vendor/interface/vendor.repository.interface';
import { Vendor } from '@entities/vendor/vendor.entity';
import { GetSuggestStoredByPoImportIdRequestDto } from './dto/request/get-suggest-stored-by-po-import-id.request.dto';
import { PurchasedOrderImportReceiveItemEntity } from '@entities/purchased-order-import/purchased-order-import-receive-item.entity';
import {
  getInnerJoinElements,
  minus,
  minusBigNumber,
  plusBigNumber,
} from '@utils/common';
import { UpdatePurchasedOrderImportReceiveRequestDto } from './dto/request/update-purchased-order-import-receive.request.dto';
import { GetByItemIdsRequestDto } from './dto/request/get-by-item-ids.request.dto';
import { FileRepositoryInterface } from '@components/file/interface/file.repository.interface';
import { FileResource } from '@components/file/constant/file-upload.constant';
import { FileService } from '@components/file/file.service';
import {
  BusinessTypeAttributeDefaultEnum,
  WarehouseByLotManagementEnum,
} from '@components/warehouse/warehouse.contant';
import { UpdateStockStatusOrderRequest } from '@components/warehouse/dto/request/update-stock-status-order.request';
import { PurchasedOrderImportCompleteRequestDto } from './dto/request/purchased-order-import-complete.request.dto';
import { DetailMovementPurchasedOrderImportResponseDto } from './dto/response/detail-movement-purchased-order-import.response.dto';
import { ErrorItem } from '../order/dto/response/get-error-item-by-order.response.dto';
import { OrderUpdateStatusEvent } from '@components/order/events/order-update-status.event';
import { PurchasedOrderServiceInterface } from '@components/purchased-order/interface/purchased-order.service.interface';
import { CreatePurchasedOrderDto } from '@components/purchased-order/dto/request/create-purchased-order.dto';
import {
  AUTO_CREATE_RECEIVE,
  BUSINESS_TYPE,
  BUSINESS_TYPE_ATTRIBUTE_TABLE_NAME,
  EventSyncPoImportEnum,
  POIMP_ITEMS,
  POIMP_LOT,
  PO_IMPORT_CODE_PREFIX,
  PO_IMPORT_STATUS_NOT_USED_RECEIPT,
  STATUS_SYNC_PURCHASED_ORDER_IMPORT_TO_EBS,
} from './purchased-order-import.contant';
import { ValidatePoiDetailWithReceiptDetail } from './validate/validate-poi-detail-with-receipt-detail.helper';
import { ValidatePoiDetailWithSoeDetail } from './validate/validate-poi-detail-with-soe-detail.helper';
import { ValidatePoiDetailWithWarehouseExportProposalDetail } from './validate/validate-poi-detail-with-warehouse-export-proposal-detail.helper';
import { ValidatePoiDetailWithMasterDataItem } from './validate/validate-poi-detail-with-master-data-item.helper';
import { ReceiptRepositoryInterface } from '@components/receipt/interface/receipt.repository.interface';
import { SourceRepositoryInterface } from '@components/source/interface/sources.repository.interface';
import { ReasonRepositoryInterface } from '@components/reason/interface/reason.repository.interface';
import {
  CODE_DELIMITER,
  SourceStatusEnum,
  SOURCE_RULES,
} from '@components/source/source.constants';
import { ConfigService } from '@config/config.service';
import { GetAttributeDetailValuesRequestDto } from '@components/warehouse/dto/request/get-attribute-detail-values.request.dto';
import { EbsInPOImportRequestDto } from './dto/request/sync/ebs-in-po-import.request.dto';
import { ReceiptServiceInterface } from '@components/receipt/interface/receipt.service.interface';
import { ReceiptEntity } from '@entities/receipt/receipt.entity';
import {
  RECEIPT_STATUS,
  VALID_STATUS_RECEIPT,
} from '@components/receipt/receipt.contant';
import { ValidatePoiDetailWithSoeDetailAfterConfirm } from './validate/validate-poi-detail-with-so-detail-after-confirm.helper';
import { GetPurchasedOrderImportByConditions } from './dto/request/get-purchased-order-import-by-conditions.request.dto';
import { CreatePurchasedOrderImportAutoCompleteDto } from './dto/request/create-purchased-order-import-auto-complete.dto';
import { WarehouseImportDto } from '@components/warehouse/dto/request/warehouse-import.request.dto';
import { WarehouseLayoutServiceInterface } from '@components/warehouse-layout/interface/warehouse-layout.service.interface';
import { CategoryContructionRepositoryInterface } from '@components/category-contruction/interface/category-contruction.interface.repository';
import { ConstructionRepositoryInterface } from '@components/construcion/interface/construction.interface.repository';
import { CostTypeRepositoryInterface } from '@components/cost-type/interface/cost-type.repository.interface';
import { OrganizationPaymentRepositoryInterface } from '@components/organization-payment/interface/organization-payment.repository.interface';
import { GetListOpenTransactionRequestDto } from './dto/request/get-list-open-transaction.request.dto';
import { UpdateHeaderPurchasedOrderImportBodyDto } from './dto/request/update-header-purchased-orderimport.request';
import { UpdateHeaderEbsInPOIRequest } from './dto/request/sync/update-header-ebs-in-poi.request.dto';
import { UpdateStockFromOrderRequest } from '@components/item/dto/request/update-stock-from-order.request.dto';
import { CreatePurchasedOrderImportReceiveWithTicketRequestDto } from './dto/request/receive/create-purchased-order-import-receive-with-ticket-order.request.dto';
import { TicketServiceInterface } from '@components/ticket/interface/ticket.service.interface';

@Injectable()
export class PurchasedOrderImportService
  extends OrderServiceAbstract
  implements PurchasedOrderImportServiceInterface
{
  private readonly logger = new Logger(PurchasedOrderImportService.name);
  constructor(
    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('ProduceServiceInterface')
    protected readonly produceService: ProduceServiceInterface,

    @Inject('VendorRepositoryInterface')
    private readonly vendorRepository: VendorRepositoryInterface,

    @Inject('PurchasedOrderRepositoryInterface')
    private readonly purchasedOrderRepository: PurchasedOrderRepositoryInterface,

    @Inject('PurchasedOrderImportRepositoryInterface')
    private readonly purchasedOrderImportRepository: PurchasedOrderImportRepositoryInterface,

    @Inject('PurchasedOrderImportDetailRepositoryInterface')
    private readonly purchasedOrderImportDetailRepository: PurchasedOrderImportDetailRepositoryInterface,

    @Inject('PurchasedOrderImportWarehouseDetailRepositoryInterface')
    private readonly purchasedOrderImportWarehouseDetailRepository: PurchasedOrderImportWarehouseDetailRepositoryInterface,

    @Inject('PurchasedOrderImportWarehouseLotRepositoryInterface')
    private readonly purchasedOrderImportWarehouseLotRepository: PurchasedOrderImportWarehouseLotRepositoryInterface,

    @Inject('PurchasedOrderImportReceiveRepositoryInterface')
    private readonly purchasedOrderImportReceiveRepository: PurchasedOrderImportReceiveRepositoryInterface,

    @Inject('PurchasedOrderImportReceiveItemRepositoryInterface')
    private readonly purchasedOrderImportReceiveItemRepository: PurchasedOrderImportReceiveItemRepositoryInterface,

    @Inject('ReceiptRepositoryInterface')
    private readonly receiptRepository: ReceiptRepositoryInterface,

    @Inject('FileRepositoryInterface')
    private readonly fileRepository: FileRepositoryInterface,

    @Inject('PurchasedOrderImportImport')
    private readonly purchasedOrderImportImport: PurchasedOrderImportImport,

    @Inject('FileServiceInterface')
    private readonly fileService: FileService,

    @Inject('PurchasedOrderServiceInterface')
    private readonly purchasedOrderService: PurchasedOrderServiceInterface,

    @Inject('ValidatePoiDetailWithMasterDataItem')
    private readonly validatePoiDetailWithMasterDataItem: ValidatePoiDetailWithMasterDataItem,

    @Inject('ValidatePoiDetailWithReceiptDetail')
    private readonly validatePoiDetailWithReceiptDetail: ValidatePoiDetailWithReceiptDetail,

    @Inject('ValidatePoiDetailWithSoeDetail')
    private readonly validatePoiDetailWithSoeDetail: ValidatePoiDetailWithSoeDetail,

    @Inject('ValidatePoiDetailWithWarehouseExportProposalDetail')
    private readonly validatePoiDetailWithWarehouseExportProposalDetail: ValidatePoiDetailWithWarehouseExportProposalDetail,

    @Inject('ValidatePoiDetailWithSoeDetailAfterConfirm')
    private readonly validatePoiDetailWithSoeDetailAfterConfirm: ValidatePoiDetailWithSoeDetailAfterConfirm,

    @Inject('SourceRepositoryInterface')
    protected readonly sourceRepository: SourceRepositoryInterface,

    @Inject('ReasonRepositoryInterface')
    protected readonly reasonRepository: ReasonRepositoryInterface,

    @Inject('ReceiptsServiceInterface')
    private readonly receiptService: ReceiptServiceInterface,

    @Inject('TicketServiceInterface')
    private readonly ticketService: TicketServiceInterface,

    @Inject('WarehouseLayoutServiceInterface')
    private readonly warehouseLayoutService: WarehouseLayoutServiceInterface,

    @Inject('CategoryContructionRepositoryInterface')
    private readonly categoryContructionRepository: CategoryContructionRepositoryInterface,

    @Inject('ConstructionRepositoryInterface')
    private readonly constructionRepository: ConstructionRepositoryInterface,

    @Inject('CostTypeRepositoryInterface')
    private readonly costTypeRepository: CostTypeRepositoryInterface,

    @Inject('OrganizationPaymentRepositoryInterface')
    private readonly organizationPaymentRepository: OrganizationPaymentRepositoryInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private eventEmitter: EventEmitter2,

    private readonly i18n: I18nRequestScopeService,

    @Inject('SyncDataServiceInterface')
    private readonly syncDataService: SyncDataService,

    @Inject('ConfigServiceInterface')
    private configService: ConfigService,
  ) {
    super(
      itemService,
      warehouseService,
      userService,
      sourceRepository,
      reasonRepository,
    );
  }

  /**
   * Get purchased order import by warehouse
   * @param payload
   * @returns
   */
  async getPoImportByWarehouse(
    request: GetOrderByWarehouseItemRequestDto,
  ): Promise<any> {
    const { id, warehouseId, withCompletedOrder } = request;
    const data =
      await this.purchasedOrderImportRepository.getDetailByWarehouseId(
        id,
        [warehouseId],
        withCompletedOrder,
      );
    if (!isEmpty(data)) {
      data.warehouse = await this.warehouseService.getWarehouses([warehouseId]);
    }

    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Get purchased order import by ids
   * @param payload
   * @returns
   */
  async getListByIds(
    payload: GetListOrderByIdsRequestDto,
  ): Promise<ResponsePayload<PurchasedOrderImportResponseDto | any>> {
    const { ids } = payload;
    const data = await this.purchasedOrderImportRepository.getListByIds(ids);

    const dataReturn = plainToInstance(PurchasedOrderImportResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Delete
   */
  public async delete(payload: DeleteOrderRequestDto): Promise<any> {
    const { id } = payload;

    const purchasedOrderImport =
      await this.purchasedOrderImportRepository.findOneWithRelations({
        where: { id },
        relations: [
          'purchasedOrderImportDetails',
          'purchasedOrderImportWarehouseLots',
          'purchasedOrderImportWarehouseDetails',
        ],
      });
    if (!purchasedOrderImport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_DELETE_ORDER_STATUS.includes(purchasedOrderImport.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    const purchasedOrder =
      await this.purchasedOrderRepository.findOneWithRelations({
        where: { id: purchasedOrderImport.purchasedOrderId },
        relations: ['purchasedOrderDetails', 'purchasedOrderWarehouseDetails'],
      });

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const purchasedOrderDetails = purchasedOrder.purchasedOrderDetails.map(
        (item) => {
          item.deletedAt = new Date();
          item.deletedBy = payload.userId;
          return item;
        },
      );
      await queryRunner.manager.save(purchasedOrderDetails);

      const purchasedOrderWarehouseDetails =
        purchasedOrder.purchasedOrderWarehouseDetails.map((item) => {
          item.deletedAt = new Date();
          item.deletedBy = payload.userId;
          return item;
        });
      await queryRunner.manager.save(purchasedOrderWarehouseDetails);

      purchasedOrder.deletedAt = new Date();
      purchasedOrder.deletedBy = payload.userId;
      await queryRunner.manager.save(purchasedOrder);

      const purchasedOrderImportDetails =
        purchasedOrderImport.purchasedOrderImportDetails.map((item) => {
          item.deletedAt = new Date();
          item.deletedBy = payload.userId;
          return item;
        });
      await queryRunner.manager.save(purchasedOrderImportDetails);

      const purchasedOrderImportWarehouseLots =
        purchasedOrderImport.purchasedOrderImportWarehouseLots.map((item) => {
          item.deletedAt = new Date();
          item.deletedBy = payload.userId;
          return item;
        });
      await queryRunner.manager.save(purchasedOrderImportWarehouseLots);

      const purchasedOrderImportWarehouseDetails =
        purchasedOrderImport.purchasedOrderImportWarehouseDetails.map(
          (item) => {
            item.deletedAt = new Date();
            item.deletedBy = payload.userId;
            return item;
          },
        );
      await queryRunner.manager.save(purchasedOrderImportWarehouseDetails);

      purchasedOrderImport.deletedAt = new Date();
      purchasedOrderImport.deletedBy = payload.userId;
      await queryRunner.manager.save(purchasedOrderImport);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }
    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Delete
   */
  public async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const purchasedOrderImports =
      await this.purchasedOrderImportRepository.findByCondition({
        id: In(ids),
      });

    const purchasedOrderImportIds = purchasedOrderImports.map(
      (purchasedOrderImport) => purchasedOrderImport.id,
    );
    if (purchasedOrderImports.length !== ids.length) {
      ids.forEach((id) => {
        if (!purchasedOrderImportIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < purchasedOrderImports.length; i++) {
      const purchasedOrderImport = purchasedOrderImports[i];
      if (!STATUS_TO_DELETE_ORDER_STATUS.includes(purchasedOrderImport.status))
        failIdsList.push(purchasedOrderImport.id);
    }

    const validIds = purchasedOrderImports
      .filter(
        (purchasedOrderImport) =>
          !failIdsList.includes(purchasedOrderImport.id),
      )
      .map((purchasedOrderImport) => purchasedOrderImport.id);

    const queryRunner = await this.connection.createQueryRunner();
    try {
      if (!isEmpty(validIds)) {
        await queryRunner.startTransaction();
        await queryRunner.manager.delete(
          PurchasedOrderImportWarehouseLotEntity,
          {
            purchasedOrderImportId: In(validIds),
          },
        );
        await queryRunner.manager.delete(PurchasedOrderImportDetailEntity, {
          purchasedOrderImportId: In(validIds),
        });
        await queryRunner.manager.delete(
          PurchasedOrderImportWarehouseDetailEntity,
          {
            purchasedOrderImportId: In(validIds),
          },
        );

        await queryRunner.manager.delete(PurchasedOrderImportEntity, validIds);
        await queryRunner.commitTransaction();
      }
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    await queryRunner.release();
    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  async getPurchasedOrderImportByConditions(
    request: GetPurchasedOrderImportByConditions,
  ): Promise<any> {
    const { warehouseId, itemIds, receiptDate } = request;
    const defaultTimeZone = this.configService.get('defaultTimeZone');
    const purchasedOrderImport =
      await this.purchasedOrderImportRepository.getPurchasedOrderImportByConditions(
        warehouseId,
        itemIds,
        receiptDate,
        defaultTimeZone,
      );
    if (!purchasedOrderImport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    return new ResponseBuilder(purchasedOrderImport)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  /**
   * Get genetal purchased order detail
   * @param payload
   * @returns
   */
  async getDetail(payload: GetOrderDetailRequestDto): Promise<any> {
    const { id } = payload;
    const purchasedOrderImport =
      await this.purchasedOrderImportRepository.getDetail(id);

    if (!purchasedOrderImport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const [businessType, attachment, departmentReceipt] = await Promise.all([
      this.warehouseService.getBusinessTypeDetail(
        purchasedOrderImport.businessTypeId,
        id,
        SaleOrderTypeEnum.PO,
      ),
      this.fileRepository.findOneByCondition({
        resourceId: id,
        resource: FileResource.POI,
      }),
      this.userService.getDepartmentReceiptById(
        purchasedOrderImport.departmentReceiptId,
      ),
    ]);
    let attachmentDetail;
    if (!isEmpty(attachment)) {
      attachmentDetail = await this.fileService.getFileById(attachment.fileId);
    }

    const itemIds = map(
      purchasedOrderImport.purchasedOrderImportDetails,
      'itemId',
    );
    const userIds = uniq([
      purchasedOrderImport.createdByUserId,
      purchasedOrderImport.confirmerId,
      purchasedOrderImport.approverId,
    ]).filter((id) => !isNull(id));
    const { items, warehouses, users } = await super.getOrderExtraInfo(
      itemIds,
      [purchasedOrderImport.warehouseId],
      userIds,
      false,
    );
    const normalizeItems = keyBy(items, 'itemId');
    const normalizeWarehouses = keyBy(warehouses, 'id');
    const normalizeUsers = keyBy(users, 'id');

    const itemLots = purchasedOrderImport.purchasedOrderImportWarehouseLots.map(
      (itemLot) => ({
        itemId: itemLot.itemId,
        lotNumber: itemLot.lotNumber,
        warehouseId: purchasedOrderImport.warehouseId,
      }),
    );
    const itemStockAvailable =
      await this.itemService.getItemStockAvailableByConditions({
        order: {
          orderId: id,
          orderType: OrderTypeEnum.Import,
        },
        items: itemLots,
      });
    const itemStockAvailableByItemId = groupBy(itemStockAvailable, 'itemId');

    const sourceIds = flatten(
      items.map((item) => item.itemWarehouseSources.map((iws) => iws.sourceId)),
    );
    const sources = await this.sourceRepository.findByCondition({
      id: In(sourceIds),
    });
    const sourceByIds = keyBy(
      sources.map((source) => {
        const companyCode = generatePaddingCode(
          source?.companyId,
          SOURCE_RULES.COMPANY_CODE.MAX_LENGTH,
        );
        const accountIdentifier = [
          companyCode,
          source?.branchCode,
          source?.costCenterCode,
          source?.accountant,
          source?.produceTypeCode,
          source?.productCode,
          source?.factorialCode,
          source?.internalDepartmentCode,
          source?.departmentBackupCode,
          source?.EVNBackupCode,
        ].join(CODE_DELIMITER);
        return {
          ...source,
          accountIdentifier,
        };
      }),
      'id',
    );
    purchasedOrderImport.createdByUser =
      normalizeUsers[purchasedOrderImport.createdByUserId];
    purchasedOrderImport.approver =
      normalizeUsers[purchasedOrderImport.approverId];
    purchasedOrderImport.confirmer =
      normalizeUsers[purchasedOrderImport.confirmerId];
    purchasedOrderImport.attributes = businessType.bussinessTypeAttributes;
    let attributeDetailValues: any = {};
    if (!isEmpty(purchasedOrderImport.attributes)) {
      const attributeGroup = groupBy(
        purchasedOrderImport.attributes,
        'tableName',
      );
      const payload = new GetAttributeDetailValuesRequestDto();
      const attributeKeys = Object.keys(attributeGroup).filter(
        (el) => !el.match('null'),
      );
      payload.filter = attributeKeys.map((key) => {
        return {
          tableName: key,
          id: map(attributeGroup[key], 'value').join(','),
        };
      });
      attributeDetailValues =
        await this.warehouseService?.getAttributeDetailValuesTcp(payload);
    }

    let serializeWarehouseExportProposal = {} as any;
    let warehouseExportProposal = {} as any;

    if (
      !isEmpty(attributeDetailValues) &&
      !isEmpty(attributeDetailValues?.receipts) &&
      !purchasedOrderImport?.receiptNumberEbs
    ) {
      purchasedOrderImport.receiptNumberEbs = first(
        attributeDetailValues?.receipts,
      )?.receiptNumber;
    }
    if (
      !isEmpty(attributeDetailValues) &&
      !isEmpty(attributeDetailValues?.warehouse_export_proposals)
    ) {
      warehouseExportProposal =
        await this.warehouseService.getWarehouseExportProposalDetail(
          first(attributeDetailValues?.warehouse_export_proposals)?.id,
        );

      const warehouseExportProposalDetailChilds = map(
        warehouseExportProposal.items,
        'childrens',
      );
      serializeWarehouseExportProposal = keyBy(
        flatMap(warehouseExportProposalDetailChilds),
        'itemId',
      );
    }

    purchasedOrderImport.purchasedOrderImportDetails =
      purchasedOrderImport.purchasedOrderImportDetails.map(
        (purchasedOrderImportDetail) => ({
          ...purchasedOrderImportDetail,
          exportableQuantity: !isEmpty(serializeWarehouseExportProposal)
            ? serializeWarehouseExportProposal[
                purchasedOrderImportDetail.itemId
              ]?.exportableQuantity || 0
            : itemStockAvailableByItemId[
                purchasedOrderImportDetail.itemId
              ]?.reduce((prev, cur) => prev + Number(cur.quantity), 0),
          requestedQuantityWarehouseExportProposal:
            serializeWarehouseExportProposal[purchasedOrderImportDetail.itemId]
              ?.requestedQuantity
              ? serializeWarehouseExportProposal[
                  purchasedOrderImportDetail.itemId
                ].requestedQuantity
              : 0,
          itemCode: normalizeItems[purchasedOrderImportDetail.itemId]?.code,
          item: {
            ...normalizeItems[purchasedOrderImportDetail.itemId],
            itemWarehouseSources: normalizeItems[
              purchasedOrderImportDetail.itemId
            ]?.itemWarehouseSources?.map((iws) => ({
              ...iws,
              ...sourceByIds[iws.sourceId],
            })),
          },
          lots: purchasedOrderImport.purchasedOrderImportWarehouseLots
            .filter(
              (purchasedOrderImportWarehouseLot) =>
                purchasedOrderImportWarehouseLot.itemId ===
                purchasedOrderImportDetail.itemId,
            )
            .map((purchasedOrderImportWarehouseLot) => {
              const purchasedOrderImportWarehouseLotFormat = {
                ...purchasedOrderImportWarehouseLot,
                item: {
                  ...normalizeItems[purchasedOrderImportWarehouseLot.itemId],
                  itemWarehouseSources: normalizeItems[
                    purchasedOrderImportWarehouseLot.itemId
                  ]?.itemWarehouseSources?.map((iws) => ({
                    ...iws,
                    ...sourceByIds[iws.sourceId],
                  })),
                },
                warehouse:
                  normalizeWarehouses[
                    purchasedOrderImportWarehouseLot.warehouseId
                  ],
                actualQuantity: plus(
                  purchasedOrderImportWarehouseLot.actualQuantity,
                  purchasedOrderImportWarehouseLot.returnedQuantity,
                ),
                exportableQuantity: itemStockAvailableByItemId[
                  purchasedOrderImportDetail.itemId
                ]?.find(
                  (item) =>
                    item.lotNumber ===
                    purchasedOrderImportWarehouseLot.lotNumber,
                )?.quantity,
                amount: purchasedOrderImportWarehouseLot.amount,
                price: purchasedOrderImportWarehouseLot.price,
                debitAccount:
                  purchasedOrderImportDetail.debitAccount ||
                  purchasedOrderImportWarehouseLot.debitAccount,
                creditAccount:
                  purchasedOrderImportDetail.creditAccount ||
                  purchasedOrderImportWarehouseLot.creditAccount,
              };

              return purchasedOrderImportWarehouseLotFormat;
            }),
        }),
      );

    const purchasedOrderImportDetailMap = keyBy(
      purchasedOrderImport.purchasedOrderImportDetails,
      'itemId',
    );

    const serializePurchasedOrderReceiveItem = keyBy(
      purchasedOrderImport?.purchasedOrderImportReceiveItems,
      'itemId',
    );

    purchasedOrderImport.purchasedOrderImportWarehouseLots =
      purchasedOrderImport.purchasedOrderImportWarehouseLots.map(
        (purchasedOrderImportWarehouseLot) => {
          const storedQuantity = min([
            serializePurchasedOrderReceiveItem[
              purchasedOrderImportWarehouseLot.itemId
            ]?.storedQuantity || 0,
            purchasedOrderImportWarehouseLot.quantity,
          ]);
          const purchasedOrderImportWarehouseLotFormat = {
            ...purchasedOrderImportWarehouseLot,
            price:
              +purchasedOrderImportWarehouseLot?.price > 0
                ? purchasedOrderImportWarehouseLot.price
                : purchasedOrderImportDetailMap[
                    purchasedOrderImportWarehouseLot.itemId
                  ].price,
            amount:
              +purchasedOrderImportWarehouseLot?.amount > 0
                ? purchasedOrderImportWarehouseLot.amount
                : purchasedOrderImportDetailMap[
                    purchasedOrderImportWarehouseLot.itemId
                  ].amount,
            storedQuantity: storedQuantity,
            item: normalizeItems[purchasedOrderImportWarehouseLot.itemId],
            warehouse:
              normalizeWarehouses[purchasedOrderImportWarehouseLot.warehouseId],
            actualQuantity: plus(
              purchasedOrderImportWarehouseLot.actualQuantity,
              purchasedOrderImportWarehouseLot.returnedQuantity,
            ),
            exportableQuantity: !isEmpty(serializeWarehouseExportProposal)
              ? serializeWarehouseExportProposal[
                  purchasedOrderImportWarehouseLot.itemId
                ]?.exportableQuantity || 0
              : itemStockAvailableByItemId[
                  purchasedOrderImportWarehouseLot.itemId
                ]?.reduce((prev, cur) => prev + Number(cur.quantity), 0),
            requestedQuantityWarehouseExportProposal:
              serializeWarehouseExportProposal[
                purchasedOrderImportWarehouseLot.itemId
              ]?.requestedQuantity
                ? serializeWarehouseExportProposal[
                    purchasedOrderImportWarehouseLot.itemId
                  ].requestedQuantity
                : 0,
          };
          if (
            has(
              serializePurchasedOrderReceiveItem,
              purchasedOrderImportWarehouseLot.itemId,
            )
          ) {
            serializePurchasedOrderReceiveItem[
              purchasedOrderImportWarehouseLot.itemId
            ].storedQuantity = minus(
              serializePurchasedOrderReceiveItem[
                purchasedOrderImportWarehouseLot.itemId
              ].storedQuantity,
              storedQuantity,
            );
          }

          return purchasedOrderImportWarehouseLotFormat;
        },
      );

    purchasedOrderImport.purchasedOrderImportWarehouseDetails =
      purchasedOrderImport.purchasedOrderImportWarehouseDetails.map(
        (purchasedOrderImportWarehouseDetail) => ({
          ...purchasedOrderImportWarehouseDetail,
          item: normalizeItems[purchasedOrderImportWarehouseDetail.itemId],
          warehouse:
            normalizeWarehouses[
              purchasedOrderImportWarehouseDetail.warehouseId
            ],
          actualQuantity: plus(
            purchasedOrderImportWarehouseDetail.actualQuantity,
            purchasedOrderImportWarehouseDetail.returnedQuantity,
          ),
        }),
      );

    const poImportWarehouseLotsByFirstWarehouseId =
      purchasedOrderImport.purchasedOrderImportWarehouseLots.filter(
        (item) => item.warehouseId === Number(purchasedOrderImport.warehouseId),
      );
    const poImportWarehouseDetailsByFirstWarehouseId =
      purchasedOrderImport.purchasedOrderImportWarehouseDetails.filter(
        (item) => item.warehouseId === Number(purchasedOrderImport.warehouseId),
      );
    const purchasedOrderImportDetails =
      purchasedOrderImport.purchasedOrderImportDetails.filter((item) =>
        poImportWarehouseDetailsByFirstWarehouseId.some(
          (warehoueDetail) => warehoueDetail.itemId === item.itemId,
        ),
      );
    const dataReturn = plainToInstance(
      PurchasedOrderImportResponseDto,
      {
        ...purchasedOrderImport,
        departmentReceipt,
        purchasedOrderImportWarehouseLots: orderBy(
          poImportWarehouseLotsByFirstWarehouseId,
          ['itemId', 'lotNumber', 'quantity'],
          ['asc', 'asc', 'asc'],
        ),
        purchasedOrderImportDetails: purchasedOrderImportDetails,
        purchasedOrderImportWarehouseDetails:
          poImportWarehouseDetailsByFirstWarehouseId,
        warehouse: normalizeWarehouses[purchasedOrderImport.warehouseId],
        businessType: businessType,
        attachment: {
          ...attachmentDetail,
          id: attachmentDetail?._id,
        },
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
  /**
   * Get genetal purchased order detail by warehouseId
   * @param payload
   * @returns
   */
  async getDetailByWarehouseId(
    payload: GetOrderDetailByWarehouseRequestDto,
  ): Promise<any> {
    const { id, warehouseId, userId, withCompletedOrder } = payload;

    const isWarehouseOfUser = await this.validateWarehouseIsOfUser(
      userId,
      warehouseId,
    );

    if (!isWarehouseOfUser) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const purchasedOrderImport =
      await this.purchasedOrderImportRepository.getDetailByWarehouseId(
        id,
        [warehouseId],
        withCompletedOrder,
      );

    if (!purchasedOrderImport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const itemIds = map(purchasedOrderImport.items, 'id');
    const userIds = uniq([
      purchasedOrderImport.createdByUserId,
      purchasedOrderImport.confirmerId,
      purchasedOrderImport.approverId,
    ]).filter((id) => !isNull(id));

    const { items, warehouses, users } = await super.getOrderExtraInfo(
      itemIds,
      [warehouseId],
      userIds,
    );
    const normalizeItems = {};
    const normalizeUsers = {};
    const normalizeWarehouses = {};

    items.forEach((item) => {
      normalizeItems[item.itemId] = item;
    });
    warehouses.forEach((warehouse) => {
      normalizeWarehouses[warehouse.id] = warehouse;
    });
    users.forEach((user) => {
      normalizeUsers[user.id] = user;
    });
    purchasedOrderImport.createdByUser =
      normalizeUsers[purchasedOrderImport.createdByUserId];
    purchasedOrderImport.approver =
      normalizeUsers[purchasedOrderImport.approverId];
    purchasedOrderImport.confirmer =
      normalizeUsers[purchasedOrderImport.confirmerId];
    purchasedOrderImport.warehouse = normalizeWarehouses[warehouseId];
    // TO DO
    purchasedOrderImport.items = purchasedOrderImport.items.map((item) => {
      const poiri = purchasedOrderImport.purchasedOrderImportReceiveItem.find(
        (it) => it.itemId === item.id,
      );
      let remainingQuantity = item.receivedQuantity - item.actualQuantity || 0;
      return {
        ...normalizeItems[item.id],
        ...item,
        purchasedOrderImportReceiveItemQuantity: poiri?.quantity ?? null,
        lots: item.lots.map((lot) => {
          const remainingPlanQuantity = minus(
            lot.planQuantity,
            lot.actualQuantity,
          );
          const receivedQuantity =
            remainingQuantity > 0
              ? remainingQuantity > remainingPlanQuantity
                ? remainingPlanQuantity
                : remainingQuantity
              : 0;
          remainingQuantity = minus(remainingQuantity, receivedQuantity);
          return {
            ...lot,
            receivedQuantity,
          };
        }),
      };
    });
    const purchasedOrderImportWarehouseLots = flatMap(
      map(purchasedOrderImport.items, 'lots'),
    );
    purchasedOrderImport.type = OrderTypeEnum.Import;
    const dataReturn = plainToInstance(
      PurchasedOrderImportWarehouseDetailResponseDto,
      {
        ...purchasedOrderImport,
        orderType: purchasedOrderImport.poType,
        purchasedOrderImportWarehouseLots:
          purchasedOrderImportWarehouseLots.map((item) => ({
            ...normalizeItems[item.itemId],
            ...item,
          })),
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Get List
   * @param payload
   * @returns
   */
  async getList(payload: GetPurchasedOrderImportListRequest): Promise<any> {
    const { page } = payload;
    if (!payload.filter) payload.filter = [];

    const userWarehouses = await this.userService.getUserWarehousesById(
      payload.userId,
    );
    if (isEmpty(userWarehouses)) {
      return new ResponseBuilder<PagingResponse>({
        items: [],
        meta: { total: 0, page: 1 },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const filterWarehouseId = payload.filter.find(
      (filter) => filter.column === 'warehouseId',
    );

    let warehouseIds = map(
      userWarehouses,
      (userWarehouse) => +userWarehouse.id,
    );
    if (filterWarehouseId) {
      warehouseIds = getInnerJoinElements(
        warehouseIds,
        filterWarehouseId.text.split(',').map((warehouseId) => +warehouseId),
      );
      if (isEmpty(warehouseIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
      }
    }

    payload.filter.push({
      column: 'warehouseId',
      text: warehouseIds.join(','),
    });

    const [data, count] =
      await this.purchasedOrderImportRepository.getListPoImport(payload);
    const dataSortWarehouseId = data.map((i) => ({
      ...i,
    }));

    const importedWarehouseIds = uniq(map(data, 'warehouseId'));
    const businessTypeIds = uniq(map(data, 'businessTypeId'));
    const departmentReceiptIds = uniq(map(data, 'departmentReceiptId'));
    const createdByUserIds = uniq(map(data, 'createdByUserId'));
    const [
      importedWarehouses,
      businessTypeByIds,
      departmentReceiptByIds,
      users,
    ] = await Promise.all([
      this.warehouseService.getWarehouses(importedWarehouseIds),
      this.warehouseService.getBusinessTypeByIds(businessTypeIds, true),
      this.userService.getDepartmentReceiptByIds(departmentReceiptIds, true),
      this.userService.getUsers(createdByUserIds, true),
    ]);
    const warehouseByIds = keyBy(importedWarehouses, 'id');

    const dataReturn = plainToInstance(
      PurchasedOrderImportListResponse,
      dataSortWarehouseId.map((poImport) => ({
        ...poImport,
        warehouse: warehouseByIds[poImport.warehouseId],
        businessType: businessTypeByIds[poImport.businessTypeId],
        departmentReceipt: departmentReceiptByIds[poImport.departmentReceiptId],
        createdByUser: users[poImport.createdByUserId],
      })),
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  async getListOrderWarehouse(request: GetOrderWarehouseRequest): Promise<any> {
    const { user, keyword } = request;
    const userWarehouses = await this.userService.getUserWarehousesById(
      user.id,
    );
    let warehouseIds = [];
    if (!isEmpty(keyword)) {
      warehouseIds = filter(
        userWarehouses,
        (warehouse) =>
          searchLikeString(warehouse.name, keyword) ||
          searchLikeString(warehouse.code, keyword),
      ).map((w) => w.id);
    } else {
      warehouseIds = userWarehouses.map((e) => e.id);
    }

    const data =
      await this.purchasedOrderImportWarehouseDetailRepository.getListOrderWarehouse(
        request,
        warehouseIds,
      );

    const requestWarehouseExistFloor =
      new GetListWarehouseExitsFloorRequestDto();
    requestWarehouseExistFloor.isSpace = '1';
    requestWarehouseExistFloor.sort = request.sort;
    requestWarehouseExistFloor.limit = request.limit;
    requestWarehouseExistFloor.page = request.page;
    requestWarehouseExistFloor.filter = [
      {
        column: 'ids',
        text: map(data, 'warehouseId').join(','),
      },
    ];
    const warehousesExistFloor =
      await this.warehouseService.getListWarehouseExistFloor(
        requestWarehouseExistFloor,
      );

    const normalizeWarehouses = keyBy(userWarehouses, 'id');

    //get_factory_by_ids
    let dataMaping = data.map((e) => ({
      warehouseId: e.warehouseId,
      warehouseName: normalizeWarehouses[e.warehouseId].name,
      warehouseCode: normalizeWarehouses[e.warehouseId].code,
      items: e.items,
      factoryId: normalizeWarehouses[e.warehouseId].factoryId,
    }));
    const factoriesNameData = await this.userService.getFactories(
      dataMaping.map((e) => e.factoryId),
    );

    dataMaping = dataMaping.map((e) => {
      const factory = factoriesNameData.find(
        (e2) => e2.factoryId === e.factoryId,
      );
      return {
        ...e,
        factoryName: factory?.factoryName,
      };
    });

    const dataReturn = plainToInstance(OrderWarehouseResponse, dataMaping, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: warehousesExistFloor.meta,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  /**
   * Update Confirmed Quantity
   */
  async updateOrderDetailConfirmQuantity(
    data: UpdateOrderDetailConfirmQuantityRequestDto,
  ): Promise<any> {
    const { orderId, orderDetails, warehouseOrderDetails } = data;
    let message;
    let code = ResponseCodeEnum.SUCCESS;
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const updatePurchasedOrderImportDetailEntities =
        await this.purchasedOrderImportDetailRepository.getUpdateOrderDetailConfirmQuantityByIds(
          orderId,
          orderDetails,
        );

      const updatePurchasedOrderImportWarehouseDetailEntities =
        await this.purchasedOrderImportWarehouseDetailRepository.getUpdateOrderWarehouseDetailConfirmQuantityByIds(
          orderId,
          warehouseOrderDetails,
        );

      await queryRunner.manager.save(updatePurchasedOrderImportDetailEntities);
      await queryRunner.manager.save(
        updatePurchasedOrderImportWarehouseDetailEntities,
      );
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      message = error;
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      await queryRunner.rollbackTransaction();
    } finally {
      await queryRunner.release();
      this.eventEmitter.emit(
        'order.updateConfirmedQuantity',
        new OrderUpdateConfirmedQuantityEvent({
          id: orderId,
          orderType: SaleOrderTypeEnum.PO,
        }),
      );
    }
    return new ResponseBuilder()
      .withCode(code)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  /**
   *
   * @param data
   * @returns
   */
  async updateOrderDetailActualQuantity(
    data: UpdateOrderDetailActualQuantityRequestDto,
  ): Promise<any> {
    const { orderId, orderDetails, warehouseOrderDetails, itemLots } = data;

    let message;
    let code = ResponseCodeEnum.SUCCESS;

    const purchasedOrderImportWarehouseLotEntities =
      await this.purchasedOrderImportWarehouseLotRepository.getDetailLotsByItems(
        map(itemLots, 'itemId'),
        map(itemLots, 'warehouseId'),
        orderId,
      );

    purchasedOrderImportWarehouseLotEntities.forEach(
      (
        purchasedOrderImportWarehouseLotEntity: PurchasedOrderImportWarehouseLotEntity,
      ) => {
        const itemId = purchasedOrderImportWarehouseLotEntity.itemId;
        const itemLot = filter(
          itemLots,
          (iL) =>
            iL.itemId === itemId &&
            (iL.lotNumber ===
              purchasedOrderImportWarehouseLotEntity.lotNumber ||
              (isEmpty(iL.lotNumber) &&
                isEmpty(purchasedOrderImportWarehouseLotEntity.lotNumber))) &&
            iL.warehouseId ===
              purchasedOrderImportWarehouseLotEntity.warehouseId,
        );
        if (itemLot) {
          const quantityItemLot = itemLot.reduce(
            (curr, prev) => plus(curr, prev.quantity),
            0,
          );
          purchasedOrderImportWarehouseLotEntity.actualQuantity = plus(
            purchasedOrderImportWarehouseLotEntity.actualQuantity,
            quantityItemLot,
          );
        }
      },
    );
    const purchasedOrderImportWarehouseLotMap = keyBy(
      purchasedOrderImportWarehouseLotEntities,
      (item) => `${item.itemId}-${item.lotNumber || ''}`,
    );

    const purchasedOrderImportReceivedItems =
      await this.purchasedOrderImportReceiveItemRepository.getListByPurchasedOrderImportId(
        orderId,
        itemLots,
      );
    purchasedOrderImportReceivedItems.map(
      (purchasedOrderImportReceivedItem) => {
        purchasedOrderImportReceivedItem.actualQuantity =
          purchasedOrderImportWarehouseLotMap[
            `${purchasedOrderImportReceivedItem.itemId}-${
              purchasedOrderImportReceivedItem.lotNumber || ''
            }`
          ]?.actualQuantity || 0;
        return purchasedOrderImportReceivedItem;
      },
    );

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const updatePurchasedOrderImportDetailEntities =
        await this.purchasedOrderImportDetailRepository.getUpdateOrderDetailActualQuantityByIds(
          orderId,
          orderDetails,
        );

      const updatePurchasedOrderImportWarehouseDetailEntities =
        await this.purchasedOrderImportWarehouseDetailRepository.getUpdateOrderWarehouseDetailActualQuantityByIds(
          orderId,
          warehouseOrderDetails,
        );

      await queryRunner.manager.save(updatePurchasedOrderImportDetailEntities);
      await queryRunner.manager.save(purchasedOrderImportWarehouseLotEntities);
      await queryRunner.manager.save(purchasedOrderImportReceivedItems);
      await queryRunner.manager.save(
        updatePurchasedOrderImportWarehouseDetailEntities,
      );

      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      message = error;
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      await queryRunner.rollbackTransaction();
    }
    await queryRunner.release();
    this.eventEmitter.emit(
      'order.updateActualQuantity',
      new OrderUpdateActualQuantityEvent({
        id: orderId,
        orderType: SaleOrderTypeEnum.PO,
      }),
      itemLots,
    );
    this.eventEmitter.emit(EventSyncPoImportEnum.Update, orderId);
    return new ResponseBuilder()
      .withCode(code)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  async updateSyncStatus(data: GetOrderDetailRequestDto): Promise<any> {
    const { id } = data;
    const purchasedOrderImport =
      await this.purchasedOrderImportRepository.findOneById(id);

    if (!purchasedOrderImport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (purchasedOrderImport.syncStatus === StatusSyncOrderToEbsEnum.DEACTIVE) {
      purchasedOrderImport.syncStatus = StatusSyncOrderToEbsEnum.OUT_OF_SYNC;
      await this.purchasedOrderImportRepository.create(purchasedOrderImport);
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Update
   * @param payload
   * @returns
   */
  public async updatePoImport(
    payload: UpdatePurchasedOrderImportDto,
  ): Promise<any> {
    const { code, id, businessTypeId, attributes, sourceId } = payload;

    const purchasedOrderImport =
      await this.purchasedOrderImportRepository.findOneById(id);
    if (!purchasedOrderImport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CAN_UPDATE_POI_STATUS.includes(purchasedOrderImport.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }
    const isExistPurchasedOrderImport =
      await this.purchasedOrderImportRepository.checkPurchasedOrderImportCodeExist(
        code,
        id,
      );
    if (isExistPurchasedOrderImport.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PURCHASE_ORDER_IS_EXITS'))
        .build();
    }
    const businessType = await this.warehouseService.getBusinessTypeDetail(
      businessTypeId,
    );
    if (isEmpty(businessType)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.BUSINESS_TYPE_NOT_FOUND_ATTRIBUTE'),
        )
        .build();
    }

    const { bussinessTypeAttributes } = businessType;
    let businessTypeAttrsRequest = [];
    if (!isEmpty(bussinessTypeAttributes)) {
      const attributeByIds = attributes ? keyBy(attributes, 'id') : {};
      businessTypeAttrsRequest = bussinessTypeAttributes?.map((attr) => ({
        ...attr,
        value: attributeByIds[attr.id]?.value,
        attrId: Number(attr.id),
        businessTypeId: businessTypeId,
      }));
      if (isEmpty(businessTypeAttrsRequest)) {
        businessTypeAttrsRequest = uniqBy(bussinessTypeAttributes, 'id')?.map(
          (attr) => ({
            ...attr,
            value: attributeByIds[attr.id]?.value,
            attrId: Number(attr.id),
            businessTypeId: businessTypeId,
          }),
        );
      }
      const validationResult =
        await this.warehouseService.validateBusinessTypeAttrs(
          businessTypeAttrsRequest,
          sourceId,
        );

      if (validationResult.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validationResult;
      }
    }

    if (purchasedOrderImport.status === OrderStatusEnum.Reject) {
      purchasedOrderImport.status = OrderStatusEnum.Pending;
    }
    const purchasedOrderImportEntity =
      this.purchasedOrderImportRepository.updateEntity(
        purchasedOrderImport,
        payload,
      );
    return await this.save(
      purchasedOrderImportEntity,
      payload,
      purchasedOrderImport.purchasedOrderId,
      SaleOrderTypeEnum.PO,
      businessTypeAttrsRequest,
    );
  }

  public async updateHeader(
    payload: UpdateHeaderPurchasedOrderImportBodyDto,
  ): Promise<any> {
    const { id, businessTypeId, attributes, sourceId, reasonId } = payload;

    const purchasedOrderImport =
      await this.purchasedOrderImportRepository.findOneWithRelations({
        where: { id },
        relations: [
          'purchasedOrderImportDetails',
          'purchasedOrderImportWarehouseLots',
        ],
      });
    if (!purchasedOrderImport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_CAN_UPDATE_HEADER_POI.includes(purchasedOrderImport.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.PURCHASED_ORDER_EXPORT_STATUS_IS_INVALID',
          ),
        )
        .build();
    }

    if (
      !SYNC_STATUS_CAN_UPDATE_HEADER_POI.includes(
        purchasedOrderImport.syncStatus,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.PURCHASED_ORDER_EXPORT_STATUS_IS_INVALID',
          ),
        )
        .build();
    }

    const businessType = await this.warehouseService.getBusinessTypeDetail(
      businessTypeId,
      purchasedOrderImport.id,
      SaleOrderTypeEnum.PO,
    );
    if (isEmpty(businessType)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.BUSINESS_TYPE_NOT_FOUND_ATTRIBUTE'),
        )
        .build();
    }

    const { bussinessTypeAttributes } = businessType;
    let businessTypeAttrsRequest = [];
    if (!isEmpty(bussinessTypeAttributes)) {
      const attributeByIds = attributes ? keyBy(attributes, 'id') : {};
      businessTypeAttrsRequest = bussinessTypeAttributes?.map((attr) => ({
        ...attr,
        value: attributeByIds[attr.id]?.value,
        attrId: Number(attr.id),
        businessTypeId: businessTypeId,
      }));
      if (isEmpty(businessTypeAttrsRequest)) {
        businessTypeAttrsRequest = uniqBy(bussinessTypeAttributes, 'id')?.map(
          (attr) => ({
            ...attr,
            value: attributeByIds[attr.id]?.value,
            attrId: Number(attr.id),
            businessTypeId: businessTypeId,
          }),
        );
      }
      const validationResult =
        await this.warehouseService.validateBusinessTypeAttrs(
          businessTypeAttrsRequest,
          sourceId,
        );

      if (validationResult.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validationResult;
      }
    }

    let message: string;
    const responeCode = ResponseCodeEnum.SUCCESS;

    const purchasedOrder = await this.purchasedOrderRepository.findOneById(
      purchasedOrderImport.purchasedOrderId,
    );
    if (!purchasedOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.PURCHASE_ORDER_NOT_FOUND'),
        )
        .build();
    }

    // validate source

    const source = await this.sourceRepository.findOneByCondition({
      id: payload.sourceId,
      warehouseId: purchasedOrderImport.warehouseId,
    });

    if (isEmpty(source)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.SOURCE_NOT_FOUND'))
        .build();
    }

    if (
      purchasedOrderImport.ebsId &&
      payload.sourceId !== purchasedOrderImport.sourceId
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CANNOT_CHANGE_SOURCE'))
        .build();
    }

    const reason = await this.reasonRepository.findOneById(reasonId);
    if (isEmpty(reason)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REASON_NOT_FOUND'))
        .build();
    }

    if (payload?.ebsId && payload?.ebsId?.split('.')[2] !== reason.code) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.REASON_INVALID'))
        .build();
    }

    const warehouse = await this.warehouseService.getDetailById(
      payload.warehouseId,
    );
    if (isEmpty(warehouse)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
        .build();
    }

    if (payload?.ebsId && payload?.ebsId?.split('.')[1] !== warehouse.code) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WAREHOUSE_INVALID'))
        .build();
    }

    if (purchasedOrderImport.businessTypeId !== payload.businessTypeId) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.CANNOT_CHANGE_BUSINESS_TYPE'),
        )
        .build();
    }

    // validate receipt
    const attrReceipt = bussinessTypeAttributes.find(
      (attr) => attr?.code === BusinessTypeAttributeDefaultEnum.RECEIPT_ID,
    );

    if (isEmpty(attrReceipt) && purchasedOrderImport.receiptNumber) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CANNOT_CHANGE_RECEIPT'))
        .build();
    }

    if (attrReceipt?.value) {
      const newReceipt = await this.receiptRepository.findOneById(
        Number(attrReceipt?.value),
      );
      if (
        isEmpty(newReceipt) ||
        (newReceipt && newReceipt.code !== purchasedOrderImport.receiptNumber)
      ) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.CANNOT_CHANGE_RECEIPT'))
          .build();
      }
    }

    if (!purchasedOrderImport.ebsId) {
      payload.items.forEach((item) => {
        item.creditAccount = source.accountant;
      });
    } else {
      payload.items.forEach((item) => {
        item.creditAccount = [
          source.companyCode,
          source.branchCode,
          source.costCenterCode,
          item.creditAccount,
          source.produceTypeCode,
          source.productCode,
          source.factorialCode,
          source.internalDepartmentCode,
          source.departmentBackupCode,
          source.EVNBackupCode,
        ].join(CODE_DELIMITER);
      });
    }

    const itemMap = keyBy(
      payload.items,
      (item) => `${item.itemId}_${item.lotNumber || ''}`,
    );

    purchasedOrderImport.purchasedOrderImportWarehouseLots.forEach((item) => {
      item.creditAccount =
        itemMap[`${item.itemId}_${item.lotNumber || ''}`]?.creditAccount;
    });

    // update header poi
    if (!purchasedOrderImport.oldEbsId && payload.ebsId) {
      purchasedOrderImport.oldEbsId = purchasedOrderImport.ebsId;
    }
    purchasedOrderImport.ebsId = payload.ebsId;
    purchasedOrderImport.deliver = payload.deliver;
    purchasedOrderImport.departmentReceiptId = payload.departmentReceiptId;
    purchasedOrderImport.reasonId = payload.reasonId;
    purchasedOrderImport.sourceId = payload.sourceId;
    purchasedOrderImport.explanation = payload.explanation;

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(purchasedOrderImport);

      // save bussiness type attribute values
      if (!isEmpty(payload.attributes)) {
        const saveBusinessTypeAttrValues =
          await this.warehouseService.saveBusinessTypeAttrs(
            payload.attributes?.map((attr) => {
              const businessTypeAttr = businessTypeAttrsRequest.find(
                (data) => Number(attr.id) === data.id,
              );
              return {
                orderId: purchasedOrderImport.id,
                orderType: SaleOrderTypeEnum.PO,
                businessTypeId: businessTypeAttr.bussinessTypeId,
                businessTypeAttributeId: attr.id,
                values: attr.value,
                type: businessTypeAttr.type,
              };
            }),
          );
        if (
          saveBusinessTypeAttrValues.statusCode !== ResponseCodeEnum.SUCCESS
        ) {
          throw new Error(saveBusinessTypeAttrValues.message);
        }
      }

      const file = await this.fileService.handleSaveFiles(
        purchasedOrderImport.id || null,
        FileResource.POI,
        payload.files ? payload.files.filter((file) => !isEmpty(file)) : null,
        payload.attachment,
      );
      if (file.statusCode !== ResponseCodeEnum.SUCCESS) {
        return new ResponseBuilder()
          .withCode(file.statusCode)
          .withMessage(file.message)
          .build();
      }
      await queryRunner.commitTransaction();

      this.eventEmitter.emit(
        EventSyncPoImportEnum.Update,
        purchasedOrderImport.id,
      );

      // const resEbs = await this.syncOrderToEbs(
      //   purchasedOrderImport.id,
      //   payload.user.id,
      //   true,
      // );

      // if (resEbs.statusCode !== ResponseCodeEnum.SUCCESS) {
      //   return new ResponseBuilder({
      //     ebsError: true,
      //   })
      //     .withCode(ResponseCodeEnum.BAD_REQUEST)
      //     .withMessage(await this.i18n.translate('error.ERROR_SYNC_EBS'))
      //     .build();
      // }
      return new ResponseBuilder()
        .withCode(responeCode)
        .withMessage(
          responeCode === ResponseCodeEnum.SUCCESS
            ? await this.i18n.translate('error.SUCCESS')
            : message,
        )
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  public async updateHeaderEbsIn(
    payload: UpdateHeaderEbsInPOIRequest,
  ): Promise<any> {
    const purchasedOrderImport =
      await this.purchasedOrderImportRepository.findOneWithRelations({
        where: {
          id: payload.id,
        },
        relations: ['purchasedOrderImportWarehouseLots'],
      });

    if (!purchasedOrderImport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (payload.status !== ResponseCodeEnum.SUCCESS) {
      purchasedOrderImport.syncStatus =
        StatusSyncOrderToEbsEnum.SYNC_WSO2_ERROR;
    } else {
      const creditMap = keyBy(payload.item, 'order');

      purchasedOrderImport.syncStatus = StatusSyncOrderToEbsEnum.COMPLETED;
      purchasedOrderImport.ebsId = payload.ebsId;
      purchasedOrderImport.oldEbsId = null;
      orderBy(
        purchasedOrderImport.purchasedOrderImportWarehouseLots,
        ['itemId', 'lotNumber', 'quantity'],
        ['asc', 'asc', 'asc'],
      ).forEach((item, index) => {
        if (has(creditMap, plus(index, 1))) {
          item.creditAccount = creditMap[plus(index, 1)]?.credit;
        }
      });
    }

    await this.purchasedOrderImportRepository.create(purchasedOrderImport);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private getBaseConditionForPoImportDetail(businessTypeAttrs) {
    const warehouseExportProposalAttr = businessTypeAttrs.find(
      (attr) =>
        attr.code ===
        BusinessTypeAttributeDefaultEnum.WAREHOUSE_EXPORT_PROPOSAL_ID,
    );
    const receiptIdAttr = businessTypeAttrs.find(
      (attr) => attr.code === BusinessTypeAttributeDefaultEnum.RECEIPT_ID,
    );
    const soExportIdAttr = businessTypeAttrs.find(
      (attr) => attr.code === BusinessTypeAttributeDefaultEnum.SO_EXPORT_ID,
    );

    if (warehouseExportProposalAttr) {
      if (receiptIdAttr?.required || receiptIdAttr?.value) {
        return BusinessTypeAttributeDefaultEnum.RECEIPT_ID;
      } else if (warehouseExportProposalAttr?.value) {
        return BusinessTypeAttributeDefaultEnum.WAREHOUSE_EXPORT_PROPOSAL_ID;
      }
    } else if (soExportIdAttr?.value || soExportIdAttr?.required) {
      return BusinessTypeAttributeDefaultEnum.SO_EXPORT_ID;
    }
  }

  /**
   * Save
   * @param payload
   * @returns
   */
  private async save(
    purchasedOrderImportEntity: PurchasedOrderImportEntity,
    payload:
      | CreatePurchasedOrderImportDto
      | CreatePurchasedOrderImportAutoCompleteDto,
    purchasedOrderId?: number,
    type?: number,
    businessTypeAttrs?: any,
    autoComplete?: boolean,
  ): Promise<any> {
    const { items } = payload;
    const isUpdate = purchasedOrderImportEntity.id;
    let message: string;
    const responeCode = ResponseCodeEnum.SUCCESS;
    let purchasedOrderImport;

    const attrReceipt = businessTypeAttrs.find(
      (attr) => attr?.code === BusinessTypeAttributeDefaultEnum.RECEIPT_ID,
    );
    purchasedOrderImportEntity.receiptNumber = null;
    let newReceipt = null;
    if (!isEmpty(attrReceipt) && Number(attrReceipt?.value)) {
      newReceipt = await this.receiptRepository.findOneById(
        Number(attrReceipt?.value),
      );
      if (isEmpty(newReceipt)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.RECEIPT_NOT_FOUND'))
          .build();
      }
      if (newReceipt.status === RECEIPT_STATUS.USED) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.RECEIPT_USED'))
          .build();
      }
      if (newReceipt.status === RECEIPT_STATUS.CANCELED) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.RECEIPT_CANCELED'))
          .build();
      }

      purchasedOrderImportEntity.receiptNumber = newReceipt.code;
    }
    if (purchasedOrderImportEntity?.receiptNumber) {
      const condition = purchasedOrderImportEntity.id
        ? {
            receiptNumber: purchasedOrderImportEntity.receiptNumber,
            status: Not(In(PO_IMPORT_STATUS_NOT_USED_RECEIPT)),
            id: Not(purchasedOrderImportEntity.id),
          }
        : {
            receiptNumber: purchasedOrderImportEntity.receiptNumber,
            status: Not(In(PO_IMPORT_STATUS_NOT_USED_RECEIPT)),
          };

      const poImportUsedReceipt =
        await this.purchasedOrderImportRepository.findOneByCondition(condition);
      if (!isEmpty(poImportUsedReceipt)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.RECEIPT_USED'))
          .build();
      }
    }
    const purchasedOrder = await this.purchasedOrderRepository.findOneById(
      purchasedOrderId,
    );
    if (!purchasedOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.PURCHASE_ORDER_NOT_FOUND'),
        )
        .build();
    }

    /** Validate items
     * Step 1: Validate items existed in master data
     * Step 2: Validate items via receipt detail or warehouse export proposal detail or so export (depend on business type)
     */
    const baseCondition =
      this.getBaseConditionForPoImportDetail(businessTypeAttrs);
    const attrByBaseCondition = businessTypeAttrs?.find(
      (attr) => attr.code === baseCondition,
    );
    const baseId = payload.attributes?.find(
      (attr) => Number(attr.id) === attrByBaseCondition?.id,
    )?.value;
    if (!payload.isImport) {
      let validateItemsResult;
      switch (baseCondition) {
        case BusinessTypeAttributeDefaultEnum.WAREHOUSE_EXPORT_PROPOSAL_ID:
          validateItemsResult =
            await this.validatePoiDetailWithWarehouseExportProposalDetail.validateItems(
              items,
              baseId,
            );
          break;
        case BusinessTypeAttributeDefaultEnum.SO_EXPORT_ID:
          validateItemsResult =
            await this.validatePoiDetailWithSoeDetail.validateItems(
              items,
              baseId,
            );
          break;
        case BusinessTypeAttributeDefaultEnum.RECEIPT_ID:
          validateItemsResult =
            await this.validatePoiDetailWithReceiptDetail.validateItems(
              items,
              baseId,
            );
          break;
        default:
          validateItemsResult =
            await this.validatePoiDetailWithMasterDataItem.validateItems(items);
          break;
      }

      if (!validateItemsResult.success) {
        return new ResponseBuilder()
          .withData(validateItemsResult.data)
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate(validateItemsResult.message))
          .build();
      }
    }

    const warehouseIds = compact(uniq(map(items, 'warehouseId')));
    const warehouses = await this.warehouseService.getWarehouses(warehouseIds);
    if (warehouseIds.length !== warehouses.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
        .build();
    }
    const warehouse = warehouses[0];

    // validate source
    if (payload.sourceId) {
      const source = await this.sourceRepository.findOneByCondition({
        id: payload.sourceId,
        warehouseId: payload.warehouseId,
      });

      if (isEmpty(source)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.SOURCE_NOT_FOUND'))
          .build();
      }
    }

    // validate lotNumber, warehouseId, qcCriteriaId, packageId, palletId

    // let checkUniqWarehouse = false;
    // const arrLotNumberOfItem = [];
    // for (let i = 0; i < items.length; i++) {
    //   const item = items[i];
    //   // validate lotNumber
    //   const lotNumberRequest = item.lotNumber;

    //   const key = item.id + `_` + item.warehouseId;

    //   if (arrLotNumberOfItem[key]) {
    //     arrLotNumberOfItem[key] = arrLotNumberOfItem[key].concat([
    //       lotNumberRequest,
    //     ]);
    //   } else {
    //     arrLotNumberOfItem[key] = [lotNumberRequest];
    //   }

    //   if (
    //     arrLotNumberOfItem[key].length !== uniq(arrLotNumberOfItem[key]).length
    //   ) {
    //     checkUniqWarehouse = true;
    //     break;
    //   }
    // }

    // if (checkUniqWarehouse) {
    //   return new ResponseBuilder()
    //     .withCode(ResponseCodeEnum.BAD_REQUEST)
    //     .withMessage(await this.i18n.translate('error.DUPLICATE_WAREHOUSE'))
    //     .build();
    // }

    const purchasedOrderImportDetailRaws = {};
    items.forEach((item) => {
      if (purchasedOrderImportDetailRaws[item.id]) {
        purchasedOrderImportDetailRaws[item.id].quantity = plus(
          purchasedOrderImportDetailRaws[item.id].quantity,
          item.quantity,
        );
      } else {
        purchasedOrderImportDetailRaws[item.id] = {
          ...item,
          lotNumber: null,
        };
      }
    });

    const purchasedOrderImportWarehouseDetailRaws = {};
    items.forEach((item) => {
      const key = item.id + '_' + item.warehouseId;
      if (purchasedOrderImportWarehouseDetailRaws[key]) {
        purchasedOrderImportWarehouseDetailRaws[key].quantity = plus(
          purchasedOrderImportWarehouseDetailRaws[key].quantity,
          item.quantity,
        );
      } else {
        purchasedOrderImportWarehouseDetailRaws[key] = {
          itemId: item.id,
          quantity: item.quantity,
          warehouseId: item.warehouseId,
          qcCheck: item.qcCheck,
          qcCriteriaId: item.qcCriteriaId,
        };
      }
    });

    const itemMap = keyBy(
      items,
      (item) => `${item.id}_${item.lotNumber || ''}`,
    );
    const itemDetailIdRemove = [];
    const itemWarehouseDetailIdRemove = [];
    const itemLotIdRemove = [];
    let oldReceipt = null;
    if (isUpdate) {
      const purchasedOrderImport =
        await this.purchasedOrderImportRepository.findOneById(
          purchasedOrderImportEntity.id,
        );

      oldReceipt = await this.receiptRepository.findOneByCondition({
        code: purchasedOrderImport.receiptNumber,
      });

      oldReceipt.status = RECEIPT_STATUS.EMPTY;

      const poimps =
        await this.purchasedOrderImportRepository.findWithRelations({
          where: {
            id: purchasedOrderImportEntity.id,
          },
          relations: [
            'purchasedOrderImportDetails',
            'purchasedOrderImportWarehouseDetails',
            'purchasedOrderImportWarehouseLots',
          ],
        });

      const poimp = poimps[0];
      const poimpDetails = poimp.purchasedOrderImportDetails;
      const poimpWarehouseDetails = poimp.purchasedOrderImportWarehouseDetails;
      const poimpLots = poimp.purchasedOrderImportWarehouseLots;
      poimpDetails.forEach((i) => {
        if (!purchasedOrderImportDetailRaws[i.itemId])
          itemDetailIdRemove.push(i.id);
        else purchasedOrderImportDetailRaws[i.itemId].idUpdate = i.id;
      });
      poimpWarehouseDetails.forEach((i) => {
        if (
          !purchasedOrderImportWarehouseDetailRaws[
            `${i.itemId}_${i.warehouseId}`
          ]
        )
          itemWarehouseDetailIdRemove.push(i.id);
        else
          purchasedOrderImportWarehouseDetailRaws[
            `${i.itemId}_${i.warehouseId}`
          ].idUpdate = i.id;
      });
      poimpLots.forEach((i) => {
        if (!itemMap[`${i.itemId}_${i.lotNumber || ''}`])
          itemLotIdRemove.push(i.id);
        else itemMap[`${i.itemId}_${i.lotNumber || ''}`].idUpdate = i.id;
      });
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      purchasedOrderImportEntity.syncCode = (
        await this.userService.getCompanyDefault()
      )?.code;
      // save purchased order import
      if (baseCondition === BusinessTypeAttributeDefaultEnum.RECEIPT_ID) {
        const receipt = await this.receiptRepository.findOneById(baseId);
        purchasedOrderImportEntity.contractNumber = receipt?.contractNumber;
      }

      purchasedOrderImport = await queryRunner.manager.save(
        purchasedOrderImportEntity,
      );

      if (!isEmpty(oldReceipt)) {
        await queryRunner.manager.save(oldReceipt);
      }

      const itemResponse = await this.itemService.getItemWarehouseStock({
        warehouseId: purchasedOrderImport.warehouseId,
      } as any);
      // save purchased order import detail
      const purchasedOrderImportDetailEntities = values(
        purchasedOrderImportDetailRaws,
      ).map((purchasedOrderImportDetailRaw) =>
        this.purchasedOrderImportDetailRepository.createEntity({
          ...purchasedOrderImportDetailRaw,
          idUpdate: purchasedOrderImportDetailRaw.idUpdate,
          purchasedOrderImportId: purchasedOrderImport.id,
        }),
      );

      if (isUpdate) {
        if (itemLotIdRemove.length)
          await queryRunner.manager.delete(
            PurchasedOrderImportWarehouseLotEntity,
            {
              id: In(itemLotIdRemove),
            },
          );
        if (itemWarehouseDetailIdRemove.length)
          await queryRunner.manager.delete(
            PurchasedOrderImportWarehouseDetailEntity,
            {
              id: In(itemWarehouseDetailIdRemove),
            },
          );
        if (itemDetailIdRemove.length)
          await queryRunner.manager.delete(PurchasedOrderImportDetailEntity, {
            id: In(itemDetailIdRemove),
          });
      }

      const itemMapById = keyBy(items, 'id');

      const debitAccountByItem = {};

      itemResponse?.items?.forEach((itemStock) => {
        itemStock?.itemWarehouseSources?.forEach((itemWarehouse) => {
          if (
            purchasedOrderImport?.warehouseId === itemWarehouse?.warehouseId &&
            has(itemMapById, itemStock.id)
          ) {
            debitAccountByItem[itemStock.id] = itemWarehouse?.accounting;
          }
        });
      });

      purchasedOrderImport.purchasedOrderImportDetails =
        await queryRunner.manager.save(purchasedOrderImportDetailEntities);

      // save bussiness type attribute values
      if (!isEmpty(payload.attributes)) {
        const saveBusinessTypeAttrValues =
          await this.warehouseService.saveBusinessTypeAttrs(
            payload.attributes?.map((attr) => {
              const businessTypeAttr = businessTypeAttrs.find(
                (data) => Number(attr.id) === data.id,
              );
              return {
                orderId: purchasedOrderImportEntity.id,
                orderType: type,
                businessTypeId: businessTypeAttr.bussinessTypeId,
                businessTypeAttributeId: attr.id,
                values: attr.value,
                type: businessTypeAttr.type,
              };
            }),
          );
        if (
          saveBusinessTypeAttrValues.statusCode !== ResponseCodeEnum.SUCCESS
        ) {
          throw new Error(saveBusinessTypeAttrValues.message);
        }
      }

      const purchasedOrderImportDetailMap = keyBy(
        purchasedOrderImport.purchasedOrderImportDetails,
        'itemId',
      );

      // save import order warehouse detail
      const purchasedOrderImportWarehouseDetailEntities = values(
        purchasedOrderImportWarehouseDetailRaws,
      ).map((item) => {
        const key = item.itemId;

        const purchasedOrderImportDetail = purchasedOrderImportDetailMap[key];

        return this.purchasedOrderImportWarehouseDetailRepository.createEntity({
          id: item.idUpdate,
          itemId: item.itemId,
          warehouseId: item.warehouseId,
          purchasedOrderImportDetailId: purchasedOrderImportDetail.id,
          purchasedOrderImportId:
            purchasedOrderImportDetail.purchasedOrderImportId,
          quantity: item.quantity,
          qcCheck: +item.qcCheck || 0,
          qcCriteriaId: item.qcCriteriaId,
        });
      });

      purchasedOrderImport.purchasedOrderImportWarehouseDetails =
        await queryRunner.manager.save(
          purchasedOrderImportWarehouseDetailEntities,
        );

      const purchasedOrderImportWarehouseDetailsMap = [];
      purchasedOrderImport.purchasedOrderImportWarehouseDetails.forEach(
        (record) => {
          const key = record.itemId + '_' + record.warehouseId;
          purchasedOrderImportWarehouseDetailsMap[key] = record;
        },
      );

      // save import order warehouse lot
      const purchasedOrderImportWarehouseLotEntities = items.map(
        (purchasedOrderImportWarehouseLot: any) => {
          const key =
            purchasedOrderImportWarehouseLot.id +
            '_' +
            purchasedOrderImportWarehouseLot.warehouseId;
          const keyLot = `${purchasedOrderImportWarehouseLot.id}_${
            purchasedOrderImportWarehouseLot.lotNumber || ''
          }`;
          const purchasedOrderImportWarehouseDetail =
            purchasedOrderImportWarehouseDetailsMap[key];
          return this.purchasedOrderImportWarehouseLotRepository.createEntity({
            id: itemMap[keyLot].idUpdate,
            purchasedOrderImportId:
              purchasedOrderImportWarehouseDetail.purchasedOrderImportId,
            purchasedOrderImportWarehouseDetailId:
              purchasedOrderImportWarehouseDetail.id,
            itemId: purchasedOrderImportWarehouseLot.id,
            quantity: purchasedOrderImportWarehouseLot.quantity,
            lotNumber: purchasedOrderImportWarehouseLot.lotNumber
              ? purchasedOrderImportWarehouseLot.lotNumber
              : null,
            mfg: purchasedOrderImportWarehouseLot.mfg,
            packageId: purchasedOrderImportWarehouseLot.packageId,
            warehouseId: purchasedOrderImportWarehouseLot.warehouseId,
            palletId: purchasedOrderImportWarehouseLot.palletId,
            locationId: purchasedOrderImportWarehouseLot.locationId,
            isEven: purchasedOrderImportWarehouseLot.isEven,
            amount: purchasedOrderImportWarehouseLot.amount,
            price: purchasedOrderImportWarehouseLot.price,
            debitAccount:
              debitAccountByItem[purchasedOrderImportWarehouseLot.id] || '',
            creditAccount: itemMap[keyLot]?.creditAccount,
          });
        },
      );

      purchasedOrderImport.purchasedOrderImportWarehouseLots =
        await queryRunner.manager.save(
          purchasedOrderImportWarehouseLotEntities,
        );

      purchasedOrderImport.purchasedOrderImportWarehouseLots.forEach(
        (poimpwl) => {
          const id = poimpwl.id;
          const lotNumber =
            id < POIMP_LOT.SUFFIX_4
              ? `${POIMP_LOT.PREFIX}${warehouse.code}` +
                `${POIMP_LOT.SUFFIX_CUSTOM + id}`.slice(1)
              : `${POIMP_LOT.PREFIX}${warehouse.code}${id}`;

          if (
            warehouse.manageByLot === WarehouseByLotManagementEnum.LOT &&
            !autoComplete
          ) {
            poimpwl.lotNumber = lotNumber;
          }
          poimpwl.lotNumberOld = lotNumber;
        },
      );

      purchasedOrderImport.purchasedOrderImportWarehouseLots =
        await queryRunner.manager.save(
          purchasedOrderImportWarehouseLotEntities,
        );

      const file = await this.fileService.handleSaveFiles(
        purchasedOrderImportEntity.id || null,
        FileResource.POI,
        payload.files ? payload.files.filter((file) => !isEmpty(file)) : null,
        payload.attachment,
      );
      if (file.statusCode !== ResponseCodeEnum.SUCCESS) {
        return new ResponseBuilder()
          .withCode(file.statusCode)
          .withMessage(file.message)
          .build();
      }
      await queryRunner.commitTransaction();

      if (purchasedOrderImportEntity.status === OrderStatusEnum.Confirmed)
        this.eventEmitter.emit(
          EventSyncPoImportEnum.Update,
          purchasedOrderImportEntity.id,
        );
      return new ResponseBuilder(purchasedOrderImportEntity)
        .withCode(responeCode)
        .withMessage(
          responeCode === ResponseCodeEnum.SUCCESS
            ? await this.i18n.translate('error.SUCCESS')
            : message,
        )
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  private async generatePoImportCode() {
    const currentDate = Moment().utcOffset(7).format('DDMMYYYY');
    const lastPoImportInDay =
      await this.purchasedOrderImportRepository.findOneWithRelations({
        where: { code: Like(`${PO_IMPORT_CODE_PREFIX}${currentDate}%`) },
        withDeleted: true,
        order: { code: 'DESC' },
      });
    if (!isEmpty(lastPoImportInDay)) {
      const lastIncreaseId = Number(lastPoImportInDay.code.slice(-3));
      const newIncreaseId = lastIncreaseId + 1;
      return `${PO_IMPORT_CODE_PREFIX}${currentDate}${newIncreaseId
        .toString()
        .padStart(3, '0')}`;
    }
    return `${PO_IMPORT_CODE_PREFIX}${currentDate}000`;
  }

  /**
   * Create
   * @param payload
   * @returns
   */
  public async createPoImport(
    payload:
      | CreatePurchasedOrderImportDto
      | CreatePurchasedOrderImportAutoCompleteDto,
    autoComplete?: boolean,
  ): Promise<any> {
    const { businessTypeId, attributes, sourceId } = payload;
    const businessType = await this.warehouseService.getBusinessTypeDetail(
      businessTypeId,
    );
    if (isEmpty(businessType)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.BUSINESS_TYPE_NOT_FOUND_ATTRIBUTE'),
        )
        .build();
    }
    const { bussinessTypeAttributes } = businessType;
    let businessTypeAttrsRequest = [];
    if (!isEmpty(bussinessTypeAttributes)) {
      const attributeByIds = attributes ? keyBy(attributes, 'id') : {};
      businessTypeAttrsRequest = bussinessTypeAttributes?.map((attr) => ({
        ...attr,
        value: attributeByIds[attr.id]?.value,
        attrId: Number(attr.id),
        businessTypeId,
      }));
      const validationResult =
        await this.warehouseService.validateBusinessTypeAttrs(
          businessTypeAttrsRequest,
          sourceId,
        );
      if (validationResult.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validationResult;
      }
    }
    const code = await this.generatePoImportCode();
    const existedPo = await this.purchasedOrderRepository.findOneByCondition({
      code,
    });
    let createPoResult;
    if (!isEmpty(existedPo)) {
      createPoResult = existedPo;
    } else {
      const payloadCreatePo = new CreatePurchasedOrderDto();
      payloadCreatePo.code = code;
      payloadCreatePo.purchasedAt = payload.receiptDate;
      payloadCreatePo.createdByUserId = payload.userId;
      payloadCreatePo.items = payload.items.map((item) => ({
        id: item.id,
        warehouseId: item.warehouseId,
        quantity: item.quantity,
        qcCheck: item.qcCheck,
        qcCriteriaId: item.qcCriteriaId,
        price: item.price,
      }));
      const result = await this.purchasedOrderService.create(payloadCreatePo);

      if (result.statusCode !== ResponseCodeEnum.SUCCESS) {
        return new ResponseBuilder()
          .withCode(result.statusCode)
          .withData(result.data)
          .withMessage(result.message)
          .build();
      }
      createPoResult = result.data;
    }

    const isExist =
      await this.purchasedOrderImportRepository.checkPurchasedOrderImportCodeExist(
        code,
      );

    if (isExist.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PURCHASE_ORDER_IS_EXITS'))
        .build();
    }

    const purchasedOrderImportEntity =
      this.purchasedOrderImportRepository.createEntity({
        ...payload,
        purchasedOrderId: createPoResult?.id,
        code,
      });
    return await this.save(
      purchasedOrderImportEntity,
      payload,
      createPoResult?.id,
      SaleOrderTypeEnum.PO,
      businessTypeAttrsRequest,
      autoComplete,
    );
  }

  /**
   * Get data purchased order by id and warehouseId
   * @param id
   * @param warehouseId
   * @returns
   */
  public async getWarehouseDetails(
    id: number,
    warehouseId: number,
    type: number,
  ): Promise<any> {
    try {
      const data =
        await this.purchasedOrderImportRepository.getWarehouseDetails(
          id,
          warehouseId,
          type,
        );
      if (!data) {
        return new ResponseBuilder(data)
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }
      return new ResponseBuilder(data)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async confirm(payload: SetOrderStatusRequestDto): Promise<any> {
    const { id, userId } = payload;
    const purchasedOrderImport =
      await this.purchasedOrderImportRepository.getDetail(id);
    if (!purchasedOrderImport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_CONFIRM_ORDER_STATUS.includes(purchasedOrderImport.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.PURCHASE_ORDER_IMPORT_WAS_CONFIRMED',
          ),
        )
        .build();
    }
    let receipt: ReceiptEntity = null;
    if (purchasedOrderImport.receiptNumber) {
      const poImportUsedReceipt =
        await this.purchasedOrderImportRepository.findOneByCondition({
          receiptNumber: purchasedOrderImport.receiptNumber,
          status: Not(In(PO_IMPORT_STATUS_NOT_USED_RECEIPT)),
        });
      receipt = await this.receiptRepository.findOneByCondition({
        code: purchasedOrderImport.receiptNumber,
      });
      if (receipt.status === RECEIPT_STATUS.USED) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.RECEIPT_USED'))
          .build();
      }
      if (receipt.status === RECEIPT_STATUS.CANCELED) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.RECEIPT_CANCELED'))
          .build();
      }
      if (!isEmpty(poImportUsedReceipt)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.RECEIPT_USED'))
          .build();
      }
    }
    const businessType = await this.warehouseService.getBusinessTypeDetail(
      purchasedOrderImport.businessTypeId,
      id,
      SaleOrderTypeEnum.PO,
    );

    purchasedOrderImport.attributes = businessType.bussinessTypeAttributes;
    const baseCondition = this.getBaseConditionForPoImportDetail(
      purchasedOrderImport.attributes,
    );
    let attributeDetailValues: any = {};
    if (!isEmpty(purchasedOrderImport.attributes)) {
      const attributeGroup = groupBy(
        purchasedOrderImport.attributes,
        'tableName',
      );
      const payload = new GetAttributeDetailValuesRequestDto();
      const attributeKeys = Object.keys(attributeGroup).filter(
        (el) => !el.match('null'),
      );
      payload.filter = attributeKeys.map((key) => {
        return {
          tableName: key,
          id: map(attributeGroup[key], 'value').join(','),
        };
      });
      attributeDetailValues =
        await this.warehouseService?.getAttributeDetailValuesTcp(payload);
    }
    let validateItemsResult;
    switch (baseCondition) {
      case BusinessTypeAttributeDefaultEnum.SO_EXPORT_ID:
        validateItemsResult =
          await this.validatePoiDetailWithSoeDetailAfterConfirm.validateOrderDetailAfterConfirmWithBaseCondition(
            purchasedOrderImport,
            first(map(attributeDetailValues?.sale_order_exports, 'id')),
          );
        break;
      default:
        validateItemsResult = {
          success: true,
        };
        break;
    }
    if (!validateItemsResult.success) {
      return new ResponseBuilder()
        .withData(validateItemsResult.data)
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate(validateItemsResult.message))
        .build();
    }
    const purchasedOrderImportWarehouseDetails =
      await this.purchasedOrderImportWarehouseDetailRepository.findByCondition({
        purchasedOrderImportId: purchasedOrderImport.id,
      });
    const purchasedOrderImportWarehouseDetailHaveNotWarehouses =
      purchasedOrderImportWarehouseDetails.filter(
        (record) => record.warehouseId === null,
      );
    if (purchasedOrderImportWarehouseDetailHaveNotWarehouses.length > 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.PURCHASE_ORDER_IMPORT_MISSING_WAREHOUSE',
          ),
        )
        .build();
    }

    purchasedOrderImport.confirmerId = userId;
    purchasedOrderImport.status = OrderStatusEnum.Confirmed;
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(
        PurchasedOrderImportEntity,
        purchasedOrderImport,
      );
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
    this.eventEmitter.emit(
      EventSyncPoImportEnum.Update,
      purchasedOrderImport.id,
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async cancelSync(payload: SetOrderStatusRequestDto): Promise<any> {
    const { id } = payload;
    const purchasedOrderImport =
      await this.purchasedOrderImportRepository.findOneWithRelations({
        where: {
          id,
        },
        relations: ['purchasedOrderImportWarehouseLots'],
      });
    if (!purchasedOrderImport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (
      purchasedOrderImport.syncStatus !==
      StatusSyncOrderToEbsEnum.SYNC_WSO2_ERROR
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    const { ebsId, lotNumbers } = await this.generateDataCancelSync(
      purchasedOrderImport,
    );

    if (!purchasedOrderImport.ebsId)
      purchasedOrderImport.purchasedOrderImportWarehouseLots.forEach(
        (lot, index) => {
          lot.lotNumber = lotNumbers[index];
        },
      );
    purchasedOrderImport.syncStatus = StatusSyncOrderToEbsEnum.CANCEL;
    purchasedOrderImport.ebsId = purchasedOrderImport.ebsId || ebsId;

    await this.purchasedOrderImportRepository.create(purchasedOrderImport);
    this.eventEmitter.emit(
      EventSyncPoImportEnum.Update,
      purchasedOrderImport.id,
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async return(payload: SetOrderStatusRequestDto): Promise<any> {
    const { id } = payload;
    const purchasedOrderImport =
      await this.purchasedOrderImportRepository.findOneWithRelations({
        where: {
          id,
        },
        relations: ['purchasedOrderImportWarehouseLots'],
      });
    if (!purchasedOrderImport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (purchasedOrderImport.status !== OrderStatusEnum.Confirmed) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }
    purchasedOrderImport.status = OrderStatusEnum.Pending;
    await this.purchasedOrderImportRepository.create(purchasedOrderImport);
    this.eventEmitter.emit(
      EventSyncPoImportEnum.Delete,
      purchasedOrderImport.id,
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async generateDataCancelSync(
    purchasedOrderImport: PurchasedOrderImportEntity,
  ): Promise<any> {
    const warehouse = await this.warehouseService.getDetailById(
      purchasedOrderImport.warehouseId,
    );
    const reason = await this.reasonRepository.findOneById(
      purchasedOrderImport.reasonId,
    );

    const suff = `${warehouse?.code || ''}.${reason.code || ''}.0000`;
    const ebsId = `01.${suff}`;

    const lotNumbers = [];
    if (warehouse.manageByLot === WarehouseByLotManagementEnum.LOT) {
      const latestLot =
        await this.purchasedOrderImportWarehouseLotRepository.getLatestLotByWarehouseId(
          purchasedOrderImport.warehouseId,
        );

      const prefixLotNumber = `WB${warehouse?.code || ''}`;

      const orderLot =
        +latestLot?.lotNumber?.replace(prefixLotNumber, '0') || 0;
      purchasedOrderImport.purchasedOrderImportWarehouseLots.forEach(
        (_, index) => {
          lotNumbers.push(
            `${prefixLotNumber}${plus(orderLot, plus(index, 1))
              .toString()
              .padStart(4, '0')}`,
          );
        },
      );
    }

    return { ebsId, lotNumbers };
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async confirmMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const purchasedOrderImports =
      await this.purchasedOrderImportRepository.findByCondition({
        id: In(ids),
      });

    const purchasedOrderImportIds = purchasedOrderImports.map(
      (purchasedOrderImport) => purchasedOrderImport.id,
    );
    if (purchasedOrderImports.length !== ids.length) {
      ids.forEach((id) => {
        if (!purchasedOrderImportIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < purchasedOrderImports.length; i++) {
      const purchasedOrderImport = purchasedOrderImports[i];
      if (!STATUS_TO_CONFIRM_ORDER_STATUS.includes(purchasedOrderImport.status))
        failIdsList.push(purchasedOrderImport.id);
    }

    const purchasedOrderImportWarehouseDetails =
      await this.purchasedOrderImportWarehouseDetailRepository.findByCondition({
        purchasedOrderImportId: In(
          purchasedOrderImports.map((poImp) => poImp.id),
        ),
      });

    const purchasedOrderImportWarehouseDetailHaveNotWarehouses =
      purchasedOrderImportWarehouseDetails.filter(
        (record) => record.warehouseId === null,
      );

    if (purchasedOrderImportWarehouseDetailHaveNotWarehouses.length > 0) {
      purchasedOrderImportWarehouseDetailHaveNotWarehouses.forEach((record) => {
        failIdsList.push(record.purchasedOrderImportId);
      });
    }

    const validIds = purchasedOrderImports
      .filter(
        (purchasedOrderImport) =>
          !failIdsList.includes(purchasedOrderImport.id),
      )
      .map((purchasedOrderImport) => purchasedOrderImport.id);

    const validPurchasedOrderImports = purchasedOrderImports.filter(
      (purchasedOrderImport) => validIds.includes(purchasedOrderImport.id),
    );

    if (!isEmpty(validPurchasedOrderImports)) {
      validPurchasedOrderImports.forEach((purchasedOrderImport) => {
        purchasedOrderImport.status = OrderStatusEnum.Confirmed;
        purchasedOrderImport.approvedAt = new Date(Date.now());
      });
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(
          PurchasedOrderImportEntity,
          validPurchasedOrderImports,
        );
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.CONFIRM_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async reject(payload: SetOrderStatusRequestDto): Promise<any> {
    const { id, userId } = payload;

    const purchasedOrderImport =
      await this.purchasedOrderImportRepository.getDetail(id);
    if (!purchasedOrderImport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_REJECT_ORDER_STATUS.includes(purchasedOrderImport.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }
    if (purchasedOrderImport?.receiptNumber) {
      const receipt = await this.receiptRepository.findOneByCondition({
        code: purchasedOrderImport.receiptNumber,
      });
      if (VALID_STATUS_RECEIPT.includes(receipt?.status)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.RECEIPT_CANCELED'))
          .build();
      }
    }

    const result = await this.setPurchasedOrderStatus(
      purchasedOrderImport,
      OrderStatusEnum.Reject,
      userId,
    );
    return result;
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async rejectMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const purchasedOrderImports =
      await this.purchasedOrderImportRepository.findByCondition({
        id: In(ids),
      });

    const purchasedOrderImportIds = purchasedOrderImports.map(
      (purchasedOrderImport) => purchasedOrderImport.id,
    );
    if (purchasedOrderImports.length !== ids.length) {
      ids.forEach((id) => {
        if (!purchasedOrderImportIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < purchasedOrderImports.length; i++) {
      const purchasedOrderImport = purchasedOrderImports[i];
      if (!STATUS_TO_REJECT_ORDER_STATUS.includes(purchasedOrderImport.status))
        failIdsList.push(purchasedOrderImport.id);
    }

    const validIds = purchasedOrderImports
      .filter(
        (purchasedOrderImport) =>
          !failIdsList.includes(purchasedOrderImport.id),
      )
      .map((purchasedOrderImport) => purchasedOrderImport.id);

    const validPurchasedOrderImports = purchasedOrderImports.filter(
      (purchasedOrderImport) => validIds.includes(purchasedOrderImport.id),
    );

    if (!isEmpty(validPurchasedOrderImports)) {
      validPurchasedOrderImports.forEach((purchasedOrderImport) => {
        purchasedOrderImport.status = OrderStatusEnum.Reject;
        purchasedOrderImport.approvedAt = new Date(Date.now());
      });
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(
          PurchasedOrderImportEntity,
          validPurchasedOrderImports,
        );
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.REJECT_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async approve(payload: SetOrderStatusRequestDto): Promise<any> {
    const { id } = payload;

    const purchasedOrderImport =
      await this.purchasedOrderImportRepository.findOneById(id);
    if (!purchasedOrderImport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_APPROVE_ORDER_STATUS.includes(purchasedOrderImport.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    return await this.setPurchasedOrderStatus(
      purchasedOrderImport,
      OrderStatusEnum.Completed,
    );
  }

  /**
   *
   * @param purchasedOrderEntity
   * @param status
   * @returns
   */
  private async setPurchasedOrderStatus(
    purchasedOrderImportEntity: PurchasedOrderImportEntity,
    status: number,
    userId?: number,
  ): Promise<any> {
    let syncStatus = purchasedOrderImportEntity.syncStatus;
    switch (status) {
      case OrderStatusEnum.Received:
      case OrderStatusEnum.Completed:
      case OrderStatusEnum.InProgress:
        syncStatus = StatusSyncOrderToEbsEnum.OUT_OF_SYNC;
        break;

      default:
        break;
    }

    purchasedOrderImportEntity.status = status;
    purchasedOrderImportEntity.syncStatus = syncStatus;
    await this.purchasedOrderImportRepository.create(
      purchasedOrderImportEntity,
    );

    //Push notification
    const user = await this.userService.getUserById(userId);
    const notificationRequest = new PushNotificationRequestDto();
    const titleConfirm = `${
      user.username +
      (await this.i18n.translate(
        'error.PURCHASE_ORDER_IMPORT_CONFIRMED_NOTIFICATION',
      )) +
      purchasedOrderImportEntity.name
    }`;
    const titleReject = `${
      user.username +
      (await this.i18n.translate(
        'error.PURCHASE_ORDER_IMPORT_REJECT_NOTIFICATION',
      )) +
      purchasedOrderImportEntity.name
    }`;
    const titleRejectReceived = `${
      user.username +
      (await this.i18n.translate(
        'error.PURCHASE_ORDER_IMPORT_REJECT_RECEIVED_NOTIFICATION',
      )) +
      purchasedOrderImportEntity.name
    }`;
    notificationRequest.type = TypeNotificationEnum.WEB;
    notificationRequest.action = ActionNotificationEnum.WAREHOUSE_YARD;
    notificationRequest.content = purchasedOrderImportEntity.description;
    //TODO SnP waiting
    notificationRequest.templateId = '62675f887848315c26a23033';
    notificationRequest.executionDate = new Date().toISOString();
    notificationRequest.userIds = [purchasedOrderImportEntity.createdByUserId];
    if (status === OrderStatusEnum.Confirmed) {
      notificationRequest.payload = {
        title: titleConfirm,
        content: purchasedOrderImportEntity.description,
      };
      notificationRequest.title = titleConfirm;
      const pushMail = Object.assign(notificationRequest, {
        type: TypeNotificationEnum.MAIL,
      });
      this.eventEmitter.emit('purchased_order_import.confirm', pushMail);
      this.eventEmitter.emit(
        'purchased_order_import.confirm',
        notificationRequest,
      );
    }
    if (status === OrderStatusEnum.Reject) {
      notificationRequest.payload = {
        title: titleReject,
        content: purchasedOrderImportEntity.description,
      };
      notificationRequest.title = titleReject;
      const pushMail = Object.assign(notificationRequest, {
        type: TypeNotificationEnum.MAIL,
      });
      this.eventEmitter.emit('purchased_order_import.reject', pushMail);
      this.eventEmitter.emit(
        'purchased_order_import.reject',
        notificationRequest,
      );
    }
    if (status === OrderStatusEnum.RejectReceived) {
      notificationRequest.payload = {
        title: titleRejectReceived,
        content: purchasedOrderImportEntity.description,
      };
      notificationRequest.title = titleRejectReceived;
      const pushMail = Object.assign(notificationRequest, {
        type: TypeNotificationEnum.MAIL,
      });
      this.eventEmitter.emit(
        'purchased_order_import.reject_received',
        pushMail,
      );
      this.eventEmitter.emit(
        'purchased_order_import.reject_received',
        notificationRequest,
      );
    }

    const response = plainToInstance(
      PurchasedOrderImportResponseDto,
      purchasedOrderImportEntity,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  /**
   * Get List Purchased Order
   * @param request
   * @returns
   */
  public async getPurchasedOrderImports(
    request: GetAllPOImportRequest,
  ): Promise<ResponsePayload<any>> {
    try {
      const data = await this.purchasedOrderImportRepository.findWithRelations({
        relations: ['purchasedOrderImportWarehouseDetails'],
        where: {
          status: In(request.status),
        },
      });

      const dataReturn = plainToInstance(GetAllPOImportResponse, data, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error)
        .build();
    }
  }

  async getLatestPOImportSuccess(
    request: GetByItemIdsRequestDto,
  ): Promise<ResponsePayload<any>> {
    const poImp =
      await this.purchasedOrderImportRepository.getLatestPOImportSuccess(
        request.itemIds,
      );

    if (isEmpty(poImp)) {
      return new ResponseBuilder({
        doorIds: [],
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const poImportReceive =
      await this.purchasedOrderImportReceiveRepository.findByCondition({
        purchasedOrderImportId: poImp.id,
      });

    const doorIds = poImportReceive.map((e) => e.doorId);
    return new ResponseBuilder({
      doorIds,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  async checkItemHasExistOnPurchaseOrderImport(
    request: GetByItemIdRequestDto,
  ): Promise<any> {
    return await this.purchasedOrderImportDetailRepository.findOneByCondition(
      request,
    );
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async updatePOQcQuantityPurchasedOrderImportWarehouse(
    request: UpdatePurchasedOrderImportWarehouseQcQuantityDto,
  ): Promise<any> {
    try {
      const {
        purchasedOrderImportId,
        warehouseId,
        itemId,
        qcRejectQuantity,
        qcPassQuantity,
        lotNumber,
      } = request;
      const purchasedOrderImportWarehouse =
        await this.purchasedOrderImportWarehouseDetailRepository.findOneWithRelations(
          {
            where: {
              purchasedOrderImportId,
              warehouseId,
              itemId,
            },
            relations: ['purchasedOrderImport'],
          },
        );

      const purchasedOrderImportWarehouseLot =
        await this.purchasedOrderImportWarehouseLotRepository.findOneWithRelations(
          {
            where: {
              purchasedOrderImportId: purchasedOrderImportId,
              warehouseId: warehouseId,
              itemId: itemId,
              lotNumber: ILike(lotNumber),
            },
          },
        );

      if (!purchasedOrderImportWarehouse || !purchasedOrderImportWarehouseLot) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }
      if (!purchasedOrderImportWarehouse.purchasedOrderImport) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }

      if (
        !STATUS_TO_QC_ORDER.includes(
          purchasedOrderImportWarehouse.purchasedOrderImport.status,
        )
      ) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
          .build();
      }

      // TO DO mobile update validate lot_number

      if (qcPassQuantity < 0 || qcRejectQuantity < 0) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
          .build();
      }

      if (
        plus(qcPassQuantity, qcRejectQuantity) >
        purchasedOrderImportWarehouse.quantity
      ) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
          .build();
      }

      purchasedOrderImportWarehouseLot.qcPassQuantity = plus(
        purchasedOrderImportWarehouseLot.qcPassQuantity || 0,
        qcPassQuantity,
      );
      purchasedOrderImportWarehouseLot.qcRejectQuantity = plus(
        purchasedOrderImportWarehouseLot.qcRejectQuantity || 0,
        qcRejectQuantity,
      );

      await this.purchasedOrderImportWarehouseLotRepository.create(
        purchasedOrderImportWarehouseLot,
      );

      return await this.setPurchasedOrderImportWarehouseDetailQcQuantity(
        purchasedOrderImportWarehouse,
        request.qcPassQuantity,
        request.qcRejectQuantity,
      );
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error)
        .build();
    }
  }

  /**
   *
   * @param purchasedOrderWarehouseDetail
   * @param qcPassQuantity
   * @param qcRejectQuantity
   * @returns
   */
  private async setPurchasedOrderImportWarehouseDetailQcQuantity(
    purchasedOrderImportWarehouseDetail: PurchasedOrderImportWarehouseDetailEntity,
    qcPassQuantity: number,
    qcRejectQuantity: number,
  ): Promise<any> {
    purchasedOrderImportWarehouseDetail.qcPassQuantity = plus(
      +purchasedOrderImportWarehouseDetail.qcPassQuantity || 0,
      qcPassQuantity,
    );
    purchasedOrderImportWarehouseDetail.qcRejectQuantity = plus(
      +purchasedOrderImportWarehouseDetail.qcRejectQuantity || 0,
      qcRejectQuantity,
    );
    purchasedOrderImportWarehouseDetail.errorQuantity = plus(
      +purchasedOrderImportWarehouseDetail.errorQuantity || 0,
      qcRejectQuantity,
    );
    await this.purchasedOrderImportWarehouseDetailRepository.create(
      purchasedOrderImportWarehouseDetail,
    );

    const response = plainToInstance(
      PurchasedOrderImportWarehouseDetailResponseDto,
      purchasedOrderImportWarehouseDetail,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getTotalQuantityItemPurchasedOrderImportsByCondition(
    condition: any,
  ): Promise<any> {
    const { itemIds } = condition;

    const purchasedOrderImports =
      await this.purchasedOrderImportRepository.getPurchasedOrderImportInProgress(
        condition,
      );
    if (purchasedOrderImports.length === 0) {
      return [];
    }
    const purchasedOrderImportIds = uniq(
      map(flatMap(purchasedOrderImports), 'id'),
    );
    const totalQuantityItems =
      await this.purchasedOrderImportDetailRepository.getTotalQuantityItemPurchasedOrderImportsByCondition(
        {
          purchasedOrderImportIds: purchasedOrderImportIds,
          itemIds: itemIds,
        },
      );
    const response = plainToInstance(
      TotalQuantityItemPurchaseOrderImportResponseDto,
      totalQuantityItems,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  async importPurchasedOrderImports(
    request: FileUpdloadRequestDto,
  ): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
      userId: request.userId,
    } as ImportRequestDto;
    const importPurchasedOrderImport =
      await this.purchasedOrderImportImport.importUtil(importRequestDto, this);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(importPurchasedOrderImport)
      .build();
  }

  public async updateWarehouseLots(
    payload: UpdateWarehouseLotRequestDto,
  ): Promise<any> {
    const { orderId, warehouseId, itemLotOrderDetails } = payload;
    const itemIds = map(itemLotOrderDetails, 'itemId');
    const poImportWarehouseDetails =
      await this.purchasedOrderImportWarehouseDetailRepository.findWithRelations(
        {
          where: {
            purchasedOrderImportId: orderId,
            warehouseId: warehouseId,
            itemId: In(itemIds),
          },
        },
      );
    if (
      !poImportWarehouseDetails ||
      poImportWarehouseDetails.length !== itemIds.length
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const poImportWarehouseLots =
      await this.purchasedOrderImportWarehouseLotRepository.findWithRelations({
        warehouseId: warehouseId,
        purchasedOrderImportId: orderId,
        itemId: In(itemIds),
      });

    //TO DO mobile update
    const lotEntities = [];

    itemLotOrderDetails.forEach((itemLotOrderDetail) => {
      itemLotOrderDetail.lots.forEach((lot) => {
        const entity = new PurchasedOrderImportWarehouseLotEntity();
        entity.purchasedOrderImportId = orderId;
        entity.warehouseId = warehouseId;
        entity.itemId = itemLotOrderDetail.itemId;
        entity.qcPassQuantity = 0;
        entity.qcRejectQuantity = 0;
        entity.actualQuantity = 0;
        entity.lotNumber = lot.lotNumber.toUpperCase();

        const existedLot = find(
          poImportWarehouseLots,
          (poImportWarehouseLot) =>
            poImportWarehouseLot.lotNumber.toUpperCase() ===
              lot.lotNumber.toUpperCase() &&
            poImportWarehouseLot.itemId === poImportWarehouseLot.itemId,
        );
        if (existedLot) {
          entity.actualQuantity = plus(
            existedLot.actualQuantity || 0,
            lot.quantity,
          );
          entity.qcPassQuantity = existedLot.qcPassQuantity;
          entity.qcRejectQuantity = existedLot.qcRejectQuantity;
          entity.id = existedLot.id;
        }
        //TO DO mobile update
        lotEntities.push(entity);
      });
    });

    try {
      await this.purchasedOrderImportWarehouseLotRepository.create(lotEntities);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (e) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(e?.message || e)
        .build();
    }
  }

  public async getListLotNumberByItemId(
    itemIds: number[],
  ): Promise<ResponsePayload<any>> {
    const lotNumberOfItemPOIMP =
      await this.purchasedOrderImportWarehouseLotRepository.getListLotNumber(
        itemIds,
      );
    const result = lotNumberOfItemPOIMP.reduce((record, item) => {
      const temp = record.find((x) => x.itemId === item.itemId);
      if (!temp) {
        record.push({
          itemId: item.itemId,
          lotNumbers: [item],
        });
      } else {
        temp.lotNumbers.push(item);
      }
      return record;
    }, []);
    const dataReturn = plainToInstance(LotNumberOfItemResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async createPurchasedOrderImportReceive(
    request: CreatePurchasedOrderImportReceiveRequestDto,
  ): Promise<any> {
    const { purchasedOrderImportId, items, isComplete, userId, warehouseId } =
      request;

    const purchasedOrderImport =
      await this.purchasedOrderImportRepository.findOneWithRelations({
        where: {
          id: purchasedOrderImportId,
        },
        relations: [
          'purchasedOrderImportDetails',
          'purchasedOrderImportWarehouseDetails',
          'purchasedOrderImportWarehouseLots',
        ],
      });

    if (isEmpty(purchasedOrderImport)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.PURCHASE_ORDER_IMPORT_NOT_EXIST'),
        )
        .build();
    }
    if (!STATUS_TO_CREATE_ORDER_RECEIVE.includes(purchasedOrderImport.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.PURCHASE_ORDER_STATUS_IS_INVALID'),
        )
        .build();
    }

    if (+warehouseId !== +purchasedOrderImport.warehouseId) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'),
      ).toResponse();
    }

    const poImportItemById = keyBy(
      purchasedOrderImport.purchasedOrderImportDetails,
      'itemId',
    );
    const poImportItemWarehouseById = keyBy(
      purchasedOrderImport.purchasedOrderImportWarehouseDetails,
      'itemId',
    );
    const poImportItemWarehouseLotById = keyBy(
      purchasedOrderImport.purchasedOrderImportWarehouseLots,
      (item) => `${item.itemId}-${item.lotNumber || ''}`,
    );

    if (
      items.some(
        (item) =>
          !has(
            poImportItemWarehouseLotById,
            `${item.itemId}-${item.lotNumber || ''}`,
          ),
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.ITEM_IN_PURCHASED_ORDER_IMPORT_IS_INVALID',
          ),
        )
        .build();
    }

    const poImportReceiveItemEntities =
      purchasedOrderImport.purchasedOrderImportWarehouseLots.map((itemLot) => {
        const requestCreatePoImportReceiveItem =
          new CreatePurchasedOrderImportReceiveItemEntityRequestDto();
        requestCreatePoImportReceiveItem.itemId = itemLot.itemId;
        requestCreatePoImportReceiveItem.lotNumber = itemLot.lotNumber;
        requestCreatePoImportReceiveItem.actualQuantity =
          itemLot.actualQuantity;
        requestCreatePoImportReceiveItem.quantity = Number(itemLot.quantity);
        return this.purchasedOrderImportReceiveItemRepository.createEntity(
          requestCreatePoImportReceiveItem,
        );
      });

    const poImportReceiveEntity =
      this.purchasedOrderImportReceiveRepository.createEntityWithRelationItems(
        request,
        poImportReceiveItemEntities,
      );

    const tempPoimpDetail = {};
    const tempPoimpDetailWarehouse = {};
    const tempPoimpDetailWarehouseLot = {};

    items.forEach((item) => {
      if (!tempPoimpDetail[item.itemId] && poImportItemById[`${item.itemId}`]) {
        tempPoimpDetail[item.itemId] = {
          ...poImportItemById[`${item.itemId}`],
          receivedQuantity: item.actualQuantity,
        };
      } else {
        tempPoimpDetail[item.itemId].receivedQuantity = plusBigNumber(
          tempPoimpDetail[item.itemId].receivedQuantity,
          item.actualQuantity,
        );
      }

      const keyLot = `${item.itemId}-${item.lotNumber || ''}`;
      if (
        !tempPoimpDetailWarehouseLot[keyLot] &&
        poImportItemWarehouseLotById[keyLot]
      ) {
        tempPoimpDetailWarehouseLot[keyLot] = {
          ...poImportItemWarehouseLotById[keyLot],
          receivedQuantity: item.actualQuantity,
        };
      } else {
        tempPoimpDetailWarehouseLot[keyLot].receivedQuantity = plusBigNumber(
          tempPoimpDetailWarehouseLot[keyLot].receivedQuantity,
          item.actualQuantity,
        );
      }

      if (
        !tempPoimpDetailWarehouse[item.itemId] &&
        poImportItemWarehouseById[`${item.itemId}`]
      ) {
        tempPoimpDetailWarehouse[item.itemId] = {
          ...poImportItemWarehouseById[`${item.itemId}`],
          receivedQuantity: item.actualQuantity,
        };
      } else {
        tempPoimpDetailWarehouse[item.itemId].receivedQuantity = plusBigNumber(
          tempPoimpDetailWarehouse[item.itemId].receivedQuantity,
          item.actualQuantity,
        );
      }
    });

    const poImportDetailEntities = values(tempPoimpDetail);
    const poImportDetailWarehouseEntities = values(tempPoimpDetailWarehouse);
    const poImportWarehouseLotEntities = values(tempPoimpDetailWarehouseLot);

    const poiwLotMap = keyBy(
      purchasedOrderImport.purchasedOrderImportWarehouseLots,
      (poiwl) => `${poiwl.itemId}_${poiwl.lotNumber || ''}`,
    );

    let lotFail = 0;
    const itemReceives = items.map((item) => {
      const warehouseDetail =
        purchasedOrderImport.purchasedOrderImportWarehouseDetails.find(
          (detail) => detail.itemId === item.itemId,
        );
      if (isEmpty(poiwLotMap[`${item.itemId}_${item.lotNumber || ''}`])) {
        lotFail++;
      }
      return new WarehouseItemReceiveRequestDto(
        item.itemId,
        Number(item.actualQuantity),
        warehouseDetail.id,
        item.lotNumber,
      );
    });

    if (lotFail > 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.LOT_NUMBER_NOT_FOUND'));
    }

    const requestWarehouseReceive = new WarehouseReceiveRequestDto(
      WarehouseStockMovementTypeEnum.PO_IMPORT_RECEIVE,
      purchasedOrderImport.id,
      purchasedOrderImport.code,
      purchasedOrderImport.warehouseId,
      userId,
      itemReceives,
      isComplete,
    );

    purchasedOrderImport.status = OrderStatusEnum.Received;
    purchasedOrderImport.syncStatus = StatusSyncOrderToEbsEnum.OUT_OF_SYNC;
    if (isComplete) {
      purchasedOrderImport.status = OrderStatusEnum.Completed;
      poImportDetailEntities.forEach((poDetail) => {
        poDetail.actualQuantity = poDetail.receivedQuantity;
        poDetail.confirmedQuantity = poDetail.receivedQuantity;
      });
      poImportDetailWarehouseEntities.forEach((poDetailWarehouse) => {
        poDetailWarehouse.actualQuantity = poDetailWarehouse.receivedQuantity;
        poDetailWarehouse.actualQuantity = poDetailWarehouse.receivedQuantity;
        poDetailWarehouse.confirmedQuantity =
          poDetailWarehouse.receivedQuantity;
      });
      poImportWarehouseLotEntities.forEach((poWarehouseLot) => {
        const poDetailEntity = poImportDetailEntities.find(
          (poDetail) => poDetail.itemId === poWarehouseLot.itemId,
        );
        poWarehouseLot.actualQuantity = poDetailEntity?.receivedQuantity || 0;
      });
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(purchasedOrderImport);
      await queryRunner.manager.save(poImportReceiveEntity);
      await queryRunner.manager.save(
        PurchasedOrderImportDetailEntity,
        poImportDetailEntities,
      );
      await queryRunner.manager.save(
        PurchasedOrderImportWarehouseDetailEntity,
        poImportDetailWarehouseEntities,
      );
      if (!isEmpty(poImportWarehouseLotEntities)) {
        await queryRunner.manager.save(
          PurchasedOrderImportWarehouseLotEntity,
          poImportWarehouseLotEntities,
        );
      }

      const receiptNumber = purchasedOrderImport?.receiptNumber;
      if (receiptNumber) {
        const receipt = await this.receiptRepository.findOneByCondition({
          code: receiptNumber,
        });
        if (!isEmpty(receipt)) {
          receipt.status = RECEIPT_STATUS.USED;
          await queryRunner.manager.save(ReceiptEntity, receipt);
        }
      }

      const warehouseStockMovement =
        await this.warehouseService.warehouseReceive(requestWarehouseReceive);
      if (warehouseStockMovement.statusCode !== ResponseCodeEnum.SUCCESS) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(
            warehouseStockMovement?.statusCode || ResponseCodeEnum.BAD_REQUEST,
          )
          .withMessage(
            warehouseStockMovement?.message ||
              (await this.i18n.translate('error.INTERNAL_SERVER_ERROR')),
          );
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error);
    } finally {
      await queryRunner.release();
    }

    this.eventEmitter.emit(
      EventSyncPoImportEnum.Update,
      purchasedOrderImportId,
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async createPurchasedOrderImportReceiveWithTicket(
    request: CreatePurchasedOrderImportReceiveWithTicketRequestDto,
  ): Promise<any> {
    const { ticketId, warehouseId, items, isComplete } = request;
    //TODO valid ticket
    const ticket = await this.ticketService.getTicketReceiptById(ticketId);
    if (!ticket) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const poImportReceiveItemEntities = items.map((itemLot) => {
      const requestCreatePoImportReceiveItem =
        new CreatePurchasedOrderImportReceiveItemEntityRequestDto();
      requestCreatePoImportReceiveItem.itemId = itemLot.itemId;
      requestCreatePoImportReceiveItem.lotNumber = itemLot.lotNumber;
      requestCreatePoImportReceiveItem.actualQuantity = itemLot.actualQuantity;
      requestCreatePoImportReceiveItem.quantity = Number(
        itemLot.actualQuantity,
      );

      return this.purchasedOrderImportReceiveItemRepository.createEntity(
        requestCreatePoImportReceiveItem,
      );
    });

    const poImportReceiveEntity =
      this.purchasedOrderImportReceiveRepository.createEntityWithRelationItemsTicket(
        request,
        poImportReceiveItemEntities,
      );
    const itemReceives = items.map((item) => {
      return new WarehouseItemReceiveRequestDto(
        item.itemId,
        Number(item.actualQuantity),
        warehouseId,
        item.lotNumber,
      );
    });

    const requestWarehouseReceive = new WarehouseReceiveRequestDto(
      WarehouseStockMovementTypeEnum.PO_IMPORT_RECEIVE,
      ticketId,
      ticket.code,
      warehouseId,
      request.userId,
      itemReceives,
      isComplete,
    );
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(poImportReceiveEntity);
      const warehouseStockMovement =
        await this.warehouseService.warehouseReceive(requestWarehouseReceive);
      if (warehouseStockMovement.statusCode !== ResponseCodeEnum.SUCCESS) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(
            warehouseStockMovement?.statusCode || ResponseCodeEnum.BAD_REQUEST,
          )
          .withMessage(
            warehouseStockMovement?.message ||
              (await this.i18n.translate('error.INTERNAL_SERVER_ERROR')),
          );
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error);
    } finally {
      await queryRunner.release();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async updatePurchasedOrderImportReceive(
    request: UpdatePurchasedOrderImportReceiveRequestDto,
  ): Promise<any> {
    const { id, items } = request;

    const purchasedOrderImportReceive =
      await this.purchasedOrderImportReceiveRepository.findOneWithRelations({
        where: { id },
        relations: [
          'purchasedOrderImport',
          'purchasedOrderImport.purchasedOrderImportDetails',
          'purchasedOrderImportReceiveItems',
        ],
      });

    if (isEmpty(purchasedOrderImportReceive)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.PURCHASE_ORDER_IMPORT_NOT_EXIST'),
        )
        .build();
    }
    const purchasedOrderImport =
      purchasedOrderImportReceive.purchasedOrderImport;

    if (
      !STATUS_TO_UPDATE_PURCHASED_ORDER_IMPORT.includes(
        purchasedOrderImport.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.PURCHASE_ORDER_STATUS_IS_INVALID'),
        )
        .build();
    }

    const poImportItemById = keyBy(
      purchasedOrderImport.purchasedOrderImportDetails,
      'itemId',
    );

    const poImportReceiveItemEntities = items.map((item) => {
      const requestCreatePoImportReceiveItem =
        new CreatePurchasedOrderImportReceiveItemEntityRequestDto();
      requestCreatePoImportReceiveItem.itemId = item.itemId;
      requestCreatePoImportReceiveItem.actualQuantity = item.actualQuantity;
      requestCreatePoImportReceiveItem.quantity = Number(
        poImportItemById[`${item.itemId}`]?.quantity,
      );
      return this.purchasedOrderImportReceiveItemRepository.createEntity(
        requestCreatePoImportReceiveItem,
      );
    });

    const poImportReceiveEntity =
      this.purchasedOrderImportReceiveRepository.updateEntity(
        purchasedOrderImportReceive.id,
        request,
        poImportReceiveItemEntities,
      );

    const poImportEntity =
      this.purchasedOrderImportRepository.updatePoImportStatus(
        purchasedOrderImport,
        OrderStatusEnum.InReceiving,
      );
    poImportEntity.syncStatus = StatusSyncOrderToEbsEnum.OUT_OF_SYNC;

    const itemRequest = keyBy(items, 'itemId');

    const poImportDetailEntities =
      purchasedOrderImport.purchasedOrderImportDetails.map((poImportDetail) => {
        if (!isEmpty(itemRequest[`${poImportDetail.itemId}`])) {
          return this.purchasedOrderImportDetailRepository.updatePoImportDetailReceivedQuantity(
            poImportDetail,
            plus(
              poImportDetail.receivedQuantity,
              itemRequest[`${poImportDetail.itemId}`]?.actualQuantity || 0,
            ),
          );
        }
        return this.purchasedOrderImportDetailRepository.updatePoImportDetailReceivedQuantity(
          poImportDetail,
          0,
        );
      });

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.delete(PurchasedOrderImportReceiveItemEntity, {
        purchasedOrderImportReceiveId: id,
      });
      await queryRunner.manager.save(poImportReceiveEntity);
      await queryRunner.manager.save(poImportDetailEntities);
      await queryRunner.manager.save(poImportEntity);
      const fileResponse = await this.fileService.uploadFiles(
        request.files,
        FileResource.POI,
      );

      if (fileResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(fileResponse?.message);
      }

      const fileUploadEntities = fileResponse.data.map((fileId) =>
        this.fileRepository.createEntity({
          resourceId: id,
          resource: FileResource.POI,
          fileId,
        }),
      );

      await queryRunner.manager.save(fileUploadEntities);

      await queryRunner.commitTransaction();

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error);
    } finally {
      await queryRunner.release();
    }
  }

  /**
   *
   * @param _request
   * @returns
   */
  public async submitPOImportReceive(
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    request: SubmitPOImportReceiveRequeseDto,
  ): Promise<any> {
    // TODO: Đồng bộ sang EBS
    try {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (e) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(
          e.message ||
            (await await this.i18n.translate('error.INTERNAL_SERVER_ERROR')),
        )
        .build();
    }
  }

  private async getListUserByRoles(userRoleSettings: any[]): Promise<any> {
    const listCode = uniq(map(flatMap(userRoleSettings), 'code'));
    if (listCode.find((c) => c !== ROLE.EMPLOYEE)) {
      const listUserRoles = await this.userService.getUsersByRoleCodes([
        ROLE.EMPLOYEE,
      ]);
      return uniq(map(flatMap(listUserRoles, 'userId')));
    }
  }

  public async getPoImportReceiveDetail(id: number): Promise<any> {
    const result =
      await this.purchasedOrderImportReceiveRepository.getPurchasedOrderImportReceiveDetail(
        id,
      );

    if (isEmpty(result)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const door = await this.warehouseService.getWarehouseDoorById(
      result.doorId,
    );

    const itemIds = result.items.map((item) => item.itemId);
    const items = await this.itemService.getItems(itemIds);
    const itemByIds = keyBy(items, 'itemId');

    const response = plainToInstance(
      PurchasedOrderImportReceiveDetailResponseDto,
      {
        ...result,
        door,
        items: result.items.map((item) => ({
          ...item,
          itemName: itemByIds[`${item.itemId}`]?.name,
          itemCode: itemByIds[`${item.itemId}`]?.code,
          itemUnit: itemByIds[`${item.itemId}`]?.itemUnit,
        })),
      },
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  async suggestStoredByOrderId(
    request: SuggestStoredOrderImportRequestDto,
  ): Promise<any> {
    const { id, items, locatorIds } = request;
    const order =
      await this.purchasedOrderImportRepository.findOneWithRelations({
        where: {
          id,
        },
        relations: [
          'purchasedOrderImportReceive',
          'purchasedOrderImportReceive.purchasedOrderImportReceiveItems',
          'purchasedOrder',
          'purchasedOrderImportDetails',
        ],
      });
    if (isEmpty(order) || isEmpty(order.purchasedOrderImportReceive)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const purchasedOrderImportReceiveItems =
      order.purchasedOrderImportReceive.purchasedOrderImportReceiveItems;
    const purchasedOrderImportReceiveItemsSerialize = keyBy(
      purchasedOrderImportReceiveItems,
      'itemId',
    );

    const warehouse = await this.warehouseService.getDetailById(
      order.purchasedOrderImportReceive.warehouseId,
    );

    let vendor = {} as Vendor;
    if (order?.purchasedOrder?.vendorId) {
      vendor = await this.vendorRepository.findOneById(
        order.purchasedOrder.vendorId,
      );
    }

    const checkItemsExist = items.filter(
      (item) =>
        !map(purchasedOrderImportReceiveItems, 'itemId').includes(item.itemId),
    );

    if (!isEmpty(checkItemsExist)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    const mapItemSuggest = [];

    items.forEach((receiveItem) => {
      mapItemSuggest.push({
        quantity: receiveItem.quantity,
        itemId: receiveItem.itemId,
        lotNumber: receiveItem.lotNumber,
      });
    });
    const requestSuggest =
      new SuggestImportItemToWarehouseShelfFloorRequestDto();
    requestSuggest.warehouseId = order.purchasedOrderImportReceive.warehouseId;
    requestSuggest.locatorIds = locatorIds;
    requestSuggest.items = mapItemSuggest;
    requestSuggest.filter = request.filter;
    const responseSuggest =
      await this.warehouseService.suggestItemImportToWarehouse(requestSuggest);
    if (responseSuggest.statusCode !== ResponseCodeEnum.SUCCESS) {
      return responseSuggest;
    }

    const suggestStored = responseSuggest.data;
    const itemsSuggest = [];
    suggestStored?.items?.forEach((suggest) => {
      const itemId = suggest.itemId;
      itemsSuggest.push({
        itemId: itemId,
        name: suggest.name,
        code: suggest.code,
        lotNumber: purchasedOrderImportReceiveItemsSerialize[itemId]?.lotNumber,
        storedQuantity:
          purchasedOrderImportReceiveItemsSerialize[itemId]?.storedQuantity,
        actualQuantity:
          purchasedOrderImportReceiveItemsSerialize[itemId]?.actualQuantity,
        planQuantity:
          purchasedOrderImportReceiveItemsSerialize[itemId]?.quantity,
        remainingQuantity: minus(
          purchasedOrderImportReceiveItemsSerialize[itemId]?.storedQuantity ||
            0,
          purchasedOrderImportReceiveItemsSerialize[itemId]?.actualQuantity ||
            0,
        ),
        locations: [
          {
            ...suggest.locator,
            quantity: suggest.quantity,
          },
        ],
      });
    });

    const response = plainToInstance(
      SuggestStoredPurchasedOrderImportResponseDto,
      {
        ...order,
        warehouseName: warehouse?.name,
        vendorName: vendor?.name,
        items: itemsSuggest,
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  async getListOrderWarehouseDoor(
    request: GetOrderDoorRequestDto,
  ): Promise<any> {
    const { user, keyword } = request;
    const userWarehouses = await this.userService.getUserWarehousesById(
      user.id,
    );
    let warehouseIds = [];
    if (!isEmpty(keyword)) {
      warehouseIds = filter(
        userWarehouses,
        (warehouse) =>
          searchLikeString(warehouse.name, keyword) ||
          searchLikeString(warehouse.code, keyword),
      ).map((w) => w.id);
    } else {
      warehouseIds = userWarehouses.map((e) => e.id);
    }

    const data =
      await this.purchasedOrderImportWarehouseDetailRepository.getListOrderWarehouse(
        request,
        warehouseIds,
      );
    const warehouseDoors =
      await this.warehouseService.getWarehouseDoorsByWarehouseIds(
        data.map((warehouse) => warehouse.warehouseId),
      );

    const dataReturn = plainToInstance(
      WarehouseDoorResponseDto,
      !isEmpty(warehouseDoors) ? warehouseDoors : [],
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async getSuggestStoredByPoImportId(
    request: GetSuggestStoredByPoImportIdRequestDto,
  ): Promise<any> {
    const { poImportId, itemIds } = request;
    const poImportReceive =
      await this.purchasedOrderImportReceiveRepository.findOneWithRelations({
        where: { purchasedOrderImportId: poImportId },
        relations: ['purchasedOrderImportReceiveItems'],
      });

    if (isEmpty(poImportReceive)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const suggestedItem = poImportReceive.purchasedOrderImportReceiveItems
      .filter((item) => itemIds.includes(item.itemId))
      ?.map((poReceiveItem) => {
        return {
          itemId: poReceiveItem.itemId,
          quantity: minus(
            poReceiveItem.storedQuantity,
            poReceiveItem.actualQuantity,
          ),
        };
      });
    if (isEmpty(suggestedItem)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.ITEM_NOT_IN_ORDER'))
        .build();
    }

    if (!isEmpty(suggestedItem.find((item) => Number(item.quantity) <= 0))) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.ITEM_HAS_BEEN_STORED'))
        .build();
    }

    const suggestStoredRequest = new SuggestStoredOrderImportRequestDto();
    suggestStoredRequest.id = poImportId;
    suggestStoredRequest.items = suggestedItem;
    return await this.suggestStoredByOrderId(suggestStoredRequest);
  }

  public async rejectReceived(payload: SetOrderStatusRequestDto): Promise<any> {
    const { id, userId } = payload;

    const purchasedOrderImport =
      await this.purchasedOrderImportRepository.findOneById(id);
    if (!purchasedOrderImport) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (
      !STATUS_TO_REJECT_RECEIVED_PURCHASED_ORDER_INPORT.includes(
        purchasedOrderImport.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    return await this.setPurchasedOrderStatus(
      purchasedOrderImport,
      OrderStatusEnum.RejectReceived,
      userId,
    );
  }

  async completePurchasedOrderImport(
    request: PurchasedOrderImportCompleteRequestDto,
  ): Promise<any> {
    const { id } = request;
    const order =
      await this.purchasedOrderImportRepository.checkReadyToComplete(id);

    if (!order) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    const poImportEntity =
      await this.purchasedOrderImportRepository.findOneById(id);

    if (!CAN_COMPLETE_PO.includes(poImportEntity.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }
    poImportEntity.status = OrderStatusEnum.Completed;
    poImportEntity.completedAt = new Date();
    poImportEntity.note = request.note || '';

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(poImportEntity);
      const receiptNumber = poImportEntity?.receiptNumber;
      if (receiptNumber) {
        const receipt = await this.receiptRepository.findOneByCondition({
          code: receiptNumber,
        });
        if (!isEmpty(receipt)) {
          receipt.status = RECEIPT_STATUS.USED;
          await queryRunner.manager.save(ReceiptEntity, receipt);
        }
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder(error)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } finally {
      await queryRunner.release();
      this.eventEmitter.emit(
        'order.updateStatus',
        new OrderUpdateStatusEvent({
          id: poImportEntity.purchasedOrderId,
          orderType: SaleOrderTypeEnum.PO,
        }),
      );
    }

    const updateStockStatusOrder = new UpdateStockStatusOrderRequest();
    updateStockStatusOrder.id = poImportEntity.id;
    updateStockStatusOrder.completedAt = poImportEntity.completedAt;
    updateStockStatusOrder.status = OrderStatusEnum.Completed;
    updateStockStatusOrder.type = SaleOrderTypeEnum.PO;

    await this.warehouseService.updateStatusWarehouseStockMovement(
      updateStockStatusOrder,
    );

    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async getHistoryMovementByOrderId(
    request: GetOrderDetailRequestDto,
  ): Promise<any> {
    const order =
      await this.purchasedOrderImportRepository.findOneWithRelations({
        where: {
          id: request.id,
        },
        relations: [
          'purchasedOrderImportWarehouseDetails',
          'purchasedOrder',
          'purchasedOrder.vendor',
        ],
      });

    if (isEmpty(order)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const groupOrderarehouseDetailByItemId = groupBy(
      order.purchasedOrderImportWarehouseDetails,
      'itemId',
    );

    const movements = await this.warehouseService.getDetailMovementByOrderId(
      order.id,
      WarehouseStockMovementTypeEnum.PO_IMPORT,
    );

    movements.forEach((movement) => {
      movement.planQuantity = has(
        groupOrderarehouseDetailByItemId,
        movement.itemId,
      )
        ? sumBy(groupOrderarehouseDetailByItemId[movement.itemId], 'quantity')
        : 0;
    });

    const warehouseId = first(
      order.purchasedOrderImportWarehouseDetails,
    )?.warehouseId;

    let warehouse = {};

    if (warehouseId) {
      warehouse = await this.warehouseService.getDetailById(warehouseId);
    }

    const response = plainToInstance(
      DetailMovementPurchasedOrderImportResponseDto,
      {
        ...order,
        vendorName: order?.purchasedOrder?.vendor?.name,
        items: movements,
        warehouse: warehouse,
      },
      { excludeExtraneousValues: true },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getErrorItemsByOrder(
    request: GetErrorItemByOrderRequestDto,
  ): Promise<any> {
    const data =
      await this.purchasedOrderImportWarehouseDetailRepository.getErrorItemById(
        request.id,
      );
    const res = plainToInstance(ErrorItem, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(res)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateOrderDetailReturnQuantity(
    request: UpdateOrderDetailReturnQuantityRequestDto,
  ): Promise<any> {
    const { itemLots, orderDetails, warehouseOrderDetails, orderId } = request;
    const order =
      await this.purchasedOrderImportRepository.findOneWithRelations({
        where: { id: orderId },
        relations: [
          'purchasedOrderImportWarehouseDetails',
          'purchasedOrderImportWarehouseLots',
          'purchasedOrderImportDetails',
        ],
      });
    if (!order || order.status !== OrderStatusEnum.Received) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      );
    }
    const {
      purchasedOrderImportWarehouseDetails,
      purchasedOrderImportWarehouseLots,
      purchasedOrderImportDetails,
    } = order;
    const purchasedOrderImportDetailEntities = [];
    const purchasedOrderImportWarehouseDetailEntities = [];
    const purchasedOrderImportWarehouseLotEntities = [];
    orderDetails.forEach((orderDetail) => {
      const poid = purchasedOrderImportDetails.find(
        (poid) => +poid.id === +orderDetail.id,
      );
      if (poid) {
        poid.returnedQuantity = plus(
          poid.returnedQuantity,
          orderDetail.quantity,
        );
        poid.actualQuantity = plus(poid.actualQuantity, orderDetail.quantity);
        poid.confirmedQuantity = plus(
          poid.confirmedQuantity,
          orderDetail.quantity,
        );
        purchasedOrderImportDetailEntities.push(poid);
      }
    });
    warehouseOrderDetails.forEach((warehouseOrderDetail) => {
      const poiwd = purchasedOrderImportWarehouseDetails.find(
        (poiwd) =>
          +poiwd.id === +warehouseOrderDetail.id &&
          poiwd.qcCheck &&
          poiwd.qcRejectQuantity > 0,
      );
      if (poiwd) {
        poiwd.returnedQuantity = plus(
          poiwd.returnedQuantity,
          warehouseOrderDetail.quantity,
        );
        poiwd.actualQuantity = plus(
          poiwd.actualQuantity,
          warehouseOrderDetail.quantity,
        );
        poiwd.confirmedQuantity = plus(
          poiwd.confirmedQuantity,
          warehouseOrderDetail.quantity,
        );
        purchasedOrderImportWarehouseDetailEntities.push(poiwd);
      }
    });
    itemLots.forEach((item) => {
      const poiwl = purchasedOrderImportWarehouseLots.find(
        (poiwl) =>
          +poiwl.purchasedOrderImportId === orderId &&
          +poiwl.itemId === +item.itemId &&
          +poiwl.warehouseId === +item.warehouseId &&
          poiwl.lotNumber === item.lotNumber &&
          poiwl.qcRejectQuantity > 0,
      );
      if (poiwl) {
        poiwl.returnedQuantity = plus(poiwl.returnedQuantity, item.quantity);
        poiwl.actualQuantity = plus(poiwl.actualQuantity, item.quantity);
        purchasedOrderImportWarehouseLotEntities.push(poiwl);
      }
    });

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(purchasedOrderImportDetailEntities);
      await queryRunner.manager.save(
        purchasedOrderImportWarehouseDetailEntities,
      );
      await queryRunner.manager.save(purchasedOrderImportWarehouseLotEntities);
      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder(error)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  public async syncEbsInput(request: EbsInPOImportRequestDto): Promise<any> {
    const { id, ebsId, item, status, receipt } = request;

    const order =
      await this.purchasedOrderImportRepository.findOneWithRelations({
        where: {
          id: id,
        },
        relations: [
          'purchasedOrderImportWarehouseLots',
          'purchasedOrderImportDetails',
        ],
      });

    if (isEmpty(order)) {
      this.logger.error(`SYNC EBS PO IMPORT (${id}) FAILED: NOT FOUND`);
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (!STATUS_SYNC_PURCHASED_ORDER_IMPORT_TO_EBS.includes(order.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.BAD_REQUEST'),
      ).toResponse();
    }

    if (status !== ResponseCodeEnum.SUCCESS) {
      order.syncStatus = StatusSyncOrderToEbsEnum.SYNC_WSO2_ERROR;
      await this.purchasedOrderImportRepository.create(order);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    if (order.ebsId) {
      order.ebsId = ebsId;
      await this.purchasedOrderImportRepository.create(order);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const serializeItem: any = await this.itemService.getItemsInfo(
      uniq(map(order.purchasedOrderImportDetails, 'itemId')),
      true,
    );

    const warehouses = await this.warehouseService.getWarehouses([
      order.warehouseId,
    ]);

    const purchasedOrderImportWarehouseLots =
      order.purchasedOrderImportWarehouseLots;

    if (
      warehouses[0].manageByLot === WarehouseByLotManagementEnum.LOT &&
      purchasedOrderImportWarehouseLots.length !== item.length
    ) {
      this.logger.error(
        'SYNC_EBS_PO_IMPORT_FAILED: NOT FOUND ITEM LOT',
        JSON.stringify(item),
        JSON.stringify(purchasedOrderImportWarehouseLots),
      );
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const toUpdateWarehouseItemLots = [];
    const toUpdateItemDetails = [];
    const toUpdateItemStockWarehousePrices = [];
    for (let i = 0; i < item.length; i++) {
      const element = item[i];
      const itemLot = find(
        purchasedOrderImportWarehouseLots,
        (detailLot) =>
          (detailLot.lotNumber?.toUpperCase() || '') ==
            (element.lotWMS?.toUpperCase() || '') &&
          serializeItem[detailLot.itemId]?.code.toUpperCase() ==
            element.code.toUpperCase(),
      );
      if (isEmpty(itemLot)) {
        this.logger.error(
          'SYNC_EBS_PO_IMPORT_FAILED: NOT FOUND ITEM LOT',
          JSON.stringify(request),
          JSON.stringify(element),
        );
        return new ApiError(
          ResponseCodeEnum.INTERNAL_SERVER_ERROR,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }
      const itemDetail = find(
        order.purchasedOrderImportDetails,
        (orderDetail) => itemLot.itemId === orderDetail.itemId,
      );
      if (isEmpty(itemDetail)) {
        this.logger.error(
          'SYNC_EBS_PO_IMPORT_FAILED: NOT FOUND ITEM',
          JSON.stringify(request),
          JSON.stringify(element),
        );
        return new ApiError(
          ResponseCodeEnum.INTERNAL_SERVER_ERROR,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }
      itemDetail.debitAccount = element.debt;
      itemDetail.creditAccount = element.credit;
      itemLot.debitAccount = element.debt;
      itemLot.creditAccount = element.credit;

      itemLot.lotNumber = element.lot ? element.lot : element.lotWMS || null;
      toUpdateItemDetails.push(itemDetail);
      toUpdateWarehouseItemLots.push(itemLot);
      toUpdateItemStockWarehousePrices.push({
        itemId: itemLot.itemId,
        lotNumber: element.lotWMS,
        lotEBS: element.lot,
        warehouseId: order.warehouseId,
        quantity: itemLot.actualQuantity,
        totalPrice: itemLot.amount,
      });
    }
    toUpdateItemDetails.forEach((item) => {
      const lots = toUpdateWarehouseItemLots.filter(
        (lot) => lot.itemId === item.itemId,
      );
      const amount = lots.reduce(
        (amount, prev) => plus(amount, prev.amount),
        0,
      );
      item.amount = amount <= 0 ? 0 : amount.toFixed(2);
      const price = div(item.amount, item.receivedQuantity);
      item.price = price <= 0 ? 0 : price.toFixed(2);
    });

    order.ebsId = ebsId;
    order.syncStatus = StatusSyncOrderToEbsEnum.COMPLETED;
    if (receipt) {
      order.receiptNumberEbs = receipt;
    }
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();

    try {
      const itemStockWarehousePrice =
        await this.itemService.updateItemStockWarehousePriceEbsIn(
          toUpdateItemStockWarehousePrices,
          OrderTypeEnum.Import,
          id,
          SaleOrderTypeEnum.PO,
        );
      if (itemStockWarehousePrice.statusCode !== ResponseCodeEnum.SUCCESS)
        throw (
          itemStockWarehousePrice.message ||
          (await this.i18n.translate('error.INTERNAL_ERROR'))
        );
      await queryRunner.manager.save(toUpdateItemDetails);
      await queryRunner.manager.save(toUpdateWarehouseItemLots);
      await queryRunner.manager.save(order);
      await queryRunner.commitTransaction();
    } catch (e) {
      this.logger.error('SYNC_EBS_PO_IMPORT_FAILED:', JSON.stringify(e));
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.INTERNAL_ERROR'),
      );
    } finally {
      await queryRunner.release();
    }
    this.eventEmitter.emit(EventSyncPoImportEnum.Update, order.id);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async syncOrderToEbs(
    id: number,
    userId: number,
    isUpdateHeader = false,
  ): Promise<any> {
    const order =
      await this.purchasedOrderImportRepository.findOneWithRelations({
        where: {
          id: id,
        },
        relations: [
          'purchasedOrderImportWarehouseLots',
          'purchasedOrderImportDetails',
          'purchasedOrderImportReceive',
        ],
      });

    if (isEmpty(order)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const itemIds = map(order.purchasedOrderImportDetails, 'itemId');

    const [
      items,
      warehouses,
      reason,
      source,
      departmentReceipt,
      businessType,
      serializeUser,
    ] = await Promise.all([
      this.itemService.getItems(itemIds),
      this.warehouseService.getWarehouses([order.warehouseId]),
      order.reasonId
        ? this.reasonRepository.findOneById(order.reasonId)
        : ({} as any),
      order.sourceId
        ? this.sourceRepository.findOneById(order.sourceId)
        : ({} as any),
      order.departmentReceiptId
        ? this.userService.getDepartmentReceiptById(order.departmentReceiptId)
        : ({} as any),
      this.warehouseService.getBusinessTypeDetail(
        order.businessTypeId,
        id,
        SaleOrderTypeEnum.PO,
      ),
      this.userService.getUsers(
        compact([
          order.confirmerId,
          userId,
          order?.purchasedOrderImportReceive?.createdBy,
        ]),
        true,
      ),
    ]);
    const warehouse = first(warehouses);
    const serializeItem = keyBy(items, 'itemId');
    const attributes = businessType.bussinessTypeAttributes;

    let attributeDetailValues = {} as any;
    if (!isEmpty(attributes)) {
      const attributeGroup = groupBy(attributes, 'tableName');
      const payload = new GetAttributeDetailValuesRequestDto();
      const attributeKeys = Object.keys(attributeGroup).filter(
        (el) => !el.match('null'),
      );
      payload.filter = attributeKeys.map((key) => {
        return {
          tableName: key,
          id: map(attributeGroup[key], 'value').join(','),
        };
      });
      attributeDetailValues =
        await this.warehouseService?.getAttributeDetailValuesTcp(payload);
    }
    const construction = first(attributeDetailValues?.constructions);
    const costType = first(attributeDetailValues?.cost_types);
    const organizationPayment = first(
      attributeDetailValues?.organization_payments,
    );
    const categoryConstruction = first(
      attributeDetailValues?.category_constructions,
    );
    const receipt = first(attributeDetailValues?.receipts);

    const headers = [
      {
        key: 'Transaction.Number order',
        title: 'Transaction.Number order',
      },
      {
        key: 'IDWMS',
        title: 'IDWMS',
      },
      {
        key: 'Organizations.Code',
        title: 'Organizations.Code',
      },
      {
        key: 'Organizations.Name',
        title: 'Organizations.Name',
      },
      {
        key: 'Transaction.Date',
        title: 'Transaction.Date',
      },
      {
        key: 'Transaction.Type',
        title: 'Transaction.Type',
      },
      {
        key: 'Transaction.Source',
        title: 'Transaction.Source',
      },
      {
        key: 'Transaction.Reason',
        title: 'Transaction.Reason',
      },
      {
        key: 'Transaction.Number',
        title: 'Transaction.Number',
      },
      {
        key: 'Transaction.Reference',
        title: 'Transaction.Reference',
      },
      {
        key: 'Transaction.Transaction history.Number',
        title: 'Transaction.Transaction history.Number',
      },
      {
        key: 'Transaction.Transaction history.Value',
        title: 'Transaction.Transaction history.Value',
      },
      {
        key: 'Transaction.Transaction history.Context Value',
        title: 'Transaction.Transaction history.Context Value',
      },
      {
        key: 'Transaction.Transaction history.Deliverer',
        title: 'Transaction.Transaction history.Deliverer',
      },
      {
        key: 'Transaction.Transaction history.Transact Number',
        title: 'Transaction.Transaction history.Transact Number',
      },
      {
        key: 'Transaction.Transaction history.Department receipt',
        title: 'Transaction.Transaction history.Department receipt',
      },
      {
        key: 'Transaction.Transaction history.Org Transact',
        title: 'Transaction.Transaction history.Org Transact',
      },
      {
        key: 'Transaction.Transaction history.Contractors',
        title: 'Transaction.Transaction history.Contractors',
      },
      {
        key: 'Transaction.Transaction history.FMIS Number',
        title: 'Transaction.Transaction history.FMIS Number',
      },
      {
        key: 'Transaction.Transaction history.Supplier',
        title: 'Transaction.Transaction history.Supplier',
      },
      {
        key: 'Transaction.Transaction history.Address',
        title: 'Transaction.Transaction history.Address',
      },
      {
        key: 'Transaction.Transaction history.Project',
        title: 'Transaction.Transaction history.Project',
      },
      {
        key: 'Transaction.Transaction history.Receiver',
        title: 'Transaction.Transaction history.Receiver',
      },
      {
        key: 'Transaction.Transaction history.Receiving/Adjust Number',
        title: 'Transaction.Transaction history.Receiving/Adjust Number',
      },
      {
        key: 'Transaction Lines.Item',
        title: 'Transaction Lines.Item',
      },
      {
        key: 'Transaction Lines.PO Number',
        title: 'Transaction Lines.PO Number',
      },
      {
        key: 'Transaction Lines.Subinventory',
        title: 'Transaction Lines.Subinventory',
      },
      {
        key: 'Transaction Lines.Issue Number',
        title: 'Transaction Lines.Issue Number',
      },
      {
        key: 'Transaction Lines.Quantity',
        title: 'Transaction Lines.Quantity',
      },
      {
        key: 'Transaction Lines.Total Line Amount',
        title: 'Transaction Lines.Total Line Amount',
      },
      {
        key: 'Transaction Lines.Location',
        title: 'Transaction Lines.Location',
      },
      {
        key: 'Transaction Lines.Reason',
        title: 'Transaction Lines.Reason',
      },
      {
        key: 'Transaction Lines.Reference',
        title: 'Transaction Lines.Reference',
      },
      {
        key: 'Transaction Lines.Source Project',
        title: 'Transaction Lines.Source Project',
      },
      {
        key: 'Transaction Lines.Source Task',
        title: 'Transaction Lines.Source Task',
      },
      {
        key: 'Transaction Lines.Expenditure Type',
        title: 'Transaction Lines.Expenditure Type',
      },
      {
        key: 'Transaction Lines.Expenditure Org',
        title: 'Transaction Lines.Expenditure Org',
      },
      {
        key: 'Transaction Lines.Lot',
        title: 'Transaction Lines.Lot',
      },
      {
        key: 'Transaction Lines.Number',
        title: 'Transaction Lines.Number',
      },
      {
        key: 'Transaction Lines.Value',
        title: 'Transaction Lines.Value',
      },
      {
        key: 'Transaction Lines.Context Value',
        title: 'Transaction Lines.Context Value',
      },
      {
        key: 'Transaction Lines.Deliverer',
        title: 'Transaction Lines.Deliverer',
      },
      {
        key: 'Transaction Lines.Transact Number',
        title: 'Transaction Lines.Transact Number',
      },
      {
        key: 'Transaction Lines.Department receipt',
        title: 'Transaction Lines.Department receipt',
      },
      {
        key: 'Transaction Lines.Org Transact',
        title: 'Transaction Lines.Org Transact',
      },
      {
        key: 'Transaction Lines.Contractors',
        title: 'Transaction Lines.Contractors',
      },
      {
        key: 'Transaction Lines.FMIS Number',
        title: 'Transaction Lines.FMIS Number',
      },
      {
        key: 'Transaction Lines.Supplier',
        title: 'Transaction Lines.Supplier',
      },
      {
        key: 'Transaction Lines.Address',
        title: 'Transaction Lines.Address',
      },
      {
        key: 'Transaction Lines.Project',
        title: 'Transaction Lines.Project',
      },
      {
        key: 'Transaction Lines.Receiver',
        title: 'Transaction Lines.Receiver',
      },
      {
        key: 'Transaction Lines.Receiving/Adjust Number',
        title: 'Transaction Lines.Receiving/Adjust Number',
      },
      {
        key: 'Username_create',
        title: 'Username_create',
      },
      {
        key: 'Username_inbound',
        title: 'Username_inbound',
      },
      {
        key: 'Username_complete',
        title: 'Username_complete',
      },
      {
        key: 'Receipt Header.Receipt',
        title: 'Receipt Header.Receipt',
      },
      {
        key: 'Receipt Header.Receipt Date',
        title: 'Receipt Header.Receipt Date',
      },
      {
        key: 'Receipt Header.Shipment',
        title: 'Receipt Header.Shipment',
      },
      {
        key: 'Receipt Header.Shipped Date',
        title: 'Receipt Header.Shipped Date',
      },
      {
        key: 'Receipt Header.Packing Slip',
        title: 'Receipt Header.Packing Slip',
      },
      {
        key: 'Receipt Header.Waybill/Airbill',
        title: 'Receipt Header.Waybill/Airbill',
      },
      {
        key: 'Receipt Header.Freight Carrier',
        title: 'Receipt Header.Freight Carrier',
      },
      {
        key: 'Receipt Header.Bill of Lading',
        title: 'Receipt Header.Bill of Lading',
      },
      {
        key: 'Receipt Header.Containers',
        title: 'Receipt Header.Containers',
      },
      {
        key: 'Receipt Header.Received By',
        title: 'Receipt Header.Received By',
      },
      {
        key: 'Receipt Header.Supplier',
        title: 'Receipt Header.Supplier',
      },
      {
        key: 'Receipt Header.Comments',
        title: 'Receipt Header.Comments',
      },
      {
        key: 'Receipt .Order Type',
        title: 'Receipt .Order Type',
      },
      {
        key: 'Receipt .Order',
        title: 'Receipt .Order',
      },
      {
        key: 'Receipt .Receiving Number',
        title: 'Receipt .Receiving Number',
      },
      {
        key: 'Receipt .Operating Unit',
        title: 'Receipt .Operating Unit',
      },
      {
        key: 'Receipt .Destination',
        title: 'Receipt .Destination',
      },
      {
        key: 'Receipt .DueDate',
        title: 'Receipt .DueDate',
      },
      {
        key: 'Receipt .Comments',
        title: 'Receipt .Comments',
      },
      {
        key: 'Receipt .Supplier',
        title: 'Receipt .Supplier',
      },
      {
        key: 'Receipt .Hazard',
        title: 'Receipt .Hazard',
      },
      {
        key: 'Receipt .Header Receiver Note',
        title: 'Receipt .Header Receiver Note',
      },
      {
        key: 'Receipt .Header Shipment Receiver Note',
        title: 'Receipt .Header Shipment Receiver Note',
      },
      {
        key: 'Receipt .UN Number',
        title: 'Receipt .UN Number',
      },
      {
        key: 'Receipt .Routing',
        title: 'Receipt .Routing',
      },
      {
        key: 'Receipt Lines.Item',
        title: 'Receipt Lines.Item',
      },
      {
        key: 'Receipt Lines.Destination Type',
        title: 'Receipt Lines.Destination Type',
      },
      {
        key: 'Receipt Lines.Quantity',
        title: 'Receipt Lines.Quantity',
      },
      {
        key: 'Receipt Lines.Descsiption',
        title: 'Receipt Lines.Descsiption',
      },
      {
        key: 'Receipt Lines.Rev',
        title: 'Receipt Lines.Rev',
      },
    ];

    const serializeAttribute = keyBy(attributes, 'ebsLabel');
    const serializeValueAttributeTable = {};
    Object.keys(attributeDetailValues)?.forEach((tableName) => {
      serializeValueAttributeTable[tableName] = keyBy(
        attributeDetailValues[tableName],
        'id',
      );
    });

    const accountIdentifier = [
      source?.companyCode,
      source?.branchCode,
      source?.costCenterCode,
      source?.accountant,
      source?.produceTypeCode,
      source?.productCode,
      source?.factorialCode,
      source?.internalDepartmentCode,
      source?.departmentBackupCode,
      source?.EVNBackupCode,
    ].join(CODE_DELIMITER);

    const sourceMap = {};

    order.purchasedOrderImportWarehouseLots.forEach((item) => {
      if (!accountIdentifier.includes(item.creditAccount)) {
        const creditAccount =
          item.creditAccount.split('.').length ===
          NUMBER_OF_CREDIT_ACCOUNT_SEGMENTS
            ? item.creditAccount.split('.').splice(3, 4).join(CODE_DELIMITER)
            : [
                item.creditAccount,
                source.produceTypeCode,
                source.productCode,
                source.factorialCode,
              ].join(CODE_DELIMITER);
        sourceMap[`${item.itemId}_${item.lotNumber}`] = `${source?.code}--${[
          source.companyCode,
          source.branchCode,
          source.costCenterCode,
          creditAccount,
          source.internalDepartmentCode,
          source.departmentBackupCode,
          source.EVNBackupCode,
        ].join(CODE_DELIMITER)}`;
      }
    });

    const data = orderBy(
      order.purchasedOrderImportWarehouseLots,
      ['itemId', 'lotNumber', 'quantity'],
      ['asc', 'asc', 'asc'],
    ).map((ordeDetail, index) => {
      return {
        'Transaction.Number order': plus(index, 1),
        IDWMS: order.id,
        'Organizations.Code': warehouse?.code || '',
        'Organizations.Name': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Organizations.Name',
        ),
        'Transaction.Date':
          Moment(order.receiptDate).format('DD/MM/YYYY HH:mm:ss') || '',
        'Transaction.Type': businessType.name || '',
        'Transaction.Source':
          (has(sourceMap, `${ordeDetail.itemId}_${ordeDetail.lotNumber}`)
            ? sourceMap[`${ordeDetail.itemId}_${ordeDetail.lotNumber}`]
            : source?.code) || '',
        'Transaction.Reason': reason?.code || '',
        'Transaction.Number':
          !isEmpty(order.ebsId) && order.oldEbsId
            ? `${order.ebsId}-${order.oldEbsId}`
            : this.getValueEbsLabel(
                serializeAttribute,
                serializeValueAttributeTable,
                'Transaction.Number',
              ),
        'Transaction.Reference': order.explanation,
        'Transaction.Transaction history.Number': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction.Transaction history.Number',
        ),
        'Transaction.Transaction history.Value': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction.Transaction history.Value',
        ),
        'Transaction.Transaction history.Context Value':
          'Receipt Transaction info',
        'Transaction.Transaction history.Deliverer': order.deliver || '',
        'Transaction.Transaction history.Transact Number':
          this.getValueEbsLabel(
            serializeAttribute,
            serializeValueAttributeTable,
            'Transaction.Transaction history.Transact Number',
          ),
        'Transaction.Transaction history.Department receipt':
          departmentReceipt?.name || '',
        'Transaction.Transaction history.Org Transact': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction.Transaction history.Org Transact',
        ),
        'Transaction.Transaction history.Contractors': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction.Transaction history.Contractors',
        ),
        'Transaction.Transaction history.FMIS Number': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction.Transaction history.FMIS Number',
        ),
        'Transaction.Transaction history.Supplier': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction.Transaction history.Supplier',
        ),
        'Transaction.Transaction history.Address': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction.Transaction history.Address',
        ),
        'Transaction.Transaction history.Project': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction.Transaction history.Project',
        ),
        'Transaction.Transaction history.Receiver': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction.Transaction history.Receiver',
        ),
        'Transaction.Transaction history.Receiving/Adjust Number':
          this.getValueEbsLabel(
            serializeAttribute,
            serializeValueAttributeTable,
            'Transaction.Transaction history.Receiving/Adjust Number',
          ),
        'Transaction Lines.Item': serializeItem[ordeDetail.itemId]?.code || '',
        'Transaction Lines.PO Number': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction Lines.PO Number',
        ),
        'Transaction Lines.Subinventory': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction Lines.Subinventory',
        ),
        'Transaction Lines.Issue Number': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction Lines.Issue Number',
        ),
        'Transaction Lines.Quantity': ordeDetail.actualQuantity || 0,
        'Transaction Lines.Total Line Amount': ordeDetail.amount || 0,
        'Transaction Lines.Location': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction Lines.Location',
        ),
        'Transaction Lines.Reason': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction Lines.Reason',
        ),
        'Transaction Lines.Reference': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction Lines.Reference',
        ),
        'Transaction Lines.Source Project': construction?.code || '',
        'Transaction Lines.Source Task': categoryConstruction?.code || '',
        'Transaction Lines.Expenditure Type': costType?.code,
        'Transaction Lines.Expenditure Org': organizationPayment?.name,
        'Transaction Lines.Lot': ordeDetail.lotNumber || '',
        'Transaction Lines.Number': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction Lines.Number',
        ),
        'Transaction Lines.Value': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction Lines.Value',
        ),
        'Transaction Lines.Context Value': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction Lines.Context Value',
        ),
        'Transaction Lines.Deliverer': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction Lines.Deliverer',
        ),
        'Transaction Lines.Transact Number': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction Lines.Transact Number',
        ),
        'Transaction Lines.Department receipt': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction Lines.Department receipt',
        ),
        'Transaction Lines.Org Transact': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction Lines.Org Transact',
        ),
        'Transaction Lines.Contractors': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction Lines.Contractors',
        ),
        'Transaction Lines.FMIS Number': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction Lines.FMIS Number',
        ),
        'Transaction Lines.Supplier': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction Lines.Supplier',
        ),
        'Transaction Lines.Address': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction Lines.Address',
        ),
        'Transaction Lines.Project': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction Lines.Project',
        ),
        'Transaction Lines.Receiver': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction Lines.Receiver',
        ),
        'Transaction Lines.Receiving/Adjust Number': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Transaction Lines.Receiving/Adjust Number',
        ),
        Username_create: serializeUser[order.confirmerId]?.username || '',
        Username_inbound:
          serializeUser[order.purchasedOrderImportReceive?.createdBy]
            ?.username || '',
        Username_complete: serializeUser[userId]?.username || '',
        'Receipt Header.Receipt': receipt?.receiptNumber,
        'Receipt Header.Receipt Date': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt Header.Receipt Date',
        ),
        'Receipt Header.Shipment': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt Header.Shipment',
        ),
        'Receipt Header.Shipped Date': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt Header.Shipped Date',
        ),
        'Receipt Header.Packing Slip': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt Header.Packing Slip',
        ),
        'Receipt Header.Waybill/Airbill': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt Header.Waybill/Airbill',
        ),
        'Receipt Header.Freight Carrier': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt Header.Freight Carrier',
        ),
        'Receipt Header.Bill of Lading': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt Header.Bill of Lading',
        ),
        'Receipt Header.Containers': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt Header.Containers',
        ),
        'Receipt Header.Received By': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt Header.Received By',
        ),
        'Receipt Header.Supplier': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt Header.Supplier',
        ),
        'Receipt Header.Comments': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt Header.Comments',
        ),
        'Receipt .Order Type': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt .Order Type',
        ),
        'Receipt .Order': order?.contractNumber || '',
        'Receipt .Receiving Number': receipt?.code || '',
        'Receipt .Operating Unit': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt .Operating Unit',
        ),
        'Receipt .Destination': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt .Destination',
        ),
        'Receipt .DueDate': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt .DueDate',
        ),
        'Receipt .Comments': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt .Comments',
        ),
        'Receipt .Supplier': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt .Supplier',
        ),
        'Receipt .Hazard': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt .Hazard',
        ),
        'Receipt .Header Receiver Note': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt .Header Receiver Note',
        ),
        'Receipt .Header Shipment Receiver Note': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt .Header Shipment Receiver Note',
        ),
        'Receipt .UN Number': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt .UN Number',
        ),
        'Receipt .Routing': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt .Routing',
        ),
        'Receipt Lines.Item': serializeItem[ordeDetail.itemId]?.code || '',
        'Receipt Lines.Destination Type': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt Lines.Destination Type',
        ),
        'Receipt Lines.Quantity': ordeDetail.receivedQuantity || 0,
        'Receipt Lines.Descsiption': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt Lines.Descsiption',
        ),
        'Receipt Lines.Rev': this.getValueEbsLabel(
          serializeAttribute,
          serializeValueAttributeTable,
          'Receipt Lines.Rev',
        ),
      };
    });
    return await this.syncDataService.syncPoImportToEbs(
      order.id,
      data,
      headers,
      isUpdateHeader,
    );
  }

  private getValueEbsLabel(
    serializeAttribute: object,
    serializeValueAttributeTable: object,
    ebsLabel: string,
  ) {
    try {
      if (!has(serializeAttribute, ebsLabel)) {
        return '';
      }
      if (
        serializeAttribute[ebsLabel]?.tableName &&
        serializeAttribute[ebsLabel]?.value
      ) {
        const attribute = serializeAttribute[ebsLabel];
        if (has(serializeValueAttributeTable, attribute.tableName)) {
          return (
            serializeValueAttributeTable[attribute.tableName][attribute.value][
              MAPPING_MASTER_DATA_BUSSINESS_TYPE[attribute.tableName]
            ] ?? ''
          );
        } else {
          return '';
        }
      }

      if (
        serializeAttribute[ebsLabel].type === TypeBussinessAttributeEnum.DATE
      ) {
        return serializeAttribute[ebsLabel]?.value
          ? Moment(serializeAttribute[ebsLabel]?.value).format(
              'DD/MM/YYYY HH:mm:ss',
            )
          : '';
      }
      return serializeAttribute[ebsLabel]?.value;
    } catch (error) {
      console.log(error);
      return '';
    }
  }

  async createPoImportAutoComplete(
    request: CreatePurchasedOrderImportAutoCompleteDto,
  ): Promise<any> {
    let poimp;
    try {
      const {
        sourceCode,
        warehouseCode,
        departmentReceiptName,
        reasonCode,
        vendorCode,
        categoryConstructionCode,
        constructionCode,
        costTypeCode,
        organizationPaymentName,
        items,
        ebsId,
        receipt,
        username,
      } = request;

      const attributes = [];
      let businessTypeCode;

      if (
        !isEmpty(categoryConstructionCode) &&
        !isEmpty(constructionCode) &&
        !isEmpty(costTypeCode) &&
        !isEmpty(organizationPaymentName)
      ) {
        const [
          construction,
          categoryConstruction,
          costType,
          organizationPayment,
        ] = await Promise.all([
          this.constructionRepository.findOneByCondition({
            code: constructionCode,
          }),
          this.categoryContructionRepository.findOneByCondition({
            code: categoryConstructionCode,
          }),
          this.costTypeRepository.findOneByCondition({
            code: costTypeCode,
          }),
          this.organizationPaymentRepository.findOneByCondition({
            name: organizationPaymentName,
          }),
        ]);
        businessTypeCode = BUSINESS_TYPE.N0003;
        attributes.push(
          {
            id: null,
            value: construction?.id?.toString(),
            table: BUSINESS_TYPE_ATTRIBUTE_TABLE_NAME.CONSTRUCTIONS,
          },
          {
            id: null,
            value: categoryConstruction?.id?.toString(),
            table: BUSINESS_TYPE_ATTRIBUTE_TABLE_NAME.CATEGORY_CONSTRUCTIONS,
          },
          {
            id: null,
            value: costType?.id?.toString(),
            table: BUSINESS_TYPE_ATTRIBUTE_TABLE_NAME.COST_TYPES,
          },
          {
            id: null,
            value: organizationPayment?.id?.toString(),
            table: BUSINESS_TYPE_ATTRIBUTE_TABLE_NAME.ORGANIZATION_PAYMENTS,
          },
        );

        if (isEmpty(construction)) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.NOT_FOUND)
            .withMessage(
              await this.i18n.translate('error.CONSTRUCTION_NOTFOUND'),
            )
            .build();
        }

        if (
          isEmpty(categoryConstruction) ||
          categoryConstruction?.constructionId !== construction?.id
        ) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.NOT_FOUND)
            .withMessage(
              await this.i18n.translate('error.CATEGORY_CONSTRUCTION_NOTFOUND'),
            )
            .build();
        }

        if (isEmpty(costType)) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.NOT_FOUND)
            .withMessage(await this.i18n.translate('error.COST_TYPE_NOTFOUND'))
            .build();
        }

        if (isEmpty(organizationPayment)) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.NOT_FOUND)
            .withMessage(
              await this.i18n.translate('error.ORIGANIZATION_PAYMENT_NOTFOUND'),
            )
            .build();
        }
      } else if (
        isEmpty(categoryConstructionCode) &&
        isEmpty(constructionCode) &&
        isEmpty(costTypeCode) &&
        isEmpty(organizationPaymentName)
      ) {
        businessTypeCode = BUSINESS_TYPE.N0002;
      } else {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.BUSINESS_TYPE_N0003_ERROR'),
          )
          .build();
      }

      const [businessType, warehouse, reason, vendor, user] = await Promise.all(
        [
          this.warehouseService.getBusinessByCode(businessTypeCode),
          this.warehouseService.getWarehouseByCodes([warehouseCode]),
          this.reasonRepository.findOneWithRelations({
            where: { code: reasonCode },
          }),
          this.vendorRepository.findOneWithRelations({
            where: { code: vendorCode ? vendorCode : IsNull() },
          }),
          this.userService.getUserByUsername(username),
        ],
      );

      let departmentReceipt = null;

      if (departmentReceiptName) {
        departmentReceipt =
          await this.userService.getDepartmentReceiptByCodeOrName(
            departmentReceiptName,
          );

        if (isEmpty(departmentReceipt)) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.NOT_FOUND)
            .withMessage(
              await this.i18n.translate('error.DEPARTMENT_RECEIPT_NOT_FOUND'),
            )
            .build();
        }
      }

      const isWarehouseOfUser = await this.validateWarehouseIsOfUser(
        user.id,
        warehouse[0].id,
      );

      if (!isWarehouseOfUser) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.WAREHOUSE_NOT_MANAGER_BY_USER'),
          )
          .build();
      }

      const bussinessTypeAttributesMap = keyBy(
        businessType.bussinessTypeAttributes,
        'tableName',
      );

      if (isEmpty(warehouse)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.WAREHOUSE_CODE_NOT_EXIST'),
          )
          .build();
      }

      if (isEmpty(reason)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.REASON_NOTFOUND'))
          .build();
      }

      if (isEmpty(vendor) && !isEmpty(vendorCode)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.VENDOR_CODE_NOT_EXIST'))
          .build();
      } else {
        attributes.push({
          id: bussinessTypeAttributesMap[
            BUSINESS_TYPE_ATTRIBUTE_TABLE_NAME.VENDORS
          ]?.id,
          value: `${vendor?.id}`,
          table: BUSINESS_TYPE_ATTRIBUTE_TABLE_NAME.VENDORS,
        });
      }

      if (isEmpty(user)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.USER_NOT_FOUND'))
          .build();
      }

      const source = await this.sourceRepository.findOneByCondition({
        code: sourceCode,
        warehouseId: warehouse[0].id,
      });

      if (!source) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.SOURCE_NOT_FOUND'))
          .build();
      }

      if (source.status === SourceStatusEnum.INACTIVE) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.SOURCE_NOT_ACTIVE'))
          .build();
      }

      if (source.warehouseId !== warehouse[0].id) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.SOURCE_NOT_MAP_WITH_WAREHOUSE'),
          )
          .build();
      }

      const codes = map(items, 'code');
      const itemByCodes = await this.itemService.getItemByCodes(codes);
      const itemMap = keyBy(itemByCodes, 'code');
      const requestItems = [];
      for (let i = 0; i < items.length; i++) {
        const item = items[i];

        if (item.quantity && item.quantity != item.actualQuantity) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.NOT_FOUND)
            .withMessage(
              await this.i18n.translate(
                'error.PLAN_QUANTITY_OTHER_ACTUAL_QUANTTIY',
              ),
            )
            .build();
        }

        item.quantity = item.quantity ? item.quantity : item.actualQuantity;
        item.id = itemMap[item.code].id;
        item.warehouseId = warehouse[0].id;
        requestItems.push(item);
        if (i == POIMP_ITEMS.LENGTH) break;
      }

      const requestPoimp = {
        ...request,
        warehouseId: warehouse[0].id,
        sourceId: source.id,
        departmentReceiptId: departmentReceipt?.id,
        reasonId: reason.id,
        businessTypeId: businessType.id,
        userId: user.id,
        items: requestItems,
        attributes: attributes.map((item) => {
          return {
            ...item,
            id: bussinessTypeAttributesMap[item.table].id,
          };
        }),
      };

      // tạo poimp
      const resCreatePoImport = await this.createPoImport(requestPoimp, true);
      poimp = resCreatePoImport.data;

      if (resCreatePoImport.statusCode !== ResponseCodeEnum.SUCCESS) {
        this.logger.error(
          'POIMP_AUTO_COMPLETE_ERROR: create poimp error',
          JSON.stringify(request),
        );
        throw resCreatePoImport?.message;
      }

      // confirm poimp
      const confirmRequest = new SetOrderStatusRequestDto();
      confirmRequest.id = poimp.id;
      confirmRequest.userId = user.id;
      const resConfirm = await this.confirm(confirmRequest);

      if (resConfirm.statusCode !== ResponseCodeEnum.SUCCESS) {
        this.logger.error('POIMP_AUTO_COMPLETE_ERROR: confirm poimp error');
        throw resConfirm?.messsage;
      }

      // suggest vị trí
      const locatorVirtualByWarehouse =
        await this.warehouseLayoutService.getLocatorVirtualByWarehouseId(
          poimp.warehouseId,
        );

      const conditionSuggestLocators = [];
      poimp.purchasedOrderImportWarehouseLots.forEach((item) => {
        conditionSuggestLocators.push({
          itemId: item.itemId,
          lotNumber: item.lotNumber,
          warehouseId: item.warehouseId,
          locatorVirtualId: locatorVirtualByWarehouse.locatorId,
        });
      });

      const suggestLocators =
        await this.itemService.suggestLocatorPoimpAutoComplete(
          conditionSuggestLocators,
        );
      const suggestLocatorMap = {};
      for (let i = 0; i < suggestLocators.length; i++) {
        const suggestLocator = suggestLocators[i];
        const key = `${suggestLocator.itemId}-${
          suggestLocator.lotNumber || ''
        }-${suggestLocator.warehouseId}`;
        if (isEmpty(suggestLocatorMap[key])) {
          suggestLocatorMap[key] = suggestLocator;
        }
      }

      // nhập kho
      const warehouseImportRequest = new WarehouseImportDto();
      Object.assign(warehouseImportRequest, {
        ...warehouseImportRequest,
        autoCreateReceive: AUTO_CREATE_RECEIVE.YES,
        userId: user.id,
        movementType: WarehouseMovementTypeEnum.PO_IMPORT,
        orderId: poimp.id,
        warehouseId: warehouse[0].id,
        items: poimp.purchasedOrderImportWarehouseLots.map((item) => {
          const key = `${item.itemId}-${item.lotNumber || ''}-${
            item.warehouseId
          }`;
          return {
            id: item.itemId,
            lotNumber: item.lotNumber,
            locations: [
              {
                locatorId:
                  suggestLocatorMap[key]?.locatorId ||
                  locatorVirtualByWarehouse.locatorId,
                quantity: item.quantity,
              },
            ],
          };
        }),
      });

      const resWarehouseImport = await this.warehouseService.warehouseImport(
        warehouseImportRequest,
      );

      if (resWarehouseImport.statusCode !== ResponseCodeEnum.SUCCESS) {
        this.logger.error('POIMP_AUTO_COMPLETE_ERROR: warehouse import error');
        throw resWarehouseImport?.message;
      }

      // async ebs-in
      const ebsInPOImportRequest = new EbsInPOImportRequestDto();
      const resPoimpEbsIn = await this.syncEbsInput({
        ...ebsInPOImportRequest,
        id: poimp.id,
        status: ResponseCodeEnum.SUCCESS,
        receipt: receipt,
        ebsId: ebsId,
        item: requestItems.map((item) => {
          return {
            code: item.code,
            lot: item.lotNumber,
            lotWMS: item.lotNumber,
            costOfGoods: item.amount,
            debt: item.debitAccount,
            credit: item.creditAccount,
          };
        }),
      });

      if (resPoimpEbsIn.statusCode !== ResponseCodeEnum.SUCCESS) {
        this.logger.error('POIMP_AUTO_COMPLETE_ERROR: ebs in error');
        throw resPoimpEbsIn?.message;
      }

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(
          error?.message ||
            error ||
            (await this.i18n.translate('error.INTERNAL_SERVER_ERROR')),
        )
        .build();
    }
  }

  async getListOpenTransaction(
    request: GetListOpenTransactionRequestDto,
  ): Promise<any> {
    const configService = new ConfigService();
    const defaultTimeZone = configService.get('defaultTimeZone');
    const data =
      await this.purchasedOrderImportRepository.getListOpenTransaction(
        request,
        defaultTimeZone,
      );

    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  genLotNumberPoimpNext(lotNumberLastest: string): string {
    if (isEmpty(lotNumberLastest)) {
      return `${POIMP_LOT.PREFIX}0001`;
    }
    let num = +lotNumberLastest.slice(2);
    num++;
    if (num <= POIMP_LOT.SUFFIX_4) {
      return (
        `${POIMP_LOT.PREFIX}` + `${POIMP_LOT.SUFFIX_CUSTOM + num}`.slice(1)
      );
    }

    return `${POIMP_LOT.PREFIX}${num}`;
  }
}
