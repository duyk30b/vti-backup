import { OrderStatusEnum, StatusSyncOrderToEbsEnum } from '@constant/common';

export const PO_IMPORT_STATUS_CAN_COMPLETED_PO = [
  OrderStatusEnum.Reject,
  OrderStatusEnum.Completed,
  OrderStatusEnum.Pending,
];

export const PO_IMPORT_CODE_PREFIX = 'N';
export const POIMP_LOT = {
  PREFIX: 'WL',
  SUFFIX_4: 9999,
  SUFFIX_CUSTOM: 10000,
};

export const PO_IMPORT_RULES = {
  DELIVER: {
    MAX_LENGTH: 255,
  },
  EXPLAINATION: {
    MAX_LENGTH: 255,
  },
  LOT_NUMBER: {
    MAX_LENGTH: 10,
  },
  DEBIT_ACCOUNT: {
    MAX_LENGTH: 255,
  },
  CREDIT_ACCOUNT: {
    MAX_LENGTH: 255,
  },
};
export const STATUS_PURCHASED_ORDER_IMPORT_DASHBOARD = [
  OrderStatusEnum.Confirmed,
  OrderStatusEnum.Completed,
  OrderStatusEnum.Stored,
  OrderStatusEnum.Received,
  OrderStatusEnum.InProgress,
];

export const STATUS_SYNC_PURCHASED_ORDER_IMPORT: number[] = [
  OrderStatusEnum.Completed,
];

export const STATUS_SYNC_PURCHASED_ORDER_IMPORT_TO_EBS: number[] = [
  OrderStatusEnum.Completed,
  OrderStatusEnum.Stored,
  OrderStatusEnum.Received,
  OrderStatusEnum.InProgress,
];

export enum EventSyncPoImportEnum {
  Create = 'event.syncPoImport.create',
  Update = 'event.syncPoImport.update',
  Confirm = 'event.syncPoImport.confirm',
  Reject = 'event.syncPoImport.reject',
  Delete = 'event.syncPoImport.delete',
  SyncEbs = 'event.syncPoImport.SyncEBS',
}

export const STATUS_SYNC_ACCEPT_SYNC_PURCHASED_ORDER_IMPORT_TO_EBS = [
  StatusSyncOrderToEbsEnum.SYNC_WSO2_ERROR,
  StatusSyncOrderToEbsEnum.OUT_OF_SYNC,
  StatusSyncOrderToEbsEnum.COMPLETED,
];

export const PO_IMPORT_STATUS_NOT_USED_RECEIPT = [
  OrderStatusEnum.Pending,
  OrderStatusEnum.Reject,
];

export const PO_IMPORT_STATUS_EXPORT_FILE = [
  OrderStatusEnum.InProgress,
  OrderStatusEnum.Completed,
  OrderStatusEnum.Received,
];

export const AUTO_CREATE_RECEIVE = {
  NO: 0,
  YES: 1,
};

export const BUSINESS_TYPE = {
  N0002: 'N0002',
  N0003: 'N0003',
};

export const BUSINESS_TYPE_ATTRIBUTE_TABLE_NAME = {
  CONSTRUCTIONS: 'constructions',
  CATEGORY_CONSTRUCTIONS: 'category_constructions',
  COST_TYPES: 'cost_types',
  ORGANIZATION_PAYMENTS: 'organization_payments',
  VENDORS: 'vendors',
  RECEIVER: 'null',
  WAREHOUSE_EXPORT_PROPOSALS: 'warehouse_export_proposals',
  RECEIVER_EBS_LABEL: 'Transaction.Transaction history.Receiver',
};

export const POIMP_ITEMS = {
  LENGTH: 9,
};
