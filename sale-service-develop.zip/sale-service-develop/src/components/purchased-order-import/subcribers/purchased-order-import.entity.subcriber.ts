import { PurchasedOrderImportEntity } from '@entities/purchased-order-import/purchased-order-import.entity';
import { Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import {
  DataSource,
  EntitySubscriberInterface,
  InsertEvent,
  UpdateEvent,
} from 'typeorm';
import { EventEmitter2 } from '@nestjs/event-emitter';
import {
  EventSyncPoImportEnum,
  STATUS_SYNC_PURCHASED_ORDER_IMPORT,
} from '../purchased-order-import.contant';

@Injectable()
export class PurchasedOrderImportSubcriber
  implements EntitySubscriberInterface<PurchasedOrderImportEntity>
{
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
    private eventEmitter: EventEmitter2,
  ) {
    dataSource.subscribers.push(this);
  }
  listenTo() {
    return PurchasedOrderImportEntity;
  }
  afterInsert(
    event: InsertEvent<PurchasedOrderImportEntity>,
  ): void | Promise<any> {
    this.eventEmitter.emit(EventSyncPoImportEnum.Create, event.entity);
  }

  afterUpdate(
    event: UpdateEvent<PurchasedOrderImportEntity>,
  ): void | Promise<any> {
    if (STATUS_SYNC_PURCHASED_ORDER_IMPORT.includes(+event.entity.status)) {
      this.eventEmitter.emit(EventSyncPoImportEnum.Update, event.entity.id);
    }
  }
}
