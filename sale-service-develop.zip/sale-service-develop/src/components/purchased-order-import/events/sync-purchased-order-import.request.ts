import { OrderStatusEnum } from '@constant/common';
import { Expose, Type } from 'class-transformer';

export class ItemResponseDto {
  @Expose()
  itemId: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  price: number;

  @Expose()
  itemUnit: string;

  @Expose()
  description: string;

  @Expose()
  quantity: number;

  @Expose()
  itemDetails: any;

  details: any;
}
class PurchasedOrderImportWarehouseLot {
  @Expose()
  id: number;

  @Expose()
  itemId: number;

  @Expose()
  purchasedOrderImportWarehouseDetailId: number;

  @Expose()
  purchasedOrderImportId: number;

  @Expose()
  actualQuantity: number;

  @Expose()
  quantity: number;

  @Expose()
  qcRejectQuantity: number;

  @Expose()
  qcPassQuantity: number;

  @Expose()
  isEven: boolean;

  @Expose()
  lotNumber: string;

  @Expose()
  lotNumberOld: string;

  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @Expose()
  storedQuantity: number;

  @Expose()
  exportableQuantity: number;
}

export class PoImportRelationData {
  @Expose()
  id: number;

  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  accountant: string;
}

class PurchasedOrderImportDetail {
  @Expose()
  id: number;

  @Expose()
  purchasedOrderImportId: number;

  @Expose()
  itemId: number;

  @Expose()
  actualQuantity: number;

  @Expose()
  exportableQuantity: number;

  @Expose()
  quantity: number;

  @Expose()
  qcPassQuantity: number;

  @Expose()
  qcRejectQuantity: number;

  @Expose()
  confirmQuantity: number;

  @Expose()
  receivedQuantity: number;

  @Expose()
  lotNumber: string;

  @Expose()
  itemCode: string;

  @Expose()
  itemCodeImportActual: string;

  @Expose()
  unit: PoImportRelationData;

  @Expose()
  itemCategory: PoImportRelationData;

  @Expose()
  objectCategory: PoImportRelationData;

  @Expose()
  price: number;

  @Expose()
  amount: number;

  @Expose()
  debitAccount: any;

  @Expose()
  creditAccount: string;

  @Expose()
  item: ItemResponseDto;

  @Expose()
  @Type(() => PurchasedOrderImportWarehouseLot)
  lots: PurchasedOrderImportWarehouseLot[];
}

export class Company {
  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  address: string;
}

export class WarehouseExportProposal {
  @Expose()
  id: number;

  @Expose()
  code: string;
}

export class SyncPurchasedOrderRequestDto {
  @Expose()
  id: number;

  @Expose()
  companyCode: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  status: OrderStatusEnum;

  @Expose()
  deliver: string;

  @Expose()
  explanation: string;

  @Expose()
  receiptDate: Date;

  @Expose()
  contractNumber: string;

  @Expose()
  receiptNumber: string; //Phiếu yêu cầu nhập kho

  @Expose()
  @Type(() => PoImportRelationData)
  departmentReceipt: PoImportRelationData;

  @Expose()
  @Type(() => PoImportRelationData)
  vendor: PoImportRelationData[];

  @Expose()
  @Type(() => PoImportRelationData)
  source: PoImportRelationData;

  @Expose()
  @Type(() => PoImportRelationData)
  reason: PoImportRelationData;

  @Expose()
  @Type(() => PoImportRelationData)
  warehouse: PoImportRelationData;

  @Expose()
  @Type(() => PoImportRelationData)
  construction: PoImportRelationData;

  @Expose()
  @Type(() => PoImportRelationData)
  warehouseExportProposal: PoImportRelationData;

  @Expose()
  @Type(() => PurchasedOrderImportDetail)
  purchasedOrderImportDetails: PurchasedOrderImportDetail[];

  @Expose()
  @Type(() => Company)
  company: Company;

  @Expose()
  @Type(() => WarehouseExportProposal)
  warehouseExportProposals: WarehouseExportProposal;

  @Expose()
  syncCode: string;

  @Expose({ name: 'ebsId' })
  ebsNumber: string;

  @Expose()
  qrCode: string;
}
