import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

export class ImportPurchasedOrderImportResponseDto {
  @ApiProperty({ type: ImportResponseDto })
  @Expose()
  @Type(() => ImportResponseDto)
  purchasedOrderImport: ImportResponseDto;

  @ApiProperty({ type: ImportResponseDto })
  @Expose()
  @Type(() => ImportResponseDto)
  purchasedOrderImportDetail: ImportResponseDto;
}
