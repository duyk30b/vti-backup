import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class TotalQuantityItemPurchaseOrderImportResponseDto {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  totalActualQuantity: number;

  @ApiProperty()
  @Expose()
  totalQuantity: number;
}
