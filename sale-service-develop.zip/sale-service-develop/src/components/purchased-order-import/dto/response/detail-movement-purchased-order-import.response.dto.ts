import { OrderResponseDto } from '@components/order/dto/response/order-response.dto';
import { WarehouseResponseDto } from '@components/warehouse/dto/response/warehouse.dto.response';
import { Expose, Type } from 'class-transformer';

export class DetailMovementPurchasedOrderImportResponseDto extends OrderResponseDto {
  @Expose()
  vendorName: string;

  @Expose()
  @Type(() => WarehouseResponseDto)
  warehouse: WarehouseResponseDto;

  @Expose()
  items: any;
}
