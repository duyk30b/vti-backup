import { Expose, Transform, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { VendorResponseDto } from '@components/vendor/dto/response/vendor.response.dto';
import { WarehouseDoorResponseDto } from '@components/warehouse/dto/response/warehouse-door.response.dto';

class PurchasedOrderImportReceiveItemResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  itemCode: string;

  @ApiProperty()
  @Expose()
  itemName: string;

  @ApiProperty()
  @Expose()
  itemUnit: string;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  @Transform((data) => Boolean(data.value))
  qcCheck: boolean;

  @ApiProperty()
  @Expose()
  @Transform((data) => data.obj.qcPassQuantity || 0)
  passQuantity: number;

  @ApiProperty()
  @Expose()
  @Transform((data) => data.obj.qcRejectQuantity || 0)
  failQuantity: number;

  @ApiProperty()
  @Expose()
  @Transform(
    (data) => (data.obj.qcPassQuantity || 0) + (data.obj.qcRejectQuantity || 0),
  )
  totalQcQuantity: number;
}

class PurchasedOrderImportReceiveVendor extends VendorResponseDto {}

class PurchasedOrderInReceiveResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty({ type: PurchasedOrderImportReceiveVendor })
  @Expose()
  @Type(() => PurchasedOrderImportReceiveVendor)
  vendor: PurchasedOrderImportReceiveVendor;
}

export class PurchasedOrderImportReceiveDoor extends WarehouseDoorResponseDto {}

export class PurchasedOrderImportReceiveDetailResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  referenceDoc: string;

  @ApiProperty()
  @Expose()
  postedAt: Date;

  @ApiProperty({ type: PurchasedOrderImportReceiveDoor })
  @Expose()
  @Type(() => PurchasedOrderImportReceiveDoor)
  door: PurchasedOrderImportReceiveDoor;

  @ApiProperty()
  @Expose()
  purchasedOrder: PurchasedOrderInReceiveResponseDto;

  @ApiProperty()
  @Expose()
  note: string;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty({ type: PurchasedOrderImportReceiveItemResponseDto })
  @Expose()
  @Type(() => PurchasedOrderImportReceiveItemResponseDto)
  items: PurchasedOrderImportReceiveItemResponseDto[];
}
