import { OrderResponseDto } from '@components/order/dto/response/order-response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class LocationPoImport {
  @ApiProperty()
  @Expose()
  locatorId: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose({ name: 'quantity' })
  storedQuantity: number;
}
class ItemsPurchasedOrderImport {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  storedQuantity: number;

  @ApiProperty()
  @Expose()
  remainingQuantity: number;

  @ApiProperty({ type: LocationPoImport, isArray: true })
  @Expose()
  @Type(() => LocationPoImport)
  locations: LocationPoImport[];
}

export class SuggestStoredPurchasedOrderImportResponseDto extends OrderResponseDto {
  @ApiProperty()
  @Expose()
  deliver: string;

  @ApiProperty()
  @Expose()
  vendorName: string;

  @ApiProperty()
  @Expose()
  warehouseName: string;

  @ApiProperty()
  @Expose()
  receiptDate: Date;

  @ApiProperty({ type: ItemsPurchasedOrderImport, isArray: true })
  @Expose()
  @Type(() => ItemsPurchasedOrderImport)
  items: ItemsPurchasedOrderImport[];
}
