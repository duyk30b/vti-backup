import { IsArray } from 'class-validator';
import { Expose, Transform, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { OrderResponseDto } from '@components/order/dto/response/order-response.dto';

class Warehouse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}

class Detail {
  @ApiProperty()
  @Expose({ name: 'itemDetailSettingId' })
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty({})
  @Expose({ name: 'itemDetailQuantity' })
  quantity: number;
}

class LotDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty({ description: '' })
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  mfg: string;

  @ApiProperty({ description: 'Số lượng KH' })
  @Expose()
  @Transform(({ value }) => (value > 0 ? value : 0))
  planQuantity: number;

  @ApiProperty({ description: 'Số lượng cần nhập còn lại' })
  @Expose()
  @Transform(({ value }) => (value > 0 ? value : 0))
  quantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  receivedQuantity: number;

  @ApiProperty()
  @Expose()
  unQuantity: number;

  @ApiProperty()
  @Expose()
  qcPassQuantity: number;

  @ApiProperty()
  @Expose()
  qcRejectQuantity: number;

  @ApiProperty()
  @Expose()
  price: number;

  @ApiProperty()
  @Expose()
  totalPrice: number;

  @ApiProperty()
  @Expose()
  isExpired?: boolean;
}

class Vendor {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class POImportItem {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  detailId: number;

  @ApiProperty()
  @Expose()
  warehouseDetailId: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty({ description: 'Số lượng thực tế đã nhập' })
  @Expose()
  actualQuantity: number;

  @ApiProperty({ description: 'Số lượng cần nhập còn lại' })
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  receivedQuantity: number;

  @ApiProperty({ description: 'Số lượng cần nhập theo kế hoạch' })
  @Expose()
  planQuantity: number;

  @ApiProperty({ description: 'Số lươgnj đã xác nhận' })
  @Expose()
  confirmQuantity: number;

  @ApiProperty({ description: 'Số lươgnj đã xác nhận' })
  @Expose()
  qcCheck: number;

  @ApiProperty({ description: 'Số lươgnj đã xác nhận' })
  @Expose()
  qcCriteriaId: number;

  @ApiProperty({
    description: 'Danh sách chi tiết',
    type: () => Detail,
    isArray: true,
  })
  @Expose()
  @Type(() => Detail)
  details: Detail[];

  @ApiProperty({
    description: 'Danh sách số lô',
    type: () => LotDetail,
    isArray: true,
  })
  @Expose()
  @Type(() => LotDetail)
  lots: LotDetail[];

  @Expose()
  purchasedOrderImportReceiveItemQuantity: number;
}

class POImpDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  price: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  totalPrice: number;
}

export class PurchasedOrderImportWarehouseDetailResponseDto extends OrderResponseDto {
  @ApiProperty()
  @Expose()
  vendorId: number;

  @ApiProperty()
  @Expose()
  orderType: number;

  @ApiProperty({
    type: () => Warehouse,
    description: 'Chi tiết kho theo user - chỉ kho thuộc user mới hiển thị',
  })
  @Expose()
  @Type(() => Warehouse)
  @IsArray()
  warehouse: Warehouse[];

  @ApiProperty({
    type: () => Vendor,
  })
  @Expose()
  @Type(() => Vendor)
  vendor: Vendor;

  @Expose()
  departmentReceiptId: number;

  @Expose()
  explanation: string;

  @ApiProperty({
    type: () => POImportItem,
    isArray: true,
    description: 'Danh sách item',
  })
  @Expose()
  @Type(() => POImportItem)
  @IsArray()
  items: POImportItem[];

  @ApiProperty({
    type: () => POImpDetail,
    isArray: true,
    description: 'Chi tiết phiếu',
  })
  @Expose()
  @Type(() => POImpDetail)
  @IsArray()
  purchasedOrderImportDetails: POImpDetail[];

  @ApiProperty({
    type: () => LotDetail,
    isArray: true,
    description: 'Danh sách số lô',
  })
  @Expose()
  @Type(() => LotDetail)
  @IsArray()
  purchasedOrderImportWarehouseLots: LotDetail[];
}
