import { WarehouseResponseDto } from '../../../warehouse/dto/response/warehouse.dto.response';
import { ItemResponseDto } from '../../../item/dto/response/item.dto.response';
import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray } from 'class-validator';

class User {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  username: string;

  @ApiProperty()
  @Expose()
  fullName: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  email: string;
}

class PurchasedOrderImportWarehouseLot {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  purchasedOrderImportWarehouseDetailId: number;

  @ApiProperty()
  @Expose()
  purchasedOrderImportId: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  qcRejectQuantity: number;

  @ApiProperty()
  @Expose()
  qcPassQuantity: number;

  @ApiProperty()
  @Expose()
  isEven: boolean;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  storedQuantity: number;

  @ApiProperty()
  @Expose()
  exportableQuantity: number;

  @ApiProperty()
  @Expose()
  requestedQuantityWarehouseExportProposal: number;

  @ApiProperty()
  @Expose()
  price: number;

  @ApiProperty()
  @Expose()
  amount: number;

  @ApiProperty()
  @Expose()
  debitAccount: string;

  @ApiProperty()
  @Expose()
  creditAccount: string;

  @ApiProperty()
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;
}

class PoImportRelationData {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  desc: string;

  @ApiProperty()
  @Expose()
  accountant: string;

  @ApiProperty()
  @Expose()
  manageByLot: number;
}

class PurchasedOrderImportDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  purchasedOrderImportId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  exportableQuantity: number;

  @ApiProperty({
    description:
      'Số  lượng giao dịch(Số lượng Nv kho approve  - Số lượng nhập thực tết)',
    example: 1,
  })
  @Expose()
  requestedQuantityWarehouseExportProposal: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  qcPassQuantity: number;

  @ApiProperty()
  @Expose()
  qcRejectQuantity: number;

  @ApiProperty()
  @Expose()
  confirmQuantity: number;

  @ApiProperty()
  @Expose()
  receivedQuantity: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  itemCode: string;

  @ApiProperty()
  @Expose()
  itemCodeImportActual: string;

  @ApiProperty({ type: PoImportRelationData })
  @Expose()
  @Type(() => PoImportRelationData)
  unit: PoImportRelationData;

  @ApiProperty({ type: PoImportRelationData })
  @Expose()
  @Type(() => PoImportRelationData)
  itemCategory: PoImportRelationData;

  @ApiProperty({ type: PoImportRelationData })
  @Expose()
  @Type(() => PoImportRelationData)
  objectCategory: PoImportRelationData;

  @ApiProperty()
  @Expose()
  price: number;

  @ApiProperty()
  @Expose()
  amount: number;

  @ApiProperty()
  @Expose()
  debitAccount: string;

  @ApiProperty()
  @Expose()
  creditAccount: string;

  @ApiProperty()
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;

  @ApiProperty()
  @Type(() => PurchasedOrderImportWarehouseLot)
  @Expose()
  lots: PurchasedOrderImportWarehouseLot[];
}

class PurchasedOrderImportWarehouseDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  purchasedOrderImportId: number;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  confirmQuantity: number;

  @ApiProperty()
  @Expose()
  qcRejectQuantity: number;

  @ApiProperty()
  @Expose()
  qcPassQuantity: number;

  @ApiProperty()
  @Expose()
  errorQuantity: number;

  @ApiProperty()
  @Expose()
  qcCheck: number;

  @ApiProperty()
  @Expose()
  qcCriteriaId: number;

  @ApiProperty()
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;

  @ApiProperty()
  @Type(() => WarehouseResponseDto)
  @Expose()
  warehouse: WarehouseResponseDto;

  @ApiProperty({ type: PurchasedOrderImportWarehouseLot })
  @Expose()
  @Type(() => PurchasedOrderImportWarehouseLot)
  purchasedOrderImportWarehouseLots: PurchasedOrderImportWarehouseLot[];
}

export class ManufacturingOrder {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  factoryId: number;

  @ApiProperty()
  @Expose()
  saleOrderId: number;

  @ApiProperty()
  @Expose()
  planFrom: Date;

  @ApiProperty()
  @Expose()
  planTo: Date;

  @ApiProperty()
  @Expose()
  status: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;
}

export class PurchasedOrderImportReceive {
  @ApiProperty()
  @Expose()
  referenceDoc: string;

  @ApiProperty()
  @Expose()
  postedAt: Date;

  @ApiProperty()
  @Expose()
  note: string;
}

export class AttributeResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  bussinessTypeId: number;

  @ApiProperty()
  @Expose()
  fieldName: string;

  @ApiProperty()
  @Expose()
  ebsLabel: string;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  columnName: string;

  @ApiProperty()
  @Expose()
  tableName: string;

  @ApiProperty()
  @Expose()
  value: any;

  @ApiProperty()
  @Expose()
  required: boolean;
}

class Attachment {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  fileName: string;
}

export class PurchasedOrderImportResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  companyId: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  ebsId: string;

  @ApiProperty()
  @Expose()
  oldEbsId: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  status: string;

  @ApiProperty()
  @Expose()
  syncStatus: number;

  @ApiProperty()
  @Expose()
  businessTypeId: number;

  @ApiProperty()
  @Expose()
  departmentReceiptId: number;

  @ApiProperty()
  @Expose()
  deliver: string;

  @ApiProperty()
  @Expose()
  explanation: string;

  @ApiProperty()
  @Expose()
  receiptDate: Date;

  @ApiProperty()
  @Expose()
  contractNumber: string;

  @ApiProperty()
  @Expose()
  syncCode: string;

  @ApiProperty()
  @Expose()
  receiptNumber: string;

  @ApiProperty()
  @Expose()
  receiptNumberEbs: string;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  @Type(() => User)
  createdByUser: User;

  @ApiProperty()
  @Expose()
  @Type(() => Attachment)
  attachment: Attachment;

  @ApiProperty({ type: PoImportRelationData })
  @Expose()
  @Type(() => PoImportRelationData)
  departmentReceipt: PoImportRelationData;

  @ApiProperty({ type: PoImportRelationData })
  @Expose()
  @Type(() => PoImportRelationData)
  vendor: PoImportRelationData;

  @ApiProperty({ type: PoImportRelationData })
  @Expose()
  @Type(() => PoImportRelationData)
  businessType: PoImportRelationData;

  @ApiProperty({ type: PoImportRelationData })
  @Expose()
  @Type(() => PoImportRelationData)
  source: PoImportRelationData;

  @ApiProperty({ type: PoImportRelationData })
  @Expose()
  @Type(() => PoImportRelationData)
  reason: PoImportRelationData;

  @ApiProperty({ type: PoImportRelationData })
  @Expose()
  @Type(() => PoImportRelationData)
  warehouse: PoImportRelationData;

  @ApiProperty({ type: PoImportRelationData })
  @Expose()
  @Type(() => PoImportRelationData)
  construction: PoImportRelationData;

  @ApiProperty({ type: PoImportRelationData })
  @Expose()
  @Type(() => PoImportRelationData)
  constructionCategory: PoImportRelationData;

  @ApiProperty({ type: PoImportRelationData })
  @Expose()
  @Type(() => PoImportRelationData)
  warehouseExportProposal: PoImportRelationData;

  @ApiProperty({ type: PurchasedOrderImportDetail, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => PurchasedOrderImportDetail)
  purchasedOrderImportDetails: PurchasedOrderImportDetail[];

  @ApiProperty({ type: PurchasedOrderImportWarehouseLot, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => PurchasedOrderImportWarehouseLot)
  purchasedOrderImportWarehouseLots: PurchasedOrderImportWarehouseLot[];

  @ApiProperty({ type: PurchasedOrderImportWarehouseDetail, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => PurchasedOrderImportWarehouseDetail)
  purchasedOrderImportWarehouseDetails: PurchasedOrderImportWarehouseDetail[];

  @ApiProperty({ type: PurchasedOrderImportWarehouseDetail, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => AttributeResponse)
  attributes: AttributeResponse[];
}
