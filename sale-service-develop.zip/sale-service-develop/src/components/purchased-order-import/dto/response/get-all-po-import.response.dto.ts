import { Expose, Type } from 'class-transformer';

class Vendor {
  @Expose()
  id: number;

  @Expose()
  name: string;
}

class Item {
  @Expose()
  purchasedOrderImportId: number;

  @Expose()
  itemId: number;

  @Expose()
  quantity: number;

  @Expose()
  confirmedQuantity: number;

  @Expose()
  warehouseId: number;
}
export class GetAllPOImportResponse {
  @Expose()
  id: number;

  @Expose()
  companyId: number;

  @Expose()
  createdAt: Date;

  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose({ name: 'vendor' })
  @Type(() => Vendor)
  vendor: Vendor;

  @Expose({ name: 'purchasedOrderImportWarehouseDetails' })
  @Type(() => Item)
  items: Item[];
}
