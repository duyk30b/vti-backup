import { BaseDto } from '@core/dto/base.dto';
import { File } from '@core/dto/file-upload.request';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  Matches,
  MaxLength,
  ValidateIf,
  ValidateNested,
} from 'class-validator';
import { isJson } from 'src/helper/string.helper';
import { AttributeRequest, OldFile } from './create-purchased-order-import.dto';
import { isEmpty, isString } from 'lodash';
import { PO_IMPORT_RULES } from '@components/purchased-order-import/purchased-order-import.contant';

class ItemRequest {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  itemId: number;

  @ApiProperty()
  @IsString()
  @IsOptional()
  lotNumber: string;

  @ApiPropertyOptional()
  @MaxLength(PO_IMPORT_RULES.CREDIT_ACCOUNT.MAX_LENGTH)
  @IsString()
  @IsOptional()
  creditAccount: string;
}

export class UpdateHeaderPurchasedOrderImportBodyDto extends BaseDto {
  @ApiProperty()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  @IsOptional()
  id: number;

  @ApiProperty()
  @ValidateIf((_, value) => !isEmpty(value))
  @Matches(/^01\.[a-zA-Z0-9]+\.[a-zA-Z0-9]+\.\d+$/, {
    message: 'error.EBS_NOT_MATCHES',
  })
  @IsString()
  @IsOptional()
  ebsId: string;

  @ApiProperty()
  @IsString()
  @IsOptional()
  deliver: string;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  @IsOptional()
  departmentReceiptId: number;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  @IsOptional()
  reasonId: number;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  @IsOptional()
  sourceId: number;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  @IsOptional()
  warehouseId: number;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  @IsOptional()
  businessTypeId: number;

  @ApiProperty()
  @IsString()
  @IsOptional()
  explanation: string;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => File)
  attachment: File;

  @ApiProperty()
  @IsOptional()
  @Transform(({ value }) => {
    if (value instanceof Array) {
      return value;
    }

    if (value && value.includes('\\"')) value = value.replace(/\\/g, '');

    if (isJson(value) && JSON.parse(value) instanceof Array) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    } else {
      return value.split(',');
    }
  })
  @Type(() => OldFile)
  files: OldFile[];

  @ApiProperty()
  // @ArrayUnique<AttributeRequest>()
  @ValidateNested()
  @Type(() => AttributeRequest)
  @IsOptional()
  attributes: AttributeRequest[];

  @ApiProperty()
  @ValidateNested()
  @Transform(({ value }) => (isString(value) ? JSON.parse(value) : value))
  @Type(() => ItemRequest)
  @ArrayNotEmpty()
  items: ItemRequest[];
}
