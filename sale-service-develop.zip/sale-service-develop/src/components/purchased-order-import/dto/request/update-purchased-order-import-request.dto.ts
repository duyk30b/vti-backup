import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import { ArrayUnique, IsInt, IsNotEmpty, IsString, ValidateNested } from 'class-validator';
import { AttributeRequest, CreatePurchasedOrderImportBodyDto } from './create-purchased-order-import.dto';

export class UpdatePurchasedOrderImportBody extends CreatePurchasedOrderImportBodyDto {}

export class UpdatePurchasedOrderImportDto extends UpdatePurchasedOrderImportBody {
  @ApiProperty()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;

  @ApiProperty()
  @IsString()
  code: string;

  @ApiProperty()
  @ArrayUnique<AttributeRequest>()
  @ValidateNested()
  @Type(() => AttributeRequest)
  attributes: AttributeRequest[];
}
