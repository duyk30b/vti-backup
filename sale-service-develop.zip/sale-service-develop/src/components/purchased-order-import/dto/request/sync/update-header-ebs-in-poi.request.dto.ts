import { BaseDto } from '@core/dto/base.dto';
import { Expose, Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsArray,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

class EbsInPOImportItem {
  @Expose({ name: 'numberOrder' })
  @IsString()
  order: string;

  @Expose()
  @IsOptional()
  @IsString()
  credit: string;
}

export class UpdateHeaderEbsInPOIRequest extends BaseDto {
  @Expose({ name: 'idWMS' })
  @Transform(({ value }) => Number(value))
  @IsInt()
  @IsNotEmpty()
  id: number;

  @Expose()
  @Transform(({ value }) => Number(value))
  @IsInt()
  @IsNotEmpty()
  status: number;

  @Expose({ name: 'transactionNumberCreated' })
  @IsString()
  @IsOptional()
  ebsId: string;

  @Expose()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => EbsInPOImportItem)
  @IsOptional()
  item: EbsInPOImportItem[];
}
