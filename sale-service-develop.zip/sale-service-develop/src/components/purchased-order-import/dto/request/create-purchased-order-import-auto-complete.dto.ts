import { PO_IMPORT_RULES } from '@components/purchased-order-import/purchased-order-import.contant';
import { BaseDto } from '@core/dto/base.dto';
import { File } from '@core/dto/file-upload.request';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsBoolean,
  IsDateString,
  IsInt,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';
import * as moment from 'moment';
export class OldFile {
  id: string;
  fileName: string;
  fileUrl: string;
}
class ItemRequest {
  @ApiProperty()
  @IsOptional()
  id: number;

  @ApiProperty()
  @Expose({ name: 'item' })
  @IsString()
  code: string;

  @ApiProperty()
  @Expose({ name: 'lots' })
  @IsOptional()
  @IsString()
  @MaxLength(PO_IMPORT_RULES.LOT_NUMBER.MAX_LENGTH)
  lotNumber: string;

  @ApiProperty()
  @Expose({ name: 'planQuantities' })
  @IsNumber()
  @Transform(({ value }) => Number(value))
  @Min(0)
  quantity: number;

  @ApiProperty()
  @Expose({ name: 'actualQuantities' })
  @IsNumber()
  @Transform(({ value }) => Number(value))
  @Min(0)
  actualQuantity: number;

  @ApiProperty()
  @Expose({ name: 'costOfGoods' })
  @IsNumber()
  @IsPositive()
  amount: number;

  @ApiPropertyOptional()
  @Expose({ name: 'debt' })
  @IsOptional()
  @IsString()
  @MaxLength(PO_IMPORT_RULES.DEBIT_ACCOUNT.MAX_LENGTH)
  debitAccount: string;

  @ApiPropertyOptional()
  @Expose({ name: 'credit' })
  @IsOptional()
  @IsString()
  @MaxLength(PO_IMPORT_RULES.CREDIT_ACCOUNT.MAX_LENGTH)
  creditAccount: string;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  warehouseId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  qcCheck?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  qcCriteriaId?: number;
}

export class AttributeRequest {
  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  id: number;

  @ApiProperty()
  value: any;
}

export class CreatePurchasedOrderImportAutoCompleteDto extends BaseDto {
  @Expose({ name: 'idEbs' })
  @IsString()
  ebsId: string;

  @ApiProperty()
  @Expose()
  @IsString()
  @MaxLength(PO_IMPORT_RULES.DELIVER.MAX_LENGTH)
  deliver: string;

  @ApiProperty()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  @IsInt()
  businessTypeId: number;

  @ApiProperty()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  @IsInt()
  reasonId: number;

  reasonCode: string;

  @ApiProperty()
  @Expose({ name: 'vendor' })
  @IsOptional()
  @IsString()
  vendorCode: string;

  @ApiProperty()
  @Expose({ name: 'reference' })
  @IsString()
  @IsOptional()
  @MaxLength(PO_IMPORT_RULES.EXPLAINATION.MAX_LENGTH)
  explanation: string;

  @ApiProperty()
  @Expose({ name: 'dateCreated' })
  @Transform((v) => {
    return moment(v.value, 'DD/MM/YYYY HH:mm:ss').toISOString();
  })
  @IsDateString()
  receiptDate: Date;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  departmentReceiptId: number;

  @ApiProperty()
  @Expose({ name: 'departmentReceipt' })
  @IsString()
  departmentReceiptName: string;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  sourceId: number;

  @ApiProperty()
  @Expose({ name: 'source' })
  @IsString()
  sourceCode: string;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @Expose({ name: 'warehouse' })
  @IsString()
  warehouseCode: string;

  @ApiProperty()
  @IsOptional()
  userId: number;

  @ApiProperty()
  @IsOptional()
  files: OldFile[];

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => File)
  attachment: File;

  @Expose()
  @IsOptional()
  @IsString()
  receipt: string;

  @Expose({ name: 'task' })
  @IsOptional()
  @IsString()
  categoryConstructionCode: string;

  @Expose({ name: 'project' })
  @IsOptional()
  @IsString()
  constructionCode: string;

  @Expose({ name: 'expenditureType' })
  @IsOptional()
  @IsString()
  costTypeCode: string;

  @Expose({ name: 'expenditureOrg' })
  @IsOptional()
  @IsString()
  organizationPaymentName: string;

  @Expose()
  @IsString()
  username: string;

  @ApiProperty()
  @Expose({ name: 'item' })
  @ArrayUnique<ItemRequest>()
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => ItemRequest)
  items: ItemRequest[];

  @ApiProperty()
  @IsOptional()
  @ArrayUnique<AttributeRequest>()
  @ValidateNested()
  @Type(() => AttributeRequest)
  attributes: AttributeRequest[];

  @ApiPropertyOptional()
  @IsBoolean()
  @IsOptional()
  isImport?: boolean;
}
