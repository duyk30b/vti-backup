import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { Transform, Type } from 'class-transformer';
import {
  ArrayUnique,
  IsArray,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

class ItemStored {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  lotNumber?: string;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsNumber()
  quantity: number;
}

export class SuggestStoredOrderImportBodyDto extends PaginationQuery {
  @ApiProperty()
  @IsNotEmpty()
  @ArrayUnique((item: ItemStored) => `${item.itemId}-${item.lotNumber || ''}`)
  @ValidateNested()
  @Type(() => ItemStored)
  items: ItemStored[];

  @ApiProperty()
  @IsOptional()
  @IsArray()
  locatorIds: number[];
}

export class SuggestStoredOrderImportRequestDto extends SuggestStoredOrderImportBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;
}
