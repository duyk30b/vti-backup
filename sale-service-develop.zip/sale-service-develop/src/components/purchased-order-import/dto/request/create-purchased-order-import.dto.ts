import { PO_IMPORT_RULES } from '@components/purchased-order-import/purchased-order-import.contant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import { File } from '@core/dto/file-upload.request';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsBoolean,
  IsDateString,
  IsInt,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  Length,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';
import { isJson } from 'src/helper/string.helper';
export class OldFile {
  id: string;
  fileName: string;
  fileUrl: string;
}
class ItemRequest {
  @ApiProperty()
  @IsInt()
  id: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  itemCodeImportActual: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(PO_IMPORT_RULES.LOT_NUMBER.MAX_LENGTH)
  lotNumber: string;

  @ApiProperty()
  @IsNumber()
  @Transform(({ value }) => Number(value))
  @Min(0)
  quantity: number;

  @ApiProperty()
  @IsNumber()
  @IsPositive()
  price: number;

  @ApiProperty()
  @IsNumber()
  @IsPositive()
  amount: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(PO_IMPORT_RULES.DEBIT_ACCOUNT.MAX_LENGTH)
  debitAccount: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(PO_IMPORT_RULES.CREDIT_ACCOUNT.MAX_LENGTH)
  creditAccount: string;

  @ApiProperty()
  @IsInt()
  warehouseId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  qcCheck?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  qcCriteriaId?: number;
}

export class AttributeRequest {
  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  id: number;

  @ApiProperty()
  value: any;
}

export class CreatePurchasedOrderImportBodyDto extends BaseDto {
  @ApiProperty()
  @IsString()
  @MaxLength(PO_IMPORT_RULES.DELIVER.MAX_LENGTH)
  deliver: string;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  businessTypeId: number;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  reasonId: number;

  @ApiProperty()
  @IsString()
  @MaxLength(PO_IMPORT_RULES.EXPLAINATION.MAX_LENGTH)
  explanation: string;

  @ApiProperty()
  @IsDateString()
  receiptDate: Date;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  departmentReceiptId: number;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  sourceId: number;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsString()
  contractNumber: string;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => File)
  attachment: File;

  @ApiProperty()
  @Transform(({ value }) => JSON.parse(value))
  @ArrayUnique<ItemRequest>()
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => ItemRequest)
  items: ItemRequest[];

  @ApiProperty()
  @IsOptional()
  @Transform(({ value }) => {
    if (value instanceof Array) {
      return value;
    }

    if (value && value.includes('\\"')) value = value.replace(/\\/g, '');

    if (isJson(value) && JSON.parse(value) instanceof Array) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    } else {
      return value.split(',');
    }
  })
  @Type(() => OldFile)
  files: OldFile[];
}

export class CreatePurchasedOrderImportDto extends CreatePurchasedOrderImportBodyDto {
  @ApiProperty()
  @ArrayUnique<AttributeRequest>()
  @ValidateNested()
  @Type(() => AttributeRequest)
  attributes: AttributeRequest[];

  @ApiPropertyOptional()
  @IsBoolean()
  @IsOptional()
  isImport?: boolean;
}
