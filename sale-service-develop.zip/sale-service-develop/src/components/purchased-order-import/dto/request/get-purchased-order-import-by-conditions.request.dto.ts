import { BaseDto } from '@core/dto/base.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsArray,
  IsDateString,
  IsInt,
  IsOptional,
} from 'class-validator';
import { isJson } from 'src/helper/string.helper';

export class GetPurchasedOrderImportByConditions extends BaseDto {
  @ApiPropertyOptional()
  @Transform(({ value }) => Number(value))
  @IsInt()
  warehouseId: number;

  @ApiPropertyOptional()
  @ArrayNotEmpty()
  @Transform(({ value }) => {
    if (value instanceof Array) {
      return value;
    }

    if (value && value.includes('\\"')) value = value.replace(/\\/g, '');

    if (isJson(value) && JSON.parse(value) instanceof Array) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    } else {
      return value.split(',');
    }
  })
  itemIds: number[];

  @ApiPropertyOptional()
  @IsDateString()
  receiptDate: Date;
}
