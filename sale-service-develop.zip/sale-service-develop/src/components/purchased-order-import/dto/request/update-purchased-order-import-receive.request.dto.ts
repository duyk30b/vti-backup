import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';

import {
  IsArray,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
} from 'class-validator';
import { CreatePurchasedOrderImportReceiveRequestDto } from './create-purchased-order-import-receive.request.dto';

export class UpdatePurchasedOrderImportReceiveBodyDto extends CreatePurchasedOrderImportReceiveRequestDto {}
export class UpdatePurchasedOrderImportReceiveRequestDto extends CreatePurchasedOrderImportReceiveRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @IsArray()
  @IsOptional()
  files: any[];
}
