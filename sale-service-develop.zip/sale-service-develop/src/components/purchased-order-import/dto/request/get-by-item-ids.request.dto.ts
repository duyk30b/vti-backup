import { BaseDto } from '@core/dto/base.dto';
import { ArrayNotEmpty } from 'class-validator';

export class GetByItemIdsRequestDto extends BaseDto {
  @ArrayNotEmpty()
  itemIds: number[];
}
