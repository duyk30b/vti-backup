import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt } from 'class-validator';

export class SubmitPOImportReceiveRequeseDto extends BaseDto {
  @ApiProperty()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;

  @ApiProperty()
  @IsInt()
  userId: number;
}
