import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsBoolean,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';

export class PurchasedOrderImportReceiveItemRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiProperty()
  @IsNotEmpty()
  @Transform(({ value }) => Number(value))
  @IsNumber()
  @IsPositive()
  actualQuantity: number;

  @ApiProperty()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  @IsNumber()
  @IsPositive()
  storedQuantity: number;
}

export class CreatePurchasedOrderImportReceiveWithTicketRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  ticketId: number;

  @ApiProperty()
  @IsBoolean()
  isComplete: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(255)
  referenceDoc: string;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  postedAt: Date;

  @ApiPropertyOptional()
  @IsInt()
  warehouseId?: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @MaxLength(255)
  note: string;

  @ApiProperty({
    type: PurchasedOrderImportReceiveItemRequestDto,
    isArray: true,
  })
  @IsArray()
  @ArrayNotEmpty()
  @Type(() => PurchasedOrderImportReceiveItemRequestDto)
  items: PurchasedOrderImportReceiveItemRequestDto[];
}

export class CreatePurchasedOrderImportReceiveItemEntityRequestDto extends PurchasedOrderImportReceiveItemRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  purchasedOrderImportReceiveId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  quantity: number;
}
