import { BaseDto } from "@core/dto/base.dto";
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { IsInt, IsNotEmpty, IsOptional } from "class-validator";

export class GetSuggestStoredByPoImportIdRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  poImportId: number;

  @ApiPropertyOptional()
  @IsOptional()
  itemIds: number[];
}