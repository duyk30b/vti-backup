import { IsInt, IsDate, IsOptional } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';

export class GetListOpenTransactionRequestDto extends BaseDto {
  @IsOptional()
  dateFrom: Date;

  @IsOptional()
  dateTo: Date;

  @IsOptional()
  @IsInt()
  warehouseId: number;

  @IsOptional()
  itemIds: number[];
}
