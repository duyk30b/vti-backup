import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class PurchasedOrderImportCompleteQueryDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @IsString()
  note: string;
}

export class PurchasedOrderImportCompleteRequestDto extends PurchasedOrderImportCompleteQueryDto {
  @ApiProperty()
  @IsNotEmpty()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
