import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { ValidateOrderDetailAbstract } from '@core/abstracts/validate-order-detail.abstract';
import { Inject, Injectable } from '@nestjs/common';
import { keyBy, isEmpty, map, flatMap } from 'lodash';

@Injectable()
export class ValidatePoiDetailWithWarehouseExportProposalDetail extends ValidateOrderDetailAbstract {
  constructor(
    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,
  ) {
    super(itemService);
  }

  public async validateItems(items: any, id: number) {
    return super.validateItems(items, id);
  }

  protected async validateOrderDetailWithBaseCondition(
    items: any,
    id: number,
  ): Promise<any> {
    const warehouseExportProposal =
      await this.warehouseService.getWarehouseExportProposalDetail(id);
    if (isEmpty(warehouseExportProposal)) {
      return {
        success: false,
        message: 'error.WAREHOUSE_EXPORT_PROPOSAL_NOT_FOUND',
      };
    }
    const warehouseExportProposalDetailChilds = map(
      warehouseExportProposal.items,
      'childrens',
    );
    const warehouseExportProposalDetailsByItemId = keyBy(
      flatMap(warehouseExportProposalDetailChilds),
      'itemId',
    );
    const notExistedItems = items.filter(
      (item) => !warehouseExportProposalDetailsByItemId[item.id],
    );
    if (!isEmpty(notExistedItems)) {
      return {
        success: false,
        message: 'error.ITEM_NOT_EXIST_IN_WAREHOUSE_EXPORT_PROPOSAL',
        data: notExistedItems,
      };
    }

    const invalidQuantityItems = items.filter((item) => {
      const baseItem = warehouseExportProposalDetailsByItemId[item.id];
      return (
        item.quantity >
        baseItem?.requestedQuantity - baseItem?.importedActualQuantity
      );
    });
    if (!isEmpty(invalidQuantityItems)) {
      return {
        success: false,
        message: 'error.ITEM_QUANTITY_IS_OVER_IMPORTED_QUANTITY',
        data: invalidQuantityItems,
      };
    }

    return {
      success: true,
    };
  }
}
