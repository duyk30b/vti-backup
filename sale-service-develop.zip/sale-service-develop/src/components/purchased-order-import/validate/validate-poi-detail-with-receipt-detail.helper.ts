import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { ReceiptRepositoryInterface } from '@components/receipt/interface/receipt.repository.interface';
import { ValidateOrderDetailAbstract } from '@core/abstracts/validate-order-detail.abstract';
import { Inject, Injectable } from '@nestjs/common';
import { keyBy, isEmpty } from 'lodash';

@Injectable()
export class ValidatePoiDetailWithReceiptDetail extends ValidateOrderDetailAbstract {
  constructor(
    @Inject('ReceiptRepositoryInterface')
    protected readonly receiptRepository: ReceiptRepositoryInterface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,
  ) {
    super(itemService);
  }

  public async validateItems(items: any, id: number) {
    return super.validateItems(items, id);
  }

  protected async validateOrderDetailWithBaseCondition(
    items: any,
    id: number,
  ): Promise<any> {
    const receipt = await this.receiptRepository.findOneWithRelations({
      where: { id },
      relations: ['receiptDetails'],
    });
    if (isEmpty(receipt)) {
      return {
        success: false,
        message: 'error.RECEIPT_NOT_FOUND',
      };
    }

    const { receiptDetails } = receipt;

    const receiptDetailsByItemId = keyBy(receiptDetails, 'itemId');
    const notExistedItems = items.filter(
      (item) => !receiptDetailsByItemId[item.id],
    );
    if (!isEmpty(notExistedItems)) {
      return {
        success: false,
        message: 'error.ITEM_NOT_EXIST_IN_RECEIPT',
        data: notExistedItems,
      };
    }

    const itemById = keyBy(items, 'id');
    const missedItems = receiptDetails.filter((item) => !itemById[item.itemId]);
    if (!isEmpty(missedItems)) {
      return {
        success: false,
        message: 'error.MISSING_ITEM_BASED_ON_RECEIPT',
        data: notExistedItems,
      };
    }

    const invalidQuantityItems = items.filter((item) => {
      const baseItem = receiptDetailsByItemId[item.id];
      return item.quantity != baseItem?.quantity;
    });
    if (!isEmpty(invalidQuantityItems)) {
      return {
        success: false,
        message: 'error.ITEM_QUANTITY_IS_NOT_EQUAL_RECEIPT_ITEM_QUANTITY',
        data: invalidQuantityItems,
      };
    }

    return {
      success: true,
    };
  }
}
