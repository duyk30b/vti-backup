import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { SaleOrderExportRepositoryInterface } from '@components/sale-order-export/interface/sale-order-export.repository.interface';
import { Inject, Injectable } from '@nestjs/common';
import { In } from 'typeorm';
import { isEmpty, map, groupBy, first, flatMap } from 'lodash';
import { PurchasedOrderImportRepositoryInterface } from '../interface/purchased-order-import.repository.interface';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { OrderStatusEnum, OrderTypeEnum } from '@constant/order.constant';
import { plus } from '@utils/helper';
@Injectable()
export class ValidatePoiDetailWithSoeDetailAfterConfirm {
  constructor(
    @Inject('SaleOrderExportRepositoryInterface')
    protected readonly saleOrderExportRepository: SaleOrderExportRepositoryInterface,

    @Inject('PurchasedOrderImportRepositoryInterface')
    protected readonly purchasedOrderImportRepository: PurchasedOrderImportRepositoryInterface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,
  ) {}

  public async validateOrderDetailAfterConfirmWithBaseCondition(
    purchasedOrderImport: any,
    id: number,
  ): Promise<any> {
    const saleOrderExport =
      await this.saleOrderExportRepository.findOneWithRelations({
        where: { id },
        relations: ['saleOrderExportDetails'],
      });
    if (isEmpty(saleOrderExport)) {
      return {
        success: false,
        message: 'error.SALE_ORDER_EXPORT_NOT_FOUND',
      };
    }
    const { saleOrderExportDetails } = saleOrderExport;

    let purchasedOrderImportListBaseUseSoExport = [];
    if (!isEmpty(purchasedOrderImport.attributes)) {
      const attributeGroup = groupBy(
        purchasedOrderImport.attributes,
        'tableName',
      );
      if (!isEmpty(attributeGroup?.sale_order_exports)) {
        purchasedOrderImportListBaseUseSoExport =
          await this.warehouseService.getBusinessTypeListTransaction(
            first(attributeGroup.sale_order_exports)?.code,
            id.toString(),
            OrderTypeEnum.PO,
          );
      }
    }
    const purchasedOrderImportIds = map(
      purchasedOrderImportListBaseUseSoExport,
      'orderId',
    );
    const purchasedOrderImports =
      await this.purchasedOrderImportRepository.findWithRelations({
        where: {
          id: In(purchasedOrderImportIds),
          status: OrderStatusEnum.Confirmed,
        },
        relations: ['purchasedOrderImportDetails'],
      });
    const purchasedOrderImportItems = purchasedOrderImports.map((item) =>
      item.purchasedOrderImportDetails.map((itemDetail) => {
        return {
          quantity: itemDetail.quantity,
          itemId: itemDetail.itemId,
        };
      }),
    );
    const invalidItems = [];
    saleOrderExportDetails.map((itemSo) => {
      const invalidItem = flatMap(purchasedOrderImportItems).filter(
        (itemPo) => itemPo.itemId === itemSo.itemId,
      );
      const quantity = invalidItem.reduce(
        (cur, prev) => plus(cur, prev?.quantity),
        0,
      );
      if (quantity >= itemSo.actualQuantity) {
        invalidItems.push(itemSo);
      }
    });
    if (!isEmpty(invalidItems)) {
      return {
        success: false,
        message:
          'error.ITEM_QUANTITY_IS_NOT_OVER_SALE_ORDER_EXPORT_ITEM_ACTUAL_QUANTITY',
        data: invalidItems,
      };
    }
    return {
      success: true,
    };
  }
}
