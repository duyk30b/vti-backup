import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { SaleOrderExportRepositoryInterface } from '@components/sale-order-export/interface/sale-order-export.repository.interface';
import { ValidateOrderDetailAbstract } from '@core/abstracts/validate-order-detail.abstract';
import { Inject, Injectable } from '@nestjs/common';
import { keyBy, isEmpty } from 'lodash';

@Injectable()
export class ValidatePoiDetailWithSoeDetail extends ValidateOrderDetailAbstract {
  constructor(
    @Inject('SaleOrderExportRepositoryInterface')
    protected readonly saleOrderExportRepository: SaleOrderExportRepositoryInterface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,
  ) {
    super(itemService);
  }

  public async validateItems(items: any, id: number) {
    return super.validateItems(items, id);
  }

  protected async validateOrderDetailWithBaseCondition(
    items: any,
    id: number,
  ): Promise<any> {
    const saleOrderExport =
      await this.saleOrderExportRepository.findOneWithRelations({
        where: { id },
        relations: ['saleOrderExportDetails'],
      });
    if (isEmpty(saleOrderExport)) {
      return {
        success: false,
        message: 'error.SALE_ORDER_EXPORT_NOT_FOUND',
      };
    }

    const { saleOrderExportDetails } = saleOrderExport;
    const saleOrderExportDetailsByItemId = keyBy(
      saleOrderExportDetails,
      'itemId',
    );

    const notExistedItems = items.filter((item) => ![item.id]);
    if (!isEmpty(notExistedItems)) {
      return {
        success: false,
        message: 'error.ITEM_NOT_EXIST_IN_SALE_ORDER_EXPORT',
        data: notExistedItems,
      };
    }

    const invalidQuantityItems = items.filter((item) => {
      const baseItem = saleOrderExportDetailsByItemId[item.id];
      return item.quantity > baseItem?.quantity;
    });
    if (!isEmpty(invalidQuantityItems)) {
      return {
        success: false,
        message:
          'error.ITEM_QUANTITY_IS_NOT_OVER_SALE_ORDER_EXPORT_ITEM_QUANTITY',
        data: invalidQuantityItems,
      };
    }

    const invalidActualQuantityItems = items.filter((item) => {
      const baseItem = saleOrderExportDetailsByItemId[item.id];
      return item.quantity > baseItem?.actualQuantity;
    });
    if (!isEmpty(invalidActualQuantityItems)) {
      return {
        success: false,
        message:
          'error.ITEM_QUANTITY_IS_NOT_OVER_SALE_ORDER_EXPORT_ITEM_ACTUAL_QUANTITY',
        data: invalidActualQuantityItems,
      };
    }

    return {
      success: true,
    };
  }
}
