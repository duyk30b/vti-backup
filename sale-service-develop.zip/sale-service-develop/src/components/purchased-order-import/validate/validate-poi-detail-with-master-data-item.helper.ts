import { ItemServiceInterface } from "@components/item/interface/item.service.interface";
import { ValidateOrderDetailAbstract } from "@core/abstracts/validate-order-detail.abstract";
import { Inject, Injectable } from "@nestjs/common";

@Injectable()
export class ValidatePoiDetailWithMasterDataItem extends ValidateOrderDetailAbstract {
  constructor(
    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,
  ) {
    super(itemService);
  }

  public async validateItems(items: any, id?: number) {
    return super.validateItems(items, id);
  }

  protected async validateOrderDetailWithBaseCondition(): Promise<any> {
    return {
      success: true,
    }
  }
}