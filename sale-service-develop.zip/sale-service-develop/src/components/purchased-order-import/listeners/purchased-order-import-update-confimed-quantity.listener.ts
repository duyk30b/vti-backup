import { OrderTypeEnum } from '../../../constant/order.constant';
import { OrderUpdateConfirmedQuantityEvent } from '@components/order/events/order-update-confirmed-quantity.event';
import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { PurchasedOrderImportRepositoryInterface } from '../interface/purchased-order-import.repository.interface';
import { OrderUpdateConfirmedQuantityListener } from '@components/order/listeners/order-update-confimed-quantity.listener';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { PurchasedOrderRepositoryInterface } from '@components/purchased-order/interface/purchased-order.repository.interface';

@Injectable()
export class PurchasedOrderUpdateConfirmedQuantityListener extends OrderUpdateConfirmedQuantityListener {
  constructor(
    @Inject('PurchasedOrderImportRepositoryInterface')
    private readonly purchasedOrderImportRepository: PurchasedOrderImportRepositoryInterface,

    @Inject('PurchasedOrderRepositoryInterface')
    private readonly purchasedOrderRepository: PurchasedOrderRepositoryInterface,

    @Inject('WarehouseCronServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,
  ) {
    super();
  }

  @OnEvent('order.updateConfirmedQuantity')
  async handleOrderCreatedEvent(event: OrderUpdateConfirmedQuantityEvent) {
    const { id, orderType } = event;
    let order;
    if (orderType === OrderTypeEnum.PO) {
      order = await this.purchasedOrderImportRepository.checkReadyToComplete(
        id,
      );
    }
    if (order) {
      await this.purchasedOrderImportRepository.setCompleted(id);
    }

    return;
  }
}
