import { OrderTypeEnum } from '../../../constant/order.constant';
import { OnEvent } from '@nestjs/event-emitter';
import { OrderUpdateActualQuantityListener } from '@components/order/listeners/order-update-actual-quantity.listener';
import { PurchasedOrderImportRepositoryInterface } from '../interface/purchased-order-import.repository.interface';
import { Inject, Injectable } from '@nestjs/common';
import { OrderUpdateActualQuantityEvent } from '@components/order/events/order-update-actual-quantity.event';
import { PurchasedOrderImportEntity } from '@entities/purchased-order-import/purchased-order-import.entity';
import { PurchasedOrderDetailRepositoryInterface } from '@components/purchased-order/interface/purchased-order-detail.repository.interface';
import { DataSource, In } from 'typeorm';
import { map, sumBy, uniq } from 'lodash';
import { CAN_UPDATE_ACTUAL_QUANTITY_PO } from '@constant/common';
import { plus } from '@utils/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { PurchasedOrderDetail } from '@entities/purchased-order/purchased-order-detail.entity';

@Injectable()
export class PurchasedOrderUpdateActualQuantityListener extends OrderUpdateActualQuantityListener {
  constructor(
    @Inject('PurchasedOrderImportRepositoryInterface')
    private readonly purchasedOrderImportRepository: PurchasedOrderImportRepositoryInterface,

    @Inject('PurchasedOrderDetailRepositoryInterface')
    private readonly purchasedOrderDetailRepository: PurchasedOrderDetailRepositoryInterface,

    @InjectDataSource()
    private readonly connection: DataSource,
  ) {
    super();
  }

  @OnEvent('order.updateActualQuantity')
  async handleOrderUpdateActualQuantityEvent(
    event: OrderUpdateActualQuantityEvent,
    itemLots: any,
  ) {
    const { id, orderType } = event;
    let order: PurchasedOrderImportEntity;

    if (orderType === OrderTypeEnum.PO) {
      order = await this.purchasedOrderImportRepository.findOneWithRelations({
        where: {
          id,
        },
        relations: ['purchasedOrder'],
      });
      const purchasedOrderId = order.purchasedOrderId;
      const purchasedOrderDetails =
        await this.purchasedOrderDetailRepository.findByCondition({
          purchasedOrderId,
          itemId: In(uniq(map(itemLots, 'itemId'))),
        });
      if (CAN_UPDATE_ACTUAL_QUANTITY_PO.includes(order.purchasedOrder.status)) {
        purchasedOrderDetails.forEach((purchasedOrderDetail) => {
          const itemLotQuantity = sumBy(
            itemLots.filter(
              (itemLot) => itemLot.itemId === purchasedOrderDetail.itemId,
            ),
            'quantity',
          );

          purchasedOrderDetail.actualQuantity = plus(
            +purchasedOrderDetail.actualQuantity,
            itemLotQuantity,
          );
        });
      } else {
        order = await this.purchasedOrderImportRepository.findOneById(id);
      }
      const queryRunner = await this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(
          PurchasedOrderDetail,
          purchasedOrderDetails,
        );
        await queryRunner.commitTransaction();
      } catch (error) {
        console.log(error);
        await queryRunner.rollbackTransaction();
      } finally {
        await queryRunner.release();
      }
    }
    return await this.checkAndUpdateInProgessOrderStatus(order);
  }

  public async updateInProgessOrderStatus(order) {
    return await this.purchasedOrderImportRepository.create(order);
  }
}
