import { ReasonRepositoryInterface } from '@components/reason/interface/reason.repository.interface';
import { plainToInstance } from 'class-transformer';
import { WarehouseCronService } from '@components/warehouse/warehouse.cron.service';
import { isEmpty, groupBy, map, first, keyBy } from 'lodash';
import { ConfigService } from '@config/config.service';
import { DatasyncServiceInterface } from '@components/datasync/interface/datasync.service.interface';
import { PurchasedOrderImportRepositoryInterface } from '@components/purchased-order-import/interface/purchased-order-import.repository.interface';
import { SyncDataRequestDto } from '@components/sync-data/dto/request/sync-data.request.dto';
import { SyncDataToHQListener } from '@components/sync-data/listeners/sync-data-to-hq.listener';
import {
  ProcessSyncDataEnum,
  RepositorySyncDataEnum,
  SYNC_TO_SYSTEM_ENUM,
  TypeTransactionDataSyncEnum,
} from '@components/sync-data/sync-data.constant';
import { QUEUES_NAME_ENUM } from '@constant/common';
import { InjectQueue } from '@nestjs/bull';
import { Inject } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { EventSyncPoImportEnum } from '../purchased-order-import.contant';
import Queue from 'bull';
import { OrderTypeEnum as SaleOrderTypeEnum } from '@constant/order.constant';
import { GetAttributeDetailValuesRequestDto } from '@components/warehouse/dto/request/get-attribute-detail-values.request.dto';
import { ItemService } from '@components/item/item.service';
import { SyncPurchasedOrderRequestDto } from '../events/sync-purchased-order-import.request';
import { SourceRepositoryInterface } from '@components/source/interface/sources.repository.interface';
import { UserService } from '@components/user/user.service';
import { PushQueueEvent } from '@components/sync-data/event/push-queue.event';

export class SyncPoImportListener extends SyncDataToHQListener {
  constructor(
    @InjectQueue(QUEUES_NAME_ENUM.SYNC_DATA_QUEUE)
    protected queue: Queue,

    @Inject('DatasyncServiceInterface')
    protected datasyncService: DatasyncServiceInterface,

    @Inject('PurchasedOrderImportRepositoryInterface')
    private readonly purchasedOrderImportRepository: PurchasedOrderImportRepositoryInterface,

    @Inject('ReasonRepositoryInterface')
    private readonly reasonRepository: ReasonRepositoryInterface,

    @Inject('SourceRepositoryInterface')
    private readonly sourceRepository: SourceRepositoryInterface,

    @Inject('WarehouseCronServiceInterface')
    private readonly warehouseService: WarehouseCronService,

    @Inject('UserServiceInterface')
    private readonly userService: UserService,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemService,
  ) {
    super(queue, datasyncService);
  }

  async getDetailPoImport(id: number): Promise<any> {
    const purchasedOrderImport =
      await this.purchasedOrderImportRepository.findOneWithRelations({
        where: {
          id,
        },
        relations: [
          'purchasedOrderImportDetails',
          'purchasedOrderImportWarehouseLots',
        ],
      });
    const itemIds = map(
      purchasedOrderImport.purchasedOrderImportDetails,
      'itemId',
    );
    const [items, warehouses, businessType] = await Promise.all([
      this.itemService.getItems(itemIds),
      this.warehouseService.getWarehouses([purchasedOrderImport.warehouseId]),
      this.warehouseService.getBusinessTypeDetail(
        purchasedOrderImport.businessTypeId,
        id,
        SaleOrderTypeEnum.PO,
      ),
    ]);
    let reason, source, departmentReceipt;
    if (purchasedOrderImport.reasonId) {
      reason = await this.reasonRepository.findOneById(
        purchasedOrderImport.reasonId,
      );
    }
    if (purchasedOrderImport.sourceId) {
      source = await this.sourceRepository.findOneById(
        purchasedOrderImport.sourceId,
      );
    }
    if (purchasedOrderImport.departmentReceiptId) {
      departmentReceipt = await this.userService.getDepartmentReceiptById(
        purchasedOrderImport.departmentReceiptId,
      );
    }
    const warehouse = first(warehouses);
    const serializeItem = keyBy(items, 'itemId');
    const attributes = businessType.bussinessTypeAttributes;

    let attributeDetailValues = {} as any;
    if (!isEmpty(attributes)) {
      const attributeGroup = groupBy(attributes, 'tableName');
      const payload = new GetAttributeDetailValuesRequestDto();
      const attributeKeys = Object.keys(attributeGroup).filter(
        (el) => !el.match('null'),
      );
      payload.filter = attributeKeys.map((key) => {
        return {
          tableName: key,
          id: map(attributeGroup[key], 'value').join(','),
        };
      });
      attributeDetailValues =
        await this.warehouseService?.getAttributeDetailValuesTcp(payload);
    }
    const company = await this.userService.getCompanyDefault();
    const vendor = first(attributeDetailValues?.vendors);
    const construction = first(attributeDetailValues?.constructions);
    const warehouseExportProposal = first(
      attributeDetailValues?.warehouse_export_proposals,
    );
    return plainToInstance(
      SyncPurchasedOrderRequestDto,
      {
        warehouse,
        vendor: vendor,
        construction: construction,
        source: source,
        reason: reason,
        departmentReceipt: departmentReceipt,
        warehouseExportProposal: warehouseExportProposal,
        ...purchasedOrderImport,
        syncCode: company.code,
        companyCode: company.code,
        company: {
          name: company.name,
          code: company.code,
          address: company.address,
        },
        purchasedOrderImportDetails:
          purchasedOrderImport.purchasedOrderImportDetails.map(
            (purchasedOrderImportDetail) => {
              return {
                ...purchasedOrderImportDetail,
                item: serializeItem[+purchasedOrderImportDetail.itemId],
                lots: purchasedOrderImport.purchasedOrderImportWarehouseLots.filter(
                  (lot) => lot.itemId === purchasedOrderImportDetail.itemId,
                ),
              };
            },
          ),
      },
      {
        excludeExtraneousValues: true,
      },
    );
  }

  @OnEvent(EventSyncPoImportEnum.Update)
  async updateItem(id: number) {
    const data = await this.getDetailPoImport(id);
    const request = {
      id: id,
      masterData: RepositorySyncDataEnum.PoImport,
      data: data,
    } as SyncDataRequestDto;
    await this.pushQueue(
      this.getInfoQueue(ProcessSyncDataEnum.UpdatePoImport, data),
      request,
    );

    await this.pushQueue(
      this.getInfoQueue(ProcessSyncDataEnum.UpdatePoImportHQ, data),
      request,
    );
  }

  @OnEvent(EventSyncPoImportEnum.Delete)
  async deleteItem(id: number) {
    const data = await this.getDetailPoImport(id);
    const request = {
      id: id,
      masterData: RepositorySyncDataEnum.PoImport,
      data: data,
    } as SyncDataRequestDto;
    await this.pushQueue(
      this.getInfoQueue(ProcessSyncDataEnum.DeletePoImport, data),
      request,
    );

    await this.pushQueue(
      this.getInfoQueue(ProcessSyncDataEnum.DeletePoImportHQ, data),
      request,
    );
  }

  private getInfoQueue(process: string, data) {
    const infoQueue = new PushQueueEvent();
    infoQueue.process = process;
    infoQueue.resourceCode = data.code;
    infoQueue.typeTransaction = TypeTransactionDataSyncEnum.PO_IMPORT;
    infoQueue.toSystem = SYNC_TO_SYSTEM_ENUM.COMPANY_HQ;
    return infoQueue;
  }
}
