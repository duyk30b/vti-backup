import { OrderTypeEnum } from '../../../constant/order.constant';
import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { PurchasedOrderImportRepositoryInterface } from '../interface/purchased-order-import.repository.interface';
import { OrderStatusEnum } from '@constant/common';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { PurchasedOrderRepositoryInterface } from '@components/purchased-order/interface/purchased-order.repository.interface';
import { OrderUpdateStatusListener } from '@components/order/listeners/order-update-status.listener';
import { OrderUpdateStatusEvent } from '@components/order/events/order-update-status.event';
import { PO_IMPORT_STATUS_CAN_COMPLETED_PO } from '../purchased-order-import.contant';
import { isEmpty } from 'lodash';

@Injectable()
export class PurchasedOrderUpdateStatusListener extends OrderUpdateStatusListener {
  constructor(
    @Inject('PurchasedOrderImportRepositoryInterface')
    private readonly purchasedOrderImportRepository: PurchasedOrderImportRepositoryInterface,

    @Inject('PurchasedOrderRepositoryInterface')
    private readonly purchasedOrderRepository: PurchasedOrderRepositoryInterface,

    @Inject('WarehouseCronServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,
  ) {
    super();
  }

  @OnEvent('order.updateStatus')
  async handleOrderCreatedEvent(event: OrderUpdateStatusEvent) {
    const { id, orderType } = event;

    if (orderType === OrderTypeEnum.PO) {
      const poImports = await this.purchasedOrderImportRepository.findByCondition(
        {
          purchasedOrderId: id,
        },
      );

      let check = true;

      poImports.forEach((poImp) => {
        if (!PO_IMPORT_STATUS_CAN_COMPLETED_PO.includes(poImp.status)) {
          check = false;
        }
      });

      if (check) {
        const purchasedOrder = await this.purchasedOrderRepository.findOneById(
          id,
        );

        if (!isEmpty(purchasedOrder)) {
          const isPurchasedOrderComplete = await this.purchasedOrderRepository.checkComplete(
            id,
          );

          if (isPurchasedOrderComplete) {
            purchasedOrder.status = OrderStatusEnum.Completed;
            await this.purchasedOrderRepository.create(purchasedOrder);
          }
        }
      }
    }

    return;
  }
}
