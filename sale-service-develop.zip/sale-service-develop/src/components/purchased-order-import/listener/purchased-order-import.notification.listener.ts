import { PushNotificationRequestDto } from '@components/notification/dto/notification.request.dto';
import { NotificationService } from '@components/notification/notification.service';
import { NotificationListenerAbstract } from '@core/abstracts/notification.listener.abstract';
import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { OnEvent } from '@nestjs/event-emitter';

@Injectable()
export class PurchasedOrderImportListener extends NotificationListenerAbstract {
  constructor(
    protected readonly configService: ConfigService,
    protected readonly notificationService: NotificationService,
  ) {
    super(notificationService);
  }

  @OnEvent('purchased_order_import.created')
  public async createListener(event: PushNotificationRequestDto) {
    return super.pushRealtimeNotification(event);
  }

  @OnEvent('purchased_order_import.confirm')
  public async confirmListener(event: PushNotificationRequestDto) {
    return super.pushRealtimeNotification(event);
  }

  @OnEvent('purchased_order_import.reject')
  public async rejectListener(event: PushNotificationRequestDto) {
    return super.pushRealtimeNotification(event);
  }

  @OnEvent('purchased_order_import.reject_received')
  public async rejectReceivedListener(event: PushNotificationRequestDto) {
    return super.pushRealtimeNotification(event);
  }
}
