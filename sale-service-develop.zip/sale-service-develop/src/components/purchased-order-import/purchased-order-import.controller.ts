import { BaseDto } from './../../core/dto/base.dto';
import { UpdateOrderDetailReturnQuantityRequestDto } from '@components/order/dto/request/update-return-quantity-order-detail.request.dto';
import { GetLotNumberByItemIdRequestDto } from '@components/import-order/dto/request/list-lot-number.request.dto';
import { GetListLotNumberResponseDto } from '@components/import-order/dto/response/list-lot-number.response.dto';
import { ApiConsumes, ApiOperation, ApiResponse } from '@nestjs/swagger';
import {
  GetOrderDetailByWarehouseQueryDto,
  GetOrderDetailByWarehouseRequestDto,
} from '../order/dto/request/get-order-detail-by-warehouse.request.dto';
import { SetOrderStatusBodyDto } from '../order/dto/request/set-order-status-request.dto';
import { UpdatePurchasedOrderImportBody } from './dto/request/update-purchased-order-import-request.dto';
import { GetOrderDetailRequestDto } from '../order/dto/request/get-order-detail.request.dto';
import { GetPurchasedOrderImportListRequest } from './dto/request/get-purchased-order-import-list-request.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Req,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { GetOrderRequestDto } from '@components/order/dto/request/get-order.request.dto';
import { isEmpty } from 'lodash';
import { UpdateOrderDetailActualQuantityRequestDto } from '@components/order/dto/request/update-actual-quantity-order-detail.request.dto';
import { PurchasedOrderImportService } from './purchased-order-import.service';
import { UpdateOrderDetailConfirmQuantityRequestDto } from '@components/order/dto/request/update-confirm-quantity-order-detail.request.dto';
import { CreatePurchasedOrderImportBodyDto } from './dto/request/create-purchased-order-import.dto';
import { DeleteOrderRequestDto } from '@components/order/dto/request/delete-order.request.dto';
import { GetAllPOImportRequest } from './dto/request/get-all-po-import.request.dto';
import { GetListOrderByIdsRequestDto } from '@components/order/dto/request/get-list-order-by-ids.request.dto';
import { GetByItemIdRequestDto } from '@components/purchased-order/dto/request/get-by-item-id.request.dto';
import {
  GetOrderWarehouseQueryRequest,
  GetOrderWarehouseRequest,
} from '@components/order/dto/request/get-order-warehouse.request.dto';
import { GetOrderByWarehouseItemRequestDto } from '@components/order/dto/request/get-order-by-warehouse-item.request.dto';
import { UpdatePurchasedOrderImportWarehouseQcQuantityDto } from './dto/request/update-purchased-order-import-warehouse-qc-quantity-request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CREATE_PURCHASED_ORDER_IMPORT_PERMISSION,
  UPDATE_PURCHASED_ORDER_IMPORT_PERMISSION,
  DELETE_PURCHASED_ORDER_IMPORT_PERMISSION,
  DETAIL_PURCHASED_ORDER_IMPORT_PERMISSION,
  LIST_PURCHASED_ORDER_IMPORT_PERMISSION,
  CONFIRM_PURCHASED_ORDER_IMPORT_PERMISSION,
  REJECT_PURCHASED_ORDER_IMPORT_PERMISSION,
  IMPORT_PURCHASED_ORDER_IMPORT_PERMISSION,
  APPROVE_PURCHASED_ORDER_IMPORT_PERMISSION,
  REJECT_RECEIVED_PURCHASED_ORDER_IMPORT_PERMISSION,
  CREATE_PURCHASED_ORDER_IMPORT_RECEIVE_PERMISSION,
  SYNC_PURCHASED_ORDER_IMPORT_TO_EBS_PERMISSION,
  RETURN_PURCHASED_ORDER_IMPORT_PERMISSION,
  UPDATE_HEADER_PURCHASED_ORDER_IMPORT_PERMISSION,
  CANCEL_SYNC_PURCHASED_ORDER_IMPORT_PERMISSION,
} from '@utils/permissions/purchased-order-import';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { UpdateWarehouseLotRequestDto } from '@components/order/dto/request/update-warehouse-lot.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { SuggestStoredOrderImportBodyDto } from './dto/request/suggest-stored-order-import.request.dto';
import { SubmitPOImportReceiveRequeseDto } from './dto/request/receive/submit-po-import-receive.request.dto';
import { CreatePurchasedOrderImportReceiveRequestDto } from './dto/request/create-purchased-order-import-receive.request.dto';
import { GetPurchasedOrderImportReceiveDetailRequestDto } from './dto/request/get-purchased-order-import-receive-detail.request.dto';
import { GetOrderDoorRequestDto } from '@components/order/dto/request/get-order-door.request.dto';
import { GetSuggestStoredByPoImportIdRequestDto } from './dto/request/get-suggest-stored-by-po-import-id.request.dto';
import { UpdatePurchasedOrderImportReceiveBodyDto } from './dto/request/update-purchased-order-import-receive.request.dto';
import { GetByItemIdsRequestDto } from './dto/request/get-by-item-ids.request.dto';
import {
  PurchasedOrderImportCompleteQueryDto,
  PurchasedOrderImportCompleteRequestDto,
} from './dto/request/purchased-order-import-complete.request.dto';
import { GetErrorItemByOrderQueryDto } from '../order/dto/request/get-error-item-by-order.request.dto';
import { PurchasedOrderImportResponseDto } from './dto/response/purchased-order-import.response.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { SuggestStoredPurchasedOrderImportResponseDto } from './dto/response/suggest-stored-purchased-order-import.response.dto';
import { PaginationQuery } from '@utils/pagination.query';
import { mapSplitKeyInFormDataToJson } from '@utils/helper';
import { EbsInPOImportRequestDto } from './dto/request/sync/ebs-in-po-import.request.dto';
import { Public } from '@core/decorator/set-public.decorator';
import { GetPurchasedOrderImportByConditions } from './dto/request/get-purchased-order-import-by-conditions.request.dto';
import { CreatePurchasedOrderImportAutoCompleteDto } from './dto/request/create-purchased-order-import-auto-complete.dto';
import { GetListOpenTransactionRequestDto } from './dto/request/get-list-open-transaction.request.dto';
import { UpdateHeaderPurchasedOrderImportBodyDto } from './dto/request/update-header-purchased-orderimport.request';
import { UpdateHeaderEbsInPOIRequest } from './dto/request/sync/update-header-ebs-in-poi.request.dto';
import { CreatePurchasedOrderImportReceiveWithTicketRequestDto } from './dto/request/receive/create-purchased-order-import-receive-with-ticket-order.request.dto';

@Controller('')
export class PurchasedOrderImportController {
  constructor(
    @Inject('PurchasedOrderImportServiceInterface')
    private readonly purchasedOrderImportService: PurchasedOrderImportService,
  ) {}

  // @MessagePattern('ping')
  @Get('ping')
  public async get(@Req() request): Promise<any> {
    return new ResponseBuilder('PURCHASED ORDER: PONG')
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  /**
   * Get data purchase order by id and warehouseId
   * @param request
   * @returns
   */
  @MessagePattern('get_po_import_warehouse_details')
  public async getPoDetail(@Body() payload: GetOrderRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderImportService.getWarehouseDetails(
      request.id,
      request.warehouseId,
      request.type,
    );
  }

  /**
   * Update actual quantity of purchased order detail
   * @param request updateOrderDetailActualQuantityRequestDto
   * @returns
   */
  @MessagePattern('update_po_import_actual_quantity')
  public async updateActualQuantity(
    @Body() payload: UpdateOrderDetailActualQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.updateOrderDetailActualQuantity(
      request,
    );
  }

  // @MessagePattern('suggest_stored_by_purchased_order_import_id')
  @Post('/purchased-order-imports/:id/suggest/stored')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import', 'suggest', 'stored'],
    summary: 'Suggest Purchased Order Import Stored',
    description: 'Suggest import item by order',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully',
    type: SuggestStoredPurchasedOrderImportResponseDto,
  })
  public async suggestStoredByOrderId(
    @Param('id', new ParseIntPipe()) id,
    @Query() query: PaginationQuery,
    @Body() payload: SuggestStoredOrderImportBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.suggestStoredByOrderId({
      ...request,
      ...query,
      id,
    });
  }

  // @MessagePattern('update_po_import_warehouse_lots')
  public async updateWarehouseLots(
    @Body() payload: UpdateWarehouseLotRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.updateWarehouseLots(request);
  }

  /**
   * Update actual quantity of purchased order detail
   * @param request updateOrderDetailActualQuantityRequestDto
   * @returns
   */
  @MessagePattern('update_po_import_confirm_quantity')
  public async updateConfirmQuantity(
    @Body() payload: UpdateOrderDetailConfirmQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.updateOrderDetailConfirmQuantity(
      request,
    );
  }

  @MessagePattern('update_sync_status_po_import')
  public async updateSyncStatus(
    @Body() payload: GetOrderDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.updateSyncStatus(request);
  }

  /**
   * Create new purchased order
   * @param request CreatePurchasedOrderDto
   * @returns
   */
  @PermissionCode(CREATE_PURCHASED_ORDER_IMPORT_PERMISSION.code)
  // @MessagePattern('create_purchased_order_import')
  @Post('purchased-order-imports/create')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import'],
    summary: 'Create Purchased Order Import',
    description: 'Tạo lệnh đặt hàng nhập',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: PurchasedOrderImportResponseDto,
  })
  @ApiConsumes('multipart/form-data')
  public async create(
    @Body() payload: CreatePurchasedOrderImportBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    const mappedObj = mapSplitKeyInFormDataToJson(request);
    request.attributes = !isEmpty(mappedObj)
      ? [...(mappedObj as any)?.attributes]
      : [];
    return await this.purchasedOrderImportService.createPoImport(request);
  }

  /**
   * Create new purchased order
   * @param request CreatePurchasedOrderDto
   * @returns
   */
  @Public()
  // @PermissionCode(CREATE_PURCHASED_ORDER_IMPORT_PERMISSION.code)
  @Post('purchased-order-imports/excute/ebs-in')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import'],
    summary: 'Create Purchased Order Import',
    description: 'Tạo lệnh đặt hàng nhập, hoàn thành lệnh đặt hàng nhập',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async createAutoComplete(
    @Body() payload: CreatePurchasedOrderImportAutoCompleteDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.reasonCode = request.ebsId.split('.')[2] || '';
    return await this.purchasedOrderImportService.createPoImportAutoComplete(
      request,
    );
  }

  /**
   * Update purchased order
   * @param request UpdatePurchasedOrderDto
   * @returns
   */
  @PermissionCode(UPDATE_PURCHASED_ORDER_IMPORT_PERMISSION.code)
  // @MessagePattern('update_purchased_order_import')
  @Put('purchased-order-imports/:id')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import'],
    summary: 'Update Purchased Order Import',
    description: 'Cập nhật lệnh đặt hàng nhập',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: PurchasedOrderImportResponseDto,
  })
  @ApiConsumes('multipart/form-data')
  public async update(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdatePurchasedOrderImportBody,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    const mappedObj = mapSplitKeyInFormDataToJson(request);
    request.attributes = !isEmpty(mappedObj)
      ? [...(mappedObj as any)?.attributes]
      : [];
    request.id = id;
    return await this.purchasedOrderImportService.updatePoImport(request);
  }

  @PermissionCode(UPDATE_HEADER_PURCHASED_ORDER_IMPORT_PERMISSION.code)
  // @MessagePattern('update_purchased_order_import')
  @Put('purchased-order-imports/:id/update-header')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import'],
    summary: 'Update header Purchased Order Import',
    description: 'Cập nhật header lệnh đặt hàng nhập',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: PurchasedOrderImportResponseDto,
  })
  @ApiConsumes('multipart/form-data')
  public async updateHeader(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateHeaderPurchasedOrderImportBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    const mappedObj = mapSplitKeyInFormDataToJson(request);
    request.attributes = !isEmpty(mappedObj)
      ? [...(mappedObj as any)?.attributes]
      : [];
    request.id = id;
    return await this.purchasedOrderImportService.updateHeader(request);
  }

  /**
   * Confirm purchased order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @PermissionCode(CONFIRM_PURCHASED_ORDER_IMPORT_PERMISSION.code)
  // @MessagePattern('confirm_purchased_order_import')
  @Put('purchased-order-imports/:id/confirm')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import'],
    summary: 'Confirm Purchased Order Import',
    description: 'Confirm lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: PurchasedOrderImportResponseDto,
  })
  public async confirm(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: SetOrderStatusBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.purchasedOrderImportService.confirm(request);
  }

  /**
   * Confirm purchased order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @PermissionCode(CONFIRM_PURCHASED_ORDER_IMPORT_PERMISSION.code)
  // @MessagePattern('confirm_purchased_order_import_multiple')
  @Put('purchased-order-imports/confirm/multiple')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import'],
    summary: 'Confirm multiple Purchased Order Import',
    description: 'Confirm nhiều lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: PurchasedOrderImportResponseDto,
  })
  public async confirmMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.confirmMultiple(request);
  }

  /**
   * Reject purchased order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @PermissionCode(REJECT_PURCHASED_ORDER_IMPORT_PERMISSION.code)
  // @MessagePattern('reject_purchased_order_import')
  @Put('purchased-order-imports/:id/reject')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import'],
    summary: 'Reject Purchased Order Import',
    description: 'Reject lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: PurchasedOrderImportResponseDto,
  })
  public async reject(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: SetOrderStatusBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.purchasedOrderImportService.reject(request);
  }

  @PermissionCode(REJECT_RECEIVED_PURCHASED_ORDER_IMPORT_PERMISSION.code)
  // @MessagePattern('reject_received_purchased_order_import')
  @Put('purchased-order-imports/:id/reject-received')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import'],
    summary: 'Reject received Purchased Order Import',
    description: 'Reject nhập lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: SuccessResponse,
  })
  public async rejectReceived(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: SetOrderStatusBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.purchasedOrderImportService.rejectReceived(request);
  }

  /**
   * Reject purchased order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @PermissionCode(REJECT_PURCHASED_ORDER_IMPORT_PERMISSION.code)
  // @MessagePattern('reject_purchased_order_import_multiple')
  @Put('purchased-order-imports/reject/multiple')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import'],
    summary: 'Reject multiple Purchased Order Import',
    description: 'Reject nhiều lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: PurchasedOrderImportResponseDto,
  })
  public async rejectMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.rejectMultiple(request);
  }

  /**
   * Approve purchased order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @PermissionCode(APPROVE_PURCHASED_ORDER_IMPORT_PERMISSION.code)
  // @MessagePattern('approve_purchased_order_import')
  @Put('purchased-order-imports/:id/approve')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import'],
    summary: 'Approve Purchased Order Import',
    description: 'Approve lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: PurchasedOrderImportResponseDto,
  })
  public async approve(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: SetOrderStatusBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.purchasedOrderImportService.approve(request);
  }

  /**
   * Get purchased order list
   * @param request GetPurchasedOrderListRequest
   * @returns
   */
  @PermissionCode(LIST_PURCHASED_ORDER_IMPORT_PERMISSION.code)
  // @MessagePattern('get_purchased_order_import_list')
  @Get('purchased-order-imports/list')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import', 'Mobile'],
    summary: 'Get List Purchased Order Import',
    description: 'Danh sách lệnh đặt hàng nhập',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: PurchasedOrderImportResponseDto,
  })
  public async getList(
    @Query() payload: GetPurchasedOrderImportListRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.getList(request);
  }

  // @MessagePattern('get_purchased_order_import_warehouses')
  @Get('purchased-order-imports/:id/warehouses/list')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import', 'Warehouse'],
    summary: 'Get Purchased Order Import Warehouse List',
    description: 'Danh sách kho của lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: null,
  })
  public async getPurchasedOrderImportWarehouse(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: GetOrderWarehouseQueryRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.purchasedOrderImportService.getListOrderWarehouse(
      request,
    );
  }

  /**
   * Get purchased order detail
   * @param request GetPurchasedOrderListRequest
   * @returns
   */
  // @MessagePattern('get_purchased_order_import_warehouse')
  @Get('/purchased-order-imports/:id/warehouses/:warehouseId')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import', 'Warehouse'],
    summary: 'Get Purchased Order Import Warehouse Detail',
    description: 'Chi tiết kho của lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: null,
  })
  public async getDetailByWarehouseId(
    @Param('id', new ParseIntPipe()) id,
    @Param('warehouseId', new ParseIntPipe()) warehouseId,
    @Query() payload: GetOrderDetailByWarehouseQueryDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    request.warehouseId = warehouseId;
    return await this.purchasedOrderImportService.getDetailByWarehouseId(
      request,
    );
  }

  /**
   * Get purchased order detail by warehouse
   * @param request GetPurchasedOrderListRequest
   * @returns
   */
  @PermissionCode(DETAIL_PURCHASED_ORDER_IMPORT_PERMISSION.code)
  // @MessagePattern('get_purchased_order_import_detail')
  @Get('purchased-order-imports/:id')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import'],
    summary: 'Get Purchased Order Import Detail',
    description: 'Chi tiết lệnh đặt hàng nhập',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: PurchasedOrderImportResponseDto,
  })
  public async getDetail(
    @Param() param: GetOrderDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.getDetail(request);
  }

  // @MessagePattern('get_purchased_order_imports')
  @Get('purchased-order-imports/all')
  @ApiOperation({
    tags: ['Purchased', 'Purchased Order Import'],
    summary: 'Get List Purchase Order Import',
    description: 'Danh sách lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: null,
  })
  public async getPurchasedOrderImports(
    @Query() payload: GetAllPOImportRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderImportService.getPurchasedOrderImports(
      request,
    );
  }

  // @MessagePattern('get_latest_po_import_success')
  public async getLatestPOImportSuccess(
    @Body() payload: GetByItemIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderImportService.getLatestPOImportSuccess(
      request,
    );
  }

  @PermissionCode(DELETE_PURCHASED_ORDER_IMPORT_PERMISSION.code)
  // @MessagePattern('delete_purchased_order_import')
  @Delete('purchased-order-imports/:id')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import'],
    summary: 'Delete Purchased Order Import',
    description: 'Xoá lệnh đặt hàng nhập',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async delete(@Param() param: DeleteOrderRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderImportService.delete(request);
  }

  @PermissionCode(DELETE_PURCHASED_ORDER_IMPORT_PERMISSION.code)
  // @MessagePattern('delete_purchased_order_import_multiple')
  @Delete('purchased-order-imports/multiple')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import'],
    summary: 'Delete multiple Purchased Order Import',
    description: 'Xoá nhiều lệnh đặt hàng nhập',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deleteMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderImportService.deleteMultiple(request);
  }

  @MessagePattern('get_purchased_order_import_by_ids')
  public async getPurchasedOrderImportByIdsTcp(
    @Body() payload: GetListOrderByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderImportService.getListByIds(request);
  }

  @MessagePattern('check_item_has_exist_on_purchase_order_import')
  public async checkItemHasExistOnPurchaseOrder(
    @Body() payload: GetByItemIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderImportService.checkItemHasExistOnPurchaseOrderImport(
      request,
    );
  }

  @MessagePattern('get_po_import_by_warehouse')
  public async getPoByWarehouseItem(
    @Body() payload: GetOrderByWarehouseItemRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderImportService.getPoImportByWarehouse(
      request,
    );
  }

  @MessagePattern('update_purchased_order_import_qc_quantity')
  public async updateQcQuantityTcp(
    @Body() payload: UpdatePurchasedOrderImportWarehouseQcQuantityDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.updatePOQcQuantityPurchasedOrderImportWarehouse(
      request,
    );
  }

  @MessagePattern('get_total_quantity_item_purchased_order_import_by_condition')
  public async getTotalQuantityItemPurchasedOrderImportsByCondition(
    request: any,
  ): Promise<any> {
    return await this.purchasedOrderImportService.getTotalQuantityItemPurchasedOrderImportsByCondition(
      request,
    );
  }

  @PermissionCode(IMPORT_PURCHASED_ORDER_IMPORT_PERMISSION.code)
  @Post('purchased-order-imports/import')
  public async importPurchasedOrderImports(
    @Body() body: FileUpdloadRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.importPurchasedOrderImports(
      request,
    );
  }

  /**
   * Create new purchased order import receive
   * @param payload CreatePurchasedOrderImportReceiveDto
   * @returns
   */
  @PermissionCode(CREATE_PURCHASED_ORDER_IMPORT_RECEIVE_PERMISSION.code)
  @MessagePattern('create_purchased_order_import_receive')
  @Post('purchased-order-imports/receive/create')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import', 'Mobile', 'Receive'],
    summary: 'Create Purchased Order Import Receive',
    description: 'Tạo phiếu nhận hàng (PO import)',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async createPurchasedOrderImportReceive(
    @Body() payload: CreatePurchasedOrderImportReceiveRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.createPurchasedOrderImportReceive(
      request,
    );
  }

  @PermissionCode(CREATE_PURCHASED_ORDER_IMPORT_RECEIVE_PERMISSION.code)
  @MessagePattern('create_purchased_order_import_receive_ticket')
  @Post('purchased-order-imports/receive/ticket/create')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import', 'Mobile', 'Receive'],
    summary: 'Create Purchased Order Import Receive',
    description: 'Tạo phiếu nhận hàng (PO import)',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async createPurchasedOrderImportReceiveTicket(
    @Body() payload: CreatePurchasedOrderImportReceiveWithTicketRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    console.log(
      '🚀 ~ file: purchased-order-import.controller.ts:843 ~ PurchasedOrderImportController ~ request:',
      request,
    );
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.createPurchasedOrderImportReceiveWithTicket(
      request,
    );
  }

  @Get('/purchased-order/items/lots')
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListLotNumberResponseDto,
  })
  @MessagePattern('get_list_lot_number_of_item_poimp')
  public async getListLotNumberByItemId(
    @Query() payload: GetLotNumberByItemIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.getListLotNumberByItemId(
      request.itemIds,
    );
  }

  @Put('purchased-order-imports/receive/:id/confirm')
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListLotNumberResponseDto,
  })
  @MessagePattern('confirm_purchased_order_import_receive')
  public async submitPurchasedOrderImportReceive(
    @Param() param: SubmitPOImportReceiveRequeseDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.submitPOImportReceive(
      request,
    );
  }

  /**
   * Get purchase order import receive detail
   * @param payload
   * @returns
   */
  // @MessagePattern('get_purchased_order_import_receive_detail')
  @Get('purchased-order-imports/receive/:id')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import', 'Mobile', 'Receive'],
    summary: 'Get Purchased Order Import Receive Detail',
    description: 'Chi tiết phiếu nhận hàng (PO import)',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: null,
  })
  public async getPoImportReceiveDetail(
    @Param() param: GetPurchasedOrderImportReceiveDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderImportService.getPoImportReceiveDetail(
      request.id,
    );
  }

  // @MessagePattern('get_purchased_order_import_warehouse_doors')
  @Get('purchased-order-imports/:id/doors/list')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import', 'Warehouse Door'],
    summary: 'Get Purchased Order Import Warehouse Door List',
    description: 'Danh sách cửa kho của lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: null,
  })
  public async getPurchasedOrderImportWarehouseDoors(
    @Param() param: GetOrderDoorRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.getListOrderWarehouseDoor(
      request,
    );
  }

  @MessagePattern('get_suggest_stored_by_po_import_id')
  public async getSuggestStoredByPoImportId(
    @Body() payload: GetSuggestStoredByPoImportIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.getSuggestStoredByPoImportId(
      request,
    );
  }

  // @MessagePattern('update_purchased_order_import_receive')
  @Put('purchased-order-imports/receive/:id')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import'],
    summary: 'Update received Purchased Order Import',
    description: 'Update nhập lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  public async updatePurchasedOrderImportReceive(
    @Param('id', new ParseIntPipe()) id,
    @Body()
    payload: UpdatePurchasedOrderImportReceiveBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;

    return await this.purchasedOrderImportService.updatePurchasedOrderImportReceive(
      request,
    );
  }

  // @MessagePattern('complete_purchased_order_import')
  @Put('purchased-order-imports/:id/complete')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import'],
    summary: 'complete Purchased Order Import',
    description: 'completed lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: PurchasedOrderImportResponseDto,
  })
  public async completePurchasedOrderImport(
    @Param() param: PurchasedOrderImportCompleteRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.completePurchasedOrderImport(
      request,
    );
  }

  @PermissionCode(CANCEL_SYNC_PURCHASED_ORDER_IMPORT_PERMISSION.code)
  @Put('purchased-order-imports/:id/cancel-sync')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import'],
    summary: 'Cancel sync Purchased Order Import',
    description: 'Hủy đồng bộ lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  public async cancelSync(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: SetOrderStatusBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.purchasedOrderImportService.cancelSync(request);
  }

  @Get('purchased-order-imports/:id/movement')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import'],
    summary: 'Lịch sử Purchased Order Import',
    description: 'Lịch sử lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  // @MessagePattern('get_movement_by_purchased_order_import_id')
  public async getHistoryMovementByOrderId(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: PurchasedOrderImportCompleteQueryDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.getHistoryMovementByOrderId({
      ...request,
      id,
    });
  }

  @Get('/purchased-order-imports/:id/error-items')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import'],
    summary: 'Get Purchased Order Import error item',
    description: 'Chi tiết lệnh đặt hàng nhập',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  // @MessagePattern('get_error_items_by_order')
  public async getErrorItemsByOrder(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: GetErrorItemByOrderQueryDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.getErrorItemsByOrder({
      ...request,
      id,
    });
  }

  @MessagePattern('update_po_import_return_quantity')
  public async updateReturnQuantity(
    @Body() payload: UpdateOrderDetailReturnQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.updateOrderDetailReturnQuantity(
      request,
    );
  }

  @MessagePattern('get_purchased_order_import_warehouse')
  public async getDetailByWarehouseIdTcp(
    @Body() payload: GetOrderDetailByWarehouseRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.getDetailByWarehouseId(
      request,
    );
  }

  @PermissionCode(DETAIL_PURCHASED_ORDER_IMPORT_PERMISSION.code)
  @MessagePattern('get_purchased_order_import_detail')
  public async getDetailTcp(
    @Body() param: GetOrderDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.getDetail(request);
  }

  @MessagePattern('get_purchased_order_imports')
  public async getPurchasedOrderImportsTcp(
    @Body() payload: GetAllPOImportRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderImportService.getPurchasedOrderImports(
      request,
    );
  }

  @PermissionCode(LIST_PURCHASED_ORDER_IMPORT_PERMISSION.code)
  @MessagePattern('get_purchased_order_import_list')
  public async getListTcp(
    @Body() payload: GetPurchasedOrderImportListRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.getList(request);
  }

  @MessagePattern('get_purchased_order_import_warehouses')
  public async getPurchasedOrderImportWarehouseTcp(
    @Body() payload: GetOrderWarehouseRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.getListOrderWarehouse(
      request,
    );
  }

  // TODO: Bypass auth test sync EBS
  @Public()
  @Post('purchased-order-imports/sync/ebs-in')
  @ApiOperation({
    tags: ['SYNC', 'EBS'],
  })
  @ApiResponse({
    status: 200,
  })
  public async syncEbsInput(
    @Body() body: EbsInPOImportRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.syncEbsInput(request);
  }

  @PermissionCode(SYNC_PURCHASED_ORDER_IMPORT_TO_EBS_PERMISSION.code)
  @Post('purchased-order-imports/:id/sync/to-ebs')
  public async syncOrderToEbs(
    @Param('id', new ParseIntPipe()) id,
    @Query() query: BaseDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.syncOrderToEbs(
      id,
      request.userId,
    );
  }

  @Get('/purchased-order-imports/condition')
  async getPurchasedOrderImportByConditions(
    @Query() query: GetPurchasedOrderImportByConditions,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.getPurchasedOrderImportByConditions(
      request,
    );
  }

  @PermissionCode(RETURN_PURCHASED_ORDER_IMPORT_PERMISSION.code)
  @Put('purchased-order-imports/:id/return')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order Import'],
    summary: 'Return Purchased Order Import',
    description: 'Return lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: PurchasedOrderImportResponseDto,
  })
  public async return(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: SetOrderStatusBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.purchasedOrderImportService.return(request);
  }

  @MessagePattern('get_list_purchased_order_import_open_transaction')
  public async getListOpenTransaction(
    @Body() body: GetListOpenTransactionRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.getListOpenTransaction(
      request,
    );
  }

  @Public()
  @Post('purchased-order-imports/update-header/ebs-in')
  @ApiOperation({
    tags: ['SYNC', 'EBS'],
  })
  @ApiResponse({
    status: 200,
  })
  public async updateHeaderEbsIn(
    @Body() body: UpdateHeaderEbsInPOIRequest,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderImportService.updateHeaderEbsIn(request);
  }
}
