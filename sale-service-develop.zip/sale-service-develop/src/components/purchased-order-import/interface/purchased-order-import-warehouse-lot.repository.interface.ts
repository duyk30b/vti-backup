import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { PurchasedOrderImportWarehouseLotEntity } from '@entities/purchased-order-import/purchased-order-import-warehouse-lot.entity';

export interface PurchasedOrderImportWarehouseLotRepositoryInterface
  extends BaseInterfaceRepository<PurchasedOrderImportWarehouseLotEntity> {
  getItemWithoutMOLots(warehouseId: number, itemIds: number[]): Promise<any>;
  getLotsByItems(
    itemIds: number[],
    lotNumbers: string[],
    warehouseIds: number[],
    orderId: number,
  ): Promise<any>;
  getDetailLotsByItems(
    itemIds: number[],
    warehouseIds: number[],
    orderId: number,
  ): Promise<any>;
  getListLotNumber(
    itemIds?: number[],
    purchasedOrderImportId?: number,
  ): Promise<any>;
  getItemLotsByPoImportId(
    poImportId: number,
    warehouseId: number,
  ): Promise<any>;
  getLatestLotByWarehouseId(
    warehouseId: number,
  ): Promise<PurchasedOrderImportWarehouseLotEntity>;
}
