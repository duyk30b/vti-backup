import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { PurchasedOrderImportReceiveItemEntity } from '@entities/purchased-order-import/purchased-order-import-receive-item.entity';
import { CreatePurchasedOrderImportReceiveItemEntityRequestDto } from '../dto/request/create-purchased-order-import-receive.request.dto';
import { ItemLot } from '@components/order/dto/request/update-actual-quantity-order-detail.request.dto';

export interface PurchasedOrderImportReceiveItemRepositoryInterface
  extends BaseInterfaceRepository<PurchasedOrderImportReceiveItemEntity> {
  createEntity(
    data: CreatePurchasedOrderImportReceiveItemEntityRequestDto,
  ): PurchasedOrderImportReceiveItemEntity;

  getListByPurchasedOrderImportId(
    purchasedOrderImportId: number,
    itemLots?: ItemLot[],
  ): Promise<PurchasedOrderImportReceiveItemEntity[] | any>;
}
