import { OrderWarehouseDetailRepositoryInterface } from '@components/order/interface/order-warehouse-detail.repository.interface';
import { PurchasedOrderImportWarehouseDetailEntity } from '@entities/purchased-order-import/purchased-order-import-warehouse-detail.entity';

export interface PurchasedOrderImportWarehouseDetailRepositoryInterface
  extends OrderWarehouseDetailRepositoryInterface<PurchasedOrderImportWarehouseDetailEntity> {
  getProExportItemLots(moId: number, warehouseId: number, itemIds: number[]);
  getErrorItemById(id: number): Promise<any>;
}
