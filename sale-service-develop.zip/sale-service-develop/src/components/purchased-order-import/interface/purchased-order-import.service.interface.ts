import { GetOrderByWarehouseItemRequestDto } from '../../order/dto/request/get-order-by-warehouse-item.request.dto';
import { OrderServiceInterface } from '@components/order/interface/order.service.interface';
import { GetByItemIdRequestDto } from '@components/purchased-order/dto/request/get-by-item-id.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { SubmitPOImportReceiveRequeseDto } from '../dto/request/receive/submit-po-import-receive.request.dto';
import { GetSuggestStoredByPoImportIdRequestDto } from '../dto/request/get-suggest-stored-by-po-import-id.request.dto';
import { UpdatePurchasedOrderImportReceiveRequestDto } from '../dto/request/update-purchased-order-import-receive.request.dto';
import { UploadFilesRequest } from '@components/file/dto/upload-files.request';
import { PurchasedOrderImportCompleteRequestDto } from '../dto/request/purchased-order-import-complete.request.dto';
import { GetErrorItemByOrderRequestDto } from '../../order/dto/request/get-error-item-by-order.request.dto';
import { CreatePurchasedOrderImportDto } from '../dto/request/create-purchased-order-import.dto';
import { EbsInPOImportRequestDto } from '../dto/request/sync/ebs-in-po-import.request.dto';
import { GetPurchasedOrderImportByConditions } from '../dto/request/get-purchased-order-import-by-conditions.request.dto';
import { CreatePurchasedOrderImportAutoCompleteDto } from '../dto/request/create-purchased-order-import-auto-complete.dto';
import { GetListOpenTransactionRequestDto } from '../dto/request/get-list-open-transaction.request.dto';
import { CreatePurchasedOrderImportReceiveWithTicketRequestDto } from '../dto/request/receive/create-purchased-order-import-receive-with-ticket-order.request.dto';

export interface PurchasedOrderImportServiceInterface
  extends OrderServiceInterface {
  checkItemHasExistOnPurchaseOrderImport(
    request: GetByItemIdRequestDto,
  ): Promise<any>;
  getPoImportByWarehouse(
    request: GetOrderByWarehouseItemRequestDto,
  ): Promise<any>;
  confirmMultiple(request: DeleteMultipleDto): Promise<any>;
  rejectMultiple(request: DeleteMultipleDto): Promise<any>;
  deleteMultiple(request: DeleteMultipleDto): Promise<any>;
  submitPOImportReceive(request: SubmitPOImportReceiveRequeseDto): Promise<any>;
  getSuggestStoredByPoImportId(
    request: GetSuggestStoredByPoImportIdRequestDto,
  ): Promise<any>;
  updatePurchasedOrderImportReceive(
    request: UpdatePurchasedOrderImportReceiveRequestDto & UploadFilesRequest,
  ): Promise<any>;
  completePurchasedOrderImport(
    request: PurchasedOrderImportCompleteRequestDto,
  ): Promise<any>;
  getErrorItemsByOrder(request: GetErrorItemByOrderRequestDto): Promise<any>;
  createPoImport(
    payload:
      | CreatePurchasedOrderImportDto
      | CreatePurchasedOrderImportAutoCompleteDto,
    autoComplete?: boolean,
  ): Promise<any>;
  syncEbsInput(request: EbsInPOImportRequestDto): Promise<any>;
  syncOrderToEbs(id: number, userId: number): Promise<any>;
  getPurchasedOrderImportByConditions(
    request: GetPurchasedOrderImportByConditions,
  ): Promise<any>;
  createPoImportAutoComplete(
    request: CreatePurchasedOrderImportAutoCompleteDto,
  ): Promise<any>;
  getListOpenTransaction(
    request: GetListOpenTransactionRequestDto,
  ): Promise<any>;
  createPurchasedOrderImportReceiveWithTicket(
    request: CreatePurchasedOrderImportReceiveWithTicketRequestDto,
  ): Promise<any>;
}
