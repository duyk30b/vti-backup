import { OrderDetailRepositoryInterface } from '@components/order/interface/order-detail.repository.interface';
import { PurchasedOrderImportDetailEntity } from '@entities/purchased-order-import/purchased-order-import-detail.entity';

export interface PurchasedOrderImportDetailRepositoryInterface
  extends OrderDetailRepositoryInterface<PurchasedOrderImportDetailEntity> {
  getTotalQuantityItemPurchasedOrderImportsByCondition(
    condition: any,
  ): Promise<any>;
  getPOIsByPurchasedOrderImportIds(
    purchasedOrderImportIds: number[],
    onlyId?: boolean,
  ): Promise<any>;
  getTotalQuantityOfItemByPOIds(
    purchasedOrderIds: number[],
    rejectPurchasedOrderImportId?: number,
  );
  updatePoImportDetailReceivedQuantity(
    poImportDetail: PurchasedOrderImportDetailEntity,
    receivedQuantity: number
  ): PurchasedOrderImportDetailEntity;
}
