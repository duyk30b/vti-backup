import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { PurchasedOrderImportReceiveItemEntity } from '@entities/purchased-order-import/purchased-order-import-receive-item.entity';
import { PurchasedOrderImportReceiveEntity } from '@entities/purchased-order-import/purchased-order-import-receive.entity';
import { CreatePurchasedOrderImportReceiveRequestDto } from '../dto/request/create-purchased-order-import-receive.request.dto';
import { CreatePurchasedOrderImportReceiveWithTicketRequestDto } from '../dto/request/receive/create-purchased-order-import-receive-with-ticket-order.request.dto';
import { UpdatePurchasedOrderImportReceiveRequestDto } from '../dto/request/update-purchased-order-import-receive.request.dto';

export interface PurchasedOrderImportReceiveRepositoryInterface
  extends BaseInterfaceRepository<PurchasedOrderImportReceiveEntity> {
  createEntityWithRelationItems(
    data: CreatePurchasedOrderImportReceiveRequestDto,
    poImportReceiveItemEntities: PurchasedOrderImportReceiveItemEntity[],
  ): PurchasedOrderImportReceiveEntity;
  createEntityWithRelationItemsTicket(
    data: CreatePurchasedOrderImportReceiveWithTicketRequestDto,
    poImportReceiveItemEntities: PurchasedOrderImportReceiveItemEntity[],
  ): PurchasedOrderImportReceiveEntity;
  getPurchasedOrderImportReceiveDetail(id: number): Promise<any>;
  updateEntity(
    id: number,
    request: UpdatePurchasedOrderImportReceiveRequestDto,
    poImportReceiveItemEntities: PurchasedOrderImportReceiveItemEntity[],
  ): PurchasedOrderImportReceiveEntity;
}
