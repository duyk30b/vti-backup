import { ReportDetailOrderRequestDto } from '@components/dashboard/dto/request/report-detail-order.request.dto';
import { ReportTotalOrderRequestDto } from '@components/dashboard/dto/request/report-total-order.request.dto';
import { OrderRepositoryInterface } from '@components/order/interface/order.repository.interface';
import { OrderStatusEnum } from '@constant/common';
import { PurchasedOrderImportEntity } from '@entities/purchased-order-import/purchased-order-import.entity';
import { GetListOpenTransactionRequestDto } from '../dto/request/get-list-open-transaction.request.dto';
import { GetPurchasedOrderImportListRequest } from '../dto/request/get-purchased-order-import-list-request.dto';

export interface PurchasedOrderImportRepositoryInterface
  extends OrderRepositoryInterface<PurchasedOrderImportEntity> {
  getPurchasedOrderImportInProgress(condition: any): Promise<any>;
  checkPurchasedOrderImportCodeExist(
    code: string,
    purchasedOrderImportId?: number,
  ): Promise<any>;
  updatePoImportStatus(
    poImport: PurchasedOrderImportEntity,
    status: OrderStatusEnum,
  ): PurchasedOrderImportEntity;
  getLatestPOImportSuccess(
    itemIds: number[],
  ): Promise<PurchasedOrderImportEntity>;
  setStored(id: number): Promise<any>;
  getListPoImport(request: GetPurchasedOrderImportListRequest): Promise<any>;
  reportTotalOrder(request: ReportTotalOrderRequestDto): Promise<number>;
  reportDetailOrder(request: ReportDetailOrderRequestDto): Promise<any>;
  updateEntity(
    purchasedOrderImportEntity: PurchasedOrderImportEntity,
    data: any,
  ): PurchasedOrderImportEntity;
  getPurchasedOrderImportByConditions(
    warehouseId: number,
    itemIds: number[],
    receiptDate: Date,
    defaultTimeZone?: string,
  ): Promise<any>;
  getListOpenTransaction(
    request: GetListOpenTransactionRequestDto,
    defaultTimeZone: string,
  ): Promise<any>;
}
