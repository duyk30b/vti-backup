import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { Inject } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, In } from 'typeorm';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ConfigService } from '@nestjs/config';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportDataAbstract } from '@core/abstracts/import-data.abstract';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { keyBy, reverse, isEmpty, has, first, omitBy, values } from 'lodash';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Alignment, Borders, FillPattern, Font, Row, Workbook } from 'exceljs';
import { EXCEL_STYLE, HEADER_IN } from '@components/export/export.constant';
import { CreatePurchasedOrderImportDto } from '../dto/request/create-purchased-order-import.dto';
import * as moment from 'moment';
import { divBigNumber } from '@utils/common';
import { ReasonRepositoryInterface } from '@components/reason/interface/reason.repository.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { SourceRepositoryInterface } from '@components/source/interface/sources.repository.interface';
import { ConstructionRepositoryInterface } from '@components/construcion/interface/construction.interface.repository';
import { CategoryContructionRepositoryInterface } from '@components/category-contruction/interface/category-contruction.interface.repository';
import { CostTypeRepositoryInterface } from '@components/cost-type/interface/cost-type.repository.interface';
import { OrganizationPaymentRepositoryInterface } from '@components/organization-payment/interface/organization-payment.repository.interface';
import { VendorRepositoryInterface } from '@components/vendor/interface/vendor.repository.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { BUSINESS_TYPE_ATTRIBUTE_TABLE_NAME } from '../purchased-order-import.contant';

export class PurchasedOrderImportImport extends ImportDataAbstract {
  private readonly ROW_NUMBER_START_DATA = 0;

  private readonly FIELD_TEMPLATE_ITEM_CONST = {
    INDEX: {
      DB_COL_NAME: 'index',
      COL_NAME: 'STT phiếu',
      ALLOW_NULL: true,
    },
    RECEIPT_DATE: {
      DB_COL_NAME: 'receiptDate',
      COL_NAME: 'Ngày lập phiếu',
      ALLOW_NULL: true,
      HEADER_NOT_NULL: true,
    },
    BUSINESS_TYPE: {
      DB_COL_NAME: 'businessType',
      COL_NAME: 'Loại nghiệp vụ',
      ALLOW_NULL: true,
      HEADER_NOT_NULL: true,
    },
    WAREHOUSE: {
      DB_COL_NAME: 'warehouse',
      COL_NAME: 'Kho nhập',
      ALLOW_NULL: true,
      HEADER_NOT_NULL: true,
    },
    REASON: {
      DB_COL_NAME: 'reason',
      COL_NAME: 'Lý do nhập kho',
      ALLOW_NULL: true,
      HEADER_NOT_NULL: true,
    },
    DEPARTMENT_RECEIPT: {
      DB_COL_NAME: 'departmentReceipt',
      COL_NAME: 'Phòng ban nhận',
      ALLOW_NULL: true,
      HEADER_NOT_NULL: true,
    },
    SOURCE: {
      DB_COL_NAME: 'source',
      COL_NAME: 'Nguồn tài khoản kế toán(source)',
      ALLOW_NULL: true,
      HEADER_NOT_NULL: true,
    },
    CONSTRUCTION: {
      DB_COL_NAME: 'construction',
      COL_NAME: 'Công trình',
      ALLOW_NULL: true,
    },
    CATEGORY_CONSTRUCTION: {
      DB_COL_NAME: 'categoryConstruction',
      COL_NAME: 'Hạng mục',
      ALLOW_NULL: true,
    },
    COST_TYPE: {
      DB_COL_NAME: 'costType',
      COL_NAME: 'Loại chi phí',
      ALLOW_NULL: true,
    },
    ORGANIZATION_PAYMENT: {
      DB_COL_NAME: 'organizationPayment',
      COL_NAME: 'Tổ chức chi',
      ALLOW_NULL: true,
    },
    WAREHOUSE_EXPORT_PROPOSAL: {
      DB_COL_NAME: 'warehouseExportProposal',
      COL_NAME: 'Giấy đề nghị',
      ALLOW_NULL: true,
    },
    VENDOR: {
      DB_COL_NAME: 'vendor',
      COL_NAME: 'Nhà cung cấp',
      ALLOW_NULL: true,
    },
    DELIVER: {
      DB_COL_NAME: 'deliver',
      COL_NAME: 'Người giao hàng',
      ALLOW_NULL: true,
    },
    REVEIVER: {
      DB_COL_NAME: 'receiver',
      COL_NAME: 'Người nhận hàng',
      ALLOW_NULL: true,
    },
    EXPLANATION: {
      DB_COL_NAME: 'explanation',
      COL_NAME: 'Diễn giải',
      ALLOW_NULL: true,
    },
    ITEM_INDEX: {
      DB_COL_NAME: 'itemIndex',
      COL_NAME: 'STT vật tư',
      ALLOW_NULL: true,
    },
    ITEM_CODE: {
      DB_COL_NAME: 'itemCode',
      COL_NAME: 'Mã vật tư',
      ALLOW_NULL: true,
    },
    ITEM_NAME: {
      DB_COL_NAME: 'itemName',
      COL_NAME: 'Tên vật tư',
      ALLOW_NULL: true,
    },
    ITEM_UNIT: {
      DB_COL_NAME: 'itemUnit',
      COL_NAME: 'ĐVT',
      ALLOW_NULL: true,
    },
    QUANTITY: {
      DB_COL_NAME: 'quantity',
      COL_NAME: 'SL nhập',
      ALLOW_NULL: true,
    },
    TOTAL_AMOUNT: {
      DB_COL_NAME: 'totalAmount',
      COL_NAME: 'Thành tiền',
      ALLOW_NULL: true,
    },
    PRICE: {
      DB_COL_NAME: 'price',
      COL_NAME: 'Đơn giá',
      ALLOW_NULL: true,
    },

    REQUIRED_COL_NUM: 23,
  };

  private readonly SHEET_NAME = 'Import';

  constructor(
    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,

    @Inject('ReasonRepositoryInterface')
    private readonly reasonRepository: ReasonRepositoryInterface,

    @Inject('SourceRepositoryInterface')
    private readonly sourceRepository: SourceRepositoryInterface,

    @Inject('ConstructionRepositoryInterface')
    private readonly constructionRepository: ConstructionRepositoryInterface,

    @Inject('CostTypeRepositoryInterface')
    private readonly costTypeRepository: CostTypeRepositoryInterface,

    @Inject('CategoryContructionRepositoryInterface')
    private readonly categoryContructionRepository: CategoryContructionRepositoryInterface,

    @Inject('OrganizationPaymentRepositoryInterface')
    private readonly organizationPaymentRepository: OrganizationPaymentRepositoryInterface,

    @Inject('VendorRepositoryInterface')
    private readonly vendorRepository: VendorRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    const arrayField = [];
    for (const [key, value] of Object.entries(this.FIELD_TEMPLATE_ITEM_CONST)) {
      arrayField.push(value);
    }

    this.fieldsMap.groupSet(
      [
        this.FIELD_TEMPLATE_ITEM_CONST.INDEX,
        this.FIELD_TEMPLATE_ITEM_CONST.RECEIPT_DATE,
        this.FIELD_TEMPLATE_ITEM_CONST.BUSINESS_TYPE,
        this.FIELD_TEMPLATE_ITEM_CONST.WAREHOUSE,
        this.FIELD_TEMPLATE_ITEM_CONST.REASON,
        this.FIELD_TEMPLATE_ITEM_CONST.DEPARTMENT_RECEIPT,
        this.FIELD_TEMPLATE_ITEM_CONST.SOURCE,
        this.FIELD_TEMPLATE_ITEM_CONST.CONSTRUCTION,
        this.FIELD_TEMPLATE_ITEM_CONST.CATEGORY_CONSTRUCTION,
        this.FIELD_TEMPLATE_ITEM_CONST.COST_TYPE,
        this.FIELD_TEMPLATE_ITEM_CONST.ORGANIZATION_PAYMENT,
        this.FIELD_TEMPLATE_ITEM_CONST.WAREHOUSE_EXPORT_PROPOSAL,
        this.FIELD_TEMPLATE_ITEM_CONST.VENDOR,
        this.FIELD_TEMPLATE_ITEM_CONST.DELIVER,
        this.FIELD_TEMPLATE_ITEM_CONST.REVEIVER,
        this.FIELD_TEMPLATE_ITEM_CONST.EXPLANATION,
        this.FIELD_TEMPLATE_ITEM_CONST.ITEM_INDEX,
        this.FIELD_TEMPLATE_ITEM_CONST.ITEM_CODE,
        this.FIELD_TEMPLATE_ITEM_CONST.ITEM_NAME,
        this.FIELD_TEMPLATE_ITEM_CONST.ITEM_UNIT,
        this.FIELD_TEMPLATE_ITEM_CONST.QUANTITY,
        this.FIELD_TEMPLATE_ITEM_CONST.TOTAL_AMOUNT,
        this.FIELD_TEMPLATE_ITEM_CONST.PRICE,
      ],
      1,
    );
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
    error: number,
    total: number,
    userId?: number,
    parentService?: any,
  ): Promise<ImportResponseDto> {
    const purchasedOrderImportMap = {};
    const logMap = keyBy(logs, 'id');

    let index = 0;
    let chunk = 10;
    let key = null;
    const joinCharacter = '___';

    const businessTypeCodes = [];
    const warehouseCodes = [];
    const reasonCodes = [];
    const departmentReceiptNames = [];
    const sourceCodes = [];
    const contructionCodes = [];
    const categoryContructionCodes = [];
    const costTypeCodes = [];
    const organizationPaymentCodes = [];
    const warehouseExportProposalCodes = [];
    const vendorCodes = [];
    const itemCodes = [];

    dataDto.forEach((item) => {
      if (item.businessType) {
        businessTypeCodes.push(first(item.businessType.split('-')).trim());
      }
      if (item.warehouse) {
        warehouseCodes.push(item.warehouse.trim());
      }
      if (item.reason) {
        reasonCodes.push(first(item.reason.split('-')).trim());
      }
      if (item.departmentReceipt) {
        departmentReceiptNames.push(item.departmentReceipt.trim());
      }
      if (item.source) {
        sourceCodes.push(first(item.source?.split('--'))?.trim());
      }
      if (item.construction) {
        contructionCodes.push(item.construction.trim());
      }
      if (item.categoryConstruction) {
        categoryContructionCodes.push(item.categoryConstruction.trim());
      }
      if (item.costType) {
        costTypeCodes.push(item.costType.toString().trim());
      }
      if (item.organizationPayment) {
        organizationPaymentCodes.push(
          first(item.organizationPayment.split('-')).trim(),
        );
      }
      if (item.warehouseExportProposal) {
        warehouseExportProposalCodes.push(item.warehouseExportProposal.trim());
      }
      if (item.vendor) {
        vendorCodes.push(first(item.vendor.split('-')).trim());
      }
      if (item.itemCode) {
        itemCodes.push(item.itemCode.trim());
      }

      const newKey = JSON.stringify(
        omitBy(
          {
            receiptDate: item.receiptDate,
            businessType: item.businessType,
            warehouse: item.warehouse,
            reason: item.reason,
            departmentReceipt: item.departmentReceipt,
            source: item.source,
            deliver: item.deliver,
            receiver: item.receiver,
            explanation: item.explanation,
            construction: item.construction,
            categoryConstruction: item.categoryConstruction,
            costType: item.costType,
            organizationPayment: item.organizationPayment,
            warehouseExportProposal: item.warehouseExportProposal,
            vendor: item.vendor,
          },
          (val) => val === '',
        ),
      );

      if (isEmpty(JSON.parse(newKey))) {
        chunk--;
        if (chunk === 0) {
          chunk = 10;
          index = item.i;
        }
      } else {
        chunk = 10;
        index = item.i;
      }

      key = isEmpty(JSON.parse(newKey)) ? key : newKey;

      if (!has(purchasedOrderImportMap, `${key}${joinCharacter}${index}`)) {
        purchasedOrderImportMap[`${key}${joinCharacter}${index}`] = [item];
      } else {
        purchasedOrderImportMap[`${key}${joinCharacter}${index}`].push(item);
      }
    });

    const [
      businessTypes,
      warehouses,
      reasons,
      departmentReceipts,
      sources,
      constructions,
      categoryContructions,
      costTypes,
      organizationPayments,
      warehouseExportProposals,
      vendors,
      items,
    ] = await Promise.all([
      this.warehouseService.getBusinessByCodes(businessTypeCodes),
      this.warehouseService.getWarehouseByCodes(warehouseCodes),
      this.reasonRepository.findByCondition({
        code: In(reasonCodes),
      }),
      isEmpty(departmentReceiptNames)
        ? []
        : this.userService.getDepartmentReceiptsByCodeOrName(
            departmentReceiptNames,
          ),
      this.sourceRepository.findByCondition({
        code: In(sourceCodes),
      }),
      this.constructionRepository.findByCondition({
        code: In(contructionCodes),
      }),
      this.categoryContructionRepository.findByCondition({
        code: In(categoryContructionCodes),
      }),
      this.costTypeRepository.findByCondition({
        code: In(costTypeCodes),
      }),
      this.organizationPaymentRepository.findByCondition({
        code: In(organizationPaymentCodes),
      }),
      this.warehouseService.getWarehouseExportProposalByCodes(
        warehouseExportProposalCodes,
      ),
      this.vendorRepository.findByCondition({
        code: In(vendorCodes),
      }),
      this.itemService.getItemByCodes(itemCodes),
    ]);

    const [
      businessTypeMap,
      warehouseMap,
      reasonMap,
      departmentReceiptByCode,
      departmentReceiptByName,
      sourceMap,
      constructionMap,
      categoryContructionMap,
      costTypeMap,
      organizationPaymentMap,
      warehouseExportProposalMap,
      vendorMap,
      itemMap,
    ] = [
      keyBy(businessTypes, 'code'),
      keyBy(warehouses, 'code'),
      keyBy(reasons, 'code'),
      keyBy(departmentReceipts, 'code'),
      keyBy(departmentReceipts, 'name'),
      keyBy(sources, (e) => `${e.code}_${e.warehouseId}`),
      keyBy(constructions, 'code'),
      keyBy(categoryContructions, 'code'),
      keyBy(costTypes, 'code'),
      keyBy(organizationPayments, 'code'),
      keyBy(warehouseExportProposals, 'code'),
      keyBy(vendors, 'code'),
      keyBy(items, 'code'),
    ];

    const flagHeader = {};

    for (const key in purchasedOrderImportMap) {
      const [rootKey, index] = key.split(joinCharacter);

      const {
        receiptDate,
        businessType,
        warehouse,
        reason,
        departmentReceipt,
        source,
        deliver,
        receiver,
        explanation,
        construction,
        categoryConstruction,
        costType,
        organizationPayment,
        warehouseExportProposal,
        vendor,
      } = JSON.parse(rootKey);

      for (const key in this.FIELD_TEMPLATE_ITEM_CONST) {
        if (
          this.FIELD_TEMPLATE_ITEM_CONST[key].HEADER_NOT_NULL === true &&
          !has(flagHeader, rootKey.toString()) &&
          !JSON.parse(rootKey)[this.FIELD_TEMPLATE_ITEM_CONST[key].DB_COL_NAME]
        ) {
          flagHeader[rootKey.toString()] = (
            await this.i18n.translate('error.IMPORT_FIELD_REQUIRED')
          ).replace(':field', this.FIELD_TEMPLATE_ITEM_CONST[key].COL_NAME);

          logMap[index] = {
            id: +index,
            row: +index,
            log: [flagHeader[rootKey.toString()]],
          } as ImportResultDto;
        }
      }

      const items = purchasedOrderImportMap[key];
      const businessTypeCode = first(businessType?.split('-'))?.trim();
      const reasonCode = first(reason.split('-')).trim();
      const sourceCode = first(source.split('--')).trim();

      const requestCreatePOI = new CreatePurchasedOrderImportDto();
      requestCreatePOI.isImport = true;
      requestCreatePOI.userId = userId;
      requestCreatePOI.deliver = deliver;
      requestCreatePOI.businessTypeId = businessTypeMap[businessTypeCode]?.id;
      requestCreatePOI.reasonId = reasonMap[reasonCode]?.id;
      requestCreatePOI.explanation = explanation;
      requestCreatePOI.receiptDate = moment(receiptDate, 'DD/MM/YYYY').toDate();
      requestCreatePOI.departmentReceiptId =
        departmentReceiptByCode[departmentReceipt]?.id ||
        departmentReceiptByName[departmentReceipt]?.id;
      requestCreatePOI.sourceId =
        sourceMap[`${sourceCode}_${warehouseMap[warehouse]?.id}`]?.id;
      requestCreatePOI.warehouseId = warehouseMap[warehouse]?.id;

      if (!has(sourceMap, `${sourceCode}_${warehouseMap[warehouse]?.id}`)) {
        logMap[index] = {
          id: +index,
          row: +index,
          log: [await this.i18n.translate('error.SOURCE_NOT_FOUND')],
        } as ImportResultDto;
      }

      const attributes = businessTypeMap[
        businessTypeCode
      ]?.bussinessTypeAttributes
        ?.map((attr) => {
          if (
            attr.ebsLabel ===
            BUSINESS_TYPE_ATTRIBUTE_TABLE_NAME.RECEIVER_EBS_LABEL
          )
            return {
              id: attr.id,
              value: receiver,
            };
          switch (attr.tableName) {
            case BUSINESS_TYPE_ATTRIBUTE_TABLE_NAME.CONSTRUCTIONS:
              return {
                id: attr.id,
                value: constructionMap[construction?.trim()]?.id?.toString(),
              };
            case BUSINESS_TYPE_ATTRIBUTE_TABLE_NAME.CATEGORY_CONSTRUCTIONS:
              return {
                id: attr.id,
                value:
                  categoryContructionMap[
                    categoryConstruction?.trim()
                  ]?.id?.toString(),
              };
            case BUSINESS_TYPE_ATTRIBUTE_TABLE_NAME.COST_TYPES:
              return {
                id: attr.id,
                value:
                  costTypeMap[costType?.toString()?.trim()]?.id?.toString(),
              };
            case BUSINESS_TYPE_ATTRIBUTE_TABLE_NAME.ORGANIZATION_PAYMENTS:
              return {
                id: attr.id,
                value:
                  organizationPaymentMap[
                    first(organizationPayment?.split('-'))?.trim()
                  ]?.id?.toString(),
              };
            case BUSINESS_TYPE_ATTRIBUTE_TABLE_NAME.WAREHOUSE_EXPORT_PROPOSALS:
              return {
                id: attr.id,
                value:
                  warehouseExportProposalMap[
                    warehouseExportProposal?.trim()
                  ]?.id?.toString(),
              };
            case BUSINESS_TYPE_ATTRIBUTE_TABLE_NAME.VENDORS:
              return {
                id: attr.id,
                value:
                  vendorMap[first(vendor?.split('-'))?.trim()]?.id?.toString(),
              };

            default:
              return {
                id: undefined,
                value: undefined,
              };
          }
        })
        .filter((e) => e.value);

      requestCreatePOI.attributes = attributes;

      const msgItemNotFound = await this.i18n.translate('error.ITEM_NOT_FOUND');
      const msgInvalidQuantity = await this.i18n.translate(
        'error.INVALID_QUANTITY',
      );
      const messSucc = await this.i18n.translate('error.SUCCESS');

      const indexChilds = items.map((item) => +item.i);
      if (has(sourceMap, `${sourceCode}_${warehouseMap[warehouse]?.id}`)) {
        requestCreatePOI.items = items
          .map((item) => {
            if (!has(itemMap, item.itemCode)) {
              logMap[+item.i] = {
                id: +item.i,
                row: +item.i,
                log: [msgItemNotFound],
              } as ImportResultDto;

              return null;
            }

            if (!item.quantity) {
              logMap[+item.i] = {
                id: +item.i,
                row: +item.i,
                log: [msgInvalidQuantity],
              } as ImportResultDto;
              return null;
            }

            if (has(flagHeader, rootKey.toString()))
              logMap[+item.i] = {
                id: +item.i,
                row: +item.i,
                log: [flagHeader[rootKey.toString()]],
              } as ImportResultDto;
            else {
              logMap[+item.i] = {
                id: +item.i,
                row: +item.i,
                log: [messSucc],
              } as ImportResultDto;
            }

            return {
              id: itemMap[item.itemCode]?.id,
              lotNumber: '',
              quantity: item.quantity || 0,
              price: divBigNumber(item.totalAmount || 0, item.quantity || 1),
              amount: item.totalAmount || 0,
              warehouseId: warehouseMap[warehouse]?.id,
              creditAccount: sourceMap[sourceCode]?.accountant?.replace(
                /^(\d*?[1-9])0+$/,
                '$1',
              ),
            } as any;
          })
          .filter((item) => item !== null);

        const response = await parentService.createPoImport(requestCreatePOI);

        if (
          !has(flagHeader, rootKey.toString()) &&
          response.statusCode !== ResponseCodeEnum.SUCCESS
        ) {
          logMap[+index] = {
            id: +index,
            row: +index,
            log: [response.message],
          } as ImportResultDto;
          indexChilds.forEach((index) => {
            logMap[+index] = {
              id: +index,
              row: +index,
              log: [response.message],
            } as ImportResultDto;
          });
        }
      } else {
        indexChilds.forEach((i) => {
          logMap[+i] = {
            id: +i,
            row: +i,
            log: logMap[+index]?.log || [''],
          } as ImportResultDto;
        });
      }
    }

    const response = new ImportResponseDto();
    response.result = values(logMap);

    response.totalCount = total;

    return response;
  }

  public async importUtil(
    request: ImportRequestDto,
    parentService: any,
  ): Promise<any> {
    const result = await super.importUtil(
      request,
      this.FIELD_TEMPLATE_ITEM_CONST.REQUIRED_COL_NUM,
      this.SHEET_NAME,
      true,
      parentService,
    );

    const data = result?.data?.result || [];
    if (result.statusCode == ResponseCodeEnum.SUCCESS) {
      const { file, success, fail } = await this.exportResultImport(
        request,
        this.FIELD_TEMPLATE_ITEM_CONST.REQUIRED_COL_NUM,
        this.SHEET_NAME,
        reverse(data),
      );
      return {
        success,
        fail,
        log: file,
      };
    }
    return result;
  }

  protected async exportResultImport(
    request: ImportRequestDto,
    requiredFieldNum: number,
    sheetName: string,
    data: any[],
  ) {
    let success = 0;
    let fail = 0;
    const dataMap = keyBy(data, 'row');
    const { buffer, mimeType } = request;
    let workbook = new Workbook();
    const wsExport = new Workbook();
    workbook = await workbook.xlsx.load(Buffer.from(buffer));
    const ws = workbook.getWorksheet(sheetName);
    const ws1 = wsExport.addWorksheet('sheet2');
    const dataRows: Row[] | string[][] = ws.getRows(1, ws.rowCount - 1);
    const messSucc = await this.i18n.translate('error.SUCCESS');
    const unSucc = await this.i18n.translate('error.UNSUCCESS');
    const resultImport = await this.i18n.translate(
      'export.purchasedOrderImport.result',
    );
    const reasonImport = await this.i18n.translate(
      'export.purchasedOrderImport.reason',
    );
    const headers = HEADER_IN;
    ws1.columns = headers;
    for (let j = 0; j < dataRows.length; j++) {
      const row = dataRows[j];
      const cells = this.getCells(row, mimeType);
      if (!isEmpty(cells)) {
        cells[cells.length - 1] =
          cells[cells.length - 1]['result'] || cells[cells.length - 1];
      }

      if (j == 0) {
        cells.push(resultImport);
        cells.push(reasonImport);
        const row = ws1.getRow(j + 1);
        row.values = cells;
        row.eachCell(function (cell) {
          cell.font = <Font>EXCEL_STYLE.TITLE_FONT_IN;
          cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE;
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          cell.fill = <FillPattern>EXCEL_STYLE.HEADER_FILL_IN;
        });
      } else {
        const mess = dataMap[j - 1]?.log[0];

        if (has(dataMap, j - 1))
          if (mess && mess !== messSucc && cells.length > 0) {
            cells.push(unSucc);
            cells.push(mess);
            fail++;
          } else {
            cells.push(messSucc);
            cells.push('');
            success++;
          }
        const row = ws1.getRow(j + 1);
        row.values = cells;
      }
    }
    const file = await wsExport.xlsx.writeBuffer();
    return {
      file,
      success,
      fail,
    };
  }

  protected async formatCell(cells: any[]) {
    const result = [];
    cells.forEach((item) => {
      if (isEmpty(item)) result.push('');
      else result.push(item.toString());
    });
    return result;
  }
}
