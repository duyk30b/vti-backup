import { WarehouseService } from '../warehouse/warehouse.service';
import { WarehouseModule } from '../warehouse/warehouse.module';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ItemService } from '@components/item/item.service';
import { ItemModule } from '@components/item/item.module';
import { VendorModule } from '@components/vendor/vendor.module';
import { VendorRepository } from '@repositories/vendor/vendor.repository';
import { Vendor } from '@entities/vendor/vendor.entity';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { PurchasedOrderUpdateActualQuantityListener } from './listeners/purchased-order-import-update-actual-quantity.listener';
import { PurchasedOrderUpdateConfirmedQuantityListener } from './listeners/purchased-order-import-update-confimed-quantity.listener';
import { QualityControlService } from '@components/qmx/quality-control.service';
import { QmsxModule } from '@components/qmx/qmx.module';
import { PurchasedOrderImportImport } from './import/purchased-order-import.import.helper';
import { PurchasedOrderImportEntity } from '@entities/purchased-order-import/purchased-order-import.entity';
import { PurchasedOrderImportDetailEntity } from '@entities/purchased-order-import/purchased-order-import-detail.entity';
import { PurchasedOrderImportWarehouseDetailEntity } from '@entities/purchased-order-import/purchased-order-import-warehouse-detail.entity';
import { PurchasedOrderImportWarehouseLotEntity } from '@entities/purchased-order-import/purchased-order-import-warehouse-lot.entity';
import { PurchasedOrderImportService } from './purchased-order-import.service';
import { PurchasedOrderImportController } from './purchased-order-import.controller';
import { PurchasedOrderImportRepository } from '@repositories/purchased-order-import/purchased-order-import.repository';
import { PurchasedOrderImportWarehouseLotRepository } from '@repositories/purchased-order-import/purchased-order-import-warehouse-lot.repository';
import { PurchasedOrderImportDetailRepository } from '@repositories/purchased-order-import/purchased-order-import-detail.repository';
import { PurchasedOrderImportWarehouseDetailRepository } from '@repositories/purchased-order-import/purchased-order-import-warehouse-detail.repository';
import { PurchasedOrderRepository } from '@repositories/purchased-order/purchased-order.repository';
import { PurchasedOrder } from '@entities/purchased-order/purchased-order.entity';
import { PurchasedOrderDetailRepository } from '@repositories/purchased-order/purchased-order-detail.repository';
import { PurchasedOrderDetail } from '@entities/purchased-order/purchased-order-detail.entity';
import { WarehouseCronService } from '@components/warehouse/warehouse.cron.service';
import { PurchasedOrderImportReceiveEntity } from '@entities/purchased-order-import/purchased-order-import-receive.entity';
import { PurchasedOrderImportReceiveRepository } from '@repositories/purchased-order-import/purchased-order-import-receive.repository';
import { PurchasedOrderImportReceiveItemEntity } from '@entities/purchased-order-import/purchased-order-import-receive-item.entity';
import { PurchasedOrderImportReceiveItemRepository } from '@repositories/purchased-order-import/purchased-order-import-receive-item.repository';
import { FileRepository } from '@repositories/file/file.repository';
import { FileEntity } from '@entities/file/file.entity';
import { FileModule } from '@components/file/file.module';
import { FileService } from '@components/file/file.service';
import { ConfigService } from '@config/config.service';
import { PurchasedOrderUpdateStatusListener } from './listeners/purchased-order-import-update-status.listener';
import { AssignOrderEntity } from '@entities/assign-order/assign-order.entity';
import { AssignOrderRepository } from '@repositories/assign-order/assign-order.repository';
import { PurchasedOrderService } from '@components/purchased-order/purchased-order.service';
import { PurchasedOrderModule } from '@components/purchased-order/purchased-order.module';
import { ReceiptModule } from '@components/receipt/receipt.module';
import { ReceiptDetailRepository } from '@repositories/receipt/receipt-detail.repository';
import { ReceiptDetailEntity } from '@entities/receipt/receipt-detail.entity';
import { ReceiptRepository } from '@repositories/receipt/receipt.repository';
import { SaleOrderExportRepository } from '@repositories/sale-order-export/sale-order-export.repository';
import { ValidatePoiDetailWithReceiptDetail } from './validate/validate-poi-detail-with-receipt-detail.helper';
import { ValidatePoiDetailWithSoeDetail } from './validate/validate-poi-detail-with-soe-detail.helper';
import { ReceiptEntity } from '@entities/receipt/receipt.entity';
import { SaleOrderExport } from '@entities/sale-order-export/sale-order-export.entity';
import { ValidatePoiDetailWithWarehouseExportProposalDetail } from './validate/validate-poi-detail-with-warehouse-export-proposal-detail.helper';
import { ValidatePoiDetailWithMasterDataItem } from './validate/validate-poi-detail-with-master-data-item.helper';
import { SaleOrderExportDetailRepository } from '@repositories/sale-order-export/sale-order-export-detail.repository';
import { SaleOrderExportDetail } from '@entities/sale-order-export/sale-order-export-detail.entity';
import { SourceEntity } from '@entities/source/source.entity';
import { ReasonEntity } from '@entities/reason/reason.entity';
import { SourceRepository } from '@repositories/source/source.repository';
import { ReasonRepository } from '@repositories/reason/reason.repository';
import { QUEUES_NAME_ENUM } from '@constant/common';
import { SyncDataModule } from '@components/sync-data/sync-data.module';
import { BullModule } from '@nestjs/bull';
import { SyncPoImportListener } from './listeners/sync-to-hq.listener';
import { ExportModule } from '@components/export/export.module';
import { PurchasedOrderImportSubcriber } from './subcribers/purchased-order-import.entity.subcriber';
import { ReceiptService } from '@components/receipt/receipt.service';
import { ValidatePoiDetailWithSoeDetailAfterConfirm } from './validate/validate-poi-detail-with-so-detail-after-confirm.helper';
import { WarehouseLayoutService } from '@components/warehouse-layout/warehouse-layout.service';
import { WarehouseLayoutModule } from '@components/warehouse-layout/warehouse-layout.module';
import { CategoryContructionEntity } from '@entities/category-contruction/category-contruction.entity';
import { ConstructionEntity } from '@entities/construction/construction.entity';
import { CostTypeEntity } from '@entities/cost-type/cost-type.entity';
import { OrganizationPaymentEntity } from '@entities/organization-payment/organization-payment.entity';
import { CategoryContructionModule } from '@components/category-contruction/category-contruction.module';
import { ConstructionModule } from '@components/construcion/construction.module';
import { CostTypeModule } from '@components/cost-type/cost-type.module';
import { OrganizationPaymentModule } from '@components/organization-payment/organization-payment.module';
import { CategoryContructionRepository } from '@repositories/category-contruction/category-contruction.repository';
import { ConstructionRepository } from '@repositories/construction/construction.repository';
import { CostTypeRepository } from '@repositories/cost-type/cost-type.repository';
import { OrganizationPaymentRepository } from '@repositories/organization-payment/organization-payment.repository';
import { TicketService } from '@components/ticket/ticket.service';
@Module({
  imports: [
    TypeOrmModule.forFeature([
      PurchasedOrder,
      PurchasedOrderDetail,
      PurchasedOrderImportEntity,
      PurchasedOrderImportDetailEntity,
      PurchasedOrderImportWarehouseDetailEntity,
      Vendor,
      PurchasedOrderImportWarehouseLotEntity,
      PurchasedOrderImportReceiveEntity,
      PurchasedOrderImportReceiveItemEntity,
      FileEntity,
      AssignOrderEntity,
      ReceiptDetailEntity,
      ReceiptEntity,
      SaleOrderExport,
      SaleOrderExportDetail,
      SourceEntity,
      ReasonEntity,
      CategoryContructionEntity,
      ConstructionEntity,
      CostTypeEntity,
      OrganizationPaymentEntity,
    ]),
    BullModule.registerQueue({
      name: QUEUES_NAME_ENUM.SYNC_DATA_QUEUE,
    }),
    ItemModule,
    WarehouseModule,
    VendorModule,
    UserModule,
    QmsxModule,
    FileModule,
    PurchasedOrderModule,
    ReceiptModule,
    SyncDataModule,
    ExportModule,
    WarehouseLayoutModule,
    CategoryContructionModule,
    ConstructionModule,
    CostTypeModule,
    OrganizationPaymentModule,
  ],
  providers: [
    {
      provide: 'ReceiptsServiceInterface',
      useClass: ReceiptService,
    },
    {
      provide: 'TicketServiceInterface',
      useClass: TicketService,
    },
    {
      provide: 'PurchasedOrderRepositoryInterface',
      useClass: PurchasedOrderRepository,
    },
    {
      provide: 'PurchasedOrderDetailRepositoryInterface',
      useClass: PurchasedOrderDetailRepository,
    },
    {
      provide: 'PurchasedOrderImportRepositoryInterface',
      useClass: PurchasedOrderImportRepository,
    },
    {
      provide: 'PurchasedOrderImportWarehouseLotRepositoryInterface',
      useClass: PurchasedOrderImportWarehouseLotRepository,
    },
    {
      provide: 'PurchasedOrderImportDetailRepositoryInterface',
      useClass: PurchasedOrderImportDetailRepository,
    },
    {
      provide: 'PurchasedOrderImportWarehouseDetailRepositoryInterface',
      useClass: PurchasedOrderImportWarehouseDetailRepository,
    },
    {
      provide: 'VendorRepositoryInterface',
      useClass: VendorRepository,
    },
    {
      provide: 'PurchasedOrderImportReceiveRepositoryInterface',
      useClass: PurchasedOrderImportReceiveRepository,
    },
    {
      provide: 'PurchasedOrderImportReceiveItemRepositoryInterface',
      useClass: PurchasedOrderImportReceiveItemRepository,
    },
    {
      provide: 'FileRepositoryInterface',
      useClass: FileRepository,
    },
    {
      provide: 'AssignOrderRepositoryInterface',
      useClass: AssignOrderRepository,
    },
    {
      provide: 'PurchasedOrderImportServiceInterface',
      useClass: PurchasedOrderImportService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'WarehouseCronServiceInterface',
      useClass: WarehouseCronService,
    },
    {
      provide: 'WarehouseLayoutServiceInterface',
      useClass: WarehouseLayoutService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'QualityServiceInterface',
      useClass: QualityControlService,
    },
    {
      provide: 'FileServiceInterface',
      useClass: FileService,
    },
    {
      provide: 'PurchasedOrderImportImport',
      useClass: PurchasedOrderImportImport,
    },
    {
      provide: 'qmsxService',
      useClass: QualityControlService,
    },
    {
      provide: 'ConfigServiceInterface',
      useClass: ConfigService,
    },
    PurchasedOrderUpdateActualQuantityListener,
    PurchasedOrderUpdateConfirmedQuantityListener,
    PurchasedOrderUpdateStatusListener,
    {
      provide: 'PurchasedOrderServiceInterface',
      useClass: PurchasedOrderService,
    },
    {
      provide: 'ReceiptDetailRepositoryInterface',
      useClass: ReceiptDetailRepository,
    },
    {
      provide: 'ReceiptRepositoryInterface',
      useClass: ReceiptRepository,
    },
    {
      provide: 'ReceiptsServiceInterface',
      useClass: ReceiptService,
    },
    {
      provide: 'SaleOrderExportRepositoryInterface',
      useClass: SaleOrderExportRepository,
    },
    {
      provide: 'SaleOrderExportDetailRepositoryInterface',
      useClass: SaleOrderExportDetailRepository,
    },
    {
      provide: 'ValidatePoiDetailWithMasterDataItem',
      useClass: ValidatePoiDetailWithMasterDataItem,
    },
    {
      provide: 'ValidatePoiDetailWithReceiptDetail',
      useClass: ValidatePoiDetailWithReceiptDetail,
    },
    {
      provide: 'ValidatePoiDetailWithSoeDetail',
      useClass: ValidatePoiDetailWithSoeDetail,
    },
    {
      provide: 'ValidatePoiDetailWithWarehouseExportProposalDetail',
      useClass: ValidatePoiDetailWithWarehouseExportProposalDetail,
    },

    {
      provide: 'ValidatePoiDetailWithSoeDetailAfterConfirm',
      useClass: ValidatePoiDetailWithSoeDetailAfterConfirm,
    },
    {
      provide: 'SourceRepositoryInterface',
      useClass: SourceRepository,
    },
    {
      provide: 'ReasonRepositoryInterface',
      useClass: ReasonRepository,
    },
    {
      provide: 'CategoryContructionRepositoryInterface',
      useClass: CategoryContructionRepository,
    },
    {
      provide: 'ConstructionRepositoryInterface',
      useClass: ConstructionRepository,
    },
    {
      provide: 'CostTypeRepositoryInterface',
      useClass: CostTypeRepository,
    },
    {
      provide: 'OrganizationPaymentRepositoryInterface',
      useClass: OrganizationPaymentRepository,
    },
    ConfigService,
    SyncPoImportListener,
    PurchasedOrderImportSubcriber,
  ],
  controllers: [PurchasedOrderImportController],
  exports: [
    {
      provide: 'PurchasedOrderImportServiceInterface',
      useClass: PurchasedOrderImportService,
    },
    {
      provide: 'PurchasedOrderImportRepositoryInterface',
      useClass: PurchasedOrderImportRepository,
    },
  ],
})
export class PurchasedOrderImportModule {}
