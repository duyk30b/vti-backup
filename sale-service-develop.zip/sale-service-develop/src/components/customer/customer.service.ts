import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { WarehouseYardServiceInterface } from '@components/warehouse-yard/interface/warehouse-yard.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { Customer } from '@entities/customer/customer.entity';
import { Injectable, Inject } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import { plus } from '@utils/helper';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { flatMap, isEmpty, map, uniq } from 'lodash';
import { DataSource, ILike, In, Not } from 'typeorm';
import { CreateCustomerDto } from './dto/request/create-customer.dto';
import { DeleteCustomerDto } from './dto/request/delete-customer.dto';
import { GetCustomerDetailRequestDto } from './dto/request/get-customer-detail.request.dto';
import { GetListCustomerRequest } from './dto/request/get-customer-list.request.dto';
import { GetCustomerRequestDto } from './dto/request/get-customer.request.dto';
import { UpdateCustomerDto } from './dto/request/update-customer.dto';
import { UpdateTotalPriceCustomerRequestDto } from './dto/request/update-total-price.request.dto';
import { CustomerResponseDto } from './dto/response/customer.response.dto';
import { CustomerImport } from './import/customer.import.helper';
import { CustomerRepositoryInterface } from './interface/customer.repository.interface';
import { CustomerServiceInterface } from './interface/customer.service.interface';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { stringFormat } from '@utils/object.util';

@Injectable()
export class CustomerService implements CustomerServiceInterface {
  constructor(
    @Inject('CustomerRepositoryInterface')
    private readonly customerRepository: CustomerRepositoryInterface,

    @Inject('CustomerImport')
    private readonly customerImport: CustomerImport,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('WarehouseYardServiceInterface')
    private readonly warehouseYardService: WarehouseYardServiceInterface,

    private readonly i18n: I18nRequestScopeService,

    @InjectDataSource()
    private readonly connection: DataSource,
  ) {}

  async createCustomer(
    request: CreateCustomerDto,
  ): Promise<ResponsePayload<any>> {
    const newCustomerEntity = this.customerRepository.createEntity(request);
    const isCustomerExist = await this.customerRepository.findOneByCondition({
      code: ILike(request.code),
    });

    if (isCustomerExist) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_IS_EXIST'),
      ).toResponse();
    }
    return await this.save(newCustomerEntity, 'message.customer.createSuccess');
  }

  async updateCustomer(
    request: UpdateCustomerDto,
  ): Promise<ResponsePayload<any>> {
    const customerFind = await this.customerRepository.findOneById(request.id);
    if (!customerFind) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const isCustomerExist = await this.customerRepository.findOneByCondition({
      code: ILike(request.code),
      id: Not(request.id),
    });

    if (isCustomerExist) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_IS_EXIST'),
      ).toResponse();
    }
    const updateCustomerEntity = this.customerRepository.updateEntity(
      customerFind,
      request,
    );
    return await this.save(
      updateCustomerEntity,
      'message.customer.updateSuccess',
    );
  }

  importCustomer(request: FileUpdloadRequestDto): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
    } as ImportRequestDto;
    return this.customerImport.importUtil(importRequestDto);
  }

  private async save(
    customerEntity: Customer,
    message?: string,
  ): Promise<ResponsePayload<any> | any> {
    try {
      const response = await this.customerRepository.create(customerEntity);
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate(message || 'message.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  async deleteCustomer(
    request: DeleteCustomerDto,
  ): Promise<ResponsePayload<any>> {
    const customerFind = await this.customerRepository.findOneById(request.id);

    if (!customerFind) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    try {
      await this.customerRepository.remove(request.id);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate('message.customer.deleteSuccess'),
        )
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }
  }

  async deleteMultipleCustomer(
    request: DeleteMultipleDto,
  ): Promise<ResponsePayload<any>> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const vendors = await this.customerRepository.findByCondition({
      id: In(ids),
    });
    const vendorIds = vendors.map((vendor) => vendor.id);
    if (vendors.length !== ids.length) {
      ids.forEach((id) => {
        if (!vendorIds.includes(id)) failIdsList.push(id);
      });
    }

    const validIds = vendors
      .filter((vendor) => !failIdsList.includes(vendor.id))
      .map((vendor) => vendor.id);

    try {
      if (!isEmpty(validIds)) {
        await this.customerRepository.multipleRemove(validIds);
      }
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  async getList(
    payload: GetListCustomerRequest,
  ): Promise<ResponsePayload<any>> {
    const { page } = payload;
    const [data, count] = await this.customerRepository.getList(payload);
    const customerLevelIds = uniq(map(flatMap(data, 'customerLevelId')));
    const customerClass = await this.warehouseYardService.getCustomerClassIds(
      customerLevelIds,
      true,
    );
    let result = data;
    result = data.map((i) => ({
      ...i,
      customerLevel: {
        ...customerClass[i.customerLevelId],
        currencyUnitId:
          customerClass[i.customerLevelId]?.currencyUnitId?.id || null,
      },
    }));

    const dataReturn = plainToInstance(CustomerResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getDetail(
    payload: GetCustomerDetailRequestDto,
  ): Promise<ResponsePayload<any>> {
    const customer = await this.customerRepository.getDetail(payload);

    if (!customer)
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    if (customer.createdBy) {
      const createdBy = await this.userService.getUserById(customer.createdBy);
      customer.createdBy = createdBy;
    }
    const dataReturn = plainToInstance(CustomerResponseDto, customer, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getListByIds(
    payload: GetCustomerRequestDto,
  ): Promise<Customer[] | ResponsePayload<any>> {
    const data = await this.customerRepository.findWithRelations({
      where: {
        id: In(payload.customerIds),
      },
    });

    if (!isEmpty(data.length)) {
      return new ResponseBuilder().withCode(ResponseCodeEnum.NOT_FOUND).build();
    }
    return new ResponseBuilder(data).withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async getCustomersByNameKeyword(nameKeyword: any): Promise<any> {
    const customers = await this.customerRepository.findCustomersByNameKeyword(
      nameKeyword,
    );

    const response = plainToInstance(CustomerResponseDto, customers, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  public async updateTotalPriceCustomer(
    request: UpdateTotalPriceCustomerRequestDto,
  ): Promise<any> {
    const customer = await this.customerRepository.findOneById(request.id);
    if (!customer) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    customer.totalPrice = plus(request.totalPrice, customer.totalPrice);
    const customerClass =
      await this.warehouseYardService.getCustomerClassCheckPrice(
        customer.totalPrice,
      );
    const customerEntity = await this.customerRepository.updateCustomer({
      customerLevelId: customerClass.id,
      id: customer.id,
      totalPrice: customer.totalPrice,
    });

    //Transaction
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();

    try {
      const result = await queryRunner.manager.save(customerEntity);
      await queryRunner.commitTransaction();
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder(error)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } finally {
      await queryRunner.release();
    }
  }
}
