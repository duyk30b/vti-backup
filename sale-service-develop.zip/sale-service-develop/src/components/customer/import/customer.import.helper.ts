import { ImportDataAbstract } from '@core/abstracts/import-data.abstract';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectDataSource } from '@nestjs/typeorm';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty, keyBy } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, In } from 'typeorm';
import { CustomerRepositoryInterface } from '../interface/customer.repository.interface';
import { CreateCustomerDto } from '../dto/request/create-customer.dto';
import { REGEX_MAIL, REGEX_PHONE } from '@constant/common';

@Injectable()
export class CustomerImport extends ImportDataAbstract {
  private readonly FIELD_TEMPLATE_CONST = {
    CODE: {
      DB_COL_NAME: 'customerCode',
      COL_NAME: ['Customer code', '顧客コード', 'Mã khách hàng'],
      MAX_LENGTH: 4,
      ALLOW_NULL: false,
      REGEX: /^([a-zA-Z0-9]+)$/,
    },
    NAME: {
      DB_COL_NAME: 'customerName',
      COL_NAME: ['Customer name', '顧客名', 'Tên khách hàng'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    DESCRIPTION: {
      DB_COL_NAME: 'description',
      COL_NAME: ['Description', '説明', 'Mô tả'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    ADDRESS: {
      DB_COL_NAME: 'address',
      COL_NAME: ['Address', '住所', 'Địa chỉ'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    PHONE: {
      DB_COL_NAME: 'phone',
      COL_NAME: ['Phone number', '電話番号', 'Số điện thoại'],
      MAX_LENGTH: 20,
      ALLOW_NULL: true,
      REGEX_PHONE: REGEX_PHONE,
    },
    FAX: {
      DB_COL_NAME: 'fax',
      COL_NAME: ['Fax'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    EMAIL: {
      DB_COL_NAME: 'email',
      COL_NAME: ['Email', 'メールアドレス'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
      REGEX_MAIL: REGEX_MAIL,
    },
    BANK_ACCOUNT: {
      DB_COL_NAME: 'bankAccount',
      COL_NAME: ['Bank account number', '銀行口座', 'STK Ngân Hàng'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    BANK_ACCOUNT_OWNER: {
      DB_COL_NAME: 'bankAccountOwner',
      COL_NAME: ['Bank owner name', '口座名義', 'Chủ tài khoản'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    BANK: {
      DB_COL_NAME: 'bank',
      COL_NAME: ['Bank name', '金融機関名', 'Tên ngân hàng'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    REQUIRED_COL_NUM: 11,
  };

  constructor(
    @Inject('CustomerRepositoryInterface')
    private readonly customerRepository: CustomerRepositoryInterface,
    @InjectDataSource()
    private readonly connection: DataSource,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    this.fieldsMap.set(2, this.FIELD_TEMPLATE_CONST.CODE);
    this.fieldsMap.set(3, this.FIELD_TEMPLATE_CONST.NAME);
    this.fieldsMap.set(4, this.FIELD_TEMPLATE_CONST.DESCRIPTION);
    this.fieldsMap.set(5, this.FIELD_TEMPLATE_CONST.ADDRESS);
    this.fieldsMap.set(6, this.FIELD_TEMPLATE_CONST.PHONE);
    this.fieldsMap.set(7, this.FIELD_TEMPLATE_CONST.FAX);
    this.fieldsMap.set(8, this.FIELD_TEMPLATE_CONST.EMAIL);
    this.fieldsMap.set(9, this.FIELD_TEMPLATE_CONST.BANK_ACCOUNT);
    this.fieldsMap.set(10, this.FIELD_TEMPLATE_CONST.BANK_ACCOUNT_OWNER);
    this.fieldsMap.set(11, this.FIELD_TEMPLATE_CONST.BANK);
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
    error: number,
    total: number,
  ): Promise<ImportResponseDto> {
    const findByCode = await this.customerRepository.findWithRelations({
      where: {
        code: In(dataDto.map((i) => i.customerCode)),
      },
    });

    findByCode.forEach((i) => Object.assign(i, { type: 'old' }));

    const findByCodeMap = keyBy(findByCode, 'code');
    const entities = [];
    const valid = [];
    const {
      duplicateCodeMsg,
      codeNotExistMsg,
      successMsg,
      unsuccessMsg,
      addText,
      updateText,
    } = await this.getMessage();
    dataDto.forEach((data) => {
      const {
        i,
        action,
        customerCode,
        customerName,
        description,
        address,
        phone,
        fax,
        email,
        bank,
        bankAccount,
        bankAccountOwner,
      } = data;
      const logRow = {
        id: i,
        row: i,
        action: action,
      } as ImportResultDto;
      const msgLogs = [];

      const formatedData = new CreateCustomerDto();
      formatedData.code = customerCode?.trim();
      formatedData.name = customerName?.trim();
      formatedData.description = description?.trim() || '';
      formatedData.address = address?.trim();
      formatedData.phone = phone?.trim();
      formatedData.fax = fax?.trim();
      formatedData.email = email?.trim();
      formatedData.bankAccount = bankAccount?.trim();
      formatedData.bank = bank?.trim();
      formatedData.bankAccountOwner = bankAccountOwner?.trim();

      if (action.toLowerCase() === addText) {
        if (findByCodeMap[customerCode]) {
          msgLogs.push(duplicateCodeMsg);
        } else {
          const entity = this.customerRepository.createEntity(formatedData);
          entities.push(entity);
          Object.assign(entity, { type: 'new' });
          findByCodeMap[customerCode] = entity;
        }
      } else if (action.toLowerCase() === updateText) {
        if (
          findByCodeMap[customerCode] &&
          findByCodeMap[customerCode]?.['type'] === 'old'
        ) {
          const entity = this.customerRepository.updateEntity(
            findByCodeMap[customerCode],
            formatedData,
          );
          Object.assign(entity, { type: 'new' });
          entities.push(entity);
          findByCodeMap[customerCode] = entity;
        } else {
          msgLogs.push(codeNotExistMsg);
        }
      }
      if (isEmpty(msgLogs)) {
        logRow.log = [successMsg];
        valid.push(logRow);
      } else {
        logRow.log = msgLogs;
        logs.push(logRow);
      }
    });
    const response = new ImportResponseDto();
    if (!isEmpty(entities)) {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(entities);
        await queryRunner.commitTransaction();
        response.successCount = valid.length;
      } catch (error) {
        await queryRunner.rollbackTransaction();
        response.successCount = 0;
        valid.forEach((l) => (l.log = [unsuccessMsg]));
      } finally {
        await queryRunner.release();
        logs.push(...valid);
      }
    }
    response.result = logs;
    response.totalCount = logs.length;
    response.result;
    return response;
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<ImportResponseDto | any>> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_CONST.REQUIRED_COL_NUM,
    );
  }
}
