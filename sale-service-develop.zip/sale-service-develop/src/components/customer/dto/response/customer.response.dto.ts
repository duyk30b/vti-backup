import { UserResponseDto } from '@components/user/dto/response/user.dto.response';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

export class CustomerLevel {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  discount: number;

  @ApiProperty()
  @Expose()
  currencyUnitId: number;

}

export class CustomerResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  address: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  fax: string;

  @ApiProperty()
  @Expose()
  phone: string;

  @ApiProperty()
  @Expose()
  email: string;

  @ApiProperty()
  @Expose()
  updatedAt: string;

  @ApiProperty()
  @Expose()
  customerLevelId: number;

  @ApiProperty()
  @Expose()
  @Type(() => CustomerLevel)
  customerLevel: CustomerLevel;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  createdBy: UserResponseDto;

  @ApiProperty({ example: '03058444901', description: '' })
  @Expose()
  bankAccount: string;

  @ApiProperty({ example: 'NQT', description: '' })
  @Expose()
  bankAccountOwner: string;

  @ApiProperty({ example: 'TP BANK', description: '' })
  @Expose()
  bank: string;
}
