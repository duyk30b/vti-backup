import { BaseDto } from '@core/dto/base.dto';
import { ArrayNotEmpty } from 'class-validator';

export class GetCustomerRequestDto extends BaseDto {
  @ArrayNotEmpty()
  customerIds: number[];
}
