import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsDecimal, IsInt, IsNotEmpty } from 'class-validator';

export class UpdateTotalPriceCustomerRequestDto extends BaseDto {
  @ApiProperty({example: '1000.00'})
  @IsNotEmpty()
  @IsDecimal()
  totalPrice: number;
  
  @ApiProperty({example: '1000.00'})
  @IsNotEmpty()
  @IsInt()
  id: number
}
