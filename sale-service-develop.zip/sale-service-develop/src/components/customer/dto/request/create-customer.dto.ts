import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsEmail,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';

export class CreateCustomerDto extends BaseDto {
  @ApiProperty({ example: 'Khách hàng A', description: 'Tên khách hàng' })
  @MaxLength(255)
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({ example: '0000', description: 'Mã khách hàng' })
  @MaxLength(20)
  @IsString()
  @IsNotEmpty()
  code: string;

  @ApiProperty({
    example: 'Số 6 ngõ 82 Duy Tân',
    description: 'Địa chỉ khách hàng',
  })
  @MaxLength(255)
  @IsString()
  @IsOptional()
  address: string;

  @ApiProperty({
    example: 'Số 6 ngõ 82 Duy Tân',
    description: 'Mô tả Vendor',
  })
  @MaxLength(255)
  @IsString()
  @IsOptional()
  description: string;

  @ApiProperty({
    example: '5473574375',
    description: 'Số fax của khách hàng',
  })
  @MaxLength(255)
  @IsString()
  @IsOptional()
  fax: string;

  @ApiProperty({
    example: '012345678',
    description: 'Số điện thoại khách hàng',
  })
  @MaxLength(20)
  @IsString()
  @IsOptional()
  phone: string;

  @ApiProperty({
    example: 'hnt@gmail.com',
    description: 'Địa chỉ email của khách hàng',
  })
  @MaxLength(255)
  @IsEmail()
  @IsOptional()
  email: string;

  @ApiPropertyOptional({ example: '03058444901', description: '' })
  @IsString()
  @IsOptional()
  @MaxLength(255)
  bankAccount: string;

  @ApiPropertyOptional({ example: 'NQT', description: '' })
  @IsString()
  @IsOptional()
  @MaxLength(255)
  bankAccountOwner: string;

  @ApiPropertyOptional({ example: 'TP BANK', description: '' })
  @IsString()
  @IsOptional()
  @MaxLength(255)
  bank: string;

  @ApiProperty({ example: 1, description: 'userId' })
  @IsInt()
  @IsNotEmpty()
  userId: number;
}
