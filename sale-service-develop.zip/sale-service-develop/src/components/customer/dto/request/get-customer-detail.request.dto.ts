import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty, IsNumber } from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';

export class GetCustomerDetailRequestDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'Mã id của khách hàng cần tìm' })
  @IsInt()
  @IsNotEmpty()
  @Transform(({ value }) => Number(value))
  id: number;
}
