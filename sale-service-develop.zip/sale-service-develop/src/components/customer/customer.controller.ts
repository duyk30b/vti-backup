import { PermissionCode } from '@core/decorator/get-code.decorator';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { Controller, Inject, Body, Post, Put, Param, ParseIntPipe, Delete, Query, Get } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiConsumes, ApiOperation, ApiResponse } from '@nestjs/swagger';
import {
  CREATE_CUSTOMER_PERMISSION,
  UPDATE_CUSTOMER_PERMISSION,
  DELETE_CUSTOMER_PERMISSION,
  DETAIL_CUSTOMER_PERMISSION,
  LIST_CUSTOMER_PERMISSION,
  IMPORT_CUSTOMER_PERMISSION,
} from '@utils/permissions/customer';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateCustomerDto } from './dto/request/create-customer.dto';
import { DeleteCustomerDto } from './dto/request/delete-customer.dto';
import { GetCustomerDetailRequestDto } from './dto/request/get-customer-detail.request.dto';
import { GetListCustomerRequest } from './dto/request/get-customer-list.request.dto';
import { GetCustomerRequestDto } from './dto/request/get-customer.request.dto';
import { UpdateCustomerBodyDto } from './dto/request/update-customer.dto';
import { UpdateTotalPriceCustomerRequestDto } from './dto/request/update-total-price.request.dto';
import { CustomerResponseDto } from './dto/response/customer.response.dto';
import { CustomerServiceInterface } from './interface/customer.service.interface';

@Controller('customers')
export class CustomerController {
  constructor(
    @Inject('CustomerServiceInterface')
    private readonly customerService: CustomerServiceInterface,
  ) {}

  @PermissionCode(CREATE_CUSTOMER_PERMISSION.code)
  @Post('/create')
  @ApiOperation({
    tags: ['Sales', 'Customer'],
    summary: 'Create new customer',
    description: 'Tạo 1 khách hàng mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: CustomerResponseDto,
  })
  // @MessagePattern('create_customer')
  public async create(@Body() body: CreateCustomerDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.customerService.createCustomer(request);
  }

  @PermissionCode(IMPORT_CUSTOMER_PERMISSION.code)
  @Post('/import')
  @ApiOperation({
    tags: ['Sales', 'Customer'],
    summary: 'Import customer',
    description: 'Nhập một loạt customer mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Import successfully',
    type: ImportResponseDto,
  })
  @ApiConsumes('multipart/form-data')
  // @MessagePattern('import_customer')
  public async importCustomer(
    @Body() body: FileUpdloadRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.customerService.importCustomer(request);
  }

  @PermissionCode(UPDATE_CUSTOMER_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Sales', 'Customer'],
    summary: 'Update customer',
    description: 'Cập nhật thông tin khách hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: CustomerResponseDto,
  })
  // @MessagePattern('update_customer')
  public async update(
    @Param('id', new ParseIntPipe()) id,
    @Body() body: UpdateCustomerBodyDto
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;
    return await this.customerService.updateCustomer(request);
  }

  @PermissionCode(DELETE_CUSTOMER_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Sales', 'Customer'],
    summary: 'Delete customer (soft delete)',
    description: 'Xóa khách hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  // @MessagePattern('delete_customer')
  public async delete(
    @Param() param: DeleteCustomerDto
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.customerService.deleteCustomer(request);
  }

  @PermissionCode(DELETE_CUSTOMER_PERMISSION.code)
  @Delete('/multiple')
  @ApiOperation({
    tags: ['Sales', 'Customer'],
    summary: 'Delete multiple customer (soft delete)',
    description: 'Xóa nhiều khách hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  // @MessagePattern('delete_customer_multiple')
  public async deleteMultiple(
    @Query() query: DeleteMultipleDto
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.customerService.deleteMultipleCustomer(request);
  }

  /**
   * Get customer list
   * @param request GetCustomerListRequest
   * @returns
   */
  @PermissionCode(LIST_CUSTOMER_PERMISSION.code)
  @Get('/list')
  @ApiOperation({
    tags: ['Sales', 'Customer'],
    summary: 'Get list customer',
    description: 'Danh sách khách hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: GetListCustomerRequest,
  })
  // @MessagePattern('get_customers')
  public async getList(
    @Query() query: GetListCustomerRequest
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.customerService.getList(request);
  }

  /**
   * Get customer detail
   * @param request GetCustomerDetailRequestDto
   * @returns
   */
  @PermissionCode(DETAIL_CUSTOMER_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Sales', 'Customer'],
    summary: 'Get customer detail',
    description: 'Lấy thông tin khách hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: GetCustomerDetailRequestDto,
  })
  // @MessagePattern('get_customer')
  public async getCustomerDetail(
    @Param() param: GetCustomerDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.customerService.getDetail(request);
  }

  // @MessagePattern('get_customers_by_ids')
  public async getCustomerByIds(
    @Body() payload: GetCustomerRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.customerService.getListByIds(request);
  }

  // @MessagePattern('get_customer_by_name_keyword')
  public async getItemByConditions(@Body() payload: any): Promise<any> {
    return await this.customerService.getCustomersByNameKeyword(
      payload.nameKeyword,
    );
  }
  
  // @MessagePattern('update_bill_complete')
  public async updateCompleteCustomer(
    @Body() payload: UpdateTotalPriceCustomerRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    

    return await this.customerService.updateTotalPriceCustomer(request);
  }

  // TO DO: remove after refactor done
  @MessagePattern('get_customers_by_ids')
  public async getCustomerByIdsTcp(
    @Body() payload: GetCustomerRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.customerService.getListByIds(request);
  }

  @MessagePattern('get_customer_by_name_keyword')
  public async getItemByConditionsTcp(@Body() payload: any): Promise<any> {
    return await this.customerService.getCustomersByNameKeyword(
      payload.nameKeyword,
    );
  }

  @MessagePattern('update_bill_complete')
  public async updateCompleteCustomerTcp(
    @Body() payload: UpdateTotalPriceCustomerRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    

    return await this.customerService.updateTotalPriceCustomer(request);
  }
}
