import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { Customer } from '@entities/customer/customer.entity';
import { CreateCustomerDto } from '../dto/request/create-customer.dto';
import { GetCustomerDetailRequestDto } from '../dto/request/get-customer-detail.request.dto';
import { GetListCustomerRequest } from '../dto/request/get-customer-list.request.dto';
import { UpdateCustomerDto } from '../dto/request/update-customer.dto';

export interface CustomerRepositoryInterface
  extends BaseInterfaceRepository<Customer> {
  createEntity(request: CreateCustomerDto): Customer;
  updateEntity(
    customerUpdate: Customer,
    request: UpdateCustomerDto | CreateCustomerDto,
  ): Customer;
  getList(
    request: GetListCustomerRequest,
  ): Promise<[data: any[], count: number]>;
  getDetail(request: GetCustomerDetailRequestDto): Promise<any>;
  getCount(): Promise<any>;
  findCustomersByNameKeyword(nameKeyword: any): Promise<any>;
  updateCustomer(data: any): Customer;
}
