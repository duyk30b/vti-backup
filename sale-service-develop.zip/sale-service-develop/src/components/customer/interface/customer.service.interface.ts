import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreateCustomerDto } from '../dto/request/create-customer.dto';
import { DeleteCustomerDto } from '../dto/request/delete-customer.dto';
import { GetCustomerDetailRequestDto } from '../dto/request/get-customer-detail.request.dto';
import { GetListCustomerRequest } from '../dto/request/get-customer-list.request.dto';
import { UpdateCustomerDto } from '../dto/request/update-customer.dto';

export interface CustomerServiceInterface {
  createCustomer(request: CreateCustomerDto): Promise<ResponsePayload<any>>;
  importCustomer(request: FileUpdloadRequestDto): Promise<any>;
  updateCustomer(request: UpdateCustomerDto): Promise<ResponsePayload<any>>;
  deleteCustomer(request: DeleteCustomerDto): Promise<ResponsePayload<any>>;
  deleteMultipleCustomer(request: DeleteMultipleDto): Promise<ResponsePayload<any>>;
  getList(payload: GetListCustomerRequest): Promise<ResponsePayload<any>>;
  getDetail(
    payload: GetCustomerDetailRequestDto,
  ): Promise<ResponsePayload<any>>;
  getListByIds(payload: any): Promise<any>;
  getCustomersByNameKeyword(nameKeyword: any): Promise<any>;
  updateTotalPriceCustomer(request: any): Promise<any>;
}
