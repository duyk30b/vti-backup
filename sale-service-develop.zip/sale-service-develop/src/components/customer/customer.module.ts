import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Customer } from '@entities/customer/customer.entity';
import { CustomerRepository } from '@repositories/customer/customer.repository';
import { CustomerController } from './customer.controller';
import { CustomerService } from './customer.service';
import { CustomerImport } from './import/customer.import.helper';
import { WarehouseYardService } from '@components/warehouse-yard/warehouse-yard.service';
import { WarehouseYardModule } from '@components/warehouse-yard/warehouse-yard.module';

@Module({
  imports: [TypeOrmModule.forFeature([Customer]),
    WarehouseYardModule],
  providers: [
    {
      provide: 'CustomerRepositoryInterface',
      useClass: CustomerRepository,
    },
    {
      provide: 'CustomerServiceInterface',
      useClass: CustomerService,
    },
    {
      provide: 'CustomerImport',
      useClass: CustomerImport,
    },
    {
      provide: 'WarehouseYardServiceInterface',
      useClass: WarehouseYardService,
    },
  ],
  controllers: [CustomerController],
})
export class CustomerModule { }
