import { searchLikeString } from '@utils/helper';
import { PurchasedOrderWarehouseDetailResponseDto } from './dto/response/purchased-order-warehouse-detail-response.dto';
import { OrderUpdateConfirmedQuantityEvent } from './../order/events/order-update-confirmed-quantity.event';
import { SetOrderStatusRequestDto } from './../order/dto/request/set-order-status-request.dto';
import {
  CAN_UPDATE_ORDER_STATUS,
  STATUS_TO_CONFIRM_ORDER_STATUS,
  STATUS_TO_APPROVE_ORDER_STATUS,
  STATUS_TO_DELETE_ORDER_STATUS,
  STATUS_TO_REJECT_ORDER_STATUS,
  STATUS_TO_QC_ORDER,
} from '@constant/order.constant';
import { PurchasedOrderWarehouseDetail } from '@entities/purchased-order/purchased-order-warehouse-detail.entity';
import { PurchasedOrderDetail } from '@entities/purchased-order/purchased-order-detail.entity';
import { PurchasedOrder } from '@entities/purchased-order/purchased-order.entity';
import { UpdatePurchasedOrderDto } from './dto/request/update-purchased-order-request.dto';
import { WarehouseServiceInterface } from './../warehouse/interface/warehouse.service.interface';
import { OrderServiceAbstract } from './../order/interface/order.service.abstract';
import {
  ListMoItemLotsResponse,
  PurchasedOrderResponseDto,
} from './dto/response/purchased-order-response.dto';
import { PurchasedOrderListResponse } from './dto/response/purchased-order-list-response.dto';
import { PagingResponse } from '@utils/paging.response';
import { GetPurchasedOrderListRequest } from './dto/request/get-purchased-order-list-request.dto';
import { plainToInstance } from 'class-transformer';
import { plus } from '@utils/helper';
import { Inject, Injectable } from '@nestjs/common';
import { PurchasedOrderRepositoryInterface } from '@components/purchased-order/interface/purchased-order.repository.interface';
import { PurchasedOrderServiceInterface } from '@components/purchased-order/interface/purchased-order.service.interface';
import { CreatePurchasedOrderDto } from '@components/purchased-order/dto/request/create-purchased-order.dto';
import { UpdateOrderDetailActualQuantityRequestDto } from '@components/order/dto/request/update-actual-quantity-order-detail.request.dto';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, In, Not } from 'typeorm';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ResponseBuilder } from '@utils/response-builder';
import { PurchasedOrderDetailRepositoryInterface } from './interface/purchased-order-detail.repository.interface';
import { PurchasedOrderWarehouseDetailRepositoryInterface } from './interface/purchased-order-warehouse-detail.repository.interface';
import { UpdateOrderDetailConfirmQuantityRequestDto } from '@components/order/dto/request/update-confirm-quantity-order-detail.request.dto';
import {
  compact,
  filter,
  first,
  flatMap,
  isEmpty,
  isNull,
  keyBy,
  map,
  split,
  uniq,
  values,
  isArray,
} from 'lodash';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { VendorRepositoryInterface } from '@components/vendor/interface/vendor.repository.interface';
import {
  CheckStockAvailableDto,
  ItemStockCheck,
} from '@components/item/dto/request/check-stock-available.request.dto';
import { OrderStatusEnum, OrderTypeEnum } from '@constant/common';
import { OrderTypeEnum as SaleOrderTypeEnum } from '@constant/order.constant';
import { GetOrderDetailRequestDto } from '@components/order/dto/request/get-order-detail.request.dto';
import { GetAllPORequest } from './dto/request/get-all-po.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { GetAllPOResponse } from './dto/response/get-all-po.response.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { DeleteOrderRequestDto } from '@components/order/dto/request/delete-order.request.dto';
import { GetListOrderByIdsRequestDto } from '@components/order/dto/request/get-list-order-by-ids.request.dto';
import { GetByItemIdRequestDto } from '@components/purchased-order/dto/request/get-by-item-id.request.dto';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { OrderUpdateActualQuantityEvent } from '@components/order/events/order-update-actual-quantity.event';
import { GetOrderDetailByWarehouseRequestDto } from '@components/order/dto/request/get-order-detail-by-warehouse.request.dto';
import { GetOrderWarehouseRequest } from '@components/order/dto/request/get-order-warehouse.request.dto';
import { OrderWarehouseResponse } from '@components/order/dto/response/order-warehouse-response.dto';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { GetOrderByWarehouseItemRequestDto } from '@components/order/dto/request/get-order-by-warehouse-item.request.dto';
import { UpdatePurchasedOrderWarehouseQcQuantityDto } from './dto/request/update-purchased-order-warehouse-qc-quantity-request.dto';
import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { QualityControlServiceInterface } from '@components/qmx/interface/quality-control.service.interface';
import { TotalQuantityItemPurchaseOrderResponseDto } from './dto/response/total-quantity-item-purchased-order.response.dto';
import { PurchasedOrderWarehouseLotRepositoryInterface } from './interface/purchased-order-warehouse-lot.repository.interface';
import { PurchasedOrderWarehouseLotEntity } from '@entities/purchased-order/purchased-order-warehouse-lot.entity';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { PurchasedOrdersImport } from './import/purchased-order.import.helper';
import { PurchasedOrderItemDetailsImport } from './import/purchased-order-item-detail.import.helper';
import { ImportPurchasedOrderResponseDto } from './dto/response/import-purchased-order.response.dto';
import { PurchasedOrderImportRepositoryInterface } from '@components/purchased-order-import/interface/purchased-order-import.repository.interface';
import { stringFormat } from '@utils/object.util';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { UpdateMoneyForVendorEvent } from './events/update-money-for-vendor.event';

@Injectable()
export class PurchasedOrderService
  extends OrderServiceAbstract
  implements PurchasedOrderServiceInterface
{
  constructor(
    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('ProduceServiceInterface')
    protected readonly produceService: ProduceServiceInterface,

    @Inject('PurchasedOrderRepositoryInterface')
    private readonly purchasedOrderRepository: PurchasedOrderRepositoryInterface,

    @Inject('PurchasedOrderDetailRepositoryInterface')
    private readonly purchasedOrderDetailRepository: PurchasedOrderDetailRepositoryInterface,

    @Inject('PurchasedOrderWarehouseDetailRepositoryInterface')
    private readonly purchasedOrderWarehouseDetailRepository: PurchasedOrderWarehouseDetailRepositoryInterface,

    @Inject('PurchasedOrderWarehouseLotRepositoryInterface')
    private readonly purchasedOrderWarehouseLotRepository: PurchasedOrderWarehouseLotRepositoryInterface,

    @Inject('VendorRepositoryInterface')
    private readonly vendorRepository: VendorRepositoryInterface,

    @Inject('QualityServiceInterface')
    private readonly qualityControlService: QualityControlServiceInterface,

    @Inject('PurchasedOrdersImport')
    private readonly purchasedOrdersImport: PurchasedOrdersImport,

    @Inject('PurchasedOrderItemDetailsImport')
    private readonly purchasedOrderItemDetailsImport: PurchasedOrderItemDetailsImport,

    @Inject('PurchasedOrderImportRepositoryInterface')
    private readonly purchasedOrderImportRepository: PurchasedOrderImportRepositoryInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private eventEmitter: EventEmitter2,

    private readonly i18n: I18nRequestScopeService,
  ) {
    super(itemService, warehouseService, userService);
  }

  async getPoByWarehouse(
    request: GetOrderByWarehouseItemRequestDto,
  ): Promise<any> {
    const { id, warehouseId } = request;
    const data = await this.purchasedOrderRepository.getDetailByWarehouseId(
      id,
      [warehouseId],
    );
    if (!isEmpty(data)) {
      data.warehouse = await this.warehouseService.getWarehouses([warehouseId]);
    }

    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getListByIds(
    payload: GetListOrderByIdsRequestDto,
  ): Promise<ResponsePayload<PurchasedOrderResponseDto | any>> {
    const { ids } = payload;
    const data = await this.purchasedOrderRepository.getListByIds(ids);

    const dataReturn = plainToInstance(PurchasedOrderResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Delete
   */
  public async delete(payload: DeleteOrderRequestDto): Promise<any> {
    const { id } = payload;

    const purchasedOrder = await this.purchasedOrderRepository.findOneById(id);
    if (!purchasedOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_DELETE_ORDER_STATUS.includes(purchasedOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    const result = await this.purchasedOrderRepository.delete(id);
    if (result.affected === 1) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } else {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  /**
   * Delete
   */
  public async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const purchasedOrders = await this.purchasedOrderRepository.findByCondition(
      {
        id: In(ids),
      },
    );

    const purchasedOrderIds = purchasedOrders.map(
      (purchasedOrder) => purchasedOrder.id,
    );
    if (purchasedOrders.length !== ids.length) {
      ids.forEach((id) => {
        if (!purchasedOrderIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < purchasedOrders.length; i++) {
      const purchasedOrder = purchasedOrders[i];
      if (!STATUS_TO_DELETE_ORDER_STATUS.includes(purchasedOrder.status))
        failIdsList.push(purchasedOrder.id);
    }

    const validIds = purchasedOrders
      .filter((purchasedOrder) => !failIdsList.includes(purchasedOrder.id))
      .map((purchasedOrder) => purchasedOrder.id);

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (!isEmpty(validIds)) {
        await queryRunner.manager.delete(PurchasedOrder, {
          id: In(validIds),
        });
        await queryRunner.commitTransaction();
      }
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    await queryRunner.release();
    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  /**
   * Get genetal purchased order detail
   * @param payload
   * @returns
   */
  async getDetail(payload: GetOrderDetailRequestDto): Promise<any> {
    const { id } = payload;
    const purchasedOrder = await this.purchasedOrderRepository.getDetail(id);
    if (!purchasedOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (purchasedOrder.companyId) {
      const company = await this.userService.getCompanyById(
        purchasedOrder.companyId,
      );

      purchasedOrder['company'] = company ?? {};
    }

    if (purchasedOrder.manufacturingOrderId) {
      const manufacturingOrderIds = [purchasedOrder.manufacturingOrderId];
      const manufacturingOrder = await this.produceService.getMoByIds(
        manufacturingOrderIds,
      );

      purchasedOrder.manufacturingOrder = manufacturingOrder[0];
    }

    const itemIds = map(purchasedOrder.purchasedOrderDetails, 'itemId');
    const userIds = uniq([
      purchasedOrder.createdByUserId,
      purchasedOrder.confirmerId,
      purchasedOrder.approverId,
    ]).filter((id) => !isNull(id));
    const warehouseIds = uniq(
      map(purchasedOrder.purchasedOrderWarehouseDetails, 'warehouseId'),
    );
    const { items, warehouses, users } = await super.getOrderExtraInfo(
      itemIds,
      warehouseIds,
      userIds,
    );
    const normalizeItems = {};
    const normalizeWarehouses = {};
    const normalizeUsers = {};

    items.forEach((item) => {
      normalizeItems[item.itemId] = item;
    });

    warehouses.forEach((warehouse) => {
      normalizeWarehouses[warehouse.id] = warehouse;
    });
    users.forEach((user) => {
      normalizeUsers[user.id] = user;
    });
    purchasedOrder.createdByUser =
      normalizeUsers[purchasedOrder.createdByUserId];
    purchasedOrder.approver = normalizeUsers[purchasedOrder.approverId];
    purchasedOrder.confirmer = normalizeUsers[purchasedOrder.confirmerId];

    purchasedOrder.purchasedOrderDetails =
      purchasedOrder.purchasedOrderDetails.map((purchasedOrderDetail) => ({
        ...purchasedOrderDetail,
        item: normalizeItems[purchasedOrderDetail.itemId],
      }));

    purchasedOrder.purchasedOrderWarehouseDetails =
      purchasedOrder.purchasedOrderWarehouseDetails.map(
        (purchasedOrderWarehouseDetail) => ({
          ...purchasedOrderWarehouseDetail,
          item: normalizeItems[purchasedOrderWarehouseDetail.itemId],
          warehouse:
            normalizeWarehouses[purchasedOrderWarehouseDetail.warehouseId],
        }),
      );
    const dataReturn = plainToInstance(
      PurchasedOrderResponseDto,
      purchasedOrder,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getDetailByWarehouseId(
    payload: GetOrderDetailByWarehouseRequestDto,
  ): Promise<any> {
    const { id, warehouseId, user } = payload;
    const userWarehouseIds = !isEmpty(user.userWarehouses)
      ? map(user.userWarehouses, 'id')
      : [];
    if (!userWarehouseIds.includes(warehouseId)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const purchasedOrder =
      await this.purchasedOrderRepository.getDetailByWarehouseId(id, [
        warehouseId,
      ]);

    if (!purchasedOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const itemIds = map(purchasedOrder.items, 'id');
    const userIds = uniq([
      purchasedOrder.createdByUserId,
      purchasedOrder.confirmerId,
      purchasedOrder.approverId,
    ]).filter((id) => !isNull(id));

    const { items, warehouses, users } = await super.getOrderExtraInfo(
      itemIds,
      [warehouseId],
      userIds,
    );
    const normalizeItems = {};
    const normalizeUsers = {};
    const normalizeWarehouses = {};

    items.forEach((item) => {
      normalizeItems[item.itemId] = item;
    });
    warehouses.forEach((warehouse) => {
      normalizeWarehouses[warehouse.id] = warehouse;
    });
    users.forEach((user) => {
      normalizeUsers[user.id] = user;
    });
    purchasedOrder.createdByUser =
      normalizeUsers[purchasedOrder.createdByUserId];
    purchasedOrder.approver = normalizeUsers[purchasedOrder.approverId];
    purchasedOrder.confirmer = normalizeUsers[purchasedOrder.confirmerId];
    purchasedOrder.warehouse = normalizeWarehouses[warehouseId];

    purchasedOrder.items = purchasedOrder.items.map((item) => ({
      ...normalizeItems[item.id],
      ...item,
      lots: item.qcCheck
        ? item.lots
        : [
            {
              id: 0,
              lotNumber: purchasedOrder.code,
              lotDate: purchasedOrder.purchasedAt,
              qcPassQuantity: item.qcPassQuantity,
              qcRejectQuantity: item.qcRejectQuantity,
              quantity: item.quantity,
              isExpired: false,
            },
          ],
    }));

    const dataReturn = plainToInstance(
      PurchasedOrderWarehouseDetailResponseDto,
      purchasedOrder,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Get List
   * @param payload
   * @returns
   */
  async getList(payload: GetPurchasedOrderListRequest): Promise<any> {
    const { page, user, onlyCreatedFromMo } = payload;
    const filterPoHaveNotPoimp = payload.filter?.filter(
      (record) => record.column === 'poHaveNotPoimp',
    );
    if (!isEmpty(filterPoHaveNotPoimp)) {
      const purchasedOrderImportIds = compact(
        split(first(filterPoHaveNotPoimp)['text']),
      );

      return await this.getPurchasedOrderListHaveNotPoimp(
        purchasedOrderImportIds,
      );
    }
    if (!payload.filter) payload.filter = [];

    const userWarehouses = await this.userService.getUserWarehousesById(
      user.id,
    );

    if (isEmpty(userWarehouses)) {
      return new ResponseBuilder<PagingResponse>({
        items: [],
        meta: { total: 0, page: 1 },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    payload.filter.push({
      column: 'warehouseId',
      text: map(userWarehouses, 'id').join(','),
    });

    let manufacturingOrders = [];
    let saleOrders = [];
    if (onlyCreatedFromMo) {
      const purchasedOrders = await this.purchasedOrderRepository.findAll();
      const manufacturingOrderIds = uniq(
        map(flatMap(purchasedOrders), 'manufacturingOrderId'),
      );
      if (manufacturingOrderIds.length) {
        manufacturingOrders = await this.produceService.getMoByIds(
          manufacturingOrderIds,
        );
        saleOrders = uniq(map(flatMap(manufacturingOrders), 'saleOrder'));
        saleOrders = [
          ...new Map(
            saleOrders.map((record) => [record['id'], record]),
          ).values(),
        ];
      }
    }

    const [data, count] = await this.purchasedOrderRepository.getList(
      payload,
      manufacturingOrders,
      saleOrders,
    );

    const companydIds = uniq(map(flatMap(data), 'companyId'));

    const companies = await this.userService.getCompanies(companydIds, true);

    const result = data.map((item) => {
      return {
        ...item,
        company: companies[item.companyId],
      };
    });

    const dataReturn = plainToInstance(PurchasedOrderListResponse, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getListOrderWarehouse(request: GetOrderWarehouseRequest): Promise<any> {
    const { page, user, keyword } = request;
    const userWarehouses = user.userWarehouses;
    let warehouseIds = [];
    if (!isEmpty(keyword)) {
      warehouseIds = filter(
        userWarehouses,
        (warehouse) =>
          searchLikeString(warehouse.name, keyword) ||
          searchLikeString(warehouse.code, keyword),
      ).map((w) => w.id);
    } else {
      warehouseIds = userWarehouses.map((e) => e.id);
    }

    const [data, count] =
      await this.purchasedOrderWarehouseDetailRepository.getListOrderWarehouse(
        request,
        warehouseIds,
      );
    const normalizeWarehouses = {};
    userWarehouses.forEach((warehouse) => {
      normalizeWarehouses[warehouse.id] = warehouse;
    });

    //get_factory_by_ids
    let dataMaping = data.map((e) => ({
      warehouseId: e.warehouseId,
      warehouseName: normalizeWarehouses[e.warehouseId].name,
      warehouseCode: normalizeWarehouses[e.warehouseId].code,
      items: e.items,
      factoryId: normalizeWarehouses[e.warehouseId].factoryId,
    }));
    const factoriesNameData = await this.userService.getFactories(
      dataMaping.map((e) => e.factoryId),
    );

    dataMaping = dataMaping.map((e) => {
      const factory = factoriesNameData.find(
        (e2) => e2.factoryId === e.factoryId,
      );
      return {
        ...e,
        factoryName: factory?.factoryName,
      };
    });

    const dataReturn = plainToInstance(OrderWarehouseResponse, dataMaping, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  /**
   * Update Confirmed Quantity
   */
  async updateOrderDetailConfirmQuantity(
    data: UpdateOrderDetailConfirmQuantityRequestDto,
  ): Promise<any> {
    const { orderId, orderDetails, warehouseOrderDetails } = data;
    let message;
    let code = ResponseCodeEnum.SUCCESS;
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const updatePurchasedOrderDetailEntities =
        await this.purchasedOrderDetailRepository.getUpdateOrderDetailConfirmQuantityByIds(
          orderId,
          orderDetails,
        );

      const updatePurchasedOrderWarehouseDetailEntities =
        await this.purchasedOrderWarehouseDetailRepository.getUpdateOrderWarehouseDetailConfirmQuantityByIds(
          orderId,
          warehouseOrderDetails,
        );

      await queryRunner.manager.save(updatePurchasedOrderDetailEntities);
      await queryRunner.manager.save(
        updatePurchasedOrderWarehouseDetailEntities,
      );
      await queryRunner.commitTransaction();
    } catch (error) {
      message = error;
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      await queryRunner.rollbackTransaction();
    } finally {
      await queryRunner.release();
      this.eventEmitter.emit(
        'order.updateConfirmedQuantity',
        new OrderUpdateConfirmedQuantityEvent({
          id: orderId,
          orderType: SaleOrderTypeEnum.PO,
        }),
      );
    }
    return new ResponseBuilder()
      .withCode(code)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  /**
   *
   * @param data
   * @returns
   */
  async updateOrderDetailActualQuantity(
    data: UpdateOrderDetailActualQuantityRequestDto,
  ): Promise<any> {
    const { orderId, orderDetails, warehouseOrderDetails } = data;
    let message;
    let code = ResponseCodeEnum.SUCCESS;

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const updatePurchasedOrderDetailEntities =
        await this.purchasedOrderDetailRepository.getUpdateOrderDetailActualQuantityByIds(
          orderId,
          orderDetails,
        );

      const updatePurchasedOrderWarehouseDetailEntities =
        await this.purchasedOrderWarehouseDetailRepository.getUpdateOrderWarehouseDetailActualQuantityByIds(
          orderId,
          warehouseOrderDetails,
        );

      await queryRunner.manager.save(updatePurchasedOrderDetailEntities);
      await queryRunner.manager.save(
        updatePurchasedOrderWarehouseDetailEntities,
      );
      await queryRunner.commitTransaction();
    } catch (error) {
      message = error;
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      await queryRunner.rollbackTransaction();
    }
    await queryRunner.release();
    this.eventEmitter.emit(
      'order.updateActualQuantity',
      new OrderUpdateActualQuantityEvent({
        id: orderId,
        orderType: SaleOrderTypeEnum.PO,
      }),
    );
    return new ResponseBuilder()
      .withCode(code)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async update(payload: UpdatePurchasedOrderDto): Promise<any> {
    const { code, id } = payload;
    const purchasedOrder = await this.purchasedOrderRepository.findOneById(id);
    if (!purchasedOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CAN_UPDATE_ORDER_STATUS.includes(purchasedOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }
    const isExistPurchasedOrder =
      await this.purchasedOrderRepository.findByCondition({
        code: code,
        id: Not(id),
      });
    if (isExistPurchasedOrder.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ORDER_IS_EXIST'))
        .build();
    }

    if (purchasedOrder.status === OrderStatusEnum.Reject) {
      purchasedOrder.status = OrderStatusEnum.Pending;
    }

    return await this.save(purchasedOrder, payload);
  }

  private async save(
    purchasedOrderEntity: PurchasedOrder,
    payload: CreatePurchasedOrderDto,
  ): Promise<any> {
    const {
      items,
      code,
      vendorId,
      type,
      purchasedAt,
      deadline,
      name,
      companyId,
      description,
      createdByUserId,
      manufacturingOrderId,
    } = payload;
    const isUpdate = purchasedOrderEntity.id !== null;
    let response, message;
    let responeCode = ResponseCodeEnum.SUCCESS;

    // Validate vendor
    if (vendorId) {
      const vendor = await this.vendorRepository.findOneById(vendorId);
      if (!vendor)
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.VENDOR_NOT_FOUND'))
          .build();
    }

    const itemIds = uniq(items.map((e) => e.id));

    if (manufacturingOrderId) {
      const manufacturingOrderIds = [manufacturingOrderId];
      const manufacturingOrder = await this.produceService.getMoByIds(
        manufacturingOrderIds,
      );
      if (manufacturingOrder.length === 0) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.MANUFACTURING_ORDER_NOT_FOUND'),
          )
          .build();
      }
    }

    // Validate items
    const itemsExist = await this.itemService.getItems(itemIds);
    if (!itemsExist || itemIds.length !== itemsExist.length) {
      const itemIdsExist = itemsExist ? itemsExist.map((e) => e.itemId) : [];
      return new ResponseBuilder({
        invalidItems: items.filter((e) => !itemIdsExist.includes(e.id)),
      })
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }

    //Validate stock if action export
    if (type === OrderTypeEnum.Export) {
      const isStockAvaiable = await this.itemService.checkStockAvailable(
        new CheckStockAvailableDto(
          items.map((e) => {
            return new ItemStockCheck(e.id, e.quantity, e.warehouseId);
          }),
        ),
      );

      if (
        isStockAvaiable.statusCode != ResponseCodeEnum.SUCCESS ||
        isStockAvaiable.data?.invalidItems?.length > 0
      )
        return new ResponseBuilder(isStockAvaiable?.data)
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.ORDER_NOT_ENOUGH_ITEM_IN_STOCK'),
          )
          .build();
    }

    // const itemS
    const purchasedOrderDetailRaws = {};
    items.forEach((item) => {
      if (purchasedOrderDetailRaws[item.id]) {
        purchasedOrderDetailRaws[item.id].quantity = plus(
          purchasedOrderDetailRaws[item.id].quantity,
          item.quantity,
        );
      } else {
        purchasedOrderDetailRaws[item.id] = {
          id: item.id,
          quantity: item.quantity,
          price: item.price ? item.price : 0,
        };
      }
    });
    const itemsMap = keyBy(itemsExist, 'itemId');
    // create purchased order
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      purchasedOrderEntity.vendorId = vendorId;
      purchasedOrderEntity.code = code;
      purchasedOrderEntity.companyId = companyId;
      purchasedOrderEntity.deadline = deadline;
      purchasedOrderEntity.description = description;
      purchasedOrderEntity.name = name;
      purchasedOrderEntity.purchasedAt = purchasedAt;
      purchasedOrderEntity.type = type;
      purchasedOrderEntity.createdByUserId = createdByUserId;
      purchasedOrderEntity.manufacturingOrderId = manufacturingOrderId
        ? manufacturingOrderId
        : purchasedOrderEntity.manufacturingOrderId;

      const purchasedOrder = await queryRunner.manager.save(
        purchasedOrderEntity,
      );
      const purchasedOrderDetailEntities = values(purchasedOrderDetailRaws).map(
        (purchasedOrderDetail: any) =>
          this.purchasedOrderDetailRepository.createEntity({
            purchasedOrderId: purchasedOrder.id,
            itemId: purchasedOrderDetail.id,
            quantity: purchasedOrderDetail.quantity,
            price: purchasedOrderDetail.price
              ? purchasedOrderDetail.price
              : itemsMap[purchasedOrderDetail.id].price,
          }),
      );
      if (isUpdate) {
        await queryRunner.manager.delete(PurchasedOrderDetail, {
          purchasedOrderId: purchasedOrder.id,
        });
      }
      purchasedOrder.purchasedOrderDetails = await queryRunner.manager.save(
        purchasedOrderDetailEntities,
      );
      const purchasedOrderWarehouseDetailEntities = items.map((item) => {
        const purchasedOrderDetail = purchasedOrder.purchasedOrderDetails.find(
          (pod) => pod.itemId === item.id,
        );
        return this.purchasedOrderWarehouseDetailRepository.createEntity({
          itemId: item.id,
          warehouseId: item.warehouseId,
          purchasedOrderDetailId: purchasedOrderDetail.id,
          purchasedOrderId: purchasedOrderDetail.purchasedOrderId,
          quantity: item.quantity,
          qcCheck: +item.qcCheck || 0,
          qcCriteriaId: item.qcCriteriaId,
        });
      });
      if (isUpdate) {
        await queryRunner.manager.delete(PurchasedOrderWarehouseDetail, {
          purchasedOrderId: purchasedOrder.id,
        });
      }
      purchasedOrder.purchasedOrderWarehouseDetails =
        await queryRunner.manager.save(purchasedOrderWarehouseDetailEntities);
      await queryRunner.commitTransaction();
      response = plainToInstance(PurchasedOrderResponseDto, purchasedOrder, {
        excludeExtraneousValues: true,
      });
    } catch (error) {
      await queryRunner.rollbackTransaction();
      responeCode = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      message = error;
    }
    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(responeCode)
      .withData(response)
      .withMessage(
        responeCode === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  public async create(payload: CreatePurchasedOrderDto): Promise<any> {
    const { code } = payload;

    const isExist = await this.purchasedOrderRepository.findByCondition({
      code: code,
    });

    if (isExist.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ORDER_IS_EXIST'))
        .build();
    }

    const purchasedOrderEntity =
      this.purchasedOrderRepository.createEntity(payload);
    return await this.save(purchasedOrderEntity, payload);
  }

  /**
   * Get data purchased order by id and warehouseId
   * @param id
   * @param warehouseId
   * @returns
   */
  public async getWarehouseDetails(
    id: number,
    warehouseId: number,
    type: number,
  ): Promise<any> {
    try {
      const data = await this.purchasedOrderRepository.getWarehouseDetails(
        id,
        warehouseId,
        type,
      );
      return new ResponseBuilder(data)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async confirm(payload: SetOrderStatusRequestDto): Promise<any> {
    const { id } = payload;

    const purchasedOrder = await this.purchasedOrderRepository.findOneById(id);
    if (!purchasedOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_CONFIRM_ORDER_STATUS.includes(purchasedOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.PURCHASE_ORDER_WAS_CONFIRMED'),
        )
        .build();
    }
    if (!purchasedOrder.companyId) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.COMPANY_NOT_FOUND'))
        .build();
    }
    if (!purchasedOrder.vendorId) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.VENDOR_NOT_FOUND'))
        .build();
    }

    const vendor = await this.vendorRepository.findOneById(
      purchasedOrder.vendorId,
    );

    if (!vendor) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.VENDOR_NOT_FOUND'))
        .build();
    }

    const company = await this.userService.getCompanies([
      purchasedOrder.companyId,
    ]);

    if (company.length === 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.COMPANY_NOT_FOUND'))
        .build();
    }

    if (purchasedOrder.manufacturingOrderId) {
      const manufacturingOrder = await this.produceService.getMoByIds([
        purchasedOrder.manufacturingOrderId,
      ]);

      if (manufacturingOrder.length === 0) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.MANUFACTURING_ORDER_NOT_FOUND'),
          )
          .build();
      }
    }

    this.eventEmitter.emit(
      'order.updateMoneyVendor',
      new UpdateMoneyForVendorEvent({
        vendorId: purchasedOrder.vendorId,
        id: id,
      }),
    );

    return await this.setPurchasedOrderStatus(
      purchasedOrder,
      OrderStatusEnum.Confirmed,
    );
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async confirmMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const purchasedOrders = await this.purchasedOrderRepository.findByCondition(
      {
        id: In(ids),
      },
    );

    const purchasedOrderIds = purchasedOrders.map(
      (purchasedOrder) => purchasedOrder.id,
    );
    if (purchasedOrders.length !== ids.length) {
      ids.forEach((id) => {
        if (!purchasedOrderIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < purchasedOrders.length; i++) {
      const purchasedOrder = purchasedOrders[i];
      if (
        !STATUS_TO_CONFIRM_ORDER_STATUS.includes(purchasedOrder.status) ||
        !purchasedOrder.companyId ||
        !purchasedOrder.vendorId
      )
        failIdsList.push(purchasedOrder.id);
    }

    const validIdsHere = ids.filter((id) => !failIdsList.includes(id));
    const vendors = await this.vendorRepository.findByCondition({
      id: In(
        purchasedOrders
          .filter((purchasedOrder) => validIdsHere.includes(purchasedOrder.id))
          .map((purchasedOrder) => purchasedOrder.vendorId),
      ),
    });

    const companies = await this.userService.getCompanies(
      purchasedOrders
        .filter((purchasedOrder) => validIdsHere.includes(purchasedOrder.id))
        .map((purchasedOrder) => purchasedOrder.companyId),
    );

    if (vendors.length !== validIdsHere.length) {
      purchasedOrders.forEach((purchasedOrder) => {
        if (!vendors.find((vendor) => vendor.id === purchasedOrder.vendorId))
          failIdsList.push(purchasedOrder.id);
      });
    }

    if (companies.length !== validIdsHere.length) {
      purchasedOrders.forEach((purchasedOrder) => {
        if (
          !companies.find((company) => company.id === purchasedOrder.companyId)
        )
          failIdsList.push(purchasedOrder.id);
      });
    }

    const hasMOPurchasedOrders = purchasedOrders.filter(
      (purchasedOrder) => purchasedOrder.manufacturingOrderId,
    );
    const manufacturingOrders = await this.produceService.getMoByIds(
      hasMOPurchasedOrders.map(
        (purchasedOrder) => purchasedOrder.manufacturingOrderId,
      ),
    );

    if (manufacturingOrders.length !== hasMOPurchasedOrders.length) {
      hasMOPurchasedOrders.forEach((purchasedOrder) => {
        if (
          !manufacturingOrders.find(
            (mo) => mo.id === purchasedOrder.manufacturingOrderId,
          )
        )
          failIdsList.push(purchasedOrder.id);
      });
    }

    const validIds = purchasedOrders
      .filter((purchasedOrder) => !failIdsList.includes(purchasedOrder.id))
      .map((purchasedOrder) => purchasedOrder.id);

    const validPurchasedOrders = purchasedOrders.filter((purchasedOrder) =>
      validIds.includes(purchasedOrder.id),
    );

    if (!isEmpty(validPurchasedOrders)) {
      validPurchasedOrders.forEach((purchasedOrder) => {
        purchasedOrder.status = OrderStatusEnum.Confirmed;
        purchasedOrder.approvedAt = new Date(Date.now());
      });
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(PurchasedOrder, validPurchasedOrders);
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.CONFIRM_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async rejectMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const purchasedOrders = await this.purchasedOrderRepository.findByCondition(
      {
        id: In(ids),
      },
    );

    const purchasedOrderIds = purchasedOrders.map(
      (purchasedOrder) => purchasedOrder.id,
    );
    if (purchasedOrders.length !== ids.length) {
      ids.forEach((id) => {
        if (!purchasedOrderIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < purchasedOrders.length; i++) {
      const purchasedOrder = purchasedOrders[i];
      if (!STATUS_TO_REJECT_ORDER_STATUS.includes(purchasedOrder.status))
        failIdsList.push(purchasedOrder.id);
    }

    const validIds = purchasedOrders
      .filter((purchasedOrder) => !failIdsList.includes(purchasedOrder.id))
      .map((purchasedOrder) => purchasedOrder.id);

    const validPurchasedOrders = purchasedOrders.filter((purchasedOrder) =>
      validIds.includes(purchasedOrder.id),
    );

    if (!isEmpty(validPurchasedOrders)) {
      validPurchasedOrders.forEach((purchasedOrder) => {
        purchasedOrder.status = OrderStatusEnum.Reject;
        purchasedOrder.approvedAt = new Date(Date.now());
      });
      const queryRunner = this.connection.createQueryRunner();
      try {
        await queryRunner.startTransaction();
        await queryRunner.manager.save(PurchasedOrder, validPurchasedOrders);
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.REJECT_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async reject(payload: SetOrderStatusRequestDto): Promise<any> {
    const { id } = payload;

    const purchasedOrder = await this.purchasedOrderRepository.findOneById(id);
    if (!purchasedOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_REJECT_ORDER_STATUS.includes(purchasedOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    return await this.setPurchasedOrderStatus(
      purchasedOrder,
      OrderStatusEnum.Reject,
    );
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async approve(payload: SetOrderStatusRequestDto): Promise<any> {
    const { id } = payload;

    const purchasedOrder = await this.purchasedOrderRepository.findOneById(id);
    if (!purchasedOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_APPROVE_ORDER_STATUS.includes(purchasedOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    return await this.setPurchasedOrderStatus(
      purchasedOrder,
      OrderStatusEnum.Completed,
    );
  }

  /**
   *
   * @param purchasedOrderEntity
   * @param status
   * @returns
   */
  private async setPurchasedOrderStatus(
    purchasedOrderEntity: PurchasedOrder,
    status: number,
  ): Promise<any> {
    purchasedOrderEntity.status = status;
    await this.purchasedOrderRepository.create(purchasedOrderEntity);

    const response = plainToInstance(
      PurchasedOrderResponseDto,
      purchasedOrderEntity,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  /**
   * Get List Purchased Order
   * @param request
   * @returns
   */
  public async getPurchasedOrders(
    request: GetAllPORequest,
  ): Promise<ResponsePayload<any>> {
    try {
      const data = await this.purchasedOrderRepository.findWithRelations({
        relations: ['vendor', 'purchasedOrderWarehouseDetails'],
        where: {
          status: In(request.status),
        },
      });

      const dataReturn = plainToInstance(GetAllPOResponse, data, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error)
        .build();
    }
  }

  async checkItemHasExistOnPurchaseOrder(
    request: GetByItemIdRequestDto,
  ): Promise<any> {
    if (isArray(request.itemId))
      return await this.purchasedOrderDetailRepository.findByCondition({
        itemId: In(request.itemId),
      });

    return await this.purchasedOrderDetailRepository.findOneByCondition({
      itemId: request.itemId,
    });
  }

  public async updatePOQcQuantityPurchasedOrderWarehouse(
    request: UpdatePurchasedOrderWarehouseQcQuantityDto,
  ): Promise<any> {
    try {
      const {
        purchasedOrderId,
        warehouseId,
        itemId,
        qcRejectQuantity,
        qcPassQuantity,
        lotNumber,
        lotDate,
      } = request;
      const purchasedOrderWarehouse =
        await this.purchasedOrderWarehouseDetailRepository.findOneWithRelations(
          {
            where: {
              purchasedOrderId,
              warehouseId,
              itemId,
            },
            relations: ['purchasedOrder'],
          },
        );

      if (!purchasedOrderWarehouse) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }
      if (!purchasedOrderWarehouse.purchasedOrder) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }

      if (
        !STATUS_TO_QC_ORDER.includes(
          purchasedOrderWarehouse.purchasedOrder.status as number,
        )
      ) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
          .build();
      }
      if (qcPassQuantity < 0 || qcRejectQuantity < 0) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
          .build();
      }

      if (
        plus(qcPassQuantity, qcRejectQuantity) >
        purchasedOrderWarehouse.quantity
      ) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
          .build();
      }
      let lot =
        await this.purchasedOrderWarehouseLotRepository.findOneWithRelations({
          where: {
            purchasedOrderId: purchasedOrderId,
            warehouseId: warehouseId,
            itemId: itemId,
            lotNumber: lotNumber.toUpperCase(),
          },
        });

      if (isEmpty(lot)) {
        lot = new PurchasedOrderWarehouseLotEntity();
        lot.purchasedOrderId = purchasedOrderId;
        lot.purchasedOrderWarehouseId = purchasedOrderWarehouse.id;
        lot.lotNumber = lotNumber.toUpperCase();
        lot.warehouseId = warehouseId;
        lot.itemId = itemId;
        lot.lotDate = lotDate;
        lot.qcPassQuantity = 0;
        lot.qcRejectQuantity = 0;
      }
      lot.qcPassQuantity = plus(lot.qcPassQuantity, qcPassQuantity);
      lot.qcRejectQuantity = plus(lot.qcRejectQuantity, qcRejectQuantity);
      await this.purchasedOrderWarehouseLotRepository.create(lot);
      return await this.setPurchasedOrderWarehouseDetailQcQuantity(
        purchasedOrderWarehouse,
        request.qcPassQuantity,
        request.qcRejectQuantity,
      );
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error)
        .build();
    }
  }

  /**
   *
   * @param purchasedOrderWarehouseDetail
   * @param qcPassQuantity
   * @param qcRejectQuantity
   * @returns
   */
  private async setPurchasedOrderWarehouseDetailQcQuantity(
    purchasedOrderWarehouseDetail: PurchasedOrderWarehouseDetail,
    qcPassQuantity: number,
    qcRejectQuantity: number,
  ): Promise<any> {
    purchasedOrderWarehouseDetail.qcPassQuantity = plus(
      +purchasedOrderWarehouseDetail.qcPassQuantity || 0,
      qcPassQuantity,
    );
    purchasedOrderWarehouseDetail.qcRejectQuantity = plus(
      +purchasedOrderWarehouseDetail.qcRejectQuantity || 0,
      qcRejectQuantity,
    );
    purchasedOrderWarehouseDetail.errorQuantity = plus(
      +purchasedOrderWarehouseDetail.errorQuantity || 0,
      qcRejectQuantity,
    );
    await this.purchasedOrderWarehouseDetailRepository.create(
      purchasedOrderWarehouseDetail,
    );

    const response = plainToInstance(
      PurchasedOrderWarehouseDetailResponseDto,
      purchasedOrderWarehouseDetail,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  public async getPurchasedOrderByMOId(
    manufacturingOrderId: number,
  ): Promise<ResponsePayload<PurchasedOrderResponseDto | any>> {
    const response =
      await this.purchasedOrderRepository.getPurchasedOrderByMOId(
        manufacturingOrderId,
      );
    const dataReturn = plainToInstance(PurchasedOrderResponseDto, response, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getTotalQuantityItemPurchasedOrdersByCondition(
    condition: any,
  ): Promise<any> {
    const { itemIds } = condition;

    const purchasedOrders =
      await this.purchasedOrderRepository.getPurchasedOrderInProgress(
        condition,
      );
    if (purchasedOrders.length === 0) {
      return [];
    }
    const purchasedOrderIds = uniq(map(flatMap(purchasedOrders), 'id'));
    const totalQuantityItems =
      await this.purchasedOrderDetailRepository.getTotalQuantityItemPurchasedOrdersByCondition(
        {
          purchasedOrderIds: purchasedOrderIds,
          itemIds: itemIds,
        },
      );
    const response = plainToInstance(
      TotalQuantityItemPurchaseOrderResponseDto,
      totalQuantityItems,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  async importPurchasedOrders(request: FileUpdloadRequestDto): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
      userId: request.userId,
    } as ImportRequestDto;
    const importPurchasedOrder = await this.purchasedOrdersImport.importUtil(
      importRequestDto,
    );

    const result = new ImportPurchasedOrderResponseDto();
    if (importPurchasedOrder.statusCode === ResponseCodeEnum.SUCCESS) {
      const importPurchasedOrderDetail =
        await this.purchasedOrderItemDetailsImport.importUtil(importRequestDto);

      if (importPurchasedOrderDetail.statusCode === ResponseCodeEnum.SUCCESS) {
        result.purchasedOrder = importPurchasedOrder.data;
        result.purchasedOrderDetail = importPurchasedOrderDetail.data;
      } else {
        result.purchasedOrder = importPurchasedOrder.data;
      }
    } else {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const response = plainToInstance(ImportPurchasedOrderResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  public async getMoExportLots(id?: number): Promise<ResponsePayload<any>> {
    const data = await this.purchasedOrderRepository.getMoExportLots(id);

    const response = plainToInstance(ListMoItemLotsResponse, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  /**
   * Get PurchasedOrderListHaveNotPoimp
   * @param payload
   * @returns
   */
  async getPurchasedOrderListHaveNotPoimp(
    purchasedOrderImportIds: any[],
  ): Promise<ResponsePayload<any>> {
    const purchasedOrdersHaveNotPoimp =
      await this.purchasedOrderRepository.getPoHaveNotPoimp(
        purchasedOrderImportIds,
      );

    const dataReturn = plainToInstance(
      GetAllPOResponse,
      purchasedOrdersHaveNotPoimp,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
