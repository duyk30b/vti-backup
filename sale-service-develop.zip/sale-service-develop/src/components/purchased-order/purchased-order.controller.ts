import { GetOrderDetailByWarehouseQueryDto } from './../order/dto/request/get-order-detail-by-warehouse.request.dto';
import {
  SetOrderStatusBodyDto,
  SetOrderStatusRequestDto,
} from './../order/dto/request/set-order-status-request.dto';
import { UpdatePurchasedBodyOrderDto } from './dto/request/update-purchased-order-request.dto';
import { GetOrderDetailQueryRequestDto } from './../order/dto/request/get-order-detail.request.dto';
import { GetPurchasedOrderListRequest } from './dto/request/get-purchased-order-list-request.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Req,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { GetOrderRequestDto } from '@components/order/dto/request/get-order.request.dto';
import { isEmpty } from 'lodash';
import { UpdateOrderDetailActualQuantityRequestDto } from '@components/order/dto/request/update-actual-quantity-order-detail.request.dto';
import { PurchasedOrderService } from './purchased-order.service';
import { UpdateOrderDetailConfirmQuantityRequestDto } from '@components/order/dto/request/update-confirm-quantity-order-detail.request.dto';
import { CreatePurchasedOrderDto } from './dto/request/create-purchased-order.dto';
import { DeleteOrderQueryRequestDto } from '@components/order/dto/request/delete-order.request.dto';
import { GetAllPORequest } from './dto/request/get-all-po.request.dto';
import { GetListOrderByIdsRequestDto } from '@components/order/dto/request/get-list-order-by-ids.request.dto';
import { GetByItemIdRequestDto } from '@components/purchased-order/dto/request/get-by-item-id.request.dto';
import { GetOrderWarehouseQueryRequest } from '@components/order/dto/request/get-order-warehouse.request.dto';
import { GetOrderByWarehouseItemRequestDto } from '@components/order/dto/request/get-order-by-warehouse-item.request.dto';
import { UpdatePurchasedOrderWarehouseQcQuantityBodyDto } from './dto/request/update-purchased-order-warehouse-qc-quantity-request.dto';
import { GetPurchaseOrderByMOId } from './dto/request/get-purchased-order-by-mo-id.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CREATE_PURCHASED_ORDER_PERMISSION,
  UPDATE_PURCHASED_ORDER_PERMISSION,
  DELETE_PURCHASED_ORDER_PERMISSION,
  DETAIL_PURCHASED_ORDER_PERMISSION,
  LIST_PURCHASED_ORDER_PERMISSION,
  CONFIRM_PURCHASED_ORDER_PERMISSION,
  REJECT_PURCHASED_ORDER_PERMISSION,
  IMPORT_PURCHASES_ORDER_PERMISSION,
} from '@utils/permissions/purchased-order';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import {
  ApiConsumes,
  ApiOperation,
  ApiParam,
  ApiResponse,
} from '@nestjs/swagger';
import { PurchasedOrderResponseDto } from './dto/response/purchased-order-response.dto';
import { PurchasedOrderWarehouseDetailResponseDto } from './dto/response/purchased-order-warehouse-detail-response.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { GetItemLotsRequest } from './dto/request/get-item-lot.request.dto';

@Controller('')
export class PurchasedOrderController {
  constructor(
    @Inject('PurchasedOrderServiceInterface')
    private readonly purchasedOrderService: PurchasedOrderService,
  ) {}

  // @MessagePattern('ping')
  public async get(@Req() request): Promise<any> {
    return new ResponseBuilder('PURCHASED ORDER: PONG')
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  /**
   * Get data purchase order by id and warehouseId
   * @param request
   * @returns
   */
  // @MessagePattern('get_po_warehouse_details')
  public async getPoDetail(@Body() payload: GetOrderRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderService.getWarehouseDetails(
      request.id,
      request.warehouseId,
      request.type,
    );
  }

  /**
   * Update actual quantity of purchased order detail
   * @param request updateOrderDetailActualQuantityRequestDto
   * @returns
   */
  // @MessagePattern('update_po_actual_quantity')
  public async updateActualQuantity(
    @Body() payload: UpdateOrderDetailActualQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderService.updateOrderDetailActualQuantity(
      request,
    );
  }

  /**
   * Update actual quantity of purchased order detail
   * @param request updateOrderDetailActualQuantityRequestDto
   * @returns
   */
  // @MessagePattern('update_po_confirm_quantity')
  public async updateConfirmQuantity(
    @Body() payload: UpdateOrderDetailConfirmQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderService.updateOrderDetailConfirmQuantity(
      request,
    );
  }

  /**
   * Create new purchased order
   * @param request CreatePurchasedOrderDto
   * @returns
   */
  @PermissionCode(CREATE_PURCHASED_ORDER_PERMISSION.code)
  @Post('/purchased-orders/create')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order'],
    summary: 'Create Purchased Order',
    description: 'Tạo lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: PurchasedOrderResponseDto,
  })
  // @MessagePattern('create_purchased_order')
  public async create(@Body() payload: CreatePurchasedOrderDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.createdByUserId = request.userId;
    return await this.purchasedOrderService.create(request);
  }

  /**
   * Update purchased order
   * @param request UpdatePurchasedOrderDto
   * @returns
   */
  @PermissionCode(UPDATE_PURCHASED_ORDER_PERMISSION.code)
  @Put('/purchased-orders/:id')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order'],
    summary: 'Update Purchased Order',
    description: 'Cập nhật lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: PurchasedOrderResponseDto,
  })
  // @MessagePattern('update_purchased_order')
  public async update(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdatePurchasedBodyOrderDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    request.createdByUserId = request.userId;
    return await this.purchasedOrderService.update(request);
  }

  /**
   * Confirm purchased order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @PermissionCode(CONFIRM_PURCHASED_ORDER_PERMISSION.code)
  @Put('/purchased-orders/:id/confirm')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order'],
    summary: 'Confirm Purchased Order',
    description: 'Confirm lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: PurchasedOrderResponseDto,
  })
  // @MessagePattern('confirm_purchased_order')
  public async confirm(
    @Param() payload: SetOrderStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.createdByUserId = request.userId;
    return await this.purchasedOrderService.confirm(request);
  }

  /**
   * Confirm purchased order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @PermissionCode(CONFIRM_PURCHASED_ORDER_PERMISSION.code)
  @Put('/purchased-orders/confirm/multiple')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order'],
    summary: 'Confirm multiple Purchased Order',
    description: 'Confirm nhiều lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: PurchasedOrderResponseDto,
  })
  // @MessagePattern('confirm_purchased_order_multiple')
  public async confirmMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderService.confirmMultiple(request);
  }

  /**
   * Reject purchased order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @PermissionCode(REJECT_PURCHASED_ORDER_PERMISSION.code)
  @Put('/purchased-orders/:id/reject')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order'],
    summary: 'Reject Purchased Order',
    description: 'Reject lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: PurchasedOrderResponseDto,
  })
  // @MessagePattern('reject_purchased_order')
  public async reject(
    @Param() payload: SetOrderStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.createdByUserId = request.userId;
    return await this.purchasedOrderService.reject(request);
  }

  /**
   * Reject purchased order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @PermissionCode(REJECT_PURCHASED_ORDER_PERMISSION.code)
  @Put('/purchased-orders/reject/multiple')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order'],
    summary: 'Reject multiple Purchased Order',
    description: 'Reject nhiều lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: PurchasedOrderResponseDto,
  })
  // @MessagePattern('reject_purchased_order_multiple')
  public async rejectMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderService.rejectMultiple(request);
  }

  /**
   * Approve purchased order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @Put('/purchased-orders/:id/approve')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order'],
    summary: 'Approve Purchased Order',
    description: 'Approve lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: PurchasedOrderResponseDto,
  })
  // @MessagePattern('approve_purchased_order')
  public async approve(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: SetOrderStatusBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    request.createdByUserId = request.userId;
    return await this.purchasedOrderService.approve(request);
  }

  /**
   * Get purchased order list
   * @param request GetPurchasedOrderListRequest
   * @returns
   */
  @PermissionCode(LIST_PURCHASED_ORDER_PERMISSION.code)
  @Get('/purchased-orders/list')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order', 'Mobile'],
    summary: 'Get List Purchased Order',
    description: 'Danh sách lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: PurchasedOrderResponseDto,
  })
  // @MessagePattern('get_purchased_order_list')
  public async getList(
    @Query() payload: GetPurchasedOrderListRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderService.getList(request);
  }

  @Get('/purchased-orders/:id/warehouses/list')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order', 'Warehouse'],
    summary: 'Get Purchased Order Warehouse List',
    description: 'Danh sách kho của lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: PurchasedOrderResponseDto,
  })
  // @MessagePattern('get_purchased_order_warehouses')
  public async getPurchasedOrderWarehouse(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: GetOrderWarehouseQueryRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.purchasedOrderService.getListOrderWarehouse(request);
  }

  /**
   * Get purchased order detail
   * @param request GetPurchasedOrderListRequest
   * @returns
   */
  @Get('/purchased-orders/:id/warehouses/:warehouseId')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order', 'Warehouse'],
    summary: 'Get Purchased Order Warehouse Detail',
    description: 'Chi tiết kho của lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: PurchasedOrderWarehouseDetailResponseDto,
  })
  // @MessagePattern('get_purchased_order_warehouse')
  public async getDetailByWarehouseId(
    @Param('id', new ParseIntPipe()) id,
    @Param('warehouseId', new ParseIntPipe()) warehouseId,
    @Query() payload: GetOrderDetailByWarehouseQueryDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    request.warehouseId = warehouseId;
    return await this.purchasedOrderService.getDetailByWarehouseId(request);
  }

  /**
   * Get purchased order detail by warehouse
   * @param request GetPurchasedOrderListRequest
   * @returns
   */
  @PermissionCode(DETAIL_PURCHASED_ORDER_PERMISSION.code)
  @Get('/purchased-orders/:id')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order'],
    summary: 'Get Purchased Order Detail',
    description: 'Chi tiết lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: PurchasedOrderResponseDto,
  })
  // @MessagePattern('get_purchased_order_detail')
  public async getDetail(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: GetOrderDetailQueryRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.purchasedOrderService.getDetail(request);
  }

  @Get('/purchased-orders/all')
  @ApiOperation({
    tags: ['Purchased', 'Purchased Order'],
    summary: 'Get List Purchase Order',
    description: 'Danh sách lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: null,
  })
  // @MessagePattern('get_purchased_orders')
  public async getPurchasedOrders(
    @Query() payload: GetAllPORequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderService.getPurchasedOrders(request);
  }

  @PermissionCode(DELETE_PURCHASED_ORDER_PERMISSION.code)
  @Delete('/purchased-orders/:id')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order'],
    summary: 'Delete Purchased Order',
    description: 'Xoá lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  // @MessagePattern('delete_purchased_order')
  public async delete(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: DeleteOrderQueryRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;
    return await this.purchasedOrderService.delete(request);
  }

  @PermissionCode(DELETE_PURCHASED_ORDER_PERMISSION.code)
  @Delete('/purchased-orders/multiple')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order'],
    summary: 'Delete multiple Purchased Order',
    description: 'Xoá nhiều lệnh đặt hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  // @MessagePattern('delete_purchased_order_multiple')
  public async deleteMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderService.deleteMultiple(request);
  }

  // @MessagePattern('get_purchased_order_by_ids')
  public async getPurchasedOrderByIds(
    @Body() payload: GetListOrderByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderService.getListByIds(request);
  }

  // @MessagePattern('check_item_has_exist_on_purchase_order')
  public async checkItemHasExistOnPurchaseOrder(
    @Body() payload: GetByItemIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderService.checkItemHasExistOnPurchaseOrder(
      request,
    );
  }

  // @MessagePattern('get_po_by_warehouse')
  public async getPoByWarehouseItem(
    @Body() payload: GetOrderByWarehouseItemRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderService.getPoByWarehouse(request);
  }

  @Put(
    '/purchased-orders/:id/warehouses/:warehouseId/items/:itemId/quality-controls/quantities',
  )
  @ApiOperation({
    tags: ['Purchased', 'Purchased Order'],
    summary: 'Update QC Quantity Purchase Order Warehouse',
    description: 'Cập nhật QC lệnh sản xuất',
  })
  @ApiParam({
    name: 'id',
    type: Number,
    example: 30,
    required: true,
    description: 'purchased order id',
  })
  @ApiParam({
    name: 'warehouseId',
    type: Number,
    example: 14,
    required: true,
    description: 'warehouse id',
  })
  @ApiParam({
    name: 'itemId',
    type: Number,
    example: 154,
    required: true,
    description: 'item id',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: PurchasedOrderWarehouseDetailResponseDto,
  })
  // @MessagePattern('update_po_qc_quantity')
  public async updateQcQuantity(
    @Param('id', new ParseIntPipe()) purchasedOrderId,
    @Param('warehouseId', new ParseIntPipe()) warehouseId,
    @Param('itemId', new ParseIntPipe()) itemId,
    @Body() payload: UpdatePurchasedOrderWarehouseQcQuantityBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.purchasedOrderId = purchasedOrderId;
    request.warehouseId = warehouseId;
    request.itemId = itemId;
    return await this.purchasedOrderService.updatePOQcQuantityPurchasedOrderWarehouse(
      request,
    );
  }

  // @MessagePattern('get_purchased_order_by_mo_id')
  public async getPurchasedOrderByMOId(
    @Body() payload: GetPurchaseOrderByMOId,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderService.getPurchasedOrderByMOId(
      request.manufacturingOrderId,
    );
  }

  // @MessagePattern('get_total_quantity_item_purchased_order_by_condition')
  public async getTotalQuantityItemPurchasedOrdersByCondition(
    request: any,
  ): Promise<any> {
    return await this.purchasedOrderService.getTotalQuantityItemPurchasedOrdersByCondition(
      request,
    );
  }

  @PermissionCode(IMPORT_PURCHASES_ORDER_PERMISSION.code)
  @Post('/purchased-orders/import')
  @ApiOperation({
    tags: ['Sales', 'Purchased Order'],
    summary: 'Import Purchased Orders',
    description: 'Nhập danh sách đơn mua',
  })
  @ApiResponse({
    status: 200,
    description: 'Import list success',
    type: ImportResponseDto,
  })
  @ApiConsumes('multipart/form-data')
  // @MessagePattern('import_purchased_orders')
  public async importPurchasedOrders(
    @Body() body: FileUpdloadRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderService.importPurchasedOrders(request);
  }

  @Get('/export/lots')
  @ApiOperation({
    tags: ['MO', 'MO item lots'],
    summary: 'Get Mo Item Lots',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Mo Item Lots',
  })
  public async getMoExportLots(
    @Query() query: GetItemLotsRequest,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderService.getMoExportLots(request.moId);
  }

  // TO DO: remove after refactor done
  @MessagePattern('get_po_warehouse_details')
  public async getPoDetailTcp(
    @Body() payload: GetOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderService.getWarehouseDetails(
      request.id,
      request.warehouseId,
      request.type,
    );
  }

  @MessagePattern('update_po_actual_quantity')
  public async updateActualQuantityTcp(
    @Body() payload: UpdateOrderDetailActualQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderService.updateOrderDetailActualQuantity(
      request,
    );
  }

  @MessagePattern('update_po_confirm_quantity')
  public async updateConfirmQuantityTcp(
    @Body() payload: UpdateOrderDetailConfirmQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderService.updateOrderDetailConfirmQuantity(
      request,
    );
  }

  @MessagePattern('get_purchased_order_by_ids')
  public async getPurchasedOrderByIdsTcp(
    @Body() payload: GetListOrderByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderService.getListByIds(request);
  }

  @MessagePattern('check_item_has_exist_on_purchase_order')
  public async checkItemHasExistOnPurchaseOrderTcp(
    @Body() payload: GetByItemIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderService.checkItemHasExistOnPurchaseOrder(
      request,
    );
  }

  @MessagePattern('get_po_by_warehouse')
  public async getPoByWarehouseItemTcp(
    @Body() payload: GetOrderByWarehouseItemRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderService.getPoByWarehouse(request);
  }

  @MessagePattern('get_purchased_order_by_mo_id')
  public async getPurchasedOrderByMOIdTcp(
    @Body() payload: GetPurchaseOrderByMOId,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderService.getPurchasedOrderByMOId(
      request.manufacturingOrderId,
    );
  }

  @MessagePattern('get_total_quantity_item_purchased_order_by_condition')
  public async getTotalQuantityItemPurchasedOrdersByConditionTcp(
    request: any,
  ): Promise<any> {
    return await this.purchasedOrderService.getTotalQuantityItemPurchasedOrdersByCondition(
      request,
    );
  }

  @MessagePattern('create_purchased_order')
  public async createTcp(
    @Body() payload: CreatePurchasedOrderDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.createdByUserId = request.userId;
    return await this.purchasedOrderService.create(request);
  }
}
