import { ImportDataAbstract } from '@core/abstracts/import-data.abstract';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { PurchasedOrder } from '@entities/purchased-order/purchased-order.entity';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectDataSource } from '@nestjs/typeorm';
import { ResponsePayload } from '@utils/response-payload';
import { compact, isEmpty, keyBy, map, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, In } from 'typeorm';
import { PurchasedOrderRepositoryInterface } from '../interface/purchased-order.repository.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { PurchasedOrderDetail } from '@entities/purchased-order/purchased-order-detail.entity';
import { PurchasedOrderWarehouseDetail } from '@entities/purchased-order/purchased-order-warehouse-detail.entity';
import { CAN_UPDATE_ORDER_STATUS } from '@constant/order.constant';

@Injectable()
export class PurchasedOrderItemDetailsImport extends ImportDataAbstract {
  private readonly FIELD_TEMPLATE_PURCHASED_ORDER_DETAIL_CONST = {
    PURCHASED_ORDER_CODE: {
      DB_COL_NAME: 'purchasedOrderCode',
      COL_NAME: ['Mã đơn đặt hàng', 'Purchased order code', '発注書コード'],
      MAX_LENGTH: 24,
      ALLOW_NULL: false,
    },
    ITEM_CODE: {
      DB_COL_NAME: 'itemCode',
      COL_NAME: ['Mã sản phẩm', 'Item code', '商品コード'],
      MAX_LENGTH: 7,
      ALLOW_NULL: false,
    },
    PURCHASED_ORDER_ITEM_QUANTITY: {
      DB_COL_NAME: 'purchasedOrderItemQuantity',
      COL_NAME: ['Số lượng', 'Quantity', '額'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },

    REQUIRED_COL_NUM: 3,
  };

  private readonly SHEET_NAME = 'Item detail';
  private readonly ROW_NUMBER_START_DATA = 2;

  constructor(
    @Inject('PurchasedOrderRepositoryInterface')
    private readonly purchasedOrderRepository: PurchasedOrderRepositoryInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    const arrayField = [];
    for (const [key, value] of Object.entries(
      this.FIELD_TEMPLATE_PURCHASED_ORDER_DETAIL_CONST,
    )) {
      arrayField.push(value);
    }

    this.fieldsMap.groupSet(arrayField, this.ROW_NUMBER_START_DATA);
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
    error: number,
    total: number,
    userId?: number,
  ): Promise<ImportResponseDto | any> {
    const purchasedOrderCodeImport = [];
    const itemCodeImport = [];

    for (let i = 0; i < dataDto.length; i++) {
      purchasedOrderCodeImport.push(dataDto[i].purchasedOrderCode);
      itemCodeImport.push(dataDto[i].itemCode);
    }
    const getData = await Promise.all([
      this.purchasedOrderRepository.findByCondition({
        code: In(compact(uniq(purchasedOrderCodeImport))),
      }),
      this.itemService.getItemByCodes(compact(uniq(itemCodeImport))),
    ]);
    const purchasedOrders = keyBy(getData[0], 'code');
    const items = keyBy(getData[1], 'code');
    const messages = await this.getMessage();
    const entities = {
      purchasedOrderDetails: [],
      purchasedOrderWarehouseDetails: [],
    };
    const valid = [];
    const response = new ImportResponseDto();

    dataDto.forEach((record) => {
      const {
        i,
        action,
        purchasedOrderCode,
        itemCode,
        purchasedOrderItemQuantity,
      } = record;
      const logRow = {
        id: i,
        row: i,
        action: action,
      } as ImportResultDto;
      const purchasedOrder = purchasedOrders[purchasedOrderCode]
        ? purchasedOrders[purchasedOrderCode]
        : null;
      const item = items[itemCode] ? items[itemCode] : null;

      let msgLog = '';
      msgLog = this.validateDataPurchasedOrderItemDetail(
        record,
        purchasedOrder,
        item,
        messages,
      );
      const sameItemInPurchasedOrder = dataDto.filter(
        (i) =>
          i.itemCode === itemCode &&
          i.purchasedOrderCode === purchasedOrderCode,
      );
      if (sameItemInPurchasedOrder.length > 1) {
        msgLog = messages.sameItemCodeInPurchaseOrder;
      }

      if (msgLog === '') {
        const purchasedOrderDetailEntity = new PurchasedOrderDetail();
        purchasedOrderDetailEntity.purchasedOrderId = purchasedOrder.id;
        purchasedOrderDetailEntity.itemId = item.id;
        purchasedOrderDetailEntity.quantity = purchasedOrderItemQuantity;

        entities.purchasedOrderDetails.push(purchasedOrderDetailEntity);

        const purchasedOrderWarehouseDetailEntity =
          new PurchasedOrderWarehouseDetail();
        purchasedOrderWarehouseDetailEntity.purchasedOrderId =
          purchasedOrder.id;
        purchasedOrderWarehouseDetailEntity.itemId = item.id;
        purchasedOrderWarehouseDetailEntity.quantity =
          purchasedOrderItemQuantity;

        entities.purchasedOrderWarehouseDetails.push(
          purchasedOrderWarehouseDetailEntity,
        );
        logRow.log = [messages.successMsg];
        valid.push(logRow);
      } else {
        logRow.log = [msgLog];
        logs.push(logRow);
      }
    });

    if (!isEmpty(entities.purchasedOrderDetails)) {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        const purchaseOrderIds = uniq(
          map(entities.purchasedOrderDetails, 'purchasedOrderId'),
        );

        await queryRunner.manager.delete(PurchasedOrderWarehouseDetail, {
          purchasedOrderId: In(purchaseOrderIds),
        });

        await queryRunner.manager.delete(PurchasedOrderDetail, {
          purchasedOrderId: In(purchaseOrderIds),
        });

        const purchasedOrderDetails = await queryRunner.manager.save(
          PurchasedOrderDetail,
          entities.purchasedOrderDetails,
        );

        const purchasedOrderWarehouseDetails = [];
        entities.purchasedOrderWarehouseDetails.forEach((powd) => {
          const purchasedOrderDetailsFindMap = keyBy(
            purchasedOrderDetails.filter(
              (pod) => pod.purchasedOrderId === powd.purchasedOrderId,
            ),
            'itemId',
          );
          purchasedOrderWarehouseDetails.push({
            ...powd,
            purchasedOrderDetailId:
              purchasedOrderDetailsFindMap[powd.itemId].id,
          });
        });
        await queryRunner.manager.save(
          PurchasedOrderWarehouseDetail,
          purchasedOrderWarehouseDetails,
        );

        await queryRunner.commitTransaction();
        response.successCount = valid.length;
      } catch (error) {
        await queryRunner.rollbackTransaction();
        response.successCount = 0;
        valid.forEach((e) => (e.log = [messages.unsuccessMsg]));
      } finally {
        await queryRunner.release();
        logs.push(...valid);
      }
    }

    response.result = logs;
    response.totalCount = total;

    return response;
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<ImportResponseDto>> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_PURCHASED_ORDER_DETAIL_CONST.REQUIRED_COL_NUM,
      this.SHEET_NAME,
    );
  }

  private validateDataPurchasedOrderItemDetail(
    data: any,
    purchasedOrder: PurchasedOrder,
    item: any,
    messages: any,
  ): any {
    const {
      purchaseOrderCodeNotExist,
      itemCodeNotExist,
      quantityMustBeGreaterThanZero,
      purchaseOrderWasConfirmed,
    } = messages;

    const { purchasedOrderCode, itemCode, purchasedOrderItemQuantity } = data;
    if (!purchasedOrder) {
      return purchaseOrderCodeNotExist;
    }
    if (!CAN_UPDATE_ORDER_STATUS.includes(purchasedOrder.status)) {
      return purchaseOrderWasConfirmed;
    }
    if (!item) {
      return itemCodeNotExist;
    }
    if (purchasedOrderItemQuantity < 0) {
      return quantityMustBeGreaterThanZero;
    }
    return '';
  }
}
