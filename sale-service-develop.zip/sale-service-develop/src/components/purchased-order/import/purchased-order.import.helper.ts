import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { VendorRepositoryInterface } from '@components/vendor/interface/vendor.repository.interface';
import { ImportDataAbstract } from '@core/abstracts/import-data.abstract';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { PurchasedOrder } from '@entities/purchased-order/purchased-order.entity';
import { Vendor } from '@entities/vendor/vendor.entity';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectDataSource } from '@nestjs/typeorm';
import { ResponsePayload } from '@utils/response-payload';
import { compact, isEmpty, keyBy, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, In } from 'typeorm';
import { PurchasedOrderRepositoryInterface } from '../interface/purchased-order.repository.interface';
import * as Moment from 'moment';
import { extendMoment } from 'moment-range';
import { CAN_UPDATE_ORDER_STATUS } from '@constant/order.constant';
const moment = extendMoment(Moment);

@Injectable()
export class PurchasedOrdersImport extends ImportDataAbstract {
  private readonly FIELD_TEMPLATE_PURCHASED_ORDER_CONST = {
    PURCHASED_ORDER_CODE: {
      DB_COL_NAME: 'purchasedOrderCode',
      COL_NAME: ['Purchased order code', '発注書コード', 'Mã đơn đặt hàng'],
      MAX_LENGTH: 24,
      ALLOW_NULL: false,
    },
    PURCHASED_ORDER_NAME: {
      DB_COL_NAME: 'purchasedOrderName',
      COL_NAME: ['Purchased order name', '発注書名', 'Tên đơn đặt hàng'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    MANUFACTURING_ORDER_CODE: {
      DB_COL_NAME: 'manufacturingOrderCode',
      COL_NAME: [
        'Manufacturing order code',
        '製造指図番号',
        'Mã lệnh sản xuất',
      ],
      MAX_LENGTH: 20,
      ALLOW_NULL: true,
    },
    PURCHASED_ORDER_AT: {
      DB_COL_NAME: 'purchasedOrderAt',
      COL_NAME: ['Purchased date', '発注日', 'Ngày đặt hàng'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    COMPANY_CODE: {
      DB_COL_NAME: 'companyCode',
      COL_NAME: ['Company code', '会社コード', 'Mã công ty'],
      MAX_LENGTH: 9,
      ALLOW_NULL: false,
    },
    VENDOR_CODE: {
      DB_COL_NAME: 'vendorCode',
      COL_NAME: ['Vendor code', '仕入先コード', 'Mã nhà cung cấp'],
      MAX_LENGTH: 20,
      ALLOW_NULL: false,
    },
    PURCHASED_ORDER_DEADLINE_AT: {
      DB_COL_NAME: 'purchasedOrderDeadLineAt',
      COL_NAME: ['Delivery date', '納品日', 'Ngày giao hàng'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    PURCHASED_ORDER_DESCRIPTION: {
      DB_COL_NAME: 'purchasedOrderDescription',
      COL_NAME: ['Description', '発注書説明', 'Mô tả đơn hàng'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    REQUIRED_COL_NUM: 9,
  };

  private readonly SHEET_NAME = 'Purchased order';
  private readonly ROW_NUMBER_START_DATA = 2;

  constructor(
    @Inject('VendorRepositoryInterface')
    private readonly vendorRepositoryRepository: VendorRepositoryInterface,

    @Inject('PurchasedOrderRepositoryInterface')
    private readonly purchasedOrderRepository: PurchasedOrderRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ProduceServiceInterface')
    private readonly produceService: ProduceServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    const arrayField = [];
    for (const [key, value] of Object.entries(
      this.FIELD_TEMPLATE_PURCHASED_ORDER_CONST,
    )) {
      arrayField.push(value);
    }

    this.fieldsMap.groupSet(arrayField, this.ROW_NUMBER_START_DATA);
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
    error: number,
    total: number,
    userId?: number,
  ): Promise<ImportResponseDto | any> {
    const purchasedOrderCodeImport = [];
    const manufacturingOrderCodeImport = [];
    const vendorCodeImport = [];
    const companyCodeImport = [];

    for (let i = 0; i < dataDto.length; i++) {
      purchasedOrderCodeImport.push(dataDto[i].purchasedOrderCode);
      manufacturingOrderCodeImport.push(dataDto[i].manufacturingOrderCode);
      vendorCodeImport.push(dataDto[i].vendorCode);
      companyCodeImport.push(dataDto[i].companyCode);
    }

    const getData = await Promise.all([
      this.purchasedOrderRepository.findByCondition({
        code: In(compact(uniq(purchasedOrderCodeImport))),
      }),
      this.produceService.getMoByCodes(
        compact(uniq(manufacturingOrderCodeImport)),
      ),
      this.vendorRepositoryRepository.findByCondition({
        code: In(compact(uniq(vendorCodeImport))),
      }),
      this.userService.getListCompanyByCodes(compact(uniq(companyCodeImport))),
    ]);
    const purchasedOrders = keyBy(getData[0], 'code');
    const manufacturingOrders = keyBy(getData[1], 'code');
    const vendors = keyBy(getData[2], 'code');
    const companies = keyBy(getData[3], 'code');

    const messages = await this.getMessage();
    const entities = [];
    const valid = [];
    const response = new ImportResponseDto();

    dataDto.forEach((record) => {
      const {
        i,
        action,
        purchasedOrderCode,
        manufacturingOrderCode,
        vendorCode,
        companyCode,
        purchasedOrderName,
        purchasedOrderAt,
        purchasedOrderDeadLineAt,
        purchasedOrderDescription,
      } = record;
      let msgLog = '';
      if (
        action.toLowerCase() !== messages.addText &&
        action.toLowerCase() !== messages.updateText
      ) {
        msgLog = messages.actionValueIsIncorrect;
      }
      const logRow = {
        id: i,
        row: i,
        action: action,
      } as ImportResultDto;
      const purchasedOrderOld = purchasedOrders[purchasedOrderCode]
        ? purchasedOrders[purchasedOrderCode]
        : null;
      const company = companies[companyCode] ? companies[companyCode] : null;
      const vendor = vendors[vendorCode] ? vendors[vendorCode] : null;
      const manufacturingOrder = manufacturingOrders[manufacturingOrderCode]
        ? manufacturingOrders[manufacturingOrderCode]
        : null;

      if (action.toLowerCase() === messages.addText) {
        msgLog = this.validateDataPurchasedOrder(
          false,
          record,
          purchasedOrderOld,
          company,
          vendor,
          manufacturingOrder,
          messages,
        );
      }

      if (action.toLowerCase() === messages.updateText) {
        msgLog = this.validateDataPurchasedOrder(
          true,
          record,
          purchasedOrderOld,
          company,
          vendor,
          manufacturingOrder,
          messages,
        );
      }
      const samePurchasedOrderNew = dataDto.filter(
        (i) => i.purchasedOrderCode === purchasedOrderCode,
      );
      if (samePurchasedOrderNew.length > 1) {
        msgLog = messages.purchaseOrderCodeDuplicate;
      }

      if (msgLog === '') {
        const purchasedOrderEntity = new PurchasedOrder();
        purchasedOrderEntity.code = purchasedOrderCode?.trim();
        purchasedOrderEntity.name = purchasedOrderName?.trim();
        purchasedOrderEntity.description =
          purchasedOrderDescription?.trim() || '';
        purchasedOrderEntity.manufacturingOrderId =
          manufacturingOrderCode !== '' ? manufacturingOrder.id : null;
        purchasedOrderEntity.companyId = company.id;
        purchasedOrderEntity.vendorId = vendor.id;
        purchasedOrderEntity.purchasedAt = purchasedOrderAt;
        purchasedOrderEntity.deadline = purchasedOrderDeadLineAt;
        purchasedOrderEntity.createdByUserId = userId;
        if (action.toLowerCase() === messages.updateText) {
          purchasedOrderEntity.id = purchasedOrderOld.id;
        }

        entities.push(purchasedOrderEntity);
        logRow.log = [messages.successMsg];
        valid.push(logRow);
      } else {
        logRow.log = [msgLog];
        logs.push(logRow);
      }
    });

    if (!isEmpty(entities)) {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(PurchasedOrder, entities);
        await queryRunner.commitTransaction();
        response.successCount = valid.length;
      } catch (error) {
        await queryRunner.rollbackTransaction();
        response.successCount = 0;
        valid.forEach((e) => (e.log = [messages.unsuccessMsg]));
      } finally {
        await queryRunner.release();
        logs.push(...valid);
      }
    }

    response.result = logs;
    response.totalCount = total;

    return response;
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<ImportResponseDto>> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_PURCHASED_ORDER_CONST.REQUIRED_COL_NUM,
      this.SHEET_NAME,
    );
  }

  private validateDataPurchasedOrder(
    isUpdate: boolean,
    purchasedOrderNew: any,
    purchasedOrderOld: PurchasedOrder,
    company: any,
    vendor: Vendor,
    manufacturingOrder: any,
    messages: any,
  ): any {
    const {
      purchaseOrderCodeNotExist,
      purchaseOrderCodeIsExist,
      companyCodeNotExist,
      vendorCodeNotExist,
      manufacturingOrderCodeNotExist,
      purchaseOrderAtMustAfterDeadlineAt,
      purchaseOrderWasConfirmed,
    } = messages;

    const {
      manufacturingOrderCode,
      purchasedOrderAt,
      purchasedOrderDeadLineAt,
    } = purchasedOrderNew;
    if (isUpdate) {
      if (!purchasedOrderOld) {
        return purchaseOrderCodeNotExist;
      }
      if (!CAN_UPDATE_ORDER_STATUS.includes(purchasedOrderOld.status)) {
        return purchaseOrderWasConfirmed;
      }
    } else {
      if (purchasedOrderOld) {
        return purchaseOrderCodeIsExist;
      }
    }
    if (!company) {
      return companyCodeNotExist;
    }
    if (!vendor) {
      return vendorCodeNotExist;
    }
    if (manufacturingOrderCode !== '' && !manufacturingOrder) {
      return manufacturingOrderCodeNotExist;
    }
    if (moment(purchasedOrderAt).isAfter(moment(purchasedOrderDeadLineAt))) {
      return purchaseOrderAtMustAfterDeadlineAt;
    }
    return '';
  }
}
