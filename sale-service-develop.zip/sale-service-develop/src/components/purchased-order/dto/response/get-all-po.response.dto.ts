import { Expose, Type } from 'class-transformer';

class Vendor {
  @Expose()
  id: number;

  @Expose()
  name: string;
}

class Item {
  @Expose()
  purchasedOrderId: number;

  @Expose()
  itemId: number;

  @Expose()
  quantity: number;

  @Expose()
  confirmedQuantity: number;

  @Expose()
  warehouseId: number;
}
export class GetAllPOResponse {
  @Expose()
  id: number;

  @Expose()
  companyId: number;

  @Expose()
  createdAt: Date;

  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose({ name: 'vendor' })
  @Type(() => Vendor)
  vendor: Vendor;

  @Expose({ name: 'purchasedOrderWarehouseDetails' })
  @Type(() => Item)
  items: Item[];
}
