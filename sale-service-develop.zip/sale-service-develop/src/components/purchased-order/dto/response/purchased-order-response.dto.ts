import { WarehouseResponseDto } from './../../../warehouse/dto/response/warehouse.dto.response';
import { ItemResponseDto } from './../../../item/dto/response/item.dto.response';
import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { OrderResponseDto } from '@components/order/dto/response/order-response.dto';

class PurchasedOrderDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  purchasedOrderId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  price: number;

  @ApiProperty()
  @Expose()
  confirmQuantity: number;

  @ApiProperty()
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;
}

class PurchasedOrderWarehouseDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  purchasedOrderId: number;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  confirmQuantity: number;

  @ApiProperty()
  @Expose()
  qcRejectQuantity: number;

  @ApiProperty()
  @Expose()
  qcPassQuantity: number;

  @ApiProperty()
  @Expose()
  errorQuantity: number;

  @ApiProperty()
  @Expose()
  qcCheck: number;

  @ApiProperty()
  @Expose()
  qcCriteriaId: number;

  @ApiProperty()
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;

  @ApiProperty()
  @Type(() => WarehouseResponseDto)
  @Expose()
  warehouse: WarehouseResponseDto;
}

class PurchasedOrderVendor {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  email: string;

  @ApiProperty()
  @Expose()
  fax: string;

  @ApiProperty()
  @Expose()
  phone: string;
}

class RequestBuyMaterial {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;
}

export class ManufacturingOrder {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  factoryId: number;

  @ApiProperty()
  @Expose()
  saleOrderId: number;

  @ApiProperty()
  @Expose()
  planFrom: Date;

  @ApiProperty()
  @Expose()
  planTo: Date;

  @ApiProperty()
  @Expose()
  status: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty()
  @Expose()
  requestBuyMaterial: RequestBuyMaterial;
}

class Company {
  @Expose()
  id: number;

  @Expose()
  code: string;

  @Expose()
  name: string;
}

export class PurchasedOrderResponseDto extends OrderResponseDto {
  @ApiProperty()
  @Expose()
  vendorId: number;

  @ApiProperty({ type: Company })
  @Expose()
  @Type(() => Company)
  company: Company;

  @ApiProperty({ type: PurchasedOrderVendor })
  @Expose()
  @Type(() => PurchasedOrderVendor)
  vendor: PurchasedOrderVendor;

  @ApiProperty({ type: ManufacturingOrder })
  @Expose()
  @Type(() => ManufacturingOrder)
  manufacturingOrder: ManufacturingOrder;

  @ApiProperty({ type: PurchasedOrderDetail })
  @Expose()
  @Type(() => PurchasedOrderDetail)
  purchasedOrderDetails: PurchasedOrderDetail[];

  @ApiProperty({ type: PurchasedOrderWarehouseDetail })
  @Expose()
  @Type(() => PurchasedOrderWarehouseDetail)
  purchasedOrderWarehouseDetails: PurchasedOrderWarehouseDetail[];
}

export class ListMoItemLotsResponse {
  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  mfg: string;

  @ApiProperty()
  @Expose()
  itemId: number;
}
