import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { OrderListResponse } from './../../../order/dto/response/order-list-response.dto';

export class ManufacturingOrder {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  factoryId: number;

  @ApiProperty()
  @Expose()
  saleOrderId: number;

  @ApiProperty()
  @Expose()
  planFrom: Date;

  @ApiProperty()
  @Expose()
  planTo: Date;

  @ApiProperty()
  @Expose()
  status: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;
}

export class Company {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;
}

export class SaleOrder {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;
}

class PurchasedOrderDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  price: number;
}
export class PurchasedOrderListResponse extends OrderListResponse {
  @ApiProperty()
  @Expose()
  vendorName: string;

  @ApiProperty()
  @Expose()
  purchasedAt: Date;

  @ApiProperty()
  @Expose()
  companyId: number;

  @ApiProperty()
  @Expose()
  @Type(() => Company)
  company: Company;

  @ApiProperty()
  @Expose()
  paymentStatus: number;

  @ApiProperty()
  @Expose()
  purchasedOrderDetail: PurchasedOrderDetail[];

  @ApiProperty({ type: ManufacturingOrder })
  @Expose()
  @Type(() => ManufacturingOrder)
  manufacturingOrder: ManufacturingOrder;

  @ApiProperty({ type: SaleOrder })
  @Expose()
  @Type(() => SaleOrder)
  saleOrder: SaleOrder;
}
