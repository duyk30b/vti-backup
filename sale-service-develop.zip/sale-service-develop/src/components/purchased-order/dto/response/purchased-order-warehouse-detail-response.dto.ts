import { IsArray } from 'class-validator';
import { Expose, Transform, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { OrderResponseDto } from '@components/order/dto/response/order-response.dto';

class Warehouse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}

class Detail {
  @ApiProperty()
  @Expose({ name: 'itemDetailSettingId' })
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty({})
  @Expose({ name: 'itemDetailQuantity' })
  quantity: number;
}

class LotDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty({ description: '' })
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  lotDate: string;

  @ApiProperty({ description: 'Số lượng cần nhập còn lại' })
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  isExpired?: boolean;
}

class Vendor {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class POItem {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty({ description: 'Số lượng thực tế đã nhập' })
  @Expose()
  actualQuantity: number;

  @ApiProperty({ description: 'Số lượng cần nhập còn lại' })
  @Expose()
  quantity: number;

  @ApiProperty({ description: 'Số lượng cần nhập theo kế hoạch' })
  @Expose()
  planQuantity: number;

  @ApiProperty({ description: 'Số lươgnj đã xác nhận' })
  @Expose()
  confirmQuantity: number;

  @ApiProperty({ description: 'Số lươgnj đã xác nhận' })
  @Expose()
  qcCheck: number;

  @ApiProperty({ description: 'Số lươgnj đã xác nhận' })
  @Expose()
  qcCriteriaId: number;

  @ApiProperty({
    description: 'Danh sách chi tiết',
    type: () => Detail,
    isArray: true,
  })
  @Expose()
  @Type(() => Detail)
  details: Detail[];

  @ApiProperty({
    description: 'Danh sách số lô',
    type: () => LotDetail,
    isArray: true,
  })
  @Expose()
  @Type(() => LotDetail)
  lots: LotDetail[];
}

export class PurchasedOrderWarehouseDetailResponseDto extends OrderResponseDto {
  @ApiProperty()
  @Expose()
  vendorId: number;

  @ApiProperty({
    type: () => Warehouse,
    description: 'Chi tiết kho theo user - chỉ kho thuộc user mới hiển thị',
  })
  @Expose()
  @Type(() => Warehouse)
  warehouse: Warehouse;

  @ApiProperty({
    type: () => Vendor,
  })
  @Expose()
  @Type(() => Vendor)
  vendor: Vendor;

  @ApiProperty({
    type: () => POItem,
    isArray: true,
    description: 'Danh sách item',
  })
  @Expose()
  @Type(() => POItem)
  @IsArray()
  items: POItem[];
}
