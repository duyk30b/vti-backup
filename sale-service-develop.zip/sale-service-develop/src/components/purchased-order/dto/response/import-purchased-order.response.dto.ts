import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

export class ImportPurchasedOrderResponseDto {
  @ApiProperty({ type: ImportResponseDto })
  @Expose()
  @Type(() => ImportResponseDto)
  purchasedOrder: ImportResponseDto;

  @ApiProperty({ type: ImportResponseDto })
  @Expose()
  @Type(() => ImportResponseDto)
  purchasedOrderDetail: ImportResponseDto;
}
