import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsNumber,
  IsInt,
  Min,
  IsNotEmpty,
  IsString,
  MaxLength,
  IsDateString,
} from 'class-validator';

export class UpdatePurchasedOrderWarehouseQcQuantityBodyDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @MaxLength(20)
  lotNumber: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  lotDate: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  qcPassQuantity: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  qcRejectQuantity: number;
}

export class UpdatePurchasedOrderWarehouseQcQuantityDto extends UpdatePurchasedOrderWarehouseQcQuantityBodyDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  purchasedOrderId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  warehouseId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  itemId: number;
}
