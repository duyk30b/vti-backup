import { CreatePurchasedOrderDto } from '@components/purchased-order/dto/request/create-purchased-order.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class UpdatePurchasedBodyOrderDto extends CreatePurchasedOrderDto {}

export class UpdatePurchasedOrderDto extends UpdatePurchasedBodyOrderDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  id: number;
}
