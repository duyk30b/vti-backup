import { CreateOrderRequestDto } from '@components/order/dto/request/create-order-resquest.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsBoolean,
  IsDateString,
  IsDecimal,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  Min,
  ValidateNested,
} from 'class-validator';

class ItemRequest {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  quantity: number;

  @ApiProperty()
  @IsOptional()
  @IsBoolean()
  qcCheck?: boolean;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  qcCriteriaId?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  @Min(0)
  price: number;
}

export class CreatePurchasedOrderDto extends CreateOrderRequestDto {
  @ApiProperty()
  @IsInt()
  @IsOptional()
  companyId: number;

  @ApiProperty()
  @IsInt()
  @IsOptional()
  vendorId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  purchasedAt: Date;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  deadline: Date;

  @ApiProperty()
  @ArrayUnique<ItemRequest>()
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => ItemRequest)
  items: ItemRequest[];

  @ApiPropertyOptional()
  @IsInt()
  @IsOptional()
  manufacturingOrderId: number;
}
