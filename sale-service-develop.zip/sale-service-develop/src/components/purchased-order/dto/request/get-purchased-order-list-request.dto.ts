import { GetOrderListRequest } from '@components/order/dto/request/get-order-list.request.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsOptional } from 'class-validator';

export class GetPurchasedOrderListRequest extends GetOrderListRequest {
  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll: string;
}
