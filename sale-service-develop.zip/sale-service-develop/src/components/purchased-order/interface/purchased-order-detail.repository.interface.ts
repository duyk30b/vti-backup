import { OrderDetailRepositoryInterface } from '@components/order/interface/order-detail.repository.interface';
import { PurchasedOrderDetail } from '@entities/purchased-order/purchased-order-detail.entity';

export interface PurchasedOrderDetailRepositoryInterface
  extends OrderDetailRepositoryInterface<PurchasedOrderDetail> {
  getTotalQuantityItemPurchasedOrdersByCondition(condition: any): Promise<any>;
}
