import { OrderWarehouseDetailRepositoryInterface } from '@components/order/interface/order-warehouse-detail.repository.interface';
import { PurchasedOrderWarehouseDetail } from '@entities/purchased-order/purchased-order-warehouse-detail.entity';

export interface PurchasedOrderWarehouseDetailRepositoryInterface
  extends OrderWarehouseDetailRepositoryInterface<PurchasedOrderWarehouseDetail> {
  getListItemIdByQcStageId(type: any): Promise<any>;
}
