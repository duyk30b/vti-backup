import { GetOrderByWarehouseItemRequestDto } from './../../order/dto/request/get-order-by-warehouse-item.request.dto';
import { OrderServiceInterface } from '@components/order/interface/order.service.interface';
import { GetByItemIdRequestDto } from '@components/purchased-order/dto/request/get-by-item-id.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { PurchasedOrderResponseDto } from '../dto/response/purchased-order-response.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';

export interface PurchasedOrderServiceInterface extends OrderServiceInterface {
  checkItemHasExistOnPurchaseOrder(
    request: GetByItemIdRequestDto,
  ): Promise<any>;
  getPoByWarehouse(request: GetOrderByWarehouseItemRequestDto): Promise<any>;
  getPurchasedOrderByMOId(
    manufacturingOrderId: number,
  ): Promise<ResponsePayload<PurchasedOrderResponseDto | any>>;
  getMoExportLots(id: number): Promise<ResponsePayload<any>>;
  getPurchasedOrderListHaveNotPoimp(
    purchasedOrderImportIds: any[],
  ): Promise<ResponsePayload<any>>;
  confirmMultiple(request: DeleteMultipleDto): Promise<any>
  rejectMultiple(request: DeleteMultipleDto): Promise<any>
  deleteMultiple(request: DeleteMultipleDto): Promise<any>
}
