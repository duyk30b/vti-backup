import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { PurchasedOrderWarehouseLotEntity } from '@entities/purchased-order/purchased-order-warehouse-lot.entity';

export interface PurchasedOrderWarehouseLotRepositoryInterface
  extends BaseInterfaceRepository<PurchasedOrderWarehouseLotEntity> {}
