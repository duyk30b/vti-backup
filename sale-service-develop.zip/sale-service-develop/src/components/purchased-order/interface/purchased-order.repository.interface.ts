import { OrderRepositoryInterface } from '@components/order/interface/order.repository.interface';
import { PurchasedOrder } from '@entities/purchased-order/purchased-order.entity';

export interface PurchasedOrderRepositoryInterface
  extends OrderRepositoryInterface<PurchasedOrder> {
  getPurchasedOrderByMOId(manufacturingOrderId: number): Promise<any>;
  getPurchasedOrderInProgress(condition: any): Promise<any>;
  getMoExportLots(id?: number): Promise<any>;
  getPoHaveNotPoimp(poimpIds: any[]): Promise<any>;
  checkComplete(id: number): Promise<any>;
}
