export class UpdateMoneyForVendorEvent {
  constructor({ vendorId, id }) {
    this.vendorId = vendorId;
    this.id = id;
  }
  vendorId: number;
  id: number;
}
