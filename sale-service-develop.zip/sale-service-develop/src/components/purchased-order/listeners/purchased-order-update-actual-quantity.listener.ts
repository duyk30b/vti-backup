import { OrderTypeEnum } from './../../../constant/order.constant';
import { OnEvent } from '@nestjs/event-emitter';
import { OrderUpdateActualQuantityListener } from '@components/order/listeners/order-update-actual-quantity.listener';
import { PurchasedOrderRepositoryInterface } from '../interface/purchased-order.repository.interface';
import { Inject, Injectable } from '@nestjs/common';
import { OrderUpdateActualQuantityEvent } from '@components/order/events/order-update-actual-quantity.event';
import { PurchasedOrderImportRepositoryInterface } from '@components/purchased-order-import/interface/purchased-order-import.repository.interface';

@Injectable()
export class PurchasedOrderUpdateActualQuantityListener extends OrderUpdateActualQuantityListener {
  constructor(
    @Inject('PurchasedOrderRepositoryInterface')
    private readonly purchasedOrderRepository: PurchasedOrderRepositoryInterface,

    @Inject('PurchasedOrderImportRepositoryInterface')
    private readonly purchasedOrderImportRepository: PurchasedOrderImportRepositoryInterface,
  ) {
    super();
  }

  @OnEvent('order.updateActualQuantity')
  async handleOrderUpdateActualQuantityEvent(
    event: OrderUpdateActualQuantityEvent,
  ) {
    const { id, orderType } = event;
    let order;

    if (orderType === OrderTypeEnum.PO) {
      const purchasedOrderImport = await this.purchasedOrderImportRepository.findOneById(
        id,
      );
      if (purchasedOrderImport) {
        order = await this.purchasedOrderRepository.findOneById(
          purchasedOrderImport.purchasedOrderId,
        );
      }
    }
    return await this.checkAndUpdateInProgessOrderStatus(order);
  }

  public async updateInProgessOrderStatus(order) {
    return await this.purchasedOrderRepository.create(order);
  }
}
