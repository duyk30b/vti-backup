import { VendorRepositoryInterface } from '@components/vendor/interface/vendor.repository.interface';
import { VendorEntity } from '@entities/vendor/vendor.entity';
import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { InjectDataSource } from '@nestjs/typeorm';
import { plus } from '@utils/common';
import { DataSource } from 'typeorm';
import { PurchasedOrderDetailRepositoryInterface } from '../interface/purchased-order-detail.repository.interface';
import { PurchasedOrderRepositoryInterface } from '../interface/purchased-order.repository.interface';

@Injectable()
export class PurchasedOrderUpdateMoneyVendorListener {
  constructor(
    @Inject('PurchasedOrderRepositoryInterface')
    private readonly purchasedOrderRepository: PurchasedOrderRepositoryInterface,

    @Inject('PurchasedOrderDetailRepositoryInterface')
    private readonly purchasedOrderDetailRepository: PurchasedOrderDetailRepositoryInterface,

    @Inject('VendorRepositoryInterface')
    private readonly vendorRepository: VendorRepositoryInterface,

    @InjectDataSource()
    private readonly connection: DataSource,
  ) {}

  @OnEvent('order.updateMoneyVendor')
  async handleOrderUpdateActualQuantityEvent(event: any) {
    const { id, vendorId } = event;
    const vendor = await this.vendorRepository.findOneWithRelations({
      where: {
        id: vendorId,
      },
    });
    const purchasedOrderDetails =
      await this.purchasedOrderDetailRepository.findWithRelations({
        where: {
          purchasedOrderId: id,
        },
      });

    let totalMoney = 0;

    purchasedOrderDetails.forEach((purchasedOrderDetail) => {
      totalMoney = plus(
        totalMoney,
        +purchasedOrderDetail.price * +purchasedOrderDetail.quantity,
      );
    });

    vendor.totalMoney = plus(vendor.totalMoney, totalMoney);

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(VendorEntity, vendor);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
    } finally {
      await queryRunner.release();
    }

    return;
  }
}
