import { OrderUpdateConfirmedQuantityEvent } from '@components/order/events/order-update-confirmed-quantity.event';
import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { PurchasedOrderRepositoryInterface } from '../interface/purchased-order.repository.interface';
import { OrderUpdateConfirmedQuantityListener } from '@components/order/listeners/order-update-confimed-quantity.listener';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { PurchasedOrderImportRepositoryInterface } from '@components/purchased-order-import/interface/purchased-order-import.repository.interface';

@Injectable()
export class PurchasedOrderUpdateConfirmedQuantityListener extends OrderUpdateConfirmedQuantityListener {
  constructor(
    @Inject('PurchasedOrderRepositoryInterface')
    private readonly purchasedOrderRepository: PurchasedOrderRepositoryInterface,

    @Inject('PurchasedOrderImportRepositoryInterface')
    private readonly purchasedOrderImportRepository: PurchasedOrderImportRepositoryInterface,

    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,
  ) {
    super();
  }

  @OnEvent('order.updateConfirmedQuantity')
  async handleOrderCreatedEvent(event: OrderUpdateConfirmedQuantityEvent) {
    const { id, orderType } = event;
    let order;

    return;
  }
}
