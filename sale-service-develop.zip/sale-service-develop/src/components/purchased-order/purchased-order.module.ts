import { ItemModule } from '@components/item/item.module';
import { ItemService } from '@components/item/item.service';
import { PurchasedOrderController } from '@components/purchased-order/purchased-order.controller';
import { PurchasedOrderService } from '@components/purchased-order/purchased-order.service';
import { QmsxModule } from '@components/qmx/qmx.module';
import { QualityControlService } from '@components/qmx/quality-control.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { VendorModule } from '@components/vendor/vendor.module';
import { PurchasedOrderImportEntity } from '@entities/purchased-order-import/purchased-order-import.entity';
import { PurchasedOrderDetail } from '@entities/purchased-order/purchased-order-detail.entity';
import { PurchasedOrderWarehouseDetail } from '@entities/purchased-order/purchased-order-warehouse-detail.entity';
import { PurchasedOrderWarehouseLotEntity } from '@entities/purchased-order/purchased-order-warehouse-lot.entity';
import { PurchasedOrder } from '@entities/purchased-order/purchased-order.entity';
import { VendorEntity } from '@entities/vendor/vendor.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PurchasedOrderImportRepository } from '@repositories/purchased-order-import/purchased-order-import.repository';
import { PurchasedOrderDetailRepository } from '@repositories/purchased-order/purchased-order-detail.repository';
import { PurchasedOrderWarehouseDetailRepository } from '@repositories/purchased-order/purchased-order-warehouse-detail.repository';
import { PurchasedOrderWarehouseLotRepository } from '@repositories/purchased-order/purchased-order-warehouse-lot.repository';
import { PurchasedOrderRepository } from '@repositories/purchased-order/purchased-order.repository';
import { VendorRepository } from '@repositories/vendor/vendor.repository';
import { WarehouseModule } from './../warehouse/warehouse.module';
import { WarehouseService } from './../warehouse/warehouse.service';
import { PurchasedOrderItemDetailsImport } from './import/purchased-order-item-detail.import.helper';
import { PurchasedOrdersImport } from './import/purchased-order.import.helper';
import { PurchasedOrderUpdateActualQuantityListener } from './listeners/purchased-order-update-actual-quantity.listener';
import { PurchasedOrderUpdateConfirmedQuantityListener } from './listeners/purchased-order-update-confimed-quantity.listener';
import { PurchasedOrderUpdateMoneyVendorListener } from './listeners/purchased-order-update-money.listener';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      PurchasedOrder,
      PurchasedOrderDetail,
      PurchasedOrderWarehouseDetail,
      VendorEntity,
      PurchasedOrderWarehouseLotEntity,
      PurchasedOrderImportEntity,
    ]),
    ItemModule,
    WarehouseModule,
    VendorModule,
    UserModule,
    QmsxModule,
  ],
  providers: [
    {
      provide: 'PurchasedOrderRepositoryInterface',
      useClass: PurchasedOrderRepository,
    },
    {
      provide: 'PurchasedOrderImportRepositoryInterface',
      useClass: PurchasedOrderImportRepository,
    },
    {
      provide: 'PurchasedOrderWarehouseLotRepositoryInterface',
      useClass: PurchasedOrderWarehouseLotRepository,
    },
    {
      provide: 'PurchasedOrderDetailRepositoryInterface',
      useClass: PurchasedOrderDetailRepository,
    },
    {
      provide: 'PurchasedOrderWarehouseDetailRepositoryInterface',
      useClass: PurchasedOrderWarehouseDetailRepository,
    },
    {
      provide: 'VendorRepositoryInterface',
      useClass: VendorRepository,
    },
    {
      provide: 'PurchasedOrderServiceInterface',
      useClass: PurchasedOrderService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'QualityServiceInterface',
      useClass: QualityControlService,
    },
    {
      provide: 'PurchasedOrdersImport',
      useClass: PurchasedOrdersImport,
    },
    {
      provide: 'PurchasedOrderItemDetailsImport',
      useClass: PurchasedOrderItemDetailsImport,
    },
    PurchasedOrderUpdateActualQuantityListener,
    PurchasedOrderUpdateConfirmedQuantityListener,
    PurchasedOrderUpdateMoneyVendorListener,
  ],
  exports: [
    {
      provide: 'PurchasedOrderRepositoryInterface',
      useClass: PurchasedOrderRepository,
    },
    {
      provide: 'PurchasedOrderImportRepositoryInterface',
      useClass: PurchasedOrderImportRepository,
    },
    {
      provide: 'PurchasedOrderWarehouseLotRepositoryInterface',
      useClass: PurchasedOrderWarehouseLotRepository,
    },
    {
      provide: 'PurchasedOrderDetailRepositoryInterface',
      useClass: PurchasedOrderDetailRepository,
    },
    {
      provide: 'PurchasedOrderWarehouseDetailRepositoryInterface',
      useClass: PurchasedOrderWarehouseDetailRepository,
    },
    {
      provide: 'VendorRepositoryInterface',
      useClass: VendorRepository,
    },
    {
      provide: 'PurchasedOrderServiceInterface',
      useClass: PurchasedOrderService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'QualityServiceInterface',
      useClass: QualityControlService,
    },
    {
      provide: 'PurchasedOrdersImport',
      useClass: PurchasedOrdersImport,
    },
    {
      provide: 'PurchasedOrderItemDetailsImport',
      useClass: PurchasedOrderItemDetailsImport,
    },
    PurchasedOrderUpdateActualQuantityListener,
    PurchasedOrderUpdateConfirmedQuantityListener,
    PurchasedOrderUpdateMoneyVendorListener,
  ],
  controllers: [PurchasedOrderController],
})
export class PurchasedOrderModule {}
