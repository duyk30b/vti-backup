import { ConfigService } from '@config/config.service';
import { APIPrefix } from '@constant/common';
import { HttpClientService } from '@core/components/http-client/http-client.service';
import { Injectable } from '@nestjs/common';
import { PushNotificationRequestDto } from './dto/notification.request.dto';
import { NotificationServiceInterface } from './interface/notification.service.interface';

@Injectable()
export class NotificationService implements NotificationServiceInterface {
  constructor(
    private configService: ConfigService,
    private readonly httpClientService: HttpClientService,
  ) {}
  protected readonly urlConfig = this.configService.get('notificationService');
  protected readonly url = `http://${
    this.urlConfig.options.host + ':' + this.urlConfig.options.port
  }`;

  async pushNotification(request: PushNotificationRequestDto): Promise<any> {
    return await this.httpClientService.post(
      `${this.url}/${APIPrefix.Version}/notifications`,
      request,
    );
  }
}