export enum ActionNotificationEnum {
  WAREHOUSE_YARD = 'GO TO WAREHOURSE',
}

export enum TypeNotificationEnum {
  MAIL = 'MAIL',
  WEB = 'WEB',
  APP = 'APP',
}

export enum TypeNotificationUserRenderAction {
  ACTION_CONFIRM_VIEW_REJECT = '1',
  ACTION_VIEW_CONFIRM = '2',
  ACTION_VIEW = '3',
}

export enum MesModuleEnum {
  WMSX = '[WMSx]',
}
