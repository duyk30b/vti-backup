import { ConfigService } from '@config/config.service';
import { NatsClientModule } from '@core/transporter/nats-transporter/nats-client.module';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { NotificationService } from './notification.service';

@Global()
@Module({
  imports: [ConfigModule, NatsClientModule],
  exports: [
    {
      provide: 'NotificationServiceInterface',
      useClass: NotificationService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'NotificationServiceInterface',
      useClass: NotificationService,
    },
  ],
  controllers: [],
})
export class NotificationModule {}
