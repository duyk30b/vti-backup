import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ClientProxyFactory } from '@nestjs/microservices';
import { ConfigService } from '@config/config.service';
import { NotificationService } from './notification.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    'NOTIFICATION_SERVICE_CLIENT',
    {
      provide: 'NotificationServiceInterface',
      useClass: NotificationService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'NOTIFICATION_SERVICE_CLIENT',
      useFactory: (configService: ConfigService) => {
        const notificationServiceOptions = configService.get(
          'notificationService',
        );
        return ClientProxyFactory.create(notificationServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'NotificationServiceInterface',
      useClass: NotificationService,
    },
  ],
  controllers: [],
})
export class NotificationModule {}