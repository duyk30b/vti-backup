import { OrderDetailRepositoryInterface } from '@components/order/interface/order-detail.repository.interface';
import { ProductionOrderDetail } from '@entities/production-order/production-order-detail.entity';

export interface ProductionOrderDetailRepositoryInterface
  extends OrderDetailRepositoryInterface<ProductionOrderDetail> {
  getTotalQuantityItemProductionOrdersByCondition(condition: any): Promise<any>;
}
