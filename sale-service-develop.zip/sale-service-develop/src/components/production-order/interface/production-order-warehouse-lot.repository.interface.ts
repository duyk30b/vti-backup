import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ProductionOrderWarehouseLotEntity } from '@entities/production-order/production-order-warehouse-lot.entity';

export interface ProductionOrderWarehouseLotRepositoryInterface
  extends BaseInterfaceRepository<ProductionOrderWarehouseLotEntity> {
  getMoItemLots(moId: number, warehouseId: number, itemIds: number[]);
  getLotsByItems(
    itemIds: number[],
    lotNumbers: string[],
    warehouseIds: number[],
    orderId: number,
  ): Promise<any>;
  getListLotNumber(
    itemIds?: number[],
    productionOrderId?: number,
    type?: number,
  ): Promise<any>;
}
