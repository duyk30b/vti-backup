import { OrderServiceInterface } from '@components/order/interface/order.service.interface';
import { ResponsePayload } from '@utils/response-payload';
import { GetAllPrORequest } from '../dto/request/get-all-pro.request.dto';
import { GetByItemIdRequestDto } from '@components/purchased-order/dto/request/get-by-item-id.request.dto';
import { GetOrderByWarehouseItemRequestDto } from '@components/order/dto/request/get-order-by-warehouse-item.request.dto';
import { UpdateProductionOrderDetailQcQuantityRequestDto } from '@components/production-order/dto/request/update-qc-quantity-production-order-request.dto';
import { CreateProductionOrderDraftRequestDto } from '../dto/request/create-production-order-draft-request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';

export interface ProductionOrderServiceInterface extends OrderServiceInterface {
  getProductionOrders(request: GetAllPrORequest): Promise<ResponsePayload<any>>;
  checkItemHasExistOnProductionOrder(
    request: GetByItemIdRequestDto,
  ): Promise<any>;
  getProByWarehouse(request: GetOrderByWarehouseItemRequestDto): Promise<any>;
  updateProductionOrderDetailQcQuantity(
    request: UpdateProductionOrderDetailQcQuantityRequestDto,
  ): Promise<ResponsePayload<any>>;
  getTotalQuantityItemProductionOrdersByCondition(condition: any): Promise<any>;
  createPrODraft(request: CreateProductionOrderDraftRequestDto): Promise<any>;
  confirmMultiple(request: DeleteMultipleDto): Promise<any>
  rejectMultiple(request: DeleteMultipleDto): Promise<any>
  deleteMultiple(request: DeleteMultipleDto): Promise<any>
}
