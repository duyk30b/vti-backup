import { OrderRepositoryInterface } from '@components/order/interface/order.repository.interface';
import { ProductionOrder } from '@entities/production-order/production-order.entity';

export interface ProductionOrderRepositoryInterface
  extends OrderRepositoryInterface<ProductionOrder> {
  getProductionOrderInProgress(condition: any): Promise<any>;
}
