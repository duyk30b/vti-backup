import { OrderWarehouseDetailRepositoryInterface } from '@components/order/interface/order-warehouse-detail.repository.interface';
import { ProductionOrderWarehouseDetail } from '@entities/production-order/production-order-warehouse-detail.entity';

export interface ProductionOrderWarehouseDetailRepositoryInterface
  extends OrderWarehouseDetailRepositoryInterface<ProductionOrderWarehouseDetail> {
  getMosItemLots(moIds: number[], warehouseId: number, itemIds: number[]);
  getListItemIdByQcStageId(type: any): Promise<any>;
}
