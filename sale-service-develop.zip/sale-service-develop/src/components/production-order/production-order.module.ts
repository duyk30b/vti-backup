import { ItemModule } from '@components/item/item.module';
import { ItemService } from '@components/item/item.service';
import { ProductionOrderController } from '@components/production-order/production-order.controller';
import { ProductionOrderService } from '@components/production-order/production-order.service';
import { QmsxModule } from '@components/qmx/qmx.module';
import { QualityControlService } from '@components/qmx/quality-control.service';
import { UserService } from '@components/user/user.service';
import { WarehouseCronService } from '@components/warehouse/warehouse.cron.service';
import { ProductionOrderDetail } from '@entities/production-order/production-order-detail.entity';
import { ProductionOrderWarehouseDetail } from '@entities/production-order/production-order-warehouse-detail.entity';
import { ProductionOrderWarehouseLotEntity } from '@entities/production-order/production-order-warehouse-lot.entity';
import { ProductionOrder } from '@entities/production-order/production-order.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProductionOrderDetailRepository } from '@repositories/production-order/production-order-detail.repository';
import { ProductionOrderWarehouseDetailRepository } from '@repositories/production-order/production-order-warehouse-detail.repository';
import { ProductionOrderWarehouseLotRepository } from '@repositories/production-order/production-order-warehouse-lot.repository';
import { ProductionOrderRepository } from '@repositories/production-order/production-order.repository';
import { PurchasedOrderImportWarehouseDetailRepository } from '@repositories/purchased-order-import/purchased-order-import-warehouse-detail.repository';
import { PurchasedOrderImportWarehouseDetailEntity } from '../../entities/purchased-order-import/purchased-order-import-warehouse-detail.entity';
import { UserModule } from './../user/user.module';
import { WarehouseModule } from './../warehouse/warehouse.module';
import { WarehouseService } from './../warehouse/warehouse.service';
import { ProductionOrderUpdateActualQuantityListener } from './listeners/production-order-update-actual-quantity.listener';
import { ProductionOrderUpdateConfirmedQuantityListener } from './listeners/production-order-update-confimed-quantity.listener';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      ProductionOrder,
      ProductionOrderDetail,
      ProductionOrderWarehouseDetail,
      ProductionOrderWarehouseLotEntity,
      PurchasedOrderImportWarehouseDetailEntity,
    ]),
    ItemModule,
    WarehouseModule,
    UserModule,
    QmsxModule,
  ],
  providers: [
    {
      provide: 'ProductionOrderRepositoryInterface',
      useClass: ProductionOrderRepository,
    },
    {
      provide: 'ProductionOrderDetailRepositoryInterface',
      useClass: ProductionOrderDetailRepository,
    },
    {
      provide: 'ProductionOrderWarehouseDetailRepositoryInterface',
      useClass: ProductionOrderWarehouseDetailRepository,
    },
    {
      provide: 'PurchasedOrderImportWarehouseDetailRepositoryInterface',
      useClass: PurchasedOrderImportWarehouseDetailRepository,
    },
    {
      provide: 'ProductionOrderWarehouseLotRepositoryInterface',
      useClass: ProductionOrderWarehouseLotRepository,
    },
    {
      provide: 'ProductionOrderServiceInterface',
      useClass: ProductionOrderService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'WarehouseCronServiceInterface',
      useClass: WarehouseCronService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'QualityControlServiceInterface',
      useClass: QualityControlService,
    },
    ProductionOrderUpdateActualQuantityListener,
    ProductionOrderUpdateConfirmedQuantityListener,
  ],
  controllers: [ProductionOrderController],
})
export class ProductionOrderModule {}
