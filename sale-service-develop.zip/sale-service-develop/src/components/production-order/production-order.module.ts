import { UserModule } from './../user/user.module';
import { WarehouseService } from './../warehouse/warehouse.service';
import { WarehouseModule } from './../warehouse/warehouse.module';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProductionOrderController } from '@components/production-order/production-order.controller';
import { ProductionOrderService } from '@components/production-order/production-order.service';
import { ProductionOrder } from '@entities/production-order/production-order.entity';
import { ProductionOrderRepository } from '@repositories/production-order/production-order.repository';
import { ProductionOrderDetailRepository } from '@repositories/production-order/production-order-detail.repository';
import { ProductionOrderDetail } from '@entities/production-order/production-order-detail.entity';
import { ProductionOrderWarehouseDetailRepository } from '@repositories/production-order/production-order-warehouse-detail.repository';
import { ProductionOrderWarehouseDetail } from '@entities/production-order/production-order-warehouse-detail.entity';
import { ItemService } from '@components/item/item.service';
import { ItemModule } from '@components/item/item.module';
import { UserService } from '@components/user/user.service';
import { ProductionOrderUpdateActualQuantityListener } from './listeners/production-order-update-actual-quantity.listener';
import { ProductionOrderUpdateConfirmedQuantityListener } from './listeners/production-order-update-confimed-quantity.listener';
import { QualityControlService } from '@components/qmx/quality-control.service';
import { QmsxModule } from '@components/qmx/qmx.module';
import { ProductionOrderWarehouseLotEntity } from '@entities/production-order/production-order-warehouse-lot.entity';
import { ProductionOrderWarehouseLotRepository } from '@repositories/production-order/production-order-warehouse-lot.repository';
import { PurchasedOrderImportWarehouseDetailEntity } from '../../entities/purchased-order-import/purchased-order-import-warehouse-detail.entity';
import { PurchasedOrderImportWarehouseDetailRepository } from '@repositories/purchased-order-import/purchased-order-import-warehouse-detail.repository';
import { WarehouseCronService } from '@components/warehouse/warehouse.cron.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      ProductionOrder,
      ProductionOrderDetail,
      ProductionOrderWarehouseDetail,
      ProductionOrderWarehouseLotEntity,
      PurchasedOrderImportWarehouseDetailEntity,
    ]),
    ItemModule,
    WarehouseModule,
    UserModule,
    QmsxModule,
  ],
  providers: [
    {
      provide: 'ProductionOrderRepositoryInterface',
      useClass: ProductionOrderRepository,
    },
    {
      provide: 'ProductionOrderDetailRepositoryInterface',
      useClass: ProductionOrderDetailRepository,
    },
    {
      provide: 'ProductionOrderWarehouseDetailRepositoryInterface',
      useClass: ProductionOrderWarehouseDetailRepository,
    },
    {
      provide: 'PurchasedOrderImportWarehouseDetailRepositoryInterface',
      useClass: PurchasedOrderImportWarehouseDetailRepository,
    },
    {
      provide: 'ProductionOrderWarehouseLotRepositoryInterface',
      useClass: ProductionOrderWarehouseLotRepository,
    },
    {
      provide: 'ProductionOrderServiceInterface',
      useClass: ProductionOrderService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'WarehouseCronServiceInterface',
      useClass: WarehouseCronService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'QualityControlServiceInterface',
      useClass: QualityControlService,
    },
    ProductionOrderUpdateActualQuantityListener,
    ProductionOrderUpdateConfirmedQuantityListener,
  ],
  controllers: [ProductionOrderController],
})
export class ProductionOrderModule {}
