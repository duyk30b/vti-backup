import { OnEvent } from '@nestjs/event-emitter';
import { OrderUpdateActualQuantityListener } from '@components/order/listeners/order-update-actual-quantity.listener';
import { ProductionOrderRepositoryInterface } from '../../production-order/interface/production-order.repository.interface';
import { Inject, Injectable } from '@nestjs/common';
import { OrderUpdateActualQuantityEvent } from '@components/order/events/order-update-actual-quantity.event';
import { OrderTypeEnum } from '@constant/order.constant';

@Injectable()
export class ProductionOrderUpdateActualQuantityListener extends OrderUpdateActualQuantityListener {
  constructor(
    @Inject('ProductionOrderRepositoryInterface')
    protected readonly productionOrderRepository: ProductionOrderRepositoryInterface,
  ) {
    super();
  }

  @OnEvent('order.updateActualQuantity')
  async handleOrderCreatedEvent(event: OrderUpdateActualQuantityEvent) {
    const { id, orderType } = event;
    let order;
    if (orderType === OrderTypeEnum.PRO) {
      order = await this.productionOrderRepository.findOneById(id);
    }

    return this.checkAndUpdateInProgessOrderStatus(order);
  }

  public async updateInProgessOrderStatus(order) {
    return await this.productionOrderRepository.create(order);
  }
}
