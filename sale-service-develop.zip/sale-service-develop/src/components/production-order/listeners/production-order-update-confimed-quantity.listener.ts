import { ProductionOrderRepositoryInterface } from './../interface/production-order.repository.interface';
import { OrderTypeEnum } from '../../../constant/order.constant';
import { OrderUpdateConfirmedQuantityEvent } from '@components/order/events/order-update-confirmed-quantity.event';
import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { OrderUpdateConfirmedQuantityListener } from '@components/order/listeners/order-update-confimed-quantity.listener';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { UpdateStockStatusOrderRequest } from '@components/warehouse/dto/request/update-stock-status-order.request';
import { OrderStatusEnum } from '@constant/common';

@Injectable()
export class ProductionOrderUpdateConfirmedQuantityListener extends OrderUpdateConfirmedQuantityListener {
  constructor(
    @Inject('ProductionOrderRepositoryInterface')
    private readonly productionOrderRepository: ProductionOrderRepositoryInterface,

    @Inject('WarehouseCronServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,
  ) {
    super();
  }

  @OnEvent('order.updateConfirmedQuantity')
  async handleOrderCreatedEvent(event: OrderUpdateConfirmedQuantityEvent) {
    const { id, orderType } = event;
    let order;
    if (orderType === OrderTypeEnum.PRO) {
      order = await this.productionOrderRepository.checkReadyToComplete(id);
    }
    if (order) {
      const newOrder = await this.productionOrderRepository.setCompleted(id);

      const updateStockStatusOrder = new UpdateStockStatusOrderRequest();
      updateStockStatusOrder.id = newOrder.id;
      updateStockStatusOrder.completedAt = newOrder.completedAt;
      updateStockStatusOrder.status = OrderStatusEnum.Completed;
      updateStockStatusOrder.type = OrderTypeEnum.PRO;

      await this.warehouseService.updateStatusWarehouseStockMovement(
        updateStockStatusOrder,
      );
    }

    return;
  }
}
