import {
  GetOrderDetailByWarehouseQueryDto,
  GetOrderDetailByWarehouseRequestDto,
} from './../order/dto/request/get-order-detail-by-warehouse.request.dto';
import {
  GetOrderDetailQueryRequestDto,
  GetOrderDetailRequestDto,
} from './../order/dto/request/get-order-detail.request.dto';
import { GetProductionOrderListRequest } from './dto/request/get-production-order-list-request.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Req,
} from '@nestjs/common';
import { ProductionOrderServiceInterface } from '@components/production-order/interface/production-order.service.interface';
import { MessagePattern } from '@nestjs/microservices';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { GetOrderRequestDto } from '@components/order/dto/request/get-order.request.dto';
import { isEmpty } from 'lodash';
import { UpdateOrderDetailActualQuantityRequestDto } from '@components/order/dto/request/update-actual-quantity-order-detail.request.dto';
import { UpdateOrderDetailConfirmQuantityRequestDto } from '@components/order/dto/request/update-confirm-quantity-order-detail.request.dto';
import { CreateProductionOrderRequestDto } from './dto/request/create-production-order-request.dto';
import { UpdateProductionOrderBodyDto } from './dto/request/update-production-order-request.dto';
import { SetOrderStatusBodyDto } from '@components/order/dto/request/set-order-status-request.dto';
import { GetAllPrORequest } from './dto/request/get-all-pro.request.dto';
import { DeleteOrderRequestDto } from '@components/order/dto/request/delete-order.request.dto';
import { GetListOrderByIdsRequestDto } from '@components/order/dto/request/get-list-order-by-ids.request.dto';
import { GetByItemIdRequestDto } from '@components/purchased-order/dto/request/get-by-item-id.request.dto';
import {
  GetOrderWarehouseQueryRequest,
  GetOrderWarehouseRequest,
} from '@components/order/dto/request/get-order-warehouse.request.dto';
import { GetOrderByWarehouseItemRequestDto } from '@components/order/dto/request/get-order-by-warehouse-item.request.dto';
import {
  UpdateProductionOrderDetailQcQuantityBodyRequestDto,
  UpdateProductionOrderDetailQcQuantityRequestDto,
} from './dto/request/update-qc-quantity-production-order-request.dto';
import { CreateProductionOrderDraftRequestDto } from './dto/request/create-production-order-draft-request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CONFIRM_PRODUCTION_ORDER_PERMISSION,
  CREATE_PRODUCTION_ORDER_PERMISSION,
  DELETE_PRODUCTION_ORDER_PERMISSION,
  DETAIL_PRODUCTION_ORDER_PERMISSION,
  LIST_PRODUCTION_ORDER_PERMISSION,
  REJECT_PRODUCTION_ORDER_PERMISSION,
  UPDATE_PRODUCTION_ORDER_PERMISSION,
} from '@utils/permissions/production-order';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ApiOperation, ApiParam, ApiResponse } from '@nestjs/swagger';
import { ProductionOrderListResponse } from './dto/response/production-order-list-response.dto';
import { ProductionOrderResponseDto } from './dto/response/production-order-response.dto';
import { ProductionOrderWarehouseDetailResponseDto } from './dto/response/production-order-warehouse-detail-response.dto';
import { GetOrderListRequest } from '@components/order/dto/request/get-order-list.request.dto';

@Controller('production-orders')
export class ProductionOrderController {
  constructor(
    @Inject('ProductionOrderServiceInterface')
    private readonly productionOrderService: ProductionOrderServiceInterface,
  ) {}

  // @MessagePattern('ping')
  public async get(@Req() request): Promise<any> {
    return new ResponseBuilder('PURCHASED ORDER: PONG')
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  /**
   * Create new production order
   * @param request CreateProductionOrderRequestDto
   * @returns
   */
  // @MessagePattern('create_production_order_draft')
  public async createPrODraft(
    @Body() payload: CreateProductionOrderDraftRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.createPrODraft(request);
  }

  /**
   * Get data production order by id and warehouseId
   * @param request productionOrderService
   * @returns
   */
  // @MessagePattern('get_pro_warehouse_details')
  public async getProDetail(@Body() payload: GetOrderRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.productionOrderService.getWarehouseDetails(
      request.id,
      request.warehouseId,
      request.type,
    );
  }

  /**
   * Update actual quantity of production order detail
   * @param request productionOrderService
   * @returns
   */
  // @MessagePattern('update_pro_actual_quantity')
  public async updateActualQuantity(
    @Body() payload: UpdateOrderDetailActualQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.updateOrderDetailActualQuantity(
      request,
    );
  }

  // @MessagePattern('update_pro_confirm_quantity')
  public async updateConfirmQuantity(
    @Body() payload: UpdateOrderDetailConfirmQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.updateOrderDetailConfirmQuantity(
      request,
    );
  }

  /**
   * Get production order list
   * @param request GetProductionOrderListRequest
   * @returns
   */
  @PermissionCode(LIST_PRODUCTION_ORDER_PERMISSION.code)
  @Get('/list')
  @ApiOperation({
    tags: ['Sales', 'Production Order'],
    summary: 'Get List Production Order',
    description: 'Danh sách lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ProductionOrderListResponse,
  })
  // @MessagePattern('get_production_order_list')
  public async getList(
    @Query() payload: GetProductionOrderListRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.productionOrderService.getList(request);
  }

  @Get('/:id/warehouses/list')
  @ApiOperation({
    tags: ['Sales', 'Production Order', 'Warehouse'],
    summary: 'Get Production Order Warehouse List',
    description: 'Danh sách kho lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  // @MessagePattern('get_production_order_warehouses')
  public async getProductionOrderWarehouse(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: GetOrderWarehouseQueryRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.productionOrderService.getListOrderWarehouse(request);
  }

  /**
   * Create new production order
   * @param request CreateProductionOrderRequestDto
   * @returns
   */
  @PermissionCode(CREATE_PRODUCTION_ORDER_PERMISSION.code)
  @Post('/create')
  @ApiOperation({
    tags: ['Sales', 'Production Order'],
    summary: 'Create Production Order',
    description: 'Tạo lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ProductionOrderResponseDto,
  })
  // @MessagePattern('create_production_order')
  public async create(
    @Body() payload: CreateProductionOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.createdByUserId = request.userId;
    return await this.productionOrderService.create(request);
  }

  /**
   * Update production order
   * @param request UpdateProductionOrderRequestDto
   * @returns
   */
  @PermissionCode(UPDATE_PRODUCTION_ORDER_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Sales', 'Production Order'],
    summary: 'Create Production Order',
    description: 'Cập nhật lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: ProductionOrderResponseDto,
  })
  // @MessagePattern('update_production_order')
  public async update(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateProductionOrderBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    request.createdByUserId = request.userId;
    return await this.productionOrderService.update(request);
  }

  /**
   * Get production order detail
   * @param request GetProductionOrderListRequest
   * @returns
   */
  @PermissionCode(DETAIL_PRODUCTION_ORDER_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Sales', 'Production Order'],
    summary: 'Get Production Order Detail',
    description: 'Chi tiết lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ProductionOrderResponseDto,
  })
  // @MessagePattern('get_production_order_detail')
  public async getDetail(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: GetOrderDetailQueryRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.productionOrderService.getDetail(request);
  }

  /**
   * Get purchased order detail
   * @param request GetPurchasedOrderListRequest
   * @returns
   */
  @Get('/:id/warehouses/:warehouseId')
  @ApiOperation({
    tags: ['Sales', 'Production Order', 'Warehouse'],
    summary: 'Get Production Order Warehouse detail',
    description: 'Danh sách item lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ProductionOrderWarehouseDetailResponseDto,
  })
  // @MessagePattern('get_production_order_warehouse')
  public async getDetailByWarehouseId(
    @Param('id', new ParseIntPipe()) id,
    @Param('warehouseId', new ParseIntPipe()) warehouseId,
    @Query() payload: GetOrderDetailByWarehouseQueryDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    request.warehouseId = warehouseId;
    return await this.productionOrderService.getDetailByWarehouseId(request);
  }

  /**
   * Confirm production order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @PermissionCode(CONFIRM_PRODUCTION_ORDER_PERMISSION.code)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Sales', 'Production Order'],
    summary: 'Confirm Production Order',
    description: 'Confirm lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ProductionOrderResponseDto,
  })
  // @MessagePattern('confirm_production_order')
  public async confirm(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: SetOrderStatusBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    request.createdByUserId = request.userId;
    return await this.productionOrderService.confirm(request);
  }

  /**
   * Confirm production order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @PermissionCode(CONFIRM_PRODUCTION_ORDER_PERMISSION.code)
  @Put('/confirm/multiple')
  @ApiOperation({
    tags: ['Sales', 'Production Order'],
    summary: 'Confirm multiple Production Order',
    description: 'Confirm nhiều lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ProductionOrderResponseDto,
  })
  // @MessagePattern('confirm_production_order_multiple')
  public async confirmMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.confirmMultiple(request);
  }

  /**
   * Reject
   * @param payload
   * @returns
   */
  @PermissionCode(REJECT_PRODUCTION_ORDER_PERMISSION.code)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Sales', 'Production Order'],
    summary: 'Reject Production Order',
    description: 'Reject lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: ProductionOrderResponseDto,
  })
  // @MessagePattern('reject_production_order')
  public async reject(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: SetOrderStatusBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    request.createdByUserId = request.userId;
    return await this.productionOrderService.reject(request);
  }

  /**
   * Reject
   * @param payload
   * @returns
   */
  @PermissionCode(REJECT_PRODUCTION_ORDER_PERMISSION.code)
  @Put('/reject/multiple')
  @ApiOperation({
    tags: ['Sales', 'Production Order'],
    summary: 'Reject multiple Production Order',
    description: 'Reject nhiều lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: ProductionOrderResponseDto,
  })
  // @MessagePattern('reject_production_order_multiple')
  public async rejectMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.rejectMultiple(request);
  }

  /**
   * Approve production order
   * @param request SetOrderStatusRequestDto
   * @returns
   */
  @Put('/:id/approve')
  @ApiOperation({
    tags: ['Sales', 'Production Order'],
    summary: 'Approve Production Order',
    description: 'Approve lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: ProductionOrderResponseDto,
  })
  // @MessagePattern('approve_production_order')
  public async approve(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: SetOrderStatusBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.productionOrderService.approve(request);
  }

  @Get('/all')
  @ApiOperation({
    tags: ['Production', 'Production Order'],
    summary: 'Get List Production Order',
    description: 'Danh sách lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: null,
  })
  // @MessagePattern('get_production_orders')
  public async getPurchasedOrders(
    @Query() payload: GetAllPrORequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.getProductionOrders(request);
  }

  @PermissionCode(DELETE_PRODUCTION_ORDER_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Sales', 'Production Order'],
    summary: 'Remove Production Order',
    description: 'Xoá lệnh sản xuất ',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  // @MessagePattern('delete_production_order')
  public async delete(@Param() payload: DeleteOrderRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.productionOrderService.delete(request);
  }

  @PermissionCode(DELETE_PRODUCTION_ORDER_PERMISSION.code)
  @Delete('/multiple')
  @ApiOperation({
    tags: ['Sales', 'Production Order'],
    summary: 'Remove multiple Production Order',
    description: 'Xoá nhiều lệnh sản xuất ',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  // @MessagePattern('delete_production_order_multiple')
  public async deleteMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.productionOrderService.deleteMultiple(request);
  }

  // @MessagePattern('get_production_order_by_ids')
  public async getPurchasedOrderByIds(
    @Body() payload: GetListOrderByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.productionOrderService.getListByIds(request);
  }

  // @MessagePattern('check_item_has_exist_on_production_order')
  public async checkItemHasExistOnProductionOrder(
    @Body() payload: GetByItemIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.productionOrderService.checkItemHasExistOnProductionOrder(
      request,
    );
  }

  // @MessagePattern('get_pro_by_warehouse')
  public async getProByWarehouseItem(
    @Body() payload: GetOrderByWarehouseItemRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.productionOrderService.getProByWarehouse(request);
  }

  @Put(
    '/production-orders/:id/warehouses/:warehouseId/items/:itemId/quality-controls/quantities',
  )
  @ApiOperation({
    tags: ['Production', 'Production Order'],
    summary: 'Update qc quantity',
    description: 'Cập nhật số lượng Qc pass và reject',
  })
  @ApiParam({
    name: 'id',
    type: Number,
    example: 27,
    required: true,
    description: 'PrO id',
  })
  @ApiParam({
    name: 'warehouseId',
    type: Number,
    example: 17,
    required: true,
    description: 'warehouse id',
  })
  @ApiParam({
    name: 'itemId',
    type: Number,
    example: 156,
    required: true,
    description: 'item id',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  // @MessagePattern('update_pro_qc_quantity')
  public async updateQcQuantity(
    @Param('id', new ParseIntPipe()) productionOrderId,
    @Param('warehouseId', new ParseIntPipe()) warehouseId,
    @Param('itemId', new ParseIntPipe()) itemId,
    @Body() payload: UpdateProductionOrderDetailQcQuantityBodyRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.productionOrderId = productionOrderId;
    request.warehouseId = warehouseId;
    request.itemId = itemId;
    return await this.productionOrderService.updateProductionOrderDetailQcQuantity(
      request,
    );
  }

  // @MessagePattern('get_total_quantity_item_production_order_by_condition')
  public async getTotalQuantityItemProductionOrdersByCondition(
    request: any,
  ): Promise<any> {
    return await this.productionOrderService.getTotalQuantityItemProductionOrdersByCondition(
      request,
    );
  }

  // TO DO: remove after refactor done
  @MessagePattern('create_production_order_draft')
  public async createPrODraftTcp(
    @Body() payload: CreateProductionOrderDraftRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.createPrODraft(request);
  }

  @MessagePattern('get_pro_warehouse_details')
  public async getProDetailTcp(
    @Body() payload: GetOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.productionOrderService.getWarehouseDetails(
      request.id,
      request.warehouseId,
      request.type,
    );
  }

  @MessagePattern('update_pro_actual_quantity')
  public async updateActualQuantityTcp(
    @Body() payload: UpdateOrderDetailActualQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.updateOrderDetailActualQuantity(
      request,
    );
  }

  @MessagePattern('update_pro_confirm_quantity')
  public async updateConfirmQuantityTcp(
    @Body() payload: UpdateOrderDetailConfirmQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.updateOrderDetailConfirmQuantity(
      request,
    );
  }

  @MessagePattern('get_production_order_by_ids')
  public async getPurchasedOrderByIdsTcp(
    @Body() payload: GetListOrderByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.productionOrderService.getListByIds(request);
  }

  @MessagePattern('check_item_has_exist_on_production_order')
  public async checkItemHasExistOnProductionOrderTcp(
    @Body() payload: GetByItemIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.productionOrderService.checkItemHasExistOnProductionOrder(
      request,
    );
  }

  @MessagePattern('get_pro_by_warehouse')
  public async getProByWarehouseItemTcp(
    @Body() payload: GetOrderByWarehouseItemRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.productionOrderService.getProByWarehouse(request);
  }

  @MessagePattern('get_total_quantity_item_production_order_by_condition')
  public async getTotalQuantityItemProductionOrdersByConditionTcp(
    request: any,
  ): Promise<any> {
    return await this.productionOrderService.getTotalQuantityItemProductionOrdersByCondition(
      request,
    );
  }

  @PermissionCode(DETAIL_PRODUCTION_ORDER_PERMISSION.code)
  @MessagePattern('get_production_order_detail')
  public async getDetailTcp(
    @Body() payload: GetOrderDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.getDetail(request);
  }

  @MessagePattern('get_production_orders')
  public async getPurchasedOrdersTcp(
    @Body() payload: GetAllPrORequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.getProductionOrders(request);
  }

  @PermissionCode(LIST_PRODUCTION_ORDER_PERMISSION.code)
  @MessagePattern('get_production_order_list')
  public async getListTcp(@Body() payload: GetOrderListRequest): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.productionOrderService.getList(request);
  }

  @MessagePattern('get_production_order_warehouses')
  public async getProductionOrderWarehouseTcp(
    @Body() payload: GetOrderWarehouseRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.getListOrderWarehouse(request);
  }

  @MessagePattern('get_production_order_warehouse')
  public async getDetailByWarehouseIdTcp(
    @Body() payload: GetOrderDetailByWarehouseRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.getDetailByWarehouseId(request);
  }

  @MessagePattern('update_pro_qc_quantity')
  public async updateQcQuantityTcp(
    @Body() payload: UpdateProductionOrderDetailQcQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.updateProductionOrderDetailQcQuantity(
      request,
    );
  }
}
