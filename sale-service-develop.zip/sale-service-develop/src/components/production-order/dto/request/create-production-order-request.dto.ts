import { CreateOrderRequestDto } from '@components/order/dto/request/create-order-resquest.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsBoolean,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Min,
  ValidateNested,
} from 'class-validator';

class ItemRequest {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  quantity: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsBoolean()
  qcCheck: boolean;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  qcCriteriaId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  lotNumber: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  mfg: string;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  packageId: number;
}
export class CreateProductionOrderRequestDto extends CreateOrderRequestDto {
  @ApiProperty()
  @ArrayUnique<ItemRequest>()
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => ItemRequest)
  items: ItemRequest[];

  @ApiPropertyOptional()
  @IsInt()
  @IsNotEmpty()
  manufacturingOrderId: number;
}
