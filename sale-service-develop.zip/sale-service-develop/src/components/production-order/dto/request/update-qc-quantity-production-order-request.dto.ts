import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import {
  IsDateString,
  IsDecimal,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';

export class UpdateProductionOrderDetailQcQuantityBodyRequestDto extends BaseDto {
  @ApiProperty()
  @IsNumber()
  @Transform(({ value }) => Number(value))
  qcPassQuantity: number;

  @ApiProperty()
  @IsNumber()
  @Transform(({ value }) => Number(value))
  qcRejectQuantity: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @MaxLength(20)
  lotNumber: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  mfg: Date;
}

export class UpdateProductionOrderDetailQcQuantityRequestDto extends UpdateProductionOrderDetailQcQuantityBodyRequestDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  productionOrderId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  warehouseId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  itemId: number;
}
