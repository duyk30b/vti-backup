import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CreateProductionOrderRequestDto } from './create-production-order-request.dto';

export class UpdateProductionOrderBodyDto extends CreateProductionOrderRequestDto {}

export class UpdateProductionOrderDto extends UpdateProductionOrderBodyDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  id: number;
}
