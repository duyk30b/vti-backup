import { GetOrderListRequest } from '@components/order/dto/request/get-order-list.request.dto';

export class GetProductionOrderListRequest extends GetOrderListRequest {}
