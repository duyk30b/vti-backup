import { WarehouseResponseDto } from './../../../warehouse/dto/response/warehouse.dto.response';
import { ItemResponseDto } from './../../../item/dto/response/item.dto.response';
import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { OrderResponseDto } from '@components/order/dto/response/order-response.dto';

class ProductionOrderDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  productionOrderId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  confirmQuantity: number;

  @ApiProperty({ type: ItemResponseDto })
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;
}

class ProductionOrderWarehouseDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  productionOrderId: number;

  @ApiProperty()
  @Expose()
  productionOrderDetailId: number;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  confirmQuantity: number;

  @ApiProperty()
  @Expose()
  qcRejectQuantity: number;

  @ApiProperty()
  @Expose()
  qcPassQuantity: number;

  @ApiProperty()
  @Expose()
  errorQuantity: number;

  @ApiProperty()
  @Expose()
  qcCheck: number;

  @ApiProperty()
  @Expose()
  qcCriteriaId: number;

  @ApiProperty({ type: ItemResponseDto })
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;

  @ApiProperty({ type: WarehouseResponseDto })
  @Type(() => WarehouseResponseDto)
  @Expose()
  warehouse: WarehouseResponseDto;
}

export class ManufacturingOrder {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  factoryId: number;

  @ApiProperty()
  @Expose()
  saleOrderId: number;

  @ApiProperty()
  @Expose()
  planFrom: Date;

  @ApiProperty()
  @Expose()
  planTo: Date;

  @ApiProperty()
  @Expose()
  status: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;
}

class PackageResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;
}

class ProductionOrderWarehouseLot {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  productionOrderId: number;

  @ApiProperty()
  @Expose()
  productionOrderWarehouseId: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  mfg: string;

  @ApiProperty({ type: ItemResponseDto })
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  packageId: number;

  @ApiProperty({ type: PackageResponseDto })
  @Type(() => PackageResponseDto)
  @Expose()
  package: PackageResponseDto;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty({ type: WarehouseResponseDto })
  @Type(() => WarehouseResponseDto)
  @Expose()
  warehouse: WarehouseResponseDto;
}

export class ProductionOrderResponseDto extends OrderResponseDto {
  @ApiProperty({ type: ProductionOrderDetail })
  @Expose()
  @Type(() => ProductionOrderDetail)
  productionOrderDetails: ProductionOrderDetail[];

  @ApiProperty({ type: ProductionOrderWarehouseDetail })
  @Expose()
  @Type(() => ProductionOrderWarehouseDetail)
  productionOrderWarehouseDetails: ProductionOrderWarehouseDetail[];

  @ApiProperty({ type: ManufacturingOrder })
  @Expose()
  @Type(() => ManufacturingOrder)
  manufacturingOrder: ManufacturingOrder;

  @ApiProperty({ type: ProductionOrderWarehouseLot })
  @Expose()
  @Type(() => ProductionOrderWarehouseLot)
  productionOrderWarehouseLots: ProductionOrderWarehouseLot[];
}
