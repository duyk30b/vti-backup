import { Expose, Type } from 'class-transformer';

export class GetAllPrOResponse {
  @Expose()
  id: number;

  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  createdAt: Date;

  @Expose()
  type: string;

  @Expose({ name: 'productionOrderWarehouseDetails' })
  @Type(() => Item)
  items: Item[];
}

class Item {
  @Expose()
  itemId: number;

  @Expose()
  quantity: number;

  @Expose()
  confirmedQuantity: number;

  @Expose()
  warehouseId: number;
}
