import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { OrderListResponse } from './../../../order/dto/response/order-list-response.dto';

export class ProductionOrderListResponse extends OrderListResponse {
  @ApiProperty()
  @Expose()
  vendorName: string;
}
