import { IsArray } from 'class-validator';
import { Expose, Transform, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { OrderResponseDto } from '@components/order/dto/response/order-response.dto';

class Warehouse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}

class Detail {
  @ApiProperty()
  @Expose({ name: 'itemDetailSettingId' })
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty({})
  @Expose({ name: 'itemDetailQuantity' })
  quantity: number;
}

class LotDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  locationId: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty({ description: '' })
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  mfg: string;

  @ApiProperty({ description: 'Số lượngKH' })
  @Expose()
  planQuantity: number;

  @ApiProperty({ description: 'Số lượng cần nhập còn lại' })
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  remainStockQuantity: number;

  @ApiProperty({ description: 'Số lượng cần nhập còn lại' })
  @Expose()
  qcPassQuantity: number;

  @ApiProperty({ description: 'Số lượng cần nhập còn lại' })
  @Expose()
  qcRejectQuantity: number;

  @ApiProperty({ description: 'Số lượng cần nhập còn lại' })
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  isExpired: boolean;
}
class WorkCenterDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty({ description: 'Số lượng cần nhập còn lại' })
  @Expose()
  quantity: number;
}

class PROItem {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  detailId: number;

  @ApiProperty()
  @Expose()
  warehouseDetailId: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty({ description: 'Số lượng thực tế đã nhập' })
  @Expose()
  actualQuantity: number;

  @ApiProperty({ description: 'Số lượng cần nhập còn lại' })
  @Expose()
  quantity: number;

  @ApiProperty({ description: 'Số lượng cần nhập theo kế hoạch' })
  @Expose()
  planQuantity: number;

  @ApiProperty({ description: 'Số lươgnj đã xác nhận' })
  @Expose()
  confirmQuantity: number;

  @ApiProperty()
  @Expose()
  qcPassQuantity: number;

  @ApiProperty()
  @Expose()
  qcRejectQuantity: number;

  @ApiProperty({ description: 'Số lươgnj đã xác nhận' })
  @Expose()
  qcCheck: number;

  @ApiProperty({ description: 'Số lươgnj đã xác nhận' })
  @Expose()
  qcCriteriaId: number;

  @ApiProperty({
    description: 'Danh sách chi tiết',
    type: () => Detail,
    isArray: true,
  })
  @Expose()
  @Type(() => Detail)
  details: Detail[];

  @ApiProperty({
    description: 'Danh sách số lô',
    type: () => LotDetail,
    isArray: true,
  })
  @Expose()
  @Type(() => LotDetail)
  lots: LotDetail[];

  @ApiProperty({
    description: 'Danh sách xưởng nhập NVL',
    type: () => WorkCenterDetail,
    isArray: true,
  })
  @Expose()
  @Type(() => WorkCenterDetail)
  workCenters: WorkCenterDetail[];
}

export class PROWorkCenter extends WorkCenterDetail {
  @ApiProperty({
    type: () => PROItem,
    isArray: true,
    description: 'Danh sách item',
  })
  @Expose()
  @Type(() => PROItem)
  @IsArray()
  items: PROItem[];
}

export class ProductionOrderWarehouseDetailResponseDto extends OrderResponseDto {
  @ApiProperty()
  @Expose()
  vendorId: number;

  @ApiProperty({
    type: () => Warehouse,
    description: 'Chi tiết kho theo user - chỉ kho thuộc user mới hiển thị',
  })
  @Expose()
  @Type(() => Warehouse)
  warehouse: Warehouse;

  @ApiProperty()
  @Expose()
  orderType: number;

  @ApiProperty({
    type: () => PROItem,
    isArray: true,
    description: 'Danh sách item',
  })
  @Expose()
  @Type(() => PROItem)
  @IsArray()
  items: PROItem[];

  @ApiProperty({
    type: () => PROWorkCenter,
    isArray: true,
  })
  @Expose()
  @Type(() => PROWorkCenter)
  @IsArray()
  workCenters: PROWorkCenter[];
}
