import { searchLikeString } from '@utils/helper';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { SetOrderStatusRequestDto } from '@components/order/dto/request/set-order-status-request.dto';
import {
  CAN_UPDATE_ORDER_STATUS,
  STATUS_TO_CONFIRM_ORDER_STATUS,
  STATUS_TO_APPROVE_ORDER_STATUS,
  STATUS_TO_REJECT_ORDER_STATUS,
  STATUS_TO_DELETE_ORDER_STATUS,
  OrderTypeEnum,
  OrderWarehouseActionTypeEnum,
} from '@constant/order.constant';
import { OrderTypeEnum as ActionOrderTypeEnum, ROLE } from '@constant/common';
import { ProductionOrderWarehouseDetail } from '@entities/production-order/production-order-warehouse-detail.entity';
import * as Moment from 'moment';
import { WarehouseServiceInterface } from './../warehouse/interface/warehouse.service.interface';
import { OrderServiceAbstract } from './../order/interface/order.service.abstract';
import { plainToInstance } from 'class-transformer';
import { PagingResponse } from '@utils/paging.response';
import { Inject, Injectable } from '@nestjs/common';
import { ProductionOrderRepositoryInterface } from '@components/production-order/interface/production-order.repository.interface';
import { ProductionOrderServiceInterface } from '@components/production-order/interface/production-order.service.interface';
import { UpdateOrderDetailActualQuantityRequestDto } from '@components/order/dto/request/update-actual-quantity-order-detail.request.dto';
import { ProductionOrderDetailRepositoryInterface } from './interface/production-order-detail.repository.interface';
import { ProductionOrderWarehouseDetailRepositoryInterface } from './interface/production-order-warehouse-detail.repository.interface';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, In, Not, ILike } from 'typeorm';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { UpdateOrderDetailConfirmQuantityRequestDto } from '@components/order/dto/request/update-confirm-quantity-order-detail.request.dto';
import { CreateProductionOrderRequestDto } from './dto/request/create-production-order-request.dto';
import { GetOrderListRequest } from '@components/order/dto/request/get-order-list.request.dto';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { plus } from '@utils/helper';
import {
  values,
  uniq,
  map,
  isNull,
  isEmpty,
  filter,
  flatMap,
  compact,
  first,
  isArray,
} from 'lodash';
import { ProductionOrderResponseDto } from './dto/response/production-order-response.dto';
import { OrderStatusEnum, STATUS_TO_QC_ORDER } from '@constant/common';
import { GetOrderDetailRequestDto } from '@components/order/dto/request/get-order-detail.request.dto';
import { ProductionOrder } from '@entities/production-order/production-order.entity';
import { UpdateProductionOrderDto } from './dto/request/update-production-order-request.dto';
import { ProductionOrderDetail } from '@entities/production-order/production-order-detail.entity';
import { GetAllPrORequest } from './dto/request/get-all-pro.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { GetAllPrOResponse } from './dto/response/get-all-pro.response.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { DeleteOrderRequestDto } from '@components/order/dto/request/delete-order.request.dto';
import { GetListOrderByIdsRequestDto } from '@components/order/dto/request/get-list-order-by-ids.request.dto';
import { GetByItemIdRequestDto } from '@components/purchased-order/dto/request/get-by-item-id.request.dto';
import { OrderUpdateActualQuantityEvent } from '@components/order/events/order-update-actual-quantity.event';
import { OrderUpdateConfirmedQuantityEvent } from '@components/order/events/order-update-confirmed-quantity.event';
import { GetOrderDetailByWarehouseRequestDto } from '@components/order/dto/request/get-order-detail-by-warehouse.request.dto';
import { ProductionOrderWarehouseDetailResponseDto } from './dto/response/production-order-warehouse-detail-response.dto';
import { GetOrderWarehouseRequest } from '@components/order/dto/request/get-order-warehouse.request.dto';
import { OrderWarehouseResponse } from '@components/order/dto/response/order-warehouse-response.dto';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { GetOrderByWarehouseItemRequestDto } from '@components/order/dto/request/get-order-by-warehouse-item.request.dto';
import { UpdateProductionOrderDetailQcQuantityRequestDto } from './dto/request/update-qc-quantity-production-order-request.dto';
import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { CreateProductionOrderDraftRequestDto } from './dto/request/create-production-order-draft-request.dto';
import { TotalQuantityItemProductionOrderResponseDto } from './dto/response/total-quantity-item-production-order.response.dto';
import { ProductionOrderWarehouseLotRepositoryInterface } from './interface/production-order-warehouse-lot.repository.interface';
import { ProductionOrderWarehouseLotEntity } from '@entities/production-order/production-order-warehouse-lot.entity';
import { keyBy, find } from 'lodash';
import { GetListWarehouseExitsFloorRequestDto } from '@components/warehouse/dto/request/get-warehouse-exits-floor.request.dto';
import { stringFormat } from '@utils/object.util';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { PushNotificationRequestDto } from '@components/notification/dto/notification.request.dto';
import {
  ActionNotificationEnum,
  TypeNotificationEnum,
  MesModuleEnum,
} from '@components/notification/notification.const';
import { getInnerJoinElements } from '@utils/common';

@Injectable()
export class ProductionOrderService
  extends OrderServiceAbstract
  implements ProductionOrderServiceInterface
{
  constructor(
    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('ProduceServiceInterface')
    protected readonly produceService: ProduceServiceInterface,

    @Inject('ProductionOrderRepositoryInterface')
    private readonly productionOrderRepository: ProductionOrderRepositoryInterface,

    @Inject('ProductionOrderDetailRepositoryInterface')
    private readonly productionOrderDetailRepository: ProductionOrderDetailRepositoryInterface,

    @Inject('ProductionOrderWarehouseDetailRepositoryInterface')
    private readonly productionOrderWarehouseDetailRepository: ProductionOrderWarehouseDetailRepositoryInterface,

    @Inject('ProductionOrderWarehouseLotRepositoryInterface')
    private readonly productionOrderWarehouseLotRepository: ProductionOrderWarehouseLotRepositoryInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly eventEmitter: EventEmitter2,

    private readonly i18n: I18nRequestScopeService,
  ) {
    super(itemService, warehouseService, userService);
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async createPrODraft(
    payload: CreateProductionOrderDraftRequestDto,
  ): Promise<any> {
    const { items, code } = payload;
    let response, message;
    let responseCode = ResponseCodeEnum.SUCCESS;
    const existedPro = await this.productionOrderRepository.findOneByCondition({
      code: code,
    });

    if (existedPro) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }
    const productionOrderDetailRaws = {};
    items.forEach((item) => {
      if (productionOrderDetailRaws[item.id]) {
        productionOrderDetailRaws[item.id].quantity = plus(
          productionOrderDetailRaws[item.id].quantity,
          item.quantity,
        );
      } else {
        productionOrderDetailRaws[item.id] = {
          id: item.id,
          quantity: item.quantity,
          lotNumber: item.lotNumber,
        };
      }
    });

    // create production order
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const productionOrderEntity =
        this.productionOrderRepository.createEntity(payload);
      const productionOrder = await queryRunner.manager.save(
        productionOrderEntity,
      );

      const productionOrderDetailEntities = values(
        productionOrderDetailRaws,
      ).map((productionOrderDetail: any) =>
        this.productionOrderDetailRepository.createEntity({
          productionOrderId: productionOrder.id,
          itemId: productionOrderDetail.id,
          quantity: productionOrderDetail.quantity,
          lotNumber: productionOrderDetail.lotNumber,
        }),
      );

      productionOrder.productionOrderDetails = await queryRunner.manager.save(
        productionOrderDetailEntities,
      );

      const productionOrderWarehouseDetailEntities = items.map((item) => {
        const productionOrderDetail =
          productionOrder.productionOrderDetails.find(
            (pod) => pod.itemId === item.id,
          );
        return this.productionOrderWarehouseDetailRepository.createEntity({
          itemId: item.id,
          productionOrderDetailId: productionOrderDetail.id,
          productionOrderId: productionOrderDetail.productionOrderId,
          quantity: item.quantity,
          qcCheck: item.qcCheck ? 1 : 0,
        });
      });

      productionOrder.productionOrderWarehouseDetails =
        await queryRunner.manager.save(productionOrderWarehouseDetailEntities);
      await queryRunner.commitTransaction();
      response = plainToInstance(ProductionOrderResponseDto, productionOrder, {
        excludeExtraneousValues: true,
      });
    } catch (error) {
      await queryRunner.rollbackTransaction();
      responseCode = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      message = error;
    }

    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(responseCode)
      .withData(response)
      .withMessage(
        responseCode === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  async getListOrderWarehouse(request: GetOrderWarehouseRequest): Promise<any> {
    const { user, keyword, id } = request;
    const userWarehouses = await this.userService.getUserWarehousesById(
      user.id,
    );
    const productionOrder = await this.productionOrderRepository.findOneById(
      +id,
    );
    if (isEmpty(productionOrder)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    let warehouseIds = [];
    if (!isEmpty(keyword)) {
      warehouseIds = filter(
        userWarehouses,
        (warehouse) =>
          searchLikeString(warehouse.name, keyword) ||
          searchLikeString(warehouse.code, keyword),
      ).map((w) => w.id);
    } else {
      warehouseIds = userWarehouses.map((e) => e.id);
    }
    const data =
      await this.productionOrderWarehouseDetailRepository.getListOrderWarehouse(
        request,
        warehouseIds,
      );

    const requestWarehouseExistFloor =
      new GetListWarehouseExitsFloorRequestDto();
    requestWarehouseExistFloor.isSpace =
      productionOrder.type === ActionOrderTypeEnum.Import ? '1' : '0';
    requestWarehouseExistFloor.sort = request.sort;
    requestWarehouseExistFloor.limit = request.limit;
    requestWarehouseExistFloor.page = request.page;
    requestWarehouseExistFloor.filter = [
      {
        column: 'ids',
        text: map(data, 'warehouseId').join(','),
      },
    ];
    if (productionOrder.type === ActionOrderTypeEnum.Export) {
      requestWarehouseExistFloor.filter.push({
        column: 'itemIds',
        text: '',
      });
    }
    const warehousesExistFloor =
      await this.warehouseService.getListWarehouseExistFloor(
        requestWarehouseExistFloor,
      );

    const normalizeWarehouses = {};
    userWarehouses.forEach((warehouse) => {
      normalizeWarehouses[warehouse.id] = warehouse;
    });

    const importOrderWarehouseDetailData = {};
    data.forEach((item) => {
      importOrderWarehouseDetailData[item.id] = item;
    });

    //get_factory_by_ids
    let dataMaping = warehousesExistFloor.items.map((e) => ({
      warehouseId: e.id,
      warehouseName: normalizeWarehouses[e.id].name,
      warehouseCode: normalizeWarehouses[e.id].code,
      items: importOrderWarehouseDetailData[e.warehoueId]?.items,
      factoryId: normalizeWarehouses[e.id].factoryId,
    }));
    const factoriesNameData = await this.userService.getFactories(
      dataMaping.map((e) => e.factoryId),
    );

    dataMaping = dataMaping.map((e) => {
      const factory = factoriesNameData.find(
        (e2) => e2.factoryId === e.factoryId,
      );
      return {
        ...e,
        factoryName: factory?.factoryName,
      };
    });

    const dataReturn = plainToInstance(OrderWarehouseResponse, dataMaping, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: warehousesExistFloor.meta,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  async getListByIds(payload: GetListOrderByIdsRequestDto): Promise<any> {
    const { ids } = payload;
    const data = await this.productionOrderRepository.getListByIds(ids);
    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async delete(payload: DeleteOrderRequestDto): Promise<any> {
    const { id } = payload;

    const productionOrder = await this.productionOrderRepository.findOneById(
      id,
    );
    if (!productionOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_DELETE_ORDER_STATUS.includes(productionOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.delete(ProductionOrderWarehouseLotEntity, {
        productionOrderId: id,
      });
      await queryRunner.manager.delete(ProductionOrderWarehouseDetail, {
        productionOrderId: id,
      });
      await queryRunner.manager.delete(ProductionOrderDetail, {
        productionOrderId: id,
      });
      await queryRunner.manager.delete(ProductionOrder, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }
    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Delete
   */
  public async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const productionOrders =
      await this.productionOrderRepository.findByCondition({
        id: In(ids),
      });

    const productionOrderIds = productionOrders.map(
      (productionOrder) => productionOrder.id,
    );
    if (productionOrders.length !== ids.length) {
      ids.forEach((id) => {
        if (!productionOrderIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < productionOrders.length; i++) {
      const productionOrder = productionOrders[i];
      if (!STATUS_TO_DELETE_ORDER_STATUS.includes(productionOrder.status))
        failIdsList.push(productionOrder.id);
    }

    const validIds = productionOrders
      .filter((productionOrder) => !failIdsList.includes(productionOrder.id))
      .map((productionOrder) => productionOrder.id);

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (!isEmpty(validIds)) {
        await queryRunner.manager.delete(ProductionOrderWarehouseLotEntity, {
          productionOrderId: In(validIds),
        });
        await queryRunner.manager.delete(ProductionOrderWarehouseDetail, {
          productionOrderId: In(validIds),
        });
        await queryRunner.manager.delete(ProductionOrderDetail, {
          productionOrderId: In(validIds),
        });
        await queryRunner.manager.delete(ProductionOrder, validIds);
        await queryRunner.commitTransaction();
      }
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    await queryRunner.release();
    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async update(payload: UpdateProductionOrderDto): Promise<any> {
    const { code, id, manufacturingOrderId } = payload;
    const productionOrder =
      await this.productionOrderRepository.findOneWithRelations({
        where: {
          id: id,
        },
        relations: ['productionOrderDetails'],
      });

    if (manufacturingOrderId)
      productionOrder.manufacturingOrderId = manufacturingOrderId;

    if (!productionOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CAN_UPDATE_ORDER_STATUS.includes(productionOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    if (manufacturingOrderId) {
      const manufacturingOrderIds = [manufacturingOrderId];
      const manufacturingOrder = await this.produceService.getMoByIds(
        manufacturingOrderIds,
      );

      if (manufacturingOrder.length === 0) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.MANUFACTURING_ORDER_NOT_FOUND'),
          )
          .build();
      }
    }

    const isExistProductionOrder =
      await this.productionOrderRepository.findByCondition({
        code: code,
        id: Not(id),
      });
    if (isExistProductionOrder.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ORDER_IS_EXIST'))
        .build();
    }

    if (productionOrder.status === OrderStatusEnum.Reject) {
      productionOrder.status = OrderStatusEnum.Pending;
    }

    return await this.save(productionOrder, payload);
  }

  /**
   * Get general production order detail
   */
  public async getDetail(payload: GetOrderDetailRequestDto): Promise<any> {
    const { id } = payload;
    const productionOrder = await this.productionOrderRepository.getDetail(id);
    if (!productionOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (productionOrder.manufacturingOrderId) {
      const manufacturingOrderIds = [productionOrder.manufacturingOrderId];
      const manufacturingOrder = await this.produceService.getMoByIds(
        manufacturingOrderIds,
      );

      productionOrder.manufacturingOrder = manufacturingOrder[0];
    }
    const itemIds = map(productionOrder.productionOrderDetails, 'itemId');
    const warehouseIds = uniq(
      map(productionOrder.productionOrderWarehouseDetails, 'warehouseId'),
    );
    const userIds = uniq([
      productionOrder.createdByUserId,
      productionOrder.confimerId,
      productionOrder.approverId,
    ]);
    const { items, warehouses, users } = await super.getOrderExtraInfo(
      itemIds,
      warehouseIds,
      userIds,
    );
    const normalizeItems = {};
    const normalizeWarehouses = {};
    const normalizeUsers = {};
    const packageIds = uniq(
      map(productionOrder.productionOrderWarehouseLots, 'packageId'),
    );
    let packages;
    if (!isEmpty(packageIds)) {
      packages = await this.itemService.getPackageByIds(packageIds);
    }
    const normalizePackages = keyBy(packages, 'id');
    items.forEach((item) => {
      normalizeItems[item.itemId] = item;
    });
    warehouses.forEach((warehouse) => {
      normalizeWarehouses[warehouse.id] = warehouse;
    });

    users.forEach((user) => {
      normalizeUsers[user.id] = user;
    });
    productionOrder.createdByUser =
      normalizeUsers[productionOrder.createdByUserId];
    productionOrder.approver = normalizeUsers[productionOrder.approverId];
    productionOrder.confirmer = normalizeUsers[productionOrder.confirmerId];
    productionOrder.productionOrderDetails =
      productionOrder.productionOrderDetails.map((productionOrderDetail) => ({
        ...productionOrderDetail,
        item: normalizeItems[productionOrderDetail.itemId],
      }));

    productionOrder.productionOrderWarehouseLots =
      productionOrder.productionOrderWarehouseLots.map(
        (productionOrderWarehouseLot) => ({
          ...productionOrderWarehouseLot,
          package: normalizePackages[productionOrderWarehouseLot.packageId]
            ? normalizePackages[productionOrderWarehouseLot.packageId]
            : {},
          item: normalizeItems[productionOrderWarehouseLot.itemId]
            ? normalizeItems[productionOrderWarehouseLot.itemId]
            : {},
          warehouse:
            normalizeWarehouses[productionOrderWarehouseLot.warehouseId],
        }),
      );

    productionOrder.productionOrderWarehouseDetails =
      productionOrder.productionOrderWarehouseDetails.map(
        (productionOrderWarehouseDetail) => ({
          ...productionOrderWarehouseDetail,
          item: normalizeItems[productionOrderWarehouseDetail.itemId],
          warehouse:
            normalizeWarehouses[productionOrderWarehouseDetail.warehouseId],
        }),
      );

    const dataReturn = plainToInstance(
      ProductionOrderResponseDto,
      productionOrder,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getDetailByWarehouseId(
    payload: GetOrderDetailByWarehouseRequestDto,
  ): Promise<any> {
    const { id, warehouseId, user, warehouseShelfFloorId } = payload;
    const isWarehouseOfUser = await this.validateWarehouseIsOfUser(
      user.id,
      warehouseId,
    );

    if (!isWarehouseOfUser) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const productionOrder =
      await this.productionOrderRepository.getDetailByWarehouseId(id, [
        warehouseId,
      ]);

    if (!productionOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const itemIds = map(productionOrder.items, 'id');
    const userIds = uniq([
      productionOrder.createdByUserId,
      productionOrder.confirmerId,
      productionOrder.approverId,
    ]).filter((id) => !isNull(id));

    const { items, warehouses, users } = await super.getOrderExtraInfo(
      itemIds,
      [warehouseId],
      userIds,
    );
    const normalizeItems = {};
    const normalizeUsers = {};
    const normalizeWarehouses = {};

    warehouses.forEach((warehouse) => {
      normalizeWarehouses[warehouse.id] = warehouse;
    });
    items.forEach((item) => {
      normalizeItems[item.itemId] = item;
    });

    users.forEach((user) => {
      normalizeUsers[user.id] = user;
    });
    productionOrder.createdByUser =
      normalizeUsers[productionOrder.createdByUserId];
    productionOrder.approver = normalizeUsers[productionOrder.approverId];
    productionOrder.confirmer = normalizeUsers[productionOrder.confirmerId];
    productionOrder.warehouse = normalizeWarehouses[warehouseId];
    let rawWorkCenters = [];
    const lots = {};
    let itemStockLots;

    productionOrder.items.forEach((item) => {
      lots[item.id] = item.lots;
    });

    if (productionOrder.type === OrderWarehouseActionTypeEnum.EXPORT) {
      rawWorkCenters = await this.produceService.getMaterialImportWorkCenter(
        productionOrder.manufacturingOrderId,
        map(productionOrder.items, 'id'),
      );
      const lotNumbers = flatMap(map(productionOrder.items, 'lots'));

      const lotLocations =
        await this.itemService.getItemWarehouseSheflFloorByLotNumbers(
          warehouseShelfFloorId,
          map(lotNumbers, 'lotNumber'),
        );
      itemStockLots = keyBy(lotLocations, 'lotNumber');

      productionOrder.items = productionOrder.items.map((item) => ({
        ...normalizeItems[item.id],
        ...item,
        lots: item.lots
          .map((lot) => {
            const location =
              itemStockLots[lot.lotNumber?.toUpperCase()] &&
              itemStockLots[lot.lotNumber?.toUpperCase()].itemId === item.id
                ? itemStockLots[lot.lotNumber?.toUpperCase()]
                : null;
            return isEmpty(location)
              ? null
              : {
                  ...location,
                  ...lot,
                  id: location?.id || null,
                  remainStockQuantity: location.quantity,
                };
          })
          .filter((l) => !isEmpty(l)),
      }));
    } else {
      if (!isEmpty(productionOrder.items)) {
        rawWorkCenters = await this.produceService.getExportWorkCenter(
          productionOrder.manufacturingOrderId,
          map(productionOrder.items, 'id'),
        );
      }

      productionOrder.items = productionOrder.items.map((item) => ({
        ...normalizeItems[item.id],
        ...item,
      }));
    }
    const workCenters = {};

    rawWorkCenters.forEach((rawWorkCenter) => {
      rawWorkCenter.workCenters.forEach((wc) => {
        if (workCenters[wc.id]) {
          workCenters[wc.id].items.push({
            ...normalizeItems[rawWorkCenter.itemId],
            quantity: wc.quantity,
          });
        } else {
          workCenters[wc.id] = {
            ...wc,
            items: [
              {
                id: rawWorkCenter.itemId,
                ...normalizeItems[rawWorkCenter.itemId],
                quantity: wc.quantity,
                lots:
                  productionOrder.type === OrderWarehouseActionTypeEnum.EXPORT
                    ? lots[rawWorkCenter.itemId]
                      ? lots[rawWorkCenter.itemId]
                          .map((lot) => {
                            const location =
                              itemStockLots[lot.lotNumber] &&
                              itemStockLots[lot.lotNumber].itemId ===
                                rawWorkCenter.itemId
                                ? itemStockLots[lot.lotNumber]
                                : null;
                            return isEmpty(location)
                              ? null
                              : {
                                  ...lot,
                                  ...location,
                                  id: location?.id || null,
                                };
                          })
                          .filter((l) => !isEmpty(l))
                      : []
                    : [
                        {
                          lotNumber: rawWorkCenter.lotNumber,
                          lotDate: rawWorkCenter.lotDate,
                          quantity: wc.quantity,
                          actualQuantity: wc.quantity,
                          isExpired: false,
                        },
                      ],
              },
            ],
          };
        }
      });
    });

    productionOrder.workCenters = values(workCenters);
    const dataReturn = plainToInstance(
      ProductionOrderWarehouseDetailResponseDto,
      {
        ...productionOrder,
        orderType: productionOrder.poType,
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  async getList(payload: GetOrderListRequest): Promise<any> {
    const { page, user } = payload;
    if (!payload.filter) payload.filter = [];

    const userWarehouses = await this.userService.getUserWarehousesById(
      user.id,
    );

    if (isEmpty(userWarehouses)) {
      return new ResponseBuilder<PagingResponse>({
        items: [],
        meta: { total: 0, page: 1 },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const filterWarehouseId = payload.filter.find(
      (filter) => filter.column === 'warehouseId',
    );

    let warehouseIds = map(
      userWarehouses,
      (userWarehouse) => +userWarehouse.id,
    );
    if (filterWarehouseId) {
      warehouseIds = getInnerJoinElements(
        warehouseIds,
        filterWarehouseId.text.split(',').map((warehouseId) => +warehouseId),
      );
      if (isEmpty(warehouseIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: payload.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
      }
    }

    payload.filter.push({
      column: 'warehouseId',
      text: warehouseIds.join(','),
    });

    const [data, count] = await this.productionOrderRepository.getList(payload);

    const manufacturingOrderIds = uniq(
      map(flatMap(data), 'manufacturingOrderId'),
    );

    let result = data;
    if (manufacturingOrderIds.length > 0) {
      const manufacturingOrder = await this.produceService.getMoByIds(
        manufacturingOrderIds,
        true,
      );

      result = data.map((pro) => ({
        ...pro,
        manufacturingOrder: manufacturingOrder[pro.manufacturingOrderId],
      }));
    }
    const dataReturn = plainToInstance(ProductionOrderResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async create(payload: CreateProductionOrderRequestDto): Promise<any> {
    const { code, manufacturingOrderId } = payload;
    const isExist = await this.productionOrderRepository.findByCondition({
      code: code,
    });

    if (isExist.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ORDER_IS_EXIST'))
        .build();
    }

    if (manufacturingOrderId) {
      const manufacturingOrderIds = [manufacturingOrderId];
      const manufacturingOrder = await this.produceService.getMoByIds(
        manufacturingOrderIds,
      );

      if (manufacturingOrder.length === 0) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.MANUFACTURING_ORDER_NOT_FOUND'),
          )
          .build();
      }
    }

    const productionOrderEntity =
      this.productionOrderRepository.createEntity(payload);

    return await this.save(productionOrderEntity, payload);
  }

  /**
   *
   * @param productionOrderEntity
   * @param payload
   * @returns
   */
  private async save(
    productionOrderEntity: ProductionOrder,
    payload: CreateProductionOrderRequestDto,
  ): Promise<any> {
    const { items, userId } = payload;
    const isUpdate = productionOrderEntity.id !== null;
    let response, message;
    let code = ResponseCodeEnum.SUCCESS;
    // Validate items
    const itemIds = uniq(items.map((e) => e.id));
    const itemsExist = await this.itemService.getItems(itemIds);

    if (!itemsExist || itemIds.length !== itemsExist.length) {
      const itemIdsExist = itemsExist ? itemsExist.map((e) => e.itemId) : [];
      return new ResponseBuilder({
        invalidItems: items.filter((e) => !itemIdsExist.includes(e.id)),
      })
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }

    const productionOrderDetailRaws = {};
    items.forEach((item) => {
      if (productionOrderDetailRaws[item.id]) {
        productionOrderDetailRaws[item.id].quantity = plus(
          productionOrderDetailRaws[item.id].quantity,
          item.quantity,
        );
      } else {
        productionOrderDetailRaws[item.id] = {
          id: item.id,
          quantity: item.quantity,
        };
      }
    });

    const productionOrderWarehouseDetailRaws = [];
    items.forEach((item) => {
      const key = item.id + '_' + item.warehouseId;
      if (productionOrderWarehouseDetailRaws[key]) {
        productionOrderWarehouseDetailRaws[key].quantity = plus(
          productionOrderWarehouseDetailRaws[key].quantity,
          item.quantity,
        );
      } else {
        productionOrderWarehouseDetailRaws[key] = {
          itemId: item.id,
          quantity: item.quantity,
          warehouseId: item.warehouseId,
          qcCheck: item.qcCheck,
          qcCriteriaId: item.qcCriteriaId,
        };
      }
    });

    const moItemLots = await this.produceService.getMoItemLots(
      productionOrderEntity.manufacturingOrderId,
      true,
    );

    const packageIds = compact(uniq(map(items, 'packageId')));
    const packages = await this.itemService.getPackageByIds(packageIds);

    if (packageIds.length !== packages.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PACKAGE_NOT_FOUND'))
        .build();
    }

    const warehouseIds = compact(uniq(map(items, 'warehouseId')));
    const warehouses = await this.warehouseService.getWarehouses(warehouseIds);

    if (warehouseIds.length !== warehouses.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
        .build();
    }

    let packageMaps = {};
    if (packages.length > 0) {
      packageMaps = keyBy(packages, 'id');
    }

    const lotNumberOfPro =
      await this.productionOrderWarehouseLotRepository.getListLotNumber(
        itemIds,
        productionOrderEntity.id,
      );

    const lotNumberData = compact([...lotNumberOfPro, ...moItemLots]);

    //Validate lotNumber, packageId
    let checkNotOnlyMfgInSameLotNumber = false;
    let checkMfgLotNumberInCorrect = false;
    let checkItemNotExistInPackage = false;
    let checkUniqWarehouse = false;
    const arrLotNumberOfItem = [];

    for (let i = 0; i < items.length; i++) {
      //validate lotNumber
      const item = items[i];
      const lotNumberRequest = item.lotNumber;

      const otherMfgInSameLotNumber = items.filter(
        (record) =>
          record.lotNumber === lotNumberRequest &&
          record.mfg !== item.mfg &&
          record.id == item.id,
      );
      if (otherMfgInSameLotNumber.length > 0) {
        checkNotOnlyMfgInSameLotNumber = true;
        break;
      }

      const lotNumberExisted = lotNumberData.filter(
        (record) =>
          record.lotNumber === first(lotNumberRequest) && record.id == item.id,
      );

      if (
        lotNumberExisted.length > 0 &&
        !Moment(first(lotNumberExisted).mfg).isSame(Moment(item.mfg))
      ) {
        checkMfgLotNumberInCorrect = true;
        break;
      }
      const key = item.id + `_` + item.warehouseId;
      if (arrLotNumberOfItem[key]) {
        arrLotNumberOfItem[key] = arrLotNumberOfItem[key].concat([
          lotNumberRequest,
        ]);
      } else {
        arrLotNumberOfItem[key] = [lotNumberRequest];
      }

      //Validate Warehouse Id
      if (
        arrLotNumberOfItem[key].length !== uniq(arrLotNumberOfItem[key]).length
      ) {
        checkUniqWarehouse = true;
        break;
      }

      //validate Package Id
      if (item.packageId && !isEmpty(packageMaps)) {
        // validate packageId
        const itemIdExistInPackage = packageMaps[
          item.packageId
        ].packageItems.filter((record) => record.itemId === item.id);

        if (itemIdExistInPackage.length === 0) {
          checkItemNotExistInPackage = true;
          break;
        }
      }
    }

    if (checkUniqWarehouse) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.DUPLICATE_WAREHOUSE'))
        .build();
    }

    if (checkItemNotExistInPackage) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.ITEM_NOT_EXIST_IN_PACKAGE'),
        )
        .build();
    }

    if (checkNotOnlyMfgInSameLotNumber) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.MFG_MUST_BE_SAME_IN_THE_SAME_LOT_NUMBER',
          ),
        )
        .build();
    }
    const user = await this.userService.getUserById(userId);
    const userIds = await this.getListUserByRoles(user.userRoleSettings || []);

    // create production order
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      productionOrderEntity.name = payload.name;
      productionOrderEntity.code = payload.code;
      productionOrderEntity.deadline = payload.deadline;
      productionOrderEntity.description = payload.description;
      productionOrderEntity.type = payload.type;
      productionOrderEntity.createdByUserId = payload.createdByUserId;
      const productionOrder = await queryRunner.manager.save(
        productionOrderEntity,
      );
      const productionOrderDetailEntities = values(
        productionOrderDetailRaws,
      ).map((productionOrderDetail: any) =>
        this.productionOrderDetailRepository.createEntity({
          productionOrderId: productionOrder.id,
          itemId: productionOrderDetail.id,
          quantity: productionOrderDetail.quantity,
        }),
      );
      if (isUpdate) {
        await queryRunner.manager.delete(ProductionOrderDetail, {
          productionOrderId: productionOrder.id,
        });
      }
      productionOrder.productionOrderDetails = await queryRunner.manager.save(
        productionOrderDetailEntities,
      );

      const productionOrderDetailMap = [];
      productionOrder.productionOrderDetails.forEach((record) => {
        const key = record.itemId;
        productionOrderDetailMap[key] = record;
      });

      const productionOrderWarehouseDetailEntities = values(
        productionOrderWarehouseDetailRaws,
      ).map((item) => {
        const productionOrderDetail =
          productionOrder.productionOrderDetails.find(
            (pod) => pod.itemId === item.itemId,
          );
        return this.productionOrderWarehouseDetailRepository.createEntity({
          itemId: item.itemId,
          warehouseId: item.warehouseId,
          productionOrderDetailId: productionOrderDetail.id,
          productionOrderId: productionOrderDetail.productionOrderId,
          quantity: item.quantity,
          qcCheck: +item.qcCheck,
          qcCriteriaId: item.qcCriteriaId,
        });
      });

      if (isUpdate) {
        await queryRunner.manager.delete(ProductionOrderWarehouseLotEntity, {
          productionOrderId: productionOrder.id,
        });
        await queryRunner.manager.delete(ProductionOrderWarehouseDetail, {
          productionOrderId: productionOrder.id,
        });
      }

      productionOrder.productionOrderWarehouseDetails =
        await queryRunner.manager.save(productionOrderWarehouseDetailEntities);

      const productionOrderWarehouseDetailMap = [];
      productionOrder.productionOrderWarehouseDetails.forEach((record) => {
        const key = record.itemId + '_' + record.warehouseId;
        productionOrderWarehouseDetailMap[key] = record;
      });

      const productionOrderDetailLotEntities = items.map((item: any) => {
        const key = item.id + '_' + item.warehouseId;
        const productionOrderWarehouseDetail =
          productionOrderWarehouseDetailMap[key];
        return this.productionOrderWarehouseLotRepository.createEntity({
          productionOrderId: productionOrder.id,
          productionOrderWarehouseDetailId: productionOrderWarehouseDetail.id,
          itemId: item.id,
          warehouseId: item.warehouseId,
          lotNumber: item.lotNumber,
          mfg: item.mfg,
          packageId: item.packageId,
          quantity: item.quantity,
        });
      });
      productionOrder.productionOrderWarehouseLots =
        await queryRunner.manager.save(productionOrderDetailLotEntities);
      await queryRunner.commitTransaction();
      if (!isUpdate) {
        const notificationRequest = new PushNotificationRequestDto();
        notificationRequest.title =
          MesModuleEnum.WMSX +
          ` ${
            user.username +
            (await this.i18n.translate(
              'error.PRODUCTION_ORDER_CREATED_NOTIFICATION',
            )) +
            productionOrder.name
          }`;
        notificationRequest.type = TypeNotificationEnum.WEB;
        notificationRequest.action = ActionNotificationEnum.WAREHOUSE_YARD;
        notificationRequest.content = productionOrder.description;
        //TODO SnP waiting
        notificationRequest.templateId = '62675f887848315c26a23033';
        notificationRequest.executionDate = new Date().toISOString();
        notificationRequest.payload = {
          title: notificationRequest.title,
          content: productionOrder.description,
        };
        notificationRequest.userIds = userIds;
        const pushMail = Object.assign(notificationRequest, {
          type: TypeNotificationEnum.MAIL,
        });
        this.eventEmitter.emit('purchased_order_import.created', pushMail);
        this.eventEmitter.emit(
          'purchased_order_import.created',
          notificationRequest,
        );
      }
      response = plainToInstance(ProductionOrderResponseDto, productionOrder, {
        excludeExtraneousValues: true,
      });
    } catch (error) {
      await queryRunner.rollbackTransaction();
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      message = error;
    }

    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(code)
      .withData(response)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  async updateOrderDetailConfirmQuantity(
    payload: UpdateOrderDetailConfirmQuantityRequestDto,
  ): Promise<any> {
    const { orderId, orderDetails, warehouseOrderDetails } = payload;
    let message;
    let code = ResponseCodeEnum.SUCCESS;
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const updateProductionOrderDetailEntities =
        await this.productionOrderDetailRepository.getUpdateOrderDetailConfirmQuantityByIds(
          orderId,
          orderDetails,
        );

      const updateProductionOrderWarehouseDetailEntities =
        await this.productionOrderWarehouseDetailRepository.getUpdateOrderWarehouseDetailConfirmQuantityByIds(
          orderId,
          warehouseOrderDetails,
        );

      await queryRunner.manager.save(updateProductionOrderDetailEntities);
      await queryRunner.manager.save(
        updateProductionOrderWarehouseDetailEntities,
      );
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      message = error;
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
    }
    await queryRunner.release();
    this.eventEmitter.emit(
      'order.updateConfirmedQuantity',
      new OrderUpdateConfirmedQuantityEvent({
        id: orderId,
        orderType: OrderTypeEnum.PRO,
      }),
    );
    return new ResponseBuilder()
      .withCode(code)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  async updateOrderDetailActualQuantity(
    payload: UpdateOrderDetailActualQuantityRequestDto,
  ): Promise<any> {
    const { orderId, orderDetails, warehouseOrderDetails, itemLots } = payload;
    let message;
    let code = ResponseCodeEnum.SUCCESS;

    const productionOrderWarehouseLotEntities =
      await this.productionOrderWarehouseLotRepository.getLotsByItems(
        map(itemLots, 'itemId'),
        map(itemLots, 'lotNumber'),
        map(itemLots, 'warehouseId'),
        orderId,
      );

    productionOrderWarehouseLotEntities.forEach(
      (
        productionOrderWarehouseLotEntity: ProductionOrderWarehouseLotEntity,
      ) => {
        const itemLot = find(
          itemLots,
          (iL) =>
            iL.itemId === productionOrderWarehouseLotEntity.itemId &&
            iL.lotNumber.toUpperCase() ===
              productionOrderWarehouseLotEntity.lotNumber.toUpperCase(),
        );

        if (itemLot) {
          productionOrderWarehouseLotEntity.actualQuantity = plus(
            productionOrderWarehouseLotEntity.actualQuantity,
            itemLot.quantity,
          );
        }
      },
    );

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const updateProductionOrderDetailEntities =
        await this.productionOrderDetailRepository.getUpdateOrderDetailActualQuantityByIds(
          orderId,
          orderDetails,
        );

      const updateProductionOrderWarehouseDetailEntities =
        await this.productionOrderWarehouseDetailRepository.getUpdateOrderWarehouseDetailActualQuantityByIds(
          orderId,
          warehouseOrderDetails,
        );

      await queryRunner.manager.save(updateProductionOrderDetailEntities);
      await queryRunner.manager.save(productionOrderWarehouseLotEntities);
      await queryRunner.manager.save(
        updateProductionOrderWarehouseDetailEntities,
      );
      await queryRunner.commitTransaction();
    } catch (error) {
      message = error;
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      await queryRunner.rollbackTransaction();
    }
    await queryRunner.release();
    this.eventEmitter.emit(
      'order.updateActualQuantity',
      new OrderUpdateActualQuantityEvent({
        id: orderId,
        orderType: OrderTypeEnum.PRO,
      }),
    );
    return new ResponseBuilder()
      .withCode(code)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  /**
   * Get data production order by id and warehouseId
   * @param id
   * @param warehouseId
   * @returns
   */
  async getWarehouseDetails(
    id: number,
    warehouseId: number,
    type: number,
  ): Promise<any> {
    try {
      const data = await this.productionOrderRepository.getWarehouseDetails(
        id,
        warehouseId,
        type,
      );
      return new ResponseBuilder(data)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async confirm(payload: SetOrderStatusRequestDto): Promise<any> {
    const { id, userId } = payload;

    const productionOrder = await this.productionOrderRepository.findOneById(
      id,
    );
    if (!productionOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_CONFIRM_ORDER_STATUS.includes(productionOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.PRODUCTION_ORDER_WAS_CONFIRMED'),
        )
        .build();
    }

    const manufacturingOrder = await this.produceService.getMoByIds([
      productionOrder.manufacturingOrderId,
    ]);

    if (manufacturingOrder.length === 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.MANUFACTURING_ORDER_NOT_FOUND'),
        )
        .build();
    }

    const productionOrderWarehouseDetails =
      await this.productionOrderWarehouseDetailRepository.findByCondition({
        productionOrderId: productionOrder.id,
      });
    const productionOrderWarehouseDetailHaveNotWarehouses =
      productionOrderWarehouseDetails.filter(
        (record) => record.warehouseId === null,
      );
    if (productionOrderWarehouseDetailHaveNotWarehouses.length > 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.PRODUCTION_ORDER_MISSING_WAREHOUSE'),
        )
        .build();
    }

    return await this.setPurchasedOrderStatus(
      productionOrder,
      OrderStatusEnum.Confirmed,
      userId,
    );
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async confirmMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const productionOrders =
      await this.productionOrderRepository.findByCondition({
        id: In(ids),
      });

    const productionOrderIds = productionOrders.map(
      (productionOrder) => productionOrder.id,
    );
    if (productionOrders.length !== ids.length) {
      ids.forEach((id) => {
        if (!productionOrderIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < productionOrders.length; i++) {
      const productionOrder = productionOrders[i];
      if (!STATUS_TO_CONFIRM_ORDER_STATUS.includes(productionOrder.status))
        failIdsList.push(productionOrder.id);
    }

    const productionOrderWarehouseDetails =
      await this.productionOrderWarehouseDetailRepository.findByCondition({
        productionOrderId: In(productionOrders.map((pro) => pro.id)),
      });

    const productionOrderWarehouseDetailHaveNotWarehouses =
      productionOrderWarehouseDetails.filter(
        (record) => record.warehouseId === null,
      );

    if (productionOrderWarehouseDetailHaveNotWarehouses.length > 0) {
      productionOrderWarehouseDetailHaveNotWarehouses.forEach((record) => {
        failIdsList.push(record.productionOrderId);
      });
    }

    const validIds = productionOrders
      .filter((productionOrder) => !failIdsList.includes(productionOrder.id))
      .map((productionOrder) => productionOrder.id);

    const validProductionOrders = productionOrders.filter((productionOrder) =>
      validIds.includes(productionOrder.id),
    );

    if (!isEmpty(validProductionOrders)) {
      validProductionOrders.forEach((productionOrder) => {
        productionOrder.status = OrderStatusEnum.Confirmed;
        productionOrder.approvedAt = new Date(Date.now());
      });
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(ProductionOrder, validProductionOrders);
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.CONFIRM_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async reject(payload: SetOrderStatusRequestDto): Promise<any> {
    const { id, userId } = payload;

    const productionOrder = await this.productionOrderRepository.findOneById(
      id,
    );
    if (!productionOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_REJECT_ORDER_STATUS.includes(productionOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    return await this.setPurchasedOrderStatus(
      productionOrder,
      OrderStatusEnum.Reject,
      userId,
    );
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async rejectMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const productionOrders =
      await this.productionOrderRepository.findByCondition({
        id: In(ids),
      });

    const productionOrderIds = productionOrders.map(
      (productionOrder) => productionOrder.id,
    );
    if (productionOrders.length !== ids.length) {
      ids.forEach((id) => {
        if (!productionOrderIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < productionOrders.length; i++) {
      const productionOrder = productionOrders[i];
      if (!STATUS_TO_REJECT_ORDER_STATUS.includes(productionOrder.status))
        failIdsList.push(productionOrder.id);
    }

    const validIds = productionOrders
      .filter((productionOrder) => !failIdsList.includes(productionOrder.id))
      .map((productionOrder) => productionOrder.id);

    const validProductionOrders = productionOrders.filter(
      (purchasedOrderImport) => validIds.includes(purchasedOrderImport.id),
    );

    if (!isEmpty(validProductionOrders)) {
      validProductionOrders.forEach((productionOrder) => {
        productionOrder.status = OrderStatusEnum.Reject;
        productionOrder.approvedAt = new Date(Date.now());
      });
      const queryRunner = this.connection.createQueryRunner();
      try {
        await queryRunner.startTransaction();
        await queryRunner.manager.save(ProductionOrder, validProductionOrders);
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.REJECT_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async approve(payload: SetOrderStatusRequestDto): Promise<any> {
    const { id } = payload;

    const productionOrder = await this.productionOrderRepository.findOneById(
      id,
    );
    if (!productionOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_APPROVE_ORDER_STATUS.includes(productionOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    return await this.setPurchasedOrderStatus(
      productionOrder,
      OrderStatusEnum.Completed,
    );
  }

  /**
   *
   * @param saleOrderEntity
   * @param status
   * @returns
   */
  private async setPurchasedOrderStatus(
    productionOrderEntity: ProductionOrder,
    status: number,
    userId?: number,
  ): Promise<any> {
    productionOrderEntity.status = status;
    await this.productionOrderRepository.create(productionOrderEntity);

    //Push notification
    const user = await this.userService.getUserById(userId);
    const notificationRequest = new PushNotificationRequestDto();
    const titleConfirm =
      MesModuleEnum.WMSX +
      ` ${
        user.username +
        (await this.i18n.translate(
          'error.PRODUCTION_ORDER_CONFIRMED_NOTIFICATION',
        )) +
        productionOrderEntity.name
      }`;
    const titleReject =
      MesModuleEnum.WMSX +
      ` ${
        user.username +
        (await this.i18n.translate(
          'error.PRODUCTION_ORDER_REJECT_NOTIFICATION',
        )) +
        productionOrderEntity.name
      }`;
    notificationRequest.type = TypeNotificationEnum.WEB;
    notificationRequest.action = ActionNotificationEnum.WAREHOUSE_YARD;
    notificationRequest.content = productionOrderEntity.description;
    //TODO SnP waiting
    notificationRequest.templateId = '62675f887848315c26a23033';
    notificationRequest.executionDate = new Date().toISOString();
    notificationRequest.userIds = [productionOrderEntity.createdByUserId];
    if (status === OrderStatusEnum.Confirmed) {
      notificationRequest.title = titleConfirm;
      notificationRequest.payload = {
        title: titleConfirm,
        content: productionOrderEntity.description,
      };
      const pushMail = Object.assign(notificationRequest, {
        type: TypeNotificationEnum.MAIL,
      });
      this.eventEmitter.emit('purchased_order_import.confirm', pushMail);
      this.eventEmitter.emit(
        'purchased_order_import.confirm',
        notificationRequest,
      );
    }
    if (status === OrderStatusEnum.Reject) {
      notificationRequest.title = titleReject;
      notificationRequest.payload = {
        title: titleReject,
        content: productionOrderEntity.description,
      };
      const pushMail = Object.assign(notificationRequest, {
        type: TypeNotificationEnum.MAIL,
      });
      this.eventEmitter.emit('purchased_order_import.reject', pushMail);
      this.eventEmitter.emit(
        'purchased_order_import.reject',
        notificationRequest,
      );
    }

    const response = plainToInstance(
      ProductionOrderResponseDto,
      productionOrderEntity,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  async getProductionOrders(
    request: GetAllPrORequest,
  ): Promise<ResponsePayload<any>> {
    try {
      const data = await this.productionOrderRepository.findWithRelations({
        relations: ['productionOrderWarehouseDetails'],
        where: {
          status: In(request.status),
        },
      });

      const dataReturn = plainToInstance(GetAllPrOResponse, data, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  async checkItemHasExistOnProductionOrder(
    request: GetByItemIdRequestDto,
  ): Promise<any> {
    if (isArray(request.itemId))
      return await this.productionOrderDetailRepository.findByCondition({
        itemId: In(request.itemId),
      });
    return await this.productionOrderDetailRepository.findOneByCondition({
      itemId: request.itemId,
    });
  }

  async getProByWarehouse(
    request: GetOrderByWarehouseItemRequestDto,
  ): Promise<any> {
    const { id, warehouseId } = request;
    const data = await this.productionOrderRepository.getDetailByWarehouseId(
      id,
      [warehouseId],
    );
    if (!isEmpty(data)) {
      data.warehouse = await this.warehouseService.getWarehouses([warehouseId]);
    }
    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateProductionOrderDetailQcQuantity(
    payload: UpdateProductionOrderDetailQcQuantityRequestDto,
  ): Promise<any> {
    const {
      productionOrderId,
      warehouseId,
      itemId,
      qcPassQuantity,
      qcRejectQuantity,
      lotNumber,
      mfg,
    } = payload;
    if (qcPassQuantity < 0 || qcRejectQuantity < 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }
    try {
      const productionOrderWarehouse =
        await this.productionOrderWarehouseDetailRepository.findOneWithRelations(
          {
            where: {
              productionOrderId,
              warehouseId,
              itemId,
            },
            relations: ['productionOrder'],
          },
        );

      const productionOrderWarehouseLot =
        await this.productionOrderWarehouseLotRepository.findOneWithRelations({
          where: {
            productionOrderId: productionOrderId,
            warehouseId: warehouseId,
            itemId: itemId,
            lotNumber: ILike(lotNumber),
          },
        });
      if (!productionOrderWarehouse || !productionOrderWarehouseLot) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate(
              'error.PRODUCTION_ORDER_WAREHOUSE_NOT_FOUND',
            ),
          )
          .build();
      }
      if (!productionOrderWarehouse.productionOrder) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.PRODUCTION_ORDER_NOT_FOUND'),
          )
          .build();
      }
      if (
        !STATUS_TO_QC_ORDER.includes(
          productionOrderWarehouse.productionOrder.status,
        )
      ) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.PRODUCTION_ORDER_STATUS_INVALID'),
          )
          .build();
      }
      if (
        plus(qcPassQuantity, qcRejectQuantity) >
        productionOrderWarehouse.quantity
      ) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.QC_QUANTITY_INVALID'))
          .build();
      }

      productionOrderWarehouseLot.qcPassQuantity = plus(
        productionOrderWarehouseLot.qcPassQuantity || 0,
        qcPassQuantity,
      );
      productionOrderWarehouseLot.qcRejectQuantity = plus(
        productionOrderWarehouseLot.qcRejectQuantity || 0,
        qcRejectQuantity,
      );

      await this.productionOrderWarehouseLotRepository.create(
        productionOrderWarehouseLot,
      );

      return await this.updateProductionOrderWarehouseDetailQcQuantity(
        productionOrderWarehouse,
        qcPassQuantity,
        qcRejectQuantity,
      );
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error)
        .build();
    }
  }
  /**
   *
   * @param {purchasedOrderWarehouseDetail} ProductionOrderWarehouseDetail
   * @param {qcPassQuantity} number
   * @param {qcRejectQuantity} number
   * @returns
   */
  private async updateProductionOrderWarehouseDetailQcQuantity(
    productionOrderWarehouseDetail: ProductionOrderWarehouseDetail,
    qcPassQuantity: number,
    qcRejectQuantity: number,
  ): Promise<any> {
    productionOrderWarehouseDetail.qcPassQuantity = plus(
      +productionOrderWarehouseDetail.qcPassQuantity,
      qcPassQuantity,
    );
    productionOrderWarehouseDetail.qcRejectQuantity = plus(
      +productionOrderWarehouseDetail.qcRejectQuantity,
      qcRejectQuantity,
    );
    productionOrderWarehouseDetail.errorQuantity = plus(
      +productionOrderWarehouseDetail.errorQuantity,
      qcRejectQuantity,
    );
    await this.productionOrderWarehouseDetailRepository.create(
      productionOrderWarehouseDetail,
    );

    const response = plainToInstance(
      ProductionOrderWarehouseDetailResponseDto,
      productionOrderWarehouseDetail,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  public async getTotalQuantityItemProductionOrdersByCondition(
    condition: any,
  ): Promise<any> {
    const { itemIds } = condition;

    const productionOrders =
      await this.productionOrderRepository.getProductionOrderInProgress(
        condition,
      );

    if (productionOrders.length === 0) {
      return [];
    }

    const productionOrderIds = uniq(map(flatMap(productionOrders), 'id'));
    const totalQuantityItems =
      await this.productionOrderDetailRepository.getTotalQuantityItemProductionOrdersByCondition(
        {
          productionOrderIds: productionOrderIds,
          itemIds: itemIds,
        },
      );

    const response = plainToInstance(
      TotalQuantityItemProductionOrderResponseDto,
      totalQuantityItems,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  private async getListUserByRoles(userRoleSettings: any[]): Promise<any> {
    const listCode = uniq(map(flatMap(userRoleSettings), 'code'));
    if (listCode.find((c) => c !== ROLE.EMPLOYEE)) {
      const listUserRoles = await this.userService.getUsersByRoleCodes([
        ROLE.EMPLOYEE,
      ]);
      return uniq(map(flatMap(listUserRoles, 'userId')));
    }
  }
}
