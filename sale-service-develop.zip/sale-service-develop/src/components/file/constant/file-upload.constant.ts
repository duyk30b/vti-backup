import { APIPrefix } from '@constant/common';

export const FileResource = {
  POI: 'POI',
  VENDOR: 'VENDOR',
};

export const UPLOAD_FILE_ENPOINT = {
  MULTIPLE: 'files/multiple-files',
  SINGLE: 'files/single-file',
  GET_FILE: 'files/detail/:id',
};
