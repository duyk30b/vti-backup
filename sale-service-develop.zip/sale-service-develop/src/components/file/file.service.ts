import { ConfigService } from '@config/config.service';
import { APIPrefix } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { HttpClientService } from '@core/components/http-client/http-client.service';
import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import * as FormData from 'form-data';
import { DataSource, In, Not } from 'typeorm';
import { UPLOAD_FILE_ENPOINT } from './constant/file-upload.constant';
import { FileRepositoryInterface } from './interface/file.repository.interface';
import { FileServiceInterface } from './interface/file.service.interface';
import { isEmpty } from 'lodash';
import { FileEntity } from '@entities/file/file.entity';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nService } from 'nestjs-i18n';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';

@Injectable()
export class FileService implements FileServiceInterface {
  protected readonly urlConfig: any;
  protected readonly url: string;

  constructor(
    private readonly configService: ConfigService,
    private readonly httpClientService: HttpClientService,
    private readonly natsClientService: NatsClientService,

    @Inject('FileRepositoryInterface')
    private readonly fileRepository: FileRepositoryInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nService,
  ) {
    this.configService = new ConfigService();
    this.urlConfig = this.configService.get('fileService');
    this.url = `http://${
      this.urlConfig?.options?.host + ':' + this.urlConfig?.options?.port
    }`;
  }

  async uploadFiles(files: any[], resource: string): Promise<any> {
    const form = new FormData();
    form.append('service', 'sale-service');
    form.append('resource', resource);
    files.forEach((file) => {
      form.append('files', Buffer.from(file.data), {
        filename: file.filename,
      });
    });
    return await this.httpClientService.post(
      this.generateUrlFileService(UPLOAD_FILE_ENPOINT.MULTIPLE),
      form,
      {
        ...form.getHeaders(),
      },
    );
  }

  async uploadFile(file: any, resource: string): Promise<any> {
    const form = new FormData();
    form.append('service', 'sale-service');
    form.append('resource', resource);
    form.append('file', Buffer.from(file.data), {
      filename: file.filename,
    });

    return await this.httpClientService.post(
      this.generateUrlFileService(UPLOAD_FILE_ENPOINT.SINGLE),
      form,
      {
        ...form.getHeaders(),
      },
    );
  }

  async getFileById(fileId: string): Promise<any> {
    const response = await this.httpClientService.get(
      this.generateUrlFileService(
        UPLOAD_FILE_ENPOINT.GET_FILE.replace(':id', fileId),
      ),
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return response.data;
  }

  private generateUrlFileService(type: string): string {
    return `${this.url}/${APIPrefix.Version}/${type}`;
  }

  async deleteFileByIds(ids: string[]): Promise<any> {
    const fileIds = ids.toString();
    const respone = await this.httpClientService.delete(
      `${this.generateUrlFileService(
        UPLOAD_FILE_ENPOINT.MULTIPLE,
      )}?ids=${fileIds}`,
    );
    if (respone.statusCode != ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return respone.data;
  }

  async handleSaveFiles(
    resourceId: any,
    resource: any,
    oldFiles: any,
    files: any,
  ): Promise<ResponseBuilder<any> | any> {
    //handle old files
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (resourceId != null) {
        const oldFileIds = [];
        if (!isEmpty(oldFiles)) {
          oldFiles.forEach((file) => {
            if (file && !isEmpty(file)) oldFileIds.push(file.id);
          });
        }
        const deleteFiles = await this.fileRepository.findByCondition({
          resource: resource,
          resourceId: resourceId,
          fileId: Not(In(oldFileIds)),
        });
        if (!isEmpty(deleteFiles)) {
          await queryRunner.manager.softDelete(
            FileEntity,
            deleteFiles.map((deleteFile) => deleteFile.id),
          );
          await this.deleteFileByIds(
            deleteFiles.map((deleteFile) => deleteFile.fileId),
          );
        }
      }
      //handle new files
      if (!isEmpty(files)) {
        const fileResponse = await this.uploadFiles(files, resource);
        if (fileResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
          return new ResponseBuilder()
            .withCode(fileResponse.statusCode)
            .withMessage(fileResponse.message)
            .build();
        }
        const fileUploadEntities = fileResponse.data.map((fileId) =>
          this.fileRepository.createEntity({
            resourceId: resourceId,
            resource: resource,
            fileId,
          }),
        );
        await queryRunner.manager.save(fileUploadEntities);
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log('<=========>   ', error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
      await queryRunner.rollbackTransaction();
    } finally {
      await queryRunner.release();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
