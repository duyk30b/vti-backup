import { ConfigService } from '@config/config.service';
import { HttpClientModule } from '@core/components/http-client/http-client.module';
import { FileEntity } from '@entities/file/file.entity';
import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FileRepository } from '@repositories/file/file.repository';
import { FileService } from './file.service';

@Global()
@Module({
  imports: [TypeOrmModule.forFeature([FileEntity]), HttpClientModule],
  exports: [
    ConfigService,
    {
      provide: 'FileServiceInterface',
      useClass: FileService,
    },
    {
      provide: 'FileRepositoryInterface',
      useClass: FileRepository,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'FileServiceInterface',
      useClass: FileService,
    },
    {
      provide: 'FileRepositoryInterface',
      useClass: FileRepository,
    },
  ],
  controllers: [],
})
export class FileModule {}
