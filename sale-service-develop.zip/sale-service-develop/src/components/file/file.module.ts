import { Global, Module } from '@nestjs/common';
import { ConfigService } from '@config/config.service';
import { FileService } from './file.service';
import { HttpClientModule } from '@core/components/http-client/http-client.module';
import { ClientProxyFactory } from '@nestjs/microservices';
import { FileRepository } from '@repositories/file/file.repository';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FileEntity } from '@entities/file/file.entity';

@Global()
@Module({
  imports: [TypeOrmModule.forFeature([FileEntity]), HttpClientModule],
  exports: [
    {
      provide: 'FileServiceInterface',
      useClass: FileService,
    },
    {
      provide: 'FileRepositoryInterface',
      useClass: FileRepository,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'FILE_SERVICE_CLIENT',
      useFactory: (configService: ConfigService) => {
        const fileServiceOptions = configService.get('fileService');
        return ClientProxyFactory.create(fileServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'FileServiceInterface',
      useClass: FileService,
    },
    {
      provide: 'FileRepositoryInterface',
      useClass: FileRepository,
    },
  ],
  controllers: [],
})
export class FileModule {}
