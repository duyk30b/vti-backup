import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { OrganizationPaymentEntity } from '@entities/organization-payment/organization-payment.entity';
import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OrganizationPaymentRepository } from '@repositories/organization-payment/organization-payment.repository';
import { OrganizationPaymentController } from './organization-payment.controller';
import { OrganizationPaymentService } from './organization-payment.service';

@Global()
@Module({
  imports: [TypeOrmModule.forFeature([OrganizationPaymentEntity]), UserModule],
  exports: [],
  providers: [
    {
      provide: 'OrganizationPaymentRepositoryInterface',
      useClass: OrganizationPaymentRepository,
    },
    {
      provide: 'OrganizationPaymentServiceInterface',
      useClass: OrganizationPaymentService,
    },
  ],
  controllers: [OrganizationPaymentController],
})
export class OrganizationPaymentModule {}
