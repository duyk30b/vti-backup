import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  Controller,
  Inject,
  Post,
  Body,
  Put,
  Param,
  ParseIntPipe,
  Delete,
  Get,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import {
  CREATE_ORGANIZATION_PAYMENT_PERMISSION,
  UPDATE_ORGANIZATION_PAYMENT_PERMISSION,
  DELETE_ORGANIZATION_PAYMENT_PERMISSION,
  DETAIL_ORGANIZATION_PAYMENT_PERMISSION,
  LIST_ORGANIZATION_PAYMENT_PERMISSION,
  CONFIRM_ORGANIZATION_PAYMENT_PERMISSION,
  REJECT_ORGANIZATION_PAYMENT_PERMISSION,
} from '@utils/permissions/organization-payment';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { ConfirmOrganizationPaymentRequestDto } from './dto/request/confirm-organization-payment.request.dto';
import { CreateOrganizationPaymentRequestDto } from './dto/request/create-organization-payment.request.dto';
import { DeleteOrganizationPaymentRequestDto } from './dto/request/delete-organization-payment.request.dto';
import { GetOrganizationPaymentByIdsRequestDto } from './dto/request/get-organization-payment-by-ids.request.dto';
import { GetOrganizationPaymentRequestDto } from './dto/request/get-organization-payment-detail.request.dto';
import { GetOrganizationPaymentListRequestDto } from './dto/request/get-organization-payment-list.request.dto';
import { UpdateOrganizationPaymentBodyDto } from './dto/request/update-organization-payment.request.dto';
import { OrganizationPaymentResponseDto } from './dto/response/organization-payment.response.dto';
import { OrganizationPaymentServiceInterface } from './interface/organization-payment.service.interface';

@Controller('organization-payments')
export class OrganizationPaymentController {
  constructor(
    @Inject('OrganizationPaymentServiceInterface')
    private readonly organizationPaymentService: OrganizationPaymentServiceInterface,
  ) {}

  @PermissionCode(CREATE_ORGANIZATION_PAYMENT_PERMISSION.code)
  @Post('create')
  @ApiOperation({
    tags: ['OrganizationPayment'],
    summary: 'Create new tổ chức chi',
    description: 'Tạo 1 tổ chức chi mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async create(
    @Body() body: CreateOrganizationPaymentRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.organizationPaymentService.create(request);
  }

  @PermissionCode(UPDATE_ORGANIZATION_PAYMENT_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['OrganizationPayment'],
    summary: 'Update tổ chức chi',
    description: 'Sửa tổ chức chi',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async update(
    @Body() body: UpdateOrganizationPaymentBodyDto,
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.organizationPaymentService.update({ ...request, id });
  }

  @PermissionCode(DELETE_ORGANIZATION_PAYMENT_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['OrganizationPayment'],
    summary: 'Delete tổ chức chi',
    description: 'Xóa tổ chức chi',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async delete(
    @Param() param: DeleteOrganizationPaymentRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.organizationPaymentService.delete(request);
  }

  @PermissionCode(DETAIL_ORGANIZATION_PAYMENT_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['OrganizationPayment'],
    summary: 'Get tổ chức chi',
    description: 'Lấy tổ chức chi',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: OrganizationPaymentResponseDto,
  })
  public async getDetail(
    @Param() param: GetOrganizationPaymentRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.organizationPaymentService.getDetail(request);
  }

  @PermissionCode(CONFIRM_ORGANIZATION_PAYMENT_PERMISSION.code)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['OrganizationPayment'],
    summary: 'Confirm tổ chức chi',
    description: 'Xác nhận tổ chức chi',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: OrganizationPaymentResponseDto,
  })
  public async confirm(
    @Param() param: ConfirmOrganizationPaymentRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.organizationPaymentService.confirm(request);
  }

  @PermissionCode(REJECT_ORGANIZATION_PAYMENT_PERMISSION.code)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['OrganizationPayment'],
    summary: 'Reject tổ chức chi',
    description: 'Từ chối tổ chức chi',
  })
  @ApiResponse({
    status: 200,
    description: 'reject successfully',
    type: SuccessResponse,
  })
  public async reject(
    @Param() param: ConfirmOrganizationPaymentRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.organizationPaymentService.reject(request);
  }

  // @PermissionCode(LIST_ORGANIZATION_PAYMENT_PERMISSION.code)
  @Get('list')
  @ApiOperation({
    tags: ['OrganizationPayment'],
    summary: 'Get list tổ chức chi',
    description: 'Lấy danh sách tổ chức chi',
  })
  @ApiResponse({
    status: 200,
    description: 'Get list successfully',
    type: null,
  })
  public async getList(
    @Query() query: GetOrganizationPaymentListRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.organizationPaymentService.getList(request);
  }

  @MessagePattern('get_organization_payment_by_ids')
  public async getOrganizationPaymentByIds(
    @Body() body: GetOrganizationPaymentByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.organizationPaymentService.getListByIds(request);
  }
}
