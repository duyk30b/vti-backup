import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray } from 'class-validator';

export class GetOrganizationPaymentByIdsRequestDto extends BaseDto {
  @ApiProperty()
  @IsArray()
  ids: number[];
}
