import { PaginationQuery } from '@utils/pagination.query';

export class GetOrganizationPaymentListRequestDto extends PaginationQuery {}
