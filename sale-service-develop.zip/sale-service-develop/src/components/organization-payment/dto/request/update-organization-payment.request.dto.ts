import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt } from 'class-validator';
import { CreateOrganizationPaymentRequestDto } from './create-organization-payment.request.dto';

export class UpdateOrganizationPaymentBodyDto extends CreateOrganizationPaymentRequestDto {}
export class UpdateOrganizationPaymentRequestDto extends UpdateOrganizationPaymentBodyDto {
  @ApiProperty({ example: '', description: '' })
  @Transform(({ value }) => Number(value))
  @IsInt()
  id: number;
}
