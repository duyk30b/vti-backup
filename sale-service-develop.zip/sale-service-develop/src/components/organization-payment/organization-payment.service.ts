import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { OrganizationPaymentEntity } from '@entities/organization-payment/organization-payment.entity';
import { Injectable, Inject } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, ILike, In, Not } from 'typeorm';
import { CreateOrganizationPaymentRequestDto } from './dto/request/create-organization-payment.request.dto';
import { DeleteOrganizationPaymentRequestDto } from './dto/request/delete-organization-payment.request.dto';
import { GetOrganizationPaymentRequestDto } from './dto/request/get-organization-payment-detail.request.dto';
import { GetOrganizationPaymentListRequestDto } from './dto/request/get-organization-payment-list.request.dto';
import { UpdateOrganizationPaymentRequestDto } from './dto/request/update-organization-payment.request.dto';
import { OrganizationPaymentResponseDto } from './dto/response/organization-payment.response.dto';
import { OrganizationPaymentRepositoryInterface } from './interface/organization-payment.repository.interface';
import { OrganizationPaymentServiceInterface } from './interface/organization-payment.service.interface';
import { uniq } from 'lodash';
import { CostTypeEntity } from '@entities/cost-type/cost-type.entity';
import { ConfirmOrganizationPaymentRequestDto } from './dto/request/confirm-organization-payment.request.dto';
import {
  CONFIRMABLE_ORG_STATUSES,
  OrganizationPaymentStatus,
  REJECTABLE_ORG_STATUSES,
} from './organization-payment.constants';
import { GetOrganizationPaymentByIdsRequestDto } from './dto/request/get-organization-payment-by-ids.request.dto';
@Injectable()
export class OrganizationPaymentService
  implements OrganizationPaymentServiceInterface
{
  constructor(
    @InjectDataSource()
    private readonly connection: DataSource,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('OrganizationPaymentRepositoryInterface')
    private readonly organizationPaymentRepository: OrganizationPaymentRepositoryInterface,
    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateOrganizationPaymentRequestDto): Promise<any> {
    const existingOrganizationPaymentEntity =
      await this.organizationPaymentRepository.findOneByCondition({
        code: ILike(request.code),
      });
    if (existingOrganizationPaymentEntity) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'message.defineOrganizationPayment.alreadyCodeExisted',
          ),
        )
        .build();
    }
    const organizationPayment =
      this.organizationPaymentRepository.createEntity(request);
    return await this.save(organizationPayment);
  }

  async update(request: UpdateOrganizationPaymentRequestDto): Promise<any> {
    const existingOrganizationPaymentEntity =
      await this.organizationPaymentRepository.findOneById(request.id);

    if (!existingOrganizationPaymentEntity) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const existingCode =
      await this.organizationPaymentRepository.findOneByCondition({
        code: ILike(request.code),
        id: Not(request.id),
      });
    if (existingCode) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'message.defineOrganizationPayment.alreadyCodeExisted',
          ),
        )
        .build();
    }

    const organizationPayment = this.organizationPaymentRepository.updateEntity(
      existingOrganizationPaymentEntity,
      request,
    );
    return await this.save(organizationPayment);
  }

  async delete(request: DeleteOrganizationPaymentRequestDto): Promise<any> {
    const organizationPayment =
      await this.organizationPaymentRepository.findOneById(request.id);
    if (!organizationPayment) {
      return new ResponseBuilder(organizationPayment)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      organizationPayment.deletedAt = new Date();
      organizationPayment.deletedBy = request.userId;
      await queryRunner.manager.save(organizationPayment);

      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            'message.defineOrganizationPayment.deleteSuccess',
          ),
        )
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  async confirm(request: ConfirmOrganizationPaymentRequestDto): Promise<any> {
    const organizationPayment =
      await this.organizationPaymentRepository.findOneById(request.id);
    if (!organizationPayment) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CONFIRMABLE_ORG_STATUSES.includes(organizationPayment.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CONFIRM'))
        .build();
    }
    try {
      organizationPayment.status = OrganizationPaymentStatus.ACTIVE;
      await this.organizationPaymentRepository.create(organizationPayment);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('message.changeStatusSuccess'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async reject(request: ConfirmOrganizationPaymentRequestDto): Promise<any> {
    const organizationPayment =
      await this.organizationPaymentRepository.findOneById(request.id);
    if (!organizationPayment) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!REJECTABLE_ORG_STATUSES.includes(organizationPayment.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_REJECT'))
        .build();
    }
    try {
      organizationPayment.status = OrganizationPaymentStatus.CREATED;
      await this.organizationPaymentRepository.create(organizationPayment);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('message.changeStatusSuccess'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getDetail(request: GetOrganizationPaymentRequestDto): Promise<any> {
    const organizationPayment =
      await this.organizationPaymentRepository.findOneById(request.id);

    if (!organizationPayment) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const response = await this.generateRespone(organizationPayment);
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(request: GetOrganizationPaymentListRequestDto): Promise<any> {
    const { page } = request;
    const [data, count] = await this.organizationPaymentRepository.getList(
      request,
    );
    const creatorIds = data.map((item) => item.createdBy);
    const updaterIds = data.map((item) => item.updatedBy);
    const userIds = uniq([...creatorIds, ...updaterIds]);
    if (userIds.length > 0) {
      const users = await this.userService.getUsers(uniq(userIds), true);

      data.forEach((item) => {
        item.createdBy = users[item.createdBy];
        item.updatedBy = users[item.updatedBy];
      });
    }

    const dataReturn = plainToInstance(OrganizationPaymentResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getListByIds(
    request: GetOrganizationPaymentByIdsRequestDto,
  ): Promise<any> {
    const data = await this.organizationPaymentRepository.getListByIds(request);
    const creatorIds = data.map((item) => item.createdBy);
    const updaterIds = data.map((item) => item.updatedBy);
    const userIds = uniq([...creatorIds, ...updaterIds]);
    if (userIds.length > 0) {
      const users = await this.userService.getUsers(uniq(userIds), true);

      data.forEach((item) => {
        item.createdBy = users[item.createdBy];
        item.updatedBy = users[item.updatedBy];
      });
    }

    const dataReturn = plainToInstance(OrganizationPaymentResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getOrganizationPaymentByids(ids: number[]): Promise<any> {
    const organizationPayments =
      await this.organizationPaymentRepository.findByCondition({
        id: In(ids),
      });

    if (!organizationPayments) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const response = plainToInstance(
      OrganizationPaymentResponseDto,
      organizationPayments,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async save(
    organizationPaymentEntity: OrganizationPaymentEntity,
  ): Promise<ResponsePayload<any> | any> {
    try {
      const isUpdate = organizationPaymentEntity.id !== undefined;
      const result = await this.organizationPaymentRepository.create(
        organizationPaymentEntity,
      );
      const response = await this.generateRespone(result);
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            isUpdate
              ? 'message.defineOrganizationPayment.updateSuccess'
              : 'message.defineOrganizationPayment.createSuccess',
          ),
        )
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder(error)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .build();
    }
  }

  private async generateRespone(
    organizationPaymentEntity: OrganizationPaymentEntity,
  ): Promise<OrganizationPaymentResponseDto> {
    const userIds = [
      organizationPaymentEntity.createdBy,
      organizationPaymentEntity.updatedBy,
    ];
    const users = await this.userService.getUsers(uniq(userIds), true);
    organizationPaymentEntity.createdBy =
      users[organizationPaymentEntity.createdBy];
    organizationPaymentEntity.updatedBy =
      users[organizationPaymentEntity.updatedBy];
    const response = plainToInstance(
      OrganizationPaymentResponseDto,
      organizationPaymentEntity,
      {
        excludeExtraneousValues: true,
      },
    );
    return response;
  }
}
