export const ORGANIZATION_PAYMENT_RULES = {
  NAME: {
    MAX_LENGTH: 255,
  },
  CODE: {
    MAX_LENGTH: 20,
    REGEX: /^[0-9a-zA-Z]{1,20}$/,
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
  EMAIL: {
    MAX_LENGTH: 100,
  },
  PHONE: {
    MAX_LENGTH: 20,
    REGEX: /^[0-9]{1,20}$/,
  },
};

export enum Warehouse {
  AVENUE = '0',
}

export enum OrganizationPaymentStatus {
  CREATED = 0,
  ACTIVE = 1,
}

export const CONFIRMABLE_ORG_STATUSES = [OrganizationPaymentStatus.CREATED];
export const REJECTABLE_ORG_STATUSES = [OrganizationPaymentStatus.ACTIVE];
