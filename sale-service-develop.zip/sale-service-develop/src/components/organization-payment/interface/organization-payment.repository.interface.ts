import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { OrganizationPaymentEntity } from '@entities/organization-payment/organization-payment.entity';
import { CreateOrganizationPaymentRequestDto } from '../dto/request/create-organization-payment.request.dto';
import { GetOrganizationPaymentByIdsRequestDto } from '../dto/request/get-organization-payment-by-ids.request.dto';
import { GetOrganizationPaymentListRequestDto } from '../dto/request/get-organization-payment-list.request.dto';
import { UpdateOrganizationPaymentRequestDto } from '../dto/request/update-organization-payment.request.dto';

export interface OrganizationPaymentRepositoryInterface
  extends BaseInterfaceRepository<OrganizationPaymentEntity> {
  createEntity(
    request: CreateOrganizationPaymentRequestDto,
  ): OrganizationPaymentEntity;
  updateEntity(
    entity: OrganizationPaymentEntity,
    request: UpdateOrganizationPaymentRequestDto,
  ): OrganizationPaymentEntity;
  getList(request: GetOrganizationPaymentListRequestDto): Promise<any>;
  getListByIds(request: GetOrganizationPaymentByIdsRequestDto): Promise<any>;
}
