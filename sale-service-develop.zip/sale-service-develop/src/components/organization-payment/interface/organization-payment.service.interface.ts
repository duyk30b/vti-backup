import { ConfirmOrganizationPaymentRequestDto } from '../dto/request/confirm-organization-payment.request.dto';
import { CreateOrganizationPaymentRequestDto } from '../dto/request/create-organization-payment.request.dto';
import { DeleteOrganizationPaymentRequestDto } from '../dto/request/delete-organization-payment.request.dto';
import { GetOrganizationPaymentByIdsRequestDto } from '../dto/request/get-organization-payment-by-ids.request.dto';
import { GetOrganizationPaymentRequestDto } from '../dto/request/get-organization-payment-detail.request.dto';
import { GetOrganizationPaymentListRequestDto } from '../dto/request/get-organization-payment-list.request.dto';
import { UpdateOrganizationPaymentRequestDto } from '../dto/request/update-organization-payment.request.dto';

export interface OrganizationPaymentServiceInterface {
  getDetail(request: GetOrganizationPaymentRequestDto): Promise<any>;
  getList(request: GetOrganizationPaymentListRequestDto): Promise<any>;
  getListByIds(request: GetOrganizationPaymentByIdsRequestDto): Promise<any>;
  create(request: CreateOrganizationPaymentRequestDto): Promise<any>;
  update(request: UpdateOrganizationPaymentRequestDto): Promise<any>;
  delete(request: DeleteOrganizationPaymentRequestDto): Promise<any>;
  confirm(request: ConfirmOrganizationPaymentRequestDto): Promise<any>;
  reject(request: ConfirmOrganizationPaymentRequestDto): Promise<any>;
  getOrganizationPaymentByids(ids: number[]): Promise<any>;
}
