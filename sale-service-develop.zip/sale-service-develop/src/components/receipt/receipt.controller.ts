import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiConsumes, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { CreateReceiptRequestDto } from './dto/request/create-receipt.request.dto';
import { isEmpty } from 'lodash';
import { ReceiptServiceInterface } from './interface/receipt.service.interface';
import { DeleteReceiptRequestDto } from './dto/request/delete-receipt.request.dto';
import { GetReceiptListRequestDto } from './dto/request/get-receipt-list.request.dto';
import { ReceiptResponseDto } from './dto/response/receipt.response.dto';
import { GetReceiptRequestDto } from './dto/request/get-receipt-detail.request.dto';
import { MessagePattern } from '@nestjs/microservices';
import { GetReceiptByIdsRequestDto } from './dto/request/get-receipt-by-ids.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  DETAIL_RECEIPT_PERMISSION,
  LIST_RECEIPT_PERMISSION,
  RETURN_RECEIPT_PERMISSION,
} from '@utils/permissions/receipt';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { Public } from '@core/decorator/set-public.decorator';
import { ReturnReceiptRequestDto } from './dto/request/return-receipt.request.dto';
import { NATS_SALE } from '@config/nats.config';

@Controller('receipts')
export class ReceiptController {
  constructor(
    @Inject('ReceiptsServiceInterface')
    private readonly receiptService: ReceiptServiceInterface,
  ) {}

  @Post('create')
  @ApiOperation({
    tags: ['Receipt'],
    summary: 'Create new receipt',
    description: 'Tạo 1 receipt mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async create(@Body() body: CreateReceiptRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.receiptService.create(request);
  }

  @Delete('/:id')
  @ApiOperation({
    tags: ['Receipt'],
    summary: 'Delete receipt',
    description: 'Xóa receipt',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async delete(@Param() param: DeleteReceiptRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.receiptService.delete(request);
  }
  @PermissionCode(DETAIL_RECEIPT_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Receipt'],
    summary: 'Delete receipt',
    description: 'Xóa receipt',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: ReceiptResponseDto,
  })
  public async getDetail(@Param() param: GetReceiptRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.receiptService.getDetail(request);
  }
  @PermissionCode(RETURN_RECEIPT_PERMISSION.code)
  @Put('/:id/return')
  @ApiOperation({
    tags: ['Receipt'],
    summary: 'Return receipt',
    description: 'Return receipt',
  })
  @ApiResponse({
    status: 200,
    description: 'Return successfully',
    type: ReceiptResponseDto,
  })
  public async returnReceipt(
    @Param() param: ReturnReceiptRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.receiptService.returnReceipt(request);
  }

  @PermissionCode(LIST_RECEIPT_PERMISSION.code)
  @Get('list')
  @ApiOperation({
    tags: ['Receipt'],
    summary: 'Get list receipt',
    description: 'Lấy danh sách receipt',
  })
  @ApiResponse({
    status: 200,
    description: 'Get list successfully',
    type: null,
  })
  public async getList(@Query() query: GetReceiptListRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.receiptService.getList(request);
  }

  @MessagePattern(`${NATS_SALE}.get_receipt_by_ids`)
  public async getReceiptByIds(
    @Body() body: GetReceiptByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.receiptService.getReceiptByIds(request.ids);
  }

  @Public()
  @Post('/import')
  @ApiOperation({
    tags: ['Recept'],
    summary: 'Import Recept',
  })
  @ApiResponse({
    status: 200,
    description: 'Import successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async importReceipt(
    @Body() body: FileUpdloadRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.receiptService.importReceipt(request);
  }

  @MessagePattern(`${NATS_SALE}.get_receipt_by_code`)
  async getReceiptByCode(code: string): Promise<any> {
    return await this.receiptService.getReceiptByCode(code);
  }
}
