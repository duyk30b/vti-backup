import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ReceiptEntity } from '@entities/receipt/receipt.entity';
import { Inject, Injectable, Logger } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, ILike, In, Not } from 'typeorm';
import {
  CreateReceiptDetailRequestDto,
  CreateReceiptRequestDto,
} from './dto/request/create-receipt.request.dto';
import { ReceiptServiceInterface } from './interface/receipt.service.interface';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ReceiptRepositoryInterface } from './interface/receipt.repository.interface';
import { DeleteReceiptRequestDto } from './dto/request/delete-receipt.request.dto';
import { GetReceiptRequestDto } from './dto/request/get-receipt-detail.request.dto';
import { ReceiptResponseDto } from './dto/response/receipt.response.dto';
import { plainToClass, plainToInstance } from 'class-transformer';
import { GetReceiptListRequestDto } from './dto/request/get-receipt-list.request.dto';
import { PagingResponse } from '@utils/paging.response';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { uniq, map, keyBy, isEmpty } from 'lodash';
import { ReceiptDetailRepository } from '@repositories/receipt/receipt-detail.repository';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { SourceRepositoryInterface } from '@components/source/interface/sources.repository.interface';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { FILE_TYPE, IMPORT_CONST } from '@constant/import.constant';
import * as Papa from 'papaparse';
import * as moment from 'moment';
import { UpdateReceiptRequestDto } from './dto/request/update-receipt.request.dto';
import {
  CAN_NOT_UPDATE_STATUS_RECEIPT,
  EventSyncReceiptEnum,
  CURRENCY,
  EXCHANGE_RATE_VND,
  CURRENCY_VND,
  RECEIPT_STATUS,
} from './receipt.contant';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { ReturnReceiptRequestDto } from './dto/request/return-receipt.request.dto';
import { PurchasedOrderImportRepositoryInterface } from '@components/purchased-order-import/interface/purchased-order-import.repository.interface';
import { PO_IMPORT_STATUS_NOT_USED_RECEIPT } from '@components/purchased-order-import/purchased-order-import.contant';
import { OrderStatusEnum } from '@constant/common';

const CSV_COLUMN_HEADER_INDEX_MAP = {
  A: 0,
  B: 1,
  C: 2,
  D: 3,
  E: 4,
  F: 5,
  G: 6,
  H: 7,
  I: 8,
  J: 9,
  K: 10,
  L: 11,
  M: 12,
  N: 13,
  O: 14,
  P: 15,
  Q: 16,
  R: 17,
  S: 18,
};

@Injectable()
export class ReceiptService implements ReceiptServiceInterface {
  private readonly logger = new Logger(ReceiptService.name);
  constructor(
    @InjectDataSource()
    private readonly connection: DataSource,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ReceiptRepositoryInterface')
    private readonly receiptRepository: ReceiptRepositoryInterface,

    @Inject('ReceiptDetailRepositoryInterface')
    private readonly receiptDetailRepository: ReceiptDetailRepository,

    @Inject('PurchasedOrderImportRepositoryInterface')
    private readonly purchasedOrderImportRepository: PurchasedOrderImportRepositoryInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,

    private eventEmitter: EventEmitter2,

    @Inject('SourceRepositoryInterface')
    private readonly sourceRepository: SourceRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateReceiptRequestDto): Promise<any> {
    const { code, items } = request;
    const existingReceipt = await this.receiptRepository.findOneByCondition({
      code: ILike(code),
    });
    if (existingReceipt) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_IS_EXIST'))
        .build();
    }

    const codes = uniq(map(items, 'code'));
    const itemsExist = await this.itemService.getItemByCodes(codes);
    if (!itemsExist || codes.length !== itemsExist.length) {
      const itemIdsExist = itemsExist ? itemsExist.map((e) => e.code) : [];
      return new ResponseBuilder({
        invalidItems: items.filter((e) => !itemIdsExist.includes(e.code)),
      })
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }
    const itemExistByCodes = keyBy(itemsExist, 'code');

    const receiptDetailEntities = items.map((item) => {
      const receiptDetailEntity = this.receiptDetailRepository.createEntity({
        ...item,
        itemId: itemExistByCodes[item.code]?.id,
        userId: 1, //request.userId,
      } as CreateReceiptDetailRequestDto);
      return receiptDetailEntity;
    });
    const receiptEntity = this.receiptRepository.createEntityWithRelation(
      request,
      receiptDetailEntities,
    );

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(receiptEntity);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error);
    } finally {
      await queryRunner.release();
    }
    const receipt = await this.receiptRepository.findOneByCondition({
      code: code,
    });
    this.eventEmitter.emit(EventSyncReceiptEnum.Update, receipt.id);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async delete(request: DeleteReceiptRequestDto): Promise<any> {
    const receipt = await this.receiptRepository.findOneWithRelations({
      where: { id: request.id },
      relations: ['receiptDetails'],
    });
    if (!receipt) {
      return new ResponseBuilder(receipt)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    receipt.deletedAt = new Date();
    receipt.deletedBy = request.userId;
    const removedReceiptDetailEntities = receipt.receiptDetails.map((item) => {
      item.deletedAt = new Date();
      item.deletedBy = request.userId;
      return item;
    });

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(receipt);
      await queryRunner.manager.save(removedReceiptDetailEntities);
      await queryRunner.commitTransaction();

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error);
    } finally {
      await queryRunner.release();
    }
  }

  async getDetail(request: GetReceiptRequestDto): Promise<any> {
    const receipt = await this.receiptRepository.findOneWithRelations({
      where: { id: request.id },
      relations: ['receiptDetails'],
    });

    if (!receipt) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const response = await this.generateRespone(receipt);
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(request: GetReceiptListRequestDto): Promise<any> {
    const { page } = request;
    const isPurchasedOrderImport = request.filter?.find(
      (item) => item.column === 'purchasedOrderImport' && +item.text === 1,
    );

    if (!isEmpty(isPurchasedOrderImport)) {
      const poImportUsedReceipts =
        await this.purchasedOrderImportRepository.findByCondition({
          status: Not(In(PO_IMPORT_STATUS_NOT_USED_RECEIPT)),
        });

      request.filter = [
        ...request.filter,
        {
          column: 'notCodes',
          text: poImportUsedReceipts.map((e) => e.receiptNumber).join(','),
        },
      ];
    }

    const [data, count] = await this.receiptRepository.getList(request);
    const creatorIds = uniq(data.map((item) => item.createdBy));
    const updaterIds = uniq(data.map((item) => item.updatedBy));
    const userIds = [...creatorIds, ...updaterIds];
    if (!isEmpty(userIds)) {
      const users = await this.userService.getUsers(uniq(userIds), true);

      data.forEach((item) => {
        item.createdBy = users[item.createdBy];
        item.updatedBy = users[item.updatedBy];
      });
    }

    const dataReturn = plainToClass(ReceiptResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getReceiptByIds(ids: number[]): Promise<any> {
    const receipts = await this.receiptRepository.findByCondition({
      id: In(ids),
    });

    if (!receipts) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const response = plainToInstance(ReceiptResponseDto, receipts, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async generateRespone(
    receiptEntity: ReceiptEntity,
  ): Promise<ReceiptResponseDto> {
    const userIds = [receiptEntity.createdBy, receiptEntity.updatedBy];
    if (!isEmpty(userIds)) {
      const users = await this.userService.getUsers(uniq(userIds), true);
      receiptEntity.createdBy = users[receiptEntity.createdBy];
      receiptEntity.updatedBy = users[receiptEntity.updatedBy];
    }

    const itemIds = receiptEntity.receiptDetails.map((item) => item.itemId);
    const items = await this.itemService.getItems(itemIds);
    const itemByIds = keyBy(
      items.map((item) => ({
        ...item,
      })),
      'itemId',
    );

    const warehouse = await this.warehouseService.getDetailById(
      receiptEntity.warehouseId,
    );

    receiptEntity.receiptDetails = receiptEntity.receiptDetails.map((item) => ({
      ...item,
      requestedQuantity: item.quantity,
      item: itemByIds[item.itemId],
    }));
    const response = plainToInstance(
      ReceiptResponseDto,
      {
        ...receiptEntity,
        warehouse,
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return response;
  }

  async getReceiptByCode(code: string): Promise<any> {
    const result = await this.receiptRepository.getReceiptByCode(code);
    if (!result) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    return result;
  }

  /**
   *
   * @param request
   * @returns
   */
  async importReceipt(request: FileUpdloadRequestDto): Promise<any> {
    const file = request.file[0];
    const buffer = file?.data;
    const mimeType = file?.mimetype;

    if (mimeType != FILE_TYPE.CSV.MIME_TYPE)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.IMPORT_INVALID_FILE_TYPE_MIME_TYPE'),
        )
        .build();

    let dataRows;
    try {
      const content = Buffer.from(buffer).toString(
        IMPORT_CONST.DEFAULT_ENCODING.TEXT as unknown as BufferEncoding,
      );

      dataRows = Papa.parse(content).data;
      const checkCurrency = isEmpty(dataRows[9][CSV_COLUMN_HEADER_INDEX_MAP.K])
        ? CURRENCY.IS_VND
        : CURRENCY.NOT_VND;
      const receiptInformation = await this.getReceiptInformationFromCSV(
        dataRows,
        checkCurrency,
      );
      const receiptDetails = await this.getReceiptDetailFromCSV(
        dataRows,
        checkCurrency,
      );
      if (isEmpty(receiptInformation.code)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.NOT_READ_CODE_RECEIPT'))
          .build();
      }
      const requestToCreate = {
        code: receiptInformation.code,
        receiptDate: receiptInformation.receiptDate,
        warehouseId: receiptInformation.warehouse?.id,
        receiptNumber: receiptInformation.receiptNumber,
        contractNumber: receiptInformation.contractNumber,
        department: receiptInformation.department,
        explaination: receiptInformation.explaination,
        purpose: receiptInformation.purpose,
        items: receiptDetails,
        deliver: receiptInformation.deliver,
        userId: 1, // request.userId,
      } as CreateReceiptRequestDto;

      return await this.create(requestToCreate);
    } catch (error) {
      this.logger.error(
        `IMPORT RECEIPT DATA RAW ERROR: ${JSON.stringify(dataRows)}`,
      );
      this.logger.error(`IMPORT RECEIPT ERROR LOG: ${JSON.stringify(error)}`);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  /**
   *
   * @param dataRows
   * @returns
   */
  private async getReceiptInformationFromCSV(
    dataRows: any,
    checkTypeMoney: number,
  ) {
    let code,
      receiptNumber,
      warehouseCode,
      receiptDate,
      warehouses,
      contractNumber,
      department,
      explaination,
      purpose,
      deliver;
    let columnCode,
      columnReceiptNumber,
      columnwarehouseCode,
      columnReceiptDate,
      columnContractNumber,
      columnDepartment,
      columnExplaination,
      columnPurpose,
      columnDeliver;
    switch (checkTypeMoney) {
      case CURRENCY.IS_VND:
        columnCode = CSV_COLUMN_HEADER_INDEX_MAP.M;
        columnReceiptNumber = CSV_COLUMN_HEADER_INDEX_MAP.M;
        columnReceiptDate = CSV_COLUMN_HEADER_INDEX_MAP.E;
        columnContractNumber = CSV_COLUMN_HEADER_INDEX_MAP.C;
        columnDepartment = CSV_COLUMN_HEADER_INDEX_MAP.H;
        columnDeliver = CSV_COLUMN_HEADER_INDEX_MAP.C;
        columnPurpose = CSV_COLUMN_HEADER_INDEX_MAP.H;
        columnExplaination = CSV_COLUMN_HEADER_INDEX_MAP.C;
        columnwarehouseCode = CSV_COLUMN_HEADER_INDEX_MAP.C;
        break;
      case CURRENCY.NOT_VND:
        columnCode = CSV_COLUMN_HEADER_INDEX_MAP.N;
        columnReceiptNumber = CSV_COLUMN_HEADER_INDEX_MAP.N;
        columnReceiptDate = CSV_COLUMN_HEADER_INDEX_MAP.E;
        columnContractNumber = CSV_COLUMN_HEADER_INDEX_MAP.C;
        columnDepartment = CSV_COLUMN_HEADER_INDEX_MAP.I;
        columnDeliver = CSV_COLUMN_HEADER_INDEX_MAP.C;
        columnPurpose = CSV_COLUMN_HEADER_INDEX_MAP.I;
        columnExplaination = CSV_COLUMN_HEADER_INDEX_MAP.C;
        columnwarehouseCode = CSV_COLUMN_HEADER_INDEX_MAP.C;
        break;
      default:
        break;
    }
    try {
      code = dataRows[0][columnCode].split(':')[1]?.trim();
      receiptNumber = dataRows[1][columnReceiptNumber].split(':')[1]?.trim();
      receiptDate = dataRows[3][columnReceiptDate].split(':')[1]?.trim();
      contractNumber = dataRows[6][columnContractNumber].split(':')[1]?.trim();
      department = dataRows[5][columnDepartment].split(':')[1]?.trim();
      deliver = dataRows[5][columnDeliver].split(':')[1]?.trim();
      purpose = dataRows[6][columnPurpose].split(':')[1]?.trim();
      explaination = dataRows[7][columnExplaination].split(':')[1]?.trim();
      warehouseCode = dataRows[8][columnwarehouseCode]
        .split('-')[0]
        .split(':')[1]
        ?.trim();

      warehouses = await this.warehouseService.getWarehouseByCodes([
        warehouseCode,
      ]);
    } catch (e) {
      console.error(e);
    }

    return {
      code,
      receiptNumber,
      receiptDate: new Date(moment(receiptDate, 'DD/MM/YYYY').format()),
      warehouse: warehouses[0],
      contractNumber,
      department,
      explaination,
      purpose,
      deliver,
    };
  }

  /**
   *
   * @param dataRows
   * @returns
   */
  private async getReceiptDetailFromCSV(dataRows: any, checkTypeMoney: number) {
    const items = [];
    let columnCode,
      columnOrderQuantity,
      columnQuantity,
      columnPrice,
      columnAmount,
      columnDebitAccount,
      columnCreditAccount,
      columnCurrencyCode,
      columnExchangeRate;
    switch (checkTypeMoney) {
      case CURRENCY.IS_VND:
        columnCode = CSV_COLUMN_HEADER_INDEX_MAP.B;
        columnOrderQuantity = CSV_COLUMN_HEADER_INDEX_MAP.G;
        columnQuantity = CSV_COLUMN_HEADER_INDEX_MAP.J;
        columnPrice = CSV_COLUMN_HEADER_INDEX_MAP.L;
        columnAmount = CSV_COLUMN_HEADER_INDEX_MAP.N;
        columnDebitAccount = CSV_COLUMN_HEADER_INDEX_MAP.P;
        columnCreditAccount = CSV_COLUMN_HEADER_INDEX_MAP.Q;
        break;
      case CURRENCY.NOT_VND:
        columnCode = CSV_COLUMN_HEADER_INDEX_MAP.B;
        columnOrderQuantity = CSV_COLUMN_HEADER_INDEX_MAP.G;
        columnQuantity = CSV_COLUMN_HEADER_INDEX_MAP.H;
        columnPrice = CSV_COLUMN_HEADER_INDEX_MAP.O;
        columnAmount = CSV_COLUMN_HEADER_INDEX_MAP.P;
        columnDebitAccount = CSV_COLUMN_HEADER_INDEX_MAP.R;
        columnCreditAccount = CSV_COLUMN_HEADER_INDEX_MAP.S;
        columnCurrencyCode = CSV_COLUMN_HEADER_INDEX_MAP.K;
        columnExchangeRate = CSV_COLUMN_HEADER_INDEX_MAP.M;
        break;
      default:
        break;
    }
    try {
      for (let i = 11; i < 21; i++) {
        const itemRow = dataRows[i];
        if (itemRow[CSV_COLUMN_HEADER_INDEX_MAP.A]?.trim() == '') break;

        items.push({
          code: itemRow[columnCode],
          orderQuantity: this.readDecimal(itemRow[columnOrderQuantity] || 0),
          quantity: this.readDecimal(itemRow[columnQuantity] || '0'),
          price: this.readDecimal(itemRow[columnPrice] || '0'),
          amount: this.readDecimal(itemRow[columnAmount] || '0'),
          debitAccount: itemRow[columnDebitAccount],
          creditAccount: itemRow[columnCreditAccount],
          currencyCode: itemRow[columnCurrencyCode] || CURRENCY_VND,
          exchangeRate: this.readDecimal(
            itemRow[columnExchangeRate] || EXCHANGE_RATE_VND,
          ),
        });
      }
    } catch (e) {
      console.error(e);
    }
    return items;
  }

  async updateStatus(request: UpdateReceiptRequestDto): Promise<any> {
    const { receiptCode } = request;
    const receipt = await this.receiptRepository.findOneByCondition({
      code: receiptCode,
    });
    if (receipt?.status) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.RECEIPT_USED'))
        .build();
    }
    receipt.status = RECEIPT_STATUS.USED;
    const queryRunner = await this.connection.createQueryRunner();
    const result = await queryRunner.manager.save(receipt);
    this.eventEmitter.emit(EventSyncReceiptEnum.Update, receipt.id);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
  async returnReceipt(request: ReturnReceiptRequestDto): Promise<any> {
    const { id } = request;
    const receipt = await this.receiptRepository.findOneByCondition({
      id: id,
    });
    if (!receipt) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (CAN_NOT_UPDATE_STATUS_RECEIPT.includes(receipt.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.RECEIPT_IS_IN_STATUS_EXPORT_WAREHOUSE',
          ),
        )
        .build();
    }

    const purchasedOderImportUseReceipt =
      await this.purchasedOrderImportRepository.findByCondition({
        receiptNumber: receipt.code,
        status: OrderStatusEnum.Confirmed,
      });
    if (!isEmpty(purchasedOderImportUseReceipt)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.THIS_RECEIPT_HAS_ALREADY_USED_ON_PO_IMPORT_IN_THE_CONFIRM_STATE_THE_RECEIPT_CAN_NOT_CANCELED',
          ),
        )
        .build();
    }
    if (receipt.status === RECEIPT_STATUS.USED) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.RECEIPT_USED'))
        .build();
    }
    receipt.status = RECEIPT_STATUS.CANCELED;
    const queryRunner = await this.connection.createQueryRunner();
    const result = await queryRunner.manager.save(receipt);
    this.eventEmitter.emit(EventSyncReceiptEnum.Update, receipt.id);
    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private readDecimal(num: string | number): number {
    num = num.toString();
    const number = num.replace(/\s/g, '');
    if (number.includes(',')) {
      const numReturn = parseFloat(
        number.split(',')[0] + '.' + number.split(',')[1],
      );
      return numReturn;
    }
    return parseFloat(number);
  }
}
