import { ItemService } from '@components/item/item.service';
import { SyncDataModule } from '@components/sync-data/sync-data.module';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { WarehouseService } from '@components/warehouse/warehouse.service';
import { QUEUES_NAME_ENUM } from '@constant/common';
import { PurchasedOrderImportEntity } from '@entities/purchased-order-import/purchased-order-import.entity';
import { ReceiptDetailEntity } from '@entities/receipt/receipt-detail.entity';
import { ReceiptEntity } from '@entities/receipt/receipt.entity';
import { SourceEntity } from '@entities/source/source.entity';
import { BullModule } from '@nestjs/bull';
import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PurchasedOrderImportRepository } from '@repositories/purchased-order-import/purchased-order-import.repository';
import { ReceiptDetailRepository } from '@repositories/receipt/receipt-detail.repository';
import { ReceiptRepository } from '@repositories/receipt/receipt.repository';
import { SourceRepository } from '@repositories/source/source.repository';
import { SyncReceiptListener } from './listeners/sync-to-hq.listener';
import { ReceiptController } from './receipt.controller';
import { ReceiptService } from './receipt.service';

@Global()
@Module({
  imports: [
    TypeOrmModule.forFeature([
      ReceiptEntity,
      ReceiptDetailEntity,
      SourceEntity,
      PurchasedOrderImportEntity,
    ]),
    BullModule.registerQueue({
      name: QUEUES_NAME_ENUM.SYNC_DATA_QUEUE,
    }),
    SyncDataModule,
    UserModule,
  ],
  exports: [],
  providers: [
    {
      provide: 'ReceiptRepositoryInterface',
      useClass: ReceiptRepository,
    },
    {
      provide: 'ReceiptDetailRepositoryInterface',
      useClass: ReceiptDetailRepository,
    },
    {
      provide: 'PurchasedOrderImportRepositoryInterface',
      useClass: PurchasedOrderImportRepository,
    },
    {
      provide: 'ReceiptsServiceInterface',
      useClass: ReceiptService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'SourceRepositoryInterface',
      useClass: SourceRepository,
    },
    SyncReceiptListener,
  ],
  controllers: [ReceiptController],
})
export class ReceiptModule {}
