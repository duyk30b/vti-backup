import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ReceiptDetailEntity } from '@entities/receipt/receipt-detail.entity';
import { CreateReceiptDetailRequestDto } from '../dto/request/create-receipt.request.dto';

export interface ReceiptDetailRepositoryInterface
  extends BaseInterfaceRepository<ReceiptDetailEntity> {
  createEntity(request: CreateReceiptDetailRequestDto): ReceiptDetailEntity;
}
