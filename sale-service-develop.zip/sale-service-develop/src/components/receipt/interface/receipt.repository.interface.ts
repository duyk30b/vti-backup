import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ReceiptDetailEntity } from '@entities/receipt/receipt-detail.entity';
import { ReceiptEntity } from '@entities/receipt/receipt.entity';
import { CreateReceiptRequestDto } from '../dto/request/create-receipt.request.dto';
import { GetReceiptListRequestDto } from '../dto/request/get-receipt-list.request.dto';

export interface ReceiptRepositoryInterface
  extends BaseInterfaceRepository<ReceiptEntity> {
  createEntityWithRelation(
    request: CreateReceiptRequestDto,
    receiptDetailEntities: ReceiptDetailEntity[],
  ): ReceiptEntity;
  getList(request: GetReceiptListRequestDto): Promise<any>;
  getReceiptByCode(code: string): Promise<any>;
}
