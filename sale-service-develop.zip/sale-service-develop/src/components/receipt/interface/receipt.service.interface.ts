import { CreateReceiptRequestDto } from '../dto/request/create-receipt.request.dto';
import { DeleteReceiptRequestDto } from '../dto/request/delete-receipt.request.dto';
import { GetReceiptRequestDto } from '../dto/request/get-receipt-detail.request.dto';
import { GetReceiptListRequestDto } from '../dto/request/get-receipt-list.request.dto';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { UpdateReceiptRequestDto } from '../dto/request/update-receipt.request.dto';
import { ReturnReceiptRequestDto } from '../dto/request/return-receipt.request.dto';
export interface ReceiptServiceInterface {
  getDetail(request: GetReceiptRequestDto): Promise<any>;
  getList(request: GetReceiptListRequestDto): Promise<any>;
  create(request: CreateReceiptRequestDto): Promise<any>;
  importReceipt(request: FileUpdloadRequestDto): Promise<any>;
  delete(request: DeleteReceiptRequestDto): Promise<any>;
  getReceiptByIds(ids: number[]): Promise<any>;
  updateStatus(request: UpdateReceiptRequestDto): Promise<any>;
  returnReceipt(request: ReturnReceiptRequestDto): Promise<any>;
  getReceiptByCode(code: string): Promise<any>;
}
