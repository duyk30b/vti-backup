export const RECEIPT_STATUS = {
  EMPTY: 0,
  USED: 1,
  CANCELED: 2,
};
export const CAN_NOT_UPDATE_STATUS_RECEIPT = [
  RECEIPT_STATUS.USED,
  RECEIPT_STATUS.CANCELED,
];

export const VALID_STATUS_RECEIPT = [
  RECEIPT_STATUS.USED,
  RECEIPT_STATUS.CANCELED,
];

export enum EventSyncReceiptEnum {
  Create = 'event.Receipt.create',
  Update = 'event.Receipt.update',
}
export const CURRENCY = {
  IS_VND: 0,
  NOT_VND: 1,
};

export const CURRENCY_VND = 'VNĐ';
export const EXCHANGE_RATE_VND = 1;
