import { DatasyncServiceInterface } from '@components/datasync/interface/datasync.service.interface';
import { SyncDataRequestDto } from '@components/sync-data/dto/request/sync-data.request.dto';
import { SyncDataToHQListener } from '@components/sync-data/listeners/sync-data-to-hq.listener';
import {
  ProcessSyncDataEnum,
  SYNC_TO_SYSTEM_ENUM,
  TypeTransactionDataSyncEnum,
} from '@components/sync-data/sync-data.constant';
import { QUEUES_NAME_ENUM } from '@constant/common';
import { InjectQueue } from '@nestjs/bull';
import { Inject } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import Queue from 'bull';
import { ItemService } from '@components/item/item.service';
import { UserService } from '@components/user/user.service';
import { PushQueueEvent } from '@components/sync-data/event/push-queue.event';
import { ReceiptRepositoryInterface } from '../interface/receipt.repository.interface';
import { EventSyncReceiptEnum } from '../receipt.contant';
import { keyBy } from 'lodash';

export class SyncReceiptListener extends SyncDataToHQListener {
  constructor(
    @InjectQueue(QUEUES_NAME_ENUM.SYNC_DATA_QUEUE)
    protected queue: Queue,

    @Inject('DatasyncServiceInterface')
    protected datasyncService: DatasyncServiceInterface,

    @Inject('ReceiptRepositoryInterface')
    private readonly receiptRepository: ReceiptRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserService,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemService,
  ) {
    super(queue, datasyncService);
  }

  async getDetailReceipt(id: number): Promise<any> {
    const company = await this.userService.getCompanyDefault();

    let data;
    data = await this.receiptRepository.findOneWithRelations({
      where: { id: id },
      relations: ['receiptDetails'],
    });
    const itemIds = data.receiptDetails.map((item) => item.itemId);
    const items = await this.itemService.getItems(itemIds);
    const itemByIds = keyBy(
      items.map((item) => ({
        ...item,
      })),
      'itemId',
    );

    const dataSync = [];
    data?.receiptDetails.map((item) => {
      const itemSync = {
        code: data?.code,
        contractNumber: data?.contractNumber,
        receiptNumber: data?.receiptNumber,
        status: data?.status,
        receiptDate: data?.receiptDate,
        companyCode: company.code,
        itemCode: item?.itemCode,
        itemName: itemByIds[item.itemId]?.name,
        quantity: Number(item?.quantity),
        orderQuantity: Number(item?.orderQuantity),
        price: Number(item?.price),
        amount: Number(item?.amount),
        syncCode: company.code,
      };
      dataSync.push(itemSync);
    });

    return { syncCode: company.code, dataSync };
  }

  @OnEvent(EventSyncReceiptEnum.Update)
  async updateItem(id: number) {
    const { syncCode, dataSync } = await this.getDetailReceipt(id);
    const request = {
      data: {
        syncCode: syncCode,
        dataSync: dataSync,
      },
    } as SyncDataRequestDto;
    await this.pushQueue(
      this.getInfoQueue(ProcessSyncDataEnum.UpdateReceipt, dataSync),
      request,
    );

    await this.pushQueue(
      this.getInfoQueue(ProcessSyncDataEnum.UpdateReceiptHQ, dataSync),
      request,
    );
  }

  private getInfoQueue(process: string, data) {
    const infoQueue = new PushQueueEvent();
    infoQueue.process = process;
    infoQueue.resourceCode = data.code;
    infoQueue.typeTransaction = TypeTransactionDataSyncEnum.PO_IMPORT;
    infoQueue.toSystem = SYNC_TO_SYSTEM_ENUM.COMPANY_HQ;
    return infoQueue;
  }
}
