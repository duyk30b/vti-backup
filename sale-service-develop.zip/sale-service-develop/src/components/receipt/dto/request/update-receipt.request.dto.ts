import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsString, } from 'class-validator';

export class UpdateReceiptRequestDto extends BaseDto {
  @ApiProperty()
  @IsString()
  receiptCode: string;
}
