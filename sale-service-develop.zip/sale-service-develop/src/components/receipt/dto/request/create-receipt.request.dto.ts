import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsDateString,
  IsInt,
  IsNumber,
  IsString,
  ValidateNested,
  IsOptional,
} from 'class-validator';

export class ReceiptDetailRequestDto {
  @ApiProperty()
  @IsString()
  code: string;

  @ApiProperty()
  @IsNumber()
  quantity: number;

  @ApiProperty()
  @IsNumber()
  price: number;

  @ApiProperty()
  @IsNumber()
  amount: number;

  @ApiProperty()
  @IsNumber()
  @IsOptional()
  currencyCode: string;

  @ApiProperty()
  @IsNumber()
  @IsOptional()
  exchangeRate: number;
}

export class CreateReceiptRequestDto extends BaseDto {
  @ApiProperty()
  @IsString()
  code: string;

  @ApiProperty()
  @IsDateString()
  receiptDate: Date;

  @ApiProperty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsString()
  contractNumber: string;

  @ApiProperty()
  @IsString()
  receiptNumber: string;

  @ApiProperty()
  @IsString()
  deliver: string;

  @ApiProperty()
  @IsString()
  department: string;

  @ApiProperty()
  @IsString()
  explaination: string;

  @ApiProperty()
  @IsString()
  purpose: string;

  @ApiProperty()
  @IsArray()
  @Type(() => ReceiptDetailRequestDto)
  @ValidateNested({ each: true })
  items: ReceiptDetailRequestDto[];
}

export class CreateReceiptDetailRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiPropertyOptional()
  @IsString()
  code: string;

  @ApiProperty()
  @IsNumber()
  orderQuantity: number;

  @ApiProperty()
  @IsNumber()
  quantity: number;

  @ApiProperty()
  @IsNumber()
  price: number;

  @ApiProperty()
  @IsNumber()
  amount: number;

  @ApiProperty()
  @IsString()
  debitAccount: string;

  @ApiProperty()
  @IsString()
  creditAccount: string;

  @ApiProperty()
  @IsNumber()
  @IsOptional()
  currencyCode: string;

  @ApiProperty()
  @IsNumber()
  @IsOptional()
  exchangeRate: number;
}
