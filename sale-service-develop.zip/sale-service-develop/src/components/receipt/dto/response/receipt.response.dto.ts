import { UserResponseDto } from '@components/user/dto/response/user.dto.response';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class WarehouseResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class UnitResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ItemWarehouseSource {
  @Expose()
  warehouseId: number;

  @Expose()
  accounting: string;

  @Expose()
  sourceId: number;

  @Expose()
  sourceName: string;

  @Expose()
  sourceCode: string;

  @Expose()
  accountIdentifier: string;
}

class ItemResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  @Type(() => UnitResponseDto)
  itemUnit: UnitResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => ItemWarehouseSource)
  itemWarehouseSources: ItemWarehouseSource[];
}

class ReceiptDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  @Type(() => ItemResponse)
  item: ItemResponse[];

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  price: number;

  @ApiProperty()
  @Expose()
  amount: number;

  @ApiProperty()
  @Expose()
  debitAccount: string;

  @ApiProperty()
  @Expose()
  creditAccount: string;
}

export class ReceiptResponseDto {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  receiptDate: string;

  @ApiProperty()
  @Expose()
  contractNumber: string;

  @ApiProperty()
  @Expose()
  receiptNumber: string;

  @ApiProperty()
  @Expose()
  deliver: string;

  @ApiProperty()
  @Expose()
  purpose: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  department: string;

  @ApiProperty()
  @Expose()
  explaination: string;

  @ApiProperty()
  @Expose()
  @Type(() => WarehouseResponse)
  warehouse: WarehouseResponse;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  createdBy: UserResponseDto;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  updatedBy: UserResponseDto;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @Expose({ name: 'receiptDetails' })
  @Type(() => ReceiptDetail)
  items: ReceiptDetail[];
}
