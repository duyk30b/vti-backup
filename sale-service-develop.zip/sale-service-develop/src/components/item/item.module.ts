import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ClientProxyFactory } from '@nestjs/microservices';
import { ItemService } from './item.service';
import { ConfigService } from '@config/config.service';
import { NatsClientModule } from '@core/transporter/nats-transporter/nats-client.module';

@Global()
@Module({
  imports: [ConfigModule, NatsClientModule],
  exports: [
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
  ],
  controllers: [],
})
export class ItemModule {}
