import { CheckStockAvailableDto } from '../dto/request/check-stock-available.request.dto';
import { CreateItemPlanningQuantitiesRequestDto } from '../dto/request/create-item-planning-quantity.request.dto';
import { GetPositionItemsByConditionsRequestDto } from '../dto/request/filter-position-items-by-conditions.request.dto';
import { GetItemStockAvailableRequestDto } from '../dto/request/get-item-stock-available.request.dto';
import { GetItemWarehouseStockRequestDto } from '../dto/request/get-item-stock.dto';
import { GetItemWarehouseByItemIdsAndWarehouseIdsRequestDto } from '../dto/request/get-item-warehouse-by-item-ids-and-warehouse-ids.request.dto';
import { SuggestLocatorWithItemQuantityRequest } from '../dto/request/suggest-locator-with-item-quantity.request.dto';
import { UpdateItemWarehousePlanningQuantityRequestDto } from '../dto/request/update-item-warehouse-planning-quantity.request.dto';
import { ItemResponseDto } from '../dto/response/item.dto.response';
import { UpdateStockFromOrderRequest } from '../dto/request/update-stock-from-order.request.dto';

export interface ItemServiceInterface {
  getItems(
    itemIds: any[],
    basicInfor?: boolean,
    serilize?: boolean,
  ): Promise<ItemResponseDto[]>;
  checkStockAvailable(request: CheckStockAvailableDto): Promise<any>;
  getItemByCodes(codes: string[]): Promise<any[]>;
  getItemWarehouseSheflFloorByLotNumbers(
    floorId: number,
    lotNumbers: string[],
  ): Promise<any>;
  getPackageByIds(ids: number[]): Promise<any[]>;
  getPositionItemsByCondition(
    request: GetPositionItemsByConditionsRequestDto,
  ): Promise<any>;
  updateItemWarehousePlanningQuantity(
    request: UpdateItemWarehousePlanningQuantityRequestDto,
  ): Promise<any>;
  getPalletByIds(ids: number[], packagePalletCondition?: any[]): Promise<any[]>;
  getItemWarehouseByItemIdsAndWarehouseIds(
    payload: GetItemWarehouseByItemIdsAndWarehouseIdsRequestDto,
  ): Promise<any>;
  getItemPlanningQuantityByOrder(
    itemIds: number[],
    warehouseId: number,
    serilize?: boolean,
  ): Promise<any>;
  getItemPlanningQuantityByOrderId(
    orderId: number,
    orderType: number,
  ): Promise<any>;
  createItemPlanningQuantities(
    request: CreateItemPlanningQuantitiesRequestDto,
  ): Promise<any>;
  getItemStockAvailableByConditions(
    request: GetItemStockAvailableRequestDto,
  ): Promise<any>;
  getItemWarehouseStock(request: GetItemWarehouseStockRequestDto): Promise<any>;
  getItemsInfo(
    itemIds: number[],
    serilize?: boolean,
  ): Promise<ItemResponseDto[] | any>;
  updateItemStockWarehousePriceEbsIn(
    request: any[],
    orderType: any,
    orderId?: number,
    saleOrderType?: number,
  ): Promise<any>;
  getItemsPrice(conditions: any[]): Promise<any>;
  getItemStockWarehousePrices(request: any): Promise<any>;
  suggestLocatorPoimpAutoComplete(request: any): Promise<any>;
  suggestLocatorWithItemQuantity(
    request: SuggestLocatorWithItemQuantityRequest,
  ): Promise<any>;
  removeItemPlanningQuantities(id: number, orderType: number): Promise<any>;
  rollbackItemPlanningQuantities(
    id: number,
    orderType: number,
    items: any[],
  ): Promise<any>;
  updateStockFromOrder(request: UpdateStockFromOrderRequest): Promise<any>;
}
