import { UpdateStockFromOrderRequest } from './dto/request/update-stock-from-order.request.dto';
import { Injectable } from '@nestjs/common';
import { ItemServiceInterface } from './interface/item.service.interface';
import { CheckStockAvailableDto } from './dto/request/check-stock-available.request.dto';
import { ItemResponseDto } from './dto/response/item.dto.response';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { plainToInstance } from 'class-transformer';
import { GetPositionItemsByConditionsRequestDto } from './dto/request/filter-position-items-by-conditions.request.dto';
import { UpdateItemWarehousePlanningQuantityRequestDto } from './dto/request/update-item-warehouse-planning-quantity.request.dto';
import { GetItemWarehouseByItemIdsAndWarehouseIdsRequestDto } from './dto/request/get-item-warehouse-by-item-ids-and-warehouse-ids.request.dto';
import { keyBy } from 'lodash';
import { CreateItemPlanningQuantitiesRequestDto } from './dto/request/create-item-planning-quantity.request.dto';
import { GetItemStockAvailableRequestDto } from './dto/request/get-item-stock-available.request.dto';
import { GetItemWarehouseStockRequestDto } from './dto/request/get-item-stock.dto';
import { SuggestLocatorWithItemQuantityRequest } from './dto/request/suggest-locator-with-item-quantity.request.dto';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { NATS_ITEM } from '@config/nats.config';

@Injectable()
export class ItemService implements ItemServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  public async getItemWarehouseSheflFloorByLotNumbers(
    floorId: number,
    lotNumbers: string[],
  ): Promise<any> {
    const response: any = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_stock_movement_by_lot_number`,
      {
        warehouseFloorId: floorId,
        lotNumbers: lotNumbers,
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async checkStockAvailable(request: CheckStockAvailableDto): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_ITEM}.check_stock_available`,
      request,
    );
  }

  async getItems(
    itemIds: any[],
    basicInfor = true,
    serialize?: boolean,
  ): Promise<ItemResponseDto[]> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_items_by_ids`,
      {
        itemIds,
        basicInfor: basicInfor,
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    const returnData = plainToInstance(ItemResponseDto, <any[]>response.data, {
      excludeExtraneousValues: true,
    });

    if (serialize) {
      return keyBy(returnData, 'itemId');
    }

    return returnData;
  }

  async getItemByCodes(codes: string[]): Promise<any[]> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_by_codes`,
      {
        codes: JSON.stringify(codes),
      },
    );

    if (
      response.statusCode !== ResponseCodeEnum.SUCCESS ||
      response.data.length === 0
    ) {
      return [];
    }

    return response.data;
  }

  async getPackageByIds(ids: number[]): Promise<any[]> {
    if (ids.length === 0) {
      return [];
    }
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_package_by_ids`,
      {
        ids: ids,
      },
    );

    if (
      response.statusCode !== ResponseCodeEnum.SUCCESS ||
      response.data.length === 0
    ) {
      return [];
    }

    return response.data;
  }

  async getPositionItemsByCondition(
    request: GetPositionItemsByConditionsRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_position_items_by_conditions`,
      request,
    );

    if (
      response.statusCode !== ResponseCodeEnum.SUCCESS ||
      response.data.length === 0
    ) {
      return [];
    }

    return response.data.filter((positionItem) => positionItem.quantity > 0);
  }

  async updateItemWarehousePlanningQuantity(
    request: UpdateItemWarehousePlanningQuantityRequestDto,
  ): Promise<any> {
    try {
      return await this.natsClientService.send(
        `${NATS_ITEM}.update_many_item_warehouse_planning_quantity`,
        request,
      );
    } catch (error) {
      console.log(
        `updateItemWarehousePlanningQuantity ERROR: ${error?.message}`,
      );
    }
  }

  async getPalletByIds(
    ids: number[],
    packagePalletCondition?: any[],
  ): Promise<any[]> {
    if (ids.length === 0) {
      return [];
    }
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_pallet_by_ids`,
      {
        ids: ids,
        packagePalletCondition: packagePalletCondition,
      },
    );

    if (
      response.statusCode !== ResponseCodeEnum.SUCCESS ||
      response.data.length === 0
    ) {
      return [];
    }

    return response.data;
  }

  async getItemWarehouseByItemIdsAndWarehouseIds(
    payload: GetItemWarehouseByItemIdsAndWarehouseIdsRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_warehouses_by_itemIds_warehouseIds`,
      payload,
    );

    if (
      response.statusCode !== ResponseCodeEnum.SUCCESS ||
      response.data.length === 0
    ) {
      return [];
    }

    return response.data;
  }

  async getItemWarehouseStock(
    request: GetItemWarehouseStockRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_warehouse_stock`,
      { ...request, isGetAll: '1' },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getItemPlanningQuantityByOrder(
    itemIds: number[],
    warehouseId: number,
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_planning_quantity_by_order`,
      {
        itemIds,
        warehouseId,
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return serilize ? {} : [];
    }

    return serilize ? keyBy(response.data, 'itemId') : response.data;
  }

  async getItemPlanningQuantityByOrderId(
    orderId: number,
    orderType: number,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_planning_quantity_by_order_id`,
      {
        orderId,
        orderType,
      },
    );

    return response.data;
  }

  async createItemPlanningQuantities(
    request: CreateItemPlanningQuantitiesRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.create_item_planning_quantitites`,
      request,
    );

    return response;
  }

  async removeItemPlanningQuantities(
    orderId: number,
    orderType: number,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.remove_item_planning_quantitites`,
      { orderId, orderType },
    );

    return response;
  }

  async rollbackItemPlanningQuantities(
    orderId: number,
    orderType: number,
    items: any[],
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.rollback_item_planning_quantitites`,
      { orderId, orderType, items },
    );

    return response;
  }

  public async getItemStockAvailableByConditions(
    request: GetItemStockAvailableRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_stock_available_by_conditions`,
      request,
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }
  public async getItemsPrice(conditions: any[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_items_price`,
      {
        conditions,
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getItemsInfo(
    itemIds: number[],
    serilize?: boolean,
  ): Promise<ItemResponseDto[] | any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_list`,
      {
        page: 1,
        limit: itemIds.length,
        filter: [{ column: 'itemIds', text: itemIds.join(',') }],
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    const dataReturn = plainToInstance(
      ItemResponseDto,
      <any[]>response.data?.items,
      {
        excludeExtraneousValues: true,
      },
    );
    if (serilize) {
      const items = keyBy(dataReturn, 'itemId');
      return items;
    }
    return dataReturn;
  }

  async updateItemStockWarehousePriceEbsIn(
    request: any[],
    orderType: any,
    orderId?: number,
    saleOrderType?: number,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.update_item_stock_warehouse_price_ebs_in`,
      {
        items: request,
        orderType: orderType,
        orderId: orderId,
        saleOrderType: saleOrderType,
      },
    );

    return response;
  }

  async getItemStockWarehousePrices(request: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_stock_warehouse_prices`,
      request,
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    return response.data;
  }

  async suggestLocatorPoimpAutoComplete(request: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.suggest_locator_poimp_auto_complete`,
      request,
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];

    return response.data;
  }

  async suggestLocatorWithItemQuantity(
    request: SuggestLocatorWithItemQuantityRequest,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.suggest_locator_with_item_quantity`,
      request,
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }

  async updateStockFromOrder(
    request: UpdateStockFromOrderRequest,
  ): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_ITEM}.update_stock_from_order`,
      request,
    );
  }
}
