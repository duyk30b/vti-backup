import { UpdateStockFromOrderRequest } from './dto/request/update-stock-from-order.request.dto';
import { Inject, Injectable } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { ItemServiceInterface } from './interface/item.service.interface';
import { CheckStockAvailableDto } from './dto/request/check-stock-available.request.dto';
import { ItemResponseDto } from './dto/response/item.dto.response';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { plainToInstance } from 'class-transformer';
import { GetPositionItemsByConditionsRequestDto } from './dto/request/filter-position-items-by-conditions.request.dto';
import { UpdateItemWarehousePlanningQuantityRequestDto } from './dto/request/update-item-warehouse-planning-quantity.request.dto';
import { GetItemWarehouseByItemIdsAndWarehouseIdsRequestDto } from './dto/request/get-item-warehouse-by-item-ids-and-warehouse-ids.request.dto';
import { keyBy } from 'lodash';
import { CreateItemPlanningQuantitiesRequestDto } from './dto/request/create-item-planning-quantity.request.dto';
import { GetItemStockAvailableRequestDto } from './dto/request/get-item-stock-available.request.dto';
import { GetItemWarehouseStockRequestDto } from './dto/request/get-item-stock.dto';
import { SuggestLocatorWithItemQuantityRequest } from './dto/request/suggest-locator-with-item-quantity.request.dto';

@Injectable()
export class ItemService implements ItemServiceInterface {
  constructor(
    @Inject('ITEM_SERVICE_CLIENT')
    private readonly itemServiceClient: ClientProxy,
  ) {}

  public async getItemWarehouseSheflFloorByLotNumbers(
    floorId: number,
    lotNumbers: string[],
  ): Promise<any> {
    const response: any = await this.itemServiceClient
      .send('get_item_stock_movement_by_lot_number', {
        warehouseFloorId: floorId,
        lotNumbers: lotNumbers,
      })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async checkStockAvailable(request: CheckStockAvailableDto): Promise<any> {
    return await this.itemServiceClient
      .send('check_stock_available', request)
      .toPromise();
  }

  async getItems(
    itemIds: any[],
    basicInfor = true,
  ): Promise<ItemResponseDto[]> {
    const response = await this.itemServiceClient
      .send('get_items_by_ids', {
        itemIds,
        basicInfor: basicInfor,
      })
      .toPromise();
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    const items = response.data.map((item) => ({
      ...item,
      itemUnit: item.itemUnitName,
    }));
    const dataReturn = plainToInstance(ItemResponseDto, <any[]>items, {
      excludeExtraneousValues: true,
    });

    return dataReturn;
  }

  async getItemByCodes(codes: string[]): Promise<any[]> {
    const response = await this.itemServiceClient
      .send('get_item_by_codes', { codes: JSON.stringify(codes) })
      .toPromise();
    if (
      response.statusCode !== ResponseCodeEnum.SUCCESS ||
      response.data.length === 0
    ) {
      return [];
    }

    return response.data;
  }

  async getPackageByIds(ids: number[]): Promise<any[]> {
    if (ids.length === 0) {
      return [];
    }
    const response = await this.itemServiceClient
      .send('get_package_by_ids', { ids: ids })
      .toPromise();
    if (
      response.statusCode !== ResponseCodeEnum.SUCCESS ||
      response.data.length === 0
    ) {
      return [];
    }

    return response.data;
  }

  async getPositionItemsByCondition(
    request: GetPositionItemsByConditionsRequestDto,
  ): Promise<any> {
    const response = await this.itemServiceClient
      .send('get_position_items_by_conditions', request)
      .toPromise();
    if (
      response.statusCode !== ResponseCodeEnum.SUCCESS ||
      response.data.length === 0
    ) {
      return [];
    }

    return response.data.filter((positionItem) => positionItem.quantity > 0);
  }

  async updateItemWarehousePlanningQuantity(
    request: UpdateItemWarehousePlanningQuantityRequestDto,
  ): Promise<any> {
    try {
      return await this.itemServiceClient
        .send('update_many_item_warehouse_planning_quantity', request)
        .toPromise();
    } catch (error) {
      console.log(
        `updateItemWarehousePlanningQuantity ERROR: ${error?.message}`,
      );
    }
  }

  async getPalletByIds(
    ids: number[],
    packagePalletCondition?: any[],
  ): Promise<any[]> {
    if (ids.length === 0) {
      return [];
    }
    const response = await this.itemServiceClient
      .send('get_pallet_by_ids', {
        ids: ids,
        packagePalletCondition: packagePalletCondition,
      })
      .toPromise();
    if (
      response.statusCode !== ResponseCodeEnum.SUCCESS ||
      response.data.length === 0
    ) {
      return [];
    }

    return response.data;
  }

  async getItemWarehouseByItemIdsAndWarehouseIds(
    payload: GetItemWarehouseByItemIdsAndWarehouseIdsRequestDto,
  ): Promise<any> {
    const response = await this.itemServiceClient
      .send('get_item_warehouses_by_itemIds_warehouseIds', payload)
      .toPromise();
    if (
      response.statusCode !== ResponseCodeEnum.SUCCESS ||
      response.data.length === 0
    ) {
      return [];
    }

    return response.data;
  }

  async getItemWarehouseStock(
    request: GetItemWarehouseStockRequestDto,
  ): Promise<any> {
    const response = await this.itemServiceClient
      .send('get_item_warehouse_stock', { ...request, isGetAll: '1' })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getItemPlanningQuantityByOrder(
    itemIds: number[],
    warehouseId: number,
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.itemServiceClient
      .send('get_item_planning_quantity_by_order', {
        itemIds,
        warehouseId,
      })
      .toPromise();
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return serilize ? {} : [];
    }

    return serilize ? keyBy(response.data, 'itemId') : response.data;
  }

  async getItemPlanningQuantityByOrderId(
    orderId: number,
    orderType: number,
  ): Promise<any> {
    const response = await this.itemServiceClient
      .send('get_item_planning_quantity_by_order_id', {
        orderId,
        orderType,
      })
      .toPromise();
    return response.data;
  }

  async createItemPlanningQuantities(
    request: CreateItemPlanningQuantitiesRequestDto,
  ): Promise<any> {
    const response = await this.itemServiceClient
      .send('create_item_planning_quantitites', request)
      .toPromise();
    return response;
  }

  async removeItemPlanningQuantities(
    orderId: number,
    orderType: number,
  ): Promise<any> {
    const response = await this.itemServiceClient
      .send('remove_item_planning_quantitites', { orderId, orderType })
      .toPromise();
    return response;
  }

  async rollbackItemPlanningQuantities(
    orderId: number,
    orderType: number,
    items: any[],
  ): Promise<any> {
    const response = await this.itemServiceClient
      .send('rollback_item_planning_quantitites', { orderId, orderType, items })
      .toPromise();
    return response;
  }

  public async getItemStockAvailableByConditions(
    request: GetItemStockAvailableRequestDto,
  ): Promise<any> {
    const response = await this.itemServiceClient
      .send('get_item_stock_available_by_conditions', request)
      .toPromise();
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }
  public async getItemsPrice(conditions: any[]): Promise<any> {
    const response = await this.itemServiceClient
      .send('get_items_price', {
        conditions,
      })
      .toPromise();
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getItemsInfo(
    itemIds: number[],
    serilize?: boolean,
  ): Promise<ItemResponseDto[] | any> {
    const response = await this.itemServiceClient
      .send('get_item_list', {
        page: 1,
        limit: itemIds.length,
        filter: [{ column: 'itemIds', text: itemIds.join(',') }],
      })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    const dataReturn = plainToInstance(
      ItemResponseDto,
      <any[]>response.data?.items,
      {
        excludeExtraneousValues: true,
      },
    );
    if (serilize) {
      const items = keyBy(dataReturn, 'itemId');
      return items;
    }
    return dataReturn;
  }

  async updateItemStockWarehousePriceEbsIn(
    request: any[],
    orderType: any,
    orderId?: number,
    saleOrderType?: number,
  ): Promise<any> {
    const response = await this.itemServiceClient
      .send('update_item_stock_warehouse_price_ebs_in', {
        items: request,
        orderType: orderType,
        orderId: orderId,
        saleOrderType: saleOrderType,
      })
      .toPromise();
    return response;
  }

  async getItemStockWarehousePrices(request: any): Promise<any> {
    const response = await this.itemServiceClient
      .send('get_item_stock_warehouse_prices', request)
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    return response.data;
  }

  async suggestLocatorPoimpAutoComplete(request: any): Promise<any> {
    const response = await this.itemServiceClient
      .send('suggest_locator_poimp_auto_complete', request)
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];

    return response.data;
  }

  async suggestLocatorWithItemQuantity(
    request: SuggestLocatorWithItemQuantityRequest,
  ): Promise<any> {
    const response = await this.itemServiceClient
      .send('suggest_locator_with_item_quantity', request)
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }

  async updateStockFromOrder(
    request: UpdateStockFromOrderRequest,
  ): Promise<any> {
    return await this.itemServiceClient
      .send('update_stock_from_order', request)
      .toPromise();
  }
}
