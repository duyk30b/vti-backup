import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { Transform } from 'class-transformer';
import { IsOptional, IsInt } from 'class-validator';

export class GetItemWarehouseStockRequestDto extends PaginationQuery {
  @ApiProperty({})
  @IsOptional()
  @Transform((data) => {
    return +data.value;
  })
  @IsInt()
  warehouseId: number;
}
