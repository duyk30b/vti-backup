import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsInt, IsNotEmpty, IsNumber } from 'class-validator';

class ItemWarehouseRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  planningQuantity: number;
}

export class UpdateItemWarehousePlanningQuantityRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @Type(() => ItemWarehouseRequestDto)
  itemWarehouses: ItemWarehouseRequestDto[]
}
