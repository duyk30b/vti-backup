import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
} from 'class-validator';

class ConditionFilter {
  @ApiProperty()
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  itemId: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  warehouseShelfFloorId: number;
}
export class GetPositionItemsByConditionsRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  @Type(() => ConditionFilter)
  conditions: ConditionFilter[];
}
