import { OrderWarehouseActionTypeEnum } from '@constant/order.constant';
import { Expose } from 'class-transformer';

export class UpdateStockFromOrderRequest {
  @Expose()
  warehouseStockMovementId: number;

  @Expose()
  orderType: OrderWarehouseActionTypeEnum;

  constructor(
    warehouseStockMovementId: number,
    orderType: OrderWarehouseActionTypeEnum,
  ) {
    this.warehouseStockMovementId = warehouseStockMovementId;
    this.orderType = orderType;
  }
}
