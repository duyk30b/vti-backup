import { Expose } from 'class-transformer';

export class CreateItemStockMovementDto {
  @Expose()
  warehouseStockMovementId: number;

  @Expose()
  itemId: number;

  @Expose()
  warehouseId: number;

  @Expose()
  userId: number;

  @Expose()
  movementOrderDetailId: number;

  @Expose()
  movementOrderWarehouseDetailId: number;

  @Expose()
  quantity: number;

  constructor(
    warehouseStockMovementId: number,
    itemId: number,
    warehouseId: number,
    userId: number,
    movementOrderDetailId: number,
    movementOrderWarehouseDetailId: number,
    quantity: number,
  ) {
    this.warehouseStockMovementId = warehouseStockMovementId;
    this.itemId = itemId;
    this.warehouseId = warehouseId;
    this.userId = userId;
    this.movementOrderDetailId = movementOrderDetailId;
    this.movementOrderWarehouseDetailId = movementOrderWarehouseDetailId;
    this.quantity = quantity;
  }
}
