import { Expose } from 'class-transformer';

export class CheckStockAvailableDto {
  @Expose()
  items: ItemStockCheck[];

  constructor(items: ItemStockCheck[]) {
    this.items = items;
  }
}

export class ItemStockCheck {
  @Expose()
  itemId: number;

  @Expose()
  quantity: number;

  @Expose()
  warehouseId: number;

  constructor(itemId: number, quantity: number, warehouseId: number) {
    this.itemId = itemId;
    this.quantity = quantity;
    this.warehouseId = warehouseId;
  }
}
