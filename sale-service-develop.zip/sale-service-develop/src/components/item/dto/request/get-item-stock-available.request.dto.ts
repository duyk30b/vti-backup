import { BaseDto } from '@core/dto/base.dto';
import { ApiPropertyOptional, ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsInt,
  IsOptional,
  ValidateNested,
  IsString,
  IsEnum,
  ArrayNotEmpty,
} from 'class-validator';

export class ConditionOrder {
  @ApiProperty()
  @IsInt()
  orderId: number;

  @ApiProperty()
  @IsInt()
  orderType: number;
}

export class FilterItemByCondition {
  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  lotNumber: string | null;

  @ApiPropertyOptional()
  @IsInt()
  warehouseId: number;

  @ApiPropertyOptional()
  @IsOptional()
  locatorIds?: number[];
}

export class GetItemStockAvailableRequestDto {
  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => ConditionOrder)
  @ValidateNested()
  order: ConditionOrder;

  @ApiProperty()
  @ValidateNested()
  @ArrayNotEmpty()
  @Type(() => FilterItemByCondition)
  items: FilterItemByCondition[];
}
