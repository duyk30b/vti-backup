import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsInt,
  IsString,
  IsPositive,
  IsNumber,
  ArrayNotEmpty,
  ValidateNested,
  IsOptional,
} from 'class-validator';

export class CreateItemPlanningQuantityRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsPositive()
  @IsNumber()
  planQuantity: number;

  @ApiPropertyOptional()
  @IsString()
  lotNumber: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  locatorId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  orderDetailId: number;

  @ApiProperty()
  @IsInt()
  orderId: number;

  @ApiProperty()
  orderType: number;
}

export class CreateItemPlanningQuantitiesRequestDto {
  @ApiProperty()
  @ArrayNotEmpty()
  @ValidateNested()
  items: CreateItemPlanningQuantityRequestDto[];
}
