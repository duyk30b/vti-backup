import { IsInt, IsNotEmpty, IsNumber } from 'class-validator';

export class ItemWarehouseRequestDto {
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @IsNotEmpty()
  @IsNumber()
  actutalQuantity: number;

  @IsNotEmpty()
  @IsInt()
  warehouseId: number;
}
