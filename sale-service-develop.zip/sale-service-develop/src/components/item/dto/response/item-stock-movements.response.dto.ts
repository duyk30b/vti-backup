import { ResponseService } from '@utils/response-service';
import { Expose } from 'class-transformer';

export class ItemStockMovementResponseDto {
  @Expose()
  id: number;

  @Expose()
  warehouseStockMovementId: number;

  @Expose()
  itemId: number;

  @Expose()
  warehouseId: number;
  @Expose()
  movementOrderDetailId: number;

  @Expose()
  movementOrderWarehouseDetailId: number;

  @Expose()
  quantity: number;
}

export class ItemStockMovementsResponseDto extends ResponseService {
  @Expose()
  data: ItemStockMovementResponseDto[];
}
