import { BasicResponseDto } from '@core/dto/basic-response.dto';
import { Expose, Type } from 'class-transformer';
import { ItemResponseDtoInterface } from './item.interface.response';
class Bom {
  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  id: string;
}
class Package {
  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  id: string;
}

class ItemWarehouseSource {
  @Expose()
  warehouseId: number;

  @Expose()
  accounting: string;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  accountIdentifier: string;
}

class ResponseAbstract {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;
}

export class ItemResponseDto implements ItemResponseDtoInterface {
  @Expose({ name: 'id' })
  itemId: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  price: number;

  @Expose()
  description: string;

  @Expose()
  quantity: number;

  @Expose()
  itemDetails: any;

  @Expose()
  details: any;

  @Expose()
  @Type(() => Bom)
  bom: Bom;

  @Expose()
  @Type(() => Package)
  packages: Package[];

  @Expose()
  @Type(() => BasicResponseDto)
  itemUnit: BasicResponseDto;

  @Expose()
  @Type(() => ResponseAbstract)
  itemQuality: ResponseAbstract;

  @Expose()
  @Type(() => ItemWarehouseSource)
  itemWarehouseSources: ItemWarehouseSource[];
}
