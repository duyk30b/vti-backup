import { ApiProperty } from '@nestjs/swagger';
import { BaseDto } from '@core/dto/base.dto';
import { ArrayNotEmpty } from 'class-validator';

export class GetConstructionByIdsRequestDto extends BaseDto {
  @ApiProperty({ example: '1', description: '' })
  @ArrayNotEmpty()
  constructionIds: number[];
}
