import { ApiProperty } from '@nestjs/swagger';
import { BaseDto } from '@core/dto/base.dto';
import { IsString } from 'class-validator';

export class GetConstructionByCodeRequestDto extends BaseDto {
  @ApiProperty()
  @IsString()
  code: string;
}
