import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt } from 'class-validator';
import { CreateConstructionRequestDto } from './create-construction.request.dto';
export class UpdateConstructionBodyDto extends CreateConstructionRequestDto {}
export class UpdateConstructionRequestDto extends UpdateConstructionBodyDto {
  @ApiProperty({ example: 1, description: '' })
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
