import {
  RULES,
  WarehouseEnumCreatedFrom,
} from '@components/construcion/construction.constants';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsString,
  MaxLength,
  IsOptional,
  IsEnum,
  Matches,
} from 'class-validator';

export class CreateConstructionRequestDto extends BaseDto {
  @ApiProperty({ example: 'construction 1', description: '' })
  @IsString()
  @MaxLength(RULES.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: 'ABCDEF', description: '' })
  @IsString()
  @Matches(RULES.CODE.REGEX)
  @MaxLength(RULES.CODE.MAX_LENGTH)
  code: string;

  @ApiPropertyOptional({ example: 'Construction 1', description: '' })
  @IsString()
  @MaxLength(RULES.DESCRIPTION.MAX_LENGTH)
  @IsOptional()
  description: string;

  @ApiPropertyOptional({})
  @IsOptional()
  @IsEnum(WarehouseEnumCreatedFrom)
  createdFrom: WarehouseEnumCreatedFrom;
}
