import { ImportResponseDto } from "@core/dto/import/response/import.response.dto";
import { ImportResultDto } from "@core/dto/import/response/import.result.dto";
import { ConstructionRepositoryInterface } from "../interface/construction.interface.repository";
import { Inject } from '@nestjs/common'
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, In } from 'typeorm';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ConfigService } from '@nestjs/config';
import { ImportRequestDto } from "@core/dto/import/request/import.request.dto";
import { ResponsePayload } from "@utils/response-payload";
import { ImportFileDataAbstract } from "@core/abstracts/import-file-data.abstract";
import {
  keyBy,
  uniq,
  isEmpty,
} from 'lodash';

export class ConstructionImport extends ImportFileDataAbstract {

  private readonly ROW_NUMBER_START_DATA = 0;

  private readonly FIELD_TEMPLATE_ITEM_CONST = {
    CODE: {
      DB_COL_NAME: 'code',
      COL_NAME: 'Mã công trình',
      MAX_LENGTH: 50,
      ALLOW_NULL: false,
    },
    NAME: {
      DB_COL_NAME: 'name',
      COL_NAME: 'Tên công trình',
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    DESCRIPTION: {
      DB_COL_NAME: 'description',
      COL_NAME: 'Mô tả công trình',
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    REQUIRED_COL_NUM: 3,
  };

  private readonly SHEET_NAME = this.i18n.translate('file-header.SHEET_NAME_FILE_IMPORT_CONSTRUCTION');

  constructor(
    @Inject('ConstructionRepositoryInterface')
    private readonly constructionRepository: ConstructionRepositoryInterface,

    @InjectDataSource()
    private readonly connection: DataSource,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    this.fieldsMap.groupSet(
      [1, 2, 3],
      [
        this.FIELD_TEMPLATE_ITEM_CONST.CODE,
        this.FIELD_TEMPLATE_ITEM_CONST.NAME,
        this.FIELD_TEMPLATE_ITEM_CONST.DESCRIPTION,
      ]
    );
  }

  protected async saveImportDataDto(dataDto: any[], logs: ImportResultDto[], error: number, total: number, userId?: number): Promise<ImportResponseDto> {

    const construcionCode = uniq(dataDto.map((c) => c.code));
    const findByCode = await this.constructionRepository.findWithRelations(
      {
        where: {
          code: In(construcionCode),
        }
      }
    )
    findByCode.forEach((c) => Object.assign(c, { type: 'old' }));
    const findByCodeMap = keyBy(findByCode, 'code');
    const entities = [];
    const valid = [];
    const {
      successMsg,
      unsuccessMsg,
    } = await this.getMessage();

    dataDto.forEach((data) => {
      if (userId) {
        data.userId = userId;
      }
      const { i, code, name, description } = data;
      const logRow = {
        id: i,
        row: i,
      } as ImportResultDto;
      const msgLogs = [];

      if (findByCodeMap[code] && findByCodeMap[code]?.['type'] === 'old') {
        const entity = this.constructionRepository.updateEntity(
          findByCodeMap[code],
          data,
        );
        entities.push(entity);
        Object.assign(entity, { type: 'new' });
      } else {
        const entity = this.constructionRepository.createEntity(data);
        entities.push(entity);
        Object.assign(entity, { type: 'new' });
        findByCodeMap[code] = entity;
      }
      if (isEmpty(msgLogs)) {
        logRow.log = [successMsg];
        valid.push(logRow);
      } else {
        logRow.log = msgLogs;
        logs.push(logRow);
      }
    })

    const response = new ImportResponseDto();
    if (!isEmpty(entities)) {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(entities);
        await queryRunner.commitTransaction();
        response.successCount = valid.length;
      } catch (error) {
        await queryRunner.rollbackTransaction();
        response.successCount = 0;
        valid.forEach((l) => (l.log = [unsuccessMsg]));
      } finally {
        await queryRunner.release();
        logs.push(...valid);
      }
    }
    response.result = logs;
    response.totalCount = total;
    response.result;
    return response;
  }

  public async importUtil(request: ImportRequestDto): Promise<ResponsePayload<any>> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_ITEM_CONST.REQUIRED_COL_NUM,
      this.SHEET_NAME,
    )
  }
}
