import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { ConstructionEntity } from '@entities/construction/construction.entity';
import { CreateConstructionRequestDto } from '../dto/request/create-construction.request.dto';
import { GetConstructionListRequestDto } from '../dto/request/get-list-construction.reqyest.dto';
import { UpdateConstructionRequestDto } from '../dto/request/update-construction.request.dto';

export interface ConstructionRepositoryInterface
  extends BaseAbstractRepository<ConstructionEntity> {
  createEntity(request: CreateConstructionRequestDto): ConstructionEntity;
  getList(request: GetConstructionListRequestDto): Promise<any>;
  getDetail(id: number): Promise<any>;
  updateEntity(
    construcionUpdate: ConstructionEntity,
    request: UpdateConstructionRequestDto | any,
  ): ConstructionEntity;
}
