import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ResponsePayload } from '@utils/response-payload';
import { ConfirmConstructionRequestDto } from '../dto/request/confirm-construction.request.dto';
import { CreateConstructionRequestDto } from '../dto/request/create-construction.request.dto';
import { DeleteConstructionRequestDto } from '../dto/request/delete-construction.request.dto';
import { GetConstructionByCodeRequestDto } from '../dto/request/get-construction-by-code.request.dto';
import { GetConstructionByIdsRequestDto } from '../dto/request/get-construction-by-ids.request.dto';
import { GetConstructionListRequestDto } from '../dto/request/get-list-construction.reqyest.dto';
import { UpdateConstructionRequestDto } from '../dto/request/update-construction.request.dto';
import { ConstructionResponseDto } from '../dto/response/construction.response.dto';

export interface ConstructionServiceInterface {
  create(
    request: CreateConstructionRequestDto,
  ): Promise<ResponsePayload<ConstructionResponseDto | any>>;
  getList(request: GetConstructionListRequestDto): Promise<any>;
  updateConstruction(
    request: UpdateConstructionRequestDto,
  ): Promise<ResponsePayload<ConstructionResponseDto | any>>;
  detail(id: number): Promise<any>;
  delete(request: DeleteConstructionRequestDto): Promise<ResponsePayload<any>>;
  deleteMultiple(request: DeleteMultipleDto): Promise<any>;
  confirm(request: ConfirmConstructionRequestDto): Promise<any>;
  reject(request: ConfirmConstructionRequestDto): Promise<any>;
  getConstructionByIds(request: GetConstructionByIdsRequestDto): Promise<any>;
  getConstructionByCode(request: GetConstructionByCodeRequestDto): Promise<any>;
  importContruction(request: FileUpdloadRequestDto): Promise<any>;
}
