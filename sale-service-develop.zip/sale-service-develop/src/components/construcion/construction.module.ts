import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { CategoryContructionEntity } from '@entities/category-contruction/category-contruction.entity';
import { ConstructionEntity } from '@entities/construction/construction.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CategoryContructionRepository } from '@repositories/category-contruction/category-contruction.repository';
import { ConstructionRepository } from '@repositories/construction/construction.repository';
import { ConstructionController } from './construction.controller';
import { ConstructionService } from './construction.service';
import { ConstructionImport } from './import/construction.import.helper';

@Module({
  imports: [
    TypeOrmModule.forFeature([ConstructionEntity, CategoryContructionEntity]),
    UserModule,
  ],
  providers: [
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'ConstructionServiceInterface',
      useClass: ConstructionService,
    },
    {
      provide: 'ConstructionRepositoryInterface',
      useClass: ConstructionRepository,
    },
    {
      provide: 'CategoryContructionRepositoryInterface',
      useClass: CategoryContructionRepository,
    },
    {
      provide: 'ConstructionImport',
      useClass: ConstructionImport,
    }

  ],
  controllers: [ConstructionController],
  exports: [],
})
export class ConstructionModule {}
