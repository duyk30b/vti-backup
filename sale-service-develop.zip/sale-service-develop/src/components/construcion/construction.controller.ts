import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';

import { ResponsePayload } from '@utils/response-payload';
import { CreateConstructionRequestDto } from './dto/request/create-construction.request.dto';
import { ConstructionResponseDto } from './dto/response/construction.response.dto';
import { isEmpty } from 'lodash';

import { ConstructionServiceInterface } from './interface/construction.interface.service';
import { GetConstructionListRequestDto } from './dto/request/get-list-construction.reqyest.dto';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { UpdateConstructionBodyDto } from './dto/request/update-construction.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { DeleteConstructionRequestDto } from './dto/request/delete-construction.request.dto';
import {
  CONFIRM_CONSTRUCTION_PERMISSION,
  CREATE_CONSTRUCTION_PERMISSION,
  DELETE_CONSTRUCTION_PERMISSION,
  DETAIL_CONSTRUCTION_PERMISSION,
  IMPORT_CONSTRUCTION_PERMISSION,
  LIST_CONSTRUCTION_PERMISSION,
  REJECT_CONSTRUCTION_PERMISSION,
  UPDATE_CONSTRUCTION_PERMISSION,
} from '@utils/permissions/construction';
import { MessagePattern } from '@nestjs/microservices';
import { GetDetailConstructionRequestDto } from './dto/request/get-detail-construction.request.dto';
import { GetConstructionByIdsRequestDto } from './dto/request/get-construction-by-ids.request.dto';
import { GetConstructionByCodeRequestDto } from './dto/request/get-construction-by-code.request.dto';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';

@Controller('constructions')
export class ConstructionController {
  constructor(
    @Inject('ConstructionServiceInterface')
    private readonly constructionService: ConstructionServiceInterface,
  ) {}

  @PermissionCode(CREATE_CONSTRUCTION_PERMISSION.code)
  @Post('/create')
  @ApiOperation({
    tags: ['Construction'],
    summary: 'Create construction Type',
    description: 'Tạo mới công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ConstructionResponseDto,
  })
  async create(
    @Body() payload: CreateConstructionRequestDto,
  ): Promise<ResponsePayload<ConstructionResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.constructionService.create(request);
  }

  // @PermissionCode(LIST_CONSTRUCTION_PERMISSION.code)
  @Get('/list')
  @ApiOperation({
    tags: ['Construction'],
    summary: 'List Construction Type',
    description: 'Danh sách công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: ConstructionResponseDto,
  })
  public async getList(
    @Query() query: GetConstructionListRequestDto,
  ): Promise<ResponsePayload<ConstructionResponseDto | any>> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.constructionService.getList(request);
  }
  @PermissionCode(UPDATE_CONSTRUCTION_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Construction'],
    summary: 'Update Construction Type',
    description: 'Sửa thông tin công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: ConstructionResponseDto,
  })
  public async update(
    @Body() payload: UpdateConstructionBodyDto,
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.constructionService.updateConstruction({
      ...request,
      id,
    });
  }

  @PermissionCode(DETAIL_CONSTRUCTION_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Construction'],
    summary: 'Get construction detail',
    description: 'Get information of an construction',
  })
  @ApiResponse({
    status: 200,
    description: 'Get information successfully',
    type: ConstructionResponseDto,
  })
  public async detail(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    return await this.constructionService.detail(id);
  }

  @PermissionCode(DELETE_CONSTRUCTION_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Construction'],
    summary: 'Delete Construction Type',
    description: 'Xóa công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async delete(
    @Param() param: DeleteConstructionRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = param;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.constructionService.delete(request);
  }

  @PermissionCode(CONFIRM_CONSTRUCTION_PERMISSION.code)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Construction'],
    summary: 'Confirm Construction Type',
    description: 'Xác nhận công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: SuccessResponse,
  })
  public async confirm(
    @Param() param: DeleteConstructionRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = param;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.constructionService.confirm(request);
  }

  @PermissionCode(REJECT_CONSTRUCTION_PERMISSION.code)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Construction'],
    summary: 'Reject Construction ',
    description: 'Từ chối công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: SuccessResponse,
  })
  public async reject(
    @Param() param: DeleteConstructionRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = param;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.constructionService.reject(request);
  }

  @PermissionCode(DELETE_CONSTRUCTION_PERMISSION.code)
  @Delete('/multiple')
  @ApiOperation({
    tags: ['Construction'],
    summary: 'Delete multiple cóntruction type',
    description: 'Xóa nhiều công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.constructionService.deleteMultiple(request);
  }

  @PermissionCode(IMPORT_CONSTRUCTION_PERMISSION.code)
  @Post('/import')
  public async importContructions(@Body() body: FileUpdloadRequestDto) {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.constructionService.importContruction(request);
  }

  @MessagePattern('get_detail_construction')
  public async detailTcp(
    @Body() param: GetDetailConstructionRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.constructionService.detail(request.id);
  }

  @MessagePattern('get_list_construction')
  public async getListTcp(
    @Body() query: GetConstructionListRequestDto,
  ): Promise<ResponsePayload<ConstructionResponseDto | any>> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.constructionService.getList(request);
  }

  @MessagePattern('get_construction_by_ids')
  public async getObjectCategoryByIds(
    @Body() payload: GetConstructionByIdsRequestDto,
  ): Promise<ResponsePayload<ConstructionResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.constructionService.getConstructionByIds(request);
  }

  @MessagePattern('get_construction_by_code')
  public async getObjectCategoryByCode(
    @Body() payload: GetConstructionByCodeRequestDto,
  ): Promise<ResponsePayload<ConstructionResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.constructionService.getConstructionByCode(request);
  }
}
