export const RULES = {
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  CODE: {
    MAX_LENGTH: 50,
    COLUMN: 'code',
    REGEX:
      /^[a-zA-Z0-9ÀÁÂÃÈÉÊẾÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêếìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀỀỂưăạảấầẩẫậắằẳẵặẹẻẽềềểỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợụủứừỬỮỰỲỴÝỶỸửữựỳỵỷỹ\s&,\/._]+$/,
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
  CREATEDFROM: {
    MAX_LENGTH: 255,
    COLUMN: 'created_from',
  },
  SHORT_NAME: {
    MAX_LENGTH: 255,
  },
};
export enum WarehouseEnumCreatedFrom {
  Avenue = 'Avenue',
}

export enum StatusConstructionEnum {
  CREATED = 0,
  ACTIVE = 1,
}

export const CONFIRMABLE_CONSTRUCTION_STATUSES = [
  StatusConstructionEnum.CREATED,
];

export const REJECTABLE_CONSTRUCTION_STATUSES = [StatusConstructionEnum.ACTIVE];
