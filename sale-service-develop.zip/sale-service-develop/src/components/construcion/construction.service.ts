import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ConstructionEntity } from '@entities/construction/construction.entity';
import { Inject, Injectable, Res } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import { isEmpty, stringFormat } from '@utils/object.util';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { I18nService } from 'nestjs-i18n';
import { DataSource, ILike, In, Not } from 'typeorm';
import { keyBy, map, uniq } from 'lodash';
import { CreateConstructionRequestDto } from './dto/request/create-construction.request.dto';
import { GetConstructionListRequestDto } from './dto/request/get-list-construction.reqyest.dto';
import { UpdateConstructionRequestDto } from './dto/request/update-construction.request.dto';
import { ConstructionResponseDto } from './dto/response/construction.response.dto';
import { ConstructionRepositoryInterface } from './interface/construction.interface.repository';
import { ConstructionServiceInterface } from './interface/construction.interface.service';
import { DeleteConstructionRequestDto } from './dto/request/delete-construction.request.dto';
import { ConfirmConstructionRequestDto } from './dto/request/confirm-construction.request.dto';
import {
  CONFIRMABLE_CONSTRUCTION_STATUSES,
  REJECTABLE_CONSTRUCTION_STATUSES,
  StatusConstructionEnum,
} from './construction.constants';
import { GetConstructionByIdsRequestDto } from './dto/request/get-construction-by-ids.request.dto';
import { GetConstructionByCodeRequestDto } from './dto/request/get-construction-by-code.request.dto';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { ConstructionImport } from './import/construction.import.helper';
import { IMPORT_FILE_CONST } from '@constant/import.constant';

@Injectable()
export class ConstructionService implements ConstructionServiceInterface {
  constructor(
    @Inject('ConstructionRepositoryInterface')
    private readonly constructionRepository: ConstructionRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ConstructionImport')
    private readonly constructionImport: ConstructionImport,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nService,
  ) {}
  public async create(
    request: CreateConstructionRequestDto,
  ): Promise<ResponsePayload<ConstructionResponseDto | any>> {
    const constructionEntity = await this.constructionRepository.createEntity(
      request,
    );
    return await this.save(
      constructionEntity,
      request,
      [],
      'message.defineConstruction.createSuccess',
    );
  }

  async getList(request: GetConstructionListRequestDto): Promise<any> {
    const { result, count } = await this.constructionRepository.getList(
      request,
    );
    const userIds = uniq(map(result, 'createdBy'));
    const users = await this.userService.getUsers(userIds, true);
    const data = result.map((record) => {
      return {
        ...record,
        createdBy: users[record.createdBy],
      };
    });
    const response = plainToInstance(ConstructionResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }
  public async updateConstruction(
    request: UpdateConstructionRequestDto | any,
  ): Promise<ResponsePayload<ConstructionResponseDto | any>> {
    const { id } = request;
    const construction = await this.constructionRepository.findOneById(id);
    if (!construction) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CONSTRUCTION_NOT_FOUND'))
        .build();
    }
    //check code
    const isExistCode = await this.constructionRepository.findByCondition({
      code: request.code,
      id: Not(id),
    });
    if (isExistCode.length > 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_IS_EXISTED'))
        .build();
    }
    construction.updatedBy = request.userId;
    const construcionEntity = this.constructionRepository.updateEntity(
      construction,
      request,
    );
    return await this.save(
      construcionEntity,
      request,
      'message.defineConstruction.updateSuccess',
    );
  }

  public async detail(
    id: number,
  ): Promise<ResponsePayload<ConstructionResponseDto | any>> {
    const construction = await this.constructionRepository.getDetail(id);
    if (!construction) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const userIds = [construction.createdBy];

    const userResponse = await this.userService.getUsers(userIds);

    const userMap = keyBy(userResponse, 'id');
    if (construction.createdBy) {
      construction.createdBy = {
        id: userMap[construction.createdBy]?.id || '',
        username: userMap[construction.createdBy]?.username || '',
        fullName: userMap[construction.createdBy]?.fullName || '',
      };
    }
    const response = plainToInstance(ConstructionResponseDto, construction, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  public async delete(
    request: DeleteConstructionRequestDto,
  ): Promise<ResponsePayload<any>> {
    const company = await this.constructionRepository.findOneByCondition({
      id: request.id,
      deletedAt: null,
    });
    if (!company) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    try {
      company.deletedAt = new Date();
      company.deletedBy = request.userId;
      await this.constructionRepository.create(company);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate('message.defineConstruction.deleteSuccess'),
        )
        .build();
    } catch (error) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_DELETE'),
      ).toResponse();
    }
  }

  public async confirm(
    request: ConfirmConstructionRequestDto,
  ): Promise<ResponsePayload<any>> {
    const construction = await this.constructionRepository.findOneByCondition({
      id: request.id,
    });
    if (!construction) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CONFIRMABLE_CONSTRUCTION_STATUSES.includes(construction.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CONFIRM'))
        .build();
    }

    try {
      construction.status = StatusConstructionEnum.ACTIVE;
      await this.constructionRepository.create(construction);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('message.changeStatusSuccess'))
        .build();
    } catch (error) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_CONFIRM'),
      ).toResponse();
    }
  }

  public async reject(
    request: ConfirmConstructionRequestDto,
  ): Promise<ResponsePayload<any>> {
    const construction = await this.constructionRepository.findOneByCondition({
      id: request.id,
    });
    if (!construction) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!REJECTABLE_CONSTRUCTION_STATUSES.includes(construction.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_REJECT'))
        .build();
    }

    try {
      construction.status = StatusConstructionEnum.CREATED;
      await this.constructionRepository.create(construction);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('message.changeStatusSuccess'))
        .build();
    } catch (error) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_REJECT'),
      ).toResponse();
    }
  }

  public async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const constructions = await this.constructionRepository.findByCondition({
      id: In(ids),
      deleteAt: null,
    });
    const constructionIds = constructions.map(
      (construction) => construction.id,
    );
    if (constructions.length !== ids.length) {
      ids.forEach((id) => {
        if (!constructionIds.includes(id)) failIdsList.push(id);
      });
    }
    const validIds = constructions
      .filter((construction) => !failIdsList.includes(construction.id))
      .map((construction) => construction.id);
    try {
      if (!isEmpty(validIds)) {
        await this.constructionRepository.multipleRemove(validIds);
      }
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }
    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }
  public async save(
    constructionEntity: ConstructionEntity,
    payload: UpdateConstructionRequestDto | CreateConstructionRequestDto,
    ids: any,
    message?: string,
  ): Promise<ResponsePayload<any>> {
    if (isEmpty(ids)) {
      const checkExistCode =
        await this.constructionRepository.findOneByCondition({
          code: ILike(payload.code),
        });
      if (checkExistCode) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.CODE_IS_EXISTED'))
          .build();
      }
    }
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const result = await queryRunner.manager.save(constructionEntity);
      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            message || 'message.defineConstruction.updateSuccess',
          ),
        )
        .withData(result)
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder(error)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  public async getConstructionByIds(
    request: GetConstructionByIdsRequestDto,
  ): Promise<ConstructionResponseDto[] | ResponsePayload<any>> {
    const result = await this.constructionRepository.findByCondition({
      id: In(request.constructionIds),
    });
    const response = plainToInstance(ConstructionResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }

  public async getConstructionByCode(
    request: GetConstructionByCodeRequestDto,
  ): Promise<ConstructionResponseDto[] | ResponsePayload<any>> {
    const result = await this.constructionRepository.findOneByCondition({
      code: request.code,
    });
    const response = plainToInstance(ConstructionResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }

  async importContruction(request: FileUpdloadRequestDto): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
      userId: request.userId,
    } as ImportRequestDto;
    const result = await this.constructionImport.importUtil(importRequestDto);
    if (result.statusCode !== ResponseCodeEnum.SUCCESS) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(result.message)
        .build();
    }
    const { data } = result;
    const successCount = data?.successCount ?? 0;
    const totalCount = data?.totalCount ?? 0;
    const logs = [];
    const succ = await this.i18n.translate('error.SUCCESS');
    const dataStart = IMPORT_FILE_CONST.SHEET.DATA_START_ROW;
    if (successCount < totalCount) {
      data?.result.map(async (item) => {
        if (item.log[0] !== succ) {
          const log = item.log[0].toLowerCase();
          const row = dataStart + item.row;
          const mess = this.i18n.translate('error.ERROR_RESPONSE', {
            args: {
              row: row,
              log: log,
            },
          });
          logs.push(mess);
        }
      });
      return new ResponseBuilder({
        successCount: successCount,
        totalCount: totalCount,
        logs: logs,
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          logs[0] ? logs[0] : await this.i18n.translate('error.BAD_REQUEST'),
        )
        .build();
    }

    return new ResponseBuilder({
      successCount: successCount,
      totalCount: totalCount,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
