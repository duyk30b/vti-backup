import { PurchasedOrderImportModule } from '@components/purchased-order-import/purchased-order-import.module';
import { UserService } from '@components/user/user.service';
import { CategoryContructionEntity } from '@entities/category-contruction/category-contruction.entity';
import { ConstructionEntity } from '@entities/construction/construction.entity';
import { Customer } from '@entities/customer/customer.entity';
import { PurchasedOrderImportEntity } from '@entities/purchased-order-import/purchased-order-import.entity';
import { ReasonEntity } from '@entities/reason/reason.entity';
import { SaleOrderExport } from '@entities/sale-order-export/sale-order-export.entity';
import { SaleOrder } from '@entities/sale-order/sale-order.entity';
import { SourceEntity } from '@entities/source/source.entity';
import { VendorEntity } from '@entities/vendor/vendor.entity';
import { Global, Module, forwardRef } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CategoryContructionRepository } from '@repositories/category-contruction/category-contruction.repository';
import { ConstructionRepository } from '@repositories/construction/construction.repository';
import { CustomerRepository } from '@repositories/customer/customer.repository';
import { ReasonRepository } from '@repositories/reason/reason.repository';
import { SaleOrderExportRepository } from '@repositories/sale-order-export/sale-order-export.repository';
import { SaleOrderRepository } from '@repositories/sale-order/sale-order.repository';
import { SourceRepository } from '@repositories/source/source.repository';
import { VendorRepository } from '@repositories/vendor/vendor.repository';
import { ExportController } from './export.controller';
import { ExportService } from './export.service';
import { UserModule } from '@components/user/user.module';

@Global()
@Module({
  imports: [
    TypeOrmModule.forFeature([
      Customer,
      SaleOrder,
      PurchasedOrderImportEntity,
      CategoryContructionEntity,
      ConstructionEntity,
      SourceEntity,
      ReasonEntity,
      VendorEntity,
      SaleOrderExport,
      UserModule,
    ]),
    forwardRef(() => PurchasedOrderImportModule),
  ],
  providers: [
    {
      provide: 'ExportServiceInterface',
      useClass: ExportService,
    },
    {
      provide: 'CustomerRepositoryInterface',
      useClass: CustomerRepository,
    },
    {
      provide: 'SaleOrderRepositoryInterface',
      useClass: SaleOrderRepository,
    },
    {
      provide: 'CategoryContructionRepositoryInterface',
      useClass: CategoryContructionRepository,
    },
    {
      provide: 'ConstructionRepositoryInterface',
      useClass: ConstructionRepository,
    },
    {
      provide: 'SourceRepositoryInterface',
      useClass: SourceRepository,
    },
    {
      provide: 'ReasonRepositoryInterface',
      useClass: ReasonRepository,
    },
    {
      provide: 'VendorRepositoryInterface',
      useClass: VendorRepository,
    },
    {
      provide: 'SaleOrderExportRepositoryInterface',
      useClass: SaleOrderExportRepository,
    },
  ],
  controllers: [ExportController],
})
export class ExportModule {}
