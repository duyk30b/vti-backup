import { GetListCustomerRequest } from '@components/customer/dto/request/get-customer-list.request.dto';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { GetOrderDetailRequestDto } from '@components/order/dto/request/get-order-detail.request.dto';
import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { PurchasedOrderImportServiceInterface } from '@components/purchased-order-import/interface/purchased-order-import.service.interface';
import { GetSaleOrderListRequest } from '@components/sale-order/dto/request/get-sale-order-list-request.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { CustomerRepository } from '@repositories/customer/customer.repository';
import { SaleOrderRepository } from '@repositories/sale-order/sale-order.repository';
import { ResponseBuilder } from '@utils/response-builder';
import { Workbook, Font, Alignment, Borders } from 'exceljs';
import { first, isEmpty, keyBy, map, uniq, groupBy, has } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ExportRequestDto } from './dto/request/export.request.dto';
import { exportPuschasedOrderImportMapping } from '../../mappings/word/export-purchased-order-import.word.mapping';
import {
  EXCEL_STYLE,
  MAX_NUMBER_PAGE,
  ROW,
  SHEET,
  TypeEnum,
} from './export.constant';
import { ExportServiceInterface } from './interface/export.service.interface';
import { GetAttributeDetailValuesRequestDto } from '../warehouse/dto/request/get-attribute-detail-values.request.dto';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { SettingServiceInterface } from '@components/setting/interface/setting.service.interface';
import { typeTicket } from '@constant/common';
import { ConfigService } from '@config/config.service';
import { GetListCategoryContructionRequestDto } from '@components/category-contruction/dto/request/list-category-contruction.request.dto';
import { CategoryContructionRepository } from '@repositories/category-contruction/category-contruction.repository';
import { CategoryContructionEntity } from '@entities/category-contruction/category-contruction.entity';
import { ConstructionEntity } from '@entities/construction/construction.entity';
import { GetConstructionListRequestDto } from '@components/construcion/dto/request/get-list-construction.reqyest.dto';
import { ConstructionRepository } from '@repositories/construction/construction.repository';
import { SourceEntity } from '@entities/source/source.entity';
import { GetSourceListRequestDto } from '@components/source/dto/request/get-source-list.request.dto';
import { SourceRepositoryInterface } from '@components/source/interface/sources.repository.interface';
import { generatePaddingCode } from '@utils/helper';
import {
  CODE_DELIMITER,
  SOURCE_RULES,
} from '@components/source/source.constants';
import { ReasonEntity } from '@entities/reason/reason.entity';
import { GetReasonListRequestDto } from '@components/reason/dto/request/get-reason-list.request.dto';
import { ReasonRepositoryInterface } from '@components/reason/interface/reason.repository.interface';
import { VendorEntity } from '@entities/vendor/vendor.entity';
import { GetVendorListRequest } from '@components/vendor/dto/request/get-vendor-list.request.dto';
import { VendorRepositoryInterface } from '@components/vendor/interface/vendor.repository.interface';
import { getProvince } from 'src/common/word-common.styles';
import { GetSaleOrderExportListRequest } from '@components/sale-order-export/dto/request/get-sale-order-export-list-request.dto';
import { SaleOrderExportRepositoryInterface } from '@components/sale-order-export/interface/sale-order-export.repository.interface';
import { In } from 'typeorm';
import { formatDateToExport, statusSaleOrderText } from '@utils/common';
import { OrderTypeEnum } from '@constant/order.constant';
import * as moment from 'moment';
@Injectable()
export class ExportService implements ExportServiceInterface {
  constructor(
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    @Inject('ProduceServiceInterface')
    private readonly produceService: ProduceServiceInterface,

    @Inject('CustomerRepositoryInterface')
    private readonly customerRepository: CustomerRepository,

    @Inject('SaleOrderRepositoryInterface')
    private readonly saleOrderRepository: SaleOrderRepository,

    @Inject('PurchasedOrderImportServiceInterface')
    private readonly purchasedOrderImportService: PurchasedOrderImportServiceInterface,

    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,

    @Inject('SettingServiceInterface')
    private readonly settingService: SettingServiceInterface,

    @Inject('CategoryContructionRepositoryInterface')
    private readonly categoryContructionRepository: CategoryContructionRepository,

    @Inject('ConstructionRepositoryInterface')
    private readonly constructionRepository: ConstructionRepository,

    @Inject('SourceRepositoryInterface')
    private readonly sourceRepository: SourceRepositoryInterface,

    @Inject('ReasonRepositoryInterface')
    private readonly reasonRepository: ReasonRepositoryInterface,

    @Inject('VendorRepositoryInterface')
    private readonly vendorRepository: VendorRepositoryInterface,

    @Inject('SaleOrderExportRepositoryInterface')
    private readonly saleOrderExportRepository: SaleOrderExportRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}
  async export(request: ExportRequestDto): Promise<any> {
    const { queryIds, type } = request;

    if (!isEmpty(queryIds) && queryIds.length > ROW.LIMIT_EXPORT) {
      return new ResponseBuilder()
        .withMessage(
          await this.i18n.translate('error.LIMIT_EXPORT_ONE_SHEET_ERROR'),
        )
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    const id = 1;
    let workbook;
    switch (type) {
      case TypeEnum.CUSTOMER:
        workbook = await this.exportCustomer(request);
        break;
      case TypeEnum.SALE_ORDER:
        workbook = await this.exportSaleOrder(request);
        break;
      case TypeEnum.PURCHASED_ORDER_IMPORT:
        return await this.exprtPurchasedOrderImport(request);
      case TypeEnum.CONSTRUCTION:
        workbook = await this.exportConstruction(request);
        break;
      case TypeEnum.CONSTRUCTION_CATEGORY:
        workbook = await this.exportConstructionCategory(request);
        break;
      case TypeEnum.SOURCE:
        workbook = await this.exportSource(request);
        break;
      case TypeEnum.REASON:
        workbook = await this.exportReason(request);
        break;
      case TypeEnum.VENDOR:
        workbook = await this.exportVendor(request);
        break;
      case TypeEnum.SALE_ORDER_EXPORT:
        workbook = await this.exportSaleOrderExport(request);
        break;
      case TypeEnum.SALE_ORDER_REPORT:
        workbook = await this.exportSaleOrderReport(request);
        break;
      default:
        break;
    }
    if (workbook?.xlsx) {
      // await workbook?.xlsx.writeFile('export.xlsx');
      const file = await workbook.xlsx.writeBuffer();
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(file)
        .build();
    } else {
      return workbook;
    }
  }
  async exportCustomer(payload: any) {
    let users: any;
    let customers: any[] = [];
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListCustomerRequest();
      request.page = i;
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const list = await this.customerRepository.getList(request);
      if (!isEmpty(list)) {
        customers = customers.concat(first(list));
      }
      if (first(list).length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }
    if (!customers || isEmpty(customers)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }
    const userIds = uniq(map(customers, 'createdBy'));

    if (!isEmpty(userIds)) {
      users = await this.userService.getUsers(uniq(userIds));
    }
    const userMap = keyBy(users, 'id');

    const data = customers.map((customer) => {
      return {
        code: customer.code || '',
        name: customer.name || '',
        address: customer.address || '',
        phone: customer.phone || '',
        email: customer.email || '',
        fax: customer.fax || '',
        description: customer.description || '',
        createdBy: userMap[customer.createdBy]?.fullName || '',
        createdAt: customer.createdAt || '',
      };
    });
    const headers = [
      {
        key: 'code',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.customer.code'),
      },
      {
        key: 'name',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.customer.name'),
      },
      {
        key: 'address',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.customer.address'),
      },
      {
        key: 'phone',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.customer.phone'),
      },
      {
        key: 'fax',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.customer.fax'),
      },
      {
        key: 'email',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.customer.email'),
      },
      {
        key: 'description',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.customer.description'),
      },
      {
        key: 'createdBy',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.common.createdBy'),
      },
      {
        key: 'createdAt',
        width: 25,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
          numFmt: EXCEL_STYLE.DDMMYYYYHHMMSS,
        },
        title: await this.i18n.translate('export.common.createdAt'),
      },
    ];
    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      data,
      [await this.i18n.translate('export.customer.title')],
      headers,
    );

    return workbook;
  }

  async exportSaleOrder(payload: any) {
    let users: any;
    let companies: any[] = [];
    let boqs: any[] = [];
    let saleOrders: any[] = [];
    let concatItemIds: any[] = [];
    const titleMap: any = new Map();
    const headersMap: any = new Map();
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetSaleOrderListRequest();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const list = await this.saleOrderRepository.getList(request);
      if (!isEmpty(list)) {
        saleOrders = saleOrders.concat(first(list));
      }
      if (first(list).length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }
    if (!saleOrders || isEmpty(saleOrders)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }
    const userIds = uniq(map(saleOrders, 'createdBy'));
    if (!isEmpty(userIds)) {
      users = await this.userService.getUsers(uniq(userIds));
    }
    const userMap = keyBy(users, 'id');

    const companyIds = uniq(map(saleOrders, 'companyId'));
    if (!isEmpty(companyIds)) {
      companies = await this.userService.getCompanies(uniq(companyIds));
    }
    const companyMap = keyBy(companies, 'id');

    const boqIds = uniq(map(saleOrders, 'boqId'));
    if (!isEmpty(boqIds)) {
      boqs = await this.produceService.getBoqByIds(uniq(boqIds), true);
    }
    const boqMap = keyBy(boqs, 'id');
    const itemIds = uniq(map(saleOrders, 'itemIds'));
    concatItemIds = concatItemIds.concat(...itemIds);
    const listItem = await this.itemService.getItems(concatItemIds);
    const headers = [
      {
        key: 'code',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrder.code'),
      },
      {
        key: 'name',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrder.name'),
      },
      {
        key: 'boqCode',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrder.boqCode'),
      },
      {
        key: 'companyName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrder.companyName'),
      },
      {
        key: 'customerName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrder.customerName'),
      },
      {
        key: 'description',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrder.description'),
      },
      {
        key: 'status',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrder.status'),
      },
      {
        key: 'createdBy',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.common.createdBy'),
      },
      {
        key: 'createdAt',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
          numFmt: EXCEL_STYLE.DDMMYYYYHHMMSS,
        },
        title: await this.i18n.translate('export.common.createdAt'),
      },
      {
        key: 'orderedAt',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
          numFmt: EXCEL_STYLE.DDMMYYYYHHMMSS,
        },
        title: await this.i18n.translate('export.saleOrder.orderedAt'),
      },
      {
        key: 'deadline',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
          numFmt: EXCEL_STYLE.DDMMYYYYHHMMSS,
        },
        title: await this.i18n.translate('export.common.deadline'),
      },
    ];

    const subHeaders = [
      {
        key: 'code',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrder.code'),
      },
      {
        key: 'itemCode',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrder.item.code'),
      },
      {
        key: 'itemName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrder.item.name'),
      },
      {
        key: 'quantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrder.item.quantity'),
      },
      {
        key: 'itemUnit',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrder.item.itemUnit'),
      },
      {
        key: 'price',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrder.item.price'),
      },
    ];
    const items: any[] = saleOrders?.map((saleOrder) => {
      const item: any = {
        code: saleOrder.code || '',
        name: saleOrder.name || '',
        boqCode: boqMap[saleOrder.boqId]?.code || '',
        companyName: companyMap[saleOrder.companyId].name || '',
        customerName: saleOrder.customer.name || '',
        description: saleOrder.description || '',
        status: saleOrder.status || '',
        createdBy: userMap[saleOrder.createdBy]?.fullName || '',
        createdAt: saleOrder.createdAt || '',
        orderedAt: saleOrder.orderedAt || '',
        deadline: saleOrder.deadline || '',
      };
      return item;
    });
    titleMap.set(1, [await this.i18n.translate('export.saleOrder.title')]);
    titleMap.set(2, [await this.i18n.translate('export.saleOrder.item.title')]);
    headersMap.set(1, headers);
    headersMap.set(2, subHeaders);
    for (let i = 0; i < saleOrders.length; i++) {
      const saleOrder = saleOrders[i];
      const arrItemId = saleOrder.itemIds.map((itemId) => {
        return itemId;
      });
      items[i].subItem = [];
      for (let j = 0; j < listItem.length; j++) {
        const item = listItem[j];
        if (arrItemId.includes(item.itemId)) {
          items[i].subItem.push({
            code: saleOrder.code || '',
            itemCode: item.code || '',
            itemName: item.name || '',
            quantity: item.quantity || 0,
            itemUnit: item.itemUnit || '',
            price: item.price || '',
          });
        }
      }
    }
    let workbook = new Workbook();
    workbook = await this.exportMultiSheetUtil(
      workbook,
      items,
      1,
      titleMap,
      headersMap,
    );
    return workbook;
  }

  async exportOneSheetUtil(data: any[], title: any, headers: any) {
    const workbook = new Workbook();
    let countRowData = ROW.COUNT_START_ROW;
    let countSheet = SHEET.START_SHEET;
    data.forEach((element) => {
      let worksheet = workbook.getWorksheet(SHEET.NAME + countSheet);
      if (countRowData == ROW.COUNT_START_ROW) {
        worksheet = workbook.addWorksheet(SHEET.NAME + countSheet);

        const titleRow = worksheet.getRow(1);
        titleRow.values = title;
        titleRow.font = <Font>EXCEL_STYLE.TITLE_FONT;

        const headerRow = worksheet.getRow(3);
        headerRow.values = headers.map((header) => header.title);
        headerRow.eachCell(function (cell) {
          cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
          cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        });
      }
      worksheet.columns = headers;
      worksheet
        .addRow({
          ...element,
        })
        .eachCell(function (cell) {
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          cell.font = <Font>EXCEL_STYLE.DEFAULT_FONT;
        });

      countRowData++;
      if (countRowData == ROW.COUNT_END_ROW) {
        countSheet++;
        countRowData = ROW.COUNT_START_ROW;
      }
    });
    return workbook;
  }

  async exportMultiSheetUtil(
    workbook: Workbook,
    items: any[],
    level: any,
    titleMap: any,
    headersMap: any,
  ) {
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      let worksheet = workbook.getWorksheet(SHEET.NAME + level);
      if (!worksheet) {
        worksheet = workbook.addWorksheet(SHEET.NAME + level);

        const titleRow = worksheet.getRow(1);
        titleRow.values = titleMap.get(level);
        titleRow.font = <Font>EXCEL_STYLE.TITLE_FONT;

        const headerRow = worksheet.getRow(3);
        headerRow.values = headersMap.get(level).map((header) => header.title);
        headerRow.eachCell(function (cell) {
          cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
          cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        });
        worksheet.columns = headersMap.get(level);
      }

      worksheet
        .addRow({
          ...item,
        })
        .eachCell(function (cell) {
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          cell.font = <Font>EXCEL_STYLE.DEFAULT_FONT;
        });
      if (item.subItem?.length > 0) {
        workbook = await this.exportMultiSheetUtil(
          workbook,
          item.subItem,
          level + 1,
          titleMap,
          headersMap,
        );
      }
    }

    return workbook;
  }

  async exprtPurchasedOrderImport(payload: any) {
    try {
      let id: number;
      if (payload.queryIds) {
        id = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      let res = await this.purchasedOrderImportService.getDetail({
        id: id,
      } as GetOrderDetailRequestDto);
      let { data } = res;
      if (isEmpty(data)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }
      let attributeDetailValues: any = {};
      if (!isEmpty(data.attributes)) {
        const attributeGroup = groupBy(data.attributes, 'tableName');
        const payload = new GetAttributeDetailValuesRequestDto();
        const attributeKeys = Object.keys(attributeGroup).filter(
          (el) => !el.match('null'),
        );
        payload.filter = attributeKeys.map((key) => {
          return {
            tableName: key,
            id: map(attributeGroup[key], 'value').join(','),
          };
        });
        attributeDetailValues =
          await this.warehouseService?.getAttributeDetailValuesTcp(payload);
      }
      const signatures = await this.settingService.getListSignature(
        typeTicket.PURCHASED_ORDER_IMPORT,
      );
      const companyDefault = await this.userService.getCompanyDefault();

      const constructions = attributeDetailValues?.constructions ?? '';
      const categorys = attributeDetailValues?.category_constructions ?? '';
      const dataInput: any = {};
      dataInput.nameCompany = companyDefault?.name ?? '';
      const addressProvince = getProvince(companyDefault?.address ?? '') ?? '';
      dataInput.addressProvince = addressProvince;
      dataInput.addressCompany = companyDefault?.address ?? '';
      dataInput.constructions = constructions;
      dataInput.categorys = categorys;
      dataInput.signatures = signatures;
      const result = await exportPuschasedOrderImportMapping(
        id,
        res,
        dataInput,
        this.i18n,
      );
      return result;
    } catch (error) {
      return new ResponseBuilder(error?.message)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async exportConstruction(payload: any) {
    let constructions: ConstructionEntity[] = [];
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetConstructionListRequestDto();

      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const list = await this.constructionRepository.getList(request);

      if (!isEmpty(list?.result)) {
        constructions = constructions.concat(list.result);
      }
      if (list?.result?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!constructions || isEmpty(constructions)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const headers = [
      {
        key: 'code',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.construction.code'),
      },
      {
        key: 'name',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.construction.name'),
      },
      {
        key: 'description',
        width: 60,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.construction.description'),
      },
      {
        key: 'status',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.common.status'),
      },
    ];

    let items: any[] = [{ code: '*', name: '*', description: '', status: '' }];
    items = items.concat(
      await Promise.all(
        constructions?.map(async (construction) => {
          const item: any = {
            code: construction.code || '',
            name: construction.name || '',
            description: construction.description || '',
            status: await this.i18n.translate(
              `export.common.${construction.status}`,
            ),
          };
          return item;
        }),
      ),
    );

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [await this.i18n.translate('export.construction.title')],
      headers,
    );

    return workbook;
  }

  async exportConstructionCategory(payload: any) {
    let constructionCategories: CategoryContructionEntity[] = [];
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListCategoryContructionRequestDto();

      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const list = await this.categoryContructionRepository.getList(request);

      if (!isEmpty(list?.result)) {
        constructionCategories = constructionCategories.concat(list.result);
      }
      if (list?.result?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!constructionCategories || isEmpty(constructionCategories)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const headers = [
      {
        key: 'code',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.constructionCategory.code'),
      },
      {
        key: 'name',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.constructionCategory.name'),
      },
      {
        key: 'description',
        width: 40,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.constructionCategory.description',
        ),
      },
      {
        key: 'constructionCode',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.constructionCategory.constructionCode',
        ),
      },
      {
        key: 'constructionName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.constructionCategory.constructionName',
        ),
      },
      {
        key: 'constructionDescription',
        width: 40,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.constructionCategory.constructionDescription',
        ),
      },
      {
        key: 'status',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.common.status'),
      },
    ];

    let items: any[] = [
      {
        code: '*',
        name: '*',
        description: '',
        constructionCode: '*',
        constructionName: '',
        constructionDescription: '',
        status: '',
      },
    ];
    items = items.concat(
      await Promise.all(
        constructionCategories?.map(async (category) => {
          const item: any = {
            code: category.code || '',
            name: category.name || '',
            description: category.description || '',
            constructionCode: category?.construction?.code || '',
            constructionName: category?.construction?.name || '',
            constructionDescription: category?.construction?.description || '',
            status: await this.i18n.translate(
              `export.common.${category.status}`,
            ),
          };
          return item;
        }),
      ),
    );

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [await this.i18n.translate('export.constructionCategory.title')],
      headers,
    );

    return workbook;
  }

  async exportSource(payload: any) {
    let sources: SourceEntity[] = [];
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetSourceListRequestDto();

      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const [list] = await this.sourceRepository.getList(request);

      if (!isEmpty(list)) {
        sources = sources.concat(list);
      }
      if (list?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!sources || isEmpty(sources)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const companyIds = map(sources, 'companyId');
    const companyMap = await this.userService.getCompanies(companyIds, true);

    const headers = [
      {
        key: 'code',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.source.code'),
      },
      {
        key: 'name',
        width: 40,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.source.name'),
      },
      {
        key: 'effectiveDate',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.source.effectiveDate'),
      },
      {
        key: 'accountIdentifier',
        width: 50,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.source.accountIdentifier'),
      },
      {
        key: 'companyCode',
        width: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.source.company'),
      },
      {
        key: 'branchCode',
        width: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.source.branch'),
      },
      {
        key: 'costCenterCode',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.source.costCenter'),
      },
      {
        key: 'accountant',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.source.accountant'),
      },
      {
        key: 'produceTypeCode',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.source.produceType'),
      },
      {
        key: 'productCode',
        width: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.source.product'),
      },
      {
        key: 'factorialCode',
        width: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.source.factorial'),
      },
      {
        key: 'internalDepartmentCode',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.source.internalDepartment'),
      },
      {
        key: 'departmentBackupCode',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.source.departmentBackup'),
      },
      {
        key: 'EVNBackupCode',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.source.EVNBackup'),
      },
      {
        key: 'description',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.source.description'),
      },
      {
        key: 'status',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.common.status'),
      },
    ];

    let items: any[] = [];

    items = items.concat(
      await Promise.all(
        sources?.map(async (source) => {
          const companyCode = generatePaddingCode(
            companyMap[source.companyId]?.code || '',
            SOURCE_RULES.COMPANY_CODE.MAX_LENGTH,
          );

          const accountIdentifier = [
            companyCode,
            source.branchCode,
            source.costCenterCode,
            source.accountant,
            source.produceTypeCode,
            source.productCode,
            source.factorialCode,
            source.internalDepartmentCode,
            source.departmentBackupCode,
            source.EVNBackupCode,
          ].join(CODE_DELIMITER);
          const item: any = {
            code: source.code || '',
            name: source.name || '',
            effectiveDate: source.effectiveDate,
            accountIdentifier: accountIdentifier,
            companyCode: companyCode,
            branchCode: source.branchCode,
            costCenterCode: source.costCenterCode,
            accountant: source.accountant,
            produceTypeCode: source.produceTypeCode,
            productCode: source.productCode,
            factorialCode: source.factorialCode,
            internalDepartmentCode: source.internalDepartmentCode,
            departmentBackupCode: source.departmentBackupCode,
            EVNBackupCode: source.EVNBackupCode,
            description: source.description || '',
            status: await this.i18n.translate(`export.common.${source.status}`),
          };
          return item;
        }),
      ),
    );

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [await this.i18n.translate('export.source.title')],
      headers,
    );

    return workbook;
  }

  async exportReason(payload: any) {
    let reasons: ReasonEntity[] = [];
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetReasonListRequestDto();

      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const [list] = await this.reasonRepository.getList(request);

      if (!isEmpty(list)) {
        reasons = reasons.concat(list);
      }
      if (list?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!reasons || isEmpty(reasons)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const headers = [
      {
        key: 'code',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.reason.code'),
      },
      {
        key: 'name',
        width: 40,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.reason.name'),
      },
      {
        key: 'description',
        width: 60,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.reason.description'),
      },
      {
        key: 'status',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.common.status'),
      },
    ];

    let items: any[] = [];

    items = items.concat(
      await Promise.all(
        reasons?.map(async (reason) => {
          const item: any = {
            code: reason.code || '',
            name: reason.name || '',
            description: reason.description || '',
            status: await this.i18n.translate(`export.common.${reason.status}`),
          };
          return item;
        }),
      ),
    );

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [await this.i18n.translate('export.reason.title')],
      headers,
    );

    return workbook;
  }

  async exportVendor(payload: any) {
    let vendors: VendorEntity[] = [];
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetVendorListRequest();

      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const [list] = await this.vendorRepository.getList(request);

      if (!isEmpty(list)) {
        vendors = vendors.concat(list);
      }
      if (list?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!vendors || isEmpty(vendors)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const headers = [
      {
        key: 'code',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.vendor.code'),
      },
      {
        key: 'name',
        width: 40,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.vendor.name'),
      },
      {
        key: 'address',
        width: 40,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.vendor.address'),
      },
      {
        key: 'phone',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.vendor.phone'),
      },
      {
        key: 'fax',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.vendor.fax'),
      },
      {
        key: 'email',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.vendor.email'),
      },
      {
        key: 'description',
        width: 40,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.vendor.description'),
      },
      {
        key: 'status',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.common.status'),
      },
    ];

    let items: any[] = [];

    items = items.concat(
      await Promise.all(
        vendors?.map(async (vendor) => {
          const item: any = {
            code: vendor.code || '',
            name: vendor.name || '',
            address: vendor.address || '',
            phone: vendor.phone || '',
            email: vendor.email || '',
            status: await this.i18n.translate(`export.common.${vendor.status}`),
          };
          return item;
        }),
      ),
    );

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [await this.i18n.translate('export.vendor.title')],
      headers,
    );

    return workbook;
  }

  async exportSaleOrderExport(payload: any) {
    let saleOrderExports: any[] = [];
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetSaleOrderExportListRequest();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const list = await this.saleOrderExportRepository.getListToExport(
        request,
      );

      if (!isEmpty(list)) {
        saleOrderExports = saleOrderExports.concat(list);
      }
      if (list.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }
    if (!saleOrderExports || isEmpty(saleOrderExports)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const businessTypeIdMap = {};
    const userIdMap = {};
    const departmentReceiptIdMap = {};
    const warehouseIdMap = {};
    const reasonIdMap = {};
    const sourceIdMap = {};
    const itemIds = [];
    for (const saleOrderExport of saleOrderExports) {
      const {
        businessTypeId,
        createdBy,
        departmentReceiptId,
        warehouseId,
        reasonId,
        sourceId,
      } = saleOrderExport;
      businessTypeIdMap[businessTypeId] = 1;
      userIdMap[createdBy] = 1;
      departmentReceiptIdMap[departmentReceiptId] = 1;
      warehouseIdMap[warehouseId] = 1;
      if (reasonId) reasonIdMap[reasonId] = 1;
      if (sourceId) sourceIdMap[sourceId] = 1;
      itemIds.push(
        ...map(saleOrderExport.saleOrderExportWarehouseLots, 'itemId'),
      );
    }

    const [
      businessTypeById,
      userById,
      departmentReceiptById,
      warehouses,
      reasons,
      sources,
      items,
    ] = await Promise.all([
      this.warehouseService.getBusinessTypeByIds(
        Object.keys(businessTypeIdMap).map((value) => +value),
        true,
      ),
      this.userService.getUsers(
        Object.keys(userIdMap).map((value) => +value),
        true,
      ),
      this.userService.getDepartmentReceiptByIds(
        Object.keys(departmentReceiptIdMap).map((value) => +value),
        true,
      ),
      this.warehouseService.getWarehouses(
        Object.keys(warehouseIdMap).map((value) => +value),
      ),
      this.reasonRepository.findByCondition({
        id: In(Object.keys(reasonIdMap)),
      }),
      this.sourceRepository.findByCondition({
        id: In(Object.keys(sourceIdMap)),
      }),
      this.itemService.getItems(itemIds),
    ]);

    const warehouseById = keyBy(warehouses, 'id');
    const reasonById = keyBy(reasons, 'id');
    const sourceById = keyBy(sources, 'id');
    const itemMap = keyBy(items, 'itemId');

    const headers = [
      {
        key: 'index',
        width: 7,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER },
        title: await this.i18n.translate('export.saleOrderExport.index'),
      },
      {
        key: 'code',
        width: 17,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderExport.code'),
      },
      {
        key: 'businessType',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderExport.businessType'),
      },
      {
        key: 'status',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderExport.status'),
      },
      {
        key: 'syncStatus',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderExport.syncStatus'),
      },
      {
        key: 'ebsId',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderExport.ebsId'),
      },
      {
        key: 'transactionNumberCreated',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.saleOrderExport.transactionNumberCreated',
        ),
      },
      {
        key: 'createdAt',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderExport.createdAt'),
      },
      {
        key: 'receiptDate',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderExport.receiptDate'),
      },
      {
        key: 'createdByUser',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.saleOrderExport.createdByUser',
        ),
      },
      {
        key: 'departmentReceipt',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.saleOrderExport.departmentReceipt',
        ),
      },
      {
        key: 'warehouseExport',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.saleOrderExport.warehouseExport',
        ),
      },
      {
        key: 'reason',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderExport.reason'),
      },
      {
        key: 'source',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderExport.source'),
      },
      {
        key: 'construction',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderExport.construction'),
      },
      {
        key: 'categoryConstruction',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.saleOrderExport.categoryConstruction',
        ),
      },
      {
        key: 'costType',
        width: 25,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderExport.costType'),
      },
      {
        key: 'organizationPayment',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.saleOrderExport.organizationPayment',
        ),
      },
      {
        key: 'warehouseExportProposals',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.saleOrderExport.warehouseExportProposals',
        ),
      },
      {
        key: 'receiver',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderExport.receiver'),
      },
      {
        key: 'explaination',
        width: 25,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderExport.explaination'),
      },
      {
        key: 'itemCode',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderExport.itemCode'),
      },
      {
        key: 'itemName',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderExport.itemName'),
      },
      {
        key: 'itemUnit',
        width: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderExport.itemUnit'),
      },
      {
        key: 'requestQuantity',
        width: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.saleOrderExport.requestQuantity',
        ),
      },
      {
        key: 'actualQuantity',
        width: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.saleOrderExport.actualQuantity',
        ),
      },
      {
        key: 'amount',
        width: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderExport.amount'),
      },
      {
        key: 'price',
        width: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderExport.price'),
      },
      {
        key: 'debitAccount',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderExport.debitAccount'),
      },
      {
        key: 'creditAccount',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.saleOrderExport.creditAccount',
        ),
      },
    ];

    const SPACE_DASH_SEPARATOR = ' - ';
    const DELIVER_EBS_LABEL = 'Transaction.Transaction history.Receiver';
    let itemArr: any[] = [];
    itemArr = itemArr.concat(
      ...(await Promise.all(
        saleOrderExports?.map(async (saleOrderExport, index) => {
          const {
            id,
            code,
            businessTypeId,
            status,
            syncStatus,
            ebsId,
            transactionNumberCreated,
            createdAt,
            receiptDate,
            createdBy,
            departmentReceiptId,
            warehouseId,
            reasonId,
            sourceId,
            explaination,
          } = saleOrderExport;
          const businessType = businessTypeById[businessTypeId];
          const createdByUser = userById[createdBy];
          const departmentReceipt = departmentReceiptById[departmentReceiptId];
          const warehouse = warehouseById[warehouseId];
          const reason = reasonById[reasonId];
          const source = sourceById[sourceId];

          const businessTypeDetail =
            await this.warehouseService.getBusinessTypeDetail(
              businessTypeId,
              id,
              OrderTypeEnum.SO,
            );

          let attributeDetailValues: any = {};
          let receiver = '';
          if (!isEmpty(businessTypeDetail.bussinessTypeAttributes)) {
            const attributeGroup = groupBy(
              businessTypeDetail.bussinessTypeAttributes,
              'tableName',
            );
            const payload = new GetAttributeDetailValuesRequestDto();
            const attributeKeys = Object.keys(attributeGroup).filter(
              (el) => !el.match('null'),
            );
            payload.filter = attributeKeys.map((key) => {
              return {
                tableName: key,
                id: map(attributeGroup[key], 'value').join(','),
              };
            });
            attributeDetailValues =
              await this.warehouseService?.getAttributeDetailValuesTcp(payload);

            for (const attribute of businessTypeDetail.bussinessTypeAttributes) {
              if (attribute.ebsLabel === DELIVER_EBS_LABEL) {
                receiver = attribute.value;
                break;
              }
            }
          }

          const construction = has(attributeDetailValues, 'constructions')
            ? first(attributeDetailValues.constructions)
            : null;
          const categoryConstruction = has(
            attributeDetailValues,
            'category_constructions',
          )
            ? first(attributeDetailValues.category_constructions)
            : null;
          const costType = has(attributeDetailValues, 'cost_types')
            ? first(attributeDetailValues.cost_types)
            : null;
          const organizationPayment = has(
            attributeDetailValues,
            'organization_payments',
          )
            ? first(attributeDetailValues.organization_payments)
            : null;
          const warehouseExportProposal = has(
            attributeDetailValues,
            'warehouse_export_proposals',
          )
            ? first(attributeDetailValues.warehouse_export_proposals)
            : null;

          const itemEmpty: any = {
            index: '',
            code: '',
            businessType: '',
            status: '',
            syncStatus: '',
            ebsId: '',
            transactionNumberCreated: '',
            createdAt: '',
            receiptDate: '',
            createdByUser: '',
            departmentReceipt: '',
            warehouseExport: '',
            reason: '',
            source: '',
            construction: '',
            categoryConstruction: '',
            costType: '',
            organizationPayment: '',
            warehouseExportProposals: '',
            receiver: '',
            explanation: '',
          };

          const itemFull: any = {
            index: index + 1,
            code: code,
            businessType: businessType
              ? [businessType.code, businessType.name].join(
                  SPACE_DASH_SEPARATOR,
                )
              : '',
            status: await this.i18n.translate(
              `export.saleOrderExport.status-${status}`,
            ),
            syncStatus: await this.i18n.translate(
              `export.saleOrderExport.syncStatus-${syncStatus}`,
            ),
            ebsId: ebsId ?? '',
            transactionNumberCreated: transactionNumberCreated ?? '',
            createdAt: formatDateToExport(createdAt),
            receiptDate: receiptDate,
            createdByUser:
              createdByUser?.fullName || createdByUser?.username || '',
            departmentReceipt: departmentReceipt
              ? [departmentReceipt.code, departmentReceipt.name].join(
                  SPACE_DASH_SEPARATOR,
                )
              : '',
            warehouseExport: warehouse
              ? [warehouse.code, warehouse.name].join(SPACE_DASH_SEPARATOR)
              : '',
            reason: reason
              ? [reason.code, reason.name].join(SPACE_DASH_SEPARATOR)
              : '',
            source: source
              ? [source.code, source.name].join(SPACE_DASH_SEPARATOR)
              : '',
            construction: construction
              ? [construction.code, construction.name].join(
                  SPACE_DASH_SEPARATOR,
                )
              : '',
            categoryConstruction: categoryConstruction
              ? [categoryConstruction.code, categoryConstruction.name].join(
                  SPACE_DASH_SEPARATOR,
                )
              : '',
            costType: costType
              ? [costType.code, costType.name].join(SPACE_DASH_SEPARATOR)
              : '',
            organizationPayment: organizationPayment?.name ?? '',
            warehouseExportProposals: warehouseExportProposal?.code ?? '',
            receiver: receiver ?? '',
            explaination: explaination ?? '',
          };

          let warehouseExportProposalMap = {} as any;
          if (warehouseExportProposal) {
            const detailWarehouseExportProposal =
              await this.warehouseService.getWarehouseExportProposalDetail(
                warehouseExportProposal?.id,
              );

            warehouseExportProposalMap = keyBy(
              detailWarehouseExportProposal.items,
              'itemId',
            );
          }

          return saleOrderExport.saleOrderExportWarehouseLots.map(
            (warehouseLot: any, index: number) => {
              const item = itemMap[warehouseLot.itemId];
              const extraInfo: any = {
                itemCode: item?.code ?? '',
                itemName: item?.name ?? '',
                itemUnit: item?.itemUnit ?? '',
                requestQuantity:
                  warehouseExportProposalMap[warehouseLot.itemId]
                    ?.requestedQuantity ?? 0,
                actualQuantity: warehouseLot?.actualQuantity ?? 0,
                amount: warehouseLot?.amount ?? 0,
                price: warehouseLot?.price ?? 0,
                debitAccount: warehouseLot?.debitAccount ?? '',
                creditAccount: warehouseLot?.creditAccount ?? '',
              };

              const primaryInfo = index === 0 ? itemFull : itemEmpty;

              return {
                ...primaryInfo,
                ...extraInfo,
              };
            },
          );
        }),
      )),
    );

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(itemArr, [], headers);

    return workbook;
  }

  // xuat bao cao tong hop don dat hang
  async exportSaleOrderReport(payload: any) {
    let users: any;
    let saleOrderReports: any[] = [];
    let page: any = 1;
    const count = await this.saleOrderRepository.getCount();
    if (page > MAX_NUMBER_PAGE) {
      page = 10;
    }
    const totalRecord =
      count.cnt > ROW.LIMIT_EXPORT ? ROW.LIMIT_EXPORT : count.cnt;
    page = Math.ceil(totalRecord / ROW.LIMIT_EXPORT_ON_SHEET);
    for (let i = 1; i <= page; i++) {
      const request = new GetSaleOrderListRequest();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const list = await this.saleOrderRepository.getDataReportExport(request);
      if (!isEmpty(list)) {
        saleOrderReports = saleOrderReports.concat(list);
      }
      if (first(list) > ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }
    if (!saleOrderReports || isEmpty(saleOrderReports)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }
    const userIds = uniq(map(saleOrderReports, 'createdByUserId'));
    if (!isEmpty(userIds)) {
      users = await this.userService.getUsers(uniq(userIds));
    }
    const userMap = keyBy(users, 'id');

    let itemIds = [];
    for (let i = 0; i < saleOrderReports.length; ++i) {
      const itemIdDetails = saleOrderReports[i].saleOrderDetails.map(
        (saleOrderDetail) => saleOrderDetail.itemId,
      );
      itemIds = itemIds.concat(itemIdDetails);
    }
    itemIds = uniq(itemIds);
    const itemMap = await this.itemService.getItems(itemIds, null, true);
    const headers = [
      {
        key: 'code',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderReport.code'),
      },
      {
        key: 'name',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderReport.name'),
      },
      {
        key: 'customerName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderReport.customerName'),
      },
      {
        key: 'orderAt',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderReport.orderAt'),
      },
      {
        key: 'deadline',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderReport.deadline'),
      },
      {
        key: 'itemCode',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.saleOrderReport.item.itemCode',
        ),
      },
      {
        key: 'itemName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.saleOrderReport.item.itemName',
        ),
      },
      {
        key: 'itemUnitName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.saleOrderReport.item.itemUnitName',
        ),
      },
      {
        key: 'quantity',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.saleOrderReport.item.quantity',
        ),
      },
      {
        key: 'producedQuantity',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.saleOrderReport.item.producedQuantity',
        ),
      },
      {
        key: 'deliveredQuantity',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.saleOrderReport.item.deliveredQuantity',
        ),
      },
      {
        key: 'notDeliveredQuantity',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.saleOrderReport.item.notDeliveredQuantity',
        ),
      },
      {
        key: 'totalPrice',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
        },
        title: await this.i18n.translate('export.saleOrderReport.totalPrice'),
      },
      {
        key: 'status',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.saleOrderReport.status'),
      },
      {
        key: 'createdBy',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.common.createdBy'),
      },
      {
        key: 'createdAt',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: await this.i18n.translate('export.common.createdAt'),
      },
    ];
    const items: any[] = [];
    for (let i = 0; i < saleOrderReports.length; i++) {
      const saleOrderReport = saleOrderReports[i];
      const saleOrderDetails = saleOrderReport.saleOrderDetails;
      for (let j = 0; j < saleOrderDetails.length; j++) {
        items.push({
          code: saleOrderReport.code || '',
          name: saleOrderReport.name || '',
          customerName: saleOrderReport.customer.name || '',
          orderAt: saleOrderReport.orderedAt
            ? moment(new Date(saleOrderReport.orderedAt), 'DD/MM/YYYY')
                .utc()
                .utcOffset('+07:00')
                .format('DD/MM/YYYY')
            : '',
          deadline: saleOrderDetails[j].deadline
            ? moment(new Date(saleOrderDetails[j].deadline), 'DD/MM/YYYY')
                .utc()
                .utcOffset('+07:00')
                .format('DD/MM/YYYY')
            : '',
          totalPrice: saleOrderReport.totalPrice || '',
          status: statusSaleOrderText(saleOrderReport.status) || '',
          createdBy: userMap[saleOrderReport.createdByUserId]?.fullName || '',
          createdAt: saleOrderReport.createdAt
            ? moment(new Date(saleOrderReport.orderedAt), 'DD/MM/YYYY')
                .utc()
                .utcOffset('+07:00')
                .format('DD/MM/YYYY')
            : '',
          itemCode: itemMap[saleOrderDetails[j].itemId]?.code || '',
          itemName: itemMap[saleOrderDetails[j].itemId]?.name || '',
          itemUnitName:
            itemMap[saleOrderDetails[j].itemId]?.itemUnit?.name || '',
          quantity: saleOrderDetails[j].quantity || 0,
          producedQuantity: saleOrderDetails[j].producedQuantity,
          deliveredQuantity: saleOrderDetails[j].deliveredQuantity || 0,
          notDeliveredQuantity:
            (saleOrderDetails[j].quantity || 0) -
            (saleOrderDetails[j].deliveredQuantity || 0),
        });
      }
    }
    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [await this.i18n.translate('export.saleOrderReport.title')],
      headers,
    );
    return workbook;
  }
}
