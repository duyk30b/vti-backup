import { Controller, Get, Inject, Query, Res } from '@nestjs/common';
import { isEmpty } from 'lodash';
import { ExportRequestDto } from './dto/request/export.request.dto';
import { ExportServiceInterface } from './interface/export.service.interface';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { I18nRequestScopeService } from 'nestjs-i18n';
import * as contentDisposition from 'content-disposition';
import { ResponseBuilder } from '@utils/response-builder';
import { Response } from 'express';

@Controller('export')
export class ExportController {
  constructor(
    @Inject('ExportServiceInterface')
    private readonly exportService: ExportServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  @Get('/')
  @ApiOperation({
    tags: ['Export sale'],
    summary: 'Export',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  // @MessagePattern('export_xlsx')
  public async export(@Query() payload: ExportRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export(request);
  }

  @Get('/purchased-order-import')
  @ApiOperation({
    tags: ['Export sale'],
    summary: 'Export',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  // @MessagePattern('export_xlsx')
  public async exportPurchasedOrderImport(
    @Res({ passthrough: true }) res: Response,
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    const result = await this.exportService.export(request);
    if (!result.nameFile) {
      return result;
    }
    if (!result['error']) {
      const nameFile = result?.nameFile;
      res.header('Content-Disposition', contentDisposition(nameFile + '.docx'));
      res.header('Access-Control-Expose-Headers', '*');
      return result.result;
    }
    return new ResponseBuilder<any>()
      .withCode(400)
      .withData(result)
      .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
      .build();
  }
}
