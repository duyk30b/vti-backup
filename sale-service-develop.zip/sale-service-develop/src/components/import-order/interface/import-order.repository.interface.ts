import { ImportOrderEntity } from '@entities/import-order/import-order.entity';
import { CreateImportOrderRequestDto } from '../dto/request/create-import-order.dto';
import { GetImportOrderListRequest } from '../dto/request/get-import-order-list.request.dto';
import { OrderRepositoryInterface } from '@components/order/interface/order.repository.interface';

export interface ImportOrderRepositoryInterface
  extends OrderRepositoryInterface<ImportOrderEntity> {
  createEntity(
    payload: CreateImportOrderRequestDto,
    id?: number,
  ): ImportOrderEntity;
  getDetail(id: number): Promise<any>;
  getList(request: GetImportOrderListRequest): Promise<any>;
  checkImportOrderCodeExist(code: string, importOrderId?: number);
}
