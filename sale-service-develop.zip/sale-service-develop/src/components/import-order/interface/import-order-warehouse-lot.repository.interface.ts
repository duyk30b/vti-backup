import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ImportOrderWarehouseLotEntity } from '@entities/import-order/import-order-warehouse-lot.entity';

export interface ImportOrderWarehouseLotRepositoryInterface
  extends BaseInterfaceRepository<ImportOrderWarehouseLotEntity> {
  getLotsByItems(
    itemIds: number[],
    lotNumbers: string[],
    warehouseIds: number[],
    orderId: number,
  ): Promise<any>;
  getListLotNumber(
    itemIds?: number[],
    type?: number,
    importOrderId?: number,
  ): Promise<any>;
}
