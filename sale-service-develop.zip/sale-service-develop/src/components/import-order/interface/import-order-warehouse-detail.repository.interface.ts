import { OrderWarehouseDetailRepositoryInterface } from '@components/order/interface/order-warehouse-detail.repository.interface';
import { ImportOrderWarehouseDetailEntity } from '@entities/import-order/import-order-warehouse-detail.entity';

export interface ImportOrderWarehouseDetailRepositoryInterface
  extends OrderWarehouseDetailRepositoryInterface<ImportOrderWarehouseDetailEntity> {}
