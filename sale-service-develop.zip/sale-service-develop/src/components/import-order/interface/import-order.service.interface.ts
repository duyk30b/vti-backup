import { DeleteOrderRequestDto } from '@components/order/dto/request/delete-order.request.dto';
import { GetListOrderByIdsRequestDto } from '@components/order/dto/request/get-list-order-by-ids.request.dto';
import { GetOrderDetailByWarehouseRequestDto } from '@components/order/dto/request/get-order-detail-by-warehouse.request.dto';
import { GetOrderDetailRequestDto } from '@components/order/dto/request/get-order-detail.request.dto';
import { GetOrderWarehouseRequest } from '@components/order/dto/request/get-order-warehouse.request.dto';
import { SetOrderStatusRequestDto } from '@components/order/dto/request/set-order-status-request.dto';
import { UpdateOrderDetailActualQuantityRequestDto } from '@components/order/dto/request/update-actual-quantity-order-detail.request.dto';
import { UpdateOrderDetailConfirmQuantityRequestDto } from '@components/order/dto/request/update-confirm-quantity-order-detail.request.dto';
import { UpdateWarehouseLotRequestDto } from '@components/order/dto/request/update-warehouse-lot.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { CreateImportOrderRequestDto } from '../dto/request/create-import-order.dto';
import { GetImportOrderListRequest } from '../dto/request/get-import-order-list.request.dto';
import { UpdateQcQuantityImoAndExoRequestDto } from '../dto/request/update-imo-exo-qc-quantity.dto';
import { UpdateImportOrderRequestDto } from '../dto/request/update-import-order.dto';
import { ImportOrderListResponseDto } from '../dto/response/import-order-list-response.dto';
import { ImportOrderResponseDto } from '../dto/response/import-order-response.dto';

export interface ImportOrderServiceInterface {
  create(
    payload: CreateImportOrderRequestDto,
  ): Promise<ResponsePayload<ImportOrderResponseDto | any>>;
  update(
    payload: UpdateImportOrderRequestDto,
  ): Promise<ResponsePayload<ImportOrderResponseDto | any>>;
  delete(
    payload: DeleteOrderRequestDto,
  ): Promise<ResponsePayload<SuccessResponse | any>>;
  getDetail(
    payload: GetOrderDetailRequestDto,
  ): Promise<ResponsePayload<ImportOrderResponseDto | any>>;
  confirm(payload: SetOrderStatusRequestDto): Promise<ResponsePayload<any>>;
  reject(payload: SetOrderStatusRequestDto): Promise<ResponsePayload<any>>;
  approve(payload: SetOrderStatusRequestDto): Promise<ResponsePayload<any>>;
  getList(
    payload: GetImportOrderListRequest,
  ): Promise<ResponsePayload<ImportOrderListResponseDto | any>>;
  getListLotNumberByItemId(itemIds: number[]): Promise<ResponsePayload<any>>;
  getWarehouseDetails(
    id: number,
    warehouseId: number,
    type: number,
  ): Promise<any>;
  updateOrderDetailActualQuantity(
    payload: UpdateOrderDetailActualQuantityRequestDto,
  ): Promise<any>;
  updateOrderDetailConfirmQuantity(
    payload: UpdateOrderDetailConfirmQuantityRequestDto,
  ): Promise<any>;
  getDetailByWarehouseId(
    payload: GetOrderDetailByWarehouseRequestDto,
  ): Promise<any>;
  getOrderWarehouses(request: GetOrderWarehouseRequest): Promise<any>;
  updateWarehouseLots(request: UpdateWarehouseLotRequestDto): Promise<any>;
  getListByIds(payload: GetListOrderByIdsRequestDto): Promise<any>;
  updateQcQuantityImoAndExo(
    request: UpdateQcQuantityImoAndExoRequestDto,
  ): Promise<any>;
  confirmMultiple(request: DeleteMultipleDto): Promise<any>
  rejectMultiple(request: DeleteMultipleDto): Promise<any>
  deleteMultiple(request: DeleteMultipleDto): Promise<any>
}
