import { OrderDetailRepositoryInterface } from '@components/order/interface/order-detail.repository.interface';
import { ImportOrderDetailEntity } from '@entities/import-order/import-order-detail.entity';

export interface ImportOrderDetailRepositoryInterface
  extends OrderDetailRepositoryInterface<ImportOrderDetailEntity> {}
