import { WarehouseService } from './../warehouse/warehouse.service';
import { WarehouseModule } from './../warehouse/warehouse.module';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { ProduceService } from '@components/produce/produce.service';
import { ProduceModule } from '@components/produce/produce.module';
import { ConfigService } from '@config/config.service';
import { ClientProxyFactory } from '@nestjs/microservices';
import { ImportOrderController } from './import-order.controller';
import { ImportOrderEntity } from '@entities/import-order/import-order.entity';
import { ImportOrderDetailEntity } from '@entities/import-order/import-order-detail.entity';
import { ImportOrderWarehouseDetailEntity } from '@entities/import-order/import-order-warehouse-detail.entity';
import { ImportOrderRepository } from '@repositories/import-order/import-order.repository';
import { ImportOrderDetailRepository } from '@repositories/import-order/import-order-detail.repository';
import { ImportOrderService } from './import-order.service';
import { ItemService } from '@components/item/item.service';
import { ImportOrderWarehouseDetailRepository } from '@repositories/import-order/import-order-warehouse-detail.repository';
import { MmsModule } from '@components/mmsx/mms.module';
import { MmsService } from '@components/mmsx/mms.service';
import { ImportOrderUpdateActualQuantityListener } from './listeners/import-order-update-actual-quantity.listener';
import { ImportOrderWarehouseLotEntity } from '@entities/import-order/import-order-warehouse-lot.entity';
import { ImportOrderWarehouseLotRepository } from '@repositories/import-order/import-order-warehouse-lot.repository';
import { PurchasedOrderImportWarehouseLotRepository } from '@repositories/purchased-order-import/purchased-order-import-warehouse-lot.repository';
import { PurchasedOrderImportWarehouseLotEntity } from '@entities/purchased-order-import/purchased-order-import-warehouse-lot.entity';
import { WarehouseCronService } from '@components/warehouse/warehouse.cron.service';
import { ImportOrderUpdateConfirmedQuantityListener } from './listeners/import-order-import-update-confimed-quantity.listener';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      ImportOrderEntity,
      ImportOrderDetailEntity,
      ImportOrderWarehouseDetailEntity,
      PurchasedOrderImportWarehouseLotEntity,
      ImportOrderWarehouseLotEntity,
    ]),
    WarehouseModule,
    UserModule,
    MmsModule,
    ProduceModule,
  ],
  providers: [
    {
      provide: 'ImportOrderRepositoryInterface',
      useClass: ImportOrderRepository,
    },
    {
      provide: 'ImportOrderDetailRepositoryInterface',
      useClass: ImportOrderDetailRepository,
    },
    {
      provide: 'ImportOrderWarehouseDetailRepositoryInterface',
      useClass: ImportOrderWarehouseDetailRepository,
    },
    {
      provide: 'ImportOrderWarehouseLotRepositoryInterface',
      useClass: ImportOrderWarehouseLotRepository,
    },
    {
      provide: 'ImportOrderServiceInterface',
      useClass: ImportOrderService,
    },
    {
      provide: 'PurchasedOrderImportWarehouseLotRepositoryInterface',
      useClass: PurchasedOrderImportWarehouseLotRepository,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'MmsServiceInterface',
      useClass: MmsService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'WarehouseCronServiceInterface',
      useClass: WarehouseCronService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'ProduceServiceInterface',
      useClass: ProduceService,
    },
    ConfigService,
    {
      provide: 'PRODUCE_SERVICE',
      useFactory: (configService: ConfigService) => {
        const produceServiceOptions = configService.get('produceService');
        return ClientProxyFactory.create(produceServiceOptions);
      },
      inject: [ConfigService],
    },
    ImportOrderUpdateActualQuantityListener,
    ImportOrderUpdateConfirmedQuantityListener
  ],
  controllers: [ImportOrderController],
})
export class ImporOrderModule {}
