import { ItemService } from '@components/item/item.service';
import { MmsModule } from '@components/mmsx/mms.module';
import { MmsService } from '@components/mmsx/mms.service';
import { ProduceModule } from '@components/produce/produce.module';
import { ProduceService } from '@components/produce/produce.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { WarehouseCronService } from '@components/warehouse/warehouse.cron.service';
import { ConfigService } from '@config/config.service';
import { ImportOrderDetailEntity } from '@entities/import-order/import-order-detail.entity';
import { ImportOrderWarehouseDetailEntity } from '@entities/import-order/import-order-warehouse-detail.entity';
import { ImportOrderWarehouseLotEntity } from '@entities/import-order/import-order-warehouse-lot.entity';
import { ImportOrderEntity } from '@entities/import-order/import-order.entity';
import { PurchasedOrderImportWarehouseLotEntity } from '@entities/purchased-order-import/purchased-order-import-warehouse-lot.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ImportOrderDetailRepository } from '@repositories/import-order/import-order-detail.repository';
import { ImportOrderWarehouseDetailRepository } from '@repositories/import-order/import-order-warehouse-detail.repository';
import { ImportOrderWarehouseLotRepository } from '@repositories/import-order/import-order-warehouse-lot.repository';
import { ImportOrderRepository } from '@repositories/import-order/import-order.repository';
import { PurchasedOrderImportWarehouseLotRepository } from '@repositories/purchased-order-import/purchased-order-import-warehouse-lot.repository';
import { WarehouseModule } from './../warehouse/warehouse.module';
import { WarehouseService } from './../warehouse/warehouse.service';
import { ImportOrderController } from './import-order.controller';
import { ImportOrderService } from './import-order.service';
import { ImportOrderUpdateConfirmedQuantityListener } from './listeners/import-order-import-update-confimed-quantity.listener';
import { ImportOrderUpdateActualQuantityListener } from './listeners/import-order-update-actual-quantity.listener';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      ImportOrderEntity,
      ImportOrderDetailEntity,
      ImportOrderWarehouseDetailEntity,
      PurchasedOrderImportWarehouseLotEntity,
      ImportOrderWarehouseLotEntity,
    ]),
    WarehouseModule,
    UserModule,
    MmsModule,
    ProduceModule,
  ],
  providers: [
    {
      provide: 'ImportOrderRepositoryInterface',
      useClass: ImportOrderRepository,
    },
    {
      provide: 'ImportOrderDetailRepositoryInterface',
      useClass: ImportOrderDetailRepository,
    },
    {
      provide: 'ImportOrderWarehouseDetailRepositoryInterface',
      useClass: ImportOrderWarehouseDetailRepository,
    },
    {
      provide: 'ImportOrderWarehouseLotRepositoryInterface',
      useClass: ImportOrderWarehouseLotRepository,
    },
    {
      provide: 'ImportOrderServiceInterface',
      useClass: ImportOrderService,
    },
    {
      provide: 'PurchasedOrderImportWarehouseLotRepositoryInterface',
      useClass: PurchasedOrderImportWarehouseLotRepository,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'MmsServiceInterface',
      useClass: MmsService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'WarehouseCronServiceInterface',
      useClass: WarehouseCronService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'ProduceServiceInterface',
      useClass: ProduceService,
    },
    ConfigService,
    ImportOrderUpdateActualQuantityListener,
    ImportOrderUpdateConfirmedQuantityListener,
  ],
  controllers: [ImportOrderController],
})
export class ImporOrderModule {}
