import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { plainToInstance } from 'class-transformer';
import {
  map,
  uniq,
  keyBy,
  isNull,
  isEmpty,
  compact,
  first,
  filter,
  find,
  has,
  values,
  flatMap,
} from 'lodash';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, ILike, In } from 'typeorm';
import { Inject, Injectable } from '@nestjs/common';
import { ImportOrderServiceInterface } from './interface/import-order.service.interface';
import { ImportOrderRepositoryInterface } from './interface/import-order.repository.interface';
import { ImportOrderDetailRepositoryInterface } from './interface/import-order-detail.repository.interface';
import { ImportOrderWarehouseDetailRepositoryInterface } from './interface/import-order-warehouse-detail.repository.interface';
import { I18nRequestScopeService } from 'nestjs-i18n';
import {
  CAN_UPDATE_ORDER_STATUS,
  OrderStatusEnum,
  STATUS_TO_APPROVE_ORDER_STATUS,
  STATUS_TO_CONFIRM_ORDER_STATUS,
  STATUS_TO_DELETE_ORDER_STATUS,
  STATUS_TO_REJECT_ORDER_STATUS,
} from '@constant/order.constant';
import { ImportOrderDetailEntity } from '@entities/import-order/import-order-detail.entity';
import { ImportOrderEntity } from '@entities/import-order/import-order.entity';
import { ImportOrderWarehouseDetailEntity } from '@entities/import-order/import-order-warehouse-detail.entity';
import { CreateImportOrderRequestDto } from './dto/request/create-import-order.dto';
import { ResponsePayload } from '@utils/response-payload';
import {
  ImportOrder,
  ImportOrderResponseDto,
} from './dto/response/import-order-response.dto';
import { UpdateImportOrderRequestDto } from './dto/request/update-import-order.dto';
import { GetImportOrderListRequest } from './dto/request/get-import-order-list.request.dto';
import { ImportOrderListResponseDto } from './dto/response/import-order-list-response.dto';
import { SetOrderStatusRequestDto } from '@components/order/dto/request/set-order-status-request.dto';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { MmsServiceInterface } from '@components/mmsx/interface/mms.service.interface';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { PagingResponse } from '@utils/paging.response';
import { LotNumberOfItemResponseDto } from './dto/response/list-lot-number.response.dto';
import * as Moment from 'moment';
import { UpdateOrderDetailActualQuantityRequestDto } from '@components/order/dto/request/update-actual-quantity-order-detail.request.dto';
import { UpdateOrderDetailConfirmQuantityRequestDto } from '@components/order/dto/request/update-confirm-quantity-order-detail.request.dto';
import { GetOrderDetailByWarehouseRequestDto } from '@components/order/dto/request/get-order-detail-by-warehouse.request.dto';
import { GetOrderWarehouseRequest } from '@components/order/dto/request/get-order-warehouse.request.dto';
import { searchLikeString } from '@utils/helper';
import { OrderWarehouseResponse } from '@components/order/dto/response/order-warehouse-response.dto';
import { OrderServiceAbstract } from '@components/order/interface/order.service.abstract';
import { GetOrderDetailRequestDto } from '@components/order/dto/request/get-order-detail.request.dto';
import { DeleteOrderRequestDto } from '@components/order/dto/request/delete-order.request.dto';
import { ImportOrderWarehouseDetailResponseDto } from './dto/response/import-order-warehouse-detail-response.dto';
import { OrderUpdateActualQuantityEvent } from '@components/order/events/order-update-actual-quantity.event';
import { OrderTypeEnum as SaleOrderTypeEnum } from '@constant/order.constant';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { UpdateWarehouseLotRequestDto } from '@components/order/dto/request/update-warehouse-lot.request.dto';
import { ImportOrderWarehouseLotEntity } from '@entities/import-order/import-order-warehouse-lot.entity';
import { ImportOrderWarehouseLotRepositoryInterface } from './interface/import-order-warehouse-lot.repository.interface';
import { getInnerJoinElements, plus } from '@utils/common';
import { UpdateActualQuantityImORequestDto } from '@components/mmsx/dto/request/update-actual-quantity-imo.request.dto';
import { OrderTypeEnum, ROLE, STATUS_TO_QC_ORDER } from '@constant/common';
import { OtherOrderUpdateConfirmedQuantityEvent } from './events/other-order-update-confirmed-quantity.event';
import { PurchasedOrderImportWarehouseLotRepositoryInterface } from '@components/purchased-order-import/interface/purchased-order-import-warehouse-lot.repository.interface';
import { GetPositionItemsByConditionsRequestDto } from '@components/item/dto/request/filter-position-items-by-conditions.request.dto';
import { GetListOrderByIdsRequestDto } from '@components/order/dto/request/get-list-order-by-ids.request.dto';
import { UpdateQcQuantityImoAndExoRequestDto } from './dto/request/update-imo-exo-qc-quantity.dto';
import { GetListWarehouseExitsFloorRequestDto } from '@components/warehouse/dto/request/get-warehouse-exits-floor.request.dto';
import { QualityControlServiceInterface } from '@components/qmx/interface/quality-control.service.interface';
import { UpdateActualQuantityPlanIoQcRequestDto } from '@components/qmx/dto/request/update-actual-quantity-plan-io-qc.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { stringFormat } from '@utils/object.util';
import { PushNotificationRequestDto } from '@components/notification/dto/notification.request.dto';
import {
  ActionNotificationEnum,
  TypeNotificationEnum,
  MesModuleEnum,
} from '@components/notification/notification.const';

@Injectable()
export class ImportOrderService
  extends OrderServiceAbstract
  implements ImportOrderServiceInterface
{
  constructor(
    @Inject('ImportOrderWarehouseDetailRepositoryInterface')
    private readonly importOrderWarehouseDetailRepository: ImportOrderWarehouseDetailRepositoryInterface,

    @Inject('ImportOrderRepositoryInterface')
    private readonly importOrderRepository: ImportOrderRepositoryInterface,

    @Inject('ImportOrderDetailRepositoryInterface')
    private readonly importOrderDetailRepository: ImportOrderDetailRepositoryInterface,

    @Inject('PurchasedOrderImportWarehouseLotRepositoryInterface')
    private readonly purchasedOrderImportWarehouseLotRepository: PurchasedOrderImportWarehouseLotRepositoryInterface,

    @Inject('ImportOrderWarehouseLotRepositoryInterface')
    private readonly importOrderWarehouseLotRepository: ImportOrderWarehouseLotRepositoryInterface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('MmsServiceInterface')
    protected readonly mmsService: MmsServiceInterface,

    @Inject('QualityControlServiceInterface')
    protected readonly qmsxService: QualityControlServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nRequestScopeService,

    private eventEmitter: EventEmitter2,
  ) {
    super(itemService, warehouseService, userService);
  }

  public async create(payload: CreateImportOrderRequestDto): Promise<any> {
    const { code, requestId } = payload;

    if (requestId) {
      const checkExitId = await this.checkRequestIdExistInIMO(requestId);
      if (checkExitId) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.REQUEST_ID_IS_EXIST_IN_IMO'),
          )
          .build();
      }
      const request = await this.getRequestById(requestId);
      if (isEmpty(request)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.REQUEST_NOT_FOUND'))
          .build();
      }
    }

    const importOrderCodeExist =
      await this.importOrderRepository.checkImportOrderCodeExist(code);

    if (importOrderCodeExist.length > 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.CODE_IS_EXIST'))
        .build();
    }

    const importOrderEntity = await this.importOrderRepository.createEntity(
      payload,
    );
    importOrderEntity.status = OrderStatusEnum.Pending;

    return await this.save(importOrderEntity, payload);
  }

  public async update(
    payload: UpdateImportOrderRequestDto,
  ): Promise<ResponsePayload<ImportOrderResponseDto | any>> {
    const { id, code, requestId } = payload;
    const importOrder = await this.importOrderRepository.findOneById(id);
    if (!importOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_UPDATE_ORDER_STATUS.includes(importOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }
    if (requestId) {
      const checkExitId = await this.checkRequestIdExistInIMO(requestId, id);

      if (checkExitId) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.REQUEST_ID_IS_EXIST_IN_IMO'),
          )
          .build();
      }
      const request = await this.getRequestById(requestId);
      if (isEmpty(request)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.REQUEST_NOT_FOUND'))
          .build();
      }
    }

    const importOrderCodeExist =
      await this.importOrderRepository.checkImportOrderCodeExist(code, id);

    if (importOrderCodeExist.length > 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.CODE_IS_EXIST'))
        .build();
    }

    const importOrderEntity = await this.importOrderRepository.createEntity(
      payload,
      importOrder.id,
    );

    if (importOrder.status === OrderStatusEnum.Reject) {
      importOrderEntity.status = OrderStatusEnum.Pending;
    }

    return await this.save(importOrderEntity, payload);
  }

  public async getDetail(payload: GetOrderDetailRequestDto): Promise<any> {
    const { id } = payload;
    const importOrder = await this.importOrderRepository.getDetail(id);

    if (!importOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (importOrder.requestId) {
      importOrder.request = await this.getRequestById(importOrder.requestId);
    }

    const packageIds = uniq(
      map(importOrder.importOrderWarehouseLots, 'packageId'),
    );

    const itemIds = uniq(map(importOrder.importOrderWarehouseLots, 'itemId'));
    const userIds = uniq([
      importOrder.confirmerId,
      importOrder.approverId,
    ]).filter((id) => !isNull(id));
    const warehouseIds = uniq(
      map(importOrder.importOrderWarehouseDetails, 'warehouseId'),
    );

    const [items, warehouses, users, packages] = await Promise.all([
      this.itemService.getItems(itemIds),
      this.warehouseService.getWarehouses(warehouseIds),
      this.userService.getUsers(userIds),
      this.itemService.getPackageByIds(packageIds),
    ]);

    const normalizePackages = keyBy(packages, 'id');
    const normalizeItems = keyBy(items, 'itemId');
    const normalizeWarehouses = keyBy(warehouses, 'id');
    const normalizeUsers = keyBy(users, 'id');

    importOrder.approver = normalizeUsers[importOrder.approverId];
    importOrder.confirmer = normalizeUsers[importOrder.confirmerId];

    importOrder.importOrderDetails = importOrder.importOrderDetails.map(
      (importOrderDetail) => ({
        ...importOrderDetail,
        item: normalizeItems[importOrderDetail.itemId]
          ? normalizeItems[importOrderDetail.itemId]
          : {},
      }),
    );

    importOrder.importOrderWarehouseLots =
      importOrder.importOrderWarehouseLots.map((importOrderWarehouseLot) => ({
        ...importOrderWarehouseLot,
        package: normalizePackages[importOrderWarehouseLot.packageId]
          ? normalizePackages[importOrderWarehouseLot.packageId]
          : {},
        item: normalizeItems[importOrderWarehouseLot.itemId]
          ? normalizeItems[importOrderWarehouseLot.itemId]
          : {},
        warehouse: normalizeWarehouses[importOrderWarehouseLot.warehouseId]
          ? normalizeWarehouses[importOrderWarehouseLot.warehouseId]
          : {},
      }));

    importOrder.importOrderWarehouseDetails =
      importOrder.importOrderWarehouseDetails.map(
        (importOrderWarehouseDetail) => ({
          ...importOrderWarehouseDetail,
          item: normalizeItems[importOrderWarehouseDetail.itemId]
            ? normalizeItems[importOrderWarehouseDetail.itemId]
            : {},
          warehouse: normalizeWarehouses[importOrderWarehouseDetail.warehouseId]
            ? normalizeWarehouses[importOrderWarehouseDetail.warehouseId]
            : {},
        }),
      );

    const dataReturn = plainToInstance(ImportOrder, importOrder, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Delete
   */
  public async delete(payload: DeleteOrderRequestDto): Promise<any> {
    const { id } = payload;
    const importOrder = await this.importOrderRepository.findOneById(id);
    if (!importOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_DELETE_ORDER_STATUS.includes(importOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.delete(ImportOrderWarehouseLotEntity, {
        importOrderId: id,
      });
      await queryRunner.manager.delete(ImportOrderDetailEntity, {
        importOrderId: id,
      });
      await queryRunner.manager.delete(ImportOrderWarehouseDetailEntity, {
        importOrderId: id,
      });
      await queryRunner.manager.delete(ImportOrderEntity, id);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }
    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Delete
   */
  public async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const importOrders = await this.importOrderRepository.findByCondition({
      id: In(ids),
    });

    const importOrderIds = importOrders.map((importOrder) => importOrder.id);
    if (importOrderIds.length !== ids.length) {
      ids.forEach((id) => {
        if (!importOrderIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < importOrders.length; i++) {
      const importOrder = importOrders[i];
      if (!STATUS_TO_DELETE_ORDER_STATUS.includes(importOrder.status))
        failIdsList.push(importOrder.id);
    }

    const validIds = importOrders
      .filter((importOrder) => !failIdsList.includes(importOrder.id))
      .map((importOrder) => importOrder.id);

    const queryRunner = await this.connection.createQueryRunner();
    try {
      if (!isEmpty(validIds)) {
        await queryRunner.startTransaction();
        await queryRunner.manager.delete(ImportOrderWarehouseLotEntity, {
          importOrderId: In(validIds),
        });
        await queryRunner.manager.delete(ImportOrderDetailEntity, {
          importOrderId: In(validIds),
        });
        await queryRunner.manager.delete(ImportOrderWarehouseDetailEntity, {
          importOrderId: In(validIds),
        });
        await queryRunner.manager.delete(ImportOrderEntity, validIds);
        await queryRunner.commitTransaction();
      }
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    await queryRunner.release();
    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async getList(
    payload: GetImportOrderListRequest,
  ): Promise<ResponsePayload<ImportOrderListResponseDto | any>> {
    const { page, user } = payload;
    if (!payload.filter) payload.filter = [];
    const userWarehouses = await this.userService.getUserWarehousesById(
      user.id,
    );

    if (isEmpty(userWarehouses)) {
      return new ResponseBuilder<PagingResponse>({
        items: [],
        meta: { total: 0, page: 1 },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    const filterWarehouseId = payload.filter.find(
      (filter) => filter.column === 'warehouseId',
    );

    let warehouseIds = map(
      userWarehouses,
      (userWarehouse) => +userWarehouse.id,
    );
    if (filterWarehouseId) {
      warehouseIds = getInnerJoinElements(
        warehouseIds,
        filterWarehouseId.text.split(',').map((warehouseId) => +warehouseId),
      );
      if (isEmpty(warehouseIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: payload.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
      }
    }

    payload.filter.push({
      column: 'warehouseId',
      text: warehouseIds.join(','),
    });

    const [data, count] = await this.importOrderRepository.getList(payload);

    const dataReturn = plainToInstance(ImportOrder, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async confirm(
    payload: SetOrderStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, userId } = payload;
    const importOrder = await this.importOrderRepository.findOneById(id);
    if (!importOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_CONFIRM_ORDER_STATUS.includes(importOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }
    importOrder.status = OrderStatusEnum.Confirmed;

    //Push notification
    const user = await this.userService.getUserById(userId);
    const notificationRequest = new PushNotificationRequestDto();
    notificationRequest.type = TypeNotificationEnum.WEB;
    notificationRequest.action = ActionNotificationEnum.WAREHOUSE_YARD;
    notificationRequest.content = importOrder.description;
    //TODO SnP waiting
    notificationRequest.templateId = '62675f887848315c26a23033';
    notificationRequest.executionDate = new Date().toISOString();
    notificationRequest.title =
      MesModuleEnum.WMSX +
      ` ${
        user.username +
        (await this.i18n.translate(
          'error.IMPORT_ORDER_CONFIRMED_NOTIFICATION',
        )) +
        importOrder.name
      }`;
    notificationRequest.payload = {
      title: notificationRequest.title,
      content: importOrder.description,
    };
    notificationRequest.userIds = [importOrder.createdByUserId];
    const pushMail = Object.assign(notificationRequest, {
      type: TypeNotificationEnum.MAIL,
    });
    this.eventEmitter.emit('purchased_order_import.confirm', pushMail);
    this.eventEmitter.emit(
      'purchased_order_import.confirm',
      notificationRequest,
    );
    const result = await this.importOrderRepository.create(importOrder);

    const dataReturn = plainToInstance(ImportOrder, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async confirmMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const importOrders = await this.importOrderRepository.findByCondition({
      id: In(ids),
    });

    const importOrderIds = importOrders.map((importOrder) => importOrder.id);
    if (importOrders.length !== ids.length) {
      ids.forEach((id) => {
        if (!importOrderIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < importOrders.length; i++) {
      const importOrder = importOrders[i];
      if (!STATUS_TO_CONFIRM_ORDER_STATUS.includes(importOrder.status))
        failIdsList.push(importOrder.id);
    }

    const validIds = importOrders
      .filter((importOrder) => !failIdsList.includes(importOrder.id))
      .map((importOrder) => importOrder.id);

    const validImportOrders = importOrders.filter((importOrder) =>
      validIds.includes(importOrder.id),
    );

    if (!isEmpty(validImportOrders)) {
      validImportOrders.forEach((importOrder) => {
        importOrder.status = OrderStatusEnum.Confirmed;
        importOrder.approvedAt = new Date(Date.now());
      });
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(ImportOrderEntity, validImportOrders);
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.CONFIRM_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async reject(
    payload: SetOrderStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, userId } = payload;
    const importOrder = await this.importOrderRepository.findOneById(id);
    if (!importOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_REJECT_ORDER_STATUS.includes(importOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }
    importOrder.status = OrderStatusEnum.Reject;
    //Push notification
    const user = await this.userService.getUserById(userId);
    const notificationRequest = new PushNotificationRequestDto();
    notificationRequest.title =
      MesModuleEnum.WMSX +
      ` ${
        user.username +
        (await this.i18n.translate('error.IMPORT_ORDER_REJECT_NOTIFICATION')) +
        importOrder.name
      }`;
    notificationRequest.type = TypeNotificationEnum.WEB;
    notificationRequest.action = ActionNotificationEnum.WAREHOUSE_YARD;
    notificationRequest.content = importOrder.description;
    //TODO SnP waiting
    notificationRequest.templateId = '62675f887848315c26a23033';
    notificationRequest.executionDate = new Date().toISOString();
    notificationRequest.payload = {
      title: notificationRequest.title,
      content: importOrder.description,
    };
    notificationRequest.userIds = [importOrder.createdByUserId];
    const pushMail = Object.assign(notificationRequest, {
      type: TypeNotificationEnum.MAIL,
    });
    this.eventEmitter.emit('purchased_order_import.reject', pushMail);
    this.eventEmitter.emit(
      'purchased_order_import.reject',
      notificationRequest,
    );

    const result = await this.importOrderRepository.create(importOrder);

    const dataReturn = plainToInstance(ImportOrder, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async rejectMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const importOrders = await this.importOrderRepository.findByCondition({
      id: In(ids),
    });

    const importOrderIds = importOrders.map((importOrder) => importOrder.id);
    if (importOrders.length !== ids.length) {
      ids.forEach((id) => {
        if (!importOrderIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < importOrders.length; i++) {
      const importOrder = importOrders[i];
      if (!STATUS_TO_REJECT_ORDER_STATUS.includes(importOrder.status))
        failIdsList.push(importOrder.id);
    }

    const validIds = importOrders
      .filter((importOrder) => !failIdsList.includes(importOrder.id))
      .map((importOrder) => importOrder.id);

    const validImportOrders = importOrders.filter((importOrder) =>
      validIds.includes(importOrder.id),
    );

    if (!isEmpty(validImportOrders)) {
      validImportOrders.forEach((importOrder) => {
        importOrder.status = OrderStatusEnum.Reject;
        importOrder.approvedAt = new Date(Date.now());
      });
      const queryRunner = this.connection.createQueryRunner();
      try {
        await queryRunner.startTransaction();
        await queryRunner.manager.save(ImportOrderEntity, validImportOrders);
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.REJECT_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async approve(
    payload: SetOrderStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id } = payload;
    const importOrder = await this.importOrderRepository.findOneById(id);
    if (!importOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_APPROVE_ORDER_STATUS.includes(importOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }
    importOrder.status = OrderStatusEnum.Approved;

    const result = await this.importOrderRepository.create(importOrder);

    const dataReturn = plainToInstance(ImportOrder, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getListLotNumberByItemId(
    itemIds: number[],
  ): Promise<ResponsePayload<any>> {
    const [lotNumberOfPoimp, lotNumberOfImo] = await Promise.all([
      this.purchasedOrderImportWarehouseLotRepository.getListLotNumber(itemIds),
      this.importOrderWarehouseLotRepository.getListLotNumber(itemIds),
    ]);
    const arrLotNumber = [...lotNumberOfPoimp, ...lotNumberOfImo];
    const result = arrLotNumber.reduce((record, item) => {
      const temp = record.find((x) => x.itemId === item.itemId);
      if (!temp) {
        record.push({
          itemId: item.itemId,
          lotNumbers: [item],
        });
      } else {
        temp.lotNumbers.push(item);
      }
      return record;
    }, []);
    const dataReturn = plainToInstance(LotNumberOfItemResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public getWarehouseDetails(
    id: number,
    warehouseId: number,
    type: number,
  ): Promise<any> {
    return;
  }

  public async updateOrderDetailActualQuantity(
    payload: UpdateOrderDetailActualQuantityRequestDto,
  ): Promise<any> {
    const { orderId, orderDetails, warehouseOrderDetails, itemLots } = payload;

    const importOrder = await this.importOrderRepository.findOneById(orderId);

    if (isEmpty(importOrder)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    let message;
    let code = ResponseCodeEnum.SUCCESS;

    const requestQmsx = new UpdateActualQuantityPlanIoQcRequestDto();
    requestQmsx.data = [];
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const importOrderWarehouseLotEntities =
        await this.importOrderWarehouseLotRepository.getLotsByItems(
          map(itemLots, 'itemId'),
          map(itemLots, 'lotNumber'),
          map(itemLots, 'warehouseId'),
          orderId,
        );

      const updateImportOrderDetailEntities =
        await this.importOrderDetailRepository.getUpdateOrderDetailActualQuantityByIds(
          orderId,
          orderDetails,
        );

      const updateImportOrderWarehouseDetailEntities =
        await this.importOrderWarehouseDetailRepository.getUpdateOrderWarehouseDetailActualQuantityByIds(
          orderId,
          warehouseOrderDetails,
        );

      importOrderWarehouseLotEntities.forEach(
        (importOrderWarehouseLotEntity: ImportOrderWarehouseLotEntity) => {
          const itemLot = find(
            itemLots,
            (iL) =>
              iL.itemId === importOrderWarehouseLotEntity.itemId &&
              iL.lotNumber.toUpperCase() ===
                importOrderWarehouseLotEntity.lotNumber.toUpperCase(),
          );
          if (itemLot) {
            importOrderWarehouseLotEntity.actualQuantity = plus(
              importOrderWarehouseLotEntity.actualQuantity,
              itemLot.quantity,
            );
          }
        },
      );

      await queryRunner.manager.save(updateImportOrderDetailEntities);
      await queryRunner.manager.save(updateImportOrderWarehouseDetailEntities);
      await queryRunner.manager.save(importOrderWarehouseLotEntities);

      await queryRunner.commitTransaction();
    } catch (error) {
      message = error;
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      await queryRunner.rollbackTransaction();
    }
    await queryRunner.release();
    if (importOrder.requestId && importOrder.type === OrderTypeEnum.Export) {
      await this.updateActualExOMMS(importOrder, payload);
    }

    return new ResponseBuilder()
      .withCode(code)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  public async updateOrderDetailConfirmQuantity(
    payload: UpdateOrderDetailConfirmQuantityRequestDto,
  ): Promise<any> {
    const { orderId, orderDetails, warehouseOrderDetails, userId } = payload;
    const order = await this.importOrderRepository.findOneById(orderId);
    let message;
    let code = ResponseCodeEnum.SUCCESS;
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const updateImportOrderDetailEntities =
        await this.importOrderDetailRepository.getUpdateOrderDetailConfirmQuantityByIds(
          orderId,
          orderDetails,
        );

      const updateImportdOrderWarehouseDetailEntities =
        await this.importOrderWarehouseDetailRepository.getUpdateOrderWarehouseDetailConfirmQuantityByIds(
          orderId,
          warehouseOrderDetails,
        );

      await queryRunner.manager.save(updateImportOrderDetailEntities);
      await queryRunner.manager.save(updateImportdOrderWarehouseDetailEntities);
      await queryRunner.commitTransaction();
    } catch (error) {
      message = error;
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      await queryRunner.rollbackTransaction();
    } finally {
      await queryRunner.release();
    }
    return new ResponseBuilder()
      .withCode(code)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getDetailByWarehouseId(
    payload: GetOrderDetailByWarehouseRequestDto,
  ): Promise<any> {
    const { id, warehouseId, user, warehouseShelfFloorId } = payload;
    const isWarehouseOfUser = await this.userService.getUserWarehousesById(
      user.id,
    );

    if (!isWarehouseOfUser) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const importOrder = await this.importOrderRepository.getDetailByWarehouseId(
      id,
      [warehouseId],
    );

    if (!importOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const itemIds = map(importOrder.items, 'id');
    const userIds = uniq([
      importOrder.createdByUserId,
      importOrder.confirmerId,
      importOrder.approverId,
    ]).filter((id) => !isNull(id));

    const { items, warehouses, users } = await super.getOrderExtraInfo(
      itemIds,
      [warehouseId],
      userIds,
    );
    const normalizeItems = {};
    const normalizeUsers = {};
    const normalizeWarehouses = {};

    items.forEach((item) => {
      normalizeItems[item.itemId] = item;
    });
    warehouses.forEach((warehouse) => {
      normalizeWarehouses[warehouse.id] = warehouse;
    });
    users.forEach((user) => {
      normalizeUsers[user.id] = user;
    });
    importOrder.createdByUser = normalizeUsers[importOrder.createdByUserId];
    importOrder.approver = normalizeUsers[importOrder.approverId];
    importOrder.confirmer = normalizeUsers[importOrder.confirmerId];
    importOrder.warehouse = normalizeWarehouses[warehouseId];
    let itemStockLots = [];
    if (importOrder.type === OrderTypeEnum.Export) {
      const requestFilterPositionItems =
        new GetPositionItemsByConditionsRequestDto();
      requestFilterPositionItems.conditions = [];
      importOrder.items.forEach((item) => {
        item.lots.forEach((lot) => {
          requestFilterPositionItems.conditions.push({
            itemId: item.id,
            lotNumber: lot.lotNumber,
            warehouseShelfFloorId,
          });
        });
      });

      itemStockLots = await this.itemService.getPositionItemsByCondition(
        requestFilterPositionItems,
      );
    }

    importOrder.items = importOrder.items.map((item) => ({
      ...normalizeItems[item.id],
      ...item,
      lots:
        importOrder.type === OrderTypeEnum.Export
          ? item.lots
              .map((lot) => {
                const location = itemStockLots.find(
                  (itemStock) =>
                    (itemStock.itemId =
                      item.id &&
                      itemStock.lotNumber.toUpperCase() ===
                        lot.lotNumber.toUpperCase() &&
                      itemStock.warehouseShelfFloorId ===
                        warehouseShelfFloorId),
                );
                return location
                  ? {
                      ...location,
                      ...lot,
                      id: location.id,
                      remainStockQuantity: location.quantity,
                    }
                  : {};
              })
              .filter((l) => !isEmpty(l))
          : item.lots,
    }));

    const dataReturn = plainToInstance(
      ImportOrderWarehouseDetailResponseDto,
      importOrder,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  public async getOrderWarehouses(
    request: GetOrderWarehouseRequest,
  ): Promise<any> {
    const { id, user, keyword } = request;
    const userWarehouses = await this.userService.getUserWarehousesById(
      user.id,
    );
    const importOrder = await this.importOrderRepository.findOneById(+id);
    let warehouseIds = [];
    if (!isEmpty(keyword)) {
      warehouseIds = filter(
        userWarehouses,
        (warehouse) =>
          searchLikeString(warehouse.name, keyword) ||
          searchLikeString(warehouse.code, keyword),
      ).map((w) => w.id);
    } else {
      warehouseIds = userWarehouses.map((e) => e.id);
    }

    const data =
      await this.importOrderWarehouseDetailRepository.getListOrderWarehouse(
        request,
        warehouseIds,
      );

    const requestWarehouseExistFloor =
      new GetListWarehouseExitsFloorRequestDto();
    requestWarehouseExistFloor.isSpace =
      importOrder.type === OrderTypeEnum.Import ? '1' : '0';
    requestWarehouseExistFloor.sort = request.sort;
    requestWarehouseExistFloor.limit = request.limit;
    requestWarehouseExistFloor.page = request.page;
    requestWarehouseExistFloor.filter = [
      {
        column: 'ids',
        text: map(data, 'warehouseId').join(','),
      },
    ];
    if (importOrder.type === OrderTypeEnum.Export) {
      requestWarehouseExistFloor.filter.push({
        column: 'itemIds',
        text: '',
      });
    }
    const warehousesExistFloor =
      await this.warehouseService.getListWarehouseExistFloor(
        requestWarehouseExistFloor,
      );
    warehouseIds = warehouseIds.filter((warehouseId) =>
      map(warehousesExistFloor, 'id').includes(warehouseId),
    );

    const normalizeWarehouses = {};
    userWarehouses.forEach((warehouse) => {
      normalizeWarehouses[warehouse.id] = warehouse;
    });

    const importOrderWarehouseDetailData = {};
    data.forEach((item) => {
      importOrderWarehouseDetailData[item.id] = item;
    });

    //get_factory_by_ids
    let dataMaping = warehousesExistFloor.items.map((e) => ({
      warehouseId: e.id,
      warehouseName: normalizeWarehouses[e.id]?.name,
      warehouseCode: normalizeWarehouses[e.id]?.code,
      items: importOrderWarehouseDetailData[e.warehoueId]?.items,
      factoryId: normalizeWarehouses[e.id]?.factoryId,
    }));
    const factoriesNameData = await this.userService.getFactories(
      dataMaping.map((e) => e.factoryId),
    );

    dataMaping = dataMaping.map((e) => {
      const factory = factoriesNameData.find(
        (e2) => e2.factoryId === e.factoryId,
      );
      return {
        ...e,
        factoryName: factory?.factoryName,
      };
    });

    const dataReturn = plainToInstance(OrderWarehouseResponse, dataMaping, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: warehousesExistFloor.meta,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async save(
    importOrderEntity: ImportOrderEntity,
    payload: any,
  ): Promise<any> {
    const { id, items, userId } = payload;
    const isUpdate = id !== null;

    //validate item
    const itemIds = uniq(map(items, 'id'));

    const itemsExist = await this.itemService.getItems(itemIds);

    if (!itemsExist || itemIds.length !== itemsExist.length) {
      const itemIdsExist = itemsExist ? itemsExist.map((e) => e.itemId) : [];
      return new ResponseBuilder({
        invalidItems: items.filter((e) => !itemIdsExist.includes(e.id)),
      })
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }

    const packageIds = compact(uniq(map(items, 'packageId')));
    const packages = await this.itemService.getPackageByIds(packageIds);

    if (packageIds.length !== packages.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PACKAGE_NOT_FOUND'))
        .build();
    }

    const warehouseIds = compact(uniq(map(items, 'warehouseId')));
    const warehouses = await this.warehouseService.getWarehouses(warehouseIds);
    if (warehouseIds.length !== warehouses.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
        .build();
    }

    let packageMaps = {};
    if (packages.length > 0) {
      packageMaps = keyBy(packages, 'id');
    }

    const [lotNumberOfPoimp, lotNumberOfImo] = await Promise.all([
      this.purchasedOrderImportWarehouseLotRepository.getListLotNumber(itemIds),
      this.importOrderWarehouseLotRepository.getListLotNumber(
        itemIds,
        OrderTypeEnum.Import,
        id,
      ),
    ]);
    const lotNumberData = compact([...lotNumberOfPoimp, ...lotNumberOfImo]);

    // validate lotNumber, warehouseId, qcCriteriaId, packageId
    let checkUniqWarehouse = false;
    let checkMfgLotNumberInCorrect = false;
    let checkNotOnlyQcCriteriaId = false;
    let checkItemNotExistInPackage = false;
    const arrLotNumberOfItem = [];
    const arrQcCriteriaIdOfItem = [];
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      // validate lotNumber
      const lotNumberRequest = item.lotNumber;

      const lotNumberExisted = lotNumberData.filter(
        (record) =>
          record.lotNumber === lotNumberRequest && record.itemId == item.id,
      );

      if (
        lotNumberExisted.length > 0 &&
        !Moment(first(lotNumberExisted).mfg).isSame(Moment(item.mfg))
      ) {
        checkMfgLotNumberInCorrect = true;
        break;
      }

      const key = item.id + `_` + item.warehouseId;
      if (arrLotNumberOfItem[key]) {
        arrLotNumberOfItem[key] = arrLotNumberOfItem[key].concat([
          lotNumberRequest,
        ]);
      } else {
        arrLotNumberOfItem[key] = [lotNumberRequest];
      }

      if (
        arrLotNumberOfItem[key].length !== uniq(arrLotNumberOfItem[key]).length
      ) {
        checkUniqWarehouse = true;
        break;
      }

      // validate qcCriteriaId
      const qcCriteriaIdRequest =
        item.qcCriteriaId !== null ? [item.qcCriteriaId] : [];
      if (arrQcCriteriaIdOfItem[item.id]) {
        arrQcCriteriaIdOfItem[item.id] =
          arrQcCriteriaIdOfItem[item.id].concat(qcCriteriaIdRequest);
      } else {
        arrQcCriteriaIdOfItem[item.id] = qcCriteriaIdRequest;
      }

      if (
        uniq(arrQcCriteriaIdOfItem[item.id]).length !== 1 &&
        arrQcCriteriaIdOfItem[item.id].length > 0
      ) {
        checkNotOnlyQcCriteriaId = true;
        break;
      }

      if (item.packageId && !isEmpty(packageMaps)) {
        // validate packageId
        const itemIdExistInPackage = packageMaps[
          item.packageId
        ].packageItems.filter((record) => record.itemId === item.id);

        if (itemIdExistInPackage.length === 0) {
          checkItemNotExistInPackage = true;
          break;
        }
      }
    }

    if (checkUniqWarehouse) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.DUPLICATE_WAREHOUSE'))
        .build();
    }

    if (checkNotOnlyQcCriteriaId) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.QC_MUST_BE_SAME_IN_THE_SAME_ITEM'),
        )
        .build();
    }

    if (checkItemNotExistInPackage) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.ITEM_NOT_EXIST_IN_PACKAGE'),
        )
        .build();
    }

    if (checkMfgLotNumberInCorrect) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.MFG_IN_CORRECT'))
        .build();
    }

    const importOrderDetailRaws = [];
    items.forEach((item) => {
      if (importOrderDetailRaws[item.id]) {
        importOrderDetailRaws[item.id].quantity = plus(
          importOrderDetailRaws[item.id].quantity,
          item.quantity,
        );
      } else {
        importOrderDetailRaws[item.id] = {
          id: item.id,
          quantity: item.quantity,
        };
      }
    });

    const importOrderWarehouseDetailRaws = [];
    items.forEach((item) => {
      const key = item.id + '_' + item.warehouseId;
      if (importOrderWarehouseDetailRaws[key]) {
        importOrderWarehouseDetailRaws[key].quantity = plus(
          importOrderWarehouseDetailRaws[key].quantity,
          item.quantity,
        );
      } else {
        importOrderWarehouseDetailRaws[key] = {
          itemId: item.id,
          quantity: item.quantity,
          warehouseId: item.warehouseId,
          qcCheck: item.qcCheck,
          qcCriteriaId: item.qcCriteriaId,
        };
      }
    });

    const user = await this.userService.getUserById(userId);
    const userIds = await this.getListUserByRoles(user.userRoleSettings || []);

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      // save import order
      const importOrder = await queryRunner.manager.save(importOrderEntity);

      // save import order detail
      const importOrderDetailEntities = importOrderDetailRaws.map(
        (importOrderDetail: any) =>
          this.importOrderDetailRepository.createEntity({
            importOrderId: importOrder.id,
            itemId: importOrderDetail.id,
            quantity: importOrderDetail.quantity,
          }),
      );

      if (isUpdate) {
        await queryRunner.manager.delete(ImportOrderDetailEntity, {
          importOrderId: importOrder.id,
        });
      }

      importOrder.importOrderDetails = await queryRunner.manager.save(
        importOrderDetailEntities,
      );

      const importOrderDetailMap = keyBy(
        importOrder.importOrderDetails,
        'itemId',
      );

      // save import order warehouse detail
      const importOrderWarehouseDetailEntities = values(
        importOrderWarehouseDetailRaws,
      ).map((item) => {
        const importOrderDetail = importOrderDetailMap[item.itemId];

        return this.importOrderWarehouseDetailRepository.createEntity({
          itemId: item.itemId,
          warehouseId: item.warehouseId,
          importOrderDetailId: importOrderDetail.id,
          importOrderId: importOrderDetail.importOrderId,
          quantity: item.quantity,
          qcCheck: +item.qcCheck,
          qcCriteriaId: item.qcCriteriaId,
        });
      });

      if (isUpdate) {
        await queryRunner.manager.delete(ImportOrderWarehouseLotEntity, {
          importOrderId: importOrder.id,
        });
        await queryRunner.manager.delete(ImportOrderWarehouseDetailEntity, {
          importOrderId: importOrder.id,
        });
      }

      importOrder.importOrderWarehouseDetails = await queryRunner.manager.save(
        importOrderWarehouseDetailEntities,
      );

      const importOrderWarehouseDetailsMap = [];
      importOrder.importOrderWarehouseDetails.forEach((record) => {
        const key = record.itemId + '_' + record.warehouseId;
        importOrderWarehouseDetailsMap[key] = record;
      });

      // save import order warehouse lot
      const importOrderWarehouseLotEntities = items.map(
        (importOrderWarehouseLot: any) => {
          const key =
            importOrderWarehouseLot.id +
            '_' +
            importOrderWarehouseLot.warehouseId;
          const importOrderWarehouseDetail =
            importOrderWarehouseDetailsMap[key];

          return this.importOrderWarehouseLotRepository.createEntity({
            importOrderId: importOrderWarehouseDetail.importOrderId,
            importOrderWarehouseDetailId: importOrderWarehouseDetail.id,
            itemId: importOrderWarehouseLot.id,
            warehouseId: importOrderWarehouseLot.warehouseId,
            quantity: importOrderWarehouseLot.quantity,
            lotNumber: importOrderWarehouseLot.lotNumber,
            mfg: importOrderWarehouseLot.mfg,
            packageId: importOrderWarehouseLot.packageId,
          });
        },
      );

      importOrder.importOrderWarehouseLots = await queryRunner.manager.save(
        importOrderWarehouseLotEntities,
      );
      await queryRunner.commitTransaction();
      if (!isUpdate) {
        const notificationRequest = new PushNotificationRequestDto();
        notificationRequest.title =
          MesModuleEnum.WMSX +
          ` ${
            user.username +
            (await this.i18n.translate(
              'error.IMPORT_ORDER_CREATED_NOTIFICATION',
            )) +
            importOrder.name
          }`;
        notificationRequest.type = TypeNotificationEnum.WEB;
        notificationRequest.action = ActionNotificationEnum.WAREHOUSE_YARD;
        notificationRequest.content = importOrder.description;
        //TODO SnP waiting
        notificationRequest.templateId = '62675f887848315c26a23033';
        notificationRequest.executionDate = new Date().toISOString();
        notificationRequest.payload = {
          title: notificationRequest.title,
          content: importOrder.description,
        };
        notificationRequest.userIds = userIds;
        const pushMail = Object.assign(notificationRequest, {
          type: TypeNotificationEnum.MAIL,
        });
        this.eventEmitter.emit('purchased_order_import.created', pushMail);
        this.eventEmitter.emit(
          'purchased_order_import.created',
          notificationRequest,
        );
      }
      const response = plainToInstance(ImportOrder, importOrder, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  /**
   * checkRequestIdExistInIMO
   * @param requestId
   * @param id
   * @private
   */
  private async checkRequestIdExistInIMO(
    requestId: string,
    id?: number,
  ): Promise<boolean> {
    const result = await this.importOrderRepository.findByCondition({
      requestId,
    });
    let data = [];

    if (id) {
      data = result.filter((item) => item.id !== id);

      return data.length > 0;
    }

    if (result.length > 0) {
      return true;
    }

    return false;
  }

  private async getRequestById(id: string): Promise<any> {
    return await this.mmsService.getRequestById(id);
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async updateWarehouseLots(
    payload: UpdateWarehouseLotRequestDto,
  ): Promise<any> {
    const { orderId, warehouseId, itemLotOrderDetails } = payload;

    const importOrder = await this.importOrderRepository.findOneById(orderId);

    if (isEmpty(importOrder)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const itemIds = map(itemLotOrderDetails, 'itemId');
    const importOrderWarehouseDetails =
      await this.importOrderWarehouseDetailRepository.findWithRelations({
        where: {
          importOrderId: orderId,
          warehouseId: warehouseId,
          itemId: In(itemIds),
        },
      });

    if (
      !importOrderWarehouseDetails ||
      importOrderWarehouseDetails.length !== itemIds.length
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const importOrderWarehouseLots =
      await this.importOrderWarehouseLotRepository.findWithRelations({
        warehouseId: warehouseId,
        importOrderId: orderId,
        itemId: In(itemIds),
      });

    const lotEntities = [];

    itemLotOrderDetails.forEach((itemLotOrderDetail) => {
      itemLotOrderDetail.lots.forEach((lot) => {
        const entity = new ImportOrderWarehouseLotEntity();
        entity.importOrderId = orderId;
        entity.warehouseId = warehouseId;
        entity.itemId = itemLotOrderDetail.itemId;
        entity.qcPassQuantity = 0;
        entity.qcRejectQuantity = 0;
        entity.lotNumber = lot.lotNumber.toUpperCase();

        const existedLot = find(
          importOrderWarehouseLots,
          (importOrderWarehouseLot) =>
            importOrderWarehouseLot.lotNumber.toUpperCase() ===
              lot.lotNumber.toUpperCase() &&
            importOrderWarehouseLot.itemId === importOrderWarehouseLot.itemId,
        );
        if (existedLot) {
          entity.actualQuantity = plus(
            existedLot.actualQuantity || 0,
            lot.quantity,
          );
          entity.qcPassQuantity = existedLot.qcPassQuantity;
          entity.qcRejectQuantity = existedLot.qcRejectQuantity;
        } else {
          entity.actualQuantity = lot.quantity;
        }

        lotEntities.push(entity);
      });
    });

    try {
      await this.importOrderWarehouseLotRepository.create(lotEntities);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (e) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(e?.message || e)
        .build();
    }
  }

  private async updateActualExOMMS(
    importOrder: ImportOrderEntity,
    request: UpdateOrderDetailActualQuantityRequestDto,
  ) {
    const { itemLots } = request;
    const itemsImportSerialize = {};
    try {
      itemLots.forEach((itemsLot) => {
        const key = itemsLot.itemId;
        if (!has(itemsImportSerialize, key)) {
          itemsImportSerialize[key] = 0;
        }
        itemsImportSerialize[key] = plus(
          itemsImportSerialize[key],
          itemsLot.quantity,
        );
      });
      const itemIds = Object.keys(itemsImportSerialize);
      const itemsSerialize = keyBy(
        await this.itemService.getItems(itemIds),
        'itemId',
      );
      const requestUpdateActualQuantityMMS =
        new UpdateActualQuantityImORequestDto();
      requestUpdateActualQuantityMMS.requestId = importOrder.requestId;
      requestUpdateActualQuantityMMS.items = [];
      Object.keys(itemsImportSerialize).forEach((itemId) => {
        requestUpdateActualQuantityMMS.items.push({
          quantity: itemsImportSerialize[itemId],
          code: itemsSerialize[itemId].code,
        });
      });
      const mms = await this.mmsService.updateActualExportRequestQuantity(
        requestUpdateActualQuantityMMS,
      );
      console.log('MMS-SERVICE (UPDATE ACTUAL QUANTITY HIHI):', mms);
    } catch (error) {
      console.log('MMS-SERVICE (UPDATE ACTUAL QUANTITY): ' + error.message);
    }
  }

  async getListByIds(payload: GetListOrderByIdsRequestDto): Promise<any> {
    const { ids } = payload;
    const data = await this.importOrderRepository.getListByIds(ids);
    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async updateQcQuantityImoAndExo(
    request: UpdateQcQuantityImoAndExoRequestDto,
  ): Promise<any> {
    try {
      const {
        importOrderId,
        warehouseId,
        itemId,
        qcRejectQuantity,
        qcPassQuantity,
        lotNumber,
      } = request;
      const importOrderWarehouseDetail =
        await this.importOrderWarehouseDetailRepository.findOneWithRelations({
          where: {
            importOrderId,
            warehouseId,
            itemId,
          },
          relations: ['importOrder'],
        });

      const importOrderWarehouseLot =
        await this.importOrderWarehouseLotRepository.findOneWithRelations({
          where: {
            importOrderId: importOrderId,
            warehouseId: warehouseId,
            itemId: itemId,
            lotNumber: ILike(lotNumber),
          },
        });

      if (!importOrderWarehouseDetail || !importOrderWarehouseLot) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }
      if (!importOrderWarehouseDetail.importOrder) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }

      if (
        !STATUS_TO_QC_ORDER.includes(
          importOrderWarehouseDetail.importOrder.status,
        )
      ) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
          .build();
      }

      // TO DO mobile update validate lot_number

      if (qcPassQuantity < 0 || qcRejectQuantity < 0) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
          .build();
      }

      if (
        plus(qcPassQuantity, qcRejectQuantity) >
        importOrderWarehouseDetail.quantity
      ) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
          .build();
      }

      importOrderWarehouseLot.qcPassQuantity = plus(
        importOrderWarehouseLot.qcPassQuantity || 0,
        qcPassQuantity,
      );
      importOrderWarehouseLot.qcRejectQuantity = plus(
        importOrderWarehouseLot.qcRejectQuantity || 0,
        qcRejectQuantity,
      );

      await this.importOrderWarehouseLotRepository.create(
        importOrderWarehouseLot,
      );

      return await this.setImportOrderWarehouseDetailQcQuantity(
        importOrderWarehouseDetail,
        request.qcPassQuantity,
        request.qcRejectQuantity,
      );
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error)
        .build();
    }
  }

  private async setImportOrderWarehouseDetailQcQuantity(
    importOrderWarehouseDetailEntity: ImportOrderWarehouseDetailEntity,
    qcPassQuantity: number,
    qcRejectQuantity: number,
  ): Promise<any> {
    importOrderWarehouseDetailEntity.qcPassQuantity = plus(
      +importOrderWarehouseDetailEntity.qcPassQuantity || 0,
      qcPassQuantity,
    );
    importOrderWarehouseDetailEntity.qcRejectQuantity = plus(
      +importOrderWarehouseDetailEntity.qcRejectQuantity || 0,
      qcRejectQuantity,
    );
    importOrderWarehouseDetailEntity.errorQuantity = plus(
      +importOrderWarehouseDetailEntity.errorQuantity || 0,
      qcRejectQuantity,
    );
    await this.importOrderWarehouseDetailRepository.create(
      importOrderWarehouseDetailEntity,
    );

    const response = plainToInstance(
      ImportOrderWarehouseDetailResponseDto,
      importOrderWarehouseDetailEntity,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  private async getListUserByRoles(userRoleSettings: any[]): Promise<any> {
    const listCode = uniq(map(flatMap(userRoleSettings), 'code'));
    if (listCode.find((c) => c !== ROLE.EMPLOYEE)) {
      const listUserRoles = await this.userService.getUsersByRoleCodes([
        ROLE.EMPLOYEE,
      ]);
      return uniq(map(flatMap(listUserRoles, 'userId')));
    }
  }
}
