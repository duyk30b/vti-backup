import { ImportOrderListResponseDto } from '@components/import-order/dto/response/import-order-list-response.dto';
import { ImportOrderResponseDto } from '@components/import-order/dto/response/import-order-response.dto';
import { DeleteOrderRequestDto } from '@components/order/dto/request/delete-order.request.dto';
import { GetListOrderByIdsRequestDto } from '@components/order/dto/request/get-list-order-by-ids.request.dto';
import {
  GetOrderDetailByWarehouseQueryDto,
  GetOrderDetailByWarehouseRequestDto,
} from '@components/order/dto/request/get-order-detail-by-warehouse.request.dto';
import { GetOrderDetailRequestDto } from '@components/order/dto/request/get-order-detail.request.dto';
import {
  GetOrderWarehouseQueryRequest,
  GetOrderWarehouseRequest,
} from '@components/order/dto/request/get-order-warehouse.request.dto';
import { GetOrderRequestDto } from '@components/order/dto/request/get-order.request.dto';
import { SetOrderStatusBodyDto } from '@components/order/dto/request/set-order-status-request.dto';
import { UpdateOrderDetailActualQuantityRequestDto } from '@components/order/dto/request/update-actual-quantity-order-detail.request.dto';
import { UpdateOrderDetailConfirmQuantityRequestDto } from '@components/order/dto/request/update-confirm-quantity-order-detail.request.dto';
import { UpdateWarehouseLotRequestDto } from '@components/order/dto/request/update-warehouse-lot.request.dto';
import { NATS_SALE } from '@config/nats.config';
import { OrderTypeEnum } from '@constant/common';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import {
  APPROVE_IMPORT_ORDER_PERMISSION,
  CONFIRM_IMPORT_ORDER_PERMISSION,
  CREATE_IMPORT_ORDER_PERMISSION,
  DELETE_IMPORT_ORDER_PERMISSION,
  DETAIL_IMPORT_ORDER_PERMISSION,
  LIST_IMPORT_ORDER_PERMISSION,
  REJECT_IMPORT_ORDER_PERMISSION,
  UPDATE_IMPORT_ORDER_PERMISSION,
} from '@utils/permissions/import-order';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty, find } from 'lodash';
import { CreateImportOrderRequestDto } from './dto/request/create-import-order.dto';
import { GetImportOrderListRequest } from './dto/request/get-import-order-list.request.dto';
import { GetLotNumberByItemIdRequestDto } from './dto/request/list-lot-number.request.dto';
import {
  UpdateQcQuantityImoAndExoBodyRequestDto,
  UpdateQcQuantityImoAndExoRequestDto,
} from './dto/request/update-imo-exo-qc-quantity.dto';
import { UpdateImportOrderBodyDto } from './dto/request/update-import-order.dto';
import { ImportOrderWarehouseDetailResponseDto } from './dto/response/import-order-warehouse-detail-response.dto';
import { ImportOrderWarehouseListResponseDto } from './dto/response/import-order-warehouse-list-response.dto';
import { GetListLotNumberResponseDto } from './dto/response/list-lot-number.response.dto';
import { ImportOrderServiceInterface } from './interface/import-order.service.interface';

@Controller('')
export class ImportOrderController {
  constructor(
    @Inject('ImportOrderServiceInterface')
    private readonly importOrderService: ImportOrderServiceInterface,
  ) {}

  @Post('import-orders/create')
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ImportOrderResponseDto,
  })
  @PermissionCode(CREATE_IMPORT_ORDER_PERMISSION.code)
  // @MessagePattern('create_import_order')
  public async create(
    @Body() payload: CreateImportOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importOrderService.create(request);
  }

  @Put('import-orders/:id')
  @ApiOperation({
    tags: ['Sales', 'Import Order'],
    summary: 'Update Import Order',
    description: 'Cập nhật lệnh nhập xuất khác',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: ImportOrderResponseDto,
  })
  @PermissionCode(UPDATE_IMPORT_ORDER_PERMISSION.code)
  // @MessagePattern('update_import_order')
  public async update(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateImportOrderBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.importOrderService.update(request);
  }

  @Delete('import-orders/:id')
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  @PermissionCode(DELETE_IMPORT_ORDER_PERMISSION.code)
  // @MessagePattern('delete_import_order')
  public async delete(@Param() payload: DeleteOrderRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.importOrderService.delete(request);
  }

  @PermissionCode(DELETE_IMPORT_ORDER_PERMISSION.code)
  @Delete('/import-orders/multiple')
  @ApiOperation({
    tags: ['Sales', 'Import Order'],
    summary: 'Remove multiple Import Order',
    description: 'Xoá nhiều lệnh nhập xuất khác ',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  // @MessagePattern('delete_import_order_multiple')
  public async deleteMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.importOrderService.deleteMultiple(request);
  }

  @Get('import-orders/:id')
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ImportOrderResponseDto,
  })
  @PermissionCode(DETAIL_IMPORT_ORDER_PERMISSION.code)
  // @MessagePattern('detail_import_order')
  public async getImportOrderDetail(
    @Param() param: GetOrderDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importOrderService.getDetail(request);
  }

  @PermissionCode(DETAIL_IMPORT_ORDER_PERMISSION.code)
  @Get('/export-orders/:id')
  @ApiOperation({
    tags: ['Sales', 'Import Order'],
    summary: 'Get Import Order Detail',
    description: 'Chi tiết lệnh nhập xuất khác',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ImportOrderResponseDto,
  })
  // @MessagePattern('detail_export_order')
  public async getExportOrderDetail(
    @Param() param: GetOrderDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importOrderService.getDetail(request);
  }

  @PermissionCode(LIST_IMPORT_ORDER_PERMISSION.code)
  @Get('/import-orders/list')
  @ApiOperation({
    tags: ['Sales', 'Import Order'],
    summary: 'Get List Import Order',
    description: 'Danh sách lệnh nhập xuất khác',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ImportOrderListResponseDto,
  })
  // @MessagePattern('list_import_order')
  public async getImportOrderList(
    @Query() payload: GetImportOrderListRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    if (isEmpty(find(request.filter, (f) => f.column === 'type'))) {
      request.filter = request.filter || [];
      request.filter.push({
        column: 'type',
        text: OrderTypeEnum.Import.toString(),
      });
    }
    return await this.importOrderService.getList(request);
  }

  @PermissionCode(LIST_IMPORT_ORDER_PERMISSION.code)
  @Get('/export-orders/list')
  @ApiOperation({
    tags: ['Sales', 'Export Order'],
    summary: 'Get List Export Order',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ImportOrderListResponseDto,
  })
  // @MessagePattern('list_export_order')
  public async getExportOrderList(
    @Query() payload: GetImportOrderListRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    if (isEmpty(find(request.filter, (f) => f.column === 'type'))) {
      request.filter = request.filter || [];
      request.filter.push({
        column: 'type',
        text: OrderTypeEnum.Export.toString(),
      });
    }
    return await this.importOrderService.getList(request);
  }

  @PermissionCode(CONFIRM_IMPORT_ORDER_PERMISSION.code)
  @Put('/import-orders/:id/confirm')
  @ApiOperation({
    tags: ['Sales', 'Import Order'],
    summary: 'Confirm Import Order',
    description: 'Confirm lệnh nhập xuất khác',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ImportOrderResponseDto,
  })
  // @MessagePattern('confirm_import_order')
  public async confirm(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: SetOrderStatusBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.importOrderService.confirm(request);
  }

  @PermissionCode(CONFIRM_IMPORT_ORDER_PERMISSION.code)
  // @MessagePattern('confirm_import_order_multiple')
  @Put('/import-orders/confirm/multiple')
  @ApiOperation({
    tags: ['Sales', 'Import Order'],
    summary: 'Confirm multiple Import Order',
    description: 'Confirm nhiều lệnh nhập xuất khác',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ImportOrderResponseDto,
  })
  public async confirmMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importOrderService.confirmMultiple(request);
  }

  @PermissionCode(REJECT_IMPORT_ORDER_PERMISSION.code)
  @Put('/import-orders/:id/reject')
  @ApiOperation({
    tags: ['Sales', 'Import Order'],
    summary: 'Reject Import Order',
    description: 'Reject lệnh nhập xuất khác',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: ImportOrderResponseDto,
  })
  // @MessagePattern('reject_import_order')
  public async reject(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: SetOrderStatusBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.importOrderService.reject(request);
  }

  @PermissionCode(REJECT_IMPORT_ORDER_PERMISSION.code)
  @Put('/import-orders/reject/multiple')
  @ApiOperation({
    tags: ['Sales', 'Import Order'],
    summary: 'Reject multiple Import Order',
    description: 'Reject nhiều lệnh nhập xuất khác',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: ImportOrderResponseDto,
  })
  // @MessagePattern('reject_import_order_multiple')
  public async rejectMultiple(
    @Query() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importOrderService.rejectMultiple(request);
  }

  @PermissionCode(APPROVE_IMPORT_ORDER_PERMISSION.code)
  @Put('/import-orders/:id/approve')
  @ApiOperation({
    tags: ['Sales', 'Import Order'],
    summary: 'Approve Import Order',
    description: 'Approve lệnh nhập xuất khác',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: ImportOrderResponseDto,
  })
  // @MessagePattern('approve_import_order')
  public async approve(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: SetOrderStatusBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.importOrderService.approve(request);
  }

  @Get('/import-orders/items/lots')
  @ApiOperation({
    tags: ['Sales'],
    summary: 'List Lot Number',
    description: 'Danh sách số lô theo sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListLotNumberResponseDto,
  })
  // @MessagePattern('get_list_lot_number_of_item_imo')
  public async getListLotNumberByItemId(
    @Query() payload: GetLotNumberByItemIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importOrderService.getListLotNumberByItemId(
      request.itemIds,
    );
  }

  /**
   * Get data import order by id and warehouseId
   * @param request
   * @returns
   */
  // @MessagePattern('get_imo_warehouse_details')
  public async getPoDetail(@Body() payload: GetOrderRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.importOrderService.getWarehouseDetails(
      request.id,
      request.warehouseId,
      request.type,
    );
  }

  /**
   * Update actual quantity of purchased order detail
   * @param request updateOrderDetailActualQuantityRequestDto
   * @returns
   */
  // @MessagePattern('update_import_order_actual_quantity')
  public async updateActualQuantity(
    @Body() payload: UpdateOrderDetailActualQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importOrderService.updateOrderDetailActualQuantity(
      request,
    );
  }

  /**
   * Update actual quantity of purchased order detail
   * @param request updateOrderDetailActualQuantityRequestDto
   * @returns
   */
  // @MessagePattern('update_import_order_confirm_quantity')
  public async updateConfirmQuantity(
    @Body() payload: UpdateOrderDetailConfirmQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importOrderService.updateOrderDetailConfirmQuantity(
      request,
    );
  }

  /**
   * Get import order warehouse detail
   * @param request GetOrderDetailByWarehouseRequestDto
   * @returns
   */
  @Get('/import-orders/:id/warehouses/:warehouseId')
  @ApiOperation({
    tags: ['Sales', 'Import Order', 'Warehouse'],
    summary: 'Get Import Order Warehouse Detail',
    description: 'Chi tiết kho của lệnh đặt hàng khác',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ImportOrderWarehouseDetailResponseDto,
  })
  // @MessagePattern('get_import_order_warehouse')
  public async getDetailByWarehouseId(
    @Param('id', new ParseIntPipe()) id,
    @Param('warehouseId', new ParseIntPipe()) warehouseId,
    @Query() payload: GetOrderDetailByWarehouseQueryDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    request.warehouseId = warehouseId;
    return await this.importOrderService.getDetailByWarehouseId(request);
  }

  /**
   * Get export order warehouse detail
   * @param request GetOrderDetailByWarehouseRequestDto
   * @returns
   */
  @Get('/export-orders/:id/warehouses/:warehouseId')
  @ApiOperation({
    tags: ['Sales', 'Export Order', 'Warehouse'],
    summary: 'Get Export Order Warehouse Detail',
    description: 'Chi tiết kho của lệnh đặt hàng khác',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ImportOrderWarehouseDetailResponseDto,
  })
  // @MessagePattern('get_import_order_warehouse')
  public async getExportOrderWarehouse(
    @Param('id', new ParseIntPipe()) id,
    @Param('warehouseId', new ParseIntPipe()) warehouseId,
    @Query() payload: GetOrderDetailByWarehouseQueryDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    request.warehouseId = warehouseId;
    return await this.importOrderService.getDetailByWarehouseId(request);
  }

  /**
   * Get import order warehouse details
   * @param request GetOrderWarehouseRequest
   * @returns
   */
  @Get('/import-orders/:id/warehouses/list')
  @ApiOperation({
    tags: ['Sales', 'Import Order', 'Warehouse'],
    summary: 'Get Import Order Warehouse List',
    description: 'Danh sách kho của lệnh đặt hàng khác',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ImportOrderWarehouseListResponseDto,
  })
  // @MessagePattern('get_import_order_warehouses')
  public async getImportOrderWarehouseList(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: GetOrderWarehouseQueryRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.importOrderService.getOrderWarehouses(request);
  }

  /**
   * Get export order warehouse details
   * @param request GetOrderWarehouseRequest
   * @returns
   */
  @Get('/export-orders/:id/warehouses/list')
  @ApiOperation({
    tags: ['Sales', 'Export Order', 'Warehouse'],
    summary: 'Get Import Order Warehouse List',
    description: 'Danh sách kho của lệnh đặt hàng khác',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ImportOrderWarehouseListResponseDto,
  })
  // @MessagePattern('get_import_order_warehouses')
  public async getExportOrderWarehouseList(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: GetOrderWarehouseQueryRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.importOrderService.getOrderWarehouses(request);
  }

  /**
   *
   * @param payload
   * @returns
   */
  // @MessagePattern('update_import_order_warehouse_lots')
  public async updateWarehouseLots(
    @Body() payload: UpdateWarehouseLotRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importOrderService.updateWarehouseLots(request);
  }

  // @MessagePattern('get_other_order_by_ids')
  public async getOtherOrderByIds(
    @Body() payload: GetListOrderByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.importOrderService.getListByIds(request);
  }

  @Put(
    '/import-orders/:id/warehouses/:warehouseId/items/:itemId/quality-controls/quantities',
  )
  @ApiOperation({
    tags: ['Sales', 'Import Order', 'Warehouse'],
    summary: 'Update QC Quantity IMO EXO',
    description: 'Cập nhật QC IMO EXO',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  // @MessagePattern('update_qc_quantity_imo_exo')
  public async updateQcQuantityImoAndExo(
    @Param('id', new ParseIntPipe()) importOrderId,
    @Param('warehouseId', new ParseIntPipe()) warehouseId,
    @Param('itemId', new ParseIntPipe()) itemId,
    @Body() payload: UpdateQcQuantityImoAndExoBodyRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.itemId = itemId;
    request.warehouseId = warehouseId;
    request.importOrderId = importOrderId;
    return await this.importOrderService.updateQcQuantityImoAndExo(request);
  }

  @MessagePattern(`${NATS_SALE}.update_import_order_confirm_quantity`)
  public async updateConfirmQuantityTcp(
    @Body() payload: UpdateOrderDetailConfirmQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importOrderService.updateOrderDetailConfirmQuantity(
      request,
    );
  }

  @MessagePattern(`${NATS_SALE}.update_import_order_warehouse_lots`)
  public async updateWarehouseLotsTcp(
    @Body() payload: UpdateWarehouseLotRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importOrderService.updateWarehouseLots(request);
  }

  @MessagePattern(`${NATS_SALE}.get_other_order_by_ids`)
  public async getOtherOrderByIdsTcp(
    @Body() payload: GetListOrderByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.importOrderService.getListByIds(request);
  }

  @MessagePattern(`${NATS_SALE}.get_import_order_warehouse`)
  public async getDetailByWarehouseIdTcp(
    @Body() payload: GetOrderDetailByWarehouseRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importOrderService.getDetailByWarehouseId(request);
  }

  @PermissionCode(DETAIL_IMPORT_ORDER_PERMISSION.code)
  @MessagePattern(`${NATS_SALE}.detail_import_order`)
  public async getImportOrderDetailTcp(
    @Body() body: GetOrderDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importOrderService.getDetail(request);
  }

  @PermissionCode(DETAIL_IMPORT_ORDER_PERMISSION.code)
  @MessagePattern(`${NATS_SALE}.detail_export_order`)
  public async getExportOrderDetailTcp(
    @Body() param: GetOrderDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importOrderService.getDetail(request);
  }

  @PermissionCode(LIST_IMPORT_ORDER_PERMISSION.code)
  @MessagePattern(`${NATS_SALE}.list_import_order`)
  public async getImportOrderListTcp(
    @Body() payload: GetImportOrderListRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    if (isEmpty(find(request.filter, (f) => f.column === 'type'))) {
      request.filter = request.filter || [];
      request.filter.push({
        column: 'type',
        text: OrderTypeEnum.Import.toString(),
      });
    }
    return await this.importOrderService.getList(request);
  }

  @PermissionCode(LIST_IMPORT_ORDER_PERMISSION.code)
  @MessagePattern(`${NATS_SALE}.list_export_order`)
  public async getExportOrderListTcp(
    @Body() payload: GetImportOrderListRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    if (isEmpty(find(request.filter, (f) => f.column === 'type'))) {
      request.filter = request.filter || [];
      request.filter.push({
        column: 'type',
        text: OrderTypeEnum.Export.toString(),
      });
    }
    return await this.importOrderService.getList(request);
  }

  @MessagePattern(`${NATS_SALE}.get_import_order_warehouses`)
  public async getExportOrderWarehouseListTcp(
    @Body() payload: GetOrderWarehouseRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importOrderService.getOrderWarehouses(request);
  }

  @MessagePattern(`${NATS_SALE}.update_qc_quantity_imo_exo`)
  public async updateQcQuantityImoAndExoTcp(
    @Body() payload: UpdateQcQuantityImoAndExoRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importOrderService.updateQcQuantityImoAndExo(request);
  }

  // TO DO: remove after refactor done
  @MessagePattern(`${NATS_SALE}.get_imo_warehouse_details`)
  public async getPoDetailTcp(
    @Body() payload: GetOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.importOrderService.getWarehouseDetails(
      request.id,
      request.warehouseId,
      request.type,
    );
  }

  @MessagePattern(`${NATS_SALE}.update_import_order_actual_quantity`)
  public async updateActualQuantityTcp(
    @Body() payload: UpdateOrderDetailActualQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importOrderService.updateOrderDetailActualQuantity(
      request,
    );
  }
}
