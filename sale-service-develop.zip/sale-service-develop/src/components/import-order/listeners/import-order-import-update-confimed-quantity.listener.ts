import { OrderTypeEnum as OtherOrderTypeEnum } from '@constant/order.constant';
import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { OrderUpdateConfirmedQuantityListener } from '@components/order/listeners/order-update-confimed-quantity.listener';
import { UpdateStockStatusOrderRequest } from '@components/warehouse/dto/request/update-stock-status-order.request';
import { OrderStatusEnum, OrderTypeEnum } from '@constant/common';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { ImportOrderRepositoryInterface } from '../interface/import-order.repository.interface';
import { MmsServiceInterface } from '@components/mmsx/interface/mms.service.interface';
import { ConfirmRequestImORequestDto } from '@components/mmsx/dto/request/confirm-request-by-imo.request.dto';
import { OtherOrderUpdateConfirmedQuantityEvent } from '../events/other-order-update-confirmed-quantity.event';
import { STATUS_CONFIRM_EXO } from '../import-order.constant';

@Injectable()
export class ImportOrderUpdateConfirmedQuantityListener extends OrderUpdateConfirmedQuantityListener {
  constructor(
    @Inject('ImportOrderRepositoryInterface')
    private readonly importOrderRepository: ImportOrderRepositoryInterface,

    @Inject('WarehouseCronServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,

    @Inject('MmsServiceInterface')
    protected readonly mmsService: MmsServiceInterface,
  ) {
    super();
  }

  @OnEvent('order.updateConfirmedQuantity')
  async handleOrderCreatedEvent(event: OtherOrderUpdateConfirmedQuantityEvent) {
    const { id, orderType, requestId, userId, type } = event;
    let order;
    if (order) {
      const isImport = type === OrderTypeEnum.Import;
      if (requestId && isImport) {
        try {
          const requestConfirmImO = new ConfirmRequestImORequestDto();
          requestConfirmImO.id = requestId;
          requestConfirmImO.status = STATUS_CONFIRM_EXO;
          requestConfirmImO.userId = userId;
          const mms = await this.mmsService.confirmRequestImO(
            requestConfirmImO,
          );
          console.log('MMS-SERVICE (RESPONSE UPDATE ACTUAL QUANTITY):', mms);
        } catch (error) {
          console.log(
            'MMS-SERVICE (ERROR UPDATE ACTUAL QUANTITY): ' + error.message,
          );
        }
      }
      const newOrder = await this.importOrderRepository.setCompleted(id);

      const updateStockStatusOrder = new UpdateStockStatusOrderRequest();
      updateStockStatusOrder.id = newOrder.id;
      updateStockStatusOrder.completedAt = newOrder.completedAt;
      updateStockStatusOrder.status = OrderStatusEnum.Completed;
      updateStockStatusOrder.type = isImport
        ? OtherOrderTypeEnum.IMO
        : OtherOrderTypeEnum.EXO;

      await this.warehouseService.updateStatusWarehouseStockMovement(
        updateStockStatusOrder,
      );
    }

    return;
  }
}
