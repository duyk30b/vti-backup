import { OrderTypeEnum } from '@constant/order.constant';
import { OnEvent } from '@nestjs/event-emitter';
import { OrderUpdateActualQuantityListener } from '@components/order/listeners/order-update-actual-quantity.listener';
import { Inject, Injectable } from '@nestjs/common';
import { OrderUpdateActualQuantityEvent } from '@components/order/events/order-update-actual-quantity.event';
import { ImportOrderRepositoryInterface } from '@components/import-order/interface/import-order.repository.interface';

@Injectable()
export class ImportOrderUpdateActualQuantityListener extends OrderUpdateActualQuantityListener {
  constructor(
    @Inject('ImportOrderRepositoryInterface')
    private readonly importOrderRepository: ImportOrderRepositoryInterface,
  ) {
    super();
  }

  @OnEvent('order.updateActualQuantity')
  async handleOrderUpdateActualQuantityEvent(
    event: OrderUpdateActualQuantityEvent,
  ) {
    const { id, orderType } = event;
    let order;
    return await this.checkAndUpdateInProgessOrderStatus(order);
  }

  public async updateInProgessOrderStatus(order) {
    return await this.importOrderRepository.create(order);
  }
}
