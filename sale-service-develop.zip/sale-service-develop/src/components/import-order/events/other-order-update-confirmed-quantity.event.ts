export class OtherOrderUpdateConfirmedQuantityEvent {
  constructor({ id, orderType, userId, requestId, type }) {
    this.id = id;
    this.orderType = orderType;
    this.userId = userId;
    this.requestId = requestId;
    this.type = type;
  }
  id: number;
  orderType: number;
  userId?: number;
  requestId?: string;
  type?: number;
}
