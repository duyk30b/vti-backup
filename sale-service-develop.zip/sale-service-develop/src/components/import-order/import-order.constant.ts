export const STATUS_CONFIRM_EXO = 3;

export const TYPE_IMPORT_ORDER = {
  IMO: 0,
  EXO: 1,
};

export const QC_STAGE_ID = {
  IMO: 10,
  EXO: 11,
};
