import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsOptional, IsEnum, IsNotEmpty } from 'class-validator';

export class GetImportOrderListRequest extends PaginationQuery {
  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll: string;

  @IsNotEmpty()
  user: any;
}
