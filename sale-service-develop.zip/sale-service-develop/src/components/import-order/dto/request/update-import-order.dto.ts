import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CreateImportOrderRequestDto } from './create-import-order.dto';

export class UpdateImportOrderBodyDto extends CreateImportOrderRequestDto {}

export class UpdateImportOrderRequestDto extends UpdateImportOrderBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
