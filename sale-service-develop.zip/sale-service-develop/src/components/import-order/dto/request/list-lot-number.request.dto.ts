import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from "class-transformer";
import { IsArray, IsInt, IsNotEmpty } from 'class-validator';

export class GetLotNumberByItemIdRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  @Transform(({ value }) => value.split(',').map((id) => Number(id)))
  itemIds: number[];
}
