import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsString,
  MaxLength,
  Min,
} from 'class-validator';

export class UpdateQcQuantityImoAndExoBodyRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @MaxLength(20)
  lotNumber: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  qcPassQuantity: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  qcRejectQuantity: number;
}

export class UpdateQcQuantityImoAndExoRequestDto extends UpdateQcQuantityImoAndExoBodyRequestDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  importOrderId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  warehouseId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  itemId: number;
}