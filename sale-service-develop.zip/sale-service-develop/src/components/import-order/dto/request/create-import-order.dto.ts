import { Type } from 'class-transformer';
import { OrderTypeEnum } from '@constant/common';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsDateString,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Length,
  Min,
  ValidateNested,
} from 'class-validator';
import { CreateOrderRequestDto } from '@components/order/dto/request/create-order-resquest.dto';

class ImportOrderItemRequest {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  quantity: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @Length(10)
  lotNumber: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  mfg: Date;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  packageId: number;

  @ApiProperty({ example: '0', description: 'Trạng thái QC' })
  @IsNotEmpty()
  @IsString()
  @IsEnum(['0', '1'])
  qcCheck: string;

  @ApiPropertyOptional({ example: 1, description: 'qcCriteriaId' })
  @IsOptional()
  @IsInt()
  qcCriteriaId: number;
}
export class CreateImportOrderRequestDto extends CreateOrderRequestDto {
  @ApiProperty()
  @IsOptional()
  @IsString()
  @Length(1, 255)
  requestId: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @Length(1, 255)
  name: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @Length(1, 255)
  description: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @Length(1, 24)
  code: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  deadline: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  planAt: Date;

  @ApiProperty({ type: ImportOrderItemRequest, isArray: true })
  @ArrayUnique<ImportOrderItemRequest>()
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => ImportOrderItemRequest)
  items: ImportOrderItemRequest[];
}
