import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { ImportOrder } from './import-order-response.dto';
import { SuccessResponse } from '@utils/success.response.dto';

class MetaImportOrder {
  @ApiProperty({ example: 1 })
  @Expose()
  total: number;

  @ApiProperty({ example: 1 })
  @Expose()
  page: number;
}

export class ImportOrderList {
  @ApiProperty({ type: ImportOrder, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => ImportOrderListResponseDto)
  items: ImportOrder[];

  @ApiProperty({ type: MetaImportOrder })
  @Expose()
  @Type(() => MetaImportOrder)
  meta: MetaImportOrder;
}

export class ImportOrderListResponseDto extends SuccessResponse {
  @ApiProperty({ type: ImportOrderList })
  @Expose()
  @Type(() => ImportOrderList)
  data: ImportOrderList;
}
