import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { WarehouseResponseDto } from '@components/warehouse/dto/response/warehouse.dto.response';
import { UserResponseDto } from '@components/user/dto/response/user.dto.response';

export class ItemResponseDto {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  itemUnit: string;
}

class PackageResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ImportOrderDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  importOrderId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  confirmQuantity: number;

  @ApiProperty({ type: ItemResponseDto })
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;
}

class ImportOrderWarehouseLot {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  importOrderId: number;

  @ApiProperty()
  @Expose()
  importOrderWarehouseDetailId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  packageId: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  mfg: Date;

  @ApiProperty()
  @Expose()
  qcCriteriaId: number;

  @ApiProperty()
  @Expose()
  confirmQuantity: number;

  @ApiProperty({ type: ItemResponseDto })
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;

  @ApiProperty({ type: PackageResponseDto })
  @Type(() => PackageResponseDto)
  @Expose()
  package: PackageResponseDto;

  @ApiProperty({ type: WarehouseResponseDto })
  @Type(() => WarehouseResponseDto)
  @Expose()
  warehouse: WarehouseResponseDto;
}

class ImportOrderWarehouseDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  importOrderId: number;

  @ApiProperty()
  @Expose()
  importOrderDetailId: number;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  confirmQuantity: number;

  @ApiProperty()
  @Expose()
  qcCheck: number;

  @ApiProperty()
  @Expose()
  qcCriteriaId: number;

  @ApiProperty({ type: ItemResponseDto })
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;

  @ApiProperty({ type: WarehouseResponseDto })
  @Type(() => WarehouseResponseDto)
  @Expose()
  warehouse: WarehouseResponseDto;
}

export class RequestResponse {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

export class ImportOrder {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  requestId: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  deadline: Date;

  @ApiProperty()
  @Expose()
  planAt: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty()
  @Expose()
  approvedAt: Date;

  @ApiProperty({ type: RequestResponse })
  @Expose()
  @Type(() => RequestResponse)
  request: RequestResponse;

  @ApiProperty({ type: ImportOrderDetail, isArray: true })
  @Expose()
  @Type(() => ImportOrderDetail)
  importOrderDetails: ImportOrderDetail[];

  @ApiProperty({ type: ImportOrderWarehouseLot, isArray: true })
  @Expose()
  @Type(() => ImportOrderWarehouseLot)
  importOrderWarehouseLots: ImportOrderWarehouseLot[];

  @ApiProperty({ type: ImportOrderWarehouseDetail, isArray: true })
  @Expose()
  @Type(() => ImportOrderWarehouseDetail)
  importOrderWarehouseDetails: ImportOrderWarehouseDetail[];

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  approver: UserResponseDto;
}

export class ImportOrderResponseDto extends SuccessResponse {
  @ApiProperty({ type: ImportOrder })
  @Expose()
  @Type(() => ImportOrder)
  data: ImportOrder;
}
