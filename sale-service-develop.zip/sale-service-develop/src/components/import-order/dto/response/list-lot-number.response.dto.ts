import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

export class LotNumberResponseDto {
  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  mfg: Date;

  @ApiProperty()
  @Expose()
  itemId: number;
}

export class LotNumberOfItemResponseDto {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty({ type: LotNumberResponseDto, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => LotNumberResponseDto)
  lotNumbers: LotNumberResponseDto;
}

export class GetListLotNumberResponseDto extends SuccessResponse {
  @ApiProperty({ type: LotNumberOfItemResponseDto, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => LotNumberOfItemResponseDto)
  data: LotNumberOfItemResponseDto;
}
