import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray } from 'class-validator';

export class ItemIdResponse {
  @ApiProperty()
  @Expose({ name: 'id' })
  id: number;
}

export class ImportOrderWarehouseListResponseDto {
  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  warehouseName: string;

  @ApiProperty()
  @Expose()
  factoryId: number;

  @ApiProperty()
  @Expose()
  factoryName: string;

  @ApiProperty({ isArray: true, type: ItemIdResponse })
  @Expose()
  @IsArray()
  @Type(() => ItemIdResponse)
  items: ItemIdResponse[];
}
