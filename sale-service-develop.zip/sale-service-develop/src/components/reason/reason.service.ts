import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ReasonEntity } from '@entities/reason/reason.entity';
import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ResponsePayload } from '@utils/response-payload';
import { DataSource, ILike, In, Not } from 'typeorm';
import { CreateReasonRequestDto } from './dto/request/create-reason.request.dto';
import { ReasonServiceInterface } from './interface/reason.service.interface';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ReasonRepositoryInterface } from './interface/reason.repository.interface';
import { UpdateReasonRequestDto } from './dto/request/update-reason.request.dto';
import { DeleteReasonRequestDto } from './dto/request/delete-reason.request.dto';
import { GetReasonRequestDto } from './dto/request/get-reason-detail.request.dto';
import { ReasonResponseDto } from './dto/response/reason.response.dto';
import { plainToClass, plainToInstance } from 'class-transformer';
import { GetReasonListRequestDto } from './dto/request/get-reason-list.request.dto';
import { PagingResponse } from '@utils/paging.response';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { uniq } from 'lodash';
import {
  CONFIRMABLE_REASON_STATUSES,
  ReasonStatus,
  REJECTABLE_REASON_STATUSES,
} from './reason.constants';
import { ConfirmReasonRequestDto } from './dto/request/confirm-reason.request.dto';
import { GetReasonByIdsRequestDto } from './dto/request/get-reason-by-ids.request.dto';

@Injectable()
export class ReasonService implements ReasonServiceInterface {
  constructor(
    @InjectDataSource()
    private readonly connection: DataSource,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ReasonRepositoryInterface')
    private readonly reasonRepository: ReasonRepositoryInterface,
    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateReasonRequestDto): Promise<any> {
    const existingReasonEntity = await this.reasonRepository.findOneByCondition(
      {
        code: ILike(request.code),
      },
    );
    if (existingReasonEntity) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_IS_EXIST'))
        .build();
    }
    const reason = this.reasonRepository.createEntity(request);
    return await this.save(reason);
  }

  async update(request: UpdateReasonRequestDto): Promise<any> {
    const existingReasonEntity = await this.reasonRepository.findOneById(
      request.id,
    );

    if (!existingReasonEntity) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const existingCode = await this.reasonRepository.findOneByCondition({
      code: ILike(request.code),
      id: Not(request.id),
    });
    if (existingCode) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_IS_EXIST'))
        .build();
    }

    const reason = this.reasonRepository.updateEntity(
      existingReasonEntity,
      request,
    );
    return await this.save(reason);
  }

  async delete(request: DeleteReasonRequestDto): Promise<any> {
    const reason = await this.reasonRepository.findOneById(request.id);
    if (!reason) {
      return new ResponseBuilder(reason)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    reason.deletedAt = new Date();
    reason.deletedBy = request.userId;
    await this.reasonRepository.create(reason);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async confirm(request: ConfirmReasonRequestDto): Promise<any> {
    const reason = await this.reasonRepository.findOneById(request.id);
    if (!reason) {
      return new ResponseBuilder(reason)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CONFIRMABLE_REASON_STATUSES.includes(reason.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CONFIRM'))
        .build();
    }
    reason.status = ReasonStatus.ACTIVE;
    await this.reasonRepository.create(reason);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async reject(request: ConfirmReasonRequestDto): Promise<any> {
    const reason = await this.reasonRepository.findOneById(request.id);
    if (!reason) {
      return new ResponseBuilder(reason)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!REJECTABLE_REASON_STATUSES.includes(reason.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_REJECT'))
        .build();
    }
    reason.status = ReasonStatus.CREATED;
    await this.reasonRepository.create(reason);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getDetail(request: GetReasonRequestDto): Promise<any> {
    const reason = await this.reasonRepository.findOneById(request.id);

    if (!reason) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const response = await this.generateRespone(reason);
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(request: GetReasonListRequestDto): Promise<any> {
    const { page } = request;
    const [data, count] = await this.reasonRepository.getList(request);
    const creatorIds = uniq(data.map((item) => item.createdBy));
    const updaterIds = uniq(data.map((item) => item.updatedBy));
    const userIds = [...creatorIds, ...updaterIds];
    const users = await this.userService.getUsers(uniq(userIds), true);

    data.forEach((item) => {
      item.createdBy = users[item.createdBy];
      item.updatedBy = users[item.updatedBy];
    });

    const dataReturn = plainToClass(ReasonResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async save(
    reasonEntity: ReasonEntity,
  ): Promise<ResponsePayload<any> | any> {
    try {
      const result = await this.reasonRepository.create(reasonEntity);
      const response = await this.generateRespone(result);
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder(error)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .build();
    }
  }

  private async generateRespone(
    reasonEntity: ReasonEntity,
  ): Promise<ReasonResponseDto> {
    const userIds = [reasonEntity.createdBy, reasonEntity.updatedBy];
    const users = await this.userService.getUsers(uniq(userIds), true);

    reasonEntity.createdBy = users[reasonEntity.createdBy];
    reasonEntity.updatedBy = users[reasonEntity.updatedBy];

    const response = plainToClass(ReasonResponseDto, reasonEntity, {
      excludeExtraneousValues: true,
    });

    return response;
  }

  public async getReasonByIds(request: GetReasonByIdsRequestDto): Promise<any> {
    const result = await this.reasonRepository.findByCondition({
      id: In(request.reasonIds),
    });
    const response = plainToInstance(ReasonResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }
}
