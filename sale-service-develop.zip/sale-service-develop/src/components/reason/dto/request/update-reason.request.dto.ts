import { REASON_RULES } from '@components/reason/reason.constants';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsOptional, IsString, MaxLength } from 'class-validator';

export class UpdateReasonBodyDto extends BaseDto {
  @ApiProperty({ example: '', description: '' })
  @IsString()
  @MaxLength(REASON_RULES.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: '', description: '' })
  @IsString()
  @MaxLength(REASON_RULES.CODE.MAX_LENGTH)
  code: string;

  @ApiProperty({ example: '', description: '' })
  @IsOptional()
  @IsString()
  @MaxLength(REASON_RULES.DESCRIPTION.MAX_LENGTH)
  description: string;
}
export class UpdateReasonRequestDto extends UpdateReasonBodyDto {
  @ApiProperty({ example: '', description: '' })
  @Transform(({ value }) => Number(value))
  @IsInt()
  id: number;
}
