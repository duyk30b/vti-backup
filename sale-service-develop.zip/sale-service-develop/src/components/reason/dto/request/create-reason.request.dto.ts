import { REASON_RULES, Warehouse } from '@components/reason/reason.constants';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString, MaxLength } from 'class-validator';

export class CreateReasonRequestDto extends BaseDto {
  @ApiProperty({ example: '', description: '' })
  @IsString()
  @MaxLength(REASON_RULES.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: '', description: '' })
  @IsString()
  @MaxLength(REASON_RULES.CODE.MAX_LENGTH)
  code: string;

  @ApiProperty({ example: '', description: '' })
  @IsOptional()
  @IsString()
  @MaxLength(REASON_RULES.DESCRIPTION.MAX_LENGTH)
  description: string;

  @ApiProperty({ example: '', description: '' })
  @IsOptional()
  @IsEnum(Warehouse)
  @MaxLength(REASON_RULES.CREATED_FROM.MAX_LENGTH)
  createdFrom: Warehouse;
}
