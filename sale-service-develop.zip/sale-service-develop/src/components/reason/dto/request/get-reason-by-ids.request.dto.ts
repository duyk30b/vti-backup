import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { ArrayNotEmpty } from 'class-validator';

export class GetReasonByIdsRequestDto extends BaseDto {
  @ApiProperty({ example: '', description: '' })
  @ArrayNotEmpty()
  reasonIds: number[];
}
