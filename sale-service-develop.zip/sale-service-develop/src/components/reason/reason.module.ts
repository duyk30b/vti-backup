import { ReasonEntity } from '@entities/reason/reason.entity';
import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ReasonController } from './reason.controller';
import { ReasonRepository } from '@repositories/reason/reason.repository';
import { ReasonService } from './reason.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';

@Global()
@Module({
  imports: [TypeOrmModule.forFeature([ReasonEntity]), UserModule],
  exports: [],
  providers: [
    {
      provide: 'ReasonRepositoryInterface',
      useClass: ReasonRepository,
    },
    {
      provide: 'ReasonsServiceInterface',
      useClass: ReasonService,
    },
  ],
  controllers: [ReasonController],
})
export class ReasonModule {}
