export enum Warehouse {
  AVENUE = '0',
}

export const REASON_RULES = {
  NAME: {
    MAX_LENGTH: 255,
  },
  CODE: {
    MAX_LENGTH: 20,
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
  CREATED_FROM: {
    MAX_LENGTH: 255,
  },
};

export enum ReasonStatus {
  CREATED = 0,
  ACTIVE = 1,
}

export const CONFIRMABLE_REASON_STATUSES = [ReasonStatus.CREATED];

export const REJECTABLE_REASON_STATUSES = [ReasonStatus.ACTIVE];
