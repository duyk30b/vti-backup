import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { CreateReasonRequestDto } from './dto/request/create-reason.request.dto';
import { isEmpty } from 'lodash';
import { ReasonServiceInterface } from './interface/reason.service.interface';
import { UpdateReasonBodyDto } from './dto/request/update-reason.request.dto';
import { DeleteReasonRequestDto } from './dto/request/delete-reason.request.dto';
import { GetReasonListRequestDto } from './dto/request/get-reason-list.request.dto';
import { ReasonResponseDto } from './dto/response/reason.response.dto';
import { GetReasonRequestDto } from './dto/request/get-reason-detail.request.dto';
import {
  DETAIL_REASON_PERMISSION,
  CREATE_REASON_PERMISSION,
  DELETE_REASON_PERMISSION,
  UPDATE_REASON_PERMISSION,
  LIST_REASON_PERMISSION,
  CONFIRM_REASON_PERMISSION,
  REJECT_REASON_PERMISSION,
} from '@utils/permissions/reason';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { ConfirmReasonRequestDto } from './dto/request/confirm-reason.request.dto';
import { MessagePattern } from '@nestjs/microservices';
import { GetReasonByIdsRequestDto } from './dto/request/get-reason-by-ids.request.dto';

@Controller('reasons')
export class ReasonController {
  constructor(
    @Inject('ReasonsServiceInterface')
    private readonly reasonService: ReasonServiceInterface,
  ) {}

  @PermissionCode(CREATE_REASON_PERMISSION.code)
  @Post('create')
  @ApiOperation({
    tags: ['Reason'],
    summary: 'Create new reason',
    description: 'Tạo 1 reason mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async create(@Body() body: CreateReasonRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.reasonService.create(request);
  }

  @PermissionCode(UPDATE_REASON_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Reason'],
    summary: 'Update reason',
    description: 'Sửa reason',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async update(
    @Body() body: UpdateReasonBodyDto,
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.reasonService.update({ ...request, id });
  }

  @PermissionCode(DELETE_REASON_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Reason'],
    summary: 'Delete reason',
    description: 'Xóa reason',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async delete(@Param() param: DeleteReasonRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.reasonService.delete(request);
  }

  @PermissionCode(CONFIRM_REASON_PERMISSION.code)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Reason'],
    summary: 'Confirm reason',
    description: 'Xác nhận reason',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: null,
  })
  public async confirm(@Param() param: ConfirmReasonRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.reasonService.confirm(request);
  }

  @PermissionCode(REJECT_REASON_PERMISSION.code)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Reason'],
    summary: 'Reject reason',
    description: 'Từ chối reason',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: null,
  })
  public async reject(@Param() param: ConfirmReasonRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.reasonService.reject(request);
  }

  @PermissionCode(DETAIL_REASON_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Reason'],
    summary: 'Delete reason',
    description: 'Xóa reason',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: ReasonResponseDto,
  })
  public async getDetail(@Param() param: GetReasonRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.reasonService.getDetail(request);
  }

  @PermissionCode(LIST_REASON_PERMISSION.code)
  @Get('list')
  @ApiOperation({
    tags: ['Reason'],
    summary: 'Get list reason',
    description: 'Lấy danh sách reason',
  })
  @ApiResponse({
    status: 200,
    description: 'Get list successfully',
    type: null,
  })
  public async getList(@Query() query: GetReasonListRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.reasonService.getList(request);
  }
  @MessagePattern('get_reason_detail')
  public async getDetailTcp(@Body() param: GetReasonRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.reasonService.getDetail(request);
  }

  @MessagePattern('get_reason_by_ids')
  public async getSourceByIds(
    @Body() payload: GetReasonByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.reasonService.getReasonByIds(request);
  }
}
