import { ResponsePayload } from '@utils/response-payload';
import { ConfirmReasonRequestDto } from '../dto/request/confirm-reason.request.dto';
import { CreateReasonRequestDto } from '../dto/request/create-reason.request.dto';
import { DeleteReasonRequestDto } from '../dto/request/delete-reason.request.dto';
import { GetReasonByIdsRequestDto } from '../dto/request/get-reason-by-ids.request.dto';
import { GetReasonRequestDto } from '../dto/request/get-reason-detail.request.dto';
import { GetReasonListRequestDto } from '../dto/request/get-reason-list.request.dto';
import { UpdateReasonRequestDto } from '../dto/request/update-reason.request.dto';
import { ReasonResponseDto } from '../dto/response/reason.response.dto';

export interface ReasonServiceInterface {
  getDetail(request: GetReasonRequestDto): Promise<any>;
  getList(request: GetReasonListRequestDto): Promise<any>;
  create(request: CreateReasonRequestDto): Promise<any>;
  update(request: UpdateReasonRequestDto): Promise<any>;
  delete(request: DeleteReasonRequestDto): Promise<any>;
  confirm(request: ConfirmReasonRequestDto): Promise<any>;
  reject(request: ConfirmReasonRequestDto): Promise<any>;
  getReasonByIds(request: GetReasonByIdsRequestDto): Promise<any>;
}
