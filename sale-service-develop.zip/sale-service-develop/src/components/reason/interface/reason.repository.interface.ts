import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ReasonEntity } from '@entities/reason/reason.entity';
import { CreateReasonRequestDto } from '../dto/request/create-reason.request.dto';
import { GetReasonListRequestDto } from '../dto/request/get-reason-list.request.dto';
import { UpdateReasonRequestDto } from '../dto/request/update-reason.request.dto';

export interface ReasonRepositoryInterface
  extends BaseInterfaceRepository<ReasonEntity> {
  createEntity(request: CreateReasonRequestDto): ReasonEntity;
  updateEntity(
    reason: ReasonEntity,
    request: UpdateReasonRequestDto,
  ): ReasonEntity;
  getList(request: GetReasonListRequestDto): Promise<any>;
}
