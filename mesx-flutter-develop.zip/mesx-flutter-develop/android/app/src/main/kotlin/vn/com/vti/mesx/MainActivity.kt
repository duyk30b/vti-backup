package vn.com.vti.mesx

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
