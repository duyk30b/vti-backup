# MESX

Mesx with Flutter Framework

## Config

config argument android studio
--flavor staging
--flavor uat

## Run App

flutter run --flavor uat lib/features/main_uat.dart
flutter run --flavor staging lib/features/main_staging.dart

## Build App Android

flutter build apk --flavor uat lib/features/main_uat.dart
flutter build apk --flavor staging lib/features/main_staging.dart

## Build runner

flutter packages pub run build_runner build --delete-conflicting-outputs

## flutter intl

flutter --no-color pub global run intl_utils:generate

## flutter lint

check lint: flutter analyze
fix lint: dart fix --apply

## Generate launcher icon

flutter pub run flutter_launcher_icons
