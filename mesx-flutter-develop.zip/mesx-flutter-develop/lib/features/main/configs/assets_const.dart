abstract class AssetsConst {
  static const String logo = 'assets/images/logo.png';
  static const String logoWhite = 'assets/images/logo_white.png';
  static const String flagJA = 'assets/images/flag_ja.svg';
  static const String flagEN = 'assets/images/flag_en.png';
  static const String flagVI = 'assets/images/flag_vi.svg';
  static const String splashImage = 'assets/images/splash_image.svg';

  static const String splashTopLeftCorner =
      'assets/images/splash_top_left_corner.svg';
  static const String splashTopRightCorner =
      'assets/images/splash_top_right_corner.svg';
  static const String loginTopLeftCorner =
      'assets/images/login_top_left_corner.svg';
  static const String loginTopRightCorner =
      'assets/images/login_top_right_corner.svg';
  static const String icEye = 'assets/images/ic_eye.svg';
  static const String icEyeSlash = 'assets/images/ic_eye_slash.svg';
}
