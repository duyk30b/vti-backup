import 'supply.dart';
import 'supply_group.dart';
import 'unit.dart';
import 'vendor.dart';

class WarehouseExportSupply {
  final Supply? supply;
  final Unit? unit;
  final Vendor? vendor;
  final SupplyGroup? supplyGroup;
  final num? availableQuantity;
  final num? exportQuantity;
  final num? requestQuantity;
  final num? stockQuantity;
  final String? color;
  final String? size;

  WarehouseExportSupply({
    this.supply,
    this.unit,
    this.vendor,
    this.supplyGroup,
    this.availableQuantity,
    this.exportQuantity,
    this.requestQuantity,
    this.stockQuantity,
    this.color,
    this.size,
  });

  Map<String, dynamic> toFormJson() => {
        'supply': supply,
        'supplyName': supply?.name,
        'supplyCode': supply?.code,
        'supplyGroup': supplyGroup,
        'supplyGroupName': supplyGroup?.name,
        'requestQuantity': requestQuantity,
        'stockQuantity': stockQuantity,
        'availableQuantity': availableQuantity,
        'exportQuantity': exportQuantity,
        'color': color,
        'size': size,
        'unitName': unit?.name,
      };
}
