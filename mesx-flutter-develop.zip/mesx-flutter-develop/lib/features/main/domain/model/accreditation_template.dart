import 'accreditation_template_detail.dart';

class AccreditationTemplate {
  final String? id;
  final String? name;
  final String? code;
  final int? active;
  final String? description;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final List<AccreditationTemplateDetail>? details;

  AccreditationTemplate({
    this.id,
    this.name,
    this.code,
    this.active,
    this.description,
    this.createdAt,
    this.updatedAt,
    this.details,
  });
}
