class SupplyGroup {
  final String? id;
  final String? name;
  final String? code;

  SupplyGroup({
    this.id,
    this.name,
    this.code,
  });
}
