import 'area_info.dart';
import 'device_detail.dart';
import 'device_group.dart';
import 'unit.dart';
import 'vendor.dart';

class WarehouseImportDevice {
  final DeviceDetail? device;
  final String? templateNum;
  final Unit? unit;
  final Vendor? vendor;
  final AreaInfo? importArea;
  final num? quantity;
  final DeviceGroup? deviceGroup;
  final num? price;
  final String? size;
  final String? color;
  final num? grantedQuantity;
  final num? returnQuantity;

  WarehouseImportDevice({
    this.device,
    this.templateNum,
    this.unit,
    this.vendor,
    this.importArea,
    this.quantity,
    this.deviceGroup,
    this.price,
    this.size,
    this.color,
    this.grantedQuantity,
    this.returnQuantity,
  });
}

extension WarehouseImportDeviceExt on WarehouseImportDevice {
  num? get totalPrice {
    if (price != null && quantity != null) {
      final total = price! * quantity!;
      return total;
    } else {
      return null;
    }
  }

  Map<String, dynamic> toFormJson() {
    return {
      'device': device,
      'code': device?.code,
      'serial': device?.serial,
      'name': device?.name,
      'deviceId': device?.id,
      'group': deviceGroup?.name,
      'templateNum': templateNum,
      'unit': unit?.name,
      'vendor': vendor,
      'importArea': importArea?.name,
      'importAreaId': importArea?.id,
      'quantity': quantity,
      'price': price?.toString(),
      'intoMoney': totalPrice?.toString(),
      'size': size ?? '',
      'color': color ?? '',
      'grantedQuantity': grantedQuantity,
      'returnQuantity': returnQuantity,
    };
  }
}
