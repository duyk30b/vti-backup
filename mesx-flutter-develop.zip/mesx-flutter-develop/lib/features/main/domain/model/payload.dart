import 'package:json_annotation/json_annotation.dart';

class PayLoad {
  final String id;
  final String name;
  final String code;
  final NotificationEntityEnum entity;
  final int? entityType;
  final String sId;

  PayLoad(
      {required this.id,
      required this.name,
      required this.code,
      required this.entity,
      required this.sId,
      this.entityType});
}

@JsonEnum(valueField: 'entity')
enum NotificationEntityEnum {
  deviceRequestDetail(0),
  deviceAssignDetail(1),
  jobList(2),
  jobDetail(3),
  repairRequestDetail(4),
  warningSystem(5);

  final int entity;

  const NotificationEntityEnum(this.entity);
}

// extension NotificationEntityEnumExtension on NotificationEntityEnum {
//   String get name {
//     switch (this) {
//       case NotificationEntityEnum.deviceRequestDetail:
//         return 'Yêu cầu thiết bị';
//       case NotificationEntityEnum.deviceAssignDetail:
//         return 'Phân công thiết bị';
//       case NotificationEntityEnum.jobList:
//         return 'Yêu cầu sửa chữa đột xuất';
//       case NotificationEntityEnum.jobDetail:
//         return 'Quản lý công việc';
//       case NotificationEntityEnum.repairRequestDetail:
//         return 'Công việc kiểm định';
//       case NotificationEntityEnum.warningSystem:
//         return 'Quản lý cảnh báo hệ thống';
//     }
//   }

// }
