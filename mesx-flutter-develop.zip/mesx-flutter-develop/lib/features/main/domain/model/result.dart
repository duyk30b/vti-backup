import '../enum/maintain_enum.dart';
import '../enum/qc_test_enum.dart';
import 'detail.dart';

class Result {
  int? result;
  List<Detail>? details;
  MaintainType? maintenanceType;
  String? description;

  Result({this.result, this.details, this.description, this.maintenanceType});
}

extension ResultExt on Result {
  QcTest get qcTest =>
      QcTest.values.firstWhere((element) => element.status == result);
}
