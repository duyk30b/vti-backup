import 'area_info.dart';
import 'device_detail.dart';
import 'device_group.dart';
import 'factory_info.dart';
import 'unit.dart';

class DeviceAssignment {
  final String? id;
  final String? code;
  final String? name;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final FactoryInfo? factory;
  final List<DeviceDetail> devices;
  final List<DeviceAssignmentDetail> details;

  DeviceAssignment({
    this.id,
    this.code,
    this.name,
    this.createdAt,
    this.updatedAt,
    this.factory,
    this.devices = const [],
    this.details = const [],
  });

  @override
  String toString() {
    return 'DeviceAssignment(id: $id, code: $code, createdAt: $createdAt, updatedAt: $updatedAt, factory: $factory, devices: $devices)';
  }
}

class DeviceAssignmentDetail {
  final AreaInfo? area;
  final DeviceDetail? device;
  final DeviceGroup? deviceGroup;
  final Unit? unit;

  DeviceAssignmentDetail({
    this.area,
    this.device,
    this.deviceGroup,
    this.unit,
  });

  Map<String, dynamic> toWarehouseImportDeviceJson() {
    return {
      'deviceId': device?.id,
      'device': device,
      'name': device?.name,
      'serial': device?.serial,
      'group': deviceGroup?.name,
      'price': '',
      'quantity': '1',
      'intoMoney': '',
      'importArea': area?.name,
      'importAreaId': area?.id,
      'unit': unit?.name,
    };
  }

  DeviceDetail? toDeviceDetail() {
    return device?.copyWith(
      area: area,
      unit: unit,
      deviceGroup: deviceGroup,
    );
  }
}
