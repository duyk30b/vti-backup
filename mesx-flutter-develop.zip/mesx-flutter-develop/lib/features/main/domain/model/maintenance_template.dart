import 'maintenance_template_detail.dart';

class MaintenanceTemplate {
  final String? id;
  final String? name;
  final String? code;
  final int? active;
  final String? description;
  final DateTime? createdAt;
  final List<MaintenanceTemplateDetail>? details;

  MaintenanceTemplate({
    this.id,
    this.name,
    this.code,
    this.active,
    this.description,
    this.createdAt,
    this.details,
  });
}
