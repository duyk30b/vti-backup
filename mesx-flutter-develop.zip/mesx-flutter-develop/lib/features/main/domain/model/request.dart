import 'warehouse.dart';

class Request {
  final String? id;
  final String? code;
  final String? name;
  final Warehouse? exportWarehouse;
  final Warehouse? warehouse;

  Request({
    this.id,
    this.code,
    this.name,
    this.exportWarehouse,
    this.warehouse,
  });
}
