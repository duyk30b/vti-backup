class DeviceInfo {
  final String id;
  final String code;
  final String name;
  final String? serial;
  final String? identificationNo;

  DeviceInfo(this.id, this.code, this.name, this.serial, this.identificationNo);

  @override
  String toString() {
    return 'DeviceInfo{id: $id, name: $name}';
  }
}
