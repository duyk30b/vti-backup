import '../enum/device_request_enum.dart';
import 'device_detail.dart';
import 'factory_info.dart';

class DeviceRequest {
  final String? id;
  final String? code;
  final String? name;
  final String? description;
  final FactoryInfo? factory;
  final FactoryInfo? fromFactory;
  final FactoryInfo? toFactory;
  final DateTime? expectReturnDate;
  final DeviceRequestType? type;
  final DeviceRequestStatus? status;
  final List<DeviceDetail> devices;

  DeviceRequest({
    this.id,
    this.code,
    this.name,
    this.description,
    this.factory,
    this.expectReturnDate,
    this.type,
    this.status,
    this.devices = const [],
    this.fromFactory,
    this.toFactory,
  });
}
