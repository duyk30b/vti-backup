class CreateBy {
  final int? id;
  final String? fullName;
  final String? userName;
  final String? name;

  CreateBy(this.id, this.fullName, this.userName, this.name);
}
