import '../enum/repair_request_status.dart';
import 'device_detail.dart';
import 'error_type.dart';
import 'job.dart';
import 'repair_request_history.dart';
import 'supply.dart';
import 'user.dart';

class RepairRequest {
  final String? id;
  final String? code;
  final String? name;
  final RepairRequestPriorityEnum? priority;
  final DateTime? createdAt;
  final DeviceDetail? device;
  final User? requestedBy;
  final List<RepairRequestHistory> histories;
  final RepairRequestStatusEnum? status;
  final ErrorType? errorType;
  final String? description;
  final List<Supply>? supplies;
  final User? executedBy;
  final num? stopTime;
  final num? executionTime;
  final Job? accreditationJob;

  RepairRequest({
    this.id,
    this.code,
    this.name,
    this.priority,
    this.createdAt,
    this.device,
    this.requestedBy,
    this.histories = const [],
    this.status,
    this.errorType,
    this.description,
    this.supplies = const [],
    this.executedBy,
    this.stopTime,
    this.executionTime,
    this.accreditationJob,
  });

  @override
  String toString() {
    return 'RepairRequest(id: $id, code: $code, priority: $priority, createdAt: $createdAt, device: $device, requestedBy: $requestedBy)';
  }
}
