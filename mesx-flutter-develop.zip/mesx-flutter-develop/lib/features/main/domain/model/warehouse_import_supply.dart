import 'supply.dart';
import 'supply_group.dart';
import 'unit.dart';
import 'vendor.dart';
import 'warehouse.dart';

class WarehouseImportSupply {
  final Supply? supply;
  final String? symbol;
  final String? color;
  final String? size;
  final String? templateNum;
  final Unit? unit;
  final SupplyGroup? supplyGroup;
  final Vendor? vendor;
  final Warehouse? warehouse;
  final num? quantity;
  final num? price;
  final num? grantedQuantity;
  final num? returnQuantity;
  final num? providedQuantity;

  WarehouseImportSupply({
    this.supply,
    this.symbol,
    this.templateNum,
    this.unit,
    this.supplyGroup,
    this.vendor,
    this.warehouse,
    this.color,
    this.size,
    this.quantity,
    this.price,
    this.grantedQuantity,
    this.returnQuantity,
    this.providedQuantity,
  });
}

extension WarehouseImportSupplyExt on WarehouseImportSupply {
  num? get totalPrice {
    if (price != null && quantity != null) {
      final total = price! * quantity!;
      return total;
    } else {
      return null;
    }
  }

  Map<String, dynamic> toFormJson() {
    return {
      'supply': supply,
      'code': supply?.code,
      'name': supply?.name,
      'supplyId': supply?.id,
      'group': supplyGroup?.name,
      'symbol': symbol,
      'templateNum': templateNum,
      'unit': unit?.name,
      'supplyGroup': supplyGroup,
      'supplyGroupName': supplyGroup?.name,
      'vendor': vendor,
      'warehouse': warehouse,
      'color': color,
      'size': size,
      'quantity': quantity,
      'price': price,
      'grantedQuantity': grantedQuantity,
      'returnQuantity': returnQuantity,
      'providedQuantity': providedQuantity,
    };
  }

  Supply? toSupply() {
    return supply?.copyWith(
      unit: unit,
      supplyGroup: supplyGroup,
      providedQuantity: providedQuantity as int?,
    );
  }
}
