import 'area_info.dart';
import 'device_detail.dart';
import 'device_group.dart';
import 'unit.dart';

class WarehouseExportDevice {
  final DeviceDetail? device;
  final Unit? unit;
  final AreaInfo? area;
  final DeviceGroup? deviceGroup;
  final String? size;
  final String? color;
  final int? quantity;
  WarehouseExportDevice({
    this.device,
    this.unit,
    this.area,
    this.deviceGroup,
    this.size,
    this.color,
    this.quantity,
  });

  DeviceDetail get deviceDetail => device!.copyWith(
        id: device?.id,
        name: device?.name,
        code: device?.code,
        deviceGroup: deviceGroup,
        unit: unit,
        area: area,
      );

  Map<String, dynamic> toFormJson() {
    return {
      'area': area,
      'areaName': area?.name,
      'device': device,
      'deviceName': device?.name,
      'deviceSerial': device?.serial,
      'deviceGroup': deviceGroup,
      'deviceGroupName': deviceGroup?.name,
      'unit': unit,
      'color': color,
      'size': size,
      'quantity': quantity,
    };
  }
}
