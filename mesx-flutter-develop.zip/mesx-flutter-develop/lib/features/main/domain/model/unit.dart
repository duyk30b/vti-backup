class Unit {
  final String? code;
  final String? name;
  final int? active;

  Unit({this.code, this.name, this.active});
}
