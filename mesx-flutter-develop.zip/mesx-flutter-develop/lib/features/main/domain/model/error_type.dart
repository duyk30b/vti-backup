class ErrorType {
  final String id;
  final String code;
  final String name;

  ErrorType(this.id, this.code, this.name);
}
