import '../enum/device_enum.dart';
import 'area_info.dart';
import 'article_device_group.dart';
import 'device_group.dart';
import 'factory_info.dart';
import 'maintenance_index.dart';
import 'supply.dart';
import 'unit.dart';
import 'vendor.dart';
import 'warehouse.dart';

class DeviceDetail {
  final String? id;
  final String? code;
  final String? name;
  final DeviceUsageStatus? status;
  final num? warrantyPeriod;
  final String? serial;
  final String? actualSerial;
  final String? model;
  final String? manufacturer;
  final DateTime? manufactureDate;
  final DeviceGroup? deviceGroup;
  final Vendor? vendor;
  final MaintenanceIndex? maintenanceIndex;
  final DateTime? createdAt;
  final DateTime? creationDate;
  final DateTime? capitalizationDate;
  final String? imageUrl;
  final FactoryInfo? factory;
  final AreaInfo? area;
  final String? description;
  final String? identificationNo;
  final ArticleDeviceGroup? articleDeviceGroup;
  final List<Supply>? supplies;
  final Unit? unit;
  final Warehouse? warehouse;
  final Warehouse? exportWarehouse;
  final int? exportPlanned;
  final int? exported;
  final int? imported;
  final int? importPlanned;
  final int? returnPlanned;

  DeviceDetail({
    this.id,
    this.code,
    this.name,
    this.serial,
    this.status,
    this.deviceGroup,
    this.manufacturer,
    this.vendor,
    this.manufactureDate,
    this.warrantyPeriod,
    this.maintenanceIndex,
    this.model,
    this.createdAt,
    this.capitalizationDate,
    this.factory,
    this.area,
    this.description,
    this.articleDeviceGroup,
    this.creationDate,
    this.imageUrl,
    this.identificationNo,
    this.supplies,
    this.warehouse,
    this.exportWarehouse,
    this.unit,
    this.exportPlanned,
    this.exported,
    this.importPlanned,
    this.returnPlanned,
    this.imported,
    this.actualSerial,
  });

  @override
  String toString() {
    return 'DeviceDetail(id: $id, code: $code, name: $name, status: $status, warrantyPeriod: $warrantyPeriod, serial: $serial, model: $model, manufacturer: $manufacturer, manufactureDate: $manufactureDate, deviceGroup: $deviceGroup, vendor: $vendor, maintenanceIndex: $maintenanceIndex, createdAt: $createdAt, creationDate: $creationDate, capitalizationDate: $capitalizationDate, imageUrl: $imageUrl, factory: $factory, area: $area, description: $description, identificationNo: $identificationNo, articleDeviceGroup: $articleDeviceGroup, supplies: $supplies, unit: $unit)';
  }

  DeviceDetail copyWith({
    String? id,
    String? code,
    String? name,
    DeviceUsageStatus? status,
    num? warrantyPeriod,
    String? serial,
    String? model,
    String? manufacturer,
    DateTime? manufactureDate,
    DeviceGroup? deviceGroup,
    Vendor? vendor,
    MaintenanceIndex? maintenanceIndex,
    DateTime? createdAt,
    DateTime? creationDate,
    DateTime? capitalizationDate,
    String? imageUrl,
    FactoryInfo? factory,
    AreaInfo? area,
    String? description,
    String? identificationNo,
    ArticleDeviceGroup? articleDeviceGroup,
    List<Supply>? supplies,
    Unit? unit,
    Warehouse? warehouse,
    int? exportPlanned,
    int? exported,
    int? importPlanned,
    int? returnPlanned,
  }) {
    return DeviceDetail(
      id: id ?? this.id,
      code: code ?? this.code,
      name: name ?? this.name,
      status: status ?? this.status,
      warrantyPeriod: warrantyPeriod ?? this.warrantyPeriod,
      serial: serial ?? this.serial,
      model: model ?? this.model,
      manufacturer: manufacturer ?? this.manufacturer,
      manufactureDate: manufactureDate ?? this.manufactureDate,
      deviceGroup: deviceGroup ?? this.deviceGroup,
      vendor: vendor ?? this.vendor,
      maintenanceIndex: maintenanceIndex ?? this.maintenanceIndex,
      createdAt: createdAt ?? this.createdAt,
      creationDate: creationDate ?? this.creationDate,
      capitalizationDate: capitalizationDate ?? this.capitalizationDate,
      imageUrl: imageUrl ?? this.imageUrl,
      factory: factory ?? this.factory,
      area: area ?? this.area,
      description: description ?? this.description,
      identificationNo: identificationNo ?? this.identificationNo,
      articleDeviceGroup: articleDeviceGroup ?? this.articleDeviceGroup,
      supplies: supplies ?? this.supplies,
      unit: unit ?? this.unit,
      warehouse: warehouse ?? this.warehouse,
      exportPlanned: exportPlanned ?? this.exportPlanned,
      exported: exported ?? this.exported,
      importPlanned: importPlanned ?? this.importPlanned,
      returnPlanned: returnPlanned ?? this.returnPlanned,
    );
  }
}

extension DeviceDetailExt on DeviceDetail {
  Map<String, dynamic> toWarehouseImportDeviceJson({num? quantity}) {
    return {
      'deviceId': id,
      'device': this,
      'name': name,
      'serial': serial,
      'group': articleDeviceGroup?.name,
      'price': '',
      'quantity': quantity ?? 1,
      'intoMoney': '',
      'importArea': area?.name,
      'importAreaId': area?.id,
      'unit': unit?.name,
    };
  }

  Map<String, dynamic> toFormJson() {
    return {
      'area': area,
      'areaName': area?.name,
      'device': this,
      'deviceName': name,
      'deviceSerial': serial,
      'deviceGroup': deviceGroup,
      'deviceGroupName': deviceGroup?.name,
      'unit': unit,
      'warehouse': warehouse,
      'warehouseName': warehouse?.name,
      'color': '',
      'size': '',
    };
  }

  Map<String, dynamic> toWarehouseImportTicketJson({
    String? color,
    String? size,
    num? price,
  }) {
    return {
      'deviceId': id,
      'device': this,
      'name': name,
      'serial': serial,
      'group': articleDeviceGroup?.name,
      'deviceGroup': deviceGroup,
      'deviceGroupName': deviceGroup?.name,
      'quantity': '1',
      'intoMoney': '',
      'importArea': area?.name,
      'importAreaId': area?.id,
      'unit': unit?.name,
      'color': color,
      'size': size,
      'price': price,
      'identificationNo': identificationNo
    };
  }
}
