import '../../data/network/base_response/base_response.dart';
import 'notification_info.dart';

class NotificationResponse extends BasePagingResponse<NotificationInfo> {
  NotificationResponse(super.statusCode, super.message, super.data, super.meta);
}
