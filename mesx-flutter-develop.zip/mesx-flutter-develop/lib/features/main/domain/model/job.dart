import 'package:collection/collection.dart';

import '../../../../core/utils/date_utils.dart';
import '../../../../generated/l10n.dart';
import '../enum/job_enum.dart';
import '../enum/task_status.dart';
import 'assign.dart';
import 'device_detail.dart';
import 'job_type_template.dart';
import 'repair_request_history.dart';
import 'result.dart';
import 'supply.dart';
import 'warning.dart';

class Job {
  final String? id;
  final String? code;
  final String? name;
  final JobTypeEnum? type;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final DeviceDetail? device;
  final DateTime? planFrom;
  final DateTime? planTo;
  final DateTime? executionDateFrom;
  final DateTime? executionDateTo;
  final int? status;
  final JobStatus? jobStatus;
  final String? description;
  final Assign? assign;
  final JobTypeTemplate? jobTypeTemplate;
  final Result? result;
  final List<RepairRequestHistory>? histories;
  final int? executionTime;
  final int? stopTime;
  final bool? isOverdue;
  final List<Supply>? supplies;
  final Warning? warning;
  final String? imageUrl;
  final String? fileName;
  final bool? canUpdateJobTime;

  DateTime get startTime {
    if (histories == null) return DateTime.now();
    var history = histories?.lastWhereOrNull((element) =>
        element.action.toString() == '1' && element.status.toString() == '2');
    if (history == null) return DateTime.now();
    return history.createdAt!;
  }

  Job(
      {this.id,
      this.code,
      this.name,
      this.type,
      this.createdAt,
      this.device,
      this.planFrom,
      this.planTo,
      this.status,
      this.assign,
      this.description,
      this.jobTypeTemplate,
      this.result,
      this.histories,
      this.executionTime,
      this.executionDateFrom,
      this.executionDateTo,
      this.isOverdue,
      this.jobStatus,
      this.stopTime,
      this.supplies,
      this.warning,
      this.fileName,
      this.imageUrl,
      this.canUpdateJobTime,
      this.updatedAt});
}

extension JobExtension on Job {
  String get titleState {
    if (isOverdue == true) {
      return '${taskStatus?.title}-${BS.current.over_due}';
    }
    return taskStatus?.title ?? '';
  }

  TaskStatus? get taskStatus {
    return TaskStatus.values
        .firstWhereOrNull((element) => element.status == status);
  }

  String get planFromStr {
    return DateUtilsFormat.toDateString(planFrom?.toLocal());
  }

  String get planToStr {
    return DateUtilsFormat.toDateString(planTo?.toLocal());
  }

  String get executionDateFromStr {
    return DateUtilsFormat.toDateString(executionDateFrom?.toLocal());
  }

  String get executionDateToStr {
    return DateUtilsFormat.toDateString(executionDateTo?.toLocal());
  }
}
