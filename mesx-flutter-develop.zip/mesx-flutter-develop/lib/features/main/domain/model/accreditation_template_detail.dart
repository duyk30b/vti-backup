class AccreditationTemplateDetail {
  final String? id;
  final String? title;
  final String? description;
  final num? obligatory;

  AccreditationTemplateDetail({
    this.id,
    this.title,
    this.description,
    this.obligatory,
  });
}
