import 'device_detail.dart';

class DeviceList {
  final List<DeviceDetail> data;
  final int total;
  final int page;

  DeviceList(this.data, this.total, this.page);
}
