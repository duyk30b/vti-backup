class FactoryInfo {
  final int? id;
  final String? code;
  final String? name;

  FactoryInfo({this.id, this.code, this.name});

  @override
  String toString() {
    return 'FactoryInfo{id: $id, name: $name}';
  }
}
