import '../enum/priority_enum.dart';
import 'detail.dart';

class JobTypeTemplate {
  String? id;
  String? createdAt;
  String? updatedAt;
  String? code;
  String? name;
  String? description;
  int? active;
  Priority? priority;
  List<Detail>? details;

  JobTypeTemplate(
      {this.id,
      this.createdAt,
      this.updatedAt,
      this.code,
      this.name,
      this.description,
      this.active,
      this.details,
      this.priority});
}
