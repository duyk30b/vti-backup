import '../../data/network/base_response/base_response.dart';
import 'job.dart';

class JobListResponse extends BasePagingResponse<Job> {
  JobListResponse(super.statusCode, super.message, super.data, super.meta);
}
