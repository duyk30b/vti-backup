import '../enum/device_status.dart';

class DeviceStatus {
  final String? id;
  final String? code;
  final String? name;
  final String? serial;
  final DeviceStatusType? deviceStatus;

  DeviceStatus({
    this.name,
    this.id,
    this.serial,
    this.deviceStatus,
    this.code,
  });

  @override
  String toString() {
    return 'DeviceStatus{id: $id, name: $name}';
  }
}
