import '../../../../core/configs/constants.dart';
import '../../../../core/utils/date_utils.dart';
import '../../../../generated/l10n.dart';
import 'notification_id.dart';

class NotificationInfo {
  final String sId;
  final int userId;
  final NotificationID notificationId;
  final int status;
  final String? readAt;
  final String title;
  final String content;
  final String type;
  final String createdAt;
  final String updatedAt;
  final int iV;

  NotificationInfo(
      this.sId,
      this.userId,
      this.notificationId,
      this.status,
      this.readAt,
      this.title,
      this.content,
      this.type,
      this.createdAt,
      this.updatedAt,
      this.iV);

  DateTime get dateTimeCreateAt => DateUtilsFormat.fromString(createdAt)!;

  String get dateTimeCreateAtStr {
    final now = DateTime.now();
    final diff = now.difference(dateTimeCreateAt.toLocal());
    if (diff.inDays > 0) {
      if (diff.inDays == 1) {
        return '${DateUtilsFormat.toDateTimeString(dateTimeCreateAt, format: Constants.timeFormat)} ${BS.current.yesterday}';
      }
      return DateUtilsFormat.toDateTimeString(dateTimeCreateAt);
    } else if (diff.inHours > 0) {
      return BS.current.time_hour_ago(diff.inHours.toString());
    } else if (diff.inMinutes > 0) {
      return BS.current.time_minute_ago(diff.inMinutes.toString());
    } else if (diff.inSeconds > 0) {
      return BS.current.time_seconds_ago(diff.inSeconds.toString());
    } else {
      return BS.current.just_now;
    }
  }

  bool get isRead => readAt != null;
}
