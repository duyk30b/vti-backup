import 'assets_type_display.dart';
import 'factory_info.dart';
import 'unit.dart';
import 'warehouse.dart';

class Inventory {
  String? id;
  String? assetId;
  String? assetName;
  String? assetNameOther;
  String? assetCode;
  int? stockQuantity;
  Warehouse? warehouse;
  Unit? unit;
  FactoryInfo? factory;
  AssetTypeDisplay? assetTypeDisplay;

  String get title {
    var name = '';
    if (assetName != null && assetName!.isNotEmpty) {
      name += assetName!;
    }
    if (assetNameOther != null && assetNameOther!.isNotEmpty) {
      name += ' - ${assetNameOther!}';
    }
    if (assetCode != null && assetCode!.isNotEmpty) {
      name += ' - ${assetCode!}';
    }
    return name;
  }

  Inventory(
      {this.id,
      this.assetId,
      this.assetName,
      this.assetCode,
      this.stockQuantity,
      this.warehouse,
      this.unit,
      this.factory,
      this.assetNameOther,
      this.assetTypeDisplay});
}
