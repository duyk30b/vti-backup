class MaintenanceTemplateDetail {
  final String? id;
  final String? title;
  final String? description;
  final int? type;
  final num? obligatory;
  final num? periodTime;
  final num? timeUnit;

  MaintenanceTemplateDetail({
    this.id,
    this.title,
    this.description,
    this.type,
    this.obligatory,
    this.periodTime,
    this.timeUnit,
  });
}
