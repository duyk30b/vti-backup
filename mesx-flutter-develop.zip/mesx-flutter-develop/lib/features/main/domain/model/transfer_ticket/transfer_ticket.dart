import '../../enum/transfer_ticket_enum.dart';
import '../area_info.dart';
import '../device_detail.dart';
import '../device_group.dart';
import '../factory_info.dart';
import '../unit.dart';
import '../warehouse.dart';

class TransferTicket {
  final String? id;
  final String? code;
  final String? name;
  final DateTime? estimatedReturnDate;
  final FactoryInfo? fromFactory;
  final FactoryInfo? toFactory;
  final DateTime? transferDate;
  final TransferTicketStatus? status;
  final TransferTicketType? type;
  final List<TransferTicketDevice>? devices;

  TransferTicket({
    this.id,
    this.code,
    this.name,
    this.estimatedReturnDate,
    this.fromFactory,
    this.toFactory,
    this.transferDate,
    this.status,
    this.type,
    this.devices,
  });
}

class TransferTicketDevice {
  final AreaInfo? area;
  final DeviceDetail? device;
  final DeviceGroup? deviceGroup;
  final Unit? unit;
  final Warehouse? warehouse;
  final String? color;
  final String? size;
  final int? exportPlanned;
  final int? exported;
  final int? importPlanned;
  final int? returnPlanned;

  TransferTicketDevice({
    this.area,
    this.device,
    this.deviceGroup,
    this.unit,
    this.warehouse,
    this.color,
    this.size,
    this.exportPlanned,
    this.exported,
    this.importPlanned,
    this.returnPlanned,
  });

  Map<String, dynamic> toFormJson() {
    return {
      'area': area,
      'areaName': area?.name,
      'device': device,
      'deviceName': device?.name,
      'deviceSerial': device?.serial,
      'deviceGroup': deviceGroup,
      'deviceGroupName': deviceGroup?.name,
      'unit': unit,
      'warehouse': warehouse,
      'warehouseName': warehouse?.name,
      'color': '',
      'size': '',
    };
  }

  DeviceDetail getDevice() {
    return DeviceDetail(
      id: device?.id,
      name: device?.name,
      serial: device?.serial,
      identificationNo: device?.identificationNo,
      deviceGroup: deviceGroup,
      unit: unit,
      area: area,
      warehouse: warehouse,
      exportPlanned: exportPlanned,
      exported: exported,
      importPlanned: importPlanned,
      returnPlanned: returnPlanned,
    );
  }
}
