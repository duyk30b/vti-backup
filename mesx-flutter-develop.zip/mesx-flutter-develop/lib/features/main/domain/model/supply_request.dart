import '../enum/supply_request_enum.dart';
import 'create_by.dart';
import 'factory_info.dart';
import 'job.dart';
import 'request.dart';
import 'supply.dart';
import 'warehouse.dart';

class SupplyRequest {
  final String? id;
  final String? name;
  final String? code;
  final String? description;
  final List<Job>? jobs;
  final SupplyRequestStatus? status;
  final int? type;
  final DateTime? expectDate;
  final CreateBy? requestedBy;
  final Warehouse? warehouse;
  final List<Supply>? supplies;
  final Request? request;
  final FactoryInfo? factory;
  final FactoryInfo? fromFactory;
  final FactoryInfo? toFactory;

  SupplyRequest({
    this.id,
    this.name,
    this.code,
    this.jobs,
    this.status,
    this.type,
    this.expectDate,
    this.requestedBy,
    this.description,
    this.warehouse,
    this.supplies,
    this.request,
    this.fromFactory,
    this.toFactory,
    this.factory,
  });

  @override
  String toString() {
    return 'SupplyRequest{id: $id, name: $name}';
  }
}
