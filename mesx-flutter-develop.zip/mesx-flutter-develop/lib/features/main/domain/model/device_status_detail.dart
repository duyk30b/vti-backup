import './attribute_type.dart';
import '../enum/device_status.dart';

class DeviceStatusDetail {
  final String? id;
  final DeviceStatusType? status;
  final DateTime? startTime;
  final DateTime? endTime;
  final num? activeTime;
  final List<AttributeType> attributeTypes;

  DeviceStatusDetail({
    this.status,
    this.startTime,
    this.endTime,
    this.activeTime,
    this.attributeTypes = const [],
    this.id,
  });
}
