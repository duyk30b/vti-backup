class Assign {
  final int id;
  final String code;
  final String? name;
  final String? username;

  Assign(this.id, this.code, {this.name, this.username});
}
