import '../enum/maintain_enum.dart';
import 'supply_group.dart';
import 'supply_type.dart';
import 'unit.dart';
import 'vendor.dart';

class Supply {
  final String? id;
  final String? name;
  final String? code;
  final String? nameOther;
  final int? quantity;
  final int? availableStockQuantity;
  final int? availableQuantity;
  final int? providedQuantity;
  final int? importPlannedQuantity;
  final int? exportPlannedQuantity;
  final SupplyType? supplyType;
  final num? estimateUsedTime;
  final num? price;
  final Unit? unit;
  final MaintainType? maintenanceType;
  final SupplyGroup? supplyGroup;
  final num? stockQuantity;
  final num? minStockQuantity;
  final Vendor? vendor;

  Supply({
    this.id,
    this.name,
    this.code,
    this.nameOther,
    this.quantity,
    this.supplyType,
    this.estimateUsedTime,
    this.unit,
    this.maintenanceType,
    this.availableStockQuantity,
    this.availableQuantity,
    this.supplyGroup,
    this.providedQuantity,
    this.stockQuantity,
    this.minStockQuantity,
    this.vendor,
    this.price,
    this.importPlannedQuantity,
    this.exportPlannedQuantity,
  });

  String get title {
    String titleStr = '';
    if (name != null) {
      titleStr += name!;
    }
    if (nameOther != null && nameOther!.isNotEmpty) {
      titleStr += ' - $nameOther';
    }
    if (code != null && code!.isNotEmpty) {
      titleStr += ' - $code';
    }
    return titleStr;
  }

  Supply copyWith({
    String? id,
    String? name,
    String? code,
    String? nameOther,
    int? quantity,
    SupplyType? supplyType,
    num? estimateUsedTime,
    Unit? unit,
    MaintainType? type,
    SupplyGroup? supplyGroup,
    int? providedQuantity,
    int? stockQuantity,
    int? requestQuantity,
    int? availableStockQuantity,
    Vendor? vendor,
  }) {
    return Supply(
      id: id ?? this.id,
      name: name ?? this.name,
      code: code ?? this.code,
      nameOther: nameOther ?? this.nameOther,
      quantity: quantity ?? this.quantity,
      supplyType: supplyType ?? this.supplyType,
      estimateUsedTime: estimateUsedTime ?? this.estimateUsedTime,
      unit: unit ?? this.unit,
      maintenanceType: type ?? maintenanceType,
      supplyGroup: supplyGroup ?? this.supplyGroup,
      providedQuantity: providedQuantity ?? this.providedQuantity,
      stockQuantity: stockQuantity ?? this.stockQuantity,
      availableStockQuantity:
          availableStockQuantity ?? this.availableStockQuantity,
    );
  }
}

extension SupplyExt on Supply {
  Map<String, dynamic> toJsonRequest() => {
        'supplyId': id,
        'maintenanceType': maintenanceType?.status,
        'quantity': quantity,
        'description': code
      };

  Map<String, dynamic> toWarehouseImportSupplyJson({num? quantity}) => {
        'supplyId': id,
        'supply': this,
        'code': code,
        'name': name,
        'group': supplyGroup?.name,
        'stockQuantity': stockQuantity,
        'supplyGroup': supplyGroup,
        'providedQuantity': providedQuantity,
        'quantity': quantity ?? this.quantity,
        'color': '',
        'size': '',
        'unit': unit?.name,
        'price': ''
      };

  Map<String, dynamic> toWarehouseExportSupplyJson({num? quantity}) => {
        'supply': this,
        'supplyName': name,
        'supplyCode': code,
        'supplyGroup': supplyGroup,
        'supplyGroupName': supplyGroup?.name,
        'requestQuantity': this.quantity,
        'stockQuantity': stockQuantity,
        'availableQuantity': availableStockQuantity,
        'exportQuantity': quantity ?? 1,
        'unitName': unit?.name,
      };

  Map<String, dynamic> toSupplyRequestFormJson() => {
        'id': id,
        'name': name,
        'code': code,
        'nameOther': nameOther,
        'quantity': quantity,
        'availableStockQuantity': availableStockQuantity,
        'availableQuantity': availableQuantity,
        'providedQuantity': providedQuantity,
        'supplyType': supplyType,
        'estimateUsedTime': estimateUsedTime,
        'unit': unit,
        'maintenanceType': maintenanceType,
        'supplyGroup': supplyGroup,
        'stockQuantity': stockQuantity,
        'minStockQuantity': minStockQuantity,
        'supply': this
      };
}
