class User {
  final int? id;
  final String? fullName;
  final String? userName;
  final String? name;
  final String? code;
  final int? factoryId;

  User({
    this.id,
    this.fullName,
    this.userName,
    this.name,
    this.code,
    this.factoryId,
  });
}
