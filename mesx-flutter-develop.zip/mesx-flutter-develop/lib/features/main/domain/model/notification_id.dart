import 'create_by.dart';
import 'payload.dart';

class NotificationID {
  final String sId;
  final int action;
  final PayLoad payload;
  final CreateBy? createdBy;

  NotificationID(this.sId, this.action, this.payload, {this.createdBy});
}
