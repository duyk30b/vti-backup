class PagingModel<T> {
  final List<T> data;
  final int total;
  final int page;

  PagingModel(this.data, this.total, this.page);
}
