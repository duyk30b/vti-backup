import 'factory_info.dart';

class AreaInfo {
  final String? id;
  final String? name;
  final String? code;
  final String? createdAt;
  final String? updatedAt;
  final FactoryInfo? factory;

  AreaInfo(
    this.id,
    this.name,
    this.code,
    this.createdAt,
    this.updatedAt,
    this.factory,
  );

  @override
  String toString() {
    return 'AreaInfo{id: $id, name: $name}';
  }
}
