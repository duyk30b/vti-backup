import '../enum/warehouse_export_enum.dart';
import 'device_request.dart';
import 'factory_info.dart';
import 'supply_request.dart';
import 'transfer_ticket/transfer_ticket.dart';
import 'warehouse.dart';
import 'warehouse_export_device.dart';
import 'warehouse_export_supply.dart';

class WarehouseExport {
  final String? id;
  final String? code;
  final String? name;
  final DateTime? exportDate;
  final DateTime? date;
  final String? note;
  final String? number;
  final String? contractNum;
  final String? debit;
  final String? credit;
  final String? gdiNo;
  final String? symbol;
  final String? reason;
  final WarehouseExportStatus? status;
  final FactoryInfo? toFactory;
  final Warehouse? warehouse;
  final WarehouseExportType? requestType;
  final List<WarehouseExportDevice>? devices;
  final List<WarehouseExportSupply>? supplies;
  final SupplyRequest? supplyRequest;
  final DeviceRequest? returnDevice;
  final TransferTicket? transferRequest;
  final TransferTicket? transferLoan;

  WarehouseExport({
    this.gdiNo,
    this.id,
    this.name,
    this.code,
    this.exportDate,
    this.status,
    this.date,
    this.note,
    this.number,
    this.toFactory,
    this.contractNum,
    this.debit,
    this.symbol,
    this.warehouse,
    this.reason,
    this.requestType,
    this.credit,
    this.devices,
    this.supplies,
    this.supplyRequest,
    this.returnDevice,
    this.transferRequest,
    this.transferLoan,
  });

  Map<String, dynamic> toFormJson() {
    return {
      'number': number,
      'reason': reason,
      'debit': debit,
      'credit': credit,
      'contractNum': contractNum,
      'symbol': symbol,
      'note': note,
      'date': date,
      'warehouseId': warehouse?.id,
      'toFactoryId': toFactory?.id,
      'requestType': requestType,
      'supplyRequest': supplyRequest,
      'deviceRequest': returnDevice,
      'transferRequest': transferRequest ?? transferLoan,
    };
  }
}

extension WarehouseExportExt on WarehouseExport {
  String get requestCode {
    switch (requestType) {
      case WarehouseExportType.supplyRequest:
        return supplyRequest?.code ?? '';
      case WarehouseExportType.returnDevice:
        return returnDevice?.code ?? '';
      case WarehouseExportType.transferRequest:
        return transferRequest?.code ?? '';
      case WarehouseExportType.transferLoan:
        return transferLoan?.code ?? '';
      default:
        return '';
    }
  }
}
