import './device_status_detail.dart';

class DeviceStatusDetailList {
  final List<DeviceStatusDetail> data;
  final int total;
  final int page;

  DeviceStatusDetailList(this.data, this.total, this.page);
}
