import 'unit.dart';

class AttributeType {
  final String? code;
  final String? name;
  final String? id;
  final Unit? unit;
  final String? attributeTypeName;
  final String? attributeTypeCode;
  final String? attributeTypeId;
  final num? value;

  AttributeType({
    this.code,
    this.name,
    this.id,
    this.unit,
    this.attributeTypeName,
    this.attributeTypeCode,
    this.attributeTypeId,
    this.value,
  });
}
