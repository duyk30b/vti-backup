class Warning {
  String? id;
  String? createdAt;
  String? updatedAt;
  String? name;
  String? code;

  Warning({this.id, this.createdAt, this.updatedAt, this.name, this.code});
}
