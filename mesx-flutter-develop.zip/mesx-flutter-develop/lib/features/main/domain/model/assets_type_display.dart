class AssetTypeDisplay {
  String? sId;
  String? name;
  int? type;

  AssetTypeDisplay({this.sId, this.name, this.type});
}
