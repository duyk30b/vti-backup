import '../../../../features/main/domain/model/device_status.dart';

class DeviceStatusList {
  final List<DeviceStatus> data;
  final int total;
  final int page;

  DeviceStatusList(this.data, this.total, this.page);
}
