class SupplyType {
  final String? id;
  final String? name;
  final int? type;
  final DateTime? createdAt;

  SupplyType({
    this.id,
    this.name,
    this.type,
    this.createdAt,
  });
}
