import '../enum/qc_test_enum.dart';

class Detail {
  String? id;
  String? title;
  String? description;
  int? obligatory;
  int? status;

  Detail({this.id, this.title, this.description, this.obligatory, this.status});

  QcTest get qcTest =>
      QcTest.values.firstWhere((element) => element.status == status,
          orElse: () => QcTest.failed);

  Detail copyWith({
    String? id,
    String? title,
    String? description,
    int? obligatory,
    int? status,
  }) {
    return Detail(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      obligatory: obligatory ?? this.obligatory,
      status: status ?? this.status,
    );
  }
}

extension DetailExt on Detail {
  Map<String, dynamic> toJsonRequest() => {
        'title': title,
        'description': description,
        'obligatory': obligatory,
        'status': qcTest.status,
      };
}
