class MaintenanceIndex {
  final DateTime? accreditationDateLatest;
  final DateTime? accreditationDateNext;
  final DateTime? maintenanceDateLatest;
  final DateTime? maintenanceDateNext;
  final num? mtbf;
  final num? mttr;
  final num? mtta;
  final num? mttf;

  MaintenanceIndex({
    this.accreditationDateLatest,
    this.accreditationDateNext,
    this.maintenanceDateLatest,
    this.maintenanceDateNext,
    this.mtbf,
    this.mttr,
    this.mtta,
    this.mttf,
  });
}
