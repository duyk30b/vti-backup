class Vendor {
  final String id;
  final String name;
  final String code;

  Vendor(this.id, this.name, this.code);
}
