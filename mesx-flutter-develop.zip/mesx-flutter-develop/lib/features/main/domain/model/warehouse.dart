import 'factory_info.dart';

class Warehouse {
  final String id;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final String name;
  final String code;
  final FactoryInfo? factory;

  Warehouse(
    this.id,
    this.createdAt,
    this.updatedAt,
    this.name,
    this.code,
    this.factory,
  );
}
