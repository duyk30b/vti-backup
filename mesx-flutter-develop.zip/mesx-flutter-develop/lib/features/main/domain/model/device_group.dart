// ignore_for_file: public_member_api_docs, sort_constructors_first
import './attribute_type.dart';
import 'accreditation_template.dart';
import 'article_device_group.dart';
import 'error_type.dart';
import 'installation_template.dart';
import 'maintenance_template.dart';
import 'supply.dart';

class DeviceGroup {
  final String? id;
  final String? name;
  final String? code;
  final List<AttributeType>? attributeTypes;
  final List<Supply>? supplies;
  final MaintenanceTemplate? maintenanceTemplate;
  final InstallationTemplate? installationTemplate;
  final AccreditationTemplate? accreditationTemplate;
  final List<ErrorType> errorTypes;
  final ArticleDeviceGroup? articleDeviceGroup;

  DeviceGroup({
    this.id,
    this.name,
    this.code,
    this.attributeTypes,
    this.supplies,
    this.maintenanceTemplate,
    this.installationTemplate,
    this.accreditationTemplate,
    this.errorTypes = const [],
    this.articleDeviceGroup,
  });
}
