import '../../enum/warehouse_request_enum.dart';
import '../device_detail.dart';
import '../warehouse.dart';
import 'warehouse_request_device_group.dart';
import 'warehouse_request_supply.dart';

class WarehouseRequest {
  final String? id;
  final String? code;
  final String? name;

  final List<WarehouseRequestDeviceGroup> deviceGroups;
  final List<WarehouseRequestSupply> supplies;
  final List<DeviceDetail> devices;
  final WarehouseRequestStatus? status;
  final Warehouse? warehouse;

  WarehouseRequest({
    this.id,
    this.name,
    this.code,
    this.deviceGroups = const [],
    this.supplies = const [],
    this.devices = const [],
    this.status,
    this.warehouse,
  });
}
