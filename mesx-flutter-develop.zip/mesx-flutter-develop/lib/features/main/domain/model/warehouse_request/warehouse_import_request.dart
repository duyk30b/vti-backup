import '../../enum/warehouse_request_enum.dart';
import '../../enum/warehouse_ticket_enum.dart';
import '../device_detail.dart';
import '../device_request.dart';
import '../factory_info.dart';
import '../supply_request.dart';
import '../transfer_ticket/transfer_ticket.dart';
import '../warehouse.dart';
import 'warehouse_request.dart';
import 'warehouse_request_device_group.dart';
import 'warehouse_request_supply.dart';

class WarehouseImportRequest extends WarehouseRequest {
  final String? requestCode;
  final String? description;
  final FactoryInfo? fromFactory;
  final FactoryInfo? toFactory;
  final DateTime? importDate;
  final WarehouseImportTicketRequestType? requestType;
  final DeviceRequest? deviceRequest;
  final SupplyRequest? supplyRequest;
  final TransferTicket? transferTicket;

  WarehouseImportRequest({
    this.description,
    this.fromFactory,
    this.importDate,
    this.toFactory,
    this.requestCode,
    this.requestType,
    this.deviceRequest,
    this.supplyRequest,
    this.transferTicket,
    String? id,
    String? code,
    String? name,
    List<WarehouseRequestDeviceGroup> deviceGroups = const [],
    List<WarehouseRequestSupply> supplies = const [],
    List<DeviceDetail> devices = const [],
    Warehouse? warehouse,
    WarehouseRequestStatus? status,
  }) : super(
          code: code,
          id: id,
          name: name,
          deviceGroups: deviceGroups,
          supplies: supplies,
          devices: devices,
          warehouse: warehouse,
          status: status,
        );
}
