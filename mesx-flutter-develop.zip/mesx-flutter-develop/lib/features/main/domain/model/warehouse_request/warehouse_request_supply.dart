// ignore_for_file: public_member_api_docs, sort_constructors_first
import '../../enum/maintain_enum.dart';
import '../supply.dart';
import '../supply_group.dart';
import '../supply_type.dart';
import '../unit.dart';
import '../vendor.dart';

class WarehouseRequestSupply extends Supply {
  final String? color;
  final String? size;
  final int? grantedQuantity;
  final int? returnQuantity;
  final int? requestQuantity;
  final int? importedQuantity;
  final int? importQuantity;

  final int? exportQuantity;
  final int? exportedQuantity;

  WarehouseRequestSupply({
    this.exportQuantity,
    this.exportedQuantity,
    this.importQuantity,
    this.importedQuantity,
    this.requestQuantity,
    this.color,
    this.size,
    this.grantedQuantity,
    this.returnQuantity,
    num? price,
    String? id,
    String? name,
    String? code,
    String? nameOther,
    int? quantity,
    int? availableStockQuantity,
    int? availableQuantity,
    int? providedQuantity,
    SupplyType? supplyType,
    num? estimateUsedTime,
    Unit? unit,
    MaintainType? maintenanceType,
    SupplyGroup? supplyGroup,
    num? stockQuantity,
    num? minStockQuantity,
    Vendor? vendor,
    super.importPlannedQuantity,
    super.exportPlannedQuantity,
  }) : super(
            id: id,
            name: name,
            code: code,
            nameOther: nameOther,
            quantity: quantity,
            availableStockQuantity: availableStockQuantity,
            availableQuantity: availableQuantity,
            providedQuantity: providedQuantity,
            supplyType: supplyType,
            estimateUsedTime: estimateUsedTime,
            unit: unit,
            maintenanceType: maintenanceType,
            supplyGroup: supplyGroup,
            stockQuantity: stockQuantity,
            minStockQuantity: minStockQuantity,
            price: price,
            vendor: vendor);

  int get remainExportQuantity =>
      (exportQuantity ?? 0) - (exportedQuantity ?? 0);
  num get intoMoney => (price ?? 0) * (importQuantity ?? 0);

  int? get remainImportQuantity {
    if (importQuantity == null || importedQuantity == null) return null;

    return importQuantity! - importedQuantity!;
  }

  int get remainImportRequestQuantity =>
      (requestQuantity ?? 0) - (importPlannedQuantity ?? 0);

  int get remainExportRequestQuantity =>
      (requestQuantity ?? 0) - (exportPlannedQuantity ?? 0);

  factory WarehouseRequestSupply.fromSupply(Supply supply) {
    return WarehouseRequestSupply(
      id: supply.id,
      name: supply.name,
      code: supply.code,
      nameOther: supply.nameOther,
      quantity: supply.quantity,
      availableStockQuantity: supply.availableStockQuantity,
      availableQuantity: supply.availableQuantity,
      providedQuantity: supply.providedQuantity,
      supplyType: supply.supplyType,
      estimateUsedTime: supply.estimateUsedTime,
      unit: supply.unit,
      maintenanceType: supply.maintenanceType,
      supplyGroup: supply.supplyGroup,
      stockQuantity: supply.stockQuantity,
      minStockQuantity: supply.minStockQuantity,
      price: supply.price,
      vendor: supply.vendor,
    );
  }

  @override
  WarehouseRequestSupply copyWith({
    String? color,
    String? size,
    int? grantedQuantity,
    int? returnQuantity,
    int? requestQuantity,
    int? importPlannedQuantity,
    int? importedQuantity,
    int? importQuantity,
    int? exportPlannedQuantity,
    int? exportQuantity,
    int? exportedQuantity,
    String? id,
    String? name,
    String? code,
    String? nameOther,
    int? quantity,
    SupplyType? supplyType,
    num? estimateUsedTime,
    Unit? unit,
    MaintainType? type,
    SupplyGroup? supplyGroup,
    int? providedQuantity,
    int? stockQuantity,
    int? availableStockQuantity,
    Vendor? vendor,
  }) {
    return WarehouseRequestSupply(
      color: color ?? this.color,
      size: size ?? this.size,
      grantedQuantity: grantedQuantity ?? this.grantedQuantity,
      returnQuantity: returnQuantity ?? this.returnQuantity,
      requestQuantity: requestQuantity ?? this.requestQuantity,
      importPlannedQuantity:
          importPlannedQuantity ?? this.importPlannedQuantity,
      importedQuantity: importedQuantity ?? this.importedQuantity,
      importQuantity: importQuantity ?? this.importQuantity,
      exportPlannedQuantity:
          exportPlannedQuantity ?? this.exportPlannedQuantity,
      exportQuantity: exportQuantity ?? this.exportQuantity,
      exportedQuantity: exportedQuantity ?? this.exportedQuantity,
      id: id ?? this.id,
      name: name ?? this.name,
      code: code ?? this.code,
      nameOther: nameOther ?? this.nameOther,
      quantity: quantity ?? this.quantity,
      supplyType: supplyType ?? this.supplyType,
      estimateUsedTime: estimateUsedTime ?? this.estimateUsedTime,
      unit: unit ?? this.unit,
      maintenanceType: type ?? maintenanceType,
      supplyGroup: supplyGroup ?? this.supplyGroup,
      providedQuantity: providedQuantity ?? this.providedQuantity,
      stockQuantity: stockQuantity ?? this.stockQuantity,
      availableStockQuantity:
          availableStockQuantity ?? this.availableStockQuantity,
      vendor: vendor ?? this.vendor,
    );
  }
}
