// ignore_for_file: public_member_api_docs, sort_constructors_first
import '../device_group.dart';

class WarehouseRequestDeviceGroup extends DeviceGroup {
  final int? quantity;
  final int? importedQuantity;

  WarehouseRequestDeviceGroup({
    this.quantity,
    this.importedQuantity,
    String? id,
    String? name,
    String? code,
  }) : super(
          id: id,
          name: name,
          code: code,
        );

  num? get remainQuantity => (quantity ?? 0) - (importedQuantity ?? 0);

  WarehouseRequestDeviceGroup copyWith({
    int? quantity,
    int? importedQuantity,
    String? id,
    String? name,
    String? code,
  }) {
    return WarehouseRequestDeviceGroup(
      quantity: quantity ?? this.quantity,
      importedQuantity: importedQuantity ?? this.importedQuantity,
      id: id ?? this.id,
      name: name ?? this.name,
      code: code ?? this.code,
    );
  }
}
