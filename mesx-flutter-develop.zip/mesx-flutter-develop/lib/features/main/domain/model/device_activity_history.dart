import '../enum/device_activity_enum.dart';
import 'create_by.dart';

class DeviceActivityHistory {
  final String id;
  final DateTime createdAt;
  final DateTime startTime;
  final DateTime updatedAt;
  final CreateBy createdBy;
  final DeviceActivityStatus? status;

  DeviceActivityHistory(
    this.id,
    this.createdAt,
    this.createdBy,
    this.startTime,
    this.updatedAt,
    this.status,
  );

  @override
  String toString() {
    return 'DeviceActivityHistory{id: $id, createdAt: $createdAt}';
  }
}
