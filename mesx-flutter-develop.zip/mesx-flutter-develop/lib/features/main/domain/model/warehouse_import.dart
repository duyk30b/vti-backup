import '../enum/warehouse_import_enum.dart';
import 'device_assignment.dart';
import 'factory_info.dart';
import 'supply_request.dart';
import 'warehouse.dart';
import 'warehouse_import_device.dart';
import 'warehouse_import_supply.dart';

class WarehouseImport {
  final String? id;
  final String? code;
  final String? name;
  final DateTime? importDate;
  final WarehouseImportStatus? status;
  final DateTime? date;
  final String? note;
  final String? deliver;
  final String? number;
  final String? soNum;
  final String? poNum;
  final String? remain;
  final WarehouseImportType? requestType;
  final FactoryInfo? fromFactory;
  final String? contractNum;
  final String? debit;
  final List<WarehouseImportDevice> devices;
  final List<WarehouseImportSupply> supplies;
  final String? symbol;
  final DeviceAssignment? deviceAssignmentRequest;
  final SupplyRequest? supplyRequest;
  final String? requestCode;

  final Warehouse? warehouse;
  final String? templateNum;

  WarehouseImport({
    this.requestCode,
    this.deviceAssignmentRequest,
    this.supplyRequest,
    this.id,
    this.name,
    this.code,
    this.importDate,
    this.status,
    this.date,
    this.note,
    this.deliver,
    this.number,
    this.soNum,
    this.poNum,
    this.remain,
    this.requestType,
    this.fromFactory,
    this.contractNum,
    this.debit,
    this.devices = const [],
    this.supplies = const [],
    this.symbol,
    this.warehouse,
    this.templateNum,
  });
}
