class RepairRequestHistory {
  final String? id;
  final String? content;
  final dynamic action;
  final int? status;
  final DateTime? createdAt;
  final String? reason;

  RepairRequestHistory(
      {this.id,
      this.content,
      this.action,
      this.status,
      this.createdAt,
      this.reason});

  @override
  String toString() {
    return 'RepairRequestHistory(id: $id, content: $content, action: $action, status: $status, createdAt: $createdAt)';
  }
}
