class ArticleDeviceGroup {
  final String? code;
  final String? name;
  final String? id;

  ArticleDeviceGroup({
    this.code,
    this.name,
    this.id,
  });
}
