import '../../enum/warehouse_ticket_enum.dart';
import '../factory_info.dart';
import '../warehouse.dart';
import '../warehouse_request/warehouse_export_request.dart';
import 'warehouse_ticket.dart';
import 'warehouse_ticket_device.dart';
import 'warehouse_ticket_supply.dart';

class WarehouseExportTicket extends WarehouseTicket {
  final DateTime? exportDate;
  final FactoryInfo? toFactory;
  final FactoryInfo? fromFactory;
  final WarehouseExportTicketRequestType? requestType;
  final WarehouseExportRequest? warehouseExportRequest;

  WarehouseExportTicket({
    this.fromFactory,
    this.toFactory,
    this.exportDate,
    this.warehouseExportRequest,
    this.requestType,
    String? id,
    String? name,
    String? code,
    DateTime? date,
    String? note,
    String? deliver,
    String? number,
    String? soNum,
    String? poNum,
    String? remain,
    String? contractNum,
    String? credit,
    String? debit,
    String? symbol,
    Warehouse? warehouse,
    String? templateNum,
    String? gdiNo,
    String? reason,
    WarehouseTicketTypeEnum? ticketType,
    WarehouseTicketStatus? status,
    List<WarehouseTicketDevice>? devices,
    List<WarehouseTicketSupply>? supplies,
  }) : super(
          id: id,
          name: name,
          code: code,
          date: date,
          note: note,
          deliver: deliver,
          number: number,
          soNum: soNum,
          poNum: poNum,
          remain: remain,
          contractNum: contractNum,
          debit: debit,
          symbol: symbol,
          warehouse: warehouse,
          templateNum: templateNum,
          ticketType: ticketType,
          devices: devices ?? [],
          supplies: supplies ?? [],
          status: status,
          gdiNo: gdiNo,
          reason: reason,
          credit: credit,
        );
}
