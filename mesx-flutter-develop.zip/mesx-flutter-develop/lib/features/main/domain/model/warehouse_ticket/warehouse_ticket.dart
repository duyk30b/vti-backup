import '../../enum/warehouse_ticket_enum.dart';
import '../warehouse.dart';
import '../warehouse_request/warehouse_request_device_group.dart';
import 'warehouse_ticket_device.dart';
import 'warehouse_ticket_supply.dart';

class WarehouseTicket {
  final String? id;
  final String? code;
  final String? name;
  final WarehouseTicketTypeEnum? ticketType;
  final DateTime? date;
  final String? note;
  final String? deliver;
  final String? number;
  final String? soNum;
  final String? poNum;
  final String? remain;
  final String? contractNum;
  final String? debit;
  final String? credit;
  final String? symbol;
  final String? reason;
  final String? gdiNo;
  final Warehouse? warehouse;
  final String? templateNum;
  final List<WarehouseTicketDevice> devices;
  final List<WarehouseRequestDeviceGroup> deviceGroups;
  final List<WarehouseTicketSupply> supplies;
  final WarehouseTicketStatus? status;

  WarehouseTicket({
    this.id,
    this.name,
    this.code,
    this.date,
    this.note,
    this.deliver,
    this.number,
    this.soNum,
    this.poNum,
    this.remain,
    this.contractNum,
    this.debit,
    this.symbol,
    this.warehouse,
    this.templateNum,
    this.ticketType,
    this.devices = const [],
    this.supplies = const [],
    this.deviceGroups = const [],
    this.reason,
    this.gdiNo,
    this.status,
    this.credit,
  });
}
