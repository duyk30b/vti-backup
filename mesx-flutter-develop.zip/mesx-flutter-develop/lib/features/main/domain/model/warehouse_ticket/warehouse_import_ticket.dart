import '../../enum/warehouse_ticket_enum.dart';
import '../factory_info.dart';
import '../warehouse.dart';
import '../warehouse_request/warehouse_import_request.dart';
import 'warehouse_ticket.dart';
import 'warehouse_ticket_device.dart';
import 'warehouse_ticket_supply.dart';

class WarehouseImportTicket extends WarehouseTicket {
  final FactoryInfo? fromFactory;
  final FactoryInfo? toFactory;
  final DateTime? importDate;
  final WarehouseImportTicketRequestType? requestType;
  final WarehouseImportRequest? warehouseImportRequest;

  WarehouseImportTicket({
    this.toFactory,
    this.importDate,
    this.fromFactory,
    this.requestType,
    this.warehouseImportRequest,
    String? id,
    String? name,
    String? code,
    DateTime? date,
    String? note,
    String? deliver,
    String? number,
    String? soNum,
    String? poNum,
    String? remain,
    String? contractNum,
    String? debit,
    String? symbol,
    Warehouse? warehouse,
    String? templateNum,
    String? gdiNo,
    String? reason,
    WarehouseTicketTypeEnum? ticketType,
    WarehouseTicketStatus? status,
    List<WarehouseTicketDevice>? devices,
    List<WarehouseTicketSupply>? supplies,
  }) : super(
            id: id,
            name: name,
            code: code,
            date: date,
            note: note,
            deliver: deliver,
            number: number,
            soNum: soNum,
            poNum: poNum,
            remain: remain,
            contractNum: contractNum,
            debit: debit,
            symbol: symbol,
            warehouse: warehouse,
            templateNum: templateNum,
            ticketType: ticketType,
            status: status,
            devices: devices ?? [],
            supplies: supplies ?? [],
            gdiNo: gdiNo,
            reason: reason);
}
