import '../../enum/device_enum.dart';
import '../area_info.dart';
import '../article_device_group.dart';
import '../device_detail.dart';
import '../device_group.dart';
import '../factory_info.dart';
import '../maintenance_index.dart';
import '../supply.dart';
import '../unit.dart';
import '../vendor.dart';
import '../warehouse.dart';

class WarehouseTicketDevice extends DeviceDetail {
  String? color;
  String? size;
  num? price;

  WarehouseTicketDevice({
    this.color,
    this.size,
    this.price,
    String? id,
    String? code,
    String? name,
    DeviceUsageStatus? status,
    num? warrantyPeriod,
    String? serial,
    String? model,
    String? manufacturer,
    DateTime? manufactureDate,
    DeviceGroup? deviceGroup,
    Vendor? vendor,
    MaintenanceIndex? maintenanceIndex,
    DateTime? createdAt,
    DateTime? creationDate,
    DateTime? capitalizationDate,
    String? imageUrl,
    FactoryInfo? factory,
    AreaInfo? area,
    String? description,
    String? identificationNo,
    ArticleDeviceGroup? articleDeviceGroup,
    List<Supply>? supplies,
    Unit? unit,
    Warehouse? warehouse,
  }) : super(
          id: id,
          code: code,
          name: name,
          status: status,
          warrantyPeriod: warrantyPeriod,
          serial: serial,
          model: model,
          manufacturer: manufacturer,
          manufactureDate: manufactureDate,
          deviceGroup: deviceGroup,
          vendor: vendor,
          maintenanceIndex: maintenanceIndex,
          createdAt: createdAt,
          creationDate: creationDate,
          capitalizationDate: capitalizationDate,
          imageUrl: imageUrl,
          factory: factory,
          area: area,
          description: description,
          identificationNo: identificationNo,
          articleDeviceGroup: articleDeviceGroup,
          supplies: supplies,
          unit: unit,
          warehouse: warehouse,
        );

  @override
  WarehouseTicketDevice copyWith({
    String? color,
    String? size,
    num? price,
    String? id,
    String? code,
    String? name,
    DeviceUsageStatus? status,
    num? warrantyPeriod,
    String? serial,
    String? model,
    String? manufacturer,
    DateTime? manufactureDate,
    DeviceGroup? deviceGroup,
    Vendor? vendor,
    MaintenanceIndex? maintenanceIndex,
    DateTime? createdAt,
    DateTime? creationDate,
    DateTime? capitalizationDate,
    String? imageUrl,
    FactoryInfo? factory,
    AreaInfo? area,
    String? description,
    String? identificationNo,
    ArticleDeviceGroup? articleDeviceGroup,
    List<Supply>? supplies,
    Unit? unit,
    Warehouse? warehouse,
    int? exportPlanned,
    int? exported,
    int? importPlanned,
    int? returnPlanned,
  }) {
    return WarehouseTicketDevice(
      color: color ?? this.color,
      size: size ?? this.size,
      price: price ?? this.price,
      id: id ?? this.id,
      code: code ?? this.code,
      name: name ?? this.name,
      status: status ?? this.status,
      warrantyPeriod: warrantyPeriod ?? this.warrantyPeriod,
      serial: serial ?? this.serial,
      model: model ?? this.model,
      manufacturer: manufacturer ?? this.manufacturer,
      manufactureDate: manufactureDate ?? this.manufactureDate,
      deviceGroup: deviceGroup ?? this.deviceGroup,
      vendor: vendor ?? this.vendor,
      maintenanceIndex: maintenanceIndex ?? this.maintenanceIndex,
      createdAt: createdAt ?? this.createdAt,
      creationDate: creationDate ?? this.creationDate,
      capitalizationDate: capitalizationDate ?? this.capitalizationDate,
      imageUrl: imageUrl ?? this.imageUrl,
      factory: factory ?? this.factory,
      area: area ?? this.area,
      description: description ?? this.description,
      identificationNo: identificationNo ?? this.identificationNo,
      articleDeviceGroup: articleDeviceGroup ?? this.articleDeviceGroup,
      supplies: supplies ?? this.supplies,
      unit: unit ?? this.unit,
      warehouse: warehouse ?? this.warehouse,
    );
  }

  WarehouseTicketDevice fromDevice({
    String? color,
    String? size,
    num? price,
    DeviceDetail? device,
  }) {
    return WarehouseTicketDevice(
      color: color ?? this.color,
      size: size ?? this.size,
      price: price ?? this.price,
      id: device?.id,
      code: device?.code,
      name: device?.name,
      status: device?.status,
      warrantyPeriod: device?.warrantyPeriod,
      serial: device?.serial,
      model: device?.model,
      manufacturer: device?.manufacturer,
      manufactureDate: device?.manufactureDate,
      deviceGroup: device?.deviceGroup,
      vendor: device?.vendor,
      maintenanceIndex: device?.maintenanceIndex,
      createdAt: device?.createdAt,
      creationDate: device?.creationDate,
      capitalizationDate: device?.capitalizationDate,
      imageUrl: device?.imageUrl,
      factory: device?.factory,
      area: device?.area,
      description: device?.description,
      identificationNo: device?.identificationNo,
      articleDeviceGroup: device?.articleDeviceGroup,
      supplies: device?.supplies,
      unit: device?.unit,
      warehouse: device?.warehouse,
    );
  }
}
