import '../../enum/maintain_enum.dart';
import '../supply.dart';
import '../supply_group.dart';
import '../supply_type.dart';
import '../unit.dart';
import '../vendor.dart';

class WarehouseTicketSupply extends Supply {
  final String? color;
  final String? size;
  final int? importQuantity;
  final int? importedQuantity;
  final int? requestQuantity;
  final int? exportQuantity;
  final int? exportedQuantity;

  WarehouseTicketSupply(
      {this.color,
      this.size,
      this.importQuantity,
      this.importedQuantity,
      this.requestQuantity,
      this.exportQuantity,
      this.exportedQuantity,
      num? price,
      String? id,
      String? name,
      String? code,
      String? nameOther,
      int? quantity,
      int? availableStockQuantity,
      int? availableQuantity,
      int? providedQuantity,
      SupplyType? supplyType,
      num? estimateUsedTime,
      Unit? unit,
      MaintainType? maintenanceType,
      SupplyGroup? supplyGroup,
      num? stockQuantity,
      num? minStockQuantity,
      Vendor? vendor})
      : super(
          id: id,
          name: name,
          code: code,
          nameOther: nameOther,
          quantity: quantity,
          availableStockQuantity: availableStockQuantity,
          availableQuantity: availableQuantity,
          providedQuantity: providedQuantity,
          supplyType: supplyType,
          estimateUsedTime: estimateUsedTime,
          unit: unit,
          maintenanceType: maintenanceType,
          supplyGroup: supplyGroup,
          stockQuantity: stockQuantity,
          minStockQuantity: minStockQuantity,
          vendor: vendor,
          price: price,
        );

  factory WarehouseTicketSupply.fromSupply(Supply supply) {
    return WarehouseTicketSupply(
      id: supply.id,
      name: supply.name,
      code: supply.code,
      nameOther: supply.nameOther,
      quantity: supply.quantity,
      availableStockQuantity: supply.availableStockQuantity,
      availableQuantity: supply.availableQuantity,
      providedQuantity: supply.providedQuantity,
      supplyType: supply.supplyType,
      estimateUsedTime: supply.estimateUsedTime,
      unit: supply.unit,
      maintenanceType: supply.maintenanceType,
      supplyGroup: supply.supplyGroup,
      stockQuantity: supply.stockQuantity,
      minStockQuantity: supply.minStockQuantity,
      vendor: supply.vendor,
    );
  }

  @override
  WarehouseTicketSupply copyWith({
    String? color,
    String? size,
    num? price,
    int? availableQuantity,
    int? importQuantity,
    int? importedQuantity,
    String? id,
    String? name,
    String? code,
    String? nameOther,
    int? quantity,
    SupplyType? supplyType,
    num? estimateUsedTime,
    Unit? unit,
    MaintainType? type,
    SupplyGroup? supplyGroup,
    int? providedQuantity,
    int? stockQuantity,
    int? requestQuantity,
    int? availableStockQuantity,
    Vendor? vendor,
    int? exportQuantity,
    int? exportedQuantity,
  }) {
    return WarehouseTicketSupply(
      color: color ?? this.color,
      size: size ?? this.size,
      price: price ?? this.price,
      id: id ?? this.id,
      name: name ?? this.name,
      code: code ?? this.code,
      nameOther: nameOther ?? this.nameOther,
      vendor: vendor,
      quantity: quantity ?? this.quantity,
      availableStockQuantity:
          availableStockQuantity ?? this.availableStockQuantity,
      availableQuantity: availableQuantity ?? availableQuantity,
      providedQuantity: providedQuantity ?? this.providedQuantity,
      supplyType: supplyType ?? this.supplyType,
      estimateUsedTime: estimateUsedTime ?? this.estimateUsedTime,
      unit: unit ?? this.unit,
      maintenanceType: type ?? maintenanceType,
      supplyGroup: supplyGroup ?? this.supplyGroup,
      stockQuantity: stockQuantity ?? this.stockQuantity,
      minStockQuantity: minStockQuantity ?? minStockQuantity,
      importQuantity: importQuantity ?? this.importQuantity,
      importedQuantity: importedQuantity ?? this.importedQuantity,
      requestQuantity: requestQuantity ?? this.requestQuantity,
      exportQuantity: exportQuantity ?? this.exportQuantity,
      exportedQuantity: exportedQuantity ?? this.exportedQuantity,
    );
  }

  int get remainImportQuantity =>
      (requestQuantity ?? 0) - (importedQuantity ?? 0);

  int get remainExportQuantity =>
      (requestQuantity ?? 0) - (exportedQuantity ?? 0);

  num get intoMoney => (price ?? 0) * (importQuantity ?? 0);
}
