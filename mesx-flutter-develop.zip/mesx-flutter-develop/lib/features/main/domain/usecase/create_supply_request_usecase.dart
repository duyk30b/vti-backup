import '../../data/network/base_response/base_response.dart';

import '../repository/supply_request_repository.dart';
import '../request/supply_request_form_payload.dart';
import 'usecase.dart';

class CreateSupplyRequestUseCase
    extends UseCase<SupplyRequestFormPayload, BaseResponseNoData> {
  final SupplyRequestRepository requestRepository;

  CreateSupplyRequestUseCase(this.requestRepository);

  @override
  Future<BaseResponseNoData> execute(SupplyRequestFormPayload params) async {
    return requestRepository.createSupplyRequest(params);
  }
}
