import '../repository/job_repository.dart';
import 'usecase.dart';

class AddReasonJobUseCase extends UseCase<ReasonRequest, dynamic> {
  final JobRepository jobRepository;

  AddReasonJobUseCase(this.jobRepository);

  @override
  Future execute(ReasonRequest params) async {
    final response = await jobRepository.addReason(params.id, params.reason);
    return response;
  }
}

class ReasonRequest {
  final String id;
  final String reason;

  ReasonRequest(this.id, this.reason);
}
