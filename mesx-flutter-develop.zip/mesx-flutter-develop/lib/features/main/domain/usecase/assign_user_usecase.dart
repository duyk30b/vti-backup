import '../repository/job_repository.dart';
import '../request/assign_request.dart';
import 'usecase.dart';

class AssignUserUsecase extends UseCase<AssignParam, dynamic> {
  final JobRepository _jobRepository;

  AssignUserUsecase(this._jobRepository);

  @override
  Future execute(AssignParam params) {
    return _jobRepository.assignUser(params.id, params.request);
  }
}

class AssignParam {
  final String id;
  final AssignRequest request;

  AssignParam(this.id, this.request);
}
