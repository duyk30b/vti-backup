import '../../data/network/base_response/base_response.dart';

import '../repository/supply_request_repository.dart';
import 'usecase.dart';

class ConfirmSupplyRequestUsecase extends UseCase<String, dynamic> {
  final SupplyRequestRepository repository;

  ConfirmSupplyRequestUsecase(this.repository);

  @override
  Future<BaseResponseNoData> execute(String params) async {
    return repository.confirmSupplyRequest(params);
  }
}
