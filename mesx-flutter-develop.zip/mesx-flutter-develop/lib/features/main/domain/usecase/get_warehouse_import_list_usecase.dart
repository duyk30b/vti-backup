import '../model/paging_model.dart';
import '../model/warehouse_import.dart';
import '../repository/warehouse_repository.dart';
import '../request/base_query.dart';
import 'usecase.dart';

class GetWarehouseImportListUseCase
    extends UseCase<BaseQuery, PagingModel<WarehouseImport>> {
  final WarehouseRepository repository;

  GetWarehouseImportListUseCase(this.repository);

  @override
  Future<PagingModel<WarehouseImport>> execute(BaseQuery params) async {
    return repository.getWarehouseImportList(params);
  }
}
