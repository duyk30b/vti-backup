import '../../data/network/base_response/base_response.dart';
import '../repository/warehouse_repository.dart';
import '../request/warehouse_export_request_form_payload.dart';
import 'usecase.dart';

class UpdateWarehouseExportRequestUseCase
    extends UseCase<WarehouseExportRequestFormPayload, BaseResponseNoData> {
  final WarehouseRepository repository;

  UpdateWarehouseExportRequestUseCase(this.repository);

  @override
  Future<BaseResponseNoData> execute(
      WarehouseExportRequestFormPayload params) async {
    return repository.updateWarehouseExportRequest(params);
  }
}
