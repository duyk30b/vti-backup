import '../model/device_detail.dart';
import '../repository/device_list_repository.dart';

import 'usecase.dart';

class ScanDeviceUseCase extends UseCase<String, DeviceDetail> {
  final DeviceListRepository deviceRepository;

  ScanDeviceUseCase(this.deviceRepository);

  @override
  Future<DeviceDetail> execute(String params) {
    return deviceRepository.scanDevice(params);
  }
}
