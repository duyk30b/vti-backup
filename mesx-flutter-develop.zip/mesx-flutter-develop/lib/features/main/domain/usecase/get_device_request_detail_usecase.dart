import '../model/device_request.dart';
import '../repository/device_request_repository.dart';
import 'usecase.dart';

class GetDeviceRequestDetailUseCase extends UseCase<String, DeviceRequest> {
  final DeviceRequestRepository repo;

  GetDeviceRequestDetailUseCase(this.repo);

  @override
  Future<DeviceRequest> execute(String params) {
    return repo.getDeviceRequestDetail(params);
  }
}
