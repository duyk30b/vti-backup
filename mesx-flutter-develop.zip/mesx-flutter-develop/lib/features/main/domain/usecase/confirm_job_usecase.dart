import '../repository/job_repository.dart';
import 'usecase.dart';

class ConfirmJobUseCase extends UseCase<ConfirmRequest, dynamic> {
  final JobRepository jobRepository;

  ConfirmJobUseCase(this.jobRepository);

  @override
  Future execute(ConfirmRequest params) async {
    final response = await jobRepository.confirmJob(params.id, params.action,
        executionTime: params.executionTime,
        stopTime: params.stopTime,
        reason: params.reason);
    return response;
  }
}

class ConfirmRequest {
  final String id;
  final String action;
  final String? reason;
  final int? executionTime;
  final int? stopTime;

  ConfirmRequest(this.id, this.action,
      {this.reason, this.stopTime, this.executionTime});
}
