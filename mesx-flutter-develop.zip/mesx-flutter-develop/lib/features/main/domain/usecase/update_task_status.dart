import '../repository/job_repository.dart';
import 'usecase.dart';

class UpdateStatusUseCase extends UseCase<UpdateStatusRequest, dynamic> {
  final JobRepository jobRepository;

  UpdateStatusUseCase(this.jobRepository);

  @override
  Future execute(UpdateStatusRequest params) async {
    final response =
        await jobRepository.updateTaskStatus(params.id, params.status);
    return response;
  }
}

class UpdateStatusRequest {
  final String id;
  final int status;

  UpdateStatusRequest(this.id, this.status);
}
