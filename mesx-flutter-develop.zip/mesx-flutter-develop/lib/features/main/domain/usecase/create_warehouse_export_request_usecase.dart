import '../../data/network/base_response/base_response.dart';
import '../repository/warehouse_repository.dart';
import '../request/warehouse_export_request_form_payload.dart';
import 'usecase.dart';

class CreateWarehouseExportRequestUseCase
    extends UseCase<WarehouseExportRequestFormPayload, BaseResponseNoData> {
  final WarehouseRepository repository;

  CreateWarehouseExportRequestUseCase(this.repository);

  @override
  Future<BaseResponseNoData> execute(
      WarehouseExportRequestFormPayload params) async {
    return repository.createWarehouseExportRequest(params);
  }
}
