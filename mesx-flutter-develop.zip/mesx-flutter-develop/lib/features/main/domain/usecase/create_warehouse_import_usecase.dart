import '../../data/network/base_response/base_response.dart';
import '../repository/warehouse_repository.dart';

import '../request/warehouse_import_request.dart';
import 'usecase.dart';

class CreateWarehouseImportUseCase
    extends UseCase<WarehouseImportFormRequest, BaseResponseNoData> {
  final WarehouseRepository repo;

  CreateWarehouseImportUseCase(this.repo);

  @override
  Future<BaseResponseNoData> execute(WarehouseImportFormRequest params) {
    return repo.createWarehouseImport(params);
  }
}
