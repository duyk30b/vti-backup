import '../../data/network/base_response/base_response.dart';
import '../repository/warehouse_repository.dart';

import '../request/warehouse_export_form_request.dart';
import 'usecase.dart';

class UpdateWarehouseExportUseCase
    extends UseCase<WarehouseExportFormRequest, BaseResponseNoData> {
  final WarehouseRepository repo;

  UpdateWarehouseExportUseCase(this.repo);

  @override
  Future<BaseResponseNoData> execute(WarehouseExportFormRequest params) {
    return repo.updateWarehouseExport(params, params.id ?? '');
  }
}
