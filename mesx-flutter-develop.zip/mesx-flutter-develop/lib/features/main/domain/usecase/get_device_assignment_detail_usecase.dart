import '../model/device_assignment.dart';
import '../repository/device_assignment_repository.dart';
import 'usecase.dart';

class GetDeviceAssignmentDetailUseCase
    extends UseCase<String, DeviceAssignment> {
  final DeviceAssignmentRepository repository;

  GetDeviceAssignmentDetailUseCase(this.repository);

  @override
  Future<DeviceAssignment> execute(String params) {
    return repository.getDeviceAssignMentDetail(params);
  }
}
