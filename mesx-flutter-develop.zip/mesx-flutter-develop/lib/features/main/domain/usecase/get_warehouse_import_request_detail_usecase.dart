import '../model/warehouse_request/warehouse_import_request.dart';
import '../repository/warehouse_repository.dart';
import 'usecase.dart';

class GetWarehouseImportRequestDetailUseCase
    extends UseCase<String, WarehouseImportRequest> {
  final WarehouseRepository repository;

  GetWarehouseImportRequestDetailUseCase(this.repository);

  @override
  Future<WarehouseImportRequest> execute(String params) async {
    return repository.getWarehouseImportRequestDetail(params);
  }
}
