import '../repository/authentication_repository.dart';

class SaveTokenUseCase {
  final AuthenticationRepository authRepository;

  SaveTokenUseCase(this.authRepository);

  void saveTokenToLocal(String? token, String? refreshToken) {
    authRepository.saveTokenToCache(token, refreshToken);
  }
}
