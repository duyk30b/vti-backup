import '../../data/network/base_response/base_response.dart';

import '../repository/supply_request_repository.dart';
import 'usecase.dart';

class DeleteSupplyRequestUsecase extends UseCase<String, dynamic> {
  final SupplyRequestRepository repo;

  DeleteSupplyRequestUsecase(this.repo);

  @override
  Future<BaseResponseNoData> execute(String params) async {
    return repo.deleteSupplyRequest(params);
  }
}
