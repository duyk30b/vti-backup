import '../model/device_group.dart';
import '../repository/device_group_repository.dart';
import '../request/base_query.dart';
import 'usecase.dart';

class GetListDeviceGroupUseCase extends UseCase<BaseQuery, List<DeviceGroup>> {
  final DeviceGroupRepo repository;

  GetListDeviceGroupUseCase(this.repository);

  @override
  Future<List<DeviceGroup>> execute(BaseQuery params) async {
    return repository.getDeviceGroupList(params);
  }
}
