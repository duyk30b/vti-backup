import '../model/supply.dart';
import '../repository/supply_repository.dart';
import '../request/base_query.dart';
import 'usecase.dart';

class GetSupplyListUsecase extends UseCase<BaseQuery, List<Supply>> {
  final SupplyRepository supplyRepository;

  GetSupplyListUsecase(this.supplyRepository);

  @override
  Future<List<Supply>> execute(BaseQuery params) async {
    return supplyRepository.getListSupply(params);
  }
}
