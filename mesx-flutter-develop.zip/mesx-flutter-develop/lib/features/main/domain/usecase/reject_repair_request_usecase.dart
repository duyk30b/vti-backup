import '../../data/network/base_response/base_response.dart';
import '../repository/repair_request_repository.dart';

import 'usecase.dart';

class RejectRepairRequestUseCase extends UseCase<String, BaseResponseNoData> {
  final RepairRequestRepository repairRequestRepository;

  RejectRepairRequestUseCase(this.repairRequestRepository);

  @override
  Future<BaseResponseNoData> execute(String params) async {
    return repairRequestRepository.rejectRepairRequest(params);
  }
}
