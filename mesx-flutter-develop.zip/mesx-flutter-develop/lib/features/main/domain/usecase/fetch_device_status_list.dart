import '../model/device_status_list.dart';
import '../repository/device_status_repository.dart';
import '../request/base_query.dart';

import 'usecase.dart';

class FetchDeviceStatusUsecase extends UseCase<BaseQuery, DeviceStatusList> {
  final DeviceStatusRepository deviceStatusRepository;

  FetchDeviceStatusUsecase(this.deviceStatusRepository);

  @override
  Future<DeviceStatusList> execute(BaseQuery params) {
    return deviceStatusRepository.fetchDeviceStatusList(params);
  }
}
