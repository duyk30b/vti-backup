import '../model/warehouse_import.dart';
import '../repository/warehouse_repository.dart';
import 'usecase.dart';

class GetWarehouseImportDetailUseCase extends UseCase<String, WarehouseImport> {
  final WarehouseRepository repository;

  GetWarehouseImportDetailUseCase(this.repository);

  @override
  Future<WarehouseImport> execute(String params) async {
    return repository.getWarehouseImportDetail(params);
  }
}
