import '../model/paging_model.dart';
import '../model/repair_request.dart';
import '../repository/repair_request_repository.dart';
import '../request/base_query.dart';
import 'usecase.dart';

class GetListRepairRequestUseCase
    extends UseCase<BaseQuery, PagingModel<RepairRequest>> {
  final RepairRequestRepository repository;

  GetListRepairRequestUseCase(this.repository);

  @override
  Future<PagingModel<RepairRequest>> execute(BaseQuery params) async {
    return repository.getRepairRequestList(params);
  }
}
