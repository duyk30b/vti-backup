import '../model/paging_model.dart';
import '../model/warehouse_ticket/warehouse_import_ticket.dart';
import '../repository/warehouse_repository.dart';
import '../request/base_query.dart';
import 'usecase.dart';

class GetWarehouseImportTicketListUseCase
    extends UseCase<BaseQuery, PagingModel<WarehouseImportTicket>> {
  final WarehouseRepository repository;

  GetWarehouseImportTicketListUseCase(this.repository);

  @override
  Future<PagingModel<WarehouseImportTicket>> execute(BaseQuery params) async {
    return repository.getListWarehouseImportTicket(params);
  }
}
