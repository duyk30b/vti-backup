import 'dart:math';
import 'dart:ui';

import 'usecase.dart';

class DemoUseCase extends UseCase<int, List<Color>> {
  @override
  Future<List<Color>> execute(int params) async {
    await Future.delayed(const Duration(seconds: 2));
    if (params <= 0) {
      return Future.value(
        List.generate(
          20,
          (index) => Color.fromRGBO(
            Random().nextInt(255),
            Random().nextInt(255),
            Random().nextInt(255),
            1,
          ),
        ),
      );
    }
    if (params == 1) {
      return Future.error('Something went wrong!!!!');
    }
    return Future.value([]);
  }
}
