import '../model/device_assignment.dart';
import '../repository/device_assignment_repository.dart';
import '../request/base_query.dart';
import 'usecase.dart';

class GetDeviceAssignmentUseCase
    extends UseCase<BaseQuery, List<DeviceAssignment>> {
  final DeviceAssignmentRepository repository;

  GetDeviceAssignmentUseCase(this.repository);

  @override
  Future<List<DeviceAssignment>> execute(BaseQuery params) {
    return repository.getDeviceAssignMentList(params);
  }
}
