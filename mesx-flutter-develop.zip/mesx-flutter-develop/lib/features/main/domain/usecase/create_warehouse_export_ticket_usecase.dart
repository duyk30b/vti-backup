import '../../data/network/base_response/base_response.dart';
import '../repository/warehouse_repository.dart';
import '../request/warehouse_export_ticket_form_payload.dart';
import 'usecase.dart';

class CreateWarehouseExportTicketUseCase
    extends UseCase<WarehouseExportTicketFormPayload, BaseResponseNoData> {
  final WarehouseRepository repository;

  CreateWarehouseExportTicketUseCase(this.repository);

  @override
  Future<BaseResponseNoData> execute(
      WarehouseExportTicketFormPayload params) async {
    return repository.createWarehouseExportTicket(params);
  }
}
