import '../../data/network/base_response/base_response.dart';

import '../repository/warehouse_repository.dart';
import 'usecase.dart';

class RejectWarehouseExportUsecase extends UseCase<String, BaseResponseNoData> {
  final WarehouseRepository repository;

  RejectWarehouseExportUsecase(this.repository);

  @override
  Future<BaseResponseNoData> execute(String params) async {
    return repository.rejectWarehouseExport(params);
  }
}
