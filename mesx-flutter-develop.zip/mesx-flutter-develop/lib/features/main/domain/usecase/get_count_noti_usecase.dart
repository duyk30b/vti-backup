import '../repository/notification_repository.dart';
import 'usecase.dart';

class GetCountNotifyUseCase extends NoParamsUseCase<int> {
  final NotificationRepository _repository;

  GetCountNotifyUseCase(this._repository);

  @override
  Future<int> execute() async {
    final response = await _repository.getListNotification(1, 1, 'APP');
    return response.meta.totalUnRead ?? 0;
  }
}
