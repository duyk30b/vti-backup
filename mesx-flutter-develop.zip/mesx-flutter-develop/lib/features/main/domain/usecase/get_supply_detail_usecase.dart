import '../model/supply.dart';
import '../repository/supply_repository.dart';
import 'usecase.dart';

class GetSupplyDetailUsecase extends UseCase<String, Supply> {
  final SupplyRepository supplyRepository;

  GetSupplyDetailUsecase(this.supplyRepository);

  @override
  Future<Supply> execute(String params) async {
    return supplyRepository.getSupplyDetail(params);
  }
}
