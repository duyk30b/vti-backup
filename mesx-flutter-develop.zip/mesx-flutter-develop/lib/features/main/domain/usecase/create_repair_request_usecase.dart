import '../../data/network/base_response/base_response.dart';
import '../repository/repair_request_repository.dart';

import '../request/create_repair_request.dart';
import 'usecase.dart';

class CreateRepairRequestUseCase
    extends UseCase<CreateRepairRequest, BaseResponseNoData> {
  final RepairRequestRepository repairRequestRepository;

  CreateRepairRequestUseCase(this.repairRequestRepository);

  @override
  Future<BaseResponseNoData> execute(CreateRepairRequest params) async {
    return repairRequestRepository.createRepairRequest(params);
  }
}
