import '../../data/network/response/login_response.dart';
import '../repository/authentication_repository.dart';
import '../request/login_request.dart';
import 'usecase.dart';

class LoginUseCase extends UseCase<LoginRequest, LoginResponse> {
  final AuthenticationRepository authRepository;

  LoginUseCase(this.authRepository);

  @override
  Future<LoginResponse> execute(LoginRequest params) {
    return authRepository.login(params);
  }
}
