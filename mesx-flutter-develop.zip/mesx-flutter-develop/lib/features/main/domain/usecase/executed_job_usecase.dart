import 'dart:convert';
import 'dart:io';

import '../model/detail.dart';
import '../model/supply.dart';
import '../repository/job_repository.dart';
import 'usecase.dart';

class ExecutedJobUseCase extends UseCase<JobExecutedRequest, dynamic> {
  final JobRepository jobRepository;

  ExecutedJobUseCase(this.jobRepository);

  @override
  Future execute(JobExecutedRequest params) async {
    final response = await jobRepository.executedJob(
        params.id, jsonEncode(params.toJsonRequest()),
        file: params.file);
    return response;
  }
}

class JobExecutedRequest {
  final String id;
  final DateTime executionDateFrom;
  final DateTime executionDateTo;
  final List<Detail>? details;
  final List<Supply>? supplies;
  final int? result;
  final File? file;
  final Information? information;

  JobExecutedRequest(
      {required this.executionDateFrom,
      required this.executionDateTo,
      required this.id,
      this.result,
      this.details,
      this.supplies,
      this.file,
      this.information});

  Map<String, dynamic> toJsonRequest() => {
        'executionDateFrom': executionDateFrom.toString(),
        'executionDateTo': executionDateTo.toString(),
        'result': result,
        'installationTemplateDetails':
            details?.map((e) => e.toJsonRequest()).toList(),
        'checklistDetails': details?.map((e) => e.toJsonRequest()).toList(),
        'supplies': supplies?.map((e) => e.toJsonRequest()).toList(),
        'accreditationTemplateDetails':
            details?.map((e) => e.toJsonRequest()).toList(),
        'information': information != null ? information!.toJson() : null
      };
}

class Information {
  int? maintenanceType;
  String? description;

  Information({this.maintenanceType, this.description});

  Information.fromJson(Map<String, dynamic> json) {
    maintenanceType = json['maintenanceType'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['maintenanceType'] = maintenanceType;
    data['description'] = description;
    return data;
  }
}
