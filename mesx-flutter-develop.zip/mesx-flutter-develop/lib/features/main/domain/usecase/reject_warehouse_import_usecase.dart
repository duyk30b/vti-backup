import '../../data/network/base_response/base_response.dart';

import '../repository/warehouse_repository.dart';
import 'usecase.dart';

class RejectWarehouseImportUsecase extends UseCase<String, BaseResponseNoData> {
  final WarehouseRepository repository;

  RejectWarehouseImportUsecase(this.repository);

  @override
  Future<BaseResponseNoData> execute(String params) async {
    return repository.rejectWarehouseImport(params);
  }
}
