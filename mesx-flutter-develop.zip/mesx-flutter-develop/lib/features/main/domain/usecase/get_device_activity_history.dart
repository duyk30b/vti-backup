import '../model/device_activity_history.dart';
import '../repository/device_activity_history_repository.dart';
import '../request/device_activity_request.dart';
import 'usecase.dart';

class DeviceActivityHistoryUsecase
    extends UseCase<DeviceActivityHistoryRequest, List<DeviceActivityHistory>> {
  final DeviceActivityHistoryRepo deviceActivityHistoryRepo;

  DeviceActivityHistoryUsecase(this.deviceActivityHistoryRepo);

  @override
  Future<List<DeviceActivityHistory>> execute(
      DeviceActivityHistoryRequest params) {
    return deviceActivityHistoryRepo.getDeviceActivityHistory(params);
  }
}
