import '../model/supply.dart';
import '../repository/supply_repository.dart';
import '../request/get_stock_supply_by_warehouse.dart';
import 'usecase.dart';

class GetStockSupplyByWarehouseUsecase
    extends UseCase<GetStockSupplyByWarehouseRequest, Supply> {
  final SupplyRepository repository;

  GetStockSupplyByWarehouseUsecase(this.repository);

  @override
  Future<Supply> execute(GetStockSupplyByWarehouseRequest params) async {
    return repository.getStockSupplyByWarehouse(params);
  }
}
