import '../repository/authentication_repository.dart';
import 'usecase.dart';

class CheckLoginUseCase extends BaseUseCase {
  final AuthenticationRepository authRepository;

  CheckLoginUseCase(this.authRepository);

  bool isLogin() {
    return authRepository.isLogin();
  }
}
