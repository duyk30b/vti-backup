import '../model/warehouse_export.dart';
import '../repository/warehouse_repository.dart';
import 'usecase.dart';

class GetWarehouseExportDetailUseCase extends UseCase<String, WarehouseExport> {
  final WarehouseRepository repository;

  GetWarehouseExportDetailUseCase(this.repository);

  @override
  Future<WarehouseExport> execute(String params) async {
    return repository.getWarehouseExportDetail(params);
  }
}
