import '../model/device_request.dart';
import '../model/paging_model.dart';
import '../repository/device_request_repository.dart';
import '../request/base_query.dart';
import 'usecase.dart';

class GetDeviceRequestListUseCase
    extends UseCase<BaseQuery, PagingModel<DeviceRequest>> {
  final DeviceRequestRepository repo;

  GetDeviceRequestListUseCase(this.repo);

  @override
  Future<PagingModel<DeviceRequest>> execute(BaseQuery params) {
    return repo.getDeviceRequestList(params);
  }
}
