import '../model/device_detail.dart';
import '../model/paging_model.dart';
import '../repository/warehouse_repository.dart';
import '../request/device_inventory_detail_request.dart';
import 'usecase.dart';

class GetDeviceInventoryDetailUsecase
    extends UseCase<DeviceInventoryDetailRequest, PagingModel<DeviceDetail>> {
  final WarehouseRepository repo;

  GetDeviceInventoryDetailUsecase(this.repo);

  @override
  Future<PagingModel<DeviceDetail>> execute(
      DeviceInventoryDetailRequest params) async {
    var response = await repo.getDeviceInventoryDetail(params);
    return response;
  }
}
