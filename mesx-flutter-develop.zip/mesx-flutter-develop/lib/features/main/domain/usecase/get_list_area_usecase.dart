import '../model/area_info.dart';
import '../repository/area_list_repository.dart';
import '../request/area_list_request.dart';
import 'usecase.dart';

class GetListAreaUsecase extends UseCase<AreaListRequest, List<AreaInfo>> {
  final AreaListRepository repository;

  GetListAreaUsecase(this.repository);

  @override
  Future<List<AreaInfo>> execute(AreaListRequest params) async {
    return repository.getListArea(params);
  }
}
