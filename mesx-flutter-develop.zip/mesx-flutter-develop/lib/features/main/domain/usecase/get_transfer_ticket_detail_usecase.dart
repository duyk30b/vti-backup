import '../model/transfer_ticket/transfer_ticket.dart';
import '../repository/transfer_ticket_repository.dart';
import 'usecase.dart';

class GetTransferTicketDetailUsecase extends UseCase<String, TransferTicket> {
  final TransferTicketRepository repository;

  GetTransferTicketDetailUsecase(this.repository);

  @override
  Future<TransferTicket> execute(String params) async {
    return repository.getTransferTicketDetail(params);
  }
}
