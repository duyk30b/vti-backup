import '../../data/network/base_response/base_response.dart';

import '../repository/supply_request_repository.dart';
import '../request/supply_request_form_payload.dart';
import 'usecase.dart';

class UpdateSupplyRequestUseCase
    extends UseCase<SupplyRequestFormPayload, BaseResponseNoData> {
  final SupplyRequestRepository requestRepository;

  UpdateSupplyRequestUseCase(this.requestRepository);

  @override
  Future<BaseResponseNoData> execute(SupplyRequestFormPayload params) async {
    final String id = params.id ?? '';
    return requestRepository.updateSupplyRequest(params, id);
  }
}
