import '../../data/network/base_response/base_response.dart';
import '../repository/repair_request_repository.dart';

import 'usecase.dart';

class ConfirmRepairRequestUseCase extends UseCase<String, BaseResponseNoData> {
  final RepairRequestRepository repairRequestRepository;

  ConfirmRepairRequestUseCase(this.repairRequestRepository);

  @override
  Future<BaseResponseNoData> execute(String params) async {
    return repairRequestRepository.confirmRepairRequest(params);
  }
}
