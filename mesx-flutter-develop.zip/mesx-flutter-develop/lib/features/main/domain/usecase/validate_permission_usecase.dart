import '../../data/cache/cache_manager.dart';
import '../enum/permission_enum.dart';
import 'usecase.dart';

class ValidatePermissionUsecase extends UseCase<PermissionEnum, bool> {
  final CacheManager helper;

  ValidatePermissionUsecase(this.helper);

  @override
  Future<bool> execute(PermissionEnum params) async {
    final user = helper.getUserInFo();
    final permissions = user.userPermissions?.map((e) => e.code).toList() ?? [];
    return permissions.any((element) => element == params.code);
  }
}
