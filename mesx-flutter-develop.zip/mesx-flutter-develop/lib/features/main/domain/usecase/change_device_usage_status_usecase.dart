import '../../data/network/base_response/base_response.dart';
import '../repository/device_list_repository.dart';

import '../request/change_device_usage_status_request.dart';
import 'usecase.dart';

class ChangeDeviceUsageStatusUsecase
    extends UseCase<DeviceUsageStatusRequest, dynamic> {
  final DeviceListRepository deviceListRepository;

  ChangeDeviceUsageStatusUsecase(this.deviceListRepository);

  @override
  Future<BaseResponseNoData> execute(DeviceUsageStatusRequest params) async {
    return deviceListRepository.changeDeviceUsageStatus(
        params.id, params.status);
  }
}
