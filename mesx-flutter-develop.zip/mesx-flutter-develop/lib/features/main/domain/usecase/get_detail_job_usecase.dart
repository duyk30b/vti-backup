import '../../data/network/mapper/job_list_mapper.dart';
import '../model/job.dart';

import '../repository/job_repository.dart';
import 'usecase.dart';

class GetJobDetailUsecase extends UseCase<String, Job> {
  final JobRepository _jobRepository;

  GetJobDetailUsecase(this._jobRepository);

  @override
  Future<Job> execute(String params) async {
    final response = await _jobRepository.getJobDetail(params);
    return JobListMapperImpl().fromJobDTO(response.data);
  }
}
