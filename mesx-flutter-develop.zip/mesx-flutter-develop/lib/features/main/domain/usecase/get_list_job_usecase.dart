import '../../data/network/mapper/job_list_mapper.dart';
import '../model/job_list_response.dart';
import '../repository/job_repository.dart';
import '../request/base_query.dart';
import 'usecase.dart';

class GetJobListUseCase extends UseCase<BaseQuery, JobListResponse> {
  final JobRepository jobRepository;

  GetJobListUseCase(this.jobRepository);

  @override
  Future<JobListResponse> execute(BaseQuery params) async {
    final response = await jobRepository.getListJob(params);
    return JobListResponse(response.statusCode, response.message,
        JobListMapperImpl().fromJobDTOList(response.data), response.meta);
  }
}
