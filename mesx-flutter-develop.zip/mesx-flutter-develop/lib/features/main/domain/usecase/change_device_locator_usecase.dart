import '../../data/network/base_response/base_response.dart';
import '../repository/device_list_repository.dart';

import '../request/change_device_locator_request.dart';
import 'usecase.dart';

class ChangeDeviceLocatorUsecase
    extends UseCase<ChangeDeviceLocatorRequest, dynamic> {
  final DeviceListRepository deviceListRepository;

  ChangeDeviceLocatorUsecase(this.deviceListRepository);

  @override
  Future<BaseResponseNoData> execute(ChangeDeviceLocatorRequest params) async {
    return deviceListRepository.changeDeviceLocator(
      params.id,
      params.factoryId,
      params.areaId,
    );
  }
}
