import '../model/warehouse.dart';
import '../repository/warehouse_repository.dart';
import '../request/base_query.dart';
import 'usecase.dart';

class GetWarehouseListUsecase extends UseCase<BaseQuery, List<Warehouse>> {
  final WarehouseRepository warehouseRepository;

  GetWarehouseListUsecase(this.warehouseRepository);

  @override
  Future<List<Warehouse>> execute(BaseQuery params) async {
    return warehouseRepository.getListWarehouse(params);
  }
}
