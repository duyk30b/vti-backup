import '../model/paging_model.dart';
import '../model/warehouse_request/warehouse_import_request.dart';
import '../repository/warehouse_repository.dart';
import '../request/base_query.dart';
import 'usecase.dart';

class GetWarehouseImportRequestListUseCase
    extends UseCase<BaseQuery, PagingModel<WarehouseImportRequest>> {
  final WarehouseRepository repository;

  GetWarehouseImportRequestListUseCase(this.repository);

  @override
  Future<PagingModel<WarehouseImportRequest>> execute(BaseQuery params) async {
    return repository.getListWarehouseImportRequest(params);
  }
}
