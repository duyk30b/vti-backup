import '../model/paging_model.dart';
import '../model/transfer_ticket/transfer_ticket.dart';
import '../repository/transfer_ticket_repository.dart';
import '../request/base_query.dart';
import 'usecase.dart';

class GetTransferTicketListUsecase
    extends UseCase<BaseQuery, PagingModel<TransferTicket>> {
  final TransferTicketRepository repository;

  GetTransferTicketListUsecase(this.repository);

  @override
  Future<PagingModel<TransferTicket>> execute(BaseQuery params) async {
    return repository.getTransferTicketList(params);
  }
}
