import '../model/job.dart';
import '../repository/job_repository.dart';
import '../request/base_query.dart';
import 'usecase.dart';

class GetDeviceJobListUseCase extends UseCase<BaseQuery, List<Job>> {
  final JobRepository jobRepository;

  GetDeviceJobListUseCase(this.jobRepository);

  @override
  Future<List<Job>> execute(BaseQuery params) {
    return jobRepository.getDeviceJobList(params);
  }
}
