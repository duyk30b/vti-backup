import '../model/repair_request.dart';
import '../repository/repair_request_repository.dart';
import 'usecase.dart';

class GetDetailRepairRequestUseCase extends UseCase<String, RepairRequest> {
  final RepairRequestRepository repository;

  GetDetailRepairRequestUseCase(this.repository);

  @override
  Future<RepairRequest> execute(String params) async {
    return repository.getRepairRequestDetail(params);
  }
}
