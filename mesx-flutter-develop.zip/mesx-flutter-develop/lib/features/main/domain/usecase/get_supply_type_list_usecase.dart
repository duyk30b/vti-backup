import '../model/supply_type.dart';
import '../repository/supply_repository.dart';
import '../request/base_query.dart';
import 'usecase.dart';

class GetSupplyTypeListUsecase extends UseCase<BaseQuery, List<SupplyType>> {
  final SupplyRepository repository;

  GetSupplyTypeListUsecase(this.repository);

  @override
  Future<List<SupplyType>> execute(BaseQuery params) async {
    return repository.getSupplyTypeList(params);
  }
}
