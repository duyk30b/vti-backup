import '../model/supply_group.dart';
import '../repository/supply_group_repository.dart';
import '../request/base_query.dart';
import 'usecase.dart';

class GetSupplyGroupListUseCase extends UseCase<BaseQuery, List<SupplyGroup>> {
  final SupplyGroupRepository repository;

  GetSupplyGroupListUseCase(this.repository);

  @override
  Future<List<SupplyGroup>> execute(BaseQuery params) async {
    return repository.getSupplyGroupList(params);
  }
}
