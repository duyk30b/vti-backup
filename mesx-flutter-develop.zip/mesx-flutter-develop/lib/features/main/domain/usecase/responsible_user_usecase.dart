import '../../data/network/mapper/repair_request_mapper.dart';
import '../model/user.dart';
import '../repository/job_repository.dart';
import 'usecase.dart';

class ResponsibleUserUseCase extends NoParamsUseCase<List<User>> {
  final JobRepository _jobRepository;

  ResponsibleUserUseCase(this._jobRepository);

  @override
  Future<List<User>> execute() async {
    final response = await _jobRepository.responsibleUser();
    return response.data
        .map((e) => RepairRequestMapperImpl().fromUserDTO(e))
        .toList();
  }
}
