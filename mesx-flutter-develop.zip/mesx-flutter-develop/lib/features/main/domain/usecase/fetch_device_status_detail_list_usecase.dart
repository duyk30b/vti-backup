import '../model/device_status_detail_list.dart';
import '../repository/device_status_repository.dart';
import '../request/device_status_detail_list_request.dart';

import 'usecase.dart';

class FetchDeviceStatusDetailListUsecase
    extends UseCase<DeviceStatusDetailListRequest, DeviceStatusDetailList> {
  final DeviceStatusRepository deviceStatusRepository;

  FetchDeviceStatusDetailListUsecase(this.deviceStatusRepository);

  @override
  Future<DeviceStatusDetailList> execute(DeviceStatusDetailListRequest params) {
    return deviceStatusRepository.fetchDeviceStatusDetailList(params);
  }
}
