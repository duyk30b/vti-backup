import '../model/device_group.dart';
import '../repository/device_group_repository.dart';
import 'usecase.dart';

class GetDeviceGroupDetailUsecase extends UseCase<String, DeviceGroup> {
  final DeviceGroupRepo _deviceGroupRepo;

  GetDeviceGroupDetailUsecase(this._deviceGroupRepo);

  @override
  Future<DeviceGroup> execute(String params) async {
    final response = await _deviceGroupRepo.getDeviceGroupDetail(params);
    return response;
  }
}
