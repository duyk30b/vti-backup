import '../model/device_list.dart';
import '../repository/device_list_repository.dart';

import '../request/device_list_request.dart';
import 'usecase.dart';

class DeviceListUsecase extends UseCase<DeviceListRequest, DeviceList> {
  final DeviceListRepository deviceRepository;

  DeviceListUsecase(this.deviceRepository);

  @override
  Future<DeviceList> execute(DeviceListRequest params) {
    return deviceRepository.getListDevices(params);
  }
}
