import '../../data/network/mapper/repair_request_mapper.dart';
import '../model/user.dart';
import '../repository/job_repository.dart';
import 'usecase.dart';

class MaintenanceTeamsAssignmentsUsecase extends UseCase<String, List<User>> {
  final JobRepository jobRepository;

  MaintenanceTeamsAssignmentsUsecase(this.jobRepository);

  @override
  Future<List<User>> execute(String params) async {
    final response = await jobRepository.maintenanceTeamsAssign(params);
    final listItem = <User>[];
    response.data.items?.forEach((userDto) {
      listItem.add(RepairRequestMapperImpl().fromUserDTO(userDto));
    });
    return listItem;
  }
}
