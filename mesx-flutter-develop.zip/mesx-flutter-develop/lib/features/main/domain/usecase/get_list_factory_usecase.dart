import '../model/factory_info.dart';
import '../repository/factory_list_repository.dart';
import '../request/factory_list_request.dart';
import 'usecase.dart';

class GetListFactoryUsecase
    extends UseCase<FactoryListRequest, List<FactoryInfo>> {
  final FactoryListRepository repository;

  GetListFactoryUsecase(this.repository);

  @override
  Future<List<FactoryInfo>> execute(FactoryListRequest params) async {
    return repository.getListFactory(params);
  }
}
