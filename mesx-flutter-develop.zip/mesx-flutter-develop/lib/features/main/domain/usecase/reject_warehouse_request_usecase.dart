import '../../data/network/base_response/base_response.dart';
import '../enum/warehouse_ticket_enum.dart';
import '../repository/warehouse_repository.dart';
import '../request/action_change_status_request.dart';
import 'usecase.dart';

class RejectWarehouseRequestUseCase extends UseCase<
    ActionChangeStatusRequest<WarehouseTicketTypeEnum>, BaseResponseNoData> {
  final WarehouseRepository repository;

  RejectWarehouseRequestUseCase(this.repository);

  @override
  Future<BaseResponseNoData> execute(
      ActionChangeStatusRequest<WarehouseTicketTypeEnum> params) async {
    return repository.rejectWarehouseRequest(params.id, params.payload);
  }
}
