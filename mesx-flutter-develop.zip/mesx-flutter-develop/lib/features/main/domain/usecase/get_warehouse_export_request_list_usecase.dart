import '../model/paging_model.dart';
import '../model/warehouse_request/warehouse_export_request.dart';
import '../repository/warehouse_repository.dart';
import '../request/base_query.dart';
import 'usecase.dart';

class GetWarehouseExportRequestListUseCase
    extends UseCase<BaseQuery, PagingModel<WarehouseExportRequest>> {
  final WarehouseRepository repository;

  GetWarehouseExportRequestListUseCase(this.repository);

  @override
  Future<PagingModel<WarehouseExportRequest>> execute(BaseQuery params) async {
    return repository.getListWarehouseExportRequest(params);
  }
}
