import '../../data/network/response/inventory_list_response.dart';
import '../repository/supply_repository.dart';
import '../request/base_query.dart';
import 'usecase.dart';

class GetInventoriesUseCase
    extends UseCase<InventoryRequest, InventoryListResponse> {
  final SupplyRepository repository;

  GetInventoriesUseCase(this.repository);

  @override
  Future<InventoryListResponse> execute(InventoryRequest params) async {
    return repository.getListInventories(params.type, params.baseQuery);
  }
}

class InventoryRequest {
  final String type;
  final BaseQuery baseQuery;

  InventoryRequest(this.type, this.baseQuery);
}
