import '../../data/network/base_response/base_response.dart';
import '../repository/warehouse_repository.dart';
import '../request/warehouse_export_ticket_form_payload.dart';
import 'usecase.dart';

class UpdateWarehouseExportTicketUseCase
    extends UseCase<WarehouseExportTicketFormPayload, BaseResponseNoData> {
  final WarehouseRepository repository;

  UpdateWarehouseExportTicketUseCase(this.repository);

  @override
  Future<BaseResponseNoData> execute(
      WarehouseExportTicketFormPayload params) async {
    return repository.updateWarehouseExportTicket(params);
  }
}
