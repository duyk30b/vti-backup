import '../model/supply_request.dart';
import '../repository/supply_request_repository.dart';
import 'usecase.dart';

class GetSupplyRequestDetailUsecase extends UseCase<String, SupplyRequest> {
  final SupplyRequestRepository repository;

  GetSupplyRequestDetailUsecase(this.repository);

  @override
  Future<SupplyRequest> execute(String params) {
    return repository.getSupplyRequestDetailById(params);
  }
}
