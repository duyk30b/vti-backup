import '../model/device_status_detail.dart';
import '../repository/device_status_repository.dart';

import 'usecase.dart';

class GetDeviceStatusDetailUseCase extends UseCase<String, DeviceStatusDetail> {
  final DeviceStatusRepository deviceStatusRepository;

  GetDeviceStatusDetailUseCase(this.deviceStatusRepository);

  @override
  Future<DeviceStatusDetail> execute(String params) {
    return deviceStatusRepository.getDeviceStatusDetail(params);
  }
}
