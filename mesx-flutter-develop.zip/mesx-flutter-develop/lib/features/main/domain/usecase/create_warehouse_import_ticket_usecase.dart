import '../../data/network/base_response/base_response.dart';
import '../repository/warehouse_repository.dart';
import '../request/warehouse_import_ticket_form_payload.dart';
import 'usecase.dart';

class CreateWarehouseImportTicketUseCase
    extends UseCase<WarehouseImportTicketFormPayload, BaseResponseNoData> {
  final WarehouseRepository repository;

  CreateWarehouseImportTicketUseCase(this.repository);

  @override
  Future<BaseResponseNoData> execute(
      WarehouseImportTicketFormPayload params) async {
    return repository.createWarehouseImportTicket(params);
  }
}
