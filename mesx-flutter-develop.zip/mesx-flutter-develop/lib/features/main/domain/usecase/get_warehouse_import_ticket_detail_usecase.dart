import '../model/warehouse_ticket/warehouse_import_ticket.dart';
import '../repository/warehouse_repository.dart';
import 'usecase.dart';

class GetWarehouseImportTicketDetailUseCase
    extends UseCase<String, WarehouseImportTicket> {
  final WarehouseRepository repository;

  GetWarehouseImportTicketDetailUseCase(this.repository);

  @override
  Future<WarehouseImportTicket> execute(String params) async {
    return repository.getWarehouseImportTicketDetail(params);
  }
}
