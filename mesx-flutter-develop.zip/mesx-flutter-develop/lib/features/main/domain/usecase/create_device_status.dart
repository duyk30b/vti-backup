import '../../data/network/base_response/base_response.dart';
import '../repository/device_status_repository.dart';
import '../request/device_status_form_request.dart';

import 'usecase.dart';

class CreateDeviceStatusUseCase
    extends UseCase<DeviceStatusFormRequest, BaseResponseNoData> {
  final DeviceStatusRepository deviceRepository;

  CreateDeviceStatusUseCase(this.deviceRepository);

  @override
  Future<BaseResponseNoData> execute(DeviceStatusFormRequest params) {
    return deviceRepository.createDeviceStatus(params);
  }
}
