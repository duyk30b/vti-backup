import '../model/device_detail.dart';
import '../repository/device_list_repository.dart';

import 'usecase.dart';

class GetDeviceDetailUseCase extends UseCase<String, DeviceDetail> {
  final DeviceListRepository authRepository;

  GetDeviceDetailUseCase(this.authRepository);

  @override
  Future<DeviceDetail> execute(String params) {
    return authRepository.getDetailDeviceById(params);
  }
}
