import '../model/supply_request.dart';
import '../repository/supply_request_repository.dart';
import '../request/supply_request_list_query_request.dart';
import 'usecase.dart';

class GetListSupplyRequestUsecase
    extends UseCase<SupplyRequestListQuery, List<SupplyRequest>> {
  final SupplyRequestRepository repository;

  GetListSupplyRequestUsecase(this.repository);

  @override
  Future<List<SupplyRequest>> execute(SupplyRequestListQuery params) async {
    return repository.getListSupplyRequest(params);
  }
}
