import '../model/warehouse_ticket/warehouse_export_ticket.dart';
import '../repository/warehouse_repository.dart';
import 'usecase.dart';

class GetWarehouseExportTicketDetailUseCase
    extends UseCase<String, WarehouseExportTicket> {
  final WarehouseRepository repository;

  GetWarehouseExportTicketDetailUseCase(this.repository);

  @override
  Future<WarehouseExportTicket> execute(String params) async {
    return repository.getWarehouseExportTicketDetail(params);
  }
}
