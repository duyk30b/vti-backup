import '../repository/notification_repository.dart';
import 'usecase.dart';

class ReadAllNotificationUseCase extends NoParamsUseCase<dynamic> {
  final NotificationRepository repository;

  ReadAllNotificationUseCase(this.repository);

  @override
  Future execute() {
    return repository.readAllNotification();
  }
}
