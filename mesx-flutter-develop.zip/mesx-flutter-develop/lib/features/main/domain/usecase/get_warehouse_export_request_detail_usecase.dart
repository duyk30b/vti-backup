import '../model/warehouse_request/warehouse_export_request.dart';
import '../repository/warehouse_repository.dart';
import 'usecase.dart';

class GetWarehouseExportRequestDetailUseCase
    extends UseCase<String, WarehouseExportRequest> {
  final WarehouseRepository repository;

  GetWarehouseExportRequestDetailUseCase(this.repository);

  @override
  Future<WarehouseExportRequest> execute(String params) async {
    return repository.getWarehouseExportRequestDetail(params);
  }
}
