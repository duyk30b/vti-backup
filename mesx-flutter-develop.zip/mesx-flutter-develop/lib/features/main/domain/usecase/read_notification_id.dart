import '../repository/notification_repository.dart';
import 'usecase.dart';

class ReadNotificationIdUseCase extends UseCase<String, dynamic> {
  final NotificationRepository repository;

  ReadNotificationIdUseCase(this.repository);

  @override
  Future execute(String params) {
    return repository.readNotificationID(params);
  }
}
