import '../../data/network/model/user_info_dto.dart';
import '../repository/authentication_repository.dart';
import 'usecase.dart';

class GetMeUseCase extends NoParamsUseCase<UserInfoDTO> {
  final AuthenticationRepository repository;

  GetMeUseCase(this.repository);

  @override
  Future<UserInfoDTO> execute() async {
    final response = await repository.getMe();
    return response.data;
  }
}
