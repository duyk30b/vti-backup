import '../../data/network/mapper/notification_mapper.dart';
import '../model/notification_info.dart';
import '../model/notification_response.dart';
import '../repository/notification_repository.dart';
import '../request/notification_list_request.dart';
import 'usecase.dart';

class GetListNotifyUseCase
    extends UseCase<NotificationListRequest, NotificationResponse> {
  final NotificationRepository repository;

  GetListNotifyUseCase(this.repository);

  @override
  Future<NotificationResponse> execute(NotificationListRequest params) async {
    final response = await repository.getListNotification(
        params.limit, params.page, params.type);
    final listNotify = <NotificationInfo>[];
    for (final element in response.data) {
      listNotify.add(NotificationMapperImpl().fromNotificationItemDTO(element));
    }
    return NotificationResponse(
        response.statusCode, response.message, listNotify, response.meta);
  }
}
