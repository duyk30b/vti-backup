import '../../data/network/base_response/base_response.dart';
import '../repository/device_status_repository.dart';

import '../request/device_status_form_request.dart';
import 'usecase.dart';

class UpdateDeviceStatusUseCase
    extends UseCase<DeviceStatusFormRequest, BaseResponseNoData> {
  final DeviceStatusRepository deviceRepository;

  UpdateDeviceStatusUseCase(this.deviceRepository);

  @override
  Future<BaseResponseNoData> execute(DeviceStatusFormRequest params) {
    return deviceRepository.updateDeviceStatus(params);
  }
}
