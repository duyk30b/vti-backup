import '../model/paging_model.dart';
import '../model/warehouse_export.dart';
import '../repository/warehouse_repository.dart';
import '../request/base_query.dart';
import 'usecase.dart';

class GetWarehouseExportListUseCase
    extends UseCase<BaseQuery, PagingModel<WarehouseExport>> {
  final WarehouseRepository repository;

  GetWarehouseExportListUseCase(this.repository);

  @override
  Future<PagingModel<WarehouseExport>> execute(BaseQuery params) async {
    return repository.getWarehouseExportList(params);
  }
}
