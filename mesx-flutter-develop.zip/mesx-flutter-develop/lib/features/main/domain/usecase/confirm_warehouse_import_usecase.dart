import '../../data/network/base_response/base_response.dart';

import '../repository/warehouse_repository.dart';
import 'usecase.dart';

class ConfirmWarehouseImportUsecase
    extends UseCase<String, BaseResponseNoData> {
  final WarehouseRepository repository;

  ConfirmWarehouseImportUsecase(this.repository);

  @override
  Future<BaseResponseNoData> execute(String params) async {
    return repository.confirmWarehouseImport(params);
  }
}
