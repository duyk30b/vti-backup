import '../../data/network/base_response/base_response.dart';

import '../repository/supply_request_repository.dart';
import 'usecase.dart';

class RejectSupplyRequestUsecase extends UseCase<String, dynamic> {
  final SupplyRequestRepository repo;

  RejectSupplyRequestUsecase(this.repo);

  @override
  Future<BaseResponseNoData> execute(String params) async {
    return repo.rejectSupplyRequest(params);
  }
}
