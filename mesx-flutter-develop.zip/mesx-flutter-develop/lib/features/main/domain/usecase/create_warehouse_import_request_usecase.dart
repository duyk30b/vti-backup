import '../../data/network/base_response/base_response.dart';
import '../repository/warehouse_repository.dart';
import '../request/warehouse_import_request_form_payload.dart';
import 'usecase.dart';

class CreateWarehouseImportRequestUseCase
    extends UseCase<WarehouseImportRequestFormPayload, BaseResponseNoData> {
  final WarehouseRepository repository;

  CreateWarehouseImportRequestUseCase(this.repository);

  @override
  Future<BaseResponseNoData> execute(
      WarehouseImportRequestFormPayload params) async {
    return repository.createWarehouseImportRequest(params);
  }
}
