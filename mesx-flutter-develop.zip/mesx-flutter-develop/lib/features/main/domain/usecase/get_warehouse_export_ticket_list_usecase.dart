import '../model/paging_model.dart';
import '../model/warehouse_ticket/warehouse_export_ticket.dart';
import '../repository/warehouse_repository.dart';
import '../request/base_query.dart';
import 'usecase.dart';

class GetWarehouseExportTicketListUseCase
    extends UseCase<BaseQuery, PagingModel<WarehouseExportTicket>> {
  final WarehouseRepository repository;

  GetWarehouseExportTicketListUseCase(this.repository);

  @override
  Future<PagingModel<WarehouseExportTicket>> execute(BaseQuery params) async {
    return repository.getListWarehouseExportTicket(params);
  }
}
