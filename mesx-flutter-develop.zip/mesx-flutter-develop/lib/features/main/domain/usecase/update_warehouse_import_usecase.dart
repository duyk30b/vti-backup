import '../../data/network/base_response/base_response.dart';
import '../repository/warehouse_repository.dart';

import '../request/warehouse_import_request.dart';
import 'usecase.dart';

class UpdateWarehouseImportUseCase
    extends UseCase<WarehouseImportFormRequest, BaseResponseNoData> {
  final WarehouseRepository repo;

  UpdateWarehouseImportUseCase(this.repo);

  @override
  Future<BaseResponseNoData> execute(WarehouseImportFormRequest params) {
    return repo.updateWarehouseImport(params, params.id ?? '');
  }
}
