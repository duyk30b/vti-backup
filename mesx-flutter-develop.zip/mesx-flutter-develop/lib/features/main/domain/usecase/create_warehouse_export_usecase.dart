import '../../data/network/base_response/base_response.dart';
import '../repository/warehouse_repository.dart';

import '../request/warehouse_export_form_request.dart';
import 'usecase.dart';

class CreateWarehouseExportUseCase
    extends UseCase<WarehouseExportFormRequest, BaseResponseNoData> {
  final WarehouseRepository repo;

  CreateWarehouseExportUseCase(this.repo);

  @override
  Future<BaseResponseNoData> execute(WarehouseExportFormRequest params) {
    return repo.createWarehouseExport(params);
  }
}
