import '../../../../generated/l10n.dart';

enum DeviceActivityStatus {
  active(0),
  stop(1),
  error(2),
  off(3);

  final int status;
  const DeviceActivityStatus(this.status);
}

extension DeviceActivityStatusExt on DeviceActivityStatus {
  String toLabel() {
    switch (this) {
      case DeviceActivityStatus.active:
        return BS.current.format_device_activation_log_activated;
      case DeviceActivityStatus.stop:
        return BS.current.format_device_activation_log_stop;
      case DeviceActivityStatus.error:
        return BS.current.format_device_activation_log_error;
      case DeviceActivityStatus.off:
        return BS.current.format_device_activation_log_off;
    }
  }
}
