import 'package:flutter/material.dart';
import 'package:json_annotation/json_annotation.dart';
import '../../../../core/configs/app_colors.dart';
import '../../../../generated/l10n.dart';

@JsonEnum(valueField: 'usageStatus')
enum DeviceUsageStatus {
  using(0),
  preventive(2),
  broken(3),
  awaitClearance(4);

  final int usageStatus;
  const DeviceUsageStatus(this.usageStatus);
}

extension DeviceUsageStatusExt on DeviceUsageStatus {
  String toLabel() {
    switch (this) {
      case DeviceUsageStatus.awaitClearance:
        return BS.current.awaitClearance;
      case DeviceUsageStatus.preventive:
        return BS.current.preventive;
      case DeviceUsageStatus.broken:
        return BS.current.broken;
      case DeviceUsageStatus.using:
        return BS.current.using;
    }
  }

  Color toColor() {
    switch (this) {
      case DeviceUsageStatus.awaitClearance:
        return AppColors.usageStatusAwaitClearance;
      case DeviceUsageStatus.preventive:
        return AppColors.usageStatusPreventive;
      case DeviceUsageStatus.broken:
        return AppColors.usageStatusBroken;
      case DeviceUsageStatus.using:
        return AppColors.usageStatusUsing;
    }
  }
}
