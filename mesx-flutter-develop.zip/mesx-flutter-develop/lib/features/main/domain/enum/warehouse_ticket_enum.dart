import 'package:flutter/material.dart';
import 'package:json_annotation/json_annotation.dart';
import '../../../../core/configs/app_colors.dart';
import '../../../../generated/l10n.dart';

enum WarehouseTicketTypeEnum {
  export,
  import;
}

@JsonEnum(valueField: 'status')
enum WarehouseTicketStatus {
  pending(0),
  confirmed(1),
  rejected(2),
  ;

  final int status;
  const WarehouseTicketStatus(this.status);
}

@JsonEnum(valueField: 'type')
enum WarehouseImportTicketRequestType {
  returnDevice(0),
  returnSupply(1),
  transferDevice(2),
  requestDevice(4),
  requestSupply(3);

  final int type;
  const WarehouseImportTicketRequestType(this.type);
}

@JsonEnum(valueField: 'type')
enum WarehouseExportTicketRequestType {
  returnDevice(1),
  transferDevice(2),
  requestSupply(0);

  final int type;
  const WarehouseExportTicketRequestType(this.type);
}

extension WarehouseTicketStatusExt on WarehouseTicketStatus {
  String toLabel() {
    switch (this) {
      case WarehouseTicketStatus.pending:
        return BS.current.pending;
      case WarehouseTicketStatus.confirmed:
        return BS.current.confirm;
      case WarehouseTicketStatus.rejected:
        return BS.current.reject;
    }
  }

  Color toColor() {
    switch (this) {
      case WarehouseTicketStatus.pending:
        return AppColors.statusPending;
      case WarehouseTicketStatus.confirmed:
        return AppColors.statusSuccess;
      case WarehouseTicketStatus.rejected:
        return AppColors.statusReject;
    }
  }
}

extension WarehouseTicketTypeEnumExt on WarehouseTicketTypeEnum {
  String toLabel() {
    switch (this) {
      case WarehouseTicketTypeEnum.import:
        return BS.current.import_warehouse;
      case WarehouseTicketTypeEnum.export:
        return BS.current.export_warehouse;
    }
  }
}

extension WarehouseImportTicketRequestTypeExt
    on WarehouseImportTicketRequestType {
  String toLabel() {
    switch (this) {
      case WarehouseImportTicketRequestType.returnDevice:
        return BS.current.request_return_device;
      case WarehouseImportTicketRequestType.returnSupply:
        return BS.current.supply_return_request_arc;
      case WarehouseImportTicketRequestType.transferDevice:
        return BS.current.transfer_ticket;
      case WarehouseImportTicketRequestType.requestDevice:
        return BS.current.device_request;
      case WarehouseImportTicketRequestType.requestSupply:
        return BS.current.supply_request_buy_arc;
    }
  }
}

extension WarehouseExportTicketRequestTypeExt
    on WarehouseExportTicketRequestType {
  String toLabel() {
    switch (this) {
      case WarehouseExportTicketRequestType.returnDevice:
        return BS.current.request_return_device;

      case WarehouseExportTicketRequestType.transferDevice:
        return BS.current.transfer_ticket;

      case WarehouseExportTicketRequestType.requestSupply:
        return BS.current.supply_request_arc;
    }
  }
}
