enum UserRole {
  admin(0),
  factoryManager(1),
  leader(2),
  member(3),
  other(4);

  final int code;

  const UserRole(this.code);
}
