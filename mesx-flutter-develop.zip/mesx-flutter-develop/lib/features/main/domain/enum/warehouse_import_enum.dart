import 'package:json_annotation/json_annotation.dart';

@JsonEnum(valueField: 'status')
enum WarehouseImportStatus {
  pending(0),
  confirmed(1),
  rejected(2);

  final int status;
  const WarehouseImportStatus(this.status);
}

@JsonEnum(valueField: 'type')
enum WarehouseImportType {
  deviceAssign(0),
  returnSupply(1),
  requestSupply(2);

  final int type;
  const WarehouseImportType(this.type);
}
