import 'package:json_annotation/json_annotation.dart';

@JsonEnum(valueField: 'status')
enum WarehouseExportStatus {
  pending(0),
  confirmed(1),
  rejected(2);

  final int status;
  const WarehouseExportStatus(this.status);
}

@JsonEnum(valueField: 'type')
enum WarehouseExportType {
  transferRequest(1),
  transferLoan(2),
  supplyRequest(0),
  returnDevice(3);

  final int type;
  const WarehouseExportType(this.type);
}
