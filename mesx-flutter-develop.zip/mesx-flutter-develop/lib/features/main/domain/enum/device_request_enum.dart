import 'package:json_annotation/json_annotation.dart';

@JsonEnum(valueField: 'status')
enum DeviceRequestStatus {
  pending(0),
  confirmed(1),
  rejected(2),
  completed(3);

  final int status;
  const DeviceRequestStatus(this.status);
}

@JsonEnum(valueField: 'type')
enum DeviceRequestType {
  deviceRequest(0),
  returnRequest(1);

  final int type;
  const DeviceRequestType(this.type);
}
