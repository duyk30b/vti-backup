enum ActiveEnum {
  inactive(0),
  active(1);

  final int activeEnum;
  const ActiveEnum(this.activeEnum);
}
