import 'package:json_annotation/json_annotation.dart';

@JsonEnum(valueField: 'status')
enum RepairRequestStatusEnum {
  @JsonValue(-1)
  all(-1),
  @JsonValue(0)
  pending(0),
  @JsonValue(1)
  confirm(1),
  @JsonValue(2)
  rejected(2),
  @JsonValue(3)
  inProgress(3),
  @JsonValue(4)
  done(4),
  @JsonValue(5)
  completed(5);

  final int status;
  const RepairRequestStatusEnum(this.status);
}

@JsonEnum(valueField: 'value')
enum RepairRequestPriorityEnum {
  @JsonValue(2)
  high(2),

  @JsonValue(1)
  medium(1),

  @JsonValue(0)
  low(0);

  final int value;
  const RepairRequestPriorityEnum(this.value);
}
