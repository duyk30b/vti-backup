import 'package:json_annotation/json_annotation.dart';

@JsonEnum(valueField: 'status')
enum DeviceStatusType {
  @JsonValue(-1)
  all(-1),
  @JsonValue(0)
  online(0),
  @JsonValue(3)
  offline(3),
  @JsonValue(1)
  pause(1),
  @JsonValue(2)
  error(2);

  final int status;
  const DeviceStatusType(this.status);
}
