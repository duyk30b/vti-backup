import 'package:json_annotation/json_annotation.dart';
import '../../../../generated/l10n.dart';

import '../../presentation/ui/home_dash_board/feature_enum.dart';

@JsonEnum(valueField: 'type')
enum JobTypeEnum {
  maintenance(0),
  repair(1),
  accreditation(4),
  install(3),
  check(2);

  final int type;

  const JobTypeEnum(this.type);
}

@JsonEnum(valueField: 'status')
enum JobStatus {
  nonAssign(0),
  waitConfirm(1),
  inProgress(2),
  reject(3),
  done(4),
  completed(5),
  overdue(6);

  final int status;

  const JobStatus(this.status);
}

extension JobTypeEnumExtension on JobTypeEnum {
  static JobTypeEnum jobFromFeatEnum(FeatureEnum feat) {
    return JobTypeEnum.values
        .firstWhere((element) => element.name == feat.name);
  }

  String get title {
    switch (this) {
      case JobTypeEnum.install:
        return BS.current.install;
      case JobTypeEnum.repair:
        return BS.current.hotfix;
      case JobTypeEnum.maintenance:
        return BS.current.maintain;
      case JobTypeEnum.check:
        return BS.current.check_period;
      case JobTypeEnum.accreditation:
        return BS.current.verity;
    }
  }

  String get assignTitle {
    switch (this) {
      case JobTypeEnum.install:
        return BS.current.assign_job;
      case JobTypeEnum.repair:
        return BS.current.assign_job;
      case JobTypeEnum.maintenance:
        return BS.current.assign_job;
      case JobTypeEnum.check:
        return BS.current.assign_job;
      case JobTypeEnum.accreditation:
        return BS.current.assign_job;
    }
  }

  String get assignUserTitle {
    switch (this) {
      case JobTypeEnum.install:
        return BS.current.assign_for;
      case JobTypeEnum.repair:
        return BS.current.repair_for;
      case JobTypeEnum.maintenance:
        return BS.current.maintenance_for;
      case JobTypeEnum.check:
        return BS.current.assign_check_for;
      case JobTypeEnum.accreditation:
        return BS.current.verity;
    }
  }

  String get resultTitle {
    switch (this) {
      case JobTypeEnum.install:
        return BS.current.install_result;
      case JobTypeEnum.repair:
        return BS.current.hotfix;
      case JobTypeEnum.maintenance:
        return BS.current.maintain;
      case JobTypeEnum.check:
        return BS.current.check_period_result;
      case JobTypeEnum.accreditation:
        return BS.current.check_period_result;
    }
  }
}
