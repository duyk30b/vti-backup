enum PageMode {
  create,
  edit,
  detail,
  list,
}
