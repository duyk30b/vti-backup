import 'package:json_annotation/json_annotation.dart';
import '../../../../generated/l10n.dart';

@JsonEnum(valueField: 'priority')
enum Priority {
  @JsonValue(0)
  low(0),
  @JsonValue(1)
  medium(1),
  @JsonValue(2)
  high(2);

  final int status;

  const Priority(this.status);
}

extension PriorityExt on Priority {
  String get title {
    switch (this) {
      case Priority.low:
        return BS.current.low;
      case Priority.medium:
        return BS.current.medium;
      case Priority.high:
        return BS.current.high;
    }
  }
}
