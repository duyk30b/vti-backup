import 'package:json_annotation/json_annotation.dart';

@JsonEnum(valueField: 'status')
enum TransferTicketStatus {
  pending(0),
  confirmed(1),
  rejected(2),
  export(3),
  exported(4),
  import(5),
  imported(6),
  back(7),
  completed(8);

  final int status;
  const TransferTicketStatus(this.status);
}

@JsonEnum(valueField: 'type')
enum TransferTicketType {
  transferLoan(0),
  transferDevice(1);

  final int type;
  const TransferTicketType(this.type);
}
