import '../../../../generated/l10n.dart';

enum WarehouseTypeEnum { exports, import }

extension WarehouseTypeEnumExt on WarehouseTypeEnum {
  String get title {
    switch (this) {
      case WarehouseTypeEnum.exports:
        return BS.current.export_warehouse;
      case WarehouseTypeEnum.import:
        return BS.current.import_warehouse;
    }
  }
}
