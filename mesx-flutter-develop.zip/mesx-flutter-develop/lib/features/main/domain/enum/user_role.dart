import 'package:json_annotation/json_annotation.dart';

@JsonEnum(valueField: 'status')
enum ROLE {
  @JsonValue('0')
  admin(0),
  @JsonValue('01')
  factoryManager(1),
  @JsonValue('02')
  leader(2),
  @JsonValue('03')
  member(3),
  @JsonValue('04')
  other(4);

  final int status;

  const ROLE(this.status);
}
