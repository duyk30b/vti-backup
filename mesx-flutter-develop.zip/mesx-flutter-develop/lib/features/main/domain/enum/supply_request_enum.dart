import 'package:json_annotation/json_annotation.dart';

@JsonEnum(valueField: 'status')
enum SupplyRequestStatus {
  all(-1),
  waiting(0),
  confirm(1),
  reject(2),
  complete(3),
  awaitReturn(4);

  final int status;
  const SupplyRequestStatus(this.status);
}
