import 'package:flutter/material.dart';

import '../../../../core/configs/app_colors.dart';
import '../../../../generated/assets/assets.gen.dart';
import '../../../../generated/l10n.dart';

enum QcTest {
  passed(1),
  failed(0);

  final int status;

  const QcTest(this.status);
}

extension QcTestExt on QcTest {
  String get name {
    switch (this) {
      case QcTest.passed:
        return BS.current.passed;
      case QcTest.failed:
        return BS.current.failed;
    }
  }

  String get nameQC {
    switch (this) {
      case QcTest.passed:
        return BS.current.passed;
      case QcTest.failed:
        return BS.current.fail;
    }
  }

  Widget get icon {
    switch (this) {
      case QcTest.passed:
        return Assets.images.svgIcon.icTestPass.svg();
      case QcTest.failed:
        return Assets.images.svgIcon.icTestFailed.svg();
    }
  }

  Color get backColor {
    switch (this) {
      case QcTest.passed:
        return AppColors.statusSuccess.withOpacity(0.2);
      case QcTest.failed:
        return const Color.fromRGBO(225, 57, 57, 0.1);
    }
  }

  Color get textColor {
    switch (this) {
      case QcTest.passed:
        return AppColors.statusSuccess;
      case QcTest.failed:
        return AppColors.mainWarning;
    }
  }
}
