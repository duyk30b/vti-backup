import 'package:json_annotation/json_annotation.dart';
import '../../../../generated/l10n.dart';

@JsonEnum(valueField: 'maintenanceType')
enum MaintainType {
  @JsonValue(1)
  repair(1),
  @JsonValue(0)
  replace(0);

  final int status;

  const MaintainType(this.status);
}

extension MaintainTypeExt on MaintainType {
  String get title {
    switch (this) {
      case MaintainType.repair:
        return BS.current.repair_title;
      case MaintainType.replace:
        return BS.current.replace;
    }
  }

  String get titleSub {
    switch (this) {
      case MaintainType.repair:
        return BS.current.repair_title;
      case MaintainType.replace:
        return BS.current.replace;
    }
  }

  String get titleDropDown {
    switch (this) {
      case MaintainType.repair:
        return BS.current.repair_title;
      case MaintainType.replace:
        return BS.current.replace;
    }
  }
}
