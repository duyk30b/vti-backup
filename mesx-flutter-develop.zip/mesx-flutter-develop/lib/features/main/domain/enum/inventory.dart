import '../../../../generated/l10n.dart';

enum InventoryEnums {
  device('0'),
  supplies('1');

  final String type;

  const InventoryEnums(this.type);
}

extension InventoryExt on InventoryEnums {
  String get title {
    switch (this) {
      case InventoryEnums.device:
        return BS.current.device;
      case InventoryEnums.supplies:
        return BS.current.supplies;
    }
  }
}
