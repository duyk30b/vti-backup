import 'package:json_annotation/json_annotation.dart';

@JsonEnum(valueField: 'code')
enum PermissionEnum {
  // test when no permission
  permissionGranted('PERMISSION_GRANTED'),

  //Repair request
  createRepairRequest('MMS_CREATE_REPAIR_REQUEST'),
  updateRepairRequest('MMS_UPDATE_REPAIR_REQUEST'),
  updateStatusRepairRequest('MMS_UPDATE_STATUS_REPAIR_REQUEST'),
  detailRepairRequest('MMS_DETAIL_REPAIR_REQUEST'),
  listRepairRequest('MMS_LIST_REPAIR_REQUEST'),
  importRepairRequest('MMS_IMPORT_REPAIR_REQUEST'),
  exportRepairRequest('MMS_EXPORT_REPAIR_REQUEST'),

  //Device status
  createDeviceStatus('MMS_CREATE_DEVICE_STATUS'),
  updateDeviceStatus('MMS_UPDATE_DEVICE_STATUS'),
  deleteDeviceStatus('MMS_DELETE_DEVICE_STATUS'),
  detailDeviceStatus('MMS_DETAIL_DEVICE_STATUS'),
  listDeviceStatus('MMS_LIST_DEVICE_STATUS'),

  //Device
  createDevice('MMS_CREATE_DEVICE'),
  updateDevice('MMS_UPDATE_DEVICE'),
  detailDevice('MMS_DETAIL_DEVICE'),
  listDevice('MMS_LIST_DEVICE'),
  updateStatusDevice('MMS_UPDATE_STATUS_DEVICE'),
  historyActivityDevice('MMS_HISTORY_ACTIVITY_DEVICE'),

  //Supply request
  createSupplyRequest('MMS_CREATE_SUPPLY_REQUEST_TICKET'),
  updateSupplyRequest('MMS_UPDATE_SUPPLY_REQUEST_TICKET'),
  detailSupplyRequest('MMS_DETAIL_SUPPLY_REQUEST_TICKET'),
  listSupplyRequest('MMS_LIST_SUPPLY_REQUEST'),
  confirmSupplyRequest('MMS_CONFIRM_SUPPLY_REQUEST_TICKET'),
  deleteSupplyRequest('MMS_DELETE_SUPPLY_REQUEST_TICKET'),

  //Warehouse import
  deviceWarehouseImport('MMS_DEVICE_WAREHOUSE_IMPORT'),
  supplyWarehouseImport('MMS_SUPPLY_WAREHOUSE_IMPORT'),
  listWarehouseImport('MMS_LIST_WAREHOUSE_IMPORT'),
  createWarehouseImport('MMS_CREATE_WAREHOUSE_IMPORT'),
  updateWarehouseImport('MMS_UPDATE_WAREHOUSE_IMPORT'),
  detailWarehouseImport('MMS_DETAIL_WAREHOUSE_IMPORT'),
  updateStatusWarehouseImport('MMS_UPDATE_STATUS_WAREHOUSE_IMPORT'),
  deleteWarehouseImport('MMS_DELETE_WAREHOUSE_IMPORT'),

  //Warehouse export
  deviceWarehouseExport('MMS_DEVICE_WAREHOUSE_EXPORT'),
  supplyWarehouseExport('MMS_SUPPLY_WAREHOUSE_EXPORT'),
  listWarehouseExport('MMS_LIST_WAREHOUSE_EXPORT'),
  createWarehouseExport('MMS_CREATE_WAREHOUSE_EXPORT'),
  updateWarehouseExport('MMS_UPDATE_WAREHOUSE_EXPORT'),
  detailWarehouseExport('MMS_DETAIL_WAREHOUSE_EXPORT'),
  updateStatusWarehouseExport('MMS_UPDATE_STATUS_WAREHOUSE_EXPORT'),
  deleteWarehouseExport('MMS_DELETE_WAREHOUSE_EXPORT'),

  //warehouse import request
  createWarehouseImportRequest('MMS_CREATE_WAREHOUSE_IMPORT_REQUEST'),
  updateWarehouseImportRequest('MMS_UPDATE_WAREHOUSE_IMPORT_REQUEST'),
  detailWarehouseImportRequest('MMS_DETAIL_WAREHOUSE_IMPORT_REQUEST'),
  listWarehouseImportRequest('MMS_LIST_WAREHOUSE_IMPORT_REQUEST'),
  updateStatusWarehouseImportRequest(
      'MMS_UPDATE_STATUS_WAREHOUSE_IMPORT_REQUEST'),
  deleteWarehouseImportRequest('MMS_DELETE_WAREHOUSE_IMPORT_REQUEST'),
  deviceWarehouseImportRequest('MMS_DEVICE_WAREHOUSE_IMPORT_REQUEST'),
  supplyWarehouseImportRequest('MMS_SUPPLY_WAREHOUSE_IMPORT_REQUEST'),

  //warehouse import request
  createWarehouseExportRequest('MMS_CREATE_WAREHOUSE_EXPORT_REQUEST'),
  updateWarehouseExportRequest('MMS_UPDATE_WAREHOUSE_EXPORT_REQUEST'),
  detailWarehouseExportRequest('MMS_DETAIL_WAREHOUSE_EXPORT_REQUEST'),
  listWarehouseExportRequest('MMS_LIST_WAREHOUSE_EXPORT_REQUEST'),
  updateStatusWarehouseExportRequest(
      'MMS_UPDATE_STATUS_WAREHOUSE_EXPORT_REQUEST'),
  deleteWarehouseExportRequest('MMS_DELETE_WAREHOUSE_EXPORT_REQUEST'),
  deviceWarehouseExportRequest('MMS_DEVICE_WAREHOUSE_EXPORT_REQUEST'),
  supplyWarehouseExportRequest('MMS_SUPPLY_WAREHOUSE_EXPORT_REQUEST'),
  ;

  final String code;
  const PermissionEnum(this.code);
}
