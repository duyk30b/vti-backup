import 'package:flutter/material.dart';
import '../../../../core/configs/app_colors.dart';
import '../../../../generated/assets/assets.gen.dart';
import '../../../../generated/l10n.dart';

enum TaskStatus {
  notAssign(0),
  pending(1),
  inProgress(2),
  reject(3),
  executed(4),
  resolved(5);

  final int status;

  const TaskStatus(this.status);
}

extension TaskExt on TaskStatus {
  String get title {
    switch (this) {
      case TaskStatus.notAssign:
        return BS.current.not_assign;
      case TaskStatus.pending:
        return BS.current.pending;
      case TaskStatus.inProgress:
        return BS.current.in_progress;
      case TaskStatus.reject:
        return BS.current.reject;
      case TaskStatus.executed:
        return BS.current.executed;
      case TaskStatus.resolved:
        return BS.current.resolved;
    }
  }

  String get title1 {
    switch (this) {
      case TaskStatus.notAssign:
        return BS.current.pending_assign;
      case TaskStatus.pending:
        return BS.current.pending;
      case TaskStatus.inProgress:
        return BS.current.in_progress;
      case TaskStatus.reject:
        return BS.current.reject;
      case TaskStatus.executed:
        return BS.current.executed;
      case TaskStatus.resolved:
        return BS.current.resolved;
    }
  }

  Widget get icon {
    switch (this) {
      case TaskStatus.notAssign:
        return Assets.images.svgIcon.icAssignUser.svg(
            colorFilter: const ColorFilter.mode(
                AppColors.subTextColor, BlendMode.srcIn));
      case TaskStatus.pending:
        return Assets.images.svgIcon.icAssignUser.svg();
      case TaskStatus.inProgress:
        return Assets.images.svgIcon.icInProgress.svg();
      case TaskStatus.reject:
        return Assets.images.svgIcon.icFoundationPageDelete.svg();
      case TaskStatus.executed:
        return Assets.images.svgIcon.icExcuted.svg();
      case TaskStatus.resolved:
        return Assets.images.svgIcon.icCheck.svg();
    }
  }

  Color? get textColor {
    switch (this) {
      case TaskStatus.pending:
        return AppColors.greenConfirm;
      case TaskStatus.inProgress:
        return AppColors.mainBlue;
      case TaskStatus.reject:
        return AppColors.red;
      case TaskStatus.executed:
        return AppColors.statusSuccess;
      case TaskStatus.resolved:
        return AppColors.statusSuccess;

      default:
        {
          return null;
        }
    }
  }
}
