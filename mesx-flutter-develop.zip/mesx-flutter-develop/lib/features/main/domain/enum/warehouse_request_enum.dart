import 'package:flutter/material.dart';
import 'package:json_annotation/json_annotation.dart';
import '../../../../core/configs/app_colors.dart';
import '../../../../generated/l10n.dart';

@JsonEnum(valueField: 'status')
enum WarehouseRequestStatus {
  pending(0),
  confirmed(1),
  rejected(2),
  completed(3);

  final int status;
  const WarehouseRequestStatus(this.status);
}

extension WarehouseRequestStatusExt on WarehouseRequestStatus {
  String toLabel() {
    switch (this) {
      case WarehouseRequestStatus.pending:
        return BS.current.pending;
      case WarehouseRequestStatus.confirmed:
        return BS.current.confirm;
      case WarehouseRequestStatus.rejected:
        return BS.current.reject;
      case WarehouseRequestStatus.completed:
        return BS.current.completed;
    }
  }

  Color toColor() {
    switch (this) {
      case WarehouseRequestStatus.pending:
        return AppColors.statusPending;
      case WarehouseRequestStatus.confirmed:
        return AppColors.statusSuccess;
      case WarehouseRequestStatus.rejected:
        return AppColors.statusReject;
      case WarehouseRequestStatus.completed:
        return AppColors.statusCompleted;
    }
  }
}
