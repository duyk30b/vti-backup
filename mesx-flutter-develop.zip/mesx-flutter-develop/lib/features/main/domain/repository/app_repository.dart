abstract class AppRepository {
  //Future<void> initCache();
}
