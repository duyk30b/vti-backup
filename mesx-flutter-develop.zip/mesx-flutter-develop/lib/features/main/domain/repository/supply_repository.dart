import '../../data/network/response/inventory_list_response.dart';
import '../model/supply.dart';
import '../model/supply_type.dart';
import '../request/base_query.dart';
import '../request/get_stock_supply_by_warehouse.dart';

abstract class SupplyRepository {
  Future<List<Supply>> getListSupply(BaseQuery params);
  Future<Supply> getSupplyDetail(String params);

  Future<Supply> getStockSupplyByWarehouse(
      GetStockSupplyByWarehouseRequest params);

  Future<InventoryListResponse> getListInventories(
      String type, BaseQuery params);

  Future<List<SupplyType>> getSupplyTypeList(BaseQuery params);
}
