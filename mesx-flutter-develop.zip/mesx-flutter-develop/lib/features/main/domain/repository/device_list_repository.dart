import '../../data/network/base_response/base_response.dart';
import '../model/device_detail.dart';

import '../model/device_list.dart';
import '../request/device_list_request.dart';

abstract class DeviceListRepository {
  Future<DeviceList> getListDevices(DeviceListRequest params);
  Future<DeviceDetail> getDetailDeviceById(String id);
  Future<BaseResponseNoData> changeDeviceUsageStatus(String id, int status);
  Future<BaseResponseNoData> changeDeviceLocator(
      String id, int factoryId, String? areaId);
  Future<DeviceDetail> scanDevice(
    String params,
  );
}
