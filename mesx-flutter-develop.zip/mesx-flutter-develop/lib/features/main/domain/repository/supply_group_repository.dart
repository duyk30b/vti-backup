import '../model/supply_group.dart';
import '../request/base_query.dart';

abstract class SupplyGroupRepository {
  Future<List<SupplyGroup>> getSupplyGroupList(BaseQuery params);
}
