import '../model/paging_model.dart';
import '../model/transfer_ticket/transfer_ticket.dart';
import '../request/base_query.dart';

abstract class TransferTicketRepository {
  Future<PagingModel<TransferTicket>> getTransferTicketList(BaseQuery params);
  Future<TransferTicket> getTransferTicketDetail(String params);
}
