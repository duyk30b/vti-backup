import '../../data/network/base_response/base_response.dart';
import '../enum/warehouse_ticket_enum.dart';
import '../model/device_detail.dart';
import '../model/paging_model.dart';
import '../model/warehouse.dart';
import '../model/warehouse_export.dart';
import '../model/warehouse_import.dart';
import '../model/warehouse_request/warehouse_export_request.dart';
import '../model/warehouse_request/warehouse_import_request.dart';
import '../model/warehouse_ticket/warehouse_export_ticket.dart';
import '../model/warehouse_ticket/warehouse_import_ticket.dart';
import '../request/base_query.dart';
import '../request/device_inventory_detail_request.dart';
import '../request/warehouse_export_form_request.dart';
import '../request/warehouse_export_request_form_payload.dart';
import '../request/warehouse_export_ticket_form_payload.dart';
import '../request/warehouse_import_request.dart';
import '../request/warehouse_import_request_form_payload.dart';
import '../request/warehouse_import_ticket_form_payload.dart';

abstract class WarehouseRepository {
  Future<List<Warehouse>> getListWarehouse(BaseQuery params);
  //warehouse import
  Future<PagingModel<WarehouseImport>> getWarehouseImportList(BaseQuery params);
  Future<WarehouseImport> getWarehouseImportDetail(String params);
  Future<BaseResponseNoData> confirmWarehouseImport(String params);
  Future<BaseResponseNoData> rejectWarehouseImport(String params);
  Future<BaseResponseNoData> createWarehouseImport(
      WarehouseImportFormRequest params);
  Future<BaseResponseNoData> updateWarehouseImport(
      WarehouseImportFormRequest params, String id);

  //warehouse export
  Future<PagingModel<WarehouseExport>> getWarehouseExportList(BaseQuery params);
  Future<WarehouseExport> getWarehouseExportDetail(String params);
  Future<BaseResponseNoData> confirmWarehouseExport(String params);
  Future<BaseResponseNoData> rejectWarehouseExport(String params);
  Future<BaseResponseNoData> createWarehouseExport(
      WarehouseExportFormRequest params);
  Future<BaseResponseNoData> updateWarehouseExport(
      WarehouseExportFormRequest params, String id);

  Future<PagingModel<WarehouseImportTicket>> getListWarehouseImportTicket(
    BaseQuery params,
  );
  Future<PagingModel<WarehouseExportTicket>> getListWarehouseExportTicket(
    BaseQuery params,
  );

  Future<BaseResponseNoData> rejectWarehouseTicket(
      String params, WarehouseTicketTypeEnum ticketType);
  Future<BaseResponseNoData> confirmWarehouseTicket(
      String params, WarehouseTicketTypeEnum ticketType);
  Future<BaseResponseNoData> deleteWarehouseTicket(
      String params, WarehouseTicketTypeEnum ticketType);

  Future<PagingModel<WarehouseImportRequest>> getListWarehouseImportRequest(
    BaseQuery params,
  );

  Future<PagingModel<WarehouseExportRequest>> getListWarehouseExportRequest(
    BaseQuery params,
  );
  Future<WarehouseImportRequest> getWarehouseImportRequestDetail(
    String params,
  );
  Future<WarehouseExportRequest> getWarehouseExportRequestDetail(
    String params,
  );
  Future<WarehouseImportTicket> getWarehouseImportTicketDetail(
    String params,
  );
  Future<WarehouseExportTicket> getWarehouseExportTicketDetail(
    String params,
  );

  Future<BaseResponseNoData> createWarehouseImportTicket(
    WarehouseImportTicketFormPayload params,
  );

  Future<BaseResponseNoData> updateWarehouseImportTicket(
    WarehouseImportTicketFormPayload params,
  );
  Future<BaseResponseNoData> createWarehouseExportTicket(
    WarehouseExportTicketFormPayload params,
  );

  Future<BaseResponseNoData> updateWarehouseExportTicket(
    WarehouseExportTicketFormPayload params,
  );

  Future<BaseResponseNoData> rejectWarehouseRequest(
      String params, WarehouseTicketTypeEnum ticketType);
  Future<BaseResponseNoData> confirmWarehouseRequest(
      String params, WarehouseTicketTypeEnum ticketType);
  Future<BaseResponseNoData> deleteWarehouseRequest(
      String params, WarehouseTicketTypeEnum ticketType);

  Future<BaseResponseNoData> createWarehouseImportRequest(
    WarehouseImportRequestFormPayload params,
  );

  Future<BaseResponseNoData> updateWarehouseImportRequest(
    WarehouseImportRequestFormPayload params,
  );

  Future<BaseResponseNoData> createWarehouseExportRequest(
    WarehouseExportRequestFormPayload params,
  );

  Future<BaseResponseNoData> updateWarehouseExportRequest(
    WarehouseExportRequestFormPayload params,
  );

  Future<PagingModel<DeviceDetail>> getDeviceInventoryDetail(
    DeviceInventoryDetailRequest params,
  );
}
