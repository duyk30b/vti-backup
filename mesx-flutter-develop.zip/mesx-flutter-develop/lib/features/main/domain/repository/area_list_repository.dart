import '../model/area_info.dart';
import '../request/area_list_request.dart';

abstract class AreaListRepository {
  Future<List<AreaInfo>> getListArea(AreaListRequest params);
}
