import '../../data/network/response/list_notification_response.dart';

abstract class NotificationRepository {
  Future<ListNotificationResponse> getListNotification(
      int limit, int page, String type);

  Future readNotificationID(String id);

  Future readAllNotification();
}
