import '../../data/network/base_response/base_response.dart';
import '../model/paging_model.dart';
import '../model/repair_request.dart';
import '../request/base_query.dart';
import '../request/create_repair_request.dart';

abstract class RepairRequestRepository {
  Future<PagingModel<RepairRequest>> getRepairRequestList(BaseQuery params);
  Future<RepairRequest> getRepairRequestDetail(String params);
  Future<BaseResponseNoData> createRepairRequest(CreateRepairRequest params);
  Future<BaseResponseNoData> confirmRepairRequest(String params);
  Future<BaseResponseNoData> rejectRepairRequest(String params);
}
