import '../model/factory_info.dart';
import '../request/factory_list_request.dart';

abstract class FactoryListRepository {
  Future<List<FactoryInfo>> getListFactory(FactoryListRequest params);
}
