import '../model/device_activity_history.dart';
import '../request/device_activity_request.dart';

abstract class DeviceActivityHistoryRepo {
  Future<List<DeviceActivityHistory>> getDeviceActivityHistory(
      DeviceActivityHistoryRequest params);
}
