import '../../data/network/base_response/base_response.dart';
import '../model/supply_request.dart';
import '../request/supply_request_form_payload.dart';
import '../request/supply_request_list_query_request.dart';

abstract class SupplyRequestRepository {
  Future<List<SupplyRequest>> getListSupplyRequest(
      SupplyRequestListQuery params);
  Future<SupplyRequest> getSupplyRequestDetailById(String id);
  Future<BaseResponseNoData> confirmSupplyRequest(String id);
  Future<BaseResponseNoData> rejectSupplyRequest(String id);
  Future<BaseResponseNoData> deleteSupplyRequest(String id);
  Future<BaseResponseNoData> createSupplyRequest(
      SupplyRequestFormPayload params);
  Future<BaseResponseNoData> updateSupplyRequest(
      SupplyRequestFormPayload params, String id);
}
