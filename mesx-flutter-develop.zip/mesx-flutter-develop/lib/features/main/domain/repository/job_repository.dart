import 'dart:io';

import '../../data/network/response/device_job_list_reponse.dart';
import '../../data/network/response/job_detail_response.dart';
import '../../data/network/response/responsible_list_response.dart';
import '../../data/network/response/user_assign_item_response.dart';
import '../model/job.dart';
import '../request/assign_request.dart';
import '../request/base_query.dart';

abstract class JobRepository {
  Future<List<Job>> getDeviceJobList(BaseQuery params);

  Future<DeviceJobListResponse> getListJob(BaseQuery params);

  Future<JobDetailResponse> getJobDetail(String id);

  Future confirmJob(String id, String action,
      {String? reason, int? executionTime, int? stopTime});

  Future addReason(String id, String reason);

  Future executedJob(String id, String data, {File? file});

  Future<UserAssignItemResponse> maintenanceTeamsAssign(String id);

  Future assignUser(String id, AssignRequest request);

  Future<ListResponsibleResponse> responsibleUser();

  Future updateTaskStatus(String id, int status);
}
