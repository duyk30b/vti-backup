import '../model/device_request.dart';
import '../model/paging_model.dart';
import '../request/base_query.dart';

abstract class DeviceRequestRepository {
  Future<PagingModel<DeviceRequest>> getDeviceRequestList(BaseQuery params);
  Future<DeviceRequest> getDeviceRequestDetail(String id);
}
