import '../../data/network/response/get_me_response.dart';

import '../../data/network/response/login_response.dart';
import '../request/login_request.dart';

abstract class AuthenticationRepository {
  Future<LoginResponse> login(LoginRequest params);

  Future<GetMeResponse> getMe();

  bool isLogin();

  void saveTokenToCache(String? token, String? refreshToken);
}
