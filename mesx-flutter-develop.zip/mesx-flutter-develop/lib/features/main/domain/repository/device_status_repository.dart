import '../../../main/domain/model/device_status_detail_list.dart';
import '../../../main/domain/model/device_status_list.dart';
import '../../../main/domain/request/base_query.dart';
import '../../../main/domain/request/device_status_detail_list_request.dart';
import '../.././../main/domain/model/device_status_detail.dart';
import '../../data/network/base_response/base_response.dart';
import '../request/device_status_form_request.dart';

abstract class DeviceStatusRepository {
  Future<DeviceStatusList> fetchDeviceStatusList(BaseQuery query);
  Future<DeviceStatusDetailList> fetchDeviceStatusDetailList(
      DeviceStatusDetailListRequest query);
  Future<DeviceStatusDetail> getDeviceStatusDetail(String id);
  Future<BaseResponseNoData> createDeviceStatus(
      DeviceStatusFormRequest payload);
  Future<BaseResponseNoData> updateDeviceStatus(
      DeviceStatusFormRequest payload);
}
