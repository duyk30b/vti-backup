import '../model/device_assignment.dart';
import '../request/base_query.dart';

abstract class DeviceAssignmentRepository {
  Future<List<DeviceAssignment>> getDeviceAssignMentList(BaseQuery params);
  Future<DeviceAssignment> getDeviceAssignMentDetail(String params);
}
