import '../model/device_group.dart';
import '../request/base_query.dart';

abstract class DeviceGroupRepo {
  Future<DeviceGroup> getDeviceGroupDetail(String id);

  Future<List<DeviceGroup>> getDeviceGroupList(BaseQuery params);
}
