import '../../../../core/utils/date_utils.dart';

import '../enum/device_status.dart';

class DeviceStatusFormRequest {
  final String? id;
  final String deviceId;
  final DateTime? startTime;
  final DateTime? endTime;
  final DeviceStatusType status;
  final List<AttributeTypeRequest> attributeTypes;

  DeviceStatusFormRequest(
    this.startTime,
    this.endTime,
    this.status,
    this.attributeTypes,
    this.deviceId,
    this.id,
  );

  @override
  String toString() {
    return 'DeviceStatusFormRequest(startTime: $startTime, endTime: $endTime, status: $status, attributes: $attributeTypes)';
  }

  factory DeviceStatusFormRequest.fromJson(Map<String, dynamic> json) {
    final startTime = DateUtilsFormat.mapDateAndTime(
      json['startDate'] as DateTime?,
      dateTime: json['startDate_time'] as DateTime?,
    );

    final endTime = DateUtilsFormat.mapDateAndTime(
      json['endDate'] as DateTime?,
      dateTime: json['endDate_time'] as DateTime?,
    );

    return DeviceStatusFormRequest(
      startTime,
      endTime,
      json['status'] as DeviceStatusType,
      (json['attributeTypes'] as List<dynamic>)
          .map((e) => AttributeTypeRequest.fromJson(e as Map<dynamic, dynamic>))
          .toList(),
      json['deviceId'] as String,
      json['id'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'startTime': startTime?.toUtc().toIso8601String(),
      'endTime': endTime?.toUtc().toIso8601String(),
      'status': status.status,
      'attributeTypes': attributeTypes.map((e) => e.toJson()).toList(),
      'deviceId': deviceId,
      ...(id == null ? {} : {'id': id})
    };
  }
}

class AttributeTypeRequest {
  final String attributeTypeId;
  final num? value;

  AttributeTypeRequest(this.attributeTypeId, this.value);

  @override
  String toString() =>
      'AttributeTypeRequest(attributeTypeId: $attributeTypeId, value: $value)';

  factory AttributeTypeRequest.fromJson(Map<dynamic, dynamic> json) {
    return AttributeTypeRequest(
      json['attributeTypeId'] as String,
      json['value'] as num?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'attributeTypeId': attributeTypeId,
      'value': value,
    };
  }
}
