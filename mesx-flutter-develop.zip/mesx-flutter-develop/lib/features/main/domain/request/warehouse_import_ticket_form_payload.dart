import '../enum/warehouse_ticket_enum.dart';
import '../model/warehouse_request/warehouse_import_request.dart';

class WarehouseImportTicketFormPayload {
  final String? id;
  final String? warehouseImportRequestId;
  final String? name;
  final String? note;
  final String? number;
  final String? debit;
  final String? gdiNo;
  final String? reason;
  final String? remain;
  final String? symbol;
  final String? contractNum;
  final DateTime? date;
  final DateTime? importDate;
  final List<DevicePayload>? devices;
  final List<SupplyPayload>? supplies;
  final int? requestType;

  WarehouseImportTicketFormPayload({
    this.id,
    this.warehouseImportRequestId,
    this.name,
    this.note,
    this.number,
    this.debit,
    this.gdiNo,
    this.reason,
    this.remain,
    this.symbol,
    this.contractNum,
    this.date,
    this.importDate,
    this.devices,
    this.requestType,
    this.supplies,
  });

  factory WarehouseImportTicketFormPayload.fromJson(Map<String, dynamic> json) {
    return WarehouseImportTicketFormPayload(
      id: json['id'] as String?,
      warehouseImportRequestId:
          (json['request'] as WarehouseImportRequest?)?.id,
      name: json['name'] as String?,
      note: json['note'] as String?,
      number: json['number'] as String?,
      debit: json['debit'] as String?,
      gdiNo: json['gdiNo'] as String?,
      reason: json['reason'] as String?,
      remain: json['remain'] as String?,
      symbol: json['symbol'] as String?,
      contractNum: json['contractNum'] as String?,
      date: json['date'],
      importDate: json['importDate'],
      requestType:
          (json['requestType'] as WarehouseImportTicketRequestType?)?.type,
      devices: (json['devices'] as List<dynamic>?)
          ?.map((e) => DevicePayload.fromJson(e as Map<String, dynamic>))
          .toList(),
      supplies: (json['supplies'] as List<dynamic>?)
          ?.map((e) => SupplyPayload.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'note': note,
        'number': number,
        'debit': debit,
        'gdiNo': gdiNo,
        'reason': reason,
        'remain': remain,
        'symbol': symbol,
        'contractNum': contractNum,
        'date': date?.toIso8601String(),
        'importDate': importDate?.toIso8601String(),
        'devices': devices?.map((e) => e.toJson()).toList(),
        'requestType': requestType,
        'warehouseImportRequestId': warehouseImportRequestId,
        'supplies': supplies?.map((e) => e.toJson()).toList(),
      };
}

class DevicePayload {
  final String? deviceId;
  final String? size;
  final String? color;
  final num? price;

  DevicePayload({
    this.deviceId,
    this.size,
    this.color,
    this.price,
  });

  factory DevicePayload.fromJson(Map<String, dynamic> json) {
    return DevicePayload(
      deviceId: json['deviceId'] as String?,
      size: json['size'] as String?,
      color: json['color'] as String?,
      price: json['price'] as num?,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'deviceId': deviceId,
        'size': size,
        'color': color,
        'price': price,
      };
}

class SupplyPayload {
  final String? supplyId;
  final String? color;
  final String? size;
  final int? quantity;
  final num? price;

  SupplyPayload({
    this.supplyId,
    this.color,
    this.size,
    this.quantity,
    this.price,
  });

  factory SupplyPayload.fromJson(Map<String, dynamic> json) {
    return SupplyPayload(
      supplyId: json['supplyId'] as String?,
      size: json['size'] as String?,
      color: json['color'] as String?,
      price: json['price'] as num?,
      quantity: json['quantity'] as int?,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'supplyId': supplyId,
        'size': size,
        'color': color,
        'price': price,
        'quantity': quantity,
      };
}
