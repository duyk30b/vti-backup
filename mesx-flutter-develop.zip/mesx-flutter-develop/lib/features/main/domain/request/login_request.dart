class LoginRequest {
  final String account;
  final String pass;
  final bool? rememberPassword;

  LoginRequest(this.account, this.pass, {this.rememberPassword});

  Map<String, dynamic> toJson() {
    return {
      'username': account,
      'password': pass,
      'rememberPassword': rememberPassword == null
          ? 0
          : rememberPassword!
              ? 1
              : 0,
    };
  }
}
