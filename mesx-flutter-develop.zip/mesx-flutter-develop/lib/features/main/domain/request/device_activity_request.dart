import 'base_query.dart';

class DeviceActivityHistoryRequest extends BaseQuery {
  final String deviceId;
  DeviceActivityHistoryRequest({
    super.filters,
    super.keyword,
    super.limit,
    super.page,
    super.sort,
    required this.deviceId,
  });
}
