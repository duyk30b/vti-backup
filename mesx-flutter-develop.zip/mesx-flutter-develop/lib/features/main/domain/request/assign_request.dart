class AssignRequest {
  int? assignId;
  DateTime? planFrom;
  DateTime? planTo;
  bool? isNeedAccept;
  String? reason;

  AssignRequest({
    this.assignId,
    this.planFrom,
    this.planTo,
    this.isNeedAccept,
    this.reason,
  });

  factory AssignRequest.fromJson(Map<String, dynamic> json) => AssignRequest(
        assignId: json['assignId'] as int?,
        planFrom: json['planFrom'] == null
            ? null
            : DateTime.parse(json['planFrom'] as String),
        planTo: json['planTo'] == null
            ? null
            : DateTime.parse(json['planTo'] as String),
        isNeedAccept: json['isNeedAccept'] as bool?,
        reason: json['reason'] as String?,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'assignId': assignId,
        'planFrom': planFrom?.toUtc().toIso8601String(),
        'planTo': planTo?.toUtc().toIso8601String(),
        'isNeedAccept': isNeedAccept,
        'reason': reason,
      };
}
