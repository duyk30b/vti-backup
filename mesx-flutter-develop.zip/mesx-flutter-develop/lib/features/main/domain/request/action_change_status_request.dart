class ActionChangeStatusRequest<T> {
  final String id;
  final T payload;

  ActionChangeStatusRequest(this.id, this.payload);
}
