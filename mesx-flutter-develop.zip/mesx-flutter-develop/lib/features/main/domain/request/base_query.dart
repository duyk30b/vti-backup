import 'dart:convert';

import 'package:flutter/material.dart';
import '../../../../core/configs/constants.dart';
import '../../../../core/extensions/string_ext.dart';

import '../../../../core/utils/date_utils.dart';

class Filter {
  String column;
  String? text;

  Filter(this.column, this.text);

  Map<String, dynamic> toJson() {
    return {
      'column': column,
      ...(text.isNullOrBlank) ? {'text': ''} : {'text': text}
    };
  }

  Filter copyWith({
    String? column,
    String? text,
  }) {
    return Filter(
      column ?? this.column,
      text ?? this.text,
    );
  }
}

class Sort {
  String column;
  String? order;

  Sort(this.column, this.order);

  Map<String, dynamic> toJson() {
    return {
      'column': column,
      ...(order.isNullOrBlank) ? {'order': ''} : {'order': order}
    };
  }

  Sort copyWith({
    String? column,
    String? order,
  }) {
    return Sort(
      column ?? this.column,
      order ?? this.order,
    );
  }
}

class BaseQuery {
  String? keyword;
  int? page;
  int? limit;
  List<Filter?>? filters;
  List<Sort?>? sort;
  int? isGetAll;

  BaseQuery({
    this.keyword,
    this.page = 1,
    this.limit = Constants.limit,
    this.filters,
    this.sort,
    this.isGetAll,
  });

  Map<String, dynamic> toJson() {
    return {
      ...(!keyword.isNullOrBlank) ? {'keyword': keyword} : {},
      ...(page != null) ? {'page': page} : {'page': 1},
      ...(limit != null) ? {'limit': limit} : {'limit': Constants.limit},
      ...(filters != null)
          ? filters!.isNotEmpty
              ? {
                  'filter':
                      jsonEncode(filters!.map((e) => e?.toJson()).toList())
                }
              : {}
          : {},
      ...(sort != null)
          ? sort!.isNotEmpty
              ? {'sort': jsonEncode(sort!.map((e) => e?.toJson()).toList())}
              : {}
          : {},
      ...(isGetAll != null) ? {'isGetAll': isGetAll} : {}
    };
  }

  void setFilter(String column, String? text) {
    filters ??= [];
    if (text.isNullOrBlank) {
      removeFilter(column);
      return;
    }
    if (filters!.isNotEmpty) {
      final curFilter = filters?.where((filter) => filter?.column == column);
      if (curFilter != null && curFilter.isNotEmpty) {
        curFilter.first?.text = text;
      } else {
        filters?.add(Filter(column, text));
      }
    } else {
      filters?.add(Filter(column, text));
    }
  }

  set setFilterList(List<Filter?>? filters) {
    this.filters = filters;
  }

  void setFilterDateTimeRange(
    String column, {
    DateTimeRange? dateTimeRange,
    DateTime? start,
    DateTime? end,
    String format = Constants.dateTimeAPIFormat,
  }) {
    start ??= dateTimeRange?.start;
    end ??= dateTimeRange?.end;

    if (start == null || end == null) {
      removeFilter(column);
      return;
    }

    start = DateUtilsFormat.startOfDay(start).toUtc();
    end = DateUtilsFormat.endOfDay(end).toUtc();

    final dateTime =
        DateUtilsFormat.toDateTimeRangeAPIFilter(start, end, format: format);
    setFilter(column, dateTime);
  }

  void setFilterDateTime(String column, DateTime? dateTime,
      {String format = Constants.dateTimeAPIFormat}) {
    if (dateTime != null) {
      setFilter(
          column, DateUtilsFormat.toDateAPIString(dateTime, format: format));
    } else {
      removeFilter(column);
    }
  }

  void setSort(String column, String text) {
    sort ??= [];
    if (filters!.isNotEmpty) {
      final curSort = sort?.where((item) => item?.column == column);
      if (curSort != null && curSort.isNotEmpty) {
        curSort.first?.order = text;
      } else {
        sort?.add(Sort(column, text));
      }
    } else {
      sort?.add(Sort(column, text));
    }
  }

  set setPage(int page) {
    this.page = page;
  }

  set setKeyword(String keyword) {
    this.keyword = keyword;
  }

  set setLimit(int limit) {
    this.limit = limit;
  }

  void removeFilter(String column) {
    filters?.removeWhere((filter) => filter?.column == column);
  }

  void removeSort(String column) {
    sort?.removeWhere((item) => item?.column == column);
  }

  void setIsGetAll(bool isGetAll) {
    this.isGetAll = isGetAll ? 1 : 0;
  }

  BaseQuery copyWith({
    String? keyword,
    int? page,
    int? limit,
    List<Filter?>? filters,
    List<Sort?>? sort,
  }) {
    return BaseQuery(
      keyword: keyword ?? this.keyword,
      page: page ?? this.page,
      limit: limit ?? this.limit,
      filters: filters ?? this.filters,
      sort: sort ?? this.sort,
    );
  }
}
