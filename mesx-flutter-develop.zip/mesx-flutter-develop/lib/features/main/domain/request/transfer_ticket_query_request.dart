import 'base_query.dart';

class TransferTicketQuery extends BaseQuery {
  final bool isListForDeviceReturnRequest;
  TransferTicketQuery({
    super.keyword,
    super.page,
    super.limit,
    super.filters,
    super.sort,
    this.isListForDeviceReturnRequest = false,
  });

  @override
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = super.toJson();
    if (isListForDeviceReturnRequest) {
      data['isListForDeviceReturnRequest'] = '1';
    }
    return data;
  }
}
