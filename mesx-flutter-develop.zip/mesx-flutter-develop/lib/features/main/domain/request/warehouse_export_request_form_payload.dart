import '../enum/warehouse_ticket_enum.dart';

class SupplyPayload {
  final String supplyId;
  final int quantity;

  SupplyPayload({
    required this.supplyId,
    required this.quantity,
  });

  Map<String, dynamic> toJson() {
    return {
      'supplyId': supplyId,
      'quantity': quantity,
    };
  }

  factory SupplyPayload.fromJson(Map<String, dynamic> json) {
    return SupplyPayload(
      supplyId: json['supplyId'],
      quantity: json['exportQuantity'],
    );
  }
}

class WarehouseExportRequestFormPayload {
  final String? id;
  final String? name;
  final String? description;
  final String? requestCode;
  final String? requestId;

  final WarehouseExportTicketRequestType? requestType;
  final DateTime? exportDate;
  final List<String> deviceIds;
  final List<SupplyPayload> supplies;

  WarehouseExportRequestFormPayload({
    this.id,
    this.name,
    this.description,
    this.requestCode,
    this.requestId,
    this.requestType,
    this.exportDate,
    this.deviceIds = const [],
    this.supplies = const [],
  });

  factory WarehouseExportRequestFormPayload.fromJson(
      Map<String, dynamic> json) {
    WarehouseExportTicketRequestType requestType = json['requestType'];

    bool isTransferDevice =
        requestType == WarehouseExportTicketRequestType.transferDevice;
    // bool isDeviceRequest =
    //     requestType == WarehouseExportTicketRequestType.requestDevice;

    // bool isSupplyRequest =
    //     requestType == WarehouseExportTicketRequestType.requestSupply;

    bool isSupplyRequest =
        requestType == WarehouseExportTicketRequestType.requestSupply;

    bool isDeviceReturn =
        requestType == WarehouseExportTicketRequestType.returnDevice;

    String? requestId;

    if (isTransferDevice) {
      requestId = json['transferRequest']?.id ?? '';
    } else if (isDeviceReturn) {
      requestId = json['deviceRequest']?.id ?? '';
    } else if (isSupplyRequest) {
      requestId = json['supplyRequest']?.id ?? '';
    }
    return WarehouseExportRequestFormPayload(
      id: json['id'] as String?,
      name: json['name'] as String?,
      description: json['description'] as String?,
      requestCode: json['requestCode'] as String?,
      requestId: requestId,
      requestType: json['requestType'] as WarehouseExportTicketRequestType?,
      exportDate: json['exportDate'],
      deviceIds: (json['devices'] as List<dynamic>?)
              ?.map((e) => e['deviceId'] as String)
              .toList() ??
          [],
      supplies: (json['supplies'] as List<dynamic>?)
              ?.map((e) => SupplyPayload.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'description': description,
        'requestCode': requestCode,
        'requestId': requestId,
        'requestType': requestType?.type,
        'exportDate': exportDate?.toIso8601String(),
        'deviceIds': deviceIds,
        'supplies': supplies.map((e) => e.toJson()).toList(),
      };
}
