import '../enum/warehouse_ticket_enum.dart';
import 'base_query.dart';

class WarehouseTicketListRequest extends BaseQuery {
  WarehouseTicketTypeEnum type;

  WarehouseTicketListRequest({
    required this.type,
    int? page,
    int? limit,
  }) : super(
          page: page,
          limit: limit,
        );
}
