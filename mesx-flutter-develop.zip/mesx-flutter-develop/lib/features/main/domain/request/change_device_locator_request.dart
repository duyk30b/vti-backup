class ChangeDeviceLocatorRequest {
  final String id;
  final String? areaId;
  final int factoryId;

  ChangeDeviceLocatorRequest(this.id, this.areaId, this.factoryId);

  factory ChangeDeviceLocatorRequest.fromJson(Map<String, dynamic> json) =>
      ChangeDeviceLocatorRequest(
        json['id'] as String,
        json['areaId'] as String?,
        json['factoryId'] as int,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'areaId': areaId,
        'factoryId': factoryId,
      };
}
