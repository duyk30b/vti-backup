import '../enum/warehouse_import_enum.dart';

class WarehouseImportFormRequest {
  final String? id;
  final String? code;
  final String? name;
  final int? requestType;
  final DateTime? importDate;
  final String? number;
  final String? debit;
  final String? remain;
  final String? deliver;
  final String? contractNum;
  final String? symbol;
  final String? templateNum;
  final String? note;
  final String? soNum;
  final String? poNum;
  final DateTime? date;
  final String? warehouseId;
  final String? fromFactoryId;
  final String? requestId;
  final List<WarehouseImportDeviceRequest>? devices;
  final List<WarehouseImportSupplyRequest>? supplies;

  WarehouseImportFormRequest({
    this.id,
    this.code,
    this.name,
    this.requestType,
    this.importDate,
    this.number,
    this.debit,
    this.remain,
    this.deliver,
    this.contractNum,
    this.symbol,
    this.templateNum,
    this.note,
    this.soNum,
    this.poNum,
    this.date,
    this.warehouseId,
    this.fromFactoryId,
    this.requestId,
    this.devices,
    this.supplies,
  });

  factory WarehouseImportFormRequest.fromJson(Map<String, dynamic> json) {
    String? requestId;

    final WarehouseImportType? requestType =
        json['type'] as WarehouseImportType?;

    final bool isDeviceAssign = requestType == WarehouseImportType.deviceAssign;

    final bool isReturnSupply = requestType == WarehouseImportType.returnSupply;

    if (isDeviceAssign) {
      requestId = json['deviceAssignmentRequest']?.id;
    } else if (isReturnSupply) {
      requestId = json['supplyRequest']?.id;
    }

    requestId ??= json['requestId'];

    final convertJson = {
      ...json,
      'warehouseId': json['warehouse']?.id,
      'requestId': requestId,
      'requestType': (json['type'] as WarehouseImportType).type,
    };
    return WarehouseImportFormRequest(
      id: convertJson['id'] as String?,
      code: convertJson['code'] as String?,
      name: convertJson['name'] as String?,
      requestType: convertJson['requestType'] as int?,
      importDate: convertJson['importDate'] as DateTime?,
      number: convertJson['number'] as String?,
      debit: convertJson['debit'] as String?,
      remain: convertJson['remain'] as String?,
      deliver: convertJson['deliver'] as String?,
      contractNum: convertJson['contractNum'] as String?,
      symbol: convertJson['symbol'] as String?,
      templateNum: convertJson['templateNum'] as String?,
      note: convertJson['note'] as String?,
      soNum: convertJson['soNum'] as String?,
      poNum: convertJson['poNum'] as String?,
      date: convertJson['date'] as DateTime?,
      warehouseId: convertJson['warehouseId'] as String?,
      fromFactoryId: convertJson['fromFactoryId'] as String?,
      requestId: convertJson['requestId'] as String?,
      devices: (convertJson['devices'] as List<dynamic>?)
          ?.map((e) =>
              WarehouseImportDeviceRequest.fromJson(e as Map<String, dynamic>))
          .toList(),
      supplies: (convertJson['supplies'] as List<dynamic>?)
          ?.map((e) =>
              WarehouseImportSupplyRequest.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'code': code,
        'name': name,
        'requestType': requestType,
        'importDate': importDate?.toUtc().toIso8601String(),
        'number': number,
        'debit': debit,
        'remain': remain,
        'deliver': deliver,
        'contractNum': contractNum,
        'symbol': symbol,
        'templateNum': templateNum,
        'note': note,
        'soNum': soNum,
        'poNum': poNum,
        'date': date?.toUtc().toIso8601String(),
        'warehouseId': warehouseId,
        'fromFactoryId': fromFactoryId,
        'requestId': requestId,
        'devices': devices?.map((e) => e.toJson()).toList(),
        'supplies': supplies?.map((e) => e.toJson()).toList(),
      };
}

class WarehouseImportDeviceRequest {
  final String? deviceId;
  final String? importAreaId;
  final String? color;
  final String? size;
  final num? quantity;
  final num? price;

  WarehouseImportDeviceRequest({
    this.deviceId,
    this.importAreaId,
    this.color,
    this.size,
    this.quantity,
    this.price,
  });

  factory WarehouseImportDeviceRequest.fromJson(Map<String, dynamic> json) {
    return WarehouseImportDeviceRequest(
      deviceId: json['deviceId'] as String?,
      importAreaId: json['importAreaId'] as String?,
      color: json['color'] as String?,
      size: json['size'] as String?,
      quantity: json['quantity'],
      price: num.tryParse(json['price'].toString()),
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'deviceId': deviceId,
        'importAreaId': importAreaId,
        'color': color,
        'size': size,
        'quantity': quantity,
        'price': price,
      };
}

class WarehouseImportSupplyRequest {
  final String? supplyId;
  final String? color;
  final String? size;
  final num? quantity;
  final num? price;

  WarehouseImportSupplyRequest({
    this.supplyId,
    this.color,
    this.size,
    this.quantity,
    this.price,
  });

  factory WarehouseImportSupplyRequest.fromJson(Map<String, dynamic> json) =>
      WarehouseImportSupplyRequest(
        supplyId: json['supplyId'] as String?,
        color: json['color'] as String?,
        size: json['size'] as String?,
        quantity: json['quantity'],
        price: json['price'] != null
            ? num.tryParse(json['price'].toString())
            : null,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'supplyId': supplyId,
        'color': color,
        'size': size,
        'quantity': quantity,
        'price': price,
      };
}
