class CreateRepairRequest {
  final String? name;
  final String? description;
  final int? priority;
  final String? errorTypeId;
  final String? deviceId;
  final String? accreditationJobId;

  CreateRepairRequest({
    this.name,
    this.description,
    this.priority,
    this.errorTypeId,
    this.deviceId,
    this.accreditationJobId,
  });

  factory CreateRepairRequest.fromJson(Map<String, dynamic> json) =>
      CreateRepairRequest(
        name: json['name'] as String?,
        description: json['description'] as String?,
        priority: json['priority'] as int?,
        errorTypeId: json['errorTypeId'] as String?,
        deviceId: json['deviceId'] as String?,
        accreditationJobId: json['accreditationJobId'] as String?,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'name': name,
        'description': description,
        'priority': priority,
        'errorTypeId': errorTypeId,
        'deviceId': deviceId,
        'accreditationJobId': accreditationJobId,
      };
}
