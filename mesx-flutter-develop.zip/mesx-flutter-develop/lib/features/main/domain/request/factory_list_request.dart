import 'base_query.dart';

class FactoryListRequest extends BaseQuery {
  FactoryListRequest() : super();
}
