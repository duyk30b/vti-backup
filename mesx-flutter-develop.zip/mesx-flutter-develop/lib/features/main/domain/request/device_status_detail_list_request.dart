import 'base_query.dart';

class DeviceStatusDetailListRequest {
  String? deviceStatusId;
  BaseQuery? query;

  DeviceStatusDetailListRequest({
    this.deviceStatusId,
    this.query,
  });
}
