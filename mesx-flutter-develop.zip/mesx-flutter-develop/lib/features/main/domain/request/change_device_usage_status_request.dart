class DeviceUsageStatusRequest {
  final String id;
  final int status;

  DeviceUsageStatusRequest(this.id, this.status);
}
