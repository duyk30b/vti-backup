import 'base_query.dart';

class DeviceInventoryDetailRequest extends BaseQuery {
  final String? deviceGroupId;
  final String? warehouseId;

  DeviceInventoryDetailRequest({
    super.page,
    super.limit,
    super.sort,
    this.deviceGroupId,
    this.warehouseId,
  });

  @override
  Map<String, dynamic> toJson() {
    final data = super.toJson();
    data['deviceGroupId'] = deviceGroupId;
    data['warehouseId'] = warehouseId;
    return data;
  }
}
