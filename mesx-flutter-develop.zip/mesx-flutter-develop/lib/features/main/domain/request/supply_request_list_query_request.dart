import 'base_query.dart';

class SupplyRequestListQuery extends BaseQuery {
  SupplyRequestListQuery({
    super.keyword,
    super.page,
    super.limit,
    super.filters,
    super.sort,
  });
}
