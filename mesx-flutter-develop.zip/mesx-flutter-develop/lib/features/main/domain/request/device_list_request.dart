import 'base_query.dart';

class DeviceListRequest extends BaseQuery {
  final int isMasterData;
  DeviceListRequest({
    super.filters,
    super.keyword,
    super.limit,
    super.page,
    super.sort,
    this.isMasterData = 1,
  });
}
