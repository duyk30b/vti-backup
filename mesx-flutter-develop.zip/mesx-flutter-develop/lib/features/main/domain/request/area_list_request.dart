import 'base_query.dart';

class AreaListRequest extends BaseQuery {
  AreaListRequest({int? page, int? limit}) : super(page: page, limit: limit);
}
