import '../enum/warehouse_export_enum.dart';

class WarehouseExportFormRequest {
  final String? id;
  final String? code;
  final String? name;
  final int? requestType;
  final DateTime? exportDate;
  final String? gdiNo;
  final String? number;
  final String? reason;
  final String? debit;
  final String? credit;
  final String? contractNum;
  final String? symbol;
  final String? note;
  final DateTime? date;
  final String? warehouseId;
  final int? toFactoryId;
  final String? requestId;
  final List<WarehouseExportDeviceRequest>? devices;
  final List<WarehouseExportSupplyRequest>? supplies;

  WarehouseExportFormRequest({
    this.id,
    this.code,
    this.name,
    this.requestType,
    this.exportDate,
    this.gdiNo,
    this.number,
    this.reason,
    this.debit,
    this.credit,
    this.contractNum,
    this.symbol,
    this.note,
    this.date,
    this.warehouseId,
    this.toFactoryId,
    this.requestId,
    this.devices,
    this.supplies,
  });

  factory WarehouseExportFormRequest.fromJson(Map<String, dynamic> json) {
    final WarehouseExportType requestType =
        json['requestType'] as WarehouseExportType;

    final bool isTransferTicketType =
        requestType == WarehouseExportType.transferLoan ||
            requestType == WarehouseExportType.transferRequest;
    final bool isReturnDeviceType =
        requestType == WarehouseExportType.returnDevice;

    final bool isSupplyRequestType =
        requestType == WarehouseExportType.supplyRequest;

    String? requestId;
    if (isTransferTicketType) {
      requestId = json['transferRequest']?.id ?? '';
    } else if (isReturnDeviceType) {
      requestId = json['deviceRequest']?.id ?? '';
    } else if (isSupplyRequestType) {
      requestId = json['supplyRequest']?.id ?? '';
    }
    int? toFactoryId;
    if (json['toFactoryId'] is int) {
      toFactoryId = json['toFactoryId'];
    } else if (json['toFactoryId'] is String) {
      toFactoryId = int.tryParse(json['toFactoryId']);
    }
    final convertJson = {
      ...json,
      'importAreaId': json['importArea']?.id,
      'warehouseId': json['warehouse']?.id,
      'requestId': requestId,
      'requestType': requestType.type,
      'toFactoryId': toFactoryId,
    };
    return WarehouseExportFormRequest(
      id: convertJson['id'] as String?,
      code: convertJson['code'] as String?,
      name: convertJson['name'] as String?,
      requestType: convertJson['requestType'] as int?,
      exportDate: convertJson['exportDate'] as DateTime?,
      gdiNo: convertJson['gdiNo'] as String?,
      number: convertJson['number'] as String?,
      reason: convertJson['reason'] as String?,
      debit: convertJson['debit'] as String?,
      credit: convertJson['credit'] as String?,
      contractNum: convertJson['contractNum'] as String?,
      symbol: convertJson['symbol'] as String?,
      note: convertJson['note'] as String?,
      date: convertJson['date'] as DateTime?,
      warehouseId: convertJson['warehouseId'] as String?,
      toFactoryId: convertJson['toFactoryId'] as int?,
      requestId: convertJson['requestId'] as String?,
      devices: (convertJson['devices'] as List<dynamic>?)
          ?.map((e) =>
              WarehouseExportDeviceRequest.fromJson(e as Map<String, dynamic>))
          .toList(),
      supplies: (convertJson['supplies'] as List<dynamic>?)
          ?.map((e) =>
              WarehouseExportSupplyRequest.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'code': code,
        'name': name,
        'requestType': requestType,
        'exportDate': exportDate?.toUtc().toIso8601String(),
        'gdiNo': gdiNo,
        'number': number,
        'reason': reason,
        'debit': debit,
        'credit': credit,
        'contractNum': contractNum,
        'symbol': symbol,
        'note': note,
        'date': date?.toUtc().toIso8601String(),
        'warehouseId': warehouseId,
        'toFactoryId': toFactoryId,
        'requestId': requestId,
        'devices': devices?.map((e) => e.toJson()).toList(),
        'supplies': supplies?.map((e) => e.toJson()).toList(),
      };
}

class WarehouseExportDeviceRequest {
  final String? deviceId;
  final String? color;
  final String? size;

  WarehouseExportDeviceRequest({
    this.deviceId,
    this.color,
    this.size,
  });

  factory WarehouseExportDeviceRequest.fromJson(Map<String, dynamic> json) {
    final convertJson = {
      'deviceId': json['device']?.id,
      'color': json['color'],
      'size': json['size'],
    };
    return WarehouseExportDeviceRequest(
      deviceId: convertJson['deviceId'] as String?,
      color: convertJson['color'] as String?,
      size: convertJson['size'] as String?,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'deviceId': deviceId,
        'color': color,
        'size': size,
      };
}

class WarehouseExportSupplyRequest {
  final String? supplyId;
  final String? color;
  final String? size;
  final num? quantity;

  WarehouseExportSupplyRequest({
    this.supplyId,
    this.color,
    this.size,
    this.quantity,
  });

  factory WarehouseExportSupplyRequest.fromJson(Map<String, dynamic> json) {
    final convertJson = {
      'supplyId': json['supply']?.id,
      'color': json['color'],
      'size': json['size'],
      'quantity': json['exportQuantity'],
    };
    return WarehouseExportSupplyRequest(
      supplyId: convertJson['supplyId'] as String?,
      color: convertJson['color'] as String?,
      size: convertJson['size'] as String?,
      quantity: num.tryParse(convertJson['quantity'].toString()),
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'supplyId': supplyId,
        'color': color,
        'size': size,
        'quantity': num.tryParse(quantity.toString()),
      };
}
