class GetStockSupplyByWarehouseRequest {
  final String supplyId;
  final String warehouseId;
  final String? supplyRequestId;
  final int? type;

  GetStockSupplyByWarehouseRequest(
    this.supplyId,
    this.warehouseId, {
    this.supplyRequestId,
    this.type,
  });

  Map<String, dynamic> toJson() {
    return {
      ...(supplyRequestId != null) ? {'supplyRequestId': supplyRequestId} : {},
      ...(type != null) ? {'type': type} : {},
    };
  }
}
