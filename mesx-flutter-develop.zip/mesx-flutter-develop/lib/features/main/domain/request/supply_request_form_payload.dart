import '../model/job.dart';
import '../model/supply.dart';
import '../model/warehouse.dart';

class SupplyRequestFormPayload {
  final String? id;
  final String? name;
  final String? description;
  final int? factoryId;
  final List<String> jobIds;
  final String? warehouseId;
  final int? type;
  final List<SupplyPayload>? supplies;
  final DateTime? expectDate;

  SupplyRequestFormPayload({
    this.id,
    this.name,
    this.description,
    this.factoryId,
    this.jobIds = const [],
    this.warehouseId,
    this.type,
    this.supplies,
    this.expectDate,
  });

  factory SupplyRequestFormPayload.fromJson(Map<String, dynamic> json) {
    final Job? job = json['jobs'] as Job?;
    return SupplyRequestFormPayload(
      id: json['id'] as String?,
      name: json['name'] as String?,
      description: json['description'] as String?,
      factoryId: (json['warehouse'] as Warehouse?)?.factory?.id,
      jobIds: job == null ? [] : [job.id ?? ''],
      warehouseId: (json['warehouse'] as Warehouse?)?.id,
      type: 0,
      supplies: (json['supplies'] as List<dynamic>?)
          ?.map((e) => SupplyPayload.fromJson(e as Map<String, dynamic>))
          .toList(),
      expectDate: json['expectDate'],
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'description': description,
        'factoryId': factoryId,
        'jobIds': jobIds,
        'warehouseId': warehouseId,
        'type': type,
        'supplies': supplies?.map((e) => e.toJson()).toList(),
        'expectDate': expectDate?.toIso8601String(),
      };
}

class SupplyPayload {
  final String? supplyId;
  final int? quantity;

  SupplyPayload({this.quantity, this.supplyId});

  factory SupplyPayload.fromJson(Map<String, dynamic> json) => SupplyPayload(
        quantity: json['quantity'] as int?,
        supplyId: (json['supply'] as Supply?)?.id,
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'supplyId': supplyId,
        'quantity': quantity,
      };
}
