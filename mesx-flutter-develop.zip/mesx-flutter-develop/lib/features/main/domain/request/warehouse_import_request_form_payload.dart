// ignore_for_file: public_member_api_docs, sort_constructors_first
import '../enum/warehouse_ticket_enum.dart';
import '../model/factory_info.dart';
import '../model/warehouse.dart';

class DeviceGroupPayload {
  final String deviceGroupId;
  final int quantity;

  DeviceGroupPayload({
    required this.deviceGroupId,
    required this.quantity,
  });

  Map<String, dynamic> toJson() {
    return {
      'deviceGroupId': deviceGroupId,
      'quantity': quantity,
    };
  }

  factory DeviceGroupPayload.fromJson(Map<String, dynamic> json) {
    return DeviceGroupPayload(
      deviceGroupId: json['deviceGroupId'],
      quantity: json['quantity'],
    );
  }
}

class SupplyPayload {
  final String supplyId;
  final int quantity;

  SupplyPayload({
    required this.supplyId,
    required this.quantity,
  });

  Map<String, dynamic> toJson() {
    return {
      'supplyId': supplyId,
      'quantity': quantity,
    };
  }

  factory SupplyPayload.fromJson(Map<String, dynamic> json) {
    return SupplyPayload(
      supplyId: json['supplyId'],
      quantity: json['importQuantity'],
    );
  }
}

class WarehouseImportRequestFormPayload {
  final String? id;
  final String? name;
  final String? description;
  final String? requestCode;
  final String? requestId;
  final int? toFactoryId;
  final String? warehouseId;
  final WarehouseImportTicketRequestType? requestType;
  final DateTime? importDate;
  final List<String> deviceIds;
  final List<DeviceGroupPayload> deviceGroups;
  final List<SupplyPayload> supplies;

  WarehouseImportRequestFormPayload({
    this.id,
    this.name,
    this.description,
    this.requestCode,
    this.requestId,
    this.warehouseId,
    this.requestType,
    this.toFactoryId,
    this.importDate,
    this.deviceIds = const [],
    this.deviceGroups = const [],
    this.supplies = const [],
  });

  factory WarehouseImportRequestFormPayload.fromJson(
      Map<String, dynamic> json) {
    WarehouseImportTicketRequestType requestType = json['requestType'];

    bool isTransferDevice =
        requestType == WarehouseImportTicketRequestType.transferDevice;
    // bool isDeviceRequest =
    //     requestType == WarehouseImportTicketRequestType.requestDevice;

    // bool isSupplyRequest =
    //     requestType == WarehouseImportTicketRequestType.requestSupply;

    bool isSupplyReturn =
        requestType == WarehouseImportTicketRequestType.returnSupply;

    bool isDeviceReturn =
        requestType == WarehouseImportTicketRequestType.returnDevice;

    String? requestId;

    if (isTransferDevice) {
      requestId = json['transferRequest']?.id ?? '';
    } else if (isDeviceReturn) {
      requestId = json['deviceRequest']?.id ?? '';
    } else if (isSupplyReturn) {
      requestId = json['supplyRequest']?.id ?? '';
    }
    return WarehouseImportRequestFormPayload(
      id: json['id'] as String?,
      name: json['name'] as String?,
      description: json['description'] as String?,
      requestCode: json['requestCode'] as String?,
      requestId: requestId,
      warehouseId: (json['warehouse'] as Warehouse?)?.id,
      requestType: json['requestType'] as WarehouseImportTicketRequestType?,
      importDate: json['importDate'],
      toFactoryId: (json['toFactory'] as FactoryInfo?)?.id,
      deviceIds: (json['devices'] as List<dynamic>?)
              ?.map((e) => e['deviceId'] as String)
              .toList() ??
          [],
      deviceGroups: (json['deviceGroups'] as List<dynamic>?)
              ?.map(
                  (e) => DeviceGroupPayload.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
      supplies: (json['supplies'] as List<dynamic>?)
              ?.map((e) => SupplyPayload.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name': name,
        'description': description,
        'requestCode': requestCode,
        'requestId': requestId,
        'warehouseId': warehouseId,
        'toFactoryId': toFactoryId,
        'requestType': requestType?.type,
        'importDate': importDate?.toIso8601String(),
        'deviceIds': deviceIds,
        'deviceGroups': deviceGroups.map((e) => e.toJson()).toList(),
        'supplies': supplies.map((e) => e.toJson()).toList(),
      };
}
