class NotificationListRequest {
  final int limit;
  final int page;
  final String type;

  NotificationListRequest(this.limit, this.page, this.type);
}
