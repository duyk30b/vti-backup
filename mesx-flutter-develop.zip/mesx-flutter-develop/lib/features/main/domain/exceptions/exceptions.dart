class ApiException {
  final int? statusCode;
  final String? message;
  final dynamic data;
  final dynamic extra;

  ApiException({
    this.statusCode,
    this.message,
    this.data,
    this.extra,
  });
}

enum ApiExceptionType {
  other('');

  final String? code;

  const ApiExceptionType(this.code);

  static ApiExceptionType fromCode(String code) {
    for (final element in ApiExceptionType.values) {
      if (element.code == code) {
        return element;
      }
    }
    return ApiExceptionType.other;
  }
}
