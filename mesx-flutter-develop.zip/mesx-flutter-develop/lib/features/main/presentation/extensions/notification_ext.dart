import 'package:flutter/material.dart';

import '../../../routes.dart';
import '../../domain/model/notification_info.dart';
import '../../domain/model/payload.dart';
import '../ui/task/task_page.dart';

extension NotificationEntityEnumExtension on NotificationInfo {
  Future<void> redirectTo(BuildContext context, String id) async {
    final entity = notificationId.payload.entity;

    switch (entity) {
      case NotificationEntityEnum.deviceRequestDetail:
        return;
      case NotificationEntityEnum.deviceAssignDetail:
        return;
      case NotificationEntityEnum.jobList:
        await Navigator.pushNamed(context, Routes.jobDetail.path, arguments: {
          'id': id,
          'type': JobTabs.generalJob,
        });
        return;
      case NotificationEntityEnum.jobDetail:
        await Navigator.pushNamed(context, Routes.jobDetail.path, arguments: {
          'id': id,
          'type': JobTabs.generalJob,
        });
        return;

      case NotificationEntityEnum.repairRequestDetail:
        await Navigator.pushNamed(context, Routes.repairRequestForm.path,
            arguments: {
              'requestId': id,
            });
        return;
      case NotificationEntityEnum.warningSystem:
        return;
    }
  }
}
