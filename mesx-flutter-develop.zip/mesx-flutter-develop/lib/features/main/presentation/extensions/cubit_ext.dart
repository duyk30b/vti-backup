import 'package:dio/dio.dart';

import '../../../../core/core.dart';
import '../../../../core/pop_up/pop_up_event.dart';
import '../../../../generated/l10n.dart';
import 'dio_error_ext.dart';

extension CubitExt on BaseCubit {
  void handleException(Exception exception) {
    if (exception is DioError) {
      emitNewEvent(ToastEvent.error(exception.toApiException().message ?? ''));
      return;
    }
    emitNewEvent(ToastEvent.error(exception.toString()));
    return;
  }

  void showPopUpException(Exception exception, {String? message}) {
    if (exception is DioError) {
      emitNewEvent(PopUpMsgEvent.failed(exception.toApiException().message ??
          BS.current.something_went_wrong));
      return;
    }
    if (message != null) {
      emitNewEvent(PopUpMsgEvent.failed(message));
      return;
    }

    emitNewEvent(PopUpMsgEvent.failed(exception.toString()));
    return;
  }

  void showException(Exception exception) {
    if (exception is DioError) {
      showError(exception.toApiException().message ??
          BS.current.something_went_wrong);
      return;
    }
    showError(exception.toString());
    return;
  }
}
