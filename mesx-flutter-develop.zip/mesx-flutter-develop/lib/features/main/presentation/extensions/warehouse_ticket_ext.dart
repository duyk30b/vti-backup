import '../../domain/model/warehouse_ticket/warehouse_ticket_device.dart';
import '../../domain/model/warehouse_ticket/warehouse_ticket_supply.dart';

extension WarehouseTicketDeviceExt on WarehouseTicketDevice {
  Map<String, dynamic> toWarehouseImportTicketDeviceForm() {
    return {
      'area': area,
      'areaName': area?.name,
      'device': this,
      'deviceId': id,
      'deviceName': name,
      'name': name,
      'identificationNo': identificationNo,
      'serial': serial,
      'deviceGroup': deviceGroup,
      'deviceGroupId': deviceGroup?.id,
      'deviceGroupName': deviceGroup?.name,
      'unit': unit,
      'warehouse': warehouse,
      'warehouseName': warehouse?.name,
      'color': color,
      'size': size,
      'price': price,
    };
  }

  Map<String, dynamic> toWarehouseExportTicketDeviceForm() {
    return {
      'area': area,
      'areaName': area?.name,
      'device': this,
      'deviceId': id,
      'deviceName': name,
      'name': name,
      'identificationNo': identificationNo,
      'serial': serial,
      'deviceGroup': deviceGroup,
      'deviceGroupId': deviceGroup?.id,
      'deviceGroupName': deviceGroup?.name,
      'unit': unit,
      'warehouse': warehouse,
      'warehouseName': warehouse?.name,
      'color': color,
      'size': size,
      'price': price,
    };
  }
}

extension WarehouseTicketSupplyExt on WarehouseTicketSupply {
  Map<String, dynamic> toWarehouseImportTicketSupplyForm() {
    int remainQuantity = (requestQuantity ?? 0) - (importedQuantity ?? 0);
    num intoMoney = (price ?? 0) * (importQuantity ?? 0);
    return {
      'supply': this,
      'supplyId': id,
      'supplyGroupName': supplyGroup?.name,
      'code': code,
      'name': name,
      'unit': unit,
      'unitName': unit?.name,
      'color': color,
      'size': size,
      'intoMoney': intoMoney,
      'price': price,
      'importQuantity': importQuantity,
      'requestQuantity': requestQuantity,
      'importedQuantity': importedQuantity,
      'importQuantityRemain': remainQuantity > 0 ? remainQuantity : 0,
      'quantity': importQuantity
    };
  }

  Map<String, dynamic> toWarehouseExportTicketSupplyForm() {
    int remainQuantity = (requestQuantity ?? 0) - (exportedQuantity ?? 0);
    return {
      'supply': this,
      'supplyId': id,
      'supplyGroupName': supplyGroup?.name,
      'code': code,
      'name': name,
      'unit': unit,
      'unitName': unit?.name,
      'color': color,
      'size': size,
      'exportQuantity': exportQuantity,
      'requestQuantity': requestQuantity,
      'exportedQuantity': exportedQuantity,
      'exportQuantityRemain': remainQuantity > 0 ? remainQuantity : 0,
      'quantity': exportQuantity
    };
  }
}
