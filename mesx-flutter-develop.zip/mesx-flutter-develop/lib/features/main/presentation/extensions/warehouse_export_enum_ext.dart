import 'package:flutter/material.dart';
import '../../../../core/configs/app_colors.dart';

import '../../../../generated/l10n.dart';
import '../../domain/enum/warehouse_export_enum.dart';

extension WarehouseExportStatusExt on WarehouseExportStatus {
  String toLabel() {
    switch (this) {
      case WarehouseExportStatus.pending:
        return BS.current.pending;
      case WarehouseExportStatus.confirmed:
        return BS.current.confirm;
      case WarehouseExportStatus.rejected:
        return BS.current.rejected;
    }
  }

  Color toColor() {
    switch (this) {
      case WarehouseExportStatus.pending:
        return AppColors.statusPending;
      case WarehouseExportStatus.confirmed:
        return AppColors.statusSuccess;
      case WarehouseExportStatus.rejected:
        return AppColors.statusReject;
    }
  }
}

extension WarehouseImportTypeExt on WarehouseExportType {
  String toLabel() {
    switch (this) {
      case WarehouseExportType.transferRequest:
        return BS.current.transfer_asset;
      case WarehouseExportType.transferLoan:
        return BS.current.transfer_borrow;
      case WarehouseExportType.supplyRequest:
        return BS.current.request_supply;
      case WarehouseExportType.returnDevice:
        return BS.current.request_return_device;
    }
  }
}
