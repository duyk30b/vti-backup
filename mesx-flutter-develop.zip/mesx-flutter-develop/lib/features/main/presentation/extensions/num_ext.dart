extension NumExt on num? {
  String get priceStr {
    if (this != null) {
      return this!.toStringAsFixed(0).replaceAllMapped(
          RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},');
    } else {
      return '';
    }
  }
}
