import 'package:flutter/widgets.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';

import '../../../../core/logger/app_logger.dart';
import '../../../../core/pop_up/pop_up_helper.dart';
import '../../../../generated/assets/assets.gen.dart';
import '../../../../generated/l10n.dart';
import '../widget/form_control/array_form_builder.dart';

typedef FormBuilderValue = Map<String, dynamic>;

extension FormBuilderStateExt on GlobalKey<FormBuilderState> {
  Map<String, FormBuilderFieldState<FormBuilderField<dynamic>, dynamic>>
      get fields => currentState?.fields ?? {};

  FormBuilderValue get value => currentState?.value ?? {};

  FormBuilderFieldState? field(String key) {
    return fields[key];
  }

  ArrayFormBuilderState? arrayField(String key) {
    return fields[key] as ArrayFormBuilderState?;
  }

  void setFieldValue<T>(String key, T value) {
    try {
      fields[key]?.didChange(value);
    } catch (e) {
      AppLogger.log(e.toString());
    }
  }

  void reset() {
    if (currentState == null) {
      return;
    }
    currentState!.reset();
  }

  void save() {
    currentState?.save();
  }

  bool saveAndValidate() {
    if (currentState == null) {
      return false;
    }
    return currentState!.saveAndValidate();
  }

  bool validate() {
    if (currentState == null) {
      return false;
    }
    return currentState!.validate();
  }

  void setInternalFieldValue(String key, dynamic value,
      {bool isSetState = false}) {
    currentState?.setInternalFieldValue(
      key,
      value,
      isSetState: isSetState,
    );
  }

  T? getFieldValue<T>(String key) {
    return currentState?.getRawValue(key);
  }

  String getFirstError() {
    if (fields.values.isEmpty) {
      return '';
    }

    fields.values.where((element) => element.hasError).toList();
    return fields.values
            .where((element) => element.hasError)
            .map((e) => e.errorText)
            .first ??
        '';
  }

  void handleSubmitForm(
    BuildContext context, {
    String? message,
    String? title,
    required Function onSubmit,
    bool withValidate = true,
    bool isShowFistError = true,
  }) {
    title ??= BS.current.confirm;
    if (withValidate && !saveAndValidate()) {
      if (isShowFistError) {
        PopUpHelper.showDialogMessage(
          context,
          getFirstError(),
          icon: Assets.images.svgIcon.icMessageError.svg(),
        );
      }
      return;
    }
    PopUpHelper.showDialogConfirm(
      context,
      title: title,
      message: message,
      cancelText: BS.current.cancel_action,
      onChanged: (value) {
        onSubmit();
      },
    );
  }

  void handleCancelForm(BuildContext context,
      {String? message,
      String? title,
      required Function onCancel,
      bool isShowPopUp = true}) {
    title ??= BS.current.confirm_exit_without_save;
    if (isShowPopUp) {
      PopUpHelper.showDialogConfirm(
        context,
        title: title,
        message: message,
        cancelText: BS.current.cancel_action,
        onChanged: (value) {
          onCancel();
        },
      );
    } else {
      onCancel();
    }
  }
}
