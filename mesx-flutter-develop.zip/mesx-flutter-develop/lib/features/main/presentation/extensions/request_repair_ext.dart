import 'package:flutter/material.dart';
import '../../../../core/configs/app_colors.dart';
import '../../../../generated/assets/assets.gen.dart';

import '../../../../generated/l10n.dart';
import '../../domain/enum/repair_request_status.dart';

extension RepairRequestStatusEnumExt on RepairRequestStatusEnum? {
  String toLabel() {
    if (this == null) {
      return '';
    }
    switch (this!) {
      case RepairRequestStatusEnum.all:
        return BS.current.all;
      case RepairRequestStatusEnum.pending:
        return BS.current.pending;
      case RepairRequestStatusEnum.confirm:
        return BS.current.confirm;
      case RepairRequestStatusEnum.inProgress:
        return BS.current.inProgress;
      case RepairRequestStatusEnum.rejected:
        return BS.current.rejected;
      case RepairRequestStatusEnum.completed:
        return BS.current.completed;
      case RepairRequestStatusEnum.done:
        return BS.current.done;
    }
  }

  Widget toIcon() {
    if (this == null) {
      return Container();
    }
    switch (this!) {
      case RepairRequestStatusEnum.all:
        return Container();
      case RepairRequestStatusEnum.pending:
        return Assets.images.svgIcon.icPending.svg();
      case RepairRequestStatusEnum.confirm:
        return Assets.images.svgIcon.icConfirmRequest.svg();
      case RepairRequestStatusEnum.inProgress:
        return Assets.images.svgIcon.icInProgress.svg();
      case RepairRequestStatusEnum.rejected:
        return Assets.images.svgIcon.icRejectRequest.svg();
      case RepairRequestStatusEnum.completed:
        return Assets.images.svgIcon.icCompletedRequest.svg();
      case RepairRequestStatusEnum.done:
        return Assets.images.svgIcon.icDoneRequest.svg();
    }
  }

  Color toColor() {
    if (this == null) {
      return Colors.transparent;
    }
    switch (this!) {
      case RepairRequestStatusEnum.all:
        return Colors.transparent;
      case RepairRequestStatusEnum.pending:
        return AppColors.statusPending;
      case RepairRequestStatusEnum.confirm:
        return AppColors.greenConfirm;
      case RepairRequestStatusEnum.inProgress:
        return AppColors.mainBlue;
      case RepairRequestStatusEnum.rejected:
        return AppColors.statusReject;
      case RepairRequestStatusEnum.completed:
        return AppColors.greenConfirm;
      case RepairRequestStatusEnum.done:
        return AppColors.greenConfirm;
    }
  }
}

List<RepairRequestStatusEnum> getFilterRequestRepairStatus() {
  return [
    RepairRequestStatusEnum.all,
    RepairRequestStatusEnum.pending,
    RepairRequestStatusEnum.confirm,
    RepairRequestStatusEnum.inProgress,
    RepairRequestStatusEnum.rejected,
    RepairRequestStatusEnum.completed,
    RepairRequestStatusEnum.done,
  ];
}

extension RepairRequestPriorityEnumExt on RepairRequestPriorityEnum? {
  String toLabel() {
    if (this == null) {
      return '';
    }
    switch (this!) {
      case RepairRequestPriorityEnum.low:
        return BS.current.low;
      case RepairRequestPriorityEnum.medium:
        return BS.current.medium;
      case RepairRequestPriorityEnum.high:
        return BS.current.high;
    }
  }
}
