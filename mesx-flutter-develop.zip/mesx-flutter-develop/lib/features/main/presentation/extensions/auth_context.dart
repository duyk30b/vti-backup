import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../data/network/mapper/factory_list_mapper.dart';
import '../../data/network/model/user_info_dto.dart';
import '../../domain/enum/user_enum.dart';
import '../../domain/model/factory_info.dart';
import '../ui/setting/setting_cubit.dart';

extension AuthContext on BuildContext {
  SettingCubit get cubit => read<SettingCubit>();

  UserInfoDTO? get user {
    return cubit.state.value.user;
  }

  bool get isAdmin => user?.role == UserRole.admin.code;

  bool get isLeader => user?.role == UserRole.leader.code;

  bool get isManager => user?.role == UserRole.factoryManager.code;

  bool get isMember => user?.role == UserRole.member.code;

  int? get factoryId => user?.factoryId;

  FactoryInfo? get myFactory {
    if (factoryId == null) return null;
    if (factories.isEmpty) return null;
    return factories.firstWhere((element) => element.id == factoryId);
  }

  List<FactoryInfo> get factories =>
      user?.factories
          ?.map((e) => FactoryListMapperImpl().fromFactoryDTO(e))
          .toList() ??
      [];
}
