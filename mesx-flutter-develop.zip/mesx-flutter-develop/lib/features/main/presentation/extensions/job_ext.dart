import '../../../../generated/l10n.dart';
import '../../domain/enum/job_enum.dart';

extension JobTypeEnumExt on JobTypeEnum {
  String toLabel() {
    switch (this) {
      case JobTypeEnum.maintenance:
        return BS.current.maintenance;
      case JobTypeEnum.repair:
        return BS.current.repair;
      case JobTypeEnum.accreditation:
        return BS.current.accreditation;
      case JobTypeEnum.install:
        return BS.current.install;
      case JobTypeEnum.check:
        return BS.current.periodic_check;
    }
  }
}
