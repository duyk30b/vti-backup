import 'package:flutter/material.dart';
import '../../../../core/configs/app_colors.dart';
import '../../../../generated/l10n.dart';

import '../../domain/enum/device_status.dart';

extension DeviceStatusTypeExt on DeviceStatusType {
  String toLabel() {
    switch (this) {
      case DeviceStatusType.all:
        return BS.current.all;
      case DeviceStatusType.online:
        return BS.current.online;
      case DeviceStatusType.offline:
        return BS.current.offline;
      case DeviceStatusType.pause:
        return BS.current.pause;
      case DeviceStatusType.error:
        return BS.current.error;
    }
  }

  Color toColor() {
    switch (this) {
      case DeviceStatusType.all:
        return AppColors.statusSuccess;
      case DeviceStatusType.online:
        return AppColors.statusSuccess;
      case DeviceStatusType.offline:
        return AppColors.statusReject;
      case DeviceStatusType.pause:
        return AppColors.statusPending;
      case DeviceStatusType.error:
        return AppColors.statusError;
    }
  }
}
