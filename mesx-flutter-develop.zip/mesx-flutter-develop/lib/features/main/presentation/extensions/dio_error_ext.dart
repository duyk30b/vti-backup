import 'dart:io';

import 'package:dio/dio.dart';

import '../../domain/exceptions/exceptions.dart';

extension DioErrorExt on DioError {
  ApiException toApiException() {
    switch (type) {
      case DioErrorType.connectTimeout:
        return ApiException(message: 'connectTimeout');
      case DioErrorType.sendTimeout:
        return ApiException(message: 'sendTimeout');

      case DioErrorType.receiveTimeout:
        return ApiException(message: 'receiveTimeout');
      case DioErrorType.response:
        {
          final responseMap = response?.data as Map<dynamic, dynamic>;
          return ApiException(
            statusCode: responseMap['statusCode'],
            message: responseMap['message'],
            data: responseMap['data'],
          );
        }
      case DioErrorType.cancel:
        return ApiException(message: 'cancel');
      case DioErrorType.other:
        {
          if (response?.data == null) {
            return ApiException(message: (error as SocketException).message);
          }
          final responseMap = response?.data as Map<dynamic, dynamic>;
          return ApiException(
            statusCode: responseMap['statusCode'],
            message: responseMap['message'],
            data: responseMap['data'],
          );
        }
    }
  }
}
