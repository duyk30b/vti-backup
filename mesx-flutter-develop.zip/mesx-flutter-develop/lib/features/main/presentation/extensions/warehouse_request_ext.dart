import '../../domain/model/device_detail.dart';
import '../../domain/model/warehouse_request/warehouse_request_device_group.dart';
import '../../domain/model/warehouse_request/warehouse_request_supply.dart';

extension WarehouseRequestSupplyExt on WarehouseRequestSupply {
  Map<String, dynamic> toWarehouseImportRequestSupplyForm() {
    final importQuantityRemain =
        (requestQuantity ?? 0) - (importPlannedQuantity ?? 0);
    return {
      'supply': this,
      'supplyId': id,
      'name': name,
      'code': code,
      'quantity': quantity,
      'requestQuantity': requestQuantity,
      'importQuantity': importQuantity,
      'importedQuantity': importedQuantity,
      'unitName': unit?.name,
      'supplyGroupName': supplyGroup?.name,
      'supplyType': supplyType?.name,
      'vendorName': vendor?.name,
      'importQuantityRemain': importQuantityRemain,
    };
  }

  Map<String, dynamic> toWarehouseExportRequestSupplyForm() {
    final importQuantityRemain =
        (requestQuantity ?? 0) - (exportedQuantity ?? 0);
    return {
      'supply': this,
      'supplyId': id,
      'name': name,
      'code': code,
      'quantity': quantity,
      'requestQuantity': requestQuantity,
      'exportQuantity': exportQuantity,
      'exportedQuantity': exportedQuantity,
      'unitName': unit?.name,
      'supplyGroupName': supplyGroup?.name,
      'supplyType': supplyType?.name,
      'vendorName': vendor?.name,
      'exportQuantityRemain': importQuantityRemain,
    };
  }
}

extension WarehouseRequestDeviceExt on DeviceDetail {
  Map<String, dynamic> toWarehouseImportRequestDeviceForm() {
    return {
      'device': this,
      'deviceId': id,
      'deviceGroupName': deviceGroup?.name,
      'deviceGroupId': deviceGroup?.id,
      'name': name,
      'serial': serial,
      'identificationNo': identificationNo,
      'warehouse': warehouse,
      'warehouseName': warehouse?.name,
    };
  }

  Map<String, dynamic> toWarehouseExportRequestDeviceForm() {
    return {
      'device': this,
      'deviceId': id,
      'deviceGroupName': deviceGroup?.name,
      'deviceGroupId': deviceGroup?.id,
      'name': name,
      'serial': serial,
      'identificationNo': identificationNo,
      'warehouse': warehouse,
      'warehouseName': warehouse?.name,
    };
  }
}

extension WarehouseRequestDeviceGroupExt on WarehouseRequestDeviceGroup {
  Map<String, dynamic> toWarehouseImportRequestDeviceGroupForm() {
    return {
      'deviceGroup': this,
      'deviceGroupId': id,
      'deviceGroupName': name,
      'groupCode': code,
      'quantity': quantity,
    };
  }
}
