import 'package:flutter/material.dart';
import '../../../../core/configs/app_colors.dart';
import '../../../../generated/assets/assets.gen.dart';
import '../../../../generated/l10n.dart';
import '../../domain/enum/supply_request_enum.dart';

extension SupplyRequestStatusExt on SupplyRequestStatus {
  String toLabel() {
    switch (this) {
      case SupplyRequestStatus.all:
        return BS.current.all;
      case SupplyRequestStatus.waiting:
        return BS.current.waiting;
      case SupplyRequestStatus.reject:
        return BS.current.reject;
      case SupplyRequestStatus.confirm:
        return BS.current.confirm;
      case SupplyRequestStatus.complete:
        return BS.current.complete;
      case SupplyRequestStatus.awaitReturn:
        return BS.current.awaitReturn;
    }
  }

  Color toColor() {
    switch (this) {
      case SupplyRequestStatus.all:
        return AppColors.statusSuccess;
      case SupplyRequestStatus.waiting:
        return AppColors.vtptRequestWaiting;
      case SupplyRequestStatus.reject:
        return AppColors.vtptRequestReject;
      case SupplyRequestStatus.confirm:
        return AppColors.vtptRequestConfirm;
      case SupplyRequestStatus.complete:
        return AppColors.vtptRequestComplete;
      case SupplyRequestStatus.awaitReturn:
        return AppColors.vtptRequestAwaitReturn;
    }
  }

  Widget toIcon() {
    switch (this) {
      case SupplyRequestStatus.all:
        return Assets.images.svgIcon.icTask.svg();
      case SupplyRequestStatus.waiting:
        return Assets.images.svgIcon.icWaitingStatus.svg();
      case SupplyRequestStatus.reject:
        return Assets.images.svgIcon.icRejectStatus.svg();
      case SupplyRequestStatus.confirm:
        return Assets.images.svgIcon.icConfirmStatus.svg();
      case SupplyRequestStatus.complete:
        return Assets.images.svgIcon.icCompleteStatus.svg();
      case SupplyRequestStatus.awaitReturn:
        return Assets.images.svgIcon.icAwaitReturnStatus.svg();
    }
  }
}
