import 'package:flutter/material.dart';
import '../../../../core/configs/app_colors.dart';

import '../../../../generated/l10n.dart';
import '../../domain/enum/warehouse_import_enum.dart';

extension WarehouseImportStatusExt on WarehouseImportStatus {
  String toLabel() {
    switch (this) {
      case WarehouseImportStatus.pending:
        return BS.current.pending;
      case WarehouseImportStatus.confirmed:
        return BS.current.confirm;
      case WarehouseImportStatus.rejected:
        return BS.current.rejected;
    }
  }

  Color toColor() {
    switch (this) {
      case WarehouseImportStatus.pending:
        return AppColors.statusPending;
      case WarehouseImportStatus.confirmed:
        return AppColors.statusSuccess;
      case WarehouseImportStatus.rejected:
        return AppColors.statusReject;
    }
  }
}

extension WarehouseImportTypeExt on WarehouseImportType {
  String toLabel() {
    switch (this) {
      case WarehouseImportType.deviceAssign:
        return BS.current.assignment_device;
      case WarehouseImportType.returnSupply:
        return BS.current.request_return_supply;
      case WarehouseImportType.requestSupply:
        return BS.current.supply_buy_request;
    }
  }
}
