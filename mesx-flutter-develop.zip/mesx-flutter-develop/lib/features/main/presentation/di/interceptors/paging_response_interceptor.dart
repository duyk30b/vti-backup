import 'package:dio/dio.dart';

class PagingResponseInterceptor extends Interceptor {
  @override
  void onResponse(Response response, ResponseInterceptorHandler handler) {
    if (response.data is Map) {
      final responseData = response.data as Map;
      final data = responseData['data'];
      if (data is Map) {
        if (data.containsKey('items') && data.containsKey('meta')) {
          final items = data['items'];
          final meta = data['meta'];
          responseData['data'] = items;
          responseData['meta'] = meta;
        }
      }
    }
    super.onResponse(response, handler);
  }
}
