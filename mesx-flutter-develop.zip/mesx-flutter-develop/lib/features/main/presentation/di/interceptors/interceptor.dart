import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../../../data/cache/cache_manager.dart';

class HandleExceptionInterceptor extends InterceptorsWrapper {
  @override
  void onResponse(Response response, ResponseInterceptorHandler handler) {
    if (response.data is Map) {
      //Regex to check if status code is 4xx or 5xx
      final failedStatus = RegExp(r'^[45]\d{2}$');

      final isFailed =
          response.data['statusCode'].toString().startsWith(failedStatus);

      if (isFailed) {
        return handler.reject(
          DioError(
            requestOptions: response.requestOptions,
            response: response,
            error: DioErrorType.response,
          ),
        );
      }
    }

    return super.onResponse(response, handler);
  }
}

class HandleTokenInterceptor extends InterceptorsWrapper {
  final CacheManager helper;

  HandleTokenInterceptor(this.helper);

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    final token = helper.getUserToken();
    if (token != null && options.headers['Authorization'] == null) {
      debugPrint('Bearer $token');
      options.headers['Authorization'] = 'Bearer $token';
    }

    String appLanguage = helper.getSettingAppLanguage();
    if (appLanguage == 'ja') {
      appLanguage = 'jp';
    }
    options.headers['Lang'] = appLanguage;
    super.onRequest(options, handler);
  }
}
