import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../../../../../core/core.dart';
import '../../../../../core/navigation/navigator_helper.dart';
import '../../../../../generated/l10n.dart';
import '../../../../flavor.dart';
import '../../../../routes.dart';
import '../../../data/cache/cache_manager.dart';
import '../../../data/network/response/login_response.dart';

class RefreshTokenInterceptor extends Interceptor {
  RefreshTokenInterceptor({
    required this.dio,
    required this.cacheManager,
  });

  final Dio dio;
  final CacheManager cacheManager;
  String get baseUrl => AppConfig.shared.baseUrl;

  final String _refreshTokenPath = 'v1/auth/token/refresh';
  final String _loginApiPath = 'v1/auth/login';

  final int _tokenExpiredStatusCode = 403;
  bool _redirectToLogin = false;

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    if (options.path.contains(_loginApiPath)) {
      _redirectToLogin = false;
    }
    super.onRequest(options, handler);
  }

  @override
  Future<void> onError(
    final DioError err,
    final ErrorInterceptorHandler handler,
  ) async {
    final requestOptions = err.requestOptions;
    final isRefreshRequest = requestOptions.path.contains(_refreshTokenPath);
    final isRetryApi = requestOptions.extra['isRetryRequest'] ?? false;

    if (err.response?.statusCode != _tokenExpiredStatusCode ||
        isRefreshRequest ||
        isRetryApi) {
      handler.next(err);
      return;
    }

    try {
      await _handleRefreshToken(
        err,
        handler,
      );
      final response = await _handleRetryApi(err, handler);
      handler.resolve(response);
    } catch (e) {
      handler.next(err);
      if (_redirectToLogin) return;
      _redirectToLogin = true;

      cacheManager.saveUserToken(null);
      cacheManager.saveRefreshToken(null);

      await NavigatorHelper.pushNamedAndRemoveUntil(
        Routes.login.path,
        (route) => false,
        arguments: ToastEvent.normal(BS.current.session_expired),
      );
    }
  }

  Future<void> _handleRefreshToken(
    final DioError err,
    ErrorInterceptorHandler handler,
  ) async {
    final path = '$baseUrl$_refreshTokenPath';
    final refreshToken = cacheManager.getRefreshToken();

    final requestOptions = err.requestOptions;
    requestOptions.headers['Authorization'] = 'Bearer $refreshToken';

    final opts = Options(
      headers: requestOptions.headers,
      extra: requestOptions.extra,
    );

    final response = await dio.get(path, options: opts);
    final data = LoginResponse.fromJson(response.data!).data;

    final newToken = data.accessToken.token;
    final newRefreshToken = data.refreshToken.token;

    cacheManager.saveUserToken(newToken);
    cacheManager.saveRefreshToken(newRefreshToken);
    cacheManager.saveUserInFo(data.userInfo);

    debugPrint('Refreshed token: $newToken');
  }

  Future<Response> _handleRetryApi(
    final DioError err,
    ErrorInterceptorHandler handler,
  ) async {
    final requestOptions = err.requestOptions;
    requestOptions.extra['isRetryRequest'] = true;

    final token = cacheManager.getUserToken();
    if (token != null) {
      requestOptions.headers['Authorization'] = 'Bearer $token';
    }

    final opts = Options(
      method: requestOptions.method,
      headers: requestOptions.headers,
      extra: requestOptions.extra,
    );

    final retryPath = requestOptions.path;

    final response = await dio.request(
      retryPath,
      options: opts,
      data: requestOptions.data,
      queryParameters: requestOptions.queryParameters,
    );

    debugPrint('Retried api: ${requestOptions.path}');
    return response;
  }
}
