import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../domain/usecase/add_reason_usecase.dart';
import '../../../domain/usecase/assign_user_usecase.dart';
import '../../../domain/usecase/change_device_locator_usecase.dart';
import '../../../domain/usecase/change_device_usage_status_usecase.dart';
import '../../../domain/usecase/check_login_usecase.dart';
import '../../../domain/usecase/confirm_job_usecase.dart';
import '../../../domain/usecase/confirm_repair_request_usecase.dart';
import '../../../domain/usecase/confirm_supply_request_usecase.dart';
import '../../../domain/usecase/confirm_warehouse_export_usecase.dart';
import '../../../domain/usecase/confirm_warehouse_import_usecase.dart';
import '../../../domain/usecase/confirm_warehouse_request_usecase.dart';
import '../../../domain/usecase/confirm_warehouse_ticket_usecase.dart';
import '../../../domain/usecase/create_device_status.dart';
import '../../../domain/usecase/create_repair_request_usecase.dart';
import '../../../domain/usecase/create_supply_request_usecase.dart';
import '../../../domain/usecase/create_warehouse_export_request_usecase.dart';
import '../../../domain/usecase/create_warehouse_export_ticket_usecase.dart';
import '../../../domain/usecase/create_warehouse_export_usecase.dart';
import '../../../domain/usecase/create_warehouse_import_request_usecase.dart';
import '../../../domain/usecase/create_warehouse_import_ticket_usecase.dart';
import '../../../domain/usecase/create_warehouse_import_usecase.dart';
import '../../../domain/usecase/delete_supply_request_usecase.dart';
import '../../../domain/usecase/delete_warehouse_request_usecase.dart';
import '../../../domain/usecase/delete_warehouse_ticket_usecase.dart';
import '../../../domain/usecase/executed_job_usecase.dart';
import '../../../domain/usecase/fetch_device_list_usecase.dart';
import '../../../domain/usecase/fetch_device_status_detail_list_usecase.dart';
import '../../../domain/usecase/fetch_device_status_list.dart';
import '../../../domain/usecase/fetch_domain_usecase.dart';
import '../../../domain/usecase/get_count_noti_usecase.dart';
import '../../../domain/usecase/get_detail_job_usecase.dart';
import '../../../domain/usecase/get_detail_repair_request_usecase.dart';
import '../../../domain/usecase/get_device_activity_history.dart';
import '../../../domain/usecase/get_device_assignment_detail_usecase.dart';
import '../../../domain/usecase/get_device_assignment_list_usecase.dart';
import '../../../domain/usecase/get_device_detail_by_id_usecase.dart';
import '../../../domain/usecase/get_device_group_detail_usecase.dart';
import '../../../domain/usecase/get_device_inventory_detail_usecase.dart';
import '../../../domain/usecase/get_device_job_list.dart';
import '../../../domain/usecase/get_device_request_detail_usecase.dart';
import '../../../domain/usecase/get_device_request_list_usecase.dart';
import '../../../domain/usecase/get_device_status_detail_usecase.dart';
import '../../../domain/usecase/get_inventories_usecase.dart';
import '../../../domain/usecase/get_list_area_usecase.dart';
import '../../../domain/usecase/get_list_device_group_usecase.dart';
import '../../../domain/usecase/get_list_factory_usecase.dart';
import '../../../domain/usecase/get_list_job_usecase.dart';
import '../../../domain/usecase/get_list_notificaion_usecase.dart';
import '../../../domain/usecase/get_list_repair_request_usecase.dart';
import '../../../domain/usecase/get_list_warehouse_usecase.dart';
import '../../../domain/usecase/get_me_usecase.dart';
import '../../../domain/usecase/get_stock_supply_by_warehouse_usecase.dart';
import '../../../domain/usecase/get_supply_detail_usecase.dart';
import '../../../domain/usecase/get_supply_group_list_usecase.dart';
import '../../../domain/usecase/get_supply_list_usecase.dart';
import '../../../domain/usecase/get_supply_request_detail_usecase.dart';
import '../../../domain/usecase/get_supply_request_list_usecase.dart';
import '../../../domain/usecase/get_supply_type_list_usecase.dart';
import '../../../domain/usecase/get_transfer_ticket_detail_usecase.dart';
import '../../../domain/usecase/get_transfer_ticket_list_usecase.dart';
import '../../../domain/usecase/get_warehouse_export_detail.dart';
import '../../../domain/usecase/get_warehouse_export_list_usecase.dart';
import '../../../domain/usecase/get_warehouse_export_request_detail_usecase.dart';
import '../../../domain/usecase/get_warehouse_export_request_list_usecase.dart';
import '../../../domain/usecase/get_warehouse_export_ticket_detail_usecase.dart';
import '../../../domain/usecase/get_warehouse_export_ticket_list_usecase.dart';
import '../../../domain/usecase/get_warehouse_import_detail.dart';
import '../../../domain/usecase/get_warehouse_import_list_usecase.dart';
import '../../../domain/usecase/get_warehouse_import_request_detail_usecase.dart';
import '../../../domain/usecase/get_warehouse_import_request_list_usecase.dart';
import '../../../domain/usecase/get_warehouse_import_ticket_detail_usecase.dart';
import '../../../domain/usecase/get_warehouse_import_ticket_list_usecase.dart';
import '../../../domain/usecase/init_cache_usecase.dart';
import '../../../domain/usecase/login_usecase.dart';
import '../../../domain/usecase/maintenance_teams_assignments_usecase.dart';
import '../../../domain/usecase/read_all_notification_usecase.dart';
import '../../../domain/usecase/read_notification_id.dart';
import '../../../domain/usecase/reject_repair_request_usecase.dart';
import '../../../domain/usecase/reject_supply_request_usecase.dart';
import '../../../domain/usecase/reject_warehouse_export_usecase.dart';
import '../../../domain/usecase/reject_warehouse_import_usecase.dart';
import '../../../domain/usecase/reject_warehouse_request_usecase.dart';
import '../../../domain/usecase/reject_warehouse_ticket_usecase.dart';
import '../../../domain/usecase/responsible_user_usecase.dart';
import '../../../domain/usecase/save_token_usecase.dart';
import '../../../domain/usecase/scan_device_usecase.dart';
import '../../../domain/usecase/update_device_status.dart';
import '../../../domain/usecase/update_supply_request_usecase.dart';
import '../../../domain/usecase/update_task_status.dart';
import '../../../domain/usecase/update_warehouse_export_request_usecase.dart';
import '../../../domain/usecase/update_warehouse_export_ticket_usecase.dart';
import '../../../domain/usecase/update_warehouse_export_usecase.dart';
import '../../../domain/usecase/update_warehouse_import_request_usecase.dart';
import '../../../domain/usecase/update_warehouse_import_ticket_usecase.dart';
import '../../../domain/usecase/update_warehouse_import_usecase.dart';
import '../../../domain/usecase/validate_permission_usecase.dart';
import '../../../domain/usecase/z_demo_usecase.dart';

abstract class UseCaseModule {
  static RepositoryProvider<DemoUseCase> _provideDemoUseCase() {
    return RepositoryProvider(
      create: (context) => DemoUseCase(),
    );
  }

  static RepositoryProvider<InitCacheUseCase> _provideInitCacheUseCase() {
    return RepositoryProvider(
      create: (context) => InitCacheUseCase(context.read()),
    );
  }

  static RepositoryProvider<FetchDomainUsecase> _provideFetchDomainUseCase() {
    return RepositoryProvider(
      create: (context) => FetchDomainUsecase(context.read()),
    );
  }

  static RepositoryProvider<CheckLoginUseCase> _provideCheckLoginUseCase() {
    return RepositoryProvider(
      create: (context) => CheckLoginUseCase(context.read()),
    );
  }

  static RepositoryProvider<LoginUseCase> _provideLoginUseCase() {
    return RepositoryProvider(
      create: (context) => LoginUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetMeUseCase> _provideGetMeUseCase() {
    return RepositoryProvider(
      create: (context) => GetMeUseCase(context.read()),
    );
  }

  static RepositoryProvider<SaveTokenUseCase> _provideSaveTokenLoginUseCase() {
    return RepositoryProvider(
      create: (context) => SaveTokenUseCase(context.read()),
    );
  }

  static RepositoryProvider<DeviceListUsecase> _provideDeviceListUseCase() {
    return RepositoryProvider(
      create: (context) => DeviceListUsecase(context.read()),
    );
  }

  static RepositoryProvider<FetchDeviceStatusUsecase>
      _provideFetchDeviceStatusListUseCase() {
    return RepositoryProvider(
      create: (context) => FetchDeviceStatusUsecase(context.read()),
    );
  }

  static RepositoryProvider<GetDeviceStatusDetailUseCase>
      _provideFetchDeviceStatusDetailUseCase() {
    return RepositoryProvider(
      create: (context) => GetDeviceStatusDetailUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetDeviceDetailUseCase>
      _provideGetDeviceDetailUseCase() {
    return RepositoryProvider(
      create: (context) => GetDeviceDetailUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetListNotifyUseCase>
      _provideGetListNotifyUseCase() {
    return RepositoryProvider(
      create: (context) => GetListNotifyUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetCountNotifyUseCase>
      _provideGetCountNotifyUseCase() {
    return RepositoryProvider(
      create: (context) => GetCountNotifyUseCase(context.read()),
    );
  }

  static RepositoryProvider<DeviceActivityHistoryUsecase>
      _provideDeviceActivityHistoryUsecase() {
    return RepositoryProvider(
      create: (context) => DeviceActivityHistoryUsecase(context.read()),
    );
  }

  static RepositoryProvider<ReadNotificationIdUseCase>
      _provideReadNotificationIdUsecase() {
    return RepositoryProvider(
      create: (context) => ReadNotificationIdUseCase(context.read()),
    );
  }

  static RepositoryProvider<ReadAllNotificationUseCase>
      _provideReadAllNotificationUseCase() {
    return RepositoryProvider(
      create: (context) => ReadAllNotificationUseCase(context.read()),
    );
  }

  static RepositoryProvider<FetchDeviceStatusDetailListUsecase>
      _provideFetchDeviceStatusDetailListUseCase() {
    return RepositoryProvider(
      create: (context) => FetchDeviceStatusDetailListUsecase(context.read()),
    );
  }

  static RepositoryProvider<CreateDeviceStatusUseCase>
      _provideCreateDeviceStatusUseCase() {
    return RepositoryProvider(
      create: (context) => CreateDeviceStatusUseCase(context.read()),
    );
  }

  static RepositoryProvider<UpdateDeviceStatusUseCase>
      _provideUpdateDeviceStatusUseCase() {
    return RepositoryProvider(
      create: (context) => UpdateDeviceStatusUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetDeviceJobListUseCase>
      _provideGetDeviceJobListUseCase() {
    return RepositoryProvider(
      create: (context) => GetDeviceJobListUseCase(context.read()),
    );
  }

  static RepositoryProvider<ChangeDeviceUsageStatusUsecase>
      _provideChangeDeviceUsageStatusUsecase() {
    return RepositoryProvider(
      create: (context) => ChangeDeviceUsageStatusUsecase(context.read()),
    );
  }

  static RepositoryProvider<GetListFactoryUsecase>
      _provideGetListFactoryUsecase() {
    return RepositoryProvider(
      create: (context) => GetListFactoryUsecase(context.read()),
    );
  }

  static RepositoryProvider<GetListAreaUsecase> _provideGetListAreaUsecase() {
    return RepositoryProvider(
      create: (context) => GetListAreaUsecase(context.read()),
    );
  }

  static RepositoryProvider<ChangeDeviceLocatorUsecase>
      _provideChangeDeviceLocatorUsecase() {
    return RepositoryProvider(
      create: (context) => ChangeDeviceLocatorUsecase(context.read()),
    );
  }

  static RepositoryProvider<GetListRepairRequestUseCase>
      _provideGetListRepairRequestUsecase() {
    return RepositoryProvider(
      create: (context) => GetListRepairRequestUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetDetailRepairRequestUseCase>
      _provideGetDetailRepairRequestUsecase() {
    return RepositoryProvider(
      create: (context) => GetDetailRepairRequestUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetJobListUseCase> _provideGetJobListUseCase() {
    return RepositoryProvider(
      create: (context) => GetJobListUseCase(context.read()),
    );
  }

  static RepositoryProvider<ConfirmJobUseCase> _provideConfirmJobUseCase() {
    return RepositoryProvider(
      create: (context) => ConfirmJobUseCase(context.read()),
    );
  }

  static RepositoryProvider<AddReasonJobUseCase> _provideAddReasonJobUseCase() {
    return RepositoryProvider(
      create: (context) => AddReasonJobUseCase(context.read()),
    );
  }

  static RepositoryProvider<UpdateStatusUseCase> _provideUpdateStatusUseCase() {
    return RepositoryProvider(
      create: (context) => UpdateStatusUseCase(context.read()),
    );
  }

  static RepositoryProvider<ExecutedJobUseCase> _provideExecutedJobUseCase() {
    return RepositoryProvider(
      create: (context) => ExecutedJobUseCase(context.read()),
    );
  }

  static RepositoryProvider<MaintenanceTeamsAssignmentsUsecase>
      _provideMaintenanceTeamsAssignmentsUsecase() {
    return RepositoryProvider(
      create: (context) => MaintenanceTeamsAssignmentsUsecase(context.read()),
    );
  }

  static RepositoryProvider<AssignUserUsecase> _provideAssignUserUsecase() {
    return RepositoryProvider(
      create: (context) => AssignUserUsecase(context.read()),
    );
  }

  static RepositoryProvider<GetJobDetailUsecase> _provideGetJobDetailUsecase() {
    return RepositoryProvider(
      create: (context) => GetJobDetailUsecase(context.read()),
    );
  }

  static RepositoryProvider<GetListSupplyRequestUsecase>
      _provideGetListSupplyRequestUsecase() {
    return RepositoryProvider(
      create: (context) => GetListSupplyRequestUsecase(context.read()),
    );
  }

  static RepositoryProvider<GetSupplyRequestDetailUsecase>
      _provideGetSupplyRequestDetailUsecase() {
    return RepositoryProvider(
      create: (context) => GetSupplyRequestDetailUsecase(context.read()),
    );
  }

  static RepositoryProvider<ConfirmSupplyRequestUsecase>
      _provideConfirmSupplyRequestUsecase() {
    return RepositoryProvider(
      create: (context) => ConfirmSupplyRequestUsecase(context.read()),
    );
  }

  static RepositoryProvider<RejectSupplyRequestUsecase>
      _provideRejectSupplyRequestUsecase() {
    return RepositoryProvider(
      create: (context) => RejectSupplyRequestUsecase(context.read()),
    );
  }

  static RepositoryProvider<GetListDeviceGroupUseCase>
      _provideGetListDeviceGroupUseCase() {
    return RepositoryProvider(
      create: (context) => GetListDeviceGroupUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetDeviceGroupDetailUsecase>
      _provideGetDeviceGroupDetailUsecase() {
    return RepositoryProvider(
      create: (context) => GetDeviceGroupDetailUsecase(context.read()),
    );
  }

  static RepositoryProvider<CreateRepairRequestUseCase>
      _provideCreateRepairRequestUseCase() {
    return RepositoryProvider(
      create: (context) => CreateRepairRequestUseCase(context.read()),
    );
  }

  static RepositoryProvider<RejectRepairRequestUseCase>
      _provideRejectRepairRequestUseCase() {
    return RepositoryProvider(
      create: (context) => RejectRepairRequestUseCase(context.read()),
    );
  }

  static RepositoryProvider<ConfirmRepairRequestUseCase>
      _provideConfirmRepairRequestUseCase() {
    return RepositoryProvider(
      create: (context) => ConfirmRepairRequestUseCase(context.read()),
    );
  }

  static RepositoryProvider<ScanDeviceUseCase> _provideScanDeviceUseCase() {
    return RepositoryProvider(
      create: (context) => ScanDeviceUseCase(context.read()),
    );
  }

  static RepositoryProvider<DeleteSupplyRequestUsecase>
      _provideDeleteSupplyRequestUsecase() {
    return RepositoryProvider(
      create: (context) => DeleteSupplyRequestUsecase(context.read()),
    );
  }

  static RepositoryProvider<GetWarehouseListUsecase>
      _provideGetWarehouseListUsecase() {
    return RepositoryProvider(
      create: (context) => GetWarehouseListUsecase(context.read()),
    );
  }

  static RepositoryProvider<GetSupplyListUsecase>
      _provideGetSupplyListUsecase() {
    return RepositoryProvider(
      create: (context) => GetSupplyListUsecase(context.read()),
    );
  }

  static RepositoryProvider<CreateSupplyRequestUseCase>
      _provideCreateSupplyRequestUseCase() {
    return RepositoryProvider(
      create: (context) => CreateSupplyRequestUseCase(context.read()),
    );
  }

  static RepositoryProvider<UpdateSupplyRequestUseCase>
      _provideUpdateSupplyRequestUseCase() {
    return RepositoryProvider(
      create: (context) => UpdateSupplyRequestUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetStockSupplyByWarehouseUsecase>
      _provideGetStockSupplyByWarehouseUsecase() {
    return RepositoryProvider(
      create: (context) => GetStockSupplyByWarehouseUsecase(context.read()),
    );
  }

  static RepositoryProvider<GetInventoriesUseCase>
      _provideGetInventoriesUseCase() {
    return RepositoryProvider(
      create: (context) => GetInventoriesUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetWarehouseImportListUseCase>
      _provideGetWarehouseImportListUseCase() {
    return RepositoryProvider(
      create: (context) => GetWarehouseImportListUseCase(context.read()),
    );
  }

  static RepositoryProvider<ConfirmWarehouseImportUsecase>
      _provideConfirmWarehouseImportUsecase() {
    return RepositoryProvider(
      create: (context) => ConfirmWarehouseImportUsecase(context.read()),
    );
  }

  static RepositoryProvider<RejectWarehouseImportUsecase>
      _provideRejectWarehouseImportUsecase() {
    return RepositoryProvider(
      create: (context) => RejectWarehouseImportUsecase(context.read()),
    );
  }

  static RepositoryProvider<GetWarehouseImportDetailUseCase>
      _provideGetWarehouseImportDetailUseCase() {
    return RepositoryProvider(
      create: (context) => GetWarehouseImportDetailUseCase(context.read()),
    );
  }

  static RepositoryProvider<ValidatePermissionUsecase>
      _provideValidatePermissionUsecase() {
    return RepositoryProvider(
      create: (context) => ValidatePermissionUsecase(context.read()),
    );
  }

  static RepositoryProvider<GetDeviceAssignmentUseCase>
      _provideGetDeviceAssignmentUseCase() {
    return RepositoryProvider(
      create: (context) => GetDeviceAssignmentUseCase(context.read()),
    );
  }

  static RepositoryProvider<CreateWarehouseImportUseCase>
      _provideCreateWarehouseImportUseCase() {
    return RepositoryProvider(
      create: (context) => CreateWarehouseImportUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetSupplyGroupListUseCase>
      _provideGetSupplyGroupListUseCase() {
    return RepositoryProvider(
      create: (context) => GetSupplyGroupListUseCase(context.read()),
    );
  }

  static RepositoryProvider<UpdateWarehouseImportUseCase>
      _provideUpdateWarehouseImportUseCase() {
    return RepositoryProvider(
      create: (context) => UpdateWarehouseImportUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetWarehouseExportListUseCase>
      _provideGetWarehouseExportListUseCase() {
    return RepositoryProvider(
      create: (context) => GetWarehouseExportListUseCase(context.read()),
    );
  }

  static RepositoryProvider<RejectWarehouseExportUsecase>
      _provideRejectWarehouseExportUsecase() {
    return RepositoryProvider(
      create: (context) => RejectWarehouseExportUsecase(context.read()),
    );
  }

  static RepositoryProvider<ConfirmWarehouseExportUsecase>
      _provideConfirmWarehouseExportUsecase() {
    return RepositoryProvider(
      create: (context) => ConfirmWarehouseExportUsecase(context.read()),
    );
  }

  static RepositoryProvider<GetWarehouseExportDetailUseCase>
      _provideGetWarehouseExportDetailUseCase() {
    return RepositoryProvider(
      create: (context) => GetWarehouseExportDetailUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetTransferTicketDetailUsecase>
      _provideGetTransferTicketDetailUsecase() {
    return RepositoryProvider(
      create: (context) => GetTransferTicketDetailUsecase(context.read()),
    );
  }

  static RepositoryProvider<GetTransferTicketListUsecase>
      _provideGetTransferTicketListUsecase() {
    return RepositoryProvider(
      create: (context) => GetTransferTicketListUsecase(context.read()),
    );
  }

  static RepositoryProvider<GetDeviceRequestDetailUseCase>
      _provideGetDeviceRequestDetailUseCase() {
    return RepositoryProvider(
      create: (context) => GetDeviceRequestDetailUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetDeviceRequestListUseCase>
      _provideGetDeviceRequestListUseCase() {
    return RepositoryProvider(
      create: (context) => GetDeviceRequestListUseCase(context.read()),
    );
  }

  static RepositoryProvider<UpdateWarehouseExportUseCase>
      _provideUpdateWarehouseExportUseCase() {
    return RepositoryProvider(
      create: (context) => UpdateWarehouseExportUseCase(context.read()),
    );
  }

  static RepositoryProvider<CreateWarehouseExportUseCase>
      _provideCreateWarehouseExportUseCase() {
    return RepositoryProvider(
      create: (context) => CreateWarehouseExportUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetDeviceAssignmentDetailUseCase>
      _provideGetDeviceAssignmentDetailUseCase() {
    return RepositoryProvider(
      create: (context) => GetDeviceAssignmentDetailUseCase(context.read()),
    );
  }

  static RepositoryProvider<ResponsibleUserUseCase>
      _provideResponsibleUserUseCase() {
    return RepositoryProvider(
      create: (context) => ResponsibleUserUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetWarehouseImportTicketListUseCase>
      _provideGetWarehouseImportTicketListUseCase() {
    return RepositoryProvider(
      create: (context) => GetWarehouseImportTicketListUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetWarehouseExportTicketListUseCase>
      _provideGetWarehouseExportTicketListUseCase() {
    return RepositoryProvider(
      create: (context) => GetWarehouseExportTicketListUseCase(context.read()),
    );
  }

  static RepositoryProvider<ConfirmWarehouseTicketUseCase>
      _provideConfirmWarehouseTicketUseCase() {
    return RepositoryProvider(
      create: (context) => ConfirmWarehouseTicketUseCase(context.read()),
    );
  }

  static RepositoryProvider<RejectWarehouseTicketUseCase>
      _provideRejectWarehouseTicketUseCase() {
    return RepositoryProvider(
      create: (context) => RejectWarehouseTicketUseCase(context.read()),
    );
  }

  static RepositoryProvider<DeleteWarehouseTicketUseCase>
      _provideDeleteWarehouseTicketUseCase() {
    return RepositoryProvider(
      create: (context) => DeleteWarehouseTicketUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetWarehouseImportRequestDetailUseCase>
      _provideGetWarehouseImportRequestDetailUseCase() {
    return RepositoryProvider(
      create: (context) =>
          GetWarehouseImportRequestDetailUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetWarehouseExportRequestListUseCase>
      _provideGetWarehouseExportRequestListUseCase() {
    return RepositoryProvider(
      create: (context) => GetWarehouseExportRequestListUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetWarehouseImportRequestListUseCase>
      _provideGetWarehouseImportRequestListUseCase() {
    return RepositoryProvider(
      create: (context) => GetWarehouseImportRequestListUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetWarehouseImportTicketDetailUseCase>
      _provideGetWarehouseImportTicketDetailUseCase() {
    return RepositoryProvider(
      create: (context) =>
          GetWarehouseImportTicketDetailUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetWarehouseExportTicketDetailUseCase>
      _provideGetWarehouseExportTicketDetailUseCase() {
    return RepositoryProvider(
      create: (context) =>
          GetWarehouseExportTicketDetailUseCase(context.read()),
    );
  }

  static RepositoryProvider<CreateWarehouseExportTicketUseCase>
      _provideCreateWarehouseExportTicketUseCase() {
    return RepositoryProvider(
      create: (context) => CreateWarehouseExportTicketUseCase(context.read()),
    );
  }

  static RepositoryProvider<UpdateWarehouseExportTicketUseCase>
      _provideUpdateWarehouseExportTicketUseCase() {
    return RepositoryProvider(
      create: (context) => UpdateWarehouseExportTicketUseCase(context.read()),
    );
  }

  static RepositoryProvider<CreateWarehouseImportTicketUseCase>
      _provideCreateWarehouseImportTicketUseCase() {
    return RepositoryProvider(
      create: (context) => CreateWarehouseImportTicketUseCase(context.read()),
    );
  }

  static RepositoryProvider<UpdateWarehouseImportTicketUseCase>
      _provideUpdateWarehouseImportTicketUseCase() {
    return RepositoryProvider(
      create: (context) => UpdateWarehouseImportTicketUseCase(context.read()),
    );
  }

  static RepositoryProvider<ConfirmWarehouseRequestUseCase>
      _provideConfirmWarehouseRequestUseCase() {
    return RepositoryProvider(
      create: (context) => ConfirmWarehouseRequestUseCase(context.read()),
    );
  }

  static RepositoryProvider<DeleteWarehouseRequestUseCase>
      _provideDeleteWarehouseRequestUseCase() {
    return RepositoryProvider(
      create: (context) => DeleteWarehouseRequestUseCase(context.read()),
    );
  }

  static RepositoryProvider<RejectWarehouseRequestUseCase>
      _provideRejectWarehouseRequestUseCase() {
    return RepositoryProvider(
      create: (context) => RejectWarehouseRequestUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetWarehouseExportRequestDetailUseCase>
      _provideGetWarehouseExportRequestDetailUseCase() {
    return RepositoryProvider(
      create: (context) =>
          GetWarehouseExportRequestDetailUseCase(context.read()),
    );
  }

  static RepositoryProvider<CreateWarehouseImportRequestUseCase>
      _provideCreateWarehouseImportRequestUseCase() {
    return RepositoryProvider(
      create: (context) => CreateWarehouseImportRequestUseCase(context.read()),
    );
  }

  static RepositoryProvider<UpdateWarehouseImportRequestUseCase>
      _provideUpdateWarehouseImportRequestUseCase() {
    return RepositoryProvider(
      create: (context) => UpdateWarehouseImportRequestUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetSupplyDetailUsecase>
      _provideGetSupplyDetailUsecase() {
    return RepositoryProvider(
      create: (context) => GetSupplyDetailUsecase(context.read()),
    );
  }

  static RepositoryProvider<GetSupplyTypeListUsecase>
      _provideGetSupplyTypeListUsecase() {
    return RepositoryProvider(
      create: (context) => GetSupplyTypeListUsecase(context.read()),
    );
  }

  static RepositoryProvider<CreateWarehouseExportRequestUseCase>
      _provideCreateWarehouseExportRequestUseCase() {
    return RepositoryProvider(
      create: (context) => CreateWarehouseExportRequestUseCase(context.read()),
    );
  }

  static RepositoryProvider<UpdateWarehouseExportRequestUseCase>
      _provideUpdateWarehouseExportRequestUseCase() {
    return RepositoryProvider(
      create: (context) => UpdateWarehouseExportRequestUseCase(context.read()),
    );
  }

  static RepositoryProvider<GetDeviceInventoryDetailUsecase>
      _provideGetDeviceInventoryDetailUsecase() {
    return RepositoryProvider(
      create: (context) => GetDeviceInventoryDetailUsecase(context.read()),
    );
  }

  static List<RepositoryProvider> dependencies() {
    return [
      _provideDemoUseCase(),
      _provideInitCacheUseCase(),
      _provideFetchDomainUseCase(),
      _provideLoginUseCase(),
      _provideGetMeUseCase(),
      _provideGetListNotifyUseCase(),
      _provideGetCountNotifyUseCase(),
      _provideReadNotificationIdUsecase(),
      _provideCheckLoginUseCase(),
      _provideSaveTokenLoginUseCase(),
      _provideDeviceListUseCase(),
      _provideFetchDeviceStatusListUseCase(),
      _provideGetDeviceDetailUseCase(),
      _provideFetchDeviceStatusDetailUseCase(),
      _provideReadAllNotificationUseCase(),
      _provideDeviceActivityHistoryUsecase(),
      _provideReadAllNotificationUseCase(),
      _provideFetchDeviceStatusDetailListUseCase(),
      _provideCreateDeviceStatusUseCase(),
      _provideUpdateDeviceStatusUseCase(),
      _provideGetDeviceJobListUseCase(),
      _provideChangeDeviceUsageStatusUsecase(),
      _provideGetListFactoryUsecase(),
      _provideGetListAreaUsecase(),
      _provideChangeDeviceLocatorUsecase(),
      _provideGetListRepairRequestUsecase(),
      _provideGetDetailRepairRequestUsecase(),
      _provideGetJobListUseCase(),
      _provideConfirmJobUseCase(),
      _provideExecutedJobUseCase(),
      _provideGetJobDetailUsecase(),
      _provideMaintenanceTeamsAssignmentsUsecase(),
      _provideAssignUserUsecase(),
      _provideGetListDeviceGroupUseCase(),
      _provideGetListSupplyRequestUsecase(),
      _provideGetSupplyRequestDetailUsecase(),
      _provideConfirmSupplyRequestUsecase(),
      _provideRejectSupplyRequestUsecase(),
      _provideGetDeviceGroupDetailUsecase(),
      _provideCreateRepairRequestUseCase(),
      _provideRejectRepairRequestUseCase(),
      _provideConfirmRepairRequestUseCase(),
      _provideScanDeviceUseCase(),
      _provideDeleteSupplyRequestUsecase(),
      _provideGetWarehouseListUsecase(),
      _provideGetSupplyListUsecase(),
      _provideCreateSupplyRequestUseCase(),
      _provideUpdateSupplyRequestUseCase(),
      _provideGetStockSupplyByWarehouseUsecase(),
      _provideGetInventoriesUseCase(),
      _provideGetWarehouseImportListUseCase(),
      _provideConfirmWarehouseImportUsecase(),
      _provideRejectWarehouseImportUsecase(),
      _provideGetWarehouseImportDetailUseCase(),
      _provideValidatePermissionUsecase(),
      _provideGetDeviceAssignmentUseCase(),
      _provideCreateWarehouseImportUseCase(),
      _provideGetSupplyGroupListUseCase(),
      _provideUpdateWarehouseImportUseCase(),
      _provideGetWarehouseExportListUseCase(),
      _provideRejectWarehouseExportUsecase(),
      _provideConfirmWarehouseExportUsecase(),
      _provideGetWarehouseExportDetailUseCase(),
      _provideGetTransferTicketDetailUsecase(),
      _provideGetTransferTicketListUsecase(),
      _provideGetDeviceRequestDetailUseCase(),
      _provideGetDeviceRequestListUseCase(),
      _provideUpdateWarehouseExportUseCase(),
      _provideCreateWarehouseExportUseCase(),
      _provideGetDeviceAssignmentDetailUseCase(),
      _provideResponsibleUserUseCase(),
      _provideAddReasonJobUseCase(),
      _provideUpdateStatusUseCase(),
      _provideAddReasonJobUseCase(),
      _provideGetWarehouseImportTicketListUseCase(),
      _provideGetWarehouseExportTicketListUseCase(),
      _provideConfirmWarehouseTicketUseCase(),
      _provideRejectWarehouseTicketUseCase(),
      _provideDeleteWarehouseTicketUseCase(),
      _provideGetWarehouseImportRequestDetailUseCase(),
      _provideGetWarehouseImportRequestListUseCase(),
      _provideGetWarehouseImportTicketDetailUseCase(),
      _provideCreateWarehouseExportTicketUseCase(),
      _provideUpdateWarehouseExportTicketUseCase(),
      _provideCreateWarehouseImportTicketUseCase(),
      _provideUpdateWarehouseImportTicketUseCase(),
      _provideGetWarehouseExportTicketDetailUseCase(),
      _provideGetWarehouseExportRequestListUseCase(),
      _provideConfirmWarehouseRequestUseCase(),
      _provideDeleteWarehouseRequestUseCase(),
      _provideRejectWarehouseRequestUseCase(),
      _provideGetWarehouseExportRequestDetailUseCase(),
      _provideCreateWarehouseImportRequestUseCase(),
      _provideUpdateWarehouseImportRequestUseCase(),
      _provideGetSupplyDetailUsecase(),
      _provideGetSupplyTypeListUsecase(),
      _provideCreateWarehouseExportRequestUseCase(),
      _provideUpdateWarehouseExportRequestUseCase(),
      _provideGetDeviceInventoryDetailUsecase(),
    ];
  }
}
