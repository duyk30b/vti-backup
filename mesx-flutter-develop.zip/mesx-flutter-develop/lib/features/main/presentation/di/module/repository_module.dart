import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../data/repository/app_repository_impl.dart';
import '../../../data/repository/area_list_repository_impl.dart';
import '../../../data/repository/authentication_repository.dart';
import '../../../data/repository/device_activity_history_repo_impl.dart';
import '../../../data/repository/device_assignment_repository_impl.dart';
import '../../../data/repository/device_group_repository_impl.dart';
import '../../../data/repository/device_list_repository.dart';
import '../../../data/repository/device_request_repository_impl.dart';
import '../../../data/repository/device_status_impl.dart';
import '../../../data/repository/domain_repository_impl.dart';
import '../../../data/repository/factory_list_repository_impl.dart';
import '../../../data/repository/job_repository_impl.dart';
import '../../../data/repository/notification_repository_impl.dart';
import '../../../data/repository/repair_request_repository.dart';
import '../../../data/repository/supply_group_repository_impl.dart';
import '../../../data/repository/supply_repository_impl.dart';
import '../../../data/repository/supply_request_repository_impl.dart';
import '../../../data/repository/transfer_ticket_repository_impl.dart';
import '../../../data/repository/warehouse_repository_impl.dart';
import '../../../domain/repository/app_repository.dart';
import '../../../domain/repository/area_list_repository.dart';
import '../../../domain/repository/authentication_repository.dart';
import '../../../domain/repository/device_activity_history_repository.dart';
import '../../../domain/repository/device_assignment_repository.dart';
import '../../../domain/repository/device_group_repository.dart';
import '../../../domain/repository/device_list_repository.dart';
import '../../../domain/repository/device_request_repository.dart';
import '../../../domain/repository/device_status_repository.dart';
import '../../../domain/repository/domain_repository.dart';
import '../../../domain/repository/factory_list_repository.dart';
import '../../../domain/repository/job_repository.dart';
import '../../../domain/repository/notification_repository.dart';
import '../../../domain/repository/repair_request_repository.dart';
import '../../../domain/repository/supply_group_repository.dart';
import '../../../domain/repository/supply_repository.dart';
import '../../../domain/repository/supply_request_repository.dart';
import '../../../domain/repository/transfer_ticket_repository.dart';
import '../../../domain/repository/warehouse_repository.dart';

abstract class RepositoryModule {
  static RepositoryProvider<AppRepository> _provideAppRepository() {
    return RepositoryProvider(
      create: (context) => AppRepositoryImpl(context.read()),
    );
  }

  static RepositoryProvider<DomainRepository> _provideDomainRepository() {
    return RepositoryProvider(
      create: (context) => DomainRepositoryImpl(context.read()),
    );
  }

  static RepositoryProvider<AuthenticationRepository>
      _provideAuthenticationRepository() {
    return RepositoryProvider(
      create: (context) =>
          AuthenticationRepositoryIml(context.read(), context.read()),
    );
  }

  static RepositoryProvider<DeviceListRepository>
      _provideDeviceListRepository() {
    return RepositoryProvider(
      create: (context) => DeviceListRepositoryImpl(context.read()),
    );
  }

  static RepositoryProvider<DeviceStatusRepository>
      _provideDeviceStatusRepository() {
    return RepositoryProvider(
      create: (context) => DeviceStatusRepositoryImpl(context.read()),
    );
  }

  static RepositoryProvider<NotificationRepository>
      _provideNotificationRepository() {
    return RepositoryProvider(
      create: (context) => NotificationRepositoryImpl(context.read()),
    );
  }

  static RepositoryProvider<DeviceActivityHistoryRepo>
      _provideDeviceActivityHistoryRepository() {
    return RepositoryProvider(
      create: (context) => DeviceActivityHistoryRepoImpl(context.read()),
    );
  }

  static RepositoryProvider<JobRepository> _provideJobRepository() {
    return RepositoryProvider(
      create: (context) => JobRepositoryImpl(context.read()),
    );
  }

  static RepositoryProvider<FactoryListRepository>
      _provideFactoryListRepository() {
    return RepositoryProvider(
      create: (context) => FactoryListRepositoryImpl(context.read()),
    );
  }

  static RepositoryProvider<AreaListRepository> _provideAreaListRepository() {
    return RepositoryProvider(
      create: (context) => AreaListRepositoryImpl(context.read()),
    );
  }

  static RepositoryProvider<RepairRequestRepository>
      _provideRepairRequestRepository() {
    return RepositoryProvider(
      create: (context) => RepairRequestRepositoryImpl(context.read()),
    );
  }

  static RepositoryProvider<SupplyRequestRepository>
      _provideSupplyRequestRepository() {
    return RepositoryProvider(
        create: (context) => SupplyRequestRepositoryImpl(context.read()));
  }

  static RepositoryProvider<DeviceGroupRepo> _provideDeviceGroupRepository() {
    return RepositoryProvider(
      create: (context) => DeviceGroupRepoImpl(context.read()),
    );
  }

  static RepositoryProvider<WarehouseRepository> _provideWarehouseRepository() {
    return RepositoryProvider(
      create: (context) => WarehouseRepositoryImpl(context.read()),
    );
  }

  static RepositoryProvider<SupplyRepository> _provideSupplyRepository() {
    return RepositoryProvider(
      create: (context) => SupplyRepositoryImpl(context.read()),
    );
  }

  static RepositoryProvider<DeviceAssignmentRepository>
      _provideDeviceAssignmentRepository() {
    return RepositoryProvider(
      create: (context) => DeviceAssignmentRepositoryImpl(context.read()),
    );
  }

  static RepositoryProvider<SupplyGroupRepository>
      _provideSupplyGroupRepository() {
    return RepositoryProvider(
      create: (context) => SupplyGroupRepositoryImpl(context.read()),
    );
  }

  static RepositoryProvider<TransferTicketRepository>
      _provideTransferTicketRepository() {
    return RepositoryProvider(
      create: (context) => TransferTicketRepositoryImpl(context.read()),
    );
  }

  static RepositoryProvider<DeviceRequestRepository>
      _provideDeviceRequestRepository() {
    return RepositoryProvider(
      create: (context) => DeviceRequestRepositoryImpl(context.read()),
    );
  }

  static List<RepositoryProvider> dependencies() {
    return [
      _provideAppRepository(),
      _provideDomainRepository(),
      _provideAuthenticationRepository(),
      _provideDeviceListRepository(),
      _provideDeviceStatusRepository(),
      _provideAuthenticationRepository(),
      _provideNotificationRepository(),
      _provideDeviceActivityHistoryRepository(),
      _provideJobRepository(),
      _provideFactoryListRepository(),
      _provideAreaListRepository(),
      _provideRepairRequestRepository(),
      _provideSupplyRequestRepository(),
      _provideDeviceGroupRepository(),
      _provideWarehouseRepository(),
      _provideSupplyRepository(),
      _provideDeviceAssignmentRepository(),
      _provideSupplyGroupRepository(),
      _provideTransferTicketRepository(),
      _provideDeviceRequestRepository()
    ];
  }
}
