import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../../../../core/bloc/state_wrapper.dart';
import '../../../../../../../core/configs/app_colors.dart';
import '../../../../../../../core/configs/constants.dart';
import '../../../../../../../core/configs/constants_widget.dart';
import '../../../../../../../core/pull_refresh/pull_refresh.dart';
import '../../../../../../../core/utils/date_utils.dart';
import '../../../../../../../core/widget/multi_state_view_widget.dart';
import '../../../../../../../generated/l10n.dart';
import '../../../../../domain/enum/device_activity_enum.dart';
import '../../../../../domain/model/device_activity_history.dart';
import 'activity_history_cubit.dart';
import 'activity_history_state.dart';

class ActivityHistoryWidget
    extends BaseListPage<ActivityHistoryState, ActivityHistoryCubit>
    with BaseListPageMixin<ActivityHistoryState, ActivityHistoryCubit> {
  ActivityHistoryWidget({super.key});

  @override
  Widget buildBody(
      BuildContext context, StateWrapper<ActivityHistoryState> state) {
    return Container(
      margin: const EdgeInsets.only(left: 24),
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(10),
          bottomLeft: Radius.circular(10),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Center(
            child: Container(
              margin: const EdgeInsets.only(top: 8),
              alignment: Alignment.center,
              height: 4,
              width: 100,
              decoration: BoxDecoration(
                color: AppColors.semiGrey.withOpacity(0.5),
                borderRadius: const BorderRadius.all(
                  Radius.circular(5),
                ),
              ),
            ),
          ),
          height32,
          Text(
            BS.of(context).activity_history,
            style: Theme.of(context)
                .textTheme
                .labelMedium
                ?.copyWith(fontWeight: FontWeight.w600, fontSize: 16),
          ),
          height8,
          height10,
          _buildListView(context, state),
        ],
      ),
    );
  }

  Widget _buildListView(
      BuildContext context, StateWrapper<ActivityHistoryState> state) {
    final deviceStatusList = state.value.deviceActivityHistory;

    return Expanded(
      child: MultiStateViewWidget(
        viewState: state.viewState,
        loadingWidget: buildLoading(state),
        emptyWidget: buildEmpty(state),
        errorWidget: buildError(state),
        message: message(state),
        onRetryPress: null,
        child: generateList(
          context,
          ListView.builder(
            itemBuilder: (_, index) {
              final item = deviceStatusList[index];
              return Container(
                child: _buildItem(context, item),
              );
            },
            itemCount: deviceStatusList.length,
          ),
        ),
      ),
    );
  }

  Widget _buildItem(BuildContext context, DeviceActivityHistory history) {
    final String startTime = DateUtilsFormat.toDateTimeString(
      history.startTime.toLocal(),
      format: Constants.timeDisplayFormat,
    );

    final String name = history.createdBy.fullName ?? '';
    final String content = history.status?.toLabel() ?? '';
    return ListTile(
      visualDensity: const VisualDensity(horizontal: 0, vertical: -4),
      contentPadding: EdgeInsets.zero,
      title: RichText(
        text: TextSpan(
          children: [
            WidgetSpan(
              alignment: PlaceholderAlignment.middle,
              child: Container(
                alignment: Alignment.center,
                margin: const EdgeInsets.only(right: 10),
                height: 6,
                width: 6,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.mainBlue,
                ),
              ),
            ),
            TextSpan(
              text: '$startTime: $name $content',
              style: GoogleFonts.inter(
                fontWeight: FontWeight.w400,
                fontSize: 15,
                color: AppColors.subTextColor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
