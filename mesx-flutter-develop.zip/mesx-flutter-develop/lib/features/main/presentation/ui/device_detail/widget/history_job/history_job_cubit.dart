import 'package:dio/dio.dart';

import '../../../../../../../core/pull_refresh/pull_refresh.dart';
import '../../../../../../../generated/l10n.dart';
import '../../../../../domain/enum/job_enum.dart';
import '../../../../../domain/request/base_query.dart';
import '../../../../../domain/usecase/get_device_job_list.dart';
import '../../../../extensions/dio_error_ext.dart';
import 'history_job_state.dart';

class HistoryJobCubit extends BaseListCubit<HistoryJobState> {
  bool? isDisplay;
  GetDeviceJobListUseCase jobListUsecase;
  final query = BaseQuery();
  String? deviceId;

  HistoryJobCubit(
    this.jobListUsecase,
    this.deviceId,
  ) : super.value(HistoryJobState());

  @override
  void start() {
    super.start();
    query.setFilter('deviceId', deviceId);
    query.setFilter('status', JobStatus.completed.status.toString());
    getDeviceJobList();
  }

  Future<void> getDeviceJobList() async {
    try {
      query.setPage = page;
      if (isRefresh()) {
        showLoading();
      }
      final result = await jobListUsecase.execute(query);
      final newList = [...value.jobList, ...result];
      showContent(value.copyWith(jobList: newList));
      dispatchResult(newData: result, emptyMessage: BS.current.no_device_found);
    } on DioError catch (e) {
      dispatchResult(exception: e.toApiException().message);
    } on Exception catch (error) {
      dispatchResult(exception: error.toString());
    }
  }

  @override
  Future<void> onLoadMore() async {
    await getDeviceJobList();
  }

  @override
  void refresh() {
    super.refresh();
    emitNewValue(value.copyWith(jobList: []));
    getDeviceJobList();
  }
}
