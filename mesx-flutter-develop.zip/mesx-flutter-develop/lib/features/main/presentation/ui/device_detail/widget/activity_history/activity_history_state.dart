import '../../../../../domain/model/device_activity_history.dart';

class ActivityHistoryState {
  final List<DeviceActivityHistory> deviceActivityHistory;

  ActivityHistoryState({
    this.deviceActivityHistory = const [],
  });

  ActivityHistoryState copyWith({
    List<DeviceActivityHistory>? deviceActivityHistory,
  }) {
    return ActivityHistoryState(
      deviceActivityHistory:
          deviceActivityHistory ?? this.deviceActivityHistory,
    );
  }
}
