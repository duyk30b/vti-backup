import 'package:flutter/material.dart';
import '../../../../../../core/bloc/state_wrapper.dart';
import '../../../../../../core/configs/app_colors.dart';
import '../../../../../../core/configs/constants.dart';
import '../../../../../../core/configs/constants_widget.dart';
import '../../../../../../core/extensions/extensions.dart';
import '../../../../../../core/pop_up/pop_up_helper.dart';
import '../../../../../../core/utils/date_utils.dart';
import '../../../../../../generated/assets/assets.gen.dart';
import '../../../../../../generated/l10n.dart';

import '../../../../domain/enum/device_enum.dart';
import '../../../../domain/model/device_detail.dart';
import '../../../widget/info_card.dart';
import '../../../widget/label_value.dart';
import '../device_detail_state.dart';
import 'popup/popup_change_locator.dart';
import 'popup/popup_change_usage_status.dart';

class GeneralInfo extends StatelessWidget {
  final DeviceDetail? deviceDetail;
  final BuildContext? context;
  final StateWrapper<DeviceDetailState>? state;

  const GeneralInfo({
    super.key,
    this.deviceDetail,
    this.context,
    this.state,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: showContent(context, state),
    );
  }

  Widget showLoading() {
    return const Center(
      heightFactor: 10,
      child: CircularProgressIndicator(
        color: AppColors.mainBlue,
      ),
    );
  }

  Widget showContent(
      BuildContext context, StateWrapper<DeviceDetailState>? state) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12.0),
      child: Column(
        children: [
          buildGeneralInfo(context),
          height12,
          buildDescription(context),
        ],
      ),
    );
  }

  Widget buildGeneralInfo(BuildContext context) {
    return InfoCard(
      title: BS.current.general_info,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 24.0),
        child: Column(
          children: [
            LabelValue(
              labelText: BS.current.factory,
              valueText: deviceDetail?.factory?.name,
              valueActionIcon: Assets.images.svgIcon.icEditDeviceInfo.svg(),
              isBoldValue: false,
              onValueAction: () {
                PopUpHelper.showDialogCustom(
                  context,
                  PopupChangeLocator(
                    context: context,
                    deviceDetail: deviceDetail,
                  ),
                );
              },
            ),
            height10,
            LabelValue(
              labelText: BS.current.area,
              valueText: deviceDetail?.area?.name,
              isBoldValue: false,
              valueActionIcon: Assets.images.svgIcon.icEditDeviceInfo.svg(),
              onValueAction: () {
                PopUpHelper.showDialogCustom(
                  context,
                  PopupChangeLocator(
                    context: context,
                    deviceDetail: deviceDetail,
                  ),
                );
              },
            ),
            height10,
            LabelValue(
              labelText: BS.current.createdAt,
              value: Text(
                DateUtilsFormat.toDateTimeString(
                  deviceDetail?.creationDate,
                  format: Constants.dateDisplayFormat,
                ),
              ),
            ),
            height10,
            LabelValue(
              labelText: BS.current.capitalizationDate,
              value: Text(
                DateUtilsFormat.toDateTimeString(
                  deviceDetail?.creationDate,
                  format: Constants.dateDisplayFormat,
                ),
              ),
            ),
            height10,
            LabelValue(
              labelText: BS.current.status,
              valueText: deviceDetail?.status?.toLabel(),
              colorValue: deviceDetail?.status?.toColor(),
              valueActionIcon: Assets.images.svgIcon.icEditDeviceInfo.svg(),
              isBoldValue: false,
              onValueAction: () {
                PopUpHelper.showDialogCustom(
                  context,
                  PopupChangeUsageStatus(
                    deviceDetail: deviceDetail,
                    context: context,
                  ),
                );
              },
            )
          ],
        ),
      ),
    );
  }

  Widget buildEditDeviceButton(VoidCallback onPressed) {
    return IconButton(
      padding: const EdgeInsets.only(left: 10),
      constraints: const BoxConstraints(),
      onPressed: onPressed,
      icon: Assets.images.svgIcon.icEditDeviceInfo.svg(),
    );
  }

  Widget buildDescription(BuildContext context) {
    return Visibility(
      visible: deviceDetail?.description?.isNotEmpty ?? false,
      child: SizedBox(
        width: context.screenWidth,
        child: InfoCard(
          title: BS.current.description_device,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 24.0),
            child: Text(deviceDetail?.description ?? ''),
          ),
        ),
      ),
    );
  }
}
