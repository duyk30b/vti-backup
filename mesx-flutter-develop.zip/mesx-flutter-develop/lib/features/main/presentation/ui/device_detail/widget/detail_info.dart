import 'package:flutter/material.dart';
import '../../../../../../core/configs/app_colors.dart';
import '../../../../../../core/configs/constants.dart';
import '../../../../../../core/configs/constants_widget.dart';
import '../../../../../../core/extensions/string_ext.dart';
import '../../../../../../core/utils/date_utils.dart';
import '../../../../../../generated/l10n.dart';
import '../../../../domain/model/device_detail.dart';
import '../../../widget/info_card.dart';
import '../../../widget/label_value.dart';

class DeviceDetailInfo extends StatelessWidget {
  const DeviceDetailInfo({
    super.key,
    this.deviceDetail,
  });

  final DeviceDetail? deviceDetail;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          _buildInfoDevice(),
          height20,
          _buildInfoSupplies(),
          height24,
        ],
      ),
    );
  }

  Widget _buildInfoDevice() {
    return InfoCard(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      title: BS.current.detail_info,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            height20,
            LabelValue(
              labelText: BS.current.vendor,
              valueText: deviceDetail?.vendor?.name ?? '',
              isBoldValue: false,
            ),
            height12,
            LabelValue(
              labelText: BS.current.manufacturer,
              valueText: deviceDetail?.manufacturer ?? '',
              isBoldValue: false,
            ),
            height12,
            const Divider(),
            height12,
            LabelValue(
              labelText: BS.current.device_group,
              valueText:
                  deviceDetail?.deviceGroup?.articleDeviceGroup?.name ?? '',
              isBoldValue: false,
            ),
            height12,
            LabelValue(
              labelText: BS.current.model,
              valueText: deviceDetail?.model ?? '',
              isBoldValue: false,
            ),
            height12,
            LabelValue(
              labelText: BS.current.manufacture_date,
              isBoldValue: false,
              valueText: DateUtilsFormat.toDateTimeString(
                deviceDetail?.manufactureDate,
                format: Constants.dateDisplayFormat,
              ),
            ),
            height12,
            LabelValue(
              labelText: BS.current.warranty_period,
              valueText: deviceDetail?.warrantyPeriod == null
                  ? ''
                  : '${deviceDetail?.warrantyPeriod} ${BS.current.month}',
              isBoldValue: false,
            ),
            height12,
          ],
        ),
      ),
    );
  }

  Widget _buildInfoSupplies() {
    return InfoCard(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      title: BS.current.supplies,
      child: Padding(
        padding: const EdgeInsets.only(top: 20),
        child: _buildListSupplies(),
      ),
    );
  }

  Widget _buildListSupplies() {
    final supplies = deviceDetail?.supplies ?? [];

    String estimateUsedTime(num? estimateUsedTime) {
      if (estimateUsedTime == null) {
        return '';
      }
      return '${estimateUsedTime.toString()} ${BS.current.minute}';
    }

    return ListView.builder(
      itemCount: supplies.length,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemBuilder: (context, index) {
        final supply = supplies[index];

        final List<String> supplyTitle = [];
        if (supply.name.isNotBlank) {
          supplyTitle.add(supply.name ?? '');
        }
        if (!supply.nameOther.isNullOrBlank) {
          supplyTitle.add(supply.nameOther ?? '');
        }

        if (supply.code.isNotBlank) {
          supplyTitle.add(supply.code ?? '');
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: RichText(
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: supplyTitle.isEmpty ? '' : supplyTitle.join(' - '),
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        color: AppColors.orange,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            height12,
            LabelValue(
              labelText: BS.current.supply_type,
              valueText: supply.supplyType?.name,
              padding: const EdgeInsets.symmetric(horizontal: 16),
            ),
            height12,
            LabelValue(
              labelText: BS.current.quantity,
              valueText: supply.quantity?.toString(),
              padding: const EdgeInsets.symmetric(horizontal: 16),
            ),
            height12,
            LabelValue(
              labelText: BS.current.duration_use,
              valueText: estimateUsedTime(supply.estimateUsedTime),
              padding: const EdgeInsets.symmetric(horizontal: 16),
            ),
            height12,
            const Divider(
              color: Colors.grey,
              height: 1,
              thickness: 0.8,
            ),
            height12
          ],
        );
      },
    );
  }
}
