import 'package:dio/dio.dart';

import '../../../../../../../core/pull_refresh/pull_refresh.dart';
import '../../../../../domain/request/device_activity_request.dart';
import '../../../../../domain/usecase/get_device_activity_history.dart';
import '../../../../extensions/cubit_ext.dart';
import '../../../../extensions/dio_error_ext.dart';
import 'activity_history_state.dart';

class ActivityHistoryCubit extends BaseListCubit<ActivityHistoryState> {
  bool? isDisplay;
  late DeviceActivityHistoryRequest query;
  String? deviceId;
  DeviceActivityHistoryUsecase deviceActivityHistoryUsecase;

  ActivityHistoryCubit(
    this.deviceActivityHistoryUsecase,
    this.deviceId,
  ) : super.value(ActivityHistoryState());

  @override
  void start() {
    query = DeviceActivityHistoryRequest(deviceId: deviceId ?? '');
    getDeviceActivityHistory();
    super.start();
  }

  Future<void> getDeviceActivityHistory() async {
    try {
      query.setPage = page;
      if (isRefresh()) {
        showLoading();
      }
      final deviceActivityHistory =
          await deviceActivityHistoryUsecase.execute(query);

      showContent(value.copyWith(deviceActivityHistory: deviceActivityHistory));
      dispatchResult(newData: deviceActivityHistory);
    } on DioError catch (e) {
      showPopUpException(e);
      dispatchResult(exception: e.toApiException().message);
    } on Exception catch (error) {
      showPopUpException(error);
      dispatchResult(exception: error.toString());
    }
  }

  @override
  Future<void> onLoadMore() async {
    await getDeviceActivityHistory();
  }

  @override
  void refresh() {
    super.refresh();
    emitNewValue(value.copyWith(deviceActivityHistory: []));
    getDeviceActivityHistory();
  }
}
