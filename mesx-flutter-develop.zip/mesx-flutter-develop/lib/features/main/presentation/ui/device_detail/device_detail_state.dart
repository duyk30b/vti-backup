import 'dart:io';

import '../../../domain/enum/device_enum.dart';
import '../../../domain/model/area_info.dart';
import '../../../domain/model/device_activity_history.dart';
import '../../../domain/model/device_detail.dart';
import '../../../domain/model/factory_info.dart';
import '../../../domain/model/job.dart';

class DeviceDetailState {
  final bool isDisplayImage;
  final File? imageFile;
  final List<DeviceActivityHistory>? historyActivity;
  final DeviceDetail? deviceDetail;
  final List<Job>? jobList;

  DeviceUsageStatus? usageStatus;

  DeviceDetailState({
    this.isDisplayImage = true,
    this.imageFile,
    this.historyActivity,
    this.deviceDetail,
    this.jobList = const [],
    this.usageStatus,
  });

  DeviceDetailState copyWith({
    bool? isDisplayImage,
    File? imageFile,
    List<DeviceActivityHistory>? historyActivity,
    DeviceDetail? deviceDetail,
    List<Job>? jobList,
    List<FactoryInfo>? factoryList,
    List<AreaInfo>? areaList,
    DeviceUsageStatus? usageStatus,
  }) {
    return DeviceDetailState(
      isDisplayImage: isDisplayImage ?? this.isDisplayImage,
      imageFile: imageFile ?? this.imageFile,
      historyActivity: historyActivity ?? this.historyActivity,
      deviceDetail: deviceDetail ?? this.deviceDetail,
      jobList: jobList ?? this.jobList,
      usageStatus: usageStatus ?? this.usageStatus,
    );
  }
}
