import 'dart:io';

import 'package:image_picker/image_picker.dart';

import '../../../../../core/bloc/base_bloc.dart';
import '../../../../../core/navigation/navigate_event.dart';
import '../../../../../core/pop_up/pop_up_event.dart';
import '../../../../routes.dart';
import '../../../domain/enum/active_enum.dart';
import '../../../domain/enum/job_enum.dart';
import '../../../domain/model/area_info.dart';
import '../../../domain/model/device_detail.dart';
import '../../../domain/model/factory_info.dart';
import '../../../domain/request/area_list_request.dart';
import '../../../domain/request/base_query.dart';
import '../../../domain/request/change_device_locator_request.dart';
import '../../../domain/request/change_device_usage_status_request.dart';
import '../../../domain/request/factory_list_request.dart';
import '../../../domain/usecase/change_device_locator_usecase.dart';
import '../../../domain/usecase/change_device_usage_status_usecase.dart';
import '../../../domain/usecase/get_device_activity_history.dart';
import '../../../domain/usecase/get_device_detail_by_id_usecase.dart';
import '../../../domain/usecase/get_device_job_list.dart';
import '../../../domain/usecase/get_list_area_usecase.dart';
import '../../../domain/usecase/get_list_factory_usecase.dart';
import '../../extensions/cubit_ext.dart';
import 'device_detail_state.dart';

class DeviceDetailCubit extends BaseCubit<DeviceDetailState> {
  bool? isDisplay;
  DeviceDetail deviceInfo;
  DeviceActivityHistoryUsecase deviceActivityHistoryUsecase;
  GetDeviceDetailUseCase deviceDetailUsecase;
  GetDeviceJobListUseCase jobListUsecase;
  ChangeDeviceUsageStatusUsecase changeDeviceUsageStatusUsecase;
  GetListFactoryUsecase getListFactoryUsecase;
  GetListAreaUsecase getListAreaUsecase;
  ChangeDeviceLocatorUsecase changeDeviceLocatorUsecase;

  DeviceDetailCubit(
    this.deviceActivityHistoryUsecase,
    this.deviceDetailUsecase,
    this.changeDeviceUsageStatusUsecase,
    this.getListFactoryUsecase,
    this.getListAreaUsecase,
    this.changeDeviceLocatorUsecase,
    this.jobListUsecase,
    this.deviceInfo,
  ) : super.value(DeviceDetailState());

  @override
  void start() {
    getDeviceDetail(deviceInfo.id ?? '');
    getDeviceJobList();
  }

  void changeDisplayImage() {
    emitNewValue(value.copyWith(isDisplayImage: !value.isDisplayImage));
  }

  Future getImage(ImageSource source) async {
    final image = await ImagePicker().pickImage(source: source);
    if (image != null) {
      final imageTemporary = File(image.path);
      emitNewValue(value.copyWith(imageFile: imageTemporary));
    }
    return;
  }

  void backToHome() {
    emitNewEvent(NavigateEvent.pushReplacementNamed(Routes.home.path));
  }

  Future<List<FactoryInfo>> getListFactory(String keyword) async {
    final query = FactoryListRequest();
    query.setFilter('active', ActiveEnum.active.activeEnum.toString());
    query.setKeyword = keyword;
    final factoryList = await getListFactoryUsecase.execute(query);
    return factoryList;
  }

  Future<List<AreaInfo>> getListArea(String keyword, int? factoryId) async {
    if (factoryId == null) {
      return [];
    }
    final query = AreaListRequest();
    query.setFilter('active', ActiveEnum.active.activeEnum.toString());
    query.setFilter('factoryId', factoryId.toString());
    query.setKeyword = keyword;
    final areaList = await getListAreaUsecase.execute(query);
    return areaList;
  }

  Future submitChangeDeviceUsageStatus(String id, int status) async {
    try {
      showProgress();
      final res = await changeDeviceUsageStatusUsecase.execute(
        DeviceUsageStatusRequest(
          id,
          status,
        ),
      );
      hideProgress();
      emitNewEvent(NavigateEvent.pop(true));
      emitNewEvent(PopUpMsgEvent.success(res.message));
      refresh();
    } on Exception catch (error) {
      hideProgress();
      showPopUpException(error);
      showContent();
    }
  }

  Future submitChangeLocatorDevice(
    String id,
    int factoryId,
    String? areaId,
  ) async {
    try {
      showProgress();
      final res = await changeDeviceLocatorUsecase.execute(
        ChangeDeviceLocatorRequest(
          id,
          areaId,
          factoryId,
        ),
      );
      hideProgress();
      emitNewEvent(NavigateEvent.pop(true));
      emitNewEvent(PopUpMsgEvent.success(res.message));
      refresh();
    } on Exception catch (error) {
      hideProgress();
      showPopUpException(error);
      showContent();
    }
  }

  Future<void> getDeviceDetail(String id) async {
    try {
      showLoading();
      final result = await deviceDetailUsecase.execute(id);
      showContent(
        value.copyWith(
          deviceDetail: result,
        ),
      );
    } on Exception catch (e) {
      showPopUpException(e);
      showContent();
    }
  }

  Future<void> getDeviceJobList() async {
    try {
      final query = BaseQuery();
      query.setFilter('deviceId', deviceInfo.id);
      query.setFilter('status', JobStatus.completed.status.toString());
      final result = await jobListUsecase.execute(query);
      emitNewValue(value.copyWith(jobList: result));
    } on Exception catch (e) {
      showPopUpException(e);
    }
  }

  @override
  void refresh() {
    super.refresh();
    getDeviceDetail(deviceInfo.id ?? '');
  }
}
