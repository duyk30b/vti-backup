import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../../domain/model/device_detail.dart';
import 'activity_history_cubit.dart';
import 'activity_history_widget.dart';

class ActivityHistoryPage extends StatefulWidget {
  final DeviceDetail? deviceDetail;
  const ActivityHistoryPage({
    Key? key,
    this.deviceDetail,
  }) : super(key: key);
  @override
  State<ActivityHistoryPage> createState() => _ActivityHistoryPageState();
}

class _ActivityHistoryPageState extends State<ActivityHistoryPage>
    with AutomaticKeepAliveClientMixin {
  late ActivityHistoryCubit historyJobCubit;

  @override
  void initState() {
    historyJobCubit =
        ActivityHistoryCubit(context.read(), widget.deviceDetail?.id);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return BlocProvider(
        create: (context) => historyJobCubit, child: ActivityHistoryWidget());
  }

  @override
  bool get wantKeepAlive => true;
}
