import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../../domain/model/device_detail.dart';
import 'history_job_cubit.dart';
import 'history_job_widget.dart';

class HistoryJobPage extends StatefulWidget {
  final DeviceDetail? deviceDetail;
  const HistoryJobPage({
    Key? key,
    this.deviceDetail,
  }) : super(key: key);
  @override
  State<HistoryJobPage> createState() => _HistoryJobPageState();
}

class _HistoryJobPageState extends State<HistoryJobPage>
    with AutomaticKeepAliveClientMixin {
  late HistoryJobCubit historyJobCubit;

  @override
  void initState() {
    historyJobCubit = HistoryJobCubit(context.read(), widget.deviceDetail?.id);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return BlocProvider(
        create: (context) => historyJobCubit, child: HistoryJobWidget());
  }

  @override
  bool get wantKeepAlive => true;
}
