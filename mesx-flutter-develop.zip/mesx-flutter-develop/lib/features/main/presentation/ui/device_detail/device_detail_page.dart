import 'package:flutter/material.dart';

import '../../../../../core/configs/constants_widget.dart';
import '../../../../../core/extensions/extensions.dart';
import '../../../../../core/widget/base_widget.dart';
import '../../../../../core/widget/multi_state_view_widget.dart';
import '../../../../../generated/assets/assets.gen.dart';
import '../../../../../generated/l10n.dart';
import '../../../domain/enum/permission_enum.dart';
import '../../../domain/model/device_detail.dart';
import '../../widget/appbar_widget.dart';
import '../../widget/expand_icon_widget.dart';
import '../../widget/expanded_widget.dart';
import '../../widget/guard/guard.dart';
import '../../widget/label_value.dart';
import 'device_detail_cubit.dart';
import 'device_detail_state.dart';
import 'widget/activity_history/activity_history_screen.dart';
import 'widget/detail_info.dart';
import 'widget/general_info.dart';
import 'widget/history_job/history_job_page.dart';
import 'widget/image_loader.dart';
import 'widget/maintenance_info.dart';

class DeviceDetailPage extends BaseStatefulWidget {
  final DeviceDetail deviceDetail;

  const DeviceDetailPage({
    Key? key,
    required this.deviceDetail,
  }) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return _DeviceDetailPageState();
  }
}

class _DeviceDetailPageState
    extends BaseStatefulWidgetState<DeviceDetailState, DeviceDetailCubit> {
  @override
  PreferredSizeWidget? buildAppBar(
      BuildContext context, StateWrapper<DeviceDetailState> state) {
    return AppBarWidget(
      titleString: BS.of(context).device_detail_title,
      actions: [
        Guard(
          // permission: PermissionEnum.permissionGranted,
          permission: PermissionEnum.historyActivityDevice,
          child: IconButton(
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
            onPressed: () async {
              if (context.mounted) {
                {
                  await getDeviceActivityHistory(context);
                }
              }
            },
            icon: Assets.images.svgIcon.icHistory.svg(),
          ),
        ),
        IconButton(
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(),
          onPressed: () {
            cubit(context).backToHome();
          },
          icon: Assets.images.svgIcon.icBackToHome.svg(),
        ),
      ],
    );
  }

  Future getDeviceActivityHistory(BuildContext context) {
    return showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      builder: (BuildContext contextHistory) {
        return ActivityHistoryPage(
          deviceDetail: cubit(context).deviceInfo,
        );
      },
    );
  }

  @override
  Widget buildBody(
      BuildContext context, StateWrapper<DeviceDetailState> state) {
    return MultiStateViewWidget(
      viewState: state.viewState,
      loadingWidget: buildLoading(state),
      child: Column(
        children: [
          ExpandedSection(
            expand: state.value.isDisplayImage,
            child: ConstrainedBox(
              constraints:
                  BoxConstraints(maxHeight: context.screenHeight / 2.5),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    _buildInfoDevice(context, state),
                    height8,
                    AddImageDevice(
                      title: BS.of(context).device_avatar_notification,
                      onClick: () {
                        // showModalBottomSheet(
                        //   context: context,
                        //   shape: RoundedRectangleBorder(
                        //     borderRadius: BorderRadius.circular(10),
                        //   ),
                        //   builder: (contextSheet) {
                        //     return ImagePickerWidget(onPressCamera: () {
                        //       cubit(context).getImage(ImageSource.camera);
                        //     }, onPressGallery: () {
                        //       cubit(context).getImage(ImageSource.gallery);
                        //     });
                        //   },
                        // );
                      },
                      previewImage: state.value.imageFile,
                      deviceDetail: state.value.deviceDetail,
                    ),
                  ],
                ),
              ),
            ),
          ),
          _buildExpandIcon(context, state),
          _buildTabBar(context, state),
        ],
      ),
    );
  }

  Widget _buildInfoDevice(
      BuildContext context, StateWrapper<DeviceDetailState> state) {
    final device = state.value.deviceDetail;
    return Visibility(
      visible: state.value.isDisplayImage,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            LabelValue(
              labelText: BS.of(context).device_code,
              valueText: device?.code,
            ),
            height8,
            LabelValue(
              labelText: BS.of(context).device_name,
              valueText: device?.name,
            ),
            height8,
            LabelValue(
              labelText: BS.of(context).serial,
              valueText: device?.serial,
            ),
            height8,
            LabelValue(
              labelText: BS.of(context).actual_serial,
              valueText: device?.actualSerial,
            ),
            height8,
            LabelValue(
              labelText: BS.of(context).identificationNo,
              valueText: device?.identificationNo,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildExpandIcon(
      BuildContext context, StateWrapper<DeviceDetailState> state) {
    return ExpandToggleInfoIconWidget(
      isExpanded: state.value.isDisplayImage,
      onPressed: () {
        cubit(context).changeDisplayImage();
      },
    );
  }

  Widget _buildTabBar(
      BuildContext context, StateWrapper<DeviceDetailState> state) {
    return Expanded(
      child: DefaultTabController(
        length: 4,
        child: Column(
          children: [
            _buildTabTitle(context),
            _buildTabView(context, state),
          ],
        ),
      ),
    );
  }

  Widget _buildTabTitle(BuildContext context) {
    return Container(
      constraints: const BoxConstraints.expand(height: 50),
      child: TabBar(
        indicatorWeight: 10,
        indicatorSize: TabBarIndicatorSize.tab,
        indicatorPadding: const EdgeInsets.all(10),
        isScrollable: true,
        physics: const BouncingScrollPhysics(),
        onTap: (int index) {},
        enableFeedback: true,
        tabs: [
          Tab(text: BS.of(context).general_info),
          Tab(text: BS.of(context).detail),
          Tab(text: BS.of(context).maintenance_params),
          Tab(text: BS.of(context).history_job),
        ],
      ),
    );
  }

  Widget _buildTabView(
      BuildContext context, StateWrapper<DeviceDetailState> state) {
    final device = state.value.deviceDetail;
    return Expanded(
      child: SizedBox(
        child: TabBarView(
          children: [
            GeneralInfo(
              context: context,
              deviceDetail: device,
              state: state,
            ),
            DeviceDetailInfo(
              deviceDetail: device,
            ),
            DeviceMaintenanceInfo(
              deviceDetail: device,
            ),
            HistoryJobPage(
              deviceDetail: device,
            )
          ],
        ),
      ),
    );
  }
}
