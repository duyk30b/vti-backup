import 'package:async/async.dart';
import 'package:dio/dio.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';

import '../../../../../core/navigation/navigate_event.dart';
import '../../../../../core/pop_up/pop_up_event.dart';
import '../../../../../core/pull_refresh/pull_refresh.dart';
import '../../../../../core/utils/validator.dart';
import '../../../../../generated/l10n.dart';
import '../../../../routes.dart';
import '../../../domain/model/device_detail.dart';
import '../../../domain/model/device_list.dart';
import '../../../domain/request/device_list_request.dart';
import '../../../domain/usecase/fetch_device_list_usecase.dart';
import '../../../domain/usecase/scan_device_usecase.dart';
import '../../extensions/cubit_ext.dart';
import '../../extensions/dio_error_ext.dart';
import 'device_state.dart';

class DeviceCubit extends BaseListCubit<DeviceState> with Validator {
  final DeviceListUsecase deviceListUsecase;
  ScanDeviceUseCase scanDeviceUseCase;
  DeviceListRequest query = DeviceListRequest();
  CancelableOperation? cancelableOperation;

  DeviceCubit(
    this.deviceListUsecase,
    this.scanDeviceUseCase,
  ) : super.value(DeviceState());

  @override
  Future<void> start() async {
    await handleFetchDeviceList();
  }

  void onChangeKeyword(String keyword) {
    super.refresh();
    query.setKeyword = keyword;
    emitNewValue(value.copyWith(deviceList: [], total: 0));

    handleFetchDeviceList();
  }

  void navigateToDeviceDetails(DeviceDetail device) {
    emitNewEvent(
      NavigateEvent.pushNamed(
        Routes.deviceDetail.path,
        arguments: {
          'device': device,
        },
      ),
    );
  }

  Future<void> handleFetchDeviceList() async {
    try {
      if (isRefresh()) {
        showLoading();
      }
      await cancelableOperation?.cancel();

      cancelableOperation = CancelableOperation.fromFuture(
        _getData(),
      );
      final DeviceList deviceList = await cancelableOperation?.value;

      final listDevice = deviceList.data;
      final newList = [...value.deviceList, ...listDevice];
      if (listDevice.isEmpty) {
        showEmpty();
      } else {
        showContent(
          value.copyWith(
            deviceList: newList,
            total: deviceList.total,
          ),
        );
        dispatchResult(newData: listDevice);
      }
    } on DioError catch (e) {
      dispatchResult(exception: e.toApiException().message);
    } on Exception catch (error) {
      handleException(error);
    }
  }

  void onNavigateToQRScan() {
    emitNewEvent(NavigateEvent.pushNamed(Routes.qrCode.path));
  }

  Future<void> onScanQRCode(String code) async {
    try {
      showProgress();
      if (!validatorQRCode(code)) {
        throw Exception(BS.current.data_not_found);
      }
      final deviceDetail = await scanDeviceUseCase.execute(code);
      hideProgress();
      emitNewEvent(
        NavigateEvent.pushNamed(
          Routes.deviceDetail.path,
          arguments: {
            'device': deviceDetail,
          },
        ),
      );
    } on Exception catch (e) {
      hideProgress();
      showPopUpException(e, message: BS.current.qr_data_not_found);
    }
  }

  @override
  Future<void> onEventResult(dynamic event, dynamic response) async {
    if (event is NavigateEvent) {
      if (response is Barcode) {
        await onScanQRCode(response.code ?? '');
      } else {
        refresh();
      }
    }
    if (event is PopUpMsgEvent) {
      if (event.type == PopUpType.failed &&
          event.message == BS.current.qr_data_not_found) {
        onNavigateToQRScan();
      }
    }
  }

  @override
  void refresh() {
    super.refresh();
    emitNewValue(value.copyWith(deviceList: [], total: 0));
    handleFetchDeviceList();
  }

  @override
  Future<void> onLoadMore() async {
    await handleFetchDeviceList();
  }

  Future<DeviceList> _getData() async {
    return deviceListUsecase.execute(query);
  }
}
