import '../../../domain/model/device_detail.dart';

class DeviceState {
  final List<DeviceDetail> deviceList;
  final int total;

  DeviceState({this.deviceList = const [], this.total = 0});

  DeviceState copyWith({
    List<DeviceDetail>? deviceList,
    int? total,
  }) {
    return DeviceState(
      deviceList: deviceList ?? this.deviceList,
      total: total ?? this.total,
    );
  }
}
