import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../../core/bloc/state_wrapper.dart';
import '../../../../../core/configs/app_colors.dart';
import '../../../../../core/configs/constants_widget.dart';
import '../../../../../core/extensions/extensions.dart';
import '../../../../../core/pull_refresh/pull_refresh.dart';
import '../../../../../core/widget/multi_state_view_widget.dart';
import '../../../../../generated/assets/assets.gen.dart';
import '../../../../../generated/l10n.dart';
import '../../../domain/enum/permission_enum.dart';
import '../../../domain/model/device_detail.dart';
import '../../widget/appbar_widget.dart';
import '../../widget/search_box.dart';
import 'device_cubit.dart';
import 'device_state.dart';

class DevicePage extends BaseListPage<DeviceState, DeviceCubit>
    with BaseListPageMixin<DeviceState, DeviceCubit> {
  DevicePage({super.key});

  @override
  PreferredSizeWidget? buildAppBar(
      BuildContext context, StateWrapper<DeviceState> state) {
    return AppBarWidget(
      titleString: BS.current.device_title,
      isShowShadow: true,
      actions: [
        IconButton(
          onPressed: () {
            cubit(context).onNavigateToQRScan();
          },
          icon: Assets.images.svgIcon.icScan.svg(),
        ),
      ],
    );
  }

  @override
  Widget buildBody(BuildContext context, StateWrapper<DeviceState> state) {
    return Column(
      children: [
        SearchBox(
          hint: BS.current.device_search_title,
          maxLength: 255,
          onSearch: (value) => {
            cubit(context).onChangeKeyword(value.trim()),
          },
        ),
        height12,
        _buildTotal(context, state),
        _buildListDevice(context, state),
      ],
    );
  }

  Widget _buildTotal(BuildContext context, StateWrapper<DeviceState> state) {
    final total = state.value.total;
    return Container(
      margin: const EdgeInsets.only(left: 24),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Text(
          '${BS.current.device_title_list} ($total)',
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildListDevice(
      BuildContext context, StateWrapper<DeviceState> state) {
    return Expanded(
      child: MultiStateViewWidget(
        viewState: state.viewState,
        loadingWidget: buildLoading(state),
        emptyWidget: buildEmpty(state),
        errorWidget: buildError(state),
        message: message(state),
        child: generateList(
          context,
          ListView.builder(
            itemBuilder: (_, index) {
              final item = state.value.deviceList[index];
              return Container(
                child: _buildItem(context, item),
              );
            },
            itemCount: state.value.deviceList.length,
          ),
        ),
      ),
    );
  }

  Widget _buildItem(BuildContext context, DeviceDetail device) {
    final String code = device.code ?? '';
    final String name = device.name ?? '';
    final String serial = device.serial ?? '';
    final String identificationNo = device.identificationNo ?? '';

    final bool canViewDetail =
        context.canAccess(permission: PermissionEnum.detailDevice);
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            width: 1,
            color: AppColors.plashWhite,
          ),
        ),
      ),
      child: ListTile(
        onTap: () {
          if (canViewDetail) {
            cubit(context).navigateToDeviceDetails(device);
          }
        },
        title: Padding(
          padding: const EdgeInsets.only(bottom: 6.0),
          child: Wrap(
            children: [
              Text(
                '$name ',
                style: GoogleFonts.inter(
                  fontWeight: FontWeight.w600,
                  fontSize: 16,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              Text(
                '($code)',
                style: GoogleFonts.inter(
                  fontWeight: FontWeight.w400,
                  fontSize: 16,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${BS.current.serial}: $serial',
              style: Theme.of(context).textTheme.bodyMedium,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            height4,
            Text(
              '${BS.current.identificationNo}: $identificationNo',
              style: Theme.of(context).textTheme.bodyMedium,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
        trailing: SizedBox(
          height: double.infinity,
          child: Assets.images.svgIcon.arrowRight.svg(),
        ),
      ),
    );
  }
}
