import '../../domain/model/supply_request.dart';
import '../../domain/repository/supply_request_repository.dart';
import '../../domain/request/supply_request_form_payload.dart';
import '../../domain/request/supply_request_list_query_request.dart';
import '../network/base_response/base_response.dart';
import '../network/mapper/supply_request_mapper.dart';
import '../network/network_manager.dart';

class SupplyRequestRepositoryImpl extends SupplyRequestRepository {
  final NetworkManager networkManager;

  SupplyRequestRepositoryImpl(this.networkManager);

  @override
  Future<List<SupplyRequest>> getListSupplyRequest(
      SupplyRequestListQuery params) async {
    final queryParams = params.toJson();
    final response =
        await networkManager.primaryApi.getSupplyRequestList(queryParams);
    final list = <SupplyRequest>[];
    for (final item in response.data) {
      list.add(SupplyRequestMapperImpl().fromSupplyRequestDTO(item));
    }
    return list;
  }

  @override
  Future<SupplyRequest> getSupplyRequestDetailById(String id) async {
    final response = await networkManager.primaryApi.getSupplyRequestDetail(id);
    final dto = response.data;
    return SupplyRequestMapperImpl().fromSupplyRequestDTO(dto);
  }

  @override
  Future<BaseResponseNoData> confirmSupplyRequest(String id) async {
    return networkManager.primaryApi.confirmSupplyRequest(id);
  }

  @override
  Future<BaseResponseNoData> rejectSupplyRequest(String id) async {
    return networkManager.primaryApi.rejectSupplyRequest(id);
  }

  @override
  Future<BaseResponseNoData> deleteSupplyRequest(String id) async {
    return networkManager.primaryApi.deleteSupplyRequest(id);
  }

  @override
  Future<BaseResponseNoData> createSupplyRequest(
      SupplyRequestFormPayload params) async {
    final response =
        await networkManager.primaryApi.createSupplyRequest(params.toJson());

    return response;
  }

  @override
  Future<BaseResponseNoData> updateSupplyRequest(
      SupplyRequestFormPayload params, String id) async {
    final response = await networkManager.primaryApi
        .updateSupplyRequest(params.toJson(), id);

    return response;
  }
}
