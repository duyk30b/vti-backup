import '../../domain/model/device_assignment.dart';
import '../../domain/repository/device_assignment_repository.dart';
import '../../domain/request/base_query.dart';
import '../network/mapper/device_assignment_mapper.dart';
import '../network/network_manager.dart';

class DeviceAssignmentRepositoryImpl extends DeviceAssignmentRepository {
  final NetworkManager networkManager;

  DeviceAssignmentRepositoryImpl(this.networkManager);

  DeviceAssignmentMapperImpl deviceAssignmentMapperImpl =
      DeviceAssignmentMapperImpl();

  @override
  Future<List<DeviceAssignment>> getDeviceAssignMentList(
      BaseQuery params) async {
    final queryParams = params.toJson();
    final response =
        await networkManager.primaryApi.getDeviceAssignmentList(queryParams);
    final list = <DeviceAssignment>[];
    for (final element in response.data) {
      list.add(deviceAssignmentMapperImpl.fromDeviceAssignmentDTO(element));
    }
    return list;
  }

  @override
  Future<DeviceAssignment> getDeviceAssignMentDetail(String params) async {
    final response =
        await networkManager.primaryApi.getDeviceAssignmentDetail(params);

    return deviceAssignmentMapperImpl.fromDeviceAssignmentDTO(response.data);
  }
}
