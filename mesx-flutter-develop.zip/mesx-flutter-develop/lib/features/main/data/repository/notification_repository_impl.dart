import '../../domain/repository/notification_repository.dart';

import '../network/network_manager.dart';
import '../network/response/list_notification_response.dart';

class NotificationRepositoryImpl extends NotificationRepository {
  final NetworkManager networkManager;

  NotificationRepositoryImpl(this.networkManager);

  @override
  Future<ListNotificationResponse> getListNotification(
      int limit, int page, String type) async {
    final response =
        await networkManager.primaryApi.getListNotification(limit, page, type);
    return response;
  }

  @override
  Future readNotificationID(String id) {
    return networkManager.primaryApi.readNotificationID(id);
  }

  @override
  Future readAllNotification() {
    return networkManager.primaryApi.readAllNotification();
  }
}
