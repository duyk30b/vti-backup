import '../../domain/model/supply.dart';
import '../../domain/model/supply_type.dart';
import '../../domain/repository/supply_repository.dart';
import '../../domain/request/base_query.dart';
import '../../domain/request/get_stock_supply_by_warehouse.dart';
import '../network/mapper/supply_mapper.dart';
import '../network/mapper/supply_type_mapper.dart';
import '../network/network_manager.dart';
import '../network/response/inventory_list_response.dart';

class SupplyRepositoryImpl extends SupplyRepository {
  final NetworkManager networkManager;

  SupplyRepositoryImpl(this.networkManager);

  @override
  Future<List<Supply>> getListSupply(BaseQuery params) async {
    final queryParams = params.toJson();
    final response = await networkManager.primaryApi.getSupplyList(queryParams);
    return SupplyMapperImpl().fromSupplyListDTO(response.data);
  }

  @override
  Future<Supply> getStockSupplyByWarehouse(
      GetStockSupplyByWarehouseRequest params) async {
    var response = await networkManager.primaryApi.getSupplyStockByWarehouse(
        params.supplyId, params.warehouseId, params.toJson());
    return SupplyMapperImpl().fromSupplyDTO(response.data);
  }

  @override
  Future<InventoryListResponse> getListInventories(
      String type, BaseQuery params) async {
    var response = await networkManager.primaryApi
        .getListInventories(type, params.toJson());
    return response;
  }

  @override
  Future<Supply> getSupplyDetail(String params) async {
    var response = await networkManager.primaryApi.getSupplyDetail(params);
    return SupplyMapperImpl().fromSupplyDTO(response.data);
  }

  @override
  Future<List<SupplyType>> getSupplyTypeList(BaseQuery params) async {
    final queryParams = params.toJson();
    var response =
        await networkManager.primaryApi.getSupplyTypeList(queryParams);

    List<SupplyType> list = [];
    for (final item in response.data) {
      list.add(SupplyTypeMapperImpl().fromSupplyTypeDTO(item));
    }
    return list;
  }
}
