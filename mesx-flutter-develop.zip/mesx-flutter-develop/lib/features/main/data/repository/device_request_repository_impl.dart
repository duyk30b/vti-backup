import '../../domain/model/device_request.dart';
import '../../domain/model/paging_model.dart';
import '../../domain/repository/device_request_repository.dart';
import '../../domain/request/base_query.dart';
import '../network/mapper/device_request_mapper.dart';
import '../network/network_manager.dart';

class DeviceRequestRepositoryImpl extends DeviceRequestRepository {
  final NetworkManager networkManager;

  DeviceRequestRepositoryImpl(this.networkManager);

  DeviceRequestMapperImpl deviceRequestMapperImpl = DeviceRequestMapperImpl();

  @override
  Future<PagingModel<DeviceRequest>> getDeviceRequestList(
      BaseQuery params) async {
    final queryParams = params.toJson();
    final response =
        await networkManager.primaryApi.getDeviceRequestList(queryParams);
    final meta = response.meta;
    final list = <DeviceRequest>[];
    for (final element in response.data) {
      list.add(deviceRequestMapperImpl.fromDeviceRequestDTO(element));
    }
    return PagingModel(list, meta.total, meta.page);
  }

  @override
  Future<DeviceRequest> getDeviceRequestDetail(String id) async {
    final response = await networkManager.primaryApi.getDeviceRequestDetail(id);
    return deviceRequestMapperImpl.fromDeviceRequestDTO(response.data);
  }
}
