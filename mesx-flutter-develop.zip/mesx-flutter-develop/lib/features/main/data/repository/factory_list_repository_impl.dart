import '../../domain/model/factory_info.dart';
import '../../domain/repository/factory_list_repository.dart';
import '../../domain/request/factory_list_request.dart';
import '../network/mapper/factory_list_mapper.dart';
import '../network/network_manager.dart';

class FactoryListRepositoryImpl extends FactoryListRepository {
  final NetworkManager networkManager;

  FactoryListRepositoryImpl(this.networkManager);

  @override
  Future<List<FactoryInfo>> getListFactory(FactoryListRequest params) async {
    final queryParams = params.toJson();
    final response = await networkManager.primaryApi.getListFactories(
      queryParams,
    );
    final listFactory = <FactoryInfo>[];
    for (final factory in response.data) {
      listFactory.add(FactoryListMapperImpl().fromFactoryDTO(factory));
    }
    return listFactory;
  }
}
