import '../../domain/model/device_activity_history.dart';
import '../../domain/repository/device_activity_history_repository.dart';
import '../../domain/request/device_activity_request.dart';
import '../network/mapper/device_activity_history_mapper.dart';
import '../network/network_manager.dart';

class DeviceActivityHistoryRepoImpl extends DeviceActivityHistoryRepo {
  final NetworkManager networkManager;

  DeviceActivityHistoryRepoImpl(this.networkManager);

  @override
  Future<List<DeviceActivityHistory>> getDeviceActivityHistory(
      DeviceActivityHistoryRequest params) async {
    final response = await networkManager.primaryApi
        .getDeviceActivityHistory(params.deviceId, params.toJson());
    final listHistory = <DeviceActivityHistory>[];
    for (final history in response.data) {
      listHistory.add(DeviceActivityHistoryMapperImpl()
          .fromDeviceActivityHistoryDTO(history));
    }
    return listHistory;
  }
}
