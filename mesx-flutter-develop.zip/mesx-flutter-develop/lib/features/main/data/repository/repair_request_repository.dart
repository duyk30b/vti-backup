import '../../domain/model/paging_model.dart';
import '../../domain/model/repair_request.dart';
import '../../domain/repository/repair_request_repository.dart';
import '../../domain/request/base_query.dart';

import '../../domain/request/create_repair_request.dart';
import '../network/base_response/base_response.dart';
import '../network/mapper/repair_request_mapper.dart';
import '../network/network_manager.dart';

class RepairRequestRepositoryImpl extends RepairRequestRepository {
  final NetworkManager networkManager;

  RepairRequestRepositoryImpl(this.networkManager);

  @override
  Future<PagingModel<RepairRequest>> getRepairRequestList(
      BaseQuery params) async {
    final queryParams = params.toJson();
    final response =
        await networkManager.primaryApi.getRequestRepairList(queryParams);
    final deviceDTO = response.data;
    return RepairRequestMapperImpl()
        .fromRepairRequestListDTO(deviceDTO, response.meta);
  }

  @override
  Future<RepairRequest> getRepairRequestDetail(String params) async {
    final response =
        await networkManager.primaryApi.getRequestRepairDetail(params);
    final deviceDTO = response.data;
    return RepairRequestMapperImpl().fromRequestRepairDTO(deviceDTO);
  }

  @override
  Future<BaseResponseNoData> createRepairRequest(
      CreateRepairRequest params) async {
    final response =
        await networkManager.primaryApi.createRepairRequest(params.toJson());

    return response;
  }

  @override
  Future<BaseResponseNoData> confirmRepairRequest(String params) async {
    final response =
        await networkManager.primaryApi.confirmRepairRequest(params);
    return response;
  }

  @override
  Future<BaseResponseNoData> rejectRepairRequest(String params) async {
    final response =
        await networkManager.primaryApi.rejectRepairRequest(params);
    return response;
  }
}
