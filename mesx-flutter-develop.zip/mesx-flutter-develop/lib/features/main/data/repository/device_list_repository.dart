import '../../data/network/mapper/device_list_mapper.dart';
import '../../data/network/mapper/device_mapper.dart';
import '../../domain/model/device_detail.dart';
import '../../domain/model/device_list.dart';
import '../../domain/repository/device_list_repository.dart';
import '../../domain/request/change_device_locator_request.dart';
import '../../domain/request/device_list_request.dart';
import '../network/base_response/base_response.dart';
import '../network/network_manager.dart';

class DeviceListRepositoryImpl extends DeviceListRepository {
  final NetworkManager networkManager;

  DeviceListRepositoryImpl(this.networkManager);

  @override
  Future<DeviceList> getListDevices(DeviceListRequest params) async {
    final queryParams = params.toJson();
    final response = await networkManager.primaryApi.getListDevices(
      queryParams,
      params.isMasterData,
    );
    final deviceDTO = response.data;
    final meta = response.meta;
    return DeviceListMapper.fromDeviceListDTO(deviceDTO, meta);
  }

  @override
  Future<DeviceDetail> getDetailDeviceById(String id) async {
    final response = await networkManager.primaryApi.getDetailDeviceById(id);
    final deviceDTO = response.data;
    return DeviceMapperImpl().fromDeviceDetail(deviceDTO);
  }

  @override
  Future<BaseResponseNoData> changeDeviceUsageStatus(
      String id, int status) async {
    return networkManager.primaryApi.changeDeviceUsageStatus(id, status);
  }

  @override
  Future<BaseResponseNoData> changeDeviceLocator(
    String id,
    int factoryId,
    String? areaId,
  ) async {
    final body = ChangeDeviceLocatorRequest(id, areaId, factoryId).toJson();
    return networkManager.primaryApi.changeDeviceLocator(id, body);
  }

  @override
  Future<DeviceDetail> scanDevice(
    String params,
  ) async {
    final response = await networkManager.primaryApi.scanDevice(params);
    final deviceDTO = response.data;
    return DeviceMapperImpl().fromDeviceDetail(deviceDTO);
  }
}
