import '../../domain/model/area_info.dart';
import '../../domain/repository/area_list_repository.dart';
import '../../domain/request/area_list_request.dart';
import '../network/mapper/area_list_mapper.dart';
import '../network/network_manager.dart';

class AreaListRepositoryImpl extends AreaListRepository {
  final NetworkManager networkManager;

  AreaListRepositoryImpl(this.networkManager);

  @override
  Future<List<AreaInfo>> getListArea(AreaListRequest params) async {
    final queryParams = params.toJson();
    final response = await networkManager.primaryApi.getListAreas(queryParams);
    final listArea = <AreaInfo>[];
    for (final area in response.data) {
      listArea.add(AreaListMapperImpl().fromAreaDTO(area));
    }
    return listArea;
  }
}
