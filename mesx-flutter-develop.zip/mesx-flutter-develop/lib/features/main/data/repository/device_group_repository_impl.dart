import '../../domain/model/device_group.dart';
import '../../domain/repository/device_group_repository.dart';
import '../../domain/request/base_query.dart';
import '../network/mapper/device_group_mapper.dart';
import '../network/network_manager.dart';

class DeviceGroupRepoImpl extends DeviceGroupRepo {
  final NetworkManager networkManager;

  DeviceGroupRepoImpl(this.networkManager);

  @override
  Future<DeviceGroup> getDeviceGroupDetail(String id) async {
    final response = await networkManager.primaryApi.getDeviceGroupDetail(id);
    return DeviceGroupMapperImpl().fromDeviceGroupDTO(response.data);
  }

  @override
  Future<List<DeviceGroup>> getDeviceGroupList(BaseQuery params) async {
    var response =
        await networkManager.primaryApi.getDeviceGroupList(params.toJson());
    var listDeviceGroup = response.data
        .map((e) => DeviceGroupMapperImpl().fromDeviceGroupDTO(e))
        .toList();
    return listDeviceGroup;
  }
}
