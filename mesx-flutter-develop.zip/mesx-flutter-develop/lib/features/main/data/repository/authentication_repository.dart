import '../../domain/repository/authentication_repository.dart';
import '../../domain/request/login_request.dart';
import '../cache/cache_manager.dart';
import '../network/network_manager.dart';
import '../network/response/get_me_response.dart';
import '../network/response/login_response.dart';

class AuthenticationRepositoryIml extends AuthenticationRepository {
  final NetworkManager networkManager;
  final CacheManager cacheManager;

  AuthenticationRepositoryIml(this.networkManager, this.cacheManager);

  @override
  Future<LoginResponse> login(LoginRequest params) async {
    return networkManager.primaryApi.login(params.toJson());
  }

  @override
  bool isLogin() {
    return cacheManager.getUserToken() != null;
  }

  @override
  void saveTokenToCache(String? token, String? refreshToken) {
    cacheManager.saveUserToken(token);
    cacheManager.saveRefreshToken(refreshToken);
  }

  @override
  Future<GetMeResponse> getMe() {
    return networkManager.primaryApi.getMe();
  }
}
