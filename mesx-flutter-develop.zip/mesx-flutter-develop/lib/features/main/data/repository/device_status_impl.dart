import '../../../main/data/network/mapper/device_status_list_mapper.dart';
import '../../../main/data/network/mapper/device_status_mapper.dart';
import '../../../main/domain/model/device_status_detail.dart';
import '../../../main/domain/model/device_status_list.dart';
import '../../../main/domain/repository/device_status_repository.dart';
import '../../../main/domain/request/base_query.dart';
import '../../domain/model/device_status_detail_list.dart';
import '../../domain/request/device_status_detail_list_request.dart';
import '../../domain/request/device_status_form_request.dart';
import '../network/base_response/base_response.dart';
import '../network/network_manager.dart';

class DeviceStatusRepositoryImpl implements DeviceStatusRepository {
  final NetworkManager networkManager;

  DeviceStatusRepositoryImpl(this.networkManager);

  @override
  Future<DeviceStatusList> fetchDeviceStatusList(BaseQuery query) async {
    final queryParams = query.toJson();
    final response =
        await networkManager.primaryApi.fetchDeviceStatusList(queryParams);
    final data = response.data;
    final meta = response.meta;
    return DeviceStatusListMapper.fromDeviceStatusListDTO(data, meta);
  }

  @override
  Future<DeviceStatusDetail> getDeviceStatusDetail(String id) async {
    final response = await networkManager.primaryApi.getDeviceStatusDetail(id);
    final data = response.data;
    return DeviceStatusMapperImpl().fromDeviceStatusDetailDTO(data);
  }

  @override
  Future<DeviceStatusDetailList> fetchDeviceStatusDetailList(
      DeviceStatusDetailListRequest payload) async {
    final queryParams = payload.query?.toJson();
    final response = await networkManager.primaryApi
        .fetchDeviceStatusListDetail(
            payload.deviceStatusId ?? '', queryParams ?? {});
    final data = response.data;
    final meta = response.meta;
    return DeviceStatusListMapper.fromDeviceStatusDetailListDTO(data, meta);
  }

  @override
  Future<BaseResponseNoData> createDeviceStatus(
      DeviceStatusFormRequest payload) async {
    final response =
        await networkManager.primaryApi.createDeviceStatus(payload.toJson());
    final data = response;
    return data;
  }

  @override
  Future<BaseResponseNoData> updateDeviceStatus(
      DeviceStatusFormRequest payload) async {
    final response = await networkManager.primaryApi
        .updateDeviceStatus(payload.id ?? '', payload.toJson());
    final data = response;
    return data;
  }
}
