import 'dart:io';

import '../../domain/model/job.dart';
import '../../domain/repository/job_repository.dart';
import '../../domain/request/assign_request.dart';
import '../../domain/request/base_query.dart';
import '../network/mapper/job_list_mapper.dart';
import '../network/network_manager.dart';
import '../network/response/device_job_list_reponse.dart';
import '../network/response/job_detail_response.dart';
import '../network/response/responsible_list_response.dart';
import '../network/response/user_assign_item_response.dart';

class JobRepositoryImpl extends JobRepository {
  final NetworkManager networkManager;

  JobRepositoryImpl(this.networkManager);

  @override
  Future<List<Job>> getDeviceJobList(BaseQuery params) async {
    final queryParams = params.toJson();
    final response =
        await networkManager.primaryApi.getDeviceJobList(queryParams);
    return JobListMapperImpl().fromJobDTOList(response.data);
  }

  @override
  Future<DeviceJobListResponse> getListJob(BaseQuery params) async {
    final queryParams = params.toJson();
    final response = await networkManager.primaryApi.getListJobs(queryParams);
    return response;
  }

  @override
  Future<JobDetailResponse> getJobDetail(String id) {
    final response = networkManager.primaryApi.getJobDetail(id);
    return response;
  }

  @override
  Future confirmJob(String id, String action,
      {String? reason, int? executionTime, int? stopTime}) {
    final response = networkManager.primaryApi.confirmJob(id, action,
        reason: reason, executionTime: executionTime, stopTime: stopTime);
    return response;
  }

  @override
  Future executedJob(String id, String data, {File? file}) {
    final response =
        networkManager.primaryApi.executedJob(id, data, file: file);
    return response;
  }

  @override
  Future<UserAssignItemResponse> maintenanceTeamsAssign(String id) async {
    final response = await networkManager.primaryApi.maintenanceTeamsAssign(id);
    return response;
  }

  @override
  Future assignUser(String id, AssignRequest request) async {
    final response = await networkManager.primaryApi.assignUser(id, request);
    return response;
  }

  @override
  Future<ListResponsibleResponse> responsibleUser() async {
    final response = await networkManager.primaryApi.responsibleUser();
    return response;
  }

  @override
  Future addReason(String id, String reason) async {
    final response = await networkManager.primaryApi.addReason(id, reason);
    return response;
  }

  @override
  Future updateTaskStatus(String id, int status) async {
    final response =
        await networkManager.primaryApi.updateTaskStatus(id, status);
    return response;
  }
}
