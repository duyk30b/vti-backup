import '../../domain/model/supply_group.dart';
import '../../domain/repository/supply_group_repository.dart';
import '../../domain/request/base_query.dart';
import '../network/mapper/supply_group_mapper.dart';
import '../network/network_manager.dart';

class SupplyGroupRepositoryImpl extends SupplyGroupRepository {
  final NetworkManager networkManager;

  SupplyGroupRepositoryImpl(this.networkManager);

  SupplyGroupMapperImpl supplyGroupMapperImpl = SupplyGroupMapperImpl();

  @override
  Future<List<SupplyGroup>> getSupplyGroupList(BaseQuery params) async {
    final queryParams = params.toJson();
    final response =
        await networkManager.primaryApi.getSupplyGroupList(queryParams);
    final list = <SupplyGroup>[];
    for (final element in response.data) {
      list.add(supplyGroupMapperImpl.fromSupplyGroupDTO(element));
    }
    return list;
  }
}
