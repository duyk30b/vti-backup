import '../../domain/enum/warehouse_ticket_enum.dart';
import '../../domain/model/device_detail.dart';
import '../../domain/model/paging_model.dart';
import '../../domain/model/warehouse.dart';
import '../../domain/model/warehouse_export.dart';
import '../../domain/model/warehouse_import.dart';
import '../../domain/model/warehouse_request/warehouse_export_request.dart';
import '../../domain/model/warehouse_request/warehouse_import_request.dart';
import '../../domain/model/warehouse_ticket/warehouse_export_ticket.dart';
import '../../domain/model/warehouse_ticket/warehouse_import_ticket.dart';
import '../../domain/repository/warehouse_repository.dart';
import '../../domain/request/base_query.dart';
import '../../domain/request/device_inventory_detail_request.dart';
import '../../domain/request/warehouse_export_form_request.dart';
import '../../domain/request/warehouse_export_request_form_payload.dart';
import '../../domain/request/warehouse_export_ticket_form_payload.dart';
import '../../domain/request/warehouse_import_request.dart';
import '../../domain/request/warehouse_import_request_form_payload.dart';
import '../../domain/request/warehouse_import_ticket_form_payload.dart';
import '../network/base_response/base_response.dart';
import '../network/mapper/device_mapper.dart';
import '../network/mapper/warehouse_export_mapper.dart';
import '../network/mapper/warehouse_import_mapper.dart';
import '../network/mapper/warehouse_mapper.dart';
import '../network/mapper/warehouse_request_mapper.dart';
import '../network/mapper/warehouse_ticket_mapper.dart';
import '../network/network_manager.dart';

class WarehouseRepositoryImpl extends WarehouseRepository {
  final NetworkManager networkManager;
  final WarehouseImportMapperImpl warehouseImportMapper =
      WarehouseImportMapperImpl();
  final WarehouseExportMapperImpl warehouseExportMapper =
      WarehouseExportMapperImpl();

  final WarehouseTicketMapperImpl warehouseTicketMapper =
      WarehouseTicketMapperImpl();

  final WarehouseRequestMapperImpl warehouseRequestMapper =
      WarehouseRequestMapperImpl();

  WarehouseRepositoryImpl(this.networkManager);

  @override
  Future<List<Warehouse>> getListWarehouse(BaseQuery params) async {
    final queryParams = params.toJson();
    final response =
        await networkManager.primaryApi.getWarehouseList(queryParams);
    return WarehouseMapperImpl().fromWarehouseListDTO(response.data);
  }

  @override
  Future<PagingModel<WarehouseImport>> getWarehouseImportList(
      BaseQuery params) async {
    final queryParams = params.toJson();
    final response =
        await networkManager.primaryApi.getWarehouseImportList(queryParams);
    final meta = response.meta;
    final List<WarehouseImport> list = [];
    for (final element in response.data) {
      list.add(warehouseImportMapper.fromWarehouseImportDTO(element));
    }
    return PagingModel(list, meta.total, meta.page);
  }

  @override
  Future<WarehouseImport> getWarehouseImportDetail(String params) async {
    final response =
        await networkManager.primaryApi.getWarehouseImportDetail(params);

    return warehouseImportMapper.fromWarehouseImportDTO(response.data);
  }

  @override
  Future<BaseResponseNoData> confirmWarehouseImport(String params) async {
    final response =
        await networkManager.primaryApi.confirmWarehouseImport(params);

    return response;
  }

  @override
  Future<BaseResponseNoData> rejectWarehouseImport(String params) async {
    final response =
        await networkManager.primaryApi.rejectWarehouseImport(params);

    return response;
  }

  @override
  Future<BaseResponseNoData> createWarehouseImport(
      WarehouseImportFormRequest params) async {
    final response =
        await networkManager.primaryApi.createWarehouseImport(params.toJson());

    return response;
  }

  @override
  Future<BaseResponseNoData> updateWarehouseImport(
      WarehouseImportFormRequest params, String id) async {
    final response = await networkManager.primaryApi
        .updateWarehouseImport(params.toJson(), id);

    return response;
  }

  @override
  Future<PagingModel<WarehouseExport>> getWarehouseExportList(
      BaseQuery params) async {
    final queryParams = params.toJson();
    final response =
        await networkManager.primaryApi.getWarehouseExportList(queryParams);
    final meta = response.meta;
    final List<WarehouseExport> list = [];
    for (final element in response.data) {
      list.add(warehouseExportMapper.fromWarehouseExportDTO(element));
    }
    return PagingModel(list, meta.total, meta.page);
  }

  @override
  Future<WarehouseExport> getWarehouseExportDetail(String params) async {
    final response =
        await networkManager.primaryApi.getWarehouseExportDetail(params);

    return warehouseExportMapper.fromWarehouseExportDTO(response.data);
  }

  @override
  Future<BaseResponseNoData> confirmWarehouseExport(String params) async {
    final response =
        await networkManager.primaryApi.confirmWarehouseExport(params);

    return response;
  }

  @override
  Future<BaseResponseNoData> rejectWarehouseExport(String params) async {
    final response =
        await networkManager.primaryApi.rejectWarehouseExport(params);

    return response;
  }

  @override
  Future<BaseResponseNoData> createWarehouseExport(
      WarehouseExportFormRequest params) async {
    final response =
        await networkManager.primaryApi.createWarehouseExport(params.toJson());

    return response;
  }

  @override
  Future<BaseResponseNoData> updateWarehouseExport(
      WarehouseExportFormRequest params, String id) async {
    final response = await networkManager.primaryApi
        .updateWarehouseExport(params.toJson(), id);

    return response;
  }

  @override
  Future<PagingModel<WarehouseImportTicket>> getListWarehouseImportTicket(
    BaseQuery params,
  ) async {
    final queryParams = params.toJson();
    var response = await networkManager.primaryApi.getWarehouseImportTicketList(
      queryParams,
    );

    List<WarehouseImportTicket> list = [];
    for (final element in response.data) {
      list.add(warehouseTicketMapper.fromWarehouseImportTicketDTO(element));
    }
    return PagingModel(list, response.meta.total, response.meta.page);
  }

  @override
  Future<PagingModel<WarehouseExportTicket>> getListWarehouseExportTicket(
    BaseQuery params,
  ) async {
    final queryParams = params.toJson();
    var response = await networkManager.primaryApi.getWarehouseExportTicketList(
      queryParams,
    );

    List<WarehouseExportTicket> list = [];
    for (final element in response.data) {
      list.add(warehouseTicketMapper.fromWarehouseExportTicketDTO(element));
    }
    return PagingModel(list, response.meta.total, response.meta.page);
  }

  @override
  Future<BaseResponseNoData> rejectWarehouseTicket(
      String params, WarehouseTicketTypeEnum ticketType) async {
    BaseResponseNoData response;

    if (ticketType == WarehouseTicketTypeEnum.import) {
      response = await networkManager.primaryApi.rejectWarehouseImportTicket(
        params,
      );
    } else {
      response = await networkManager.primaryApi.rejectWarehouseExportTicket(
        params,
      );
    }

    return response;
  }

  @override
  Future<BaseResponseNoData> confirmWarehouseTicket(
      String params, WarehouseTicketTypeEnum ticketType) async {
    BaseResponseNoData response;

    if (ticketType == WarehouseTicketTypeEnum.import) {
      response = await networkManager.primaryApi.confirmWarehouseImportTicket(
        params,
      );
    } else {
      response = await networkManager.primaryApi.confirmWarehouseExportTicket(
        params,
      );
    }

    return response;
  }

  @override
  Future<BaseResponseNoData> deleteWarehouseTicket(
      String params, WarehouseTicketTypeEnum ticketType) async {
    BaseResponseNoData response;

    if (ticketType == WarehouseTicketTypeEnum.import) {
      response = await networkManager.primaryApi.deleteWarehouseImportTicket(
        params,
      );
    } else {
      response = await networkManager.primaryApi.deleteWarehouseExportTicket(
        params,
      );
    }

    return response;
  }

  @override
  Future<PagingModel<WarehouseImportRequest>> getListWarehouseImportRequest(
    BaseQuery params,
  ) async {
    final queryParams = params.toJson();
    var response =
        await networkManager.primaryApi.getWarehouseImportRequestList(
      queryParams,
    );

    List<WarehouseImportRequest> list = [];
    for (final element in response.data) {
      list.add(warehouseRequestMapper.fromWarehouseImportRequestDTO(element));
    }
    return PagingModel(list, response.meta.total, response.meta.page);
  }

  @override
  Future<PagingModel<WarehouseExportRequest>> getListWarehouseExportRequest(
    BaseQuery params,
  ) async {
    final queryParams = params.toJson();
    var response =
        await networkManager.primaryApi.getWarehouseExportRequestList(
      queryParams,
    );

    List<WarehouseExportRequest> list = [];
    for (final element in response.data) {
      list.add(warehouseRequestMapper.fromWarehouseExportRequestDTO(element));
    }
    return PagingModel(list, response.meta.total, response.meta.page);
  }

  @override
  Future<WarehouseImportRequest> getWarehouseImportRequestDetail(
    String params,
  ) async {
    var response =
        await networkManager.primaryApi.getWarehouseImportRequestDetail(
      params,
    );

    return warehouseRequestMapper.fromWarehouseImportRequestDTO(response.data);
  }

  @override
  Future<WarehouseExportRequest> getWarehouseExportRequestDetail(
    String params,
  ) async {
    var response =
        await networkManager.primaryApi.getWarehouseExportRequestDetail(
      params,
    );

    return warehouseRequestMapper.fromWarehouseExportRequestDTO(response.data);
  }

  @override
  Future<WarehouseImportTicket> getWarehouseImportTicketDetail(
    String params,
  ) async {
    var response =
        await networkManager.primaryApi.getWarehouseImportTicketDetail(
      params,
    );

    return warehouseTicketMapper.fromWarehouseImportTicketDTO(response.data);
  }

  @override
  Future<WarehouseExportTicket> getWarehouseExportTicketDetail(
    String params,
  ) async {
    var response =
        await networkManager.primaryApi.getWarehouseExportTicketDetail(
      params,
    );

    return warehouseTicketMapper.fromWarehouseExportTicketDTO(response.data);
  }

  @override
  Future<BaseResponseNoData> createWarehouseImportTicket(
    WarehouseImportTicketFormPayload params,
  ) async {
    var response = await networkManager.primaryApi.createWarehouseImportTicket(
      params.toJson(),
    );

    return response;
  }

  @override
  Future<BaseResponseNoData> updateWarehouseImportTicket(
    WarehouseImportTicketFormPayload params,
  ) async {
    var response = await networkManager.primaryApi.updateWarehouseImportTicket(
      params.id ?? '',
      params.toJson(),
    );

    return response;
  }

  @override
  Future<BaseResponseNoData> createWarehouseExportTicket(
    WarehouseExportTicketFormPayload params,
  ) async {
    var response = await networkManager.primaryApi.createWarehouseExportTicket(
      params.toJson(),
    );

    return response;
  }

  @override
  Future<BaseResponseNoData> updateWarehouseExportTicket(
    WarehouseExportTicketFormPayload params,
  ) async {
    var response = await networkManager.primaryApi.updateWarehouseExportTicket(
      params.id ?? '',
      params.toJson(),
    );

    return response;
  }

  @override
  Future<BaseResponseNoData> rejectWarehouseRequest(
      String params, WarehouseTicketTypeEnum ticketType) async {
    BaseResponseNoData response;

    if (ticketType == WarehouseTicketTypeEnum.import) {
      response = await networkManager.primaryApi.rejectWarehouseImportRequest(
        params,
      );
    } else {
      response = await networkManager.primaryApi.rejectWarehouseExportRequest(
        params,
      );
    }

    return response;
  }

  @override
  Future<BaseResponseNoData> confirmWarehouseRequest(
      String params, WarehouseTicketTypeEnum ticketType) async {
    BaseResponseNoData response;

    if (ticketType == WarehouseTicketTypeEnum.import) {
      response = await networkManager.primaryApi.confirmWarehouseImportRequest(
        params,
      );
    } else {
      response = await networkManager.primaryApi.confirmWarehouseExportRequest(
        params,
      );
    }

    return response;
  }

  @override
  Future<BaseResponseNoData> deleteWarehouseRequest(
      String params, WarehouseTicketTypeEnum ticketType) async {
    BaseResponseNoData response;

    if (ticketType == WarehouseTicketTypeEnum.import) {
      response = await networkManager.primaryApi.deleteWarehouseImportRequest(
        params,
      );
    } else {
      response = await networkManager.primaryApi.deleteWarehouseExportRequest(
        params,
      );
    }

    return response;
  }

  @override
  Future<BaseResponseNoData> createWarehouseImportRequest(
      WarehouseImportRequestFormPayload params) async {
    var response = await networkManager.primaryApi.createWarehouseImportRequest(
      params.toJson(),
    );

    return response;
  }

  @override
  Future<BaseResponseNoData> updateWarehouseImportRequest(
      WarehouseImportRequestFormPayload params) async {
    var response = await networkManager.primaryApi.updateWarehouseImportRequest(
      params.id ?? '',
      params.toJson(),
    );

    return response;
  }

  @override
  Future<BaseResponseNoData> createWarehouseExportRequest(
      WarehouseExportRequestFormPayload params) async {
    var response = await networkManager.primaryApi.createWarehouseExportRequest(
      params.toJson(),
    );

    return response;
  }

  @override
  Future<BaseResponseNoData> updateWarehouseExportRequest(
      WarehouseExportRequestFormPayload params) async {
    var response = await networkManager.primaryApi.updateWarehouseExportRequest(
      params.id ?? '',
      params.toJson(),
    );

    return response;
  }

  @override
  Future<PagingModel<DeviceDetail>> getDeviceInventoryDetail(
      DeviceInventoryDetailRequest params) async {
    var response = await networkManager.primaryApi.getDeviceInventoryDetail(
        params.warehouseId, params.deviceGroupId, params.toJson());

    List<DeviceDetail> list = [];
    for (final element in response.data) {
      list.add(DeviceMapperImpl().fromDeviceDetail(element));
    }
    return PagingModel(list, response.meta.total, response.meta.page);
  }
}
