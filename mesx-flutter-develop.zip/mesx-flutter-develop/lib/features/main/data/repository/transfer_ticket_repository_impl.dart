import '../../domain/model/paging_model.dart';
import '../../domain/model/transfer_ticket/transfer_ticket.dart';
import '../../domain/repository/transfer_ticket_repository.dart';
import '../../domain/request/base_query.dart';
import '../network/mapper/transfer_ticket_mapper.dart';
import '../network/network_manager.dart';

class TransferTicketRepositoryImpl extends TransferTicketRepository {
  final NetworkManager networkManager;

  TransferTicketRepositoryImpl(this.networkManager);

  TransferTicketMapperImpl supplyGroupMapperImpl = TransferTicketMapperImpl();

  @override
  Future<PagingModel<TransferTicket>> getTransferTicketList(
      BaseQuery params) async {
    final queryParams = params.toJson();
    final response =
        await networkManager.primaryApi.getTransferTicketList(queryParams);
    final meta = response.meta;
    final list = <TransferTicket>[];
    for (final element in response.data) {
      list.add(supplyGroupMapperImpl.fromTransferTicketDTO(element));
    }
    return PagingModel(list, meta.total, meta.page);
  }

  @override
  Future<TransferTicket> getTransferTicketDetail(String params) async {
    final response =
        await networkManager.primaryApi.getTransferTicketDetail(params);
    return supplyGroupMapperImpl.fromTransferTicketDTO(response.data);
  }
}
