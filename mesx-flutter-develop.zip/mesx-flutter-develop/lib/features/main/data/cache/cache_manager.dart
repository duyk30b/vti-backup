import 'dart:convert';

import 'package:flutter/material.dart';

import '../../../../core/cache/cache_helper.dart';
import '../../../../core/configs/app_theme.dart';
import '../../presentation/widget/language_selector/language.dart';
import '../network/model/user_info_dto.dart';

enum ThemeEnum { light, dark }

extension ThemeExtension on ThemeEnum {
  ThemeData get theme {
    switch (this) {
      case ThemeEnum.light:
        return AppTheme.lightTheme;
      case ThemeEnum.dark:
        return ThemeData.dark();
    }
  }
}

abstract class CacheKey {
  static String userToken = 'USER_TOKEN';
  static String refreshToken = 'REFRESH_TOKEN';
  static String settingTheme = 'SETTING_THEME';
  static String settingLanguage = 'SETTING_LANGUAGE';
  static String userINFO = 'USER_INFO';
  static String saveUserConfig = 'SAVE_USER_CONFIG';

  static String saveAccountLogin = 'SAVE_ACCOUNT_LOGIN';
}

abstract class CacheManager {
  //Future<bool> initialize();

  void saveUserToken(String? userToken);

  void saveRefreshToken(String? userToken);

  String? getUserToken();

  String? getRefreshToken();

  void deleteUserToken();

  String getSettingAppTheme();

  void setSettingAppTheme(ThemeEnum themeEnum);

  String getSettingAppLanguage();

  void setSettingAppLanguage(Locale language);

  void saveUserInFo(UserInfoDTO userInfo);

  bool isSaveUser();

  void saveUserConfig(bool isSave);

  Map getAccountLogin();

  void saveAccountLogin(String account, String pass);

  UserInfoDTO getUserInFo();
}

class CacheManagerImpl implements CacheManager {
  final CacheHelper cacheHelper;

  CacheManagerImpl(this.cacheHelper);

  // @override
  // Future<bool> initialize() {
  //   return cacheHelper.initialize();
  // }

  @override
  String? getUserToken() {
    return cacheHelper.get(CacheKey.userToken);
  }

  @override
  void saveUserToken(String? token) {
    cacheHelper.put(CacheKey.userToken, token);
  }

  @override
  void saveRefreshToken(String? token) {
    cacheHelper.put(CacheKey.refreshToken, token);
  }

  @override
  void deleteUserToken() {
    cacheHelper.delete(CacheKey.userToken);
    cacheHelper.delete(CacheKey.refreshToken);
  }

  @override
  String getSettingAppTheme() {
    return cacheHelper.get<String>(CacheKey.settingTheme,
        defaultValue: ThemeEnum.light.name);
  }

  @override
  void setSettingAppTheme(ThemeEnum themeEnum) {
    cacheHelper.put(CacheKey.settingTheme, themeEnum.name);
  }

  @override
  String getSettingAppLanguage() {
    return cacheHelper.get<String>(CacheKey.settingLanguage,
        defaultValue: Language.vi.name);
  }

  @override
  void setSettingAppLanguage(Locale language) {
    cacheHelper.put(CacheKey.settingLanguage, language.languageCode);
  }

  @override
  void saveUserInFo(UserInfoDTO userInfo) {
    final enCode = jsonEncode(userInfo);
    return cacheHelper.put(CacheKey.userINFO, enCode);
  }

  @override
  UserInfoDTO getUserInFo() {
    final encode = cacheHelper.get<String>(CacheKey.userINFO);
    return UserInfoDTO.fromJson(jsonDecode(encode));
  }

  @override
  bool isSaveUser() {
    return cacheHelper.get(CacheKey.saveUserConfig, defaultValue: false);
  }

  @override
  void saveUserConfig(bool isSave) {
    cacheHelper.put(CacheKey.saveUserConfig, isSave);
  }

  @override
  Map getAccountLogin() {
    return cacheHelper.get(CacheKey.saveAccountLogin, defaultValue: {});
  }

  @override
  void saveAccountLogin(String account, String pass) {
    cacheHelper
        .put(CacheKey.saveAccountLogin, {'account': account, 'pass': pass});
  }

  @override
  String? getRefreshToken() {
    return cacheHelper.get(CacheKey.refreshToken);
  }
}
