import 'package:smartstruct/smartstruct.dart';
import '../../../../main/data/network/model/attribute_type_dto.dart';
import '../../../../main/domain/model/attribute_type.dart';
import '../../../domain/model/accreditation_template.dart';
import '../../../domain/model/accreditation_template_detail.dart';
import '../../../domain/model/article_device_group.dart';
import '../../../domain/model/device_group.dart';
import '../../../domain/model/error_type.dart';
import '../../../domain/model/installation_template.dart';
import '../../../domain/model/installation_template_detail.dart';
import '../../../domain/model/maintenance_template.dart';
import '../../../domain/model/maintenance_template_detail.dart';
import '../../../domain/model/supply.dart';
import '../../../domain/model/supply_type.dart';
import '../../../domain/model/unit.dart';
import '../model/accreditation_template_detail_dto.dart';
import '../model/accreditation_template_dto.dart';
import '../model/article_device_group_dto.dart';
import '../model/device_group_dto.dart';
import '../model/error_type_dto.dart';
import '../model/installation_template_detail_dto.dart';
import '../model/installation_template_dto.dart';
import '../model/maintenance_template_detail_dto.dart';
import '../model/maintenance_template_dto.dart';
import '../model/supply_dto.dart';
import '../model/supply_type_dto.dart';
import '../model/unit_dto.dart';
import 'supply_mapper.dart';

part 'device_group_mapper.mapper.g.dart';

@Mapper()
abstract class DeviceGroupMapper {
  DeviceGroup fromDeviceGroupDTO(DeviceGroupDTO dto);

  AttributeType fromAttributeTypeDTO(AttributeTypeDTO dto);

  Unit fromUnitDTO(UnitDTO dto);

  MaintenanceTemplate fromMaintenanceTemplateDTO(MaintenanceTemplateDTO dto);
  MaintenanceTemplateDetail fromMaintenanceTemplateDetailDTO(
      MaintenanceTemplateDetailDTO dto);

  InstallationTemplate fromInstallationTemplateDTO(InstallationTemplateDTO dto);
  InstallationTemplateDetail fromInstallationTemplateDetailDTO(
      InstallationTemplateDetailDTO dto);

  AccreditationTemplate fromAccreditationTemplateDTO(
      AccreditationTemplateDTO dto);
  AccreditationTemplateDetail fromAccreditationTemplateDetailDTO(
      AccreditationTemplateDetailDTO dto);

  Supply fromSupplyDTO(SupplyDTO dto) => SupplyMapperImpl().fromSupplyDTO(dto);
  SupplyType fromSupplyTypeDTO(SupplyTypeDTO dto);

  ErrorType fromErrorTypeDTO(ErrorTypeDTO dto);

  ArticleDeviceGroup fromArticleDeviceGroupDTO(ArticleDeviceGroupDTO dto);
}
