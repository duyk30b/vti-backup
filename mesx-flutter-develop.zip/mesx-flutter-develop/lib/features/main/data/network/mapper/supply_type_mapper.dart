import 'package:smartstruct/smartstruct.dart';
import '../../../domain/model/supply_type.dart';
import '../model/supply_type_dto.dart';

part 'supply_type_mapper.mapper.g.dart';

@Mapper()
abstract class SupplyTypeMapper {
  SupplyType fromSupplyTypeDTO(SupplyTypeDTO dto);
}
