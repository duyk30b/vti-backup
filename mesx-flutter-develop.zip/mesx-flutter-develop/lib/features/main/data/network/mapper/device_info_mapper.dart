import 'package:smartstruct/smartstruct.dart';

import '../../../domain/model/device_info.dart';
import '../model/device_list_dto.dart';

part 'device_info_mapper.mapper.g.dart';

@Mapper()
abstract class DeviceInfoMapper {
  static DeviceInfo fromDeviceDTO(DeviceListDTO dto) => _$fromDeviceDTO(dto);

  static List<DeviceInfo> fromDeviceListDTO(List<DeviceListDTO> dto) {
    final List<DeviceInfo> list = [];
    for (final element in dto) {
      list.add(fromDeviceDTO(element));
    }
    return list;
  }
}
