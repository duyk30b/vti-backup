import '../../../../../features/main/data/network/base_response/base_response.dart';
import '../../../domain/model/device_list.dart';
import '../model/device_detail_dto.dart';
import 'device_mapper.dart';

abstract class DeviceListMapper {
  static DeviceList fromDeviceListDTO(List<DeviceDetailDTO> data, Meta meta) {
    final deviceList = DeviceList(
      data.map((e) => DeviceMapperImpl().fromDeviceDetail(e)).toList(),
      meta.total,
      meta.page,
    );
    return deviceList;
  }
}
