import 'package:smartstruct/smartstruct.dart';

import '../../../domain/model/area_info.dart';
import '../../../domain/model/device_detail.dart';
import '../../../domain/model/device_group.dart';
import '../../../domain/model/factory_info.dart';
import '../../../domain/model/transfer_ticket/transfer_ticket.dart';
import '../../../domain/model/unit.dart';
import '../../../domain/model/warehouse.dart';
import '../model/area_info_dto.dart';
import '../model/device_detail_dto.dart';
import '../model/device_group_dto.dart';
import '../model/factory_info_dto.dart';
import '../model/transfer_ticket_dto.dart';
import '../model/unit_dto.dart';
import '../model/warehouse_dto.dart';
import 'device_group_mapper.dart';
import 'device_mapper.dart';

part 'transfer_ticket_mapper.mapper.g.dart';

@Mapper()
abstract class TransferTicketMapper {
  TransferTicket fromTransferTicketDTO(TransferTicketDTO dto);

  FactoryInfo fromFactoryDTO(FactoryInfoDTO dto);
  TransferTicketDevice fromTransferTicketDeviceDTO(TransferTicketDeviceDTO dto);
  DeviceDetail fromDeviceDetailDTO(DeviceDetailDTO dto) =>
      DeviceMapperImpl().fromDeviceDetail(dto);
  AreaInfo fromAreaInfoDTO(AreaInfoDTO dto);
  DeviceGroup fromDeviceGroupDTO(DeviceGroupDTO dto) =>
      DeviceGroupMapperImpl().fromDeviceGroupDTO(dto);
  Unit fromUnitDTO(UnitDTO dto);
  Warehouse fromWarehouseDTO(WarehouseDTO dto);
}
