import 'package:smartstruct/smartstruct.dart';

import '../../../domain/model/device_detail.dart';
import '../../../domain/model/device_request.dart';
import '../../../domain/model/factory_info.dart';
import '../model/device_detail_dto.dart';
import '../model/device_request_dto.dart';
import '../model/factory_info_dto.dart';
import 'device_mapper.dart';

part 'device_request_mapper.mapper.g.dart';

@Mapper()
abstract class DeviceRequestMapper {
  DeviceRequest fromDeviceRequestDTO(DeviceRequestDTO dto);
  DeviceDetail fromDeviceRequestDetailDTO(DeviceDetailDTO dto) =>
      DeviceMapperImpl().fromDeviceDetail(dto);

  FactoryInfo fromFactoryInfoDTO(FactoryInfoDTO dto);
}
