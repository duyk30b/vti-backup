import 'package:smartstruct/smartstruct.dart';

import '../../../domain/model/factory_info.dart';
import '../model/factory_info_dto.dart';

part 'factory_list_mapper.mapper.g.dart';

@Mapper()
abstract class FactoryListMapper {
  FactoryInfo fromFactoryDTO(FactoryInfoDTO dto);
}
