import 'package:smartstruct/smartstruct.dart';

import '../../../../main/data/network/model/attribute_type_dto.dart';
import '../../../../main/data/network/model/device_status_detail_dto.dart';
import '../../../../main/data/network/model/device_status_dto.dart';
import '../../../../main/data/network/model/unit_dto.dart';
import '../../../../main/domain/model/attribute_type.dart';
import '../../../../main/domain/model/device_status.dart';
import '../../../../main/domain/model/device_status_detail.dart';
import '../../../../main/domain/model/unit.dart';

part 'device_status_mapper.mapper.g.dart';

@Mapper()
abstract class DeviceStatusMapper {
  static DeviceStatus fromDeviceStatusDTO(DeviceStatusDTO dto) =>
      _$fromDeviceStatusDTO(dto);

  static List<DeviceStatus> fromDeviceStatusListDTO(List<DeviceStatusDTO> dto) {
    final List<DeviceStatus> list = [];
    for (final element in dto) {
      list.add(fromDeviceStatusDTO(element));
    }
    return list;
  }

  DeviceStatusDetail fromDeviceStatusDetailDTO(DeviceStatusDetailDTO dto);

  Unit fromUnitDTO(UnitDTO unitDTO);

  AttributeType fromAttributeTypeDTO(AttributeTypeDTO attributeTypeDTO);
}
