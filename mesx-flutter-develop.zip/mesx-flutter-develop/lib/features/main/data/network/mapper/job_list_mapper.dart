import 'package:smartstruct/smartstruct.dart';

import '../../../domain/model/accreditation_template.dart';
import '../../../domain/model/accreditation_template_detail.dart';
import '../../../domain/model/area_info.dart';
import '../../../domain/model/article_device_group.dart';
import '../../../domain/model/assign.dart';
import '../../../domain/model/attribute_type.dart';
import '../../../domain/model/detail.dart';
import '../../../domain/model/device_detail.dart';
import '../../../domain/model/device_group.dart';
import '../../../domain/model/error_type.dart';
import '../../../domain/model/factory_info.dart';
import '../../../domain/model/installation_template.dart';
import '../../../domain/model/installation_template_detail.dart';
import '../../../domain/model/job.dart';
import '../../../domain/model/job_type_template.dart';
import '../../../domain/model/maintenance_index.dart';
import '../../../domain/model/maintenance_template.dart';
import '../../../domain/model/maintenance_template_detail.dart';
import '../../../domain/model/repair_request_history.dart';
import '../../../domain/model/result.dart';
import '../../../domain/model/supply.dart';
import '../../../domain/model/supply_type.dart';
import '../../../domain/model/unit.dart';
import '../../../domain/model/vendor.dart';
import '../../../domain/model/warehouse.dart';
import '../../../domain/model/warning.dart';
import '../model/accreditation_template_detail_dto.dart';
import '../model/accreditation_template_dto.dart';
import '../model/area_info_dto.dart';
import '../model/article_device_group_dto.dart';
import '../model/assign_dto.dart';
import '../model/attribute_type_dto.dart';
import '../model/detail.dart';
import '../model/device_detail_dto.dart';
import '../model/device_group_dto.dart';
import '../model/error_type_dto.dart';
import '../model/factory_info_dto.dart';
import '../model/installation_template_detail_dto.dart';
import '../model/installation_template_dto.dart';
import '../model/job_dto.dart';
import '../model/job_type_template_dto.dart';
import '../model/maintenance_index_dto.dart';
import '../model/maintenance_template_detail_dto.dart';
import '../model/maintenance_template_dto.dart';
import '../model/repair_request_history_dto.dart';
import '../model/result.dart';
import '../model/supply_dto.dart';
import '../model/supply_type_dto.dart';
import '../model/unit_dto.dart';
import '../model/vendor_dto.dart';
import '../model/warehouse_dto.dart';
import '../model/warning_dto.dart';
import 'supply_mapper.dart';

part 'job_list_mapper.mapper.g.dart';

@Mapper()
abstract class JobListMapper {
  Assign fromAssignDTO(AssignDTO dto);

  Detail fromDetailDTO(DetailDTO dto);

  Result fromResultDTO(ResultDTO dto);

  DeviceGroup fromDeviceGroupDTO(DeviceGroupDTO dto);

  Vendor fromVendorDTO(VendorDTO dto);

  MaintenanceIndex fromMaintenanceIndexDTO(MaintenanceIndexDTO dto);

  FactoryInfo fromFactoryInfoDTO(FactoryInfoDTO dto);

  AreaInfo fromAreaInfoDTO(AreaInfoDTO dto);

  ArticleDeviceGroup fromArticleDeviceGroupDTO(ArticleDeviceGroupDTO dto);

  JobTypeTemplate fromJobTypeTemplateDTO(JobTypeTemplateDTO dto);

  DeviceDetail fromDeviceDTO(DeviceDetailDTO dto);

  Job fromJobDTO(JobDTO dto);

  Warning fromWarningDTO(WarningDto dto);

  List<Job> fromJobDTOList(List<JobDTO> dtoList) =>
      dtoList.map(fromJobDTO).toList();

  AttributeType fromAttributeTypeDTO(AttributeTypeDTO dto);

  RepairRequestHistory fromRepairRequestHistoryDTO(RepairRequestHistoryDTO dto);

  Supply fromSupplyDTO(SupplyDTO dto) => SupplyMapperImpl().fromSupplyDTO(dto);

  MaintenanceTemplate fromMaintenanceTemplateDTO(MaintenanceTemplateDTO dto);

  InstallationTemplate fromInstallationTemplateDTO(InstallationTemplateDTO dto);

  AccreditationTemplate fromAccreditationTemplateDTO(
      AccreditationTemplateDTO dto);

  InstallationTemplateDetail fromInstallationTemplateDetailDTO(
      InstallationTemplateDetailDTO dto);

  AccreditationTemplateDetail fromAccreditationTemplateDetailDTO(
      AccreditationTemplateDetailDTO dto);

  SupplyType fromSupplyTypeDTO(SupplyTypeDTO dto);

  Unit fromUnitDTO(UnitDTO dto);

  MaintenanceTemplateDetail fromMaintenanceTemplateDetailDTO(
      MaintenanceTemplateDetailDTO dto);

  ErrorType fromErrorTypeDTO(ErrorTypeDTO dto);

  Warehouse fromWarehouseDTO(WarehouseDTO dto);
}
