import 'package:smartstruct/smartstruct.dart';
import '../../../../main/data/network/model/attribute_type_dto.dart';
import '../../../../main/data/network/model/unit_dto.dart';
import '../../../../main/domain/model/attribute_type.dart';
import '../../../../main/domain/model/unit.dart';

part 'attribute_type_mapper.mapper.g.dart';

@Mapper()
abstract class AttributeTypeMapper {
  AttributeType fromAttributeTypeDTO(AttributeTypeDTO dto);

  Unit fromUnitDTO(UnitDTO dto);
}
