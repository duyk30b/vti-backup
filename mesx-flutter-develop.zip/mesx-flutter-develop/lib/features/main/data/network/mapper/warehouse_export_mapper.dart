import 'package:smartstruct/smartstruct.dart';

import '../../../domain/model/area_info.dart';
import '../../../domain/model/device_detail.dart';
import '../../../domain/model/device_group.dart';
import '../../../domain/model/device_request.dart';
import '../../../domain/model/factory_info.dart';
import '../../../domain/model/supply.dart';
import '../../../domain/model/supply_group.dart';
import '../../../domain/model/supply_request.dart';
import '../../../domain/model/supply_type.dart';
import '../../../domain/model/transfer_ticket/transfer_ticket.dart';
import '../../../domain/model/unit.dart';
import '../../../domain/model/vendor.dart';
import '../../../domain/model/warehouse.dart';
import '../../../domain/model/warehouse_export.dart';
import '../../../domain/model/warehouse_export_device.dart';
import '../../../domain/model/warehouse_export_supply.dart';
import '../model/area_info_dto.dart';
import '../model/device_detail_dto.dart';
import '../model/device_group_dto.dart';
import '../model/device_request_dto.dart';
import '../model/factory_info_dto.dart';
import '../model/supply_dto.dart';
import '../model/supply_group_dto.dart';
import '../model/supply_request_dto.dart';
import '../model/supply_type_dto.dart';
import '../model/transfer_ticket_dto.dart';
import '../model/unit_dto.dart';
import '../model/vendor_dto.dart';
import '../model/warehouse_dto.dart';
import '../model/warehouse_export_device_dto.dart';
import '../model/warehouse_export_dto.dart';
import '../model/warehouse_export_supply_dto.dart';
import 'device_group_mapper.dart';
import 'device_mapper.dart';
import 'device_request_mapper.dart';
import 'supply_request_mapper.dart';
import 'transfer_ticket_mapper.dart';

part 'warehouse_export_mapper.mapper.g.dart';

@Mapper()
abstract class WarehouseExportMapper {
  WarehouseExport fromWarehouseExportDTO(WarehouseExportDTO dto);
  FactoryInfo fromFactoryDTO(FactoryInfoDTO dto);
  DeviceDetail fromDeviceDetailDTO(DeviceDetailDTO dto) =>
      DeviceMapperImpl().fromDeviceDetail(dto);

  WarehouseExportDevice fromWarehouseExportDeviceDTO(
      WarehouseExportDeviceDTO dto);

  WarehouseExportSupply fromWarehouseExportSupplyDTO(
      WarehouseExportSupplyDTO dto);

  Warehouse fromWarehouseDTO(WarehouseDTO dto);

  Unit fromUnitDTO(UnitDTO dto);
  AreaInfo fromAreaInfoDTO(AreaInfoDTO dto);
  Vendor fromVendorDTO(VendorDTO dto);
  DeviceGroup fromDeviceGroupDTO(DeviceGroupDTO dto) =>
      DeviceGroupMapperImpl().fromDeviceGroupDTO(dto);
  Supply fromSupplyDTO(SupplyDTO dto);
  SupplyGroup fromSupplyGroupDTO(SupplyGroupDTO dto);
  SupplyType fromSupplyTypeDTO(SupplyTypeDTO dto);

  SupplyRequest fromVtptRequestsDTO(SupplyRequestDTO dto) =>
      SupplyRequestMapperImpl().fromSupplyRequestDTO(dto);
  DeviceRequest fromDeviceRequestDTO(DeviceRequestDTO dto) =>
      DeviceRequestMapperImpl().fromDeviceRequestDTO(dto);
  TransferTicket fromTransferTicketDTO(TransferTicketDTO dto) =>
      TransferTicketMapperImpl().fromTransferTicketDTO(dto);
}
