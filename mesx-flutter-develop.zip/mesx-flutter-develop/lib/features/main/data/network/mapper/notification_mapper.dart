import 'package:smartstruct/smartstruct.dart';

import '../../../domain/model/create_by.dart';
import '../../../domain/model/notification_id.dart';
import '../../../domain/model/notification_info.dart';
import '../../../domain/model/payload.dart';
import '../model/create_by_dto.dart';
import '../model/notification_id_dto.dart';
import '../model/notification_item_dto.dart';
import '../model/payload_dto.dart';

part 'notification_mapper.mapper.g.dart';

@Mapper()
abstract class NotificationMapper {
  NotificationInfo fromNotificationItemDTO(NotificationItemDTO dto);

  NotificationID fromNotificationIdDTO(NotificationIdDTO dto);

  PayLoad fromPayLoadDTO(PayLoadDTO dto);

  CreateBy fromCreateByDTO(CreateByDTO dto);
}
