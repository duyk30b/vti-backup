import 'package:smartstruct/smartstruct.dart';

import '../../../domain/model/supply.dart';
import '../../../domain/model/supply_group.dart';
import '../../../domain/model/supply_type.dart';
import '../../../domain/model/unit.dart';
import '../../../domain/model/vendor.dart';
import '../model/supply_dto.dart';
import '../model/supply_group_dto.dart';
import '../model/supply_type_dto.dart';
import '../model/unit_dto.dart';
import '../model/vendor_dto.dart';

part 'supply_mapper.mapper.g.dart';

@Mapper()
abstract class SupplyMapper {
  Supply fromSupplyDTO(SupplyDTO dto);
  List<Supply> fromSupplyListDTO(List<SupplyDTO> dtoList) =>
      dtoList.map(fromSupplyDTO).toList();
  SupplyType fromSupplyTypeDTO(SupplyTypeDTO dto);
  Unit fromUnitDTO(UnitDTO dto);
  SupplyGroup fromSupplyGroupDTO(SupplyGroupDTO dto);
  Vendor fromVendorDTO(VendorDTO dto);
}
