import 'package:smartstruct/smartstruct.dart';

import '../../../domain/model/create_by.dart';
import '../../../domain/model/device_activity_history.dart';
import '../model/create_by_dto.dart';
import '../model/device_activity_history_dto.dart';

part 'device_activity_history_mapper.mapper.g.dart';

@Mapper()
abstract class DeviceActivityHistoryMapper {
  DeviceActivityHistory fromDeviceActivityHistoryDTO(
      DeviceActivityHistoryDTO dto);

  CreateBy fromCreateByDTO(CreateByDTO dto);
}
