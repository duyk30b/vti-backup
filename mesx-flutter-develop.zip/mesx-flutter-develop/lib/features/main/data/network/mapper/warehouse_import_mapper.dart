import 'package:smartstruct/smartstruct.dart';

import '../../../domain/model/area_info.dart';
import '../../../domain/model/device_assignment.dart';
import '../../../domain/model/device_detail.dart';
import '../../../domain/model/device_group.dart';
import '../../../domain/model/factory_info.dart';
import '../../../domain/model/request.dart';
import '../../../domain/model/supply.dart';
import '../../../domain/model/supply_group.dart';
import '../../../domain/model/supply_request.dart';
import '../../../domain/model/unit.dart';
import '../../../domain/model/vendor.dart';
import '../../../domain/model/warehouse.dart';
import '../../../domain/model/warehouse_import.dart';
import '../../../domain/model/warehouse_import_device.dart';
import '../../../domain/model/warehouse_import_supply.dart';
import '../model/area_info_dto.dart';
import '../model/device_assignment_dto.dart';
import '../model/device_detail_dto.dart';
import '../model/device_group_dto.dart';
import '../model/factory_info_dto.dart';
import '../model/request_dto.dart';
import '../model/supply_dto.dart';
import '../model/supply_group_dto.dart';
import '../model/supply_request_dto.dart';
import '../model/unit_dto.dart';
import '../model/vendor_dto.dart';
import '../model/warehouse_dto.dart';
import '../model/warehouse_import_device_dto.dart';
import '../model/warehouse_import_dto.dart';
import '../model/warehouse_import_supply_dto.dart';
import 'device_assignment_mapper.dart';
import 'device_group_mapper.dart';
import 'device_mapper.dart';
import 'supply_group_mapper.dart';
import 'supply_mapper.dart';
import 'supply_request_mapper.dart';
import 'vendor_mapper.dart';
import 'warehouse_mapper.dart';

part 'warehouse_import_mapper.mapper.g.dart';

@Mapper()
abstract class WarehouseImportMapper {
  WarehouseImport fromWarehouseImportDTO(WarehouseImportDTO dto);
  Warehouse fromWarehouseDTO(WarehouseDTO dto) =>
      WarehouseMapperImpl().fromWarehouseDTO(dto);

  Supply fromSupplyDTO(SupplyDTO dto) => SupplyMapperImpl().fromSupplyDTO(dto);
  FactoryInfo fromFactoryDTO(FactoryInfoDTO dto);
  DeviceDetail fromDeviceDetailDTO(DeviceDetailDTO dto) =>
      DeviceMapperImpl().fromDeviceDetail(dto);

  WarehouseImportDevice fromWarehouseImportDeviceDTO(
      WarehouseImportDeviceDTO dto);

  WarehouseImportSupply fromWarehouseImportSupplyDTO(
      WarehouseImportSupplyDTO dto);
  Unit fromUnitDTO(UnitDTO dto);

  DeviceGroup fromDeviceGroupDTO(DeviceGroupDTO dto) =>
      DeviceGroupMapperImpl().fromDeviceGroupDTO(dto);

  SupplyGroup fromSupplyGroupDTO(SupplyGroupDTO dto) =>
      SupplyGroupMapperImpl().fromSupplyGroupDTO(dto);

  Vendor fromVendorDTO(VendorDTO dto) => VendorMapperImpl().fromVendorDTO(dto);
  AreaInfo fromAreaInfoDTO(AreaInfoDTO dto);
  DeviceAssignment fromDeviceAssignmentDTO(DeviceAssignmentDTO dto) =>
      DeviceAssignmentMapperImpl().fromDeviceAssignmentDTO(dto);
  SupplyRequest fromSupplyRequestInfoDTO(SupplyRequestDTO dto) =>
      SupplyRequestMapperImpl().fromSupplyRequestDTO(dto);

  Request fromRequestDTO(RequestDTO dto);
}
