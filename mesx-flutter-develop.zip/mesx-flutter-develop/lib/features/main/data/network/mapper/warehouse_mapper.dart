import 'package:smartstruct/smartstruct.dart';
import '../../../domain/model/factory_info.dart';
import '../../../domain/model/warehouse.dart';
import '../model/factory_info_dto.dart';
import '../model/warehouse_dto.dart';

part 'warehouse_mapper.mapper.g.dart';

@Mapper()
abstract class WarehouseMapper {
  Warehouse fromWarehouseDTO(WarehouseDTO dto);
  FactoryInfo fromFactoryDTO(FactoryInfoDTO dto);
  List<Warehouse> fromWarehouseListDTO(List<WarehouseDTO> dtoList) =>
      dtoList.map(fromWarehouseDTO).toList();
}
