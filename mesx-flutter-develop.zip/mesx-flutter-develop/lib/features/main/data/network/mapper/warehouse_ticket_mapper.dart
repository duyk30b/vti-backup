import 'package:smartstruct/smartstruct.dart';

import '../../../domain/model/area_info.dart';
import '../../../domain/model/article_device_group.dart';
import '../../../domain/model/device_detail.dart';
import '../../../domain/model/device_group.dart';
import '../../../domain/model/factory_info.dart';
import '../../../domain/model/maintenance_index.dart';
import '../../../domain/model/supply.dart';
import '../../../domain/model/supply_group.dart';
import '../../../domain/model/supply_type.dart';
import '../../../domain/model/unit.dart';
import '../../../domain/model/vendor.dart';
import '../../../domain/model/warehouse.dart';
import '../../../domain/model/warehouse_request/warehouse_export_request.dart';
import '../../../domain/model/warehouse_request/warehouse_import_request.dart';
import '../../../domain/model/warehouse_request/warehouse_request_device_group.dart';
import '../../../domain/model/warehouse_ticket/warehouse_export_ticket.dart';
import '../../../domain/model/warehouse_ticket/warehouse_import_ticket.dart';
import '../../../domain/model/warehouse_ticket/warehouse_ticket.dart';
import '../../../domain/model/warehouse_ticket/warehouse_ticket_device.dart';
import '../../../domain/model/warehouse_ticket/warehouse_ticket_supply.dart';
import '../model/area_info_dto.dart';
import '../model/article_device_group_dto.dart';
import '../model/device_detail_dto.dart';
import '../model/device_group_dto.dart';
import '../model/factory_info_dto.dart';
import '../model/maintenance_index_dto.dart';
import '../model/supply_dto.dart';
import '../model/supply_group_dto.dart';
import '../model/supply_type_dto.dart';
import '../model/unit_dto.dart';
import '../model/vendor_dto.dart';
import '../model/warehouse_dto.dart';
import '../model/warehouse_request/warehouse_export_request_dto.dart';
import '../model/warehouse_request/warehouse_import_request_dto.dart';
import '../model/warehouse_request/warehouse_request_device_group_dto.dart';
import '../model/warehouse_ticket/warehouse_export_ticket_dto.dart';
import '../model/warehouse_ticket/warehouse_import_ticket_dto.dart';
import '../model/warehouse_ticket/warehouse_ticket_device_dto.dart';
import '../model/warehouse_ticket/warehouse_ticket_dto.dart';
import '../model/warehouse_ticket/warehouse_ticket_supply_dto.dart';
import 'device_group_mapper.dart';
import 'device_mapper.dart';
import 'supply_mapper.dart';
import 'warehouse_request_mapper.dart';

part 'warehouse_ticket_mapper.mapper.g.dart';

@Mapper()
abstract class WarehouseTicketMapper {
  WarehouseTicket fromWarehouseTicketDTO(WarehouseTicketDTO dto);
  WarehouseImportTicket fromWarehouseImportTicketDTO(
      WarehouseImportTicketDTO dto);

  WarehouseImportRequest fromWarehouseImportRequestDTO(
          WarehouseImportRequestDTO dto) =>
      WarehouseRequestMapperImpl().fromWarehouseImportRequestDTO(dto);

  WarehouseExportTicket fromWarehouseExportTicketDTO(
      WarehouseExportTicketDTO dto);

  Warehouse fromWarehouseDTO(WarehouseDTO dto);
  FactoryInfo fromFactoryDTO(FactoryInfoDTO dto);

  DeviceDetail fromDeviceDetailDTO(DeviceDetailDTO dto) =>
      DeviceMapperImpl().fromDeviceDetail(dto);

  Supply fromSupplyDTO(SupplyDTO dto) => SupplyMapperImpl().fromSupplyDTO(dto);

  WarehouseTicketDevice fromWarehouseTicketDeviceDTO(
      WarehouseTicketDeviceDTO dto);

  DeviceGroup fromDeviceGroupDTO(DeviceGroupDTO dto) =>
      DeviceGroupMapperImpl().fromDeviceGroupDTO(dto);

  AreaInfo fromAreaDTO(AreaInfoDTO dto);

  Vendor fromVendorDTO(VendorDTO dto);

  MaintenanceIndex fromMaintenanceIndexDTO(MaintenanceIndexDTO dto);

  ArticleDeviceGroup fromArticleDeviceGroupDTO(ArticleDeviceGroupDTO dto);

  SupplyType fromSupplyTypeDTO(SupplyTypeDTO dto);

  Unit fromUnitDTO(UnitDTO dto);

  WarehouseTicketSupply fromWarehouseTicketSupplyDTO(
      WarehouseTicketSupplyDTO dto);

  SupplyGroup fromSupplyGroupDTO(SupplyGroupDTO dto);

  WarehouseRequestDeviceGroup fromWarehouseRequestDeviceGroupDTO(
          WarehouseRequestDeviceGroupDTO dto) =>
      WarehouseTicketMapperImpl().fromWarehouseRequestDeviceGroupDTO(dto);

  WarehouseExportRequest fromWarehouseExportRequestDTO(
          WarehouseExportRequestDTO dto) =>
      WarehouseRequestMapperImpl().fromWarehouseExportRequestDTO(dto);
}
