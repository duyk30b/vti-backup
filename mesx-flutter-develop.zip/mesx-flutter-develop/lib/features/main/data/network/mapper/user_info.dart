class UserInfo {
  final int id;
  final int role;
  final String email;
  final String username;
  final String fullName;
  final int companyId;
  final String? dateOfBirth;
  final String code;
  final String? phone;
  final int status;
  final String createdAt;
  final String updatedAt;

  UserInfo(
    this.id,
    this.role,
    this.email,
    this.username,
    this.fullName,
    this.companyId,
    this.dateOfBirth,
    this.code,
    this.phone,
    this.status,
    this.createdAt,
    this.updatedAt,
  );
}
