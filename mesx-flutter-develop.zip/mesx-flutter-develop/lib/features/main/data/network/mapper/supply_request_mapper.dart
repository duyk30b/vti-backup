import 'package:smartstruct/smartstruct.dart';

import '../../../domain/model/create_by.dart';
import '../../../domain/model/factory_info.dart';
import '../../../domain/model/job.dart';
import '../../../domain/model/request.dart';
import '../../../domain/model/supply.dart';
import '../../../domain/model/supply_request.dart';
import '../../../domain/model/warehouse.dart';
import '../model/create_by_dto.dart';
import '../model/factory_info_dto.dart';
import '../model/job_dto.dart';
import '../model/request_dto.dart';
import '../model/supply_dto.dart';
import '../model/supply_request_dto.dart';
import '../model/warehouse_dto.dart';
import 'job_list_mapper.dart';
import 'supply_mapper.dart';

part 'supply_request_mapper.mapper.g.dart';

@Mapper()
abstract class SupplyRequestMapper {
  SupplyRequest fromSupplyRequestDTO(SupplyRequestDTO dto);
  Job fromJobDTO(JobDTO dto) => JobListMapperImpl().fromJobDTO(dto);
  CreateBy fromCreateByDTO(CreateByDTO dto);
  Warehouse fromWarehouseDTO(WarehouseDTO dto);
  FactoryInfo fromFactoryDTO(FactoryInfoDTO dto);
  Supply fromUnitDTO(SupplyDTO dto) => SupplyMapperImpl().fromSupplyDTO(dto);
  Request fromRequestDTO(RequestDTO dto);
}
