import 'package:smartstruct/smartstruct.dart';
import '../../../domain/model/supply_group.dart';
import '../model/supply_group_dto.dart';

part 'supply_group_mapper.mapper.g.dart';

@Mapper()
abstract class SupplyGroupMapper {
  SupplyGroup fromSupplyGroupDTO(SupplyGroupDTO dto);
}
