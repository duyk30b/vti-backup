import 'package:smartstruct/smartstruct.dart';
import '../../../domain/model/vendor.dart';
import '../model/vendor_dto.dart';

part 'vendor_mapper.mapper.g.dart';

@Mapper()
abstract class VendorMapper {
  Vendor fromVendorDTO(VendorDTO dto);
}
