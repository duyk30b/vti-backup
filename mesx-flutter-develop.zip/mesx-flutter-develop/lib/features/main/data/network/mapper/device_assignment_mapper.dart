import 'package:smartstruct/smartstruct.dart';
import '../../../domain/model/area_info.dart';
import '../../../domain/model/device_assignment.dart';
import '../../../domain/model/device_detail.dart';
import '../../../domain/model/device_group.dart';
import '../../../domain/model/factory_info.dart';
import '../../../domain/model/unit.dart';
import '../model/area_info_dto.dart';
import '../model/device_assignment_dto.dart';
import '../model/device_detail_dto.dart';
import '../model/device_group_dto.dart';
import '../model/factory_info_dto.dart';
import '../model/unit_dto.dart';
import 'device_group_mapper.dart';
import 'device_mapper.dart';
import 'factory_list_mapper.dart';

part 'device_assignment_mapper.mapper.g.dart';

@Mapper()
abstract class DeviceAssignmentMapper {
  DeviceAssignment fromDeviceAssignmentDTO(DeviceAssignmentDTO dto);

  FactoryInfo fromFactoryInfoDTO(FactoryInfoDTO dto) =>
      FactoryListMapperImpl().fromFactoryDTO(dto);

  DeviceDetail fromDeviceDetail(DeviceDetailDTO dto) =>
      DeviceMapperImpl().fromDeviceDetail(dto);

  DeviceAssignmentDetail fromDeviceAssignmentDetailDTO(
      DeviceAssignmentDetailDTO dto);

  Unit fromUnitDTO(UnitDTO dto);

  AreaInfo fromAreaInfoDTO(AreaInfoDTO dto);

  DeviceGroup fromDeviceGroupDTO(DeviceGroupDTO dto) =>
      DeviceGroupMapperImpl().fromDeviceGroupDTO(dto);
}
