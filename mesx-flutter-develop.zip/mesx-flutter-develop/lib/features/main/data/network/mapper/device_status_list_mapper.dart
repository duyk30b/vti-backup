import './device_status_mapper.dart';
import '../../../domain/model/device_status_detail_list.dart';
import '../../../domain/model/device_status_list.dart';
import '../base_response/base_response.dart';
import '../model/device_status_detail_dto.dart';
import '../model/device_status_dto.dart';

abstract class DeviceStatusListMapper {
  static DeviceStatusList fromDeviceStatusListDTO(
      List<DeviceStatusDTO> data, Meta meta) {
    final deviceStatusList = DeviceStatusList(
      data.map(DeviceStatusMapper.fromDeviceStatusDTO).toList(),
      meta.total,
      meta.page,
    );
    return deviceStatusList;
  }

  static DeviceStatusDetailList fromDeviceStatusDetailListDTO(
      List<DeviceStatusDetailDTO> data, Meta meta) {
    final deviceStatusList = DeviceStatusDetailList(
      data
          .map((e) => DeviceStatusMapperImpl().fromDeviceStatusDetailDTO(e))
          .toList(),
      meta.total,
      meta.page,
    );
    return deviceStatusList;
  }
}
