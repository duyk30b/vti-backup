import 'package:smartstruct/smartstruct.dart';
import '../../../../main/data/network/model/unit_dto.dart';
import '../../../../main/domain/model/unit.dart';

part 'unit_mapper.mapper.g.dart';

@Mapper()
abstract class UnitMapper {
  static Unit fromUnitDTO(UnitDTO dto) => _$fromUnitDTO(dto);
}
