import 'package:smartstruct/smartstruct.dart';

import '../../../domain/model/area_info.dart';
import '../../../domain/model/factory_info.dart';
import '../model/area_info_dto.dart';
import '../model/factory_info_dto.dart';

part 'area_list_mapper.mapper.g.dart';

@Mapper()
abstract class AreaListMapper {
  AreaInfo fromAreaDTO(AreaInfoDTO dto);
  FactoryInfo fromFactoryDTO(FactoryInfoDTO dto);
}
