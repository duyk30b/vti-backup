import 'package:smartstruct/smartstruct.dart';

import '../../../domain/model/device_detail.dart';
import '../../../domain/model/error_type.dart';
import '../../../domain/model/job.dart';
import '../../../domain/model/paging_model.dart';
import '../../../domain/model/repair_request.dart';
import '../../../domain/model/repair_request_history.dart';
import '../../../domain/model/supply.dart';
import '../../../domain/model/supply_type.dart';
import '../../../domain/model/unit.dart';
import '../../../domain/model/user.dart';
import '../base_response/base_response.dart';
import '../model/device_detail_dto.dart';
import '../model/error_type_dto.dart';
import '../model/job_dto.dart';
import '../model/repair_request_dto.dart';
import '../model/repair_request_history_dto.dart';
import '../model/supply_dto.dart';
import '../model/supply_type_dto.dart';
import '../model/unit_dto.dart';
import '../model/user_dto.dart';
import 'device_mapper.dart';
import 'job_list_mapper.dart';
import 'supply_mapper.dart';

part 'repair_request_mapper.mapper.g.dart';

@Mapper()
abstract class RepairRequestMapper {
  RepairRequest fromRequestRepairDTO(RepairRequestDTO dto);

  User fromUserDTO(UserDTO dto);

  DeviceDetail fromDeviceDTO(DeviceDetailDTO dto) =>
      DeviceMapperImpl().fromDeviceDetail(dto);

  RepairRequestHistory fromHistoryDTO(RepairRequestHistoryDTO dto);

  ErrorType fromErrorTypeDTO(ErrorTypeDTO dto);

  Supply fromSupplyDTO(SupplyDTO dto) => SupplyMapperImpl().fromSupplyDTO(dto);
  SupplyType fromSupplyTypeDTO(SupplyTypeDTO dto);
  Unit fromUnitDTO(UnitDTO dto);

  @IgnoreMapping()
  PagingModel<RepairRequest> fromRepairRequestListDTO(
      List<RepairRequestDTO> data, Meta meta) {
    final list = PagingModel<RepairRequest>(
      data.map(fromRequestRepairDTO).toList(),
      meta.total,
      meta.page,
    );
    return list;
  }

  @IgnoreMapping()
  Job fromJobDTO(JobDTO dto) => JobListMapperImpl().fromJobDTO(dto);
}
