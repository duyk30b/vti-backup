import 'package:smartstruct/smartstruct.dart';

import '../../../domain/model/assets_type_display.dart';
import '../../../domain/model/factory_info.dart';
import '../../../domain/model/inventory.dart';
import '../../../domain/model/supply_group.dart';
import '../../../domain/model/unit.dart';
import '../../../domain/model/warehouse.dart';
import '../model/assets_type_display_dto.dart';
import '../model/factory_info_dto.dart';
import '../model/inventory_dto.dart';
import '../model/supply_group_dto.dart';
import '../model/unit_dto.dart';
import '../model/warehouse_dto.dart';

part 'inventory_mapper.mapper.g.dart';

@Mapper()
abstract class InventoryMapper {
  Inventory fromInventoryDTO(InventoryDTO dto);

  AssetTypeDisplay fromAssetTypeDisplayDTO(AssetTypeDisplayDTO dto);

  List<Inventory> fromInventoryListDTO(List<InventoryDTO> dtoList) =>
      dtoList.map(fromInventoryDTO).toList();

  Unit fromUnitDTO(UnitDTO dto);

  SupplyGroup fromSupplyGroupDTO(SupplyGroupDTO dto);

  Warehouse fromWarehouseDTO(WarehouseDTO dto);

  FactoryInfo fromFactoryInfoDTO(FactoryInfoDTO dto);
}
