import 'package:json_annotation/json_annotation.dart';

part 'base_response.g.dart';

class BaseResponse<R> {
  final int statusCode;
  final String message;
  final R data;

  BaseResponse(this.statusCode, this.message, this.data);
}

class BasePagingResponse<R> {
  final int statusCode;
  final String message;
  final List<R> data;
  final Meta meta;

  BasePagingResponse(this.statusCode, this.message, this.data, this.meta);
}

@JsonSerializable(explicitToJson: true)
class Meta {
  final int total;
  final int page;
  int? totalUnRead;

  Meta({
    this.page = 1,
    this.total = 0,
    this.totalUnRead,
  });

  factory Meta.fromJson(Map<String, dynamic> json) => _$MetaFromJson(json);

  Map<String, dynamic> toJson() => _$MetaToJson(this);
}

@JsonSerializable()
class BaseResponseNoData {
  final int statusCode;
  final String message;

  BaseResponseNoData(this.statusCode, this.message);

  factory BaseResponseNoData.fromJson(Map<String, dynamic> json) =>
      _$BaseResponseNoDataFromJson(json);

  Map<String, dynamic> toJson() => _$BaseResponseNoDataToJson(this);

  @override
  String toString() =>
      'BaseResponseNoData(statusCode: $statusCode, message: $message)';
}

class BasePagingResponseNoMeta<R> {
  final int statusCode;
  final String message;
  final List<R> data;
  final Meta? meta;

  BasePagingResponseNoMeta(this.statusCode, this.message, this.data, this.meta);
}
