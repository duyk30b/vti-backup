import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/device_activity_history_dto.dart';

part 'device_activity_history_response.g.dart';

@JsonSerializable(explicitToJson: true)
class DeviceActivityHistoryResponse
    extends BaseResponse<List<DeviceActivityHistoryDTO>> {
  DeviceActivityHistoryResponse(
    super.statusCode,
    super.message,
    super.data,
  );

  factory DeviceActivityHistoryResponse.fromJson(Map<String, dynamic> json) =>
      _$DeviceActivityHistoryResponseFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceActivityHistoryResponseToJson(this);
}
