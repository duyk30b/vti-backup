import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/warehouse_request/warehouse_import_request_dto.dart';

part 'warehouse_import_request_detail_response.g.dart';

@JsonSerializable(explicitToJson: true)
class WarehouseImportRequestDetailResponse
    extends BaseResponse<WarehouseImportRequestDTO> {
  WarehouseImportRequestDetailResponse(
    super.statusCode,
    super.message,
    super.data,
  );

  factory WarehouseImportRequestDetailResponse.fromJson(
          Map<String, dynamic> json) =>
      _$WarehouseImportRequestDetailResponseFromJson(json);

  Map<String, dynamic> toJson() =>
      _$WarehouseImportRequestDetailResponseToJson(this);
}
