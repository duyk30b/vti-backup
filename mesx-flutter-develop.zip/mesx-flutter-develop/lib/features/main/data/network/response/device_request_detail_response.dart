import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/device_request_dto.dart';

part 'device_request_detail_response.g.dart';

@JsonSerializable(explicitToJson: true)
class DeviceRequestDetailResponse extends BaseResponse<DeviceRequestDTO> {
  DeviceRequestDetailResponse(
    super.statusCode,
    super.message,
    super.data,
  );

  factory DeviceRequestDetailResponse.fromJson(Map<String, dynamic> json) =>
      _$DeviceRequestDetailResponseFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceRequestDetailResponseToJson(this);
}
