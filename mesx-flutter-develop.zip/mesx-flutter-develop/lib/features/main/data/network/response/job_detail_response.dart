import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/job_dto.dart';

part 'job_detail_response.g.dart';

@JsonSerializable(explicitToJson: true)
class JobDetailResponse extends BaseResponse<JobDTO> {
  JobDetailResponse(super.statusCode, super.message, super.data);

  factory JobDetailResponse.fromJson(Map<String, dynamic> json) =>
      _$JobDetailResponseFromJson(json);

  Map<String, dynamic> toJson() => _$JobDetailResponseToJson(this);
}
