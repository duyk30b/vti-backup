import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/device_detail_dto.dart';

part 'device_detail_response.g.dart';

@JsonSerializable(explicitToJson: true)
class DeviceDetailResponse extends BaseResponse<DeviceDetailDTO> {
  DeviceDetailResponse(
    super.statusCode,
    super.message,
    super.data,
  );

  factory DeviceDetailResponse.fromJson(Map<String, dynamic> json) =>
      _$DeviceDetailResponseFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceDetailResponseToJson(this);
}
