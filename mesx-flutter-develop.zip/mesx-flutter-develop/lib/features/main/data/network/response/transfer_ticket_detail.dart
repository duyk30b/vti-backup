import 'package:json_annotation/json_annotation.dart';
import '../base_response/base_response.dart';
import '../model/transfer_ticket_dto.dart';

part 'transfer_ticket_detail.g.dart';

@JsonSerializable(explicitToJson: true)
class TransferTicketDetailResponse extends BaseResponse<TransferTicketDTO> {
  TransferTicketDetailResponse(
    super.statusCode,
    super.message,
    super.data,
  );

  factory TransferTicketDetailResponse.fromJson(Map<String, dynamic> json) =>
      _$TransferTicketDetailResponseFromJson(json);

  Map<String, dynamic> toJson() => _$TransferTicketDetailResponseToJson(this);
}
