import 'package:json_annotation/json_annotation.dart';

import '../model/user_dto.dart';

part 'user_assign_items.g.dart';

@JsonSerializable()
class UserAssignItems {
  List<UserDTO>? items;

  UserAssignItems({this.items});

  factory UserAssignItems.fromJson(Map<String, dynamic> json) =>
      _$UserAssignItemsFromJson(json);

  Map<String, dynamic> toJson() => _$UserAssignItemsToJson(this);
}
