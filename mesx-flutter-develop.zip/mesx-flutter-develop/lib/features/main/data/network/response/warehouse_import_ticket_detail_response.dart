import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/warehouse_ticket/warehouse_import_ticket_dto.dart';

part 'warehouse_import_ticket_detail_response.g.dart';

@JsonSerializable(explicitToJson: true)
class WarehouseImportTicketDetailResponse
    extends BaseResponse<WarehouseImportTicketDTO> {
  WarehouseImportTicketDetailResponse(
    super.statusCode,
    super.message,
    super.data,
  );

  factory WarehouseImportTicketDetailResponse.fromJson(
          Map<String, dynamic> json) =>
      _$WarehouseImportTicketDetailResponseFromJson(json);

  Map<String, dynamic> toJson() =>
      _$WarehouseImportTicketDetailResponseToJson(this);
}
