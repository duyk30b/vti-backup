import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/device_status_detail_dto.dart';

part 'device_status_detail_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class DeviceStatusDetailListResponse
    extends BasePagingResponse<DeviceStatusDetailDTO> {
  DeviceStatusDetailListResponse(
      super.statusCode, super.message, super.data, super.meta);

  factory DeviceStatusDetailListResponse.fromJson(Map<String, dynamic> json) =>
      _$DeviceStatusDetailListResponseFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceStatusDetailListResponseToJson(this);
}
