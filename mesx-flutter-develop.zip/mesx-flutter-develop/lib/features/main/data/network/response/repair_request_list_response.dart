import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/repair_request_dto.dart';

part 'repair_request_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class RepairRequestListResponse extends BasePagingResponse<RepairRequestDTO> {
  RepairRequestListResponse(
      super.statusCode, super.message, super.data, super.meta);

  factory RepairRequestListResponse.fromJson(Map<String, dynamic> json) =>
      _$RepairRequestListResponseFromJson(json);

  Map<String, dynamic> toJson() => _$RepairRequestListResponseToJson(this);
}
