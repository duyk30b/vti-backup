import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/area_info_dto.dart';

part 'area_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class ListAreaResponse extends BasePagingResponse<AreaInfoDTO> {
  ListAreaResponse(super.statusCode, super.message, super.data, super.meta);

  factory ListAreaResponse.fromJson(Map<String, dynamic> json) =>
      _$ListAreaResponseFromJson(json);

  Map<String, dynamic> toJson() => _$ListAreaResponseToJson(this);
}
