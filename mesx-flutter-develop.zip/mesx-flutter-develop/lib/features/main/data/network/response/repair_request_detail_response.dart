import 'package:json_annotation/json_annotation.dart';
import '../base_response/base_response.dart';
import '../model/repair_request_dto.dart';

part 'repair_request_detail_response.g.dart';

@JsonSerializable(explicitToJson: true)
class RepairRequestDetailResponse extends BaseResponse<RepairRequestDTO> {
  RepairRequestDetailResponse(
    super.statusCode,
    super.message,
    super.data,
  );

  factory RepairRequestDetailResponse.fromJson(Map<String, dynamic> json) =>
      _$RepairRequestDetailResponseFromJson(json);

  Map<String, dynamic> toJson() => _$RepairRequestDetailResponseToJson(this);
}
