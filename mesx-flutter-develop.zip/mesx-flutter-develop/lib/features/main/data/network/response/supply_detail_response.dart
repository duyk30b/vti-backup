import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/supply_dto.dart';

part 'supply_detail_response.g.dart';

@JsonSerializable(explicitToJson: true)
class SupplyDetailResponse extends BaseResponse<SupplyDTO> {
  SupplyDetailResponse(
    super.statusCode,
    super.message,
    super.data,
  );

  factory SupplyDetailResponse.fromJson(Map<String, dynamic> json) =>
      _$SupplyDetailResponseFromJson(json);

  Map<String, dynamic> toJson() => _$SupplyDetailResponseToJson(this);
}
