import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/warehouse_ticket/warehouse_ticket_dto.dart';

part 'warehouse_ticket_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class WarehouseTicketListResponse
    extends BasePagingResponse<WarehouseTicketDTO> {
  WarehouseTicketListResponse(
    super.statusCode,
    super.message,
    super.data,
    super.meta,
  );

  factory WarehouseTicketListResponse.fromJson(Map<String, dynamic> json) =>
      _$WarehouseTicketListResponseFromJson(json);

  Map<String, dynamic> toJson() => _$WarehouseTicketListResponseToJson(this);
}
