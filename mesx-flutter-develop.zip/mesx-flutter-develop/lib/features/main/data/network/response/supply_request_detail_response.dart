import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/supply_request_dto.dart';

part 'supply_request_detail_response.g.dart';

@JsonSerializable(explicitToJson: true)
class SupplyRequestDetailResponse extends BaseResponse<SupplyRequestDTO> {
  SupplyRequestDetailResponse(
    super.statusCode,
    super.message,
    super.data,
  );

  factory SupplyRequestDetailResponse.fromJson(Map<String, dynamic> json) =>
      _$SupplyRequestDetailResponseFromJson(json);

  Map<String, dynamic> toJson() => _$SupplyRequestDetailResponseToJson(this);
}
