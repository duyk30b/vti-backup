import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/warehouse_dto.dart';

part 'warehouse_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class WarehouseListResponse extends BasePagingResponse<WarehouseDTO> {
  WarehouseListResponse(
    super.statusCode,
    super.message,
    super.data,
    super.meta,
  );

  factory WarehouseListResponse.fromJson(Map<String, dynamic> json) =>
      _$WarehouseListResponseFromJson(json);

  Map<String, dynamic> toJson() => _$WarehouseListResponseToJson(this);
}
