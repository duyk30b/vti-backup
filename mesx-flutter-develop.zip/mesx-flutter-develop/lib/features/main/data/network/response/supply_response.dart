import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/supply_dto.dart';

part 'supply_response.g.dart';

@JsonSerializable(explicitToJson: true)
class SupplyResponse extends BaseResponse<SupplyDTO> {
  SupplyResponse(
    super.statusCode,
    super.message,
    super.data,
  );

  factory SupplyResponse.fromJson(Map<String, dynamic> json) =>
      _$SupplyResponseFromJson(json);

  Map<String, dynamic> toJson() => _$SupplyResponseToJson(this);
}
