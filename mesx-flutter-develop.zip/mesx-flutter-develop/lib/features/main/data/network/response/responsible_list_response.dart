import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/user_dto.dart';

part 'responsible_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class ListResponsibleResponse extends BasePagingResponseNoMeta<UserDTO> {
  ListResponsibleResponse(
      super.statusCode, super.message, super.data, super.meta);

  factory ListResponsibleResponse.fromJson(Map<String, dynamic> json) =>
      _$ListResponsibleResponseFromJson(json);

  Map<String, dynamic> toJson() => _$ListResponsibleResponseToJson(this);
}
