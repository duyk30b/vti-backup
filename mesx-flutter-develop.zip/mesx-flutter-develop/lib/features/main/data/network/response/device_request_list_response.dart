import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/device_request_dto.dart';

part 'device_request_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class DeviceRequestListResponse extends BasePagingResponse<DeviceRequestDTO> {
  DeviceRequestListResponse(
    super.statusCode,
    super.message,
    super.data,
    super.meta,
  );

  factory DeviceRequestListResponse.fromJson(Map<String, dynamic> json) =>
      _$DeviceRequestListResponseFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceRequestListResponseToJson(this);
}
