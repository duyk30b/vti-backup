import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/device_assignment_dto.dart';

part 'device_assignment_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class DeviceAssignmentListResponse
    extends BasePagingResponse<DeviceAssignmentDTO> {
  DeviceAssignmentListResponse(
    super.statusCode,
    super.message,
    super.data,
    super.meta,
  );

  factory DeviceAssignmentListResponse.fromJson(Map<String, dynamic> json) =>
      _$DeviceAssignmentListResponseFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceAssignmentListResponseToJson(this);
}
