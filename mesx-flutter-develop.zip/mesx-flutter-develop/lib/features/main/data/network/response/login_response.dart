import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/login_data_dto.dart';

part 'login_response.g.dart';

@JsonSerializable(explicitToJson: true)
class LoginResponse extends BaseResponse<LoginDataDTO> {
  LoginResponse(super.statusCode, super.message, super.data);

  factory LoginResponse.fromJson(Map<String, dynamic> json) =>
      _$LoginResponseFromJson(json);

  Map<String, dynamic> toJson() => _$LoginResponseToJson(this);
}
