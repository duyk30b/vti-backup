import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/warehouse_ticket/warehouse_export_ticket_dto.dart';

part 'warehouse_export_ticket_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class WarehouseExportTicketListResponse
    extends BasePagingResponse<WarehouseExportTicketDTO> {
  WarehouseExportTicketListResponse(
    super.statusCode,
    super.message,
    super.data,
    super.meta,
  );

  factory WarehouseExportTicketListResponse.fromJson(
          Map<String, dynamic> json) =>
      _$WarehouseExportTicketListResponseFromJson(json);

  Map<String, dynamic> toJson() =>
      _$WarehouseExportTicketListResponseToJson(this);
}
