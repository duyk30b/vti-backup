import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/warehouse_import_dto.dart';

part 'warehouse_import_detail_response.g.dart';

@JsonSerializable(explicitToJson: true)
class WarehouseImportDetailResponse extends BaseResponse<WarehouseImportDTO> {
  WarehouseImportDetailResponse(
    super.statusCode,
    super.message,
    super.data,
  );

  factory WarehouseImportDetailResponse.fromJson(Map<String, dynamic> json) =>
      _$WarehouseImportDetailResponseFromJson(json);

  Map<String, dynamic> toJson() => _$WarehouseImportDetailResponseToJson(this);
}
