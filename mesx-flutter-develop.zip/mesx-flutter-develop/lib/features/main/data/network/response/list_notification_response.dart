import 'package:json_annotation/json_annotation.dart';
import '../base_response/base_response.dart';
import '../model/notification_item_dto.dart';
part 'list_notification_response.g.dart';

@JsonSerializable(explicitToJson: true)
class ListNotificationResponse extends BasePagingResponse<NotificationItemDTO> {
  ListNotificationResponse(
      super.statusCode, super.message, super.data, super.meta);

  factory ListNotificationResponse.fromJson(Map<String, dynamic> json) =>
      _$ListNotificationResponseFromJson(json);

  Map<String, dynamic> toJson() => _$ListNotificationResponseToJson(this);
}
