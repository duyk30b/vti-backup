import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/warehouse_request/warehouse_export_request_dto.dart';

part 'warehouse_export_request_detail_response.g.dart';

@JsonSerializable(explicitToJson: true)
class WarehouseExportRequestDetailResponse
    extends BaseResponse<WarehouseExportRequestDTO> {
  WarehouseExportRequestDetailResponse(
    super.statusCode,
    super.message,
    super.data,
  );

  factory WarehouseExportRequestDetailResponse.fromJson(
          Map<String, dynamic> json) =>
      _$WarehouseExportRequestDetailResponseFromJson(json);

  Map<String, dynamic> toJson() =>
      _$WarehouseExportRequestDetailResponseToJson(this);
}
