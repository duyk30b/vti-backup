import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/job_dto.dart';

part 'device_job_list_reponse.g.dart';

@JsonSerializable(explicitToJson: true)
class DeviceJobListResponse extends BasePagingResponse<JobDTO> {
  DeviceJobListResponse(
    super.statusCode,
    super.message,
    super.data,
    super.meta,
  );

  factory DeviceJobListResponse.fromJson(Map<String, dynamic> json) =>
      _$DeviceJobListResponseFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceJobListResponseToJson(this);
}
