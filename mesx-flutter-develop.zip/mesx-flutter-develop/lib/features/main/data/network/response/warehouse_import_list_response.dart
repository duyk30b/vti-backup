import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/warehouse_import_dto.dart';

part 'warehouse_import_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class WarehouseImportListResponse
    extends BasePagingResponse<WarehouseImportDTO> {
  WarehouseImportListResponse(
    super.statusCode,
    super.message,
    super.data,
    super.meta,
  );

  factory WarehouseImportListResponse.fromJson(Map<String, dynamic> json) =>
      _$WarehouseImportListResponseFromJson(json);

  Map<String, dynamic> toJson() => _$WarehouseImportListResponseToJson(this);
}
