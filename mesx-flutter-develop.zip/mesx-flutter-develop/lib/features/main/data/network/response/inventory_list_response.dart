import 'package:json_annotation/json_annotation.dart';
import '../base_response/base_response.dart';
import '../model/inventory_dto.dart';
part 'inventory_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class InventoryListResponse extends BasePagingResponse<InventoryDTO> {
  InventoryListResponse(
    super.statusCode,
    super.message,
    super.data,
    super.meta,
  );

  factory InventoryListResponse.fromJson(Map<String, dynamic> json) =>
      _$InventoryListResponseFromJson(json);

  Map<String, dynamic> toJson() => _$InventoryListResponseToJson(this);
}
