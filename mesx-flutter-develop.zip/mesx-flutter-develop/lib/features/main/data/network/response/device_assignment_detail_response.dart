import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/device_assignment_dto.dart';

part 'device_assignment_detail_response.g.dart';

@JsonSerializable(explicitToJson: true)
class DeviceAssignmentDetailResponse extends BaseResponse<DeviceAssignmentDTO> {
  DeviceAssignmentDetailResponse(
    super.statusCode,
    super.message,
    super.data,
  );

  factory DeviceAssignmentDetailResponse.fromJson(Map<String, dynamic> json) =>
      _$DeviceAssignmentDetailResponseFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceAssignmentDetailResponseToJson(this);
}
