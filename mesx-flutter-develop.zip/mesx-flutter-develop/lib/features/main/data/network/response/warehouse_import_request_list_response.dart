import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/warehouse_request/warehouse_import_request_dto.dart';

part 'warehouse_import_request_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class WarehouseImportRequestListResponse
    extends BasePagingResponse<WarehouseImportRequestDTO> {
  WarehouseImportRequestListResponse(
    super.statusCode,
    super.message,
    super.data,
    super.meta,
  );

  factory WarehouseImportRequestListResponse.fromJson(
          Map<String, dynamic> json) =>
      _$WarehouseImportRequestListResponseFromJson(json);

  Map<String, dynamic> toJson() =>
      _$WarehouseImportRequestListResponseToJson(this);
}
