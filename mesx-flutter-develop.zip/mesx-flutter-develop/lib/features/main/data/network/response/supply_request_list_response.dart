import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/supply_request_dto.dart';

part 'supply_request_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class SupplyRequestListResponse extends BasePagingResponse<SupplyRequestDTO> {
  SupplyRequestListResponse(
    super.statusCode,
    super.message,
    super.data,
    super.meta,
  );

  factory SupplyRequestListResponse.fromJson(Map<String, dynamic> json) =>
      _$SupplyRequestListResponseFromJson(json);

  Map<String, dynamic> toJson() => _$SupplyRequestListResponseToJson(this);
}
