import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/factory_info_dto.dart';
part 'factory_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class ListFactoryResponse extends BasePagingResponse<FactoryInfoDTO> {
  ListFactoryResponse(super.statusCode, super.message, super.data, super.meta);

  factory ListFactoryResponse.fromJson(Map<String, dynamic> json) =>
      _$ListFactoryResponseFromJson(json);

  Map<String, dynamic> toJson() => _$ListFactoryResponseToJson(this);
}
