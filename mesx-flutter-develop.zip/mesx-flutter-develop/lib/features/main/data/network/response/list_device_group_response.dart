import 'package:json_annotation/json_annotation.dart';
import '../base_response/base_response.dart';

import '../model/device_group_dto.dart';

part 'list_device_group_response.g.dart';

@JsonSerializable(explicitToJson: true)
class ListDeviceGroupResponse extends BasePagingResponse<DeviceGroupDTO> {
  ListDeviceGroupResponse(
      super.statusCode, super.message, super.data, super.meta);

  factory ListDeviceGroupResponse.fromJson(Map<String, dynamic> json) =>
      _$ListDeviceGroupResponseFromJson(json);

  Map<String, dynamic> toJson() => _$ListDeviceGroupResponseToJson(this);
}
