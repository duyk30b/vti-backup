import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/device_detail_dto.dart';

part 'device_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class DeviceListResponse extends BasePagingResponse<DeviceDetailDTO> {
  DeviceListResponse(
    super.statusCode,
    super.message,
    super.data,
    super.meta,
  );

  factory DeviceListResponse.fromJson(Map<String, dynamic> json) =>
      _$DeviceListResponseFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceListResponseToJson(this);
}
