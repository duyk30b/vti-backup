import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import 'user_assign_items.dart';

part 'user_assign_item_response.g.dart';

@JsonSerializable(explicitToJson: true)
class UserAssignItemResponse extends BaseResponse<UserAssignItems> {
  UserAssignItemResponse(super.statusCode, super.message, super.data);

  factory UserAssignItemResponse.fromJson(Map<String, dynamic> json) =>
      _$UserAssignItemResponseFromJson(json);

  Map<String, dynamic> toJson() => _$UserAssignItemResponseToJson(this);
}
