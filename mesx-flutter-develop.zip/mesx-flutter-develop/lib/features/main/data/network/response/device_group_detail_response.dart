import 'package:json_annotation/json_annotation.dart';
import '../base_response/base_response.dart';
import '../model/device_group_dto.dart';

part 'device_group_detail_response.g.dart';

@JsonSerializable(explicitToJson: true)
class DeviceGroupResponse extends BaseResponse<DeviceGroupDTO> {
  DeviceGroupResponse(
    super.statusCode,
    super.message,
    super.data,
  );

  factory DeviceGroupResponse.fromJson(Map<String, dynamic> json) =>
      _$DeviceGroupResponseFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceGroupResponseToJson(this);
}
