import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/supply_dto.dart';

part 'supply_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class SupplyListResponse extends BasePagingResponse<SupplyDTO> {
  SupplyListResponse(
    super.statusCode,
    super.message,
    super.data,
    super.meta,
  );

  factory SupplyListResponse.fromJson(Map<String, dynamic> json) =>
      _$SupplyListResponseFromJson(json);

  Map<String, dynamic> toJson() => _$SupplyListResponseToJson(this);
}
