import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/warehouse_export_dto.dart';

part 'warehouse_export_detail_response.g.dart';

@JsonSerializable(explicitToJson: true)
class WarehouseExportDetailResponse extends BaseResponse<WarehouseExportDTO> {
  WarehouseExportDetailResponse(
    super.statusCode,
    super.message,
    super.data,
  );

  factory WarehouseExportDetailResponse.fromJson(Map<String, dynamic> json) =>
      _$WarehouseExportDetailResponseFromJson(json);

  Map<String, dynamic> toJson() => _$WarehouseExportDetailResponseToJson(this);
}
