import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/transfer_ticket_dto.dart';

part 'transfer_ticket_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class TransferTicketListResponse extends BasePagingResponse<TransferTicketDTO> {
  TransferTicketListResponse(
    super.statusCode,
    super.message,
    super.data,
    super.meta,
  );

  factory TransferTicketListResponse.fromJson(Map<String, dynamic> json) =>
      _$TransferTicketListResponseFromJson(json);

  Map<String, dynamic> toJson() => _$TransferTicketListResponseToJson(this);
}
