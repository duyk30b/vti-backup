import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/supply_group_dto.dart';

part 'supply_group_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class SupplyGroupListResponse extends BasePagingResponse<SupplyGroupDTO> {
  SupplyGroupListResponse(
    super.statusCode,
    super.message,
    super.data,
    super.meta,
  );

  factory SupplyGroupListResponse.fromJson(Map<String, dynamic> json) =>
      _$SupplyGroupListResponseFromJson(json);

  Map<String, dynamic> toJson() => _$SupplyGroupListResponseToJson(this);
}
