import 'package:json_annotation/json_annotation.dart';
import '../../../../../features/main/data/network/model/device_status_dto.dart';

import '../base_response/base_response.dart';

part 'device_status_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class DeviceStatusListResponse extends BasePagingResponse<DeviceStatusDTO> {
  DeviceStatusListResponse(
      super.statusCode, super.message, super.data, super.meta);

  factory DeviceStatusListResponse.fromJson(Map<String, dynamic> json) =>
      _$DeviceStatusListResponseFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceStatusListResponseToJson(this);
}
