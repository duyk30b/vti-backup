import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/warehouse_ticket/warehouse_export_ticket_dto.dart';

part 'warehouse_export_ticket_detail_response.g.dart';

@JsonSerializable(explicitToJson: true)
class WarehouseExportTicketDetailResponse
    extends BaseResponse<WarehouseExportTicketDTO> {
  WarehouseExportTicketDetailResponse(
    super.statusCode,
    super.message,
    super.data,
  );

  factory WarehouseExportTicketDetailResponse.fromJson(
          Map<String, dynamic> json) =>
      _$WarehouseExportTicketDetailResponseFromJson(json);

  Map<String, dynamic> toJson() =>
      _$WarehouseExportTicketDetailResponseToJson(this);
}
