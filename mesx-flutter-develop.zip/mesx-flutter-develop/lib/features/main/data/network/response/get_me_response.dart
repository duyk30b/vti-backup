import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/user_info_dto.dart';

part 'get_me_response.g.dart';

@JsonSerializable(explicitToJson: true)
class GetMeResponse extends BaseResponse<UserInfoDTO> {
  GetMeResponse(super.statusCode, super.message, super.data);

  factory GetMeResponse.fromJson(Map<String, dynamic> json) =>
      _$GetMeResponseFromJson(json);

  Map<String, dynamic> toJson() => _$GetMeResponseToJson(this);
}
