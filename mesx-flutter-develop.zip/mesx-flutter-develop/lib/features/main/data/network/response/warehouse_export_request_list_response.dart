import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/warehouse_request/warehouse_export_request_dto.dart';

part 'warehouse_export_request_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class WarehouseExportRequestListResponse
    extends BasePagingResponse<WarehouseExportRequestDTO> {
  WarehouseExportRequestListResponse(
    super.statusCode,
    super.message,
    super.data,
    super.meta,
  );

  factory WarehouseExportRequestListResponse.fromJson(
          Map<String, dynamic> json) =>
      _$WarehouseExportRequestListResponseFromJson(json);

  Map<String, dynamic> toJson() =>
      _$WarehouseExportRequestListResponseToJson(this);
}
