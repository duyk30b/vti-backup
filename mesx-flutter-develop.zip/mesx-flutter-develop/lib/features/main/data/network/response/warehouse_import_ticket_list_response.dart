import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/warehouse_ticket/warehouse_import_ticket_dto.dart';

part 'warehouse_import_ticket_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class WarehouseImportTicketListResponse
    extends BasePagingResponse<WarehouseImportTicketDTO> {
  WarehouseImportTicketListResponse(
    super.statusCode,
    super.message,
    super.data,
    super.meta,
  );

  factory WarehouseImportTicketListResponse.fromJson(
          Map<String, dynamic> json) =>
      _$WarehouseImportTicketListResponseFromJson(json);

  Map<String, dynamic> toJson() =>
      _$WarehouseImportTicketListResponseToJson(this);
}
