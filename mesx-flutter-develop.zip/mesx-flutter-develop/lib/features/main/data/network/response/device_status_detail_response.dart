import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/device_status_detail_dto.dart';

part 'device_status_detail_response.g.dart';

@JsonSerializable(explicitToJson: true)
class DeviceStatusDetailResponse extends BaseResponse<DeviceStatusDetailDTO> {
  DeviceStatusDetailResponse(
    super.statusCode,
    super.message,
    super.data,
  );

  factory DeviceStatusDetailResponse.fromJson(Map<String, dynamic> json) =>
      _$DeviceStatusDetailResponseFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceStatusDetailResponseToJson(this);
}
