import 'package:json_annotation/json_annotation.dart';

import '../base_response/base_response.dart';
import '../model/supply_type_dto.dart';

part 'supply_type_list_response.g.dart';

@JsonSerializable(explicitToJson: true)
class SupplyTypeListResponse extends BasePagingResponse<SupplyTypeDTO> {
  SupplyTypeListResponse(
    super.statusCode,
    super.message,
    super.data,
    super.meta,
  );

  factory SupplyTypeListResponse.fromJson(Map<String, dynamic> json) =>
      _$SupplyTypeListResponseFromJson(json);

  Map<String, dynamic> toJson() => _$SupplyTypeListResponseToJson(this);
}
