import 'dart:io';

import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';

import '../../domain/request/assign_request.dart';
import 'base_response/base_response.dart';
import 'response/area_list_response.dart';
import 'response/device_activity_history_response.dart';
import 'response/device_assignment_detail_response.dart';
import 'response/device_assignment_list_response.dart';
import 'response/device_detail_response.dart';
import 'response/device_group_detail_response.dart';
import 'response/device_job_list_reponse.dart';
import 'response/device_list_response.dart';
import 'response/device_request_detail_response.dart';
import 'response/device_request_list_response.dart';
import 'response/device_status_detail_list_response.dart';
import 'response/device_status_detail_response.dart';
import 'response/device_status_list_response.dart';
import 'response/domain_info_response.dart';
import 'response/factory_list_response.dart';
import 'response/get_me_response.dart';
import 'response/inventory_list_response.dart';
import 'response/job_detail_response.dart';
import 'response/list_device_group_response.dart';
import 'response/list_notification_response.dart';
import 'response/login_response.dart';
import 'response/repair_request_detail_response.dart';
import 'response/repair_request_list_response.dart';
import 'response/responsible_list_response.dart';
import 'response/supply_detail_response.dart';
import 'response/supply_group_list_response.dart';
import 'response/supply_list_response.dart';
import 'response/supply_request_detail_response.dart';
import 'response/supply_request_list_response.dart';
import 'response/supply_response.dart';
import 'response/supply_type_list_response.dart';
import 'response/transfer_ticket_detail.dart';
import 'response/transfer_ticket_list_response.dart';
import 'response/user_assign_item_response.dart';
import 'response/warehouse_export_detail_response.dart';
import 'response/warehouse_export_list_response.dart';
import 'response/warehouse_export_request_detail_response.dart';
import 'response/warehouse_export_request_list_response.dart';
import 'response/warehouse_export_ticket_detail_response.dart';
import 'response/warehouse_export_ticket_list_response.dart';
import 'response/warehouse_import_detail_response.dart';
import 'response/warehouse_import_list_response.dart';
import 'response/warehouse_import_request_detail_response.dart';
import 'response/warehouse_import_request_list_response.dart';
import 'response/warehouse_import_ticket_detail_response.dart';
import 'response/warehouse_import_ticket_list_response.dart';
import 'response/warehouse_list_response.dart';

part 'api_service.g.dart';

@RestApi()
abstract class DomainApiService {
  factory DomainApiService(Dio dio, {String baseUrl}) = _DomainApiService;

  @GET('v1/contracts/endpoints')
  Future<DomainInfoResponse> fetchDomainInfo(@Query('key') String email);
}

@RestApi()
abstract class PrimaryApiService {
  factory PrimaryApiService(
    Dio dio, {
    String baseUrl,
  }) = _PrimaryApiService;

  @GET('v1/mms/device-status')
  Future<DeviceStatusListResponse> fetchDeviceStatusList(
    @Queries() Map<String, dynamic> queryParams,
  );

  @GET('v1/mms/device-status/{id}/get-by-date')
  Future<DeviceStatusDetailListResponse> fetchDeviceStatusListDetail(
    @Path('id') String id,
    @Queries(encoded: true) Map<String, dynamic> queryParams,
  );

  @POST('v1/auth/login')
  Future<LoginResponse> login(
    @Body() Map<String, dynamic> payload,
  );

  @GET('v1/users/me')
  Future<GetMeResponse> getMe();

  @GET('v1/notifications/users-notification')
  Future<ListNotificationResponse> getListNotification(
    @Query('limit') int limit,
    @Query('page') int page,
    @Query('type') String type,
  );

  @PUT('v1/notifications/notification-users/{id}/seen')
  Future readNotificationID(@Path('id') String id);

  @PUT('v1/notifications/notification-users/seen/all')
  Future readAllNotification();

  @GET('v1/mms/devices')
  Future<DeviceListResponse> getListDevices(
    @Queries() Map<String, dynamic> query,
    @Query('isMasterData') int isMasterData,
  );

  @GET('v1/mms/device-status/{id}/detail-status')
  Future<DeviceStatusDetailResponse> getDeviceStatusDetail(
      @Path('id') String id);

  @GET('/v1/mms/devices/{id}')
  Future<DeviceDetailResponse> getDetailDeviceById(@Path('id') String id);

  @GET('v1/mms/devices/{id}/activity')
  Future<DeviceActivityHistoryResponse> getDeviceActivityHistory(
      @Path('id') String id, @Queries() Map<String, dynamic> query);

  @POST('v1/mms/device-status')
  Future<BaseResponseNoData> createDeviceStatus(
    @Body() Map<String, dynamic> payload,
  );

  @PUT('v1/mms/device-status/{id}')
  Future<BaseResponseNoData> updateDeviceStatus(
    @Path('id') String id,
    @Body() Map<String, dynamic> payload,
  );

  @GET('v1/mms/jobs/histories-of-device')
  Future<DeviceJobListResponse> getDeviceJobList(
    @Queries() Map<String, dynamic> payload,
  );

  @PUT('v1/mms/devices/{id}/{status}')
  Future<BaseResponseNoData> changeDeviceUsageStatus(
    @Path('id') String id,
    @Path('status') int status,
  );

  @GET('v1/users/factories/list')
  Future<ListFactoryResponse> getListFactories(
    @Queries() Map<String, dynamic> query,
  );

  @GET('v1/mms/areas')
  Future<ListAreaResponse> getListAreas(
    @Queries() Map<String, dynamic> query,
  );

  @PUT('v1/mms/devices/{id}/location')
  Future<BaseResponseNoData> changeDeviceLocator(
    @Path('id') String id,
    @Body() Map<String, dynamic> body,
  );

  @GET('v1/mms/repair-requests')
  Future<RepairRequestListResponse> getRequestRepairList(
    @Queries() Map<String, dynamic> payload,
  );

  @GET('v1/mms/repair-requests/{id}')
  Future<RepairRequestDetailResponse> getRequestRepairDetail(
    @Path('id') String id,
  );

  @GET('v1/mms/jobs')
  Future<DeviceJobListResponse> getListJobs(
    @Queries() Map<String, dynamic> payload,
  );

  @GET('v1/mms/jobs/{id}')
  Future<JobDetailResponse> getJobDetail(@Path('id') String id);

  @GET('v1/mms/supply-request')
  Future<SupplyRequestListResponse> getSupplyRequestList(
    @Queries() Map<String, dynamic> query,
  );

  @GET('v1/mms/supply-request/{id}')
  Future<SupplyRequestDetailResponse> getSupplyRequestDetail(
      @Path('id') String id);

  @PUT('v1/mms/supply-request/{id}/confirm')
  Future<BaseResponseNoData> confirmSupplyRequest(@Path('id') String id);

  @PUT('v1/mms/supply-request/{id}/reject')
  Future<BaseResponseNoData> rejectSupplyRequest(@Path('id') String id);

  @PUT('v1/mms/jobs/{id}/{action}')
  Future confirmJob(
    @Path('id') String id,
    @Path('action') String action, {
    @Field('reason') String? reason,
    @Field('executionTime') int? executionTime,
    @Field('stopTime') int? stopTime,
  });

  @PUT('v1/mms/jobs/{id}/reason')
  Future addReason(@Path('id') String id, @Field('reason') String reason);

  @PUT('v1/mms/jobs/{id}/execute')
  @MultiPart()
  Future<BaseResponseNoData> executedJob(
      @Path('id') String id, @Part(name: 'data') String mapData,
      {@Part(name: 'file') File? file});

  @GET('v1/mms/device-groups/list')
  Future<ListDeviceGroupResponse> getDeviceGroupList(
    @Queries() Map<String, dynamic> query,
  );

  @GET('v1/mms/device-groups/{id}')
  Future<DeviceGroupResponse> getDeviceGroupDetail(@Path('id') String id);

  @POST('v1/mms/repair-requests')
  Future<BaseResponseNoData> createRepairRequest(
      @Body() Map<String, dynamic> payload);

  @PUT('v1/mms/repair-requests/{id}/confirmed')
  Future<BaseResponseNoData> confirmRepairRequest(@Path('id') String id);

  @PUT('v1/mms/repair-requests/{id}/rejected')
  Future<BaseResponseNoData> rejectRepairRequest(@Path('id') String id);

  @GET('v1/mms/devices/{code}/scan')
  Future<DeviceDetailResponse> scanDevice(
    @Path('code') String code,
  );

  @GET('v1/mms/maintenance-teams/{id}/assignments')
  Future<UserAssignItemResponse> maintenanceTeamsAssign(@Path('id') String id);

  @PUT('v1/mms/jobs/{jobId}/assignments')
  Future assignUser(@Path('jobId') String jobId, @Body() AssignRequest request);

  @DELETE('v1/mms/supply-request/{id}')
  Future<BaseResponseNoData> deleteSupplyRequest(@Path('id') String id);

  @GET('v1/mms/warehouses')
  Future<WarehouseListResponse> getWarehouseList(
    @Queries() Map<String, dynamic> query,
  );

  @GET('v1/mms/supplies')
  Future<SupplyListResponse> getSupplyList(
    @Queries() Map<String, dynamic> query,
  );

  @GET('v1/mms/supplies/{id}')
  Future<SupplyDetailResponse> getSupplyDetail(
    @Path('id') query,
  );

  @GET('v1/mms/supply-types')
  Future<SupplyTypeListResponse> getSupplyTypeList(
    @Queries() Map<String, dynamic> query,
  );

  @GET('v1/mms/warehouses/inventories/asset/{supplyId}/warehouse/{warehouseId}')
  Future<SupplyResponse> getSupplyStockByWarehouse(
    @Path('supplyId') String supplyId,
    @Path('warehouseId') String warehouseId,
    @Queries() Map<String, dynamic> query,
  );

  @GET('v1/mms/warehouses/inventories/{type}')
  Future<InventoryListResponse> getListInventories(
      @Path('type') String type, @Queries() Map<String, dynamic> query);

  @POST('v1/mms/supply-request')
  Future<BaseResponseNoData> createSupplyRequest(
      @Body() Map<String, dynamic> payload);

  @PUT('v1/mms/supply-request/{id}')
  Future<BaseResponseNoData> updateSupplyRequest(
    @Body() Map<String, dynamic> payload,
    @Path('id') String id,
  );

  @GET('v1/mms/warehouses/imports')
  Future<WarehouseImportListResponse> getWarehouseImportList(
    @Queries() Map<String, dynamic> query,
  );

  @GET('v1/mms/warehouses/imports/{id}')
  Future<WarehouseImportDetailResponse> getWarehouseImportDetail(
    @Path('id') dynamic id,
  );

  @PUT('v1/mms/warehouses/imports/{id}/confirm')
  Future<BaseResponseNoData> confirmWarehouseImport(@Path('id') String id);

  @PUT('v1/mms/warehouses/imports/{id}/reject')
  Future<BaseResponseNoData> rejectWarehouseImport(@Path('id') String id);

  @POST('v1/mms/warehouses/imports')
  Future<BaseResponseNoData> createWarehouseImport(
      @Body() Map<String, dynamic> payload);

  @PUT('v1/mms/warehouses/imports/{id}')
  Future<BaseResponseNoData> updateWarehouseImport(
      @Body() Map<String, dynamic> payload, @Path('id') String id);

  @GET('v1/mms/device-assignments')
  Future<DeviceAssignmentListResponse> getDeviceAssignmentList(
      @Queries() Map<String, dynamic> query);

  @GET('v1/mms/supply-groups/list')
  Future<SupplyGroupListResponse> getSupplyGroupList(
      @Queries() Map<String, dynamic> query);

  @GET('v1/mms/warehouses/exports')
  Future<WarehouseExportListResponse> getWarehouseExportList(
    @Queries() Map<String, dynamic> query,
  );

  @GET('v1/mms/warehouses/exports/{id}')
  Future<WarehouseExportDetailResponse> getWarehouseExportDetail(
    @Path('id') dynamic id,
  );

  @PUT('v1/mms/warehouses/exports/{id}/confirm')
  Future<BaseResponseNoData> confirmWarehouseExport(@Path('id') String id);

  @PUT('v1/mms/warehouses/exports/{id}/reject')
  Future<BaseResponseNoData> rejectWarehouseExport(@Path('id') String id);

  @POST('v1/mms/warehouses/exports')
  Future<BaseResponseNoData> createWarehouseExport(
      @Body() Map<String, dynamic> payload);

  @PUT('v1/mms/warehouses/exports/{id}')
  Future<BaseResponseNoData> updateWarehouseExport(
      @Body() dynamic payload, @Path('id') String id);

  @GET('v1/mms/transfer-tickets')
  Future<TransferTicketListResponse> getTransferTicketList(
      @Queries() Map<String, dynamic> query);

  @GET('v1/mms/transfer-tickets/{id}')
  Future<TransferTicketDetailResponse> getTransferTicketDetail(
      @Path('id') String id);

  @GET('v1/mms/device-requests')
  Future<DeviceRequestListResponse> getDeviceRequestList(
      @Queries() Map<String, dynamic> query);

  @GET('v1/mms/device-requests/{id}')
  Future<DeviceRequestDetailResponse> getDeviceRequestDetail(
      @Path('id') String id);

  @GET('v1/mms/device-assignments/{id}')
  Future<DeviceAssignmentDetailResponse> getDeviceAssignmentDetail(
      @Path('id') String id);

  @GET('v1/mms/maintenance-teams/responsible-user')
  Future<ListResponsibleResponse> responsibleUser();

  @PUT('v1/mms/jobs/{id}/status/{status}')
  Future updateTaskStatus(@Path('id') String id, @Path('status') int status);

  @GET('v1/mms/warehouse-import')
  Future<WarehouseImportTicketListResponse> getWarehouseImportTicketList(
    @Queries() Map<String, dynamic> query,
  );

  @GET('v1/mms/warehouse-export')
  Future<WarehouseExportTicketListResponse> getWarehouseExportTicketList(
    @Queries() Map<String, dynamic> query,
  );

  @PUT('v1/mms/warehouse-export/{id}/confirm')
  Future<BaseResponseNoData> confirmWarehouseExportTicket(
    @Path('id') String id,
  );
  @PUT('v1/mms/warehouse-import/{id}/confirm')
  Future<BaseResponseNoData> confirmWarehouseImportTicket(
    @Path('id') String id,
  );
  @PUT('v1/mms/warehouse-export/{id}/reject')
  Future<BaseResponseNoData> rejectWarehouseExportTicket(
    @Path('id') String id,
  );
  @PUT('v1/mms/warehouse-import/{id}/reject')
  Future<BaseResponseNoData> rejectWarehouseImportTicket(
    @Path('id') String id,
  );
  @DELETE('v1/mms/warehouse-export/{id}')
  Future<BaseResponseNoData> deleteWarehouseExportTicket(
    @Path('id') String id,
  );
  @DELETE('v1/mms/warehouse-import/{id}')
  Future<BaseResponseNoData> deleteWarehouseImportTicket(
    @Path('id') String id,
  );

  @GET('v1/mms/warehouse-import-request')
  Future<WarehouseImportRequestListResponse> getWarehouseImportRequestList(
    @Queries() Map<String, dynamic> query,
  );

  @GET('v1/mms/warehouse-export-request')
  Future<WarehouseExportRequestListResponse> getWarehouseExportRequestList(
    @Queries() Map<String, dynamic> query,
  );

  @GET('v1/mms/warehouse-import-request/{id}')
  Future<WarehouseImportRequestDetailResponse> getWarehouseImportRequestDetail(
    @Path('id') String id,
  );

  @GET('v1/mms/warehouse-export-request/{id}')
  Future<WarehouseExportRequestDetailResponse> getWarehouseExportRequestDetail(
    @Path('id') String id,
  );

  @GET('v1/mms/warehouse-import/{id}')
  Future<WarehouseImportTicketDetailResponse> getWarehouseImportTicketDetail(
    @Path('id') String id,
  );

  @GET('v1/mms/warehouse-export/{id}')
  Future<WarehouseExportTicketDetailResponse> getWarehouseExportTicketDetail(
    @Path('id') String id,
  );

  @PUT('v1/mms/warehouse-import/{id}')
  Future<BaseResponseNoData> updateWarehouseImportTicket(
      @Path('id') String id, @Body() payload);

  @POST('v1/mms/warehouse-import')
  Future<BaseResponseNoData> createWarehouseImportTicket(@Body() payload);

  @PUT('v1/mms/warehouse-export/{id}')
  Future<BaseResponseNoData> updateWarehouseExportTicket(
      @Path('id') String id, @Body() payload);

  @POST('v1/mms/warehouse-export')
  Future<BaseResponseNoData> createWarehouseExportTicket(@Body() payload);

  @PUT('v1/mms/warehouse-export-request/{id}/confirm')
  Future<BaseResponseNoData> confirmWarehouseExportRequest(
    @Path('id') String id,
  );
  @PUT('v1/mms/warehouse-import-request/{id}/confirm')
  Future<BaseResponseNoData> confirmWarehouseImportRequest(
    @Path('id') String id,
  );
  @PUT('v1/mms/warehouse-export-request/{id}/reject')
  Future<BaseResponseNoData> rejectWarehouseExportRequest(
    @Path('id') String id,
  );
  @PUT('v1/mms/warehouse-import-request/{id}/reject')
  Future<BaseResponseNoData> rejectWarehouseImportRequest(
    @Path('id') String id,
  );
  @DELETE('v1/mms/warehouse-export-request/{id}')
  Future<BaseResponseNoData> deleteWarehouseExportRequest(
    @Path('id') String id,
  );
  @DELETE('v1/mms/warehouse-import-request/{id}')
  Future<BaseResponseNoData> deleteWarehouseImportRequest(
    @Path('id') String id,
  );

  @POST('v1/mms/warehouse-import-request')
  Future<BaseResponseNoData> createWarehouseImportRequest(@Body() payload);

  @PUT('v1/mms/warehouse-import-request/{id}')
  Future<BaseResponseNoData> updateWarehouseImportRequest(
      @Path('id') id, @Body() payload);

  @POST('v1/mms/warehouse-export-request')
  Future<BaseResponseNoData> createWarehouseExportRequest(@Body() payload);

  @PUT('v1/mms/warehouse-export-request/{id}')
  Future<BaseResponseNoData> updateWarehouseExportRequest(
      @Path('id') id, @Body() payload);

  @GET(
      'v1/mms/warehouses/inventories/warehouses/{warehouseId}/device-group/{deviceGroupId}')
  Future<DeviceListResponse> getDeviceInventoryDetail(
    @Path('warehouseId') warehouseId,
    @Path('deviceGroupId') deviceGroupId,
    @Queries() Map<String, dynamic> payload,
  );
}
