import 'package:json_annotation/json_annotation.dart';

part 'user_dto.g.dart';

@JsonSerializable()
class UserDTO {
  final int? id;
  final String? fullName;
  @JsonKey(name: 'username')
  final String? userName;
  final String? name;

  final String? code;

  UserDTO({
    this.id,
    this.fullName,
    this.userName,
    this.name,
    this.code,
  });

  factory UserDTO.fromJson(Map<String, dynamic> json) =>
      _$UserDTOFromJson(json);

  Map<String, dynamic> toJson() => _$UserDTOToJson(this);
}
