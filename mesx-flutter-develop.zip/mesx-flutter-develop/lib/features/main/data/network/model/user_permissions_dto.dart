import 'package:json_annotation/json_annotation.dart';

part 'user_permissions_dto.g.dart';

@JsonSerializable()
class UserPermissionDTO {
  String code;

  UserPermissionDTO(
    this.code,
  );

  factory UserPermissionDTO.fromJson(Map<String, dynamic> json) =>
      _$UserPermissionDTOFromJson(json);

  Map<String, dynamic> toJson() => _$UserPermissionDTOToJson(this);
}
