import 'package:json_annotation/json_annotation.dart';

part 'factory_info_dto.g.dart';

@JsonSerializable()
class FactoryInfoDTO {
  final int? id;
  final String? code;
  final String? name;
  final int? companyId;
  final String? companyName;
  final String? regionId;
  final int? active;
  final int? createdBy;
  final String? address;
  final String? phone;
  final String? createdAt;
  final String? updatedAt;
  final String? description;

  FactoryInfoDTO(
    this.id,
    this.name,
    this.code,
    this.createdAt,
    this.updatedAt,
    this.description,
    this.regionId,
    this.active,
    this.createdBy,
    this.companyId,
    this.companyName,
    this.address,
    this.phone,
  );

  factory FactoryInfoDTO.fromJson(Map<String, dynamic> json) =>
      _$FactoryInfoDTOFromJson(json);

  Map<String, dynamic> toJson() => _$FactoryInfoDTOToJson(this);
}
