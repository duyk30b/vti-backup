import 'package:json_annotation/json_annotation.dart';

part 'accreditation_template_detail_dto.g.dart';

@JsonSerializable()
class AccreditationTemplateDetailDTO {
  final String? id;
  final String? title;
  final String? description;
  final num? obligatory;

  AccreditationTemplateDetailDTO({
    this.id,
    this.title,
    this.description,
    this.obligatory,
  });

  factory AccreditationTemplateDetailDTO.fromJson(Map<String, dynamic> json) =>
      _$AccreditationTemplateDetailDTOFromJson(json);

  Map<String, dynamic> toJson() => _$AccreditationTemplateDetailDTOToJson(this);
}
