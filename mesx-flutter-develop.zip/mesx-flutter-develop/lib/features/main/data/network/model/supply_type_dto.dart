import 'package:json_annotation/json_annotation.dart';

part 'supply_type_dto.g.dart';

@JsonSerializable()
class SupplyTypeDTO {
  final String? id;
  final String? name;
  final int? type;
  final DateTime? createdAt;

  SupplyTypeDTO({this.id, this.name, this.type, this.createdAt});

  factory SupplyTypeDTO.fromJson(Map<String, dynamic> json) =>
      _$SupplyTypeDTOFromJson(json);

  Map<String, dynamic> toJson() => _$SupplyTypeDTOToJson(this);
}
