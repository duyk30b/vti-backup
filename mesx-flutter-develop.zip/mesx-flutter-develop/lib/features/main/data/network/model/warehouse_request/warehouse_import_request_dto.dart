import 'package:json_annotation/json_annotation.dart';
import '../../../../domain/enum/warehouse_request_enum.dart';
import '../../../../domain/enum/warehouse_ticket_enum.dart';
import '../device_detail_dto.dart';
import '../device_request_dto.dart';
import '../factory_info_dto.dart';
import '../supply_request_dto.dart';
import '../transfer_ticket_dto.dart';
import '../warehouse_dto.dart';
import 'warehouse_request_device_group_dto.dart';
import 'warehouse_request_dto.dart';
import 'warehouse_request_supply_dto.dart';

part 'warehouse_import_request_dto.g.dart';

@JsonSerializable()
class WarehouseImportRequestDTO extends WarehouseRequestDTO {
  final String? description;
  final FactoryInfoDTO? fromFactory;
  final FactoryInfoDTO? toFactory;
  final DateTime? importDate;

  final String? requestCode;
  final WarehouseImportTicketRequestType? requestType;
  final DeviceRequestDTO? deviceRequest;
  final SupplyRequestDTO? supplyRequest;
  final TransferTicketDTO? transferTicket;

  WarehouseImportRequestDTO({
    this.description,
    this.fromFactory,
    this.importDate,
    this.toFactory,
    this.requestCode,
    this.requestType,
    this.deviceRequest,
    this.supplyRequest,
    this.transferTicket,
    String? id,
    String? code,
    String? name,
    List<WarehouseRequestSupplyDTO> supplies = const [],
    List<WarehouseRequestDeviceGroupDTO> deviceGroups = const [],
    List<DeviceDetailDTO> devices = const [],
    WarehouseDTO? warehouse,
    WarehouseRequestStatus? status,
  }) : super(
            code: code,
            id: id,
            name: name,
            deviceGroups: deviceGroups,
            supplies: supplies,
            devices: devices,
            warehouse: warehouse,
            status: status);

  factory WarehouseImportRequestDTO.fromJson(Map<String, dynamic> json) {
    final Map<String, dynamic> convertJson = {
      ...json,
      'deviceRequest': json['requestType'] ==
              WarehouseImportTicketRequestType.returnDevice.type
          ? json['request']
          : null,
      'supplyRequest': json['requestType'] ==
              WarehouseImportTicketRequestType.returnSupply.type
          ? json['request']
          : null,
      'transferTicket': json['requestType'] ==
              WarehouseImportTicketRequestType.transferDevice.type
          ? json['request']
          : null,
    };
    return _$WarehouseImportRequestDTOFromJson(convertJson);
  }

  @override
  Map<String, dynamic> toJson() => _$WarehouseImportRequestDTOToJson(this);
}
