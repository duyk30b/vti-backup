import 'package:json_annotation/json_annotation.dart';

import '../../../domain/model/payload.dart';

part 'payload_dto.g.dart';

@JsonSerializable()
class PayLoadDTO {
  final String id;
  final String name;
  final String code;
  final NotificationEntityEnum entity;
  final int? entityType;
  @JsonKey(name: '_id')
  final String sId;

  PayLoadDTO({
    required this.id,
    required this.name,
    required this.code,
    required this.entity,
    required this.sId,
    this.entityType,
  });

  factory PayLoadDTO.fromJson(Map<String, dynamic> json) =>
      _$PayLoadDTOFromJson(json);

  Map<String, dynamic> toJson() => _$PayLoadDTOToJson(this);
}
