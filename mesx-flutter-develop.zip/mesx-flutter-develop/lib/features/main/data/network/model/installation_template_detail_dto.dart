import 'package:json_annotation/json_annotation.dart';

part 'installation_template_detail_dto.g.dart';

@JsonSerializable()
class InstallationTemplateDetailDTO {
  final String? id;
  final String? title;
  final String? description;
  final num? obligatory;

  InstallationTemplateDetailDTO({
    this.id,
    this.title,
    this.description,
    this.obligatory,
  });

  factory InstallationTemplateDetailDTO.fromJson(Map<String, dynamic> json) =>
      _$InstallationTemplateDetailDTOFromJson(json);

  Map<String, dynamic> toJson() => _$InstallationTemplateDetailDTOToJson(this);
}
