import 'package:json_annotation/json_annotation.dart';

import 'create_by_dto.dart';
import 'payload_dto.dart';

part 'notification_id_dto.g.dart';

@JsonSerializable(explicitToJson: true)
class NotificationIdDTO {
  @JsonKey(name: '_id')
  final String sId;
  final int action;
  final PayLoadDTO payload;
  final CreateByDTO? createdBy;

  NotificationIdDTO(this.sId, this.action, this.payload, {this.createdBy});

  factory NotificationIdDTO.fromJson(Map<String, dynamic> json) =>
      _$NotificationIdDTOFromJson(json);

  Map<String, dynamic> toJson() => _$NotificationIdDTOToJson(this);
}
