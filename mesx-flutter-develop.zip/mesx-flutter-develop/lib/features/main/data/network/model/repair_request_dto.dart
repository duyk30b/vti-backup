import 'package:json_annotation/json_annotation.dart';
import '../../../domain/enum/repair_request_status.dart';
import 'device_detail_dto.dart';
import 'error_type_dto.dart';
import 'job_dto.dart';
import 'repair_request_history_dto.dart';
import 'supply_dto.dart';
import 'user_dto.dart';
part 'repair_request_dto.g.dart';

@JsonSerializable()
class RepairRequestDTO {
  final String? id;
  final String? code;
  final String? name;
  final RepairRequestPriorityEnum? priority;
  final DateTime? createdAt;
  final DeviceDetailDTO? device;
  final UserDTO? requestedBy;
  final List<RepairRequestHistoryDTO> histories;
  final RepairRequestStatusEnum? status;
  final ErrorTypeDTO? errorType;
  final String? description;
  final List<SupplyDTO> supplies;
  final UserDTO? executedBy;
  final num? stopTime;
  final num? executionTime;
  final JobDTO? accreditationJob;

  RepairRequestDTO({
    this.id,
    this.code,
    this.name,
    this.priority,
    this.createdAt,
    this.device,
    this.requestedBy,
    this.histories = const [],
    this.status,
    this.errorType,
    this.description,
    this.supplies = const [],
    this.executedBy,
    this.stopTime,
    this.executionTime,
    this.accreditationJob,
  });

  factory RepairRequestDTO.fromJson(Map<String, dynamic> json) =>
      _$RepairRequestDTOFromJson(json);

  Map<String, dynamic> toJson() => _$RepairRequestDTOToJson(this);
}
