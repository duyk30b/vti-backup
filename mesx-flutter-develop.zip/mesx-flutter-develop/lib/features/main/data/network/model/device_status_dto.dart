import 'package:json_annotation/json_annotation.dart';

import '../../../domain/enum/device_status.dart';

part 'device_status_dto.g.dart';

@JsonSerializable()
class DeviceStatusDTO {
  final String? id;
  final String? code;
  final String? name;
  final DeviceStatusType? deviceStatus;
  final String? serial;

  DeviceStatusDTO({
    this.id,
    this.name,
    this.deviceStatus,
    this.serial,
    this.code,
  });

  factory DeviceStatusDTO.fromJson(Map<String, dynamic> json) =>
      _$DeviceStatusDTOFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceStatusDTOToJson(this);
}
