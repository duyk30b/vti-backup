import 'package:json_annotation/json_annotation.dart';

import '../device_group_dto.dart';

part 'warehouse_request_device_group_dto.g.dart';

@JsonSerializable()
class WarehouseRequestDeviceGroupDTO extends DeviceGroupDTO {
  final int? quantity;
  final int? importedQuantity;

  WarehouseRequestDeviceGroupDTO({
    this.quantity,
    this.importedQuantity,
    String? id,
    String? name,
    String? code,
  }) : super(
          id: id,
          name: name,
          code: code,
        );

  factory WarehouseRequestDeviceGroupDTO.fromJson(Map<String, dynamic> json) =>
      _$WarehouseRequestDeviceGroupDTOFromJson(json);

  @override
  Map<String, dynamic> toJson() => _$WarehouseRequestDeviceGroupDTOToJson(this);
}
