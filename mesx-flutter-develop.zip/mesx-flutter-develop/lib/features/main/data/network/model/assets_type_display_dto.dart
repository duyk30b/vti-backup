import 'package:json_annotation/json_annotation.dart';

part 'assets_type_display_dto.g.dart';

@JsonSerializable()
class AssetTypeDisplayDTO {
  String? sId;
  String? name;
  int? type;

  AssetTypeDisplayDTO({this.sId, this.name, this.type});

  factory AssetTypeDisplayDTO.fromJson(Map<String, dynamic> json) =>
      _$AssetTypeDisplayDTOFromJson(json);

  Map<String, dynamic> toJson() => _$AssetTypeDisplayDTOToJson(this);
}
