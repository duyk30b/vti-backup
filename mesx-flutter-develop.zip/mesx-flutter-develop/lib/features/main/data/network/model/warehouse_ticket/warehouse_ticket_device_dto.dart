import 'package:json_annotation/json_annotation.dart';

import '../../../../domain/enum/device_enum.dart';
import '../area_info_dto.dart';
import '../article_device_group_dto.dart';
import '../device_detail_dto.dart';
import '../device_group_dto.dart';
import '../factory_info_dto.dart';
import '../maintenance_index_dto.dart';
import '../supply_dto.dart';
import '../unit_dto.dart';
import '../vendor_dto.dart';
import '../warehouse_dto.dart';

part 'warehouse_ticket_device_dto.g.dart';

@JsonSerializable()
class WarehouseTicketDeviceDTO extends DeviceDetailDTO {
  String? color;
  String? size;
  num? price;

  WarehouseTicketDeviceDTO({
    this.color,
    this.size,
    this.price,
    String? id,
    String? code,
    String? name,
    DeviceUsageStatus? status,
    num? warrantyPeriod,
    String? serial,
    String? model,
    String? manufacturer,
    DateTime? manufactureDate,
    DeviceGroupDTO? deviceGroup,
    VendorDTO? vendor,
    MaintenanceIndexDTO? maintenanceIndex,
    DateTime? createdAt,
    DateTime? creationDate,
    DateTime? capitalizationDate,
    String? imageUrl,
    FactoryInfoDTO? factory,
    AreaInfoDTO? area,
    String? description,
    String? identificationNo,
    ArticleDeviceGroupDTO? articleDeviceGroup,
    List<SupplyDTO>? supplies,
    UnitDTO? unit,
    WarehouseDTO? warehouse,
  }) : super(
          id: id,
          code: code,
          name: name,
          status: status,
          warrantyPeriod: warrantyPeriod,
          serial: serial,
          model: model,
          manufacturer: manufacturer,
          manufactureDate: manufactureDate,
          deviceGroup: deviceGroup,
          vendor: vendor,
          maintenanceIndex: maintenanceIndex,
          createdAt: createdAt,
          creationDate: creationDate,
          capitalizationDate: capitalizationDate,
          imageUrl: imageUrl,
          factory: factory,
          area: area,
          description: description,
          identificationNo: identificationNo,
          articleDeviceGroup: articleDeviceGroup,
          supplies: supplies,
          unit: unit,
          warehouse: warehouse,
        );

  factory WarehouseTicketDeviceDTO.fromJson(Map<String, dynamic> json) =>
      _$WarehouseTicketDeviceDTOFromJson(json);

  @override
  Map<String, dynamic> toJson() => _$WarehouseTicketDeviceDTOToJson(this);
}
