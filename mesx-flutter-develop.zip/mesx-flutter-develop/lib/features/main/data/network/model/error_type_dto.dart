import 'package:json_annotation/json_annotation.dart';

part 'error_type_dto.g.dart';

@JsonSerializable()
class ErrorTypeDTO {
  final String id;
  final String code;
  final String name;

  ErrorTypeDTO(this.id, this.code, this.name);

  factory ErrorTypeDTO.fromJson(Map<String, dynamic> json) =>
      _$ErrorTypeDTOFromJson(json);

  Map<String, dynamic> toJson() => _$ErrorTypeDTOToJson(this);
}
