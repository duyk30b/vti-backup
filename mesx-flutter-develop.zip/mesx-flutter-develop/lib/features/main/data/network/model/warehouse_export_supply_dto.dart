import 'package:json_annotation/json_annotation.dart';

import 'supply_dto.dart';
import 'supply_group_dto.dart';
import 'unit_dto.dart';
import 'vendor_dto.dart';

part 'warehouse_export_supply_dto.g.dart';

@JsonSerializable()
class WarehouseExportSupplyDTO {
  final SupplyDTO? supply;
  final UnitDTO? unit;
  final VendorDTO? vendor;
  final SupplyGroupDTO? supplyGroup;
  final num? availableQuantity;
  final num? exportQuantity;
  final num? requestQuantity;
  final num? stockQuantity;
  final String? color;
  final String? size;
  WarehouseExportSupplyDTO({
    this.supply,
    this.unit,
    this.vendor,
    this.supplyGroup,
    this.availableQuantity,
    this.exportQuantity,
    this.requestQuantity,
    this.stockQuantity,
    this.color,
    this.size,
  });

  factory WarehouseExportSupplyDTO.fromJson(Map<String, dynamic> json) =>
      _$WarehouseExportSupplyDTOFromJson(json);

  Map<String, dynamic> toJson() => _$WarehouseExportSupplyDTOToJson(this);
}
