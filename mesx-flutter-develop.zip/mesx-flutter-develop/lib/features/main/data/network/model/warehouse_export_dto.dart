import 'package:json_annotation/json_annotation.dart';

import '../../../domain/enum/warehouse_export_enum.dart';
import 'device_request_dto.dart';
import 'factory_info_dto.dart';
import 'supply_request_dto.dart';
import 'transfer_ticket_dto.dart';
import 'warehouse_dto.dart';
import 'warehouse_export_device_dto.dart';
import 'warehouse_export_supply_dto.dart';

part 'warehouse_export_dto.g.dart';

@JsonSerializable()
class WarehouseExportDTO {
  final String? id;
  final String? code;
  final String? name;
  final DateTime? exportDate;
  final DateTime? date;
  final String? note;
  final String? number;
  final String? contractNum;
  final String? debit;
  final String? credit;
  final String? gdiNo;
  final String? symbol;
  final String? reason;
  final String? requestCode;
  final WarehouseExportStatus? status;
  final FactoryInfoDTO? toFactory;
  final WarehouseDTO? warehouse;
  final WarehouseExportType? requestType;
  final List<WarehouseExportDeviceDTO>? devices;
  final List<WarehouseExportSupplyDTO>? supplies;
  final SupplyRequestDTO? supplyRequest;
  final DeviceRequestDTO? returnDevice;
  final TransferTicketDTO? transferRequest;
  final TransferTicketDTO? transferLoan;

  WarehouseExportDTO({
    this.id,
    this.code,
    this.name,
    this.exportDate,
    this.date,
    this.note,
    this.number,
    this.contractNum,
    this.debit,
    this.credit,
    this.gdiNo,
    this.symbol,
    this.reason,
    this.requestCode,
    this.status,
    this.toFactory,
    this.warehouse,
    this.requestType,
    this.devices,
    this.supplies,
    this.supplyRequest,
    this.returnDevice,
    this.transferRequest,
    this.transferLoan,
  });

  factory WarehouseExportDTO.fromJson(Map<String, dynamic> json) {
    final requestType = json['requestType'];
    final request = json['request'];
    final Map<String, dynamic> convertJson = {
      ...json,
      'transferLoan':
          requestType == WarehouseExportType.transferLoan.type ? request : null,
      'transferRequest': requestType == WarehouseExportType.transferRequest.type
          ? request
          : null,
      'supplyRequest': requestType == WarehouseExportType.supplyRequest.type
          ? request
          : null,
      'returnDevice':
          requestType == WarehouseExportType.returnDevice.type ? request : null,
    };
    return _$WarehouseExportDTOFromJson(convertJson);
  }

  Map<String, dynamic> toJson() => _$WarehouseExportDTOToJson(this);
}
