import 'package:json_annotation/json_annotation.dart';

import 'accreditation_template_dto.dart';
import 'article_device_group_dto.dart';
import 'attribute_type_dto.dart';
import 'error_type_dto.dart';
import 'installation_template_dto.dart';
import 'maintenance_template_dto.dart';
import 'supply_dto.dart';

part 'device_group_dto.g.dart';

@JsonSerializable(
  explicitToJson: true,
)
class DeviceGroupDTO {
  final String? id;
  final String? name;
  final String? code;
  final List<AttributeTypeDTO>? attributeTypes;
  final List<SupplyDTO>? supplies;
  final MaintenanceTemplateDTO? maintenanceTemplate;
  final InstallationTemplateDTO? installationTemplate;
  final AccreditationTemplateDTO? accreditationTemplate;
  final List<ErrorTypeDTO> errorTypes;
  final ArticleDeviceGroupDTO? articleDeviceGroup;

  DeviceGroupDTO({
    this.id,
    this.name,
    this.code,
    this.attributeTypes,
    this.supplies,
    this.maintenanceTemplate,
    this.installationTemplate,
    this.accreditationTemplate,
    this.errorTypes = const [],
    this.articleDeviceGroup,
  });

  factory DeviceGroupDTO.fromJson(Map<String, dynamic> json) =>
      _$DeviceGroupDTOFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceGroupDTOToJson(this);
}
