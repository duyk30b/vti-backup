import 'package:json_annotation/json_annotation.dart';

import '../../../../domain/enum/warehouse_ticket_enum.dart';
import '../warehouse_dto.dart';
import '../warehouse_request/warehouse_request_device_group_dto.dart';
import 'warehouse_ticket_device_dto.dart';
import 'warehouse_ticket_supply_dto.dart';

part 'warehouse_ticket_dto.g.dart';

@JsonSerializable()
class WarehouseTicketDTO {
  final String? id;
  final String? code;
  final String? name;
  final WarehouseTicketTypeEnum? ticketType;
  final DateTime? date;
  final String? note;
  final String? deliver;
  final String? number;
  final String? soNum;
  final String? poNum;
  final String? remain;
  final String? contractNum;
  final String? credit;
  final String? debit;
  final String? symbol;
  final String? reason;
  final String? gdiNo;
  final WarehouseDTO? warehouse;
  final String? templateNum;
  final List<WarehouseTicketDeviceDTO>? devices;
  final List<WarehouseRequestDeviceGroupDTO>? deviceGroups;
  final List<WarehouseTicketSupplyDTO>? supplies;
  final WarehouseTicketStatus? status;

  WarehouseTicketDTO({
    this.id,
    this.name,
    this.code,
    this.date,
    this.note,
    this.deliver,
    this.number,
    this.soNum,
    this.poNum,
    this.remain,
    this.contractNum,
    this.debit,
    this.symbol,
    this.warehouse,
    this.templateNum,
    this.ticketType,
    this.devices = const [],
    this.supplies = const [],
    this.reason,
    this.gdiNo,
    this.status,
    this.deviceGroups,
    this.credit,
  });

  factory WarehouseTicketDTO.fromJson(Map<String, dynamic> json) =>
      _$WarehouseTicketDTOFromJson(json);

  Map<String, dynamic> toJson() => _$WarehouseTicketDTOToJson(this);
}
