import 'package:json_annotation/json_annotation.dart';
import './unit_dto.dart';

part 'attribute_type_dto.g.dart';

@JsonSerializable()
class AttributeTypeDTO {
  final String? code;
  final String? name;
  final String? id;
  final UnitDTO? unit;
  final String? attributeTypeName;
  final String? attributeTypeCode;
  final String? attributeTypeId;
  final num? value;

  AttributeTypeDTO({
    this.code,
    this.name,
    this.id,
    this.unit,
    this.attributeTypeName,
    this.attributeTypeCode,
    this.attributeTypeId,
    this.value,
  });

  factory AttributeTypeDTO.fromJson(Map<String, dynamic> json) =>
      _$AttributeTypeDTOFromJson(json);

  Map<String, dynamic> toJson() => _$AttributeTypeDTOToJson(this);
}
