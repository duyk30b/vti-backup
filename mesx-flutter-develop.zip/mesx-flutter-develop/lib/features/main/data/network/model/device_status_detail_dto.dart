import 'package:json_annotation/json_annotation.dart';

import '../../../domain/enum/device_status.dart';
import 'attribute_type_dto.dart';

part 'device_status_detail_dto.g.dart';

@JsonSerializable(
  explicitToJson: true,
)
class DeviceStatusDetailDTO {
  final String? id;
  final DeviceStatusType? status;
  final DateTime? startTime;
  final DateTime? endTime;
  final num? activeTime;
  final List<AttributeTypeDTO> attributeTypes;

  DeviceStatusDetailDTO({
    this.status,
    this.startTime,
    this.endTime,
    this.activeTime,
    this.attributeTypes = const [],
    this.id,
  });

  factory DeviceStatusDetailDTO.fromJson(Map<String, dynamic> json) =>
      _$DeviceStatusDetailDTOFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceStatusDetailDTOToJson(this);
}
