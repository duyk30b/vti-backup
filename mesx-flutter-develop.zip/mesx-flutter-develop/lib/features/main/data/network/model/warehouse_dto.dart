import 'package:json_annotation/json_annotation.dart';

import 'factory_info_dto.dart';

part 'warehouse_dto.g.dart';

@JsonSerializable()
class WarehouseDTO {
  final String id;
  final String name;
  final String code;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final FactoryInfoDTO? factory;

  WarehouseDTO(
    this.id,
    this.name,
    this.code,
    this.createdAt,
    this.updatedAt,
    this.factory,
  );

  factory WarehouseDTO.fromJson(Map<String, dynamic> json) =>
      _$WarehouseDTOFromJson(json);

  Map<String, dynamic> toJson() => _$WarehouseDTOToJson(this);
}
