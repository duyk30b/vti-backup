import 'package:json_annotation/json_annotation.dart';

import 'installation_template_detail_dto.dart';

part 'installation_template_dto.g.dart';

@JsonSerializable()
class InstallationTemplateDTO {
  final String? id;
  final String? name;
  final String? code;
  final int? active;
  final String? description;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final List<InstallationTemplateDetailDTO>? details;

  InstallationTemplateDTO({
    this.id,
    this.name,
    this.code,
    this.active,
    this.description,
    this.createdAt,
    this.updatedAt,
    this.details,
  });

  factory InstallationTemplateDTO.fromJson(Map<String, dynamic> json) =>
      _$InstallationTemplateDTOFromJson(json);

  Map<String, dynamic> toJson() => _$InstallationTemplateDTOToJson(this);
}
