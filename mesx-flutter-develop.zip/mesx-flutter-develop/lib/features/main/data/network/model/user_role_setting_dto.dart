import 'package:json_annotation/json_annotation.dart';

import '../../../domain/enum/user_role.dart';

part 'user_role_setting_dto.g.dart';

@JsonSerializable()
class UserRoleSettingDTO {
  int? id;
  String? name;
  ROLE? code;
  int? status;
  String? createdAt;
  String? updatedAt;

  UserRoleSettingDTO(
      {this.id,
      this.name,
      this.code,
      this.status,
      this.createdAt,
      this.updatedAt});

  factory UserRoleSettingDTO.fromJson(Map<String, dynamic> json) =>
      _$UserRoleSettingDTOFromJson(json);

  Map<String, dynamic> toJson() => _$UserRoleSettingDTOToJson(this);
}
