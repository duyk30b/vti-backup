import 'package:json_annotation/json_annotation.dart';

part 'maintenance_template_detail_dto.g.dart';

@JsonSerializable()
class MaintenanceTemplateDetailDTO {
  final String? id;
  final String? title;
  final String? description;
  final int? type;
  final num? obligatory;
  final num? periodTime;
  final num? timeUnit;

  MaintenanceTemplateDetailDTO({
    this.id,
    this.title,
    this.description,
    this.type,
    this.obligatory,
    this.periodTime,
    this.timeUnit,
  });

  factory MaintenanceTemplateDetailDTO.fromJson(Map<String, dynamic> json) =>
      _$MaintenanceTemplateDetailDTOFromJson(json);

  Map<String, dynamic> toJson() => _$MaintenanceTemplateDetailDTOToJson(this);
}
