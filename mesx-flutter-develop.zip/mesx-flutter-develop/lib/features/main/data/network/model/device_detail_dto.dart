import 'package:json_annotation/json_annotation.dart';
import '../../../../../core/utils/json_converter.dart';

import '../../../domain/enum/device_enum.dart';
import 'area_info_dto.dart';
import 'article_device_group_dto.dart';
import 'device_group_dto.dart';
import 'factory_info_dto.dart';
import 'maintenance_index_dto.dart';
import 'supply_dto.dart';
import 'unit_dto.dart';
import 'vendor_dto.dart';
import 'warehouse_dto.dart';

part 'device_detail_dto.g.dart';

@JsonSerializable(explicitToJson: true, converters: [
  DateTimeConverter(),
])
class DeviceDetailDTO {
  final String? name;
  final String? serial;
  final String? actualSerial;
  final String? manufacturer;
  final num? warrantyPeriod;
  final DeviceUsageStatus? status;
  final String? model;
  final DateTime? manufactureDate;
  final String? id;
  final String? code;
  final DateTime? createdAt;
  final DateTime? creationDate;
  final DateTime? capitalizationDate;
  final String? imageUrl;
  final FactoryInfoDTO? factory;
  final AreaInfoDTO? area;
  final String? description;
  final DeviceGroupDTO? deviceGroup;
  final VendorDTO? vendor;
  final MaintenanceIndexDTO? maintenanceIndex;
  final String? identificationNo;
  final List<SupplyDTO>? supplies;
  final UnitDTO? unit;
  final num? estimateUsedTime;
  final WarehouseDTO? warehouse;
  final WarehouseDTO? exportWarehouse;
  final int? exportPlanned;
  final int? exported;
  final int? importPlanned;
  final int? returnPlanned;
  final int? imported;
  final ArticleDeviceGroupDTO? articleDeviceGroup;

  DeviceDetailDTO({
    this.id,
    this.code,
    this.createdAt,
    this.creationDate,
    this.capitalizationDate,
    this.factory,
    this.area,
    this.description,
    this.manufacturer,
    this.model,
    this.name,
    this.serial,
    this.status,
    this.deviceGroup,
    this.vendor,
    this.manufactureDate,
    this.warrantyPeriod,
    this.maintenanceIndex,
    this.identificationNo,
    this.articleDeviceGroup,
    this.imageUrl,
    this.supplies,
    this.warehouse,
    this.exportWarehouse,
    this.unit,
    this.estimateUsedTime,
    this.exportPlanned,
    this.exported,
    this.importPlanned,
    this.returnPlanned,
    this.imported,
    this.actualSerial,
  });

  factory DeviceDetailDTO.fromJson(Map<String, dynamic> json) =>
      _$DeviceDetailDTOFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceDetailDTOToJson(this);
}
