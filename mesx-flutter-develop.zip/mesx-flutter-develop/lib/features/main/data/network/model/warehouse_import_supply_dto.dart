import 'package:json_annotation/json_annotation.dart';

import 'supply_dto.dart';
import 'supply_group_dto.dart';
import 'unit_dto.dart';
import 'vendor_dto.dart';
import 'warehouse_dto.dart';

part 'warehouse_import_supply_dto.g.dart';

@JsonSerializable()
class WarehouseImportSupplyDTO {
  final SupplyDTO? supply;
  final String? symbol;
  final String? color;
  final String? size;

  final String? templateNum;
  final UnitDTO? unit;
  final SupplyGroupDTO? supplyGroup;
  final VendorDTO? vendor;
  final WarehouseDTO? warehouse;
  final num? grantedQuantity;
  final num? returnQuantity;
  final num? quantity;
  final num? providedQuantity;
  final num? price;
  final num? intoMoney;

  WarehouseImportSupplyDTO({
    this.supply,
    this.symbol,
    this.templateNum,
    this.unit,
    this.supplyGroup,
    this.vendor,
    this.warehouse,
    this.color,
    this.size,
    this.grantedQuantity,
    this.returnQuantity,
    this.quantity,
    this.providedQuantity,
    this.price,
    this.intoMoney,
  });

  factory WarehouseImportSupplyDTO.fromJson(Map<String, dynamic> json) =>
      _$WarehouseImportSupplyDTOFromJson(json);

  Map<String, dynamic> toJson() => _$WarehouseImportSupplyDTOToJson(this);
}
