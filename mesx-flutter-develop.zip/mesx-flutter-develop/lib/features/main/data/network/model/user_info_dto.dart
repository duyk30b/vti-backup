import 'package:json_annotation/json_annotation.dart';

import 'factory_info_dto.dart';
import 'maintenance_template_dto.dart';
import 'user_permissions_dto.dart';
import 'user_role_setting_dto.dart';

part 'user_info_dto.g.dart';

@JsonSerializable()
class UserInfoDTO {
  final int id;
  final int role;
  final String email;
  final String username;
  final String fullName;
  final int companyId;
  final String? dateOfBirth;
  final String code;
  final String? phone;
  final int status;
  final String createdAt;
  final String updatedAt;
  final MaintenanceTemplateDTO? maintenanceTeam;
  final List<UserPermissionDTO>? userPermissions;
  final List<UserRoleSettingDTO>? userRoleSettings;
  final int? factoryId;
  final List<FactoryInfoDTO>? factories;

  UserInfoDTO(
      this.id,
      this.role,
      this.email,
      this.username,
      this.fullName,
      this.companyId,
      this.dateOfBirth,
      this.code,
      this.phone,
      this.status,
      this.createdAt,
      this.updatedAt,
      this.maintenanceTeam,
      this.userPermissions,
      this.userRoleSettings,
      this.factoryId,
      this.factories);

  factory UserInfoDTO.fromJson(Map<String, dynamic> json) =>
      _$UserInfoDTOFromJson(json);

  Map<String, dynamic> toJson() => _$UserInfoDTOToJson(this);
}
