import 'package:json_annotation/json_annotation.dart';

import '../../../domain/enum/device_activity_enum.dart';
import 'create_by_dto.dart';

part 'device_activity_history_dto.g.dart';

@JsonSerializable(explicitToJson: true)
class DeviceActivityHistoryDTO {
  final String id;
  final CreateByDTO createdBy;
  final DateTime startTime;
  final DeviceActivityStatus? status;
  final DateTime createdAt;
  final DateTime updatedAt;

  DeviceActivityHistoryDTO(
    this.id,
    this.createdBy,
    this.startTime,
    this.status,
    this.createdAt,
    this.updatedAt,
  );

  factory DeviceActivityHistoryDTO.fromJson(Map<String, dynamic> json) =>
      _$DeviceActivityHistoryDTOFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceActivityHistoryDTOToJson(this);
}
