import 'package:json_annotation/json_annotation.dart';

import 'factory_info_dto.dart';

part 'area_info_dto.g.dart';

@JsonSerializable()
class AreaInfoDTO {
  final String id;
  final String name;
  final String code;
  final String createdAt;
  final String updatedAt;
  final String? description;
  final int? active;
  final FactoryInfoDTO? factory;

  AreaInfoDTO(
    this.id,
    this.name,
    this.code,
    this.createdAt,
    this.updatedAt,
    this.description,
    this.active,
    this.factory,
  );

  factory AreaInfoDTO.fromJson(Map<String, dynamic> json) =>
      _$AreaInfoDTOFromJson(json);

  Map<String, dynamic> toJson() => _$AreaInfoDTOToJson(this);
}
