import 'package:json_annotation/json_annotation.dart';

import '../../../domain/enum/maintain_enum.dart';
import 'detail.dart';

part 'result.g.dart';

@JsonSerializable(explicitToJson: true)
class ResultDTO {
  int? result;
  List<DetailDTO>? details;
  MaintainType? maintenanceType;
  String? description;

  ResultDTO({this.result, this.details});

  factory ResultDTO.fromJson(Map<String, dynamic> json) =>
      _$ResultDTOFromJson(json);

  Map<String, dynamic> toJson() => _$ResultDTOToJson(this);
}
