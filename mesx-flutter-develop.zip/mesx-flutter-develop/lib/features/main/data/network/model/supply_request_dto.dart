import 'package:json_annotation/json_annotation.dart';

import '../../../domain/enum/supply_request_enum.dart';
import 'create_by_dto.dart';
import 'factory_info_dto.dart';
import 'job_dto.dart';
import 'request_dto.dart';
import 'supply_dto.dart';
import 'warehouse_dto.dart';

part 'supply_request_dto.g.dart';

@JsonSerializable(explicitToJson: true)
class SupplyRequestDTO {
  final String? id;
  final String? code;
  final String? name;
  final String? description;
  final SupplyRequestStatus? status;
  final int? type;
  final DateTime? createdAt;
  final DateTime? expectDate;
  final DateTime? updatedAt;
  final List<JobDTO>? jobs;
  final CreateByDTO? requestedBy;
  final WarehouseDTO? warehouse;
  final RequestDTO? request;
  final List<SupplyDTO>? supplies;
  final FactoryInfoDTO? fromFactory;
  final FactoryInfoDTO? toFactory;
  final FactoryInfoDTO? factory;

  SupplyRequestDTO({
    this.id,
    this.code,
    this.name,
    this.type,
    this.status,
    this.createdAt,
    this.updatedAt,
    this.jobs,
    this.expectDate,
    this.requestedBy,
    this.description,
    this.warehouse,
    this.supplies,
    this.factory,
    this.request,
    this.fromFactory,
    this.toFactory,
  });

  factory SupplyRequestDTO.fromJson(Map<String, dynamic> json) =>
      _$SupplyRequestDTOFromJson(json);

  Map<String, dynamic> toJson() => _$SupplyRequestDTOToJson(this);
}
