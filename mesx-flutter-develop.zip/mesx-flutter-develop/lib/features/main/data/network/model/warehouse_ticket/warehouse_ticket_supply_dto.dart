import 'package:json_annotation/json_annotation.dart';

import '../../../../domain/enum/maintain_enum.dart';
import '../supply_dto.dart';
import '../supply_group_dto.dart';
import '../supply_type_dto.dart';
import '../unit_dto.dart';

part 'warehouse_ticket_supply_dto.g.dart';

@JsonSerializable()
class WarehouseTicketSupplyDTO extends SupplyDTO {
  final String? color;
  final String? size;
  final int? importQuantity;
  final int? importedQuantity;
  final int? requestQuantity;
  final int? exportQuantity;
  final int? exportedQuantity;

  WarehouseTicketSupplyDTO({
    this.exportedQuantity,
    this.exportQuantity,
    this.color,
    this.size,
    this.importQuantity,
    this.importedQuantity,
    this.requestQuantity,
    num? price,
    String? id,
    String? name,
    String? code,
    String? nameOther,
    int? quantity,
    int? availableStockQuantity,
    int? availableQuantity,
    int? providedQuantity,
    SupplyTypeDTO? supplyType,
    num? estimateUsedTime,
    UnitDTO? unit,
    MaintainType? maintenanceType,
    SupplyGroupDTO? supplyGroup,
    int? stockQuantity,
    int? minStockQuantity,
  }) : super(
          id: id,
          name: name,
          code: code,
          nameOther: nameOther,
          quantity: quantity,
          availableStockQuantity: availableStockQuantity,
          availableQuantity: availableQuantity,
          providedQuantity: providedQuantity,
          supplyType: supplyType,
          estimateUsedTime: estimateUsedTime,
          unit: unit,
          maintenanceType: maintenanceType,
          supplyGroup: supplyGroup,
          stockQuantity: stockQuantity,
          minStockQuantity: minStockQuantity,
          price: price,
        );

  factory WarehouseTicketSupplyDTO.fromJson(Map<String, dynamic> json) =>
      _$WarehouseTicketSupplyDTOFromJson(json);

  @override
  Map<String, dynamic> toJson() => _$WarehouseTicketSupplyDTOToJson(this);
}
