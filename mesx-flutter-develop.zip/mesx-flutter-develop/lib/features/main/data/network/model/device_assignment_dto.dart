import 'package:json_annotation/json_annotation.dart';

import 'area_info_dto.dart';
import 'device_detail_dto.dart';
import 'device_group_dto.dart';
import 'factory_info_dto.dart';
import 'unit_dto.dart';

part 'device_assignment_dto.g.dart';

@JsonSerializable(explicitToJson: true)
class DeviceAssignmentDTO {
  final String? id;
  final String? name;
  final String? code;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final FactoryInfoDTO? factory;
  final List<DeviceDetailDTO>? devices;
  final List<DeviceAssignmentDetailDTO>? details;

  DeviceAssignmentDTO({
    this.id,
    this.name,
    this.code,
    this.createdAt,
    this.updatedAt,
    this.factory,
    this.devices = const [],
    this.details,
  });

  factory DeviceAssignmentDTO.fromJson(Map<String, dynamic> json) =>
      _$DeviceAssignmentDTOFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceAssignmentDTOToJson(this);
}

@JsonSerializable(explicitToJson: true)
class DeviceAssignmentDetailDTO {
  final AreaInfoDTO? area;
  final DeviceDetailDTO? device;
  final DeviceGroupDTO? deviceGroup;
  final UnitDTO? unit;

  DeviceAssignmentDetailDTO({
    this.area,
    this.device,
    this.deviceGroup,
    this.unit,
  });

  factory DeviceAssignmentDetailDTO.fromJson(Map<String, dynamic> json) =>
      _$DeviceAssignmentDetailDTOFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceAssignmentDetailDTOToJson(this);
}
