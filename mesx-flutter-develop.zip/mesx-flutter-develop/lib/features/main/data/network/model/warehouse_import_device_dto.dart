import 'package:json_annotation/json_annotation.dart';
import 'area_info_dto.dart';
import 'device_detail_dto.dart';
import 'device_group_dto.dart';
import 'unit_dto.dart';
import 'vendor_dto.dart';

part 'warehouse_import_device_dto.g.dart';

@JsonSerializable()
class WarehouseImportDeviceDTO {
  final DeviceDetailDTO? device;
  final String? templateNum;
  final UnitDTO? unit;
  final VendorDTO? vendor;
  final AreaInfoDTO? importArea;
  final num? quantity;
  final DeviceGroupDTO? deviceGroup;
  final num? price;
  final String? size;
  final String? color;
  final num? grantedQuantity;
  final num? returnQuantity;

  WarehouseImportDeviceDTO({
    this.device,
    this.templateNum,
    this.unit,
    this.vendor,
    this.importArea,
    this.quantity,
    this.deviceGroup,
    this.price,
    this.size,
    this.color,
    this.grantedQuantity,
    this.returnQuantity,
  });

  factory WarehouseImportDeviceDTO.fromJson(Map<String, dynamic> json) =>
      _$WarehouseImportDeviceDTOFromJson(json);

  Map<String, dynamic> toJson() => _$WarehouseImportDeviceDTOToJson(this);
}
