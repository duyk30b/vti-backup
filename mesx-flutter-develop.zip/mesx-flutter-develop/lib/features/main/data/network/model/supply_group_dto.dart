import 'package:json_annotation/json_annotation.dart';

part 'supply_group_dto.g.dart';

@JsonSerializable()
class SupplyGroupDTO {
  final String? id;
  final String? name;
  final String? code;

  SupplyGroupDTO({
    this.id,
    this.name,
    this.code,
  });

  factory SupplyGroupDTO.fromJson(Map<String, dynamic> json) =>
      _$SupplyGroupDTOFromJson(json);

  Map<String, dynamic> toJson() => _$SupplyGroupDTOToJson(this);
}
