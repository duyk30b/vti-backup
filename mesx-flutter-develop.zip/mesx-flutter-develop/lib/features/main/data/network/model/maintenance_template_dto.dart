import 'package:json_annotation/json_annotation.dart';

import 'maintenance_template_detail_dto.dart';

part 'maintenance_template_dto.g.dart';

@JsonSerializable()
class MaintenanceTemplateDTO {
  final String? id;
  final String? name;
  final String? code;
  final int? active;
  final String? description;
  final DateTime? createdAt;
  final List<MaintenanceTemplateDetailDTO>? details;
  final bool? isLeader;

  MaintenanceTemplateDTO(
      {this.id,
      this.name,
      this.code,
      this.active,
      this.description,
      this.createdAt,
      this.details,
      this.isLeader});

  factory MaintenanceTemplateDTO.fromJson(Map<String, dynamic> json) =>
      _$MaintenanceTemplateDTOFromJson(json);

  Map<String, dynamic> toJson() => _$MaintenanceTemplateDTOToJson(this);
}
