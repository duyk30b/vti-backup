import 'package:json_annotation/json_annotation.dart';

part 'warning_dto.g.dart';

@JsonSerializable()
class WarningDto {
  String? id;
  String? createdAt;
  String? updatedAt;
  String? name;
  String? code;

  WarningDto({this.id, this.createdAt, this.updatedAt, this.name, this.code});

  factory WarningDto.fromJson(Map<String, dynamic> json) =>
      _$WarningDtoFromJson(json);

  Map<String, dynamic> toJson() => _$WarningDtoToJson(this);
}
