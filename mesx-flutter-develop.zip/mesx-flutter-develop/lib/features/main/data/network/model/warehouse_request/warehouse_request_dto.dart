import 'package:json_annotation/json_annotation.dart';

import '../../../../domain/enum/warehouse_request_enum.dart';
import '../device_detail_dto.dart';
import '../warehouse_dto.dart';
import 'warehouse_request_device_group_dto.dart';
import 'warehouse_request_supply_dto.dart';

part 'warehouse_request_dto.g.dart';

@JsonSerializable()
class WarehouseRequestDTO {
  final String? id;
  final String? code;
  final String? name;

  final List<WarehouseRequestDeviceGroupDTO> deviceGroups;
  final List<WarehouseRequestSupplyDTO> supplies;
  final List<DeviceDetailDTO> devices;
  final WarehouseRequestStatus? status;
  final WarehouseDTO? warehouse;

  WarehouseRequestDTO({
    this.id,
    this.name,
    this.code,
    this.deviceGroups = const [],
    this.supplies = const [],
    this.devices = const [],
    this.status,
    this.warehouse,
  });

  factory WarehouseRequestDTO.fromJson(Map<String, dynamic> json) =>
      _$WarehouseRequestDTOFromJson(json);

  Map<String, dynamic> toJson() => _$WarehouseRequestDTOToJson(this);
}
