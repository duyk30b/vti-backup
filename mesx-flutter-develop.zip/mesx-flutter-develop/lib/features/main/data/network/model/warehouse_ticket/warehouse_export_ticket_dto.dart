import 'package:json_annotation/json_annotation.dart';
import '../../../../domain/enum/warehouse_ticket_enum.dart';
import '../factory_info_dto.dart';
import '../warehouse_dto.dart';
import '../warehouse_request/warehouse_export_request_dto.dart';
import 'warehouse_ticket_device_dto.dart';
import 'warehouse_ticket_dto.dart';
import 'warehouse_ticket_supply_dto.dart';

part 'warehouse_export_ticket_dto.g.dart';

@JsonSerializable()
class WarehouseExportTicketDTO extends WarehouseTicketDTO {
  final FactoryInfoDTO? toFactory;
  final FactoryInfoDTO? fromFactory;
  final DateTime? exportDate;
  final WarehouseExportRequestDTO? warehouseExportRequest;
  final WarehouseExportTicketRequestType? requestType;

  WarehouseExportTicketDTO({
    this.fromFactory,
    this.exportDate,
    this.toFactory,
    this.warehouseExportRequest,
    this.requestType,
    String? id,
    String? name,
    String? code,
    DateTime? date,
    String? note,
    String? deliver,
    String? number,
    String? soNum,
    String? poNum,
    String? remain,
    String? contractNum,
    String? debit,
    String? symbol,
    WarehouseDTO? warehouse,
    String? templateNum,
    String? gdiNo,
    String? reason,
    String? credit,
    WarehouseTicketTypeEnum? ticketType,
    WarehouseTicketStatus? status,
    List<WarehouseTicketDeviceDTO>? devices,
    List<WarehouseTicketSupplyDTO>? supplies,
  }) : super(
          id: id,
          name: name,
          code: code,
          date: date,
          note: note,
          deliver: deliver,
          number: number,
          soNum: soNum,
          poNum: poNum,
          remain: remain,
          contractNum: contractNum,
          debit: debit,
          symbol: symbol,
          warehouse: warehouse,
          templateNum: templateNum,
          ticketType: ticketType,
          status: status,
          devices: devices,
          supplies: supplies,
          gdiNo: gdiNo,
          credit: credit,
          reason: reason,
        );

  factory WarehouseExportTicketDTO.fromJson(Map<String, dynamic> json) =>
      _$WarehouseExportTicketDTOFromJson(json);

  @override
  Map<String, dynamic> toJson() => _$WarehouseExportTicketDTOToJson(this);
}
