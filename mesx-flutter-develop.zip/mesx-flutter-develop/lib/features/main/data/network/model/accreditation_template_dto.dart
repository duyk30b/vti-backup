import 'package:json_annotation/json_annotation.dart';

import 'accreditation_template_detail_dto.dart';

part 'accreditation_template_dto.g.dart';

@JsonSerializable()
class AccreditationTemplateDTO {
  final String? id;
  final String? name;
  final String? code;
  final int? active;
  final String? description;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final List<AccreditationTemplateDetailDTO>? details;

  AccreditationTemplateDTO({
    this.id,
    this.name,
    this.code,
    this.active,
    this.description,
    this.createdAt,
    this.updatedAt,
    this.details,
  });

  factory AccreditationTemplateDTO.fromJson(Map<String, dynamic> json) =>
      _$AccreditationTemplateDTOFromJson(json);

  Map<String, dynamic> toJson() => _$AccreditationTemplateDTOToJson(this);
}
