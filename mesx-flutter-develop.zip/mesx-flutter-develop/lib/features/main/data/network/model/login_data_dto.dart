import 'package:json_annotation/json_annotation.dart';

import 'access_token_dto.dart';
import 'user_info_dto.dart';

part 'login_data_dto.g.dart';

@JsonSerializable(explicitToJson: true)
class LoginDataDTO {
  final UserInfoDTO userInfo;
  final AccessToken accessToken;
  final AccessToken refreshToken;

  LoginDataDTO(this.userInfo, this.accessToken, this.refreshToken);

  factory LoginDataDTO.fromJson(Map<String, dynamic> json) =>
      _$LoginDataDTOFromJson(json);

  Map<String, dynamic> toJson() => _$LoginDataDTOToJson(this);
}
