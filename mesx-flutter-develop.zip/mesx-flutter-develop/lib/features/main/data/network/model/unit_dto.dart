import 'package:json_annotation/json_annotation.dart';

part 'unit_dto.g.dart';

@JsonSerializable()
class UnitDTO {
  final String? code;
  final String? name;
  final int? active;

  UnitDTO({this.code, this.name, this.active});

  factory UnitDTO.fromJson(Map<String, dynamic> json) =>
      _$UnitDTOFromJson(json);

  Map<String, dynamic> toJson() => _$UnitDTOToJson(this);
}
