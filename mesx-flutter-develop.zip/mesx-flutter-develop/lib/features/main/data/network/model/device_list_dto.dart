import 'package:json_annotation/json_annotation.dart';

part 'device_list_dto.g.dart';

@JsonSerializable(explicitToJson: true)
class DeviceListDTO {
  final String id;
  final String code;
  final String name;
  final String? serial;
  final String? identificationNo;
  final int? status;
  final String createdAt;
  final String updatedAt;

  DeviceListDTO(
    this.id,
    this.code,
    this.name,
    this.serial,
    this.identificationNo,
    this.status,
    this.createdAt,
    this.updatedAt,
  );

  factory DeviceListDTO.fromJson(Map<String, dynamic> json) =>
      _$DeviceListDTOFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceListDTOToJson(this);
}
