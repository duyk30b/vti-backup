import 'package:json_annotation/json_annotation.dart';
import '../../../../domain/enum/warehouse_ticket_enum.dart';
import '../factory_info_dto.dart';
import '../warehouse_dto.dart';
import '../warehouse_request/warehouse_import_request_dto.dart';
import 'warehouse_ticket_device_dto.dart';
import 'warehouse_ticket_dto.dart';
import 'warehouse_ticket_supply_dto.dart';

part 'warehouse_import_ticket_dto.g.dart';

@JsonSerializable()
class WarehouseImportTicketDTO extends WarehouseTicketDTO {
  final FactoryInfoDTO? fromFactory;
  final FactoryInfoDTO? toFactory;

  final DateTime? importDate;
  final WarehouseImportTicketRequestType? requestType;
  final WarehouseImportRequestDTO? warehouseImportRequest;

  WarehouseImportTicketDTO({
    this.toFactory,
    this.importDate,
    this.fromFactory,
    this.requestType,
    this.warehouseImportRequest,
    String? id,
    String? name,
    String? code,
    DateTime? date,
    String? note,
    String? deliver,
    String? number,
    String? soNum,
    String? poNum,
    String? remain,
    String? contractNum,
    String? debit,
    String? symbol,
    String? gdiNo,
    String? reason,
    WarehouseDTO? warehouse,
    String? templateNum,
    WarehouseTicketTypeEnum? ticketType,
    WarehouseTicketStatus? status,
    List<WarehouseTicketDeviceDTO>? devices,
    List<WarehouseTicketSupplyDTO>? supplies,
  }) : super(
          id: id,
          name: name,
          code: code,
          date: date,
          note: note,
          deliver: deliver,
          number: number,
          soNum: soNum,
          poNum: poNum,
          remain: remain,
          contractNum: contractNum,
          debit: debit,
          symbol: symbol,
          warehouse: warehouse,
          templateNum: templateNum,
          ticketType: ticketType,
          status: status,
          devices: devices,
          supplies: supplies,
          gdiNo: gdiNo,
          reason: reason,
        );

  factory WarehouseImportTicketDTO.fromJson(Map<String, dynamic> json) =>
      _$WarehouseImportTicketDTOFromJson(json);

  @override
  Map<String, dynamic> toJson() => _$WarehouseImportTicketDTOToJson(this);
}
