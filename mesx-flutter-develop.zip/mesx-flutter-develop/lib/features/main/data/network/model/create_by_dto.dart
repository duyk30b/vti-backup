import 'package:json_annotation/json_annotation.dart';

part 'create_by_dto.g.dart';

@JsonSerializable()
class CreateByDTO {
  final int? id;
  final String? fullName;
  final String? userName;
  @JsonKey(name: 'username')
  final String? name;

  CreateByDTO(this.id, this.fullName, this.userName, this.name);

  factory CreateByDTO.fromJson(Map<String, dynamic> json) =>
      _$CreateByDTOFromJson(json);

  Map<String, dynamic> toJson() => _$CreateByDTOToJson(this);
}
