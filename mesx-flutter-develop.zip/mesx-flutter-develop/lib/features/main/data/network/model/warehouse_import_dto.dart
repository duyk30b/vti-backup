import 'package:json_annotation/json_annotation.dart';

import '../../../domain/enum/warehouse_import_enum.dart';
import 'device_assignment_dto.dart';
import 'factory_info_dto.dart';
import 'supply_request_dto.dart';
import 'warehouse_dto.dart';
import 'warehouse_import_device_dto.dart';
import 'warehouse_import_supply_dto.dart';

part 'warehouse_import_dto.g.dart';

@JsonSerializable()
class WarehouseImportDTO {
  final String? id;
  final String? code;
  final String? name;
  final DateTime? importDate;
  final WarehouseImportStatus? status;
  final DateTime? date;
  final String? note;
  final String? deliver;
  final String? number;
  final String? soNum;
  final String? poNum;
  final String? remain;
  final WarehouseImportType? requestType;
  final FactoryInfoDTO? fromFactory;
  final String? contractNum;
  final String? debit;
  final List<WarehouseImportDeviceDTO>? devices;
  final List<WarehouseImportSupplyDTO>? supplies;
  final String? symbol;
  final DeviceAssignmentDTO? deviceAssignmentRequest;
  final SupplyRequestDTO? supplyRequest;

  final WarehouseDTO? warehouse;
  final String? templateNum;

  WarehouseImportDTO({
    this.deviceAssignmentRequest,
    this.supplyRequest,
    this.id,
    this.name,
    this.code,
    this.importDate,
    this.status,
    this.date,
    this.note,
    this.deliver,
    this.number,
    this.soNum,
    this.poNum,
    this.remain,
    this.requestType,
    this.fromFactory,
    this.contractNum,
    this.debit,
    this.devices,
    this.supplies,
    this.symbol,
    this.warehouse,
    this.templateNum,
  });

  factory WarehouseImportDTO.fromJson(Map<String, dynamic> json) {
    final Map<String, dynamic> convertJson = {
      ...json,
      'deviceAssignmentRequest':
          json['requestType'] == WarehouseImportType.deviceAssign.type
              ? json['request']
              : null,
      'supplyRequest':
          json['requestType'] == WarehouseImportType.returnSupply.type
              ? json['request']
              : null,
    };
    return _$WarehouseImportDTOFromJson(convertJson);
  }

  Map<String, dynamic> toJson() => _$WarehouseImportDTOToJson(this);
}
