import 'package:json_annotation/json_annotation.dart';

import 'assets_type_display_dto.dart';
import 'factory_info_dto.dart';
import 'unit_dto.dart';
import 'warehouse_dto.dart';

part 'inventory_dto.g.dart';

@JsonSerializable()
class InventoryDTO {
  String? id;
  String? assetId;
  String? assetName;
  String? assetCode;
  String? assetNameOther;
  int? stockQuantity;
  WarehouseDTO? warehouse;
  AssetTypeDisplayDTO? assetTypeDisplay;
  UnitDTO? unit;
  FactoryInfoDTO? factory;

  InventoryDTO(
      {this.id,
      this.assetId,
      this.assetName,
      this.assetCode,
      this.stockQuantity,
      this.warehouse,
      this.unit,
      this.factory,
      this.assetNameOther,
      this.assetTypeDisplay});

  factory InventoryDTO.fromJson(Map<String, dynamic> json) =>
      _$InventoryDTOFromJson(json);

  Map<String, dynamic> toJson() => _$InventoryDTOToJson(this);
}
