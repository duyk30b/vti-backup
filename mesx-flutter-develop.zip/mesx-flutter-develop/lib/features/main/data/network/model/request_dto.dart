import 'package:json_annotation/json_annotation.dart';

import 'warehouse_dto.dart';

part 'request_dto.g.dart';

@JsonSerializable(explicitToJson: true)
class RequestDTO {
  final String? code;
  final String? name;
  final WarehouseDTO? exportWarehouse;
  final WarehouseDTO? warehouse;

  RequestDTO({
    this.code,
    this.name,
    this.exportWarehouse,
    this.warehouse,
  });

  factory RequestDTO.fromJson(Map<String, dynamic> json) =>
      _$RequestDTOFromJson(json);

  Map<String, dynamic> toJson() => _$RequestDTOToJson(this);
}
