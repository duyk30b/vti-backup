import 'package:json_annotation/json_annotation.dart';

part 'detail.g.dart';

@JsonSerializable()
class DetailDTO {
  String? id;
  String? title;
  String? description;
  int? obligatory;
  int? status;

  DetailDTO(
      {this.id, this.title, this.description, this.obligatory, this.status});

  factory DetailDTO.fromJson(Map<String, dynamic> json) =>
      _$DetailDTOFromJson(json);

  Map<String, dynamic> toJson() => _$DetailDTOToJson(this);
}
