import 'package:json_annotation/json_annotation.dart';
import '../../../../domain/enum/warehouse_request_enum.dart';
import '../../../../domain/enum/warehouse_ticket_enum.dart';
import '../device_detail_dto.dart';
import '../device_request_dto.dart';
import '../factory_info_dto.dart';
import '../supply_request_dto.dart';
import '../transfer_ticket_dto.dart';
import '../warehouse_dto.dart';
import 'warehouse_request_device_group_dto.dart';
import 'warehouse_request_dto.dart';
import 'warehouse_request_supply_dto.dart';

part 'warehouse_export_request_dto.g.dart';

@JsonSerializable()
class WarehouseExportRequestDTO extends WarehouseRequestDTO {
  final String? description;
  final FactoryInfoDTO? fromFactory;
  final FactoryInfoDTO? toFactory;
  final DateTime? exportDate;

  final String? requestCode;
  final DeviceRequestDTO? deviceRequest;
  final SupplyRequestDTO? supplyRequest;
  final TransferTicketDTO? transferTicket;
  final WarehouseExportTicketRequestType? requestType;

  WarehouseExportRequestDTO({
    this.description,
    this.fromFactory,
    this.exportDate,
    this.toFactory,
    this.requestCode,
    this.deviceRequest,
    this.supplyRequest,
    this.transferTicket,
    this.requestType,
    String? id,
    String? code,
    String? name,
    List<WarehouseRequestSupplyDTO> supplies = const [],
    List<WarehouseRequestDeviceGroupDTO> deviceGroups = const [],
    List<DeviceDetailDTO> devices = const [],
    WarehouseDTO? warehouse,
    WarehouseRequestStatus? status,
  }) : super(
          code: code,
          id: id,
          name: name,
          deviceGroups: deviceGroups,
          supplies: supplies,
          devices: devices,
          warehouse: warehouse,
          status: status,
        );

  factory WarehouseExportRequestDTO.fromJson(Map<String, dynamic> json) {
    final Map<String, dynamic> convertJson = {
      ...json,
      'deviceRequest': json['requestType'] ==
              WarehouseExportTicketRequestType.returnDevice.type
          ? json['request']
          : null,
      'supplyRequest': json['requestType'] ==
              WarehouseExportTicketRequestType.requestSupply.type
          ? json['request']
          : null,
      'transferTicket': json['requestType'] ==
              WarehouseExportTicketRequestType.transferDevice.type
          ? json['request']
          : null,
    };

    return _$WarehouseExportRequestDTOFromJson(convertJson);
  }
  @override
  Map<String, dynamic> toJson() => _$WarehouseExportRequestDTOToJson(this);
}
