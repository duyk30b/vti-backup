import 'package:json_annotation/json_annotation.dart';
import '../../../../../core/utils/json_converter.dart';

part 'maintenance_index_dto.g.dart';

@JsonSerializable(converters: [
  DateTimeConverter(),
])
class MaintenanceIndexDTO {
  final DateTime? accreditationDateLatest;
  final DateTime? accreditationDateNext;
  final DateTime? maintenanceDateLatest;
  final DateTime? maintenanceDateNext;
  final num? mtbf;
  final num? mttr;
  final num? mtta;
  final num? mttf;

  MaintenanceIndexDTO({
    this.accreditationDateLatest,
    this.accreditationDateNext,
    this.maintenanceDateLatest,
    this.maintenanceDateNext,
    this.mtbf,
    this.mttr,
    this.mtta,
    this.mttf,
  });

  factory MaintenanceIndexDTO.fromJson(Map<String, dynamic> json) =>
      _$MaintenanceIndexDTOFromJson(json);

  Map<String, dynamic> toJson() => _$MaintenanceIndexDTOToJson(this);
}
