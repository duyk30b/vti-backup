import 'package:json_annotation/json_annotation.dart';

import '../../../domain/enum/priority_enum.dart';
import 'detail.dart';

part 'job_type_template_dto.g.dart';

@JsonSerializable(explicitToJson: true)
class JobTypeTemplateDTO {
  String? id;
  String? createdAt;
  String? updatedAt;
  String? code;
  String? name;
  String? description;
  int? active;
  Priority? priority;
  List<DetailDTO>? details;

  JobTypeTemplateDTO(
      {this.id,
      this.createdAt,
      this.updatedAt,
      this.code,
      this.name,
      this.description,
      this.active,
      this.details,
      this.priority});

  factory JobTypeTemplateDTO.fromJson(Map<String, dynamic> json) =>
      _$JobTypeTemplateDTOFromJson(json);

  Map<String, dynamic> toJson() => _$JobTypeTemplateDTOToJson(this);
}
