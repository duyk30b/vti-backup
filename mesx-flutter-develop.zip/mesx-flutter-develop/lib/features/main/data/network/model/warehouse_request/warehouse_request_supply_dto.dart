import 'package:json_annotation/json_annotation.dart';

import '../../../../domain/enum/maintain_enum.dart';
import '../supply_dto.dart';
import '../supply_group_dto.dart';
import '../supply_type_dto.dart';
import '../unit_dto.dart';
import '../vendor_dto.dart';

part 'warehouse_request_supply_dto.g.dart';

@JsonSerializable()
class WarehouseRequestSupplyDTO extends SupplyDTO {
  final String? color;
  final String? size;
  final int? grantedQuantity;
  final int? returnQuantity;
  final int? requestQuantity;
  final int? importedQuantity;
  final int? importQuantity;

  final int? exportQuantity;
  final int? exportedQuantity;

  WarehouseRequestSupplyDTO({
    this.exportQuantity,
    this.exportedQuantity,
    this.importQuantity,
    this.importedQuantity,
    this.requestQuantity,
    this.color,
    this.size,
    this.grantedQuantity,
    this.returnQuantity,
    num? price,
    String? id,
    String? name,
    String? code,
    String? nameOther,
    int? quantity,
    int? availableStockQuantity,
    int? availableQuantity,
    int? providedQuantity,
    SupplyTypeDTO? supplyType,
    num? estimateUsedTime,
    UnitDTO? unit,
    MaintainType? maintenanceType,
    SupplyGroupDTO? supplyGroup,
    int? stockQuantity,
    int? minStockQuantity,
    VendorDTO? vendor,
    super.importPlannedQuantity,
    super.exportPlannedQuantity,
  }) : super(
          id: id,
          name: name,
          code: code,
          nameOther: nameOther,
          quantity: quantity,
          availableStockQuantity: availableStockQuantity,
          availableQuantity: availableQuantity,
          providedQuantity: providedQuantity,
          supplyType: supplyType,
          estimateUsedTime: estimateUsedTime,
          unit: unit,
          maintenanceType: maintenanceType,
          supplyGroup: supplyGroup,
          stockQuantity: stockQuantity,
          minStockQuantity: minStockQuantity,
          price: price,
          vendor: vendor,
        );

  factory WarehouseRequestSupplyDTO.fromJson(Map<String, dynamic> json) =>
      _$WarehouseRequestSupplyDTOFromJson(json);

  @override
  Map<String, dynamic> toJson() => _$WarehouseRequestSupplyDTOToJson(this);
}
