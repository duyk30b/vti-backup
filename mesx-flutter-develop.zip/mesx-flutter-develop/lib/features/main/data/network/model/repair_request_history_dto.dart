import 'package:json_annotation/json_annotation.dart';

part 'repair_request_history_dto.g.dart';

@JsonSerializable()
class RepairRequestHistoryDTO {
  final String? id;
  final String? content;
  final dynamic action;
  final int? status;
  final DateTime? createdAt;
  final String? reason;

  RepairRequestHistoryDTO(
      {this.id,
      this.content,
      this.action,
      this.status,
      this.createdAt,
      this.reason});

  factory RepairRequestHistoryDTO.fromJson(Map<String, dynamic> json) =>
      _$RepairRequestHistoryDTOFromJson(json);

  Map<String, dynamic> toJson() => _$RepairRequestHistoryDTOToJson(this);
}
