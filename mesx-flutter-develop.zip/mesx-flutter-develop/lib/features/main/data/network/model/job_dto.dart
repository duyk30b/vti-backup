import 'package:json_annotation/json_annotation.dart';

import '../../../domain/enum/job_enum.dart';
import 'assign_dto.dart';
import 'device_detail_dto.dart';
import 'job_type_template_dto.dart';
import 'repair_request_history_dto.dart';
import 'result.dart';
import 'supply_dto.dart';
import 'warning_dto.dart';

part 'job_dto.g.dart';

@JsonSerializable()
class JobDTO {
  final String? id;
  final String? name;
  final String? code;
  final JobTypeEnum? type;
  final String? description;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final DeviceDetailDTO? device;
  final DateTime? planFrom;
  final DateTime? planTo;
  final DateTime? executionDateFrom;
  final DateTime? executionDateTo;
  final int? status;
  final AssignDTO? assign;
  final JobTypeTemplateDTO? jobTypeTemplate;
  final ResultDTO? result;
  final List<RepairRequestHistoryDTO>? histories;
  final int? executionTime;
  final int? stopTime;
  final bool? isOverdue;
  final JobStatus? jobStatus;
  final List<SupplyDTO>? supplies;
  final WarningDto? warning;
  final String? imageUrl;
  final String? fileName;
  final bool? canUpdateJobTime;

  JobDTO(
      {this.id,
      this.name,
      this.code,
      this.type,
      this.createdAt,
      this.device,
      this.planFrom,
      this.planTo,
      this.status,
      this.assign,
      this.description,
      this.jobTypeTemplate,
      this.result,
      this.histories,
      this.executionTime,
      this.executionDateTo,
      this.executionDateFrom,
      this.isOverdue,
      this.jobStatus,
      this.stopTime,
      this.supplies,
      this.warning,
      this.imageUrl,
      this.fileName,
      this.canUpdateJobTime,
      this.updatedAt});

  factory JobDTO.fromJson(Map<String, dynamic> json) => _$JobDTOFromJson(json);

  Map<String, dynamic> toJson() => _$JobDTOToJson(this);
}
