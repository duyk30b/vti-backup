import 'package:json_annotation/json_annotation.dart';

import 'notification_id_dto.dart';

part 'notification_item_dto.g.dart';

@JsonSerializable(explicitToJson: true)
class NotificationItemDTO {
  @JsonKey(name: '_id')
  final String sId;
  final int userId;
  final NotificationIdDTO notificationId;
  final int status;
  String? readAt;
  final String title;
  final String content;
  final String type;
  final String createdAt;
  final String updatedAt;
  @JsonKey(name: '__v')
  final int iV;

  NotificationItemDTO(
      this.sId,
      this.userId,
      this.notificationId,
      this.status,
      this.readAt,
      this.title,
      this.content,
      this.type,
      this.createdAt,
      this.updatedAt,
      this.iV);

  factory NotificationItemDTO.fromJson(Map<String, dynamic> json) =>
      _$NotificationItemDTOFromJson(json);

  Map<String, dynamic> toJson() => _$NotificationItemDTOToJson(this);
}
