import 'package:json_annotation/json_annotation.dart';

import '../../../domain/enum/maintain_enum.dart';
import 'supply_group_dto.dart';
import 'supply_type_dto.dart';
import 'unit_dto.dart';
import 'vendor_dto.dart';

part 'supply_dto.g.dart';

@JsonSerializable()
class SupplyDTO {
  final String? id;
  @JsonKey(name: 'assetId')
  final String? assetId;
  final String? name;
  final String? code;
  final String? nameOther;
  final int? quantity;
  final int? availableStockQuantity;
  @JsonKey(name: 'availableQuantity')
  final int? availableQuantity;
  final int? providedQuantity;
  final int? maxStockQuantity;
  final int? minStockQuantity;
  final int? stockQuantity;
  final int? importPlannedQuantity;
  final int? exportPlannedQuantity;
  final SupplyTypeDTO? supplyType;
  final num? estimateUsedTime;
  final num? price;
  final UnitDTO? unit;
  final MaintainType? maintenanceType;
  final SupplyGroupDTO? supplyGroup;
  final VendorDTO? vendor;

  SupplyDTO({
    this.id,
    this.assetId,
    this.availableQuantity,
    this.maxStockQuantity,
    this.minStockQuantity,
    this.stockQuantity,
    this.providedQuantity,
    this.name,
    this.code,
    this.nameOther,
    this.quantity,
    this.availableStockQuantity,
    this.supplyType,
    this.estimateUsedTime,
    this.unit,
    this.maintenanceType,
    this.supplyGroup,
    this.vendor,
    this.price,
    this.importPlannedQuantity,
    this.exportPlannedQuantity,
  });

  factory SupplyDTO.fromJson(Map<String, dynamic> json) {
    if (json['quantity'] is double) json['quantity'] = json['quantity'].toInt();
    return _$SupplyDTOFromJson(json);
  }

  Map<String, dynamic> toJson() => _$SupplyDTOToJson(this);
}
