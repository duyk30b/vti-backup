import 'package:json_annotation/json_annotation.dart';

part 'article_device_group_dto.g.dart';

@JsonSerializable()
class ArticleDeviceGroupDTO {
  final String? code;
  final String? name;
  final String? id;

  ArticleDeviceGroupDTO({
    this.code,
    this.name,
    this.id,
  });

  factory ArticleDeviceGroupDTO.fromJson(Map<String, dynamic> json) =>
      _$ArticleDeviceGroupDTOFromJson(json);

  Map<String, dynamic> toJson() => _$ArticleDeviceGroupDTOToJson(this);
}
