import 'package:json_annotation/json_annotation.dart';

import 'area_info_dto.dart';
import 'device_detail_dto.dart';
import 'device_group_dto.dart';
import 'unit_dto.dart';

part 'warehouse_export_device_dto.g.dart';

@JsonSerializable()
class WarehouseExportDeviceDTO {
  final DeviceDetailDTO? device;
  final UnitDTO? unit;
  final AreaInfoDTO? area;
  final DeviceGroupDTO? deviceGroup;
  final String? size;
  final String? color;
  final int? quantity;

  WarehouseExportDeviceDTO({
    this.device,
    this.unit,
    this.area,
    this.deviceGroup,
    this.size,
    this.color,
    this.quantity,
  });

  factory WarehouseExportDeviceDTO.fromJson(Map<String, dynamic> json) =>
      _$WarehouseExportDeviceDTOFromJson(json);

  Map<String, dynamic> toJson() => _$WarehouseExportDeviceDTOToJson(this);
}
