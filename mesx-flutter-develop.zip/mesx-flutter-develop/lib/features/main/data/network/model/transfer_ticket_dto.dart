import 'package:json_annotation/json_annotation.dart';

import '../../../domain/enum/transfer_ticket_enum.dart';
import 'area_info_dto.dart';
import 'device_detail_dto.dart';
import 'device_group_dto.dart';
import 'factory_info_dto.dart';
import 'unit_dto.dart';
import 'warehouse_dto.dart';

part 'transfer_ticket_dto.g.dart';

@JsonSerializable()
class TransferTicketDTO {
  final String? id;
  final String? code;
  final String? name;
  final DateTime? estimatedReturnDate;
  final FactoryInfoDTO? fromFactory;
  final FactoryInfoDTO? toFactory;
  final DateTime? transferDate;
  final TransferTicketStatus? status;
  final TransferTicketType? type;
  final List<TransferTicketDeviceDTO>? devices;
  TransferTicketDTO({
    this.id,
    this.code,
    this.name,
    this.estimatedReturnDate,
    this.fromFactory,
    this.toFactory,
    this.transferDate,
    this.status,
    this.type,
    this.devices,
  });

  factory TransferTicketDTO.fromJson(Map<String, dynamic> json) =>
      _$TransferTicketDTOFromJson(json);

  Map<String, dynamic> toJson() => _$TransferTicketDTOToJson(this);
}

@JsonSerializable()
class TransferTicketDeviceDTO {
  final AreaInfoDTO? area;
  final DeviceDetailDTO? device;
  final DeviceGroupDTO? deviceGroup;
  final UnitDTO? unit;
  final WarehouseDTO? warehouse;
  final int? exportPlanned;
  final int? exported;
  final int? importPlanned;
  final int? returnPlanned;

  TransferTicketDeviceDTO({
    this.area,
    this.device,
    this.deviceGroup,
    this.unit,
    this.warehouse,
    this.exportPlanned,
    this.exported,
    this.importPlanned,
    this.returnPlanned,
  });

  factory TransferTicketDeviceDTO.fromJson(Map<String, dynamic> json) =>
      _$TransferTicketDeviceDTOFromJson(json);

  Map<String, dynamic> toJson() => _$TransferTicketDeviceDTOToJson(this);
}
