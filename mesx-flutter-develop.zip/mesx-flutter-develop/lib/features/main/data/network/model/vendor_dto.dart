import 'package:json_annotation/json_annotation.dart';

part 'vendor_dto.g.dart';

@JsonSerializable()
class VendorDTO {
  final String id;
  final String name;
  final String code;

  VendorDTO(this.id, this.name, this.code);

  factory VendorDTO.fromJson(Map<String, dynamic> json) =>
      _$VendorDTOFromJson(json);

  Map<String, dynamic> toJson() => _$VendorDTOToJson(this);
}
