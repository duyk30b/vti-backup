import 'package:json_annotation/json_annotation.dart';

import '../../../domain/enum/device_request_enum.dart';
import 'device_detail_dto.dart';
import 'factory_info_dto.dart';

part 'device_request_dto.g.dart';

@JsonSerializable(explicitToJson: true)
class DeviceRequestDTO {
  final String? id;
  final String? code;
  final String? name;
  final String? description;
  final FactoryInfoDTO? factory;
  final FactoryInfoDTO? toFactory;
  final FactoryInfoDTO? fromFactory;
  final DateTime? expectReturnDate;
  final DeviceRequestType? type;
  final DeviceRequestStatus? status;
  final List<DeviceDetailDTO> devices;

  DeviceRequestDTO({
    this.id,
    this.code,
    this.name,
    this.description,
    this.factory,
    this.expectReturnDate,
    this.type,
    this.status,
    this.devices = const [],
    this.fromFactory,
    this.toFactory,
  });

  factory DeviceRequestDTO.fromJson(Map<String, dynamic> json) =>
      _$DeviceRequestDTOFromJson(json);

  Map<String, dynamic> toJson() => _$DeviceRequestDTOToJson(this);
}
