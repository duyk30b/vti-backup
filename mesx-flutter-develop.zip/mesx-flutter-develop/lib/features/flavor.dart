enum Flavor { uat, stg, prod }

class AppConfig {
  String appName = '';
  String baseUrl = '';
  Flavor flavor = Flavor.stg;

  static AppConfig shared = AppConfig.create();

  AppConfig(this.appName, this.baseUrl, this.flavor);

  factory AppConfig.create({
    String appName = '',
    String baseUrl = '',
    Flavor flavor = Flavor.stg,
  }) {
    return shared = AppConfig(appName, baseUrl, flavor);
  }
}
