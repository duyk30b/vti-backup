import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import '../core/core.dart';
import '../core/navigation/navigator_helper.dart';
import '../generated/l10n.dart';
import 'main/data/cache/cache_manager.dart';
import 'main/domain/usecase/get_me_usecase.dart';
import 'main/presentation/di/app_injector_widget.dart';
import 'main/presentation/ui/setting/setting.dart';
import 'routes.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  Iterable<Locale> _provideSupportedLocales() => BS.delegate.supportedLocales;

  Iterable<LocalizationsDelegate<dynamic>>? _provideLocalizationsDelegates() =>
      const [
        BS.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ];

  @override
  Widget build(BuildContext context) {
    return AppInjector(
      child: GestureDetector(
        onTap: () {
          WidgetsBinding.instance.focusManager.primaryFocus?.unfocus();
        },
        child: MultiBlocProvider(
          providers: [
            BlocProvider(create: (context) {
              /// load from local to set init Theme
              /// if local Theme == null return Default Theme
              final CacheManager cacheManager = context.read<CacheManager>();
              final GetMeUseCase usecase = context.read<GetMeUseCase>();

              return SettingCubit(cacheManager, usecase);
            }),
          ],
          child: BlocBuilder<SettingCubit, StateWrapper<SettingState>>(
            builder: (settingContext, settingState) {
              return RefreshConfiguration(
                hideFooterWhenNotFull: false,
                shouldFooterFollowWhenNotFull: (_) => true,
                child: MaterialApp(
                  title: 'Mesx',
                  color: Colors.red,

                  /// get theme from setting
                  theme: settingState.value.themeData,
                  navigatorKey: NavigatorHelper.navigatorKey,
                  locale: BS.delegate.supportedLocales.firstWhere((element) =>
                      element.languageCode ==
                      settingState.value.language.languageCode),
                  localizationsDelegates: _provideLocalizationsDelegates(),
                  supportedLocales: _provideSupportedLocales(),
                  debugShowCheckedModeBanner: false,
                  onGenerateRoute: onGenerateRoute,
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
