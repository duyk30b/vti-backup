extension DoubleExt on double {}

extension IntExt on int {}
