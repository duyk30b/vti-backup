import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../features/main/domain/enum/permission_enum.dart';
import '../../features/main/presentation/ui/setting/setting_cubit.dart';

extension BuildContextExt on BuildContext {
  Size get screenSize => MediaQuery.of(this).size;

  double get screenWidth => MediaQuery.of(this).size.width;

  double get screenHeight => MediaQuery.of(this).size.height;

  EdgeInsets get viewInsets => MediaQuery.of(this).viewInsets;

  bool canAccess({required PermissionEnum permission}) {
    return read<SettingCubit>().validatePermission(permission: permission);
  }
}
