class EventWrapper {
  final dynamic value;

  const EventWrapper(this.value);
}
