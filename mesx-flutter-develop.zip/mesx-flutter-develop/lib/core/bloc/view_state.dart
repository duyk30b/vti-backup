enum ViewState { content, loading, empty, error }
