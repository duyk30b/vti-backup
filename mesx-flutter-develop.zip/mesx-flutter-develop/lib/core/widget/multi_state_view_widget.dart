import 'package:flutter/material.dart';

import '../../generated/assets/assets.gen.dart';
import '../../generated/l10n.dart';
import '../bloc/view_state.dart';
import '../configs/app_colors.dart';
import '../configs/constants_widget.dart';

class MultiStateViewWidget extends StatelessWidget {
  final Widget child;
  final ViewState? viewState;
  final Widget? loadingWidget;
  final Widget? emptyWidget;
  final Widget? errorWidget;
  final String? message;
  final VoidCallback? onRetryPress;

  const MultiStateViewWidget({
    super.key,
    required this.child,
    this.viewState,
    this.loadingWidget,
    this.emptyWidget,
    this.errorWidget,
    this.message,
    this.onRetryPress,
  });

  @override
  Widget build(BuildContext context) {
    switch (viewState ?? ViewState.content) {
      case ViewState.content:
        return child;
      case ViewState.loading:
        return loadingWidget ?? defaultLoadingWidget();
      case ViewState.empty:
        return emptyWidget ?? defaultEmptyWidget();
      case ViewState.error:
        return errorWidget ?? defaultErrorWidget();
    }
  }

  Widget defaultLoadingWidget() {
    return const Center(
        child: CircularProgressIndicator(
      color: AppColors.mainBlue,
    ));
  }

  Widget defaultEmptyWidget() {
    return LayoutBuilder(builder: (context, constraints) {
      return SingleChildScrollView(
        child: Container(
          alignment: Alignment.center,
          margin: EdgeInsets.only(top: constraints.maxHeight / 3),
          child: Column(
            children: [
              Assets.images.imgEmpty.image(
                width: 100,
                height: 100,
              ),
              height12,
              Text(
                message ?? BS.current.data_not_found,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 14,
                  color: Colors.black,
                  fontWeight: FontWeight.w500,
                ),
              ),
              height5,
              onRetryPress == null
                  ? emptyView
                  : TextButton(
                      onPressed: onRetryPress, child: Text(BS.current.retry))
            ],
          ),
        ),
      );
    });
  }

  Widget defaultErrorWidget() {
    return LayoutBuilder(
      builder: (context, constraints) {
        return SingleChildScrollView(
          child: Container(
            alignment: Alignment.center,
            margin: EdgeInsets.only(top: constraints.maxHeight / 3),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.error_outline_sharp,
                  size: 40,
                  color: AppColors.mainWarning,
                ),
                height12,
                Text(
                  message ?? BS.current.something_went_wrong,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.black,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                height5,
                onRetryPress == null
                    ? emptyView
                    : TextButton(
                        onPressed: onRetryPress, child: Text(BS.current.retry))
              ],
            ),
          ),
        );
      },
    );
  }
}
