import 'package:flutter/material.dart';
import '../configs/app_colors.dart';

class AppUtils {
  const AppUtils._();

  static Color colorFromHex(String hexColor) {
    try {
      final hexCode = hexColor.replaceAll('#', '');
      return Color(int.parse('FF$hexCode', radix: 16));
    } on Exception catch (_) {
      return Colors.transparent;
    }
  }

  static void hideKeyboard() {
    WidgetsBinding.instance.focusManager.primaryFocus?.unfocus();
  }

  static void showKeyboard(BuildContext context, FocusNode inputNode) {
    FocusScope.of(context).requestFocus(inputNode);
  }

  static Future<DateTime?> selectDatePicker(BuildContext context,
      {DateTime? initialDate, DateTime? firstDate, DateTime? lastDate}) {
    /// return DateTime
    return showDatePicker(
      context: context,
      initialDate: initialDate ?? DateTime.now(),
      firstDate: firstDate ??
          DateTime.now().subtract(
            const Duration(days: 7),
          ),
      lastDate: lastDate ??
          DateTime.now().add(
            const Duration(days: 7),
          ),
      builder: (context, child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: true),
          child: Theme(
            data: ThemeData.light().copyWith(
              colorScheme: const ColorScheme.light(
                primary: AppColors.mainBlue,
              ),
            ),
            child: child!,
          ),
        );
      },
    );
  }

  static Future<DateTimeRange?> selectDatePickerRange(BuildContext context,
      {DateTimeRange? initialDateRange,
      DateTime? firstDate,
      DateTime? lastDate}) {
    /// return DateTime
    return showDateRangePicker(
      context: context,
      currentDate: DateTime.now(),
      initialDateRange: initialDateRange,
      firstDate: firstDate ??
          DateTime.now().subtract(
            const Duration(days: 7),
          ),
      lastDate: lastDate ??
          DateTime.now().add(
            const Duration(days: 7),
          ),
      builder: (context, child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: true),
          child: Theme(
            data: ThemeData.light().copyWith(
              colorScheme: const ColorScheme.light(
                primary: AppColors.mainBlue,
              ),
            ),
            child: child!,
          ),
        );
      },
    );
  }
}
