import '../../generated/l10n.dart';

mixin Validator {
  String? validatorAccount(String account) {
    if (account.trim().isEmpty) {
      return BS.current.input_account_hint;
    }
    return null;
  }

  String? validatorPass(String pass) {
    if (pass.trim().isEmpty) {
      return BS.current.input_pass_hint;
    }
    // if (pass.trim().length < 6) return BS.current.pass_short;
    return null;
  }

  bool validatorQRCode(String code) {
    RegExp regExp = RegExp(r'^[a-zA-Z0-9.,_-]+$');
    if (!regExp.hasMatch(code)) return false;
    return true;
  }
}
