import 'package:json_annotation/json_annotation.dart';

class DateTimeConverter implements JsonConverter<DateTime?, String> {
  const DateTimeConverter();

  @override
  DateTime? fromJson(String json) {
    try {
      return DateTime.parse(json);
    } catch (e) {
      return null;
    }
  }

  @override
  String toJson(DateTime? json) => json?.toIso8601String() ?? '';
}

class FormDateTimeConverter implements JsonConverter<DateTime?, dynamic> {
  const FormDateTimeConverter();

  @override
  DateTime? fromJson(dynamic json) {
    if (json == null) {
      return null;
    }
    if (json is DateTime) {
      return json;
    }
    try {
      return DateTime.parse(json);
    } catch (e) {
      return null;
    }
  }

  @override
  String? toJson(DateTime? json) => json?.toIso8601String();
}

class FormNumberConverter implements JsonConverter<num?, dynamic> {
  const FormNumberConverter();

  @override
  num? fromJson(dynamic json) {
    if (json == null) {
      return null;
    }
    if (json is num) {
      return json;
    }
    return num.tryParse(json);
  }

  @override
  num? toJson(num? json) => json;
}
