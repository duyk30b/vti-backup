import 'package:flutter/material.dart';

import '../../features/main/domain/model/job.dart';
import '../../features/main/presentation/ui/task/widget/add_supplies_widget.dart';
import '../../generated/l10n.dart';
import 'pop_up_dialog.dart';

class PopUpHelper {
  static Future _showPopUp(BuildContext context, Widget child,
      {EdgeInsets? insetPadding}) {
    return showDialog(
        context: context,
        builder: (context) => Dialog(
              insetPadding: insetPadding ??
                  const EdgeInsets.symmetric(horizontal: 40.0, vertical: 24.0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              child: child,
            ));
  }

  static Future showDialogConfirm(
    BuildContext context, {
    required String title,
    String? message,
    ValueChanged<String>? onChanged,
    String? textFieldLabel,
    String? initTextField,
    String? cancelText,
  }) {
    return _showPopUp(
      context,
      PopUpDialog.confirmDialog(
        context,
        title: title,
        message: message,
        onChanged: onChanged,
        textFieldLabel: textFieldLabel,
        initTextField: initTextField,
        cancelText: cancelText,
      ),
    );
  }

  static Future showDialogMessage(
    BuildContext context,
    String message, {
    Widget? icon,
  }) {
    return _showPopUp(
        context, PopUpDialog.messageDialog(context, message, icon: icon));
  }

  static Future showDialogTextField(BuildContext context, String message,
      {String? label,
      String? hintText,
      ValueChanged? onChanged,
      bool validator = false,
      String? error}) {
    /// return String value
    return _showPopUp(
      context,
      PopUpDialog.textFieldDialog(context, message,
          label: label ?? BS.current.comment,
          hintText: hintText,
          onChanged: onChanged,
          validator: validator,
          error: error),
    );
  }

  static Future showDialogAdd(BuildContext context,
      {SupplyCallBack? callBack}) {
    /// logic not complete
    return _showPopUp(
      context,
      PopUpDialog.addDialog(context, callBack: callBack),
    );
  }

  static Future showDialogCustom(BuildContext context, Widget child) {
    return _showPopUp(context, child);
  }

  static Future showUpdateStatusDialog(BuildContext context, Job job) {
    /// logic not complete
    return _showPopUp(context, PopUpDialog.updateStatusDialog(context, job),
        insetPadding: const EdgeInsets.symmetric(horizontal: 10));
  }
}
