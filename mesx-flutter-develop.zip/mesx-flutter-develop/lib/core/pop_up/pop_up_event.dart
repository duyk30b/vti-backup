enum PopUpType { success, failed }

class PopUpMsgEvent {
  final String message;

  final PopUpType type;

  PopUpMsgEvent._(this.message, this.type);

  PopUpMsgEvent.success(String message) : this._(message, PopUpType.success);

  PopUpMsgEvent.failed(String message) : this._(message, PopUpType.failed);
}
