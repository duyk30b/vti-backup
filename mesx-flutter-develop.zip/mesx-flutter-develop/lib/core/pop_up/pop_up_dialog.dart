import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../features/main/domain/enum/maintain_enum.dart';
import '../../features/main/domain/enum/task_status.dart';
import '../../features/main/domain/model/job.dart';
import '../../features/main/domain/model/supply.dart';
import '../../features/main/domain/request/base_query.dart';
import '../../features/main/domain/usecase/get_supply_list_usecase.dart';
import '../../features/main/presentation/ui/task/widget/add_supplies_widget.dart';
import '../../features/main/presentation/widget/app_drop_down.dart';
import '../../features/main/presentation/widget/app_text_field.dart';
import '../../features/main/presentation/widget/form_control/form_autocomplete_field.dart';
import '../../features/main/presentation/widget/quantity_widget.dart';
import '../../generated/assets/assets.gen.dart';
import '../../generated/l10n.dart';
import '../configs/app_colors.dart';
import '../configs/constants.dart';
import '../configs/constants_widget.dart';
import '../extensions/string_ext.dart';

class PopUpDialog {
  static Widget confirmDialog(
    BuildContext context, {
    required String title,
    String? message,
    ValueChanged<String>? onChanged,
    String? textFieldLabel,
    String? initTextField,
    String? cancelText,
  }) {
    return ConfirmDialog(
      title: title,
      message: message,
      onChanged: onChanged,
      textFieldLabel: textFieldLabel,
      initTextField: initTextField,
      cancelText: cancelText,
    );
  }

  static Widget messageDialog(BuildContext context, String message,
      {Widget? icon}) {
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          icon ?? Assets.images.svgIcon.icVerifyUser.svg(),
          const SizedBox(height: 16),
          Text(
            message,
            textAlign: TextAlign.center,
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
          ),
          const SizedBox(height: 19),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text(BS.current.close),
          )
        ],
      ),
    );
  }

  static Widget textFieldDialog(
    BuildContext context,
    String message, {
    String? hintText,
    required String label,
    ValueChanged? onChanged,
    bool validator = false,
    String? error,
  }) {
    return TextFieldDialogContent(
      message: message,
      label: label,
      hint: hintText,
      onChanged: onChanged,
      validator: validator,
      error: error,
    );
  }

  static Widget addDialog(BuildContext context, {SupplyCallBack? callBack}) {
    return AddDialog(
      callBack: callBack,
    );
  }

  static Widget updateStatusDialog(BuildContext context, Job job) {
    return UpdateStatusDialog(job: job);
  }
}

class ConfirmDialog extends StatefulWidget {
  final String title;
  final String? message;
  final ValueChanged<String>? onChanged;
  final String? textFieldLabel;
  final String? initTextField;
  final String? cancelText;

  const ConfirmDialog(
      {Key? key,
      required this.title,
      this.message,
      this.onChanged,
      this.textFieldLabel,
      this.initTextField,
      this.cancelText})
      : super(key: key);

  @override
  State<ConfirmDialog> createState() => _ConfirmDialogState();
}

class _ConfirmDialogState extends State<ConfirmDialog> {
  final TextEditingController textController = TextEditingController();

  @override
  void initState() {
    textController.text = widget.initTextField ?? '';
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget.title,
            style: const TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 15,
            ),
          ),
          const SizedBox(height: 16),
          Visibility(
            visible: widget.message != null,
            child: Text(
              widget.message ?? '',
              style: const TextStyle(
                fontWeight: FontWeight.w400,
                fontSize: 14,
                color: AppColors.subTextColor,
              ),
            ),
          ),
          Visibility(
            visible: widget.onChanged != null && widget.textFieldLabel != null,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 3,
                  child: Text(
                    widget.textFieldLabel ?? '',
                    style: const TextStyle(
                      fontWeight: FontWeight.w400,
                      fontSize: 13,
                    ),
                  ),
                ),
                Expanded(
                  flex: 4,
                  child: AppTextField(
                    controller: textController,
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 8, horizontal: 8.8),
                  ),
                )
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              OutlinedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text(widget.cancelText ?? BS.current.close),
              ),
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: () {
                  /// confirm to return value
                  widget.onChanged?.call(textController.text);

                  /// return true result
                  Navigator.pop(context, true);
                },
                child: Text(BS.current.confirm),
              )
            ],
          )
        ],
      ),
    );
  }
}

class TextFieldDialogContent extends StatefulWidget {
  final String message;
  final String? hint;
  final String label;
  final ValueChanged? onChanged;
  final bool validator;
  final String? error;

  const TextFieldDialogContent(
      {Key? key,
      required this.message,
      this.hint,
      required this.label,
      this.onChanged,
      this.validator = false,
      this.error})
      : super(key: key);

  @override
  State<TextFieldDialogContent> createState() => _TextFieldDialogContentState();
}

class _TextFieldDialogContentState extends State<TextFieldDialogContent> {
  final textController = TextEditingController();

  final GlobalKey<FormState> key = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget.message,
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
          ),
          const SizedBox(height: 19),
          Form(
            key: key,
            child: AppTextField(
              hint: widget.hint,
              label: widget.label,
              validator: (text) {
                if (text == null || text.isEmpty == true) {
                  return widget.error ?? BS.current.please_input_reason;
                }
                return null;
              },
              controller: textController,
              limitLength: Constants.commonTextMaxLength,
              maxLines: 3,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              OutlinedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text(BS.current.cancel)),
              const SizedBox(width: 8),
              ElevatedButton(
                  onPressed: () {
                    if (widget.validator) {
                      if (key.currentState?.validate() == false) {
                        return;
                      }
                    }

                    /// pop to String result
                    widget.onChanged?.call(textController.text);
                    Navigator.pop(context, textController.text);
                  },
                  child: Text(BS.current.confirm))
            ],
          )
        ],
      ),
    );
  }
}

class AddDialog extends StatefulWidget {
  final SupplyCallBack? callBack;

  const AddDialog({Key? key, this.callBack}) : super(key: key);

  @override
  State<AddDialog> createState() => _AddDialogState();
}

class _AddDialogState extends State<AddDialog> {
  Supply? supply;
  MaintainType? type;
  int quantity = 1;

  final supplyKey = GlobalKey<FormState>();

  ValueNotifier<List<Supply>> listSupplyController =
      ValueNotifier<List<Supply>>([]);

  GetSupplyListUsecase get getSupplyListUsecase => context.read();

  @override
  void initState() {
    type = MaintainType.repair;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            BS.of(context).add_supplies,
            style: const TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 15,
            ),
          ),
          const SizedBox(height: 16),
          // Form(
          //   key: supplyKey,
          //   child: AppDropDown<Supply>(
          //     validator: (type) {
          //       if (type == null) {
          //         return "Vui lòng nhập trường bắt buộc Tên vật tư phụ tùng";
          //       }
          //       return null;
          //     },
          //     onChanged: (supply) {
          //       setState(() {
          //         this.supply = supply;
          //       });
          //     },
          //     labelText: BS.of(context).supply_name,
          //     selectedItemBuilder: (context) => widget.supplies.map(
          //       (e) {
          //         return SingleChildScrollView(
          //           scrollDirection: Axis.horizontal,
          //           child: Text(e.title),
          //         );
          //       },
          //     ).toList(),
          //     items: List<DropdownMenuItem<Supply>>.generate(
          //       widget.supplies.length,
          //       (index) {
          //         var supply = widget.supplies[index];
          //         return DropdownMenuItem(
          //           value: supply,
          //           child: Column(
          //             crossAxisAlignment: CrossAxisAlignment.start,
          //             children: [
          //               Text(
          //                 supply.title,
          //                 style: Theme.of(context)
          //                     .textTheme
          //                     .bodySmall
          //                     ?.copyWith(
          //                         fontSize: 13, fontWeight: FontWeight.w700),
          //               ),
          //               Text(
          //                 supply.code ?? '',
          //                 style: Theme.of(context)
          //                     .textTheme
          //                     .bodySmall
          //                     ?.copyWith(
          //                         fontSize: 13, fontWeight: FontWeight.w400),
          //               ),
          //             ],
          //           ),
          //         );
          //       },
          //     ),
          //   ),
          // ),
          Form(
            key: supplyKey,
            child: FormAutoCompleteField<Supply>(
              name: 'supply',
              hint: BS.current.supply_name_acr_placeholder,
              labelText: BS.current.supply_name_acr,
              asyncSearch: (keyword) {
                final baseQuery = BaseQuery(
                  limit: 50,
                );
                baseQuery.setFilter('active', '1');
                baseQuery.setKeyword = keyword;
                return getSupplyListUsecase.execute(baseQuery);
              },
              getOptionLabel: (opt) {
                final List<String> label = [];
                if (!opt.name.isNullOrBlank) {
                  label.add(opt.name!);
                }
                if (!opt.nameOther.isNullOrBlank) {
                  label.add(opt.nameOther!);
                }
                if (!opt.code.isNullOrBlank) {
                  label.add(opt.code!);
                }
                return label.join(' - ');
              },
              getValueLabel: (opt) => opt.name ?? '',
              isOptionEqualToValue: (opt, val) => opt.id == val.id,
              required: true,
              validator: (type) {
                if (type == null) {
                  return BS.current.form_required(BS.current.supply_name_acr);
                }
                return null;
              },
              onChanged: (value) {
                setState(() {
                  supply = value;
                });
              },
            ),
          ),
          const SizedBox(height: 16),
          AppDropDown<MaintainType>(
              initValue: type,
              onChanged: (type) {
                this.type = type;
              },
              items: MaintainType.values
                  .map((e) => DropdownMenuItem(
                        value: e,
                        child: Text(e.titleDropDown),
                      ))
                  .toList(),
              labelText: BS.of(context).maintenance_type,
              required: true),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                  child: QuantityWidget(
                minVolume: 1,
                initVolume: quantity,
                onChangedVolume: supply == null
                    ? null
                    : (int value) {
                        quantity = value;
                      },
              )),
              const SizedBox(width: 20),
              Text(
                supply?.unit?.name ?? '',
                style: Theme.of(context)
                    .textTheme
                    .bodySmall
                    ?.copyWith(fontWeight: FontWeight.w600, fontSize: 14),
              ),
              // hash code
            ],
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              OutlinedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text(BS.current.cancel),
              ),
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: () {
                  if (supplyKey.currentState?.validate() == false) {
                    return;
                  }

                  /// confirm to return value
                  widget.callBack
                      ?.call(supply!.copyWith(quantity: quantity, type: type));

                  /// return true result
                  Navigator.pop(context, true);
                },
                child: Text(BS.current.confirm),
              )
            ],
          ),
          SizedBox(height: MediaQuery.of(context).viewInsets.bottom)
        ],
      ),
    );
  }
}

class UpdateStatusDialog extends StatefulWidget {
  final Job job;

  const UpdateStatusDialog({Key? key, required this.job}) : super(key: key);

  @override
  State<UpdateStatusDialog> createState() => _UpdateStatusDialogState();
}

class _UpdateStatusDialogState extends State<UpdateStatusDialog> {
  List<TaskStatus> listJobUpdate = [];

  @override
  void initState() {
    if (widget.job.taskStatus == TaskStatus.inProgress) {
      if (widget.job.taskStatus == TaskStatus.inProgress) {
        listJobUpdate = List.from([TaskStatus.notAssign, TaskStatus.pending]);
      }
    }
    if (widget.job.taskStatus == TaskStatus.pending) {
      listJobUpdate = List.from([TaskStatus.notAssign]);
    }
    super.initState();
  }

  TaskStatus? status;

  final keyForm = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          height16,
          Text(
            BS.of(context).update_status,
            style: Theme.of(context)
                .textTheme
                .bodySmall
                ?.copyWith(fontSize: 16, fontWeight: FontWeight.w500),
          ),
          height16,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                BS.current.job_code,
                style: Theme.of(context)
                    .textTheme
                    .bodySmall
                    ?.copyWith(fontSize: 14),
              ),
              Text(
                widget.job.code ?? '',
                style: Theme.of(context)
                    .textTheme
                    .bodySmall
                    ?.copyWith(fontWeight: FontWeight.w600, fontSize: 14),
              ),
            ],
          ),
          height16,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                BS.current.assignee,
                style: Theme.of(context)
                    .textTheme
                    .bodySmall
                    ?.copyWith(fontSize: 14),
              ),
              Text(
                widget.job.assign?.name ?? '',
                style: Theme.of(context)
                    .textTheme
                    .bodySmall
                    ?.copyWith(fontWeight: FontWeight.w600, fontSize: 14),
              ),
            ],
          ),
          height16,
          IntrinsicHeight(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  BS.current.new_update_status,
                  style: Theme.of(context)
                      .textTheme
                      .bodySmall
                      ?.copyWith(fontSize: 14),
                ),
                const SizedBox(width: 20),
                Flexible(
                    child: Form(
                  key: keyForm,
                  child: AppDropDown<TaskStatus>(
                    onChanged: (status) {
                      this.status = status;
                    },
                    validator: (status) {
                      if (status == null) {
                        return BS.current.form_required(BS.current.status);
                      }
                      return null;
                    },
                    initValue: status,
                    labelText: BS.of(context).new_update_status,
                    items: listJobUpdate
                        .map(
                          (e) => DropdownMenuItem<TaskStatus>(
                            value: e,
                            child: Text(e.title),
                          ),
                        )
                        .toList(),
                  ),
                )),
              ],
            ),
          ),
          height16,
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text(BS.of(context).reject),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ElevatedButton(
                  onPressed: () {
                    if (keyForm.currentState?.validate() == false) {
                      return;
                    }
                    Navigator.of(context).pop(status);
                  },
                  child: Text(BS.of(context).confirm),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}
