import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import '../../generated/l10n.dart';
import '../bloc/base_bloc.dart';
import '../configs/constants.dart';
import '../widget/base_widget.dart';
import '../widget/base_widget.dart' as base;
import 'refresh_event.dart';
import 'refresh_helper.dart';

class BaseListPage<V, C extends BaseListCubit<V>>
    extends BaseStatelessWidget<V, C> {
  const BaseListPage({Key? key}) : super(key: key);
}

class BaseListPageStatefulState<V, C extends BaseListCubit<V>>
    extends State<BaseStatefulWidget> with base.Page<V, C> {
  @override
  Widget build(BuildContext context) {
    return buildRoot();
  }
}

abstract class BaseListCubit<V> extends BaseCubit<V> {
  BaseListCubit.value(super.value) : super.value();

  BaseListCubit.create(super.initialState) : super.create();

  int _page = 1;

  int get page => _page;

  int get limit => Constants.limit;

  @override
  void refresh() {
    _page = 1;
  }

  void dispatchResult(
      {List? newData, String? exception, String? emptyMessage}) {
    if (exception != null) {
      if (isRefresh()) {
        emitRefreshToIdle();
        showError(exception);
      } else {
        emitLoadFailed();
      }
      return;
    }
    if (newData != null) {
      final dataLength = newData.length;
      if (isRefresh()) {
        emitRefreshToIdle();
        if (dataLength == 0) {
          showEmpty(emptyMessage);
        } else {
          showContent();
        }
      }
      if (dataLength < limit) {
        emitLoadNoData();
      } else {
        emitLoadComplete();
      }
    }
  }

  void onLoadMore() {}

  void emitRefreshToIdle() {
    emitNewEvent(RefreshEvent.refreshToIdle());
  }

  void emitLoadComplete() {
    _page++;
    emitNewEvent(RefreshEvent.loadComplete());
  }

  void emitLoadFailed() {
    emitNewEvent(RefreshEvent.loadFailed());
  }

  void emitLoadNoData() {
    emitNewEvent(RefreshEvent.loadNoData());
  }

  bool isRefresh() => page == 1;

  bool isLoadMore() => page > 1;
}

mixin BaseListPageMixin<V, C extends BaseListCubit<V>> on BaseListPage<V, C> {
  final RefreshController refreshController = RefreshController();

  Widget generateList(BuildContext context, Widget child) {
    return SmartRefresher(
      enablePullUp: true,
      enablePullDown: true,
      controller: refreshController,
      onRefresh: () => cubit(context).refresh(),
      onLoading: () => cubit(context).onLoadMore(),
      footer: ClassicFooter(
        noDataText: '',
        loadingText: BS.current.load_more,
        idleText: '',
        idleIcon: null,
        canLoadingText: '',
        failedText: BS.current.something_went_wrong,
      ),
      header: const MaterialClassicHeader(),
      child: child,
    );
  }

  @override
  void handleListener(BuildContext context, StateWrapper<V> state) {
    final event = state.event;
    if (event is RefreshEvent) {
      RefreshHelper.handleRefresh(refreshController, event);
      return;
    }
    super.handleListener(context, state);
  }
}

mixin BaseListPageMixinFull<V, C extends BaseListCubit<V>>
    on BaseListPageStatefulState<V, C> {
  final RefreshController refreshController = RefreshController();

  Widget generateList(BuildContext context, Widget child) {
    return SmartRefresher(
      enablePullUp: true,
      enablePullDown: true,
      controller: refreshController,
      onRefresh: () => cubit(context).refresh(),
      onLoading: () => cubit(context).onLoadMore(),
      footer: ClassicFooter(
        noDataText: '',
        loadingText: BS.current.load_more,
        idleText: '',
        idleIcon: null,
        canLoadingText: '',
        failedText: BS.current.something_went_wrong,
      ),
      header: const MaterialClassicHeader(),
      child: child,
    );
  }

  @override
  void handleListener(BuildContext context, StateWrapper<V> state) {
    final event = state.event;
    if (event is RefreshEvent) {
      RefreshHelper.handleRefresh(refreshController, event);
      return;
    }
    super.handleListener(context, state);
  }
}
