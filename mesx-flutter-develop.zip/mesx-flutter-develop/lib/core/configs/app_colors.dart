import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  static const Color beige = Color(0xFFA8A878);
  static const Color black = Color(0xFF303943);
  static const Color blue = Color(0xFF429BED);
  static const Color mainBlue = Color(0xff0761AD);
  static const Color brown = Color(0xFFB1736C);
  static const Color darkBrown = Color(0xD0795548);
  static const Color darkGrey = Color(0xFF303943);
  static const Color grey = Color(0x64303943);
  static const Color indigo = Color(0xFF6C79DB);
  static const Color lightBlue = Color(0xFF7AC7FF);
  static const Color lightBrown = Color(0xFFCA8179);
  static const Color whiteGrey = Color(0xFFFDFDFD);
  static const Color lightWhite = Color(0xFFFFFFFF);
  static const Color lightCyan = Color(0xFF98D8D8);
  static const Color lightGreen = Color(0xFF78C850);
  static const Color lighterGrey = Color(0xFFF4F5F4);
  static const Color lightGrey = Color(0xFFF5F5F5);
  static const Color lightPink = Color(0xFFEE99AC);
  static const Color lightPurple = Color(0xFF9F5BBA);
  static const Color lightRed = Color(0xFFFB6C6C);
  static const Color lightTeal = Color(0xFF48D0B0);
  static const Color lightYellow = Color(0xFFFFCE4B);
  static const Color lilac = Color(0xFFA890F0);
  static const Color pink = Color(0xFFF85888);
  static const Color purple = Color(0xFF7C538C);
  static const Color red = Color(0xFFFA6555);
  static const Color teal = Color(0xFF4FC1A6);
  static const Color yellow = Color(0xFFF6C747);
  static const Color semiGrey = Color(0xFFbababa);
  static const Color violet = Color(0xD07038F8);
  static const Color orange = Color(0xffFF5900);

  static const Color dividerColor = Color(0xFF909090);
  static const Color mainWarning = Color(0xFFE13939);

  static const Color buttonBorderLine = Color(0xffD8DFE9);
  static const Color buttonDisable = Color.fromRGBO(7, 97, 173, 0.5);
  static const Color blackPrimary = Color(0xff222222);
  static const Color textBlack = Color(0xff121212);

  static const Color subTextColor = Color(0xff333333);
  static const Color secondaryTextColor = Color(0xff666666);

  static const Color plashWhite = Color(0xffEDF0F4);

  static const Color textColorTabBarUnselect = Color(0xff666666);
  static const Color textHint = Color(0xffA6A2A2);

  static const Color statusSuccess = Color(0xff0FA44A);
  static const Color statusReject = Color(0xffE13939);
  static const Color statusPending = Color(0xffFF5900);
  static const Color statusError = Color(0xff634DEC);
  static const Color statusCompleted = Color(0xff0761AD);

  static const Color usageStatusUsing = Color(0xffFF5900);
  static const Color usageStatusBroken = Color(0xff7B61FF);
  static const Color usageStatusAwaitClearance = Color(0xffEA2D21);
  static const Color usageStatusPreventive = Color(0xff0761AD);
  static const Color usageStatusRareUsed = Color(0xffA5FD86);

  static const Color vtptRequestReject = Color(0xFFFF0909);
  static const Color vtptRequestWaiting = Color(0xFFFF9054);
  static const Color vtptRequestConfirm = Color(0xFF0FA44A);
  static const Color vtptRequestComplete = Color(0xFF0FA44A);
  static const Color vtptRequestAwaitReturn = Color(0xFF0761AD);
  static const Color formFieldDisable = Color(0xffD8DFE9);
  static const Color greenConfirm = Color(0xff0FA44A);
}
