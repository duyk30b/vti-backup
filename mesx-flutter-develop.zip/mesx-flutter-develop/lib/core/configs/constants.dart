class Constants {
  static const String appLogKey = 'vn.com.vti';
  static const String blocLogSuffix = 'Bloc';
  static const String primaryFont = 'Lato';

  static const int limit = 20;

  static const dateAPIFormat = 'dd/MM/yyyy';
  static const dateTimeAPIFormat = "MM/dd/yyyy'T'hh:mm:ss.SSSZ";
  static const timeFormat = 'HH:mm:ss';

  static const dateDisplayFormat = 'dd/MM/yyyy';
  static const dateTimeDisplayFormat = 'HH:mm dd/MM/yyyy';
  static const timeDisplayFormat = 'dd/MM/yyyy HH:mm:ss';

  static const commonTextMaxLength = 255;
  static const nameMaxLength = 20;
  static const textLength100 = 100;
  static const textLength10 = 10;
}
