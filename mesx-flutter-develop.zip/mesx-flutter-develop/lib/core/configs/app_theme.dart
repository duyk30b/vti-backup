import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'app_colors.dart';

class AppTheme {
  static TextStyle darkText = GoogleFonts.inter(color: AppColors.whiteGrey);

  static TextStyle lightText = GoogleFonts.inter(color: AppColors.textBlack);

  static final ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    primaryColor: AppColors.blue,
    appBarTheme: _appBarLightTheme,
    textTheme: TextTheme(
      bodySmall: darkText,
      bodyLarge: darkText,
      bodyMedium: darkText,
      labelMedium: darkText,
      labelSmall: darkText,
      labelLarge: darkText,
    ),
    scaffoldBackgroundColor: AppColors.black,
    colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.blue).copyWith(
      background: AppColors.black,
    ),
  );

  static final AppBarTheme _appBarLightTheme = AppBarTheme(
      backgroundColor: AppColors.lightWhite,
      titleTextStyle: GoogleFonts.inter(
        color: AppColors.blackPrimary,
        fontWeight: FontWeight.w600,
        height: 24 / 16,
        fontSize: 16,
      ),
      iconTheme: const IconThemeData(
        color: AppColors.blackPrimary,
      ));

  static final ThemeData lightTheme = ThemeData(
    brightness: Brightness.light,
    primaryColor: AppColors.blue,
    fontFamily: GoogleFonts.inter().fontFamily,
    inputDecorationTheme: _inputDecorationTheme,
    appBarTheme: _appBarLightTheme,
    elevatedButtonTheme: _elevatedButtonThemeData,
    outlinedButtonTheme: _outlinedButtonThemeData,
    tabBarTheme: _tabBarThemeLight,
    bottomNavigationBarTheme: _barThemeData,
    textTheme: TextTheme(
      bodySmall: lightText,
      bodyLarge: lightText,
      bodyMedium: lightText,
      labelMedium: lightText,
      labelSmall: lightText,
      labelLarge: lightText,
    ),
    scaffoldBackgroundColor: AppColors.lightWhite,
    colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.blue).copyWith(
      background: AppColors.whiteGrey,
    ),
  );

  static final BottomNavigationBarThemeData _barThemeData =
      BottomNavigationBarThemeData(
    selectedItemColor: AppColors.mainBlue,
    unselectedItemColor: AppColors.subTextColor,
    backgroundColor: AppColors.lightWhite,
    selectedLabelStyle: GoogleFonts.inter(
      fontWeight: FontWeight.w600,
      color: AppColors.mainBlue,
      fontSize: 10,
    ),
    unselectedLabelStyle: GoogleFonts.inter(
      fontWeight: FontWeight.w400,
      color: AppColors.subTextColor,
      fontSize: 10,
    ),
  );

  static final ElevatedButtonThemeData _elevatedButtonThemeData =
      ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      /// text color
      foregroundColor: AppColors.lightWhite,
      backgroundColor: AppColors.mainBlue,
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      textStyle: GoogleFonts.inter(
        fontWeight: FontWeight.w500,
        fontSize: 14,
        height: 1,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(6),
      ),
    ),
  );

  static final OutlinedButtonThemeData _outlinedButtonThemeData =
      OutlinedButtonThemeData(
    style: OutlinedButton.styleFrom(
      /// text color
      foregroundColor: AppColors.subTextColor,
      backgroundColor: AppColors.lightWhite,
      textStyle: GoogleFonts.inter(
          fontWeight: FontWeight.w400, fontSize: 13, height: 1),
      side: const BorderSide(
        color: AppColors.buttonBorderLine,
        width: 1,
      ),
      padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 16),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(6),
      ),
    ),
  );

  static final InputDecorationTheme _inputDecorationTheme =
      InputDecorationTheme(
    hintStyle: GoogleFonts.inter(
      fontWeight: FontWeight.w500,
      color: const Color.fromRGBO(18, 18, 18, 0.5),
    ),
    labelStyle: GoogleFonts.inter(
      fontWeight: FontWeight.w400,
      color: AppColors.subTextColor,
      fontSize: 13,
    ),
    border: _defaultBorder,
    focusedBorder: _defaultBorder.copyWith(
      borderSide: const BorderSide(
        color: AppColors.blue,
        width: 1,
      ),
    ),
    errorMaxLines: 3,
    errorBorder: _defaultBorder.copyWith(
      borderSide: const BorderSide(
        color: AppColors.lightRed,
        width: 1,
      ),
    ),
    focusedErrorBorder: _defaultBorder.copyWith(
      borderSide: const BorderSide(
        color: AppColors.lightRed,
        width: 1,
      ),
    ),
    enabledBorder: _defaultBorder.copyWith(
      borderSide: const BorderSide(
        color: AppColors.buttonBorderLine,
        width: 1,
      ),
    ),
  );

  static final OutlineInputBorder _defaultBorder = OutlineInputBorder(
    borderRadius: BorderRadius.circular(6),
    borderSide: const BorderSide(
      color: AppColors.buttonBorderLine,
      width: 1,
    ),
  );

  static final TabBarTheme _tabBarThemeLight = TabBarTheme(
    indicatorSize: TabBarIndicatorSize.tab,
    unselectedLabelColor: AppColors.textColorTabBarUnselect,
    unselectedLabelStyle: GoogleFonts.inter(
      fontSize: 14,
      fontWeight: FontWeight.w400,
      height: 22 / 14,
    ),
    labelColor: AppColors.mainBlue,
    labelStyle: GoogleFonts.inter(
      fontSize: 14,
      fontWeight: FontWeight.w700,
      height: 22 / 14,
    ),
    indicator: const BoxDecoration(
      color: AppColors.lightWhite,
      boxShadow: [
        BoxShadow(
          offset: Offset(0, 3),
          blurRadius: 0,
          color: AppColors.mainBlue,
        ),
      ],
    ),
  );
}
