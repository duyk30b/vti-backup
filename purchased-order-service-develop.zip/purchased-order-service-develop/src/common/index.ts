export enum APIPrefix {
  Version = 'api/v1/purchased-orders',
}
