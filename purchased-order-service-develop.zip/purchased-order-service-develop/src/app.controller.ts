import { NATS_AUTH, NATS_PURCHASED_ORDER } from '@config/nats.config';
import { Public } from '@core/decorator/set-public.decorator';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Body, Controller, Get, Put } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ResponseBuilder } from '@utils/response-builder';
import { AppService } from './app.service';
import { ApiBearerAuth } from '@nestjs/swagger';

@Controller()
@ApiBearerAuth('access-token')
export class AppController {
  constructor(
    private readonly appService: AppService,
    private readonly natsClientService: NatsClientService,
  ) {}

  @Get('/ping')
  @MessagePattern('ping')
  async ping(): Promise<any> {
    return await this.appService.ping();
  }

  @Public()
  @Get('health')
  getHealth(): string {
    return this.appService.getHealth();
  }

  @Put('update-permission')
  updatePermission(): Promise<void> {
    return this.appService.updatePermissions();
  }

  @MessagePattern(`${NATS_PURCHASED_ORDER}.ping`)
  pingServer(@Body() body: any) {
    return new ResponseBuilder()
      .withData({ msg: `${NATS_PURCHASED_ORDER}: pong`, data: body })
      .build();
  }

  @Get('ping-nats')
  async pingNats(): Promise<any> {
    const pingAuth = await this.natsClientService.send(`${NATS_AUTH}.ping`, {
      msg: 'ping',
      queue: NATS_AUTH,
    });
    const pingSelf = await this.natsClientService.send(
      `${NATS_PURCHASED_ORDER}.ping`,
      {
        msg: 'ping',
        queue: NATS_PURCHASED_ORDER,
      },
    );
    return new ResponseBuilder()
      .withData({ data: { pingSelf, pingAuth } })
      .build();
  }
}
