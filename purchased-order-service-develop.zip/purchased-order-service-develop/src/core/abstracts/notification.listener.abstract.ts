import {
  Payload,
  PushNotificationRequestDto,
} from '@components/notification/dto/notification.request.dto';
import { NotificationEventInterface } from '@components/notification/interface/notification.event.interface';
import { NotificationServiceInterface } from '@components/notification/interface/notification.service.interface';
import {
  NOTIFICATION_ENTITY_ENUM,
  TypeNotificationEnum,
} from '@components/notification/notification.const';
import { compact, uniq } from 'lodash';

export class NotificationListenerAbstract {
  protected constructor(
    protected readonly notificationService: NotificationServiceInterface,
  ) {}

  protected generatePayload(
    event: NotificationEventInterface,
    entity: NOTIFICATION_ENTITY_ENUM,
  ): Payload {
    return {
      id: event.id,
      code: event.code,
      name: event.name,
      entityType: event.entityType,
      entity: entity,
    };
  }

  protected async sendWebNotification(
    data: PushNotificationRequestDto,
  ): Promise<any> {
    const webNotificationRequest = { ...data, type: TypeNotificationEnum.WEB };
    return await this.pushNotification(webNotificationRequest);
  }

  protected async sendAppNotification(
    data: PushNotificationRequestDto,
  ): Promise<any> {
    const appNotificationRequest = { ...data, type: TypeNotificationEnum.APP };
    return await this.pushNotification(appNotificationRequest);
  }

  private async pushNotification(
    data: PushNotificationRequestDto,
  ): Promise<any> {
    data.executionDate = new Date().toISOString();
    data.userIds = compact(uniq(data.userIds));
    return await this.notificationService.pushNotification(data);
  }
}
