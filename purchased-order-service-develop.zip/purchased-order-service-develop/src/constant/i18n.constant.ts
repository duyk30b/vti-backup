export const I18N_KEY_CONST = {
  PROPERTY: '{{property}}',
  MAX_LENGTH: '{{maxLength}}',
  MIN_LENGTH: '{{minLength}}',
};
