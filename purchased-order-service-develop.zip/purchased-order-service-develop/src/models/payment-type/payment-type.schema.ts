import {
  PaymentTypeStatusEnum,
  PAYMENT_TYPE_VALIDATION,
} from '@components/payment-type/payment-type.constant';
import { DEFAULT_COLLATION } from '@constant/common';
import * as mongoose from 'mongoose';

const HistorySchema = new mongoose.Schema({
  userId: {
    type: Number,
  },
  content: { type: [String] },
  createdAt: {
    type: Date,
  },
});

export const PaymentTypeSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      maxlength: PAYMENT_TYPE_VALIDATION.CODE.MAX_LENGTH,
    },
    name: {
      type: String,
      maxlength: PAYMENT_TYPE_VALIDATION.NAME.MAX_LENGTH,
    },
    description: {
      type: String,
    },
    createdByUserId: {
      type: Number,
    },
    status: {
      type: Number,
      enum: PaymentTypeStatusEnum,
      default: PaymentTypeStatusEnum.ACTIVE,
    },
    histories: {
      type: [HistorySchema],
      required: true,
      default: [],
    },
    deletedAt: {
      type: Date,
      required: false,
      default: null,
    },
  },
  {
    collection: 'paymentTypes',
    id: true,
    timestamps: true,
    collation: DEFAULT_COLLATION,
  },
);
