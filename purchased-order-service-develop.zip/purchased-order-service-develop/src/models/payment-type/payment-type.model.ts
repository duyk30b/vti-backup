import { BaseModel } from '@core/model/base.model';

export interface History {
  userId: number;
  content: string[];
  createdAt: Date;
}
export interface PaymentTypeModel extends BaseModel {
  name: string;
  code: string;
  description: string;
  status: number;
  createdByUserId: number;
  histories: History[];
  createdAt: Date;
  deletedAt: Date;
}
