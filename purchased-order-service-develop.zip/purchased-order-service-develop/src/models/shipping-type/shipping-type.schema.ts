import {} from '@components/payment-type/payment-type.constant';
import {
  ShippingTypeStatusEnum,
  SHIPPING_TYPE_VALIDATION,
} from '@components/shipping-type/shipping-type.constant';
import { DEFAULT_COLLATION } from '@constant/common';
import * as mongoose from 'mongoose';

const HistorySchema = new mongoose.Schema({
  userId: {
    type: Number,
  },
  content: { type: [String] },
  createdAt: {
    type: Date,
  },
});

export const ShippingTypeSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      maxlength: SHIPPING_TYPE_VALIDATION.CODE.MAX_LENGTH,
    },
    name: {
      type: String,
      maxlength: SHIPPING_TYPE_VALIDATION.NAME.MAX_LENGTH,
    },
    description: {
      type: String,
    },
    createdByUserId: {
      type: Number,
    },
    status: {
      type: Number,
      enum: ShippingTypeStatusEnum,
      default: ShippingTypeStatusEnum.ACTIVE,
    },
    histories: {
      type: [HistorySchema],
      required: true,
      default: [],
    },
    deletedAt: {
      type: Date,
      required: false,
      default: null,
    },
  },
  {
    collection: 'shippingTypes',
    id: true,
    timestamps: true,
    collation: DEFAULT_COLLATION,
  },
);
