import {
  PURCHASED_ORDER_VALIDATE,
  PaymentStatusEnum,
  PurchasedOrderStatusEnum,
  ShippingStatusEnum,
} from '@components/purchased-order/purchased-order.constant';

import { DEFAULT_COLLATION } from '@constant/common';
import * as mongoose from 'mongoose';

export const AttributeValueSchema = new mongoose.Schema({
  attributeId: {
    type: mongoose.Schema.Types.ObjectId,
  },
  code: {
    type: String,
  },
  preValue: {
    type: String,
    required: false,
  },
  isNew: {
    type: Boolean,
    required: false,
  },
  value: {
    type: mongoose.Schema.Types.Mixed,
  },
});
export const PurchasedOrderSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      maxlength: PURCHASED_ORDER_VALIDATE.CODE.MAX_LENGTH,
    },
    name: {
      type: String,
      maxlength: PURCHASED_ORDER_VALIDATE.NAME.MAX_LENGTH,
    },
    templateId: {
      type: mongoose.Schema.Types.ObjectId,
    },
    description: {
      type: String,
    },
    createdBy: {
      type: Number,
    },
    status: {
      type: Number,
      enum: PurchasedOrderStatusEnum,
      default: PurchasedOrderStatusEnum.PENDING,
    },
    shippingStatus: {
      type: Number,
      enum: ShippingStatusEnum,
    },
    paymentStatus: {
      type: Number,
      enum: PaymentStatusEnum,
    },
    reason: {
      type: String,
    },
    attributeValues: {
      type: [AttributeValueSchema],
    },
    deletedAt: {
      type: Date,
      required: false,
      default: null,
    },
  },
  {
    collection: 'purchasedOrders',
    id: true,
    timestamps: true,
    collation: DEFAULT_COLLATION,
  },
);

PurchasedOrderSchema.virtual('purchasedOrderDetails', {
  ref: 'PurchasedOrderDetail',
  localField: '_id',
  foreignField: 'purchasedOrderId',
  justOne: false,
});

PurchasedOrderSchema.virtual('purchasedOrderHistories', {
  ref: 'PurchasedOrderHistory',
  localField: '_id',
  foreignField: 'purchasedOrderId',
  justOne: false,
});
