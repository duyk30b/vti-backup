import { BaseModel } from '@core/model/base.model';

export interface PurchasedOrderHistory extends BaseModel {
  userId: string;
  purchasedOrderId: string;
  actionType: number;
  note: string;
  description: string;
}
