import { BaseModel } from '@core/model/base.model';

export interface AttributeValue {
  attributeId: string;
  code: string;
  preValue: string;
  isNew: boolean;
  value: any;
}

export interface PurchasedOrder extends BaseModel {
  name: string;
  code: string;
  templateId: string;
  type: number;
  description: string;
  createdBy: number;
  createdAt: Date;
  status: number;
  shippingStatus: number;
  paymentStatus: number;
  attributeValues: AttributeValue[];
  deletedAt: Date;
}
