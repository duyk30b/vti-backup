import { BaseModel } from '@core/model/base.model';
import { AttributeValue } from './purchased-order.model';

export interface PurchasedOrderDetail extends BaseModel {
  purchasedOrderId: string;
  purchasedOrderVersionId: string;
  groupId: string;
  attributeValues: AttributeValue[];
}
