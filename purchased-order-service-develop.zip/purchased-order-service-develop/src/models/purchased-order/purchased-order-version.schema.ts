import { DEFAULT_COLLATION } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import * as mongoose from 'mongoose';
import { AttributeValue } from './purchased-order.model';
import { AttributeValueSchema } from './purchased-order.schema';

@Schema({
  timestamps: true,
  collection: 'purchasedOrderVersions',
  collation: DEFAULT_COLLATION,
})
export class PurchasedOrderVersionModel extends BaseModel {
  @Prop({
    type: String,
    required: false,
  })
  name: string;

  @Prop({
    type: String,
    required: false,
  })
  code: string;

  @Prop({
    type: Number,
    required: false,
  })
  createdBy: number;

  @Prop({
    type: mongoose.Schema.Types.ObjectId,
    required: false,
  })
  templateId: string;

  @Prop({
    type: mongoose.Schema.Types.ObjectId,
    required: false,
    ref: 'PurchasedOrder',
  })
  purchasedOrderId: string;

  @Prop({
    type: String,
    required: false,
  })
  description: string;

  @Prop({
    type: [AttributeValueSchema],
    require: true,
  })
  attributeValues: AttributeValue[];
}

export const PurchasedOrderVersionSchema = SchemaFactory.createForClass(
  PurchasedOrderVersionModel,
);

PurchasedOrderVersionSchema.virtual('purchasedOrderDetails', {
  ref: 'PurchasedOrderDetail',
  localField: '_id',
  foreignField: 'purchasedOrderVersionId',
  justOne: false,
});

PurchasedOrderVersionSchema.virtual('purchasedOrders', {
  ref: 'PurchasedOrder',
  localField: 'purchasedOrderId',
  foreignField: '_id',
  justOne: false,
});
