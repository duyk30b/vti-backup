import { DEFAULT_COLLATION } from '@constant/common';
import * as mongoose from 'mongoose';
import { AttributeValueSchema } from './purchased-order.schema';

export const PurchasedOrderDetailSchema = new mongoose.Schema(
  {
    templateId: {
      type: mongoose.Schema.Types.ObjectId,
    },
    purchasedOrderId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'PurchasedOrder',
    },
    purchasedOrderVersionId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'PurchasedOrderVersionModel',
    },
    groupId: {
      type: mongoose.Schema.Types.ObjectId,
    },
    attributeValues: {
      type: [AttributeValueSchema],
    },
  },
  {
    collection: 'purchasedOrderDetails',
    id: true,
    timestamps: true,
    collation: DEFAULT_COLLATION,
  },
);
