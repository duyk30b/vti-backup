import { PurchasedOrderActionTypeEnum } from '@components/purchased-order/purchased-order.constant';
import { DEFAULT_COLLATION } from '@constant/common';
import * as mongoose from 'mongoose';

export const PurchasedOrderHistorySchema = new mongoose.Schema(
  {
    userId: {
      type: Number,
    },
    purchasedOrderId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'PurchasedOrder',
    },
    actionType: {
      type: Number,
      enum: PurchasedOrderActionTypeEnum,
    },
    note: {
      type: String,
    },
    description: {
      type: String,
    },
  },
  {
    collection: 'purchasedOrderHistories',
    id: true,
    timestamps: true,
    collation: DEFAULT_COLLATION,
  },
);
