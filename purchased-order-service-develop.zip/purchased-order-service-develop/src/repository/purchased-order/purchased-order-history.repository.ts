import { PurchasedOrderHistoryRepositoryInterface } from '@components/purchased-order/interface/purchased-order-history.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { PurchasedOrderHistory } from 'src/models/purchased-order/purchased-order-history.model';

@Injectable()
export class PurchasedOrderHistoryRepository
  extends BaseAbstractRepository<PurchasedOrderHistory>
  implements PurchasedOrderHistoryRepositoryInterface
{
  constructor(
    @InjectModel('PurchasedOrderHistory')
    private readonly purchasedOrderHistory: Model<PurchasedOrderHistory>,
  ) {
    super(purchasedOrderHistory);
  }

  createDocument(request: any): PurchasedOrderHistory {
    const document = new this.purchasedOrderHistory();
    document.purchasedOrderId = request.purchasedOrderId;
    document.actionType = request.actionType;
    document.userId = request.userId;
    document.note = request.note;
    document.description = request.description;

    return document;
  }
}
