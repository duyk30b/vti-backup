import { PurchasedOrderDetailRepositoryInterface } from '@components/purchased-order/interface/purchased-order-detail.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { PurchasedOrderDetail } from 'src/models/purchased-order/purchased-order-detail.model';

@Injectable()
export class PurchasedOrderDetailRepository
  extends BaseAbstractRepository<PurchasedOrderDetail>
  implements PurchasedOrderDetailRepositoryInterface
{
  constructor(
    @InjectModel('PurchasedOrderDetail')
    private readonly purchasedOrderDetail: Model<PurchasedOrderDetail>,
  ) {
    super(purchasedOrderDetail);
  }

  createDocument(request: any): PurchasedOrderDetail {
    const document = new this.purchasedOrderDetail();
    document.purchasedOrderId = request.purchasedOrderId;
    document.purchasedOrderVersionId = request.purchasedOrderVersionId;
    document.groupId = request.groupId;
    document.attributeValues = request.attributeValues;

    return document;
  }

  async getDetail(id: string): Promise<any> {
    return this.purchasedOrderDetail
      .findById(id)
      .populate({
        path: 'requestOrderId',
      })
      .exec();
  }
}
