import { PurchasedOrderVersionRepositoryInterface } from '@components/purchased-order/interface/purchased-order-version.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { PurchasedOrderVersionModel } from 'src/models/purchased-order/purchased-order-version.schema';

@Injectable()
export class PurchasedOrderVersionRepository
  extends BaseAbstractRepository<PurchasedOrderVersionModel>
  implements PurchasedOrderVersionRepositoryInterface
{
  constructor(
    @InjectModel('PurchasedOrderVersionModel')
    private readonly purchasedOrderVersionModel: Model<PurchasedOrderVersionModel>,
  ) {
    super(purchasedOrderVersionModel);
  }

  createDocument(request: any): PurchasedOrderVersionModel {
    const document = new this.purchasedOrderVersionModel();
    document.purchasedOrderId = request.purchasedOrderId;
    document.description = request.description;
    document.code = request.code;
    document.createdBy = request.createdBy;
    document.attributeValues = request.attributeValues.map((attrValue) => ({
      attributeId: attrValue.id,
      value: attrValue.value,
      code: attrValue.code,
    }));
    return document;
  }

  async getDetail(condition: any): Promise<any> {
    const filter = condition?.id
      ? {
          ...condition,
          _id: condition?.id,
        }
      : { ...condition };

    return await this.purchasedOrderVersionModel
      .findOne({ ...filter, deletedAt: null })
      .lean()
      .populate([
        {
          path: 'purchasedOrders',
        },
        {
          path: 'purchasedOrderDetails',
        },
      ])
      .exec();
  }

  async getLastPurchasedOrderVersion(purchasedOrderId: string): Promise<any> {
    const filterObj = {
      purchasedOrderId,
    };
    return await this.purchasedOrderVersionModel
      .findOne(filterObj)
      .sort({ createdAt: 'DESC' })
      .exec();
  }
}
