import { PurchasedOrderRepositoryInterface } from '@components/purchased-order/interface/purchased-order.repository.interface';
import { PURCHASED_ORDER_FIELD_CODE } from '@components/purchased-order/purchased-order.constant';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { getRegexByValue } from '@utils/common';
import { isEmpty } from 'lodash';
import moment from 'moment';
import { Model } from 'mongoose';
import { PurchasedOrder } from 'src/models/purchased-order/purchased-order.model';

@Injectable()
export class PurchasedOrderRepository
  extends BaseAbstractRepository<PurchasedOrder>
  implements PurchasedOrderRepositoryInterface
{
  constructor(
    @InjectModel('PurchasedOrder')
    private readonly purchasedOrder: Model<PurchasedOrder>,
  ) {
    super(purchasedOrder);
  }

  createDocument(request: any): PurchasedOrder {
    const document = new this.purchasedOrder();
    document.code = request.code;
    document.name = request.name;
    document.templateId = request.templateId;
    document.description = request.description;
    document.status = request.status;
    document.attributeValues = request.attributeValues.map((attrValue) => ({
      attributeId: attrValue.id,
      value: attrValue.value,
      code: attrValue.code,
    }));
    document.createdBy = request.createdBy;

    return document;
  }

  updateDocument(document: PurchasedOrder, request: any): PurchasedOrder {
    document._id = request.id;
    document.name = request.name;
    document.templateId = request.templateId;
    document.description = request.description;
    document.attributeValues = request.attributeValues.map((attrValue) => ({
      attributeId: attrValue.id,
      value: attrValue.value,
      code: attrValue.code,
    }));
    document.createdBy = request.createdBy;

    return document;
  }

  async getList(request: any): Promise<any> {
    const { keyword, sort, filter, take, skip } = request;
    let sortObj = {};
    let filterObj = request.filterObj || {};
    let sortField = '';

    if (!isEmpty(keyword)) {
      filterObj = {
        ...filterObj,
        $or: [
          { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          { name: getRegexByValue(keyword) },
          {
            attributeValues: {
              $elemMatch: {
                value: { $regex: '.*' + keyword + '.*', $options: 'i' },
                code: PURCHASED_ORDER_FIELD_CODE.ORDER_CODE,
              },
            },
          },
        ],
      };
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        switch (item.column) {
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'status':
            filterObj = {
              ...filterObj,
              status: +item.text,
            };
            break;
          case 'shippingStatus':
            filterObj = {
              ...filterObj,
              shippingStatus: +item.text,
            };
            break;
          case 'paymentStatus':
            filterObj = {
              ...filterObj,
              paymentStatus: +item.text,
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order;
        switch (item.column) {
          case 'createdAt':
            sortObj = { createdAt: order };
            break;
          case 'updatedAt':
            sortObj = { updatedAt: order };
            break;
          default:
            sortObj = { customField: order };
            sortField = item.column;
            break;
        }
      });
    } else {
      sortObj = { createdAt: -1 };
    }

    const result = await this.purchasedOrder
      .aggregate([
        {
          $addFields: {
            customField: {
              $first: {
                $filter: {
                  input: '$attributeValues',
                  as: 'attributeValue',
                  cond: {
                    $eq: ['$$attributeValue.code', sortField],
                  },
                },
              },
            },
          },
        },
      ])
      .lookup({
        from: 'purchasedOrderDetails',
        localField: '_id',
        foreignField: 'purchasedOrderId',
        as: 'purchasedOrderDetails',
      })
      .lookup({
        from: 'purchasedOrderVersions',
        localField: '_id',
        foreignField: 'purchasedOrderId',
        as: 'purchasedOrderVersions',
      })
      .addFields({
        lastPurchasedOrderVersionId: {
          $arrayElemAt: ['$purchasedOrderVersions._id', -1],
        },
      })
      .lookup({
        from: 'purchasedOrderDetails',
        let: { lastVersionId: '$lastPurchasedOrderVersionId' },
        pipeline: [
          {
            $match: {
              $expr: {
                $eq: ['$purchasedOrderVersionId', '$$lastVersionId'],
              },
            },
          },
        ],
        as: 'purchasedOrderDetails',
      })
      .match({ ...filterObj, deletedAt: null })
      .sort(sortObj)
      .skip(skip)
      .limit(take)
      .exec();

    const total: number = await this.purchasedOrder
      .find({ ...filterObj, deletedAt: null })
      .countDocuments()
      .exec();

    return { data: result, count: total };
  }

  async getDetail(id: string, versionId?: string): Promise<any> {
    const filter = versionId ? { purchasedOrderVersionId: versionId } : {};
    return await this.purchasedOrder
      .findById(id)
      .lean()
      .populate([
        {
          path: 'purchasedOrderDetails',
          match: filter,
        },
        {
          path: 'purchasedOrderHistories',
          options: {
            sort: { createdAt: -1 },
          },
        },
      ])
      .exec();
  }

  async getLastPurchasedOrder(): Promise<any> {
    const filterObj = {};
    return await this.purchasedOrder
      .findOne(filterObj)
      .sort({ createdAt: 'DESC' })
      .exec();
  }
}
