import { GetShippingTypeDetailRequestDto } from '@components/shipping-type/dto/request/get-shipping-type-detail.request.dto';
import { ShippingTypeRepositoryInterface } from '@components/shipping-type/interface/shipping-type.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { getRegexByValue } from '@utils/common';
import { isEmpty } from 'lodash';
import moment from 'moment';
import { Model, Types } from 'mongoose';
import { ShippingTypeModel } from 'src/models/shipping-type/shipping-type.model';

@Injectable()
export class ShippingTypeRepository
  extends BaseAbstractRepository<ShippingTypeModel>
  implements ShippingTypeRepositoryInterface
{
  constructor(
    @InjectModel('ShippingTypeModel')
    private readonly shippingTypeModel: Model<ShippingTypeModel>,
  ) {
    super(shippingTypeModel);
  }

  createDocument(request: any): ShippingTypeModel {
    const newDocument = new this.shippingTypeModel();
    if (request.id) newDocument._id = request.id;
    newDocument.code = request.code;
    newDocument.name = request.name;
    newDocument.description = request.description;
    newDocument.createdByUserId = request['userId'];
    newDocument.histories = [];

    return newDocument;
  }

  updateDocument(document: ShippingTypeModel, request: any): ShippingTypeModel {
    document.name = request.name;
    document.description = request.description;

    return document;
  }

  async getDetail(request: GetShippingTypeDetailRequestDto): Promise<any> {
    const result = await this.shippingTypeModel
      .aggregate()
      .match({ _id: new Types.ObjectId(request.id) })
      .addFields({
        histories: {
          $sortArray: {
            input: '$histories',
            sortBy: { createdAt: -1 },
          },
        },
      })
      .exec();
    return result[0];
  }

  async getList(request: any): Promise<any> {
    const { keyword, sort, filter, take, skip } = request;
    let sortObj = {};
    let filterObj = request.filterObj || {};
    let sortField = '';

    if (!isEmpty(keyword)) {
      filterObj = {
        ...filterObj,
        $or: [
          { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          { name: getRegexByValue(keyword) },
        ],
      };
    }
    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const filterByKeyword = getRegexByValue(item.text);
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: filterByKeyword,
            };
            break;
          case 'name':
            filterObj = {
              ...filterObj,
              name: filterByKeyword,
            };
            break;
          case 'status':
            filterObj = {
              ...filterObj,
              status: +item.text,
            };
            break;
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order === 'ASC' ? 1 : -1;
        switch (item.column) {
          case 'code':
            sortObj = { code: order };
            break;
          case 'name':
            sortObj = { name: order };
            break;
          case 'createdAt':
            sortObj = { createdAt: order };
            break;
          case 'updatedAt':
            sortObj = { updatedAt: order };
            break;
          default:
            sortObj = { customField: order };
            sortField = item.column;
            break;
        }
      });
    } else {
      sortObj = { createdAt: -1 };
    }

    const result = await this.shippingTypeModel
      .aggregate()
      .match(filterObj)
      .sort(sortObj)
      .skip(skip)
      .limit(take)
      .exec();

    const total: number = await this.shippingTypeModel
      .find({ ...filterObj, deletedAt: null })
      .countDocuments()
      .exec();

    return { data: result, count: total };
  }
}
