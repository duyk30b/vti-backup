import { ConfigService } from '@config/config.service';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ItemController } from './item.controller';
import { ItemService } from './item.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
  ],
  controllers: [ItemController],
})
export class ItemModule {}
