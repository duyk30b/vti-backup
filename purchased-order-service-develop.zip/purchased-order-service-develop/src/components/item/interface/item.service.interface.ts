import { ItemResponseDto } from '../dto/response/item.dto.response';

export interface ItemServiceInterface {
  getItems(itemIds: any[]): Promise<ItemResponseDto[]>;
  getItemByIds(itemIds: any[], serilize?: boolean): Promise<any>;
  getItemByCodes(codes: string[]): Promise<any[]>;
  getItemsByCode(itemCode: string): Promise<any>;
  getCurrencyUnitsByIds(ids: number[], serialize?: boolean): Promise<any>;
}
