import { NATS_ITEM } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { plainToInstance } from 'class-transformer';
import { keyBy } from 'lodash';
import { ItemResponseDto } from './dto/response/item.dto.response';
import { ItemServiceInterface } from './interface/item.service.interface';

@Injectable()
export class ItemService implements ItemServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}
  async getItems(itemIds: any[]): Promise<ItemResponseDto[]> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_items_by_ids`,
      {
        itemIds,
        basicInfor: true,
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    const items = response.data.map((item) => ({
      ...item,
      itemUnit: item.itemUnitName,
    }));
    const dataReturn = plainToInstance(ItemResponseDto, <any[]>items, {
      excludeExtraneousValues: true,
    });

    return dataReturn;
  }
  async getItemByIds(itemIds: number[], serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_items_by_ids`,
      {
        itemIds,
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    const serilizeItems = {};
    if (serilize) {
      response.data.forEach((item) => {
        serilizeItems[item.id] = item;
      });

      return serilizeItems;
    }
    return response.data;
  }
  async getItemStock(itemIds: number[], serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_warehouse_available_stocks`,
      {
        items: itemIds.map((id) => ({ itemId: id })),
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    const serilizeItems = {};
    if (serilize) {
      response.data.forEach((item) => {
        serilizeItems[item.itemId] = item;
      });

      return serilizeItems;
    }
    return response.data;
  }

  async getItemByCodes(codes: string[]): Promise<any[]> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_by_codes`,
      {
        codes: codes,
      },
    );

    if (
      response.statusCode !== ResponseCodeEnum.SUCCESS ||
      response.data.length === 0
    ) {
      return [];
    }

    return response.data;
  }
  async getItemsByCode(itemCode: string): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_list`,
      {
        filter: [{ column: 'code', text: itemCode }],
      },
    );

    if (
      response.statusCode !== ResponseCodeEnum.SUCCESS ||
      response.data.items.length === 0
    ) {
      return [];
    }

    return response.data.items;
  }

  async getCurrencyUnitsByIds(
    ids: number[],
    serialize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_currency_units_by_ids`,
      {
        ids,
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    if (serialize) {
      return keyBy(response.data, 'id');
    }

    return response.data;
  }
}
