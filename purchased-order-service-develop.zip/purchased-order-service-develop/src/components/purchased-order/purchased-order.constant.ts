export const PURCHASED_ORDER_VALIDATE = {
  CODE: {
    MAX_LENGTH: 50,
  },
  NAME: {
    MAX_LENGTH: 255,
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
};

export enum AreaEnum {
  COMMON = 0,
  DETAIL = 1,
}

export enum PurchasedOrderStatusEnum {
  PENDING = 0,
  CONFIRMED = 1,
  REJECTED = 2,
  DRAFT = 3,
  WAIT_DELIVER = 4,
  IN_DELIVERING = 5,
  COMPLETED = 6,
  CANCELED = 7,
}

export enum PurchasedOrderShippingStatusEnum {
  PENDING = 0,
  CONFIRMED = 1,
  WAIT_DELIVER = 2,
  IN_DELIVERING = 3,
  DELIVERED = 4,
}

export enum PurchasedOrderPaymentStatusEnum {
  PENDING = 0,
  CONFIRMED = 1,
  UNPAID = 2,
  DRAFT = 3,
}

export const PURCHASED_ORDER_STATUS_CAN_UPDATE = [
  PurchasedOrderStatusEnum.REJECTED,
  PurchasedOrderStatusEnum.DRAFT,
];

export const PURCHASED_ORDER_STATUS_CAN_DELETE = [
  PurchasedOrderStatusEnum.PENDING,
  PurchasedOrderStatusEnum.REJECTED,
  PurchasedOrderStatusEnum.DRAFT,
];

export const PURCHASED_ORDER_STATUS_CAN_CONFIRM = [
  PurchasedOrderStatusEnum.PENDING,
];

export const PURCHASED_ORDER_STATUS_CAN_REJECT = [
  PurchasedOrderStatusEnum.PENDING,
];

export const PURCHASED_ORDER_STATUS_CAN_REQUEST_CONFIRM = [
  PurchasedOrderStatusEnum.DRAFT,
];

export const PURCHASED_ORDER_STATUS_CAN_ORDER = [
  PurchasedOrderStatusEnum.CONFIRMED,
];

export const PURCHASED_ORDER_STATUS_CAN_COMPLETE = [
  PurchasedOrderStatusEnum.IN_DELIVERING,
];

export const PURCHASED_ORDER_STATUS_CAN_CANCEL = [
  PurchasedOrderStatusEnum.CONFIRMED,
  PurchasedOrderStatusEnum.WAIT_DELIVER,
  PurchasedOrderStatusEnum.IN_DELIVERING,
  PurchasedOrderStatusEnum.REJECTED,
];

export const PURCHASED_ORDER_FIELD_CODE = {
  STATUS: 'mesxStatus',
  ORDER_AT: 'mesxOrderAt',
  ORDER_CODE: 'mesxOrderCode',
  ORDER_NAME: 'mesxOrderName',
  CURRENCY_UNIT_ID: 'mesxCurrencyUnitId',
  EXCHANGE_RATE: 'mesxExchangeRate',
  ORDER_TYPE: 'mesxOrderType',
  PURCHASE_STAFF_ID: 'mesxPurchaseStaffId',
  VENDOR_ID: 'mesxVendorId',
  PHONE_NUMBER: 'mesxPhoneNumber',
  TAX_NUMBER: 'mesxTaxNumber',
  PURCHASE_PRICE: 'mesxPurchasePrice',
  PO_QUANTITY: 'mesxPOQuantity',
  RECEIVER_PHONE_NUMBER: 'mesxReceiverPhoneNumber',
  PLAN_DELIVERY_AT: 'mesxPlanDeliveryAt',
  DISCOUNT: 'mesxDiscount',
  TOTAL_AMOUNT: 'mesxTotalAmount',
  ONE_TIME_DELIVERY: 'mesxOneTimeDelivery',
  RECEIVER: 'mesxReceiver',
  SHIPPING_METHOD_ID: 'mesxShippingMethodId',
  ADDRESS: 'mesxAddress',
  DELIVER_AT: 'mesxDeliverAt',
  PAY_AT: 'mesxPayAt',
  PAYMENT_METHOD_ID: 'mesxPaymentMethodId',
  PAYMENT_RATE: 'mesxPaymentRate',
  TOTAL_PAYMENT_AMOUNT: 'mesxTotalPaymentAmount',
  USER_ACCOUNT: 'mesxUserAccount',
  DESCRIPTION: 'mesxDescription',
  FILES: 'mesxFiles',
  NOTE: 'mesxNote',

  //detail
  ITEM_ID: 'mesxItemId',
  //invoice
  CREATED_AT: 'mesxCreatedAt',
  UPDATE_BY_USER_ID: 'mesxUpdateByUserId',
  INVOICE_CODE: 'mesxInvoiceCode',
  INVOICE_VALUE: 'mesxInvoiceValue',
};

export const GEN_CODE_PO_PROPS = {
  PREFIX: 'PO',
  DATE_FORMAT: 'DDMMYY',
  DEFAULT_CODE: '0001',
};

export const PURCHASED_ORDER_ATTRIBUTE_GROUP = {
  ITEM: 'GR0003',
  DELIVERY: 'GR0004',
  PAYMENT: 'GR0005',
  INVOICE: 'GR0006',
};

export enum PurchasedOrderActionTypeEnum {
  CREATE = 0,
  REQUEST_CONFIRM = 1,
  CONFIRM = 2,
  UPDATE = 3,
  REJECT = 4,
  ORDER = 5,
  COMPLETE = 6,
  DELETE = 7,
  CANCEL = 8,
  PAY_INVOICE = 9,
}

export enum PurchasedOrderTypeEnum {
  DOMESTIC = 0,
  IMPORT = 1,
}

export enum PaymentStatusEnum {
  UNPAID = 0,
  PARTIAL = 1,
  FULL = 2,
}

export enum ShippingStatusEnum {
  PENDING = 0,
  IN_PROGRESS = 1,
  COMPLETE = 2,
}

export const ONE_PERCENT = 0.01;

export const FIRST_VERSION_CODE = '000';
