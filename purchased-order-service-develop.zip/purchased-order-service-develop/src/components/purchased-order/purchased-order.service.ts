import { AttributeServiceInterface } from '@components/attribute/interface/attribute.service.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { DATA_TYPE_ENUM, REQUIRED_ENUM } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/mongoose';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import {
  filter,
  find,
  first,
  flatMap,
  isEmpty,
  keyBy,
  map,
  omit,
  orderBy,
  uniq,
} from 'lodash';
import { Connection } from 'mongoose';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { PurchasedOrderServiceInterface } from './interface/purchased-order.service.interface';
import {
  AreaEnum,
  FIRST_VERSION_CODE,
  GEN_CODE_PO_PROPS,
  ONE_PERCENT,
  PURCHASED_ORDER_ATTRIBUTE_GROUP,
  PURCHASED_ORDER_FIELD_CODE,
  PURCHASED_ORDER_STATUS_CAN_CANCEL,
  PURCHASED_ORDER_STATUS_CAN_COMPLETE,
  PURCHASED_ORDER_STATUS_CAN_CONFIRM,
  PURCHASED_ORDER_STATUS_CAN_DELETE,
  PURCHASED_ORDER_STATUS_CAN_ORDER,
  PURCHASED_ORDER_STATUS_CAN_REJECT,
  PURCHASED_ORDER_STATUS_CAN_REQUEST_CONFIRM,
  PaymentStatusEnum,
  PurchasedOrderActionTypeEnum,
  PurchasedOrderStatusEnum,
  ShippingStatusEnum,
  PURCHASED_ORDER_STATUS_CAN_UPDATE,
} from './purchased-order.constant';
import { CreatePurchasedOrderFormData } from './dto/request/create-purchased-order.request.dto';
import {
  AttributeValue,
  PurchasedOrder,
} from 'src/models/purchased-order/purchased-order.model';
import { UpdatePurchasedOrderFormData } from './dto/request/update-purchased-order.request.dto';
import { PurchasedOrderRepositoryInterface } from './interface/purchased-order.repository.interface';
import { PurchasedOrderDetailRepositoryInterface } from './interface/purchased-order-detail.repository.interface';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { GetPurchasedOrderDetailRequestDto } from './dto/request/get-purchased-order-detail.request.dto';
import { PurchasedOrderResponseDto } from './dto/response/purchased-order.response.dto';
import { GetListPurchasedOrderRequestDto } from './dto/request/get-list-purchased-order.request.dto';
import { getRegexByValue } from '@utils/common';
import * as moment from 'moment';
import { FileServiceInterface } from '@components/file/interface/file.service.interface';
import { PurchasedOrderHistoryRepositoryInterface } from './interface/purchased-order-history.repository.interface';
import { ShippingTypeRepositoryInterface } from '@components/shipping-type/interface/shipping-type.repository.interface';
import { PaymentTypeRepositoryInterface } from '@components/payment-type/interface/payment-type.repository.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { minus, mul, plus } from '@utils/helper';
import { GetPurchasedOrderListResponseDto } from './dto/response/get-list-purchased-order.response.dto';
import { ChangePurchasedOrderStatusRequestDto } from './dto/request/change-purchased-order-status.request.dto';
import { SaleServiceInterface } from '@components/sale/interface/sale.service.interface';
import { PurchasedOrderVersionRepositoryInterface } from './interface/purchased-order-version.repository.interface';
import { GetPurchasedOrderVersionDetailRequestDto } from './dto/request/get-purchased-order-version-detail.request.dto';
import { GetListPurchasedOrderVersion } from './dto/response/get-list-purchased-order-version.response.dto';

@Injectable()
export class PurchasedOrderService implements PurchasedOrderServiceInterface {
  constructor(
    @Inject('PurchasedOrderRepositoryInterface')
    protected readonly purchasedOrderRepository: PurchasedOrderRepositoryInterface,

    @Inject('PurchasedOrderDetailRepositoryInterface')
    protected readonly purchasedOrderDetailRepository: PurchasedOrderDetailRepositoryInterface,

    @Inject('PurchasedOrderHistoryRepositoryInterface')
    protected readonly purchasedOrderHistoryRepository: PurchasedOrderHistoryRepositoryInterface,

    @Inject('ShippingTypeRepositoryInterface')
    protected readonly shippingTypeRepository: ShippingTypeRepositoryInterface,

    @Inject('PurchasedOrderVersionRepositoryInterface')
    protected readonly purchasedOrderVersionRepository: PurchasedOrderVersionRepositoryInterface,

    @Inject('PaymentTypeRepositoryInterface')
    protected readonly paymentTypeRepository: PaymentTypeRepositoryInterface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('SaleServiceInterface')
    protected readonly saleService: SaleServiceInterface,

    @Inject('FileServiceInterface')
    protected readonly fileService: FileServiceInterface,

    private readonly i18n: I18nRequestScopeService,

    @InjectConnection()
    private readonly connection: Connection,
    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('AttributeServiceInterface')
    protected readonly attributeService: AttributeServiceInterface,
  ) {}

  async create(request: CreatePurchasedOrderFormData): Promise<any> {
    const { data, userId } = request;
    const { attributeValues, templateId, purchasedOrderDetails, isDraft } =
      data;

    const codeExist = await this.purchasedOrderRepository.findOneByCondition({
      attributeValues: {
        $elemMatch: {
          code: PURCHASED_ORDER_FIELD_CODE.ORDER_CODE,
          value: attributeValues.find(
            (attributeValue) =>
              attributeValue.code === PURCHASED_ORDER_FIELD_CODE.ORDER_CODE,
          ).value,
        },
      },
    });
    if (codeExist)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_EXIST'))
        .build();

    const currencyUnitId = find(
      attributeValues,
      (attValue) =>
        attValue.code === PURCHASED_ORDER_FIELD_CODE.CURRENCY_UNIT_ID,
    )?.value;

    const currencyUnits = await this.itemService.getCurrencyUnitsByIds([
      currencyUnitId,
    ]);
    if (isEmpty(currencyUnits))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CURRENCY_UNIT_NOT_FOUND'))
        .build();

    const vendorId = find(
      attributeValues,
      (attValue) => attValue.code === PURCHASED_ORDER_FIELD_CODE.VENDOR_ID,
    )?.value;

    const vendors = await this.saleService.getVendorsByIds([vendorId]);
    if (isEmpty(vendors))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.VENDOR_NOT_FOUND'))
        .build();

    const detailAttributeValues = purchasedOrderDetails.flatMap(
      (detailRequestOrder) =>
        detailRequestOrder.attributeValues.map((attributeValue) => ({
          ...attributeValue,
          groupId: detailRequestOrder.groupId,
          area: AreaEnum.DETAIL,
        })),
    );

    const attributeRequests = [
      ...attributeValues.map((attributeValue) => ({
        ...attributeValue,
        groupId: null,
        area: AreaEnum.COMMON,
      })),
      ...detailAttributeValues,
    ];

    if (!isEmpty(attributeRequests)) {
      const resultValidateAttributes = await this.validateAttributes(
        templateId,
        attributeRequests,
      );

      if (resultValidateAttributes.code !== ResponseCodeEnum.SUCCESS) {
        return resultValidateAttributes;
      }
    }

    const purchasedOrderEntity = this.purchasedOrderRepository.createDocument({
      ...data,
      status: isDraft
        ? PurchasedOrderStatusEnum.DRAFT
        : PurchasedOrderStatusEnum.PENDING,
      createdBy: userId,
    });

    return await this.save(purchasedOrderEntity, request);
  }

  async update(request: UpdatePurchasedOrderFormData): Promise<any> {
    const { data, userId } = request;
    const { attributeValues, templateId, purchasedOrderDetails, id } = data;

    const currencyUnitId = find(
      attributeValues,
      (attValue) =>
        attValue.code === PURCHASED_ORDER_FIELD_CODE.CURRENCY_UNIT_ID,
    )?.value;

    const currencyUnits = await this.itemService.getCurrencyUnitsByIds([
      currencyUnitId,
    ]);
    if (isEmpty(currencyUnits))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CURRENCY_UNIT_NOT_FOUND'))
        .build();

    const vendorId = find(
      attributeValues,
      (attValue) => attValue.code === PURCHASED_ORDER_FIELD_CODE.VENDOR_ID,
    )?.value;

    const vendors = await this.saleService.getVendorsByIds([vendorId]);
    if (isEmpty(vendors))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.VENDOR_NOT_FOUND'))
        .build();

    const detailAttributeValues = purchasedOrderDetails.flatMap(
      (detailRequestOrder) =>
        detailRequestOrder.attributeValues.map((attributeValue) => ({
          ...attributeValue,
          groupId: detailRequestOrder.groupId,
          area: AreaEnum.DETAIL,
        })),
    );

    const attributeRequests = [
      ...attributeValues.map((attributeValue) => ({
        ...attributeValue,
        groupId: null,
        area: AreaEnum.COMMON,
      })),
      ...detailAttributeValues,
    ];

    if (!isEmpty(attributeRequests)) {
      const resultValidateAttributes = await this.validateAttributes(
        templateId,
        attributeRequests,
      );

      if (resultValidateAttributes.code !== ResponseCodeEnum.SUCCESS) {
        return resultValidateAttributes;
      }
    }

    const purchasedOrder = await this.purchasedOrderRepository.getDetail(id);
    if (!purchasedOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!PURCHASED_ORDER_STATUS_CAN_UPDATE.includes(purchasedOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }
    const purchasedOrderUpdateEntity =
      this.purchasedOrderRepository.updateDocument(purchasedOrder, {
        ...data,
      });
    purchasedOrderUpdateEntity.status = PurchasedOrderStatusEnum.DRAFT;
    return await this.save(purchasedOrderUpdateEntity, request, true);
  }

  public async delete(request: IdParamMongoDto): Promise<any> {
    try {
      const { id, userId } = request;
      const purchasedOrder = await this.purchasedOrderRepository.findOneById(
        id,
      );
      if (isEmpty(purchasedOrder)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }
      const statusAttribute = purchasedOrder.attributeValues.find(
        (attributeValue) =>
          attributeValue.code === PURCHASED_ORDER_FIELD_CODE.STATUS,
      );
      const status = statusAttribute ? +statusAttribute.value : null;
      if (!PURCHASED_ORDER_STATUS_CAN_DELETE.includes(status)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
          .build();
      }

      const purchasedOrderHistoryEntity =
        await this.purchasedOrderHistoryRepository.createDocument({
          purchasedOrderId: purchasedOrder._id,
          userId: userId,
          actionType: PurchasedOrderActionTypeEnum.DELETE,
          description: await this.i18n.translate(
            'error.DELETE_PURCHASED_ORDER',
          ),
        });

      await this.purchasedOrderHistoryRepository.create(
        purchasedOrderHistoryEntity,
      );

      await this.purchasedOrderRepository.softDelete(id);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  public async getDetail(
    request: GetPurchasedOrderDetailRequestDto,
  ): Promise<any> {
    const { id, versionId } = request;
    let purchaseOrderVersionId;
    if (versionId) {
      purchaseOrderVersionId = versionId;
    }
    const poVersions =
      await this.purchasedOrderVersionRepository.findAllByCondition({
        purchasedOrderId: id,
      });
    const orderVersionList = orderBy(poVersions, 'createdAt', 'desc');
    const lastPOVersion = first(orderVersionList);
    if (!isEmpty(lastPOVersion) && !versionId) {
      purchaseOrderVersionId = lastPOVersion._id.toString();
    }

    if (!purchaseOrderVersionId) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const currentPurchasedOrderVersion = find(
      poVersions,
      (poVersion) => poVersion._id.toString() === purchaseOrderVersionId,
    );

    const purchasedOrder = await this.purchasedOrderRepository.getDetail(
      id,
      purchaseOrderVersionId,
    );

    if (!isEmpty(currentPurchasedOrderVersion)) {
      purchasedOrder.attributeValues =
        currentPurchasedOrderVersion.attributeValues;
    }

    if (isEmpty(purchasedOrder)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const flatAttributeValues = [
      ...purchasedOrder.attributeValues,
      ...flatMap(
        purchasedOrder.purchasedOrderDetails,
        (poDetail) => poDetail.attributeValues,
      ),
    ];

    const [
      currencyUnitIds,
      purchaseStaffIds,
      shippingMethodIds,
      paymentMethodIds,
      vendorIds,
      itemIds,
      invoiceUpdateUserIds,
    ] = this.getValueOfAttributesByCode(flatAttributeValues, [
      PURCHASED_ORDER_FIELD_CODE.CURRENCY_UNIT_ID,
      PURCHASED_ORDER_FIELD_CODE.PURCHASE_STAFF_ID,
      PURCHASED_ORDER_FIELD_CODE.SHIPPING_METHOD_ID,
      PURCHASED_ORDER_FIELD_CODE.PAYMENT_METHOD_ID,
      PURCHASED_ORDER_FIELD_CODE.VENDOR_ID,
      PURCHASED_ORDER_FIELD_CODE.ITEM_ID,
      PURCHASED_ORDER_FIELD_CODE.UPDATE_BY_USER_ID,
    ]);

    const poHistoryUserIds = uniq(
      map(purchasedOrder?.purchasedOrderHistories, 'userId'),
    );

    const userIds = uniq([
      ...purchaseStaffIds,
      ...invoiceUpdateUserIds,
      purchasedOrder.createdBy,
      ...poHistoryUserIds,
    ]);
    const poAttributeGroupCodes = Object.values(
      PURCHASED_ORDER_ATTRIBUTE_GROUP,
    );

    const [
      serializedUser,
      serializedCurrencyUnit,
      shippingMethods,
      poAttributeGroups,
      serializedItem,
      paymentMethods,
      serializedVendor,
    ] = await Promise.all([
      this.userService.getUserByIds(userIds, true),
      this.itemService.getCurrencyUnitsByIds(currencyUnitIds, true),
      this.shippingTypeRepository.findAllByCondition({
        _id: { $in: shippingMethodIds },
      }),
      this.attributeService.getAttributeGroupsByCodes(poAttributeGroupCodes),
      this.itemService.getItemByIds(itemIds, true),
      this.paymentTypeRepository.findAllByCondition({
        _id: { $in: paymentMethodIds },
      }),
      this.saleService.getVendorsByIds(vendorIds, true),
    ]);

    const serializedShippingMethod = keyBy(shippingMethods, '_id');
    const serializedPaymentMethod = keyBy(paymentMethods, '_id');

    const beautifiedData = first(this.beautifyPurchasedOrder([purchasedOrder]));

    const groupedData = beautifiedData?.purchasedOrderDetails?.reduce(
      (result, item) => {
        const groupId = item.groupId.toString();

        const existingGroup = result.find((group) => group.groupId === groupId);
        const groupInfo = find(
          poAttributeGroups,
          (attributeGroup) => attributeGroup._id === groupId,
        );

        if (existingGroup) {
          existingGroup.details.push(omit(item, 'groupId'));
        } else {
          result.push({
            groupId,
            code: groupInfo?.code,
            name: groupInfo?.name,
            details: [omit(item, 'groupId')],
          });
        }

        return result;
      },
      [],
    );

    const serializedGroupData = keyBy(groupedData, 'code');

    const purchasedOrderItemDetails = serializedGroupData[
      PURCHASED_ORDER_ATTRIBUTE_GROUP.ITEM
    ]?.details?.map((detail) => {
      const itemId = detail[PURCHASED_ORDER_FIELD_CODE.ITEM_ID].value;
      return {
        itemId,
        item: serializedItem[itemId],
        quantity: detail[PURCHASED_ORDER_FIELD_CODE.PO_QUANTITY]?.value,
        purchasePrice: detail[PURCHASED_ORDER_FIELD_CODE.PURCHASE_PRICE]?.value,
        discount: detail[PURCHASED_ORDER_FIELD_CODE.DISCOUNT]?.value,
      };
    });

    const purchasedOrderDeliveryDetails = serializedGroupData[
      PURCHASED_ORDER_ATTRIBUTE_GROUP.DELIVERY
    ]?.details?.map((detail) => {
      const itemId = detail[PURCHASED_ORDER_FIELD_CODE.ITEM_ID]?.value;
      return {
        itemId,
        item: serializedItem[itemId],
        planDeliveryAt:
          detail[PURCHASED_ORDER_FIELD_CODE.PLAN_DELIVERY_AT]?.value,
        description: detail[PURCHASED_ORDER_FIELD_CODE.DESCRIPTION]?.value,
      };
    });

    const purchasedOrderPaymentDetails = serializedGroupData[
      PURCHASED_ORDER_ATTRIBUTE_GROUP.PAYMENT
    ]?.details?.map((detail) => {
      const paymentMethodId =
        detail[PURCHASED_ORDER_FIELD_CODE.PAYMENT_METHOD_ID]?.value;
      return {
        paymentMethodId,
        paymentMethod: serializedPaymentMethod[paymentMethodId],
        planPayAt: detail[PURCHASED_ORDER_FIELD_CODE.PAY_AT]?.value,
        paymentRate: detail[PURCHASED_ORDER_FIELD_CODE.PAYMENT_RATE]?.value,
        totalPaymentAmount:
          detail[PURCHASED_ORDER_FIELD_CODE.TOTAL_PAYMENT_AMOUNT]?.value,
        description: detail[PURCHASED_ORDER_FIELD_CODE.DESCRIPTION]?.value,
        userAccount: detail[PURCHASED_ORDER_FIELD_CODE.USER_ACCOUNT]?.value,
      };
    });

    const purchasedOrderInvoiceDetails = serializedGroupData[
      PURCHASED_ORDER_ATTRIBUTE_GROUP.INVOICE
    ]?.details?.map((detail) => {
      const updateByUserId =
        detail[PURCHASED_ORDER_FIELD_CODE.UPDATE_BY_USER_ID]?.value;
      return {
        updatedBy: serializedUser[updateByUserId],
        createdAt: detail[PURCHASED_ORDER_FIELD_CODE.CREATED_AT]?.value,
        invoiceCode: detail[PURCHASED_ORDER_FIELD_CODE.INVOICE_CODE]?.value,
        invoiceValue: detail[PURCHASED_ORDER_FIELD_CODE.INVOICE_VALUE]?.value,
        description: detail[PURCHASED_ORDER_FIELD_CODE.DESCRIPTION]?.value,
      };
    });

    const purchasedOrderHistories =
      purchasedOrder?.purchasedOrderHistories?.map((historyDetail) => {
        const createdByUserId = historyDetail.userId;
        return {
          createdBy: serializedUser[createdByUserId],
          ...historyDetail,
        };
      });

    const formatPurchasedOrder = {
      ...beautifiedData,
      status: beautifiedData.status,
      createdBy: serializedUser[purchasedOrder.createdBy],
      currencyUnit:
        serializedCurrencyUnit[
          beautifiedData[PURCHASED_ORDER_FIELD_CODE.CURRENCY_UNIT_ID]?.value
        ],
      vendor:
        serializedVendor[
          beautifiedData[PURCHASED_ORDER_FIELD_CODE.VENDOR_ID]?.value
        ],
      orderedAt: beautifiedData[PURCHASED_ORDER_FIELD_CODE.ORDER_AT]?.value,
      code: beautifiedData[PURCHASED_ORDER_FIELD_CODE.ORDER_CODE]?.value,
      name: beautifiedData[PURCHASED_ORDER_FIELD_CODE.ORDER_NAME]?.value,
      orderType: beautifiedData[PURCHASED_ORDER_FIELD_CODE.ORDER_TYPE]?.value,
      purchaseStaff:
        serializedUser[
          beautifiedData[PURCHASED_ORDER_FIELD_CODE.PURCHASE_STAFF_ID]?.value
        ],
      note: beautifiedData[PURCHASED_ORDER_FIELD_CODE.NOTE]?.value,
      oneTimeDelivery:
        beautifiedData[PURCHASED_ORDER_FIELD_CODE.ONE_TIME_DELIVERY]?.value,
      deliverAt: beautifiedData[PURCHASED_ORDER_FIELD_CODE.DELIVER_AT]?.value,
      receiver: beautifiedData[PURCHASED_ORDER_FIELD_CODE.RECEIVER]?.value,
      receiverPhoneNumber:
        beautifiedData[PURCHASED_ORDER_FIELD_CODE.RECEIVER_PHONE_NUMBER]?.value,
      shippingMethod:
        serializedShippingMethod[
          beautifiedData[PURCHASED_ORDER_FIELD_CODE.SHIPPING_METHOD_ID]?.value
        ],
      address: beautifiedData[PURCHASED_ORDER_FIELD_CODE.ADDRESS]?.value,
      purchasedOrderItemDetails,
      purchasedOrderDeliveryDetails,
      purchasedOrderPaymentDetails,
      purchasedOrderInvoiceDetails,
      purchasedOrderHistories,
    };

    const returnData = plainToInstance(
      PurchasedOrderResponseDto,
      { ...formatPurchasedOrder },
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder(returnData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(request: GetListPurchasedOrderRequestDto): Promise<any> {
    const { filter, sort } = request;
    let filterObj = {};
    let sortObj = {};

    const filterVendorName = filter?.find(
      (item) => item.column === 'vendorName',
    )?.text;

    let filterVendorIds = [];
    if (!isEmpty(filterVendorName)) {
      filterVendorIds = await this.saleService.getVendorsByNameKeyword(
        filterVendorName,
        true,
      );

      if (isEmpty(filterVendorIds)) {
        return new ResponseBuilder({
          items: [],
          meta: { total: 0, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    const purchaseStaffName = filter?.find(
      (item) => item.column === 'purchaseStaffName',
    )?.text;

    let filterPurchaseStaffIds = [];
    if (!isEmpty(purchaseStaffName)) {
      filterPurchaseStaffIds = await this.userService.getUsersByNameKeyword(
        purchaseStaffName,
        true,
      );

      if (isEmpty(filterPurchaseStaffIds)) {
        return new ResponseBuilder({
          items: [],
          meta: { total: 0, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'orderAt':
            filterObj = {
              ...filterObj,
              attributeValues: {
                $elemMatch: {
                  value: {
                    $gte: moment(item.text.split('|')[0])
                      .startOf('day')
                      .toDate(),
                    $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
                  },
                  code: PURCHASED_ORDER_FIELD_CODE.ORDER_AT,
                },
              },
            };
            break;
          case 'code':
            filterObj = {
              ...filterObj,
              attributeValues: {
                $elemMatch: {
                  value: getRegexByValue(item.text),
                  code: PURCHASED_ORDER_FIELD_CODE.ORDER_CODE,
                },
              },
            };
            break;
          case 'vendorId':
            filterObj = {
              ...filterObj,
              attributeValues: {
                $elemMatch: {
                  value: +value,
                  code: PURCHASED_ORDER_FIELD_CODE.VENDOR_ID,
                },
              },
            };
            break;
          case 'vendorName':
            filterObj = {
              ...filterObj,
              attributeValues: {
                $elemMatch: {
                  value: { $in: filterVendorIds },
                  code: PURCHASED_ORDER_FIELD_CODE.VENDOR_ID,
                },
              },
            };
            break;
          case 'purchaseStaffName':
            filterObj = {
              ...filterObj,
              attributeValues: {
                $elemMatch: {
                  value: { $in: filterPurchaseStaffIds },
                  code: PURCHASED_ORDER_FIELD_CODE.PURCHASE_STAFF_ID,
                },
              },
            };
            break;
          case 'purchasedStaffId':
            filterObj = {
              ...filterObj,
              attributeValues: {
                $elemMatch: {
                  value: +item.text,
                  code: PURCHASED_ORDER_FIELD_CODE.PURCHASE_STAFF_ID,
                },
              },
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        switch (item.column) {
          case 'status':
            sortObj = {
              [`attributeValues.${PURCHASED_ORDER_FIELD_CODE.STATUS}`]:
                item.order,
            };
            break;
          case 'code':
            sortObj = {
              [`attributeValues.${PURCHASED_ORDER_FIELD_CODE.ORDER_CODE}`]:
                item.order,
            };
            break;
          default:
            break;
        }
      });
    }

    request.filterObj = filterObj;
    const { data, count } = await this.purchasedOrderRepository.getList(
      request,
    );

    const flatAttributeValues = flatMap(map(data), 'attributeValues');
    const poVendors = flatAttributeValues?.filter(
      (attribute) => attribute?.code === PURCHASED_ORDER_FIELD_CODE.VENDOR_ID,
    );

    const vendorIds = uniq(map(poVendors, 'value'));

    const poAttributeGroupCodes = Object.values(
      PURCHASED_ORDER_ATTRIBUTE_GROUP,
    );

    const purchaseStaffs = flatAttributeValues?.filter(
      (attribute) =>
        attribute?.code === PURCHASED_ORDER_FIELD_CODE.PURCHASE_STAFF_ID,
    );

    const purchaseStaffIds = uniq(map(purchaseStaffs, 'value'));

    const createdByUserIds = uniq(map(data, 'createdBy'));
    const userIds = uniq([...purchaseStaffIds, ...createdByUserIds]);

    const [serializedUser, poAttributeGroups, serializedVendor] =
      await Promise.all([
        this.userService.getUserByIds(userIds, true),
        this.attributeService.getAttributeGroupsByCodes(poAttributeGroupCodes),
        this.saleService.getVendorsByIds(vendorIds, true),
      ]);

    const serializedAttributeGroup = keyBy(poAttributeGroups, 'code');

    const beautifiedData = this.beautifyPurchasedOrder(data);

    const formatPurchasedOrders = beautifiedData.map((purchasedOrder) => {
      const { purchasedOrderDetails } = purchasedOrder;
      const poDeliveryDetails = purchasedOrderDetails?.filter(
        (poDetail) =>
          poDetail?.groupId.toString() ===
          serializedAttributeGroup[PURCHASED_ORDER_ATTRIBUTE_GROUP.DELIVERY]
            ._id,
      );
      const planDeliveryDates = poDeliveryDetails?.map(
        (poDeliveryDetail) =>
          poDeliveryDetail[PURCHASED_ORDER_FIELD_CODE.PLAN_DELIVERY_AT]?.value,
      );

      const poItemDetails = purchasedOrderDetails?.filter(
        (poDetail) =>
          poDetail?.groupId.toString() ===
          serializedAttributeGroup[PURCHASED_ORDER_ATTRIBUTE_GROUP.ITEM]._id,
      );

      const totalAmountDetails = poItemDetails?.map((poItemDetail) => {
        const purchasePrice =
          poItemDetail[PURCHASED_ORDER_FIELD_CODE.PURCHASE_PRICE]?.value;
        const quantity =
          poItemDetail[PURCHASED_ORDER_FIELD_CODE.PO_QUANTITY]?.value;
        const discount =
          poItemDetail[PURCHASED_ORDER_FIELD_CODE.DISCOUNT]?.value;

        const planAmount = mul(purchasePrice || 0, quantity || 0);
        const actualAmountRate = minus(100, discount || 0);

        return mul(planAmount, mul(actualAmountRate, ONE_PERCENT));
      });

      const totalAmount = totalAmountDetails?.reduce(
        (prev, cur) => plus(prev, cur),
        0,
      );
      const maxDeliveryAt = moment
        .max(planDeliveryDates.map((dateStr) => moment(dateStr)))
        .toISOString();
      return {
        ...purchasedOrder,
        code: purchasedOrder[PURCHASED_ORDER_FIELD_CODE.ORDER_CODE]?.value,
        name: purchasedOrder[PURCHASED_ORDER_FIELD_CODE.ORDER_NAME]?.value,
        status: purchasedOrder?.status,
        orderedAt: purchasedOrder[PURCHASED_ORDER_FIELD_CODE.ORDER_AT]?.value,
        deadline: maxDeliveryAt,
        createdBy: serializedUser[purchasedOrder.createdBy],
        purchaseStaff:
          serializedUser[
            purchasedOrder[PURCHASED_ORDER_FIELD_CODE.PURCHASE_STAFF_ID]?.value
          ],
        totalAmount,
        vendor:
          serializedVendor[
            purchasedOrder[PURCHASED_ORDER_FIELD_CODE.VENDOR_ID]?.value
          ],
      };
    });

    const returnData = plainToInstance(
      GetPurchasedOrderListResponseDto,
      formatPurchasedOrders,
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder({
      items: returnData,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async confirm(request: IdParamMongoDto): Promise<any> {
    const { id, userId } = request;
    const purchasedOrder = await this.purchasedOrderRepository.findOneById(id);
    if (isEmpty(purchasedOrder)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!PURCHASED_ORDER_STATUS_CAN_CONFIRM.includes(purchasedOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
        .build();
    }

    const purchasedOrderHistoryEntity =
      await this.purchasedOrderHistoryRepository.createDocument({
        purchasedOrderId: purchasedOrder._id,
        userId: userId,
        actionType: PurchasedOrderActionTypeEnum.CONFIRM,
        description: await this.i18n.translate('error.CONFIRM_ORDER'),
      });

    try {
      await this.purchasedOrderRepository.findByIdAndUpdate(id, {
        ...purchasedOrder,
        status: PurchasedOrderStatusEnum.CONFIRMED,
        shippingStatus: ShippingStatusEnum.PENDING,
        paymentStatus: PaymentStatusEnum.UNPAID,
      });

      await this.purchasedOrderHistoryRepository.create(
        purchasedOrderHistoryEntity,
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async reject(request: ChangePurchasedOrderStatusRequestDto): Promise<any> {
    const { id, userId, note } = request;
    const purchasedOrder = await this.purchasedOrderRepository.findOneById(id);
    if (isEmpty(purchasedOrder)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!PURCHASED_ORDER_STATUS_CAN_REJECT.includes(purchasedOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
        .build();
    }

    const purchasedOrderHistoryEntity =
      await this.purchasedOrderHistoryRepository.createDocument({
        purchasedOrderId: purchasedOrder._id,
        userId: userId,
        actionType: PurchasedOrderActionTypeEnum.REJECT,
        description: await this.i18n.translate('error.REJECT_ORDER'),
        note,
      });

    try {
      await this.purchasedOrderRepository.findByIdAndUpdate(id, {
        ...purchasedOrder,
        status: PurchasedOrderStatusEnum.REJECTED,
      });

      await this.purchasedOrderHistoryRepository.create(
        purchasedOrderHistoryEntity,
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async validateAttributes(templateId: any, attributes: any): Promise<any> {
    const template = await this.attributeService.getTemplateById(templateId);
    if (isEmpty(template)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.TEMPLATE_NOT_FOUND'))
        .build();
    }
    const attributeTemplates = template.attributes;

    for (let i = 0; i < attributes.length; i++) {
      const { id, name, value } = attributes[i];
      const attribute = attributeTemplates.find((attr) => attr._id === id);
      const rule = attribute ? attribute.attributeRule : null;
      const dataType = attribute?.attribute?.dataType;

      if (rule && rule.isRequired === REQUIRED_ENUM.REQUIRE) {
        if (!value) {
          return {
            code: ResponseCodeEnum.BAD_REQUEST,
            message: await this.i18n.translate('error.ATTRIBUTE_IS_EMPTY', {
              args: { attribute: name },
            }),
          };
        }
      }

      switch (dataType) {
        case DATA_TYPE_ENUM.NUMBER:
          if (rule?.min !== undefined && value < rule.min) {
            return {
              code: ResponseCodeEnum.BAD_REQUEST,
              message: await this.i18n.translate(
                'error.ATTRIBUTE_IS_SMALLER_THAN_MIN',
                {
                  args: { attribute: name },
                },
              ),
            };
          }
          if (rule?.max !== undefined && value > rule.max) {
            return {
              code: ResponseCodeEnum.BAD_REQUEST,
              message: await this.i18n.translate(
                'error.ATTRIBUTE_IS_BIGGER_THAN_MAX',
                {
                  args: { attribute: name },
                },
              ),
            };
          }
          break;
        case DATA_TYPE_ENUM.DATE:
          const attributeDate = new Date(value);
          if (rule?.min !== undefined && attributeDate < new Date(rule.min)) {
            return {
              code: ResponseCodeEnum.BAD_REQUEST,
              message: await this.i18n.translate(
                'error.ATTRIBUTE_IS_SMALLER_THAN_MIN',
                {
                  args: { attribute: name },
                },
              ),
            };
          }
          if (rule?.max !== undefined && new Date(rule.max) < attributeDate) {
            return {
              code: ResponseCodeEnum.BAD_REQUEST,
              message: await this.i18n.translate(
                'error.ATTRIBUTE_IS_BIGGER_THAN_MAX',
                {
                  args: { attribute: name },
                },
              ),
            };
          }
          break;
        default:
          break;
      }
    }

    return {
      code: ResponseCodeEnum.SUCCESS,
    };
  }

  async generateCode(): Promise<any> {
    const prefixCodeDefault = GEN_CODE_PO_PROPS.PREFIX;
    let startCodeDefault = GEN_CODE_PO_PROPS.DEFAULT_CODE;

    const currentDay = moment()
      .utcOffset(7)
      .format(GEN_CODE_PO_PROPS.DATE_FORMAT);
    const validPattern = new RegExp(
      `^${prefixCodeDefault}\\d{${currentDay.length}}\-\\d{${startCodeDefault.length}}$`,
    );
    const lastPurchasedOrder =
      await this.purchasedOrderRepository.getLastPurchasedOrder();
    const code =
      lastPurchasedOrder?.attributeValues?.find(
        (attributeValue) =>
          attributeValue.code === PURCHASED_ORDER_FIELD_CODE.ORDER_CODE,
      )?.value || null;

    const dateCode = code && code.match(/(\d{6})-/)[1];

    let generatedCode;

    if (isEmpty(lastPurchasedOrder) || (code && !validPattern.test(code))) {
      generatedCode = `${prefixCodeDefault}${currentDay}-${startCodeDefault}`;
    } else {
      const stt = Number(code.split('-')[1]) + 1;

      const sttString = ('0'.repeat(startCodeDefault.length) + stt).slice(
        -startCodeDefault.length,
      );
      startCodeDefault = dateCode != currentDay ? startCodeDefault : sttString;
      generatedCode = `${prefixCodeDefault}${currentDay}-${startCodeDefault}`;
    }

    return new ResponseBuilder({
      code: generatedCode,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async save(
    purchasedOrderEntity: PurchasedOrder,
    payload: CreatePurchasedOrderFormData | UpdatePurchasedOrderFormData,
    isUpdate?: boolean,
  ): Promise<any> {
    try {
      const { data, files, userId } = payload;
      const { purchasedOrderDetails, isDraft } = data;

      const currentEntity = isUpdate
        ? await this.purchasedOrderRepository.findOneById(
            purchasedOrderEntity._id,
          )
        : null;
      const currentFilesAttribute = currentEntity?.attributeValues?.find(
        (attributeValue) =>
          attributeValue.code === PURCHASED_ORDER_FIELD_CODE.FILES,
      );
      const oldFilesAttribute = data.attributeValues.find(
        (attributeValue) =>
          attributeValue.code === PURCHASED_ORDER_FIELD_CODE.FILES,
      );
      const saveFileResponse = await this.fileService.handleSaveFiles(
        currentFilesAttribute?.value || [],
        oldFilesAttribute.value?.filter((file) => !isEmpty(file)) || null,
        files,
      );
      if (saveFileResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
        return saveFileResponse;
      }

      const currentPurchasedOrderCode =
        purchasedOrderEntity?.attributeValues?.find(
          (attributeValue) =>
            attributeValue.code === PURCHASED_ORDER_FIELD_CODE.ORDER_CODE,
        )?.value;

      let versionCode = `${currentPurchasedOrderCode}_${FIRST_VERSION_CODE}`;
      let purchasedOrder;

      if (isUpdate) {
        purchasedOrder = await this.purchasedOrderRepository.findByIdAndUpdate(
          purchasedOrderEntity._id,
          purchasedOrderEntity,
        );

        const lastVersion =
          await this.purchasedOrderVersionRepository.getLastPurchasedOrderVersion(
            purchasedOrderEntity._id,
          );

        versionCode = this.getVersionCode(lastVersion.code);
        //cause PO-version
        // await this.purchasedOrderDetailRepository.deleteManyByCondition({
        //   purchasedOrderId: purchasedOrderEntity._id,
        // });
      } else {
        purchasedOrder = await this.purchasedOrderRepository.create(
          purchasedOrderEntity,
        );
      }

      //handle PO-version
      const purchasedOrderVersion =
        await this.purchasedOrderVersionRepository.create(
          this.purchasedOrderVersionRepository.createDocument({
            ...data,
            purchasedOrderId: purchasedOrder._id,
            code: versionCode,
            createdBy: userId,
          }),
        );

      await this.purchasedOrderDetailRepository.create(
        purchasedOrderDetails.map((purchasedOrderDetail) => {
          return this.purchasedOrderDetailRepository.createDocument({
            ...purchasedOrderDetail,
            purchasedOrderId: purchasedOrder._id,
            purchasedOrderVersionId: purchasedOrderVersion._id,
          });
        }),
      );

      const createDescription = await this.i18n.translate(
        isDraft
          ? 'error.CREATE_PURCHASED_ORDER'
          : 'error.REQUEST_CONFIRM_PURCHASED_ORDER',
      );

      const updateDescription = await this.i18n.translate(
        'error.UPDATE_PURCHASED_ORDER',
      );

      const purchasedOrderHistoryEntity =
        await this.purchasedOrderHistoryRepository.createDocument({
          purchasedOrderId: purchasedOrder._id,
          userId: userId,
          actionType: isUpdate
            ? PurchasedOrderActionTypeEnum.UPDATE
            : PurchasedOrderActionTypeEnum.CREATE,
          description: isUpdate ? updateDescription : createDescription,
        });

      await this.purchasedOrderHistoryRepository.create(
        purchasedOrderHistoryEntity,
      );

      return new ResponseBuilder(purchasedOrder)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            isUpdate ? 'error.UPDATE_SUCCESS' : 'error.CREATE_SUCCESS',
          ),
        )
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  private beautifyPurchasedOrder(data: any[], poAttributeGroups?: any): any[] {
    return data.map((purchasedOrder) => {
      const generalInfo = keyBy(
        purchasedOrder.attributeValues.map(({ code, value }) => ({
          key: code,
          value,
        })),
        'key',
      );

      let purchasedOrderDetails = purchasedOrder.purchasedOrderDetails?.map(
        (purchasedOrderDetail) => ({
          ...purchasedOrderDetail,
          ...keyBy(
            purchasedOrderDetail.attributeValues.map(({ code, value }) => ({
              key: code,
              value,
            })),
            'key',
          ),
        }),
      );

      //to group po-details
      if (!isEmpty(poAttributeGroups)) {
        purchasedOrderDetails = keyBy(
          purchasedOrderDetails.reduce((result, item) => {
            const groupId = item.groupId.toString();

            const existingGroup = result.find(
              (group) => group.groupId === groupId,
            );
            const groupInfo = find(
              poAttributeGroups,
              (attributeGroup) => attributeGroup._id === groupId,
            );

            if (existingGroup) {
              existingGroup.details.push(omit(item, 'groupId'));
            } else {
              result.push({
                groupId,
                code: groupInfo?.code,
                name: groupInfo?.name,
                details: [omit(item, 'groupId')],
              });
            }

            return result;
          }, []),
          'code',
        );
      }

      return {
        ...purchasedOrder,
        ...generalInfo,
        purchasedOrderDetails,
      };
    });
  }

  private getValueOfAttributesByCode(
    attributeValues: AttributeValue[],
    codes: string[],
  ): any[] {
    return codes.map((code) => {
      const filteredAttributeValues = filter(
        attributeValues,
        (attributeValue) => attributeValue.code === code,
      );
      return uniq(
        map(filteredAttributeValues, (attribute) => {
          return attribute.value;
        }),
      );
    });
  }

  async getVersionDetail(
    request: GetPurchasedOrderVersionDetailRequestDto,
  ): Promise<any> {
    const { id } = request;
    const data = await this.purchasedOrderVersionRepository.getDetail({
      id,
    });
    if (isEmpty(data)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const flatAttributeValues = [
      ...data.attributeValues,
      ...flatMap(
        data.purchasedOrderDetails,
        (poDetail) => poDetail.attributeValues,
      ),
    ];

    const [
      currencyUnitIds,
      purchaseStaffIds,
      shippingMethodIds,
      paymentMethodIds,
      vendorIds,
      itemIds,
      invoiceUpdateUserIds,
    ] = this.getValueOfAttributesByCode(flatAttributeValues, [
      PURCHASED_ORDER_FIELD_CODE.CURRENCY_UNIT_ID,
      PURCHASED_ORDER_FIELD_CODE.PURCHASE_STAFF_ID,
      PURCHASED_ORDER_FIELD_CODE.SHIPPING_METHOD_ID,
      PURCHASED_ORDER_FIELD_CODE.PAYMENT_METHOD_ID,
      PURCHASED_ORDER_FIELD_CODE.VENDOR_ID,
      PURCHASED_ORDER_FIELD_CODE.ITEM_ID,
      PURCHASED_ORDER_FIELD_CODE.UPDATE_BY_USER_ID,
    ]);

    const userIds = uniq([
      ...purchaseStaffIds,
      ...invoiceUpdateUserIds,
      data.createdBy,
    ]);
    const poAttributeGroupCodes = Object.values(
      PURCHASED_ORDER_ATTRIBUTE_GROUP,
    );

    const [
      serializedUser,
      serializedCurrencyUnit,
      shippingMethods,
      poAttributeGroups,
      serializedItem,
      paymentMethods,
      serializedVendor,
    ] = await Promise.all([
      this.userService.getUserByIds(userIds, true),
      this.itemService.getCurrencyUnitsByIds(currencyUnitIds, true),
      this.shippingTypeRepository.findAllByCondition({
        _id: { $in: shippingMethodIds },
      }),
      this.attributeService.getAttributeGroupsByCodes(poAttributeGroupCodes),
      this.itemService.getItemByIds(itemIds, true),
      this.paymentTypeRepository.findAllByCondition({
        _id: { $in: paymentMethodIds },
      }),
      this.saleService.getVendorsByIds(vendorIds, true),
    ]);
    const serializedShippingMethod = keyBy(shippingMethods, '_id');
    const serializedPaymentMethod = keyBy(paymentMethods, '_id');

    const beautifiedData = first(
      this.beautifyPurchasedOrder([data], poAttributeGroups),
    );

    const serializedGroupedData = beautifiedData.purchasedOrderDetails;

    const purchasedOrderItemDetails = serializedGroupedData[
      PURCHASED_ORDER_ATTRIBUTE_GROUP.ITEM
    ]?.details?.map((i) => {
      const itemId = i[PURCHASED_ORDER_FIELD_CODE.ITEM_ID].value;
      return {
        itemId,
        item: {
          ...i[PURCHASED_ORDER_FIELD_CODE.ITEM_ID],
          value: serializedItem[itemId],
        },
        quantity: i[PURCHASED_ORDER_FIELD_CODE.PO_QUANTITY],
        purchasePrice: i[PURCHASED_ORDER_FIELD_CODE.PURCHASE_PRICE],
        discount: i[PURCHASED_ORDER_FIELD_CODE.DISCOUNT],
      };
    });

    const purchasedOrderDeliveryDetails = serializedGroupedData[
      PURCHASED_ORDER_ATTRIBUTE_GROUP.DELIVERY
    ]?.details?.map((i) => {
      const itemId = i[PURCHASED_ORDER_FIELD_CODE.ITEM_ID]?.value;
      return {
        itemId,
        item: {
          ...i[PURCHASED_ORDER_FIELD_CODE.ITEM_ID],
          value: serializedItem[itemId],
        },
        planDeliveryAt: i[PURCHASED_ORDER_FIELD_CODE.PLAN_DELIVERY_AT],
        description: i[PURCHASED_ORDER_FIELD_CODE.DESCRIPTION],
      };
    });

    const purchasedOrderPaymentDetails = serializedGroupedData[
      PURCHASED_ORDER_ATTRIBUTE_GROUP.PAYMENT
    ]?.details?.map((i) => {
      const paymentMethodId =
        i[PURCHASED_ORDER_FIELD_CODE.PAYMENT_METHOD_ID]?.value;
      return {
        paymentMethodId,
        paymentMethod: {
          ...i[PURCHASED_ORDER_FIELD_CODE.PAYMENT_METHOD_ID],
          value: serializedPaymentMethod[paymentMethodId],
        },
        planPayAt: i[PURCHASED_ORDER_FIELD_CODE.PAY_AT],
        paymentRate: i[PURCHASED_ORDER_FIELD_CODE.PAYMENT_RATE],
        totalPaymentAmount: i[PURCHASED_ORDER_FIELD_CODE.TOTAL_PAYMENT_AMOUNT],
        description: i[PURCHASED_ORDER_FIELD_CODE.DESCRIPTION],
      };
    });

    const purchasedOrderInvoiceDetails = serializedGroupedData[
      PURCHASED_ORDER_ATTRIBUTE_GROUP.INVOICE
    ]?.details?.map((i) => {
      const updateByUserId =
        i[PURCHASED_ORDER_FIELD_CODE.UPDATE_BY_USER_ID]?.value;
      return {
        updatedBy: {
          ...i[PURCHASED_ORDER_FIELD_CODE.UPDATE_BY_USER_ID],
          value: serializedUser[updateByUserId],
        },
        createdAt: i[PURCHASED_ORDER_FIELD_CODE.CREATED_AT],
        invoiceCode: i[PURCHASED_ORDER_FIELD_CODE.INVOICE_CODE],
        invoiceValue: i[PURCHASED_ORDER_FIELD_CODE.INVOICE_VALUE],
        description: i[PURCHASED_ORDER_FIELD_CODE.DESCRIPTION],
      };
    });

    const formatPurchasedOrder = {
      ...beautifiedData,
      status: beautifiedData.status,
      currencyUnit: {
        ...beautifiedData[PURCHASED_ORDER_FIELD_CODE.CURRENCY_UNIT_ID],
        value:
          serializedCurrencyUnit[
            beautifiedData[PURCHASED_ORDER_FIELD_CODE.CURRENCY_UNIT_ID]?.value
          ],
      },
      vendor:
        serializedVendor[beautifiedData[PURCHASED_ORDER_FIELD_CODE.VENDOR_ID]],
      orderedAt: beautifiedData[PURCHASED_ORDER_FIELD_CODE.ORDER_AT],
      code: beautifiedData[PURCHASED_ORDER_FIELD_CODE.ORDER_CODE],
      name: beautifiedData[PURCHASED_ORDER_FIELD_CODE.ORDER_NAME],
      orderType: beautifiedData[PURCHASED_ORDER_FIELD_CODE.ORDER_TYPE],
      purchaseStaff:
        serializedUser[
          beautifiedData[PURCHASED_ORDER_FIELD_CODE.PURCHASE_STAFF_ID]
        ],
      note: beautifiedData[PURCHASED_ORDER_FIELD_CODE.NOTE],
      oneTimeDelivery:
        beautifiedData[PURCHASED_ORDER_FIELD_CODE.ONE_TIME_DELIVERY],
      deliverAt: beautifiedData[PURCHASED_ORDER_FIELD_CODE.DELIVER_AT],
      receiver: beautifiedData[PURCHASED_ORDER_FIELD_CODE.RECEIVER],
      receiverPhoneNumber:
        beautifiedData[PURCHASED_ORDER_FIELD_CODE.RECEIVER_PHONE_NUMBER],
      shippingMethod:
        serializedShippingMethod[
          beautifiedData[PURCHASED_ORDER_FIELD_CODE.SHIPPING_METHOD_ID]
        ],
      address: beautifiedData[PURCHASED_ORDER_FIELD_CODE.ADDRESS],
      purchasedOrderItemDetails,
      purchasedOrderDeliveryDetails,
      purchasedOrderPaymentDetails,
      purchasedOrderInvoiceDetails,
    };

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async changeStatus(
    request: ChangePurchasedOrderStatusRequestDto,
  ): Promise<any> {
    const { id, type, note, userId } = request;
    let newStatus;
    let description;
    let validListStatus;
    switch (type) {
      case PurchasedOrderActionTypeEnum.REQUEST_CONFIRM:
        newStatus = PurchasedOrderStatusEnum.PENDING;
        description = await this.i18n.translate(
          'error.REQUEST_CONFIRM_PURCHASED_ORDER',
        );
        validListStatus = PURCHASED_ORDER_STATUS_CAN_REQUEST_CONFIRM;
        break;
      case PurchasedOrderActionTypeEnum.ORDER:
        newStatus = PurchasedOrderStatusEnum.WAIT_DELIVER;
        description = await this.i18n.translate('error.ORDERED');
        validListStatus = PURCHASED_ORDER_STATUS_CAN_ORDER;
        break;
      case PurchasedOrderActionTypeEnum.COMPLETE:
        newStatus = PurchasedOrderStatusEnum.COMPLETED;
        description = await this.i18n.translate('error.COMPLETE_ORDER');
        validListStatus = PURCHASED_ORDER_STATUS_CAN_COMPLETE;
        break;
      case PurchasedOrderActionTypeEnum.CANCEL:
        newStatus = PurchasedOrderStatusEnum.CANCELED;
        description = await this.i18n.translate('error.CANCEL_ORDER');
        validListStatus = PURCHASED_ORDER_STATUS_CAN_CANCEL;
        break;
      default:
        break;
    }

    if (newStatus === null || newStatus === undefined) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CHANGE_STATUS'))
        .build();
    }

    const purchasedOrder = await this.purchasedOrderRepository.findOneById(id);

    if (isEmpty(purchasedOrder)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const purchasedOrderHistoryEntity =
      await this.purchasedOrderHistoryRepository.createDocument({
        purchasedOrderId: purchasedOrder._id,
        userId: userId,
        actionType: type,
        description: description,
        note: note,
      });

    if (
      !isEmpty(validListStatus) &&
      !validListStatus.includes(purchasedOrder.status)
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
        .build();
    }

    try {
      await this.purchasedOrderRepository.findByIdAndUpdate(id, {
        ...purchasedOrder,
        status: newStatus,
      });

      await this.purchasedOrderHistoryRepository.create(
        purchasedOrderHistoryEntity,
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (e) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CHANGE_STATUS'))
        .build();
    }
  }

  async getPurchasedOrderVersionList(
    request: GetPurchasedOrderDetailRequestDto,
  ): Promise<any> {
    const { id } = request;
    const purchasedOrder = await this.purchasedOrderRepository.findOneById(id);
    if (!purchasedOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const poVersions =
      await this.purchasedOrderVersionRepository.findAllByCondition({
        purchasedOrderId: id,
      });

    const createdByUserIds = uniq(map(poVersions, 'createdBy'));

    const serializedUser = await this.userService.getUserByIds(
      createdByUserIds,
      true,
    );

    const returnPOVersions = orderBy(poVersions, 'createdAt', 'desc')?.map(
      (poVersion) => ({
        ...poVersion,
        createdBy: serializedUser[poVersion.createdBy],
      }),
    );

    const returnData = plainToInstance(
      GetListPurchasedOrderVersion,
      returnPOVersions,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(returnData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private getVersionCode(code) {
    const numericPart = code.split('_')[1];
    const prefixPart = code.split('_')[0];
    if (!numericPart) {
      return code;
    }
    const numericValue = Number(numericPart);

    const nextNumericValue = numericValue + 1;

    const newNumericPart = (
      '0'.repeat(numericPart.length) + nextNumericValue
    ).slice(-numericPart.length);

    return `${prefixPart}_${newNumericPart}`;
  }
}
