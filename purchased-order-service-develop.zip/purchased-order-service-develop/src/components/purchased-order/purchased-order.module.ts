import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { PurchasedOrderController } from './purchased-order.controller';
import { PurchasedOrderSchema } from 'src/models/purchased-order/purchased-order.schema';
import { PurchasedOrderDetailSchema } from 'src/models/purchased-order/purchased-order-detail.schema';
import { PurchasedOrderService } from './purchased-order.service';
import { AttributeService } from '@components/attribute/attribute.service';
import { PurchasedOrderRepository } from 'src/repository/purchased-order/purchased-order.repository';
import { PurchasedOrderDetailRepository } from 'src/repository/purchased-order/purchased-order-detail.repository';
import { FileService } from '@components/file/file.service';
import { FileModule } from '@components/file/file.module';
import { PurchasedOrderHistoryRepository } from 'src/repository/purchased-order/purchased-order-history.repository';
import { PurchasedOrderHistorySchema } from 'src/models/purchased-order/purchased-order-history.schema';
import { ShippingTypeSchema } from 'src/models/shipping-type/shipping-type.schema';
import { PaymentTypeSchema } from 'src/models/payment-type/payment-type.schema';
import { ShippingTypeRepository } from 'src/repository/shipping-type/shipping-type.repository';
import { PaymentTypeRepository } from 'src/repository/payment-type/payment-type.repository';
import { ShippingTypeModule } from '@components/shipping-type/shipping-type.module';
import { PaymentTypeModule } from '@components/payment-type/payment-type.module';
import { ItemService } from '@components/item/item.service';
import { UserService } from '@components/user/user.service';
import { SaleService } from '@components/sale/sale.service';
import { PurchasedOrderVersionSchema } from 'src/models/purchased-order/purchased-order-version.schema';
import { PurchasedOrderVersionRepository } from 'src/repository/purchased-order/purchased-order-version.repository';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: 'PurchasedOrder',
        schema: PurchasedOrderSchema,
      },
      {
        name: 'PurchasedOrderDetail',
        schema: PurchasedOrderDetailSchema,
      },
      {
        name: 'PurchasedOrderHistory',
        schema: PurchasedOrderHistorySchema,
      },
      {
        name: 'ShippingType',
        schema: ShippingTypeSchema,
      },
      {
        name: 'PaymentType',
        schema: PaymentTypeSchema,
      },
      {
        name: 'PurchasedOrderVersionModel',
        schema: PurchasedOrderVersionSchema,
      },
    ]),
    FileModule,
    ShippingTypeModule,
    PaymentTypeModule,
  ],
  providers: [
    {
      provide: 'PurchasedOrderServiceInterface',
      useClass: PurchasedOrderService,
    },
    {
      provide: 'PurchasedOrderRepositoryInterface',
      useClass: PurchasedOrderRepository,
    },
    {
      provide: 'PurchasedOrderDetailRepositoryInterface',
      useClass: PurchasedOrderDetailRepository,
    },
    {
      provide: 'PurchasedOrderHistoryRepositoryInterface',
      useClass: PurchasedOrderHistoryRepository,
    },
    {
      provide: 'PurchasedOrderVersionRepositoryInterface',
      useClass: PurchasedOrderVersionRepository,
    },
    {
      provide: 'ShippingTypeRepositoryInterface',
      useClass: ShippingTypeRepository,
    },
    {
      provide: 'PaymentTypeRepositoryInterface',
      useClass: PaymentTypeRepository,
    },
    {
      provide: 'PurchasedOrderRepositoryInterface',
      useClass: PurchasedOrderRepository,
    },
    {
      provide: 'AttributeServiceInterface',
      useClass: AttributeService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'FileServiceInterface',
      useClass: FileService,
    },
  ],
  controllers: [PurchasedOrderController],
  exports: [],
})
export class PurchasedOrderModule {}
