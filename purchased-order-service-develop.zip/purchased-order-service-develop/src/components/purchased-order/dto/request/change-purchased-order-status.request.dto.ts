import { PurchasedOrderActionTypeEnum } from '@components/purchased-order/purchased-order.constant';
import { BaseDto } from '@core/dto/base.dto';
import { Transform } from 'class-transformer';
import { IsIn, IsInt, IsMongoId, IsOptional } from 'class-validator';

export class ChangePurchasedOrderStatusRequestDto extends BaseDto {
  @IsMongoId()
  id: string;

  @IsOptional()
  @IsIn(Object.values(PurchasedOrderActionTypeEnum))
  @Transform(({ value }) => Number(value))
  type: number;

  @IsOptional()
  note: string;
}
