import { PURCHASED_ORDER_VALIDATE } from '@components/purchased-order/purchased-order.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { AttributeValueRequestDto } from '@utils/dto/request/attribute.request.dto';
import { Transform, Type } from 'class-transformer';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import {
  ArrayUnique,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';

export class PurchasedOrderDetailRequestDto {
  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  groupId: string;

  @ApiProperty()
  @ArrayUnique<AttributeValueRequestDto>()
  @IsOptional()
  @ValidateNested()
  @Type(() => AttributeValueRequestDto)
  attributeValues: AttributeValueRequestDto[];
}

export class CreatePurchasedOrderBodyDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  isDraft: boolean;

  @ApiProperty()
  @IsOptional()
  @MaxLength(PURCHASED_ORDER_VALIDATE.CODE.MAX_LENGTH)
  code: string;

  @ApiProperty()
  @IsOptional()
  @MaxLength(PURCHASED_ORDER_VALIDATE.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  templateId: string;

  @ApiProperty()
  @IsString()
  @IsOptional()
  @MaxLength(PURCHASED_ORDER_VALIDATE.DESCRIPTION.MAX_LENGTH)
  description: string;

  @ApiProperty()
  @ArrayUnique<AttributeValueRequestDto>()
  @IsOptional()
  @ValidateNested()
  @Type(() => AttributeValueRequestDto)
  attributeValues: AttributeValueRequestDto[];

  @ApiProperty()
  @ArrayUnique<PurchasedOrderDetailRequestDto>()
  @IsOptional()
  @ValidateNested()
  @Type(() => PurchasedOrderDetailRequestDto)
  purchasedOrderDetails: PurchasedOrderDetailRequestDto[];
}

export class CreatePurchasedOrderFormData extends BaseDto {
  @ApiProperty()
  @Transform(({ value }) => JSON.parse(value), { toClassOnly: true })
  @Type(() => CreatePurchasedOrderBodyDto)
  @ValidateNested()
  data: CreatePurchasedOrderBodyDto;

  @ApiPropertyOptional()
  @IsOptional()
  files: File[];
}
