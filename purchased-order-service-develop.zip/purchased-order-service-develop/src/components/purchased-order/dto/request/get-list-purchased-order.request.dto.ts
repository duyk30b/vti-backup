import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { IsOptional } from 'class-validator';

export class GetListPurchasedOrderRequestDto extends PaginationQuery {
  @IsOptional()
  filterObj: any;
}
