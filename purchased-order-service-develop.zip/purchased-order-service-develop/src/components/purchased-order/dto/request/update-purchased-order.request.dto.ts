import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { plainToInstance, Transform, Type } from 'class-transformer';
import { IsMongoId, IsOptional, ValidateNested } from 'class-validator';
import { CreatePurchasedOrderBodyDto } from './create-purchased-order.request.dto';
import { FileUpload } from '@core/dto/file-upload.request.dto';

export class UpdatePurchasedOrderDto extends CreatePurchasedOrderBodyDto {
  @ApiProperty()
  @IsOptional()
  @IsMongoId()
  id: string;
}

export class UpdatePurchasedOrderFormData extends BaseDto {
  @ApiProperty()
  @ValidateNested({ each: true })
  @Transform((v) => {
    return plainToInstance(UpdatePurchasedOrderDto, JSON.parse(v.value));
  })
  @Type(() => UpdatePurchasedOrderDto)
  data: UpdatePurchasedOrderDto;

  @ApiProperty({ description: 'File' })
  @ValidateNested({ each: true })
  @Type(() => FileUpload)
  files: FileUpload[];
}
