import { UserResponseDto } from '@components/user/dto/response/user.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class VendorResponseDto extends BaseResponseDto {}
export class GetPurchasedOrderListResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  orderedAt: Date;

  @ApiProperty()
  @Expose()
  deadline: Date;

  @ApiProperty()
  @Expose()
  @Type(() => VendorResponseDto)
  vendor: VendorResponseDto;

  @ApiProperty()
  @Expose()
  purchaseStaff: UserResponseDto;

  @ApiProperty()
  @Expose()
  createdBy: UserResponseDto;

  @ApiProperty()
  @Expose()
  totalAmount: number;

  @ApiProperty()
  @Expose()
  shippingStatus: number;

  @ApiProperty()
  @Expose()
  paymentStatus: number;
}
