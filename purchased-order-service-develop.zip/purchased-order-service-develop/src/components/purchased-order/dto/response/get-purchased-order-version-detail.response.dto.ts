import { UserResponseDto } from '@components/user/dto/response/user.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class AttributeResponseDto<T> {
  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  value: T;

  @ApiProperty()
  @Expose()
  isNew: string;

  @ApiProperty()
  @Expose()
  preValue: string;
}

class ItemResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => BaseResponseDto)
  itemUnit: BaseResponseDto;
}

class CurrencyUnitResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => BaseResponseDto)
  exchangeRate: BaseResponseDto;
}

class VendorResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  phone: string;

  @ApiProperty()
  @Expose()
  taxCode: string;
}
class ShippingMethodResponseDto extends BaseResponseDto {}
class PaymentMethodResponseDto extends BaseResponseDto {}

class PurchasedOrderItemDetailResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  purchasePrice: number;

  @ApiProperty()
  @Expose()
  discount: number;
}

class PurchasedOrderDeliveryDetailResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  planDeliveryAt: Date;

  @ApiProperty()
  @Expose()
  description: string;
}

class PurchasedOrderPaymentDetailResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => PaymentMethodResponseDto)
  paymentMethod: PaymentMethodResponseDto;

  @ApiProperty()
  @Expose()
  paymentMethodId: number;

  @ApiProperty()
  @Expose()
  planPayAt: Date;

  @ApiProperty()
  @Expose()
  paymentRate: number;

  @ApiProperty()
  @Expose()
  totalPaymentAmount: number;

  @ApiProperty()
  @Expose()
  description: string;
}

class PurchasedOrderInvoiceDetailResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => UserResponseDto)
  updatedBy: UserResponseDto;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  invoiceCode: string;

  @ApiProperty()
  @Expose()
  invoiceValue: number;

  @ApiProperty()
  @Expose()
  description: string;
}

class PurchasedOrderHistoryResponseDto {
  @ApiProperty()
  @Expose()
  actionType: number;

  @ApiProperty()
  @Expose()
  createdBy: UserResponseDto;

  @ApiProperty()
  @Expose()
  purchasedOrderId: string;

  @ApiProperty()
  @Expose()
  userId: number;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  createdAt: Date;
}

export class PurchasedOrderResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  orderedAt: AttributeResponseDto<Date>;

  @ApiProperty()
  @Expose()
  deadline: AttributeResponseDto<Date>;

  @ApiProperty()
  @Expose()
  @Type(() => AttributeResponseDto<UserResponseDto>)
  purchaseStaff: AttributeResponseDto<UserResponseDto>;

  @ApiProperty()
  @Expose()
  @Type(() => AttributeResponseDto<UserResponseDto>)
  createdBy: AttributeResponseDto<UserResponseDto>;

  @ApiProperty()
  @Expose()
  @Type(() => AttributeResponseDto<CurrencyUnitResponseDto>)
  currencyUnit: AttributeResponseDto<CurrencyUnitResponseDto>;

  @ApiProperty()
  @Expose()
  @Type(() => AttributeResponseDto<VendorResponseDto>)
  vendor: AttributeResponseDto<VendorResponseDto>;

  @ApiProperty()
  @Expose()
  orderType: AttributeResponseDto<number>;

  @ApiProperty()
  @Expose()
  note: AttributeResponseDto<string>;

  @ApiProperty()
  @Expose()
  oneTimeDelivery: AttributeResponseDto<number>;

  @ApiProperty()
  @Expose()
  receiverPhoneNumber: AttributeResponseDto<string>;

  @ApiProperty()
  @Expose()
  receiver: AttributeResponseDto<string>;

  @ApiProperty()
  @Expose()
  deliverAt: AttributeResponseDto<string>;

  @ApiProperty()
  @Expose()
  @Type(() => AttributeResponseDto<ShippingMethodResponseDto>)
  shippingMethod: AttributeResponseDto<ShippingMethodResponseDto>;

  @ApiProperty()
  @Expose()
  address: AttributeResponseDto<string>;

  @ApiProperty()
  @Type(() => AttributeResponseDto<PurchasedOrderItemDetailResponseDto>)
  @Expose()
  purchasedOrderItemDetails: AttributeResponseDto<
    PurchasedOrderItemDetailResponseDto[]
  >;

  @ApiProperty()
  @Type(() => AttributeResponseDto<PurchasedOrderDeliveryDetailResponseDto>)
  @Expose()
  purchasedOrderDeliveryDetails: AttributeResponseDto<
    PurchasedOrderDeliveryDetailResponseDto[]
  >;

  @ApiProperty()
  @Type(() => AttributeResponseDto<PurchasedOrderPaymentDetailResponseDto>)
  @Expose()
  purchasedOrderPaymentDetails: AttributeResponseDto<
    PurchasedOrderPaymentDetailResponseDto[]
  >;

  @ApiProperty()
  @Type(() => AttributeResponseDto<PurchasedOrderHistoryResponseDto>)
  @Expose()
  purchasedOrderHistories: AttributeResponseDto<
    PurchasedOrderHistoryResponseDto[]
  >;

  @ApiProperty()
  @Type(() => AttributeResponseDto<PurchasedOrderInvoiceDetailResponseDto>)
  @Expose()
  purchasedOrderInvoiceDetails: AttributeResponseDto<
    PurchasedOrderInvoiceDetailResponseDto[]
  >;
}
