import { UserResponseDto } from '@components/user/dto/response/user.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class GetListPurchasedOrderVersion extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  createdBy: UserResponseDto;
}
