import { UserResponseDto } from '@components/user/dto/response/user.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class ItemResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => BaseResponseDto)
  itemUnit: BaseResponseDto;
}

class ExchangeRateResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  rate: string;
}

class CurrencyUnitResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => ExchangeRateResponseDto)
  exchangeRate: ExchangeRateResponseDto;
}

class VendorResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  phone: string;

  @ApiProperty()
  @Expose()
  taxCode: string;
}
class ShippingMethodResponseDto extends BaseResponseDto {}
class PaymentMethodResponseDto extends BaseResponseDto {}

class PurchasedOrderItemDetailResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  purchasePrice: number;

  @ApiProperty()
  @Expose()
  discount: number;
}

class PurchasedOrderDeliveryDetailResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  planDeliveryAt: Date;

  @ApiProperty()
  @Expose()
  description: string;
}

class PurchasedOrderPaymentDetailResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => PaymentMethodResponseDto)
  paymentMethod: PaymentMethodResponseDto;

  @ApiProperty()
  @Expose()
  paymentMethodId: number;

  @ApiProperty()
  @Expose()
  planPayAt: Date;

  @ApiProperty()
  @Expose()
  paymentRate: number;

  @ApiProperty()
  @Expose()
  totalPaymentAmount: number;

  @ApiProperty()
  @Expose()
  userAccount: string;

  @ApiProperty()
  @Expose()
  description: string;
}

class PurchasedOrderInvoiceDetailResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => UserResponseDto)
  updatedBy: UserResponseDto;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  invoiceCode: string;

  @ApiProperty()
  @Expose()
  invoiceValue: number;

  @ApiProperty()
  @Expose()
  description: string;
}

class PurchasedOrderHistoryResponseDto {
  @ApiProperty()
  @Expose()
  actionType: number;

  @ApiProperty()
  @Expose()
  createdBy: UserResponseDto;

  @ApiProperty()
  @Expose()
  purchasedOrderId: string;

  @ApiProperty()
  @Expose()
  userId: number;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  note: string;
}

export class PurchasedOrderResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  orderedAt: Date;

  @ApiProperty()
  @Expose()
  deadline: Date;

  @ApiProperty()
  @Expose()
  @Type(() => UserResponseDto)
  purchaseStaff: UserResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => UserResponseDto)
  createdBy: UserResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => CurrencyUnitResponseDto)
  currencyUnit: CurrencyUnitResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => VendorResponseDto)
  vendor: VendorResponseDto;

  @ApiProperty()
  @Expose()
  orderType: number;

  @ApiProperty()
  @Expose()
  note: string;

  @ApiProperty()
  @Expose()
  oneTimeDelivery: number;

  @ApiProperty()
  @Expose()
  receiverPhoneNumber: string;

  @ApiProperty()
  @Expose()
  receiver: string;

  @ApiProperty()
  @Expose()
  deliverAt: string;

  @ApiProperty()
  @Expose()
  @Type(() => ShippingMethodResponseDto)
  shippingMethod: ShippingMethodResponseDto;

  @ApiProperty()
  @Expose()
  address: string;

  @ApiProperty()
  @Type(() => PurchasedOrderItemDetailResponseDto)
  @Expose()
  purchasedOrderItemDetails: PurchasedOrderItemDetailResponseDto[];

  @ApiProperty()
  @Type(() => PurchasedOrderDeliveryDetailResponseDto)
  @Expose()
  purchasedOrderDeliveryDetails: PurchasedOrderDeliveryDetailResponseDto[];

  @ApiProperty()
  @Type(() => PurchasedOrderPaymentDetailResponseDto)
  @Expose()
  purchasedOrderPaymentDetails: PurchasedOrderPaymentDetailResponseDto[];

  @ApiProperty()
  @Type(() => PurchasedOrderHistoryResponseDto)
  @Expose()
  purchasedOrderHistories: PurchasedOrderHistoryResponseDto[];

  @ApiProperty()
  @Type(() => PurchasedOrderInvoiceDetailResponseDto)
  @Expose()
  purchasedOrderInvoiceDetails: PurchasedOrderInvoiceDetailResponseDto[];
}
