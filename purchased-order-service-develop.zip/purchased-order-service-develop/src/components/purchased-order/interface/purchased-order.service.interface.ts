import { GetListPurchasedOrderRequestDto } from './../dto/request/get-list-purchased-order.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { CreatePurchasedOrderFormData } from '../dto/request/create-purchased-order.request.dto';
import { GetPurchasedOrderDetailRequestDto } from '../dto/request/get-purchased-order-detail.request.dto';
import { UpdatePurchasedOrderFormData } from '../dto/request/update-purchased-order.request.dto';
import { ChangePurchasedOrderStatusRequestDto } from '../dto/request/change-purchased-order-status.request.dto';
import { GetPurchasedOrderVersionDetailRequestDto } from '../dto/request/get-purchased-order-version-detail.request.dto';

export interface PurchasedOrderServiceInterface {
  create(request: CreatePurchasedOrderFormData): Promise<any>;
  update(request: UpdatePurchasedOrderFormData): Promise<any>;
  getDetail(request: GetPurchasedOrderDetailRequestDto): Promise<any>;
  getList(request: GetListPurchasedOrderRequestDto): Promise<any>;
  delete(request: IdParamMongoDto): Promise<any>;
  confirm(request: IdParamMongoDto): Promise<any>;
  reject(request: IdParamMongoDto): Promise<any>;
  generateCode(): Promise<any>;
  changeStatus(request: ChangePurchasedOrderStatusRequestDto): Promise<any>;
  getVersionDetail(
    request: GetPurchasedOrderVersionDetailRequestDto,
  ): Promise<any>;
  getPurchasedOrderVersionList(
    request: GetPurchasedOrderDetailRequestDto,
  ): Promise<any>;
}
