import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { PurchasedOrder } from 'src/models/purchased-order/purchased-order.model';
import { GetListPurchasedOrderRequestDto } from '../dto/request/get-list-purchased-order.request.dto';

export interface PurchasedOrderRepositoryInterface
  extends BaseInterfaceRepository<PurchasedOrder> {
  createDocument(request: any): PurchasedOrder;
  updateDocument(document: PurchasedOrder, request: any): PurchasedOrder;
  getList(request: GetListPurchasedOrderRequestDto): Promise<any>;
  getDetail(id: string, versionId?: string): Promise<any>;
  getLastPurchasedOrder(): Promise<any>;
}
