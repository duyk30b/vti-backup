import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { PurchasedOrderDetail } from 'src/models/purchased-order/purchased-order-detail.model';

export interface PurchasedOrderDetailRepositoryInterface
  extends BaseInterfaceRepository<PurchasedOrderDetail> {
  createDocument(request: any): PurchasedOrderDetail;
  getDetail(id: string): any;
}
