import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { PurchasedOrderHistory } from 'src/models/purchased-order/purchased-order-history.model';

export interface PurchasedOrderHistoryRepositoryInterface
  extends BaseInterfaceRepository<PurchasedOrderHistory> {
  createDocument(request: any): PurchasedOrderHistory;
}
