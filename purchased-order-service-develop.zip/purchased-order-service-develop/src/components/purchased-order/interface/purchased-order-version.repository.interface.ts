import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import {} from 'src/models/purchased-order/purchased-order-history.model';
import { PurchasedOrderVersionModel } from 'src/models/purchased-order/purchased-order-version.schema';

export interface PurchasedOrderVersionRepositoryInterface
  extends BaseInterfaceRepository<PurchasedOrderVersionModel> {
  createDocument(request: any): PurchasedOrderVersionModel;
  getDetail(condition: any): Promise<any>;
  getLastPurchasedOrderVersion(purchasedOrderId: string): Promise<any>;
}
