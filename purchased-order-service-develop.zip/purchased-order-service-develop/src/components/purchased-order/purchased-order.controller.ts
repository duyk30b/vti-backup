import { isEmpty } from 'lodash';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { PurchasedOrderService } from './purchased-order.service';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { GetListPurchasedOrderRequestDto } from './dto/request/get-list-purchased-order.request.dto';
import { PurchasedOrderResponseDto } from './dto/response/purchased-order.response.dto';
import { CreatePurchasedOrderFormData } from './dto/request/create-purchased-order.request.dto';
import { UpdatePurchasedOrderFormData } from './dto/request/update-purchased-order.request.dto';
import { GetPurchasedOrderDetailRequestDto } from './dto/request/get-purchased-order-detail.request.dto';
import { ChangePurchasedOrderStatusRequestDto } from './dto/request/change-purchased-order-status.request.dto';
import { GetPurchasedOrderVersionDetailRequestDto } from './dto/request/get-purchased-order-version-detail.request.dto';

@Controller('')
export class PurchasedOrderController {
  constructor(
    @Inject('PurchasedOrderServiceInterface')
    private readonly purchasedOrderService: PurchasedOrderService,
  ) {}

  /**
   * Get List PO
   * @param payload
   * @returns
   */
  @Get('')
  @ApiOperation({
    tags: ['Purchased Order'],
    summary: 'Get List Purchased Order',
    description: 'Danh sách đơn mua hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List Purchased Order Successfully',
    type: GetListPurchasedOrderRequestDto,
  })
  public async getList(
    @Query() payload: GetListPurchasedOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.purchasedOrderService.getList(request);
  }

  /**
   * Create Purchased Order
   * @param payload
   * @returns
   */
  @Post()
  @ApiOperation({
    tags: ['Purchased Order'],
    summary: 'Create Purchased Order',
    description: 'Tạo đơn mua hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Create Purchased Order Successfully',
    type: PurchasedOrderResponseDto,
  })
  public async create(
    @Body() payload: CreatePurchasedOrderFormData,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderService.create(request);
  }

  /**
   * Update Purchased Order
   * @param payload
   * @returns
   */
  @Put('/:id')
  @ApiOperation({
    tags: ['Purchased Order'],
    summary: 'Update Purchased Order',
    description: 'Sửa đơn mua hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update Purchased Order Successfully',
    type: PurchasedOrderResponseDto,
  })
  public async update(
    @Param('id') id,
    @Body() payload: UpdatePurchasedOrderFormData,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderService.update({
      ...request,
      data: {
        ...request.data,
        id: id,
      },
    });
  }

  /**
   * Detail Purchased Order
   * @param param
   * @returns
   */
  @Get('/:id')
  @ApiOperation({
    tags: ['Purchased Order'],
    summary: 'Detail Purchased Order',
    description: 'Chi tiết đơn mua hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail Purchased Order Successfully',
    type: PurchasedOrderResponseDto,
  })
  public async getDetail(
    @Param() param: GetPurchasedOrderDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.purchasedOrderService.getDetail(request);
  }

  /**
   * Detail Purchased Order
   * @param param
   * @returns
   */
  @Get('/:id/versions/:versionId')
  @ApiOperation({
    tags: ['Purchased Order'],
    summary: 'Detail Purchased Order',
    description: 'Chi tiết đơn mua hàng version',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail Purchased Order Successfully',
    type: PurchasedOrderResponseDto,
  })
  public async getDetailPurchaseOrderVersion(
    @Param() param: GetPurchasedOrderDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.purchasedOrderService.getDetail(request);
  }

  /**
   * Delete Purchased Order
   * @param param
   * @returns
   */
  @Delete('/:id')
  @ApiOperation({
    tags: ['Purchased Order'],
    summary: 'Delete Purchased Order',
    description: 'Xoá đơn mua hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete Purchased Order Successfully',
    type: null,
  })
  public async delete(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderService.delete(request);
  }

  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Purchased Order'],
    summary: 'Confirm Purchased Order',
    description: 'Xác nhận đơn mua hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm Purchased Order Successfully',
    type: PurchasedOrderResponseDto,
  })
  public async confirm(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderService.confirm(request);
  }

  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Purchased Order'],
    summary: 'Reject Purchased Order',
    description: 'Từ chối đơn mua hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject Successfully',
    type: PurchasedOrderResponseDto,
  })
  public async reject(
    @Param() param: IdParamMongoDto,
    @Body() body: ChangePurchasedOrderStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.purchasedOrderService.reject({
      ...request,
      id: param.request.id,
    });
  }

  @Get('/versions/:id')
  @ApiOperation({
    tags: ['Purchased Order Version'],
    summary: 'Get Purchased Order Version detail',
    description: 'Chi tiết phiên bản đơn mua hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get purchased order Version detail successfully',
    type: GetListPurchasedOrderRequestDto,
  })
  public async getPurchasedOrderVersionDetail(
    @Query() payload: GetPurchasedOrderVersionDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.purchasedOrderService.getVersionDetail(request);
  }

  @Get('/generate-code')
  @ApiOperation({
    tags: ['Purchased Order'],
    summary: 'Gen code purchased order',
    description: 'Gen code đơn mua hàng',
  })
  @ApiResponse({
    status: 200,
    type: null,
    description: 'Get successfully',
  })
  public async generateCode(): Promise<any> {
    return await this.purchasedOrderService.generateCode();
  }

  @Put('/:id/change-status')
  @ApiOperation({
    tags: ['Purchased Order'],
    summary: 'Reject Purchased Order',
    description: 'Thay đổi trạng thái đơn hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Change status successfully',
    type: PurchasedOrderResponseDto,
  })
  public async changeStatus(
    @Body() payload: ChangePurchasedOrderStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.purchasedOrderService.changeStatus(request);
  }

  @Get('/:id/versions')
  @ApiOperation({
    tags: ['Purchased Order Version'],
    summary: 'Get Purchased Order Version detail',
    description: 'Danh sách phiên bản của đơn hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get purchased order Version list successfully',
    type: GetListPurchasedOrderRequestDto,
  })
  public async getPurchasedOrderVersionList(
    @Param() payload: GetPurchasedOrderDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.purchasedOrderService.getPurchasedOrderVersionList(request);
  }
}
