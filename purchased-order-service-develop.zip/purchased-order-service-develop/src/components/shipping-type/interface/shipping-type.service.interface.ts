import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { CreateShippingTypeRequestDto } from '../dto/request/create-shipping-type.request.dto';
import { DeleteMultipleShippingTypeRequestDto } from '../dto/request/delete-multiple-shipping-type.request.dto';
import { GetShippingTypeDetailRequestDto } from '../dto/request/get-shipping-type-detail.request.dto';
import { GetShippingTypeListRequestDto } from '../dto/request/get-shipping-type-list.request.dto';
import { UpdateShippingTypeRequestDto } from '../dto/request/update-shipping-type-request.dto';

export interface ShippingTypeServiceInterface {
  create(request: CreateShippingTypeRequestDto): Promise<any>;
  update(request: UpdateShippingTypeRequestDto): Promise<any>;
  updateStatus(request: IdParamMongoDto, isActive?: boolean): Promise<any>;
  getDetail(request: GetShippingTypeDetailRequestDto): Promise<any>;
  getList(request: GetShippingTypeListRequestDto): Promise<any>;
  delete(request: IdParamMongoDto): Promise<any>;
  deleteMultiple(request: DeleteMultipleShippingTypeRequestDto): Promise<any>;
}
