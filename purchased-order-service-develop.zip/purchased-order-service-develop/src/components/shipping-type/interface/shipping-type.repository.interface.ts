import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ShippingTypeModel } from 'src/models/shipping-type/shipping-type.model';
import { GetShippingTypeListRequestDto } from '../dto/request/get-shipping-type-list.request.dto';
import { GetShippingTypeDetailRequestDto } from '../dto/request/get-shipping-type-detail.request.dto';

export interface ShippingTypeRepositoryInterface
  extends BaseInterfaceRepository<ShippingTypeModel> {
  createDocument(request: any): ShippingTypeModel;
  updateDocument(document: ShippingTypeModel, request: any): ShippingTypeModel;
  getList(request: GetShippingTypeListRequestDto): Promise<any>;
  getDetail(request: GetShippingTypeDetailRequestDto): Promise<any>;
}
