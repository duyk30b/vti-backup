export const SHIPPING_TYPE_VALIDATION = {
  CODE: {
    MAX_LENGTH: 50,
  },
  NAME: {
    MAX_LENGTH: 255,
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
};

export enum ShippingTypeStatusEnum {
  INACTIVE = 0,
  ACTIVE = 1,
}

export const CAN_NOT_UPDATE_SHIPPING_TYPE_STATUS = [];
