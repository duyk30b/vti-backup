import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class UserResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose({ name: 'fullName' })
  fullName: string;
}

export class ShippingTypeHistoryReponseDto {
  @ApiProperty()
  @Expose()
  user: UserResponseDto;

  @ApiProperty()
  @Expose()
  content: string[];

  @ApiProperty()
  @Expose()
  createdAt: Date;
}

export class ShippingTypeResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose({ name: 'description' })
  description: string;

  @ApiProperty()
  @Expose()
  @Type(() => UserResponseDto)
  createdBy: UserResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => ShippingTypeHistoryReponseDto)
  histories: ShippingTypeHistoryReponseDto[];
}

export class GetShippingTypeDetailResponseDto extends ShippingTypeResponseDto {}
