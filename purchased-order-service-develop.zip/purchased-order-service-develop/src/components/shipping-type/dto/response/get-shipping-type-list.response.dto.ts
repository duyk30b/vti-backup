import { ShippingTypeResponseDto } from './get-shipping-type-detail.response.dto';

export class GetShippingTypeListResponseDto extends ShippingTypeResponseDto {}
