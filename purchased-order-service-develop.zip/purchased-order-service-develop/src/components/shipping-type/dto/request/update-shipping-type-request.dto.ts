import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsOptional } from 'class-validator';
import { CreateShippingTypeRequestDto } from './create-shipping-type.request.dto';

export class UpdateShippingTypeRequestDto extends CreateShippingTypeRequestDto {
  @ApiProperty()
  @IsOptional()
  @IsMongoId()
  id: string;
}
