import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';

export class DeleteMultipleShippingTypeRequestDto extends BaseDto {
  @ApiProperty({ example: '1,2,3', description: '1,2,3' })
  @IsString()
  ids: string;
}
