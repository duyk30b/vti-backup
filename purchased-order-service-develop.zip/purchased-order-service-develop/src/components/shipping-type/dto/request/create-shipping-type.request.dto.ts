import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsString, MaxLength, MinLength } from 'class-validator';

export class CreateShippingTypeRequestDto extends BaseDto {
  @ApiProperty()
  @MaxLength(255)
  @IsString()
  name: string;

  @ApiProperty()
  @MinLength(2)
  @MaxLength(50)
  @IsString()
  code: string;

  @ApiProperty()
  @IsString()
  description: string;
}
