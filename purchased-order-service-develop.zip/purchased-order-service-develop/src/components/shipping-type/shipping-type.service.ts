import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/mongoose';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { isEmpty, isEqual, map, uniq } from 'lodash';
import { Connection } from 'mongoose';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ShippingTypeModel } from 'src/models/shipping-type/shipping-type.model';
import { CreateShippingTypeRequestDto } from './dto/request/create-shipping-type.request.dto';
import { DeleteMultipleShippingTypeRequestDto } from './dto/request/delete-multiple-shipping-type.request.dto';
import { GetShippingTypeDetailRequestDto } from './dto/request/get-shipping-type-detail.request.dto';
import { GetShippingTypeListRequestDto } from './dto/request/get-shipping-type-list.request.dto';
import { UpdateShippingTypeRequestDto } from './dto/request/update-shipping-type-request.dto';
import { ShippingTypeResponseDto } from './dto/response/get-shipping-type-detail.response.dto';
import { GetShippingTypeListResponseDto } from './dto/response/get-shipping-type-list.response.dto';
import { ShippingTypeRepositoryInterface } from './interface/shipping-type.repository.interface';
import { ShippingTypeServiceInterface } from './interface/shipping-type.service.interface';
import {
  CAN_NOT_UPDATE_SHIPPING_TYPE_STATUS,
  ShippingTypeStatusEnum,
} from './shipping-type.constant';

@Injectable()
export class ShippingTypeService implements ShippingTypeServiceInterface {
  constructor(
    @Inject('ShippingTypeRepositoryInterface')
    protected readonly shippingTypeRepository: ShippingTypeRepositoryInterface,

    @InjectConnection()
    private readonly connection: Connection,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateShippingTypeRequestDto): Promise<any> {
    const { code } = request;

    if (
      !isEmpty(
        await this.shippingTypeRepository.findOneByCondition({
          code,
        }),
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_ALREADY_EXISTS'))
        .build();
    }

    const shippingTypeDocument =
      await this.shippingTypeRepository.createDocument(request);

    return this.save(shippingTypeDocument, request);
  }

  async update(request: UpdateShippingTypeRequestDto): Promise<any> {
    const { id } = request;

    const data = await this.shippingTypeRepository.findOneById(id);

    if (isEmpty(data)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const shippingTypeDocument =
      await this.shippingTypeRepository.updateDocument(data, request);

    return this.save(shippingTypeDocument, request, true);
  }

  async updateStatus(
    request: IdParamMongoDto,
    isActive?: boolean,
  ): Promise<any> {
    const { id, userId } = request;
    const shippingType = await this.shippingTypeRepository.findOneById(id);

    if (isEmpty(shippingType)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (CAN_NOT_UPDATE_SHIPPING_TYPE_STATUS.includes(shippingType.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }

    const status = isActive
      ? ShippingTypeStatusEnum.ACTIVE
      : ShippingTypeStatusEnum.INACTIVE;

    try {
      shippingType.status = status;
      shippingType.histories.push({
        userId: userId,
        content: [
          await this.i18n.translate(
            `message.shippingTypeHistory.${isActive ? 'active' : 'inactive'}`,
          ),
        ],
        createdAt: new Date(),
      });
      await this.shippingTypeRepository.updateById(
        shippingType._id,
        shippingType,
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async delete(request: IdParamMongoDto): Promise<any> {
    try {
      const { id } = request;
      const data = await this.shippingTypeRepository.findOneById(id);
      if (isEmpty(data)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }

      await this.shippingTypeRepository.deleteById(id);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.DELETE_SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getDetail(request: GetShippingTypeDetailRequestDto): Promise<any> {
    const data = await this.shippingTypeRepository.getDetail(request);
    if (isEmpty(data)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const serializedUser = await this.userService.getUserByIds(
      uniq([data.createdByUserId, ...map(data.histories, 'userId')]),
      true,
    );

    const resData = plainToInstance(
      ShippingTypeResponseDto,
      {
        ...data,
        createdBy: serializedUser[data.createdByUserId],
        histories: data.histories.map((history) => ({
          ...history,
          user: serializedUser[history.userId],
        })),
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(resData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(request: GetShippingTypeListRequestDto): Promise<any> {
    const { data, count } = await this.shippingTypeRepository.getList(request);

    const serializedUser = await this.userService.getUserByIds(
      uniq(map(data, 'createdByUserId')),
      true,
    );

    const resData = plainToInstance(
      GetShippingTypeListResponseDto,

      data.map((i) => {
        return {
          ...i,
          createdBy: serializedUser[i.createdByUserId],
        };
      }),
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder({
      items: resData,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async deleteMultiple(
    request: DeleteMultipleShippingTypeRequestDto,
  ): Promise<any> {
    const ids = uniq(request.ids.split(','));

    const data = await this.shippingTypeRepository.findAllByCondition({
      _id: { $in: ids },
    });

    try {
      if (!isEqual(data.length, ids.length)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }

      await this.shippingTypeRepository.deleteManyByCondition({
        _id: { $in: ids },
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.DELETE_SUCCESS'))
        .build();
    } catch (err) {
      console.error('DELETE SHIPPING TYPE ERROR:', err);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  private async save(
    shippingTypeDocument: ShippingTypeModel,
    request: UpdateShippingTypeRequestDto | CreateShippingTypeRequestDto,
    isUpdate?: boolean,
  ) {
    const { userId } = request;

    let shippingType;
    try {
      let contentUpdates = [];
      if (isUpdate) {
        const oldShippingType = await this.shippingTypeRepository.findOneById(
          shippingTypeDocument._id,
        );
        if (shippingTypeDocument.name !== oldShippingType.name)
          contentUpdates.push(
            await this.i18n.translate('message.shippingTypeHistory.update', {
              args: {
                fieldName: 'tên phương thức vận chuyển',
                oldValue: oldShippingType.name,
                newValue: shippingTypeDocument.name,
              },
            }),
          );

        if (shippingTypeDocument.description !== oldShippingType.description)
          contentUpdates.push(
            await this.i18n.translate('message.shippingTypeHistory.update', {
              args: {
                fieldName: 'mô tả phương thức vận chuyển',
                oldValue: oldShippingType.description,
                newValue: shippingTypeDocument.description,
              },
            }),
          );
        if (contentUpdates.length > 0) {
          shippingTypeDocument.histories.push({
            userId: userId,
            content: contentUpdates,
            createdAt: new Date(),
          });
        }
        shippingType = await this.shippingTypeRepository.updateById(
          shippingTypeDocument._id,
          shippingTypeDocument,
        );
      } else {
        contentUpdates = [
          await this.i18n.translate('message.shippingTypeHistory.create'),
        ];
        shippingTypeDocument.histories = [
          {
            userId: userId,
            content: contentUpdates,
            createdAt: new Date(),
          },
        ];
        shippingType = await this.shippingTypeRepository.create(
          shippingTypeDocument,
        );
      }

      const resData = plainToInstance(ShippingTypeResponseDto, shippingType, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(resData)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }
}
