import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { isEmpty } from 'lodash';
import { CreateShippingTypeRequestDto } from './dto/request/create-shipping-type.request.dto';
import { DeleteMultipleShippingTypeRequestDto } from './dto/request/delete-multiple-shipping-type.request.dto';
import { GetShippingTypeDetailRequestDto } from './dto/request/get-shipping-type-detail.request.dto';
import { GetShippingTypeListRequestDto } from './dto/request/get-shipping-type-list.request.dto';
import { UpdateShippingTypeRequestDto } from './dto/request/update-shipping-type-request.dto';
import { ShippingTypeResponseDto } from './dto/response/get-shipping-type-detail.response.dto';
import { ShippingTypeServiceInterface } from './interface/shipping-type.service.interface';
import { ShippingTypeService } from './shipping-type.service';

@Controller('shipping-types')
export class ShippingTypeController {
  constructor(
    @Inject('ShippingTypeServiceInterface')
    private readonly shippingTypeService: ShippingTypeServiceInterface,
  ) {}

  @Post()
  @ApiOperation({
    tags: ['shipping Type'],
    summary: 'Create shipping type',
  })
  @ApiResponse({
    status: 200,
    description: 'Create shipping type  successfully',
    type: ShippingTypeResponseDto,
  })
  public async create(
    @Body() payload: CreateShippingTypeRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.shippingTypeService.create(request);
  }

  @Put('/:id')
  @ApiOperation({
    tags: ['shipping type'],
    summary: 'Update shipping type',
  })
  @ApiResponse({
    status: 200,
    description: 'Update shipping type successfully',
    type: ShippingTypeResponseDto,
  })
  public async update(
    @Body() body: UpdateShippingTypeRequestDto,
    @Param() param: IdParamMongoDto,
  ): Promise<any> {
    const { request, responseError } = body;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = param.request.id;
    return await this.shippingTypeService.update(request);
  }

  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Shipping type'],
    summary: 'Update shipping type status',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  public async lock(@Param() param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.shippingTypeService.updateStatus(request);
  }

  @Put('/:id/active')
  @ApiOperation({
    tags: ['Shipping type'],
    summary: 'Update shipping type status',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  public async unlock(@Param() param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.shippingTypeService.updateStatus(request, true);
  }

  @Delete('/:id')
  @ApiOperation({
    tags: ['shipping type'],
    summary: 'Delete shipping type',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete shipping type successfully',
    type: null,
  })
  public async delete(@Param() param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.shippingTypeService.delete(request);
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['shipping type'],
    summary: 'shipping type detail',
  })
  @ApiResponse({
    status: 200,
    description: 'Get shipping type successfully',
    type: ShippingTypeResponseDto,
  })
  public async getDetail(
    @Param() param: GetShippingTypeDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.shippingTypeService.getDetail(request);
  }

  @Get('')
  @ApiOperation({
    tags: ['shipping type'],
    summary: 'Get shipping type list',
  })
  @ApiResponse({
    status: 200,
    description: 'Get shipping type successfully',
  })
  public async getList(
    @Query() payload: GetShippingTypeListRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.shippingTypeService.getList(request);
  }

  @Delete('/multiple')
  @ApiOperation({
    tags: ['shipping type'],
    summary: 'Delete multiple shipping type ',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete multiple shipping type successfully',
  })
  public async deleteMultiple(
    @Query() body: DeleteMultipleShippingTypeRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.shippingTypeService.deleteMultiple(request);
  }
}
