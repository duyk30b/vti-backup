import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ShippingTypeSchema } from 'src/models/shipping-type/shipping-type.schema';
import { ShippingTypeRepository } from 'src/repository/shipping-type/shipping-type.repository';
import { ShippingTypeController } from './shipping-type.controller';
import { ShippingTypeService } from './shipping-type.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: 'ShippingTypeModel',
        schema: ShippingTypeSchema,
      },
    ]),
  ],
  exports: [
    MongooseModule,
    {
      provide: 'ShippingTypeRepositoryInterface',
      useClass: ShippingTypeRepository,
    },
    {
      provide: 'ShippingTypeServiceInterface',
      useClass: ShippingTypeService,
    },
  ],
  providers: [
    {
      provide: 'ShippingTypeServiceInterface',
      useClass: ShippingTypeService,
    },
    {
      provide: 'ShippingTypeRepositoryInterface',
      useClass: ShippingTypeRepository,
    },
  ],
  controllers: [ShippingTypeController],
})
export class ShippingTypeModule {}
