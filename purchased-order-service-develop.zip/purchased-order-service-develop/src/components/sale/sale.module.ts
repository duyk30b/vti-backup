import { SaleService } from '@components/sale/sale.service';
import { ConfigService } from '@config/config.service';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
  ],
  controllers: [],
})
export class SaleModule {}
