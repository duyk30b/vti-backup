export interface SaleServiceInterface {
  getVendorsByIds(ids: number[], serialize?: boolean): Promise<any>;
  getVendorsByNameKeyword(nameKeyword: any, onlyId?: boolean): Promise<any>;
}
