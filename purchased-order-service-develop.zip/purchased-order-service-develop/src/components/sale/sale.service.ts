import { SaleServiceInterface } from '@components/sale/interface/sale.service.interface';
import { NATS_SALE } from '@config/nats.config';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { isEmpty, keyBy, map, uniq } from 'lodash';
import { ResponseCodeEnum } from './../../constant/response-code.enum';

@Injectable()
export class SaleService implements SaleServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async getVendorsByIds(ids: number[], serialize?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_vendor_by_ids`,
      {
        ids,
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    if (serialize) {
      return keyBy(response.data, 'id');
    }

    return response.data;
  }

  async getVendorsByNameKeyword(nameKeyword, onlyId?: boolean): Promise<any> {
    if (isEmpty(nameKeyword)) {
      return [];
    }

    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_vendors_by_name_keyword`,
      {
        nameKeyword,
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    if (onlyId) {
      return uniq(map(response.data, 'id'));
    }

    return response.data;
  }
}
