import { NATS_ATTRIBUTE } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { AttributeServiceInterface } from './interface/attribute.service.interface';

@Injectable()
export class AttributeService implements AttributeServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async getTemplateById(id: string): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_ATTRIBUTE}.get_template_by_id`,
        {
          id,
        },
      );

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return null;
      }
      return response.data;
    } catch (error) {
      return null;
    }
  }

  async getTemplateByCode(code: string): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ATTRIBUTE}.get_templates_by_code`,
      { code },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return null;
    }
    return response.data;
  }

  async validateTemplateAttributes(payload): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ATTRIBUTE}.validate_template_attributes`,
      {
        data: payload,
      },
    );

    return response;
  }

  async getAttributeByIds(ids: string[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ATTRIBUTE}.get_attribute_by_ids`,
      ids,
    );

    return response.data;
  }

  async getAttributeByCodes(codes: string[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ATTRIBUTE}.get_attribute_by_codes`,
      {
        filter: [
          {
            column: 'codes',
            text: codes.join(','),
          },
        ],
      },
    );

    return response.data?.items || [];
  }

  async getAttributeGroupsByCodes(codes: string[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ATTRIBUTE}.get_attribute_groups_by_codes`,
      {
        codes,
      },
    );

    return response.data || [];
  }
}
