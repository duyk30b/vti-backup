import { ConfigService } from '@config/config.service';
import { HttpClientModule } from '@core/components/http-client/http-client.module';
import { Global, Module } from '@nestjs/common';
import { AttributeService } from './attribute.service';

@Global()
@Module({
  imports: [HttpClientModule],
  exports: [
    {
      provide: 'AttributeServiceInterface',
      useClass: AttributeService,
    },
  ],
  providers: [
    ConfigService,

    {
      provide: 'AttributeServiceInterface',
      useClass: AttributeService,
    },
  ],
  controllers: [],
})
export class AttributeModule {}
