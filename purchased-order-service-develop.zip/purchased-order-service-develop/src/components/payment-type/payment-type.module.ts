import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { PaymentTypeSchema } from 'src/models/payment-type/payment-type.schema';
import { PaymentTypeRepository } from 'src/repository/payment-type/payment-type.repository';
import { PaymentTypeController } from './payment-type.controller';
import { PaymentTypeService } from './payment-type.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: 'PaymentTypeModel',
        schema: PaymentTypeSchema,
      },
    ]),
  ],
  exports: [
    MongooseModule,
    {
      provide: 'PaymentTypeRepositoryInterface',
      useClass: PaymentTypeRepository,
    },
    {
      provide: 'PaymentTypeServiceInterface',
      useClass: PaymentTypeService,
    },
  ],
  providers: [
    {
      provide: 'PaymentTypeServiceInterface',
      useClass: PaymentTypeService,
    },
    {
      provide: 'PaymentTypeRepositoryInterface',
      useClass: PaymentTypeRepository,
    },
  ],
  controllers: [PaymentTypeController],
})
export class PaymentTypeModule {}
