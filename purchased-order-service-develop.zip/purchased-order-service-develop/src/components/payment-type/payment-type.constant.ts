export const PAYMENT_TYPE_VALIDATION = {
  CODE: {
    MAX_LENGTH: 50,
  },
  NAME: {
    MAX_LENGTH: 255,
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
};

export enum PaymentTypeStatusEnum {
  INACTIVE = 0,
  ACTIVE = 1,
}

export const CAN_NOT_UPDATE_PAYMENT_TYPE_STATUS = [];
