import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { CreatePaymentTypeRequestDto } from '../dto/request/create-payment-type.request.dto';
import { DeleteMultiplePaymentTypeRequestDto } from '../dto/request/delete-multiple-payment-type.request.dto';
import { GetPaymentTypeDetailRequestDto } from '../dto/request/get-payment-type-detail.request.dto';
import { GetPaymentTypeListRequestDto } from '../dto/request/get-payment-type-list.request.dto';
import { UpdatePaymentTypeRequestDto } from '../dto/request/update-payment-type-request.dto';

export interface PaymentTypeServiceInterface {
  create(request: CreatePaymentTypeRequestDto): Promise<any>;
  update(request: UpdatePaymentTypeRequestDto): Promise<any>;
  updateStatus(request: IdParamMongoDto, isActive?: boolean): Promise<any>;
  getDetail(request: GetPaymentTypeDetailRequestDto): Promise<any>;
  getList(request: GetPaymentTypeListRequestDto): Promise<any>;
  delete(request: IdParamMongoDto): Promise<any>;
  deleteMultiple(request: DeleteMultiplePaymentTypeRequestDto): Promise<any>;
}
