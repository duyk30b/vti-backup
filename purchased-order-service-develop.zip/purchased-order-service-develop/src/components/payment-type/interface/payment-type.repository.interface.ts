import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { PaymentTypeModel } from 'src/models/payment-type/payment-type.model';
import { GetPaymentTypeListRequestDto } from '../dto/request/get-payment-type-list.request.dto';
import { GetPaymentTypeDetailRequestDto } from '../dto/request/get-payment-type-detail.request.dto';

export interface PaymentTypeRepositoryInterface
  extends BaseInterfaceRepository<PaymentTypeModel> {
  createDocument(request: any): PaymentTypeModel;
  updateDocument(document: PaymentTypeModel, request: any): PaymentTypeModel;
  getDetail(request: GetPaymentTypeDetailRequestDto): Promise<any>;
  getList(request: GetPaymentTypeListRequestDto): Promise<any>;
}
