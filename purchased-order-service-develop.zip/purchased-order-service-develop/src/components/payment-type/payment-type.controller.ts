import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { isEmpty } from 'lodash';
import { CreatePaymentTypeRequestDto } from './dto/request/create-payment-type.request.dto';
import { DeleteMultiplePaymentTypeRequestDto } from './dto/request/delete-multiple-payment-type.request.dto';
import { GetPaymentTypeDetailRequestDto } from './dto/request/get-payment-type-detail.request.dto';
import { GetPaymentTypeListRequestDto } from './dto/request/get-payment-type-list.request.dto';
import { UpdatePaymentTypeRequestDto } from './dto/request/update-payment-type-request.dto';
import { PaymentTypeResponseDto } from './dto/response/get-payment-type-detail.response.dto';
import { GetPaymentTypeListResponseDto } from './dto/response/get-payment-type-list.response.dto';
import { PaymentTypeService } from './payment-type.service';

@Controller('payment-types')
export class PaymentTypeController {
  constructor(
    @Inject('PaymentTypeServiceInterface')
    private readonly paymentTypeService: PaymentTypeService,
  ) {}

  @Post()
  @ApiOperation({
    tags: ['Payment Type'],
    summary: 'Create payment type',
  })
  @ApiResponse({
    status: 200,
    description: 'Create payment type  successfully',
    type: PaymentTypeResponseDto,
  })
  public async create(
    @Body() payload: CreatePaymentTypeRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.paymentTypeService.create(request);
  }

  @Put('/:id')
  @ApiOperation({
    tags: ['Payment type'],
    summary: 'Update payment type',
  })
  @ApiResponse({
    status: 200,
    description: 'Update payment type successfully',
    type: PaymentTypeResponseDto,
  })
  public async update(
    @Body() body: UpdatePaymentTypeRequestDto,
    @Param() param: IdParamMongoDto,
  ): Promise<any> {
    const { request, responseError } = body;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = param.request.id;
    return await this.paymentTypeService.update(request);
  }

  @Delete('/:id')
  @ApiOperation({
    tags: ['Payment type'],
    summary: 'Delete payment type',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete payment type successfully',
    type: null,
  })
  public async delete(@Param() param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.paymentTypeService.delete(request);
  }

  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Payment type'],
    summary: 'Update payment type status',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  public async lock(@Param() param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    const { id } = request;
    return await this.paymentTypeService.updateStatus(request);
  }

  @Put('/:id/active')
  @ApiOperation({
    tags: ['Payment type'],
    summary: 'Update payment type status',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  public async unlock(@Param() param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.paymentTypeService.updateStatus(request, true);
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['Payment type'],
    summary: 'payment type detail',
  })
  @ApiResponse({
    status: 200,
    description: 'Get payment type successfully',
    type: PaymentTypeResponseDto,
  })
  public async getDetail(
    @Param() param: GetPaymentTypeDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.paymentTypeService.getDetail(request);
  }

  @Get('')
  @ApiOperation({
    tags: ['Payment type'],
    summary: 'Get payment type list',
  })
  @ApiResponse({
    status: 200,
    description: 'Get payment type successfully',
    type: GetPaymentTypeListResponseDto,
  })
  public async getList(
    @Query() payload: GetPaymentTypeListRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.paymentTypeService.getList(request);
  }

  @Delete('/multiple')
  @ApiOperation({
    tags: ['Payment type'],
    summary: 'Delete payment type ',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete payment type successfully',
  })
  public async deleteMultiple(
    @Query() query: DeleteMultiplePaymentTypeRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.paymentTypeService.deleteMultiple(request);
  }
}
