import { PaymentTypeResponseDto } from './get-payment-type-detail.response.dto';

export class GetPaymentTypeListResponseDto extends PaymentTypeResponseDto {}
