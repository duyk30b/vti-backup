import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsOptional } from 'class-validator';
import { CreatePaymentTypeRequestDto } from './create-payment-type.request.dto';

export class UpdatePaymentTypeRequestDto extends CreatePaymentTypeRequestDto {
  @ApiProperty()
  @IsOptional()
  @IsMongoId()
  id: string;
}
