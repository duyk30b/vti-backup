import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/mongoose';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { isEmpty, isEqual, map, uniq } from 'lodash';
import { Connection } from 'mongoose';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { PaymentTypeModel } from 'src/models/payment-type/payment-type.model';
import { PaymentTypeRepository } from 'src/repository/payment-type/payment-type.repository';
import { CreatePaymentTypeRequestDto } from './dto/request/create-payment-type.request.dto';
import { DeleteMultiplePaymentTypeRequestDto } from './dto/request/delete-multiple-payment-type.request.dto';
import { GetPaymentTypeDetailRequestDto } from './dto/request/get-payment-type-detail.request.dto';
import { GetPaymentTypeListRequestDto } from './dto/request/get-payment-type-list.request.dto';
import { UpdatePaymentTypeRequestDto } from './dto/request/update-payment-type-request.dto';
import { PaymentTypeResponseDto } from './dto/response/get-payment-type-detail.response.dto';
import { GetPaymentTypeListResponseDto } from './dto/response/get-payment-type-list.response.dto';
import { PaymentTypeServiceInterface } from './interface/payment-type.service.interface';
import {
  CAN_NOT_UPDATE_PAYMENT_TYPE_STATUS,
  PaymentTypeStatusEnum,
} from './payment-type.constant';

@Injectable()
export class PaymentTypeService implements PaymentTypeServiceInterface {
  constructor(
    @Inject('PaymentTypeRepositoryInterface')
    protected readonly paymentTypeRepository: PaymentTypeRepository,

    @InjectConnection()
    private readonly connection: Connection,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreatePaymentTypeRequestDto): Promise<any> {
    const { code } = request;

    if (
      !isEmpty(
        await this.paymentTypeRepository.findOneByCondition({
          code,
        }),
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_ALREADY_EXISTS'))
        .build();
    }

    const paymentTypeDocument = await this.paymentTypeRepository.createDocument(
      request,
    );

    return this.save(paymentTypeDocument, request);
  }

  async update(request: UpdatePaymentTypeRequestDto): Promise<any> {
    const { id } = request;

    const data = await this.paymentTypeRepository.findOneById(id);

    if (isEmpty(data)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const paymentTypeDocument = await this.paymentTypeRepository.updateDocument(
      data,
      request,
    );

    return this.save(paymentTypeDocument, request, true);
  }

  async delete(request: IdParamMongoDto): Promise<any> {
    try {
      const { id } = request;
      const data = await this.paymentTypeRepository.findOneById(id);
      if (isEmpty(data)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }

      await this.paymentTypeRepository.deleteById(id);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.DELETE_SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getDetail(request: GetPaymentTypeDetailRequestDto): Promise<any> {
    const data = await this.paymentTypeRepository.getDetail(request);
    if (isEmpty(data)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const serializedUser = await this.userService.getUserByIds(
      uniq([data.createdByUserId, ...map(data.histories, 'userId')]),
      true,
    );

    const resData = plainToInstance(
      PaymentTypeResponseDto,
      {
        ...data,
        createdBy: serializedUser[data.createdByUserId],
        histories: data.histories.map((history) => ({
          ...history,
          user: serializedUser[history.userId],
        })),
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return resData;

    return new ResponseBuilder(resData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateStatus(
    request: IdParamMongoDto,
    isActive?: boolean,
  ): Promise<any> {
    const { id, userId } = request;
    const paymentType = (await this.paymentTypeRepository.findOneById(
      id,
    )) as PaymentTypeModel;

    if (isEmpty(paymentType)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (CAN_NOT_UPDATE_PAYMENT_TYPE_STATUS.includes(paymentType.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }

    const status = isActive
      ? PaymentTypeStatusEnum.ACTIVE
      : PaymentTypeStatusEnum.INACTIVE;

    try {
      paymentType.status = status;
      paymentType.histories.push({
        userId: userId,
        content: [
          await this.i18n.translate(
            `message.paymentTypeHistory.${isActive ? 'active' : 'inactive'}`,
          ),
        ],
        createdAt: new Date(),
      });
      await this.paymentTypeRepository.updateById(paymentType._id, paymentType);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getList(request: GetPaymentTypeListRequestDto): Promise<any> {
    const { data, count } = await this.paymentTypeRepository.getList(request);

    const serializedUser = await this.userService.getUserByIds(
      uniq(map(data, 'createdByUserId')),
      true,
    );

    const resData = plainToInstance(
      GetPaymentTypeListResponseDto,
      data.map((i) => {
        return {
          ...i,
          createdBy: serializedUser[i.createdByUserId],
        };
      }),
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder({
      items: resData,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async deleteMultiple(
    request: DeleteMultiplePaymentTypeRequestDto,
  ): Promise<any> {
    const ids = uniq(request.ids.split(','));

    const data = await this.paymentTypeRepository.findAllByCondition({
      _id: { $in: ids },
    });

    try {
      if (!isEqual(data.length, ids.length)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }

      await this.paymentTypeRepository.deleteManyByCondition({
        _id: { $in: ids },
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.DELETE_SUCCESS'))
        .build();
    } catch (err) {
      console.error('DELETE PAYMENT TYPE ERROR:', err);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  private async save(
    paymentTypeDocument: PaymentTypeModel,
    request: UpdatePaymentTypeRequestDto | CreatePaymentTypeRequestDto,
    isUpdate?: boolean,
  ) {
    const { userId } = request;
    let paymentType;
    try {
      let contentUpdates = [];
      if (isUpdate) {
        const oldPaymentType = await this.paymentTypeRepository.findOneById(
          paymentTypeDocument._id,
        );
        if (paymentTypeDocument.name !== oldPaymentType.name)
          contentUpdates.push(
            await this.i18n.translate('message.paymentTypeHistory.update', {
              args: {
                fieldName: 'tên phương thức thanh toán',
                oldValue: oldPaymentType.name,
                newValue: paymentTypeDocument.name,
              },
            }),
          );

        if (paymentTypeDocument.description !== oldPaymentType.description)
          contentUpdates.push(
            await this.i18n.translate('message.paymentTypeHistory.update', {
              args: {
                fieldName: 'mô tả phương thức thanh toán',
                oldValue: oldPaymentType.description,
                newValue: paymentTypeDocument.description,
              },
            }),
          );
        if (contentUpdates.length > 0) {
          paymentTypeDocument.histories.push({
            userId: userId,
            content: contentUpdates,
            createdAt: new Date(),
          });
        }
        paymentType = await this.paymentTypeRepository.updateById(
          paymentTypeDocument._id,
          paymentTypeDocument,
        );
      } else {
        contentUpdates = [
          await this.i18n.translate('message.paymentTypeHistory.create'),
        ];
        paymentTypeDocument.histories = [
          {
            userId: userId,
            content: contentUpdates,
            createdAt: new Date(),
          },
        ];

        paymentType = await this.paymentTypeRepository.create(
          paymentTypeDocument,
        );
      }

      const resData = plainToInstance(PaymentTypeResponseDto, paymentType, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(resData)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }
}
