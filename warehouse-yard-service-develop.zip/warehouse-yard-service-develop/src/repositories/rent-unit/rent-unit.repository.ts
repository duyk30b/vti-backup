import { escapeCharForSearch } from '@utils/common';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { isEmpty } from 'lodash';
import { RentUnitEntity } from '@entities/rent-unit/rent-unit.entity';
import { RentUnitRepositoryInterface } from '@components/rent-unit/interface/rent-unit.repository.interface';
import { CreateRentUnitRequestDto } from '@components/rent-unit/dto/request/create-rent-unit.request.dto';
import { RentUnitStatusEnum } from '@components/rent-unit/rent-unit.constant';
import { UpdateRentUnitRequestDto } from '@components/rent-unit/dto/request/update-rent-unit.request.dto';
import { GetListRentUnitRequestDto } from '@components/rent-unit/dto/request/get-list-rent-unit.request.dto';
import { RentUnitAttributeEntity } from '@entities/rent-unit/rent-unit-attribute.entity';
import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';

@Injectable()
export class RentUnitRepository
  extends BaseAbstractRepository<RentUnitEntity>
  implements RentUnitRepositoryInterface
{
  constructor(
    @InjectRepository(RentUnitEntity)
    private readonly rentUnitRepository: Repository<RentUnitEntity>,
  ) {
    super(rentUnitRepository);
  }
  createEntity(request: CreateRentUnitRequestDto): RentUnitEntity {
    const entity = new RentUnitEntity();
    entity.name = request.name;
    entity.code = request.code;
    entity.description = request.description;
    entity.status = RentUnitStatusEnum.CREATED;
    entity.createdByUserId = request['userId'];
    entity.lastestEditedUserId = request['userId'];
    return entity;
  }
  updateEntity(
    entity: RentUnitEntity,
    request: UpdateRentUnitRequestDto,
  ): RentUnitEntity {
    entity.code = request.code || entity.code;
    entity.name = request.name || entity.name;
    entity.description = request.description || entity.description;
    entity.createdByUserId = entity.createdByUserId;
    entity.lastestEditedUserId = request['userId'];
    return entity;
  }

  async getList(request: GetListRentUnitRequestDto): Promise<any> {
    const { filter, skip, sort, take, keyword, isGetAll } = request;

    const query = await this.rentUnitRepository
      .createQueryBuilder('ru')
      .select([
        'ru.id AS "id"',
        'ru.name AS "name"',
        'ru.code AS "code"',
        'ru.description AS "description"',
        'ru.status AS "status"',
        'ru.updated_at AS "updatedAt"',
        'ru.created_at AS "createdAt"',
      ]);

    if (keyword) {
      query
        .orWhere(
          `LOWER(unaccent("ru"."name")) LIKE LOWER(unaccent(:pkeyWord)) escape '\\'`,
          {
            pkeyWord: `%${escapeCharForSearch(keyword)}%`,
          },
        )
        .orWhere(
          `LOWER(unaccent("ru"."code")) LIKE LOWER(unaccent(:pkeyWord)) escape '\\'`,
          {
            pkeyWord: `%${escapeCharForSearch(keyword)}%`,
          },
        );
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        switch (item.column) {
          case 'name':
            query.andWhere(
              `lower(unaccent("ru"."name")) like lower(unaccent(:name)) escape '\\'`,
              {
                name: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'code':
            query.andWhere(
              `lower(unaccent("ru"."code")) like lower(unaccent(:code)) escape '\\'`,
              {
                code: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'status':
            query.andWhere(`"ru"."status" IN (:...status)`, {
              status: item.text.split(','),
            });
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        switch (item.column) {
          case 'code':
            query.addOrderBy('ru.code', item.order);
            break;
          case 'name':
            query.addOrderBy('ru.name', item.order);
            break;
          default:
            break;
        }
      });
    } else {
      query.orderBy('ru.id', 'DESC');
    }

    const data = parseInt(isGetAll)
      ? await query.getRawMany()
      : await query.offset(skip).limit(take).getRawMany();
    const count = await query.getCount();

    return {
      result: data,
      total: count,
    };
  }

  public async getDetail(id: number) {
    const result = await this.rentUnitRepository
      .createQueryBuilder('ru')
      .select([
        'ru.id AS id',
        'ru.code AS code',
        'ru.name AS name',
        'ru.description AS description',
        'ru.status AS status',
        'ru.created_at AS "createdAt"',
        'ru.updated_at AS "updatedAt"',
        'ru.created_by_user_id AS "createdByUserId"',
        'ru.lastest_edited_user_id AS "latestEditedUserId"',
        `CASE WHEN count(rua) = 0 THEN '[]' ELSE JSON_AGG (JSONB_BUILD_OBJECT('name', "rua"."name", 'value', "rua"."value")) END AS "customFields"`,
      ])
      .leftJoin(RentUnitAttributeEntity, 'rua', 'ru.id = rua.rent_unit_id')
      .where('ru.id = :id', { id: id })
      .groupBy('ru.id')
      .getRawOne();
    return result;
  }
}
