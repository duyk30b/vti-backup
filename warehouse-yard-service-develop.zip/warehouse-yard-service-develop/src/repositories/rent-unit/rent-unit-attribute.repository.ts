import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { RentUnitAttributeEntity } from '@entities/rent-unit/rent-unit-attribute.entity';
import { CreateRentUnitAttributeRequestDto } from '@components/rent-unit/dto/request/create-rent-unit-attribute.request.dto';
import { UpdateRentUnitAttributeRequestDto } from '@components/rent-unit/dto/request/update-rent-unit-attribute.request.dto';
import { RentUnitAttributeRepositoryInterface } from '@components/rent-unit/interface/rent-unit-attribute.repository.interface';
import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';

@Injectable()
export class RentUnitAttributeRepository
  extends BaseAbstractRepository<RentUnitAttributeEntity>
  implements RentUnitAttributeRepositoryInterface
{
  constructor(
    @InjectRepository(RentUnitAttributeEntity)
    private readonly rentUnitAttributeRepository: Repository<RentUnitAttributeEntity>,
  ) {
    super(rentUnitAttributeRepository);
  }
  createEntity(
    request: CreateRentUnitAttributeRequestDto,
  ): RentUnitAttributeEntity {
    const entity = new RentUnitAttributeEntity();
    entity.name = request.name;
    entity.value = request.value;
    entity.rentUnitId = request.rentUnitId;
    return entity;
  }
  updateEntity(
    request: UpdateRentUnitAttributeRequestDto,
  ): RentUnitAttributeEntity {
    const entity = new RentUnitAttributeEntity();
    entity.id = request?.id;
    entity.value = request.value || entity.value;
    entity.name = request.name || entity.name;
    entity.rentUnitId = request.rentUnitId || entity.rentUnitId;
    return entity;
  }
}
