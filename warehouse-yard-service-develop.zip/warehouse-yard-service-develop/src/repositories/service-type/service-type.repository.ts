import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { ServiceTypeEntity } from '@entities/service-type/service-type.entity';
import { ServiceTypeAtrributeEntity } from '@entities/service-type/service-type-attribute.entity';
import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { ServiceTypeRepoInterface } from '@components/service-type/interface/service-type.repository.interface';
import { CreateServiceTypeRequestDto } from '@components/service-type/dto/request/create-service-type.request.dto';
import { GetServiceTypeListRequestDto } from '@components/service-type/dto/request/search-service-type.request.dto';
import { escapeCharForSearch } from '@utils/common';
import { isEmpty } from 'lodash';

@Injectable()
export class ServiceTypeRepo
  extends BaseAbstractRepository<ServiceTypeEntity>
  implements ServiceTypeRepoInterface
{
  constructor(
    @InjectRepository(ServiceTypeEntity)
    private readonly serviceTypeRepository: Repository<ServiceTypeEntity>,
  ) {
    super(serviceTypeRepository);
  }

  createEntity(request: CreateServiceTypeRequestDto) {
    const entity = new ServiceTypeEntity();
    entity.code = request.code;
    entity.name = request.name;
    entity.description = request?.description;
    entity.createdByUserId = request['userId'];
    entity.lastestEditedUserId = request['userId'];
    return entity;
  }

  updateEntity(id: number, request: CreateServiceTypeRequestDto) {
    const entity = new ServiceTypeEntity();
    entity.id = id;
    entity.code = request.code;
    entity.name = request.name;
    entity.description = request?.description;
    entity.createdByUserId = entity.createdByUserId;
    entity.lastestEditedUserId = request['userId'];
    return entity;
  }

  public async getList(request: GetServiceTypeListRequestDto) {
    const { keyword, skip, take, isGetAll, sort, filter } = request;
    let query = this.serviceTypeRepository
      .createQueryBuilder('st')
      .select([
        'st.id AS id',
        'st.name AS name',
        'st.code AS code',
        'st.status AS status',
      ]);

    if (keyword) {
      query = query
        .orWhere(`LOWER("st".name) LIKE LOWER(:pkeyWord) escape '\\'`, {
          pkeyWord: `%${escapeCharForSearch(keyword)}%`,
        })
        .orWhere(`LOWER("st".code) LIKE LOWER(:pkeyWord) escape '\\'`, {
          pkeyWord: `%${escapeCharForSearch(keyword)}%`,
        });
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        switch (item.column) {
          case 'code':
            query.andWhere(
              `lower(unaccent("st"."code")) like lower(unaccent(:code)) escape '\\'`,
              {
                code: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'name':
            query.andWhere(
              `lower(unaccent("st"."name")) like lower(unaccent(:name)) escape '\\'`,
              {
                name: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'status':
            query.andWhere(`"st"."status" IN (:...status)`, {
              status: item.text.split(','),
            });
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        switch (item.column) {
          case 'code':
            query.addOrderBy('st.code', item.order);
            break;
          case 'name':
            query.addOrderBy('st.name', item.order);
            break;
          default:
            break;
        }
      });
    } else {
      query.orderBy('st.id', 'DESC');
    }

    query.addGroupBy('st.id');

    const data = parseInt(isGetAll)
      ? await query.getRawMany()
      : await query.offset(skip).limit(take).getRawMany();

    const total = await query.getCount();

    return {
      result: data,
      count: total,
    };
  }

  public async getDetail(id: number) {
    const result = await this.serviceTypeRepository
      .createQueryBuilder('st')
      .select([
        'st.id AS id',
        'st.code AS code',
        'st.name AS name',
        'st.description AS description',
        'st.status AS status',
        'st.created_at AS "createdAt"',
        'st.updated_at AS "updatedAt"',
        'st.created_by_user_id AS "createdByUserId"',
        'st.lastest_edited_user_id AS "latestEditedUserId"',
        `CASE WHEN count(sta) = 0 THEN '[]' ELSE JSON_AGG (JSONB_BUILD_OBJECT('name', "sta"."name", 'value', "sta"."value")) END AS "customFields"`,
      ])
      .leftJoin(
        ServiceTypeAtrributeEntity,
        'sta',
        'st.id = sta.service_type_id',
      )
      .where('st.id = :id', { id: id })
      .groupBy('st.id')
      .getRawOne();
    return result;
  }

  public async delete(id: number) {
    const serviceType = await this.serviceTypeRepository.find({
      where: { id: id },
    });

    return await this.serviceTypeRepository.remove(serviceType);
  }
}
