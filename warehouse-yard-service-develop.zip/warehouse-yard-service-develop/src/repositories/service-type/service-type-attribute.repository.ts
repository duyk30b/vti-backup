import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { ServiceTypeAtrributeEntity } from '@entities/service-type/service-type-attribute.entity';
import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { ServiceTypeAttributesRepositoryInterface } from '@components/service-type/interface/service-type-attribute.repository.interface';
import { CreateServiceTypeAttributeRequestDto } from '@components/service-type/dto/request/create-service-type-attribute.request.dto';
import { UpdateServiceTypeAttributeRequestDto } from '@components/service-type/dto/request/update-service-type-attribute.request.dto';
@Injectable()
export class ServiceTypeAttributesRepository
  extends BaseAbstractRepository<ServiceTypeAtrributeEntity>
  implements ServiceTypeAttributesRepositoryInterface
{
  constructor(
    @InjectRepository(ServiceTypeAtrributeEntity)
    private readonly serviceTypeAttributeRepository: Repository<ServiceTypeAtrributeEntity>,
  ) {
    super(serviceTypeAttributeRepository);
  }

  createEntity(request: CreateServiceTypeAttributeRequestDto) {
    const entity = new ServiceTypeAtrributeEntity();
    entity.name = request.name;
    entity.value = request.value;
    entity.serviceTypeId = request.serviceTypeId;

    return entity;
  }

  updateEntity(request: UpdateServiceTypeAttributeRequestDto) {
    const entity = new ServiceTypeAtrributeEntity();
    entity.id = request?.id;
    entity.name = request.name;
    entity.value = request.value;
    entity.serviceTypeId = request.serviceTypeId;

    return entity;
  }
}
