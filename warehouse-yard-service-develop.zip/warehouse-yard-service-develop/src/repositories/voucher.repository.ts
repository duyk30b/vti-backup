import { CreateVoucherRequestDto } from '@components/voucher/dto/request/create-voucher.request.dto';
import { GetListVoucherRequestDto } from '@components/voucher/dto/request/list-voucher.request.dto';
import { VoucherRepositoryInterface } from '@components/voucher/interface/voucher.repository.interface';
import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { VoucherAttributeEntity } from '@entities/voucher/voucher-attribute.entity';
import { VoucherEntity } from '@entities/voucher/voucher.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { escapeCharForSearch } from '@utils/common';
import { SetStatusDto } from '@utils/set-status.dto';
import { isEmpty } from 'lodash';
import { Repository } from 'typeorm';

@Injectable()
export class VoucherRepository
  extends BaseAbstractRepository<VoucherEntity>
  implements VoucherRepositoryInterface
{
  constructor(
    @InjectRepository(VoucherEntity)
    private readonly voucherRepository: Repository<VoucherEntity>,
  ) {
    super(voucherRepository);
  }

  confirm(payload: SetStatusDto): Promise<any> {
    return Promise.resolve(undefined);
  }

  createEntity(request: CreateVoucherRequestDto): VoucherEntity {
    const entity = new VoucherEntity();
    entity.name = request.name;
    entity.code = request.code;
    entity.percentage = request.percentage;
    entity.description = request.description;
    entity.dateFrom = request.dateFrom;
    entity.dateTo = request.dateTo;
    entity.createdByUserId = request['userId'];
    entity.lastestEditedUserId = request['userId'];
    return entity;
  }

  async detail(id: number): Promise<any> {
    const result = await this.voucherRepository
      .createQueryBuilder('v')
      .select([
        'v.id AS id',
        'v.code AS code',
        'v.name AS name',
        'v.description AS description',
        'v.percentage AS percentage',
        'v.status AS status',
        'v.created_at AS "createdAt"',
        'v.updated_at AS "updatedAt"',
        'v.date_from AS "dateFrom"',
        'v.date_to AS "dateTo"',
        'v.created_by_user_id AS "createdByUserId"',
        'v.lastest_edited_user_id AS "latestEditedUserId"',
        `CASE WHEN count(va) = 0 THEN '[]' ELSE JSON_AGG (JSONB_BUILD_OBJECT('name', "va"."name", 'value', "va"."value")) END AS "customFields"`,
      ])
      .leftJoin(VoucherAttributeEntity, 'va', 'v.id = va.voucher_id')
      .where('v.id = :id', { id })
      .groupBy('v.id')
      .getRawOne();
    return result;
  }

  async getList(request: GetListVoucherRequestDto): Promise<any> {
    const { keyword, skip, take, isGetAll, sort, filter } = request;

    const query = this.voucherRepository
      .createQueryBuilder('v')
      .select([
        'v.id AS id',
        'v.name AS name',
        'v.code AS code',
        'v.status AS status',
        'v.percentage AS percentage',
        'v.date_from AS "dateFrom"',
        'v.date_to AS "dateTo"',
      ]);

    if (keyword) {
      query
        .orWhere(`LOWER("v".name) LIKE LOWER(:pkeyWord) escape '\\'`, {
          pkeyWord: `%${escapeCharForSearch(keyword)}%`,
        })
        .orWhere(`LOWER("v".code) LIKE LOWER(:pkeyWord) escape '\\'`, {
          pkeyWord: `%${escapeCharForSearch(keyword)}%`,
        });
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        switch (item.column) {
          case 'code':
            query.andWhere(
              `lower(unaccent("v"."code")) like lower(unaccent(:code)) escape '\\'`,
              {
                code: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'name':
            query.andWhere(
              `lower(unaccent("v"."name")) like lower(unaccent(:name)) escape '\\'`,
              {
                name: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'percentage':
            query.andWhere(`"v"."percentage" = :percentage`, {
              percentage: item.text,
            });
            break;
          case 'date':
            const dateFrom = item.text.split('|')[0];
            const dateTo = item.text.split('|')[1];
            query.andWhere(
              `cast("v"."date_from" as date) >= cast(:dateFrom as date) AND cast("v"."date_to" as date) <= cast(:dateTo as date)`,
              {
                dateFrom: dateFrom,
                dateTo: dateTo,
              },
            );
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        switch (item.column) {
          case 'code':
            query.addOrderBy('v.code', item.order);
            break;
          case 'name':
            query.addOrderBy('v.name', item.order);
            break;
          case 'percentage':
            query.addOrderBy('v.percentage', item.order);
            break;
          default:
            break;
        }
      });
    } else {
      query.orderBy('v.id', 'DESC');
    }
    query.addGroupBy('v.id');
    return {
      result: parseInt(isGetAll)
        ? await query.getRawMany()
        : await query.offset(skip).limit(take).getRawMany(),
      count: await query.getCount(),
    };
  }

  reject(payload: SetStatusDto): Promise<any> {
    return Promise.resolve(undefined);
  }

  updateEntity(id: number, request: CreateVoucherRequestDto): VoucherEntity {
    const entity = new VoucherEntity();
    entity.id = id;
    entity.code = request.code;
    entity.name = request.name;
    entity.percentage = request.percentage;
    entity.description = request?.description;
    entity.dateFrom = request.dateFrom;
    entity.dateTo = request.dateTo;
    entity.createdByUserId = entity.createdByUserId;
    entity.lastestEditedUserId = request['userId'];
    return entity;
  }
}
