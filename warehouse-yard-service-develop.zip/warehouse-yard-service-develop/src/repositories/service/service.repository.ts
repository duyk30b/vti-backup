import { escapeCharForSearch } from '@utils/common';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { isEmpty } from 'lodash';

import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { ServiceEntity } from '@entities/service/service.entity';
import { ServiceRepositoryInterface } from '@components/service/interface/service.repository.interface';
import { CreateServiceRequestDto } from '@components/service/dto/request/create-service.request.dto';
import { ServiceStatusEnum } from '@components/service/service.constant';
import { UpdateServiceRequestDto } from '@components/service/dto/request/update-service.request.dto';
import { GetListServiceRequestDto } from '@components/service/dto/request/get-list-service.request.dto';
import { ServiceAttributeEntity } from '@entities/service/service-attribute.entity';
import { UsedVoucherEntity } from '@entities/service/used-voucher.entity';
import { CurrencyUnitEntity } from '@entities/currency-unit/currency-unit.entity';
import { ServiceTypeEntity } from '@entities/service-type/service-type.entity';
import { RentUnitEntity } from '@entities/rent-unit/rent-unit.entity';

@Injectable()
export class ServiceRepository
  extends BaseAbstractRepository<ServiceEntity>
  implements ServiceRepositoryInterface
{
  constructor(
    @InjectRepository(ServiceEntity)
    private readonly serviceRepository: Repository<ServiceEntity>,
  ) {
    super(serviceRepository);
  }
  createEntity(request: CreateServiceRequestDto): ServiceEntity {
    const entity = new ServiceEntity();
    entity.name = request.name;
    entity.code = request.code;
    entity.description = request.description;
    entity.pricePerDay = request.pricePerDay;
    entity.pricePerMonth = request.pricePerMonth;
    entity.pricePerQuarter = request.pricePerQuarter;
    entity.pricePerYear = request.pricePerYear;
    entity.currencyUnitId = request.currencyUnitId;
    entity.rentUnitId = request.rentUnitId;
    entity.serviceTypeId = request.serviceTypeId;
    entity.status = ServiceStatusEnum.CREATED;
    entity.createdByUserId = request['userId'];
    entity.lastestEditedUserId = request['userId'];
    return entity;
  }
  updateEntity(
    entity: ServiceEntity,
    request: UpdateServiceRequestDto,
  ): ServiceEntity {
    entity.name = request.name || entity.name;
    entity.code = request.code || entity.code;
    entity.description = request.description;
    entity.pricePerDay = request.pricePerDay || entity.pricePerDay;
    entity.pricePerMonth = request.pricePerMonth || entity.pricePerDay;
    entity.pricePerQuarter = request.pricePerQuarter || entity.pricePerQuarter;
    entity.pricePerYear = request.pricePerYear || entity.pricePerYear;
    entity.currencyUnitId = request.currencyUnitId || entity.currencyUnitId;
    entity.rentUnitId = request.rentUnitId || entity.rentUnitId;
    entity.serviceTypeId = request.serviceTypeId || entity.serviceTypeId;
    entity.createdByUserId = entity.createdByUserId;
    entity.lastestEditedUserId = request['userId'];
    return entity;
  }

  async getList(request: GetListServiceRequestDto): Promise<any> {
    const { filter, skip, sort, take, keyword, isGetAll } = request;

    const query = await this.serviceRepository
      .createQueryBuilder('sv')
      .select([
        'sv.id AS "id"',
        'sv.name AS "name"',
        'sv.code AS "code"',
        'sv.description AS "description"',
        'st.name AS "serviceTypeName"',
        'sv.status AS "status"',
        'sv.updated_at AS "updatedAt"',
        'sv.created_at AS "createdAt"',
        'sv.currency_unit_id AS "currencyUnitId"',
      ])
      .leftJoin('service_types', 'st', 'st.id = sv.service_type_id');

    if (keyword) {
      query
        .orWhere(
          `LOWER(unaccent("sv"."name")) LIKE LOWER(unaccent(:pkeyWord)) escape '\\'`,
          {
            pkeyWord: `%${escapeCharForSearch(keyword)}%`,
          },
        )
        .orWhere(
          `LOWER(unaccent("sv"."code")) LIKE LOWER(unaccent(:pkeyWord)) escape '\\'`,
          {
            pkeyWord: `%${escapeCharForSearch(keyword)}%`,
          },
        );
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        switch (item.column) {
          case 'name':
            query.andWhere(
              `lower(unaccent("sv"."name")) like lower(unaccent(:name)) escape '\\'`,
              {
                name: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'code':
            query.andWhere(
              `lower(unaccent("sv"."code")) like lower(unaccent(:code)) escape '\\'`,
              {
                code: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'serviceTypeName':
            query.andWhere(
              `lower(unaccent("st"."name")) like lower(unaccent(:serviceTypeName)) escape '\\'`,
              {
                serviceTypeName: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        switch (item.column) {
          case 'code':
            query.addOrderBy('sv.code', item.order);
            break;
          case 'name':
            query.addOrderBy('sv.name', item.order);
            break;
          case 'serviceTypeName':
            query.addOrderBy('st.name', item.order);
            break;
          default:
            break;
        }
      });
    } else {
      query.orderBy('sv.id', 'DESC');
    }

    const data = parseInt(isGetAll)
      ? await query.getRawMany()
      : await query.offset(skip).limit(take).getRawMany();
    const count = await query.getCount();

    return {
      result: data,
      total: count,
    };
  }

  public async getDetail(id: number) {
    const result = await this.serviceRepository
      .createQueryBuilder('sv')
      .select([
        'sv.id AS id',
        'sv.code AS code',
        'sv.name AS name',
        'sv.description AS description',
        'sv.price_per_day AS "pricePerDay"',
        'sv.price_per_month AS "pricePerMonth"',
        'sv.price_per_quarter AS "pricePerQuarter"',
        'sv.price_per_year AS "pricePerYear"',
        'sv.currency_unit_id AS "currencyUnitId"',
        'sv.rent_unit_id AS "rentUnitId"',
        'sv.service_type_id AS "serviceTypeId"',
        'uv.voucher_id AS "voucherId"',
        'sv.status AS status',
        'sv.created_at AS "createdAt"',
        'sv.updated_at AS "updatedAt"',
        'sv.created_by_user_id AS "createdByUserId"',
        'sv.lastest_edited_user_id AS "latestEditedUserId"',
        `CASE WHEN count(sva) = 0 THEN '[]' ELSE JSON_AGG (JSONB_BUILD_OBJECT('name', "sva"."name", 'value', "sva"."value")) END AS "customFields"`,
      ])
      .leftJoin(ServiceAttributeEntity, 'sva', 'sv.id = sva.service_id')
      .leftJoin(UsedVoucherEntity, 'uv', 'sv.id = uv.service_id')
      .where('sv.id = :id', { id: id })
      .groupBy('sv.id')
      .addGroupBy('uv.id')
      .getRawOne();
    return result;
  }

  async checkServiceCodeExist(code: string, serviceId?: number): Promise<any> {
    const query = await this.serviceRepository
      .createQueryBuilder('sv')
      .select(['sv.id AS "id"'])
      .andWhere(`lower(unaccent("sv"."code")) = lower(unaccent(:code))`, {
        code: `${escapeCharForSearch(code)}`,
      });

    if (serviceId) {
      query.andWhere('sv.id != :id', { id: serviceId });
    }

    return query.getRawMany();
  }

  async getListService(serviceIds?: number[]): Promise<any> {
    const query = this.serviceRepository
      .createQueryBuilder('s')
      .select([
        's.id AS "id"',
        's.code AS "code"',
        's.name AS "name"',
        's.price_per_day AS "pricePerDay"',
        's.price_per_month AS "pricePerMonth"',
        's.price_per_quarter AS "pricePerQuarter"',
        's.price_per_year AS "pricePerYear"',
        `CASE WHEN COUNT(cu) = 0 THEN '{}'
          ELSE JSONB_BUILD_OBJECT('id', cu.id, 'name', cu.name, 'code', cu.code) 
          END AS "currencyUnit"`,
        `CASE WHEN COUNT(ru) = 0 THEN '{}'
          ELSE JSONB_BUILD_OBJECT('id', ru.id, 'name', ru.name, 'code', ru.code) 
          END AS "rentUnit"`,
        `CASE WHEN COUNT(st) = 0 THEN '{}'
          ELSE JSONB_BUILD_OBJECT('id', st.id, 'name', st.name, 'code', st.code) 
          END AS "serviceType"`,
      ])
      .distinct(true);
    query.leftJoin(CurrencyUnitEntity, 'cu', 'cu.id = s.currency_unit_id');
    query.leftJoin(ServiceTypeEntity, 'st', 'st.id = s.service_type_id');
    query.leftJoin(RentUnitEntity, 'ru', 'ru.id = s.rent_unit_id');
    query.addGroupBy('s.id');
    query.addGroupBy('cu.id');
    query.addGroupBy('ru.id');
    query.addGroupBy('st.id');
    if (!isEmpty(serviceIds)) {
      query.andWhere('s.id IN (:...serviceIds)', { serviceIds });
    }
    return await query.getRawMany();
  }
}
