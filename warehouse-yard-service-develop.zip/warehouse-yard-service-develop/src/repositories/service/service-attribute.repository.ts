import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { ServiceAttributeEntity } from '@entities/service/service-attribute.entity';
import { ServiceAttributeRepositoryInterface } from '@components/service/interface/service-attribute.repository.interface';
import { CreateServiceAttributeRequestDto } from '@components/service/dto/request/create-service-attribute.request.dto';
import { UpdateServiceAttributeRequestDto } from '@components/service/dto/request/update-service-attribute.request.dto';

@Injectable()
export class ServiceAttributeRepository
  extends BaseAbstractRepository<ServiceAttributeEntity>
  implements ServiceAttributeRepositoryInterface
{
  constructor(
    @InjectRepository(ServiceAttributeEntity)
    private readonly serviceAttributeRepository: Repository<ServiceAttributeEntity>,
  ) {
    super(serviceAttributeRepository);
  }
  createEntity(
    request: CreateServiceAttributeRequestDto,
  ): ServiceAttributeEntity {
    const entity = new ServiceAttributeEntity();
    entity.name = request.name;
    entity.value = request.value;
    entity.serviceId = request.serviceId;
    return entity;
  }
  updateEntity(
    request: UpdateServiceAttributeRequestDto,
  ): ServiceAttributeEntity {
    const entity = new ServiceAttributeEntity();
    entity.id = request?.id;
    entity.value = request.value || entity.value;
    entity.name = request.name || entity.name;
    entity.serviceId = request.serviceId || entity.serviceId;
    return entity;
  }
}
