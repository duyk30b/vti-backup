import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { UsedVoucherEntity } from '@entities/service/used-voucher.entity';
import { UsedVoucherRepositoryInterface } from '@components/service/interface/used-voucher.repository.interface';
import { CreateUsedVoucherRequestDto } from '@components/service/dto/request/create-used-voucher.request.dto';

@Injectable()
export class UsedVoucherRepository
  extends BaseAbstractRepository<UsedVoucherEntity>
  implements UsedVoucherRepositoryInterface
{
  constructor(
    @InjectRepository(UsedVoucherEntity)
    private readonly usedVoucherRepository: Repository<UsedVoucherEntity>,
  ) {
    super(usedVoucherRepository);
  }
  createEntity(request: any): UsedVoucherEntity {
    const entity = new UsedVoucherEntity();
    entity.serviceId = request.serviceId;
    entity.voucherId = request.voucherId;
    entity.createdBy = request.createdBy;
    return entity;
  }
}
