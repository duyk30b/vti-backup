import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { CustomerClassAtrributeEntity } from '@entities/customer-class/customer-class-attribute.entity';
import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { CustomerClassAttributesRepositoryInterface } from '@components/customer-class/interface/customer-class-attribute.repository.interface';
import { CreateCustomerClassAttributeRequestDto } from '@components/customer-class/dto/request/create-customer-class-attribute.request.dto';
import { UpdateCustomerClassAttributeRequestDto } from '@components/customer-class/dto/request/update-customer-class-attribute.request.dto';
@Injectable()
export class CustomerClassAttributesRepository
  extends BaseAbstractRepository<CustomerClassAtrributeEntity>
  implements CustomerClassAttributesRepositoryInterface
{
  constructor(
    @InjectRepository(CustomerClassAtrributeEntity)
    private readonly customerClassAttributeRepository: Repository<CustomerClassAtrributeEntity>,
  ) {
    super(customerClassAttributeRepository);
  }

  createEntity(request: CreateCustomerClassAttributeRequestDto) {
    const entity = new CustomerClassAtrributeEntity();
    entity.name = request.name;
    entity.value = request.value;
    entity.customerClassId = request.customerClassId;

    return entity;
  }

  updateEntity(request: UpdateCustomerClassAttributeRequestDto) {
    const entity = new CustomerClassAtrributeEntity();
    entity.id = request?.id;
    entity.name = request.name;
    entity.value = request.value;
    entity.customerClassId = request.customerClassId;

    return entity;
  }
}
