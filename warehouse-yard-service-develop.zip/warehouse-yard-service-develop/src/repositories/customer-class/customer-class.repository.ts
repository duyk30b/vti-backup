import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { CustomerClassEntity } from '@entities/customer-class/customer-class.entity';
import { CustomerClassAtrributeEntity } from '@entities/customer-class/customer-class-attribute.entity';
import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { CustomerClassRepoInterface } from '@components/customer-class/interface/customer-class.repository.interface';
import { CreateCustomerClassRequestDto } from '@components/customer-class/dto/request/create-customer-class.request.dto';
import { GetCustomerClassListRequestDto } from '@components/customer-class/dto/request/search-customer-class.request.dto';
import { escapeCharForSearch } from '@utils/common';
import { isEmpty } from 'lodash';

@Injectable()
export class CustomerClassRepo
  extends BaseAbstractRepository<CustomerClassEntity>
  implements CustomerClassRepoInterface
{
  constructor(
    @InjectRepository(CustomerClassEntity)
    private readonly customerClassRepository: Repository<CustomerClassEntity>,
  ) {
    super(customerClassRepository);
  }

  createEntity(request: CreateCustomerClassRequestDto) {
    const entity = new CustomerClassEntity();
    entity.code = request.code;
    entity.name = request.name;
    entity.description = request?.description;
    entity.minJoinedDays = request.minJoinedDays;
    entity.maxJoinedDays = request.maxJoinedDays;
    entity.amountFrom = request.amountFrom;
    entity.amountTo = request.amountTo;
    entity.currencyUnitId = request.currencyUnitId;
    entity.createdByUserId = request['userId'];
    entity.lastestEditedUserId = request['userId'];
    entity.discount = request.discount;
    return entity;
  }

  updateEntity(id: number, request: CreateCustomerClassRequestDto) {
    const entity = new CustomerClassEntity();
    entity.id = id;
    entity.code = request.code;
    entity.name = request.name;
    entity.description = request?.description;
    entity.minJoinedDays = request.minJoinedDays;
    entity.maxJoinedDays = request.maxJoinedDays;
    entity.amountFrom = request.amountFrom;
    entity.amountTo = request.amountTo;
    entity.currencyUnitId = request.currencyUnitId;
    entity.createdByUserId = entity.createdByUserId;
    entity.lastestEditedUserId = request['userId'];
    entity.discount = request.discount;
    return entity;
  }

  public async getList(request: GetCustomerClassListRequestDto) {
    const { keyword, skip, take, isGetAll, sort, filter } = request;
    let query = this.customerClassRepository
      .createQueryBuilder('cc')
      .select([
        'cc.id AS id',
        'cc.name AS name',
        'cc.code AS code',
        'cc.status AS status',
        'cc.discount AS discount',
      ]);

    if (keyword) {
      query = query
        .orWhere(`LOWER("cc".name) LIKE LOWER(:pkeyWord) escape '\\'`, {
          pkeyWord: `%${escapeCharForSearch(keyword)}%`,
        })
        .orWhere(`LOWER("cc".code) LIKE LOWER(:pkeyWord) escape '\\'`, {
          pkeyWord: `%${escapeCharForSearch(keyword)}%`,
        });
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        switch (item.column) {
          case 'code':
            query.andWhere(
              `lower(unaccent("cc"."code")) like lower(unaccent(:code)) escape '\\'`,
              {
                code: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'name':
            query.andWhere(
              `lower(unaccent("cc"."name")) like lower(unaccent(:name)) escape '\\'`,
              {
                name: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'status':
            query.andWhere(`"cc"."status" IN (:...status)`, {
              status: item.text.split(','),
            });
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        switch (item.column) {
          case 'code':
            query.addOrderBy('cc.code', item.order);
            break;
          case 'name':
            query.addOrderBy('cc.name', item.order);
            break;
          default:
            break;
        }
      });
    } else {
      query.orderBy('cc.id', 'DESC');
    }

    query.addGroupBy('cc.id');

    const data = parseInt(isGetAll)
      ? await query.getRawMany()
      : await query.offset(skip).limit(take).getRawMany();

    const total = await query.getCount();

    return {
      result: data,
      count: total,
    };
  }

  public async getDetail(id: number) {
    const result = await this.customerClassRepository
      .createQueryBuilder('cc')
      .select([
        'cc.id AS id',
        'cc.code AS code',
        'cc.name AS name',
        'cc.description AS description',
        'cc.status AS status',
        'cc.min_joined_days AS "minJoinedDays"',
        'cc.max_joined_days AS "maxJoinedDays"',
        'cc.amount_from AS "amountFrom"',
        'cc.amount_to AS "amountTo"',
        'cc.created_at AS "createdAt"',
        'cc.discount AS "discount"',
        'cc.updated_at AS "updatedAt"',
        'cc.currency_unit_id AS "currencyUnitId"',
        'cc.created_by_user_id AS "createdByUserId"',
        'cc.lastest_edited_user_id AS "latestEditedUserId"',
        `CASE WHEN count(cca) = 0 THEN '[]' ELSE JSON_AGG (JSONB_BUILD_OBJECT('name', "cca"."name", 'value', "cca"."value")) END AS "customFields"`,
      ])
      .leftJoin(
        CustomerClassAtrributeEntity,
        'cca',
        'cc.id = cca.customer_class_id',
      )
      .where('cc.id = :id', { id: id })
      .groupBy('cc.id')
      .getRawOne();
    return result;
  }

  public async delete(id: number) {
    const customerClass = await this.customerClassRepository.find({
      where: { id: id },
    });

    return await this.customerClassRepository.remove(customerClass);
  }

  async checkAndGetCustomerClass(totalPrice: number) {
    return await this.customerClassRepository
      .createQueryBuilder('cc')
      .select([
        `cc.id as "id"`,
        `cc.name as "name"`,
        `cc.discount as "discount"`,
      ])
      .where('cc.amount_from < :totalPrice', {
        totalPrice,
      })
      .orWhere('cc.amount_to <= :totalPrice', { totalPrice })
      .orderBy('cc.amount_from', 'DESC')
      .getRawOne();
  }
}
