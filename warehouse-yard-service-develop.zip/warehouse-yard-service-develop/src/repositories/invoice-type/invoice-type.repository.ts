import { escapeCharForSearch } from '@utils/common';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { isEmpty } from 'lodash';

import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { InvoiceTypeEntity } from '@entities/invoice-type/invoice-type.entity';
import { InvoiceTypeRepositoryInterface } from '@components/invoice-type/interface/invoice-type.repository.interface';
import { CreateInvoiceTypeRequestDto } from '@components/invoice-type/dto/request/create-invoice-type.request.dto';
import { InvoiceTypeStatusEnum } from '@components/invoice-type/invoice-type.constant';
import { UpdateInvoiceTypeRequestDto } from '@components/invoice-type/dto/request/update-invoice-type.request.dto';
import { GetListInvoiceTypeRequestDto } from '@components/invoice-type/dto/request/get-list-invoice-type.request.dto';
import { InvoiceTypeAttributeEntity } from '@entities/invoice-type/invoice-type-attribute.entity';

@Injectable()
export class InvoiceTypeRepository
  extends BaseAbstractRepository<InvoiceTypeEntity>
  implements InvoiceTypeRepositoryInterface
{
  constructor(
    @InjectRepository(InvoiceTypeEntity)
    private readonly invoiceTypeRepository: Repository<InvoiceTypeEntity>,
  ) {
    super(invoiceTypeRepository);
  }
  createEntity(request: CreateInvoiceTypeRequestDto): InvoiceTypeEntity {
    const entity = new InvoiceTypeEntity();
    entity.name = request.name;
    entity.code = request.code;
    entity.description = request.description;
    entity.status = InvoiceTypeStatusEnum.CREATED;
    entity.createdByUserId = request['userId'];
    entity.lastestEditedUserId = request['userId'];
    return entity;
  }
  updateEntity(
    entity: InvoiceTypeEntity,
    request: UpdateInvoiceTypeRequestDto,
  ): InvoiceTypeEntity {
    entity.code = request.code || entity.code;
    entity.name = request.name || entity.name;
    entity.description = request.description;
    entity.createdByUserId = entity.createdByUserId;
    entity.lastestEditedUserId = request['userId'];
    return entity;
  }

  async getList(request: GetListInvoiceTypeRequestDto): Promise<any> {
    const { filter, skip, sort, take, keyword, isGetAll } = request;

    const query = await this.invoiceTypeRepository
      .createQueryBuilder('it')
      .select([
        'it.id AS "id"',
        'it.name AS "name"',
        'it.code AS "code"',
        'it.description AS "description"',
        'it.status AS "status"',
        'it.updated_at AS "updatedAt"',
        'it.created_at AS "createdAt"',
      ]);

    if (keyword) {
      query
        .orWhere(
          `LOWER(unaccent("it"."name")) LIKE LOWER(unaccent(:pkeyWord)) escape '\\'`,
          {
            pkeyWord: `%${escapeCharForSearch(keyword)}%`,
          },
        )
        .orWhere(
          `LOWER(unaccent("it"."code")) LIKE LOWER(unaccent(:pkeyWord)) escape '\\'`,
          {
            pkeyWord: `%${escapeCharForSearch(keyword)}%`,
          },
        );
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        switch (item.column) {
          case 'name':
            query.andWhere(
              `lower(unaccent("it"."name")) like lower(unaccent(:name)) escape '\\'`,
              {
                name: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'code':
            query.andWhere(
              `lower(unaccent("it"."code")) like lower(unaccent(:code)) escape '\\'`,
              {
                code: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'status':
            query.andWhere(`"it"."status" IN (:...status)`, {
              status: item.text.split(','),
            });
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        switch (item.column) {
          case 'code':
            query.addOrderBy('it.code', item.order);
            break;
          case 'name':
            query.addOrderBy('it.name', item.order);
            break;
          default:
            break;
        }
      });
    } else {
      query.orderBy('it.id', 'DESC');
    }

    const data = parseInt(isGetAll)
      ? await query.getRawMany()
      : await query.offset(skip).limit(take).getRawMany();
    const count = await query.getCount();

    return {
      result: data,
      total: count,
    };
  }

  public async getDetail(id: number) {
    const result = await this.invoiceTypeRepository
      .createQueryBuilder('it')
      .select([
        'it.id AS id',
        'it.code AS code',
        'it.name AS name',
        'it.description AS description',
        'it.status AS status',
        'it.created_at AS "createdAt"',
        'it.updated_at AS "updatedAt"',
        'it.created_by_user_id AS "createdByUserId"',
        'it.lastest_edited_user_id AS "latestEditedUserId"',
        `CASE WHEN count(ita) = 0 THEN '[]' ELSE JSON_AGG (JSONB_BUILD_OBJECT('name', "ita"."name", 'value', "ita"."value")) END AS "customFields"`,
      ])
      .leftJoin(
        InvoiceTypeAttributeEntity,
        'ita',
        'it.id = ita.invoice_type_id',
      )
      .where('it.id = :id', { id: id })
      .groupBy('it.id')
      .getRawOne();
    return result;
  }
}
