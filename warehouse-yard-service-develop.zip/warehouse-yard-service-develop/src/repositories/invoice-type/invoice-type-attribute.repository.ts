import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { InvoiceTypeAttributeEntity } from '@entities/invoice-type/invoice-type-attribute.entity';
import { InvoiceTypeAttributeRepositoryInterface } from '@components/invoice-type/interface/invoice-type-attribute.repository.interface';
import { CreateInvoiceTypeAttributeRequestDto } from '@components/invoice-type/dto/request/create-invoice-type-attribute.request.dto';
import { UpdateInvoiceTypeAttributeRequestDto } from '@components/invoice-type/dto/request/update-invoice-type-attribute.request.dto';

@Injectable()
export class InvoiceTypeAttributeRepository
  extends BaseAbstractRepository<InvoiceTypeAttributeEntity>
  implements InvoiceTypeAttributeRepositoryInterface
{
  constructor(
    @InjectRepository(InvoiceTypeAttributeEntity)
    private readonly invoiceTypeAttributeRepository: Repository<InvoiceTypeAttributeEntity>,
  ) {
    super(invoiceTypeAttributeRepository);
  }
  createEntity(
    request: CreateInvoiceTypeAttributeRequestDto,
  ): InvoiceTypeAttributeEntity {
    const entity = new InvoiceTypeAttributeEntity();
    entity.name = request.name;
    entity.value = request.value;
    entity.invoiceTypeId = request.invoiceTypeId;
    return entity;
  }
  updateEntity(
    request: UpdateInvoiceTypeAttributeRequestDto,
  ): InvoiceTypeAttributeEntity {
    const entity = new InvoiceTypeAttributeEntity();
    entity.id = request?.id;
    entity.value = request.value || entity.value;
    entity.name = request.name || entity.name;
    entity.invoiceTypeId = request.invoiceTypeId || entity.invoiceTypeId;
    return entity;
  }
}
