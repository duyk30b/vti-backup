import { CurrencyUnitAttributeEntity } from '@entities/currency-unit/currency-unit-attribute.entity';
import { CurrencyUnitStatusEnum } from './../../components/currency-unit/currency-unit.constant';
import { escapeCharForSearch } from './../../utils/common';
import { GetListCurrencyUnitRequestDto } from '@components/currency-unit/dto/request/get-list-currency-unit.request.dto';
import { Injectable } from '@nestjs/common';
import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { isEmpty } from 'lodash';
import { CurrencyUnitEntity } from '@entities/currency-unit/currency-unit.entity';
import { CurrencyUnitRepositoryInterface } from '@components/currency-unit/interface/currency-unit.repository.interface';
import { UpdateCurrencyUnitRequestDto } from '@components/currency-unit/dto/request/update-currency-unit.request.dto';
import { CreateCurrencyUnitRequestDto } from '@components/currency-unit/dto/request/create-currency-unit.request.dto';

@Injectable()
export class CurrencyUnitRepository
  extends BaseAbstractRepository<CurrencyUnitEntity>
  implements CurrencyUnitRepositoryInterface
{
  constructor(
    @InjectRepository(CurrencyUnitEntity)
    private readonly currencyUnitRepository: Repository<CurrencyUnitEntity>,
  ) {
    super(currencyUnitRepository);
  }
  createEntity(request: CreateCurrencyUnitRequestDto): CurrencyUnitEntity {
    const entity = new CurrencyUnitEntity();
    entity.name = request.name;
    entity.code = request.code;
    entity.description = request.description;
    entity.status = CurrencyUnitStatusEnum.CREATED;
    entity.createdByUserId = request['userId'];
    entity.lastestEditedUserId = request['userId'];
    return entity;
  }
  updateEntity(
    entity: CurrencyUnitEntity,
    request: UpdateCurrencyUnitRequestDto,
  ): CurrencyUnitEntity {
    entity.code = request.code || entity.code;
    entity.name = request.name || entity.name;
    entity.description = request.description || entity.description;
    entity.createdByUserId = entity.createdByUserId;
    entity.lastestEditedUserId = request['userId'];
    return entity;
  }

  async getList(request: GetListCurrencyUnitRequestDto): Promise<any> {
    const { filter, skip, sort, take, keyword, isGetAll } = request;

    const query = await this.currencyUnitRepository
      .createQueryBuilder('cru')
      .select([
        'cru.id AS "id"',
        'cru.name AS "name"',
        'cru.code AS "code"',
        'cru.description AS "description"',
        'cru.status AS "status"',
        'cru.updated_at AS "updatedAt"',
        'cru.created_at AS "createdAt"',
      ]);

    if (keyword) {
      query
        .orWhere(
          `LOWER(unaccent("cru"."name")) LIKE LOWER(unaccent(:pkeyWord)) escape '\\'`,
          {
            pkeyWord: `%${escapeCharForSearch(keyword)}%`,
          },
        )
        .orWhere(
          `LOWER(unaccent("cru"."code")) LIKE LOWER(unaccent(:pkeyWord)) escape '\\'`,
          {
            pkeyWord: `%${escapeCharForSearch(keyword)}%`,
          },
        );
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        switch (item.column) {
          case 'name':
            query.andWhere(
              `lower(unaccent("cru"."name")) like lower(unaccent(:name)) escape '\\'`,
              {
                name: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'code':
            query.andWhere(
              `lower(unaccent("cru"."code")) like lower(unaccent(:code)) escape '\\'`,
              {
                code: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'status':
            query.andWhere(`"cru"."status" IN (:...status)`, {
              status: item.text.split(','),
            });
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        switch (item.column) {
          case 'code':
            query.addOrderBy('cru.code', item.order);
            break;
          case 'name':
            query.addOrderBy('cru.name', item.order);
            break;
          default:
            break;
        }
      });
    } else {
      query.orderBy('cru.id', 'DESC');
    }

    const data = parseInt(isGetAll)
      ? await query.getRawMany()
      : await query.offset(skip).limit(take).getRawMany();
    const count = await query.getCount();

    return {
      result: data,
      total: count,
    };
  }

  public async getDetail(id: number) {
    const result = await this.currencyUnitRepository
      .createQueryBuilder('cru')
      .select([
        'cru.id AS id',
        'cru.code AS code',
        'cru.name AS name',
        'cru.description AS description',
        'cru.status AS status',
        'cru.created_at AS "createdAt"',
        'cru.updated_at AS "updatedAt"',
        'cru.created_by_user_id AS "createdByUserId"',
        'cru.lastest_edited_user_id AS "latestEditedUserId"',
        `CASE WHEN count(crua) = 0 THEN '[]' ELSE JSON_AGG (JSONB_BUILD_OBJECT('name', "crua"."name", 'value', "crua"."value")) END AS "customFields"`,
      ])
      .leftJoin(
        CurrencyUnitAttributeEntity,
        'crua',
        'cru.id = crua.currency_unit_id',
      )
      .where('cru.id = :id', { id: id })
      .groupBy('cru.id')
      .getRawOne();
    return result;
  }
}
