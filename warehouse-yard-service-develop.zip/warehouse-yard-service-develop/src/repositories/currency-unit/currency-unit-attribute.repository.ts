import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CurrencyUnitAttributeRepositoryInterface } from '@components/currency-unit/interface/currency-unit-attribute.repository.interface';
import { CurrencyUnitAttributeEntity } from '@entities/currency-unit/currency-unit-attribute.entity';
import { CreateCurrencyUnitAttributeRequestDto } from '@components/currency-unit/dto/request/create-currency-unit-attribute.request.dto';
import { UpdateCurrencyUnitAttributeRequestDto } from '@components/currency-unit/dto/request/update-currency-unit-attribute.request.dto';
import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';

@Injectable()
export class CurrencyUnitAttributeRepository
  extends BaseAbstractRepository<CurrencyUnitAttributeEntity>
  implements CurrencyUnitAttributeRepositoryInterface
{
  constructor(
    @InjectRepository(CurrencyUnitAttributeEntity)
    private readonly currencyUnitAttributeRepository: Repository<CurrencyUnitAttributeEntity>,
  ) {
    super(currencyUnitAttributeRepository);
  }
  createEntity(
    request: CreateCurrencyUnitAttributeRequestDto,
  ): CurrencyUnitAttributeEntity {
    const entity = new CurrencyUnitAttributeEntity();
    entity.name = request.name;
    entity.value = request.value;
    entity.currencyUnitId = request.currencyUnitId;
    return entity;
  }
  updateEntity(
    request: UpdateCurrencyUnitAttributeRequestDto,
  ): CurrencyUnitAttributeEntity {
    const entity = new CurrencyUnitAttributeEntity();
    entity.id = request?.id;
    entity.value = request.value || entity.value;
    entity.name = request.name || entity.name;
    entity.currencyUnitId = request.currencyUnitId || entity.currencyUnitId;
    return entity;
  }
}
