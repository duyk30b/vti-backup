import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { PaymentTypeAtrributeEntity } from '@entities/payment-type/payment-type-attribute.entity';
import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { PaymentTypeAttributesRepositoryInterface } from '@components/payment-type/interface/payment-type-attribute.repository.interface';
import { CreatePaymentTypeAttributeRequestDto } from '@components/payment-type/dto/request/create-payment-type-attribute.request.dto';
import { UpdatePaymentTypeAttributeRequestDto } from '@components/payment-type/dto/request/update-payment-type-attribute.request.dto';
@Injectable()
export class PaymentTypeAttributesRepository
  extends BaseAbstractRepository<PaymentTypeAtrributeEntity>
  implements PaymentTypeAttributesRepositoryInterface
{
  constructor(
    @InjectRepository(PaymentTypeAtrributeEntity)
    private readonly paymentTypeAttributeRepository: Repository<PaymentTypeAtrributeEntity>,
  ) {
    super(paymentTypeAttributeRepository);
  }

  createEntity(request: CreatePaymentTypeAttributeRequestDto) {
    const entity = new PaymentTypeAtrributeEntity();
    entity.name = request.name;
    entity.value = request.value;
    entity.paymentTypeId = request.paymentTypeId;

    return entity;
  }

  updateEntity(request: UpdatePaymentTypeAttributeRequestDto) {
    const entity = new PaymentTypeAtrributeEntity();
    entity.id = request?.id;
    entity.name = request.name;
    entity.value = request.value;
    entity.paymentTypeId = request.paymentTypeId;

    return entity;
  }
}
