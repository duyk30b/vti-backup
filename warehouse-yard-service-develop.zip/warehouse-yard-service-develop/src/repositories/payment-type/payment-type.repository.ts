import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { PaymentTypeEntity } from '@entities/payment-type/payment-type.entity';
import { PaymentTypeAtrributeEntity } from '@entities/payment-type/payment-type-attribute.entity';
import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { PaymentTypeRepoInterface } from '@components/payment-type/interface/payment-type.repository.interface';
import { CreatePaymentTypeRequestDto } from '@components/payment-type/dto/request/create-payment-type.request.dto';
import { GetPaymentTypeListRequestDto } from '@components/payment-type/dto/request/search-payment-type.request.dto';
import { escapeCharForSearch } from '@utils/common';
import { isEmpty } from 'lodash';

@Injectable()
export class PaymentTypeRepo
  extends BaseAbstractRepository<PaymentTypeEntity>
  implements PaymentTypeRepoInterface
{
  constructor(
    @InjectRepository(PaymentTypeEntity)
    private readonly paymentTypeRepository: Repository<PaymentTypeEntity>,
  ) {
    super(paymentTypeRepository);
  }

  createEntity(request: CreatePaymentTypeRequestDto) {
    const entity = new PaymentTypeEntity();
    entity.code = request.code;
    entity.name = request.name;
    entity.description = request?.description;
    entity.createdByUserId = request['userId'];
    entity.lastestEditedUserId = request['userId'];
    entity.discount = request.discount;
    return entity;
  }

  updateEntity(id: number, request: CreatePaymentTypeRequestDto) {
    const entity = new PaymentTypeEntity();
    entity.id = id;
    entity.code = request.code;
    entity.name = request.name;
    entity.description = request?.description;
    entity.createdByUserId = entity.createdByUserId;
    entity.lastestEditedUserId = request['userId'];
    entity.discount = request.discount;
    return entity;
  }

  public async getList(request: GetPaymentTypeListRequestDto) {
    const { keyword, skip, take, isGetAll, sort, filter } = request;
    let query = this.paymentTypeRepository
      .createQueryBuilder('pt')
      .select([
        'pt.id AS id',
        'pt.name AS name',
        'pt.code AS code',
        'pt.status AS status',
        'pt.discount AS discount',
      ]);

    if (keyword) {
      query = query
        .orWhere(`LOWER("pt".name) LIKE LOWER(:pkeyWord) escape '\\'`, {
          pkeyWord: `%${escapeCharForSearch(keyword)}%`,
        })
        .orWhere(`LOWER("pt".code) LIKE LOWER(:pkeyWord) escape '\\'`, {
          pkeyWord: `%${escapeCharForSearch(keyword)}%`,
        });
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        switch (item.column) {
          case 'code':
            query.andWhere(
              `lower(unaccent("pt"."code")) like lower(unaccent(:code)) escape '\\'`,
              {
                code: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'name':
            query.andWhere(
              `lower(unaccent("pt"."name")) like lower(unaccent(:name)) escape '\\'`,
              {
                name: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'status':
            query.andWhere(`"pt"."status" IN (:...status)`, {
              status: item.text.split(','),
            });
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        switch (item.column) {
          case 'code':
            query.addOrderBy('pt.code', item.order);
            break;
          case 'name':
            query.addOrderBy('pt.name', item.order);
            break;
          default:
            break;
        }
      });
    } else {
      query.orderBy('pt.id', 'DESC');
    }

    query.addGroupBy('pt.id');

    const data = parseInt(isGetAll)
      ? await query.getRawMany()
      : await query.offset(skip).limit(take).getRawMany();

    const total = await query.getCount();

    return {
      result: data,
      count: total,
    };
  }

  public async getDetail(id: number) {
    const result = await this.paymentTypeRepository
      .createQueryBuilder('pt')
      .select([
        'pt.id AS id',
        'pt.code AS code',
        'pt.name AS name',
        'pt.description AS description',
        'pt.status AS status',
        'pt.created_at AS "createdAt"',
        'pt.updated_at AS "updatedAt"',
        'pt.discount AS "discount"',
        'pt.created_by_user_id AS "createdByUserId"',
        'pt.lastest_edited_user_id AS "latestEditedUserId"',
        `CASE WHEN count(pta) = 0 THEN '[]' ELSE JSON_AGG (JSONB_BUILD_OBJECT('name', "pta"."name", 'value', "pta"."value")) END AS "customFields"`,
      ])
      .leftJoin(
        PaymentTypeAtrributeEntity,
        'pta',
        'pt.id = pta.payment_type_id',
      )
      .where('pt.id = :id', { id: id })
      .groupBy('pt.id')
      .getRawOne();
    return result;
  }

  public async delete(id: number) {
    const paymentType = await this.paymentTypeRepository.find({
      where: { id: id },
    });

    return await this.paymentTypeRepository.remove(paymentType);
  }
}
