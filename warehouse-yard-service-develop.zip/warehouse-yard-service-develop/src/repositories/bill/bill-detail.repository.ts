import { BillDetailRepositoryInterface } from '@components/bill/interface/bill-detail.repository.interface';
import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { BillDetailEntity } from '@entities/bill/bill-detail.entity';
import { CurrencyUnitEntity } from '@entities/currency-unit/currency-unit.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { isEmpty } from 'lodash';
import { Repository } from 'typeorm';

@Injectable()
export class BillDetailRepository
  extends BaseAbstractRepository<BillDetailEntity>
  implements BillDetailRepositoryInterface
{
  constructor(
    @InjectRepository(BillDetailEntity)
    private readonly billDetailRepository: Repository<BillDetailEntity>,
  ) {
    super(billDetailRepository);
  }

  createEntity(request: any): BillDetailEntity {
    const billDetail = new BillDetailEntity();
    if (request.id) {
      billDetail.id = request.id;
    }
    billDetail.serviceId = request.serviceId;
    billDetail.billId = request.billId;
    billDetail.unitPrice = request.unitPrice;
    billDetail.fee = request.fee;
    billDetail.price = request.price;
    billDetail.rentDurationFrom = request.rentDurationFrom;
    billDetail.rentDurationTo = request.rentDurationTo;
    billDetail.quantity = request.quantity;
    return billDetail;
  }
}
