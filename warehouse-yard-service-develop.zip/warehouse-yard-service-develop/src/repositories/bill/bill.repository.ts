import { CreateBillRequestDto } from '@components/bill/dto/request/create-bill.request.dto';
import { GetListBillRequestDto } from '@components/bill/dto/request/get-list-bill.request.dto';
import { GetRentWarehouseReportRequestDto } from '@components/bill/dto/request/get-rent-warehouse-report.request.dto';
import { UpdateBillRequestDto } from '@components/bill/dto/request/update-bill.request.dto';
import { BillRepositoryInterface } from '@components/bill/interface/bill.repository.interface';
import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { BillDetailEntity } from '@entities/bill/bill-detail.entity';
import { BillEntity } from '@entities/bill/bill.entity';
import { CurrencyUnitEntity } from '@entities/currency-unit/currency-unit.entity';
import { InvoiceTypeEntity } from '@entities/invoice-type/invoice-type.entity';
import { PaymentTypeEntity } from '@entities/payment-type/payment-type.entity';
import { VoucherEntity } from '@entities/voucher/voucher.entity';
import { ServiceEntity } from '@entities/service/service.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { escapeCharForSearch } from '@utils/common';
import { SetStatusDto } from '@utils/set-status.dto';
import { isEmpty } from 'lodash';
import { Repository } from 'typeorm';

export class BillRepository
  extends BaseAbstractRepository<BillEntity>
  implements BillRepositoryInterface
{
  constructor(
    @InjectRepository(BillEntity)
    private readonly billRepository: Repository<BillEntity>,
  ) {
    super(billRepository);
  }

  async getList(
    request: GetListBillRequestDto,
    customerIds?: number[],
  ): Promise<any> {
    const { filter, skip, sort, take, keyword, isGetAll } = request;
    const query = await this.billRepository
      .createQueryBuilder('b')
      .select([
        'b.id AS "id"',
        'b.name AS "name"',
        'b.code AS "code"',
        'b.status AS "status"',
        'b.updated_at AS "updatedAt"',
        'b.created_at AS "createdAt"',
        'b.total_price AS "totalPrice"',
        'b.customer_id AS "customerId"',
        'b.created_by_user_id AS "createdByUserId"',
        'b.customer_level_id AS "customerLevelId"',
        `CASE WHEN COUNT(it) = 0 THEN '{}'
          ELSE JSONB_BUILD_OBJECT('id', it.id, 'name', it.name, 'code', it.code) 
          END AS "invoiceType"`,
        `CASE WHEN COUNT(cu) = 0 THEN '{}'
          ELSE JSONB_BUILD_OBJECT('id', cu.id, 'name', cu.name, 'code', cu.code) 
          END AS "currencyUnit"`,
        `CASE WHEN count(bd) = 0 THEN '[]' 
        ELSE 
          JSON_AGG (
            JSONB_BUILD_OBJECT(
            'serviceId',"bd"."service_id",
            'billId', "bd"."bill_id",
            'price', "bd"."price",
            'fee', "bd"."fee",
            'quantity', "bd"."quantity",
            'unitPrice', "bd"."unit_price",
            'rentDurationFrom', "bd"."rent_duration_from",
            'rentDurationTo', "bd"."rent_duration_to"
            )
          ) 
        END AS "billDetails"`,
      ])
      .leftJoin(BillDetailEntity, 'bd', 'b.id = bd.bill_id')
      .leftJoin(InvoiceTypeEntity, 'it', 'it.id = b.invoice_type_id')
      .leftJoin(CurrencyUnitEntity, 'cu', 'cu.id = b.currency_unit_id');

    if (keyword) {
      query
        .orWhere(
          `LOWER(unaccent("b"."name")) LIKE LOWER(unaccent(:pkeyWord)) escape '\\'`,
          {
            pkeyWord: `%${escapeCharForSearch(keyword)}%`,
          },
        )
        .orWhere(
          `LOWER(unaccent("b"."code")) LIKE LOWER(unaccent(:pkeyWord)) escape '\\'`,
          {
            pkeyWord: `%${escapeCharForSearch(keyword)}%`,
          },
        );
    }

    if (!isEmpty(customerIds)) {
      query.andWhere('b.customer_id IN (:...customerIds)', { customerIds });
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        switch (item.column) {
          case 'name':
            query.andWhere(
              `lower(unaccent("b"."name")) like lower(unaccent(:name)) escape '\\'`,
              {
                name: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'code':
            query.andWhere(
              `lower(unaccent("b"."code")) like lower(unaccent(:code)) escape '\\'`,
              {
                code: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'currencyUnit':
            query.andWhere(
              `lower(unaccent("cu"."name")) like lower(unaccent(:name)) escape '\\'`,
              {
                name: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'invoiceType':
            query.andWhere(
              `lower(unaccent("it"."name")) like lower(unaccent(:name)) escape '\\'`,
              {
                name: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'status':
            query.andWhere(`"b"."status" IN (:...status)`, {
              status: item.text.split(','),
            });
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        switch (item.column) {
          case 'code':
            query.addOrderBy('b.code', item.order);
            break;
          case 'name':
            query.addOrderBy('b.name', item.order);
            break;
          case 'invoiceType':
            query.addOrderBy('it.name', item.order);
            break;
          case 'currencyUnit':
            query.addOrderBy('cu.name', item.order);
            break;
          case 'status':
            query.addOrderBy('b.status', item.order);
            break;
          case 'customer':
            query.addOrderBy('b.customer_id', item.order);
            break;
          default:
            break;
        }
      });
    } else {
      query.orderBy('b.id', 'DESC');
    }
    query.addGroupBy('b.id');
    query.addGroupBy('it.id');
    query.addGroupBy('cu.id');
    const result = parseInt(isGetAll)
      ? await query.getRawMany()
      : await query.offset(skip).limit(take).getRawMany();
    const total = await query.getCount();

    return {
      result,
      total,
    };
  }

  createEntity(
    request: CreateBillRequestDto | UpdateBillRequestDto | any,
  ): BillEntity {
    const billEntity = new BillEntity();
    if (request.id) {
      billEntity.id = request.id;
    }
    billEntity.code = request.code;
    billEntity.name = request.name;
    billEntity.invoiceTypeId = request.invoiceTypeId;
    billEntity.currencyUnitId = request.currencyUnitId;
    billEntity.isQr = request.isQr;
    billEntity.vendorId = request.vendorId;
    billEntity.customerId = request.customerId;
    billEntity.paymentTypeId = request.paymentTypeId;
    billEntity.note = request.note;
    billEntity.file = request.file;
    billEntity.percentageTax = request.percentageTax;
    billEntity.voucherId = request.voucherId;
    billEntity.totalPrice = request.totalPrice;
    billEntity.taxNo = request.taxNo;
    billEntity.customerLevelId = request.customerLevelId;
    billEntity.createdByUserId = request['userId'];
    billEntity.latestEditedUserId = request['userId'];

    return billEntity;
  }

  async detail(id: number): Promise<any> {
    return await this.billRepository
      .createQueryBuilder('b')
      .select([
        'b.id AS id',
        'b.code AS "code"',
        'b.name AS "name"',
        'b.is_qr AS "isQr"',
        'b.vendor_id AS "vendorId"',
        'b.customer_id AS "customerId"',
        'b.note AS "note"',
        'b.file AS "file"',
        'b.status AS "status"',
        'b.created_at AS "createdAt"',
        'b.updated_at AS "updatedAt"',
        'b.voucher_id AS "voucherId"',
        'b.total_price AS "totalPrice"',
        'b.percentage_tax AS "percentageTax"',
        'b.customer_level_id AS "customerLevelId"',
        'b.tax_no AS "taxNo"',
        `CASE WHEN COUNT(cu) = 0 THEN '{}'
          ELSE JSONB_BUILD_OBJECT('id', cu.id, 'name', cu.name, 'code', cu.code) 
          END AS "currencyUnit"`,
        `CASE WHEN COUNT(it) = 0 THEN '{}'
          ELSE JSONB_BUILD_OBJECT('id', it.id, 'name', it.name, 'code', it.code) 
          END AS "invoiceType"`,
        `CASE WHEN COUNT(pt) = 0 THEN '{}'
          ELSE JSONB_BUILD_OBJECT('id', pt.id, 'name', pt.name, 'discount', pt.discount, 'code', pt.code) 
          END AS "paymentType"`,
        `CASE WHEN COUNT(v) = 0 THEN '{}'
          ELSE JSONB_BUILD_OBJECT('id', v.id, 'name', v.name, 'code', v.code) 
          END AS "voucher"`,
        `CASE WHEN count(bd) = 0 THEN '[]' 
        ELSE 
          JSON_AGG (
            JSONB_BUILD_OBJECT(
            'serviceId',"bd"."service_id",
            'billId', "bd"."bill_id",
            'price', "bd"."price",
            'fee', "bd"."fee",
            'quantity', "bd"."quantity",
            'unitPrice', "bd"."unit_price",
            'rentDurationFrom', "bd"."rent_duration_from",
            'rentDurationTo', "bd"."rent_duration_to"
            )
          ) 
        END AS "billDetails"`,
      ])
      .leftJoin(BillDetailEntity, 'bd', 'b.id = bd.bill_id')
      .leftJoin(CurrencyUnitEntity, 'cu', 'cu.id = b.currency_unit_id')
      .leftJoin(InvoiceTypeEntity, 'it', 'it.id = b.invoice_type_id')
      .leftJoin(PaymentTypeEntity, 'pt', 'pt.id = b.payment_type_id')
      .leftJoin(VoucherEntity, 'v', 'v.id = b.voucher_id')
      .where('b.id = :id', { id })
      .groupBy('b.id')
      .addGroupBy('cu.id')
      .addGroupBy('it.id')
      .addGroupBy('pt.id')
      .addGroupBy('v.id')
      .getRawOne();
  }

  async checkBillCodeExit(code: string, billId?: number): Promise<any> {
    const query = await this.billRepository
      .createQueryBuilder('b')
      .select(['b.id'])
      .andWhere(`lower(unaccent("b"."code")) = lower(unaccent(:code))`, {
        code: `${escapeCharForSearch(code)}`,
      });

    if (billId) {
      query.andWhere('b.id != :id', { id: billId });
    }

    return query.getRawMany();
  }

  async getRentWarehouseReport(
    request: GetRentWarehouseReportRequestDto,
    customerIds: number[],
  ): Promise<[any[], number]> {
    const { skip, take, sort, filter, isGetAll, keyword } = request;
    let query = await this.billRepository.createQueryBuilder('b').select([
      'COUNT(bd.id) OVER() AS cnt',
      'bd.id AS "id"',
      'b.name AS "billName"',
      'b.code AS "billCode"',
      'b.customer_id AS "customerId"',
      'bd.rent_duration_from AS "rentDurationFrom"',
      'bd.rent_duration_to AS "rentDurationTo"',
      'bd.price AS "price"',
      'bd.service_id AS "serviceId"',
      'bd.bill_id AS "billId"',
      `CASE WHEN COUNT(b) = 0 THEN '{}'
          ELSE JSONB_BUILD_OBJECT('id', b.id, 'name', b.name, 'code', b.code , 'status', b.status ,'billDate', b.created_at ) 
          END AS "bill"`,
      `CASE WHEN COUNT(s) = 0 THEN '{}'
          ELSE JSONB_BUILD_OBJECT('id', s.id, 'name', s.name, 'code', s.code) 
          END AS "service"`,
    ]);
    query
      .leftJoin(BillDetailEntity, 'bd', `"b"."id" = "bd"."bill_id"`)
      .leftJoin(ServiceEntity, 's', `"s"."id" = "bd"."service_id"`)
      .groupBy('bd.id')
      .addGroupBy('b.name')
      .addGroupBy('b.id')
      .addGroupBy('s.id')
      .addGroupBy('b.vendor_id')
      .addGroupBy('b.customer_id')
      .addGroupBy('b.created_at')
      .addGroupBy('b.status');

    if (keyword) {
      query
        .orWhere(
          `LOWER(unaccent("b"."name")) LIKE LOWER(unaccent(:pkeyWord)) escape '\\'`,
          {
            pkeyWord: `%${escapeCharForSearch(keyword)}%`,
          },
        )
        .orWhere(
          `LOWER(unaccent("b"."code")) LIKE LOWER(unaccent(:pkeyWord)) escape '\\'`,
          {
            pkeyWord: `%${escapeCharForSearch(keyword)}%`,
          },
        );
    }
    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        switch (item.column) {
          case 'billCode':
            query.andWhere(
              `LOWER(unaccent("b"."code")) LIKE LOWER(unaccent(:code)) ESCAPE '\\'`,
              {
                code: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'serviceName':
            query.andWhere(
              `LOWER(unaccent("s"."name")) LIKE LOWER(unaccent(:name)) ESCAPE '\\'`,
              {
                name: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'customerId':
            query.andWhere(`"b"."customer_id" = :fCustomerId`, {
              fCustomerId: item.text,
            });
            break;
          case 'customerName':
            if (!isEmpty(customerIds)) {
              query.andWhere(`"b"."customer_id" IN (:...customerIds)`, {
                customerIds,
              });
            }
            break;
          case 'billDate':
            const from = item.text.split('|')[0];
            const to = item.text.split('|')[1];
            query.andWhere(`"b"."created_at" between :from AND :to`, {
              from: from,
              to: to,
            });
            break;
          case 'serviceId':
            query.andWhere(`"bd"."service_id" = :fServiceId`, {
              fServiceId: item.text,
            });
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        switch (item.column) {
          case 'billCode':
            query = query.orderBy('"b"."code"', item.order);
            break;
          default:
            break;
        }
      });
    } else {
      query.orderBy('bd.id', 'DESC');
    }
    const data = +isGetAll
      ? await query.getRawMany()
      : await query.offset(skip).limit(take).getRawMany();
    const count = +(await query.getRawOne())?.cnt || 0;
    return [data, count];
  }
}
