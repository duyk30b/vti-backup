import { CreateVoucherAttributeRequestDto } from '@components/voucher/dto/request/create-voucher-attribute.request.dto';
import { UpdateVoucherAttributeRequestDto } from '@components/voucher/dto/request/update-voucher-attribute.request.dto';
import { VoucherAttributesRepositoryInterface } from '@components/voucher/interface/voucher-attribute.repository.interface';
import { BaseAbstractRepository } from '@core/repositories/base.abstract.repository';
import { VoucherAttributeEntity } from '@entities/voucher/voucher-attribute.entity';
import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';

@Injectable()
export class VoucherAttributesRepository
  extends BaseAbstractRepository<VoucherAttributeEntity>
  implements VoucherAttributesRepositoryInterface
{
  constructor(
    @InjectRepository(VoucherAttributeEntity)
    private readonly voucherAttributeRepository: Repository<VoucherAttributeEntity>,
  ) {
    super(voucherAttributeRepository);
  }

  createEntity(request: CreateVoucherAttributeRequestDto) {
    const entity = new VoucherAttributeEntity();
    entity.name = request.name;
    entity.value = request.value;
    entity.voucherId = request.voucherId;
    return entity;
  }

  updateEntity(request: UpdateVoucherAttributeRequestDto) {
    const entity = new VoucherAttributeEntity();
    entity.id = request?.id;
    entity.name = request.name;
    entity.value = request.value;
    entity.voucherId = request.voucherId;
    return entity;
  }
}
