import { BillModule } from '@components/bill/bill.module';
import { CustomerClassModule } from '@components/customer-class/customer-class.module';
import { InvoiceTypeModule } from '@components/invoice-type/invoice-type.module';
import { NotificationModule } from '@components/notification/notification.module';
import { PaymentTypeModule } from '@components/payment-type/payment-type.module';
import { RentUnitModule } from '@components/rent-unit/rent-unit.module';
import { SaleModule } from '@components/sale/sale.module';
import { ServiceTypeModule } from '@components/service-type/service-type.module';
import { ServiceModule } from '@components/service/service.module';
import { StaticModule } from '@components/static/static.module';
import { UserModule } from '@components/user/user.module';
import { VoucherModule } from '@components/voucher/voucher.module';
import { ConfigService } from '@config/config.service';
import * as connectionOptions from '@config/database.config';
import { HttpClientModule } from '@core/components/http-client/http-client.module';
import { ValidationPipe } from '@core/pipe/validator.pipe';
import { NatsClientModule } from '@core/transporter/nats-transporter/nats-client.module';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { APP_PIPE } from '@nestjs/core';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { TypeOrmModule } from '@nestjs/typeorm';
import { I18nJsonParser, I18nModule } from 'nestjs-i18n';
import * as path from 'path';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AuthModule } from './components/auth/auth.module';
import { CurrencyUnitModule } from './components/currency-unit/currency-unit.module';
import { CoreModule } from './core/core.module';
import { QueryResolver } from './i18n/query-resolver';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    I18nModule.forRoot({
      fallbackLanguage: 'vi',
      parser: I18nJsonParser,
      parserOptions: {
        path: path.join(__dirname, '/i18n/'),
        watch: true,
      },
      resolvers: [{ use: QueryResolver, options: ['lang', 'locale', 'l'] }],
    }),
    EventEmitterModule.forRoot(),
    TypeOrmModule.forRoot(connectionOptions),
    AuthModule,
    CoreModule,
    RentUnitModule,
    UserModule,
    PaymentTypeModule,
    CurrencyUnitModule,
    VoucherModule,
    CustomerClassModule,
    ServiceTypeModule,
    InvoiceTypeModule,
    StaticModule,
    ServiceModule,
    BillModule,
    SaleModule,
    HttpClientModule,
    NotificationModule,
    NatsClientModule,
  ],
  controllers: [AppController],
  providers: [
    {
      provide: APP_PIPE,
      useClass: ValidationPipe,
    },
    ConfigService,
    AppService,
  ],
})
export class AppModule {}
