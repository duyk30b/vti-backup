export enum APIPrefix {
  Version = 'api/v1',
}

//permission
export enum StatusPermission {
  ACTIVE = 1,
  INACTIVE = 0,
}

export const FORMAT_CODE_PERMISSION = 'WAREHOUSE_YARD_';

export const ROLE = {
  ADMIN: '01',
  EMPLOYEE: '02',
  PM: '03',
  LEADER: '04',
};
