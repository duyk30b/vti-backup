import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { InvoiceTypeAttributeEntity } from '@entities/invoice-type/invoice-type-attribute.entity';

export interface InvoiceTypeAttributeRepositoryInterface
  extends BaseInterfaceRepository<InvoiceTypeAttributeEntity> {
  createEntity(data: any): InvoiceTypeAttributeEntity;
  updateEntity(request: any): InvoiceTypeAttributeEntity;
}
