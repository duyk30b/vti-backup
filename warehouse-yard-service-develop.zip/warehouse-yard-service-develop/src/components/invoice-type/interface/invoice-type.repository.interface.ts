import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { InvoiceTypeEntity } from '@entities/invoice-type/invoice-type.entity';
import { GetListInvoiceTypeRequestDto } from '../dto/request/get-list-invoice-type.request.dto';

export interface InvoiceTypeRepositoryInterface
  extends BaseInterfaceRepository<InvoiceTypeEntity> {
  createEntity(data: any): InvoiceTypeEntity;
  updateEntity(entity: InvoiceTypeEntity, request: any): InvoiceTypeEntity;
  getList(request: GetListInvoiceTypeRequestDto): Promise<any>;
  getDetail(id: number);
}
