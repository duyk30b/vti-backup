import { SetStatusRequestDto } from '@utils/common.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreateInvoiceTypeRequestDto } from '../dto/request/create-invoice-type.request.dto';
import { DeleteInvoiceTypeDto } from '../dto/request/delete-invoice-type.request.dto';
import { GetListInvoiceTypeRequestDto } from '../dto/request/get-list-invoice-type.request.dto';
import { UpdateInvoiceTypeRequestDto } from '../dto/request/update-invoice-type.request.dto';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';

export interface InvoiceTypeServiceInterface {
  create(payload: CreateInvoiceTypeRequestDto): Promise<ResponsePayload<any>>;
  update(payload: UpdateInvoiceTypeRequestDto): Promise<ResponsePayload<any>>;
  getDetail(id: number): Promise<ResponsePayload<any>>;
  delete(id: DeleteInvoiceTypeDto): Promise<ResponsePayload<any>>;
  getList(payload: GetListInvoiceTypeRequestDto): Promise<ResponsePayload<any>>;
  confirm(request: SetStatusRequestDto): Promise<ResponsePayload<any>>;
  deleteMultiple(request: DeleteMultipleDto): Promise<ResponsePayload<any>>;
  confirmMultiple(request: DeleteMultipleDto): Promise<ResponsePayload<any>>;
  reject(request: SetStatusRequestDto): Promise<ResponsePayload<any>>;
  importInvoiceType(request: FileUploadRequestDto): Promise<any>;
}
