import { UserResponseDto } from '@components/user/dto/response/user.response.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { CustomFieldResponse } from '@utils/custom-field.response.dto';
import { Expose, Type } from 'class-transformer';

export class InvoiceTypeResponseDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'Hoá đơn bán hàng', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: '001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'Mô tả', description: '' })
  @Expose()
  description: string;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  status: number;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  createdAt: Date;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  updatedAt: Date;

  @ApiPropertyOptional()
  @Type(() => CustomFieldResponse)
  @Expose()
  customFields: CustomFieldResponse[];

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  createdByUser: UserResponseDto;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  latestEditedUser: UserResponseDto;
}
