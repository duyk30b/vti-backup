import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { PagingResponse } from '@utils/paging.response';
import { InvoiceTypeResponseDto } from './invoice-type.response.dto';
import { SuccessResponse } from '@utils/success.response.dto';

export class DataList extends PagingResponse {
  @ApiProperty({ type: InvoiceTypeResponseDto, isArray: true })
  @Type(() => InvoiceTypeResponseDto)
  @Expose()
  @IsArray()
  items: InvoiceTypeResponseDto[];
}
export class GetListInvoiceTypeResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: DataList;
}
