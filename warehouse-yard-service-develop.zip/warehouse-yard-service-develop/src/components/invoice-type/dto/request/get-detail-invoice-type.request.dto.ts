import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class GetDetailInvoiceTypeRequestDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'Id của loại hoá đơn' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
