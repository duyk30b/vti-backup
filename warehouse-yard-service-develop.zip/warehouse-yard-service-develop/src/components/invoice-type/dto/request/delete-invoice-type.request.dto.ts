import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class DeleteInvoiceTypeDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'Mã id của loại hoá đơn cần xóa' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
