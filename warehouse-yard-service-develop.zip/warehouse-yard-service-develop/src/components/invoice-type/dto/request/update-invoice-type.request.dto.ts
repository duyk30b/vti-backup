import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CreateInvoiceTypeRequestDto } from './create-invoice-type.request.dto';

export class UpdateInvoiceTypeRequestDto extends CreateInvoiceTypeRequestDto {
  @ApiProperty({ example: 1, description: 'Id của loại hoá đơn cần update' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
