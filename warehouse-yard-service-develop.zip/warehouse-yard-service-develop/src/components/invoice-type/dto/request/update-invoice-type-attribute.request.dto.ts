import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CreateInvoiceTypeAttributeRequestDto } from './create-invoice-type-attribute.request.dto';

export class UpdateInvoiceTypeAttributeRequestDto extends CreateInvoiceTypeAttributeRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;
}
