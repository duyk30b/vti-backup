import { ApiProperty } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { CustomFieldRequest } from '@utils/custom-field.request.dto';

export class CreateInvoiceTypeRequestDto extends BaseDto {
  @ApiProperty({ example: 'VND', description: 'Tên loại hoá đơn' })
  @IsNotEmpty()
  @MaxLength(255)
  @IsString()
  name: string;

  @ApiProperty({ example: '001', description: 'Mã loại hoá đơn' })
  @IsNotEmpty()
  @MaxLength(50)
  @IsString()
  code: string;

  @ApiProperty({ example: 'Mô tả', description: 'Mô tả' })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;

  @ApiProperty({ type: CustomFieldRequest, isArray: true })
  @ValidateNested()
  @IsOptional()
  customFields: CustomFieldRequest[];
}
