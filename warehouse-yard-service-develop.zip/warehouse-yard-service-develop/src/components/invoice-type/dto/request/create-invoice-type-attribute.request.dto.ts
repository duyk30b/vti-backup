import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CustomFieldRequest } from '@utils/custom-field.request.dto';

export class CreateInvoiceTypeAttributeRequestDto extends CustomFieldRequest {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  invoiceTypeId: number;
}
