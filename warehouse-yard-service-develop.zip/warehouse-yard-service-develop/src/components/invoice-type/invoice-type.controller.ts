import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Post,
  Put,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiResponse } from '@nestjs/swagger';
import { SetStatusRequestDto } from '@utils/common.request.dto';
import {
  CONFIRM_INVOICE_TYPE_PERMISSION,
  CREATE_INVOICE_TYPE_PERMISSION,
  DELETE_INVOICE_TYPE_PERMISSION,
  DETAIL_INVOICE_TYPE_PERMISSION,
  LIST_INVOICE_TYPE_PERMISSION,
  REJECT_INVOICE_TYPE_PERMISSION,
  UPDATE_INVOICE_TYPE_PERMISSION,
  IMPORT_INVOICE_TYPE_PERMISSION,
} from '@utils/permissions/invoice-type';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateInvoiceTypeRequestDto } from './dto/request/create-invoice-type.request.dto';
import { DeleteInvoiceTypeDto } from './dto/request/delete-invoice-type.request.dto';
import { GetDetailInvoiceTypeRequestDto } from './dto/request/get-detail-invoice-type.request.dto';

import { GetListInvoiceTypeRequestDto } from './dto/request/get-list-invoice-type.request.dto';
import { UpdateInvoiceTypeRequestDto } from './dto/request/update-invoice-type.request.dto';
import { GetListInvoiceTypeResponseDto } from './dto/response/get-list-invoice-type.response.dto';
import { InvoiceTypeResponseDto } from './dto/response/invoice-type.response.dto';
import { InvoiceTypeServiceInterface } from './interface/invoice-type.service.interface';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';

@Controller('invoice-types')
export class InvoiceTypeController {
  constructor(
    @Inject('InvoiceTypeServiceInterface')
    private readonly invoiceTypeService: InvoiceTypeServiceInterface,
  ) {}

  @Post('/invoice-types/create')
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: InvoiceTypeResponseDto,
  })
  @PermissionCode(CREATE_INVOICE_TYPE_PERMISSION.code)
  @MessagePattern('create_invoice_type')
  public async createInvoiceType(
    payload: CreateInvoiceTypeRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.invoiceTypeService.create(request);
  }

  @Get('/invoice-types/:id')
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: InvoiceTypeResponseDto,
  })
  @PermissionCode(DETAIL_INVOICE_TYPE_PERMISSION.code)
  @MessagePattern('get_invoice_type_detail')
  public async getInvoiceTypeDetail(
    @Body() payload: GetDetailInvoiceTypeRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.invoiceTypeService.getDetail(request.id);
  }

  @Get('/invoice-types/list')
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListInvoiceTypeResponseDto,
  })
  @PermissionCode(LIST_INVOICE_TYPE_PERMISSION.code)
  @MessagePattern('get_list_invoice_type')
  public async getListInvoiceType(
    @Body() payload: GetListInvoiceTypeRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.invoiceTypeService.getList(request);
  }

  @Put('/invoice-types/:id')
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: InvoiceTypeResponseDto,
  })
  @PermissionCode(UPDATE_INVOICE_TYPE_PERMISSION.code)
  @MessagePattern('update_invoice_type')
  public async updateInvoiceType(
    @Body() payload: UpdateInvoiceTypeRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.invoiceTypeService.update(request);
  }

  @Delete('/invoice-types/:id')
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  @PermissionCode(DELETE_INVOICE_TYPE_PERMISSION.code)
  @MessagePattern('delete_invoice_type')
  public async deleteInvoiceType(
    @Body() payload: DeleteInvoiceTypeDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.invoiceTypeService.delete(request);
  }

  @PermissionCode(DELETE_INVOICE_TYPE_PERMISSION.code)
  @MessagePattern('delete_invoice_type_multiple')
  public async deleteMultipleInvoiceType(
    @Body() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.invoiceTypeService.deleteMultiple(request);
  }

  @Put('/invoice-types/:id/confirm')
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: InvoiceTypeResponseDto,
  })
  @PermissionCode(CONFIRM_INVOICE_TYPE_PERMISSION.code)
  @MessagePattern('confirm_invoice_type')
  public async confirm(@Body() body: SetStatusRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.invoiceTypeService.confirm(request);
  }

  @PermissionCode(CONFIRM_INVOICE_TYPE_PERMISSION.code)
  @MessagePattern('confirm_invoice_type_multiple')
  public async confirmMultiple(@Body() body: DeleteMultipleDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.invoiceTypeService.confirmMultiple(request);
  }

  @Put('/invoice-types/:id/reject')
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: InvoiceTypeResponseDto,
  })
  @PermissionCode(REJECT_INVOICE_TYPE_PERMISSION.code)
  @MessagePattern('reject_invoice_type')
  public async reject(@Body() body: SetStatusRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.invoiceTypeService.reject(request);
  }

  @PermissionCode(IMPORT_INVOICE_TYPE_PERMISSION.code)
  @MessagePattern('import_invoice_type')
  public async importFactory(@Body() body: FileUploadRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.invoiceTypeService.importInvoiceType(request);
  }
}
