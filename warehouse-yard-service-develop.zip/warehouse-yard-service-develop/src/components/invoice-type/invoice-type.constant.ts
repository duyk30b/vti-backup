export enum InvoiceTypeStatusEnum {
  CREATED = 0,
  CONFIRMED = 1,
  REJECT = 2,
}

export const CAN_UPDATE_INVOICE_TYPE_STATUS: number[] = [
  InvoiceTypeStatusEnum.CREATED,
  InvoiceTypeStatusEnum.REJECT,
];

export const CAN_DELETE_INVOICE_TYPE_STATUS: number[] = [
  InvoiceTypeStatusEnum.CREATED,
  InvoiceTypeStatusEnum.REJECT,
];

export const CAN_CONFIRM_INVOICE_TYPE_STATUS: number[] = [
  InvoiceTypeStatusEnum.CREATED,
  InvoiceTypeStatusEnum.REJECT,
];

export const CAN_REJECT_INVOICE_TYPE_STATUS: number[] = [
  InvoiceTypeStatusEnum.CREATED,
];
