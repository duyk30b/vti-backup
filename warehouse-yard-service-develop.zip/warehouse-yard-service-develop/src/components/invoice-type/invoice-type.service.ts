import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToClass } from 'class-transformer';
import { isEmpty } from 'class-validator';
import { isEmpty as isEmpty2 } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { Connection, Not, In } from 'typeorm';
import {
  CAN_CONFIRM_INVOICE_TYPE_STATUS,
  CAN_DELETE_INVOICE_TYPE_STATUS,
  CAN_REJECT_INVOICE_TYPE_STATUS,
  CAN_UPDATE_INVOICE_TYPE_STATUS,
  InvoiceTypeStatusEnum,
} from './invoice-type.constant';
import { InvoiceTypeAttributeRepositoryInterface } from './interface/invoice-type-attribute.repository.interface';
import { CreateInvoiceTypeAttributeRequestDto } from './dto/request/create-invoice-type-attribute.request.dto';
import { InvoiceTypeServiceInterface } from './interface/invoice-type.service.interface';
import { InvoiceTypeRepositoryInterface } from './interface/invoice-type.repository.interface';
import { CreateInvoiceTypeRequestDto } from './dto/request/create-invoice-type.request.dto';
import { InvoiceTypeResponseDto } from './dto/response/invoice-type.response.dto';
import { UpdateInvoiceTypeRequestDto } from './dto/request/update-invoice-type.request.dto';
import { GetListInvoiceTypeRequestDto } from './dto/request/get-list-invoice-type.request.dto';
import { DeleteInvoiceTypeDto } from './dto/request/delete-invoice-type.request.dto';
import { SetStatusRequestDto } from '@utils/common.request.dto';
import { InvoiceTypeImport } from './import/invoice-type.import.helper';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { InvoiceTypeEntity } from '@entities/invoice-type/invoice-type.entity';
import { stringFormat } from '@utils/object.util';

@Injectable()
export class InvoiceTypeService implements InvoiceTypeServiceInterface {
  constructor(
    @Inject('InvoiceTypeRepositoryInterface')
    private readonly invoiceTypeRepository: InvoiceTypeRepositoryInterface,

    @Inject('InvoiceTypeAttributeRepositoryInterface')
    private readonly invoiceTypeAttributeRepository: InvoiceTypeAttributeRepositoryInterface,

    @Inject('InvoiceTypeImport')
    private readonly invoiceTypeImport: InvoiceTypeImport,
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @InjectConnection()
    private readonly connection: Connection,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  public async create(
    request: CreateInvoiceTypeRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { customFields, code, name } = request;
    const invoiceTypeCode = await this.invoiceTypeRepository.findByCondition({
      code,
    });
    if (invoiceTypeCode.length) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_EXIST'),
      ).toResponse();
    }

    const invoiceTypeName = await this.invoiceTypeRepository.findByCondition({
      name,
    });
    if (invoiceTypeName.length) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.NAME_EXIST'),
      ).toResponse();
    }
    const newInvoiceTypeEntity = await this.invoiceTypeRepository.createEntity(
      request,
    );
    const queryRunner = this.connection.createQueryRunner();
    let invoiceType;
    await queryRunner.startTransaction();

    try {
      invoiceType = await queryRunner.manager.save(newInvoiceTypeEntity);

      if (customFields.length > 0) {
        const invoiceTypeAttributeEntities = [];
        customFields.forEach((customField) => {
          const request = new CreateInvoiceTypeAttributeRequestDto();
          request.name = customField.name;
          request.invoiceTypeId = invoiceType.id;
          request.value = customField.value;

          invoiceTypeAttributeEntities.push(
            this.invoiceTypeAttributeRepository.createEntity(request),
          );
        });

        const response = await queryRunner.manager.save(
          invoiceTypeAttributeEntities,
        );
        invoiceType.customFields = response.map((i) => ({
          name: i.name,
          value: i.value,
        }));
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
    const responseData = plainToClass(InvoiceTypeResponseDto, invoiceType, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(responseData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async update(
    request: UpdateInvoiceTypeRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { code, customFields, id, name } = request;
    const invoiceType = await this.invoiceTypeRepository.findOneById(id);
    if (!invoiceType) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (!CAN_UPDATE_INVOICE_TYPE_STATUS.includes(invoiceType.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    }

    const invoiceTypeCode = await this.invoiceTypeRepository.findByCondition({
      code,
      id: Not(id),
    });

    if (request.code !== invoiceType.code && invoiceTypeCode.length > 0) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_EXIST'),
      ).toResponse();
    }

    const invoiceTypeName = await this.invoiceTypeRepository.findByCondition({
      name,
      id: Not(id),
    });
    if (invoiceTypeName.length) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.NAME_EXIST'),
      ).toResponse();
    }
    const invoiceTypeEntity = await this.invoiceTypeRepository.updateEntity(
      invoiceType,
      request,
    );

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    let result;
    try {
      result = await queryRunner.manager.save(invoiceTypeEntity);
      const invoiceTypeAttributes =
        await this.invoiceTypeAttributeRepository.findWithRelations({
          where: {
            invoiceTypeId: invoiceTypeEntity.id,
          },
        });
      await queryRunner.manager.remove(invoiceTypeAttributes);
      const attributesEntityList = [];
      if (customFields.length > 0) {
        customFields.forEach((customField) => {
          const request = new CreateInvoiceTypeAttributeRequestDto();
          request.name = customField.name;
          request.invoiceTypeId = invoiceType.id;
          request.value = customField.value;

          attributesEntityList.push(
            this.invoiceTypeAttributeRepository.createEntity(request),
          );
        });

        const response = await queryRunner.manager.save(attributesEntityList);
        result.customFields = response.map((i) => ({
          name: i.name,
          value: i.value,
        }));
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error.message)
        .build();
    }

    await queryRunner.release();

    const response = plainToClass(InvoiceTypeResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  public async getList(
    request: GetListInvoiceTypeRequestDto,
  ): Promise<ResponsePayload<any> | any> {
    const { result, total } = await this.invoiceTypeRepository.getList(request);

    const dataReturn = plainToClass(InvoiceTypeResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getDetail(id: number): Promise<ResponsePayload<any>> {
    const invoiceType = await this.invoiceTypeRepository.getDetail(id);

    if (isEmpty(invoiceType)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const users = await this.userService.getUserByIds(
      [invoiceType.createdByUserId, invoiceType.latestEditedUserId],
      true,
    );

    invoiceType['createdByUser'] = users[invoiceType.createdByUserId];
    invoiceType['latestEditedUser'] = users[invoiceType.latestEditedUserId];

    const response = plainToClass(InvoiceTypeResponseDto, invoiceType, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async delete(
    request: DeleteInvoiceTypeDto,
  ): Promise<ResponsePayload<any>> {
    const invoiceType = await this.invoiceTypeRepository.findOneById(
      request.id,
    );
    if (!invoiceType) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    if (!CAN_DELETE_INVOICE_TYPE_STATUS.includes(invoiceType.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate(
          'error.CAN_NOT_UPDATE_IN_CONFIRM_INVOICE_TYPE',
        ),
      ).toResponse();
    }

    try {
      await this.invoiceTypeRepository.remove(request.id);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Delete
   */
  public async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const invoiceTypes = await this.invoiceTypeRepository.findByCondition({
      id: In(ids),
    });

    const invoiceTypeIds = invoiceTypes.map((invoiceType) => invoiceType.id);
    if (invoiceTypes.length !== ids.length) {
      ids.forEach((id) => {
        if (!invoiceTypeIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < invoiceTypes.length; i++) {
      const invoiceType = invoiceTypes[i];
      if (!CAN_DELETE_INVOICE_TYPE_STATUS.includes(invoiceType.status))
        failIdsList.push(invoiceType.id);
    }

    const validIds = invoiceTypes
      .filter((invoiceType) => !failIdsList.includes(invoiceType.id))
      .map((invoiceType) => invoiceType.id);

    try {
      if (!isEmpty2(validIds)) {
        this.invoiceTypeRepository.multipleRemove(validIds);
      }
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    if (isEmpty2(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id } = request;
    const invoiceType = await this.invoiceTypeRepository.findOneById(id);

    if (!invoiceType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_CONFIRM_INVOICE_TYPE_STATUS.includes(invoiceType.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.CAN_NOT_CONFIRM_INVOICE_TYPE'),
        )
        .build();
    }
    invoiceType.status = InvoiceTypeStatusEnum.CONFIRMED;
    const result = await this.invoiceTypeRepository.create(invoiceType);
    const response = plainToClass(InvoiceTypeResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async confirmMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const invoiceTypes = await this.invoiceTypeRepository.findByCondition({
      id: In(ids),
    });

    const invoiceTypeIds = invoiceTypes.map((invoiceType) => invoiceType.id);
    if (invoiceTypes.length !== ids.length) {
      ids.forEach((id) => {
        if (!invoiceTypeIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < invoiceTypes.length; i++) {
      const invoiceType = invoiceTypes[i];
      if (!CAN_CONFIRM_INVOICE_TYPE_STATUS.includes(invoiceType.status))
        failIdsList.push(invoiceType.id);
    }

    const validIds = invoiceTypes
      .filter((invoiceType) => !failIdsList.includes(invoiceType.id))
      .map((invoiceType) => invoiceType.id);

    const validateInvoiceTypes = invoiceTypes.filter((invoiceType) =>
      validIds.includes(invoiceType.id),
    );

    if (!isEmpty2(validateInvoiceTypes)) {
      validateInvoiceTypes.forEach((serviceType) => {
        serviceType.status = InvoiceTypeStatusEnum.CONFIRMED;
      });
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(InvoiceTypeEntity, validateInvoiceTypes);
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty2(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.CONFIRM_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async reject(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id } = request;
    const invoiceType = await this.invoiceTypeRepository.findOneById(id);

    if (!invoiceType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_REJECT_INVOICE_TYPE_STATUS.includes(invoiceType.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.CAN_NOT_REJECT_INVOICE_TYPE'),
        )
        .build();
    }

    invoiceType.status = InvoiceTypeStatusEnum.REJECT;
    const result = await this.invoiceTypeRepository.create(invoiceType);
    const response = plainToClass(InvoiceTypeResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async importInvoiceType(request: FileUploadRequestDto): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
      userId: request.userId,
    } as ImportRequestDto;
    return this.invoiceTypeImport.importUtil(importRequestDto);
  }
}
