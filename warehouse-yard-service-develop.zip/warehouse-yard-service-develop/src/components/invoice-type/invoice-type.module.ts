import { InvoiceTypeAttributeEntity } from '@entities/invoice-type/invoice-type-attribute.entity';
import { InvoiceTypeEntity } from '@entities/invoice-type/invoice-type.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InvoiceTypeAttributeRepository } from '@repositories/invoice-type/invoice-type-attribute.repository';
import { InvoiceTypeRepository } from '@repositories/invoice-type/invoice-type.repository';
import { InvoiceTypeImport } from './import/invoice-type.import.helper';
import { InvoiceTypeController } from './invoice-type.controller';
import { InvoiceTypeService } from './invoice-type.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([InvoiceTypeEntity, InvoiceTypeAttributeEntity]),
  ],
  providers: [
    {
      provide: 'InvoiceTypeServiceInterface',
      useClass: InvoiceTypeService,
    },
    {
      provide: 'InvoiceTypeRepositoryInterface',
      useClass: InvoiceTypeRepository,
    },
    {
      provide: 'InvoiceTypeAttributeRepositoryInterface',
      useClass: InvoiceTypeAttributeRepository,
    },
    {
      provide: 'InvoiceTypeImport',
      useClass: InvoiceTypeImport,
    },
  ],

  controllers: [InvoiceTypeController],
})
export class InvoiceTypeModule {}
