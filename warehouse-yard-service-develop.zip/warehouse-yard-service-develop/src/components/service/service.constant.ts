export enum ServiceStatusEnum {
  CREATED = 0,
  CONFIRMED = 1,
  REJECT = 2,
}

export const CAN_UPDATE_SERVICE_STATUS: number[] = [
  ServiceStatusEnum.CREATED,
  ServiceStatusEnum.REJECT,
];

export const CAN_DELETE_SERVICE_STATUS: number[] = [
  ServiceStatusEnum.CREATED,
  ServiceStatusEnum.REJECT,
];

export const CAN_CONFIRM_SERVICE_STATUS: number[] = [
  ServiceStatusEnum.CREATED,
  ServiceStatusEnum.REJECT,
];

export const CAN_REJECT_SERVICE_STATUS: number[] = [ServiceStatusEnum.CREATED];
