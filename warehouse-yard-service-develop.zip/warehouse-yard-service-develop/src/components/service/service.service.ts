import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToClass } from 'class-transformer';
import { isEmpty } from 'class-validator';
import { isEmpty as isEmpty2 } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { Connection, In } from 'typeorm';
import {
  CAN_CONFIRM_SERVICE_STATUS,
  CAN_DELETE_SERVICE_STATUS,
  CAN_REJECT_SERVICE_STATUS,
  CAN_UPDATE_SERVICE_STATUS,
  ServiceStatusEnum,
} from './service.constant';
import { ServiceAttributeRepositoryInterface } from './interface/service-attribute.repository.interface';
import { CreateServiceAttributeRequestDto } from './dto/request/create-service-attribute.request.dto';
import { ServiceServiceInterface } from './interface/service.service.interface';
import { ServiceRepositoryInterface } from './interface/service.repository.interface';
import { CreateServiceRequestDto } from './dto/request/create-service.request.dto';
import { ServiceResponseDto } from './dto/response/service.response.dto';
import { UpdateServiceRequestDto } from './dto/request/update-service.request.dto';
import { GetListServiceRequestDto } from './dto/request/get-list-service.request.dto';
import { DeleteServiceDto } from './dto/request/delete-service.request.dto';
import { SetStatusRequestDto } from '@utils/common.request.dto';
import { CurrencyUnitRepository } from '@repositories/currency-unit/currency-unit.repository';
import { RentUnitRepository } from '@repositories/rent-unit/rent-unit.repository';
import { ServiceTypeRepo } from '@repositories/service-type/service-type.repository';
import { VoucherRepository } from '@repositories/voucher.repository';
import { UsedVoucherRepository } from '@repositories/service/used-voucher.repository';
import { CreateUsedVoucherRequestDto } from './dto/request/create-used-voucher.request.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { GetListServiceIdsRequestDto } from './dto/request/list-service-ids.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { stringFormat } from '@utils/object.util';
import { ServiceEntity } from '@entities/service/service.entity';

@Injectable()
export class ServiceService implements ServiceServiceInterface {
  constructor(
    @Inject('ServiceRepositoryInterface')
    private readonly serviceRepository: ServiceRepositoryInterface,

    @Inject('ServiceAttributeRepositoryInterface')
    private readonly serviceAttributeRepository: ServiceAttributeRepositoryInterface,

    @Inject('CurrencyUnitRepositoryInterface')
    private readonly currencyUnitRepository: CurrencyUnitRepository,

    @Inject('RentUnitRepositoryInterface')
    private readonly rentUnitRepository: RentUnitRepository,

    @Inject('ServiceTypeRepoInterface')
    private readonly serviceTypeRepository: ServiceTypeRepo,

    @Inject('VoucherRepositoryInterface')
    private readonly voucherRepository: VoucherRepository,

    @Inject('UsedVoucherRepositoryInterface')
    private readonly usedVoucherRepository: UsedVoucherRepository,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @InjectConnection()
    private readonly connection: Connection,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  public async create(
    request: CreateServiceRequestDto,
  ): Promise<ResponsePayload<any>> {
    const {
      customFields,
      code,
      currencyUnitId,
      rentUnitId,
      serviceTypeId,
      voucherId,
      userId,
    } = request;

    const serviceCode = await this.serviceRepository.checkServiceCodeExist(
      code,
    );
    if (serviceCode.length) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_EXIST'),
      ).toResponse();
    }

    const currencyUnit = await this.currencyUnitRepository.findOneById(
      currencyUnitId,
    );
    if (!currencyUnit)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CURRENCY_UNIT_NOT_FOUND'))
        .build();

    const rentUnit = await this.rentUnitRepository.findOneById(rentUnitId);
    if (!rentUnit)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.RENT_UNIT_NOT_FOUND'))
        .build();

    const serviceType = await this.serviceTypeRepository.findOneById(
      serviceTypeId,
    );
    if (!serviceType)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.SERVICE_TYPE_NOT_FOUND'))
        .build();

    const voucher = await this.voucherRepository.findOneById(voucherId);
    if (!voucher)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.VOUCHER_NOT_FOUND'))
        .build();

    const newServiceEntity = await this.serviceRepository.createEntity(request);
    const queryRunner = this.connection.createQueryRunner();
    let service;
    await queryRunner.startTransaction();

    try {
      service = await queryRunner.manager.save(newServiceEntity);
      const usedVoucherEntity = this.usedVoucherRepository.createEntity({
        createdBy: userId,
        serviceId: service.id,
        voucherId: voucherId,
      });
      const responseUsedVoucher = await queryRunner.manager.save(
        usedVoucherEntity,
      );

      if (customFields.length > 0) {
        const serviceAttributeEntities = [];
        customFields.forEach((customField) => {
          const request = new CreateServiceAttributeRequestDto();
          request.name = customField.name;
          request.serviceId = service.id;
          request.value = customField.value;

          serviceAttributeEntities.push(
            this.serviceAttributeRepository.createEntity(request),
          );
        });

        const response = await queryRunner.manager.save(
          serviceAttributeEntities,
        );
        service.customFields = response.map((i) => ({
          name: i.name,
          value: i.value,
        }));
        service.voucherId = responseUsedVoucher.voucherId;
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
    const responseData = plainToClass(ServiceResponseDto, service, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(responseData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async update(
    request: UpdateServiceRequestDto,
  ): Promise<ResponsePayload<any>> {
    const {
      code,
      customFields,
      currencyUnitId,
      rentUnitId,
      serviceTypeId,
      userId,
      voucherId,
    } = request;
    const service = await this.serviceRepository.findOneById(request.id);

    if (!service) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (!CAN_UPDATE_SERVICE_STATUS.includes(service.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    }

    const serviceCode = await this.serviceRepository.checkServiceCodeExist(
      code,
    );
    if (request.code !== service.code && serviceCode.length > 0) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_EXIST'),
      ).toResponse();
    }

    const currencyUnit = await this.currencyUnitRepository.findOneById(
      currencyUnitId,
    );
    if (!currencyUnit)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CURRENCY_UNIT_NOT_FOUND'))
        .build();

    const rentUnit = await this.rentUnitRepository.findOneById(rentUnitId);
    if (!rentUnit)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.RENT_UNIT_NOT_FOUND'))
        .build();

    const serviceType = await this.serviceTypeRepository.findOneById(
      serviceTypeId,
    );
    if (!serviceType)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.SERVICE_TYPE_NOT_FOUND'))
        .build();

    const voucher = await this.voucherRepository.findOneById(voucherId);
    if (!voucher)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.VOUCHER_NOT_FOUND'))
        .build();
    const serviceEntity = await this.serviceRepository.updateEntity(
      service,
      request,
    );

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    let result;
    const usedVoucher = await this.usedVoucherRepository.findWithRelations({
      where: {
        serviceId: serviceEntity.id,
      },
    });
    try {
      result = await queryRunner.manager.save(serviceEntity);
      await queryRunner.manager.remove(usedVoucher);
      const usedVoucherEntity = this.usedVoucherRepository.createEntity({
        createdBy: userId,
        serviceId: service.id,
        voucherId: voucherId,
      });
      const responseUsedVoucher = await queryRunner.manager.save(
        usedVoucherEntity,
      );
      const serviceAttributes =
        await this.serviceAttributeRepository.findWithRelations({
          where: {
            serviceId: serviceEntity.id,
          },
        });
      await queryRunner.manager.remove(serviceAttributes);

      const attributesEntityList = [];
      if (customFields.length > 0) {
        customFields.forEach((customField) => {
          const request = new CreateServiceAttributeRequestDto();
          request.name = customField.name;
          request.serviceId = service.id;
          request.value = customField.value;

          attributesEntityList.push(
            this.serviceAttributeRepository.createEntity(request),
          );
        });

        const response = await queryRunner.manager.save(attributesEntityList);
        result.customFields = response.map((i) => ({
          name: i.name,
          value: i.value,
        }));
        result.voucherId = responseUsedVoucher.voucherId;
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error.message)
        .build();
    }

    await queryRunner.release();

    const response = plainToClass(ServiceResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  public async getList(
    request: GetListServiceRequestDto,
  ): Promise<ResponsePayload<any> | any> {
    const { result, total } = await this.serviceRepository.getList(request);

    const dataReturn = plainToClass(ServiceResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getDetail(id: number): Promise<ResponsePayload<any>> {
    const service = await this.serviceRepository.getDetail(id);

    if (isEmpty(service)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const users = await this.userService.getUserByIds(
      [service.createdByUserId, service.latestEditedUserId],
      true,
    );

    if (!isEmpty(users)) {
      service['createdByUser'] = users[service.createdByUserId];
      service['latestEditedUser'] = users[service.latestEditedUserId];
    }
    const response = plainToClass(ServiceResponseDto, service, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async delete(
    request: DeleteServiceDto,
  ): Promise<ResponsePayload<any>> {
    const service = await this.serviceRepository.findOneById(request.id);
    if (!service) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    if (!CAN_DELETE_SERVICE_STATUS.includes(service.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_UPDATE_IN_CONFIRM_SERVICE'),
      ).toResponse();
    }

    try {
      await this.serviceRepository.remove(request.id);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Delete
   */
  public async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const services = await this.serviceRepository.findByCondition({
      id: In(ids),
    });

    const serviceIds = services.map((service) => service.id);
    if (services.length !== ids.length) {
      ids.forEach((id) => {
        if (!serviceIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < services.length; i++) {
      const service = services[i];
      if (!CAN_DELETE_SERVICE_STATUS.includes(service.status))
        failIdsList.push(service.id);
    }

    const validIds = services
      .filter((service) => !failIdsList.includes(service.id))
      .map((service) => service.id);

    try {
      if (!isEmpty2(validIds)) {
        this.serviceRepository.multipleRemove(validIds);
      }
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    if (isEmpty2(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id } = request;
    const service = await this.serviceRepository.findOneById(id);

    if (!service) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_CONFIRM_SERVICE_STATUS.includes(service.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CONFIRM_SERVICE'))
        .build();
    }
    service.status = ServiceStatusEnum.CONFIRMED;
    const result = await this.serviceRepository.create(service);
    const response = plainToClass(ServiceResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async confirmMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const services = await this.serviceRepository.findByCondition({
      id: In(ids),
    });

    const serviceIds = services.map((service) => service.id);
    if (services.length !== ids.length) {
      ids.forEach((id) => {
        if (!serviceIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < services.length; i++) {
      const service = services[i];
      if (!CAN_CONFIRM_SERVICE_STATUS.includes(service.status))
        failIdsList.push(service.id);
    }

    const validIds = services
      .filter((service) => !failIdsList.includes(service.id))
      .map((service) => service.id);

    const validateServices = services.filter((service) =>
      validIds.includes(service.id),
    );

    if (!isEmpty2(validateServices)) {
      validateServices.forEach((serviceType) => {
        serviceType.status = ServiceStatusEnum.CONFIRMED;
      });
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(ServiceEntity, validateServices);
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty2(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.CONFIRM_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async reject(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id } = request;
    const service = await this.serviceRepository.findOneById(id);

    if (!service) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_REJECT_SERVICE_STATUS.includes(service.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_REJECT_SERVICE'))
        .build();
    }

    service.status = ServiceStatusEnum.REJECT;
    const result = await this.serviceRepository.create(service);
    const response = plainToClass(ServiceResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  async getListService(request: GetListServiceIdsRequestDto): Promise<any> {
    const item = await this.serviceRepository.getListService(
      request.serviceIds,
    );
    const response = plainToClass(ServiceResponseDto, item, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder({
      services: response,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }
}
