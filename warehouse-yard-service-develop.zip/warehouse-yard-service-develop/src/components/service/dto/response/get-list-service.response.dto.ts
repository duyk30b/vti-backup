import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { PagingResponse } from '@utils/paging.response';
import { SuccessResponse } from '@utils/success.response.dto';
import { ServiceResponseDto } from './service.response.dto';

export class DataList extends PagingResponse {
  @ApiProperty({ type: ServiceResponseDto, isArray: true })
  @Type(() => ServiceResponseDto)
  @Expose()
  @IsArray()
  items: ServiceResponseDto[];
}
export class GetListServiceResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: DataList;
}
