import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class CreateUsedVoucherRequestDto extends BaseDto {
  @ApiProperty({ example: 1, description: '' })
  @IsNotEmpty()
  @IsInt()
  serviceId: number;

  @ApiProperty({ example: 1, description: '' })
  @IsNotEmpty()
  @IsInt()
  voucherId: number;

  @ApiProperty({ example: 1, description: '' })
  @IsNotEmpty()
  @IsInt()
  createdBy: number;
}
