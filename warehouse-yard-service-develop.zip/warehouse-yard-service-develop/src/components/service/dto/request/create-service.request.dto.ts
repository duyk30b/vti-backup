import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { CustomFieldRequest } from '@utils/custom-field.request.dto';
import {
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';

export class CreateServiceRequestDto extends BaseDto {
  @ApiProperty({ example: 'Thuê kho bãi', description: 'Name' })
  @IsNotEmpty()
  @MaxLength(255)
  @IsString()
  name: string;

  @ApiProperty({ example: '001', description: 'Code' })
  @IsNotEmpty()
  @MaxLength(20)
  @IsString()
  code: string;

  @ApiProperty({
    example: 20000,
    description: 'Đơn giá/ngày',
  })
  @IsNumber()
  @IsNotEmpty()
  @Min(0)
  pricePerDay: number;

  @ApiProperty({
    example: 20000,
    description: 'Đơn giá/tháng',
  })
  @IsNumber()
  @IsNotEmpty()
  @Min(0)
  pricePerMonth: number;

  @ApiProperty({
    example: 20000,
    description: 'Đơn giá/quý',
  })
  @IsNumber()
  @IsNotEmpty()
  @Min(0)
  pricePerQuarter: number;

  @ApiProperty({
    example: 20000,
    description: 'Đơn giá/năm',
  })
  @IsNumber()
  @IsNotEmpty()
  @Min(0)
  pricePerYear: number;

  @ApiProperty({ example: 'Mô tả', description: 'Mô tả' })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;

  @ApiProperty({ example: 1, description: 'Id đơn vị tiền tệ ' })
  @IsNotEmpty()
  @IsInt()
  currencyUnitId: number;

  @ApiProperty({ example: 1, description: 'Id đơn vị tính' })
  @IsNotEmpty()
  @IsInt()
  rentUnitId: number;

  @ApiProperty({ example: 1, description: 'Id loại dịch vụ' })
  @IsNotEmpty()
  @IsInt()
  serviceTypeId: number;

  @ApiProperty({ example: 1, description: 'Id mã giảm giá' })
  @IsNotEmpty()
  @IsInt()
  voucherId: number;

  @ApiProperty({ example: 1, description: 'Id user' })
  @IsNotEmpty()
  @IsInt()
  userId: number;

  @ApiProperty({ type: CustomFieldRequest, isArray: true })
  @ValidateNested()
  @IsOptional()
  customFields: CustomFieldRequest[];
}
