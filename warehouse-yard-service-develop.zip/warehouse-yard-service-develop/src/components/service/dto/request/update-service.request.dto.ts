import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CreateServiceRequestDto } from './create-service.request.dto';

export class UpdateServiceRequestDto extends CreateServiceRequestDto {
  @ApiProperty({ example: 1, description: 'Id của dịch vụ cần update' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
