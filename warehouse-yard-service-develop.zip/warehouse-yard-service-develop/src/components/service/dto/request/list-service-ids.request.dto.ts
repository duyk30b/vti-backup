import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsOptional } from 'class-validator';

export class GetListServiceIdsRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @IsArray()
  serviceIds: number[];
}
