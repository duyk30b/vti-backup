import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class GetDetailServiceRequestDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'Id của dịch vụ' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
