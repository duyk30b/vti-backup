import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CreateServiceAttributeRequestDto } from './create-service-attribute.request.dto';

export class UpdateServiceAttributeRequestDto extends CreateServiceAttributeRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;
}
