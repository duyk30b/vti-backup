import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { CurrencyUnitRepository } from '@repositories/currency-unit/currency-unit.repository';
import { CurrencyUnitEntity } from '@entities/currency-unit/currency-unit.entity';
import { ServiceEntity } from '@entities/service/service.entity';
import { ServiceAttributeEntity } from '@entities/service/service-attribute.entity';
import { RentUnitEntity } from '@entities/rent-unit/rent-unit.entity';
import { ServiceTypeEntity } from '@entities/service-type/service-type.entity';
import { ServiceController } from './service.controller';
import { ServiceRepository } from '@repositories/service/service.repository';
import { ServiceAttributeRepository } from '@repositories/service/service-attribute.repository';
import { RentUnitRepository } from '@repositories/rent-unit/rent-unit.repository';
import { ServiceTypeRepo } from '@repositories/service-type/service-type.repository';
import { ServiceService } from './service.service';
import { VoucherEntity } from '@entities/voucher/voucher.entity';
import { UsedVoucherEntity } from '@entities/service/used-voucher.entity';
import { VoucherRepository } from '@repositories/voucher.repository';
import { UsedVoucherRepository } from '@repositories/service/used-voucher.repository';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      ServiceEntity,
      ServiceAttributeEntity,
      CurrencyUnitEntity,
      RentUnitEntity,
      ServiceTypeEntity,
      UsedVoucherEntity,
      VoucherEntity,
    ]),
  ],
  providers: [
    {
      provide: 'ServiceRepositoryInterface',
      useClass: ServiceRepository,
    },
    {
      provide: 'ServiceAttributeRepositoryInterface',
      useClass: ServiceAttributeRepository,
    },
    {
      provide: 'ServiceServiceInterface',
      useClass: ServiceService,
    },
    {
      provide: 'CurrencyUnitRepositoryInterface',
      useClass: CurrencyUnitRepository,
    },
    {
      provide: 'RentUnitRepositoryInterface',
      useClass: RentUnitRepository,
    },
    {
      provide: 'ServiceTypeRepoInterface',
      useClass: ServiceTypeRepo,
    },
    {
      provide: 'VoucherRepositoryInterface',
      useClass: VoucherRepository,
    },
    {
      provide: 'UsedVoucherRepositoryInterface',
      useClass: UsedVoucherRepository,
    },
  ],
  controllers: [ServiceController],
  exports: [
    {
      provide: 'ServiceRepositoryInterface',
      useClass: ServiceRepository,
    },
  ],
})
export class ServiceModule {}
