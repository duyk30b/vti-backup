import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { SetStatusRequestDto } from '@utils/common.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreateServiceRequestDto } from '../dto/request/create-service.request.dto';
import { DeleteServiceDto } from '../dto/request/delete-service.request.dto';
import { GetListServiceRequestDto } from '../dto/request/get-list-service.request.dto';
import { GetListServiceIdsRequestDto } from '../dto/request/list-service-ids.request.dto';
import { UpdateServiceRequestDto } from '../dto/request/update-service.request.dto';

export interface ServiceServiceInterface {
  create(payload: CreateServiceRequestDto): Promise<ResponsePayload<any>>;
  update(payload: UpdateServiceRequestDto): Promise<ResponsePayload<any>>;
  getDetail(id: number): Promise<ResponsePayload<any>>;
  delete(id: DeleteServiceDto): Promise<ResponsePayload<any>>;
  getList(payload: GetListServiceRequestDto): Promise<ResponsePayload<any>>;
  confirm(request: SetStatusRequestDto): Promise<ResponsePayload<any>>;
  deleteMultiple(request: DeleteMultipleDto): Promise<ResponsePayload<any>>;
  confirmMultiple(request: DeleteMultipleDto): Promise<ResponsePayload<any>>;
  reject(request: SetStatusRequestDto): Promise<ResponsePayload<any>>;
  getListService(request: GetListServiceIdsRequestDto): Promise<any>;
}
