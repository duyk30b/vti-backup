import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { UsedVoucherEntity } from '@entities/service/used-voucher.entity';

export interface UsedVoucherRepositoryInterface
  extends BaseInterfaceRepository<UsedVoucherEntity> {
  createEntity(data: any): UsedVoucherEntity;
}
