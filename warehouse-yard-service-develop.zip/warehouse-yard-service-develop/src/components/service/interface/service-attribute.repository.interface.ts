import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { ServiceAttributeEntity } from '@entities/service/service-attribute.entity';

export interface ServiceAttributeRepositoryInterface
  extends BaseInterfaceRepository<ServiceAttributeEntity> {
  createEntity(data: any): ServiceAttributeEntity;
  updateEntity(request: any): ServiceAttributeEntity;
}
