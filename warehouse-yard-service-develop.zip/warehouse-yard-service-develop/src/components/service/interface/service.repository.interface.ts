import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { ServiceEntity } from '@entities/service/service.entity';
import { GetListServiceRequestDto } from '../dto/request/get-list-service.request.dto';

export interface ServiceRepositoryInterface
  extends BaseInterfaceRepository<ServiceEntity> {
  createEntity(data: any): ServiceEntity;
  updateEntity(entity: ServiceEntity, request: any): ServiceEntity;
  getList(request: GetListServiceRequestDto): Promise<any>;
  getDetail(id: number);
  checkServiceCodeExist(code: string, serviceId?: number);
  getListService(serviceIds?: number[]): Promise<any>;
}
