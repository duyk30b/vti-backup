import { PermissionCode } from '@core/decorator/get-code.decorator';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Post,
  Put,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiResponse } from '@nestjs/swagger';
import { SetStatusRequestDto } from '@utils/common.request.dto';
import {
  CONFIRM_SERVICE_PERMISSION,
  CREATE_SERVICE_PERMISSION,
  DELETE_SERVICE_PERMISSION,
  DETAIL_SERVICE_PERMISSION,
  LIST_SERVICE_PERMISSION,
  REJECT_SERVICE_PERMISSION,
  UPDATE_SERVICE_PERMISSION,
} from '@utils/permissions/service';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateServiceRequestDto } from './dto/request/create-service.request.dto';
import { DeleteServiceDto } from './dto/request/delete-service.request.dto';
import { GetDetailServiceRequestDto } from './dto/request/get-detail-service.request.dto';
import { GetListServiceRequestDto } from './dto/request/get-list-service.request.dto';
import { GetListServiceIdsRequestDto } from './dto/request/list-service-ids.request.dto';
import { UpdateServiceRequestDto } from './dto/request/update-service.request.dto';
import { GetListServiceResponseDto } from './dto/response/get-list-service.response.dto';
import { ServiceResponseDto } from './dto/response/service.response.dto';
import { ServiceServiceInterface } from './interface/service.service.interface';

@Controller('services')
export class ServiceController {
  constructor(
    @Inject('ServiceServiceInterface')
    private readonly serviceService: ServiceServiceInterface,
  ) {}

  @Post('/services/create')
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ServiceResponseDto,
  })
  @PermissionCode(CREATE_SERVICE_PERMISSION.code)
  @MessagePattern('create_service')
  public async createService(payload: CreateServiceRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.serviceService.create(request);
  }

  @Get('/services/:id')
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: ServiceResponseDto,
  })
  @PermissionCode(DETAIL_SERVICE_PERMISSION.code)
  @MessagePattern('get_service_detail')
  public async getServiceDetail(
    @Body() payload: GetDetailServiceRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.serviceService.getDetail(request.id);
  }

  @Get('/services/list')
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListServiceResponseDto,
  })
  @PermissionCode(LIST_SERVICE_PERMISSION.code)
  @MessagePattern('get_list_service')
  public async getListService(
    @Body() payload: GetListServiceRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.serviceService.getList(request);
  }

  @Put('/services/:id')
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: ServiceResponseDto,
  })
  @PermissionCode(UPDATE_SERVICE_PERMISSION.code)
  @MessagePattern('update_service')
  public async updateService(
    @Body() payload: UpdateServiceRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.serviceService.update(request);
  }

  @Delete('/services/:id')
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  @PermissionCode(DELETE_SERVICE_PERMISSION.code)
  @MessagePattern('delete_service')
  public async deleteService(@Body() payload: DeleteServiceDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.serviceService.delete(request);
  }

  @PermissionCode(DELETE_SERVICE_PERMISSION.code)
  @MessagePattern('delete_service_multiple')
  public async deleteMultipleService(
    @Body() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.serviceService.deleteMultiple(request);
  }

  @Put('/services/:id/confirm')
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ServiceResponseDto,
  })
  @PermissionCode(CONFIRM_SERVICE_PERMISSION.code)
  @MessagePattern('confirm_service')
  public async confirm(@Body() body: SetStatusRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.serviceService.confirm(request);
  }

  @PermissionCode(CONFIRM_SERVICE_PERMISSION.code)
  @MessagePattern('confirm_service_multiple')
  public async confirmMultiple(@Body() body: DeleteMultipleDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.serviceService.confirmMultiple(request);
  }

  @Put('/services/:id/reject')
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: ServiceResponseDto,
  })
  @PermissionCode(REJECT_SERVICE_PERMISSION.code)
  @MessagePattern('reject_service')
  public async reject(@Body() body: SetStatusRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.serviceService.reject(request);
  }

  @MessagePattern('get_list_service_by_ids_of_bill')
  public async getServiceByIds(
    @Body() payload: GetListServiceIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.serviceService.getListService(request);
  }
}
