import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { escapeCharForSearch } from '@utils/common';
import { flatMap, isEmpty, map, uniq } from 'lodash';
import { UserServiceInterface } from './interface/user.service.interface';

@Injectable()
export class UserService implements UserServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async getCompanies(condition, serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send('get_companies', {
      condition: condition,
    });
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    const serilizeCompany = {};
    if (serilize) {
      response.data.forEach((c) => {
        serilizeCompany[c.id] = c;
      });

      return serilizeCompany;
    }
    return response.data;
  }

  async getUserByIds(ids: number[], serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send('get_users_by_ids', {
      userIds: ids,
    });
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    const serilizeUsers = {};
    if (serilize) {
      response.data.forEach((user) => {
        serilizeUsers[user.id] = user;
      });

      return serilizeUsers;
    }
    return response.data;
  }

  async getFactories(condition): Promise<any> {
    return await this.natsClientService.send('get_factories', {
      condition: condition,
    });
  }

  async getFactoriesByIds(ids, serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send('get_factory_by_ids', {
      ids: ids,
    });
    if (serilize) {
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
      const serilizeFactories = {};
      response.data.forEach((factory) => {
        serilizeFactories[factory.id] = factory;
      });

      return serilizeFactories;
    }

    return response;
  }

  async deleteRecordUserWarehouses(condition): Promise<any> {
    return await this.natsClientService.send(
      'delete_user_warehouse_by_condition',
      {
        condition: condition,
      },
    );
  }

  async getUsersByConditions(condition): Promise<any> {
    return await this.natsClientService.send('get_users_by_conditions', {
      condition: condition,
    });
  }

  async getUsersByUsernameOrFullName(filterByUser, onlyId?): Promise<any> {
    if (isEmpty(filterByUser)) {
      return [];
    }

    const users = await this.getUsersByConditions(
      'LOWER(username)LIKE ' +
        `LOWER(unaccent('%${escapeCharForSearch(
          filterByUser.text,
        )}%')) escape '\\'` +
        ' or LOWER(full_name) LIKE ' +
        `LOWER(unaccent('%${escapeCharForSearch(
          filterByUser.text,
        )}%')) escape '\\'`,
    );

    if (!isEmpty(users) && onlyId === true) {
      return uniq(map(flatMap(users), 'id'));
    }

    return users;
  }

  public async insertPermission(permissions): Promise<any> {
    return await this.natsClientService.send('insert_permission', permissions);
  }

  public async deletePermissionNotActive(): Promise<any> {
    return await this.natsClientService.send(
      'delete_permission_not_active',
      {},
    );
  }

  public async getUserById(id: number): Promise<any> {
    const result = await this.natsClientService.send('detail', { id });
    if (result.statusCode !== ResponseCodeEnum.SUCCESS) return {};
    return result.data;
  }

  public async getUsersByRoleCodes(roleCodes?: string[]): Promise<any> {
    const result = await this.natsClientService.send(
      'get_users_by_role_codes',
      { roleCodes },
    );
    if (result.statusCode !== ResponseCodeEnum.SUCCESS) return {};
    return result.data;
  }
}
