export class PushNotificationRequestDto {
  title: string;
  content: string;
  templateId?: string;
  executionDate?: string;
  type: string;
  action: string;
  payload?: Payload;
  userIds?: number[];
}

class Payload {
  title: string;
  content: string;
}
