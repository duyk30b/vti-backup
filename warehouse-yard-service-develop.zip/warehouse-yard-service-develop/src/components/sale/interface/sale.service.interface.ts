export interface SaleServiceInterface {
  getCustomerById(id: number): Promise<any>;
  getCustomerByIds(condition, serilize?: boolean): Promise<any>;
  getCustomerByNameKeyword(
    filterByName,
    onlyId?: boolean,
    serilize?: boolean,
  ): Promise<any>;
  billCompleteEvent(data: any): Promise<any>;
}
