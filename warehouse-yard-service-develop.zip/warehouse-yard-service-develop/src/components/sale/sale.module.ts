import { SaleService } from '@components/sale/sale.service';
import { ConfigService } from '@config/config.service';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { SaleCronService } from './sale-cron.service';
@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
    {
      provide: 'SaleServiceInterface',
      useClass: SaleCronService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
    {
      provide: 'SaleServiceInterface',
      useClass: SaleCronService,
    },
  ],
  controllers: [],
})
export class SaleModule {}
