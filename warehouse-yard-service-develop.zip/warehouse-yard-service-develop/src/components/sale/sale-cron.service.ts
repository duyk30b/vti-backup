import { BillCompleteEvent } from '@components/bill/events/bill-complete.event';
import { SaleServiceInterface } from '@components/sale/interface/sale.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { flatMap, isEmpty, map, uniq } from 'lodash';
@Injectable()
export class SaleCronService implements SaleServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}
  async getCustomerById(id: number): Promise<any> {
    const response = await this.natsClientService.send('get_customer', { id });
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return null;
    return response.data;
  }

  async billCompleteEvent(data: BillCompleteEvent): Promise<any> {
    const response = await this.natsClientService.send('update_bill_complete', {
      ...data,
    });
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return null;
    return response.data;
  }

  async getCustomerByIds(ids: number[], serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send('get_customers_by_ids', {
      customerIds: ids,
    });
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    const serilizeUsers = {};
    if (serilize) {
      response.data.forEach((customer) => {
        serilizeUsers[customer.id] = customer;
      });

      return serilizeUsers;
    }
    return response.data;
  }

  async getCustomerByNameKeyword(
    filterByName,
    onlyId?: boolean,
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      'get_customer_by_name_keyword',
      {
        nameKeyword: filterByName.text,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    if (!isEmpty(response.data) && onlyId === true) {
      return uniq(map(flatMap(response.data), 'id'));
    }

    if (serilize) {
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
      const serilizeCustomers = [];
      response.data.forEach((customer) => {
        serilizeCustomers[customer.id] = customer;
      });

      return serilizeCustomers;
    }

    return response.data;
  }
}
