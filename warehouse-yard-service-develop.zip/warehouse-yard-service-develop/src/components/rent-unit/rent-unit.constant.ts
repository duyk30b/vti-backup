export enum RentUnitStatusEnum {
  CREATED = 0,
  CONFIRMED = 1,
  REJECT = 2,
}

export const CAN_UPDATE_RENT_UNIT_STATUS: number[] = [
  RentUnitStatusEnum.CREATED,
  RentUnitStatusEnum.REJECT,
];

export const CAN_DELETE_RENT_UNIT_STATUS: number[] = [
  RentUnitStatusEnum.CREATED,
  RentUnitStatusEnum.REJECT,
];

export const CAN_CONFIRM_RENT_UNIT_STATUS: number[] = [
  RentUnitStatusEnum.CREATED,
  RentUnitStatusEnum.REJECT,
];

export const CAN_REJECT_RENT_UNIT_STATUS: number[] = [
  RentUnitStatusEnum.CREATED,
];
