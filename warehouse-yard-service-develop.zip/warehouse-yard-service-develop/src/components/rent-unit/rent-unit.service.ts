import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToClass } from 'class-transformer';
import { isEmpty } from 'class-validator';
import { isEmpty as isEmpty2 } from 'lodash';
import { I18nService } from 'nestjs-i18n';
import { Connection, In, Not } from 'typeorm';
import { SetStatusRequestDto } from './dto/request/set-status-request.dto';
import {
  CAN_CONFIRM_RENT_UNIT_STATUS,
  CAN_DELETE_RENT_UNIT_STATUS,
  CAN_REJECT_RENT_UNIT_STATUS,
  CAN_UPDATE_RENT_UNIT_STATUS,
  RentUnitStatusEnum,
} from './rent-unit.constant';
import { RentUnitAttributeRepositoryInterface } from './interface/rent-unit-attribute.repository.interface';
import { CreateRentUnitAttributeRequestDto } from './dto/request/create-rent-unit-attribute.request.dto';
import { RentUnitServiceInterface } from './interface/rent-unit.service.interface';
import { RentUnitRepositoryInterface } from './interface/rent-unit.repository.interface';
import { CreateRentUnitRequestDto } from './dto/request/create-rent-unit.request.dto';
import { RentUnitResponseDto } from './dto/response/rent-unit.response.dto';
import { UpdateRentUnitRequestDto } from './dto/request/update-rent-unit.request.dto';
import { GetListRentUnitRequestDto } from './dto/request/get-list-rent-unit.request.dto';
import { DeleteRentUnitDto } from './dto/request/delete-rent-unit.request.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { RentUnitImport } from './import/rent-unit.import.helper';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { stringFormat } from '@utils/object.util';
import { RentUnitEntity } from '@entities/rent-unit/rent-unit.entity';

@Injectable()
export class RentUnitService implements RentUnitServiceInterface {
  constructor(
    @Inject('RentUnitRepositoryInterface')
    private readonly rentUnitRepository: RentUnitRepositoryInterface,

    @Inject('RentUnitAttributeRepositoryInterface')
    private readonly rentUnitAttributeRepository: RentUnitAttributeRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('RentUnitImport')
    private readonly rentUnitImport: RentUnitImport,

    @InjectConnection()
    private readonly connection: Connection,

    private readonly i18n: I18nService,
  ) {}

  public async create(
    request: CreateRentUnitRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { customFields, code, name } = request;
    const rentUnitCode = await this.rentUnitRepository.findByCondition({
      code,
    });
    if (rentUnitCode.length) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_EXIST'),
      ).toResponse();
    }

    const rentUnitName = await this.rentUnitRepository.findByCondition({
      name,
    });
    if (rentUnitName.length) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.NAME_EXIST'),
      ).toResponse();
    }
    const newRentUnitEntity = await this.rentUnitRepository.createEntity(
      request,
    );
    const queryRunner = this.connection.createQueryRunner();
    let rentUnit;
    await queryRunner.startTransaction();

    try {
      rentUnit = await queryRunner.manager.save(newRentUnitEntity);

      if (customFields.length > 0) {
        const rentUnitAttributeEntities = [];
        customFields.forEach((customField) => {
          const request = new CreateRentUnitAttributeRequestDto();
          request.name = customField.name;
          request.rentUnitId = rentUnit.id;
          request.value = customField.value;

          rentUnitAttributeEntities.push(
            this.rentUnitAttributeRepository.createEntity(request),
          );
        });

        const response = await queryRunner.manager.save(
          rentUnitAttributeEntities,
        );
        rentUnit.customFields = response.map((i) => ({
          name: i.name,
          value: i.value,
        }));
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
    const responseData = plainToClass(RentUnitResponseDto, rentUnit, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(responseData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async update(
    request: UpdateRentUnitRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { name, code, customFields, id } = request;
    const rentUnit = await this.rentUnitRepository.findOneById(id);
    if (!rentUnit) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (!CAN_UPDATE_RENT_UNIT_STATUS.includes(rentUnit.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    }

    const rentUnitCode = await this.rentUnitRepository.findByCondition({
      code,
      id: Not(id),
    });

    if (request.code !== rentUnit.code && rentUnitCode.length > 0) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_EXIST'),
      ).toResponse();
    }

    const rentUnitName = await this.rentUnitRepository.findByCondition({
      name,
      id: Not(id),
    });
    if (rentUnitName.length) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.NAME_EXIST'),
      ).toResponse();
    }
    const rentUnitEntity = await this.rentUnitRepository.updateEntity(
      rentUnit,
      request,
    );

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    let result;
    try {
      result = await queryRunner.manager.save(rentUnitEntity);
      const rentUnitAttributes =
        await this.rentUnitAttributeRepository.findWithRelations({
          where: {
            rentUnitId: rentUnitEntity.id,
          },
        });
      await queryRunner.manager.remove(rentUnitAttributes);
      const attributesEntityList = [];
      if (customFields.length > 0) {
        customFields.forEach((customField) => {
          const request = new CreateRentUnitAttributeRequestDto();
          request.name = customField.name;
          request.rentUnitId = rentUnit.id;
          request.value = customField.value;

          attributesEntityList.push(
            this.rentUnitAttributeRepository.createEntity(request),
          );
        });

        const response = await queryRunner.manager.save(attributesEntityList);
        result.customFields = response.map((i) => ({
          name: i.name,
          value: i.value,
        }));

        await queryRunner.commitTransaction();
      }
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error.message)
        .build();
    }

    await queryRunner.release();

    const response = plainToClass(RentUnitResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  public async getList(
    request: GetListRentUnitRequestDto,
  ): Promise<ResponsePayload<any> | any> {
    const { result, total } = await this.rentUnitRepository.getList(request);

    const dataReturn = plainToClass(RentUnitResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getDetail(id: number): Promise<ResponsePayload<any>> {
    const rentUnit = await this.rentUnitRepository.getDetail(id);

    if (isEmpty(rentUnit)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const users = await this.userService.getUserByIds(
      [rentUnit.createdByUserId, rentUnit.latestEditedUserId],
      true,
    );

    rentUnit['createdByUser'] = users[rentUnit.createdByUserId];
    rentUnit['latestEditedUser'] = users[rentUnit.latestEditedUserId];

    const response = plainToClass(RentUnitResponseDto, rentUnit, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async delete(
    request: DeleteRentUnitDto,
  ): Promise<ResponsePayload<any>> {
    const rentUnit = await this.rentUnitRepository.findOneById(request.id);
    if (!rentUnit) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    if (!CAN_DELETE_RENT_UNIT_STATUS.includes(rentUnit.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_UPDATE_IN_CONFIRM_RENT_UNIT'),
      ).toResponse();
    }

    try {
      await this.rentUnitRepository.remove(request.id);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Delete
   */
  public async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const rentUnits = await this.rentUnitRepository.findByCondition({
      id: In(ids),
    });

    const rentUnitIds = rentUnits.map((rentUnit) => rentUnit.id);
    if (rentUnits.length !== ids.length) {
      ids.forEach((id) => {
        if (!rentUnitIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < rentUnits.length; i++) {
      const rentUnit = rentUnits[i];
      if (!CAN_DELETE_RENT_UNIT_STATUS.includes(rentUnit.status))
        failIdsList.push(rentUnit.id);
    }

    const validIds = rentUnits
      .filter((rentUnit) => !failIdsList.includes(rentUnit.id))
      .map((rentUnit) => rentUnit.id);

    try {
      if (!isEmpty2(validIds)) {
        this.rentUnitRepository.multipleRemove(validIds);
      }
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    if (isEmpty2(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, userId } = request;
    const rentUnit = await this.rentUnitRepository.findOneById(id);

    if (!rentUnit) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_CONFIRM_RENT_UNIT_STATUS.includes(rentUnit.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.CAN_NOT_CONFIRM_RENT_UNIT'),
        )
        .build();
    }
    rentUnit.status = RentUnitStatusEnum.CONFIRMED;
    const result = await this.rentUnitRepository.create(rentUnit);
    const response = plainToClass(RentUnitResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async confirmMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const rentUnits = await this.rentUnitRepository.findByCondition({
      id: In(ids),
    });

    const rentUnitIds = rentUnits.map((rentUnit) => rentUnit.id);
    if (rentUnits.length !== ids.length) {
      ids.forEach((id) => {
        if (!rentUnitIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < rentUnits.length; i++) {
      const rentUnit = rentUnits[i];
      if (!CAN_CONFIRM_RENT_UNIT_STATUS.includes(rentUnit.status))
        failIdsList.push(rentUnit.id);
    }

    const validIds = rentUnits
      .filter((rentUnit) => !failIdsList.includes(rentUnit.id))
      .map((rentUnit) => rentUnit.id);

    const validateRentUnits = rentUnits.filter((rentUnit) =>
      validIds.includes(rentUnit.id),
    );

    if (!isEmpty2(validateRentUnits)) {
      validateRentUnits.forEach((rentUnit) => {
        rentUnit.status = RentUnitStatusEnum.CONFIRMED;
      });
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(RentUnitEntity, validateRentUnits);
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty2(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.CONFIRM_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async reject(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, userId } = request;
    const rentUnit = await this.rentUnitRepository.findOneById(id);

    if (!rentUnit) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_REJECT_RENT_UNIT_STATUS.includes(rentUnit.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.CAN_NOT_REJECT_RENT_UNIT'),
        )
        .build();
    }

    rentUnit.status = RentUnitStatusEnum.REJECT;
    const result = await this.rentUnitRepository.create(rentUnit);
    const response = plainToClass(RentUnitResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async importRentUnit(request: FileUploadRequestDto): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
      userId: request.userId,
    } as ImportRequestDto;
    return this.rentUnitImport.importUtil(importRequestDto);
  }
}
