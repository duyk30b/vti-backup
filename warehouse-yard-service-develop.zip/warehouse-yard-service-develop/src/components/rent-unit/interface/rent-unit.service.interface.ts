import { ResponsePayload } from '@utils/response-payload';
import { CreateRentUnitRequestDto } from '../dto/request/create-rent-unit.request.dto';
import { DeleteRentUnitDto } from '../dto/request/delete-rent-unit.request.dto';
import { GetListRentUnitRequestDto } from '../dto/request/get-list-rent-unit.request.dto';
import { SetStatusRequestDto } from '../dto/request/set-status-request.dto';
import { UpdateRentUnitRequestDto } from '../dto/request/update-rent-unit.request.dto';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
export interface RentUnitServiceInterface {
  create(payload: CreateRentUnitRequestDto): Promise<ResponsePayload<any>>;
  update(payload: UpdateRentUnitRequestDto): Promise<ResponsePayload<any>>;
  getDetail(id: number): Promise<ResponsePayload<any>>;
  delete(id: DeleteRentUnitDto): Promise<ResponsePayload<any>>;
  getList(payload: GetListRentUnitRequestDto): Promise<ResponsePayload<any>>;
  confirm(request: SetStatusRequestDto): Promise<ResponsePayload<any>>;
  deleteMultiple(request: DeleteMultipleDto): Promise<ResponsePayload<any>>;
  confirmMultiple(request: DeleteMultipleDto): Promise<ResponsePayload<any>>;
  reject(request: SetStatusRequestDto): Promise<ResponsePayload<any>>;
  importRentUnit(request: FileUploadRequestDto): Promise<any>;
}
