import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { RentUnitAttributeEntity } from '@entities/rent-unit/rent-unit-attribute.entity';

export interface RentUnitAttributeRepositoryInterface
  extends BaseInterfaceRepository<RentUnitAttributeEntity> {
  createEntity(data: any): RentUnitAttributeEntity;
  updateEntity(request: any): RentUnitAttributeEntity;
}
