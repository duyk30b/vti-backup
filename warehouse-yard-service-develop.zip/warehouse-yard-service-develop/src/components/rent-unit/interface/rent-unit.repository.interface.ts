import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { RentUnitEntity } from '@entities/rent-unit/rent-unit.entity';
import { GetListRentUnitRequestDto } from '../dto/request/get-list-rent-unit.request.dto';

export interface RentUnitRepositoryInterface
  extends BaseInterfaceRepository<RentUnitEntity> {
  createEntity(data: any): RentUnitEntity;
  updateEntity(entity: RentUnitEntity, request: any): RentUnitEntity;
  getList(request: GetListRentUnitRequestDto): Promise<any>;
  getDetail(id: number);
}
