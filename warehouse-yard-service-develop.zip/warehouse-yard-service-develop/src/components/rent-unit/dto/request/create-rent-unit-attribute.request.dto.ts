import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CustomFieldRequest } from '@utils/custom-field.request.dto';

export class CreateRentUnitAttributeRequestDto extends CustomFieldRequest {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  rentUnitId: number;
}
