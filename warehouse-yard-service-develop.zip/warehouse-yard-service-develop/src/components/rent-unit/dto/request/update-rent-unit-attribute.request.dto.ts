import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CreateRentUnitAttributeRequestDto } from './create-rent-unit-attribute.request.dto';

export class UpdateRentUnitAttributeRequestDto extends CreateRentUnitAttributeRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;
}
