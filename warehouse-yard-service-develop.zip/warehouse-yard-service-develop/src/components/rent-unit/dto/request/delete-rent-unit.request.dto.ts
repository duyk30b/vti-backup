import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class DeleteRentUnitDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'Mã id của đơn vị tính cần xóa' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
