import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class GetDetailRentUnitRequestDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'Id của đơn vị tính' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
