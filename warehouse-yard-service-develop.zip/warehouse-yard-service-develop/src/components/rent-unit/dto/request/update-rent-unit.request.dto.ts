import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CreateRentUnitRequestDto } from './create-rent-unit.request.dto';

export class UpdateRentUnitRequestDto extends CreateRentUnitRequestDto {
  @ApiProperty({ example: 1, description: 'Id của đơn vị tính cần update' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
