import { SuccessResponse } from '@components/currency-unit/dto/response/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { PagingResponse } from '@utils/paging.response';
import { RentUnitResponseDto } from './rent-unit.response.dto';

export class DataList extends PagingResponse {
  @ApiProperty({ type: RentUnitResponseDto, isArray: true })
  @Type(() => RentUnitResponseDto)
  @Expose()
  @IsArray()
  items: RentUnitResponseDto[];
}
export class GetListRentUnitResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: DataList;
}
