import { ImportDataAbstract } from '@core/abstracts/import-data.abstract';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectConnection } from '@nestjs/typeorm';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty, keyBy } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { Connection, In, ILike } from 'typeorm';
import { RentUnitRepositoryInterface } from '../interface/rent-unit.repository.interface';
import { RentUnitEntity } from '@entities/rent-unit/rent-unit.entity';
import { toLowerKeys } from '@utils/common';

@Injectable()
export class RentUnitImport extends ImportDataAbstract {
  private readonly FIELD_TEMPLATE_CONST = {
    CODE: {
      DB_COL_NAME: 'rentUnitCode',
      COL_NAME: ['Mã đơn vị tính', 'Type unit code', '計算単位コード'],
      MAX_LENGTH: 4,
      ALLOW_NULL: false,
      REGEX: /^([a-zA-Z0-9]+)$/,
    },
    NAME: {
      DB_COL_NAME: 'rentUnitName',
      COL_NAME: ['Type unit name', 'サービスタイプ名', 'Tên đơn vị tính'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    DESCRIPTION: {
      DB_COL_NAME: 'description',
      COL_NAME: ['Description', '説明', 'Mô tả'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    REQUIRED_COL_NUM: 4,
  };

  constructor(
    @Inject('RentUnitRepositoryInterface')
    private readonly rentUnitRepository: RentUnitRepositoryInterface,
    @InjectConnection()
    private readonly connection: Connection,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    this.fieldsMap.groupSet(
      [2, 3, 4],
      [
        this.FIELD_TEMPLATE_CONST.CODE,
        this.FIELD_TEMPLATE_CONST.NAME,
        this.FIELD_TEMPLATE_CONST.DESCRIPTION,
      ],
    );
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
    error: number,
    total: number,
    userId,
  ): Promise<ImportResponseDto> {
    const condition = {};
    dataDto
      .map((i) => i.rentUnitCode)
      .forEach((code) => {
        Object.assign(condition, { code: ILike(code) });
      });
    const findByCode = await this.rentUnitRepository.findWithRelations({
      where: condition,
    });
    const findByName = await this.rentUnitRepository.findWithRelations({
      where: {
        name: In(dataDto.map((i) => i.rentUnitName)),
      },
    });

    findByCode.forEach((i) => Object.assign(i, { type: 'old' }));
    findByName.forEach((i) => Object.assign(i, { type: 'old' }));

    const findByCodeMap = toLowerKeys(keyBy(findByCode, 'code'));
    const findByNameMap = keyBy(findByName, 'name');
    const entities = [];
    const valid = [];
    const {
      duplicateCodeOrNameMsg,
      codeNotExistMsg,
      successMsg,
      unsuccessMsg,
      addText,
      updateText,
      noText,
      doneText,
    } = await this.getMessage();
    dataDto.forEach((data) => {
      const { i, action, rentUnitCode, rentUnitName, description } = data;
      const logRow = {
        id: i,
        row: i,
        action: action,
      } as ImportResultDto;
      const msgLogs = [];

      const formatedData = new RentUnitEntity();
      formatedData.code = rentUnitCode;
      formatedData.name = rentUnitName;
      formatedData.description = description;

      if (action.toLowerCase() === addText) {
        if (
          findByCodeMap[rentUnitCode.toLowerCase()] ||
          findByNameMap[rentUnitName]
        ) {
          msgLogs.push(duplicateCodeOrNameMsg);
        } else {
          formatedData['userId'] = userId;
          const entity = this.rentUnitRepository.createEntity(formatedData);
          entities.push(entity);
          Object.assign(entity, { type: 'new' });
          findByCodeMap[rentUnitCode.toLowerCase()] = entity;
          findByNameMap[rentUnitName] = entity;
        }
      } else if (action.toLowerCase() === updateText) {
        if (
          findByCodeMap[rentUnitCode.toLowerCase()] &&
          findByCodeMap[rentUnitCode.toLowerCase()]?.['type'] === 'old'
        ) {
          if (
            findByNameMap[rentUnitName] &&
            findByNameMap[rentUnitName].id !=
              findByCodeMap[rentUnitCode.toLowerCase()].id
          ) {
            msgLogs.push(duplicateCodeOrNameMsg);
          } else {
            formatedData['userId'] = userId;
            const entity = this.rentUnitRepository.updateEntity(
              findByCodeMap[rentUnitCode.toLowerCase()],
              formatedData,
            );
            entities.push(entity);
            Object.assign(entity, { type: 'new' });
            findByCodeMap[rentUnitCode.toLowerCase()] = entity;
            findByNameMap[rentUnitName] = entity;
          }
        } else {
          msgLogs.push(codeNotExistMsg);
        }
      }
      if (isEmpty(msgLogs)) {
        logRow.log = [successMsg];
        valid.push(logRow);
      } else {
        logRow.log = msgLogs;
        logs.push(logRow);
      }
    });
    const response = new ImportResponseDto();
    if (!isEmpty(entities)) {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(entities);
        await queryRunner.commitTransaction();
        response.successCount = valid.length;
      } catch (error) {
        queryRunner.rollbackTransaction();
        response.successCount = 0;
        valid.forEach((l) => (l.log = [unsuccessMsg]));
      } finally {
        await queryRunner.release();
        logs.push(...valid);
      }
    }
    response.result = logs;
    response.totalCount = total;
    response.result;
    return response;
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<ImportResponseDto | any>> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_CONST.REQUIRED_COL_NUM,
    );
  }
}
