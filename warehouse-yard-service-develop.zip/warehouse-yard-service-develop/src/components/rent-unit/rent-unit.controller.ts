import { PermissionCode } from '@core/decorator/get-code.decorator';
import { Body, Controller, Inject } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import {
  CONFIRM_RENT_UNIT_PERMISSION,
  CREATE_RENT_UNIT_PERMISSION,
  DELETE_RENT_UNIT_PERMISSION,
  DETAIL_RENT_UNIT_PERMISSION,
  LIST_RENT_UNIT_PERMISSION,
  REJECT_RENT_UNIT_PERMISSION,
  UPDATE_RENT_UNIT_PERMISSION,
  IMPORT_RENT_UNIT_PERMISSION,
} from '@utils/permissions/rent-unit';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { isEmpty } from 'lodash';
import { CreateRentUnitRequestDto } from './dto/request/create-rent-unit.request.dto';
import { DeleteRentUnitDto } from './dto/request/delete-rent-unit.request.dto';
import { GetDetailRentUnitRequestDto } from './dto/request/get-detail-rent-unit.request.dto';

import { GetListRentUnitRequestDto } from './dto/request/get-list-rent-unit.request.dto';
import { SetStatusRequestDto } from './dto/request/set-status-request.dto';
import { UpdateRentUnitRequestDto } from './dto/request/update-rent-unit.request.dto';
import { RentUnitServiceInterface } from './interface/rent-unit.service.interface';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';

@Controller('rent-units')
export class RentUnitController {
  constructor(
    @Inject('RentUnitServiceInterface')
    private readonly rentUnitService: RentUnitServiceInterface,
  ) {}

  @PermissionCode(CREATE_RENT_UNIT_PERMISSION.code)
  @MessagePattern('create_rent_unit')
  public async createRentUnit(payload: CreateRentUnitRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.rentUnitService.create(request);
  }

  @PermissionCode(DETAIL_RENT_UNIT_PERMISSION.code)
  @MessagePattern('get_rent_unit_detail')
  public async getRentUnitDetail(
    @Body() payload: GetDetailRentUnitRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.rentUnitService.getDetail(request.id);
  }

  @PermissionCode(LIST_RENT_UNIT_PERMISSION.code)
  @MessagePattern('get_list_rent_unit')
  public async getListRentUnit(
    @Body() payload: GetListRentUnitRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.rentUnitService.getList(request);
  }

  @PermissionCode(UPDATE_RENT_UNIT_PERMISSION.code)
  @MessagePattern('update_rent_unit')
  public async updateRentUnit(
    @Body() payload: UpdateRentUnitRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.rentUnitService.update(request);
  }

  @PermissionCode(DELETE_RENT_UNIT_PERMISSION.code)
  @MessagePattern('delete_rent_unit')
  public async deleteRentUnit(
    @Body() payload: DeleteRentUnitDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.rentUnitService.delete(request);
  }

  @PermissionCode(DELETE_RENT_UNIT_PERMISSION.code)
  @MessagePattern('delete_rent_unit_multiple')
  public async deleteMultipleRentUnit(
    @Body() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.rentUnitService.deleteMultiple(request);
  }

  @PermissionCode(CONFIRM_RENT_UNIT_PERMISSION.code)
  @MessagePattern('confirm_rent_unit')
  public async confirm(@Body() body: SetStatusRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.rentUnitService.confirm(request);
  }

  @PermissionCode(CONFIRM_RENT_UNIT_PERMISSION.code)
  @MessagePattern('confirm_rent_unit_multiple')
  public async confirmMultiple(@Body() body: DeleteMultipleDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.rentUnitService.confirmMultiple(request);
  }

  @PermissionCode(REJECT_RENT_UNIT_PERMISSION.code)
  @MessagePattern('reject_rent_unit')
  public async reject(@Body() body: SetStatusRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.rentUnitService.reject(request);
  }

  @PermissionCode(IMPORT_RENT_UNIT_PERMISSION.code)
  @MessagePattern('import_rent_unit')
  public async importFactory(@Body() body: FileUploadRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.rentUnitService.importRentUnit(request);
  }
}
