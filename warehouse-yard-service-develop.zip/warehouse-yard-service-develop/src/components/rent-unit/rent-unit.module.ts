import { RentUnitAttributeEntity } from '@entities/rent-unit/rent-unit-attribute.entity';
import { RentUnitEntity } from '@entities/rent-unit/rent-unit.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RentUnitController } from './rent-unit.controller';
import { RentUnitAttributeRepository } from '@repositories/rent-unit/rent-unit-attribute.repository';
import { RentUnitRepository } from '@repositories/rent-unit/rent-unit.repository';
import { RentUnitService } from './rent-unit.service';
import { RentUnitImport } from './import/rent-unit.import.helper';

@Module({
  imports: [
    TypeOrmModule.forFeature([RentUnitEntity, RentUnitAttributeEntity]),
  ],
  providers: [
    {
      provide: 'RentUnitServiceInterface',
      useClass: RentUnitService,
    },
    {
      provide: 'RentUnitRepositoryInterface',
      useClass: RentUnitRepository,
    },
    {
      provide: 'RentUnitAttributeRepositoryInterface',
      useClass: RentUnitAttributeRepository,
    },
    {
      provide: 'RentUnitImport',
      useClass: RentUnitImport,
    },
  ],
  exports: [
    {
      provide: 'RentUnitRepositoryInterface',
      useClass: RentUnitRepository,
    },
  ],
  controllers: [RentUnitController],
})
export class RentUnitModule {}
