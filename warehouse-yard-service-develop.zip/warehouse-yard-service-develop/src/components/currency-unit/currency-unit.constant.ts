export enum CurrencyUnitStatusEnum {
  CREATED = 0,
  CONFIRMED = 1,
  REJECT = 2,
}

export const CAN_UPDATE_CURRENCY_UNIT_STATUS: number[] = [
  CurrencyUnitStatusEnum.CREATED,
  CurrencyUnitStatusEnum.REJECT,
];

export const CAN_DELETE_CURRENCY_UNIT_STATUS: number[] = [
  CurrencyUnitStatusEnum.CREATED,
  CurrencyUnitStatusEnum.REJECT,
];

export const CAN_CONFIRM_CURRENCY_UNIT_STATUS: number[] = [
  CurrencyUnitStatusEnum.CREATED,
  CurrencyUnitStatusEnum.REJECT,
];

export const CAN_REJECT_CURRENCY_UNIT_STATUS: number[] = [
  CurrencyUnitStatusEnum.CREATED,
];
