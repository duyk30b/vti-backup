import { PermissionCode } from '@core/decorator/get-code.decorator';
import { Body, Controller, Inject, Req } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import {
  CONFIRM_CURRENCY_UNIT_PERMISSION,
  CREATE_CURRENCY_UNIT_PERMISSION,
  DELETE_CURRENCY_UNIT_PERMISSION,
  DETAIL_CURRENCY_UNIT_PERMISSION,
  LIST_CURRENCY_UNIT_PERMISSION,
  REJECT_CURRENCY_UNIT_PERMISSION,
  UPDATE_CURRENCY_UNIT_PERMISSION,
  IMPORT_CURRENCY_UNIT_PERMISSION,
} from '@utils/permissions/currency-unit';
import { isEmpty } from 'lodash';
import { CreateCurrencyUnitRequestDto } from './dto/request/create-currency-unit.request.dto';
import { DeleteCurrencyUnitDto } from './dto/request/delete-currency-unit.request.dto';
import { GetDetailCurrencyUnitRequestDto } from './dto/request/get-detail-currency-unit.request.dto';
import { GetListCurrencyUnitRequestDto } from './dto/request/get-list-currency-unit.request.dto';
import { SetStatusRequestDto } from './dto/request/set-status-request.dto';
import { UpdateCurrencyUnitRequestDto } from './dto/request/update-currency-unit.request.dto';
import { CurrencyUnitServiceInterface } from './interface/currency-unit.service.interface';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';

@Controller('currency-units')
export class CurrencyUnitController {
  constructor(
    @Inject('CurrencyUnitServiceInterface')
    private readonly currencyUnitService: CurrencyUnitServiceInterface,
  ) {}

  @PermissionCode(CREATE_CURRENCY_UNIT_PERMISSION.code)
  @MessagePattern('create_currency_unit')
  public async createCurrencyUnit(
    payload: CreateCurrencyUnitRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.currencyUnitService.create(request);
  }

  @PermissionCode(DETAIL_CURRENCY_UNIT_PERMISSION.code)
  @MessagePattern('get_currency_unit_detail')
  public async getCurrencyUnitDetail(
    @Body() payload: GetDetailCurrencyUnitRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.currencyUnitService.getDetail(request.id);
  }

  @PermissionCode(LIST_CURRENCY_UNIT_PERMISSION.code)
  @MessagePattern('get_list_currency_unit')
  public async getListCurrencyUnit(
    @Body() payload: GetListCurrencyUnitRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.currencyUnitService.getList(request);
  }

  @PermissionCode(UPDATE_CURRENCY_UNIT_PERMISSION.code)
  @MessagePattern('update_currency_unit')
  public async updateCurrencyUnit(
    @Body() payload: UpdateCurrencyUnitRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.currencyUnitService.update(request);
  }

  @PermissionCode(DELETE_CURRENCY_UNIT_PERMISSION.code)
  @MessagePattern('delete_currency_unit')
  public async deleteCurrencyUnit(
    @Body() payload: DeleteCurrencyUnitDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.currencyUnitService.delete(request);
  }

  @PermissionCode(DELETE_CURRENCY_UNIT_PERMISSION.code)
  @MessagePattern('delete_currency_unit_multiple')
  public async deleteMultipleCurrencyUnit(
    @Body() payload: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.currencyUnitService.deleteMultiple(request);
  }

  @PermissionCode(CONFIRM_CURRENCY_UNIT_PERMISSION.code)
  @MessagePattern('confirm_currency_unit')
  public async confirm(@Body() body: SetStatusRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.currencyUnitService.confirm(request);
  }

  @PermissionCode(CONFIRM_CURRENCY_UNIT_PERMISSION.code)
  @MessagePattern('confirm_currency_unit_multiple')
  public async confirmMultiple(@Body() body: DeleteMultipleDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.currencyUnitService.confirmMultiple(request);
  }

  @PermissionCode(REJECT_CURRENCY_UNIT_PERMISSION.code)
  @MessagePattern('reject_currency_unit')
  public async reject(@Body() body: SetStatusRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.currencyUnitService.reject(request);
  }

  @PermissionCode(IMPORT_CURRENCY_UNIT_PERMISSION.code)
  @MessagePattern('import_currency_unit')
  public async importFactory(@Body() body: FileUploadRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.currencyUnitService.importCurrencyUnit(request);
  }
}
