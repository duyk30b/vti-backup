import { CurrencyUnitRepository } from '@repositories/currency-unit/currency-unit.repository';
import { CurrencyUnitEntity } from '@entities/currency-unit/currency-unit.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CurrencyUnitController } from './currency-unit.controller';
import { CurrencyUnitService } from './currency-unit.service';
import { CurrencyUnitAttributeRepository } from '@repositories/currency-unit/currency-unit-attribute.repository';
import { CurrencyUnitAttributeEntity } from '@entities/currency-unit/currency-unit-attribute.entity';
import { CurrencyUnitImport } from './import/currency-unit.import.helper';

@Module({
  imports: [
    TypeOrmModule.forFeature([CurrencyUnitEntity, CurrencyUnitAttributeEntity]),
  ],
  providers: [
    {
      provide: 'CurrencyUnitServiceInterface',
      useClass: CurrencyUnitService,
    },
    {
      provide: 'CurrencyUnitRepositoryInterface',
      useClass: CurrencyUnitRepository,
    },
    {
      provide: 'CurrencyUnitAttributeRepositoryInterface',
      useClass: CurrencyUnitAttributeRepository,
    },
    {
      provide: 'CurrencyUnitImport',
      useClass: CurrencyUnitImport,
    },
  ],
  exports: [
    {
      provide: 'CurrencyUnitRepositoryInterface',
      useClass: CurrencyUnitRepository,
    },
  ],
  controllers: [CurrencyUnitController],
})
export class CurrencyUnitModule {}
