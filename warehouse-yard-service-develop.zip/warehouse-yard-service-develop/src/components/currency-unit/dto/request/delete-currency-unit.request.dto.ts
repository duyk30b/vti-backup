import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class DeleteCurrencyUnitDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'Mã id của đơn vị tiền tệ cần xóa' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
