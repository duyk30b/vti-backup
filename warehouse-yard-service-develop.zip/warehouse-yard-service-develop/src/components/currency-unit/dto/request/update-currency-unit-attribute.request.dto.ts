import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CreateCurrencyUnitAttributeRequestDto } from './create-currency-unit-attribute.request.dto';

export class UpdateCurrencyUnitAttributeRequestDto extends CreateCurrencyUnitAttributeRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;
}
