import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CreateCurrencyUnitRequestDto } from './create-currency-unit.request.dto';

export class UpdateCurrencyUnitRequestDto extends CreateCurrencyUnitRequestDto {
  @ApiProperty({ example: 1, description: 'Id của đơn vị tiền tệ cần update' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
