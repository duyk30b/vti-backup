import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CustomFieldRequest } from '@utils/custom-field.request.dto';

export class CreateCurrencyUnitAttributeRequestDto extends CustomFieldRequest {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  currencyUnitId: number;
}
