import { CurrencyUnitResponseDto } from './currency-unit.response.dto';
import { SuccessResponse } from '@components/currency-unit/dto/response/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { PagingResponse } from '@utils/paging.response';

export class DataList extends PagingResponse {
  @ApiProperty({ type: CurrencyUnitResponseDto, isArray: true })
  @Type(() => CurrencyUnitResponseDto)
  @Expose()
  @IsArray()
  items: CurrencyUnitResponseDto[];
}
export class GetListCurrencyUnitResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: DataList;
}
