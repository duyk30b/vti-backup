import { CurrencyUnitEntity } from '@entities/currency-unit/currency-unit.entity';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { GetListCurrencyUnitRequestDto } from '../dto/request/get-list-currency-unit.request.dto';

export interface CurrencyUnitRepositoryInterface
  extends BaseInterfaceRepository<CurrencyUnitEntity> {
  createEntity(data: any): CurrencyUnitEntity;
  updateEntity(entity: CurrencyUnitEntity, request: any): CurrencyUnitEntity;
  getList(request: GetListCurrencyUnitRequestDto): Promise<any>;
  getDetail(id: number);
}
