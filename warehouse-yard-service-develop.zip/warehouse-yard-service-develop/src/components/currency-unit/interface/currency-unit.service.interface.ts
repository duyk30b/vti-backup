import { ResponsePayload } from '@utils/response-payload';
import { CreateCurrencyUnitRequestDto } from '../dto/request/create-currency-unit.request.dto';
import { DeleteCurrencyUnitDto } from '../dto/request/delete-currency-unit.request.dto';
import { GetListCurrencyUnitRequestDto } from '../dto/request/get-list-currency-unit.request.dto';
import { SetStatusRequestDto } from '../dto/request/set-status-request.dto';
import { UpdateCurrencyUnitRequestDto } from '../dto/request/update-currency-unit.request.dto';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';

export interface CurrencyUnitServiceInterface {
  create(payload: CreateCurrencyUnitRequestDto): Promise<ResponsePayload<any>>;
  update(payload: UpdateCurrencyUnitRequestDto): Promise<ResponsePayload<any>>;
  getDetail(id: number): Promise<ResponsePayload<any>>;
  delete(id: DeleteCurrencyUnitDto): Promise<ResponsePayload<any>>;
  getList(
    payload: GetListCurrencyUnitRequestDto,
  ): Promise<ResponsePayload<any>>;
  confirm(request: SetStatusRequestDto): Promise<ResponsePayload<any>>;
  deleteMultiple(request: DeleteMultipleDto): Promise<ResponsePayload<any>>;
  confirmMultiple(request: DeleteMultipleDto): Promise<ResponsePayload<any>>;
  reject(request: SetStatusRequestDto): Promise<ResponsePayload<any>>;
  importCurrencyUnit(request: FileUploadRequestDto): Promise<any>;
}
