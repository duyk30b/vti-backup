import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { CurrencyUnitAttributeEntity } from '@entities/currency-unit/currency-unit-attribute.entity';

export interface CurrencyUnitAttributeRepositoryInterface
  extends BaseInterfaceRepository<CurrencyUnitAttributeEntity> {
  createEntity(data: any): CurrencyUnitAttributeEntity;
  updateEntity(request: any): CurrencyUnitAttributeEntity;
}
