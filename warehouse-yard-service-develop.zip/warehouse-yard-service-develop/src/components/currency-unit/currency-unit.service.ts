import { GetListCurrencyUnitRequestDto } from './dto/request/get-list-currency-unit.request.dto';
import { UpdateCurrencyUnitRequestDto } from './dto/request/update-currency-unit.request.dto';
import { CreateCurrencyUnitRequestDto } from '@components/currency-unit/dto/request/create-currency-unit.request.dto';
import { CurrencyUnitRepositoryInterface } from './interface/currency-unit.repository.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToClass } from 'class-transformer';
import { isEmpty } from 'class-validator';
import { isEmpty as isEmpty2 } from 'lodash';
import { I18nService } from 'nestjs-i18n';
import { Connection, In, Not } from 'typeorm';
import { CurrencyUnitServiceInterface } from './interface/currency-unit.service.interface';
import { DeleteCurrencyUnitDto } from './dto/request/delete-currency-unit.request.dto';
import { CurrencyUnitEntity } from '@entities/currency-unit/currency-unit.entity';
import { CurrencyUnitResponseDto } from './dto/response/currency-unit.response.dto';
import { SetStatusRequestDto } from './dto/request/set-status-request.dto';
import {
  CAN_CONFIRM_CURRENCY_UNIT_STATUS,
  CAN_DELETE_CURRENCY_UNIT_STATUS,
  CAN_REJECT_CURRENCY_UNIT_STATUS,
  CAN_UPDATE_CURRENCY_UNIT_STATUS,
  CurrencyUnitStatusEnum,
} from './currency-unit.constant';
import { CurrencyUnitAttributeRepositoryInterface } from './interface/currency-unit-attribute.repository.interface';
import { CreateCurrencyUnitAttributeRequestDto } from './dto/request/create-currency-unit-attribute.request.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { CurrencyUnitImport } from './import/currency-unit.import.helper';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { stringFormat } from '@utils/object.util';

@Injectable()
export class CurrencyUnitService implements CurrencyUnitServiceInterface {
  constructor(
    @Inject('CurrencyUnitRepositoryInterface')
    private readonly currencyUnitRepository: CurrencyUnitRepositoryInterface,

    @Inject('CurrencyUnitAttributeRepositoryInterface')
    private readonly currencyUnitAttributeRepository: CurrencyUnitAttributeRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('CurrencyUnitImport')
    private readonly currencyUnitImport: CurrencyUnitImport,

    @InjectConnection()
    private readonly connection: Connection,

    private readonly i18n: I18nService,
  ) {}

  public async create(
    request: CreateCurrencyUnitRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { customFields, code, name } = request;

    const currencyUnitCode = await this.currencyUnitRepository.findByCondition({
      code,
    });
    if (currencyUnitCode.length) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_EXIST'),
      ).toResponse();
    }

    const currencyUnitName = await this.currencyUnitRepository.findByCondition({
      name,
    });
    if (currencyUnitName.length) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.NAME_EXIST'),
      ).toResponse();
    }

    const newCurrencyUnitEntity =
      await this.currencyUnitRepository.createEntity(request);
    const queryRunner = this.connection.createQueryRunner();
    let currencyUnit;
    await queryRunner.startTransaction();

    try {
      currencyUnit = await queryRunner.manager.save(newCurrencyUnitEntity);
      const currencyUnitAttributeEntities = [];

      if (customFields.length > 0) {
        customFields.forEach((customField) => {
          const request = new CreateCurrencyUnitAttributeRequestDto();
          request.name = customField.name;
          request.currencyUnitId = currencyUnit.id;
          request.value = customField.value;

          currencyUnitAttributeEntities.push(
            this.currencyUnitAttributeRepository.createEntity(request),
          );
        });
      }

      const response = await queryRunner.manager.save(
        currencyUnitAttributeEntities,
      );
      currencyUnit.customFields = response.map((i) => ({
        name: i.name,
        value: i.value,
      }));

      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
    const responseData = plainToClass(CurrencyUnitResponseDto, currencyUnit, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(responseData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async update(
    request: UpdateCurrencyUnitRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { name, code, customFields, id } = request;
    const currencyUnit = await this.currencyUnitRepository.findOneById(id);
    if (!currencyUnit) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (!CAN_UPDATE_CURRENCY_UNIT_STATUS.includes(currencyUnit.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    }

    const currencyUnitCode = await this.currencyUnitRepository.findByCondition({
      code,
      id: Not(id),
    });

    if (request.code !== currencyUnit.code && currencyUnitCode.length > 0) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_EXIST'),
      ).toResponse();
    }

    const currencyUnitName = await this.currencyUnitRepository.findByCondition({
      name,
      id: Not(id),
    });
    if (currencyUnitName.length) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.NAME_EXIST'),
      ).toResponse();
    }

    const currencyUnitEntity = await this.currencyUnitRepository.updateEntity(
      currencyUnit,
      request,
    );

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    let result;
    try {
      result = await queryRunner.manager.save(currencyUnitEntity);
      const currencyUnitAttributes =
        await this.currencyUnitAttributeRepository.findWithRelations({
          where: {
            currencyUnitId: currencyUnitEntity.id,
          },
        });
      await queryRunner.manager.remove(currencyUnitAttributes);

      const attributesEntityList = [];
      if (customFields.length > 0) {
        customFields.forEach((customField) => {
          const request = new CreateCurrencyUnitAttributeRequestDto();
          request.name = customField.name;
          request.currencyUnitId = currencyUnit.id;
          request.value = customField.value;

          attributesEntityList.push(
            this.currencyUnitAttributeRepository.createEntity(request),
          );
        });

        const response = await queryRunner.manager.save(attributesEntityList);
        result.customFields = response.map((i) => ({
          name: i.name,
          value: i.value,
        }));
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error.message)
        .build();
    }

    await queryRunner.release();

    const response = plainToClass(CurrencyUnitResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  public async getList(
    request: GetListCurrencyUnitRequestDto,
  ): Promise<ResponsePayload<any> | any> {
    const { result, total } = await this.currencyUnitRepository.getList(
      request,
    );

    const dataReturn = plainToClass(CurrencyUnitResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getDetail(id: number): Promise<ResponsePayload<any>> {
    const currencyUnit = await this.currencyUnitRepository.getDetail(id);

    if (isEmpty(currencyUnit)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const users = await this.userService.getUserByIds(
      [currencyUnit.createdByUserId, currencyUnit.latestEditedUserId],
      true,
    );

    currencyUnit['createdByUser'] = users[currencyUnit.createdByUserId];
    currencyUnit['latestEditedUser'] = users[currencyUnit.latestEditedUserId];

    const response = plainToClass(CurrencyUnitResponseDto, currencyUnit, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async delete(
    request: DeleteCurrencyUnitDto,
  ): Promise<ResponsePayload<any>> {
    const currencyUnit = await this.currencyUnitRepository.findOneById(
      request.id,
    );
    if (!currencyUnit) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    if (!CAN_DELETE_CURRENCY_UNIT_STATUS.includes(currencyUnit.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate(
          'error.CAN_NOT_UPDATE_IN_CONFIRM_CURRENCY_UNIT',
        ),
      ).toResponse();
    }

    try {
      await this.currencyUnitRepository.remove(request.id);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Delete
   */
  public async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const currencyUnits = await this.currencyUnitRepository.findByCondition({
      id: In(ids),
    });

    const currencyUnitIds = currencyUnits.map(
      (currencyUnit) => currencyUnit.id,
    );
    if (currencyUnits.length !== ids.length) {
      ids.forEach((id) => {
        if (!currencyUnitIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < currencyUnits.length; i++) {
      const currencyUnit = currencyUnits[i];
      if (!CAN_DELETE_CURRENCY_UNIT_STATUS.includes(currencyUnit.status))
        failIdsList.push(currencyUnit.id);
    }

    const validIds = currencyUnits
      .filter((currencyUnit) => !failIdsList.includes(currencyUnit.id))
      .map((currencyUnit) => currencyUnit.id);

    try {
      if (!isEmpty2(validIds)) {
        this.currencyUnitRepository.multipleRemove(validIds);
      }
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    if (isEmpty2(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, userId } = request;
    const currencyUnit = await this.currencyUnitRepository.findOneById(id);

    if (!currencyUnit) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_CONFIRM_CURRENCY_UNIT_STATUS.includes(currencyUnit.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.CAN_NOT_CONFIRM_CURRENCY_UNIT'),
        )
        .build();
    }
    currencyUnit.status = CurrencyUnitStatusEnum.CONFIRMED;
    const result = await this.currencyUnitRepository.create(currencyUnit);
    const response = plainToClass(CurrencyUnitResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async confirmMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const currencyUnits = await this.currencyUnitRepository.findByCondition({
      id: In(ids),
    });

    const currencyUnitIds = currencyUnits.map(
      (currencyUnit) => currencyUnit.id,
    );
    if (currencyUnits.length !== ids.length) {
      ids.forEach((id) => {
        if (!currencyUnitIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < currencyUnits.length; i++) {
      const currencyUnit = currencyUnits[i];
      if (!CAN_CONFIRM_CURRENCY_UNIT_STATUS.includes(currencyUnit.status))
        failIdsList.push(currencyUnit.id);
    }

    const validIds = currencyUnits
      .filter((currencyUnit) => !failIdsList.includes(currencyUnit.id))
      .map((currencyUnit) => currencyUnit.id);

    const validCurrencyUnits = currencyUnits.filter((currencyUnit) =>
      validIds.includes(currencyUnit.id),
    );

    if (!isEmpty2(validCurrencyUnits)) {
      validCurrencyUnits.forEach((paymentType) => {
        paymentType.status = CurrencyUnitStatusEnum.CONFIRMED;
      });
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(CurrencyUnitEntity, validCurrencyUnits);
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty2(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.CONFIRM_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async reject(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, userId } = request;
    const currencyUnit = await this.currencyUnitRepository.findOneById(id);

    if (!currencyUnit) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_REJECT_CURRENCY_UNIT_STATUS.includes(currencyUnit.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.CAN_NOT_REJECT_CURRENCY_UNIT'),
        )
        .build();
    }

    currencyUnit.status = CurrencyUnitStatusEnum.REJECT;
    const result = await this.currencyUnitRepository.create(currencyUnit);
    const response = plainToClass(CurrencyUnitResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async importCurrencyUnit(request: FileUploadRequestDto): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
      userId: request.userId,
    } as ImportRequestDto;
    return this.currencyUnitImport.importUtil(importRequestDto);
  }
}
