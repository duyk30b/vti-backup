import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class VoucherListResponseDto {
  @ApiProperty({ example: 1, description: 'Voucher id' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'Voucher 1', description: 'Voucher name' })
  @Expose()
  name: string;

  @ApiProperty({ example: '22%', description: 'Voucher percentage' })
  @Expose()
  percentage: string;

  @ApiProperty({ example: '', description: 'dateFrom' })
  @Expose()
  dateFrom: string;

  @ApiProperty({ example: '', description: 'dateTo' })
  @Expose()
  dateTo: string;

  @ApiProperty({ example: 'Voucher code', description: 'Voucher id' })
  @Expose()
  code: string;

  @ApiProperty({ example: 0, description: 'Voucher name' })
  @Expose()
  status: number;
}
