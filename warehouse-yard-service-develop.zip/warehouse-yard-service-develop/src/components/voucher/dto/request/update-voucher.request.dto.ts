import { CreateVoucherRequestDto } from '@components/voucher/dto/request/create-voucher.request.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class UpdateVoucherRequestDto extends CreateVoucherRequestDto {
  @ApiProperty({ example: 1, description: 'Mã id' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
