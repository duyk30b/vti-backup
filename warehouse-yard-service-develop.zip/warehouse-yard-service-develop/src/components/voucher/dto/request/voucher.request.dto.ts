import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class VoucherDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'Mã id ' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
