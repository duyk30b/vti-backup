import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsString, MaxLength, IsInt } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';

export class CreateVoucherAttributeRequestDto extends BaseDto {
  @ApiProperty({
    example: 'custom1',
    description: 'Name',
  })
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiProperty({
    example: 'custom1 value',
    description: 'Value',
  })
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  value: string;

  @ApiPropertyOptional({
    example: 'Voucher',
    description: 'Voucher Id',
  })
  @IsNotEmpty()
  @IsInt()
  voucherId: number;
}
