import { CreateVoucherAttributeRequestDto } from '@components/voucher/dto/request/create-voucher-attribute.request.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class UpdateVoucherAttributeRequestDto extends CreateVoucherAttributeRequestDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  id: number;
}
