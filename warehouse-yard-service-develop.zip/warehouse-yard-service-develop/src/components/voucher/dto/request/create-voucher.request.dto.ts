import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { decimal } from '@utils/common';
import { CustomFieldRequest } from '@utils/custom-field.request.dto';
import {
  IsDateString,
  IsNotEmpty,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';

export class CreateVoucherRequestDto extends BaseDto {
  @ApiProperty({ example: 'C0021', description: 'Code' })
  @IsNotEmpty()
  @MaxLength(50)
  @IsString()
  code: string;

  @ApiProperty({ example: 'Khu vực A', description: 'Name' })
  @IsNotEmpty()
  @MaxLength(255)
  @IsString()
  name: string;

  @ApiProperty({ example: '%', description: '%' })
  @IsNotEmpty()
  @Min(0)
  @Max(decimal(5, 3))
  percentage: number;

  @ApiProperty({ example: '', description: 'date_from' })
  @IsNotEmpty()
  @IsDateString()
  dateFrom: Date;

  @ApiProperty({ example: '', description: 'date_to' })
  @IsNotEmpty()
  @IsDateString()
  dateTo: Date;

  @ApiProperty({ example: '', description: 'Description' })
  @IsOptional()
  @MaxLength(255)
  @IsString()
  description: string;

  @ApiProperty({ type: CustomFieldRequest, isArray: true })
  @ValidateNested()
  @IsOptional()
  customFields: CustomFieldRequest[];
}
