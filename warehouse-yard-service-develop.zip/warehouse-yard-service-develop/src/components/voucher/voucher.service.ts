import { CreateVoucherAttributeRequestDto } from '@components/voucher/dto/request/create-voucher-attribute.request.dto';
import { CreateVoucherRequestDto } from '@components/voucher/dto/request/create-voucher.request.dto';
import { GetListVoucherRequestDto } from '@components/voucher/dto/request/list-voucher.request.dto';
import { UpdateVoucherRequestDto } from '@components/voucher/dto/request/update-voucher.request.dto';
import { VoucherListResponseDto } from '@components/voucher/dto/response/list-voucher.response.dto';
import { VoucherResponseDto } from '@components/voucher/dto/response/voucher.response.dto';
import { VoucherAttributesRepositoryInterface } from '@components/voucher/interface/voucher-attribute.repository.interface';
import { VoucherRepositoryInterface } from '@components/voucher/interface/voucher.repository.interface';
import { VoucherServiceInterface } from '@components/voucher/interface/voucher.service.interface';
import {
  CAN_CONFIRM_VOUCHER_STATUS,
  CAN_DELETE_VOUCHER_STATUS,
  CAN_REJECT_VOUCHER_STATUS,
  CAN_UPDATE_VOUCHER_STATUS,
  VoucherStatusEnum,
} from '@components/voucher/voucher.constant';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { SetStatusDto } from '@utils/set-status.dto';
import { plainToClass } from 'class-transformer';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { Connection, Not, In } from 'typeorm';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { VoucherImport } from './import/voucher.import.helper';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { stringFormat } from '@utils/object.util';
import { isEmpty } from 'lodash';
import { VoucherEntity } from '@entities/voucher/voucher.entity';

@Injectable()
export class VoucherService implements VoucherServiceInterface {
  constructor(
    @Inject('VoucherRepositoryInterface')
    private readonly voucherRepository: VoucherRepositoryInterface,
    @Inject('VoucherAttributesRepositoryInterface')
    private readonly voucherAttributesRepository: VoucherAttributesRepositoryInterface,
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,
    @Inject('VoucherImport')
    private readonly voucherImport: VoucherImport,
    @InjectConnection()
    private readonly connection: Connection,
    private readonly i18n: I18nRequestScopeService,
  ) {}

  async confirm(request: SetStatusDto): Promise<ResponsePayload<any>> {
    const { id } = request;
    const voucher = await this.voucherRepository.findOneById(id);
    if (!voucher) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.VOUCHER_NOT_FOUND'))
        .build();
    }

    if (!CAN_CONFIRM_VOUCHER_STATUS.includes(voucher.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_INVALID'),
      ).toResponse();
    }
    voucher.status = VoucherStatusEnum.CONFIRMED;

    try {
      const result = await this.voucherRepository.update(voucher);
      const response = plainToClass(VoucherResponseDto, result, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(response)
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withData(err)
        .build();
    }
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async confirmMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const vouchers = await this.voucherRepository.findByCondition({
      id: In(ids),
    });

    const voucherIds = vouchers.map((voucher) => voucher.id);
    if (vouchers.length !== ids.length) {
      ids.forEach((id) => {
        if (!voucherIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < vouchers.length; i++) {
      const voucher = vouchers[i];
      if (!CAN_CONFIRM_VOUCHER_STATUS.includes(voucher.status))
        failIdsList.push(voucher.id);
    }

    const validIds = vouchers
      .filter((voucher) => !failIdsList.includes(voucher.id))
      .map((voucher) => voucher.id);

    const validateVouchers = vouchers.filter((voucher) =>
      validIds.includes(voucher.id),
    );

    if (!isEmpty(validateVouchers)) {
      validateVouchers.forEach((serviceType) => {
        serviceType.status = VoucherStatusEnum.CONFIRMED;
      });
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(VoucherEntity, validateVouchers);
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.CONFIRM_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  async createVoucher(
    payload: CreateVoucherRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { code, name, customFields } = payload;
    const checkExistCode = await this.checkUniqueCode(code);
    const checkExistName = await this.checkUniqueName(name);

    if (checkExistCode) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_IS_ALREADY_EXISTS'))
        .build();
    }

    if (checkExistName)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NAME_ALREADY_EXISTS'))
        .build();

    const voucherEntity = this.voucherRepository.createEntity(payload);
    let result;

    const queryRunner = this.connection.createQueryRunner();

    await queryRunner.startTransaction();
    // create voucher attributes
    try {
      result = await queryRunner.manager.save(voucherEntity);

      if (customFields?.length > 0) {
        const attributesEntityList = [];
        customFields.forEach((i) => {
          const attributeRequest = new CreateVoucherAttributeRequestDto();
          attributeRequest.name = i.name;
          attributeRequest.value = i.value;
          attributeRequest.voucherId = voucherEntity.id;

          const attributeEntity =
            this.voucherAttributesRepository.createEntity(attributeRequest);
          attributesEntityList.push(attributeEntity);
        });

        const response = await queryRunner.manager.save(attributesEntityList);
        result.customFields = response.map((i) => ({
          name: i.name,
          value: i.value,
        }));
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error.message)
        .build();
    }
    await queryRunner.release();

    const response = plainToClass(VoucherResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  async updateVoucher(
    payload: UpdateVoucherRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, code, name, customFields } = payload;
    const voucher = await this.voucherRepository.findOneById(id);

    if (!voucher) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.VOUCHER_NOT_FOUND'))
        .build();
    }

    const checkExistCode = await this.checkUniqueCode(code, id);
    const checkExistName = await this.checkUniqueName(name, id);

    if (checkExistCode) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_IS_ALREADY_EXISTS'))
        .build();
    }

    if (checkExistName)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NAME_ALREADY_EXISTS'))
        .build();

    if (!CAN_UPDATE_VOUCHER_STATUS.includes(voucher.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.VOUCHER_WAS_CONFIRMED'),
      ).toResponse();
    }

    const voucherEntity = this.voucherRepository.updateEntity(id, payload);
    let result;

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    // update voucher attributes
    try {
      result = await queryRunner.manager.save(voucherEntity);

      const voucherAttributes =
        await this.voucherAttributesRepository.findWithRelations({
          where: {
            voucherId: voucherEntity.id,
          },
        });
      await queryRunner.manager.remove(voucherAttributes);

      if (customFields?.length > 0) {
        const attributesEntityList = [];
        customFields.forEach((i) => {
          const attributeRequest = new CreateVoucherAttributeRequestDto();
          attributeRequest.name = i.name;
          attributeRequest.value = i.value;
          attributeRequest.voucherId = voucherEntity.id;

          const attributeEntity =
            this.voucherAttributesRepository.createEntity(attributeRequest);
          attributesEntityList.push(attributeEntity);
        });

        const response = await queryRunner.manager.save(attributesEntityList);
        result.customFields = response.map(({ name, value }) => ({
          name,
          value,
        }));

        await queryRunner.commitTransaction();
      }
    } catch (error) {
      await queryRunner.rollbackTransaction();
      console.log(error.message);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error.message)
        .build();
    }
    await queryRunner.release();

    const response = plainToClass(VoucherResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  async delete(id: number): Promise<ResponsePayload<any>> {
    try {
      const voucher = await this.voucherRepository.findOneById(id);
      if (!voucher) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.VOUCHER_NOT_FOUND'))
          .build();
      }

      if (!CAN_DELETE_VOUCHER_STATUS.includes(voucher.status)) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.VOUCHER_WAS_CONFIRMED'),
        ).toResponse();
      }

      await this.voucherRepository.remove(voucher.id);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Delete
   */
  public async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const vouchers = await this.voucherRepository.findByCondition({
      id: In(ids),
    });

    const voucherIds = vouchers.map((voucher) => voucher.id);
    if (vouchers.length !== ids.length) {
      ids.forEach((id) => {
        if (!voucherIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < vouchers.length; i++) {
      const voucher = vouchers[i];
      if (!CAN_DELETE_VOUCHER_STATUS.includes(voucher.status))
        failIdsList.push(voucher.id);
    }

    const validIds = vouchers
      .filter((voucher) => !failIdsList.includes(voucher.id))
      .map((voucher) => voucher.id);

    try {
      if (!isEmpty(validIds)) {
        this.voucherRepository.multipleRemove(validIds);
      }
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  async detail(id: number): Promise<ResponsePayload<any>> {
    const voucher = await this.voucherRepository.detail(id);

    if (!voucher) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.VOUCHER_NOT_FOUND'))
        .build();
    }

    const users = await this.userService.getUserByIds(
      [voucher.createdByUserId, voucher.latestEditedUserId],
      true,
    );

    voucher['createdByUser'] = users[voucher.createdByUserId];
    voucher['latestEditedUser'] = users[voucher.latestEditedUserId];

    const response = plainToClass(VoucherResponseDto, voucher, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }

  async getList(
    payload: GetListVoucherRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { result, count } = await this.voucherRepository.getList(payload);
    const response = plainToClass(VoucherListResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: payload.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async reject(request: SetStatusDto): Promise<ResponsePayload<any>> {
    const { id } = request;
    const voucher = await this.voucherRepository.findOneById(id);
    if (!voucher) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.VOUCHER_NOT_FOUND'))
        .build();
    }

    if (!CAN_REJECT_VOUCHER_STATUS.includes(voucher.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_INVALID'),
      ).toResponse();
    }
    voucher.status = VoucherStatusEnum.DISABLED;

    const result = await this.voucherRepository.update(voucher);
    const response = plainToClass(VoucherResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }

  private async checkUniqueCode(code: string, id?: number): Promise<boolean> {
    const result = await this.voucherRepository.findByCondition([{ code }]);
    let data = [];
    if (id) {
      data = result.filter((item) => item.id !== id);
      return data.length > 0;
    }
    return result.length > 0;
  }

  private async checkUniqueName(name: string, id?: number): Promise<boolean> {
    const condition = {
      name: name,
      id: Not(id),
    };
    if (!id) delete condition.id;
    const result = await this.voucherRepository.findOneByCondition(condition);

    return !!result;
  }

  public async importVoucher(request: FileUploadRequestDto): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
      userId: request.userId,
    } as ImportRequestDto;
    return this.voucherImport.importUtil(importRequestDto);
  }
}
