import { CreateVoucherRequestDto } from '@components/voucher/dto/request/create-voucher.request.dto';
import { GetListVoucherRequestDto } from '@components/voucher/dto/request/list-voucher.request.dto';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { VoucherEntity } from '@entities/voucher/voucher.entity';
import { SetStatusDto } from '@utils/set-status.dto';

export interface VoucherRepositoryInterface
  extends BaseInterfaceRepository<VoucherEntity> {
  getList(payload: GetListVoucherRequestDto): Promise<any>;
  updateEntity(id: number, request: CreateVoucherRequestDto): VoucherEntity;
  createEntity(payload: CreateVoucherRequestDto): VoucherEntity;
  detail(id: number): Promise<any>;
  confirm(payload: SetStatusDto): Promise<any>;
  reject(payload: SetStatusDto): Promise<any>;
}
