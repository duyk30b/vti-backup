import { CreateVoucherRequestDto } from '@components/voucher/dto/request/create-voucher.request.dto';
import { GetListVoucherRequestDto } from '@components/voucher/dto/request/list-voucher.request.dto';
import { UpdateVoucherRequestDto } from '@components/voucher/dto/request/update-voucher.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { SetStatusDto } from '@utils/set-status.dto';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
export interface VoucherServiceInterface {
  getList(payload: GetListVoucherRequestDto): Promise<ResponsePayload<any>>;
  createVoucher(
    payload: CreateVoucherRequestDto,
  ): Promise<ResponsePayload<any>>;
  updateVoucher(
    payload: UpdateVoucherRequestDto,
  ): Promise<ResponsePayload<any>>;
  detail(id: number): Promise<ResponsePayload<any>>;
  confirm(request: SetStatusDto): Promise<ResponsePayload<any>>;
  reject(request: SetStatusDto): Promise<ResponsePayload<any>>;
  delete(id: number): Promise<ResponsePayload<any>>;
  confirmMultiple(request: DeleteMultipleDto): Promise<ResponsePayload<any>>;
  deleteMultiple(request: DeleteMultipleDto): Promise<ResponsePayload<any>>;
  importVoucher(request: FileUploadRequestDto): Promise<any>;
}
