import { CreateVoucherAttributeRequestDto } from '@components/voucher/dto/request/create-voucher-attribute.request.dto';
import { UpdateVoucherAttributeRequestDto } from '@components/voucher/dto/request/update-voucher-attribute.request.dto';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { VoucherAttributeEntity } from '@entities/voucher/voucher-attribute.entity';

export interface VoucherAttributesRepositoryInterface
  extends BaseInterfaceRepository<VoucherAttributeEntity> {
  createEntity(request: CreateVoucherAttributeRequestDto);
  updateEntity(request: UpdateVoucherAttributeRequestDto);
}
