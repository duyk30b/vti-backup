import { VoucherController } from '@components/voucher/voucher.controller';
import { VoucherAttributeEntity } from '@entities/voucher/voucher-attribute.entity';
import { VoucherEntity } from '@entities/voucher/voucher.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { VoucherService } from '@components/voucher/voucher.service';
import { VoucherAttributesRepository } from '@repositories/voucher-attribute.repository';
import { VoucherRepository } from '@repositories/voucher.repository';
import { VoucherImport } from './import/voucher.import.helper';

@Module({
  imports: [TypeOrmModule.forFeature([VoucherEntity, VoucherAttributeEntity])],
  providers: [
    {
      provide: 'VoucherServiceInterface',
      useClass: VoucherService,
    },
    {
      provide: 'VoucherRepositoryInterface',
      useClass: VoucherRepository,
    },
    {
      provide: 'VoucherAttributesRepositoryInterface',
      useClass: VoucherAttributesRepository,
    },
    {
      provide: 'VoucherImport',
      useClass: VoucherImport,
    },
  ],
  controllers: [VoucherController],
})
export class VoucherModule {}
