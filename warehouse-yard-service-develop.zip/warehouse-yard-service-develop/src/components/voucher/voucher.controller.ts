import { PaymentTypeResponseDto } from '@components/payment-type/dto/response/payment-type.response.dto';
import { CreateVoucherRequestDto } from '@components/voucher/dto/request/create-voucher.request.dto';
import { GetListVoucherRequestDto } from '@components/voucher/dto/request/list-voucher.request.dto';
import { VoucherDto } from '@components/voucher/dto/request/voucher.request.dto';
import { VoucherListResponseDto } from '@components/voucher/dto/response/list-voucher.response.dto';
import { VoucherResponseDto } from '@components/voucher/dto/response/voucher.response.dto';
import { VoucherServiceInterface } from '@components/voucher/interface/voucher.service.interface';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Post,
  Put,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiResponse } from '@nestjs/swagger';
import { SetStatusDto } from '@utils/set-status.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import {
  CREATE_VOUCHER_PERMISSION,
  UPDATE_VOUCHER_PERMISSION,
  DELETE_VOUCHER_PERMISSION,
  DETAIL_VOUCHER_PERMISSION,
  LIST_VOUCHER_PERMISSION,
  CONFIRM_VOUCHER_PERMISSION,
  REJECT_VOUCHER_PERMISSION,
  IMPORT_VOUCHER_PERMISSION,
} from '@utils/permissions/voucher';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';

@Controller('vouchers')
export class VoucherController {
  constructor(
    @Inject('VoucherServiceInterface')
    private readonly voucherService: VoucherServiceInterface,
  ) {}

  @Get('/vouchers/list')
  @ApiResponse({
    status: 200,
    description: 'Get List',
    type: VoucherListResponseDto,
  })
  @PermissionCode(LIST_VOUCHER_PERMISSION.code)
  @MessagePattern('get_list_voucher')
  public async getList(@Body() body: GetListVoucherRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.voucherService.getList(request);
  }

  @Post('/vouchers/create')
  @ApiResponse({
    status: 200,
    description: 'Create Success',
    type: VoucherResponseDto,
  })
  @PermissionCode(CREATE_VOUCHER_PERMISSION.code)
  @MessagePattern('create_voucher')
  public async create(@Body() body: CreateVoucherRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.voucherService.createVoucher(request);
  }

  @Put('/vouchers/:id')
  @ApiResponse({
    status: 200,
    description: 'Update Success',
    type: VoucherResponseDto,
  })
  @PermissionCode(UPDATE_VOUCHER_PERMISSION.code)
  @MessagePattern('update_voucher')
  public async update(@Body() body: CreateVoucherRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.voucherService.updateVoucher(request);
  }

  @Get('/vouchers/:id')
  @ApiResponse({
    status: 200,
    description: 'Detail Success',
    type: VoucherResponseDto,
  })
  @PermissionCode(DETAIL_VOUCHER_PERMISSION.code)
  @MessagePattern('get_voucher')
  public async detail(@Body() body: VoucherDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.voucherService.detail(request.id);
  }

  @Delete('/vouchers/:id')
  @ApiResponse({
    status: 200,
    description: 'Delete Success',
    type: SuccessResponse,
  })
  @PermissionCode(DELETE_VOUCHER_PERMISSION.code)
  @MessagePattern('delete_voucher')
  public async delete(@Body() body: VoucherDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.voucherService.delete(request.id);
  }

  @PermissionCode(DELETE_VOUCHER_PERMISSION.code)
  @MessagePattern('delete_voucher_multiple')
  public async deleteMultiple(@Body() body: DeleteMultipleDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.voucherService.deleteMultiple(request);
  }

  @Put('/vouchers/:id/confirm')
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: VoucherResponseDto,
  })
  @PermissionCode(CONFIRM_VOUCHER_PERMISSION.code)
  @MessagePattern('confirm_voucher')
  public async confirm(@Body() body: SetStatusDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.voucherService.confirm(request);
  }

  @PermissionCode(CONFIRM_VOUCHER_PERMISSION.code)
  @MessagePattern('confirm_voucher_multiple')
  public async confirmMultiple(@Body() body: DeleteMultipleDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.voucherService.confirmMultiple(request);
  }

  @Put('/vouchers/:id/reject')
  @ApiResponse({
    status: 200,
    description: 'Disable successfully',
    type: VoucherResponseDto,
  })
  @PermissionCode(REJECT_VOUCHER_PERMISSION.code)
  @MessagePattern('reject_voucher')
  public async reject(@Body() body: SetStatusDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.voucherService.reject(request);
  }

  @PermissionCode(IMPORT_VOUCHER_PERMISSION.code)
  @MessagePattern('import_voucher')
  public async importFactory(@Body() body: FileUploadRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.voucherService.importVoucher(request);
  }
}
