export enum VoucherStatusEnum {
  PENDING,
  CONFIRMED,
  DISABLED,
}

export const CAN_UPDATE_VOUCHER_STATUS: number[] = [
  VoucherStatusEnum.PENDING,
  VoucherStatusEnum.DISABLED,
];

export const CAN_DELETE_VOUCHER_STATUS: number[] = [
  VoucherStatusEnum.PENDING,
  VoucherStatusEnum.DISABLED,
];

export const CAN_CONFIRM_VOUCHER_STATUS: number[] = [
  VoucherStatusEnum.PENDING,
  VoucherStatusEnum.DISABLED,
];

export const CAN_REJECT_VOUCHER_STATUS: number[] = [VoucherStatusEnum.PENDING];
