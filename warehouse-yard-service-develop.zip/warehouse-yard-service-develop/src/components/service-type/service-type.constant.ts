export enum ServiceTypeStatusEnum {
  PENDING = 0,
  CONFIRMED = 1,
  DISABLED = 2,
}

export const CAN_UPDATE_PAYMENT_TYPE_STATUS: number[] = [
  ServiceTypeStatusEnum.PENDING,
  ServiceTypeStatusEnum.DISABLED,
];

export const CAN_DELETE_PAYMENT_TYPE_STATUS: number[] = [
  ServiceTypeStatusEnum.PENDING,
  ServiceTypeStatusEnum.DISABLED,
];

export const CAN_CONFIRM_PAYMENT_TYPE_STATUS: number[] = [
  ServiceTypeStatusEnum.PENDING,
  ServiceTypeStatusEnum.DISABLED,
];
