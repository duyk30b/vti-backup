import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class ServiceTypeListResponseDto {
  @ApiProperty({ example: 1, description: 'service type id' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'service type 1', description: 'service type name' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'service type code', description: 'service type id' })
  @Expose()
  code: string;

  @ApiProperty({ example: 0, description: 'service type name' })
  @Expose()
  status: number;
}
