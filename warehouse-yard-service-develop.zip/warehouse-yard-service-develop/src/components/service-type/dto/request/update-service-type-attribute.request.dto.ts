import { CreateServiceTypeAttributeRequestDto } from './create-service-type-attribute.request.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class UpdateServiceTypeAttributeRequestDto extends CreateServiceTypeAttributeRequestDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  id: number;
}
