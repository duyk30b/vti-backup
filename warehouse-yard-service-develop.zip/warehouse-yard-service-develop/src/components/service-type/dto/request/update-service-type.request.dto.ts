import { CreateServiceTypeRequestDto } from './create-service-type.request.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class UpdateServiceTypeRequestDto extends CreateServiceTypeRequestDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  id: number;
}
