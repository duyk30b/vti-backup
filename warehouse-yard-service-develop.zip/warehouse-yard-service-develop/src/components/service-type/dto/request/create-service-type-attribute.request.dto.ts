import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsInt } from 'class-validator';
import { CustomFieldRequest } from '@utils/custom-field.request.dto';

export class CreateServiceTypeAttributeRequestDto extends CustomFieldRequest {
  @ApiPropertyOptional({
    example: 'Service type id',
    description: 'Service type',
  })
  @IsNotEmpty()
  @IsInt()
  serviceTypeId: number;
}
