import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { CustomFieldRequest } from '@utils/custom-field.request.dto';

export class CreateServiceTypeRequestDto extends BaseDto {
  @ApiProperty({ example: '1234', description: 'Mã của service type' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(50)
  code: string;

  @ApiProperty({
    example: 'service type name',
    description: 'Ten cua service type',
  })
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiPropertyOptional({
    example: 'description service type',
    description: 'Mo ta cho service type',
  })
  @IsString()
  @IsOptional()
  @MaxLength(255)
  description: string;

  @ApiProperty({ type: CustomFieldRequest, isArray: true })
  @ValidateNested()
  @IsOptional()
  customFields: CustomFieldRequest[];
}
