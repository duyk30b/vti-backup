import { Inject, Injectable, Logger } from '@nestjs/common';
import { ServiceTypeServiceInterface } from './interface/service-type.service.interface';
import { ResponsePayload } from '@utils/response-payload';
import { CreateServiceTypeRequestDto } from './dto/request/create-service-type.request.dto';
import { UpdateServiceTypeRequestDto } from './dto/request/update-service-type.request.dto';
import { GetServiceTypeListRequestDto } from './dto/request/search-service-type.request.dto';
import { SetStatusRequestDto } from '@utils/common.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { ServiceTypeResponseDto } from './dto/response/service-type.response.dto';
import { ServiceTypeListResponseDto } from './dto/response/service-type-list.response.dto';
import { ServiceTypeRepoInterface } from './interface/service-type.repository.interface';
import { ServiceTypeAttributesRepositoryInterface } from './interface/service-type-attribute.repository.interface';
import { CreateServiceTypeAttributeRequestDto } from './dto/request/create-service-type-attribute.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { I18nService } from 'nestjs-i18n';
import { plainToClass } from 'class-transformer';
import {
  CAN_UPDATE_PAYMENT_TYPE_STATUS,
  CAN_DELETE_PAYMENT_TYPE_STATUS,
  CAN_CONFIRM_PAYMENT_TYPE_STATUS,
  ServiceTypeStatusEnum,
} from './service-type.constant';
import { ApiError } from '@utils/api.error';
import { PagingResponse } from '@utils/paging.response';
import { InjectConnection } from '@nestjs/typeorm';
import { Connection, Not, In } from 'typeorm';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ServiceTypeImport } from './import/service-type.import.helper';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { stringFormat } from '@utils/object.util';
import { isEmpty } from 'lodash';
import { ServiceTypeEntity } from '@entities/service-type/service-type.entity';

@Injectable()
export class ServiceTypeService implements ServiceTypeServiceInterface {
  private readonly logger = new Logger(ServiceTypeService.name);
  constructor(
    @Inject('ServiceTypeRepoInterface')
    private readonly serviceTypeRepository: ServiceTypeRepoInterface,
    @Inject('ServiceTypeAttributesRepositoryInterface')
    private readonly serviceTypeAttributeRepository: ServiceTypeAttributesRepositoryInterface,
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,
    @Inject('ServiceTypeImport')
    private readonly serviceTypeImport: ServiceTypeImport,
    @InjectConnection()
    private readonly connection: Connection,
    private readonly i18n: I18nService,
  ) {}

  public async createServiceType(
    payload: CreateServiceTypeRequestDto,
  ): Promise<ResponsePayload<ServiceTypeResponseDto | any>> {
    const { code, name, customFields } = payload;
    const checkExistCode = await this.checkUniqueCode(code);
    const checkExistName = await this.checkUniqueName(name);

    if (checkExistCode) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_IS_ALREADY_EXISTS'))
        .build();
    }

    if (checkExistName)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NAME_ALREADY_EXISTS'))
        .build();

    const serviceTypeEntity = this.serviceTypeRepository.createEntity(payload);
    let result;

    const queryRunner = this.connection.createQueryRunner();
    queryRunner.startTransaction();
    // create service type attributes
    try {
      result = await queryRunner.manager.save(serviceTypeEntity);

      if (customFields.length > 0) {
        const attributesEntityList = [];
        customFields.forEach((i) => {
          const attributeRequest = new CreateServiceTypeAttributeRequestDto();
          attributeRequest.name = i.name;
          attributeRequest.value = i.value;
          attributeRequest.serviceTypeId = serviceTypeEntity.id;

          const attributeEntity =
            this.serviceTypeAttributeRepository.createEntity(attributeRequest);
          attributesEntityList.push(attributeEntity);
        });

        const response = await queryRunner.manager.save(attributesEntityList);
        result.customFields = response.map((i) => ({
          name: i.name,
          value: i.value,
        }));
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error.message)
        .build();
    }
    await queryRunner.release();

    const response = plainToClass(ServiceTypeResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  public async updateServiceType(
    payload: UpdateServiceTypeRequestDto,
  ): Promise<ResponsePayload<ServiceTypeResponseDto | any>> {
    const { id, code, name, customFields } = payload;
    const serviceType = await this.serviceTypeRepository.findOneById(id);

    if (!serviceType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PAYMENT_TYPE_NOT_FOUND'))
        .build();
    }

    const checkExistCode = await this.checkUniqueCode(code, id);
    const checkExistName = await this.checkUniqueName(name, id);

    if (checkExistCode) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_IS_ALREADY_EXISTS'))
        .build();
    }

    if (checkExistName)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NAME_ALREADY_EXISTS'))
        .build();

    if (!CAN_UPDATE_PAYMENT_TYPE_STATUS.includes(serviceType.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.PAYMENT_TYPE_WAS_CONFIRMED'),
      ).toResponse();
    }

    const serviceTypeEntity = this.serviceTypeRepository.updateEntity(
      id,
      payload,
    );
    let result;

    const queryRunner = this.connection.createQueryRunner();
    queryRunner.startTransaction();
    // update service type attributes
    try {
      result = await queryRunner.manager.save(serviceTypeEntity);

      const serviceTypeAttributes =
        await this.serviceTypeAttributeRepository.findWithRelations({
          where: {
            serviceTypeId: serviceTypeEntity.id,
          },
        });
      await queryRunner.manager.remove(serviceTypeAttributes);

      if (customFields.length > 0) {
        const attributesEntityList = [];
        customFields.forEach((i) => {
          const attributeRequest = new CreateServiceTypeAttributeRequestDto();
          attributeRequest.name = i.name;
          attributeRequest.value = i.value;
          attributeRequest.serviceTypeId = serviceTypeEntity.id;

          const attributeEntity =
            this.serviceTypeAttributeRepository.createEntity(attributeRequest);
          attributesEntityList.push(attributeEntity);
        });

        const response = await queryRunner.manager.save(attributesEntityList);
        result.customFields = response.map((i) => ({
          name: i.name,
          value: i.value,
        }));

        await queryRunner.commitTransaction();
      }
    } catch (error) {
      await queryRunner.rollbackTransaction();
      console.log(error.message);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error.message)
        .build();
    }
    await queryRunner.release();

    const response = plainToClass(ServiceTypeResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  public async deleteServiceType(
    id: number,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const serviceType = await this.serviceTypeRepository.findOneById(id);
    if (!serviceType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PAYMENT_TYPE_NOT_FOUND'))
        .build();
    }

    if (!CAN_DELETE_PAYMENT_TYPE_STATUS.includes(serviceType.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.PAYMENT_TYPE_WAS_CONFIRMED'),
      ).toResponse();
    }

    try {
      await this.serviceTypeRepository.delete(id);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Delete
   */
  public async deleteMultipleServiceType(
    request: DeleteMultipleDto,
  ): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const serviceTypes = await this.serviceTypeRepository.findByCondition({
      id: In(ids),
    });

    const serviceTypeIds = serviceTypes.map((serviceType) => serviceType.id);
    if (serviceTypes.length !== ids.length) {
      ids.forEach((id) => {
        if (!serviceTypeIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < serviceTypes.length; i++) {
      const serviceType = serviceTypes[i];
      if (!CAN_DELETE_PAYMENT_TYPE_STATUS.includes(serviceType.status))
        failIdsList.push(serviceType.id);
    }

    const validIds = serviceTypes
      .filter((serviceType) => !failIdsList.includes(serviceType.id))
      .map((serviceType) => serviceType.id);

    try {
      if (!isEmpty(validIds)) {
        this.serviceTypeRepository.multipleRemove(validIds);
      }
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async detailServiceType(
    id: number,
  ): Promise<ResponsePayload<ServiceTypeResponseDto | any>> {
    const serviceType = await this.serviceTypeRepository.getDetail(id);

    if (!serviceType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PAYMENT_TYPE_NOT_FOUND'))
        .build();
    }

    const users = await this.userService.getUserByIds(
      [serviceType.createdByUserId, serviceType.latestEditedUserId],
      true,
    );

    serviceType['createdByUser'] = users[serviceType.createdByUserId];
    serviceType['latestEditedUser'] = users[serviceType.latestEditedUserId];

    const response = plainToClass(ServiceTypeResponseDto, serviceType, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }

  public async getListServiceType(
    payload: GetServiceTypeListRequestDto,
  ): Promise<ResponsePayload<ServiceTypeListResponseDto | any>> {
    const { result, count } = await this.serviceTypeRepository.getList(payload);

    const response = plainToClass(ServiceTypeListResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: payload.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async confirmServiceType(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<ServiceTypeResponseDto | any>> {
    const { id } = request;
    const serviceType = await this.serviceTypeRepository.findOneById(id);
    if (!serviceType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PAYMENT_TYPE_NOT_FOUND'))
        .build();
    }

    if (!CAN_CONFIRM_PAYMENT_TYPE_STATUS.includes(serviceType.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_INVALID'),
      ).toResponse();
    }
    serviceType.status = ServiceTypeStatusEnum.CONFIRMED;
    serviceType.updatedAt = new Date(Date.now());

    const result = await this.serviceTypeRepository.update(serviceType);
    const response = plainToClass(ServiceTypeResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async confirmMultipleServiceType(
    request: DeleteMultipleDto,
  ): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const serviceTypes = await this.serviceTypeRepository.findByCondition({
      id: In(ids),
    });

    const serviceTypeIds = serviceTypes.map((serviceType) => serviceType.id);
    if (serviceTypes.length !== ids.length) {
      ids.forEach((id) => {
        if (!serviceTypeIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < serviceTypes.length; i++) {
      const serviceType = serviceTypes[i];
      if (!CAN_CONFIRM_PAYMENT_TYPE_STATUS.includes(serviceType.status))
        failIdsList.push(serviceType.id);
    }

    const validIds = serviceTypes
      .filter((serviceType) => !failIdsList.includes(serviceType.id))
      .map((serviceType) => serviceType.id);

    const validateServiceTypes = serviceTypes.filter((serviceType) =>
      validIds.includes(serviceType.id),
    );

    if (!isEmpty(validateServiceTypes)) {
      validateServiceTypes.forEach((serviceType) => {
        serviceType.status = ServiceTypeStatusEnum.CONFIRMED;
      });
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(ServiceTypeEntity, validateServiceTypes);
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.CONFIRM_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  private async checkUniqueCode(code: string, id?: number): Promise<boolean> {
    const result = await this.serviceTypeRepository.findByCondition([
      { code: code },
    ]);
    let data = [];
    if (id) {
      data = result.filter((item) => item.id !== id);
      return data.length > 0;
    }

    return result.length > 0;
  }

  private async checkUniqueName(name: string, id?: number): Promise<boolean> {
    const condition = {
      name: name,
      id: Not(id),
    };
    if (!id) delete condition.id;
    const result = await this.serviceTypeRepository.findOneByCondition(
      condition,
    );

    return !!result;
  }

  public async importServiceType(request: FileUploadRequestDto): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
      userId: request.userId,
    } as ImportRequestDto;
    return this.serviceTypeImport.importUtil(importRequestDto);
  }
}
