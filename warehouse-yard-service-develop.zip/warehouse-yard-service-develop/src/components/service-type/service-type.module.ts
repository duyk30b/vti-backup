import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ServiceTypeController } from './service-type.controller';
import { ServiceTypeService } from './service-type.service';
import { ServiceTypeRepo } from '@repositories/service-type/service-type.repository';
import { ServiceTypeAttributesRepository } from '@repositories/service-type/service-type-attribute.repository';
import { ServiceTypeEntity } from '@entities/service-type/service-type.entity';
import { ServiceTypeAtrributeEntity } from '@entities/service-type/service-type-attribute.entity';
import { ServiceTypeImport } from './import/service-type.import.helper';

@Module({
  imports: [
    TypeOrmModule.forFeature([ServiceTypeEntity, ServiceTypeAtrributeEntity]),
  ],
  providers: [
    {
      provide: 'ServiceTypeRepoInterface',
      useClass: ServiceTypeRepo,
    },
    {
      provide: 'ServiceTypeAttributesRepositoryInterface',
      useClass: ServiceTypeAttributesRepository,
    },
    {
      provide: 'ServiceTypeServiceInterface',
      useClass: ServiceTypeService,
    },
    {
      provide: 'ServiceTypeImport',
      useClass: ServiceTypeImport,
    },
  ],
  controllers: [ServiceTypeController],
  exports: [
    {
      provide: 'ServiceTypeRepoInterface',
      useClass: ServiceTypeRepo,
    },
  ],
})
export class ServiceTypeModule {}
