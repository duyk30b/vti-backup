import { ResponsePayload } from '@utils/response-payload';
import { CreateServiceTypeRequestDto } from '../dto/request/create-service-type.request.dto';
import { UpdateServiceTypeRequestDto } from '../dto/request/update-service-type.request.dto';
import { GetServiceTypeListRequestDto } from '../dto/request/search-service-type.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { ServiceTypeResponseDto } from '../dto/response/service-type.response.dto';
import { SetStatusRequestDto } from '@utils/common.request.dto';
import { ServiceTypeListResponseDto } from '../dto/response/service-type-list.response.dto';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
export interface ServiceTypeServiceInterface {
  createServiceType(
    payload: CreateServiceTypeRequestDto,
  ): Promise<ResponsePayload<ServiceTypeResponseDto | any>>;

  updateServiceType(
    payload: UpdateServiceTypeRequestDto,
  ): Promise<ResponsePayload<ServiceTypeResponseDto | any>>;

  confirmServiceType(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<ServiceTypeResponseDto | any>>;

  deleteServiceType(
    id: number,
  ): Promise<ResponsePayload<SuccessResponse | any>>;

  confirmMultipleServiceType(
    request: DeleteMultipleDto,
  ): Promise<ResponsePayload<ServiceTypeResponseDto | any>>;

  deleteMultipleServiceType(
    request: DeleteMultipleDto,
  ): Promise<ResponsePayload<SuccessResponse | any>>;

  detailServiceType(
    id: number,
  ): Promise<ResponsePayload<ServiceTypeResponseDto | any>>;

  getListServiceType(
    payload: GetServiceTypeListRequestDto,
  ): Promise<ResponsePayload<ServiceTypeListResponseDto | any>>;

  importServiceType(request: FileUploadRequestDto): Promise<any>;
}
