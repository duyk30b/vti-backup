import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { ServiceTypeAtrributeEntity } from '@entities/service-type/service-type-attribute.entity';
import { CreateServiceTypeAttributeRequestDto } from '../dto/request/create-service-type-attribute.request.dto';
import { UpdateServiceTypeAttributeRequestDto } from '../dto/request/update-service-type-attribute.request.dto';
export interface ServiceTypeAttributesRepositoryInterface
  extends BaseInterfaceRepository<ServiceTypeAtrributeEntity> {
  createEntity(request: CreateServiceTypeAttributeRequestDto);
  updateEntity(request: UpdateServiceTypeAttributeRequestDto);
}
