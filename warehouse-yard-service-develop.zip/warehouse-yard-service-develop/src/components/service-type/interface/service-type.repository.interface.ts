import { CreateServiceTypeRequestDto } from '@components/service-type/dto/request/create-service-type.request.dto';
import { GetServiceTypeListRequestDto } from '@components/service-type/dto/request/search-service-type.request.dto';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { ServiceTypeEntity } from '@entities/service-type/service-type.entity';

export interface ServiceTypeRepoInterface
  extends BaseInterfaceRepository<ServiceTypeEntity> {
  createEntity(request: CreateServiceTypeRequestDto);
  updateEntity(id: number, request: CreateServiceTypeRequestDto);
  getList(request: GetServiceTypeListRequestDto);
  getDetail(id: number);
  delete(id: number);
}
