import {
  Body,
  Controller,
  Inject,
  Post,
  Put,
  Get,
  Delete,
} from '@nestjs/common';
import { ServiceTypeServiceInterface } from './interface/service-type.service.interface';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { MessagePattern } from '@nestjs/microservices';
import { ResponsePayload } from '@utils/response-payload';
import {
  CREATE_SERVICE_TYPE_PERMISSION,
  UPDATE_SERVICE_TYPE_PERMISSION,
  DELETE_SERVICE_TYPE_PERMISSION,
  DETAIL_SERVICE_TYPE_PERMISSION,
  LIST_SERVICE_TYPE_PERMISSION,
  CONFIRM_SERVICE_TYPE_PERMISSION,
  IMPORT_SERVICE_TYPE_PERMISSION,
} from '@utils/permissions/service-type';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { CreateServiceTypeRequestDto } from './dto/request/create-service-type.request.dto';
import { UpdateServiceTypeRequestDto } from './dto/request/update-service-type.request.dto';
import { GetServiceTypeListRequestDto } from './dto/request/search-service-type.request.dto';
import {
  DeleteRequestDto,
  DetailRequestDto,
  SetStatusRequestDto,
} from '@utils/common.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { ServiceTypeResponseDto } from './dto/response/service-type.response.dto';
import { ServiceTypeListResponseDto } from './dto/response/service-type-list.response.dto';
import { isEmpty } from 'lodash';
import { ApiResponse } from '@nestjs/swagger';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';

@Controller('service-types')
export class ServiceTypeController {
  constructor(
    @Inject('ServiceTypeServiceInterface')
    private readonly serviceTypeService: ServiceTypeServiceInterface,
  ) {}

  @Post('/service-types')
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ServiceTypeResponseDto,
  })
  @PermissionCode(CREATE_SERVICE_TYPE_PERMISSION.code)
  @MessagePattern('create_service_type')
  public async createServiceType(
    @Body() payload: CreateServiceTypeRequestDto,
  ): Promise<ResponsePayload<ServiceTypeResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.serviceTypeService.createServiceType(request);
  }

  @Put('/service-types/:id')
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: ServiceTypeResponseDto,
  })
  @PermissionCode(UPDATE_SERVICE_TYPE_PERMISSION.code)
  @MessagePattern('update_service_type')
  public async updateServiceType(
    @Body() payload: UpdateServiceTypeRequestDto,
  ): Promise<ResponsePayload<ServiceTypeResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.serviceTypeService.updateServiceType(request);
  }

  @Put('/service-types/:id/confirm')
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ServiceTypeResponseDto,
  })
  @PermissionCode(CONFIRM_SERVICE_TYPE_PERMISSION.code)
  @MessagePattern('confirm_service_type')
  public async confirmServiceType(
    @Body() payload: SetStatusRequestDto,
  ): Promise<ResponsePayload<ServiceTypeResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.serviceTypeService.confirmServiceType(request);
  }

  @PermissionCode(CONFIRM_SERVICE_TYPE_PERMISSION.code)
  @MessagePattern('confirm_service_type_multiple')
  public async confirmMultipleServiceType(
    @Body() payload: DeleteMultipleDto,
  ): Promise<ResponsePayload<ServiceTypeResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.serviceTypeService.confirmMultipleServiceType(request);
  }

  @Delete('/service-types/:id')
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  @PermissionCode(DELETE_SERVICE_TYPE_PERMISSION.code)
  @MessagePattern('delete_service_type')
  public async deleteServiceType(
    @Body() payload: DeleteRequestDto,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.serviceTypeService.deleteServiceType(request.id);
  }

  @PermissionCode(DELETE_SERVICE_TYPE_PERMISSION.code)
  @MessagePattern('delete_service_type_multiple')
  public async deleteMultipleServiceType(
    @Body() payload: DeleteMultipleDto,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.serviceTypeService.deleteMultipleServiceType(request);
  }

  @Get('/service-types/:id')
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: ServiceTypeResponseDto,
  })
  @PermissionCode(DETAIL_SERVICE_TYPE_PERMISSION.code)
  @MessagePattern('detail_service_type')
  public async detailServiceType(
    @Body() payload: DetailRequestDto,
  ): Promise<ResponsePayload<ServiceTypeResponseDto | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.serviceTypeService.detailServiceType(request.id);
  }

  @Get('/service-types/list')
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: ServiceTypeListResponseDto,
  })
  @PermissionCode(LIST_SERVICE_TYPE_PERMISSION.code)
  @MessagePattern('list_service_types')
  public async getListServiceType(
    @Body() payload: GetServiceTypeListRequestDto,
  ): Promise<ResponsePayload<ServiceTypeListResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.serviceTypeService.getListServiceType(request);
  }

  @PermissionCode(IMPORT_SERVICE_TYPE_PERMISSION.code)
  @MessagePattern('import_service_type')
  public async importFactory(@Body() body: FileUploadRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.serviceTypeService.importServiceType(request);
  }
}
