import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class CustomerClassListResponseDto {
  @ApiProperty({ example: 1, description: 'customer class id' })
  @Expose()
  id: number;

  @ApiProperty({
    example: 'customer class 1',
    description: 'customer class name',
  })
  @Expose()
  name: string;

  @ApiProperty({
    example: 'customer class code',
    description: 'customer class id',
  })
  @Expose()
  code: string;

  @ApiProperty({ example: 0, description: 'customer class name' })
  @Expose()
  status: number;
}
