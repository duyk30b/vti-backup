import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { CustomFieldResponse } from '@utils/custom-field.response.dto';
import { UserResponseDto } from '@components/user/dto/response/user.response.dto';
export class CustomerClassResponseDto {
  @ApiProperty({ example: '1', description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'R1', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'customer class 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'customer class desc', description: '' })
  @Expose()
  description: string;

  @ApiProperty({ example: '1', description: '' })
  @Expose()
  status: number;

  @ApiProperty({ example: '10', description: '' })
  @Expose()
  minJoinedDays: number;

  @ApiProperty({ example: '30', description: '' })
  @Expose()
  maxJoinedDays: number;

  @ApiProperty({ example: '100.00', description: '' })
  @Expose()
  amountFrom: number;

  @ApiProperty({ example: '100.00', description: '' })
  @Expose()
  discount: number;

  @ApiProperty({ example: '200.00', description: '' })
  @Expose()
  amountTo: number;

  @ApiProperty({ example: '1', description: '' })
  @Expose()
  currencyUnitId: number;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  createdAt: Date;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: CustomFieldResponse, isArray: true })
  @Expose()
  customFields: CustomFieldResponse[];

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  createdByUser: UserResponseDto;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  latestEditedUser: UserResponseDto;
}
