import { CreateCustomerClassRequestDto } from './create-customer-class.request.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class UpdateCustomerClassRequestDto extends CreateCustomerClassRequestDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  id: number;
}
