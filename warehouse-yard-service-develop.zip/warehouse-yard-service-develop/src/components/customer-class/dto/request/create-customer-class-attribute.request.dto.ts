import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsInt } from 'class-validator';
import { CustomFieldRequest } from '@utils/custom-field.request.dto';

export class CreateCustomerClassAttributeRequestDto extends CustomFieldRequest {
  @ApiProperty({
    example: '1',
    description: 'Customer class id',
  })
  @IsNotEmpty()
  @IsInt()
  customerClassId: number;
}
