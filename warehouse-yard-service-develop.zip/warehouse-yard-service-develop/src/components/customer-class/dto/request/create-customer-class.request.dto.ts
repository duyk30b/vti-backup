import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsDecimal,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  IsNumber,
  IsInt,
  Min,
  Max,
} from 'class-validator';
import { CustomFieldResponse } from '@utils/custom-field.response.dto';
import { BaseDto } from '@core/dto/base.dto';
import { decimal } from '@utils/common';

export class CreateCustomerClassRequestDto extends BaseDto {
  @ApiProperty({ example: '1234', description: 'Mã code của customer class' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(50)
  code: string;

  @ApiProperty({
    example: 'customer class name',
    description: 'Ten cua customer class',
  })
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiPropertyOptional({
    example: 'description customer class',
    description: 'Mo ta cho customer class',
  })
  @IsString()
  @IsOptional()
  @MaxLength(255)
  description: string;

  @ApiProperty({
    example: 'min joined days customer class',
    description: 'Số ngày tham gia tối thiểu customer class',
  })
  @IsNotEmpty()
  @IsInt()
  minJoinedDays: number;

  @ApiProperty()
  @IsNotEmpty()
  @Min(0)
  @Max(decimal(5, 3))
  discount: number;

  @ApiProperty({
    example: 'max joined days customer class',
    description: 'Số ngày tham gia tối đa của customer class',
  })
  @IsNotEmpty()
  @IsInt()
  maxJoinedDays: number;

  @ApiProperty({
    example: 'amount from customer class',
    description: 'Số tiền tham gia tối thiểu của customer class',
  })
  @IsNotEmpty()
  @IsNumber()
  amountFrom: number;

  @ApiProperty({
    example: 'amount to customer class',
    description: 'Số tiền tham gia tối đa của customer class',
  })
  @IsNotEmpty()
  @IsNumber()
  amountTo: number;

  @ApiProperty({
    example: 'currency unit id customer class',
    description: 'Id đơn vị tiền tệ customer class',
  })
  @IsNotEmpty()
  @IsNumber()
  currencyUnitId: number;

  @ApiProperty({ type: CustomFieldResponse, isArray: true })
  customFields: CustomFieldResponse[];
}
