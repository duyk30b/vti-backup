import { CreateCustomerClassAttributeRequestDto } from './create-customer-class-attribute.request.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class UpdateCustomerClassAttributeRequestDto extends CreateCustomerClassAttributeRequestDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  id: number;
}
