import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { CustomerClassAtrributeEntity } from '@entities/customer-class/customer-class-attribute.entity';
import { CreateCustomerClassAttributeRequestDto } from '../dto/request/create-customer-class-attribute.request.dto';
import { UpdateCustomerClassAttributeRequestDto } from '../dto/request/update-customer-class-attribute.request.dto';
export interface CustomerClassAttributesRepositoryInterface
  extends BaseInterfaceRepository<CustomerClassAtrributeEntity> {
  createEntity(request: CreateCustomerClassAttributeRequestDto);
  updateEntity(request: UpdateCustomerClassAttributeRequestDto);
}
