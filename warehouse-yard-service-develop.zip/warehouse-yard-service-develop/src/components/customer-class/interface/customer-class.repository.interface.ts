import { CreateCustomerClassRequestDto } from '@components/customer-class/dto/request/create-customer-class.request.dto';
import { GetCustomerClassListRequestDto } from '@components/customer-class/dto/request/search-customer-class.request.dto';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { CustomerClassEntity } from '@entities/customer-class/customer-class.entity';

export interface CustomerClassRepoInterface
  extends BaseInterfaceRepository<CustomerClassEntity> {
  createEntity(request: CreateCustomerClassRequestDto);
  updateEntity(id: number, request: CreateCustomerClassRequestDto);
  getList(request: GetCustomerClassListRequestDto);
  getDetail(id: number);
  delete(id: number);
  checkAndGetCustomerClass(totalPrice: number);
}
