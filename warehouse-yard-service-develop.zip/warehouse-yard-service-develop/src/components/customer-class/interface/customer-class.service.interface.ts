import { ResponsePayload } from '@utils/response-payload';
import { CreateCustomerClassRequestDto } from '../dto/request/create-customer-class.request.dto';
import { UpdateCustomerClassRequestDto } from '../dto/request/update-customer-class.request.dto';
import { GetCustomerClassListRequestDto } from '../dto/request/search-customer-class.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { CustomerClassResponseDto } from '../dto/response/customer-class.response.dto';
import { SetStatusRequestDto } from '@utils/common.request.dto';
import { CustomerClassListResponseDto } from '../dto/response/customer-class-list.response.dto';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';

export interface CustomerClassServiceInterface {
  createCustomerClass(
    payload: CreateCustomerClassRequestDto,
  ): Promise<ResponsePayload<CustomerClassResponseDto | any>>;

  updateCustomerClass(
    payload: UpdateCustomerClassRequestDto,
  ): Promise<ResponsePayload<CustomerClassResponseDto | any>>;

  confirmCustomerClass(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<CustomerClassResponseDto | any>>;

  deleteCustomerClass(
    id: number,
  ): Promise<ResponsePayload<SuccessResponse | any>>;

  confirmMultipleCustomerClass(
    request: DeleteMultipleDto,
  ): Promise<ResponsePayload<CustomerClassResponseDto | any>>;

  deleteMultipleCustomerClass(
    request: DeleteMultipleDto,
  ): Promise<ResponsePayload<SuccessResponse | any>>;

  detailCustomerClass(
    id: number,
  ): Promise<ResponsePayload<CustomerClassResponseDto | any>>;

  getListCustomerClass(
    payload: GetCustomerClassListRequestDto,
  ): Promise<ResponsePayload<CustomerClassListResponseDto | any>>;

  importCustomerClass(request: FileUploadRequestDto): Promise<any>;
  getListByIds(payload: any): Promise<any>;
  getCustomerCheckPrice(totalPrice: number): Promise<any>;
}
