export enum CustomerClassStatusEnum {
  PENDING = 0,
  CONFIRMED = 1,
  DISABLED = 2,
}

export const CAN_UPDATE_CUSTOMER_CLASS_STATUS: number[] = [
  CustomerClassStatusEnum.PENDING,
  CustomerClassStatusEnum.DISABLED,
];

export const CAN_DELETE_CUSTOMER_CLASS_STATUS: number[] = [
  CustomerClassStatusEnum.PENDING,
  CustomerClassStatusEnum.DISABLED,
];

export const CAN_CONFIRM_CUSTOMER_CLASS_STATUS: number[] = [
  CustomerClassStatusEnum.PENDING,
  CustomerClassStatusEnum.DISABLED,
];
