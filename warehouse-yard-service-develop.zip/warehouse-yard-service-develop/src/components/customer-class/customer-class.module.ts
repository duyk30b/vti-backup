import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CustomerClassController } from './customer-class.controller';
import { CustomerClassService } from './customer-class.service';
import { CustomerClassRepo } from '@repositories/customer-class/customer-class.repository';
import { CustomerClassAttributesRepository } from '@repositories/customer-class/customer-class-attribute.repository';
import { CustomerClassEntity } from '@entities/customer-class/customer-class.entity';
import { CustomerClassAtrributeEntity } from '@entities/customer-class/customer-class-attribute.entity';
import { CurrencyUnitRepository } from '@repositories/currency-unit/currency-unit.repository';
import { CurrencyUnitEntity } from '@entities/currency-unit/currency-unit.entity';
import { CustomerClassImport } from './import/customer-class.import.helper';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      CustomerClassEntity,
      CustomerClassAtrributeEntity,
      CurrencyUnitEntity,
    ]),
  ],
  providers: [
    {
      provide: 'CustomerClassRepoInterface',
      useClass: CustomerClassRepo,
    },
    {
      provide: 'CustomerClassAttributesRepositoryInterface',
      useClass: CustomerClassAttributesRepository,
    },
    {
      provide: 'CustomerClassServiceInterface',
      useClass: CustomerClassService,
    },
    {
      provide: 'CurrencyUnitRepositoryInterface',
      useClass: CurrencyUnitRepository,
    },
    {
      provide: 'CustomerClassImport',
      useClass: CustomerClassImport,
    },
  ],
  controllers: [CustomerClassController],
  exports: [],
})
export class CustomerClassModule {}
