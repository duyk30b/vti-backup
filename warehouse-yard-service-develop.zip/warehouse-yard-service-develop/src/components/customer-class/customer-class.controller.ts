import {
  Body,
  Controller,
  Inject,
  Post,
  Put,
  Get,
  Delete,
} from '@nestjs/common';
import { CustomerClassServiceInterface } from './interface/customer-class.service.interface';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { MessagePattern } from '@nestjs/microservices';
import { ResponsePayload } from '@utils/response-payload';
import {
  CREATE_CUSTOMER_CLASS_PERMISSION,
  UPDATE_CUSTOMER_CLASS_PERMISSION,
  DELETE_CUSTOMER_CLASS_PERMISSION,
  DETAIL_CUSTOMER_CLASS_PERMISSION,
  LIST_CUSTOMER_CLASS_PERMISSION,
  CONFIRM_CUSTOMER_CLASS_PERMISSION,
  IMPORT_CUSTOMER_CLASS_PERMISSION,
} from '@utils/permissions/customer-class';
import { CreateCustomerClassRequestDto } from './dto/request/create-customer-class.request.dto';
import { UpdateCustomerClassRequestDto } from './dto/request/update-customer-class.request.dto';
import { GetCustomerClassListRequestDto } from './dto/request/search-customer-class.request.dto';
import {
  DeleteRequestDto,
  DetailRequestDto,
  SetStatusRequestDto,
} from '@utils/common.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { CustomerClassResponseDto } from './dto/response/customer-class.response.dto';
import { CustomerClassListResponseDto } from './dto/response/customer-class-list.response.dto';
import { isEmpty } from 'lodash';
import { ApiResponse } from '@nestjs/swagger';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { GetCustomerClassRequestDto } from './dto/request/get-customer-class.request.dto';
import { CheckPriceRequestDto } from '@components/bill/dto/request/check-price.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';

@Controller('customer-classes')
export class CustomerClassController {
  constructor(
    @Inject('CustomerClassServiceInterface')
    private readonly customerClassService: CustomerClassServiceInterface,
  ) {}

  @Post('/customer-classes')
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: CustomerClassResponseDto,
  })
  @PermissionCode(CREATE_CUSTOMER_CLASS_PERMISSION.code)
  @MessagePattern('create_customer_class')
  public async createCustomerClass(
    @Body() payload: CreateCustomerClassRequestDto,
  ): Promise<ResponsePayload<CustomerClassResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.customerClassService.createCustomerClass(request);
  }

  @Put('/customer-classes/:id')
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: CustomerClassResponseDto,
  })
  @PermissionCode(UPDATE_CUSTOMER_CLASS_PERMISSION.code)
  @MessagePattern('update_customer_class')
  public async updateCustomerClass(
    @Body() payload: UpdateCustomerClassRequestDto,
  ): Promise<ResponsePayload<CustomerClassResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.customerClassService.updateCustomerClass(request);
  }

  @Put('/customer-classes/:id/confirm')
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: CustomerClassResponseDto,
  })
  @PermissionCode(CONFIRM_CUSTOMER_CLASS_PERMISSION.code)
  @MessagePattern('confirm_customer_class')
  public async confirmCustomerClass(
    @Body() payload: SetStatusRequestDto,
  ): Promise<ResponsePayload<CustomerClassResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.customerClassService.confirmCustomerClass(request);
  }

  @PermissionCode(CONFIRM_CUSTOMER_CLASS_PERMISSION.code)
  @MessagePattern('confirm_customer_class_multiple')
  public async confirmMultipleCustomerClass(
    @Body() payload: DeleteMultipleDto,
  ): Promise<ResponsePayload<CustomerClassResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.customerClassService.confirmMultipleCustomerClass(
      request,
    );
  }

  @Delete('/customer-classes/:id')
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  @PermissionCode(DELETE_CUSTOMER_CLASS_PERMISSION.code)
  @MessagePattern('delete_customer_class')
  public async deleteCustomerClass(
    @Body() payload: DeleteRequestDto,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.customerClassService.deleteCustomerClass(request.id);
  }

  @PermissionCode(DELETE_CUSTOMER_CLASS_PERMISSION.code)
  @MessagePattern('delete_customer_class_multiple')
  public async deleteMultipleCustomerClass(
    @Body() payload: DeleteMultipleDto,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.customerClassService.deleteMultipleCustomerClass(request);
  }

  @Get('/customer-classes/:id')
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: CustomerClassResponseDto,
  })
  @PermissionCode(DETAIL_CUSTOMER_CLASS_PERMISSION.code)
  @MessagePattern('detail_customer_class')
  public async detailCustomerClass(
    @Body() payload: DetailRequestDto,
  ): Promise<ResponsePayload<CustomerClassResponseDto | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.customerClassService.detailCustomerClass(request.id);
  }

  @Get('/customer-classes/list')
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: CustomerClassListResponseDto,
  })
  @PermissionCode(LIST_CUSTOMER_CLASS_PERMISSION.code)
  @MessagePattern('list_customer_class')
  public async getListCustomerClass(
    @Body() payload: GetCustomerClassListRequestDto,
  ): Promise<ResponsePayload<CustomerClassListResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.customerClassService.getListCustomerClass(request);
  }

  @PermissionCode(IMPORT_CUSTOMER_CLASS_PERMISSION.code)
  @MessagePattern('import_customer_class')
  public async importFactory(@Body() body: FileUploadRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.customerClassService.importCustomerClass(request);
  }

  @MessagePattern('get_customer_class_by_ids')
  public async getCustomerByIds(
    @Body() payload: GetCustomerClassRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.customerClassService.getListByIds(request);
  }

  @MessagePattern('get_customer_class_check_price')
  public async getCustomerCheckPrice(
    @Body() payload: CheckPriceRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.customerClassService.getCustomerCheckPrice(
      request.totalPrice,
    );
  }
}
