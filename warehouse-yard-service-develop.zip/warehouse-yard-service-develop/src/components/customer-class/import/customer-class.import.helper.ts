import { ImportDataAbstract } from '@core/abstracts/import-data.abstract';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectConnection } from '@nestjs/typeorm';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty, keyBy } from 'lodash';
import { I18nRequestScopeService, I18nService } from 'nestjs-i18n';
import {
  Connection,
  In,
  ILike,
  MoreThanOrEqual,
  LessThanOrEqual,
  Not,
} from 'typeorm';
import { CustomerClassRepoInterface } from '../interface/customer-class.repository.interface';
import { CreateCustomerClassRequestDto } from '../dto/request/create-customer-class.request.dto';
import { CurrencyUnitRepositoryInterface } from '@components/currency-unit/interface/currency-unit.repository.interface';
import { toLowerKeys } from '@utils/common';

@Injectable()
export class CustomerClassImport extends ImportDataAbstract {
  private readonly FIELD_TEMPLATE_CONST = {
    CODE: {
      DB_COL_NAME: 'customerClassCode',
      COL_NAME: [
        'Mã hạng khách hàng',
        'Customer level code',
        '顧客ランクコード',
      ],
      MAX_LENGTH: 50,
      ALLOW_NULL: false,
      REGEX: /^([a-zA-Z0-9]+)$/,
    },
    NAME: {
      DB_COL_NAME: 'customerClassName',
      COL_NAME: ['Tên hạng khách hàng', '顧客ランク名', 'Customer level name'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    JOINED_DATE_FROM: {
      DB_COL_NAME: 'joinedDateFrom',
      COL_NAME: ['Ngày tham gia từ', '開始日', 'Joined date from'],
      MAX_LENGTH: 18,
      ALLOW_NULL: false,
      IS_DECIMAL: false,
    },
    JOINED_DATE_TO: {
      DB_COL_NAME: 'joinedDateTo',
      COL_NAME: ['Ngày tham gia đến', '終了日', 'Joined date to'],
      MAX_LENGTH: 18,
      ALLOW_NULL: false,
      IS_DECIMAL: false,
    },
    JOINED_AMOUNT_FROM: {
      DB_COL_NAME: 'joinedAmountFrom',
      COL_NAME: ['Số tiền tham gia từ', '金額下限', 'Joined amount from'],
      MAX_LENGTH: 18,
      ALLOW_NULL: false,
      IS_DECIMAL: true,
      IS_DECIMAL_ALLOW_ZERO: true,
    },
    JOINED_AMOUNT_TO: {
      DB_COL_NAME: 'joinedAmountTo',
      COL_NAME: ['Số tiền tham gia đến', '金額上限', 'Joined amount to'],
      MAX_LENGTH: 18,
      ALLOW_NULL: false,
      IS_DECIMAL: true,
      IS_DECIMAL_ALLOW_ZERO: true,
    },
    CURRENCY_UNIT: {
      DB_COL_NAME: 'currencyUnit',
      COL_NAME: ['Đơn vị tiền tệ', '通貨単位', 'Currency unit'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    DESCRIPTION: {
      DB_COL_NAME: 'description',
      COL_NAME: ['Description', '説明', 'Mô tả'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    REQUIRED_COL_NUM: 9,
  };

  constructor(
    @Inject('CustomerClassRepoInterface')
    private readonly customerClassRepository: CustomerClassRepoInterface,
    @Inject('CurrencyUnitRepositoryInterface')
    private readonly currencyUnitRepository: CurrencyUnitRepositoryInterface,
    @InjectConnection()
    private readonly connection: Connection,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    this.fieldsMap.groupSet(
      [2, 3, 4, 5, 6, 7, 8, 9],
      [
        this.FIELD_TEMPLATE_CONST.CODE,
        this.FIELD_TEMPLATE_CONST.NAME,
        this.FIELD_TEMPLATE_CONST.JOINED_DATE_FROM,
        this.FIELD_TEMPLATE_CONST.JOINED_DATE_TO,
        this.FIELD_TEMPLATE_CONST.JOINED_AMOUNT_FROM,
        this.FIELD_TEMPLATE_CONST.JOINED_AMOUNT_TO,
        this.FIELD_TEMPLATE_CONST.CURRENCY_UNIT,
        this.FIELD_TEMPLATE_CONST.DESCRIPTION,
      ],
    );
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
    error: number,
    total: number,
    userId,
  ): Promise<ImportResponseDto> {
    const findCurrencyUnit =
      await this.currencyUnitRepository.findWithRelations({
        where: {
          name: In(dataDto.map((i) => i.currencyUnit)),
        },
      });
    const condition = {};
    dataDto
      .map((i) => i.customerClassCode)
      .forEach((code) => {
        Object.assign(condition, { code: ILike(code) });
      });
    const findByCode = await this.customerClassRepository.findWithRelations({
      where: condition,
    });
    const findByName = await this.customerClassRepository.findWithRelations({
      where: {
        name: In(dataDto.map((i) => i.customerClassName)),
      },
    });

    findByCode.forEach((i) => Object.assign(i, { type: 'old' }));
    findByName.forEach((i) => Object.assign(i, { type: 'old' }));

    const findCurrencyUnitByName = keyBy(findCurrencyUnit, 'name');
    const findByCodeMap = toLowerKeys(keyBy(findByCode, 'code'));
    const findByNameMap = keyBy(findByName, 'name');
    const entities = [];
    const valid = [];
    const {
      duplicateCodeOrNameMsg,
      codeNotExistMsg,
      successMsg,
      unsuccessMsg,
      addText,
      updateText,
      noText,
      doneText,
      currencyUnitNotFoundMsg,
      amountOrDateInvalid,
    } = await this.getMessage();

    const validateCustomerClassList = await this.validateCustomerClassList(
      dataDto.map((data) => {
        if (data.action.toLowerCase() === addText) return data;
        return {
          ...data,
          id: findByCodeMap[data.customerClassCode.toLowerCase()]?.id,
        };
      }),
    );

    for (let index = 0; index < dataDto.length; index++) {
      const data = dataDto[index];
      const {
        i,
        action,
        customerClassCode,
        customerClassName,
        description,
        joinedDateFrom,
        joinedDateTo,
        joinedAmountFrom,
        joinedAmountTo,
        currencyUnit,
      } = data;
      const logRow = {
        id: i,
        row: i,
        action: action,
      } as ImportResultDto;
      const msgLogs = [];

      const formatedData = new CreateCustomerClassRequestDto();
      formatedData.code = customerClassCode;
      formatedData.name = customerClassName;
      formatedData.minJoinedDays = joinedDateFrom;
      formatedData.maxJoinedDays = joinedDateTo;
      formatedData.amountFrom = joinedAmountFrom;
      formatedData.amountTo = joinedAmountTo;
      formatedData.description = description;

      if (findCurrencyUnitByName[currencyUnit])
        formatedData.currencyUnitId = findCurrencyUnitByName[currencyUnit].id;
      else {
        msgLogs.push(currencyUnitNotFoundMsg);
        logRow.log = msgLogs;
        logs.push(logRow);
        continue;
      }

      if (action.toLowerCase() === addText) {
        if (
          findByCodeMap[customerClassCode.toLowerCase()] ||
          findByNameMap[customerClassName]
        ) {
          msgLogs.push(duplicateCodeOrNameMsg);
        } else {
          formatedData['userId'] = userId;

          if (
            !this.validateCustomerClass(formatedData, validateCustomerClassList)
          ) {
            msgLogs.push(amountOrDateInvalid);
            logRow.log = msgLogs;
            logs.push(logRow);
            continue;
          }
          const entity =
            this.customerClassRepository.createEntity(formatedData);
          entities.push(entity);
          Object.assign(entity, { type: 'new' });
          findByCodeMap[customerClassCode.toLowerCase()] = entity;
          findByNameMap[customerClassName] = entity;
        }
      } else if (action.toLowerCase() === updateText) {
        if (
          findByCodeMap[customerClassCode.toLowerCase()] &&
          findByCodeMap[customerClassCode.toLowerCase()]?.['type'] === 'old'
        ) {
          if (
            findByNameMap[customerClassName] &&
            findByNameMap[customerClassName].id !=
              findByCodeMap[customerClassCode.toLowerCase()].id
          ) {
            msgLogs.push(duplicateCodeOrNameMsg);
          } else {
            formatedData['userId'] = userId;

            if (
              !this.validateCustomerClass(
                {
                  ...formatedData,
                  id: findByCodeMap[data.customerClassCode.toLowerCase()]?.id,
                },
                validateCustomerClassList,
              )
            ) {
              msgLogs.push(amountOrDateInvalid);
              logRow.log = msgLogs;
              logs.push(logRow);
              continue;
            }
            const entity = this.customerClassRepository.updateEntity(
              findByCodeMap[customerClassCode.toLowerCase()].id,
              formatedData,
            );
            entities.push(entity);
            Object.assign(entity, { type: 'new' });
            findByCodeMap[customerClassCode.toLowerCase()] = entity;
            findByNameMap[customerClassName] = entity;
          }
        } else {
          msgLogs.push(codeNotExistMsg);
        }
      }
      if (isEmpty(msgLogs)) {
        logRow.log = [successMsg];
        valid.push(logRow);
      } else {
        logRow.log = msgLogs;
        logs.push(logRow);
      }
    }
    const response = new ImportResponseDto();
    if (!isEmpty(entities)) {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(entities);
        await queryRunner.commitTransaction();
        response.successCount = valid.length;
      } catch (error) {
        queryRunner.rollbackTransaction();
        response.successCount = 0;
        valid.forEach((l) => (l.log = [unsuccessMsg]));
      } finally {
        await queryRunner.release();
        logs.push(...valid);
      }
    }
    response.result = logs;
    response.totalCount = total;
    response.result;
    return response;
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<ImportResponseDto | any>> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_CONST.REQUIRED_COL_NUM,
    );
  }

  private async validateCustomerClassList(payloadList) {
    const daysCondition = {};
    const amountCondition = {};
    payloadList.forEach((payload) => {
      const {
        joinedDateFrom,
        joinedDateTo,
        joinedAmountFrom,
        joinedAmountTo,
        id,
      } = payload;

      Object.assign(daysCondition, {
        minJoinedDays: LessThanOrEqual(joinedDateTo),
        maxJoinedDays: MoreThanOrEqual(joinedDateFrom),
        id: Not(id || -1),
      });
      Object.assign(amountCondition, {
        amountFrom: LessThanOrEqual(joinedAmountTo),
        amountTo: MoreThanOrEqual(joinedAmountFrom),
        id: Not(id || -1),
      });
    });

    const checkJoinedDays = await this.customerClassRepository.findByCondition(
      daysCondition,
    );

    const checkAmount = await this.customerClassRepository.findByCondition(
      amountCondition,
    );

    return checkJoinedDays.concat(checkAmount);
  }

  private validateCustomerClass(payload, list) {
    const { minJoinedDays, maxJoinedDays, amountFrom, amountTo, id } = payload;

    const checkJoinedDays = list.find(
      (customerClass) =>
        (customerClass.id !== id || !id) &&
        customerClass.minJoinedDays <= maxJoinedDays &&
        customerClass.maxJoinedDays >= minJoinedDays,
    );

    const checkAmount = list.find(
      (customerClass) =>
        (customerClass.id !== id || !id) &&
        customerClass.amountFrom <= amountTo &&
        customerClass.amountTo >= amountFrom,
    );

    return !checkJoinedDays || !checkAmount;
  }
}
