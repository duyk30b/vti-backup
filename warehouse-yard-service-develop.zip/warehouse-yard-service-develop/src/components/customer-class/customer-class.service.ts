import { Inject, Injectable, Logger } from '@nestjs/common';
import { CustomerClassServiceInterface } from './interface/customer-class.service.interface';
import { ResponsePayload } from '@utils/response-payload';
import { CreateCustomerClassRequestDto } from './dto/request/create-customer-class.request.dto';
import { UpdateCustomerClassRequestDto } from './dto/request/update-customer-class.request.dto';
import { GetCustomerClassListRequestDto } from './dto/request/search-customer-class.request.dto';
import { SetStatusRequestDto } from '@utils/common.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { CustomerClassResponseDto } from './dto/response/customer-class.response.dto';
import { CustomerClassListResponseDto } from './dto/response/customer-class-list.response.dto';
import { CustomerClassRepoInterface } from './interface/customer-class.repository.interface';
import { CustomerClassAttributesRepositoryInterface } from './interface/customer-class-attribute.repository.interface';
import { CurrencyUnitRepository } from '@repositories/currency-unit/currency-unit.repository';
import { CreateCustomerClassAttributeRequestDto } from './dto/request/create-customer-class-attribute.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { I18nService } from 'nestjs-i18n';
import { plainToClass } from 'class-transformer';
import {
  CAN_UPDATE_CUSTOMER_CLASS_STATUS,
  CAN_DELETE_CUSTOMER_CLASS_STATUS,
  CAN_CONFIRM_CUSTOMER_CLASS_STATUS,
  CustomerClassStatusEnum,
} from './customer-class.constant';
import { ApiError } from '@utils/api.error';
import { PagingResponse } from '@utils/paging.response';
import { InjectConnection } from '@nestjs/typeorm';
import { Connection, MoreThanOrEqual, LessThanOrEqual, Not, In } from 'typeorm';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { CustomerClassImport } from './import/customer-class.import.helper';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { isEmpty } from 'lodash';
import { GetCustomerClassRequestDto } from './dto/request/get-customer-class.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { CustomerClassEntity } from '@entities/customer-class/customer-class.entity';
import { stringFormat } from '@utils/object.util';

@Injectable()
export class CustomerClassService implements CustomerClassServiceInterface {
  private readonly logger = new Logger(CustomerClassService.name);
  constructor(
    @Inject('CustomerClassRepoInterface')
    private readonly customerClassRepository: CustomerClassRepoInterface,
    @Inject('CustomerClassAttributesRepositoryInterface')
    private readonly customerClassAttributeRepository: CustomerClassAttributesRepositoryInterface,
    @Inject('CurrencyUnitRepositoryInterface')
    private readonly currencyUnitRepository: CurrencyUnitRepository,
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,
    @Inject('CustomerClassImport')
    private readonly customerClassImport: CustomerClassImport,
    @InjectConnection()
    private readonly connection: Connection,
    private readonly i18n: I18nService,
  ) {}

  public async createCustomerClass(
    payload: CreateCustomerClassRequestDto,
  ): Promise<ResponsePayload<CustomerClassResponseDto | any>> {
    const { code, name, customFields, currencyUnitId } = payload;
    const checkExistCode = await this.checkUniqueCode(code);
    const checkExistName = await this.checkUniqueName(name);
    const checkExistCurrency = await this.currencyUnitRepository.findOneById(
      currencyUnitId,
    );

    const customerClass = await this.currencyUnitRepository.findByCondition({
      name,
    });
    if (customerClass.length) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.NAME_EXIST'),
      ).toResponse();
    }

    const validateCustomerClass = await this.validateCustomerClass(payload);

    if (checkExistCode)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_IS_ALREADY_EXISTS'))
        .build();

    if (checkExistName)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NAME_ALREADY_EXISTS'))
        .build();

    if (!checkExistCurrency)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CURRENCY_UNIT_NOT_FOUND'))
        .build();

    if (!validateCustomerClass)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.JOINED_DAYS_OR_AMOUNT_INVALID'),
        )
        .build();

    const customerClassEntity =
      this.customerClassRepository.createEntity(payload);
    let result;

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    // create customer class attributes
    try {
      result = await queryRunner.manager.save(customerClassEntity);

      if (customFields.length > 0) {
        const attributesEntityList = [];
        customFields.forEach((i) => {
          const attributeRequest = new CreateCustomerClassAttributeRequestDto();
          attributeRequest.name = i.name;
          attributeRequest.value = i.value;
          attributeRequest.customerClassId = customerClassEntity.id;

          const attributeEntity =
            this.customerClassAttributeRepository.createEntity(
              attributeRequest,
            );
          attributesEntityList.push(attributeEntity);
        });

        const response = await queryRunner.manager.save(attributesEntityList);
        result.customFields = response.map((i) => ({
          name: i.name,
          value: i.value,
        }));
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error.message)
        .build();
    }
    await queryRunner.release();

    const response = plainToClass(CustomerClassResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  public async updateCustomerClass(
    payload: UpdateCustomerClassRequestDto,
  ): Promise<ResponsePayload<CustomerClassResponseDto | any>> {
    const { id, code, name, customFields, currencyUnitId } = payload;
    const customerClass = await this.customerClassRepository.findOneById(id);
    const checkExistCurrency = await this.currencyUnitRepository.findOneById(
      currencyUnitId,
    );

    const validateCustomerClass = await this.validateCustomerClass(payload);

    if (!customerClass)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.CUSTOMER_CLASS_NOT_FOUND'),
        )
        .build();

    if (!checkExistCurrency)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CURRENCY_UNIT_NOT_FOUND'))
        .build();

    const checkExistCode = await this.checkUniqueCode(code, id);
    const checkExistName = await this.checkUniqueName(name, id);

    if (checkExistCode) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_IS_ALREADY_EXISTS'))
        .build();
    }

    if (checkExistName)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NAME_ALREADY_EXISTS'))
        .build();

    if (!validateCustomerClass)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.JOINED_DAYS_OR_AMOUNT_INVALID'),
        )
        .build();

    if (!CAN_UPDATE_CUSTOMER_CLASS_STATUS.includes(customerClass.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CUSTOMER_CLASS_WAS_CONFIRMED'),
      ).toResponse();
    }

    const customerClassEntity = this.customerClassRepository.updateEntity(
      id,
      payload,
    );
    let result;

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    // update customer class attributes
    try {
      result = await queryRunner.manager.save(customerClassEntity);

      const customerClassAttributes =
        await this.customerClassAttributeRepository.findWithRelations({
          where: {
            customerClassId: customerClassEntity.id,
          },
        });
      await queryRunner.manager.remove(customerClassAttributes);

      if (customFields.length > 0) {
        const attributesEntityList = [];
        customFields.forEach((i) => {
          const attributeRequest = new CreateCustomerClassAttributeRequestDto();
          attributeRequest.name = i.name;
          attributeRequest.value = i.value;
          attributeRequest.customerClassId = customerClassEntity.id;

          const attributeEntity =
            this.customerClassAttributeRepository.createEntity(
              attributeRequest,
            );
          attributesEntityList.push(attributeEntity);
        });

        const response = await queryRunner.manager.save(attributesEntityList);
        result.customFields = response.map((i) => ({
          name: i.name,
          value: i.value,
        }));

        await queryRunner.commitTransaction();
      }
    } catch (error) {
      await queryRunner.rollbackTransaction();
      console.log(error.message);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error.message)
        .build();
    }
    await queryRunner.release();

    const response = plainToClass(CustomerClassResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  public async deleteCustomerClass(
    id: number,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const customerClass = await this.customerClassRepository.findOneById(id);
    if (!customerClass) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.CUSTOMER_CLASS_NOT_FOUND'),
        )
        .build();
    }

    if (!CAN_DELETE_CUSTOMER_CLASS_STATUS.includes(customerClass.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CUSTOMER_CLASS_WAS_CONFIRMED'),
      ).toResponse();
    }

    try {
      await this.customerClassRepository.delete(id);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Delete
   */
  public async deleteMultipleCustomerClass(
    request: DeleteMultipleDto,
  ): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const customerClasses = await this.customerClassRepository.findByCondition({
      id: In(ids),
    });

    const customerClassIds = customerClasses.map(
      (customerClass) => customerClass.id,
    );
    if (customerClasses.length !== ids.length) {
      ids.forEach((id) => {
        if (!customerClassIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < customerClasses.length; i++) {
      const customerClass = customerClasses[i];
      if (!CAN_DELETE_CUSTOMER_CLASS_STATUS.includes(customerClass.status))
        failIdsList.push(customerClass.id);
    }

    const validIds = customerClasses
      .filter((customerClass) => !failIdsList.includes(customerClass.id))
      .map((customerClass) => customerClass.id);

    try {
      if (!isEmpty(validIds)) {
        this.customerClassRepository.multipleRemove(validIds);
      }
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async detailCustomerClass(
    id: number,
  ): Promise<ResponsePayload<CustomerClassResponseDto | any>> {
    const customerClass = await this.customerClassRepository.getDetail(id);

    if (!customerClass) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.CUSTOMER_CLASS_NOT_FOUND'),
        )
        .build();
    }

    const users = await this.userService.getUserByIds(
      [customerClass.createdByUserId, customerClass.latestEditedUserId],
      true,
    );

    customerClass['createdByUser'] = users[customerClass.createdByUserId];
    customerClass['latestEditedUser'] = users[customerClass.latestEditedUserId];

    const response = plainToClass(CustomerClassResponseDto, customerClass, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }

  public async getListCustomerClass(
    payload: GetCustomerClassListRequestDto,
  ): Promise<ResponsePayload<CustomerClassListResponseDto | any>> {
    const { result, count } = await this.customerClassRepository.getList(
      payload,
    );

    const response = plainToClass(CustomerClassListResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: payload.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async confirmCustomerClass(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<CustomerClassResponseDto | any>> {
    const { id } = request;
    const customerClass = await this.customerClassRepository.findOneById(id);
    if (!customerClass) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.CUSTOMER_CLASS_NOT_FOUND'),
        )
        .build();
    }

    if (!CAN_CONFIRM_CUSTOMER_CLASS_STATUS.includes(customerClass.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_INVALID'),
      ).toResponse();
    }
    customerClass.status = CustomerClassStatusEnum.CONFIRMED;
    customerClass.updatedAt = new Date(Date.now());

    const result = await this.customerClassRepository.update(customerClass);
    const response = plainToClass(CustomerClassResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async confirmMultipleCustomerClass(
    request: DeleteMultipleDto,
  ): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const customerClasses = await this.customerClassRepository.findByCondition({
      id: In(ids),
    });

    const customerClassIds = customerClasses.map(
      (customerClass) => customerClass.id,
    );
    if (customerClasses.length !== ids.length) {
      ids.forEach((id) => {
        if (!customerClassIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < customerClasses.length; i++) {
      const customerClass = customerClasses[i];
      if (!CAN_CONFIRM_CUSTOMER_CLASS_STATUS.includes(customerClass.status))
        failIdsList.push(customerClass.id);
    }

    const validIds = customerClasses
      .filter((customerClass) => !failIdsList.includes(customerClass.id))
      .map((customerClass) => customerClass.id);

    const validateCustomerClasses = customerClasses.filter((customerClass) =>
      validIds.includes(customerClass.id),
    );

    if (!isEmpty(validateCustomerClasses)) {
      validateCustomerClasses.forEach((paymentType) => {
        paymentType.status = CustomerClassStatusEnum.CONFIRMED;
      });
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(
          CustomerClassEntity,
          validateCustomerClasses,
        );
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.CONFIRM_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  private async checkUniqueCode(code: string, id?: number): Promise<boolean> {
    const result = await this.customerClassRepository.findByCondition([
      { code: code },
    ]);
    let data = [];
    if (id) {
      data = result.filter((item) => item.id !== id);
      return data.length > 0;
    }

    return result.length > 0;
  }

  private async checkUniqueName(name: string, id?: number): Promise<boolean> {
    const condition = {
      name: name,
      id: Not(id),
    };
    if (!id) delete condition.id;
    const result = await this.customerClassRepository.findOneByCondition(
      condition,
    );

    return !!result;
  }

  private async validateCustomerClass(payload): Promise<boolean> {
    const { minJoinedDays, maxJoinedDays, amountFrom, amountTo, id } = payload;

    const check = await this.customerClassRepository.findOneByCondition({
      amountFrom: LessThanOrEqual(amountTo),
      amountTo: MoreThanOrEqual(amountFrom),
      minJoinedDays: LessThanOrEqual(maxJoinedDays),
      maxJoinedDays: MoreThanOrEqual(minJoinedDays),
      id: Not(id || -1),
    });

    return !check;
  }

  public async importCustomerClass(
    request: FileUploadRequestDto,
  ): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
      userId: request.userId,
    } as ImportRequestDto;
    return this.customerClassImport.importUtil(importRequestDto);
  }

  async getListByIds(payload: GetCustomerClassRequestDto): Promise<any> {
    const data = await this.customerClassRepository.findWithRelations({
      where: {
        id: In(payload.ids),
      },
      relations: ['currencyUnit'],
    });
    if (isEmpty(data)) {
      return new ResponseBuilder().withCode(ResponseCodeEnum.NOT_FOUND).build();
    }
    return new ResponseBuilder(data).withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async getCustomerCheckPrice(totalPrice: number): Promise<any> {
    const data = await this.customerClassRepository.checkAndGetCustomerClass(
      totalPrice,
    );
    if (isEmpty(data)) {
      return new ResponseBuilder().withCode(ResponseCodeEnum.NOT_FOUND).build();
    }
    return new ResponseBuilder(data).withCode(ResponseCodeEnum.SUCCESS).build();
  }
}
