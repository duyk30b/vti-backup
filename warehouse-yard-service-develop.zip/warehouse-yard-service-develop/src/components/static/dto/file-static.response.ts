import { SuccessResponse } from '@utils/success.response.dto';

export class FileStaticResponse extends SuccessResponse {
  file: Buffer;
}
