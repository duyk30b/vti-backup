import { OnEvent } from '@nestjs/event-emitter';
import { Injectable } from '@nestjs/common';
import { NotificationListenerAbstract } from '@core/abstracts/notification.listener.abstract';
import { NotificationService } from '@components/notification/notification.service';
import { PushNotificationRequestDto } from '@components/notification/dto/notification.request.dto';

@Injectable()
export class BillListener extends NotificationListenerAbstract {
  constructor(protected readonly notificationService: NotificationService) {
    super(notificationService);
  }

  @OnEvent('bill.created')
  public async createListener(event: PushNotificationRequestDto) {
    return super.pushRealtimeNotification(event);
  }

  @OnEvent('bill.confirm')
  public async confirmListener(event: PushNotificationRequestDto) {
    return super.pushRealtimeNotification(event);
  }

  @OnEvent('bill.reject')
  public async rejectListener(event: PushNotificationRequestDto) {
    return super.pushRealtimeNotification(event);
  }

  @OnEvent('bill.complete')
  public async completeListener(event: PushNotificationRequestDto) {
    return super.pushRealtimeNotification(event);
  }
}
