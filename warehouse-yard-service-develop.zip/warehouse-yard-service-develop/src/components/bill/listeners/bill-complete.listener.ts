import { OnEvent } from '@nestjs/event-emitter';
import { Injectable } from '@nestjs/common';
import { BillCompleteEvent } from '../events/bill-complete.event';
import { SaleCronService } from '@components/sale/sale-cron.service';

@Injectable()
export class BillCompleteListener {
  constructor(protected readonly saleService: SaleCronService) {}
  @OnEvent('bill.complete')
  public async completeListener(event: BillCompleteEvent) {
    return await this.saleService.billCompleteEvent(event);
  }
}
