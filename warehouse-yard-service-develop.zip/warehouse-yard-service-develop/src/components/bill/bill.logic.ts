import { div, minus, mul } from '@utils/helper';
import { sum } from 'lodash';

export const calculateTotalPrice = function (
  bill,
  billDetails,
  paymentTypeDiscount,
  voucherDiscount,
  customerClassDiscount,
) {
  if (!bill) return 0;
  let totalPriceItem = 0;
  let costPrice = 0;
  let price = 0;
  const listPriceItem = [];
  billDetails.forEach((bd) => {
    const dataPrice = mul(bd.unitPrice.value, bd.quantity);
    price = minus(dataPrice, div(mul(dataPrice, bd.fee), 100));
    listPriceItem.push(price);
  });
  totalPriceItem = sum(listPriceItem);
  costPrice =
    totalPriceItem -
    div(mul(totalPriceItem, paymentTypeDiscount), 100) +
    div(mul(totalPriceItem, bill.percentageTax), 100);
  if (voucherDiscount) {
    costPrice = minus(
      costPrice,
      div(mul(totalPriceItem, voucherDiscount), 100),
    );
  }
  if (customerClassDiscount) {
    costPrice = minus(
      costPrice,
      div(mul(totalPriceItem, customerClassDiscount), 100),
    );
  }
  return div(Math.round(mul(costPrice, 100)), 100);
};
