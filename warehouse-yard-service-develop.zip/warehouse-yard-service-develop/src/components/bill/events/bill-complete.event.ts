export class BillCompleteEvent {
  totalPrice: number;
  id: number;
}
