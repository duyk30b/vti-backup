import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ApiError } from '@utils/api.error';
import { plainToClass } from 'class-transformer';
import { validate, ValidationError } from 'class-validator';
import { BillBarcodeQuery } from '../dto/request/qr-code/bill-barcode.query';

export const barcodeScanValidator = async (plain): Promise<any> => {
  const transformed = plainToClass(BillBarcodeQuery, plain);
  if (Array.isArray(transformed)) {
    return [
      transformed,
      new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        'Only accept object',
      ).toResponse(),
    ];
  }

  const errors = await validate(
    transformed,
    Object.assign({ whitelist: true }, {}),
  );
  if (errors.length) {
    return [
      transformed,
      new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        getMessage(errors),
      ).toResponse(),
    ];
  }

  return [transformed, null];
};

function getMessage(errors: ValidationError[]): string {
  const error = errors[0];
  if (!error) return 'Unknown error';

  if (!error.children || !error.children.length) {
    return Object.values(error.constraints)[0];
  }

  return getMessage(error.children);
}
