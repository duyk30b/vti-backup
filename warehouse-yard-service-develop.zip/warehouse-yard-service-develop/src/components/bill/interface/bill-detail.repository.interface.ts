import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { BillDetailEntity } from '@entities/bill/bill-detail.entity';
import { CreateBillDetailRequestDto } from '../dto/request/create-bill-detail.request.dto';
import { UpdateBillDetailRequestDto } from '../dto/request/update-bill-detail.request.dto';

export interface BillDetailRepositoryInterface
  extends BaseInterfaceRepository<BillDetailEntity> {
  createEntity(
    request: CreateBillDetailRequestDto | UpdateBillDetailRequestDto | any,
  ): BillDetailEntity;
}
