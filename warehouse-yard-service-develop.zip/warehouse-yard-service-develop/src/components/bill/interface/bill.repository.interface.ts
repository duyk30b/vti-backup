import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { BillEntity } from '@entities/bill/bill.entity';
import { SetStatusDto } from '@utils/set-status.dto';
import { CreateBillRequestDto } from '../dto/request/create-bill.request.dto';
import { GetListBillRequestDto } from '../dto/request/get-list-bill.request.dto';
import { GetRentWarehouseReportRequestDto } from '../dto/request/get-rent-warehouse-report.request.dto';
import { UpdateBillRequestDto } from '../dto/request/update-bill.request.dto';

export interface BillRepositoryInterface
  extends BaseInterfaceRepository<BillEntity> {
  getList(payload: GetListBillRequestDto, customerIds?: number[]): Promise<any>;
  createEntity(
    request: CreateBillRequestDto | UpdateBillRequestDto | any,
  ): BillEntity;
  detail(id: number): Promise<any>;
  checkBillCodeExit(code: string, billId?: number): Promise<any>;
  getRentWarehouseReport(
    request: GetRentWarehouseReportRequestDto,
    customerIds: number[],
  ): Promise<any>;
}
