import { PrintQrCodeRequestDto } from '@components/qr-code/dto/request/print.request.dto';
import { ScanQrCodeRequestDto } from '@components/qr-code/dto/request/scan.request.dto';
import { DeleteMultipleWithUserIdDto } from '@core/dto/multiple/delete-multiple-with-user-id.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ResponsePayload } from '@utils/response-payload';
import { SetStatusDto } from '@utils/set-status.dto';
import { CreateBillRequestDto } from '../dto/request/create-bill.request.dto';
import { GetListBillRequestDto } from '../dto/request/get-list-bill.request.dto';
import { GetRentWarehouseReportRequestDto } from '../dto/request/get-rent-warehouse-report.request.dto';
import { UpdateBillRequestDto } from '../dto/request/update-bill.request.dto';

export interface BillServiceInterface {
  getList(payload: GetListBillRequestDto): Promise<ResponsePayload<any>>;
  createBill(payload: CreateBillRequestDto): Promise<ResponsePayload<any>>;
  updateBill(payload: UpdateBillRequestDto): Promise<ResponsePayload<any>>;
  detail(id: number): Promise<ResponsePayload<any>>;
  confirm(request: SetStatusDto): Promise<ResponsePayload<any>>;
  reject(request: SetStatusDto): Promise<ResponsePayload<any>>;
  complete(request: SetStatusDto): Promise<ResponsePayload<any>>;
  delete(id: number): Promise<ResponsePayload<any>>;
  confirmMultiple(
    request: DeleteMultipleWithUserIdDto,
  ): Promise<ResponsePayload<any>>;
  rejectMultiple(
    request: DeleteMultipleWithUserIdDto,
  ): Promise<ResponsePayload<any>>;
  deleteMultiple(request: DeleteMultipleDto): Promise<ResponsePayload<any>>;
  getRentWarehouseReport(
    request: GetRentWarehouseReportRequestDto,
  ): Promise<ResponsePayload<any>>;
  scanQrCode(request: ScanQrCodeRequestDto): Promise<ResponsePayload<any>>;
  printQrCode(request: PrintQrCodeRequestDto): Promise<any>;
}
