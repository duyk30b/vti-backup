import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { BillResponseDto } from './bill.response.dto';

class Meta {
  @Expose()
  total: number;
}

class MetaData {
  @Expose()
  data: BillResponseDto[];

  @Expose()
  meta: Meta;
}

export class GetListBillResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: MetaData;
}
