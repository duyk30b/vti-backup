import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';

class BillResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  billDate: Date;
}

class CustomerResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ServiceResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

export class GetRentWarehouseReportResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  customerName: string;

  @ApiProperty()
  @Expose()
  billCode: string;

  @ApiProperty()
  @Expose()
  billName: string;

  @ApiProperty()
  @Expose()
  @Type(() => BillResponse)
  bill: BillResponse;

  @ApiProperty()
  @Expose()
  @Type(() => CustomerResponse)
  customer: CustomerResponse;

  @ApiProperty()
  @Expose()
  @Type(() => ServiceResponse)
  service: ServiceResponse;

  @ApiProperty()
  @Expose()
  price: number;
}
