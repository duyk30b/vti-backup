import { UnitPriceEnum } from '@components/bill/bill.constanst';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';
import { IsEnum } from 'class-validator';

class PriceAbstractResponse {
  @ApiProperty({ example: 200 })
  @Expose()
  value: number;

  @ApiProperty({ example: 1 })
  @IsEnum(UnitPriceEnum)
  @Transform((data) => Number(data.value))
  @Expose()
  unit: UnitPriceEnum;
}

class ServiceResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'abc', description: '' })
  @Expose()
  name: string;
}

export class ServiceTypeResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'abc', description: '' })
  @Expose()
  name: string;
}

class TypeUnitResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'abc', description: '' })
  @Expose()
  name: string;
}

export class RentUnitResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'abc', description: '' })
  @Expose()
  name: string;
}

export class CurrencyUnitResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'abc', description: '' })
  @Expose()
  name: string;
}

export class InvoiceTypeResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'abc', description: '' })
  @Expose()
  name: string;
}

export class VoucherResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'abc', description: '' })
  @Expose()
  name: string;
}

export class PaymentTypeResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'abc', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 20.2, description: '' })
  @Expose()
  discount: number;
}

export class BillDetailResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  serviceId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  @Type(() => ServiceResponse)
  service: ServiceResponse;

  @ApiProperty()
  @Expose()
  @Type(() => ServiceTypeResponse)
  serviceType: ServiceTypeResponse;

  @ApiProperty()
  @Expose()
  @Type(() => TypeUnitResponse)
  typeUnit: TypeUnitResponse;

  @ApiProperty()
  @Expose()
  @Type(() => PriceAbstractResponse)
  unitPrice: PriceAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => PriceAbstractResponse)
  price: PriceAbstractResponse;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  fee: number;

  @ApiProperty()
  @Expose()
  rentDurationFrom: Date;

  @ApiProperty()
  @Expose()
  rentDurationTo: Date;
}

class VendorResponse {
  @ApiProperty({ example: '', description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  name: number;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  taxNo: string;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  address: string;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  phone: string;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  bankAccount: string;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  bank: string;
}

class CustomerResponse {
  @ApiProperty({ example: '', description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  address: string;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  phone: string;
}

class CustomerLevelResponse {
  @ApiProperty({ example: '', description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  discount: number;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  code: string;
}

class CreateByUser {
  @ApiProperty({ example: '', description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  fullName: string;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  code: string;
}
export class BillResponseDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'Mua macbook', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: '001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 1, description: 'price' })
  @Expose()
  price: number;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  @Type(() => InvoiceTypeResponse)
  invoiceType: InvoiceTypeResponse;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  @Type(() => CurrencyUnitResponse)
  currencyUnit: CurrencyUnitResponse;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  @Type(() => CustomerLevelResponse)
  customerLevel: CustomerLevelResponse;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  isQr: boolean;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  totalPrice: number;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  createdByUserId: number;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  customerId: number;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  @Type(() => CreateByUser)
  createByUser: CreateByUser;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  @Type(() => VendorResponse)
  vendor: VendorResponse;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  @Type(() => CustomerResponse)
  customer: CustomerResponse;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  @Type(() => PaymentTypeResponse)
  paymentType: PaymentTypeResponse;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  note: string;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  file: string;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  percentageTax: number;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  taxNo: string;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  @Type(() => VoucherResponse)
  voucher: VoucherResponse;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  status: number;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  createdAt: Date;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: BillDetailResponse, isArray: true })
  @Expose()
  billDetails: BillDetailResponse[];

  @ApiProperty({})
  @Expose()
  serviceIds: number[];

  @ApiProperty()
  @Expose()
  customerLevelId: string;
}
