import { ApiProperty } from '@nestjs/swagger';
import { decimal } from '@utils/common';
import { Type } from 'class-transformer';
import {
  IsDateString,
  IsDecimal,
  IsInt,
  IsNotEmpty,
  IsString,
  Max,
  Min,
  ValidateNested,
} from 'class-validator';
import { PriceRequest } from './create-bill.request.dto';

export class CreateBillDetailRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  serviceId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  billId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  quantity: number;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'unitPrice' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => PriceRequest)
  unitPrice: PriceRequest;

  @ApiProperty()
  @IsNotEmpty()
  @Min(0)
  @Max(decimal(4, 2))
  fee: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsDecimal()
  price: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  rentDurationFrom: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  rentDurationTo: Date;
}
