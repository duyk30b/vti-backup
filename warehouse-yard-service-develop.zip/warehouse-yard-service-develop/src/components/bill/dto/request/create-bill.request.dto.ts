import { UnitPriceEnum } from '@components/bill/bill.constanst';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { decimal } from '@utils/common';
import { CustomFieldRequest } from '@utils/custom-field.request.dto';
import { Type } from 'class-transformer';
import {
  IsBoolean,
  IsDateString,
  IsDecimal,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  Max,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';

export class PriceRequest {
  @ApiProperty({ example: '10.00', description: 'Giá trị' })
  @IsNotEmpty()
  @IsPositive()
  @IsNumber()
  value: number;

  @ApiProperty({ example: 1, description: 'Đơn giá' })
  @IsNotEmpty()
  @IsPositive()
  @IsEnum(UnitPriceEnum)
  unit: UnitPriceEnum;
}

export class BillDetail {
  @ApiProperty({ example: 1, description: 'serviceType' })
  @IsNotEmpty()
  @IsInt()
  serviceTypeId: number;

  @ApiProperty({ example: 1, description: 'rentUnit' })
  @IsNotEmpty()
  @IsInt()
  rentUnitId: number;

  @ApiProperty({ example: 1, description: 'fee' })
  @IsNotEmpty()
  @IsDecimal()
  fee: number;

  @ApiProperty({ example: { value: 1, unit: 1 }, description: 'unitPrice' })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => PriceRequest)
  unitPrice: PriceRequest;

  @ApiProperty({ example: 1, description: 'price' })
  @IsInt()
  price: number;

  @ApiProperty({ example: 1, description: 'rentDurationFrom' })
  @IsNotEmpty()
  @IsDateString()
  rentDurationFrom: Date;

  @ApiProperty({ example: 1, description: 'rentDurationTo' })
  @IsNotEmpty()
  @IsDateString()
  rentDurationTo: Date;
}

export class CreateBillRequestDto extends BaseDto {
  @ApiProperty({ example: 'Mua mác bốc', description: 'Name' })
  @IsNotEmpty()
  @MaxLength(255)
  @IsString()
  name: string;

  @ApiProperty({ example: '001', description: 'Code' })
  @IsNotEmpty()
  @MaxLength(50)
  @IsString()
  code: string;

  @ApiProperty({ example: 1, description: 'Type Invoice' })
  @IsNotEmpty()
  @IsInt()
  invoiceTypeId: number;

  @ApiProperty({ example: 1, description: 'Currency Unit' })
  @IsNotEmpty()
  @IsInt()
  currencyUnitId: number;

  @ApiPropertyOptional({ example: true, description: 'Is QR' })
  @IsOptional()
  @IsBoolean()
  isQr: boolean;

  @ApiProperty({ example: 1, description: 'Vendor' })
  @IsNotEmpty()
  @IsInt()
  vendorId: number;

  @ApiProperty({ example: 1, description: 'Customer' })
  @IsNotEmpty()
  @IsInt()
  customerId: number;

  @ApiProperty({ example: 1, description: 'paymentType' })
  @IsNotEmpty()
  @IsInt()
  paymentTypeId: number;

  @ApiPropertyOptional({ example: 'note', description: 'note' })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  note: string;

  @ApiPropertyOptional({ example: 'taxNo', description: 'taxNo' })
  @IsOptional()
  @IsString()
  @MaxLength(20)
  taxNo: string;

  //Todo File Request
  @ApiPropertyOptional({ example: 'files', description: 'file' })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  file: string;

  @ApiPropertyOptional({
    example: 'percentageTax',
    description: 'percentageTax',
  })
  @IsOptional()
  @Min(0)
  @Max(decimal(4, 2))
  percentageTax: number;

  @ApiPropertyOptional({ example: 'voucherId', description: 'voucherId' })
  @IsOptional()
  @IsInt()
  voucherId: number;

  @ApiProperty({ type: BillDetail, isArray: true })
  billDetails: BillDetail[];

  @ApiPropertyOptional({ example: 'totalPrice', description: 'totalPrice' })
  @IsOptional()
  @IsDecimal()
  totalPrice: number;

  @ApiProperty({ example: 1, description: 'customerLevelId' })
  @IsOptional()
  @IsInt()
  customerLevelId: number;
}
