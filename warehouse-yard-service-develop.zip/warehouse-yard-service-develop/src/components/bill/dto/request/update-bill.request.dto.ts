import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CreateBillRequestDto } from './create-bill.request.dto';

export class UpdateBillRequestDto extends CreateBillRequestDto {
  @ApiProperty({ example: 1, description: 'Id' })
  @IsInt()
  @IsNotEmpty()
  id: number;
}
