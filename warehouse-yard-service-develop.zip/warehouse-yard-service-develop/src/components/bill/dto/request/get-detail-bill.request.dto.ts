import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class GetDetailBillRequestDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'id ' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
