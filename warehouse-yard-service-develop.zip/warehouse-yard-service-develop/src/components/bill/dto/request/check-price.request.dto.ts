import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class CheckPriceRequestDto extends BaseDto {
  @ApiProperty({ example: '1000.00' })
  @IsNotEmpty()
  totalPrice: number;
}
