import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CreateBillDetailRequestDto } from './create-bill-detail.request.dto';

export class UpdateBillDetailRequestDto extends CreateBillDetailRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;
}
