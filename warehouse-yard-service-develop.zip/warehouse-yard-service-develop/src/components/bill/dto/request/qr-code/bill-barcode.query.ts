import { IsNotEmpty } from 'class-validator';

export class BillBarcodeQuery {
  @IsNotEmpty()
  qrCode: string;
}
