import { PrintQrCodeRequestDto } from '@components/qr-code/dto/request/print.request.dto';
import { ScanQrCodeRequestDto } from '@components/qr-code/dto/request/scan.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { DeleteMultipleWithUserIdDto } from '@core/dto/multiple/delete-multiple-with-user-id.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Post,
  Put,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { DeleteRequestDto } from '@utils/common.request.dto';
import {
  COMPLETE_BILL_PERMISSION,
  CONFIRM_BILL_PERMISSION,
  CREATE_BILL_PERMISSION,
  DELETE_BILL_PERMISSION,
  DETAIL_BILL_PERMISSION,
  GET_RENT_WAREHOUSE_REPORT_PERMISSION,
  LIST_BILL_PERMISSION,
  REJECT_BILL_PERMISSION,
  UPDATE_BILL_PERMISSION,
} from '@utils/permissions/bill';
import { ResponsePayload } from '@utils/response-payload';
import { SetStatusDto } from '@utils/set-status.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateBillRequestDto } from './dto/request/create-bill.request.dto';
import { GetDetailBillRequestDto } from './dto/request/get-detail-bill.request.dto';
import { GetListBillRequestDto } from './dto/request/get-list-bill.request.dto';
import { GetRentWarehouseReportRequestDto } from './dto/request/get-rent-warehouse-report.request.dto';
import { UpdateBillRequestDto } from './dto/request/update-bill.request.dto';
import { BillResponseDto } from './dto/response/bill.response.dto';
import { GetListBillResponseDto } from './dto/response/get-list-bill.response.dto';
import { GetRentWarehouseReportResponseDto } from './dto/response/get-rent-warehouse-report.response';
import { BillServiceInterface } from './interface/bill.service.interface';
import { barcodeScanValidator } from './middlewares/qr-code.validator';

@Controller('bills')
export class BillController {
  constructor(
    @Inject('BillServiceInterface')
    private readonly billService: BillServiceInterface,
  ) {}

  @Post('bills/create')
  @ApiResponse({
    status: 200,
    description: 'Create Success',
    type: BillResponseDto,
  })
  @PermissionCode(CREATE_BILL_PERMISSION.code)
  @MessagePattern('create_bill')
  public async create(@Body() body: CreateBillRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.billService.createBill(request);
  }

  @Put('/bills/:id')
  @ApiResponse({
    status: 200,
    description: 'Update Success',
    type: BillResponseDto,
  })
  @PermissionCode(UPDATE_BILL_PERMISSION.code)
  @MessagePattern('update_bill')
  public async update(@Body() body: UpdateBillRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.billService.updateBill(request);
  }

  @Get('/bills/:id')
  @ApiOperation({
    tags: ['Warehouse yard'],
    summary: 'Get bill detail',
    description: 'Bill detail',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail bill successfully',
    type: BillResponseDto,
  })
  @PermissionCode(DETAIL_BILL_PERMISSION.code)
  @MessagePattern('get_bill_detail')
  public async getBillDetail(
    @Body() payload: GetDetailBillRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.billService.detail(request.id);
  }

  @Get('/bills/list')
  @ApiOperation({
    tags: ['Warehouse yard'],
    summary: 'List bill',
    description: 'Danh sách bill',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListBillResponseDto,
  })
  @PermissionCode(LIST_BILL_PERMISSION.code)
  @MessagePattern('get_list_bill')
  public async getListBill(
    @Body() payload: GetListBillRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.billService.getList(request);
  }

  @Put('/bills/:id/confirm')
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: BillResponseDto,
  })
  @PermissionCode(CONFIRM_BILL_PERMISSION.code)
  @MessagePattern('confirm_bill')
  public async confirm(@Body() body: SetStatusDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.billService.confirm(request);
  }

  @PermissionCode(CONFIRM_BILL_PERMISSION.code)
  @MessagePattern('confirm_bill_multiple')
  public async confirmMultiple(
    @Body() body: DeleteMultipleWithUserIdDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.billService.confirmMultiple(request);
  }

  @Put('/bills/:id/reject')
  @ApiResponse({
    status: 200,
    description: 'Disable successfully',
    type: BillResponseDto,
  })
  @PermissionCode(REJECT_BILL_PERMISSION.code)
  @MessagePattern('reject_bill')
  public async reject(@Body() body: SetStatusDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.billService.reject(request);
  }

  @PermissionCode(REJECT_BILL_PERMISSION.code)
  @MessagePattern('reject_bill_multiple')
  public async rejectMultiple(
    @Body() body: DeleteMultipleWithUserIdDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.billService.rejectMultiple(request);
  }

  @Put('/bills/:id/complete')
  @ApiResponse({
    status: 200,
    description: 'Complete successfully',
    type: BillResponseDto,
  })
  @PermissionCode(COMPLETE_BILL_PERMISSION.code)
  @MessagePattern('complete_bill')
  public async complete(@Body() body: SetStatusDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.billService.complete(request);
  }

  @Delete('/bills/:id')
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  @PermissionCode(DELETE_BILL_PERMISSION.code)
  @MessagePattern('delete_bill')
  public async deleteBill(
    @Body() payload: DeleteRequestDto,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.billService.delete(request.id);
  }

  @PermissionCode(DELETE_BILL_PERMISSION.code)
  @MessagePattern('delete_bill_multiple')
  public async deleteMultipleBill(
    @Body() payload: DeleteMultipleDto,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.billService.deleteMultiple(request);
  }

  @Get('/bills/reports')
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetRentWarehouseReportResponseDto,
  })
  @PermissionCode(GET_RENT_WAREHOUSE_REPORT_PERMISSION.code)
  @MessagePattern('get_rent_warehouse_reports')
  public async getRentWarehouseReport(
    @Body() payload: GetRentWarehouseReportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.billService.getRentWarehouseReport(request);
  }

  @MessagePattern('scan_qr_code')
  public async scanQrCode(@Body() payload: ScanQrCodeRequestDto): Promise<any> {
    const [request, responseError] = await barcodeScanValidator(payload);
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.billService.scanQrCode(request);
  }

  @MessagePattern('print_qr_code')
  public async printQrCode(
    @Body() payload: PrintQrCodeRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.billService.printQrCode(request);
  }
}
