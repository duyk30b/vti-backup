export enum BillStatusEnum {
  CREATED,
  CONFIRMED,
  COMPLETE,
  REJECT,
}

export const CAN_UPDATE_BILL_STATUS: any[] = [
  BillStatusEnum.CREATED,
  BillStatusEnum.REJECT,
];

export enum UnitPriceEnum {
  DAY,
  MONTH,
  QUARTER,
  YEAR,
}

export const CAN_CONFIRM_BILL_STATUS: any[] = [BillStatusEnum.CREATED];

export const CAN_REJECT_BILL_STATUS: any[] = [BillStatusEnum.CREATED];

export const CAN_COMPLETE_BILL_STATUS: any[] = [BillStatusEnum.CONFIRMED];

export const CAN_DELETE_BILL_STATUS: any[] = [
  BillStatusEnum.REJECT,
  BillStatusEnum.CREATED,
];

export const BILL_FILTER = {
  CUSTOMER: 'customer',
};

export enum ActionNotificationEnum {
  WAREHOUSE_YARD = 'GO TO WAREHOURSE',
}

export enum TypeNotificationEnum {
  MAIL = 'MAIL',
  WEB = 'WEB',
  APP = 'APP',
}

export enum MesModuleEnum {
  WMSX = '[WMSx]',
}
