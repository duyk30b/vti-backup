import { CurrencyUnitRepositoryInterface } from '@components/currency-unit/interface/currency-unit.repository.interface';
import { InvoiceTypeRepositoryInterface } from '@components/invoice-type/interface/invoice-type.repository.interface';
import { PaymentTypeRepoInterface } from '@components/payment-type/interface/payment-type.repository.interface';
import { SaleServiceInterface } from '@components/sale/interface/sale.service.interface';
import { ServiceRepositoryInterface } from '@components/service/interface/service.repository.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { VoucherRepositoryInterface } from '@components/voucher/interface/voucher.repository.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { BillEntity } from '@entities/bill/bill.entity';
import { Inject, Injectable, Logger } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { SetStatusDto } from '@utils/set-status.dto';
import { plainToClass } from 'class-transformer';
import { flatMap, isEmpty, map, orderBy, uniq } from 'lodash';
import { I18nService } from 'nestjs-i18n';
import { Connection, In } from 'typeorm';
import {
  ActionNotificationEnum,
  BillStatusEnum,
  BILL_FILTER,
  CAN_COMPLETE_BILL_STATUS,
  CAN_CONFIRM_BILL_STATUS,
  CAN_DELETE_BILL_STATUS,
  CAN_REJECT_BILL_STATUS,
  CAN_UPDATE_BILL_STATUS,
  TypeNotificationEnum,
  MesModuleEnum,
} from './bill.constanst';
import { calculateTotalPrice } from './bill.logic';
import { CreateBillDetailRequestDto } from './dto/request/create-bill-detail.request.dto';
import { CreateBillRequestDto } from './dto/request/create-bill.request.dto';
import { GetListBillRequestDto } from './dto/request/get-list-bill.request.dto';
import { GetRentWarehouseReportRequestDto } from './dto/request/get-rent-warehouse-report.request.dto';
import { UpdateBillRequestDto } from './dto/request/update-bill.request.dto';
import { BillResponseDto } from './dto/response/bill.response.dto';
import { GetRentWarehouseReportResponseDto } from './dto/response/get-rent-warehouse-report.response';
import { BillDetailRepositoryInterface } from './interface/bill-detail.repository.interface';
import { BillRepositoryInterface } from './interface/bill.repository.interface';
import { BillServiceInterface } from './interface/bill.service.interface';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { BillCompleteEvent } from './events/bill-complete.event';
import { CustomerClassRepoInterface } from '@components/customer-class/interface/customer-class.repository.interface';
import { QrCodeServiceInterface } from '@components/qr-code/interface/qr-code.service.interface';
import { PrintQrCodeRequestDto } from '@components/qr-code/dto/request/print.request.dto';
import { ScanQrCodeRequestDto } from '@components/qr-code/dto/request/scan.request.dto';
import { NotificationServiceInterface } from '@components/notification/interface/notification.service.interface';
import { PushNotificationRequestDto } from '@components/notification/dto/notification.request.dto';
import { ROLE } from '@constant/common';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { stringFormat } from '@utils/object.util';
import { DeleteMultipleWithUserIdDto } from '@core/dto/multiple/delete-multiple-with-user-id.dto';

@Injectable()
export class BillService implements BillServiceInterface {
  constructor(
    @Inject('BillRepositoryInterface')
    private readonly billRepository: BillRepositoryInterface,

    @Inject('BillDetailRepositoryInterface')
    private readonly billDetailRepository: BillDetailRepositoryInterface,

    @Inject('InvoiceTypeRepositoryInterface')
    private readonly invoiceTypeRepository: InvoiceTypeRepositoryInterface,

    @Inject('VoucherRepositoryInterface')
    private readonly voucherRepository: VoucherRepositoryInterface,

    @Inject('CurrencyUnitRepositoryInterface')
    private readonly currencyUnitRepository: CurrencyUnitRepositoryInterface,

    @Inject('PaymentTypeRepoInterface')
    private readonly paymentTypeRepository: PaymentTypeRepoInterface,

    @Inject('ServiceRepositoryInterface')
    private readonly serviceRepository: ServiceRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('NotificationServiceInterface')
    private readonly notificationService: NotificationServiceInterface,

    @Inject('SaleServiceInterface')
    private readonly saleService: SaleServiceInterface,

    @Inject('CustomerClassRepoInterface')
    private readonly customerClassRepository: CustomerClassRepoInterface,

    @Inject('QrCodeServiceInterface')
    private readonly qrCodeService: QrCodeServiceInterface,

    @InjectConnection()
    private readonly connection: Connection,

    private readonly i18n: I18nService,

    private readonly eventEmitter: EventEmitter2,
  ) {}

  async getList(request: GetListBillRequestDto): Promise<ResponsePayload<any>> {
    const filterCustomerName = request?.filter?.find(
      (i) => i.column === BILL_FILTER.CUSTOMER,
    );
    let filterCustomerIds = [];
    if (!isEmpty(filterCustomerName)) {
      filterCustomerIds = await this.saleService.getCustomerByNameKeyword(
        filterCustomerName,
        true,
      );
    }
    const { result, total } = await this.billRepository.getList(
      request,
      filterCustomerIds,
    );

    const createByUserIds = uniq(map(flatMap(result, 'createdByUserId')));
    const customerIds = uniq(map(flatMap(result, 'customerId')));
    let data = result;
    const createByUser = await this.userService.getUserByIds(
      createByUserIds,
      true,
    );
    const customerData = await this.saleService.getCustomerByIds(
      customerIds,
      true,
    );
    data = result.map((i) => ({
      ...i,
      createByUser: createByUser[i.createdByUserId] || {},
      customer: customerData[i.customerId] || {},
      serviceIds: uniq(map(flatMap(i.billDetails, 'serviceId'))),
    }));

    const dataReturn = plainToClass(BillResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
  async createBill(
    payload: CreateBillRequestDto,
  ): Promise<ResponsePayload<any>> {
    const entity = await this.billRepository.createEntity(payload);
    return await this.save(entity, payload);
  }

  async updateBill(
    payload: UpdateBillRequestDto,
  ): Promise<ResponsePayload<any>> {
    const bill = await this.billRepository.findOneById(payload.id);
    if (!bill) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    if (!CAN_UPDATE_BILL_STATUS.includes(bill.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_UPDATE_IN_CONFIRM_BILL'),
      ).toResponse();
    }
    const entity = await this.billRepository.createEntity(payload);
    return await this.save(entity, payload);
  }

  // Check And Update or Create Bill
  private async save(
    entity: BillEntity,
    request: CreateBillRequestDto | UpdateBillRequestDto | any,
  ): Promise<any> {
    let message;
    let codeResponse = ResponseCodeEnum.SUCCESS;
    const {
      name,
      code,
      vendorId,
      customerId,
      invoiceTypeId,
      currencyUnitId,
      paymentTypeId,
      billDetails,
      voucherId,
      userId,
    } = request;
    const isUpdate = entity.id !== undefined;
    //Check code or name exits
    const billCode = await this.billRepository.checkBillCodeExit(code);
    if (!isUpdate && billCode.length) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_ALREADY_EXISTS'),
      ).toResponse();
    }

    if (isUpdate && request.code !== entity.code && billCode.length) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_ALREADY_EXISTS'),
      ).toResponse();
    }

    //Check name exits
    const billName = await this.billRepository.findByCondition({ name });
    if (!isUpdate && billName.length) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.NAME_ALREADY_EXISTS'),
      ).toResponse();
    }

    if (isUpdate && request.name !== entity.name && billName.length) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.NAME_ALREADY_EXISTS'),
      ).toResponse();
    }

    //Check Invoice Type
    const invoiceType = await this.invoiceTypeRepository.findOneById(
      invoiceTypeId,
    );
    if (!invoiceType) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.INVOICE_TYPE_NOT_FOUND'),
      ).toResponse();
    }
    //Check Currency Unit
    const currencyUnit = await this.currencyUnitRepository.findOneById(
      currencyUnitId,
    );
    if (!currencyUnit) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CURRENCY_UNIT_NOT_FOUND'),
      ).toResponse();
    }
    //Check Payment Type
    const paymentType = await this.paymentTypeRepository.findOneById(
      paymentTypeId,
    );
    if (!paymentType) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.PAYMENT_TYPE_NOT_FOUND'),
      ).toResponse();
    }

    //Check Voucher
    let discountVoucher;
    if (voucherId) {
      const voucher = await this.voucherRepository.findOneById(voucherId);
      if (!voucher) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.VOUCHER_NOT_FOUND'),
        ).toResponse();
      }
      discountVoucher = voucher.percentage;
    }

    //Check Vendor(Company)
    const vendor = await this.userService.getCompanies({ id: vendorId });
    if (!vendor) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.VENDOR_NOT_FOUND'),
      ).toResponse();
    }

    //Check Customer
    const customer = await this.saleService.getCustomerById(customerId);
    if (!customer) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CUSTOMER_NOT_FOUND'),
      ).toResponse();
    }

    let discountCustomerClass;
    if (customer.customerLevelId) {
      const customerClass = await this.customerClassRepository.findOneById(
        customer.customerLevelId,
      );
      if (!customerClass) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.CUSTOMER_CLASS_NOT_FOUND'),
        ).toResponse();
      }
      discountCustomerClass = customerClass.discount;
    }
    //Check BillDetails Not Found
    if (billDetails && billDetails.length > 0) {
      const serviceIds = billDetails.map((e) => e.serviceId);
      const service = await this.serviceRepository.findWithRelations({
        where: {
          id: In(serviceIds),
        },
      });
      if (serviceIds.length !== service.length) {
        const serviceIdsExist = service.map((e) => e.id);
        return new ResponseBuilder({
          invalidDetail: billDetails.filter(
            (e) => !serviceIdsExist.includes(e.serviceId),
          ),
        })
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.SERVICE_NOT_FOUND'))
          .build();
      }
    }
    const costPrice = calculateTotalPrice(
      entity,
      billDetails,
      paymentType.discount,
      discountVoucher || undefined,
      discountCustomerClass || undefined,
    );
    entity.totalPrice = costPrice;

    //Check if status === REJECT => update status to CONFIRMED
    if (isUpdate) {
      const bill = await this.billRepository.findOneById(entity.id);
      if (bill.status === BillStatusEnum.REJECT) {
        entity.status = BillStatusEnum.CREATED;
      }
    }
    const user = await this.userService.getUserById(userId);
    const userIds = await this.getListUserByRoles(user.userRoleSettings || []);
    //Transaction
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    let result;
    try {
      result = await queryRunner.manager.save(entity);
      if (isUpdate) {
        const billDetails = await this.billDetailRepository.findWithRelations({
          where: {
            billId: entity.id,
          },
        });
        await queryRunner.manager.remove(billDetails);
      }
      if (billDetails.length) {
        const billDetailEntities = [];
        billDetails.forEach((bd) => {
          const request = new CreateBillDetailRequestDto();
          request.billId = result.id;
          request.serviceId = bd.serviceId;
          request.unitPrice = bd.unitPrice;
          request.fee = bd.fee;
          request.price = bd.price;
          request.rentDurationFrom = bd.rentDurationFrom;
          request.quantity = bd.quantity;
          request.rentDurationTo = bd.rentDurationTo;
          billDetailEntities.push(
            this.billDetailRepository.createEntity(request),
          );
        });

        const response = await queryRunner.manager.save(billDetailEntities);
        result.billDetails = response;
        await queryRunner.commitTransaction();
        if (!isUpdate) {
          const notificationRequest = new PushNotificationRequestDto();
          notificationRequest.title =
            MesModuleEnum.WMSX +
            ` ${
              user.username +
              (await this.i18n.translate('error.BILL_CREATED_NOTIFICATION')) +
              result.name
            }`;
          notificationRequest.type = TypeNotificationEnum.WEB;
          notificationRequest.action = ActionNotificationEnum.WAREHOUSE_YARD;
          notificationRequest.content = result.note;
          //TODO SnP waiting
          notificationRequest.templateId = '62675f887848315c26a23033';
          notificationRequest.executionDate = new Date().toISOString();
          notificationRequest.payload = {
            title: notificationRequest.title,
            content: result.note,
          };
          notificationRequest.userIds = userIds;
          const pushMail = Object.assign(notificationRequest, {
            type: TypeNotificationEnum.MAIL,
          });
          this.eventEmitter.emit('bill.created', pushMail);
          this.eventEmitter.emit('bill.created', notificationRequest);
        }
      }
    } catch (error) {
      await queryRunner.rollbackTransaction();
      codeResponse = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      message = error;
    } finally {
      await queryRunner.release();
    }
    const responseData = plainToClass(BillResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(responseData)
      .withCode(codeResponse)
      .withMessage(message)
      .build();
  }

  async detail(id: number): Promise<ResponsePayload<any>> {
    const bill = await this.billRepository.detail(id);
    if (!bill) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const vendor = await this.userService.getCompanies(
      { id: bill.vendorId },
      true,
    );
    const customer = await this.saleService.getCustomerById(bill.customerId);
    const customerLevel = await this.customerClassRepository.findOneById(
      bill.customerLevelId,
    );
    bill.vendor = vendor[bill.vendorId];
    bill.customer = customer;
    bill.customerLevel = customerLevel || {};
    const response = plainToClass(BillResponseDto, bill, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async confirm(request: SetStatusDto): Promise<ResponsePayload<any>> {
    const { id, userId } = request;
    const bill = await this.billRepository.findOneById(id);
    if (!bill) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_CONFIRM_BILL_STATUS.includes(bill.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_INVALID'),
      ).toResponse();
    }

    //Check customer class is exits
    const customer = await this.saleService.getCustomerById(bill.customerId);
    if (!customer) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CUSTOMER_NOT_FOUND'),
      ).toResponse();
    }

    //Push notification
    const user = await this.userService.getUserById(request.userId);
    const notificationRequest = new PushNotificationRequestDto();
    notificationRequest.title =
      MesModuleEnum.WMSX +
      ` ${
        user.username +
        (await this.i18n.translate('error.BILL_CONFIRM_NOTIFICATION')) +
        bill.name
      }`;
    notificationRequest.type = TypeNotificationEnum.WEB;
    notificationRequest.action = ActionNotificationEnum.WAREHOUSE_YARD;
    notificationRequest.content = bill.note;
    //TODO SnP waiting
    notificationRequest.templateId = '62675f887848315c26a23033';
    notificationRequest.executionDate = new Date().toISOString();
    notificationRequest.payload = {
      title: notificationRequest.title,
      content: bill.note,
    };
    notificationRequest.userIds = [bill.createdByUserId];
    const pushMail = Object.assign(notificationRequest, {
      type: TypeNotificationEnum.MAIL,
    });
    this.eventEmitter.emit('bill.confirm', pushMail);
    this.eventEmitter.emit('bill.confirm', notificationRequest);

    bill.approverId = userId;
    bill.approvedAt = new Date(Date.now());
    bill.status = BillStatusEnum.CONFIRMED;
    bill.customerLevelId = customer.customerLevelId;

    try {
      const result = await this.billRepository.update(bill);
      const response = plainToClass(BillResponseDto, result, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(response)
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withData(err)
        .build();
    }
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async confirmMultiple(
    request: DeleteMultipleWithUserIdDto,
  ): Promise<any> {
    const { userId } = request;
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const bills = await this.billRepository.findByCondition({
      id: In(ids),
    });

    const billIds = bills.map((bill) => bill.id);
    if (bills.length !== ids.length) {
      ids.forEach((id) => {
        if (!billIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < bills.length; i++) {
      const bill = bills[i];
      if (!CAN_CONFIRM_BILL_STATUS.includes(bill.status))
        failIdsList.push(bill.id);
    }

    const validIds = bills
      .filter((bill) => !failIdsList.includes(bill.id))
      .map((bill) => bill.id);

    const validateBills = bills.filter((voucher) =>
      validIds.includes(voucher.id),
    );

    if (!isEmpty(validateBills)) {
      validateBills.forEach((bill) => {
        bill.status = BillStatusEnum.CONFIRMED;
        bill.approverId = userId;
        bill.approvedAt = new Date(Date.now());
      });
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(BillEntity, validateBills);
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.CONFIRM_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  async reject(request: SetStatusDto): Promise<ResponsePayload<any>> {
    const { id, userId } = request;
    const bill = await this.billRepository.findOneById(id);
    if (!bill) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_REJECT_BILL_STATUS.includes(bill.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_INVALID'),
      ).toResponse();
    }

    //Push notification
    const user = await this.userService.getUserById(request.userId);
    const notificationRequest = new PushNotificationRequestDto();
    notificationRequest.title =
      MesModuleEnum.WMSX +
      ` ${
        user.username +
        (await this.i18n.translate('error.BILL_REJECT_NOTIFICATION')) +
        bill.name
      }`;
    notificationRequest.type = TypeNotificationEnum.WEB;
    notificationRequest.action = ActionNotificationEnum.WAREHOUSE_YARD;
    notificationRequest.content = bill.note;
    //TODO SnP waiting
    notificationRequest.templateId = '62675f887848315c26a23033';
    notificationRequest.executionDate = new Date().toISOString();
    notificationRequest.payload = {
      title: notificationRequest.title,
      content: bill.note,
    };
    notificationRequest.userIds = [bill.createdByUserId];
    const pushMail = Object.assign(notificationRequest, {
      type: TypeNotificationEnum.MAIL,
    });
    this.eventEmitter.emit('bill.reject', pushMail);
    this.eventEmitter.emit('bill.reject', notificationRequest);

    bill.approverId = userId;
    bill.approvedAt = new Date(Date.now());
    bill.status = BillStatusEnum.REJECT;

    const result = await this.billRepository.update(bill);
    const response = plainToClass(BillResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async rejectMultiple(
    request: DeleteMultipleWithUserIdDto,
  ): Promise<any> {
    const { userId } = request;
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const bills = await this.billRepository.findByCondition({
      id: In(ids),
    });

    const billIds = bills.map((bill) => bill.id);
    if (bills.length !== ids.length) {
      ids.forEach((id) => {
        if (!billIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < bills.length; i++) {
      const bill = bills[i];
      if (!CAN_REJECT_BILL_STATUS.includes(bill.status))
        failIdsList.push(bill.id);
    }

    const validIds = bills
      .filter((bill) => !failIdsList.includes(bill.id))
      .map((bill) => bill.id);

    const validateBills = bills.filter((voucher) =>
      validIds.includes(voucher.id),
    );

    if (!isEmpty(validateBills)) {
      validateBills.forEach((bill) => {
        bill.status = BillStatusEnum.REJECT;
        bill.approverId = userId;
        bill.approvedAt = new Date(Date.now());
      });
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(BillEntity, validateBills);
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.REJECT_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  async complete(request: SetStatusDto): Promise<ResponsePayload<any>> {
    const { id, userId } = request;
    const bill = await this.billRepository.findOneById(id);
    if (!bill) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_COMPLETE_BILL_STATUS.includes(bill.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_INVALID'),
      ).toResponse();
    }

    //Push notification
    const user = await this.userService.getUserById(request.userId);
    const notificationRequest = new PushNotificationRequestDto();
    notificationRequest.title = `${
      user.username +
      (await this.i18n.translate('error.BILL_COMPLETE_NOTIFICATION')) +
      bill.name
    }`;
    notificationRequest.type = TypeNotificationEnum.WEB;
    notificationRequest.action = ActionNotificationEnum.WAREHOUSE_YARD;
    notificationRequest.content = bill.note;
    //TODO SnP waiting
    notificationRequest.templateId = '62675f887848315c26a23033';
    notificationRequest.executionDate = new Date().toISOString();
    notificationRequest.payload = {
      title: notificationRequest.title,
      content: bill.note,
    };
    notificationRequest.userIds = [bill.createdByUserId];
    const pushMail = Object.assign(notificationRequest, {
      type: TypeNotificationEnum.MAIL,
    });
    this.eventEmitter.emit('bill.complete', pushMail);
    this.eventEmitter.emit('bill.complete', notificationRequest);

    bill.approverId = userId;
    bill.approvedAt = new Date(Date.now());
    bill.status = BillStatusEnum.COMPLETE;

    const billEvent = new BillCompleteEvent();
    billEvent.totalPrice = bill.totalPrice;
    billEvent.id = bill.customerId;
    this.eventEmitter.emit('bill.complete', billEvent);
    const result = await this.billRepository.update(bill);
    const response = plainToClass(BillResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }

  async delete(id: number): Promise<ResponsePayload<any>> {
    try {
      const bill = await this.billRepository.findOneById(id);
      if (!bill) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }

      if (!CAN_DELETE_BILL_STATUS.includes(bill.status)) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.BILL_WAS_CONFIRMED'),
        ).toResponse();
      }

      await this.billRepository.remove(bill.id);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Delete
   */
  public async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const bills = await this.billRepository.findByCondition({
      id: In(ids),
    });

    const billIds = bills.map((bill) => bill.id);
    if (bills.length !== ids.length) {
      ids.forEach((id) => {
        if (!billIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < bills.length; i++) {
      const bill = bills[i];
      if (!CAN_DELETE_BILL_STATUS.includes(bill.status))
        failIdsList.push(bill.id);
    }

    const validIds = bills
      .filter((bill) => !failIdsList.includes(bill.id))
      .map((bill) => bill.id);

    try {
      if (!isEmpty(validIds)) {
        this.billRepository.multipleRemove(validIds);
      }
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  async getRentWarehouseReport(
    request: GetRentWarehouseReportRequestDto,
  ): Promise<any> {
    const filterCustomerName = request.filter?.find(
      (item) => item.column === 'customerName',
    );
    let filterCustomerIds = [];
    const { sort } = request;
    if (!isEmpty(filterCustomerName)) {
      filterCustomerIds = await this.saleService.getCustomerByNameKeyword(
        filterCustomerName,
        true,
      );
      if (isEmpty(filterCustomerIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }
    const [data, count] = await this.billRepository.getRentWarehouseReport(
      request,
      filterCustomerIds,
    );
    const customerIds = uniq(map(flatMap(data, 'customerId')));
    let dataReport = data;
    if (customerIds.length) {
      const customerData = await this.saleService.getCustomerByIds(
        customerIds,
        true,
      );
      dataReport = data.map((i) => ({
        ...i,
        customer: customerData[i.customerId] || {},
        customerName: customerData[i.customerId]?.name,
        serviceName: i.service.name,
      }));
    }
    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order === 'ASC' ? 'asc' : 'desc';
        switch (item.column) {
          case 'customerName':
            dataReport = orderBy(dataReport, ['customerName'], order);
            break;
          case 'serviceName':
            dataReport = orderBy(dataReport, ['serviceName'], order);
          default:
            break;
        }
      });
    }
    const response = plainToClass(
      GetRentWarehouseReportResponseDto,
      dataReport,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async scanQrCode(params: ScanQrCodeRequestDto) {
    return await this.qrCodeService.scanQrCode(params);
  }

  async printQrCode(request: PrintQrCodeRequestDto): Promise<any> {
    return await this.qrCodeService.print(request);
  }

  private async getListUserByRoles(userRoleSettings: any[]): Promise<any> {
    const listCode = uniq(map(flatMap(userRoleSettings), 'code'));
    if (listCode.find((c) => c !== ROLE.EMPLOYEE)) {
      const listUserRoles = await this.userService.getUsersByRoleCodes([
        ROLE.EMPLOYEE,
      ]);
      return uniq(map(flatMap(listUserRoles, 'userId')));
    }
  }
}
