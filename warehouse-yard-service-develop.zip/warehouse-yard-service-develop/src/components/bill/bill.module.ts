import { NotificationService } from '@components/notification/notification.service';
import { QrCodeService } from '@components/qr-code/qr-code.service';
import { SaleCronService } from '@components/sale/sale-cron.service';
import { SaleModule } from '@components/sale/sale.module';
import { SaleService } from '@components/sale/sale.service';
import { ConfigService } from '@config/config.service';
import { BillDetailEntity } from '@entities/bill/bill-detail.entity';
import { BillEntity } from '@entities/bill/bill.entity';
import { CurrencyUnitEntity } from '@entities/currency-unit/currency-unit.entity';
import { CustomerClassEntity } from '@entities/customer-class/customer-class.entity';
import { InvoiceTypeEntity } from '@entities/invoice-type/invoice-type.entity';
import { PaymentTypeEntity } from '@entities/payment-type/payment-type.entity';
import { ServiceEntity } from '@entities/service/service.entity';
import { VoucherEntity } from '@entities/voucher/voucher.entity';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BillDetailRepository } from '@repositories/bill/bill-detail.repository';
import { BillRepository } from '@repositories/bill/bill.repository';
import { CurrencyUnitRepository } from '@repositories/currency-unit/currency-unit.repository';
import { CustomerClassRepo } from '@repositories/customer-class/customer-class.repository';
import { InvoiceTypeRepository } from '@repositories/invoice-type/invoice-type.repository';
import { PaymentTypeRepo } from '@repositories/payment-type/payment-type.repository';
import { ServiceRepository } from '@repositories/service/service.repository';
import { VoucherRepository } from '@repositories/voucher.repository';
import { BillController } from './bill.controller';
import { BillService } from './bill.service';
import { BillCompleteListener } from './listeners/bill-complete.listener';
import { BillListener } from './listeners/bill-notification.listener';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      BillEntity,
      BillDetailEntity,
      InvoiceTypeEntity,
      CurrencyUnitEntity,
      PaymentTypeEntity,
      ServiceEntity,
      VoucherEntity,
      CustomerClassEntity,
    ]),
    SaleModule,
    ConfigModule,
  ],
  providers: [
    {
      provide: 'BillServiceInterface',
      useClass: BillService,
    },
    {
      provide: 'BillRepositoryInterface',
      useClass: BillRepository,
    },
    {
      provide: 'ServiceRepositoryInterface',
      useClass: ServiceRepository,
    },
    {
      provide: 'BillDetailRepositoryInterface',
      useClass: BillDetailRepository,
    },
    {
      provide: 'InvoiceTypeRepositoryInterface',
      useClass: InvoiceTypeRepository,
    },
    {
      provide: 'CurrencyUnitRepositoryInterface',
      useClass: CurrencyUnitRepository,
    },
    {
      provide: 'VoucherRepositoryInterface',
      useClass: VoucherRepository,
    },
    {
      provide: 'PaymentTypeRepoInterface',
      useClass: PaymentTypeRepo,
    },
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
    {
      provide: 'CustomerClassRepoInterface',
      useClass: CustomerClassRepo,
    },
    {
      provide: 'QrCodeServiceInterface',
      useClass: QrCodeService,
    },
    {
      provide: 'SaleServiceInterface',
      useClass: SaleCronService,
    },
    SaleService,
    SaleCronService,
    BillCompleteListener,
    BillListener,
    NotificationService,
    ConfigService,
  ],
  controllers: [BillController],
})
export class BillModule {}
