import { BillService } from '@components/bill/bill.service';
import { BillEntity } from '@entities/bill/bill.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BillRepository } from '@repositories/bill/bill.repository';
import { QrCodeService } from './qr-code.service';
@Module({
  imports: [TypeOrmModule.forFeature([BillEntity])],
  providers: [
    {
      provide: 'BillRepositoryInterface',
      useClass: BillRepository,
    },
    {
      provide: 'BillServiceInterface',
      useClass: BillService,
    },
    {
      provide: 'QrCodeServiceInterface',
      useClass: QrCodeService,
    },
  ],
  controllers: [],
  exports: [
    {
      provide: 'QrCodeServiceInterface',
      useClass: QrCodeService,
    },
  ],
})
export class QrCodeModule {}
