import { BillRepositoryInterface } from '@components/bill/interface/bill.repository.interface';
import { SaleServiceInterface } from '@components/sale/interface/sale.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { PrintQrCodeRequestDto } from './dto/request/print.request.dto';
import { ScanQrCodeRequestDto } from './dto/request/scan.request.dto';
import { QrCodeServiceInterface } from './interface/qr-code.service.interface';

const startCommandChars = '^XA';
const endCommandChars = '^XZ';

@Injectable()
export class QrCodeService implements QrCodeServiceInterface {
  constructor(
    @Inject('BillRepositoryInterface')
    private readonly billRepository: BillRepositoryInterface,

    @Inject('SaleServiceInterface')
    private readonly saleService: SaleServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}
  async print(request: PrintQrCodeRequestDto): Promise<ResponsePayload<any>> {
    const { code } = request;
    const bill = await this.billRepository.findOneWithRelations({
      where: {
        code,
      },
    });
    const data: any = bill;
    const customer = await this.saleService.getCustomerById(bill.customerId);
    data.customerName = customer?.name;
    data.customerCode = customer?.code;
    if (isEmpty(data)) {
      return new ApiError(ResponseCodeEnum.NOT_FOUND).toResponse();
    }
    const result = this.formatQrCodeData(data);
    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  formatQrCodeData = async (item) => {
    const { code, totalPrice, customerCode, customerName } = item;
    return `${startCommandChars}^FT27,365^BQN,2,9^FH\^FDLA,${code}^FS^CI27^FO0,25^FB750,0,0,c,0^A@N,34,34,E:TIM000.TTF^FH^CI28^FD${code}^FS^CI27^FO250,150^FB450,100^A@N,34,34,E:TIM000.TTF^FH^CI28^FD${await this.i18n.translate(
      'file-header.billName',
    )}: ${code}\\&${await this.i18n.translate(
      'file-header.totalPrice',
    )}: ${totalPrice}\\&${await this.i18n.translate(
      'file-header.customerCode',
    )}:${customerCode}\\&${await this.i18n.translate(
      'file-header.customerName',
    )}:${customerName} ${endCommandChars}`;
  };
  async scanQrCode(
    params: ScanQrCodeRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { qrCode } = params;
    if (!qrCode) throw new Error('qr_code incorrect!');
    const data = await this.billRepository.findOneByCondition({
      code: qrCode,
    });
    if (isEmpty(data)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
