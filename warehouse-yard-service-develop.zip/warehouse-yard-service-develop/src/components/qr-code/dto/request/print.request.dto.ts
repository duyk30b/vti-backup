import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsDecimal, IsNotEmpty, IsString } from 'class-validator';

export class PrintQrCodeRequestDto extends BaseDto {
  @ApiProperty({ example: '1' })
  @IsNotEmpty()
  @IsString()
  code: string;
}
