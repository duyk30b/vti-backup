import { ResponsePayload } from '@utils/response-payload';
import { PrintQrCodeRequestDto } from '../dto/request/print.request.dto';
import { ScanQrCodeRequestDto } from '../dto/request/scan.request.dto';

export interface QrCodeServiceInterface {
  print(request: PrintQrCodeRequestDto): Promise<ResponsePayload<any>>;
  scanQrCode(params: ScanQrCodeRequestDto): Promise<ResponsePayload<any>>;
}
