import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class PaymentTypeListResponseDto {
  @ApiProperty({ example: 1, description: 'payment type id' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'payment type 1', description: 'payment type name' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'payment type code', description: 'payment type id' })
  @Expose()
  code: string;

  @ApiProperty({ example: 0, description: 'payment type name' })
  @Expose()
  status: number;

  @ApiProperty({ example: 0, description: 'discount' })
  @Expose()
  discount: number;
}
