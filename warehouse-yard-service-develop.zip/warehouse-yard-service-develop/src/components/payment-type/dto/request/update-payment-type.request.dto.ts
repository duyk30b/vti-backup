import { CreatePaymentTypeRequestDto } from './create-payment-type.request.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class UpdatePaymentTypeRequestDto extends CreatePaymentTypeRequestDto {
  @ApiProperty()
  @IsInt()
  id: number;
}
