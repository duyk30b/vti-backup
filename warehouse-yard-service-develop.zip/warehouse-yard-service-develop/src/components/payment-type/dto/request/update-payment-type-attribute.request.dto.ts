import { CreatePaymentTypeAttributeRequestDto } from './create-payment-type-attribute.request.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class UpdatePaymentTypeAttributeRequestDto extends CreatePaymentTypeAttributeRequestDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  id: number;
}
