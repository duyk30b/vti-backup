import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsDecimal,
  IsNotEmpty,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { CustomFieldRequest } from '@utils/custom-field.request.dto';
import { decimal } from '@utils/common';

export class CreatePaymentTypeRequestDto extends BaseDto {
  @ApiProperty({ example: '1234', description: 'Mã của payment types' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(50)
  code: string;

  @ApiProperty({
    example: 'payment types name',
    description: 'Ten cua payment types',
  })
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiProperty()
  @IsNotEmpty()
  @Min(0)
  @Max(decimal(5, 3))
  discount: number;

  @ApiPropertyOptional({
    example: 'description payment types',
    description: 'Mo ta cho payment types',
  })
  @IsString()
  @IsOptional()
  @MaxLength(255)
  description: string;

  @ApiProperty({ type: CustomFieldRequest, isArray: true })
  @ValidateNested()
  @IsOptional()
  customFields: CustomFieldRequest[];
}
