import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsInt } from 'class-validator';
import { CustomFieldRequest } from '@utils/custom-field.request.dto';

export class CreatePaymentTypeAttributeRequestDto extends CustomFieldRequest {
  @ApiPropertyOptional({
    example: 'Payment type id',
    description: 'Payment type id',
  })
  @IsNotEmpty()
  @IsInt()
  paymentTypeId: number;
}
