import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PaymentTypeController } from './payment-type.controller';
import { PaymentTypeService } from './payment-type.service';
import { PaymentTypeRepo } from '@repositories/payment-type/payment-type.repository';
import { PaymentTypeAttributesRepository } from '@repositories/payment-type/payment-type-attribute.repository';
import { PaymentTypeEntity } from '@entities/payment-type/payment-type.entity';
import { PaymentTypeAtrributeEntity } from '@entities/payment-type/payment-type-attribute.entity';
import { PaymentTypeImport } from './import/payment-type.import.helper';

@Module({
  imports: [
    TypeOrmModule.forFeature([PaymentTypeEntity, PaymentTypeAtrributeEntity]),
  ],
  providers: [
    {
      provide: 'PaymentTypeRepoInterface',
      useClass: PaymentTypeRepo,
    },
    {
      provide: 'PaymentTypeAttributesRepositoryInterface',
      useClass: PaymentTypeAttributesRepository,
    },
    {
      provide: 'PaymentTypeServiceInterface',
      useClass: PaymentTypeService,
    },
    {
      provide: 'PaymentTypeImport',
      useClass: PaymentTypeImport,
    },
  ],
  controllers: [PaymentTypeController],
  exports: [],
})
export class PaymentTypeModule {}
