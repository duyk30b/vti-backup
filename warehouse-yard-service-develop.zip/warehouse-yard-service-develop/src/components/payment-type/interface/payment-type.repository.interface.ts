import { CreatePaymentTypeRequestDto } from '@components/payment-type/dto/request/create-payment-type.request.dto';
import { GetPaymentTypeListRequestDto } from '@components/payment-type/dto/request/search-payment-type.request.dto';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { PaymentTypeEntity } from '@entities/payment-type/payment-type.entity';

export interface PaymentTypeRepoInterface
  extends BaseInterfaceRepository<PaymentTypeEntity> {
  createEntity(request: CreatePaymentTypeRequestDto);
  updateEntity(id: number, request: CreatePaymentTypeRequestDto);
  getList(request: GetPaymentTypeListRequestDto);
  getDetail(id: number);
  delete(id: number);
}
