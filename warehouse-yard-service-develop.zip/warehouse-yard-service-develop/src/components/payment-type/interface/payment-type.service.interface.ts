import { ResponsePayload } from '@utils/response-payload';
import { CreatePaymentTypeRequestDto } from '../dto/request/create-payment-type.request.dto';
import { UpdatePaymentTypeRequestDto } from '../dto/request/update-payment-type.request.dto';
import { GetPaymentTypeListRequestDto } from '../dto/request/search-payment-type.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { PaymentTypeResponseDto } from '../dto/response/payment-type.response.dto';
import { SetStatusRequestDto } from '@utils/common.request.dto';
import { PaymentTypeListResponseDto } from '../dto/response/payment-type-list.response.dto';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';

export interface PaymentTypeServiceInterface {
  createPaymentType(
    payload: CreatePaymentTypeRequestDto,
  ): Promise<ResponsePayload<PaymentTypeResponseDto | any>>;

  updatePaymentType(
    payload: UpdatePaymentTypeRequestDto,
  ): Promise<ResponsePayload<PaymentTypeResponseDto | any>>;

  confirmPaymentType(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<PaymentTypeResponseDto | any>>;

  deletePaymentType(
    id: number,
  ): Promise<ResponsePayload<SuccessResponse | any>>;

  confirmMultiplePaymentType(
    request: DeleteMultipleDto,
  ): Promise<ResponsePayload<PaymentTypeResponseDto | any>>;

  deleteMultiplePaymentType(
    request: DeleteMultipleDto,
  ): Promise<ResponsePayload<SuccessResponse | any>>;

  detailPaymentType(
    id: number,
  ): Promise<ResponsePayload<PaymentTypeResponseDto | any>>;

  getListPaymentType(
    payload: GetPaymentTypeListRequestDto,
  ): Promise<ResponsePayload<PaymentTypeListResponseDto | any>>;

  importPaymentType(request: FileUploadRequestDto): Promise<any>;
}
