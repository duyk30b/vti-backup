import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { PaymentTypeAtrributeEntity } from '@entities/payment-type/payment-type-attribute.entity';
import { CreatePaymentTypeAttributeRequestDto } from '../dto/request/create-payment-type-attribute.request.dto';
import { UpdatePaymentTypeAttributeRequestDto } from '../dto/request/update-payment-type-attribute.request.dto';
export interface PaymentTypeAttributesRepositoryInterface
  extends BaseInterfaceRepository<PaymentTypeAtrributeEntity> {
  createEntity(request: CreatePaymentTypeAttributeRequestDto);
  updateEntity(request: UpdatePaymentTypeAttributeRequestDto);
}
