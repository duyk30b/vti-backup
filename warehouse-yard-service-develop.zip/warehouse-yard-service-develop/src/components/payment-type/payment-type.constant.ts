export enum PaymentTypeStatusEnum {
  PENDING = 0,
  CONFIRMED = 1,
  DISABLED = 2,
}

export const CAN_UPDATE_PAYMENT_TYPE_STATUS: number[] = [
  PaymentTypeStatusEnum.PENDING,
  PaymentTypeStatusEnum.DISABLED,
];

export const CAN_DELETE_PAYMENT_TYPE_STATUS: number[] = [
  PaymentTypeStatusEnum.PENDING,
  PaymentTypeStatusEnum.DISABLED,
];

export const CAN_CONFIRM_PAYMENT_TYPE_STATUS: number[] = [
  PaymentTypeStatusEnum.PENDING,
  PaymentTypeStatusEnum.DISABLED,
];
