import { Inject, Injectable, Logger } from '@nestjs/common';
import { PaymentTypeServiceInterface } from './interface/payment-type.service.interface';
import { ResponsePayload } from '@utils/response-payload';
import { CreatePaymentTypeRequestDto } from './dto/request/create-payment-type.request.dto';
import { UpdatePaymentTypeRequestDto } from './dto/request/update-payment-type.request.dto';
import { GetPaymentTypeListRequestDto } from './dto/request/search-payment-type.request.dto';
import { SetStatusRequestDto } from '@utils/common.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { PaymentTypeResponseDto } from './dto/response/payment-type.response.dto';
import { PaymentTypeListResponseDto } from './dto/response/payment-type-list.response.dto';
import { PaymentTypeRepoInterface } from './interface/payment-type.repository.interface';
import { PaymentTypeAttributesRepositoryInterface } from './interface/payment-type-attribute.repository.interface';
import { CreatePaymentTypeAttributeRequestDto } from './dto/request/create-payment-type-attribute.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { I18nService } from 'nestjs-i18n';
import { plainToClass } from 'class-transformer';
import {
  CAN_UPDATE_PAYMENT_TYPE_STATUS,
  CAN_DELETE_PAYMENT_TYPE_STATUS,
  CAN_CONFIRM_PAYMENT_TYPE_STATUS,
  PaymentTypeStatusEnum,
} from './payment-type.constant';
import { ApiError } from '@utils/api.error';
import { PagingResponse } from '@utils/paging.response';
import { InjectConnection } from '@nestjs/typeorm';
import { Connection, Not } from 'typeorm';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { PaymentTypeImport } from './import/payment-type.import.helper';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { In } from 'typeorm';
import { isEmpty } from 'lodash';
import { stringFormat } from '@utils/object.util';
import { PaymentTypeEntity } from '@entities/payment-type/payment-type.entity';
@Injectable()
export class PaymentTypeService implements PaymentTypeServiceInterface {
  private readonly logger = new Logger(PaymentTypeService.name);
  constructor(
    @Inject('PaymentTypeRepoInterface')
    private readonly paymentTypeRepository: PaymentTypeRepoInterface,
    @Inject('PaymentTypeAttributesRepositoryInterface')
    private readonly paymentTypeAttributeRepository: PaymentTypeAttributesRepositoryInterface,
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,
    @Inject('PaymentTypeImport')
    private readonly paymentTypeImport: PaymentTypeImport,
    @InjectConnection()
    private readonly connection: Connection,
    private readonly i18n: I18nService,
  ) {}

  public async createPaymentType(
    payload: CreatePaymentTypeRequestDto,
  ): Promise<ResponsePayload<PaymentTypeResponseDto | any>> {
    const { code, name, customFields } = payload;
    const checkExistCode = await this.checkUniqueCode(code);
    const checkExistName = await this.checkUniqueName(name);

    if (checkExistCode) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_IS_ALREADY_EXISTS'))
        .build();
    }

    if (checkExistName)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NAME_ALREADY_EXISTS'))
        .build();

    const paymentTypeEntity = this.paymentTypeRepository.createEntity(payload);
    let result;

    const queryRunner = this.connection.createQueryRunner();
    queryRunner.startTransaction();
    // create payment types attributes
    try {
      result = await queryRunner.manager.save(paymentTypeEntity);

      if (customFields.length > 0) {
        const attributesEntityList = [];
        customFields.forEach((i) => {
          const attributeRequest = new CreatePaymentTypeAttributeRequestDto();
          attributeRequest.name = i.name;
          attributeRequest.value = i.value;
          attributeRequest.paymentTypeId = paymentTypeEntity.id;

          const attributeEntity =
            this.paymentTypeAttributeRepository.createEntity(attributeRequest);
          attributesEntityList.push(attributeEntity);
        });

        const response = await queryRunner.manager.save(attributesEntityList);
        result.customFields = response.map((i) => ({
          name: i.name,
          value: i.value,
        }));
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error.message)
        .build();
    }
    await queryRunner.release();

    const response = plainToClass(PaymentTypeResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  public async updatePaymentType(
    payload: UpdatePaymentTypeRequestDto,
  ): Promise<ResponsePayload<PaymentTypeResponseDto | any>> {
    const { id, code, name, customFields } = payload;
    const paymentType = await this.paymentTypeRepository.findOneById(id);

    if (!paymentType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PAYMENT_TYPE_NOT_FOUND'))
        .build();
    }

    const checkExistCode = await this.checkUniqueCode(code, id);
    const checkExistName = await this.checkUniqueName(name, id);

    if (checkExistCode) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_IS_ALREADY_EXISTS'))
        .build();
    }

    if (checkExistName)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NAME_ALREADY_EXISTS'))
        .build();

    if (!CAN_UPDATE_PAYMENT_TYPE_STATUS.includes(paymentType.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.PAYMENT_TYPE_WAS_CONFIRMED'),
      ).toResponse();
    }

    const paymentTypeEntity = this.paymentTypeRepository.updateEntity(
      id,
      payload,
    );
    let result;

    const queryRunner = this.connection.createQueryRunner();
    queryRunner.startTransaction();
    // update payment types attributes
    try {
      result = await queryRunner.manager.save(paymentTypeEntity);

      const paymentTypeAttributes =
        await this.paymentTypeAttributeRepository.findWithRelations({
          where: {
            paymentTypeId: paymentTypeEntity.id,
          },
        });
      await queryRunner.manager.remove(paymentTypeAttributes);

      if (customFields.length > 0) {
        const attributesEntityList = [];
        customFields.forEach((i) => {
          const attributeRequest = new CreatePaymentTypeAttributeRequestDto();
          attributeRequest.name = i.name;
          attributeRequest.value = i.value;
          attributeRequest.paymentTypeId = paymentTypeEntity.id;

          const attributeEntity =
            this.paymentTypeAttributeRepository.createEntity(attributeRequest);
          attributesEntityList.push(attributeEntity);
        });

        const response = await queryRunner.manager.save(attributesEntityList);
        result.customFields = response.map((i) => ({
          name: i.name,
          value: i.value,
        }));

        await queryRunner.commitTransaction();
      }
    } catch (error) {
      await queryRunner.rollbackTransaction();
      console.log(error.message);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error.message)
        .build();
    }
    await queryRunner.release();

    const response = plainToClass(PaymentTypeResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  public async deletePaymentType(
    id: number,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const paymentType = await this.paymentTypeRepository.findOneById(id);
    if (!paymentType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PAYMENT_TYPE_NOT_FOUND'))
        .build();
    }

    if (!CAN_DELETE_PAYMENT_TYPE_STATUS.includes(paymentType.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.PAYMENT_TYPE_WAS_CONFIRMED'),
      ).toResponse();
    }

    try {
      await this.paymentTypeRepository.delete(id);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Delete
   */
  public async deleteMultiplePaymentType(
    request: DeleteMultipleDto,
  ): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const paymentTypes = await this.paymentTypeRepository.findByCondition({
      id: In(ids),
    });

    const paymentTypeIds = paymentTypes.map((saleOrder) => saleOrder.id);
    if (paymentTypes.length !== ids.length) {
      ids.forEach((id) => {
        if (!paymentTypeIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < paymentTypes.length; i++) {
      const saleOrder = paymentTypes[i];
      if (!CAN_DELETE_PAYMENT_TYPE_STATUS.includes(saleOrder.status))
        failIdsList.push(saleOrder.id);
    }

    const validIds = paymentTypes
      .filter((saleOrder) => !failIdsList.includes(saleOrder.id))
      .map((saleOrder) => saleOrder.id);

    try {
      if (!isEmpty(validIds)) {
        this.paymentTypeRepository.multipleRemove(validIds);
      }
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async detailPaymentType(
    id: number,
  ): Promise<ResponsePayload<PaymentTypeResponseDto | any>> {
    const paymentType = await this.paymentTypeRepository.getDetail(id);

    if (!paymentType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PAYMENT_TYPE_NOT_FOUND'))
        .build();
    }

    const users = await this.userService.getUserByIds(
      [paymentType.createdByUserId, paymentType.latestEditedUserId],
      true,
    );

    paymentType['createdByUser'] = users[paymentType.createdByUserId];
    paymentType['latestEditedUser'] = users[paymentType.latestEditedUserId];

    const response = plainToClass(PaymentTypeResponseDto, paymentType, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }

  public async getListPaymentType(
    payload: GetPaymentTypeListRequestDto,
  ): Promise<ResponsePayload<PaymentTypeListResponseDto | any>> {
    const { result, count } = await this.paymentTypeRepository.getList(payload);

    const response = plainToClass(PaymentTypeListResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: payload.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async confirmPaymentType(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<PaymentTypeResponseDto | any>> {
    const { id } = request;
    const paymentType = await this.paymentTypeRepository.findOneById(id);
    if (!paymentType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PAYMENT_TYPE_NOT_FOUND'))
        .build();
    }

    if (!CAN_CONFIRM_PAYMENT_TYPE_STATUS.includes(paymentType.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_INVALID'),
      ).toResponse();
    }
    paymentType.status = PaymentTypeStatusEnum.CONFIRMED;
    paymentType.updatedAt = new Date(Date.now());

    const result = await this.paymentTypeRepository.update(paymentType);
    const response = plainToClass(PaymentTypeResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }

  /**
   *
   * @param payload SetOrderStatusRequestDto
   * @returns
   */
  public async confirmMultiplePaymentType(
    request: DeleteMultipleDto,
  ): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const paymentTypes = await this.paymentTypeRepository.findByCondition({
      id: In(ids),
    });

    const paymentTypeIds = paymentTypes.map((paymentType) => paymentType.id);
    if (paymentTypes.length !== ids.length) {
      ids.forEach((id) => {
        if (!paymentTypeIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < paymentTypes.length; i++) {
      const paymentType = paymentTypes[i];
      if (!CAN_CONFIRM_PAYMENT_TYPE_STATUS.includes(paymentType.status))
        failIdsList.push(paymentType.id);
    }

    const validIds = paymentTypes
      .filter((paymentType) => !failIdsList.includes(paymentType.id))
      .map((paymentType) => paymentType.id);

    const validPaymentTypes = paymentTypes.filter((paymentType) =>
      validIds.includes(paymentType.id),
    );

    if (!isEmpty(validPaymentTypes)) {
      validPaymentTypes.forEach((paymentType) => {
        paymentType.status = PaymentTypeStatusEnum.CONFIRMED;
        paymentType.updatedAt = new Date(Date.now());
      });
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(PaymentTypeEntity, validPaymentTypes);
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error?.message || error)
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.CONFIRM_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  private async checkUniqueCode(code: string, id?: number): Promise<boolean> {
    const result = await this.paymentTypeRepository.findByCondition([
      { code: code },
    ]);
    let data = [];
    if (id) {
      data = result.filter((item) => item.id !== id);
      return data.length > 0;
    }

    return result.length > 0;
  }

  private async checkUniqueName(name: string, id?: number): Promise<boolean> {
    const condition = {
      name: name,
      id: Not(id),
    };
    if (!id) delete condition.id;
    const result = await this.paymentTypeRepository.findOneByCondition(
      condition,
    );

    return !!result;
  }

  public async importPaymentType(request: FileUploadRequestDto): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
      userId: request.userId,
    } as ImportRequestDto;
    return this.paymentTypeImport.importUtil(importRequestDto);
  }
}
