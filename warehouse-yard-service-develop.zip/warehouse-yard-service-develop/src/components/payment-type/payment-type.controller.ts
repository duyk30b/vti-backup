import {
  Body,
  Controller,
  Inject,
  Post,
  Put,
  Get,
  Delete,
} from '@nestjs/common';
import { PaymentTypeServiceInterface } from './interface/payment-type.service.interface';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { MessagePattern } from '@nestjs/microservices';
import { ResponsePayload } from '@utils/response-payload';
import {
  CREATE_PAYMENT_TYPE_PERMISSION,
  UPDATE_PAYMENT_TYPE_PERMISSION,
  DELETE_PAYMENT_TYPE_PERMISSION,
  DETAIL_PAYMENT_TYPE_PERMISSION,
  LIST_PAYMENT_TYPE_PERMISSION,
  CONFIRM_PAYMENT_TYPE_PERMISSION,
  IMPORT_PAYMENT_TYPE_PERMISSION,
} from '@utils/permissions/payment-type';
import { FileUploadRequestDto } from '@core/dto/file-upload.dto';
import { CreatePaymentTypeRequestDto } from './dto/request/create-payment-type.request.dto';
import { UpdatePaymentTypeRequestDto } from './dto/request/update-payment-type.request.dto';
import { GetPaymentTypeListRequestDto } from './dto/request/search-payment-type.request.dto';
import {
  DeleteRequestDto,
  DetailRequestDto,
  SetStatusRequestDto,
} from '@utils/common.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { PaymentTypeResponseDto } from './dto/response/payment-type.response.dto';
import { PaymentTypeListResponseDto } from './dto/response/payment-type-list.response.dto';
import { isEmpty } from 'lodash';
import { ApiResponse } from '@nestjs/swagger';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';

@Controller('payment-types')
export class PaymentTypeController {
  constructor(
    @Inject('PaymentTypeServiceInterface')
    private readonly paymentTypeService: PaymentTypeServiceInterface,
  ) {}

  @Post('/payment-types')
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: PaymentTypeResponseDto,
  })
  @PermissionCode(CREATE_PAYMENT_TYPE_PERMISSION.code)
  @MessagePattern('create_payment_type')
  public async createPaymentType(
    @Body() payload: CreatePaymentTypeRequestDto,
  ): Promise<ResponsePayload<PaymentTypeResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.paymentTypeService.createPaymentType(request);
  }

  @Put('/payment-types/:id')
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: PaymentTypeResponseDto,
  })
  @PermissionCode(UPDATE_PAYMENT_TYPE_PERMISSION.code)
  @MessagePattern('update_payment_type')
  public async updatePaymentType(
    @Body() payload: UpdatePaymentTypeRequestDto,
  ): Promise<ResponsePayload<PaymentTypeResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.paymentTypeService.updatePaymentType(request);
  }

  @Put('/payment-types/:id/confirm')
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: PaymentTypeResponseDto,
  })
  @PermissionCode(CONFIRM_PAYMENT_TYPE_PERMISSION.code)
  @MessagePattern('confirm_payment_type')
  public async confirmPaymentType(
    @Body() payload: SetStatusRequestDto,
  ): Promise<ResponsePayload<PaymentTypeResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.paymentTypeService.confirmPaymentType(request);
  }

  @PermissionCode(CONFIRM_PAYMENT_TYPE_PERMISSION.code)
  @MessagePattern('confirm_payment_type_multiple')
  public async confirmMultiplePaymentType(
    @Body() payload: DeleteMultipleDto,
  ): Promise<ResponsePayload<PaymentTypeResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.paymentTypeService.confirmMultiplePaymentType(request);
  }

  @Delete('/payment-types/:id')
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  @PermissionCode(DELETE_PAYMENT_TYPE_PERMISSION.code)
  @MessagePattern('delete_payment_type')
  public async deletePaymentType(
    @Body() payload: DeleteRequestDto,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.paymentTypeService.deletePaymentType(request.id);
  }

  @PermissionCode(DELETE_PAYMENT_TYPE_PERMISSION.code)
  @MessagePattern('delete_payment_type_multiple')
  public async deleteMultiplePaymentType(
    @Body() payload: DeleteMultipleDto,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.paymentTypeService.deleteMultiplePaymentType(request);
  }

  @Get('/payment-types/:id')
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: PaymentTypeResponseDto,
  })
  @PermissionCode(DETAIL_PAYMENT_TYPE_PERMISSION.code)
  @MessagePattern('detail_payment_type')
  public async detailPaymentType(
    @Body() payload: DetailRequestDto,
  ): Promise<ResponsePayload<PaymentTypeResponseDto | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.paymentTypeService.detailPaymentType(request.id);
  }

  @Get('/payment-types/list')
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: PaymentTypeListResponseDto,
  })
  @PermissionCode(LIST_PAYMENT_TYPE_PERMISSION.code)
  @MessagePattern('list_payment_types')
  public async getListPaymentType(
    @Body() payload: GetPaymentTypeListRequestDto,
  ): Promise<ResponsePayload<PaymentTypeListResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.paymentTypeService.getListPaymentType(request);
  }

  @PermissionCode(IMPORT_PAYMENT_TYPE_PERMISSION.code)
  @MessagePattern('import_payment_type')
  public async importFactory(@Body() body: FileUploadRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.paymentTypeService.importPaymentType(request);
  }
}
