import { MigrationInterface, QueryRunner } from 'typeorm';

export class changeColumnTotalPriceInBills1651632557062
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      'ALTER Table bills ALTER COLUMN total_price TYPE DECIMAL(22,5);',
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      'ALTER Table bills ALTER COLUMN total_price TYPE DECIMAL;',
    );
  }
}
