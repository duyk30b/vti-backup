import { BillStatusEnum } from '@components/bill/bill.constanst';
import { MigrationInterface, QueryRunner, Table } from 'typeorm';

export class createBillsTable1649060173132 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'bills',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'code',
            type: 'varchar',
            length: '20',
            isUnique: true,
          },
          {
            name: 'name',
            type: 'varchar',
            length: '255',
          },
          {
            name: 'invoice_type_id',
            type: 'int',
          },
          {
            name: 'currency_unit_id',
            type: 'int',
          },
          {
            name: 'is_qr',
            type: 'boolean',
          },
          {
            name: 'vendor_id',
            type: 'int',
          },
          {
            name: 'customer_id',
            type: 'int',
          },
          {
            name: 'payment_type_id',
            type: 'int',
          },
          {
            name: 'note',
            type: 'varchar',
          },
          {
            name: 'file',
            type: 'varchar',
          },
          {
            name: 'percentage_tax',
            type: 'decimal',
            precision: 10,
            scale: 2,
          },
          {
            name: 'price_tax',
            type: 'decimal',
            precision: 10,
            scale: 2,
          },
          {
            name: 'created_at',
            type: 'timestamptz',
            default: 'now()',
          },
          {
            name: 'updated_at',
            type: 'timestamptz',
            default: 'now()',
          },
          {
            name: 'status',
            default: BillStatusEnum.CREATED,
            type: 'int',
          },
          {
            name: 'approver_id',
            type: 'int',
            isNullable: true,
          },
          {
            name: 'approved_at',
            type: 'timestamptz',
            isNullable: true,
          },
        ],
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable('bills');
  }
}
