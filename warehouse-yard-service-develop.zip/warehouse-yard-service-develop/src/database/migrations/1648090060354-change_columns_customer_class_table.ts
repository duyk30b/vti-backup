import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class changeColumnsCustomerClassTable1648090060354
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.changeColumns('customer_classes', [
      {
        oldColumn: new TableColumn({
          name: 'amount_from',
          type: 'decimal',
          precision: 10,
          scale: 3,
        }),
        newColumn: new TableColumn({
          name: 'amount_from',
          type: 'decimal',
          precision: 21,
          scale: 3,
        }),
      },
      {
        oldColumn: new TableColumn({
          name: 'amount_to',
          type: 'decimal',
          precision: 10,
          scale: 3,
        }),
        newColumn: new TableColumn({
          name: 'amount_to',
          type: 'decimal',
          precision: 21,
          scale: 3,
        }),
      },
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.changeColumns('customer_classes', [
      {
        oldColumn: new TableColumn({
          name: 'amount_from',
          type: 'decimal',
          precision: 10,
          scale: 3,
        }),
        newColumn: new TableColumn({
          name: 'amount_from',
          type: 'decimal',
          precision: 21,
          scale: 3,
        }),
      },
      {
        oldColumn: new TableColumn({
          name: 'amount_to',
          type: 'decimal',
          precision: 10,
          scale: 3,
        }),
        newColumn: new TableColumn({
          name: 'amount_to',
          type: 'decimal',
          precision: 21,
          scale: 3,
        }),
      },
    ]);
  }
}
