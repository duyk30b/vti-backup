import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class changeColumnInBillDetailTable1649316220268
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('bill_details', [
      new TableColumn({ name: 'ren_unit_id', type: 'int' }),
      new TableColumn({ name: 'service_type_id', type: 'int' }),
    ]);
    await queryRunner.addColumns('bill_details', [
      new TableColumn({
        name: 'service_id',
        type: 'int',
        isNullable: true,
      }),
      new TableColumn({
        name: 'quantity',
        type: 'int',
        isNullable: true,
        default: 0,
      }),
    ]);
    await queryRunner.query(
      'Alter table bill_details alter column unit_price type json using to_jsonb(unit_price)::json;',
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumns('bill_details', [
      new TableColumn({ name: 'ren_unit_id', type: 'int' }),
      new TableColumn({ name: 'service_type_id', type: 'int' }),
    ]);
    await queryRunner.dropColumns('bill_details', [
      new TableColumn({
        name: 'service_id',
        type: 'int',
      }),
      new TableColumn({
        name: 'quantity',
        type: 'int',
        isNullable: true,
        default: 0,
      }),
    ]);
    await queryRunner.query(
      'ALTER TABLE bill_details ALTER COLUMN unit_price TYPE decimal',
    );
  }
}
