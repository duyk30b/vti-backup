import { ServiceStatusEnum } from '@components/service/service.constant';
import {
  MigrationInterface,
  QueryRunner,
  Table,
  TableForeignKey,
} from 'typeorm';

export class createServiceTable1645499796703 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'services',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'code',
            type: 'varchar',
            length: '50',
            isUnique: true,
          },
          {
            name: 'name',
            type: 'varchar',
            length: '255',
          },
          {
            name: 'description',
            type: 'varchar',
            length: '255',
            isNullable: true,
          },
          {
            name: 'status',
            type: 'int',
            default: ServiceStatusEnum.CREATED,
          },
          {
            name: 'price_per_day',
            type: 'decimal',
            precision: 10,
            scale: 2,
            default: 0,
          },
          {
            name: 'price_per_month',
            type: 'decimal',
            precision: 10,
            scale: 2,
            default: 0,
          },
          {
            name: 'price_per_quarter',
            type: 'decimal',
            precision: 10,
            scale: 2,
            default: 0,
          },
          {
            name: 'price_per_year',
            type: 'decimal',
            precision: 10,
            scale: 2,
            default: 0,
          },
          {
            name: 'created_at',
            type: 'timestamptz',
            default: 'now()',
          },
          {
            name: 'updated_at',
            type: 'timestamptz',
            default: 'now()',
          },
          {
            name: 'currency_unit_id',
            type: 'int',
          },
          {
            name: 'rent_unit_id',
            type: 'int',
          },
          {
            name: 'service_type_id',
            type: 'int',
          },
          {
            name: 'created_by_user_id',
            type: 'int',
          },
          {
            name: 'lastest_edited_user_id',
            type: 'int',
          },
        ],
      }),
    );

    await queryRunner.createForeignKey(
      'services',
      new TableForeignKey({
        columnNames: ['currency_unit_id'],
        referencedColumnNames: ['id'],
        referencedTableName: 'currency_units',
      }),
    );

    await queryRunner.createForeignKey(
      'services',
      new TableForeignKey({
        columnNames: ['rent_unit_id'],
        referencedColumnNames: ['id'],
        referencedTableName: 'rent_units',
      }),
    );

    await queryRunner.createForeignKey(
      'services',
      new TableForeignKey({
        columnNames: ['service_type_id'],
        referencedColumnNames: ['id'],
        referencedTableName: 'service_types',
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const table = await queryRunner.getTable('services');
    const foreignKey = table.foreignKeys.find(
      (fk) => fk.columnNames.indexOf('currency_unit_id') !== -1,
    );
    await queryRunner.dropForeignKey('services', foreignKey);
    const foreignKey2 = table.foreignKeys.find(
      (fk) => fk.columnNames.indexOf('rent_unit_id') !== -1,
    );
    await queryRunner.dropForeignKey('services', foreignKey2);
    const foreignKey3 = table.foreignKeys.find(
      (fk) => fk.columnNames.indexOf('service_type_id') !== -1,
    );
    await queryRunner.dropForeignKey('services', foreignKey3);
    await queryRunner.dropTable('services');
  }
}
