import {
  MigrationInterface,
  QueryRunner,
  Table,
  TableForeignKey,
} from 'typeorm';

export class createRentUnitAttributeTable1644810560200
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'rent_unit_attributes',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'value',
            type: 'text',
            isNullable: true,
          },
          {
            name: 'name',
            type: 'varchar',
            length: '255',
          },
          {
            name: 'rent_unit_id',
            type: 'int',
          },
        ],
      }),
    );
    await queryRunner.createForeignKey(
      'rent_unit_attributes',
      new TableForeignKey({
        columnNames: ['rent_unit_id'],
        referencedColumnNames: ['id'],
        referencedTableName: 'rent_units',
        onDelete: 'CASCADE',
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable('rent_unit_attributes');
  }
}
