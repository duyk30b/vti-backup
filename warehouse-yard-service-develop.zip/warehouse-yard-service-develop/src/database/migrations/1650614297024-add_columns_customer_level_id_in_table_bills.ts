import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addColumnsCustomerLevelIdInTableBills1650614297024
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumn(
      'bills',
      new TableColumn({
        name: 'customer_level_id',
        type: 'int',
        isNullable: true,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn(
      'bills',
      new TableColumn({
        name: 'customer_level_id',
        type: 'int',
        isNullable: true,
      }),
    );
  }
}
