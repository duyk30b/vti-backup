import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addColumnsRentUnitTable1645672283424
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('TRUNCATE TABLE "rent_units" CASCADE');
    await queryRunner.changeColumn(
      'rent_units',
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '20',
        isUnique: true,
      }),
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '50',
        isUnique: true,
      }),
    );
    return await queryRunner.addColumns('rent_units', [
      new TableColumn({
        name: 'created_by_user_id',
        type: 'int',
      }),
      new TableColumn({
        name: 'lastest_edited_user_id',
        type: 'int',
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.changeColumn(
      'rent_units',
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '50',
        isUnique: true,
      }),
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '20',
        isUnique: true,
      }),
    );
    return await queryRunner.dropColumns('rent_units', [
      new TableColumn({
        name: 'created_by_user_id',
        type: 'int',
      }),
      new TableColumn({
        name: 'lastest_edited_user_id',
        type: 'int',
      }),
    ]);
  }
}
