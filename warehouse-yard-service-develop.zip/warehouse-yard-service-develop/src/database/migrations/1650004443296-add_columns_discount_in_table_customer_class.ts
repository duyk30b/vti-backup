import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addColumnsDiscountInTableCustomerClass1650004443296
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumn(
      'customer_classes',
      new TableColumn({
        name: 'discount',
        type: 'decimal',
        precision: 10,
        scale: 2,
        default: 0,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn(
      'customer_classes',
      new TableColumn({
        name: 'discount',
        type: 'decimal',
        precision: 10,
        scale: 2,
        default: 0,
      }),
    );
  }
}
