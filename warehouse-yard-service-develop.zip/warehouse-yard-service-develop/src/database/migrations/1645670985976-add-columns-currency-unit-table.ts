import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addColumnsCurrencyUnitTable1645670985976
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('TRUNCATE TABLE "currency_units" CASCADE');
    await queryRunner.changeColumn(
      'currency_units',
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '20',
        isUnique: true,
      }),
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '50',
        isUnique: true,
      }),
    );
    return await queryRunner.addColumns('currency_units', [
      new TableColumn({
        name: 'created_by_user_id',
        type: 'int',
      }),
      new TableColumn({
        name: 'lastest_edited_user_id',
        type: 'int',
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.changeColumn(
      'currency_units',
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '50',
        isUnique: true,
      }),
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '20',
        isUnique: true,
      }),
    );
    return await queryRunner.dropColumns('currency_units', [
      new TableColumn({
        name: 'created_by_user_id',
        type: 'int',
      }),
      new TableColumn({
        name: 'lastest_edited_user_id',
        type: 'int',
      }),
    ]);
  }
}
