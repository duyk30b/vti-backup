import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class alterCustomerClassesAmountFromTo1646105373077
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.changeColumns('customer_classes', [
      {
        oldColumn: new TableColumn({
          name: 'amount_from',
          type: 'decimal',
          length: '10,2',
        }),
        newColumn: new TableColumn({
          name: 'amount_from',
          type: 'decimal',
          length: '10,3',
        }),
      },
      {
        oldColumn: new TableColumn({
          name: 'amount_to',
          type: 'decimal',
          length: '10,2',
        }),
        newColumn: new TableColumn({
          name: 'amount_to',
          type: 'decimal',
          length: '10,3',
        }),
      },
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.changeColumns('customer_classes', [
      {
        oldColumn: new TableColumn({
          name: 'amount_from',
          type: 'decimal',
          length: '10,2',
        }),
        newColumn: new TableColumn({
          name: 'amount_from',
          type: 'decimal',
          length: '10,3',
        }),
      },
      {
        oldColumn: new TableColumn({
          name: 'amount_to',
          type: 'decimal',
          length: '10,2',
        }),
        newColumn: new TableColumn({
          name: 'amount_to',
          type: 'decimal',
          length: '10,3',
        }),
      },
    ]);
  }
}
