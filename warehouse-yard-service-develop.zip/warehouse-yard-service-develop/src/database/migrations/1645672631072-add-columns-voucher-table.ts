import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addColumnsVoucherTable1645672631072 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('TRUNCATE TABLE "vouchers" CASCADE');
    await queryRunner.changeColumn(
      'vouchers',
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '20',
        isUnique: true,
      }),
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '50',
        isUnique: true,
      }),
    );
    return await queryRunner.addColumns('vouchers', [
      new TableColumn({
        name: 'created_by_user_id',
        type: 'int',
      }),
      new TableColumn({
        name: 'lastest_edited_user_id',
        type: 'int',
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.changeColumn(
      'vouchers',
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '50',
        isUnique: true,
      }),
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '20',
        isUnique: true,
      }),
    );
    return await queryRunner.dropColumns('vouchers', [
      new TableColumn({
        name: 'created_by_user_id',
        type: 'int',
      }),
      new TableColumn({
        name: 'lastest_edited_user_id',
        type: 'int',
      }),
    ]);
  }
}
