import {
  MigrationInterface,
  QueryRunner,
  Table,
  TableForeignKey,
} from 'typeorm';

export class createTableVoucherAttributes1644832872864
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'voucher_attributes',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'value',
            type: 'text',
          },
          {
            name: 'name',
            type: 'varchar',
            length: '255',
          },
          {
            name: 'voucher_id',
            type: 'int',
          },
        ],
      }),
    );
    return await queryRunner.createForeignKey(
      'voucher_attributes',
      new TableForeignKey({
        columnNames: ['voucher_id'],
        referencedTableName: 'vouchers',
        referencedColumnNames: ['id'],
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const table = await queryRunner.getTable('voucher_attributes');
    const voucherAttributeForeignKey = table.foreignKeys.find(
      (fk) => fk.columnNames.indexOf('voucher_id') !== -1,
    );
    await queryRunner.dropForeignKey(
      'voucher_attributes',
      voucherAttributeForeignKey,
    );
    return await queryRunner.dropTable('voucher_attributes');
  }
}
