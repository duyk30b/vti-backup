import {
  MigrationInterface,
  QueryRunner,
  Table,
  TableForeignKey,
} from 'typeorm';

export class createServiceAttributeTable1645499819307
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'service_attributes',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'value',
            type: 'text',
            isNullable: true,
          },
          {
            name: 'name',
            type: 'varchar',
            length: '255',
          },
          {
            name: 'service_id',
            type: 'int',
          },
        ],
      }),
    );
    await queryRunner.createForeignKey(
      'service_attributes',
      new TableForeignKey({
        columnNames: ['service_id'],
        referencedColumnNames: ['id'],
        referencedTableName: 'services',
        onDelete: 'CASCADE',
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const table = await queryRunner.getTable('service_attributes');
    const foreignKey = table.foreignKeys.find(
      (fk) => fk.columnNames.indexOf('service_id') !== -1,
    );
    await queryRunner.dropForeignKey('service_attributes', foreignKey);
    await queryRunner.dropTable('service_attributes');
  }
}
