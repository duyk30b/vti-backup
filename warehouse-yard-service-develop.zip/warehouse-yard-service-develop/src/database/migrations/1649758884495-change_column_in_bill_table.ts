import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class changeColumnInBillTable1649758884495
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumns('bills', [
      new TableColumn({
        name: 'total_price',
        type: 'decimal',
        isNullable: true,
        default: 0,
      }),
      new TableColumn({
        name: 'tax_no',
        type: 'varchar',
        isNullable: true,
        length: '20',
      }),
      new TableColumn({
        name: 'created_by_user_id',
        type: 'int',
        isNullable: true,
      }),
      new TableColumn({
        name: 'latest_edited_user_id',
        type: 'int',
        isNullable: true,
      }),
      new TableColumn({
        name: 'voucher_id',
        type: 'int',
        isNullable: true,
      }),
    ]);
    await queryRunner.dropColumns('bills', [
      new TableColumn({
        name: 'price_tax',
        type: 'decimal',
        precision: 10,
        scale: 2,
      }),
    ]);
    await queryRunner.query(
      'ALTER TABLE bills ALTER COLUMN file DROP NOT NULL',
    );
    await queryRunner.query(
      'ALTER TABLE bills ALTER COLUMN note DROP NOT NULL',
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('bills', [
      new TableColumn({
        name: 'total_price',
        type: 'decimal',
        isNullable: true,
        default: 0,
      }),
      new TableColumn({
        name: 'tax_no',
        type: 'varchar',
        isNullable: true,
        length: '20',
      }),
      new TableColumn({
        name: 'created_by_user_id',
        type: 'int',
        isNullable: true,
      }),
      new TableColumn({
        name: 'latest_edited_user_id',
        type: 'int',
        isNullable: true,
      }),
      new TableColumn({
        name: 'voucher_id',
        type: 'int',
        isNullable: true,
      }),
    ]);
    await queryRunner.query(
      'ALTER TABLE bills ALTER COLUMN file SET NOT NULL;',
    );
    await queryRunner.query('ALTER TABLE bills ALTER COLUMN note SET NOT NULL');
    await queryRunner.addColumns('bills', [
      new TableColumn({
        name: 'price_tax',
        type: 'decimal',
        precision: 10,
        scale: 2,
      }),
    ]);
  }
}
