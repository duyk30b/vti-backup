import { MigrationInterface, QueryRunner, Table } from 'typeorm';

export class createBillDetailsTable1649060201194 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'bill_details',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'service_type_id',
            type: 'int',
          },
          {
            name: 'ren_unit_id',
            type: 'int',
          },
          {
            name: 'bill_id',
            type: 'int',
          },
          {
            name: 'unit_price',
            type: 'decimal',
            precision: 10,
            scale: 2,
          },
          {
            name: 'fee',
            precision: 10,
            scale: 2,
            type: 'decimal',
            isNullable: true,
          },
          {
            name: 'price',
            precision: 10,
            scale: 2,
            type: 'decimal',
          },
          {
            name: 'rent_duration_from',
            type: 'timestamptz',
            isNullable: true,
          },
          {
            name: 'rent_duration_to',
            type: 'timestamptz',
            isNullable: true,
          },
          {
            name: 'created_at',
            type: 'timestamptz',
            default: 'now()',
          },
          {
            name: 'updated_at',
            type: 'timestamptz',
            default: 'now()',
          },
        ],
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable('bill_details');
  }
}
