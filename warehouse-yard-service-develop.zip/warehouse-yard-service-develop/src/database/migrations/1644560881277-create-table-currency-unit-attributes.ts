import {
  MigrationInterface,
  QueryRunner,
  Table,
  TableForeignKey,
} from 'typeorm';

export class createTableCurrencyUnitAttributes1644560881277
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'currency_unit_attributes',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'value',
            type: 'text',
            isNullable: true,
          },
          {
            name: 'name',
            type: 'varchar',
            length: '255',
          },
          {
            name: 'currency_unit_id',
            type: 'int',
          },
        ],
      }),
    );
    await queryRunner.createForeignKey(
      'currency_unit_attributes',
      new TableForeignKey({
        columnNames: ['currency_unit_id'],
        referencedColumnNames: ['id'],
        referencedTableName: 'currency_units',
        onDelete: 'CASCADE',
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable('currency_unit_attributes');
  }
}
