import { MigrationInterface, QueryRunner } from 'typeorm';

export class changeTypeColumnInTablePaymentTypes1651811427217
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      'ALTER Table payment_types ALTER COLUMN discount TYPE DECIMAL(10,3);',
    );
    await queryRunner.query(
      'ALTER Table payment_types ALTER COLUMN discount  SET DEFAULT 0;',
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      'ALTER Table payment_types ALTER COLUMN discount TYPE DECIMAL(10,2);',
    );
    await queryRunner.query(
      'ALTER TABLE payment_types ALTER COLUMN discount DROP DEFAULT;',
    );
  }
}
