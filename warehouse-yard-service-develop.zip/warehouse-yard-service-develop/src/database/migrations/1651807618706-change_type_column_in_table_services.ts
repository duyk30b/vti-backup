import { MigrationInterface, QueryRunner } from 'typeorm';

export class changeTypeColumnInTableServices1651807618706
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      'ALTER Table services ALTER COLUMN price_per_day TYPE DECIMAL(13,3);',
    );
    await queryRunner.query(
      'ALTER Table services ALTER COLUMN price_per_month TYPE DECIMAL(13,3);',
    );
    await queryRunner.query(
      'ALTER Table services ALTER COLUMN price_per_quarter TYPE DECIMAL(13,3);',
    );
    await queryRunner.query(
      'ALTER Table services ALTER COLUMN price_per_year TYPE DECIMAL(13,3);',
    );
    await queryRunner.query(
      'ALTER Table services ALTER COLUMN price_per_year  SET DEFAULT 0;',
    );
    await queryRunner.query(
      'ALTER Table services ALTER COLUMN price_per_quarter  SET DEFAULT 0;',
    );
    await queryRunner.query(
      'ALTER Table services ALTER COLUMN price_per_month  SET DEFAULT 0;',
    );
    await queryRunner.query(
      'ALTER Table services ALTER COLUMN price_per_day  SET DEFAULT 0;',
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      'ALTER Table services ALTER COLUMN price_per_day TYPE DECIMAL(10,2);',
    );
    await queryRunner.query(
      'ALTER Table services ALTER COLUMN price_per_month TYPE DECIMAL(10,2);',
    );
    await queryRunner.query(
      'ALTER Table services ALTER COLUMN price_per_quarter TYPE DECIMAL(10,2);',
    );
    await queryRunner.query(
      'ALTER Table services ALTER COLUMN price_per_year TYPE DECIMAL(10,2);',
    );
    await queryRunner.query(
      'ALTER TABLE services ALTER COLUMN price_per_year DROP DEFAULT;',
    );
    await queryRunner.query(
      'ALTER TABLE services ALTER COLUMN price_per_quarter DROP DEFAULT;',
    );
    await queryRunner.query(
      'ALTER TABLE services ALTER COLUMN price_per_month DROP DEFAULT;',
    );
    await queryRunner.query(
      'ALTER TABLE services ALTER COLUMN price_per_day DROP DEFAULT;',
    );
  }
}
