import {
  MigrationInterface,
  QueryRunner,
  Table,
  TableForeignKey,
} from 'typeorm';

export class createCustomerClassesTable1644913965619
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'customer_classes',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'code',
            type: 'varchar',
            length: '20',
            isUnique: true,
          },
          {
            name: 'name',
            type: 'varchar',
            length: '255',
          },
          {
            name: 'description',
            type: 'varchar',
            length: '255',
            isNullable: true,
          },
          {
            name: 'status',
            type: 'int',
            default: 0,
          },
          {
            name: 'min_joined_days',
            type: 'int',
          },
          {
            name: 'max_joined_days',
            type: 'int',
          },
          {
            name: 'amount_from',
            type: 'decimal',
            length: '10,2',
          },
          {
            name: 'amount_to',
            type: 'decimal',
            length: '10,2',
          },
          {
            name: 'created_at',
            type: 'timestamptz',
            default: 'now()',
          },
          {
            name: 'updated_at',
            type: 'timestamptz',
            default: 'now()',
          },
          {
            name: 'currency_unit_id',
            type: 'int',
          },
        ],
      }),
    );

    await queryRunner.createForeignKey(
      'customer_classes',
      new TableForeignKey({
        columnNames: ['currency_unit_id'],
        referencedColumnNames: ['id'],
        referencedTableName: 'currency_units',
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable('customer_classes');
  }
}
