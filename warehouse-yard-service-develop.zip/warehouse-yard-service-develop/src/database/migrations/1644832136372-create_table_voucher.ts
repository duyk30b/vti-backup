import { VoucherStatusEnum } from '@components/voucher/voucher.constant';
import { MigrationInterface, QueryRunner, Table } from 'typeorm';

export class createTableVoucher1644832136372 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'vouchers',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'code',
            type: 'varchar',
            length: '20',
          },
          {
            name: 'name',
            type: 'varchar',
            length: '255',
          },
          {
            name: 'percentage',
            type: 'decimal',
            precision: 5,
            scale: 2,
            default: 0,
            isNullable: true,
          },
          {
            name: 'description',
            isNullable: true,
            type: 'varchar',
            length: '255',
          },
          {
            name: 'date_from',
            type: 'timestamptz',
            default: null,
          },
          {
            name: 'date_to',
            type: 'timestamptz',
            default: null,
          },
          {
            name: 'created_at',
            type: 'timestamptz',
            default: 'now()',
          },
          {
            name: 'updated_at',
            type: 'timestamptz',
            default: 'now()',
          },
          {
            name: 'status',
            default: VoucherStatusEnum.PENDING,
            type: 'int',
          },
          {
            name: 'approver_id',
            type: 'int',
            isNullable: true,
          },
          {
            name: 'approved_at',
            type: 'timestamptz',
            isNullable: true,
          },
        ],
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    return await queryRunner.dropTable('vouchers');
  }
}
