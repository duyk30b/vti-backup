import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addColumnsCustomerClassTable1645672387801
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('TRUNCATE TABLE "customer_classes" CASCADE');
    await queryRunner.changeColumn(
      'customer_classes',
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '20',
        isUnique: true,
      }),
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '50',
        isUnique: true,
      }),
    );
    return await queryRunner.addColumns('customer_classes', [
      new TableColumn({
        name: 'created_by_user_id',
        type: 'int',
      }),
      new TableColumn({
        name: 'lastest_edited_user_id',
        type: 'int',
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.changeColumn(
      'customer_classes',
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '50',
        isUnique: true,
      }),
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '20',
        isUnique: true,
      }),
    );
    return await queryRunner.dropColumns('customer_classes', [
      new TableColumn({
        name: 'created_by_user_id',
        type: 'int',
      }),
      new TableColumn({
        name: 'lastest_edited_user_id',
        type: 'int',
      }),
    ]);
  }
}
