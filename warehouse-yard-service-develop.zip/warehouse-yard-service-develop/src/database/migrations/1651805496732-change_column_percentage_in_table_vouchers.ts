import { MigrationInterface, QueryRunner } from 'typeorm';

export class changeColumnPercentageInTableVouchers1651805496732
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      'ALTER Table vouchers ALTER COLUMN percentage TYPE DECIMAL(5,3);',
    );
    await queryRunner.query(
      'ALTER Table vouchers ALTER COLUMN percentage  SET DEFAULT 0;',
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      'ALTER Table vouchers ALTER COLUMN percentage TYPE DECIMAL(5,2);',
    );
    await queryRunner.query(
      'ALTER TABLE vouchers ALTER COLUMN percentage DROP DEFAULT;',
    );
  }
}
