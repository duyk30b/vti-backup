import { NATS_WAREHOUSE_YARD, NatsConfig } from '@config/nats.config';
import { NestFactory } from '@nestjs/core';
import { Transport } from '@nestjs/microservices';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.createMicroservice(AppModule, {
    transport: Transport.NATS,
    options: {
      servers: NatsConfig().servers,
      queue: NATS_WAREHOUSE_YARD,
    },
  });

  await app.listen();
}
export const SRC_DIR = __dirname;
bootstrap();
