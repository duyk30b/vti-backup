import { PushNotificationRequestDto } from '@components/notification/dto/notification.request.dto';
import { NotificationServiceInterface } from '@components/notification/interface/notification.service.interface';

export abstract class NotificationListenerAbstract {
  protected constructor(
    protected readonly notificationService: NotificationServiceInterface,
  ) {}

  protected async pushRealtimeNotification(
    request: PushNotificationRequestDto,
  ): Promise<any> {
    await this.notificationService.pushNotification(request);
  }
}
