export abstract class ImportResultDto {
  log: string[];
  action: string;
  row: number;
  id: number;
}
