import { IsOptional } from 'class-validator';
import { DeleteMultipleDto } from './delete-multiple.dto';

export class DeleteMultipleWithUserIdDto extends DeleteMultipleDto {
  @IsOptional()
  userId: number;
}
