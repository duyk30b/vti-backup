export class BaseDto {
  request: any;

  responseError: any;
}
