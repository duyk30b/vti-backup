export class BaseModel {}
