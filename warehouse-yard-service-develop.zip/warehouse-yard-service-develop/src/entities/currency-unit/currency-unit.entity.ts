import { CurrencyUnitStatusEnum } from '@components/currency-unit/currency-unit.constant';
import { BillEntity } from '@entities/bill/bill.entity';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { CurrencyUnitAttributeEntity } from './currency-unit-attribute.entity';

@Entity({ name: 'currency_units' })
export class CurrencyUnitEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
  })
  name: string;

  @Column({
    type: 'varchar',
  })
  code: string;

  @Column({
    type: 'varchar',
  })
  description: string;

  @Column({
    type: 'enum',
    enum: CurrencyUnitStatusEnum,
    default: CurrencyUnitStatusEnum.CREATED,
  })
  status: number;

  @CreateDateColumn({
    type: 'timestamptz',
  })
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamptz',
  })
  updatedAt: Date;

  @OneToMany(
    () => CurrencyUnitAttributeEntity,
    (currencyUnitAttribute) => currencyUnitAttribute.currencyUnit,
    {
      cascade: ['insert'],
    },
  )
  @JoinColumn({ name: 'id', referencedColumnName: 'currency_unit_id' })
  currencyUnitAttributes: CurrencyUnitAttributeEntity[];

  @Column({
    type: 'int',
  })
  createdByUserId: number;

  @Column({
    type: 'int',
  })
  lastestEditedUserId: number;

  @OneToMany(() => BillEntity, (bill) => bill.currencyUnit)
  bills: BillEntity[];
}
