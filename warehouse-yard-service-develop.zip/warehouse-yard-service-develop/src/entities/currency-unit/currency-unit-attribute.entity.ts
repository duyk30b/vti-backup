import { CurrencyUnitEntity } from '@entities/currency-unit/currency-unit.entity';
import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  JoinColumn,
  ManyToOne,
} from 'typeorm';

@Entity({ name: 'currency_unit_attributes' })
export class CurrencyUnitAttributeEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
    length: 255,
  })
  name: string;

  @Column({
    type: 'int',
  })
  currencyUnitId: number;

  @Column({
    type: 'text',
    nullable: true,
  })
  value: string;

  @ManyToOne(
    () => CurrencyUnitEntity,
    (currencyUnit) => currencyUnit.currencyUnitAttributes,
    {
      cascade: ['insert'],
    },
  )
  @JoinColumn({ name: 'currency_unit_id', referencedColumnName: 'id' })
  currencyUnit: CurrencyUnitEntity;
}
