import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
  OneToMany,
  JoinColumn,
} from 'typeorm';
import { ServiceTypeStatusEnum } from '@components/service-type/service-type.constant';
import { ServiceTypeAtrributeEntity } from './service-type-attribute.entity';
import { BillDetailEntity } from '@entities/bill/bill-detail.entity';

@Entity({ name: 'service_types' })
export class ServiceTypeEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
    length: 20,
  })
  code: string;

  @Column({
    type: 'varchar',
    length: 255,
  })
  name: string;

  @Column({
    type: 'varchar',
    length: 255,
    nullable: true,
  })
  description: string;

  @Column({
    type: 'integer',
    enum: ServiceTypeStatusEnum,
    default: ServiceTypeStatusEnum.PENDING,
  })
  status: number;

  @CreateDateColumn({
    type: 'timestamptz',
  })
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamptz',
  })
  updatedAt: Date;

  @OneToMany(
    () => ServiceTypeAtrributeEntity,
    (serviceTypeAttribute) => serviceTypeAttribute.serviceTypeId,
    {
      cascade: ['insert'],
    },
  )
  @JoinColumn({ name: 'id', referencedColumnName: 'service_type_id' })
  serviceTypeAttributes: ServiceTypeAtrributeEntity[];

  @Column({
    type: 'int',
  })
  createdByUserId: number;

  @Column({
    type: 'int',
  })
  lastestEditedUserId: number;
}
