import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
  OneToMany,
  JoinColumn,
  ManyToOne,
} from 'typeorm';
import { CurrencyUnitEntity } from '@entities/currency-unit/currency-unit.entity';
import { ServiceStatusEnum } from '@components/service/service.constant';
import { RentUnitEntity } from '@entities/rent-unit/rent-unit.entity';
import { ServiceTypeEntity } from '@entities/service-type/service-type.entity';
import { ServiceAttributeEntity } from './service-attribute.entity';
import { UsedVoucherEntity } from './used-voucher.entity';
import { BillDetailEntity } from '@entities/bill/bill-detail.entity';

@Entity({ name: 'services' })
export class ServiceEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
    length: 20,
  })
  code: string;

  @Column({
    type: 'varchar',
    length: 255,
  })
  name: string;

  @Column({
    type: 'varchar',
    length: 255,
    nullable: true,
  })
  description: string;

  @Column({
    type: 'integer',
    enum: ServiceStatusEnum,
    default: ServiceStatusEnum.CREATED,
  })
  status: number;

  @Column({
    type: 'decimal',
  })
  pricePerDay: number;

  @Column({
    type: 'decimal',
  })
  pricePerMonth: number;

  @Column({
    type: 'decimal',
  })
  pricePerQuarter: number;

  @Column({
    type: 'decimal',
  })
  pricePerYear: number;

  @CreateDateColumn({
    type: 'timestamptz',
  })
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamptz',
  })
  updatedAt: Date;

  @ManyToOne(() => CurrencyUnitEntity, (currencyUnit) => currencyUnit.id, {
    cascade: ['insert'],
  })
  @JoinColumn({ name: 'currency_unit_id', referencedColumnName: 'id' })
  currencyUnitId: number;

  @ManyToOne(() => RentUnitEntity, (rentUnit) => rentUnit.id, {
    cascade: ['insert'],
  })
  @JoinColumn({ name: 'rent_unit_id', referencedColumnName: 'id' })
  rentUnitId: number;

  @ManyToOne(() => ServiceTypeEntity, (serviceType) => serviceType.id, {
    cascade: ['insert'],
  })
  @JoinColumn({ name: 'service_type_id', referencedColumnName: 'id' })
  serviceTypeId: number;

  @OneToMany(
    () => ServiceAttributeEntity,
    (serviceAttribute) => serviceAttribute.serviceId,
    {
      cascade: ['insert'],
    },
  )
  @JoinColumn({ name: 'id', referencedColumnName: 'service_id' })
  serviceAttributes: ServiceAttributeEntity[];

  @OneToMany(() => UsedVoucherEntity, (usedVoucher) => usedVoucher.serviceId, {
    cascade: ['insert'],
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'id', referencedColumnName: 'service_id' })
  usedVouchers: UsedVoucherEntity[];

  @Column({
    type: 'int',
  })
  createdByUserId: number;

  @Column({
    type: 'int',
  })
  lastestEditedUserId: number;

  @OneToMany(() => BillDetailEntity, (billDetail) => billDetail.service)
  billDetails: BillDetailEntity[];
}
