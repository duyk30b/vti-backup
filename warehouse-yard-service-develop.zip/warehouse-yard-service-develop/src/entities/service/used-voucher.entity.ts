import { VoucherEntity } from '@entities/voucher/voucher.entity';
import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  JoinColumn,
  ManyToOne,
  CreateDateColumn,
} from 'typeorm';
import { ServiceEntity } from './service.entity';

@Entity({ name: 'used_vouchers' })
export class UsedVoucherEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'int',
  })
  createdBy: number;

  @CreateDateColumn({
    type: 'timestamptz',
  })
  createdAt: Date;

  @ManyToOne(() => ServiceEntity, (service) => service.usedVouchers, {
    cascade: ['insert'],
  })
  @JoinColumn({ name: 'service_id', referencedColumnName: 'id' })
  serviceId: number;

  @ManyToOne(() => VoucherEntity, (voucher) => voucher.usedVouchers, {
    cascade: ['insert'],
  })
  @JoinColumn({ name: 'voucher_id', referencedColumnName: 'id' })
  voucherId: number;
}
