import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  JoinColumn,
  ManyToOne,
} from 'typeorm';
import { ServiceEntity } from './service.entity';

@Entity({ name: 'service_attributes' })
export class ServiceAttributeEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
    length: 255,
  })
  name: string;

  @Column({
    type: 'text',
    nullable: true,
  })
  value: string;

  @ManyToOne(() => ServiceEntity, (service) => service.serviceAttributes, {
    cascade: ['insert'],
  })
  @JoinColumn({ name: 'service_id', referencedColumnName: 'id' })
  serviceId: number;
}
