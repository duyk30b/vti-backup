import { UnitPriceEnum } from '@components/bill/bill.constanst';
import { RentUnitEntity } from '@entities/rent-unit/rent-unit.entity';
import { ServiceTypeEntity } from '@entities/service-type/service-type.entity';
import { ServiceEntity } from '@entities/service/service.entity';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { BillEntity } from './bill.entity';

@Entity({ name: 'bill_details' })
export class BillDetailEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'int',
  })
  serviceId: number;

  @Column({
    type: 'int',
  })
  billId: number;

  @Column({
    type: 'simple-json',
    default: { value: 0, unit: UnitPriceEnum.DAY },
  })
  unitPrice: { value: number; unit: number };

  @Column({
    type: 'decimal',
    nullable: true,
    precision: 10,
    scale: 2,
  })
  fee: number;

  @Column({
    type: 'int',
    nullable: true,
  })
  quantity: number;

  @Column({
    type: 'decimal',
    precision: 10,
    scale: 2,
  })
  price: number;

  @Column({
    type: 'timestamptz',
    nullable: true,
  })
  rentDurationFrom: Date;

  @Column({
    type: 'timestamptz',
    nullable: true,
  })
  rentDurationTo: Date;

  @CreateDateColumn({
    type: 'timestamptz',
  })
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamptz',
  })
  updatedAt: Date;

  @ManyToOne(() => ServiceEntity, (service) => service.billDetails)
  service: ServiceEntity;

  @ManyToOne(() => BillEntity, (bill) => bill.billDetails, {
    cascade: ['insert'],
  })
  @JoinColumn({ name: 'bill_id', referencedColumnName: 'id' })
  bill: BillEntity;
}
