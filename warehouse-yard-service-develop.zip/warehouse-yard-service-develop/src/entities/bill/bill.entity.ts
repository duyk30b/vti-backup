import { BillStatusEnum } from '@components/bill/bill.constanst';
import { CurrencyUnitEntity } from '@entities/currency-unit/currency-unit.entity';
import { InvoiceTypeEntity } from '@entities/invoice-type/invoice-type.entity';
import { VoucherEntity } from '@entities/voucher/voucher.entity';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { BillDetailEntity } from './bill-detail.entity';

@Entity({ name: 'bills' })
export class BillEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
    length: 20,
  })
  code: string;

  @Column({
    type: 'varchar',
    length: 255,
  })
  name: string;

  @Column({
    type: 'int',
  })
  invoiceTypeId: number;

  @Column({
    type: 'int',
  })
  currencyUnitId: number;

  @Column({
    type: 'bool',
  })
  isQr: boolean;

  @Column({
    type: 'int',
  })
  vendorId: number;

  @Column({
    type: 'int',
  })
  customerId: number;

  @Column({
    type: 'int',
  })
  paymentTypeId: number;

  @Column({
    type: 'int',
  })
  customerLevelId: number;

  @Column({
    type: 'varchar',
  })
  note: string;

  @Column({
    type: 'varchar',
  })
  taxNo: string;

  @Column({
    type: 'varchar',
  })
  file: string;

  @Column({
    type: 'decimal',
  })
  percentageTax: number;

  @Column({
    type: 'int',
  })
  voucherId: number;

  @Column({
    type: 'decimal',
  })
  totalPrice: number;

  @Column({
    type: 'int',
    default: BillStatusEnum.CREATED,
  })
  status: number;

  @Column({
    type: 'int',
    nullable: true,
  })
  approverId: number;

  @Column({
    type: 'timestamptz',
    nullable: true,
  })
  approvedAt: Date;

  @CreateDateColumn({
    type: 'timestamptz',
  })
  createdAt: Date;

  @Column({
    type: 'int',
  })
  createdByUserId: number;

  @Column({
    type: 'int',
  })
  latestEditedUserId: number;

  @UpdateDateColumn({
    type: 'timestamptz',
  })
  updatedAt: Date;

  @ManyToOne(() => InvoiceTypeEntity, (invoiceType) => invoiceType.bills)
  invoiceType: InvoiceTypeEntity;

  @ManyToOne(() => VoucherEntity, (voucher) => voucher.bills)
  voucher: VoucherEntity;

  @ManyToOne(() => CurrencyUnitEntity, (currencyUnit) => currencyUnit.bills)
  currencyUnit: CurrencyUnitEntity;

  @OneToMany(() => BillDetailEntity, (billDetail) => billDetail.bill, {
    cascade: ['insert'],
  })
  @JoinColumn({ name: 'id', referencedColumnName: 'billId' })
  billDetails: BillDetailEntity[];
}
