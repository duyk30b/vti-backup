import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
  OneToMany,
  JoinColumn,
} from 'typeorm';
import { PaymentTypeStatusEnum } from '@components/payment-type/payment-type.constant';
import { PaymentTypeAtrributeEntity } from './payment-type-attribute.entity';

@Entity({ name: 'payment_types' })
export class PaymentTypeEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
    length: 20,
  })
  code: string;

  @Column({
    type: 'varchar',
    length: 255,
  })
  name: string;

  @Column({
    type: 'varchar',
    length: 255,
    nullable: true,
  })
  description: string;

  @Column({
    type: 'decimal',
  })
  discount: number;

  @Column({
    type: 'integer',
    enum: PaymentTypeStatusEnum,
    default: PaymentTypeStatusEnum.PENDING,
  })
  status: number;

  @CreateDateColumn({
    type: 'timestamptz',
  })
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamptz',
  })
  updatedAt: Date;

  @OneToMany(
    () => PaymentTypeAtrributeEntity,
    (paymentTypeAttribute) => paymentTypeAttribute.paymentTypeId,
    {
      cascade: ['insert'],
    },
  )
  @JoinColumn({ name: 'id', referencedColumnName: 'payment_type_id' })
  paymentTypeAttributes: PaymentTypeAtrributeEntity[];

  @Column({
    type: 'int',
  })
  createdByUserId: number;

  @Column({
    type: 'int',
  })
  lastestEditedUserId: number;
}
