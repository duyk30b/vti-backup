import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  JoinColumn,
  ManyToOne,
} from 'typeorm';
import { PaymentTypeEntity } from './payment-type.entity';

@Entity({ name: 'payment_type_attributes' })
export class PaymentTypeAtrributeEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
    length: 255,
  })
  name: string;

  @Column({
    type: 'text',
    nullable: true,
  })
  value: string;

  @ManyToOne(
    () => PaymentTypeEntity,
    (paymentType) => paymentType.paymentTypeAttributes,
    {
      cascade: ['insert'],
    },
  )
  @JoinColumn({ name: 'payment_type_id', referencedColumnName: 'id' })
  paymentTypeId: number;
}
