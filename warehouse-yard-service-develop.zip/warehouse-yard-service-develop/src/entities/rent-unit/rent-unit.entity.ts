import { RentUnitStatusEnum } from '@components/rent-unit/rent-unit.constant';
import { BillDetailEntity } from '@entities/bill/bill-detail.entity';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { RentUnitAttributeEntity } from './rent-unit-attribute.entity';

@Entity({ name: 'rent_units' })
export class RentUnitEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
  })
  name: string;

  @Column({
    type: 'varchar',
  })
  code: string;

  @Column({
    type: 'varchar',
  })
  description: string;

  @Column({
    type: 'enum',
    enum: RentUnitStatusEnum,
    default: RentUnitStatusEnum.CREATED,
  })
  status: number;

  @CreateDateColumn({
    type: 'timestamptz',
  })
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamptz',
  })
  updatedAt: Date;

  @OneToMany(
    () => RentUnitAttributeEntity,
    (rentUnitAttribute) => rentUnitAttribute.rentUnitId,
    {
      cascade: ['insert'],
    },
  )
  @JoinColumn({ name: 'id', referencedColumnName: 'rent_unit_id' })
  rentUnitAttributes: RentUnitAttributeEntity[];

  @Column({
    type: 'int',
  })
  createdByUserId: number;

  @Column({
    type: 'int',
  })
  lastestEditedUserId: number;
}
