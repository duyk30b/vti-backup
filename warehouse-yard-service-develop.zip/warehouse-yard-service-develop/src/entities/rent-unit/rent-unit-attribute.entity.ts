import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  JoinColumn,
  ManyToOne,
} from 'typeorm';
import { RentUnitEntity } from './rent-unit.entity';

@Entity({ name: 'rent_unit_attributes' })
export class RentUnitAttributeEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
    length: 255,
  })
  name: string;

  @Column({
    type: 'text',
    nullable: true,
  })
  value: string;

  @ManyToOne(() => RentUnitEntity, (rentUnit) => rentUnit.rentUnitAttributes, {
    cascade: ['insert'],
  })
  @JoinColumn({ name: 'rent_unit_id', referencedColumnName: 'id' })
  rentUnitId: number;
}
