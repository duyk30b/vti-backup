import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  JoinColumn,
  ManyToOne,
} from 'typeorm';
import { InvoiceTypeEntity } from './invoice-type.entity';

@Entity({ name: 'invoice_type_attributes' })
export class InvoiceTypeAttributeEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
    length: 255,
  })
  name: string;

  @Column({
    type: 'text',
    nullable: true,
  })
  value: string;

  @ManyToOne(
    () => InvoiceTypeEntity,
    (InvoiceType) => InvoiceType.InvoiceTypeAttributes,
    {
      cascade: ['insert'],
    },
  )
  @JoinColumn({ name: 'invoice_type_id', referencedColumnName: 'id' })
  invoiceTypeId: number;
}
