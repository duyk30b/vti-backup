import { InvoiceTypeStatusEnum } from '@components/invoice-type/invoice-type.constant';
import { BillEntity } from '@entities/bill/bill.entity';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { InvoiceTypeAttributeEntity } from './invoice-type-attribute.entity';

@Entity({ name: 'invoice_types' })
export class InvoiceTypeEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
  })
  name: string;

  @Column({
    type: 'varchar',
  })
  code: string;

  @Column({
    type: 'varchar',
  })
  description: string;

  @Column({
    type: 'enum',
    enum: InvoiceTypeStatusEnum,
    default: InvoiceTypeStatusEnum.CREATED,
  })
  status: number;

  @CreateDateColumn({
    type: 'timestamptz',
  })
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamptz',
  })
  updatedAt: Date;

  @OneToMany(
    () => InvoiceTypeAttributeEntity,
    (InvoiceTypeAttribute) => InvoiceTypeAttribute.invoiceTypeId,
    {
      cascade: ['insert'],
    },
  )
  @JoinColumn({ name: 'id', referencedColumnName: 'invoice_type_id' })
  InvoiceTypeAttributes: InvoiceTypeAttributeEntity[];

  @Column({
    type: 'int',
  })
  createdByUserId: number;

  @Column({
    type: 'int',
  })
  lastestEditedUserId: number;

  @OneToMany(() => BillEntity, (bill) => bill.invoiceType)
  bills: BillEntity[];
}
