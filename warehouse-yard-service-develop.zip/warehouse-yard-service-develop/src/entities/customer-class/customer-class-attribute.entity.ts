import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  JoinColumn,
  ManyToOne,
} from 'typeorm';
import { CustomerClassEntity } from './customer-class.entity';

@Entity({ name: 'customer_class_attributes' })
export class CustomerClassAtrributeEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
    length: 255,
  })
  name: string;

  @Column({
    type: 'text',
    nullable: true,
  })
  value: string;

  @ManyToOne(
    () => CustomerClassEntity,
    (customerClass) => customerClass.customerClassAttributes,
    {
      cascade: ['insert'],
    },
  )
  @JoinColumn({ name: 'customer_class_id', referencedColumnName: 'id' })
  customerClassId: number;
}
