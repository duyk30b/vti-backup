import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
  OneToMany,
  JoinColumn,
  ManyToOne,
} from 'typeorm';
import { CustomerClassStatusEnum } from '@components/customer-class/customer-class.constant';
import { CustomerClassAtrributeEntity } from './customer-class-attribute.entity';
import { CurrencyUnitEntity } from '@entities/currency-unit/currency-unit.entity';

@Entity({ name: 'customer_classes' })
export class CustomerClassEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
    length: 20,
  })
  code: string;

  @Column({
    type: 'varchar',
    length: 255,
  })
  name: string;

  @Column({
    type: 'varchar',
    length: 255,
    nullable: true,
  })
  description: string;

  @Column({
    type: 'integer',
    enum: CustomerClassStatusEnum,
    default: CustomerClassStatusEnum.PENDING,
  })
  status: number;

  @Column({
    type: 'integer',
  })
  minJoinedDays: number;

  @Column({
    type: 'integer',
  })
  maxJoinedDays: number;

  @Column({
    type: 'decimal',
  })
  amountFrom: number;

  @Column({
    type: 'decimal',
  })
  amountTo: number;

  @CreateDateColumn({
    type: 'timestamptz',
  })
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamptz',
  })
  updatedAt: Date;

  @Column({
    type: 'decimal',
  })
  discount: number;

  @Column({
    type: 'int',
  })
  currencyUnitId: number;

  @ManyToOne(() => CurrencyUnitEntity, (currencyUnit) => currencyUnit.id, {
    cascade: ['insert'],
  })
  @JoinColumn({ name: 'currency_unit_id', referencedColumnName: 'id' })
  currencyUnit: CurrencyUnitEntity;

  @OneToMany(
    () => CustomerClassAtrributeEntity,
    (customerClassAttribute) => customerClassAttribute.customerClassId,
    {
      cascade: ['insert'],
    },
  )
  @JoinColumn({ name: 'id', referencedColumnName: 'customer_class_id' })
  customerClassAttributes: CustomerClassAtrributeEntity[];

  @Column({
    type: 'int',
  })
  createdByUserId: number;

  @Column({
    type: 'int',
  })
  lastestEditedUserId: number;
}
