import { VoucherEntity } from '@entities/voucher/voucher.entity';
import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';

@Entity({
  name: 'voucher_attributes',
})
export class VoucherAttributeEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
    length: 255,
  })
  name: string;

  @Column({
    type: 'text',
    nullable: true,
  })
  value: string;

  @ManyToOne(() => VoucherEntity, (voucher) => voucher.voucherAttributes, {
    cascade: ['insert'],
  })
  @JoinColumn({ name: 'voucher_id', referencedColumnName: 'id' })
  voucherId: number;
}
