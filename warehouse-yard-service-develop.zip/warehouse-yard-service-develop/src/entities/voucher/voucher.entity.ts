import { VoucherStatusEnum } from '@components/voucher/voucher.constant';
import { BillEntity } from '@entities/bill/bill.entity';
import { UsedVoucherEntity } from '@entities/service/used-voucher.entity';
import { VoucherAttributeEntity } from '@entities/voucher/voucher-attribute.entity';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity({ name: 'vouchers' })
export class VoucherEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column()
  code: string;

  @Column()
  name: string;

  @Column({
    type: 'decimal',
  })
  percentage: number;

  @Column()
  description: string;

  @Column({
    type: 'timestamptz',
  })
  dateFrom: Date;

  @Column({
    type: 'timestamptz',
  })
  dateTo: Date;

  @UpdateDateColumn({
    type: 'timestamptz',
  })
  updatedAt: Date;

  @CreateDateColumn({
    type: 'timestamptz',
  })
  createdAt: Date;

  @Column({
    type: 'enum',
    enum: VoucherStatusEnum,
    default: VoucherStatusEnum.PENDING,
  })
  status: number;

  @Column({
    type: 'int',
    nullable: true,
  })
  approverId: number;

  @Column({
    type: 'timestamptz',
    nullable: true,
  })
  approvedAt: Date;

  @OneToMany(
    () => VoucherAttributeEntity,
    (voucherAttribute) => voucherAttribute.voucherId,
    {
      cascade: ['insert'],
    },
  )
  @JoinColumn({ name: 'id', referencedColumnName: 'payment_type_id' })
  voucherAttributes: VoucherAttributeEntity[];

  @OneToMany(() => UsedVoucherEntity, (usedVoucher) => usedVoucher.voucherId, {
    cascade: ['insert'],
  })
  @JoinColumn({ name: 'id', referencedColumnName: 'voucher_id' })
  usedVouchers: UsedVoucherEntity[];

  @OneToMany(() => BillEntity, (bill) => bill.voucher)
  bills: BillEntity[];

  @Column({
    type: 'int',
  })
  createdByUserId: number;

  @Column({
    type: 'int',
  })
  lastestEditedUserId: number;
}
