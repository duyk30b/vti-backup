import { FORMAT_CODE_PERMISSION } from '@constant/common';
import { StatusPermission } from '@constant/common';

export const CUSTOMER_CLASS_GROUP_PERMISSION = {
  name: 'Định nghĩa hạng khách hàng',
  code: FORMAT_CODE_PERMISSION + 'CUSTOMER_CLASS_GROUP',
  status: StatusPermission.ACTIVE,
};

const STATUS = StatusPermission.ACTIVE;
const GROUP = CUSTOMER_CLASS_GROUP_PERMISSION.code;

export const CREATE_CUSTOMER_CLASS_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'CREATE_CUSTOMER_CLASS',
  name: 'Tạo hạng khách hàng',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const UPDATE_CUSTOMER_CLASS_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'UPDATE_CUSTOMER_CLASS',
  name: 'Sửa hạng khách hàng',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const DELETE_CUSTOMER_CLASS_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'DELETE_CUSTOMER_CLASS',
  name: 'Xóa hạng khách hàng',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const DETAIL_CUSTOMER_CLASS_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'DETAIL_CUSTOMER_CLASS',
  name: 'Chi tiết hạng khách hàng',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const LIST_CUSTOMER_CLASS_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'LIST_CUSTOMER_CLASS',
  name: 'Danh sách hạng khách hàng',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const CONFIRM_CUSTOMER_CLASS_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'CONFIRM_CUSTOMER_CLASS',
  name: 'Xác nhận hạng khách hàng',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const IMPORT_CUSTOMER_CLASS_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'IMPORT_CUSTOMER_CLASS',
  name: 'Nhập hạng khách hàng',
  groupPermissionSettingCode: CUSTOMER_CLASS_GROUP_PERMISSION.code,
  status: STATUS,
};

export const CUSTOMER_CLASS_PERMISSION = [
  CREATE_CUSTOMER_CLASS_PERMISSION,
  UPDATE_CUSTOMER_CLASS_PERMISSION,
  DELETE_CUSTOMER_CLASS_PERMISSION,
  DETAIL_CUSTOMER_CLASS_PERMISSION,
  LIST_CUSTOMER_CLASS_PERMISSION,
  CONFIRM_CUSTOMER_CLASS_PERMISSION,
  IMPORT_CUSTOMER_CLASS_PERMISSION,
];
