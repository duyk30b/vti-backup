import { FORMAT_CODE_PERMISSION } from '@constant/common';
import { StatusPermission } from '@constant/common';

export const INVOICE_TYPE_GROUP_PERMISSION = {
  name: 'Định nghĩa loại hoá đơn',
  code: FORMAT_CODE_PERMISSION + 'INVOICE_TYPE_GROUP',
  status: StatusPermission.ACTIVE,
};

const STATUS = StatusPermission.ACTIVE;
const GROUP = INVOICE_TYPE_GROUP_PERMISSION.code;

export const CREATE_INVOICE_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'CREATE_INVOICE_TYPE',
  name: 'Tạo loại hoá đơn',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const UPDATE_INVOICE_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'UPDATE_INVOICE_TYPE',
  name: 'Sửa loại hoá đơn',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const DELETE_INVOICE_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'DELETE_INVOICE_TYPE',
  name: 'Xóa loại hoá đơn',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const DETAIL_INVOICE_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'DETAIL_INVOICE_TYPE',
  name: 'Chi tiết loại hoá đơn',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const LIST_INVOICE_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'LIST_INVOICE_TYPE',
  name: 'Danh sách loại hoá đơn',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const CONFIRM_INVOICE_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'CONFIRM_INVOICE_TYPE',
  name: 'Xác nhận loại hoá đơn',
  groupPermissionSettingCode: INVOICE_TYPE_GROUP_PERMISSION.code,
  status: STATUS,
};

export const REJECT_INVOICE_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'REJECT_INVOICE_TYPE',
  name: 'Từ chối xác nhận loại hoá đơn',
  groupPermissionSettingCode: INVOICE_TYPE_GROUP_PERMISSION.code,
  status: STATUS,
};

export const IMPORT_INVOICE_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'IMPORT_INVOICE_TYPE',
  name: 'Nhập loại hóa đơn',
  groupPermissionSettingCode: INVOICE_TYPE_GROUP_PERMISSION.code,
  status: STATUS,
};

export const INVOICE_TYPE_PERMISSION = [
  CREATE_INVOICE_TYPE_PERMISSION,
  UPDATE_INVOICE_TYPE_PERMISSION,
  DELETE_INVOICE_TYPE_PERMISSION,
  DETAIL_INVOICE_TYPE_PERMISSION,
  LIST_INVOICE_TYPE_PERMISSION,
  CONFIRM_INVOICE_TYPE_PERMISSION,
  REJECT_INVOICE_TYPE_PERMISSION,
  IMPORT_INVOICE_TYPE_PERMISSION,
];
