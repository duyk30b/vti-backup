import { FORMAT_CODE_PERMISSION } from '@constant/common';
import { StatusPermission } from '@constant/common';

export const PAYMENT_TYPE_GROUP_PERMISSION = {
  name: 'Định nghĩa hình thức thanh toán',
  code: FORMAT_CODE_PERMISSION + 'PAYMENT_TYPE_GROUP',
  status: StatusPermission.ACTIVE,
};

const STATUS = StatusPermission.ACTIVE;
const GROUP = PAYMENT_TYPE_GROUP_PERMISSION.code;

export const CREATE_PAYMENT_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'CREATE_PAYMENT_TYPE',
  name: 'Tạo hình thức thanh toán',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const UPDATE_PAYMENT_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'UPDATE_PAYMENT_TYPE',
  name: 'Sửa hình thức thanh toán',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const DELETE_PAYMENT_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'DELETE_PAYMENT_TYPE',
  name: 'Xóa hình thức thanh toán',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const DETAIL_PAYMENT_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'DETAIL_PAYMENT_TYPE',
  name: 'Chi tiết hình thức thanh toán',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const LIST_PAYMENT_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'LIST_PAYMENT_TYPE',
  name: 'Danh sách hình thức thanh toán',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const CONFIRM_PAYMENT_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'CONFIRM_PAYMENT_TYPE',
  name: 'Xác nhận hình thức thanh toán',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const IMPORT_PAYMENT_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'IMPORT_PAYMENT_TYPE',
  name: 'Nhập hình thức thanh toán',
  groupPermissionSettingCode: PAYMENT_TYPE_GROUP_PERMISSION.code,
  status: STATUS,
};

export const PAYMENT_TYPE_PERMISSION = [
  CREATE_PAYMENT_TYPE_PERMISSION,
  UPDATE_PAYMENT_TYPE_PERMISSION,
  DELETE_PAYMENT_TYPE_PERMISSION,
  DETAIL_PAYMENT_TYPE_PERMISSION,
  LIST_PAYMENT_TYPE_PERMISSION,
  CONFIRM_PAYMENT_TYPE_PERMISSION,
  IMPORT_PAYMENT_TYPE_PERMISSION,
];
