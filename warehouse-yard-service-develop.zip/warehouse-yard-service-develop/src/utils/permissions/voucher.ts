import { FORMAT_CODE_PERMISSION } from '@constant/common';
import { StatusPermission } from '@constant/common';

export const VOUCHER_GROUP_PERMISSION = {
  name: 'Định nghĩa Mã giảm giá',
  code: FORMAT_CODE_PERMISSION + 'VOUCHER_GROUP',
  status: StatusPermission.ACTIVE,
};

const STATUS = StatusPermission.ACTIVE;
const GROUP = VOUCHER_GROUP_PERMISSION.code;

export const CREATE_VOUCHER_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'CREATE_VOUCHER',
  name: 'Tạo Mã giảm giá',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const UPDATE_VOUCHER_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'UPDATE_VOUCHER',
  name: 'Sửa Mã giảm giá',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const DELETE_VOUCHER_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'DELETE_VOUCHER',
  name: 'Xóa Mã giảm giá',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const DETAIL_VOUCHER_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'DETAIL_VOUCHER',
  name: 'Chi tiết Mã giảm giá',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const LIST_VOUCHER_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'LIST_VOUCHER',
  name: 'Danh sách Mã giảm giá',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const CONFIRM_VOUCHER_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'CONFIRM_VOUCHER',
  name: 'Xác nhận Mã giảm giá',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const REJECT_VOUCHER_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'REJECT_VOUCHER',
  name: 'Từ chối Mã giảm giá',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const IMPORT_VOUCHER_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'IMPORT_VOUCHER',
  name: 'Nhập Mã giảm giá',
  groupPermissionSettingCode: VOUCHER_GROUP_PERMISSION.code,
  status: STATUS,
};

export const VOUCHER_PERMISSION = [
  CREATE_VOUCHER_PERMISSION,
  UPDATE_VOUCHER_PERMISSION,
  DELETE_VOUCHER_PERMISSION,
  DETAIL_VOUCHER_PERMISSION,
  LIST_VOUCHER_PERMISSION,
  CONFIRM_VOUCHER_PERMISSION,
  REJECT_VOUCHER_PERMISSION,
  IMPORT_VOUCHER_PERMISSION,
];
