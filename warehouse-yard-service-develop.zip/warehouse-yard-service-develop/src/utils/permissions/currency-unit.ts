import { FORMAT_CODE_PERMISSION } from '@constant/common';
import { StatusPermission } from '@constant/common';

export const CURRENCY_UNIT_GROUP_PERMISSION = {
  name: 'Định nghĩa đơn vị tiền tệ',
  code: FORMAT_CODE_PERMISSION + 'CURRENCY_UNIT_GROUP',
  status: StatusPermission.ACTIVE,
};

const STATUS = StatusPermission.ACTIVE;
const GROUP = CURRENCY_UNIT_GROUP_PERMISSION.code;

export const CREATE_CURRENCY_UNIT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'CREATE_CURRENCY_UNIT',
  name: 'Tạo đơn vị tiền tệ',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const UPDATE_CURRENCY_UNIT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'UPDATE_CURRENCY_UNIT',
  name: 'Sửa đơn vị tiền tệ',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const DELETE_CURRENCY_UNIT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'DELETE_CURRENCY_UNIT',
  name: 'Xóa đơn vị tiền tệ',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const DETAIL_CURRENCY_UNIT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'DETAIL_CURRENCY_UNIT',
  name: 'Chi tiết đơn vị tiền tệ',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const LIST_CURRENCY_UNIT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'LIST_CURRENCY_UNIT',
  name: 'Danh sách đơn vị tiền tệ',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const CONFIRM_CURRENCY_UNIT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'CONFIRM_CURRENCY_UNIT',
  name: 'Xác nhận đơn vị tiền tệ',
  groupPermissionSettingCode: CURRENCY_UNIT_GROUP_PERMISSION.code,
  status: STATUS,
};

export const REJECT_CURRENCY_UNIT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'REJECT_CURRENCY_UNIT',
  name: 'Từ chối xác nhận đơn vị tiền tệ',
  groupPermissionSettingCode: CURRENCY_UNIT_GROUP_PERMISSION.code,
  status: STATUS,
};

export const IMPORT_CURRENCY_UNIT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'IMPORT_CURRENCY_UNIT',
  name: 'Nhập đơn vị tiền tệ',
  groupPermissionSettingCode: CURRENCY_UNIT_GROUP_PERMISSION.code,
  status: STATUS,
};

export const CURRENCY_UNIT_PERMISSION = [
  CREATE_CURRENCY_UNIT_PERMISSION,
  UPDATE_CURRENCY_UNIT_PERMISSION,
  DELETE_CURRENCY_UNIT_PERMISSION,
  DETAIL_CURRENCY_UNIT_PERMISSION,
  LIST_CURRENCY_UNIT_PERMISSION,
  CONFIRM_CURRENCY_UNIT_PERMISSION,
  REJECT_CURRENCY_UNIT_PERMISSION,
  IMPORT_CURRENCY_UNIT_PERMISSION,
];
