import { FORMAT_CODE_PERMISSION } from '@constant/common';
import { StatusPermission } from '@constant/common';

export const SERVICE_TYPE_GROUP_PERMISSION = {
  name: 'Định nghĩa loại dịch vụ',
  code: FORMAT_CODE_PERMISSION + 'SERVICE_TYPE_GROUP',
  status: StatusPermission.ACTIVE,
};

const STATUS = StatusPermission.ACTIVE;
const GROUP = SERVICE_TYPE_GROUP_PERMISSION.code;

export const CREATE_SERVICE_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'CREATE_SERVICE_TYPE',
  name: 'Tạo loại dịch vụ',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const UPDATE_SERVICE_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'UPDATE_SERVICE_TYPE',
  name: 'Sửa loại dịch vụ',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const DELETE_SERVICE_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'DELETE_SERVICE_TYPE',
  name: 'Xóa loại dịch vụ',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const DETAIL_SERVICE_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'DETAIL_SERVICE_TYPE',
  name: 'Chi tiết loại dịch vụ',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const LIST_SERVICE_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'LIST_SERVICE_TYPE',
  name: 'Danh sách loại dịch vụ',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const CONFIRM_SERVICE_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'CONFIRM_SERVICE_TYPE',
  name: 'Xác nhận loại dịch vụ',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const IMPORT_SERVICE_TYPE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'IMPORT_SERVICE_TYPE',
  name: 'Nhập loại dịch vụ',
  groupPermissionSettingCode: SERVICE_TYPE_GROUP_PERMISSION.code,
  status: STATUS,
};

export const SERVICE_TYPE_PERMISSION = [
  CREATE_SERVICE_TYPE_PERMISSION,
  UPDATE_SERVICE_TYPE_PERMISSION,
  DELETE_SERVICE_TYPE_PERMISSION,
  DETAIL_SERVICE_TYPE_PERMISSION,
  LIST_SERVICE_TYPE_PERMISSION,
  CONFIRM_SERVICE_TYPE_PERMISSION,
  IMPORT_SERVICE_TYPE_PERMISSION,
];
