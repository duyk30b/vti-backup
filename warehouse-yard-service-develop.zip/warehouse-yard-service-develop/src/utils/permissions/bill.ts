import { FORMAT_CODE_PERMISSION } from '@constant/common';
import { StatusPermission } from '@constant/common';

export const BILL_GROUP_PERMISSION = {
  name: 'Định nghĩa Hóa đơn',
  code: FORMAT_CODE_PERMISSION + 'BILL_GROUP',
  status: StatusPermission.ACTIVE,
};

const STATUS = StatusPermission.ACTIVE;
const GROUP = BILL_GROUP_PERMISSION.code;

export const CREATE_BILL_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'CREATE_BILL',
  name: 'Tạo Hóa đơn',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const UPDATE_BILL_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'UPDATE_BILL',
  name: 'Sửa Hóa đơn',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const DELETE_BILL_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'DELETE_BILL',
  name: 'Xóa Hóa đơn',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const DETAIL_BILL_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'DETAIL_BILL',
  name: 'Chi tiết Hóa đơn',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const LIST_BILL_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'LIST_BILL',
  name: 'Danh sách Hóa đơn',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const CONFIRM_BILL_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'CONFIRM_BILL',
  name: 'Xác nhận Hóa đơn',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const REJECT_BILL_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'REJECT_BILL',
  name: 'Từ chối Hóa đơn',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const COMPLETE_BILL_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'COMPLETE_BILL',
  name: 'Hoàn thành Hóa đơn',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const GET_RENT_WAREHOUSE_REPORT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'GET_RENT_WAREHOUSE_REPORT',
  name: 'Danh sách báo cáo thuê kho',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const IMPORT_BILL_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'IMPORT_BILL',
  name: 'Nhập Hóa đơn',
  groupPermissionSettingCode: BILL_GROUP_PERMISSION.code,
  status: STATUS,
};

export const BILL_PERMISSION = [
  CREATE_BILL_PERMISSION,
  UPDATE_BILL_PERMISSION,
  DELETE_BILL_PERMISSION,
  DETAIL_BILL_PERMISSION,
  LIST_BILL_PERMISSION,
  CONFIRM_BILL_PERMISSION,
  REJECT_BILL_PERMISSION,
  COMPLETE_BILL_PERMISSION,
  GET_RENT_WAREHOUSE_REPORT_PERMISSION,
  IMPORT_BILL_PERMISSION,
];
