import { FORMAT_CODE_PERMISSION } from '@constant/common';
import { StatusPermission } from '@constant/common';

export const RENT_UNIT_GROUP_PERMISSION = {
  name: 'Định nghĩa đơn vị tính',
  code: FORMAT_CODE_PERMISSION + 'RENT_UNIT_GROUP',
  status: StatusPermission.ACTIVE,
};

const STATUS = StatusPermission.ACTIVE;
const GROUP = RENT_UNIT_GROUP_PERMISSION.code;

export const CREATE_RENT_UNIT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'CREATE_RENT_UNIT',
  name: 'Tạo đơn vị tính',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const UPDATE_RENT_UNIT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'UPDATE_RENT_UNIT',
  name: 'Sửa đơn vị tính',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const DELETE_RENT_UNIT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'DELETE_RENT_UNIT',
  name: 'Xóa đơn vị tính',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const DETAIL_RENT_UNIT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'DETAIL_RENT_UNIT',
  name: 'Chi tiết đơn vị tính',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const LIST_RENT_UNIT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'LIST_RENT_UNIT',
  name: 'Danh sách đơn vị tính',
  groupPermissionSettingCode: GROUP,
  status: STATUS,
};

export const CONFIRM_RENT_UNIT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'CONFIRM_RENT_UNIT',
  name: 'Xác nhận đơn vị tính',
  groupPermissionSettingCode: RENT_UNIT_GROUP_PERMISSION.code,
  status: STATUS,
};

export const REJECT_RENT_UNIT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'REJECT_RENT_UNIT',
  name: 'Từ chối xác nhận đơn vị tính',
  groupPermissionSettingCode: RENT_UNIT_GROUP_PERMISSION.code,
  status: STATUS,
};

export const IMPORT_RENT_UNIT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'IMPORT_RENT_UNIT',
  name: 'Nhập đơn vị tính',
  groupPermissionSettingCode: RENT_UNIT_GROUP_PERMISSION.code,
  status: STATUS,
};

export const RENT_UNIT_PERMISSION = [
  CREATE_RENT_UNIT_PERMISSION,
  UPDATE_RENT_UNIT_PERMISSION,
  DELETE_RENT_UNIT_PERMISSION,
  DETAIL_RENT_UNIT_PERMISSION,
  LIST_RENT_UNIT_PERMISSION,
  CONFIRM_RENT_UNIT_PERMISSION,
  REJECT_RENT_UNIT_PERMISSION,
  IMPORT_RENT_UNIT_PERMISSION,
];
