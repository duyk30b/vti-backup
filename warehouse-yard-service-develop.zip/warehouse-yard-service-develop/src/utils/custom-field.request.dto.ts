import { IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CustomFieldRequest {
  @ApiProperty({ example: 'custom1', description: 'ma truong custom' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  name: string;

  @ApiProperty({
    example: 'custom1 value',
    description: 'gia tri truong custom',
  })
  @IsString()
  @IsOptional()
  value: string;

  @ApiProperty({
    example: 'custom1 value',
    description: 'gia tri truong custom',
  })
  @IsString()
  @IsOptional()
  type: string;
}
