import { Expose } from 'class-transformer';

export class CustomFieldResponse {
  @Expose()
  name: string;

  @Expose()
  value: string;
}
