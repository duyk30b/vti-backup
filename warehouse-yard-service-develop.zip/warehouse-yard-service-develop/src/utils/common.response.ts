import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class Meta {
  @ApiProperty({ example: 1 })
  @Expose()
  total: number;

  @ApiProperty({ example: 1 })
  @Expose()
  page: number;
}

export class Approver {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  username: string;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  fullName: string;
}
