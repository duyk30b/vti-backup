import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class SetStatusDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'id' })
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty({ example: 1, description: 'user id' })
  @IsNotEmpty()
  @IsInt()
  userId: number;
}
