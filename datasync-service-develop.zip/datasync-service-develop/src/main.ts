import { NATS_DATASYNC, NatsConfig } from '@config/nats.config';
import { ClusterService } from '@core/cluster/cluster.service';
import { ExceptionInterceptor } from '@core/interceptors/exception.interceptor';
import { FilterQueryPipe } from '@core/pipe/filter-query.pipe';
import { SortQueryPipe } from '@core/pipe/sort-query.pipe';
import { NestFactory } from '@nestjs/core';
import { Transport } from '@nestjs/microservices';
import {
  FastifyAdapter,
  NestFastifyApplication,
} from '@nestjs/platform-fastify';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { isDevMode } from '@utils/helper';
import 'dotenv/config';
import fastifyMultipart from 'fastify-multipart';
import { AppModule } from './app.module';
import { ConfigService } from './config/config.service';

async function bootstrap() {
  const fastifyAdapter = new FastifyAdapter();

  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
  fastifyAdapter.register(fastifyMultipart, {
    attachFieldsToBody: true,
    addToBody: true,
  });

  const app = await NestFactory.create<NestFastifyApplication>(
    AppModule,
    fastifyAdapter,
    {
      logger: isDevMode()
        ? ['debug', 'error', 'log', 'verbose', 'warn']
        : ['error'],
    },
  );

  // app.connectMicroservice<MicroserviceOptions>({
  //   transport: Transport.KAFKA,
  //   options: {
  //     client: {
  //       brokers: [`${process.env.KAFAK_HOST || 'kafka:9092'}`],
  //     },
  //   },
  // });

  let corsOptions = {};
  const configService = new ConfigService();
  if (configService.get('corsOrigin')) {
    corsOptions = {
      origin: new ConfigService().get('corsOrigin'),
    };
  }

  app.connectMicroservice(
    {
      transport: Transport.NATS,
      options: {
        servers: NatsConfig().servers,
        queue: NATS_DATASYNC,
      },
    },
    { inheritAppConfig: true },
  );

  await app.startAllMicroservices();

  app.setGlobalPrefix(process.env.API_PATH);

  // eslint-disable-next-line @typescript-eslint/no-var-requires
  app.register(require('fastify-cors'), corsOptions);
  app.useGlobalPipes(new SortQueryPipe());
  app.useGlobalPipes(new FilterQueryPipe());
  app.useGlobalInterceptors(new ExceptionInterceptor());

  const options = new DocumentBuilder()
    .setTitle('API docs')
    .addBearerAuth(
      { type: 'http', description: 'Access token' },
      'access-token',
    )
    .setVersion('1.0')
    .build();
  const document = SwaggerModule.createDocument(app, options);
  SwaggerModule.setup('/api/v1/datasync/swagger-docs', app, document);

  await app.listen(new ConfigService().get('httpPort'), '0.0.0.0');
}

isDevMode() ? bootstrap() : ClusterService.clusterize(bootstrap);
