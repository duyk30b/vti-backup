import { CollationOptions } from 'mongodb';
import * as dotenv from 'dotenv';
dotenv.config();

export enum APIPrefix {
  Version = 'api/v1',
}
export const FORMAT_CODE_PERMISSION = 'REPORT_';

export enum SortOrder {
  Ascending = 1,
  Descending = -1,
}

export const SORT_CONST = {
  ASCENDING: 'asc',
  DESCENDING: 'desc',
};

//permission
export enum StatusPermission {
  ACTIVE = 1,
  INACTIVE = 0,
}

export const DEFAULT_COLLATION: CollationOptions = {
  locale: 'vi',
};
