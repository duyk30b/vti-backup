import { StatusPermission } from '@constant/common';

export const DATASYNC_JOB_GROUP_PERMISSION = {
  name: 'Quản lý tín hiệu đồng bộ',
  code: 'DATASYNC_JOB_GROUP_PERMISSION',
  status: StatusPermission.ACTIVE,
};

export const CREATE_JOB_PERMISSION = {
  code: 'DATASYNC_CREATE_STATUS_JOB',
  name: 'Tạo trạng thái dữ liệu đồng bộ',
  groupPermissionSettingCode: 'DATASYNC_JOB_GROUP_PERMISSION',
  status: StatusPermission.INACTIVE,
};

export const UPDATE_STATUS_JOB_PERMISSION = {
  code: 'DATASYNC_UPDATE_STATUS_JOB',
  name: 'Cập nhật trạng thái dữ liệu đồng bộ',
  groupPermissionSettingCode: 'DATASYNC_JOB_GROUP_PERMISSION',
  status: StatusPermission.INACTIVE,
};

export const UPDATE_JOB_PERMISSION = {
  code: 'DATASYNC_UPDATE_JOB',
  name: 'Cập nhật dữ liệu đồng bộ',
  groupPermissionSettingCode: 'DATASYNC_JOB_GROUP_PERMISSION',
  status: StatusPermission.INACTIVE,
};

export const DETAIL_JOB_PERMISSION = {
  code: 'DATASYNC_DETAIL_JOB',
  name: 'Chi tiết dữ liệu đồng bộ',
  groupPermissionSettingCode: 'DATASYNC_JOB_GROUP_PERMISSION',
  status: StatusPermission.ACTIVE,
};

export const DELETE_JOB_PERMISSION = {
  code: 'DATASYNC_DELETE_JOB',
  name: 'Xóa dữ liệu đồng bộ',
  groupPermissionSettingCode: 'DATASYNC_JOB_GROUP_PERMISSION',
  status: StatusPermission.INACTIVE,
};

export const HISTORY_JOB_PERMISSION = {
  code: 'DATASYNC_HISTORY_JOB',
  name: 'Lịch sử dữ liệu đồng bộ',
  groupPermissionSettingCode: 'DATASYNC_JOB_GROUP_PERMISSION',
  status: StatusPermission.INACTIVE,
};

export const LIST_JOB_PERMISSION = {
  code: 'DATASYNC_LIST_JOB',
  name: 'Danh sách tín hiệu đồng bộ',
  groupPermissionSettingCode: 'DATASYNC_JOB_GROUP_PERMISSION',
  status: StatusPermission.ACTIVE,
};

export const CANCEL_JOB_PERMISSION = {
  code: 'DATASYNC_CANCEL_JOB',
  name: 'Hủy đồng bộ',
  groupPermissionSettingCode: 'DATASYNC_JOB_GROUP_PERMISSION',
  status: StatusPermission.ACTIVE,
};

export const RETRY_JOB_PERMISSION = {
  code: 'DATASYNC_RETRY_JOB',
  name: 'Gửi lại dữ liệu đồng bộ',
  groupPermissionSettingCode: 'DATASYNC_JOB_GROUP_PERMISSION',
  status: StatusPermission.ACTIVE,
};

export const JOB_PERMISSION = [
  LIST_JOB_PERMISSION,
  CANCEL_JOB_PERMISSION,
  RETRY_JOB_PERMISSION,
  UPDATE_STATUS_JOB_PERMISSION,
  UPDATE_JOB_PERMISSION,
  DETAIL_JOB_PERMISSION,
  DELETE_JOB_PERMISSION,
  HISTORY_JOB_PERMISSION,
  CREATE_JOB_PERMISSION,
];
