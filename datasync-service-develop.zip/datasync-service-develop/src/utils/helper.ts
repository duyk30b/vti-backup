export function serilize(data) {
  if (data.length > 0) {
    const serilizeData = [];
    data.forEach((record) => {
      serilizeData[record.id] = record;
    });
    return serilizeData;
  }
  return data;
}

export const isDevMode = () => {
  return process.env.NODE_ENV.startsWith('dev');
};
