import { BaseModel } from '@core/model/base.model';
import * as mongoose from 'mongoose';

export class JobStatus {
  executionDate: Date;
  status: number;
  responseError: Object;
  id: string;
}

export interface JobModel extends BaseModel {
  resourceCode: string;
  service: string;
  event: string;
  typeTransaction: string;
  retryMessagePattern: string;
  object: Object;
  fromSystem: string;
  toSystem: string;
  status: number;
  dateFrom: Date;
  urlDetail: string;
  history: [JobStatus];
}
