import { JOB_STATUS_ENUM } from '@components/job/job.constant';
import * as mongoose from 'mongoose';

export const JobStatus = new mongoose.Schema({
  executionDate: {
    type: Date,
    default: Date.now(),
  },
  status: {
    type: Number,
  },
  responseError: {
    type: Object,
    required: false,
  },
  createdAt: {
    type: Date,
    default: Date.now(),
  },
  updatedAt: {
    type: Date,
    default: Date.now(),
  },
  deletedAt: {
    type: Date,
    default: null,
  },
});

export const JobSchema = new mongoose.Schema(
  {
    resourceCode: {
      type: String,
      required: false,
    },
    service: {
      type: String,
    },
    event: {
      type: String,
    },
    retryMessagePattern: {
      type: String,
      required: false,
    },
    typeTransaction: {
      type: String,
    },
    object: {
      type: Object,
    },
    fromSystem: {
      type: String,
    },
    toSystem: {
      type: String,
    },
    status: {
      type: Number,
      default: JOB_STATUS_ENUM.PENDING,
    },
    dateFrom: {
      type: Date,
      default: Date.now(),
    },
    urlDetail: {
      type: String,
    },
    history: {
      type: [JobStatus],
      required: false,
    },
    createdBy: {
      type: Number,
      required: true,
    },
    deletedAt: {
      type: Date,
      default: null,
    },
    updatedBy: {
      type: Number,
      default: null,
    },
    createdAt: {
      type: Date,
      default: Date.now(),
    },
    updatedAt: {
      type: Date,
      default: Date.now(),
    },
  },
  {
    collection: 'jobs',
    timestamps: true,
  },
);
