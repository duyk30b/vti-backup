import { ItemMasterDataSync } from './services/item-master-data.service';
import { SYNC_MASTER_DATA_MAP } from './sync-manager.constant';

class DatasyncFactory {
  create(type) {
    switch (type) {
      case SYNC_MASTER_DATA_MAP.ITEM_MASTER_DATA.name:
        return new ItemMasterDataSync();
      default: {
        console.log('Unknown type...');
      }
    }
  }
}
export default new DatasyncFactory();
