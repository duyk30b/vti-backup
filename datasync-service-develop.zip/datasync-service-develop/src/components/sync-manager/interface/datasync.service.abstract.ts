import { DatasyncServiceInterface } from './datasync.service.interface';

export class DatasyncServiceAbstract implements DatasyncServiceInterface {
  protected topic: string;

  postDatasync(request: any): { topic: string; value: any } {
    return { topic: this.topic, value: request };
  }
}
