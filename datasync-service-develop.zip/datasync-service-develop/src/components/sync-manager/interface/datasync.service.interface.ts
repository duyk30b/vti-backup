export interface DatasyncServiceInterface {
  postDatasync(request: any);
}
