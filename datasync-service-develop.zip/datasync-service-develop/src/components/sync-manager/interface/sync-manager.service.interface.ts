export interface SyncManagerServiceInterface {
  postDatasync(request: any): Promise<any>;
  sendKafkaEvent(key: string, value);
}
