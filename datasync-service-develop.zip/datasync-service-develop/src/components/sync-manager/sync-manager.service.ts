import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { SyncManagerServiceInterface } from './interface/sync-manager.service.interface';
import { PostDataRequestDto } from './dto/request/post-data.request.dto';
import DatasyncFactory from './data-sync.factory';
import { Producer } from 'kafkajs';

@Injectable()
export class SyncManagerService implements SyncManagerServiceInterface {
  constructor(
    @Inject('KAFKA_PRODUCER') private kafkaProducer: Producer,
    private readonly i18n: I18nRequestScopeService,
  ) {}
  sendKafkaEvent(topic, value) {
    this.kafkaProducer.send({
      topic: topic,
      messages: [{ key: topic, value: JSON.stringify(value) }],
    });
  }

  async postDatasync(request: PostDataRequestDto): Promise<any> {
    const { dataName, data } = request;
    const service = DatasyncFactory.create(dataName);

    const { topic, value } = service.postDatasync(data);

    this.sendKafkaEvent(topic, value);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
