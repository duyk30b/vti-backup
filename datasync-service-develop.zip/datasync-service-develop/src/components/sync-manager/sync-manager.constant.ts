export const SYNC_MASTER_DATA_MAP = {
  ITEM_MASTER_DATA: {
    name: 'item_master_data',
    topic: 'sync_item_master_data',
  },
};
