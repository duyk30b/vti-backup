import { DatasyncServiceAbstract } from '../interface/datasync.service.abstract';
import { DatasyncServiceInterface } from '../interface/datasync.service.interface';
import { SYNC_MASTER_DATA_MAP } from '../sync-manager.constant';

export class ItemMasterDataSync
  extends DatasyncServiceAbstract
  implements DatasyncServiceInterface
{
  protected topic = SYNC_MASTER_DATA_MAP.ITEM_MASTER_DATA.topic;
}
