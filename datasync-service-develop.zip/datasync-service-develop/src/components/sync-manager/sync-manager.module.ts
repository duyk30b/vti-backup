import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { SyncManagerController } from './sync-manager.controller';
import { SyncManagerService } from './sync-manager.service';
import { ClientKafka, ClientsModule, Transport } from '@nestjs/microservices';

@Module({
  imports: [
    HttpModule,
    ClientsModule.register([
      {
        name: 'CLIENT_KAFKA',
        transport: Transport.KAFKA,
        options: {
          client: {
            clientId: 'sync_manager',
            brokers: process.env.KAFKA_BROKERS.split(','),
            ssl: true,
            sasl: {
              mechanism: 'plain',
              username: process.env.KAFKA_SASL_USERNAME,
              password: process.env.KAFKA_SASL_PASSWD,
            },
          },
          consumer: {
            groupId: 'sync_manager',
          },
        },
      },
    ]),
  ],
  providers: [
    {
      provide: 'SyncManagerServiceInterface',
      useClass: SyncManagerService,
    },
    {
      provide: 'KAFKA_PRODUCER',
      useFactory: async (kafkaClient: ClientKafka) => {
        return kafkaClient.connect();
      },
      inject: ['CLIENT_KAFKA'],
    },
  ],
  exports: [
    {
      provide: 'SyncManagerServiceInterface',
      useClass: SyncManagerService,
    },
  ],
  controllers: [SyncManagerController],
})
export class SyncManagerModule {}
