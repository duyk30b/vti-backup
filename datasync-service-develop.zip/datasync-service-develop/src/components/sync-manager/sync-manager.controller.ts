import { Public } from '@core/decorator/set-public.decorator';
import { Body, Controller, Inject, Post } from '@nestjs/common';
import { isEmpty } from 'lodash';
import { PostDataRequestDto } from './dto/request/post-data.request.dto';
import { SyncManagerServiceInterface } from './interface/sync-manager.service.interface';

@Controller('')
export class SyncManagerController {
  constructor(
    @Inject('SyncManagerServiceInterface')
    private readonly syncManagerService: SyncManagerServiceInterface,
  ) {}

  @Public()
  @Post('')
  async postDatasync(@Body() body: PostDataRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.syncManagerService.postDatasync(request);
  }
}
