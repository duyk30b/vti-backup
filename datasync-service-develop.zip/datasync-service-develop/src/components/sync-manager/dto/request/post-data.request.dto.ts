import { IsString } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';

export class PostDataRequestDto extends BaseDto {
  @IsString()
  dataName: string;

  data: any;
}
