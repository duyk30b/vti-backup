import { CreateJobDto } from '../dto/request/create-job.request.dto';
import { DetailJobRequestDto } from '../dto/request/detail-job.request.dto';
import { GetJobStatusRequestDto } from '../dto/request/get-jobstatus.request.dto';
import { GetListJobRequestDto } from '../dto/request/get-list-job.request.dto';
import { UpdateJobStatusDto } from '../dto/request/update-job-status.request.dto';
import { UpdateJobDocumentDto } from '../dto/request/update-job.request.dto';

export interface JobServiceInterface {
  createJob(request: CreateJobDto): Promise<any>;
  getJob(id: DetailJobRequestDto): Promise<any>;
  delete(id: string): Promise<any>;
  updateJobDocument(request: UpdateJobDocumentDto): Promise<any>;
  updateJobStatus(request: UpdateJobStatusDto): Promise<any>;
  retry(id: string): Promise<any>;
  getList(data: GetListJobRequestDto): Promise<any>;
  deleteJobStatus(data: GetJobStatusRequestDto, idJob: string): Promise<any>
  reject(id: string): Promise<any>
}
