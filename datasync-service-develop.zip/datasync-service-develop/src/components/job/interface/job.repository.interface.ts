import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { JobModel } from 'src/model/job/job.model';
import { CreateJobDto } from '../dto/request/create-job.request.dto';
import { GetListJobRequestDto } from '../dto/request/get-list-job.request.dto';
import { UpdateJobDocumentDto } from '../dto/request/update-job.request.dto';

export interface JobRepositoryInterface
  extends BaseAbstractRepository<JobModel> {
  createJobDocument(data: CreateJobDto): Promise<any>;
  getDetailJob(id: string): Promise<any>;
  findAndDeleteOneDocumentById(id: string): Promise<any>;
  updateDocument(data: UpdateJobDocumentDto): Promise<any>;
  getList(data: GetListJobRequestDto): Promise<any>;
}
