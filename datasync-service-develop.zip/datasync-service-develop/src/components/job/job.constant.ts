export enum JOB_STATUS_ENUM {
  PENDING = 0,
  IN_PROGRESS = 1,
  ERROR_TRANSACTION = 2,
  ERROR_SYNC = 3,
  SUCCESS = 4,
  CANCEL = 5,
}

export const JOB_STATUS_TO_RETRY = [
  JOB_STATUS_ENUM.ERROR_TRANSACTION,
  JOB_STATUS_ENUM.ERROR_SYNC,
];

export const JOB_STATUS_TO_REJECT = [
  JOB_STATUS_ENUM.ERROR_TRANSACTION,
  JOB_STATUS_ENUM.ERROR_SYNC,
];

export enum EnumSort {
  ASC = 'ASC',
  DESC = 'DESC',
}

export const FIELD_JOB_ENUM = {
  STATUS: {
    COLUMN: 'status',
  },
  RESOURCE_CODE: {
    COLUMN: 'resourceCode',
  },
  TYPE_TRANSACTION: {
    COLUMN: 'typeTransaction',
  },
  FROM_SYSTEM: {
    COLUMN: 'fromSystem',
  },
  TO_SYSTEM: {
    COLUMN: 'toSystem',
  },
  DATE: {
    COLUMN: 'date',
  },
};

export enum TypeTransactionDataSyncEnum {
  WAREHOUSE_TRANSFER = 'Chuyển kho',
  PO_IMPORT = 'Phiếu nhập kho',
  SO_EXPORT = 'Phiếu xuất kho',
  TRANSACTION = 'Giao dịch',
}
