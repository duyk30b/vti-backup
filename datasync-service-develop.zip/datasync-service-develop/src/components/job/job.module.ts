import { Module } from '@nestjs/common';
import { JobController } from './job.controller';
import { JobService } from './job.service';
import { MongooseModule } from '@nestjs/mongoose';
import { JobRepository } from '@repositories/job.repository';
import { JobSchema } from 'src/model/job/job.schema';

@Module({
  imports: [MongooseModule.forFeature([{ name: 'jobs', schema: JobSchema }])],
  providers: [
    {
      provide: 'JobServiceInterface',
      useClass: JobService,
    },
    {
      provide: 'JobRepositoryInterface',
      useClass: JobRepository,
    },
  ],
  exports: [
    {
      provide: 'JobServiceInterface',
      useClass: JobService,
    },
    {
      provide: 'JobRepositoryInterface',
      useClass: JobRepository,
    },
  ],
  controllers: [JobController],
})
export class JobModule {}
