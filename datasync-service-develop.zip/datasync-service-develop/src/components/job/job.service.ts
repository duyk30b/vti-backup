import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Injectable, Inject } from '@nestjs/common';
import { isEmpty } from 'lodash';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { CreateJobDto } from './dto/request/create-job.request.dto';
import { DetailJobRequestDto } from './dto/request/detail-job.request.dto';
import { GetListJobRequestDto } from './dto/request/get-list-job.request.dto';
import { UpdateJobDocumentDto } from './dto/request/update-job.request.dto';
import { DetailJobResponseDto } from './dto/response/get-detail-job.response.dto';
import { JobResponseDto } from './dto/response/get-job.response.dto';
import { ListJobResponseDto } from './dto/response/list-job.response.dto';
import { JobRepositoryInterface } from './interface/job.repository.interface';
import { JobServiceInterface } from './interface/job.service.interface';
import { UpdateJobStatusDto } from './dto/request/update-job-status.request.dto';
import {
  JOB_STATUS_TO_RETRY,
  JOB_STATUS_ENUM,
  JOB_STATUS_TO_REJECT,
} from './job.constant';
import { HttpClientService } from '@core/components/http-client/http-client.service';
import { GetJobStatusRequestDto } from './dto/request/get-jobstatus.request.dto';
import { CreateJobResponseDto } from './dto/response/create-job.response.dto';
import { PagingResponse } from '@utils/paging.response';

@Injectable()
export class JobService implements JobServiceInterface {
  constructor(
    @Inject('JobRepositoryInterface')
    private readonly jobRepository: JobRepositoryInterface,

    private readonly httpClientService: HttpClientService,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  public async retry(id: string): Promise<any> {
    const job = await this.jobRepository.findOneById(id);
    if (isEmpty(job)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!JOB_STATUS_TO_RETRY.includes(job.status) || !job.retryMessagePattern) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }
    try {
      const httpConfig = {
        scalingDuration: 1000,
        excludedStatusCodes: [409, 422],
        callInternalService: true,
        serviceName: job.service,
      };

      const result = await this.httpClientService.put(
        job.retryMessagePattern,
        {
          jobSyncId: job.id,
          payload: {
            event: job.event,
            object: job.object,
          },
        },
        httpConfig,
      );

      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (e) {
      return new ResponseBuilder(e)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  public async updateJobStatus(request: UpdateJobStatusDto): Promise<any> {
    const { id, status } = request;
    const job = await this.jobRepository.getDetailJob(id);
    if (isEmpty(job)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    try {
      job.status = status;
      job.id = id;
      await this.jobRepository.updateDocument({
        id: id,
        status: status,
      } as UpdateJobDocumentDto);
      const result = plainToInstance(JobResponseDto, job, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder(error?.message)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async createJob(request: CreateJobDto): Promise<any> {
    try {
      const document = await this.jobRepository.createJobDocument(request);
      const jobDocument = await this.jobRepository.create(document);
      const result = await plainToInstance(CreateJobResponseDto, jobDocument, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder(error?.message)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withData(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getJob(id: DetailJobRequestDto): Promise<any> {
    try {
      const idJob = id.toString();
      const jobDetail = await this.jobRepository.findOneById(idJob);
      if (isEmpty(jobDetail)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }
      const result = plainToInstance(DetailJobResponseDto, jobDetail, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder(error?.message)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withData(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async delete(id: string): Promise<any> {
    try {
      const result = await this.jobRepository.getDetailJob(id);
      if (isEmpty(result)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }

      await this.jobRepository.findAndDeleteOneDocumentById(id);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder(error?.message)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async updateJobDocument(request: UpdateJobDocumentDto): Promise<any> {
    const { id } = request;
    const result = await this.jobRepository.getDetailJob(id);
    if (isEmpty(result)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    try {
      const documentUpdate = await this.jobRepository.updateDocument(request);
      const result = plainToInstance(JobResponseDto, documentUpdate, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder(error?.message)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getList(data: GetListJobRequestDto): Promise<any> {
    try {
      const { result, count } = await this.jobRepository.getList(data);

      const response = plainToInstance(ListJobResponseDto, result, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder<PagingResponse>({
        items: response,
        meta: { total: count, page: data.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } catch (error) {
      return new ResponseBuilder(error?.message)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async deleteJobStatus(
    data: GetJobStatusRequestDto,
    idJob: string,
  ): Promise<any> {
    const { id } = data;
    const job = await this.jobRepository.findOneById(idJob);
    let check = true;
    if (isEmpty(job)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    try {
      job.history.forEach(function (item, index) {
        if (item.id === id) {
          job.history.splice(index, 1);
          check = false;
        }
      });
      if (check) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }
      job.save();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder(error?.message)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async reject(id: string): Promise<any> {
    const job = await this.jobRepository.findOneById(id);
    if (isEmpty(job)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!JOB_STATUS_TO_REJECT.includes(job.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.CANNOT_REJECT'))
        .build();
    }
    try {
      const status = JOB_STATUS_ENUM.CANCEL;
      this.jobRepository.updateDocument({
        id: id,
        status: status,
      } as UpdateJobDocumentDto);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder(error?.message)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }
}
