import {
  Controller,
  Inject,
  Get,
  Body,
  Post,
  Param,
  Delete,
  Put,
  Query,
} from '@nestjs/common';
import { JobServiceInterface } from './interface/job.service.interface';
import { ApiOperation, ApiParam, ApiResponse } from '@nestjs/swagger';
import { CreateJobDto } from './dto/request/create-job.request.dto';
import { UpdateJobDocumentDto } from './dto/request/update-job.request.dto';
import { isEmpty } from 'lodash';
import { GetListJobRequestDto } from './dto/request/get-list-job.request.dto';
import { DetailJobRequestDto } from './dto/request/detail-job.request.dto';
import { JobResponseDto } from './dto/response/get-job.response.dto';
import { ListJobResponseDto } from './dto/response/list-job.response.dto';
import { DetailJobResponseDto } from './dto/response/get-detail-job.response.dto';
import { UpdateJobStatusDto } from './dto/request/update-job-status.request.dto';
import { GetJobStatusRequestDto } from './dto/request/get-jobstatus.request.dto';
import {
  CANCEL_JOB_PERMISSION,
  CREATE_JOB_PERMISSION,
  DELETE_JOB_PERMISSION,
  DETAIL_JOB_PERMISSION,
  LIST_JOB_PERMISSION,
  RETRY_JOB_PERMISSION,
  UPDATE_STATUS_JOB_PERMISSION,
} from '@utils/permissions/job';
import { PermissionCode } from '@core/decorator/get-code.decorator';

@Controller('jobs')
export class JobController {
  constructor(
    @Inject('JobServiceInterface')
    private readonly jobService: JobServiceInterface,
  ) {}

  @PermissionCode(CREATE_JOB_PERMISSION.code)
  @ApiOperation({
    tags: ['job'],
    summary: 'create document job',
  })
  @ApiResponse({
    status: 200,
    description: 'create document job successfully!!!',
    type: JobResponseDto,
  })
  @Post()
  async createJob(@Body() payload: CreateJobDto) {
    const { request, responseError } = payload;
    if (!isEmpty(responseError)) {
      return responseError;
    }
    return await this.jobService.createJob(request);
  }

  @PermissionCode(DETAIL_JOB_PERMISSION.code)
  @ApiOperation({
    tags: ['job'],
    summary: 'get detail job',
  })
  @ApiResponse({
    status: 200,
    description: 'get detail successfully !!!',
    type: DetailJobResponseDto,
  })
  @ApiParam({ name: 'id', type: String, example: '633fe8f11d4ab3a4dfe43de1' })
  @Get('/:id')
  async getDetailJob(@Param() param: DetailJobRequestDto) {
    const { request, responseError } = param;
    if (!isEmpty(responseError)) {
      return responseError;
    }
    return await this.jobService.getJob(request.id);
  }

  @PermissionCode(DELETE_JOB_PERMISSION.code)
  @ApiOperation({
    tags: ['job'],
    summary: 'Soft Delete job',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete  successfully !!!',
  })
  @ApiParam({ name: 'id', type: String, example: '63438f9d6086283342731b11' })
  @Delete('/delete/:id')
  async DeleteJobDocumentById(@Param() param: DetailJobRequestDto) {
    const { request, responseError } = param;
    if (!isEmpty(responseError)) {
      return responseError;
    }
    return await this.jobService.delete(request.id);
  }

  @PermissionCode(UPDATE_STATUS_JOB_PERMISSION.code)
  @ApiOperation({
    tags: ['job'],
    summary: 'update job document !!!',
  })
  @ApiResponse({
    status: 200,
    description: 'update successfully !!!',
    type: JobResponseDto,
  })
  @ApiParam({ name: 'id', type: String, example: '633fe8f11d4ab3a4dfe43de1' })
  @Put('/:id')
  async updateJobDocument(
    @Body() payload: UpdateJobDocumentDto,
    @Param('id') id: string,
  ) {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.jobService.updateJobDocument({
      ...request,
    });
  }

  @PermissionCode(UPDATE_STATUS_JOB_PERMISSION.code)
  @ApiOperation({
    tags: ['job'],
    summary: 'update job status !!!',
  })
  @ApiResponse({
    status: 200,
    description: 'update successfully !!!',
    type: JobResponseDto,
  })
  @ApiParam({ name: 'id', type: String, example: '633fe8f11d4ab3a4dfe43de1' })
  @Put('/:id/status')
  async changeJobStatus(
    @Body() payload: UpdateJobStatusDto,
    @Param('id') id: string,
  ) {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.jobService.updateJobStatus({
      ...request,
    });
  }

  @PermissionCode(RETRY_JOB_PERMISSION.code)
  @ApiOperation({
    tags: ['job'],
    summary: 'retry job!!!',
  })
  @ApiResponse({
    status: 200,
    description: 'update successfully !!!',
    type: JobResponseDto,
  })
  @ApiParam({ name: 'id', type: String, example: '633fe8f11d4ab3a4dfe43de1' })
  @Put('/:id/retry')
  async retryJob(@Param('id') id: string) {
    return await this.jobService.retry(id);
  }

  @PermissionCode(LIST_JOB_PERMISSION.code)
  @ApiOperation({
    tags: ['job'],
    summary: 'get List jobs document !!!',
  })
  @ApiResponse({
    status: 200,
    description: 'List document',
    type: ListJobResponseDto,
  })
  @Get('/list')
  async getListDocument(@Query() payload: GetListJobRequestDto): Promise<any> {
    return await this.jobService.getList(payload.request);
  }

  @PermissionCode(CANCEL_JOB_PERMISSION.code)
  @ApiOperation({
    tags: ['job'],
    summary: 'reject job !!!',
  })
  @ApiResponse({
    status: 200,
    description: 'successfully',
  })
  @Put('/:id/reject')
  async reject(@Param('id') id: string): Promise<any> {
    return await this.jobService.reject(id);
  }

  @PermissionCode(DELETE_JOB_PERMISSION.code)
  @ApiOperation({
    tags: ['jobStatus'],
    summary: 'delete item in history',
    description:
      'delete jobstatus in history - (input: id(param) - idJob/ id(Body) - idJobStatus)',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
  })
  @Delete('/:id/history')
  async deleteHistory(
    @Param('id') id: string,
    @Body() payload: GetJobStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    const idJob = id;
    return await this.jobService.deleteJobStatus(request, idJob);
  }
}
