import { BaseResponseDto } from "@core/dto/base.response.dto";
import { ApiProperty } from "@nestjs/swagger";
import { Expose } from "class-transformer";

export class JobResponseDto extends BaseResponseDto {
  @Expose()
  @ApiProperty()
  resourceCode: string

  @Expose()
  @ApiProperty()
  typeTransaction: string

  @Expose()
  @ApiProperty()
  retryMessagePattern: string

  @Expose()
  @ApiProperty()
  fromSystem: string

  @Expose()
  @ApiProperty()
  toSystem: string

  @Expose()
  @ApiProperty()
  status: number

  @Expose()
  @ApiProperty()
  createdBy: number

  @Expose()
  @ApiProperty()
  dateFrom: Date

  @Expose()
  @ApiProperty()
  urlDetail: string
}