import { BaseResponseDto } from "@core/dto/base.response.dto";
import { ApiProperty } from "@nestjs/swagger";
import { Expose } from "class-transformer";
import { DetailJobResponseDto } from "./get-detail-job.response.dto";
import { JobResponseDto } from "./get-job.response.dto";

export class ListJobResponseDto extends JobResponseDto {
}