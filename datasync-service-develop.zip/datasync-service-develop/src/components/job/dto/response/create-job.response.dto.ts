import { JobResponseDto } from "./get-job.response.dto";
import { ApiProperty } from "@nestjs/swagger";
import { Expose } from "class-transformer";

export class CreateJobResponseDto extends JobResponseDto {
  @Expose()
  @ApiProperty()
  object: Object
}