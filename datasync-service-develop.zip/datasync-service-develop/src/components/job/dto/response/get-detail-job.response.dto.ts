import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { JobResponseDto } from './get-job.response.dto';

class JobStatusResponse extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty({
    example: {
      title: 'this is title',
      desc: 'this is desc',
    },
  })
  @Expose()
  responseError: any;

  @ApiProperty()
  @Expose()
  executionDate: Date;
}

export class DetailJobResponseDto extends JobResponseDto {
  @Expose()
  @ApiProperty()
  object: any;

  @Expose()
  @ApiProperty({ type: JobStatusResponse })
  @Type(() => JobStatusResponse)
  history: [JobStatusResponse];
}
