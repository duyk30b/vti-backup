import { BaseDto } from "@core/dto/base.dto";
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { IsMongoId } from 'class-validator';

export class DetailJobRequestDto extends BaseDto {
  @ApiProperty({
    example: '633fe8f11d4ab3a4dfe43de1'
  })
  @IsMongoId()
  id: string;
}