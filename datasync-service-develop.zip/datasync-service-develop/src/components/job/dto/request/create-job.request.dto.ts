import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsInt,
  IsNotEmpty,
  IsString,
  IsObject,
  IsEnum,
  IsOptional,
  IsDateString,
  MaxLength,
} from 'class-validator';
import {
  JOB_STATUS_ENUM,
  TypeTransactionDataSyncEnum,
} from '@components/job/job.constant';

export class CreateJobDto extends BaseDto {
  @IsOptional()
  @IsString()
  @MaxLength(50)
  @ApiProperty({
    example: 'N16072022001',
    description: 'mã đối tượng',
  })
  resourceCode: string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty({
    example: 'name service',
    description: '',
  })
  service: string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty({
    example: 'name service',
    description: '',
  })
  event: string;

  @IsNotEmpty()
  @IsString()
  @ApiProperty({
    example: 'phiếu nhập kho',
    description: 'loại giao dịch',
  })
  typeTransaction: TypeTransactionDataSyncEnum;

  @IsOptional()
  @IsString()
  @ApiProperty({
    example: 'name event',
  })
  retryMessagePattern: string;

  @IsObject()
  @ApiProperty({
    example: {
      title: 'this is title',
      desc: ' this is desc',
    },
  })
  object: any;

  @IsString()
  @ApiProperty({
    example: 'WMS',
    description: 'Từ hệ thống',
  })
  fromSystem: string;

  @IsString()
  @ApiProperty({
    example: 'EBS',
    description: 'Đến hệ thống',
  })
  toSystem: string;

  @IsInt()
  @ApiProperty({
    example: 0,
  })
  @IsOptional()
  @IsEnum(JOB_STATUS_ENUM)
  status: number;

  @IsDateString()
  @IsOptional()
  @ApiProperty({
    example: '',
    description: 'Ngày gửi',
  })
  dateFrom: Date;

  @IsString()
  @IsOptional()
  @ApiProperty({
    example: '',
    description: 'urlDetail',
  })
  urlDetail: string;

  @IsNotEmpty()
  @IsInt()
  @IsOptional()
  @ApiProperty({
    example: 10101010,
  })
  createdBy: number;
}
