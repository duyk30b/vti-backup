import { DetailJobRequestDto } from "./detail-job.request.dto";

export class GetJobStatusRequestDto extends DetailJobRequestDto {
}