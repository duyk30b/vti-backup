import { CreateJobDto } from './create-job.request.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsInt, IsMongoId, IsOptional } from 'class-validator';
import { JOB_STATUS_ENUM } from '@components/job/job.constant';
import { BaseDto } from '@core/dto/base.dto';

export class UpdateJobStatusDto extends BaseDto {
  @ApiPropertyOptional({
    example: '633fe785a45c9b2bcbd63c58',
  })
  @IsOptional()
  @IsMongoId()
  id: string;

  @IsInt()
  @ApiProperty({
    example: 0,
  })
  @IsEnum(JOB_STATUS_ENUM)
  status: number;
}
