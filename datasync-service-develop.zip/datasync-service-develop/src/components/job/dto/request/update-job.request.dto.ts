import { CreateJobDto } from './create-job.request.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsMongoId, IsOptional } from 'class-validator';

export class UpdateJobDocumentDto extends CreateJobDto {
  @ApiPropertyOptional({
    example: '633fe785a45c9b2bcbd63c58',
  })
  @IsOptional()
  @IsMongoId()
  id: string;
}
