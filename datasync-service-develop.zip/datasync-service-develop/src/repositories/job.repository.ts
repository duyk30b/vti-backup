import { JobRepositoryInterface } from '@components/job/interface/job.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { JobModel, JobStatus } from 'src/model/job/job.model';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { UpdateJobDocumentDto } from '@components/job/dto/request/update-job.request.dto';
import { GetListJobRequestDto } from '@components/job/dto/request/get-list-job.request.dto';
import { isEmpty } from 'lodash';
import { FIELD_JOB_ENUM, JOB_STATUS_ENUM } from '@components/job/job.constant';
import { SortOrder } from '@constant/common';
import { CreateJobDto } from '@components/job/dto/request/create-job.request.dto';

@Injectable()
export class JobRepository
  extends BaseAbstractRepository<JobModel>
  implements JobRepositoryInterface
{
  constructor(
    @InjectModel('jobs')
    private readonly jobModel: Model<JobModel>,
  ) {
    super(jobModel);
  }

  async createJobDocument(data: CreateJobDto) {
    const jobDocument = new this.jobModel();
    jobDocument.resourceCode = data.resourceCode;
    jobDocument.typeTransaction = data.typeTransaction;
    jobDocument.retryMessagePattern = data?.retryMessagePattern;
    jobDocument.fromSystem = data?.fromSystem;
    jobDocument.toSystem = data?.toSystem;
    jobDocument.object = data?.object;
    jobDocument.status = JOB_STATUS_ENUM.PENDING;
    jobDocument.dateFrom = data?.dateFrom || new Date();
    jobDocument.createdBy = data.createdBy;
    jobDocument.service = data?.service;
    jobDocument.event = data?.event;
    jobDocument.urlDetail = data?.urlDetail;
    const jobStatus = new JobStatus();
    jobStatus.status = jobDocument.status;
    jobDocument.history.push(jobStatus);
    return jobDocument;
  }

  async getDetailJob(id: string) {
    const jobDetail = await this.jobModel.findById(new Types.ObjectId(id));
    return jobDetail;
  }

  async findAndDeleteOneDocumentById(id: string) {
    const jobDel = await this.jobModel
      .findOneAndUpdate(
        {
          _id: new Types.ObjectId(id),
          deletedAt: null,
        },
        {
          deletedAt: new Date(),
        },
      )
      .exec();
    return jobDel;
  }

  async updateDocument(data: UpdateJobDocumentDto) {
    const result = await this.jobModel.findByIdAndUpdate(data.id, {
      resourceCode: data.resourceCode,
      typeTransaction: data?.typeTransaction,
      object: data?.object,
      fromSystem: data?.fromSystem,
      toSystem: data?.toSystem,
      dateFrom: data?.dateFrom,
      createdBy: data?.createdBy,
      event: data?.event,
      urlDetail: data?.urlDetail,
    });
    const status = result.status;
    if (data.status != status) {
      const jobStatus = new JobStatus();
      jobStatus.status = data.status;
      result.status = data.status;
      result.history.push(jobStatus);
    }
    return await result.save();
  }

  async getList(data: GetListJobRequestDto): Promise<any> {
    const { sort, take, skip, keyword, filter } = data;
    let sortObj = {};
    let filterObj = {};
    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const sortDeirection = item.order == 'DESC' ? -1 : 1;
        switch (item.column) {
          case FIELD_JOB_ENUM.RESOURCE_CODE.COLUMN:
            sortObj = {
              ...sortObj,
              resourceCode: sortDeirection,
            };
            break;
          case FIELD_JOB_ENUM.TYPE_TRANSACTION.COLUMN:
            sortObj = {
              ...sortObj,
              typeTransaction: sortDeirection,
            };
            break;
          case FIELD_JOB_ENUM.FROM_SYSTEM.COLUMN:
            sortObj = {
              ...sortObj,
              fromSystem: sortDeirection,
            };
            break;
          case FIELD_JOB_ENUM.TO_SYSTEM.COLUMN:
            sortObj = {
              ...sortObj,
              toSystem: sortDeirection,
            };
            break;
          case FIELD_JOB_ENUM.STATUS.COLUMN:
            sortObj = {
              ...sortObj,
              status: sortDeirection,
            };
            break;
          default:
            sortObj = {
              ...sortObj,
              dateFrom: SortOrder.Descending,
            };
            break;
        }
      });
    } else {
      sortObj = { dateFrom: SortOrder.Descending };
    }

    if (keyword) {
      filterObj = {
        ...filterObj,
        resourceCode: { $regex: '.*' + keyword + '.*', $options: 'i' },
      };
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const text = item.text;
        switch (item.column) {
          case FIELD_JOB_ENUM.RESOURCE_CODE.COLUMN:
            filterObj = {
              ...filterObj,
              resourceCode: { $regex: '.*' + text + '.*', $options: 'i' },
            };
            break;
          case FIELD_JOB_ENUM.TYPE_TRANSACTION.COLUMN:
            filterObj = {
              ...filterObj,
              typeTransaction: { $regex: text, $options: 'i' },
            };
            break;
          case FIELD_JOB_ENUM.FROM_SYSTEM.COLUMN:
            filterObj = {
              ...filterObj,
              fromSystem: { $regex: '.*' + text + '.*', $options: 'i' },
            };
            break;
          case FIELD_JOB_ENUM.TO_SYSTEM.COLUMN:
            filterObj = {
              ...filterObj,
              toSystem: { $regex: '.*' + text + '.*', $options: 'i' },
            };
            break;
          case FIELD_JOB_ENUM.STATUS.COLUMN:
            filterObj = {
              ...filterObj,
              status: text,
            };
            break;
          case 'createdAt':
            const createdFrom = text.split('|')[0];
            const createdTo = text.split('|')[1];
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: createdFrom,
                $lt: createdTo,
              },
            };
            break;
          case 'dateFrom':
            const dateFromStartFind = text.split('|')[0];
            const dateFromEndFind = text.split('|')[1];
            filterObj = {
              ...filterObj,
              dateFrom: {
                $gte: dateFromStartFind,
                $lt: dateFromEndFind,
              },
            };
            break;
          default:
            break;
        }
      });
    }
    const result = await this.jobModel
      .find(filterObj)
      .limit(take)
      .skip(skip)
      .sort(sortObj)
      .exec();

    const total = await this.jobModel.find(filterObj).count().exec();
    return { result: result, count: total };
  }
}
