import { BaseDto } from './../../../../core/dto/base.dto';
export class VerifyLicenseRequestDto extends BaseDto {
  license: string;
  numberContract: string;
}