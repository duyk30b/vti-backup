export enum CustomConfigEnum {
    // ================= Pagination ===============================
    TAKE_PAGINATION = 20,
    SKIP_PAGINATION = 0,
}