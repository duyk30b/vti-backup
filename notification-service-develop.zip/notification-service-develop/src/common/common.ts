export enum APIPrefix {
  Version = 'api/v1/notifications',
  Socket = 'notifications',
  ItemSocket = 'items',
}
