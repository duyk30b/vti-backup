import { Injectable } from '@nestjs/common';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { NotificationModel } from '../models/notification/notification.model';
import { NotificationRepositoryInterface } from '@components/notification/interface/notification.repository.interface';
import { CreateNotificationRequestDto } from '@components/notification/dto/request/create-notification.request.dto';
import { GetListNotificationRequestDto } from '@components/notification/dto/request/list-notification.request.dto';
import { isEmpty } from 'lodash';
import {
  NOTIFICATION_RULES,
  StatusNotificationEnum,
} from '@components/notification/notification.constant';
import { SortOrder } from '@constant/common';
import { findByIdAndPopulateHistory } from '@utils/extensions/mongoose.extension';
import { UpdateNotificationRequestDto } from '@components/notification/dto/request/update-notification.request.dto';

@Injectable()
export class NotificationRepository
  extends BaseAbstractRepository<NotificationModel>
  implements NotificationRepositoryInterface
{
  constructor(
    @InjectModel('Notification')
    private readonly notificationModel: Model<NotificationModel>,
  ) {
    super(notificationModel);
  }

  createNotification(param: CreateNotificationRequestDto): NotificationModel {
    const notification = new this.notificationModel();
    notification.title = param.title;
    notification.content = param?.content;
    notification.templateId = param?.templateId;
    notification.status = StatusNotificationEnum.CREATED;
    notification.executionDate = param.executionDate;
    notification.type = param.type;
    notification.action = param.action;
    notification.payload = param.payload;
    notification.createdBy = param?.createdBy || param.userId;
    return notification;
  }

  async getList(request: GetListNotificationRequestDto): Promise<any> {
    const { keyword, sort, filter, take, skip } = request;

    let filterObj = {};
    let sortObj = {};

    if (!isEmpty(keyword)) {
      filterObj = {
        $or: [{ title: { $regex: '.*' + keyword + '.*', $options: 'i' } }],
      };
    }
    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const text = item.text;
        switch (item.column) {
          case 'title':
            filterObj = {
              ...filterObj,
              title: { $regex: '.*' + text + '.*', $options: 'i' },
            };
            break;
          case 'type':
            filterObj = {
              ...filterObj,
              type: { $regex: '.*' + text + '.*', $options: 'i' },
            };
            break;
          case 'status':
            filterObj = {
              ...filterObj,
              status: {
                $in: [item.text],
              },
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const sortDirection = item.order == 'DESC' ? -1 : 1;
        switch (item.column) {
          case NOTIFICATION_RULES.TITLE.COLUMN:
            sortObj = {
              ...sortObj,
              title: sortDirection,
            };
            break;
          case NOTIFICATION_RULES.STATUS.COLUMN:
            sortObj = {
              ...sortObj,
              status: sortDirection,
            };
            break;
          case NOTIFICATION_RULES.EXECUTION_DATE.COLUMN:
            sortObj = {
              ...sortObj,
              executionDate: sortDirection,
            };
          default:
            break;
        }
      });
    } else {
      sortObj = { createdAt: SortOrder.Descending };
    }

    const result = await this.notificationModel
      .find(filterObj)
      .sort(sortObj)
      .skip(skip)
      .limit(take)
      .exec();
    return { result: result, count: result.length };
  }

  async detail(id: string): Promise<any> {
    const result = await this.notificationModel.findById(id);
    return result;
  }

  async update(request: UpdateNotificationRequestDto): Promise<any> {
    const result = await this.notificationModel.findByIdAndUpdate(request.id, {
      title: request.title,
      content: request?.content,
      templateId: request?.templateId,
      executionDate: request.executionDate,
      type: request.type,
      action: request.action,
      payload: request.payload,
    });
    return await result.save();
  }

  async delete(id: string): Promise<any> {
    const result = await this.notificationModel.findByIdAndDelete(id);
    return result;
  }

  async findById(id: string, userIds?: number[]): Promise<any> {
    const findQuery = findByIdAndPopulateHistory(this.notificationModel, id);
    const queryResult = await findQuery
      .lookup({
        from: 'notificationUser',
        localField: '_id',
        foreignField: 'notificationId',
        as: 'notificationUser',
        pipeline: userIds?.length
          ? [
              {
                $match: {
                  userId: { $in: [userIds] },
                },
              },
            ]
          : [],
      })
      .exec();

    return queryResult[0];
  }
}
