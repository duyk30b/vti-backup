import { Injectable } from '@nestjs/common';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { NotificationTemplateModel } from 'src/models/notification-template/notification-template.model';
import { NotificationTemplateRepositoryInterface } from '@components/notification/interface/notification-template.repository.interface';
import { CreateNotificationTemplateRequestDto } from '@components/notification/dto/request/create-notification-template.request.dto';
import { GetListNotificationTemplateRequestDto } from '@components/notification/dto/request/list-notification-template.request.dto';
import { isEmpty } from 'lodash';
import { NOTIFICATION_RULES } from '@components/notification/notification.constant';
import { SortOrder } from '@constant/common';
@Injectable()
export class NotificationTemplateRepository
  extends BaseAbstractRepository<NotificationTemplateModel>
  implements NotificationTemplateRepositoryInterface
{
  constructor(
    @InjectModel('NotificationTemplate')
    private readonly notificationTemplateModel: Model<NotificationTemplateModel>,
  ) {
    super(notificationTemplateModel);
  }
  createNotificationTemplate(
    param: CreateNotificationTemplateRequestDto,
  ): NotificationTemplateModel {
    const notificationTemplate = new this.notificationTemplateModel();
    notificationTemplate.title = param.title;
    notificationTemplate.content = param.content;
    notificationTemplate.description = param?.description;
    return notificationTemplate;
  }

  async detail(id: string): Promise<any> {
    const result = await this.notificationTemplateModel.findById(id);
    return result;
  }
  async getList(request: GetListNotificationTemplateRequestDto): Promise<any> {
    const { keyword, sort, filter, take, skip } = request;

    let filterObj = {};
    let sortObj = {};

    if (!isEmpty(keyword)) {
      filterObj = {
        $or: [{ title: { $regex: '.*' + keyword + '.*', $options: 'i' } }],
      };
    }
    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const text = item.text;
        switch (item.column) {
          case 'title':
            filterObj = {
              ...filterObj,
              title: { $regex: '.*' + text + '.*', $options: 'i' },
            };
            break;
          case 'description':
            filterObj = {
              ...filterObj,
              description: { $regex: '.*' + text + '.*', $options: 'i' },
            };
            break;
          default:
            break;
        }
      });
    }
    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const sortDirection = item.order == 'DESC' ? -1 : 1;
        switch (item.column) {
          case NOTIFICATION_RULES.TITLE.COLUMN:
            sortObj = {
              ...sortObj,
              title: sortDirection,
            };
            break;
          case 'description':
            sortObj = {
              ...sortObj,
              description: sortDirection,
            };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = { createdAt: SortOrder.Descending };
    }

    const result = await this.notificationTemplateModel
      .find(filterObj)
      .limit(take)
      .skip(skip)
      .sort(sortObj)
      .exec();
    return { result: result, count: result.length };
  }

  async update(param: any): Promise<any> {
    const result = await this.notificationTemplateModel.findByIdAndUpdate(
      param.id,
      {
        title: param.title,
        content: param.content,
        description: param.description,
      },
    );
    return await result.save();
  }
  async delete(id: string): Promise<any> {
    const result = await this.notificationTemplateModel.findByIdAndDelete(id);
    return result;
  }
}
