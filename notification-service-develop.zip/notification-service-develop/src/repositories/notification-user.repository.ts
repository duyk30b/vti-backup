import { Injectable } from '@nestjs/common';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { NotificationUserModel } from 'src/models/user-notification/user-notification.model';
import { NotificationUserRepositoryInterface } from '@components/notification/interface/notification-user.repository.interface';
import { GetListNotificationUserRequestDto } from '@components/notification/dto/request/list-notification-user.request.dto';
import { GetListNotificationUserByNotificationId } from '@components/notification/dto/request/list-notification-user-by-notification-id.request.dto';
import { SortOrder } from '@constant/common';
import { isEmpty } from 'lodash';
import {
  NOTIFICATION_RULES,
  StatusNotificationUserEnum,
} from '@components/notification/notification.constant';
import { DetailNotificationUserRequestDto } from '@components/notification/dto/request/detail-notification-user.request.dto';
import { Types, Model } from 'mongoose';
import { SeenAllNotificationUserRequestDto } from '@components/notification/dto/request/seen-all-notification-user.request.dto';

const ObjectId = Types.ObjectId;
@Injectable()
export class NotificationUserRepository
  extends BaseAbstractRepository<NotificationUserModel>
  implements NotificationUserRepositoryInterface
{
  constructor(
    @InjectModel('NotificationUser')
    private readonly notificationUserModel: Model<NotificationUserModel>,
  ) {
    super(notificationUserModel);
  }

  async getList(request: GetListNotificationUserRequestDto): Promise<any> {
    const { keyword, sort, filter, take, skip, lastId, type } = request;

    const filterObj = type ? { type } : {};
    let sortObj = {};
    if (!isEmpty(keyword)) {
      filterObj['$or'] = [
        {
          title: { $regex: '.*' + keyword + '.*', $options: 'i' },
        },
      ];
    }
    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const text = item.text;
        switch (item.column) {
          case 'title':
            filterObj['title'] = { $regex: '.*' + text + '.*', $options: 'i' };
            break;
          default:
            break;
        }
      });
    }
    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const sortDirection = item.order == 'DESC' ? -1 : 1;
        switch (item.column) {
          case NOTIFICATION_RULES.TITLE.COLUMN:
            sortObj = {
              ...sortObj,
              title: sortDirection,
            };
            break;
          case NOTIFICATION_RULES.STATUS.COLUMN:
            sortObj = {
              ...sortObj,
              status: sortDirection,
            };
            break;
          case NOTIFICATION_RULES.READ_AT.COLUMN:
            sortObj = {
              ...sortObj,
              readAt: sortDirection,
            };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = { createdAt: SortOrder.Descending, _id: SortOrder.Descending };
    }

    if (lastId) {
      sortObj = {
        _id: -1,
      };
    } else {
      sortObj = { createdAt: SortOrder.Descending, _id: SortOrder.Descending };
    }
    const condition: any = {
      $and: [
        {
          userId: request.userId,
        },
        {
          status: {
            $in: [
              StatusNotificationUserEnum.SUCCESS,
              StatusNotificationUserEnum.CREATED,
            ],
          },
        },
        {
          _id: { $lt: new ObjectId(lastId) },
        },
      ],
      ...filterObj,
    };
    const result = await this.model
      .find(condition)
      .populate('notificationId')
      .sort(sortObj)
      .limit(take)
      .skip(skip)
      .exec();
    const data = await this.notificationUserModel.find({
      $and: [
        {
          userId: request.userId,
        },
        {
          status: {
            $in: [
              StatusNotificationUserEnum.SUCCESS,
              StatusNotificationUserEnum.CREATED,
            ],
          },
        },
        {
          readAt: null,
        },
      ],
      ...filterObj,
    });

    const totalUnRead = data.length;
    return {
      result: result,
      count: result.length,
      totalUnRead: totalUnRead,
      lastId: lastId,
    };
  }

  async getListByNotificationId(
    request: GetListNotificationUserByNotificationId,
  ): Promise<any> {
    const { notificationId, take, skip } = request;
    const result = await this.notificationUserModel
      .find({
        notificationId: notificationId,
      })
      .limit(take)
      .skip(skip)
      .exec();
    return result;
  }

  async detail(request: DetailNotificationUserRequestDto): Promise<any> {
    const { id, userId } = request;
    const result = await this.notificationUserModel.aggregate([
      {
        $lookup: {
          from: 'notification',
          localField: 'notificationId',
          foreignField: '_id',
          as: 'notification',
        },
      },
      {
        $match: {
          $and: [{ userId: userId }, { _id: new ObjectId(`${id}`) }],
        },
      },
    ]);

    return result;
  }

  async seenAllNotificationUser(
    request: SeenAllNotificationUserRequestDto,
  ): Promise<any> {
    return await this.notificationUserModel.updateMany(
      {
        userId: {
          $in: [request.userId],
        },
        readAt: null,
      },
      {
        $set: { readAt: new Date() },
      },
    );
  }

  async findByIdsAndUpdate(ids: Types.ObjectId[], update: any): Promise<void> {
    const query = this.notificationUserModel.updateMany(
      {
        _id: {
          $in: ids,
        },
      },
      update,
    );

    await query.exec();
  }
}
