import { Controller, Inject } from '@nestjs/common';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { MessagePattern } from '@nestjs/microservices';

@Controller('user')
export class UserController {
  constructor(
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,
  ) {}

  @MessagePattern('get_factory_list_for_supply')
  async getFactoryList(): Promise<any> {
    return await this.userService.getFactoryList();
  }

  @MessagePattern('get_user_list')
  async getUserList(): Promise<any> {
    return await this.userService.getUserList();
  }

  @MessagePattern('get_user_list_by_department')
  async getUserListByDepartment(): Promise<any> {
    return await this.userService.getUserListByDepartment();
  }

  @MessagePattern('get_firebase_token_by_user_ids')
  async getFirebaseTokenByUserIds(userIds: number[]): Promise<any> {
    return await this.userService.getFirebaseTokenByUserIds(userIds);
  }
}
