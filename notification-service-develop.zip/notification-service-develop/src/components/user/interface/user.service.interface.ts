import { UserResponseDto } from '../dto/response/user.response.dto';

export interface UserServiceInterface {
  getListByIDs(idList: number[]): Promise<any>;
  detailFactory(id: number): Promise<any>;
  detailUser(id: number): Promise<any>;
  detailCompany(id: number): Promise<any>;
  getUserList(): Promise<any>;
  getFactoryList(): Promise<any>;
  detailFactoryById(id: number): Promise<any>;
  getUserById(id: number): Promise<any>;
  getUserListByDepartment(): Promise<any>;
  getUsersByUsernames(usernames: string[]): Promise<any[]>;
  getFirebaseTokenByUserIds(userIds: number[]): Promise<any>;
  getUsers(userIds: number[]): Promise<UserResponseDto[]>;
}
