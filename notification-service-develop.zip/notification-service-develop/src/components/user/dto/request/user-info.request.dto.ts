import { Type } from 'class-transformer';
import { IsNotEmpty } from 'class-validator';

class UserRoleSettingResponse {
  @IsNotEmpty()
  id: number;

  @IsNotEmpty()
  name: string;

  @IsNotEmpty()
  code: string;
}

class DepartmentSettingResponse {
  @IsNotEmpty()
  id: number;
}
class FactoryResponse {
  @IsNotEmpty()
  id: number;
}

export class UserInforRequestDto {
  @IsNotEmpty()
  id: number;

  @IsNotEmpty()
  email: string;

  @IsNotEmpty()
  username: string;

  @IsNotEmpty()
  fullName: string;

  @IsNotEmpty()
  companyId: string;

  @IsNotEmpty()
  dateOfBirth: string;

  @IsNotEmpty()
  code: string;

  @IsNotEmpty()
  phone: string;

  @IsNotEmpty()
  status: number;

  @IsNotEmpty()
  createdAt: string;

  @IsNotEmpty()
  updatedAt: string;

  @IsNotEmpty()
  @Type(() => UserRoleSettingResponse)
  userRoleSettings: UserRoleSettingResponse[];

  @IsNotEmpty()
  @Type(() => DepartmentSettingResponse)
  departmentSettings: DepartmentSettingResponse[];

  @IsNotEmpty()
  @Type(() => FactoryResponse)
  factories: FactoryResponse[];
}
