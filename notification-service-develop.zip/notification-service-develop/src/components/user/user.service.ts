import { GetUserListResponseDto } from '@components/user/dto/response/get-user-list.response.dto';
import { NATS_USER } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Inject, Injectable } from '@nestjs/common';
import { REQUEST } from '@nestjs/core';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToClass, plainToInstance } from 'class-transformer';
import { I18nService } from 'nestjs-i18n';
import { GetListFactoryResponseDto } from './dto/response/get-list-factory.response.dto';
import { UserResponseDto } from './dto/response/user.response.dto';
import { UserServiceInterface } from './interface/user.service.interface';

@Injectable()
export class UserService implements UserServiceInterface {
  constructor(
    private readonly natsClientService: NatsClientService,
    private readonly i18n: I18nService,
    @Inject(REQUEST)
    private readonly request: any,
  ) {}
  async detailUser(id: number): Promise<any> {
    return await this.natsClientService.send(`${NATS_USER}.detail`, {
      id: id,
      userId: this.request.userId,
    });
  }

  async getListUserByIds(userIds: any): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_USER}.get_users_by_ids`,
      userIds,
    );
  }

  async detailFactory(id: number): Promise<any> {
    return await this.natsClientService.send(`${NATS_USER}.detail_factory`, {
      id: id,
      userId: this.request.userId,
    });
  }

  async getUserList(): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_USER}.list`,
        1,
      );
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }
      const result = plainToClass(GetUserListResponseDto, response.data.items, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (err) {
      return [];
    }
  }
  async getFactoryList(): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_USER}.list_factories`,
        1,
      );
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }
      const result = plainToInstance(
        GetListFactoryResponseDto,
        response.data.items,
        {
          excludeExtraneousValues: true,
        },
      );
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (err) {
      return [];
    }
  }

  async detailFactoryById(id: number): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_USER}.detail_factory`,
        {
          id: id,
        },
      );
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return '';
      }
      return response.data;
    } catch (err) {
      return '';
    }
  }

  async detailCompany(id: number): Promise<any> {
    return await this.natsClientService.send(`${NATS_USER}.company_detail`, {
      id: id,
      userId: this.request.userId,
    });
  }

  async listUserByIds(userIds: number[]): Promise<any> {
    return await this.natsClientService.send(`${NATS_USER}.get_users_by_ids`, {
      userIds,
    });
  }

  async getListByIDs(ids: number[], relation?: string[]): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_USER}.get_users_by_ids`,
        {
          userIds: ids,
          relation,
        },
      );

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }
      return response.data;
    } catch (err) {
      return [];
    }
  }

  async getUserById(id: number): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_USER}.detail`,
        {
          id: id,
        },
      );

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        console.log(response.message);
        return '';
      }
      return response.data;
    } catch (err) {
      console.log(err);
      return '';
    }
  }
  async getUserListByDepartment(): Promise<any> {
    try {
      const departmentNameFilter = 'IT';
      const request = {
        isGetAll: '1',
        filter: [
          {
            column: 'departmentName',
            text: departmentNameFilter.trim(),
          },
        ],
      };
      const response = await this.natsClientService.send(
        `${NATS_USER}.list`,
        request,
      );

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }

      const result = plainToClass(GetUserListResponseDto, response.data.items, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (err) {
      return [];
    }
  }

  async getUsersByUsernames(usernames: string[]): Promise<any[]> {
    try {
      const usernamesAsStr = usernames.join(',');

      const response = await this.natsClientService.send(`${NATS_USER}.list`, {
        filter: [{ column: 'listUsername', text: usernamesAsStr }],
      });

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }
      return response.data.items;
    } catch (err) {
      return [];
    }
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  async getFirebaseTokenByUserIds(userIds: number[]): Promise<any> {
    return [
      {
        id: 1,
        tokens: '',
      },
    ];
  }

  async getUsers(userIds: number[]): Promise<UserResponseDto[]> {
    const response = await this.natsClientService.send(
      `${NATS_USER}.get_users_by_ids`,
      {
        userIds,
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    const dataReturn = plainToClass(UserResponseDto, <any[]>response.data, {
      excludeExtraneousValues: true,
    });

    return dataReturn;
  }
}
