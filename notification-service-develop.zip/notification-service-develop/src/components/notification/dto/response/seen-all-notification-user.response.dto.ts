import { BaseResponseDto } from '@core/dto/base.response.dto';
export class SeenAllNotificationUserResponseDto extends BaseResponseDto {}
