import { DetailNotificationUserResponseDto } from './get-detail-notification-user.response.dto';

export class SeenNotificationUserResponseDto extends DetailNotificationUserResponseDto {}
