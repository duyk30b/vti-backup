import { DetailNotificationResponseDto } from './get-detail-notification.response.dto';

export class ListNotificationResponseDto extends DetailNotificationResponseDto {}
