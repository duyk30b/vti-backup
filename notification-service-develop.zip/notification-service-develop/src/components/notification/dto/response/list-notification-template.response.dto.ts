import { DetailNotificationTemplateResponseDto } from './get-detail-notification-template.response.dto';

export class ListNotificationTemplateResponseDto extends DetailNotificationTemplateResponseDto {}
