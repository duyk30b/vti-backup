import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { Date } from 'mongoose';

class UserResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  username: string;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  fullName: string;
}
class Payload {
  @ApiProperty({
    example: 'id tên đơn bán hàng',
    description: 'id đối tượng được gửi thông báo',
  })
  @Expose()
  id: number;

  @ApiProperty({
    example: 'Tên đơn bán hàng',
    description: 'Tên đối tượng được gửi thông báo',
  })
  @Expose()
  name: string;

  @ApiProperty({
    example: 'Mã đơn bán hàng',
    description: 'mã đối tượng được gửi thông báo',
  })
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  content: string;

  @ApiProperty()
  @Expose()
  entityType: number;

  @ApiProperty({
    example: 'SALE_ORDER',
    description: 'loại đối tượng được gửi thông báo',
  })
  @Expose()
  entity: string;
}

export class DetailNotificationResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  title: string;

  @ApiProperty()
  @Expose()
  content: string;

  @Expose({ name: 'templateId' })
  templateId: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  executionDate: Date;

  @ApiProperty()
  @Expose()
  type: string;

  @ApiProperty()
  @Expose()
  action: string;

  @ApiProperty()
  @Expose()
  @Type(() => Payload)
  payload: Payload;

  @ApiProperty()
  @Expose()
  userId: number;

  @ApiProperty({ type: UserResponse })
  @Expose()
  @Type(() => UserResponse)
  createdByUser: UserResponse;
}
