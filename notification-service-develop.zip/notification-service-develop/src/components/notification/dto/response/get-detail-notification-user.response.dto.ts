import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';

class Payload {
  @ApiProperty()
  @Expose()
  title: string;

  @ApiProperty()
  @Expose()
  content: string;
}
export class DetailNotificationUserResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  userId: number;

  @ApiProperty()
  @Transform((value) => {
    return value.obj?.notificationId?.toString();
  })
  @Expose()
  notificationId: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  title: string;

  @ApiProperty()
  @Expose()
  content: string;

  @ApiProperty()
  @Expose()
  readAt: Date;

  @ApiProperty()
  @Expose()
  @Type(() => Payload)
  payload: Payload;
}
