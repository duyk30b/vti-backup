import { PaginationQuery } from '@utils/pagination.query';
import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId } from 'class-validator';

export class GetListNotificationUserByNotificationId extends PaginationQuery {
  @ApiProperty()
  @IsMongoId()
  notificationId: string;
}
