import { TypeNotificationEnum } from '@components/notification/notification.constant';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsEnum, IsMongoId, IsOptional, IsString } from 'class-validator';

export class GetListNotificationUserRequestDto extends PaginationQuery {
  @ApiPropertyOptional()
  @IsMongoId()
  @IsOptional()
  lastId: string;

  @ApiPropertyOptional()
  @IsEnum(TypeNotificationEnum)
  @IsString()
  @IsOptional()
  type: string;
}
