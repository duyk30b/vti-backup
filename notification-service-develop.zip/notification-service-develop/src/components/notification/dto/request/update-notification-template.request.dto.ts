import { ApiProperty } from '@nestjs/swagger';
import { CreateNotificationTemplateRequestDto } from './create-notification-template.request.dto';
import { IsMongoId } from 'class-validator';

export class UpdateNotificationTemplateRequestDto extends CreateNotificationTemplateRequestDto {
  @ApiProperty()
  @IsMongoId()
  id: string;
}
