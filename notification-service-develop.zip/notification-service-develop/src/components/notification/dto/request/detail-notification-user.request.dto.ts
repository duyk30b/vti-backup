import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId } from 'class-validator';
export class DetailNotificationUserRequestDto extends BaseDto {
  @ApiProperty()
  @IsMongoId()
  id: string;
}
