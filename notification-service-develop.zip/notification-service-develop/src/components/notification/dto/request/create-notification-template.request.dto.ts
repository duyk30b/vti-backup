import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty, MaxLength, IsOptional } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { NOTIFICATION_RULES } from '@components/notification/notification.constant';

export class CreateNotificationTemplateRequestDto extends BaseDto {
  @IsString()
  @MaxLength(NOTIFICATION_RULES.TITLE.MAX_LENGTH)
  @IsNotEmpty()
  title: string;

  @ApiProperty({ example: 'Nội dung thông báo', description: '' })
  @IsString()
  @MaxLength(NOTIFICATION_RULES.CONTENT.MAX_LENGTH)
  @IsNotEmpty()
  content: string;

  @ApiProperty({ example: 'Ghi chú mẫu thông báo', description: '' })
  @IsOptional()
  @IsString()
  @MaxLength(NOTIFICATION_RULES.DESCRIPTION.MAX_LENGTH)
  description: string;
}
