import { BaseDto } from '@core/dto/base.dto';
export class SeenAllNotificationUserRequestDto extends BaseDto {}
