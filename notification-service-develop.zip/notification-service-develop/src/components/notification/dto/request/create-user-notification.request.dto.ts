import { NOTIFICATION_RULES } from '@components/notification/notification.constant';
import { BaseDto } from '@core/dto/base.dto';
import { IsString, IsNotEmpty, MaxLength, IsMongoId } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
export class CreateUserNotificationRequestDto extends BaseDto {
  @ApiProperty({ example: '', description: '' })
  @IsMongoId()
  @IsNotEmpty()
  notificationId: string;

  @ApiProperty()
  readAt: Date;

  @ApiProperty({ example: 'Tiêu đề thông báo', description: '' })
  @IsString()
  @MaxLength(NOTIFICATION_RULES.TITLE.MAX_LENGTH)
  @IsNotEmpty()
  title: string;

  @ApiProperty({ example: 'Nội dung thông báo', description: '' })
  @IsNotEmpty()
  @IsString()
  content: string;
}
