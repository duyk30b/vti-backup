import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsNotEmpty,
  MaxLength,
  IsEnum,
  IsOptional,
  IsDateString,
  IsArray,
  ArrayUnique,
  IsNumber,
} from 'class-validator';
import {
  NotificationEntityEnum,
  TypeNotificationEnum,
  TypeNotificatoinUserRenderAction,
} from '@components/notification/notification.constant';
import { Type } from 'class-transformer';
import { BaseDto } from '@core/dto/base.dto';
import { NOTIFICATION_RULES } from '@components/notification/notification.constant';
import { Date } from 'mongoose';

class Payload extends BaseDto {
  @ApiProperty({
    description: 'id đối tượng được gửi thông báo',
  })
  @IsOptional()
  id: any;

  @ApiProperty({
    example: 'Tên đơn bán hàng',
    description: 'Tên đối tượng được gửi thông báo',
  })
  @IsOptional()
  @IsString()
  @MaxLength(NOTIFICATION_RULES.PAYLOAD.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({
    example: 'Mã đơn bán hàng',
    description: 'mã đối tượng được gửi thông báo',
  })
  @IsOptional()
  @IsString()
  @MaxLength(NOTIFICATION_RULES.PAYLOAD.CODE.MAX_LENGTH)
  code: string;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  entityType: number;

  @ApiProperty({
    description: 'loại đối tượng được gửi thông báo',
  })
  @IsOptional()
  @IsEnum(NotificationEntityEnum)
  entity: number;
}
export class CreateNotificationRequestDto extends BaseDto {
  @ApiProperty({ example: 'Tiêu đề thông báo', description: '' })
  @IsString()
  @MaxLength(NOTIFICATION_RULES.TITLE.MAX_LENGTH)
  @IsNotEmpty()
  title: string;

  @ApiProperty({ example: 'Nội dung thông báo cáo', description: '' })
  @IsNotEmpty()
  @IsString()
  content: string;

  @ApiProperty({ example: '6201e7c79dd4cfb0105964e6', description: '' })
  @IsOptional()
  templateId: string;

  @ApiProperty({ example: '2022-02-11 08:48:58.458', description: '' })
  @IsDateString()
  @IsOptional()
  executionDate: Date;

  @ApiProperty({ example: 'MAIL, APP, WEB', description: '' })
  @IsString()
  @IsNotEmpty()
  @IsEnum(TypeNotificationEnum)
  type: string;

  @ApiProperty({
    description:
      'ACTION_CONFIRM_VIEW_REJECT = 1,ACTION_VIEW_CONFIRM = 2,ACTION_VIEW = 3,',
  })
  @IsNotEmpty()
  @IsString()
  @IsEnum(TypeNotificatoinUserRenderAction)
  action: string;

  @ApiProperty({ type: Payload, description: 'title, content' })
  @IsNotEmpty()
  @Type(() => Payload)
  payload: Payload;

  @ApiProperty({ type: Number, description: '' })
  @IsArray()
  @ArrayUnique()
  @IsNotEmpty()
  userIds: number[];

  @ApiProperty({ type: Number, description: '' })
  @IsNumber()
  @IsOptional()
  createdBy: number;
}
