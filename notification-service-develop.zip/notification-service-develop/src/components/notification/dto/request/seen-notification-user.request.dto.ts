import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId } from 'class-validator';

export class SeenNotificationUserBodyDto extends BaseDto {}
export class SeenNotificationUserRequestDto extends SeenNotificationUserBodyDto {
  @ApiProperty()
  @IsMongoId()
  id: string;
}
