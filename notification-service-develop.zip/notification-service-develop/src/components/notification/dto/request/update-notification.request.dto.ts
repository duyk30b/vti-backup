import { ApiProperty } from '@nestjs/swagger';
import { CreateNotificationRequestDto } from './create-notification.request.dto';
import { IsMongoId } from 'class-validator';

export class UpdateNotificationRequestDto extends CreateNotificationRequestDto {
  @ApiProperty()
  @IsMongoId()
  id: string;
}
