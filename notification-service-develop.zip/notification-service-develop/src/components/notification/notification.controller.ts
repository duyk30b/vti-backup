import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { Server } from 'http';
import { isEmpty } from 'lodash';
import { CreateNotificationTemplateRequestDto } from './dto/request/create-notification-template.request.dto';
import { CreateNotificationRequestDto } from './dto/request/create-notification.request.dto';
import { DetailNotificationUserRequestDto } from './dto/request/detail-notification-user.request.dto';
import { GetListNotificationTemplateRequestDto } from './dto/request/list-notification-template.request.dto';
import { GetListNotificationUserRequestDto } from './dto/request/list-notification-user.request.dto';
import { GetListNotificationRequestDto } from './dto/request/list-notification.request.dto';
import { SeenAllNotificationUserRequestDto } from './dto/request/seen-all-notification-user.request.dto';
import { SeenNotificationUserBodyDto } from './dto/request/seen-notification-user.request.dto';
import { UpdateNotificationTemplateRequestDto } from './dto/request/update-notification-template.request.dto';
import { UpdateNotificationRequestDto } from './dto/request/update-notification.request.dto';
import { DetailNotificationTemplateResponseDto } from './dto/response/get-detail-notification-template.response.dto';
import { DetailNotificationUserResponseDto } from './dto/response/get-detail-notification-user.response.dto';
import { DetailNotificationResponseDto } from './dto/response/get-detail-notification.response.dto';
import { NotificationServiceInterface } from './interface/notification.service.interface';
import { PushNotificationGateway } from './push-notification-socket.gateway';
import { NATS_NOTIFICATION } from '@config/nats.config';
@Controller('')
export class NotificationController {
  private socket: Server;
  constructor(
    @Inject('NotificationServiceInterface')
    private readonly notificationService: NotificationServiceInterface,
    private gateway: PushNotificationGateway,
  ) {}

  //TODO CRUD Notitification

  @MessagePattern(`${NATS_NOTIFICATION}.createNotification`)
  @Post('/')
  @ApiOperation({
    tags: ['Notification'],
    summary: 'Create Notification',
    description: 'Create Notification',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: DetailNotificationResponseDto,
  })
  async createNotification(
    @Body() payload: CreateNotificationRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.notificationService.createNotification(request);
  }

  @ApiOperation({
    tags: ['Notification'],
    summary: 'All Notification',
    description: 'ALl Notification',
  })
  @ApiResponse({
    status: 200,
    description: 'All successfully',
  })
  @ApiOperation({
    tags: ['Notification'],
    summary: 'List Notification',
    description: 'List Notification',
  })
  @ApiResponse({
    status: 200,
    description: 'List successfully',
    type: DetailNotificationResponseDto,
  })
  @Get('/list')
  async getListNotification(
    @Query() payload: GetListNotificationRequestDto,
  ): Promise<any> {
    return await this.notificationService.getListNotification(payload.request);
  }

  @ApiOperation({
    tags: ['Notification'],
    summary: 'Detail Notification',
    description: 'Detail Notification',
  })
  @ApiResponse({
    status: 200,
    description: 'Detail successfully',
    type: DetailNotificationResponseDto,
  })
  @Get('/:id')
  async detailNotification(@Param('id') id: string): Promise<any> {
    return await this.notificationService.detailNotification(id);
  }

  @ApiOperation({
    tags: ['Notification'],
    summary: 'Update Notification',
    description: 'Update Notification',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: DetailNotificationResponseDto,
  })
  @Put('/:id')
  async updateNotification(
    @Body() payload: UpdateNotificationRequestDto,
    @Param('id') id: number,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.notificationService.updateNotification({
      ...request,
      id,
    });
  }

  @ApiOperation({
    tags: ['Notification'],
    summary: 'Delete Notification',
    description: '',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
  })
  @Delete('/:id')
  async deleteNotification(@Param('id') id: string): Promise<any> {
    return this.notificationService.deleteNotification(id);
  }
  //TODO End CRUD Notification
  @ApiOperation({
    tags: ['Notification User'],
    summary: 'List Notification User',
    description: 'List Notification User',
  })
  @ApiResponse({
    status: 200,
    description: 'List successfully',
    type: DetailNotificationUserResponseDto,
  })
  @Get('/users-notification')
  async listUser(
    @Query() payload: GetListNotificationUserRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.notificationService.getListNotificationUser(request);
  }

  @ApiOperation({
    tags: ['Notification User'],
    summary: 'Detail Notification User',
    description: 'Detail Notification User',
  })
  @ApiResponse({
    status: 200,
    description: 'Detail successfully',
    type: DetailNotificationUserResponseDto,
  })
  @Get('/:id/user-notification')
  async detailUser(
    @Param() param: DetailNotificationUserRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.notificationService.detailNotificationUser(request);
  }

  @ApiOperation({
    tags: ['Notification User'],
    summary: 'Seen Notification User',
    description: 'Seen Notification User',
  })
  @ApiResponse({
    status: 200,
    description: 'Seen successfully',
    type: DetailNotificationUserResponseDto,
  })
  @Put('notification-users/:id/seen')
  async seenNotificationUser(
    @Query() payload: SeenNotificationUserBodyDto,
    @Param('id') id: string,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;
    return await this.notificationService.seenNotificationUser(request);
  }

  @ApiOperation({
    tags: ['Notification User'],
    summary: 'Seen All Notification User',
    description: 'Seen All Notification User',
  })
  @ApiResponse({
    status: 200,
    description: 'Seen All successfully',
    type: DetailNotificationUserResponseDto,
  })
  @Put('notification-users/seen/all')
  async seenAllNotificationUser(
    @Query() payload: SeenAllNotificationUserRequestDto,
  ): Promise<any> {
    return await this.notificationService.seenAllNotiByUser({
      ...payload.request,
    });
  }

  //TODO End CRUD NotificationUser

  //TODO CRUD NotificationTemplate
  @ApiOperation({
    tags: ['Notification Template'],
    summary: 'Create Notification Template',
    description: 'Create Notification Template',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: DetailNotificationTemplateResponseDto,
  })
  @Post('/template')
  async createTemplate(
    @Body() payload: CreateNotificationTemplateRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.notificationService.createNotificationTemplate(request);
  }

  @ApiOperation({
    tags: ['Notification Template'],
    summary: 'List Notification Template',
    description: 'List Notification Template',
  })
  @ApiResponse({
    status: 200,
    description: 'List successfully',
    type: DetailNotificationTemplateResponseDto,
  })
  @Get('/templates')
  async getListTemplate(
    @Query() payload: GetListNotificationTemplateRequestDto,
  ): Promise<any> {
    return await this.notificationService.getListNotificationTemplate(
      payload.request,
    );
  }

  @ApiOperation({
    tags: ['Notification Template'],
    summary: 'Detail Notification Template',
    description: 'Detail Notification Template',
  })
  @ApiResponse({
    status: 200,
    description: 'Detail successfully',
    type: DetailNotificationTemplateResponseDto,
  })
  @Get('/:id/template')
  async detailTemplate(@Param('id') id: string): Promise<any> {
    return await this.notificationService.detailNotificationTemplate(id);
  }

  @ApiOperation({
    tags: ['Notification Template'],
    summary: 'Update Notification Template',
    description: 'Update Notification Template',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  @Put(':id/template')
  async updateTemplate(
    @Body() payload: UpdateNotificationTemplateRequestDto,
    @Param('id') id: string,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.notificationService.updateNotificationTemplate({
      ...request,
      id,
    });
  }

  @ApiOperation({
    tags: ['Notification Template'],
    summary: 'Delete Notification Template',
    description: 'Delete Notification Template',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
  })
  @Delete('/:id/template')
  async deleteTemplate(@Param('id') id: string): Promise<any> {
    return this.notificationService.deleteNotificationTemplate(id);
  }
  //TODO End CRUD NotificationTemplate
}
