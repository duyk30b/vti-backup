import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { NotificationModel } from '../../../models/notification/notification.model';
import { CreateNotificationRequestDto } from '../dto/request/create-notification.request.dto';
import { GetListNotificationRequestDto } from '../dto/request/list-notification.request.dto';

export interface NotificationRepositoryInterface
  extends BaseAbstractRepository<NotificationModel> {
  createNotification(param: CreateNotificationRequestDto): NotificationModel;
  getList(request: GetListNotificationRequestDto): Promise<any>;
  detail(id: string): Promise<any>;
  findById(id: string, userIds?: number[]): Promise<any>;
  update(param: any): Promise<any>;
  delete(id: string): Promise<any>;
}
