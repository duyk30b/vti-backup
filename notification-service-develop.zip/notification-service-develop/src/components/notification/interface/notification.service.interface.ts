import { ResponsePayload } from '@utils/response-payload';
import { PagingResponse } from '@utils/paging.response';
import { CreateNotificationRequestDto } from '../dto/request/create-notification.request.dto';
import { CreateNotificationTemplateRequestDto } from '../dto/request/create-notification-template.request.dto';
import { UpdateNotificationTemplateRequestDto } from '../dto/request/update-notification-template.request.dto';
import { UpdateNotificationRequestDto } from '@components/notification/dto/request/update-notification.request.dto';
import { GetListNotificationRequestDto } from '../dto/request/list-notification.request.dto';
import { GetListNotificationTemplateRequestDto } from '../dto/request/list-notification-template.request.dto';
import { GetListNotificationUserRequestDto } from '../dto/request/list-notification-user.request.dto';
import { DetailNotificationUserRequestDto } from '../dto/request/detail-notification-user.request.dto';
import { SeenAllNotificationUserRequestDto } from '../dto/request/seen-all-notification-user.request.dto';
import { SeenNotificationUserRequestDto } from '../dto/request/seen-notification-user.request.dto';
export interface NotificationServiceInterface {
  createNotification(request: CreateNotificationRequestDto): Promise<any>;
  getListNotification(
    request: GetListNotificationRequestDto,
  ): Promise<ResponsePayload<PagingResponse>>;
  detailNotification(id: string): Promise<ResponsePayload<any>>;
  updateNotification(request: UpdateNotificationRequestDto): Promise<any>;
  deleteNotification(id: string): Promise<any>;

  createNotificationTemplate(
    request: CreateNotificationTemplateRequestDto,
  ): Promise<any>;
  getListNotificationTemplate(
    request: GetListNotificationTemplateRequestDto,
  ): Promise<ResponsePayload<any>>;
  detailNotificationTemplate(id: string): Promise<ResponsePayload<any>>;
  updateNotificationTemplate(
    request: UpdateNotificationTemplateRequestDto,
  ): Promise<any>;
  deleteNotificationTemplate(id: string): Promise<any>;

  getListNotificationUser(
    request: GetListNotificationUserRequestDto,
  ): Promise<ResponsePayload<any>>;
  detailNotificationUser(
    request: DetailNotificationUserRequestDto,
  ): Promise<ResponsePayload<any>>;
  seenNotificationUser(request: SeenNotificationUserRequestDto): Promise<any>;
  seenAllNotiByUser(request: SeenAllNotificationUserRequestDto): Promise<any>;
}
