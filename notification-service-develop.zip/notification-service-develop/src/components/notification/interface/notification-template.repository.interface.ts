import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { CreateNotificationTemplateRequestDto } from '../dto/request/create-notification-template.request.dto';
import { GetListNotificationTemplateRequestDto } from '../dto/request/list-notification-template.request.dto';
import { NotificationTemplateModel } from '../../../models/notification-template/notification-template.model';

export interface NotificationTemplateRepositoryInterface
  extends BaseAbstractRepository<NotificationTemplateModel> {
  createNotificationTemplate(
    param: CreateNotificationTemplateRequestDto,
  ): NotificationTemplateModel;
  getList(request: GetListNotificationTemplateRequestDto): Promise<any>;
  detail(id: string): Promise<any>;
  update(param: any): Promise<any>;
  delete(id: string): Promise<any>;
}
