import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Types } from 'mongoose';
import { NotificationUserModel } from '../../../models/user-notification/user-notification.model';
import { DetailNotificationUserRequestDto } from '../dto/request/detail-notification-user.request.dto';
import { GetListNotificationUserRequestDto } from '../dto/request/list-notification-user.request.dto';
import { GetListNotificationUserByNotificationId } from '../dto/request/list-notification-user-by-notification-id.request.dto';

export interface NotificationUserRepositoryInterface
  extends BaseAbstractRepository<NotificationUserModel> {
  getList(request: GetListNotificationUserRequestDto): Promise<any>;
  getListByNotificationId(
    request: GetListNotificationUserByNotificationId,
  ): Promise<any>;
  detail(request: DetailNotificationUserRequestDto): Promise<any>;
  seenAllNotificationUser(param: any): Promise<any>;
  findByIdsAndUpdate(ids: Types.ObjectId[], update: any): Promise<void>;
}
