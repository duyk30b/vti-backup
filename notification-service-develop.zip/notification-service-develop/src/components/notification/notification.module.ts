import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { NotificationSchema } from '../../models/notification/notification.schema';
import { NotificationTemplateSchema } from '../../models/notification-template/notification-template.schema';
import { NotificationUserSchema } from '../../models/user-notification/user-notification.schema';
import { NotificationController } from '@components/notification/notification.controller';
import { NotificationService } from '@components/notification/notification.service';
import { NotificationRepository } from '@repositories/notification.repository';
import { NotificationTemplateRepository } from '@repositories/notification-template.repository';
import { NotificationUserRepository } from '@repositories/notification-user.repository';
import { BullModule } from '@nestjs/bull';
import { NotificationConsumer } from './push-notification.consumer';
import { PushNotificationGateway } from '@components/notification/push-notification-socket.gateway';
import { NOTIFICATION_QUEUE } from './notification.constant';
import { PushNotiService } from '@components/firebase/firebase.service';
import { UserService } from '@components/user/user.service';
import { MailService } from '@components/mail/mail.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'Notification', schema: NotificationSchema },
      { name: 'NotificationTemplate', schema: NotificationTemplateSchema },
      { name: 'NotificationUser', schema: NotificationUserSchema },
    ]),
    BullModule.registerQueue({
      name: NOTIFICATION_QUEUE,
    }),
  ],
  controllers: [NotificationController],
  providers: [
    {
      provide: 'NotificationRepositoryInterface',
      useClass: NotificationRepository,
    },
    {
      provide: 'NotificationTemplateRepositoryInterface',
      useClass: NotificationTemplateRepository,
    },
    {
      provide: 'NotificationUserRepositoryInterface',
      useClass: NotificationUserRepository,
    },
    {
      provide: 'NotificationServiceInterface',
      useClass: NotificationService,
    },
    {
      provide: 'PushNotiServiceInterface',
      useClass: PushNotiService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'MailServiceInterface',
      useClass: MailService,
    },
    PushNotificationGateway,
    NotificationConsumer,
  ],
  exports: [MongooseModule],
})
export class NotificationModule {}
