export const NOTIFICATION_RULES = {
  TITLE: {
    MAX_LENGTH: 255,
    COLUMN: 'title',
  },
  CONTENT: {
    MAX_LENGTH: 255,
    COLUMN: 'content',
  },
  STATUS: {
    COLUMN: 'status',
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
  READ_AT: {
    COLUMN: 'readAt',
  },
  EXECUTION_DATE: {
    COLUMN: 'executionDate',
  },
  PAYLOAD: {
    NAME: {
      MAX_LENGTH: 255,
    },
    CODE: {
      MAX_LENGTH: 255,
    },
  },
};

export enum TypeNotificationEnum {
  MAIL = 'MAIL',
  WEB = 'WEB',
  APP = 'APP',
}
export enum StatusNotificationEnum {
  CREATED = 1,
  IN_PROGRESS = 2,
  COMPLETED = 3,
}

export enum StatusNotificationUserEnum {
  CREATED = 0,
  FAILURE = 1,
  SUCCESS = 2,
}

export enum TypeNotificatoinUserRenderAction {
  ACTION_CONFIRM_VIEW_REJECT = '1',
  ACTION_VIEW_CONFIRM = '2',
  ACTION_VIEW = '3',
}

export enum NotificationEntityEnum {
  SALE_ORDER = 1,
  PRODUCING_STEP = 2,
  WORK_CENTER = 3,
  ROUTING = 4,
  BOQ = 5,
  MASTER_PLAN = 6,
  MATERIAL_REQUEST_WARNING = 7,
  MANUFACTORING_ORDER = 8,
  DEVICE_REQUEST_DETAIL = 9,
  DEVICE_ASSIGN_DETAIL = 10,
  JOB_LIST = 11,
  JOB_DETAIL = 12,
  REPAIR_REQUEST_DETAIL = 13,
  WARNING_SYSTEM = 14,
}

export enum GetAllConstant {
  NO = 0,
  YES = 1,
}

export const CAN_STATUS_UPDATE_NOTIFICATION = [StatusNotificationEnum.CREATED];

export const PREFIX_CHANNEL_WEB = 'channel-notification';

export const CHANNEL_NOTIFICATION_WEB = `${PREFIX_CHANNEL_WEB}-{userId}`;

export const PUSH_NOTIFICATION_QUEUE = 'PUSH_NOTIFICATION_QUEUE';

export const NOTIFICATION_QUEUE = 'NOTIFICATION_QUEUE';

export const USERS_RECEIVE_EMAIL_PER_TIME = 20;
