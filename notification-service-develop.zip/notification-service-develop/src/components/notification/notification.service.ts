import { Injectable, Inject } from '@nestjs/common';
import { PagingResponse } from '@utils/paging.response';
import { I18nService } from 'nestjs-i18n';
import { plainToClass, plainToInstance } from 'class-transformer';
import { ResponsePayload } from '@utils/response-payload';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NotificationRepositoryInterface } from './interface/notification.repository.interface';
import { NotificationUserRepositoryInterface } from './interface/notification-user.repository.interface';
import { NotificationTemplateRepositoryInterface } from './interface/notification-template.repository.interface';
import { CreateNotificationRequestDto } from '@components/notification/dto/request/create-notification.request.dto';
import { CreateNotificationTemplateRequestDto } from '@components/notification/dto/request/create-notification-template.request.dto';
import { UpdateNotificationRequestDto } from './dto/request/update-notification.request.dto';
import { UpdateNotificationTemplateRequestDto } from './dto/request/update-notification-template.request.dto';
import { GetListNotificationRequestDto } from './dto/request/list-notification.request.dto';
import { GetListNotificationTemplateRequestDto } from './dto/request/list-notification-template.request.dto';
import { GetListNotificationUserRequestDto } from './dto/request/list-notification-user.request.dto';
import { ListNotificationResponseDto } from './dto/response/list-notification.response.dto';
import { DetailNotificationResponseDto } from './dto/response/get-detail-notification.response.dto';
import { DetailNotificationTemplateResponseDto } from './dto/response/get-detail-notification-template.response.dto';
import { DetailNotificationUserResponseDto } from './dto/response/get-detail-notification-user.response.dto';
import { DetailNotificationUserRequestDto } from './dto/request/detail-notification-user.request.dto';
import {
  StatusNotificationUserEnum,
  PUSH_NOTIFICATION_QUEUE,
  NOTIFICATION_QUEUE,
  GetAllConstant,
} from './notification.constant';
import { ApiError } from '@utils/api.error';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { isEmpty, keyBy, map, uniq } from 'lodash';
import * as moment from 'moment';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { SeenNotificationUserRequestDto } from './dto/request/seen-notification-user.request.dto';
import { NotificationServiceInterface } from './interface/notification.service.interface';
import { SeenAllNotificationUserRequestDto } from './dto/request/seen-all-notification-user.request.dto';
@Injectable()
export class NotificationService implements NotificationServiceInterface {
  constructor(
    @Inject('NotificationRepositoryInterface')
    private readonly notificationRepository: NotificationRepositoryInterface,

    @Inject('NotificationTemplateRepositoryInterface')
    private readonly notificationTemplateRepository: NotificationTemplateRepositoryInterface,

    @Inject('NotificationUserRepositoryInterface')
    private readonly notificationUserRepository: NotificationUserRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    private readonly i18n: I18nService,

    @InjectQueue(NOTIFICATION_QUEUE)
    private notificationQueues: Queue,
  ) {}

  //TODO CRUD Notification

  async createNotification(
    request: CreateNotificationRequestDto,
  ): Promise<any> {
    const { userIds } = request;
    try {
      const notificationDocument =
        this.notificationRepository.createNotification(request);
      const notification = await this.notificationRepository.create(
        notificationDocument,
      );
      const response = await notification.save();
      if (!isEmpty(userIds)) {
        const createNotificationUserEntities = userIds.map((userId) => {
          return {
            title: request.title,
            content: request.content,
            status: StatusNotificationUserEnum.CREATED,
            notificationId: notification._id,
            type: notification.type,
            userId,
          };
        });
        await this.notificationUserRepository.create(
          createNotificationUserEntities,
        );
      }
      response.payload['content'] = response.content;
      const result = plainToClass(DetailNotificationResponseDto, response, {
        excludeExtraneousValues: true,
      });
      await this.notificationQueues.add(
        this.getProcessType(notification.type),
        {
          id: result.id,
        },
        { delay: this.getTimeDelay(notification.executionDate) },
      );
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } catch (error) {
      return new ResponseBuilder(error?.message)
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
  }

  private getTimeDelay(timeActive): number {
    const diffTime = moment(timeActive).diff(moment().format(), 'millisecond');
    return diffTime < 0 ? 0 : diffTime;
  }

  private getProcessType(type): string {
    const queueProcessType = `${PUSH_NOTIFICATION_QUEUE}-${type}`;
    return queueProcessType;
  }

  async detailNotification(id: string): Promise<any> {
    const response = await this.notificationRepository.detail(id);
    if (!response) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (response.createdBy) {
      const responseUserService = await this.userService.getUserById(
        response.createdBy,
      );

      response.createdByUser = responseUserService;
    }

    const result = plainToClass(DetailNotificationResponseDto, response, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getListNotification(
    request: GetListNotificationRequestDto,
  ): Promise<any> {
    if (parseInt(request.isGetAll) == GetAllConstant.YES) {
      const response = await this.notificationRepository.findAll();
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } else {
      try {
        const { result, count } = await this.notificationRepository.getList(
          request,
        );
        const response = plainToClass(ListNotificationResponseDto, result, {
          excludeExtraneousValues: true,
        });

        return new ResponseBuilder<PagingResponse>({
          items: response,
          meta: { total: count, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('success.SUCCESS'))
          .build();
      } catch (error) {
        return new ResponseBuilder(error?.message)
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .build();
      }
    }
  }

  async deleteNotification(id: string): Promise<any> {
    const notification = await this.notificationRepository.findByIdAndRemove(
      id,
    );
    if (!notification) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async updateNotification(
    request: UpdateNotificationRequestDto,
  ): Promise<any> {
    try {
      const { id } = request;
      const notification = await this.notificationRepository.detail(id);
      if (!notification) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
          .build();
      }
      await this.notificationRepository.update({ ...request });
      const response = await this.notificationRepository.detail(request.id);
      if (!response) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
          .build();
      }

      const result = plainToInstance(DetailNotificationResponseDto, response, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } catch (err) {
      return new ResponseBuilder(err?.message)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  //TODO End CRUD Notification

  //TODO CRUD NotificationUser
  async detailNotificationUser(
    request: DetailNotificationUserRequestDto,
  ): Promise<any> {
    const response = await this.notificationUserRepository.detail(request);
    if (!response) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const result = plainToClass(DetailNotificationUserResponseDto, response, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getListNotificationUser(
    request: GetListNotificationUserRequestDto,
  ): Promise<ResponsePayload<PagingResponse>> {
    try {
      const { result, count, totalUnRead, lastId } =
        await this.notificationUserRepository.getList(request);
      const userIds = uniq(map(result, 'notificationId.createdBy'));
      const users = await this.userService.getUsers(uniq(userIds));
      const userMap = keyBy(users, 'id');
      const data = [];
      result.forEach((item) => {
        data.push({
          ...item._doc,
          notificationId: {
            ...item.notificationId?._doc,
            createdBy: {
              id: userMap[item.notificationId?.createdBy]?.id,
              fullName: userMap[item.notificationId?.createdBy]?.fullName,
              userName: userMap[item.notificationId?.createdBy]?.username,
            },
          },
        });
      });
      return new ResponseBuilder<PagingResponse>({
        items: data,
        meta: {
          total: count,
          page: request.page,
          totalUnRead: totalUnRead,
          lastId: lastId,
        },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder(error?.message)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
  }

  async seenNotificationUser(
    request: SeenNotificationUserRequestDto,
  ): Promise<any> {
    try {
      const { id, userId } = request;
      const notificationUser =
        await this.notificationUserRepository.findOneByCondition({
          userId: userId,
          _id: id,
        });

      if (!notificationUser) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }

      if (notificationUser.readAt === null) {
        notificationUser.readAt = new Date();
        await notificationUser.save();
      }

      return new ResponseBuilder(notificationUser)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } catch (err) {
      return new ResponseBuilder(err?.message)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async seenAllNotiByUser(
    request: SeenAllNotificationUserRequestDto,
  ): Promise<any> {
    try {
      const notificationUser =
        await this.notificationUserRepository.seenAllNotificationUser({
          userId: request.userId,
        });
      if (notificationUser) {
        return new ResponseBuilder(notificationUser)
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    } catch (err) {
      return new ResponseBuilder(err?.message)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }
  //TODO End CRUD NotificationUser

  //TODO CRUD NotificationTemplate
  async createNotificationTemplate(
    request: CreateNotificationTemplateRequestDto,
  ): Promise<any> {
    try {
      const notificationTemplateDocument =
        this.notificationTemplateRepository.createNotificationTemplate(request);
      const notification = await this.notificationTemplateRepository.create(
        notificationTemplateDocument,
      );
      const response = await notification.save();
      const result = plainToClass(
        DetailNotificationTemplateResponseDto,
        response,
        {
          excludeExtraneousValues: true,
        },
      );
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } catch (error) {
      return new ResponseBuilder(error?.message)
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
  }

  async getListNotificationTemplate(
    request: GetListNotificationTemplateRequestDto,
  ): Promise<any> {
    if (parseInt(request.isGetAll) == GetAllConstant.YES) {
      const response = await this.notificationTemplateRepository.findAll();
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } else {
      try {
        const { result, count } =
          await this.notificationTemplateRepository.getList(request);

        return new ResponseBuilder<PagingResponse>({
          items: result,
          meta: { total: count, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('success.SUCCESS'))
          .build();
      } catch (error) {
        return new ResponseBuilder(error?.message)
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .build();
      }
    }
  }

  async detailNotificationTemplate(id: string): Promise<any> {
    const response = await this.notificationTemplateRepository.detail(id);
    if (!response) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateNotificationTemplate(
    request: UpdateNotificationTemplateRequestDto,
  ): Promise<any> {
    try {
      const { id } = request;
      const checkNotification =
        await this.notificationTemplateRepository.detail(id);
      if (!checkNotification) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
          .build();
      }
      await this.notificationTemplateRepository.update({
        ...request,
      });
      const response = await this.notificationTemplateRepository.detail(id);
      const result = plainToInstance(
        DetailNotificationTemplateResponseDto,
        response,
        { excludeExtraneousValues: true },
      );
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async deleteNotificationTemplate(id: string): Promise<any> {
    const notificationTemplate =
      await this.notificationTemplateRepository.findByIdAndRemove(id);
    if (!notificationTemplate) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  //TODO End CRUD NotificationTemplate
}
