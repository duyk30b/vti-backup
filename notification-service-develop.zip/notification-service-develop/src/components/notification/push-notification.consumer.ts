import { Process, Processor } from '@nestjs/bull';
import { Inject } from '@nestjs/common';
import { generateChannelSocket } from '@utils/common';
import { keyBy, map, mapValues } from 'lodash';
import { NotificationUserRepositoryInterface } from './interface/notification-user.repository.interface';
import { NotificationRepositoryInterface } from './interface/notification.repository.interface';
import {
  NOTIFICATION_QUEUE,
  PUSH_NOTIFICATION_QUEUE,
  StatusNotificationEnum,
  TypeNotificationEnum,
  StatusNotificationUserEnum,
  USERS_RECEIVE_EMAIL_PER_TIME,
} from './notification.constant';
import { PushNotificationGateway } from './push-notification-socket.gateway';
import { PushNotiServiceInterface } from '@components/firebase/interface/push-noti.service.interface';
import { PushMultipleNotiRequestDto } from '@components/firebase/dto/request/push-multiple-noti.request.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { MailServiceInterface } from '@components/mail/interface/mail.service.interface';
import { SendMailRequestDto } from '@components/mail/dto/request/send-mail.request.dto';
import { GetListNotificationUserByNotificationId } from './dto/request/list-notification-user-by-notification-id.request.dto';

@Processor(NOTIFICATION_QUEUE)
export class NotificationConsumer {
  constructor(
    @Inject('NotificationRepositoryInterface')
    private notificationRepository: NotificationRepositoryInterface,
    @Inject('NotificationUserRepositoryInterface')
    private readonly notificationUserRepository: NotificationUserRepositoryInterface,
    private gateway: PushNotificationGateway,
    @Inject('PushNotiServiceInterface')
    private readonly pushNotiFirebase: PushNotiServiceInterface,
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,
    @Inject('MailServiceInterface')
    private readonly mailService: MailServiceInterface,
  ) {}

  @Process(`${PUSH_NOTIFICATION_QUEUE}-${TypeNotificationEnum.WEB}`)
  async pushNotificationWeb(job: any): Promise<any> {
    const notification =
      (await this.notificationRepository.findById(job.data.id)) || {};
    // TODO format notification rồi bắn cho từng user

    await this.notificationRepository.findByIdAndUpdate(notification._id, {
      ...notification,
      status: StatusNotificationEnum.IN_PROGRESS,
    });
    const userIds = map(notification.notificationUser, 'userId');
    const userNotificationSerialize = keyBy(
      notification.notificationUser,
      'userId',
    );
    let responseUserService: any = {};
    if (notification.createdBy) {
      responseUserService = await this.userService.getUserById(
        notification.createdBy,
      );
      notification.createdBy = responseUserService;
    }
    // eslint-disable-next-line prefer-const
    let listIdUser;
    for (let i = 0; i < userIds?.length; i++) {
      const userNotification = userNotificationSerialize[userIds[i]];
      const userId = userNotification.userId;
      const response = {
        user: {
          ...userNotification,
          notificationId: {
            _id: notification._id,
            action: notification.action,
            payload: { ...notification.payload, content: notification.content },
            createdBy: {
              id: responseUserService.id,
              username: responseUserService.username,
              fullName: responseUserService.fullName,
            },
          },
        },
      };
      await this.gateway.server.emit(generateChannelSocket(userId), response);
      // TODO use userService check status notification
      // const responseUserService = await this.userService.getListByIDs(userIds);
      // if (responseUserService.status_notification) {
      //   await this.notificationUserRepository.findByIdsAndUpdate(listIdUser, {
      //     status: StatusNotificationUserEnum.SUCCESS,
      //   });
      // } else {
      //   await this.gateway.server.emit(generateChannelSocket(userId), response);
      //   await this.notificationUserRepository.findByIdsAndUpdate(listIdUser, {
      //     status: StatusNotificationUserEnum.SUCCESS,
      //   });
      // }
    }
    // eslint-disable-next-line prefer-const
    listIdUser = notification.notificationUser.map((user) => user._id);

    await this.notificationUserRepository.findByIdsAndUpdate(listIdUser, {
      status: StatusNotificationUserEnum.SUCCESS,
    });
    await this.notificationRepository.findByIdAndUpdate(notification._id, {
      ...notification,
      status: StatusNotificationEnum.COMPLETED,
    });
  }

  @Process(`${PUSH_NOTIFICATION_QUEUE}-${TypeNotificationEnum.APP}`)
  async pushNotificationApp(job: any): Promise<any> {
    const notification = await this.notificationRepository.findById(
      job.data.id,
    );
    const userIds = map(notification.notificationUser, 'userId');
    // TODO get token user
    const usersToken = await this.userService.getFirebaseTokenByUserIds(
      userIds,
    );
    const requestPushNoti = new PushMultipleNotiRequestDto();
    requestPushNoti.tokens = usersToken.map((userToken) => userToken.tokens);
    requestPushNoti.payload = {
      data: {
        action: notification.action,
        payload: notification.payload,
      },
      notification: {
        title: notification.title,
        body: notification.content,
      },
    };

    const listIdUser = notification.notificationUser
      .filter((notiUser) => map(usersToken, 'id').includes(notiUser.userId))
      .map((user) => user._id);
    const responseUserService = await this.userService.getListByIDs(userIds);
    if (responseUserService.status_notification) {
      await this.notificationUserRepository.findByIdsAndUpdate(listIdUser, {
        status: StatusNotificationUserEnum.SUCCESS,
      });
    } else {
      await this.pushNotiFirebase.pushMultiNotication(requestPushNoti);
      await this.notificationUserRepository.findByIdsAndUpdate(listIdUser, {
        status: StatusNotificationUserEnum.SUCCESS,
      });
    }
    await this.notificationUserRepository.findByIdsAndUpdate(listIdUser, {
      status: StatusNotificationUserEnum.SUCCESS,
    });
    await this.notificationRepository.findByIdAndUpdate(notification._id, {
      ...notification,
      status: StatusNotificationEnum.COMPLETED,
    });
  }

  @Process(`${PUSH_NOTIFICATION_QUEUE}-${TypeNotificationEnum.MAIL}`)
  async pushNotificationMail(job: any): Promise<any> {
    const { id } = job.data;
    await this.notificationRepository.findByIdAndUpdate(id, {
      status: StatusNotificationEnum.IN_PROGRESS,
    });

    const totalNotificationUsers = await this.notificationUserRepository.count({
      notificationId: id,
    });
    const chunkOfNotificationUsers = await Promise.all(
      [
        ...Array(
          Math.ceil(totalNotificationUsers / USERS_RECEIVE_EMAIL_PER_TIME),
        ).keys(),
      ].map((chunk) => {
        const request = new GetListNotificationUserByNotificationId();
        request.notificationId = id;
        request.limit = USERS_RECEIVE_EMAIL_PER_TIME;
        request.page = chunk;
        return this.notificationUserRepository.getListByNotificationId(request);
      }),
    );

    await Promise.all(
      chunkOfNotificationUsers.map(async (notificationUsers) => {
        const userIds = notificationUsers.map(
          (notificationUser) => notificationUser.userId,
        );

        const userByIds = await this.userService.getListByIDs(userIds);
        const emailByUserId = mapValues(keyBy(userByIds, 'id'), 'email');

        const userNotificationSerialize = keyBy(notificationUsers, 'userId');

        await Promise.all(
          userIds.map((userId: number) => {
            const userNotification = userNotificationSerialize[userId];
            const requestMail = new SendMailRequestDto();
            requestMail.email = emailByUserId[`${userId}`];
            requestMail.body = {
              subject: userNotification.title,
              text: userNotification.content,
            };
            return this.mailService.sendMail(requestMail);
          }),
        );

        const listIdUser = notificationUsers.map((user) => user._id);
        // TODO use userService check status notification
        // if (userByIds.status_notification) {
        //   this.notificationUserRepository.findByIdsAndUpdate(listIdUser, {
        //     status: StatusNotificationUserEnum.SUCCESS,
        //   });
        // }
        this.notificationUserRepository.findByIdsAndUpdate(listIdUser, {
          status: StatusNotificationUserEnum.SUCCESS,
        });
      }),
    );

    await this.notificationRepository.findByIdAndUpdate(id, {
      status: StatusNotificationEnum.COMPLETED,
    });
  }
}
