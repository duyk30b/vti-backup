import { Injectable } from '@nestjs/common';
import * as firebaseAdmin from 'firebase-admin';
import { PushNotiServiceInterface } from '@components/firebase/interface/push-noti.service.interface';
import { ResponsePayload } from '@utils/response-payload';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ResponseBuilder } from '@utils/response-builder';
import { ApiError } from '@utils/api.error';
import { PushNotiRequestDto } from '@components/firebase/dto/request/push-noti.request.dto';
import { I18nService } from 'nestjs-i18n';
import { PushMultipleNotiRequestDto } from './dto/request/push-multiple-noti.request.dto';

@Injectable()
export class PushNotiService implements PushNotiServiceInterface {
  constructor(private readonly i18n: I18nService) {}

  public async pushNoti(
    request: PushNotiRequestDto,
  ): Promise<ResponsePayload<any>> {
    try {
      const { registrationToken, payload } = request;
      await firebaseAdmin.messaging().sendToDevice(registrationToken, payload);
      return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
    } catch (error) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.INTERNAL_SERVER_ERROR'),
      ).toResponse();
    }
  }
  public async pushMultiNotication(
    request: PushMultipleNotiRequestDto,
  ): Promise<ResponsePayload<any>> {
    try {
      await firebaseAdmin.messaging().sendMulticast(request);
      return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
    } catch (error) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.INTERNAL_SERVER_ERROR'),
      ).toResponse();
    }
  }
}
