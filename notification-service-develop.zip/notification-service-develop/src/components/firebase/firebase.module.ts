import { Global, Module } from '@nestjs/common';
import { PushNotiService } from '@components/firebase/firebase.service';

@Global()
@Module({
  imports: [],
  exports: [PushNotiService],
  providers: [PushNotiService],
  controllers: [],
})
export class FirebaseModule {}
