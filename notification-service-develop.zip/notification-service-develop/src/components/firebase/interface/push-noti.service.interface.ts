import { ResponsePayload } from '@utils/response-payload';
import { PushNotiRequestDto } from '@components/firebase/dto/request/push-noti.request.dto';
import { PushMultipleNotiRequestDto } from '../dto/request/push-multiple-noti.request.dto';

export interface PushNotiServiceInterface {
  pushNoti(request: PushNotiRequestDto): Promise<ResponsePayload<any>>;
  pushMultiNotication(
    request: PushMultipleNotiRequestDto,
  ): Promise<ResponsePayload<any>>;
}
