import * as firebaseAdmin from 'firebase-admin';
import { ApiProperty } from '@nestjs/swagger';
import { BaseDto } from '@core/dto/base.dto';
import { IsArray, IsNotEmpty } from 'class-validator';

export class PushMultipleNotiRequestDto extends BaseDto {
  @ApiProperty({ example: '' })
  @IsNotEmpty()
  @IsArray()
  tokens: string[];

  @ApiProperty({
    example: {
      data: {},
      notification: {
        title: 'Notification',
        body: 'Content',
      },
    },
  })
  payload: firebaseAdmin.messaging.MessagingPayload;
}
