import * as firebaseAdmin from 'firebase-admin';
import { ApiProperty } from '@nestjs/swagger';
import { BaseDto } from '@core/dto/base.dto';
import { IsNotEmpty } from 'class-validator';

export class PushNotiRequestDto extends BaseDto {
  @ApiProperty({ example: '' })
  @IsNotEmpty()
  registrationToken: string;

  @ApiProperty({
    example: {
      data: {},
      notification: {
        title: 'Notification',
        body: 'Content',
      },
    },
  })
  payload: firebaseAdmin.messaging.MessagingPayload;
}
