import { Controller, Get, Inject } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { MailServiceInterface } from '@components/mail/interface/mail.service.interface';

@Controller('')
export class MailController {
  constructor(
    @Inject('MailServiceInterface')
    private readonly mailService: MailServiceInterface,
  ) {}

  @Get('ping')
  @MessagePattern('ping')
  public async get(): Promise<any> {
    return new ResponseBuilder('PONG')
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }
}
