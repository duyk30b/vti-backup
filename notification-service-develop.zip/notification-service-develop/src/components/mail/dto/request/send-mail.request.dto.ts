import { ApiProperty } from '@nestjs/swagger';
import { BaseDto } from '@core/dto/base.dto';
import { IsEmail, IsString, MaxLength } from 'class-validator';

class BodyMail {
  @ApiProperty({ example: 'subject mail' })
  @IsString()
  subject: string;

  @ApiProperty({ example: 'content mail' })
  @IsString()
  text: string;
}

export class SendMailRequestDto extends BaseDto {
  @ApiProperty({ example: 'example@gmail.com' })
  @IsEmail()
  @MaxLength(255)
  email: string;

  @ApiProperty({ example: BodyMail })
  body: BodyMail;
}
