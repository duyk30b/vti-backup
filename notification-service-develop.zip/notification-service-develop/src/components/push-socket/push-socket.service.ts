import { Injectable } from '@nestjs/common';
import { I18nService } from 'nestjs-i18n';
import { PushSocketRequestDto } from './dto/request/push-socket.request.dto';
import { ResourceEnum } from './push-socket.constant';
import { PushSocketItemGateway } from './socket-item/socket-item.gateway';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
@Injectable()
export class PushSocketService {
  constructor(
    private itemGateway: PushSocketItemGateway,

    private readonly i18n: I18nService,
  ) {}

  public async pushSocket(request: PushSocketRequestDto): Promise<any> {
    const { resource, channel, payload } = request;

    switch (resource) {
      case ResourceEnum.ITEM:
        await this.itemGateway.server.emit(channel, payload);
        break;
      default:
        break;
    }

    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }
}
