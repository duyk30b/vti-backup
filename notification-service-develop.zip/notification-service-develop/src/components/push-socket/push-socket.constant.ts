export enum ResourceEnum {
  ITEM = 'ITEM',
}
