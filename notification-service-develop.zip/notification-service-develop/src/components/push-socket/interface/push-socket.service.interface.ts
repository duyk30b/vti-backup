import { PushSocketRequestDto } from '../dto/request/push-socket.request.dto';

export interface PushSocketServiceInterface {
  pushSocket(request: PushSocketRequestDto): Promise<any>;
}
