import { Body, Controller, Inject, Post } from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { Server } from 'http';
import { isEmpty } from 'lodash';
import { PushSocketRequestDto } from './dto/request/push-socket.request.dto';
import { PushSocketServiceInterface } from './interface/push-socket.service.interface';
import { PushSocketItemGateway } from './socket-item/socket-item.gateway';

@Controller('push-socket')
export class PushSocketController {
  private socket: Server;
  constructor(
    @Inject('PushSocketServiceInterface')
    private readonly pushSocketService: PushSocketServiceInterface,
    private itemGateway: PushSocketItemGateway,
  ) {}

  @ApiOperation({
    tags: ['Notification'],
    summary: 'List Notification',
    description: 'List Notification',
  })
  @ApiResponse({
    status: 200,
    description: 'List successfully',
  })
  @Post('/create')
  public async PushSocket(@Body() payload: PushSocketRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.pushSocketService.pushSocket({
      ...request,
    });
  }
}
