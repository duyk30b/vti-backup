import { ResourceEnum } from '@components/push-socket/push-socket.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsInt } from 'class-validator';

export class PushSocketRequestDto extends BaseDto {
  @ApiProperty()
  payload: any;

  @ApiProperty()
  channel: string;

  @ApiProperty()
  @IsEnum(ResourceEnum)
  resource: ResourceEnum;
}
