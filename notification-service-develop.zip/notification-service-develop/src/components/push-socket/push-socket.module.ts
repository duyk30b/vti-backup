import { Module } from '@nestjs/common';
import { PushSocketItemGateway } from './socket-item/socket-item.gateway';
import { PushSocketService } from './push-socket.service';
import { PushSocketController } from './push-socket.controller';

@Module({
  controllers: [PushSocketController],
  providers: [
    {
      provide: 'PushSocketServiceInterface',
      useClass: PushSocketService,
    },
    PushSocketItemGateway,
  ],
  exports: [],
})
export class PushSocketModule {}
