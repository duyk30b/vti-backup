import {
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { APIPrefix } from 'src/common/common';

@WebSocketGateway({
  cors: {
    origin: '*',
  },
  namespace: APIPrefix.ItemSocket,
})
export class PushSocketItemGateway {
  @WebSocketServer() server: Server;

  @SubscribeMessage('test')
  handleMessage(client: Socket, payload: any): void {
    console.log('handling', payload);
  }
}
