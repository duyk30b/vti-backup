import * as dotenv from 'dotenv';
import { ServiceAccount } from 'firebase-admin';

dotenv.config();

export class FirebaseConfig {
  private readonly envConfig: { serviceAccount: ServiceAccount } = null;

  constructor() {
    this.envConfig = {
      serviceAccount: {
        projectId: process.env.FIREBASE_PROJECT_ID,
        privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
        clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      },
    };
  }

  get(key: string): any {
    return this.envConfig[key];
  }
}
