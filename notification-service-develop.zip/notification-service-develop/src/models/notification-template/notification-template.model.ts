import { BaseModel } from '@core/model/base.model';

export interface NotificationTemplateModel extends BaseModel {
  title: string;
  content: string;
  description: string;
  deletedAt: Date;
}
