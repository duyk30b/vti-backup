import { Schema } from 'mongoose';
import { NOTIFICATION_RULES } from '@components/notification/notification.constant';

export const NotificationTemplateSchema = new Schema(
  {
    title: {
      type: String,
      maxlength: NOTIFICATION_RULES.TITLE.MAX_LENGTH,
    },
    content: {
      type: String,
      maxlength: NOTIFICATION_RULES.CONTENT.MAX_LENGTH,
    },
    description: {
      default: null,
      type: String,
      maxlength: NOTIFICATION_RULES.DESCRIPTION.MAX_LENGTH,
    },
    deletedAt: {
      type: Date,
    },
  },
  {
    collection: 'notificationTemplate',
    timestamps: true,
  },
);
