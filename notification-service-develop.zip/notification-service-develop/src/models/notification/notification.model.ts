import { BaseModel } from '@core/model/base.model';
import { Date } from 'mongoose';

class Payload {
  id: any;
  name: string;
  code: string;
  entityType: number;
  entity: number;
}
export interface NotificationModel extends BaseModel {
  title: string;
  content: string;
  templateId: string;
  status: number;
  executionDate: Date;
  type: string;
  action: string;
  payload: Payload;
  createdBy: number;
}
