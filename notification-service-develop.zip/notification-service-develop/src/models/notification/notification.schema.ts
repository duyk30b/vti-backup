import * as mongoose from 'mongoose';
import {
  NotificationEntityEnum,
  NOTIFICATION_RULES,
  TypeNotificatoinUserRenderAction,
} from '@components/notification/notification.constant';

const Payload = new mongoose.Schema({
  id: {
    type: mongoose.SchemaTypes.Mixed,
  },
  name: {
    type: String,
  },
  code: {
    type: String,
  },
  entityType: {
    type: Number,
  },
  entity: {
    type: Number,
    enum: NotificationEntityEnum,
  },
});

export const NotificationSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      maxlength: NOTIFICATION_RULES.TITLE.MAX_LENGTH,
    },
    content: {
      type: String,
    },
    templateId: {
      type: String,
    },
    status: {
      type: Number,
      required: true,
    },
    type: {
      type: String,
    },
    action: {
      type: String,
      enum: TypeNotificatoinUserRenderAction,
    },
    payload: {
      type: Payload,
      required: false,
    },
    executionDate: {
      type: Date,
    },
    createdBy: {
      type: Number,
    },
  },
  {
    collection: 'notification',
    timestamps: true,
  },
);
