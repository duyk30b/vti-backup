import { Schema, Types } from 'mongoose';
import { NOTIFICATION_RULES } from '@components/notification/notification.constant';

export const NotificationUserSchema = new Schema(
  {
    userId: {
      type: Number,
    },
    notificationId: {
      type: Types.ObjectId,
      ref: 'Notification',
    },
    status: {
      type: Number,
    },
    readAt: {
      default: null,
      type: Date,
    },
    title: {
      type: String,
      maxlength: NOTIFICATION_RULES.TITLE.MAX_LENGTH,
    },
    content: {
      type: String,
    },
  },
  {
    collection: 'notificationUser',
    timestamps: true,
  },
);
