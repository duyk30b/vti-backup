import { BaseModel } from '@core/model/base.model';

export interface NotificationUserModel extends BaseModel {
  notificationId: string;
  userId: number;
  status: number;
  readAt: Date;
  title: string;
  content: string;
}
