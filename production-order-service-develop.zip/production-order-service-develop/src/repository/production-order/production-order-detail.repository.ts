import { ProductionOrderDetailRepositoryInterface } from '@components/production-order/interface/production-order-detail.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { ProductionOrderDetailModel } from 'src/models/production-order/production-order-detail.schema';

export class ProductionOrderDetailRepository
  extends BaseAbstractRepository<ProductionOrderDetailModel>
  implements ProductionOrderDetailRepositoryInterface
{
  constructor(
    @InjectModel('ProductionOrderDetailModel')
    private readonly productionOrderDetailModel: Model<ProductionOrderDetailModel>,
  ) {
    super(productionOrderDetailModel);
  }

  createDocument(request: any, id?: string): ProductionOrderDetailModel {
    const newDocument = new this.productionOrderDetailModel();
    if (request.id) newDocument._id = request.id;

    newDocument.proId = request.proId;
    newDocument.moItemId = request.moItemId;
    newDocument.itemId = request.itemId;
    newDocument.bomVersionId = request.bomVersionId;

    newDocument.warehouseId = request.warehouseId;
    newDocument.itemConvertUnitId = request.itemConvertUnitId;

    newDocument.quantity = request.quantity;
    newDocument.actualQuantity = request.actualQuantity;
    newDocument.bomQuantity = request.bomQuantity;
    newDocument.producedQuantity = request.producedQuantity;

    return newDocument;
  }
}
