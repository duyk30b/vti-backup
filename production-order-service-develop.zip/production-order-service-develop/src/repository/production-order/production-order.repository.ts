import { ProductionOrderRepositoryInterface } from '@components/production-order/interface/production-order.repository.interface';
import {
  ProductionOrderStatusEnum,
  ProductionOrderTypeEnum,
} from '@components/production-order/production-order.constant';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { isEmpty } from 'lodash';
import { Model, Types } from 'mongoose';
import { ProductionOrderModel } from 'src/models/production-order/production-order.schema';
import * as moment from 'moment';
import { getRegexByValue } from '@utils/common';

export class ProductionOrderRepository
  extends BaseAbstractRepository<ProductionOrderModel>
  implements ProductionOrderRepositoryInterface
{
  constructor(
    @InjectModel('ProductionOrderModel')
    private readonly productionOrderModel: Model<ProductionOrderModel>,
  ) {
    super(productionOrderModel);
  }

  createDocument(request: any, id?: string): ProductionOrderModel {
    const newDocument = new this.productionOrderModel();
    if (request.id) newDocument._id = request.id;

    newDocument.code = request.code;
    newDocument.name = request.name;
    newDocument.moId = request.moId;
    newDocument.moCode = request.moCode;

    newDocument.createdUserId = request['userId'];
    newDocument.requestUserId = request.requestUserId;

    newDocument.requestDate = request.requestDate;

    newDocument.note = request.note;

    newDocument.type = request.type;

    newDocument.fileIds = request.fileIds;

    newDocument.status = request.status
      ? request.status
      : ProductionOrderStatusEnum.DRAFT;

    return newDocument;
  }

  async getDetail(id: string): Promise<any> {
    return await this.productionOrderModel
      .findById(id)
      .lean()
      .populate([
        {
          path: 'productionOrderDetails',
        },
      ])
      .exec();
  }

  async getList(request: any): Promise<any> {
    const { keyword, sort, filter, take, skip } = request;
    let sortObj = {};
    let filterObj = {};

    if (!isEmpty(keyword)) {
      filterObj = {
        ...filterObj,
        $or: [
          { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          { name: getRegexByValue(keyword) },
        ],
      };
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const filterByKeyword = getRegexByValue(item.text);
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: filterByKeyword,
            };
            break;
          case 'name':
            filterObj = {
              ...filterObj,
              name: filterByKeyword,
            };
            break;
          case 'status':
            filterObj = {
              ...filterObj,
              status: +item.text,
            };
            break;
          case 'moId':
            filterObj = {
              ...filterObj,
              moId: +item.text,
            };
            break;

          case 'type':
            filterObj = {
              ...filterObj,
              type: +item.text,
            };
            break;
          case 'itemId':
            filterObj = {
              ...filterObj,
              'productionOrderDetails.itemId': +item.text,
            };
            break;
          case 'approvedAt':
            filterObj = {
              ...filterObj,
              approvedAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'requestDate':
            filterObj = {
              ...filterObj,
              requestDate: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order === 'ASC' ? 1 : -1;
        switch (item.column) {
          case 'code':
            sortObj = { code: order };
            break;
          case 'name':
            sortObj = { name: order };
            break;
          case 'status':
            sortObj = { status: order };
            break;
          case 'producedQuantity':
            sortObj = { 'productionOrderDetails.producedQuantity': order };
            break;
          case 'quantity':
            sortObj = { 'productionOrderDetails.quantity': order };
            break;
          case 'createdAt':
            sortObj = { createdAt: order };
            break;
          case 'requestDate':
            sortObj = { requestDate: order };
            break;
          case 'completedAt':
            sortObj = { completedAt: order };
            break;
          case 'updatedAt':
            sortObj = { updatedAt: order };
            break;
          default:
            sortObj = { createdAt: -1 };
            break;
        }
      });
    } else {
      sortObj = { createdAt: -1 };
    }

    const result = await this.productionOrderModel
      .aggregate()
      .lookup({
        from: 'productionOrderDetails',
        localField: '_id',
        foreignField: 'proId',
        as: 'productionOrderDetails',
      })
      .match(filterObj)
      .sort(sortObj)
      .skip(skip)
      .limit(take)
      .exec();

    const total: number = await this.productionOrderModel
      .find({ ...filterObj, deletedAt: null })
      .countDocuments()
      .exec();

    return { data: result, count: total };
  }

  async getLast(): Promise<any> {
    const filterObj = {};
    return await this.productionOrderModel
      .findOne(filterObj)
      .sort({ createdAt: 'DESC' })
      .exec();
  }

  async getProsByCondition(options: {
    proCondition?: any;
    prodCondition?: any;
  }): Promise<any> {
    return await this.productionOrderModel
      .find(options.proCondition)
      .lean()
      .populate([
        {
          path: 'productionOrderDetails',
          match: options.prodCondition,
        },
      ])
      .exec();
  }
}
