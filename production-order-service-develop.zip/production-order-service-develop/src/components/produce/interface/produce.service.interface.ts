export interface ProduceServiceInterface {
  getListBomVersionByIds(
    bomVersionIds: number[],
    serialize?: boolean,
  ): Promise<any>;
  getBomByItemIds(itemIds: number[]): Promise<any>;
  getAllManufacturingOrder(payload: any): Promise<any>;
  getBomTreeByItemIds(itemIds: number[], bomVersionIds: number[]);
  previewMaterials(
    payload: [{ id: number; quantity: number; bomVersionId: number }] | any,
  ): Promise<any>;
  completeMoByCompletedManufacturingRequestOrderId(payload: any): Promise<any>;
  getBomVersionByItemIds(itemIds: number[], serialize?: boolean);
  getMoDetail(id: number);
}
