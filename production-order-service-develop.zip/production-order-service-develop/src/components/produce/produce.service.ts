import { Inject, Injectable } from '@nestjs/common';
import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { REQUEST } from '@nestjs/core';
import { Request } from 'express';
import { isEmpty, keyBy } from 'lodash';
import { GetMaterialRequestWarningByIdsRequestDto } from './dto/request/get-material-request-warning-by-ids.request.dto';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { NATS_PRODUCE } from '@config/nats.config';
@Injectable()
export class ProduceService implements ProduceServiceInterface {
  constructor(
    private readonly natsClientService: NatsClientService,

    @Inject(REQUEST) private readonly req: Request,
  ) {}

  async previewMaterials(
    payload: [{ id: number; quantity: number; bomVersionId: number }] | any,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.preview_available_stock_materials`,
      {
        items: payload,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];

    return response.data;
  }

  async importMoMaterials(payload: any): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_PRODUCE}.import_mo_materials`,
      payload,
    );
  }

  public async getItemsByMo(id: number, serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_mo_item_material`,
      {
        id,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];

    if (serilize) {
      return keyBy(response.data, 'itemId');
    }
    return response.data;
  }

  public async getFinishedItemLots(
    moId: number,
    itemIds: number[],
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_finished_item_lots`,
      {
        moId: moId,
        itemIds: itemIds,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];

    return response.data;
  }

  public async getMaterialImportWorkCenter(
    moId: number,
    itemIds: number[],
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_material_import_work_centers`,
      {
        moId: moId,
        itemIds: itemIds,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];

    return response.data;
  }

  public async getExportWorkCenter(
    moId: number,
    itemIds: number[],
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_item_export_work_centers`,
      {
        moId: moId,
        itemIds: itemIds,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];

    return response.data;
  }

  public async getMoByIds(ids: number[], serilize?: boolean): Promise<any> {
    if (!isEmpty(ids)) {
      const response = await this.natsClientService.send(
        `${NATS_PRODUCE}.get_list_mo_by_ids`,
        ids,
      );
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
      const serilizeMos = {};
      if (serilize) {
        response.data.forEach((mo) => {
          serilizeMos[mo.id] = mo;
        });
        return serilizeMos;
      }
      return response.data;
    } else return [];
  }

  public async getMoItemLots(id: number, serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_mo_item_lots`,
      {
        id: id,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];

    if (serilize) {
      return keyBy(response.data, 'itemId');
    }
    return response.data;
  }

  public async getMoByCodes(codes: string[], serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_list_mo_by_codes`,
      {
        codes: codes,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    const serilizeMos = {};
    if (serilize) {
      response.data.forEach((mo) => {
        serilizeMos[mo.id] = mo;
      });
      return serilizeMos;
    }
    return response.data;
  }

  public async getBoqByIds(ids: number[], serilize?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_list_boq_by_ids`,
      ids,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    const serilizeBoqs = {};
    if (serilize) {
      response.data.forEach((boq) => {
        serilizeBoqs[boq.id] = boq;
      });
      return serilizeBoqs;
    }
    return response.data;
  }
  public async getBoqByCodes(
    codes: string[],
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_list_boq_by_codes`,
      { codes: codes },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    if (serilize) {
      return keyBy(response.data, 'id');
    }
    return response.data;
  }

  public async getMOBySaleOrderId(
    id: number,
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_list_mo_by_sale_order_id`,
      id,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    const serilizeMos = {};
    if (serilize) {
      response.data.forEach((mo) => {
        serilizeMos[mo.itemId] = mo;
      });
      return serilizeMos;
    }
    return response.data;
  }

  public async createMoForQcReject(
    data: any,
    getResponse = false,
  ): Promise<any> {
    const userId = await this.req['data'].userId;
    const payload = {
      ...data,
      userId: userId,
    };
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.create_mo`,
      payload,
    );
    if (getResponse) {
      return response;
    }
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return null;
    return response.data;
  }

  public async getAllManufacturingOrder(payload: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_list_mo_by_manufacturing_request_order_ids`,
      payload,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return null;
    return response.data.items;
  }

  async getBomByItemIds(itemIds: number[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_bom_by_item_ids`,
      {
        itemIds,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return null;
    return response.data;
  }

  async getMoGroupBySo(payload: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_mo_group_by_so`,
      payload,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return null;
    return {
      data: response.data?.items,
      count: response.data?.meta?.total,
    };
  }

  async getListBomVersionByIds(
    bomVersionIds: number[],
    serialize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_list_bom_version_by_bom_version_ids`,
      { bomVersionIds },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];

    return serialize ? keyBy(response.data, 'id') : response.data;
  }

  async getMaterialRequestWarningById(id: number): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_material_request_warning_by_id`,
      {
        id: id,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return {};
    return response.data;
  }

  async getProductionLineByIds(
    ids: number[],
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_production_line_by_ids`,
      {
        ids: ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    if (serilize) {
      return keyBy(response.data, 'id');
    }
    return response.data;
  }

  async getMoPlanBomByMoId(id: number): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_mo_plan_bom_by_id`,
      { id: id },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    return response.data;
  }

  /**
   *
   * @param itemIds
   * @returns
   */
  public async getBomTreeByItemIds(
    itemIds: number[],
    bomVersionIds: number[],
  ): Promise<any> {
    const payload = {
      itemIds,
      bomVersionIds,
    };
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_boms_tree_by_item_ids`,
      payload,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    return response.data;
  }

  async getMaterialRequestWarningByIds(
    ids: number[],
    serilize?: boolean,
  ): Promise<any> {
    const request = new GetMaterialRequestWarningByIdsRequestDto();
    request.ids = ids;
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_material_request_warning_by_ids`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    if (serilize) {
      return keyBy(response.data, 'id');
    }
    return response.data;
  }

  async getMoSupplies(moId: number): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_mo_supplies`,
      {
        id: moId,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    return response.data;
  }

  async completeMoByCompletedSoId(saleOrderId: number): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.complete_mo_by_completed_so_id`,
      {
        saleOrderId: saleOrderId,
      },
    );
    return response;
  }

  async getListProducingStepByIds(ids: number[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_list_producing_step_by_ids`,
      {
        ids: ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];

    return response.data;
  }

  async completeMoByCompletedManufacturingRequestOrderId(
    manufacturingRequestOrderId: string,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.complete_mo_by_completed_manufacturing_request_order_id`,
      {
        id: manufacturingRequestOrderId,
      },
    );
    return response;
  }

  async getBomVersionByItemIds(
    itemIds: number[],
    serialize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_bom_version_by_item_ids`,
      { itemIds },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];

    return serialize ? keyBy(response.data, 'itemId') : response.data;
  }

  public async getMoDetail(id: number): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_mo_detail`,
      { id: id },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return {};
    return response.data;
  }
}
