export enum ProductionOrderTypeEnum {
  IMPORT = 0,
  EXPORT = 1,
}

export enum ProductionOrderStatusEnum {
  DRAFT = 0,
  PENDING = 1,
  CONFIRMED = 2,
  IN_PROGRESS = 3,
  COMPLETED = 4,
  REJECTED = 5,
  APPROVED = 6,
}

export enum UpdateProductionOrderQuantityActionEnum {
  MINUS = 0,
  PLUS = 1,
}

export const PRO_IMPORT_STATUS_CAN_PENDING = [ProductionOrderStatusEnum.DRAFT];

//confirm
export const PRO_EXPORT_STATUS_CAN_CONFIRM = [ProductionOrderStatusEnum.DRAFT];
export const PRO_IMPORT_STATUS_CAN_CONFIRM = [
  ProductionOrderStatusEnum.DRAFT,
  ProductionOrderStatusEnum.PENDING,
];

//reject
export const PRO_EXPORT_STATUS_CAN_REJECT = [
  ProductionOrderStatusEnum.CONFIRMED,
];
export const PRO_IMPORT_STATUS_CAN_REJECT = [ProductionOrderStatusEnum.PENDING];

//approve
export const PRO_EXPORT_STATUS_CAN_APPROVED = [
  ProductionOrderStatusEnum.DRAFT,
  ProductionOrderStatusEnum.CONFIRMED,
];

//approve
export const PRO_EXPORT_STATUS_CAN_IN_PROGRESS = [
  ProductionOrderStatusEnum.APPROVED,
];
export const PRO_IMPORT_STATUS_CAN_IN_PROGRESS = [
  ProductionOrderStatusEnum.CONFIRMED,
];

//conplete
export const PRO_EXPORT_STATUS_CAN_COMPLETE = [
  ProductionOrderStatusEnum.IN_PROGRESS,
];
export const PRO_IMPORT_STATUS_CAN_COMPLETE = [
  ProductionOrderStatusEnum.IN_PROGRESS,
];

export const PRODUCTION_ORDER_STATUS_CAN_DELETE = [
  ProductionOrderStatusEnum.DRAFT,
];

export const PRO_CODE_GEN_PREFIX = 'PRO';
