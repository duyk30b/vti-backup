import { ProductionOrderStatusEnum } from '@components/production-order/production-order.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsEnum } from 'class-validator';

export class DeleteProductionOrderRequestDto extends BaseDto {
  @ApiProperty()
  id: string;
}
