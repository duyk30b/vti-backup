import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsInt } from 'class-validator';
import { CreateProductionOrderFormData } from './create-production-order.request.dto';

export class AutoGenForMoRequestDto extends BaseDto {
  @ApiProperty()
  @Type(() => CreateProductionOrderFormData)
  payload: CreateProductionOrderFormData[];
}
