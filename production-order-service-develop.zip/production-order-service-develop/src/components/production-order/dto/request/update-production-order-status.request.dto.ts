import { ProductionOrderStatusEnum } from '@components/production-order/production-order.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsMongoId } from 'class-validator';

export class UpdateProductionOrderStatusRequestDto extends BaseDto {
  @ApiProperty()
  @IsMongoId()
  id: string;
}
