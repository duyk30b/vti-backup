import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { Transform } from 'class-transformer';
import { IsArray, IsNumber, IsOptional } from 'class-validator';

export class GetQuantityTotalByMoIdRequestDto extends PaginationQuery {
  @ApiProperty()
  @Transform(({ value }) => +value)
  @IsNumber()
  moId: number;

  @ApiProperty()
  @Transform(({ value }) => JSON.parse(value))
  @IsOptional()
  itemIds: number;

  @ApiProperty()
  @Transform(({ value }) => +value)
  @IsNumber()
  type: number;
}
