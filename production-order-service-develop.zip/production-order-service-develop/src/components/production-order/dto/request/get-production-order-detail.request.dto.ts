import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId } from 'class-validator';

export class GetProductionOrderDetailRequestDto extends BaseDto {
  @ApiProperty()
  @IsMongoId()
  id: string;
}
