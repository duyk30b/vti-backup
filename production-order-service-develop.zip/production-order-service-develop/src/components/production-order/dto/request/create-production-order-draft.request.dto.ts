import { ProductionOrderTypeEnum } from '@components/production-order/production-order.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  IsEnum,
  IsInt,
  IsNumber,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';
import { ProductionOrderRequestDto } from './create-production-order.request.dto';

export class CreateProductionOrderDraftRequestDto extends ProductionOrderRequestDto {}

export class CreateProductionOrderDraftFormData extends BaseDto {
  @ApiProperty()
  // @Transform(({ value }) => JSON.parse(value), { toClassOnly: true })
  @Type(() => CreateProductionOrderDraftRequestDto)
  // @ValidateNested()
  data: CreateProductionOrderDraftRequestDto;

  @ApiPropertyOptional()
  @IsOptional()
  files: File[];
}
