import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsInt, IsNotEmpty, IsNumber, IsString } from 'class-validator';

class ItemDetailRequestDto {
  @ApiProperty()
  @IsNumber()
  itemId: number;

  @ApiProperty()
  @IsNumber()
  actualQuantity: number;
}

export class UpdateProductionOrderQuantityRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  type: number;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  requestCode: string;

  @ApiProperty()
  @Type(() => ItemDetailRequestDto)
  items: ItemDetailRequestDto[]; //production order details
}
