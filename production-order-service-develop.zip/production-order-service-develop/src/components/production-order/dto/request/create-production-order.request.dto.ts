import { ProductionOrderTypeEnum } from '@components/production-order/production-order.constant';
import { BaseDto } from '@core/dto/base.dto';
import { FileUpload } from '@core/dto/file-upload.request.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  IsEnum,
  IsInt,
  IsNumber,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';
import { isJson } from 'src/helper/string.helper';

export class ProductionOrderDetailRequestDto {
  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  itemConvertUnitId: number;

  @ApiProperty()
  @IsOptional()
  quantity: number;

  @ApiProperty()
  @IsOptional()
  actualQuantity: number;

  @ApiProperty()
  @IsOptional()
  bomQuantity: number;

  @ApiProperty()
  @IsOptional()
  producedQuantity: number;

  @ApiProperty()
  @IsOptional()
  bomVersionId: number;
}

export class OldFile {
  id: string;
  filNameRaw: string;
  fileUrl: string;
}

export class ProductionOrderRequestDto {
  @ApiProperty()
  @IsOptional()
  isDraft: boolean;

  @ApiProperty()
  @IsEnum(ProductionOrderTypeEnum)
  type: number;

  @ApiProperty()
  @IsOptional()
  name: string;

  @ApiProperty()
  @IsString()
  @IsOptional()
  code: string;

  @ApiProperty()
  @IsNumber()
  moId: number;

  @ApiProperty()
  @IsNumber()
  @IsOptional()
  departmentId: number;

  @ApiProperty()
  @IsOptional()
  moCode: string;

  @ApiProperty()
  @IsOptional()
  requestDate: Date;

  @ApiProperty()
  @IsOptional()
  note: Date;

  @ApiProperty()
  @IsOptional()
  @Type(() => OldFile)
  files: OldFile[];

  @ApiProperty()
  @IsOptional()
  @Type(() => ProductionOrderDetailRequestDto)
  productionOrderDetails: ProductionOrderDetailRequestDto[];
}

export class CreateProductionOrderRequestDto extends ProductionOrderRequestDto {}

export class CreateProductionOrderFormData extends BaseDto {
  @ApiProperty()
  @Transform(({ value }) => {
    if (isJson(value)) return JSON.parse(value);
  })
  @Type(() => CreateProductionOrderRequestDto)
  data: CreateProductionOrderRequestDto;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => FileUpload)
  files: FileUpload[];
}
