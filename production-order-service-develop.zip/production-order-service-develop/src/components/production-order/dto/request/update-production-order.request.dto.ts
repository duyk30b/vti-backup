import { BaseDto } from '@core/dto/base.dto';
import { FileUpload } from '@core/dto/file-upload.request.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import { IsOptional, ValidateNested } from 'class-validator';
import { ProductionOrderRequestDto } from './create-production-order.request.dto';

export class UpdateProductionOrderRequestDto extends ProductionOrderRequestDto {
  @ApiProperty()
  @IsOptional()
  id: string;
}

export class UpdateProductionOrderFormData extends BaseDto {
  @ApiProperty()
  @Transform(({ value }) => JSON.parse(value), { toClassOnly: true })
  @Type(() => UpdateProductionOrderRequestDto)
  @ValidateNested()
  data: UpdateProductionOrderRequestDto;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => FileUpload)
  files: FileUpload[];
}
