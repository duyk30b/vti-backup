import { ProductionOrderResponseDto } from './get-production-order-detail.response.dto';

export class GetProductionOrderListResponseDto extends ProductionOrderResponseDto {}
