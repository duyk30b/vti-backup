import { FileInforResponeDto } from '@components/file/dto/file-infor.respone';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class UserResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  fullName: string;

  @ApiProperty()
  @Expose()
  departmentSettings: any;

  @ApiProperty()
  @Expose()
  status: number;
}

class ItemResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => BaseResponseDto)
  itemUnit: BaseResponseDto;

  @ApiProperty()
  @Expose()
  itemConvertUnits: any;
}

class ManufacturingOrderDetailResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;
}

class MoResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => ManufacturingOrderDetailResponseDto)
  manufacturingOrderDetails: ManufacturingOrderDetailResponseDto[];
}

export class ProductionOrderDetailResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  proId: string;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  bomQuantity: number;

  @ApiProperty()
  @Expose()
  producedQuantity: number;

  @ApiProperty()
  @Expose()
  importQuantity: number;

  @ApiProperty()
  @Expose()
  bomVersionId: number;

  @ApiProperty()
  @Expose()
  itemConvertUnit: any;

  @ApiProperty()
  @Expose()
  @Type(() => BaseResponseDto)
  bomVersion: BaseResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => BaseResponseDto)
  warehouse: BaseResponseDto;
}

export class ProductionOrderResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  @Type(() => MoResponseDto)
  mo: MoResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => UserResponseDto)
  createdUser: UserResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => UserResponseDto)
  approvedUser: UserResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => UserResponseDto)
  requestUser: UserResponseDto;

  @ApiProperty()
  @Expose()
  requestDate: string;

  @ApiProperty()
  @Expose()
  approvedAt: string;

  @ApiProperty()
  @Expose()
  note: string;

  @ApiProperty()
  @Expose()
  @Type(() => ProductionOrderDetailResponseDto)
  productionOrderDetails: ProductionOrderDetailResponseDto[];

  @ApiProperty({ type: FileInforResponeDto })
  @Type(() => FileInforResponeDto)
  @Expose()
  files: FileInforResponeDto[];
}

export class GetProductionOrderDetailResponseDto extends ProductionOrderResponseDto {}
