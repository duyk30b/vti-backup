import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { Expose } from 'class-transformer';
import { ProductionOrderResponseDto } from './get-production-order-detail.response.dto';

export class GetQuantityTotalByMoIdResponseDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  importQuantity: number;

  @ApiProperty()
  @Expose()
  producedQuantity: number;

  @ApiProperty()
  @Expose()
  remainQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;
}
