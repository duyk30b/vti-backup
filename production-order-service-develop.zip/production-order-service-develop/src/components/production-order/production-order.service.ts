import { FileServiceInterface } from '@components/file/interface/file.service.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { ProduceService } from '@components/produce/produce.service';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/mongoose';
import { minus, plus } from '@utils/helper';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import {
  compact,
  filter,
  find,
  first,
  flatMap,
  forEach,
  has,
  isEmpty,
  isEqual,
  isNaN,
  keyBy,
  map,
  orderBy,
  reduce,
  some,
  sortBy,
  uniq,
} from 'lodash';
import * as moment from 'moment';
import { Connection } from 'mongoose';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { generateCode } from 'src/helper/code.helper';
import { AutoGenForMoRequestDto } from './dto/request/auto-gen-for-mo.request.dto';
import { CreateProductionOrderFormData } from './dto/request/create-production-order.request.dto';
import { DeleteProductionOrderRequestDto } from './dto/request/delete-production-order.request.dto';
import { GetProductionOrderDetailRequestDto } from './dto/request/get-production-order-detail.request.dto';
import { GetProductionOrderListRequestDto } from './dto/request/get-production-order-list.request.dto';
import { UpdateProductionOrderQuantityRequestDto } from './dto/request/update-production-order-quantity.request.dto';
import { UpdateProductionOrderStatusRequestDto } from './dto/request/update-production-order-status.request.dto';
import { UpdateProductionOrderFormData } from './dto/request/update-production-order.request.dto';
import {
  GetProductionOrderDetailResponseDto,
  ProductionOrderResponseDto,
} from './dto/response/get-production-order-detail.response.dto';
import { GetProductionOrderListResponseDto } from './dto/response/get-production-order-list.response.dto';
import { ProductionOrderDetailRepositoryInterface } from './interface/production-order-detail.repository.interface';
import { ProductionOrderRepositoryInterface } from './interface/production-order.repository.interface';
import { ProductionOrderServiceInterface } from './interface/production-order.service.interface';
import {
  ProductionOrderStatusEnum,
  PRO_EXPORT_STATUS_CAN_CONFIRM,
  PRODUCTION_ORDER_STATUS_CAN_DELETE,
  PRO_IMPORT_STATUS_CAN_REJECT,
  PRO_CODE_GEN_PREFIX,
  UpdateProductionOrderQuantityActionEnum,
  ProductionOrderTypeEnum,
  PRO_IMPORT_STATUS_CAN_PENDING,
  PRO_IMPORT_STATUS_CAN_COMPLETE,
  PRO_IMPORT_STATUS_CAN_CONFIRM,
  PRO_EXPORT_STATUS_CAN_REJECT,
  PRO_EXPORT_STATUS_CAN_COMPLETE,
  PRO_EXPORT_STATUS_CAN_APPROVED,
} from './production-order.constant';
import { RequestServiceInterface } from '@components/request/interface/request.service.interface';
import {
  CreateManufacturingExportRequestOrderRequestDto,
  CreateManufacturingImportRequestOrderRequestDto,
} from '@components/request/dto/request/create-manufacturing-import-export-request-order.request.dto';
import { CreateProductionOrderDraftFormData } from './dto/request/create-production-order-draft.request.dto';
import { GetQuantityTotalByMoIdResponseDto } from './dto/response/get-pro-by-condition.response.dto';

Injectable();
export class ProductionOrderService implements ProductionOrderServiceInterface {
  constructor(
    @Inject('ProductionOrderRepositoryInterface')
    protected readonly productionOrderRepository: ProductionOrderRepositoryInterface,

    @Inject('ProductionOrderDetailRepositoryInterface')
    protected readonly productionOrderDetailRepository: ProductionOrderDetailRepositoryInterface,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('ProduceServiceInterface')
    protected readonly produceService: ProduceService,

    @Inject('WarehouseServiceInterface')
    protected readonly warehouseService: WarehouseServiceInterface,

    @Inject('RequestServiceInterface')
    protected readonly requestService: RequestServiceInterface,

    @Inject('FileServiceInterface')
    protected readonly fileService: FileServiceInterface,

    private readonly i18n: I18nRequestScopeService,

    @InjectConnection()
    private readonly connection: Connection,
  ) {}

  async create(
    request:
      | CreateProductionOrderFormData
      | CreateProductionOrderDraftFormData
      | any,
  ): Promise<any> {
    const { data } = request;
    const { moId, moCode, productionOrderDetails, departmentId } = data;

    const checkedResult = await this.checkExistance({
      moId,
      departmentId,
      itemIds: compact(uniq(map(productionOrderDetails, 'itemId'))),
    });

    if (checkedResult.statusCode !== ResponseCodeEnum.SUCCESS) {
      return checkedResult;
    }
    return await this.save(request);
  }

  async update(request: UpdateProductionOrderFormData): Promise<any> {
    const { data } = request;
    const { moId, moCode, productionOrderDetails, departmentId } = data;

    const checkedResult = await this.checkExistance({
      moId,
      moCode,
      departmentId,
      itemIds: compact(uniq(map(productionOrderDetails, 'itemId'))),
    });

    if (checkedResult.statusCode !== ResponseCodeEnum.SUCCESS) {
      return checkedResult;
    }

    return await this.save(request, true);
  }

  async getList(request: GetProductionOrderListRequestDto): Promise<any> {
    const { sort } = request;

    const { data, count } = await this.productionOrderRepository.getList(
      request,
    );

    if (isEmpty(data)) {
      return new ResponseBuilder({
        items: data,
        meta: { total: count, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const [serializedWarehouse, serializedUser, serializedMo, serializedItem] =
      await Promise.all([
        this.warehouseService.getWarehouses(
          flatMap(data, (i) => {
            return map(i.productionOrderDetails, 'warehouseId');
          }),
          true,
        ),
        this.userService.getUserByIds(uniq(map(data, 'requestUserId')), true),
        this.produceService.getMoByIds(uniq(map(data, 'moId')), true),
        this.itemService.getItemByIds(
          flatMap(
            map(data, (i) => {
              return map(i.productionOrderDetails, 'itemId');
            }),
          ),
          true,
        ),
      ]);

    let resData: any = plainToInstance(
      GetProductionOrderListResponseDto,
      data.map((pro) => {
        return {
          ...pro,
          mo: {
            ...serializedMo[pro.moId],
            manufacturingOrderDetails: map(
              serializedMo[pro.moId]?.manufacturingOrderDetails,
              (moDetail) => {
                return {
                  ...moDetail,
                  item: moDetail.item,
                };
              },
            ),
          },
          requestUser: serializedUser[pro.requestUserId],
          productionOrderDetails: map(
            pro.productionOrderDetails,
            (proDetail) => {
              return {
                ...proDetail,
                item: serializedItem[proDetail.itemId],
                warehouse: serializedWarehouse[proDetail.warehouseId],
              };
            },
          ),
        };
      }),
      {
        excludeExtraneousValues: true,
      },
    );

    if (!isEmpty(sort)) {
      sort.forEach((i) => {
        const order = i.order === 'ASC' ? 'asc' : 'desc';
        switch (i.column) {
          case 'moName':
            resData = orderBy(resData, (i) => i.mo.name, [order]);
            break;
          case 'itemName':
            resData = orderBy(
              resData,
              (i) => (first(i.productionOrderDetails) as any).item?.name,
              [order],
            );
            break;
          case 'actualQuantity':
            resData = orderBy(
              resData,
              (i) => (first(i.productionOrderDetails) as any)?.actualQuantity,
              [order],
            );
            break;
          default:
            break;
        }
      });
    }

    return new ResponseBuilder({
      items: resData,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getDetail(request: GetProductionOrderDetailRequestDto): Promise<any> {
    const { id } = request;

    const data = await this.productionOrderRepository.getDetail(id);

    if (isEmpty(data)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const [
      serializedUser,
      serializedItem,
      serializedMo,
      serializedBomVersion,
      serializedWarehouse,
      files,
    ] = await Promise.all([
      this.userService.getUserByIds(
        uniq([data.requestUserId, data.approverId]),
        true,
      ),
      this.itemService.getItemByIds(
        uniq(map(data.productionOrderDetails, 'itemId')),
        true,
      ),
      this.produceService.getMoByIds([data.moId], true),
      this.produceService.getListBomVersionByIds(
        uniq(map(data.productionOrderDetails, 'bomVersionId')),
        true,
      ),
      this.warehouseService.getWarehouses(
        map(data.productionOrderDetails, 'warehouseId'),
        true,
      ),
      this.fileService.getFilesByIds(data.fileIds || []),
    ]);

    //cal imported quantity
    let obj;
    if (data.type === ProductionOrderTypeEnum.IMPORT) {
      obj = first(
        (
          await this.getQuantityTotalByMoId({
            moId: data.moId,
            type: ProductionOrderTypeEnum.IMPORT,
          })
        ).data,
      );
    }

    const resData = plainToInstance(
      GetProductionOrderDetailResponseDto,
      {
        ...data,
        mo: {
          ...serializedMo[data.moId],
          manufacturingOrderDetails: map(
            serializedMo[data.moId]?.manufacturingOrderDetails,
            (moDetail) => {
              return {
                ...moDetail,
                item: moDetail.item,
              };
            },
          ),
        },
        requestUser: serializedUser[data.requestUserId],
        approvedUser: serializedUser[data.approverId],
        productionOrderDetails: map(data.productionOrderDetails, (i) => {
          return {
            ...i,
            item: serializedItem[i.itemId],
            bomVersion: serializedBomVersion[i.bomVersionId],
            warehouse: serializedWarehouse[i.warehouseId],
            importQuantity: obj?.importQuantity,
            itemConvertUnit: find(
              serializedItem[i.itemId]?.itemConvertUnits || [],
              (j) => {
                return j.id === i.itemConvertUnitId;
              },
            ),
          };
        }),
        files,
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(resData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateStatus(
    request: UpdateProductionOrderStatusRequestDto,
    options?: { newStatus?: ProductionOrderStatusEnum },
  ): Promise<any> {
    const { newStatus } = options;
    const { id, userId } = request;
    let data = await this.productionOrderRepository.getDetail(id);
    if (isEmpty(data)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    let result, status;
    switch (newStatus) {
      case ProductionOrderStatusEnum.CONFIRMED:
        result = await this.confirm(data);
        status = result.data?.status;
        if (status === ProductionOrderStatusEnum.APPROVED) {
          data.approverId = userId;
          data.approvedAt = new Date();
        }
        break;
      case ProductionOrderStatusEnum.PENDING:
        result = await this.pending(data);
        status = ProductionOrderStatusEnum.PENDING;
        break;
      case ProductionOrderStatusEnum.REJECTED:
        result = await this.reject(data);
        status = ProductionOrderStatusEnum.REJECTED;
        break;
      case ProductionOrderStatusEnum.COMPLETED:
        result = await this.complete(data);
        status = ProductionOrderStatusEnum.COMPLETED;
        data.completedAt = new Date();
        break;
      case ProductionOrderStatusEnum.APPROVED:
        result = await this.approve(data, { isOmittedConfirm: false });
        status = ProductionOrderStatusEnum.APPROVED;
        data.approverId = userId;
        data.approvedAt = new Date();
        break;
      default:
        break;
    }

    if (result.statusCode !== ResponseCodeEnum.SUCCESS) {
      return result;
    }

    try {
      await this.productionOrderRepository.findByIdAndUpdate(id, {
        ...data,
        status,
      });
      if (
        (status === ProductionOrderStatusEnum.CONFIRMED &&
          data.type === ProductionOrderTypeEnum.IMPORT) ||
        (status === ProductionOrderStatusEnum.APPROVED &&
          data.type === ProductionOrderTypeEnum.EXPORT)
      ) {
        const response = await this.createManufacturingImportExportRequest({
          ...data,
          approverId: userId,
          approvedAt: new Date(),
        });

        //if (response.status != ResponseCodeEnum.SUCCESS) return response;
      }
    } catch (error) {
      new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }

    return isEmpty(result)
      ? new ResponseBuilder()
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build()
      : result;
  }

  async delete(request: DeleteProductionOrderRequestDto): Promise<any> {
    const { id } = request;
    const data = await this.productionOrderRepository.getDetail(id);
    if (isEmpty(data)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!PRODUCTION_ORDER_STATUS_CAN_DELETE.includes(data.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
        .build();
    }

    await this.productionOrderRepository.deleteById(id);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateActualQuantity(
    request: UpdateProductionOrderQuantityRequestDto,
  ): Promise<any> {
    const { requestCode, items } = request;
    const productionOrder = await this.productionOrderRepository.findOneByCode(
      requestCode,
    );
    if (isEmpty(productionOrder)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const productionOrderDetails =
      await this.productionOrderDetailRepository.findAllByCondition({
        proId: { $eq: productionOrder._id },
      });

    const serializedItem = keyBy(items, 'itemId');
    for (let i = 0; i < productionOrderDetails.length; ++i) {
      const productionOrderDetail = productionOrderDetails[i];
      if (has(serializedItem, productionOrderDetail.itemId)) {
        productionOrderDetail.actualQuantity = plus(
          productionOrderDetail.actualQuantity || 0,
          serializedItem[productionOrderDetail.itemId].actualQuantity,
        );
      }
    }

    const prodBulkOps = productionOrderDetails.map((productionOrderDetail) => ({
      updateOne: {
        filter: { _id: productionOrderDetail._id },
        update: productionOrderDetail,
        upsert: true,
      },
    }));

    try {
      await this.productionOrderDetailRepository.bulkWrite(prodBulkOps);
      await this.productionOrderRepository.updateById(productionOrder.id, {
        ...productionOrder,
        status: ProductionOrderStatusEnum.IN_PROGRESS,
      });

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.error('PRODUCTION-ORDER UPDATE QUANTITY: ', error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async generateCode(): Promise<any> {
    let defaultOrdNum = '00001';
    let isNotGenYear = true;
    let separChar = '.';
    const prefix = PRO_CODE_GEN_PREFIX;

    const latestPro = await this.productionOrderRepository.getLast();

    const code = latestPro?.code || null;

    const isValidPattern = isNotGenYear
      ? new RegExp(`^${prefix}\\${separChar}\\d{${defaultOrdNum.length}}$`)
      : new RegExp(
          `^${prefix}\\${separChar}\\d{${defaultOrdNum.length}}\.\\d{2}$`,
        );

    const year = moment().year().toString().slice(-2);
    const lastCodeYear = code ? Number(code.split(separChar)[2]) : Number(year);
    const isNextYear = lastCodeYear && lastCodeYear + 1 === Number(year);

    const isDefault =
      (code && !isValidPattern.test(code)) || !code || isNextYear;
    if (!isDefault) {
      const nextOrdNum = Number(code.split(separChar)[1]) + 1;
      const nextOrdNumStr = (
        '0'.repeat(defaultOrdNum.length) + nextOrdNum
      ).slice(-defaultOrdNum.length);
      defaultOrdNum = nextOrdNumStr;
    }

    const generatedCode = isNotGenYear
      ? [prefix, defaultOrdNum].join(separChar)
      : [prefix, defaultOrdNum, year].join(separChar);

    return new ResponseBuilder({
      code: generatedCode,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async save(
    request: CreateProductionOrderFormData | UpdateProductionOrderFormData,
    isUpdate?: boolean,
  ) {
    const { data, files } = request;
    const { isDraft, productionOrderDetails } = data;

    data['status'] =
      isUpdate || isDraft
        ? ProductionOrderStatusEnum.DRAFT
        : ProductionOrderStatusEnum.PENDING;

    try {
      const proDocument = this.productionOrderRepository.createDocument(data);

      const savedFileResponse = await this.fileService.handleSaveFiles(
        proDocument.fileIds || [],
        data.files ? data.files.filter((file) => !isEmpty(file)) : null,
        files,
      );
      if (savedFileResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
        // return savedFileResponse;
      }
      proDocument.fileIds = savedFileResponse.data;

      if (isUpdate) {
        await this.productionOrderRepository.findByIdAndUpdate(
          proDocument._id,
          proDocument,
        );
        await this.productionOrderDetailRepository.deleteManyByCondition({
          proId: proDocument._id,
        });
      } else {
        const code = (await this.generateCode()).data.code;
        await this.productionOrderRepository.create({
          ...proDocument['_doc'],
          code,
        });
      }

      await this.productionOrderDetailRepository.create(
        map(productionOrderDetails, (i) => {
          return this.productionOrderDetailRepository.createDocument({
            ...i,
            proId: proDocument._id,
          });
        }),
      );

      const resData = plainToInstance(ProductionOrderResponseDto, proDocument, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(resData)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.error('PRODUCTION ORDER SAVE: ', error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  private async checkExistance(data: any): Promise<any> {
    const { proId, proCode, moId, itemIds, bomVersionIds, departmentId } = data;

    switch (true) {
      case proId &&
        isEmpty(await this.productionOrderRepository.findOneById(proId)):
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
        break;

      case departmentId &&
        isEmpty(
          await this.userService.getDepartmentSettingByIds([departmentId]),
        ):
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
        break;

      case moId && isEmpty(await this.produceService.getMoByIds([moId])):
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
        break;

      case proCode &&
        !isEmpty(await this.productionOrderRepository.findOneByCode(proCode)):
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.CODE_IS_EXIST'))
          .build();
        break;

      case itemIds &&
        !isEqual(
          (await this.itemService.getItemByIds(itemIds)).length,
          itemIds.length,
        ):
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.ITEM_NOT_FOUND'))
          .build();
        break;

      default:
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
    }
  }

  async createManufacturingImportExportRequest(data: any): Promise<any> {
    try {
      let createRequestRequest;
      const mos = await this.produceService.getMoByIds([data.moId]);
      const mo = mos ? mos[0] : null;
      if (data.type === ProductionOrderTypeEnum.IMPORT) {
        createRequestRequest =
          new CreateManufacturingImportRequestOrderRequestDto();
      } else if (data.type === ProductionOrderTypeEnum.EXPORT) {
        createRequestRequest =
          new CreateManufacturingExportRequestOrderRequestDto();
      }
      createRequestRequest.productionOrderId = data._id;
      createRequestRequest.productionOrderCode = data.code;
      createRequestRequest.moId = data.moId;
      createRequestRequest.moCode = mo.code;
      createRequestRequest.requesterId = data.requestUserId;
      createRequestRequest.proId = data._id;
      createRequestRequest.proCode = data.code;
      createRequestRequest.requestDate = data.requestDate;
      createRequestRequest.itemId = mo.manufacturingOrderDetails[0].itemId;
      createRequestRequest.bomVersionId =
        mo.manufacturingOrderDetails[0].bomVersionId;
      createRequestRequest.approvedAt = data.approvedAt;
      createRequestRequest.approverId = data.approverId;
      createRequestRequest.description = data.description;
      if (data.type === ProductionOrderTypeEnum.IMPORT) {
        createRequestRequest.requestQuantity =
          data.productionOrderDetails[0].quantity;

        return await this.requestService.createManufacturingImportRequestOrder(
          createRequestRequest,
        );
      } else if (data.type === ProductionOrderTypeEnum.EXPORT) {
        createRequestRequest.materials = data.productionOrderDetails.map(
          (productionOrderDetail) => ({
            itemId: productionOrderDetail.itemId,
            quantity: productionOrderDetail.quantity,
          }),
        );

        return await this.requestService.createManufacturingExportRequestOrder(
          createRequestRequest,
        );
      }
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getQuantityTotalByMoId(request: any) {
    const { moId, type, itemIds } = request;

    const statuses =
      type === ProductionOrderTypeEnum.IMPORT
        ? // except REJECTED
          map(
            filter(
              filter(Object.keys(ProductionOrderStatusEnum), (i) =>
                isNaN(Number(i)),
              ),
              (key) => {
                return ![ProductionOrderStatusEnum.REJECTED].includes(
                  ProductionOrderStatusEnum[key],
                );
              },
            ),
            (key) => ProductionOrderStatusEnum[key],
          )
        : //APPROVED
          [ProductionOrderStatusEnum.APPROVED];

    //get pro by condition
    const proCondition = {
      moId,
      type,
      status: { $in: statuses },
    };
    const prodCondition = !isEmpty(itemIds)
      ? {
          itemId: { $in: itemIds },
        }
      : {};
    const pros = await this.productionOrderRepository.getProsByCondition({
      proCondition,
      prodCondition,
    });

    const prods = compact(
      flatMap(pros, (i) => {
        return i.productionOrderDetails;
      }),
    );
    if (isEmpty(prods)) {
      return new ResponseBuilder([])
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    let result = [];
    if (type === ProductionOrderTypeEnum.IMPORT) {
      const mods = (await this.produceService.getMoDetail(moId))
        .manufacturingOrderDetails;
      const serializedMod = keyBy(mods, 'itemId');

      const groupedProds = this.sumQuantity(prods, {
        keys: ['itemId'],
        quantityField: 'actualQuantity',
      });

      result = map(groupedProds, (i) => {
        const moQuantity = serializedMod[i.itemId]?.quantity || 0;
        const proQuantity = i.actualQuantity || 0;

        const remainQuantity = minus(moQuantity, proQuantity);
        return {
          ...i,
          remainQuantity: remainQuantity < 0 ? 0 : remainQuantity,
          importQuantity: i.actualQuantity ? i.actualQuantity : 0,
        };
      });
    } else if (type === ProductionOrderTypeEnum.EXPORT) {
      const groupedProds = this.sumQuantity(prods, {
        keys: ['itemId'],
        quantityField: 'quantity',
      });
      result = map(groupedProds, (i) => {
        return {
          ...i,
        };
      });
    }

    const resData = plainToInstance(GetQuantityTotalByMoIdResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(resData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private sumQuantity(
    objArr: any[],
    options: {
      keys: string[];
      quantityField: string;
    },
  ) {
    const { keys, quantityField: QuantityField } = options;
    return reduce(
      objArr,
      (result, i) => {
        const key = map(keys, (key) => {
          return i[key];
        }).join('-');

        const existing = find(result, (j) => {
          i['key'] = key;
          return j['key'] === i['key'];
        });

        if (isEmpty(existing)) {
          result.push({ ...i, key });
        } else {
          existing[QuantityField] = plus(
            i[QuantityField] | 0,
            existing[QuantityField] | 0,
          );
        }
        return result;
      },
      [],
    );
  }

  private async confirm(data: any): Promise<any> {
    const { type, status } = data;

    let newStatus = ProductionOrderStatusEnum.CONFIRMED;

    if (type === ProductionOrderTypeEnum.EXPORT) {
      if (!PRO_EXPORT_STATUS_CAN_CONFIRM.includes(status)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
          .build();
      }

      //handle pro-export status
      const result = await this.approve(data, { isOmittedConfirm: true });
      if (result.statusCode === ResponseCodeEnum.SUCCESS) {
        newStatus = ProductionOrderStatusEnum.APPROVED;
      }
    }

    if (type === ProductionOrderTypeEnum.IMPORT) {
      if (!PRO_IMPORT_STATUS_CAN_CONFIRM.includes(status)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
          .build();
      }
    }

    return new ResponseBuilder({ status: newStatus })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async reject(data: any): Promise<any> {
    const { type, status } = data;

    if (type === ProductionOrderTypeEnum.EXPORT) {
      if (!PRO_EXPORT_STATUS_CAN_REJECT.includes(status)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
          .build();
      }
    }

    if (type === ProductionOrderTypeEnum.IMPORT) {
      if (!PRO_IMPORT_STATUS_CAN_REJECT.includes(status)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
          .build();
      }
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async pending(data: any): Promise<any> {
    const { type, status } = data;

    if (type === ProductionOrderTypeEnum.IMPORT) {
      if (!PRO_IMPORT_STATUS_CAN_PENDING.includes(status)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
          .build();
      }
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async complete(data: any): Promise<any> {
    const { type, status, productionOrderDetails } = data;

    const canComplete = (prods: any[]): any => {
      if (isEmpty(prods)) {
        return false;
      }
      return !some(prods, (i) => {
        return !isEqual(i.quantity, i?.actualQuantity);
      });
    };

    if (type === ProductionOrderTypeEnum.EXPORT) {
      if (!PRO_EXPORT_STATUS_CAN_COMPLETE.includes(status)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
          .build();
      }
    }

    if (type === ProductionOrderTypeEnum.IMPORT) {
      if (!PRO_IMPORT_STATUS_CAN_COMPLETE.includes(status)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
          .build();
      }
    }

    if (!canComplete(productionOrderDetails)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
        .build();
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async approve(
    data: any,
    options?: {
      isOmittedConfirm?: boolean;
    },
  ): Promise<any> {
    const { moId, type, status, productionOrderDetails } = data;
    const { isOmittedConfirm } = options;

    if (type === ProductionOrderTypeEnum.EXPORT) {
      if (!PRO_EXPORT_STATUS_CAN_APPROVED.includes(status)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
          .build();
      }
      if (!isOmittedConfirm) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
      }
    }

    //get all pro by conditions
    const statuses = [
      ProductionOrderStatusEnum.APPROVED,
      ProductionOrderStatusEnum.COMPLETED,
      ProductionOrderStatusEnum.IN_PROGRESS,
    ];
    const proCondition = {
      moId,
      type: ProductionOrderTypeEnum.EXPORT,
      status: { $in: statuses },
    };
    const pros = await this.productionOrderRepository.getProsByCondition({
      proCondition,
    });
    const prods = compact(
      flatMap(pros, (i) => {
        return i.productionOrderDetails;
      }),
    );
    const groupedProds = this.sumQuantity(prods, {
      keys: ['itemId'],
      quantityField: 'quantity',
    });

    //check valid quantity
    const canApprove = (groupedProds: any[], prods: any[]): any => {
      const serializedProd = keyBy(groupedProds, 'itemId');
      if (isEmpty(prods)) {
        return false;
      }
      return !some(prods, (i) => {
        const itemId = i.itemId;
        return (
          minus(
            plus(i?.quantity || 0, serializedProd[itemId]?.quantity || 0),
            i.bomQuantity,
          ) > 0
        );
      });
    };

    if (!canApprove(groupedProds, productionOrderDetails)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PRO_QUANTITY_INVALID'))
        .build();
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
