import { FileModule } from '@components/file/file.module';
import { FileService } from '@components/file/file.service';
import { ItemService } from '@components/item/item.service';
import { ProduceModule } from '@components/produce/produce.module';
import { ProduceService } from '@components/produce/produce.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { WarehouseService } from '@components/warehouse/warehouse.service';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import {
  ProductionOrderDetailModel,
  ProductionOrderDetailSchema,
} from 'src/models/production-order/production-order-detail.schema';
import { ProductionOrderSchema } from 'src/models/production-order/production-order.schema';
import { ProductionOrderDetailRepository } from 'src/repository/production-order/production-order-detail.repository';
import { ProductionOrderRepository } from 'src/repository/production-order/production-order.repository';
import { ProductionOrderController } from './production-order.controller';
import { ProductionOrderService } from './production-order.service';
import { RequestService } from '@components/request/request.service';
import { RequestModule } from '@components/request/request.module';
import { ClientsModule, Transport } from '@nestjs/microservices';
import * as fs from 'fs';
import * as path from 'path';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: 'ProductionOrderDetailModel',
        schema: ProductionOrderDetailSchema,
      },
      {
        name: 'ProductionOrderModel',
        schema: ProductionOrderSchema,
      },
    ]),
    UserModule,
    FileModule,
    ProduceModule,
    RequestModule,
    ClientsModule.register([
      {
        name: 'CLIENT_KAFKA',
        transport: Transport.KAFKA,
        options: {
          client: {
            clientId: 'item_sync_report',
            brokers: process.env.KAFKA_BROKERS.split(','),
            ssl: {
              rejectUnauthorized: false,
              ca: [
                fs.readFileSync(
                  path.join(__dirname, '/../../cert/kafka.crt'),
                  'utf-8',
                ),
              ],
              key: fs.readFileSync(
                path.join(__dirname, '/../../cert/kafka.key'),
                'utf-8',
              ),
              cert: fs.readFileSync(
                path.join(__dirname, '/../../cert/kafka.pem'),
                'utf-8',
              ),
            },
          },
        },
      },
    ]),
  ],
  exports: [],
  providers: [
    {
      provide: 'ProductionOrderServiceInterface',
      useClass: ProductionOrderService,
    },
    {
      provide: 'ProductionOrderRepositoryInterface',
      useClass: ProductionOrderRepository,
    },
    {
      provide: 'ProductionOrderDetailRepositoryInterface',
      useClass: ProductionOrderDetailRepository,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'FileServiceInterface',
      useClass: FileService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'ProduceServiceInterface',
      useClass: ProduceService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'RequestServiceInterface',
      useClass: RequestService,
    },
  ],
  controllers: [ProductionOrderController],
})
export class ProductionOrderModule {}
