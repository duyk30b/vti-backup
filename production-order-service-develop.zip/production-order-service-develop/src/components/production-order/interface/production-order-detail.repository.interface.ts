import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ProductionOrderDetailModel } from 'src/models/production-order/production-order-detail.schema';

export interface ProductionOrderDetailRepositoryInterface
  extends BaseInterfaceRepository<ProductionOrderDetailModel> {
  createDocument(request: any, id?: string): ProductionOrderDetailModel;
}
