import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ProductionOrderModel } from 'src/models/production-order/production-order.schema';
import { GetProductionOrderListRequestDto } from '../dto/request/get-production-order-list.request.dto';

export interface ProductionOrderRepositoryInterface
  extends BaseInterfaceRepository<ProductionOrderModel> {
  createDocument(request: any, id?: string): ProductionOrderModel;
  getList(request: GetProductionOrderListRequestDto): Promise<any>;
  getDetail(id: string): Promise<any>;
  getLast(): Promise<any>;
  getProsByCondition(options: {
    proCondition: any;
    prodCondition?: any;
  }): Promise<any>;
}
