import { AutoGenForMoRequestDto } from '../dto/request/auto-gen-for-mo.request.dto';
import { CreateProductionOrderFormData } from '../dto/request/create-production-order.request.dto';
import { DeleteProductionOrderRequestDto } from '../dto/request/delete-production-order.request.dto';
import { GetQuantityTotalByMoIdRequestDto } from '../dto/request/get-pro-by-condition.request.dto';
import { GetProductionOrderListRequestDto } from '../dto/request/get-production-order-list.request.dto';
import { UpdateProductionOrderQuantityRequestDto } from '../dto/request/update-production-order-quantity.request.dto';
import { UpdateProductionOrderStatusRequestDto } from '../dto/request/update-production-order-status.request.dto';
import { UpdateProductionOrderFormData } from '../dto/request/update-production-order.request.dto';
import { ProductionOrderStatusEnum } from '../production-order.constant';

export interface ProductionOrderServiceInterface {
  create(request: CreateProductionOrderFormData): Promise<any>;
  update(request: UpdateProductionOrderFormData): Promise<any>;
  getDetail(request: any): Promise<any>;
  getList(request: GetProductionOrderListRequestDto): Promise<any>;
  delete(request: DeleteProductionOrderRequestDto): Promise<any>;
  updateStatus(
    request: UpdateProductionOrderStatusRequestDto,
    options?: {
      newStatus?: ProductionOrderStatusEnum;
    },
  ): Promise<any>;
  updateActualQuantity(
    request: UpdateProductionOrderQuantityRequestDto,
  ): Promise<any>;
  generateCode(): Promise<any>;
  getQuantityTotalByMoId(
    request: GetQuantityTotalByMoIdRequestDto,
  ): Promise<any>;
}
