import { NATS_PRODUCTION_ORDER } from '@config/nats.config';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern, Payload } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { isEmpty } from 'lodash';
import { AutoGenForMoRequestDto } from './dto/request/auto-gen-for-mo.request.dto';
import { CreateProductionOrderDraftFormData } from './dto/request/create-production-order-draft.request.dto';
import { CreateProductionOrderFormData } from './dto/request/create-production-order.request.dto';
import { DeleteProductionOrderRequestDto } from './dto/request/delete-production-order.request.dto';
import { GetQuantityTotalByMoIdRequestDto } from './dto/request/get-pro-by-condition.request.dto';
import { GetProductionOrderDetailRequestDto } from './dto/request/get-production-order-detail.request.dto';
import { GetProductionOrderListRequestDto } from './dto/request/get-production-order-list.request.dto';
import { UpdateProductionOrderQuantityRequestDto } from './dto/request/update-production-order-quantity.request.dto';
import { UpdateProductionOrderStatusRequestDto } from './dto/request/update-production-order-status.request.dto';
import { UpdateProductionOrderFormData } from './dto/request/update-production-order.request.dto';
import { ProductionOrderServiceInterface } from './interface/production-order.service.interface';
import { ProductionOrderStatusEnum } from './production-order.constant';
import { SyncImportExportWarehouseQuantity } from './dto/request/sync-import-export-warehouse-quantity.request.dto';
import { ResponsePayload } from '@utils/response-payload';

@Controller('')
export class ProductionOrderController {
  constructor(
    @Inject('ProductionOrderServiceInterface')
    private readonly productionOrderService: ProductionOrderServiceInterface,
  ) {}

  @Post('')
  @ApiOperation({
    tags: ['Producton Order'],
    summary: 'Create production order',
  })
  @ApiResponse({
    status: 200,
    description: 'Create production order successfully',
  })
  public async create(
    @Body() body: CreateProductionOrderFormData,
  ): Promise<any> {
    const { request, responseError } = body;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.productionOrderService.create(request);
  }

  @Put('/:id')
  @ApiOperation({
    tags: ['Producton Order'],
    summary: 'Update production order',
  })
  @ApiResponse({
    status: 200,
    description: 'Update production order successfully',
  })
  public async update(
    @Body() body: UpdateProductionOrderFormData,
  ): Promise<any> {
    const { request, responseError } = body;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.productionOrderService.update(request);
  }

  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Production order'],
    summary: 'Update production order status',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  public async confirm(
    @Param() param: UpdateProductionOrderStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.updateStatus(request, {
      newStatus: ProductionOrderStatusEnum.CONFIRMED,
    });
  }

  @Put('/:id/approve')
  @ApiOperation({
    tags: ['Production order'],
    summary: 'Update production order status',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  public async approve(
    @Param() param: UpdateProductionOrderStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.updateStatus(request, {
      newStatus: ProductionOrderStatusEnum.APPROVED,
    });
  }

  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Production order'],
    summary: 'Update production order status',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  public async reject(
    @Param() param: UpdateProductionOrderStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.updateStatus(request, {
      newStatus: ProductionOrderStatusEnum.REJECTED,
    });
  }

  @Put('/:id/pending')
  @ApiOperation({
    tags: ['Production order'],
    summary: 'Update production order status',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  public async pending(
    @Param() param: UpdateProductionOrderStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.updateStatus(request, {
      newStatus: ProductionOrderStatusEnum.PENDING,
    });
  }

  @Put('/:id/complete')
  @ApiOperation({
    tags: ['Production order'],
    summary: 'Update production order status',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  public async complete(
    @Param() param: UpdateProductionOrderStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.updateStatus(request, {
      newStatus: ProductionOrderStatusEnum.COMPLETED,
    });
  }

  @Delete('/:id')
  @ApiOperation({
    tags: ['Production order'],
    summary: 'Delete production order ',
  })
  @ApiResponse({
    status: 200,
    description: 'delete successfully',
  })
  public async delete(
    @Param() param: DeleteProductionOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.delete(request);
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['Producton Order'],
    summary: 'Get production order detail',
  })
  @ApiResponse({
    status: 200,
    description: 'Get production order detail successfully',
  })
  public async getDetail(
    @Param() param: GetProductionOrderDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.productionOrderService.getDetail(request);
  }

  @Get('')
  @ApiOperation({
    tags: ['Producton Order'],
    summary: 'Get production order list',
  })
  @ApiResponse({
    status: 200,
    description: 'Get production order list successfully',
  })
  public async getList(
    @Query() query: GetProductionOrderListRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.productionOrderService.getList(request);
  }

  @Get('/generate-code')
  @ApiOperation({
    tags: ['Production order'],
    summary: 'Gen code production order',
  })
  @ApiResponse({
    status: 200,
    type: null,
    description: 'Get successfully',
  })
  public async generateCode(): Promise<any> {
    return await this.productionOrderService.generateCode();
  }

  @ApiOperation({
    tags: ['Production order'],
    summary: 'Create production order draft',
  })
  @ApiResponse({
    status: 200,
    type: null,
    description: 'successfully',
  })
  @MessagePattern(`${NATS_PRODUCTION_ORDER}.create_production_order_draft`)
  public async CreateProductionOrderDraft(
    @Body() body: CreateProductionOrderDraftFormData,
  ): Promise<any> {
    const { request, responseError } = body;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.create(request);
  }

  @Get('/quantity-total')
  @ApiOperation({
    tags: ['Production order'],
    summary: 'sum production order',
  })
  @ApiResponse({
    status: 200,
    type: null,
    description: 'successfully',
  })
  public async getQuantityByMoId(
    @Query() query: GetQuantityTotalByMoIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.getQuantityTotalByMoId(request);
  }

  @ApiOperation({
    tags: ['Production order'],
    summary: 'sum production order',
  })
  @ApiResponse({
    status: 200,
    type: null,
    description: 'successfully',
  })
  @MessagePattern(`${NATS_PRODUCTION_ORDER}.get_pro_quantity_total`)
  public async getQuantityByMoIdTCP(
    @Body() body: GetQuantityTotalByMoIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.productionOrderService.getQuantityTotalByMoId(request);
  }

  @MessagePattern('sync_actual_import_export_warehouse_quantity_by_request')
  async readMessageSyncImportExportWarehouseQuantity(
    @Payload() body: SyncImportExportWarehouseQuantity,
  ): Promise<ResponsePayload<any>> {
    const { request } = body;
    return await this.productionOrderService.updateActualQuantity(request);
  }
}
