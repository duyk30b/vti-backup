import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class ProductionLine extends BaseResponseDto {
  @ApiProperty({ type: BaseResponseDto })
  @Expose()
  @Type(() => BaseResponseDto)
  plant: BaseResponseDto;
}
class DosageForm extends BaseResponseDto {
  @ApiProperty({ type: ProductionLine })
  @Expose()
  @Type(() => ProductionLine)
  productionLine: ProductionLine;
}
class Bom {
  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  id: string;
}

class Lot {
  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  mfg: string;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  ipcConfirmedQuantity: number;

  @ApiProperty()
  @Expose()
  staffWarConfirmedQuantity: number;

  @ApiProperty()
  @Expose()
  staffProConfirmedQuantity: number;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  @Type(() => BaseResponseDto)
  producingStep: BaseResponseDto;
}

class ExtraInformationDetail {
  @Expose()
  @ApiProperty()
  value: string;

  @Expose()
  id: number;

  @Expose()
  code: string;

  @Expose()
  name: string;
}
export class ItemResponseDto {
  @ApiProperty()
  @Expose({ name: 'id' })
  itemId: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  price: number;

  @ApiProperty()
  @Expose()
  itemUnit: string;

  @ApiProperty()
  @Expose()
  @Type(() => BaseResponseDto)
  itemType: BaseResponseDto;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  subCode: string;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  itemDetails: any;

  @ApiProperty()
  @Expose()
  isConfirmedBom: boolean;

  @ApiProperty()
  @Expose()
  ipcConfirmedQuantity: number;

  @ApiProperty()
  @Expose()
  staffWarConfirmedQuantity: number;

  @ApiProperty()
  @Expose()
  staffProConfirmedQuantity: number;

  @ApiProperty()
  @Expose()
  minStockQuantity: number;

  @ApiProperty()
  @Expose()
  maxStockQuantity: number;

  @ApiProperty()
  @Expose()
  details: any;

  @ApiProperty()
  @Expose()
  @Type(() => BaseResponseDto)
  warehouse: BaseResponseDto;

  @ApiProperty({ type: Bom })
  @Expose()
  @Type(() => Bom)
  bom: Bom;

  @ApiProperty({ type: DosageForm })
  @Expose()
  @Type(() => DosageForm)
  dosageForm: DosageForm;

  @ApiProperty({ type: Lot })
  @Expose()
  @Type(() => Lot)
  lots: Lot;

  @ApiProperty({ type: ExtraInformationDetail })
  @Type(() => ExtraInformationDetail)
  @Expose()
  extraInformationDetails: ExtraInformationDetail;
}
