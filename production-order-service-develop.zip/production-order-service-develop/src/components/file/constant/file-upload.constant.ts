export const FileResource = {
  PRODUCTION_ORDER: 'PRODUCTION_ORDER',
};

export const UPLOAD_FILE_ENPOINT = {
  MULTIPLE: 'files/multiple-files',
  SINGLE: 'files/single-file',
  INFO: 'files/info',
};

export const MIMETYPE_FILE_UPLOAD = [
  'application/pdf',
  'image/png',
  'image/jpeg',
];

export const MAX_SIZE_FILE_UPLOAD = {
  BASE: 4 * 1024 * 1024,
  SO: 4 * 1024 * 1024,
  IMPORT: 2 * 1024 * 1024,
};

export const MIMETYPE_FILE_UPLOAD_SALE_ORDER = [
  'application/pdf',
  'image/png',
  'image/jpeg',
];
