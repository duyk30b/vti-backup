import { Inject, Injectable } from '@nestjs/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { REQUEST } from '@nestjs/core';
import { Request } from 'express';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { NATS_PRODUCE, NATS_REQUEST } from '@config/nats.config';
import { RequestServiceInterface } from './interface/request.service.interface';
import {
  CreateManufacturingExportRequestOrderRequestDto,
  CreateManufacturingImportRequestOrderRequestDto,
} from './dto/request/create-manufacturing-import-export-request-order.request.dto';
@Injectable()
export class RequestService implements RequestServiceInterface {
  constructor(
    private readonly natsClientService: NatsClientService,

    @Inject(REQUEST) private readonly req: Request,
  ) {}

  async createManufacturingImportRequestOrder(
    payload: CreateManufacturingImportRequestOrderRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_REQUEST}.create_manufacturing_import_request_order`,
      payload,
    );

    return response;
  }

  async createManufacturingExportRequestOrder(
    payload: CreateManufacturingExportRequestOrderRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_REQUEST}.create_manufacturing_export_request_order`,
      payload,
    );
    return response;
  }
}
