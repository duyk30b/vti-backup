import {
  CreateManufacturingExportRequestOrderRequestDto,
  CreateManufacturingImportRequestOrderRequestDto,
} from '../dto/request/create-manufacturing-import-export-request-order.request.dto';

export interface RequestServiceInterface {
  createManufacturingImportRequestOrder(
    request: CreateManufacturingImportRequestOrderRequestDto,
  ): Promise<any>;
  createManufacturingExportRequestOrder(
    request: CreateManufacturingExportRequestOrderRequestDto,
  ): Promise<any>;
}
