import { ApiProperty } from "@nestjs/swagger";
import { Expose } from "class-transformer";

export class WarehouseDoorResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  warehouseName: string;
}