import { Expose, Type } from 'class-transformer';

export class WarehouseResponseDto {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  description: string;

  @Expose()
  quantity: number;

  @Expose()
  factoryId: number;
}

class WarehouseExistFloorMetaDto {
  @Expose()
  total: number;

  @Expose()
  totalFloor: number;
  
  @Expose()
  totalFloorSpace: number;

  @Expose()
  totalFloorExistItems: number;
}

export class WarehouseExistFloorResponseDto {
  @Expose()
  @Type(() => WarehouseResponseDto)
  items: WarehouseResponseDto[];

  @Expose()
  @Type(() => WarehouseExistFloorMetaDto)
  meta: WarehouseExistFloorMetaDto
}
