import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayUnique,
  IsArray,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

class ItemLot {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  lotNumber: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  quantity: number;
}

class ItemExport {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  quantity: number;

  @ApiProperty()
  @IsOptional()
  @IsArray()
  @ValidateNested()
  lots: ItemLot[];
}

export class SuggestExportItemToWarehouseShelfFloorRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  @ValidateNested()
  @ArrayUnique((item: ItemExport) => item.itemId)
  @Type(() => ItemExport)
  items: ItemExport[];

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsOptional()
  @IsArray()
  warehouseShelfFloorIds: number[];
}
