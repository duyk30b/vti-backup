import { IsInt, IsNotEmpty } from 'class-validator';

export class WarehouseRequestDto {
  @IsNotEmpty()
  @IsInt()
  id: number;
}
