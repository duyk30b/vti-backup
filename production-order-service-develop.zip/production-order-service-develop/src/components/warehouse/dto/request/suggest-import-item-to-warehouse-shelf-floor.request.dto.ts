import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { Type } from 'class-transformer';
import {
  ArrayUnique,
  IsArray,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

class ItemLot {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  lotNumber: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  quantity: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  warehouseShelfFloorId?: number;
}

class ItemImport {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  quantity: number;

  @ApiProperty()
  @IsOptional()
  @IsArray()
  @ValidateNested()
  lots: ItemLot[];
}

export class SuggestImportItemToWarehouseShelfFloorRequestDto extends PaginationQuery {
  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  @ValidateNested()
  @ArrayUnique((item: ItemImport) => item.itemId)
  @Type(() => ItemImport)
  items: ItemImport[];

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsOptional()
  @IsArray()
  warehouseShelfFloorIds: number[];
}
