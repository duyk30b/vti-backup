import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { IsEnum, IsOptional } from 'class-validator';

export class GetListWarehouseExitsFloorRequestDto extends PaginationQuery {
  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isSpace: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll: string;
}
