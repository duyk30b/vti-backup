import { BaseDto } from '@core/dto/base.dto';
import { Expose } from 'class-transformer';
import { IsNotEmpty, IsInt, IsString, IsDateString } from 'class-validator';

export class UpdateStockStatusOrderRequest extends BaseDto {
  @Expose()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @Expose()
  @IsNotEmpty()
  @IsInt()
  status: number;

  @Expose()
  @IsNotEmpty()
  @IsInt()
  type: number;

  @Expose()
  @IsNotEmpty()
  @IsDateString()
  completedAt: Date;
}
