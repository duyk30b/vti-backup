export enum WarehouseMovementTypeEnum {
  POIMP = 0,
  PO = 1,
  PRO = 2,
  SO = 3,
  IMO = 5,
  EXO = 6,
  RO = 7,
}

export enum APPROVE_TYPE {
  IPC_APPROVE = 0,
  STAFF_APPROVE = 1,
}
