import { Inject, Injectable } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { WarehouseServiceInterface } from './interface/warehouse.service.interface';
import {
  WarehouseResponseDto,
  WarehouseExistFloorResponseDto,
} from './dto/response/warehouse.dto.response';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { plainToClass } from 'class-transformer';
import { UpdateStockStatusOrderRequest } from './dto/request/update-stock-status-order.request';
import { REQUEST } from '@nestjs/core';
import { Request } from 'express';
import { GetListWarehouseExitsFloorRequestDto } from './dto/request/get-warehouse-exits-floor.request.dto';
import { SuggestImportItemToWarehouseShelfFloorRequestDto } from './dto/request/suggest-import-item-to-warehouse-shelf-floor.request.dto';
import { SuggestExportItemToWarehouseShelfFloorRequestDto } from './dto/request/suggest-export-item-to-warehouse-shelf-floor.request.dto';
import { keyBy, isEmpty } from 'lodash';
import { NATS_WAREHOUSE } from '@config/nats.config';

@Injectable()
export class WarehouseService implements WarehouseServiceInterface {
  constructor(
    @Inject('WAREHOUSE_SERVICE_CLIENT')
    private readonly warehouseServiceClient: ClientProxy,

    @Inject(REQUEST) private readonly req: Request,
  ) {}

  async getWarehouses(
    warehouseIds: number[],
    serialize?: boolean,
  ): Promise<WarehouseResponseDto[] | any> {
    const response = await this.warehouseServiceClient
      .send(`${NATS_WAREHOUSE}.get_warehouses_by_ids`, {
        warehouseIds,
      })
      .toPromise();
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      if (serialize) {
        return {};
      } else {
        return [];
      }
    }

    if (serialize) {
      return keyBy(response.data, 'id');
    }

    const dataReturn = plainToClass(
      WarehouseResponseDto,
      <any[]>response.data,
      {
        excludeExtraneousValues: true,
      },
    );

    return dataReturn;
  }

  async updateStatusWarehouseStockMovement(
    data: UpdateStockStatusOrderRequest,
  ): Promise<any> {
    const response = await this.warehouseServiceClient
      .send(
        `${NATS_WAREHOUSE}.update_warehouse_stock_movement_order_status`,
        data,
      )
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return true;
    }
    return false;
  }

  async getDetailById(id: number): Promise<any> {
    const userId = await this.req['data'].userId;
    const payload = {
      id: id,
      userId: userId,
    };
    const res = await this.warehouseServiceClient
      .send(`${NATS_WAREHOUSE}.detail`, payload)
      .toPromise();
    if (res.statusCode !== ResponseCodeEnum.SUCCESS) {
      return {};
    }

    const dataReturn = plainToClass(WarehouseResponseDto, res.data, {
      excludeExtraneousValues: true,
    });

    return dataReturn;
  }

  async getWarehouseByCodes(codes: string[]): Promise<WarehouseResponseDto[]> {
    const response = await this.warehouseServiceClient
      .send(`${NATS_WAREHOUSE}.get_warehouse_by_codes`, {
        warehouseCodes: codes,
      })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    const dataReturn = plainToClass(
      WarehouseResponseDto,
      <any[]>response.data,
      {
        excludeExtraneousValues: true,
      },
    );

    return dataReturn;
  }

  async getListWarehouseExistFloor(
    request: GetListWarehouseExitsFloorRequestDto,
  ): Promise<WarehouseExistFloorResponseDto | any> {
    const response = await this.warehouseServiceClient
      .send(`${NATS_WAREHOUSE}.get_list_warehouse_exist_floor`, request)
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return {};
    }

    return response.data;
  }

  async suggestItemImportToWarehouseShelfFloor(
    request: SuggestImportItemToWarehouseShelfFloorRequestDto,
  ): Promise<any> {
    const response = await this.warehouseServiceClient
      .send(
        `${NATS_WAREHOUSE}.suggest_position_item_import_to_warehouse_shelf_floor`,
        request,
      )
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async suggestItemExportToWarehouseShelfFloor(
    request: SuggestExportItemToWarehouseShelfFloorRequestDto,
  ): Promise<any> {
    const response = await this.warehouseServiceClient
      .send(
        `${NATS_WAREHOUSE}.suggest_position_item_export_to_warehouse_shelf_floor`,
        request,
      )
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getWarehouseDoorById(id: number): Promise<any> {
    const response = await this.warehouseServiceClient
      .send(`${NATS_WAREHOUSE}.get_warehouse_door_by_id`, { id })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return {};
    }

    return response.data;
  }

  async getWarehouseDoorsByWarehouseIds(warehouseIds: number[]): Promise<any> {
    const response = await this.warehouseServiceClient
      .send(`${NATS_WAREHOUSE}.get_warehouse_doors_by_warehouse_ids`, {
        warehouseIds,
      })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return {};
    }

    return response.data;
  }

  async getWarehouseStockMovementByOrderId(
    orderId: number,
    movementType: number,
  ): Promise<any> {
    const response = await this.warehouseServiceClient
      .send(`${NATS_WAREHOUSE}.get_warehouse_stock_movement_by_order_id`, {
        orderId,
        movementType,
      })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getDetailMovementByOrderId(
    orderId: number,
    movementType: number,
  ): Promise<any> {
    const response = await this.warehouseServiceClient
      .send(
        `${NATS_WAREHOUSE}.get_detail_warehouse_stock_movement_by_order_id`,
        {
          orderId,
          movementType,
        },
      )
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data?.items;
  }
  async getDetailMovementByOrderIdAndType(
    orderId: number,
    movementType: number,
    approveType: number,
  ): Promise<any> {
    const response = await this.warehouseServiceClient
      .send(
        `${NATS_WAREHOUSE}.get_detail_movement_by_order_id_and_approve_type`,
        {
          orderId,
          movementType,
          type: approveType,
        },
      )
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data?.items;
  }

  async importItemProductionOrder(request: any): Promise<any> {
    const response = await this.warehouseServiceClient
      .send(`${NATS_WAREHOUSE}.import`, request)
      .toPromise();

    return response;
  }

  async exportItemProductionOrder(request: any): Promise<any> {
    const response = await this.warehouseServiceClient
      .send(`${NATS_WAREHOUSE}.export`, request)
      .toPromise();

    return response;
  }

  async confirmProTransaction(request: any): Promise<any> {
    const response = await this.warehouseServiceClient
      .send(`${NATS_WAREHOUSE}.confirm_pro_transaction`, request)
      .toPromise();

    return response;
  }

  async createMovementHistories(request: any): Promise<any> {
    const response = await this.warehouseServiceClient
      .send(`${NATS_WAREHOUSE}.create_movement_histories`, request)
      .toPromise();

    return response;
  }

  async getWarehousesByKeyword(keyword): Promise<any> {
    if (isEmpty(keyword)) {
      return [];
    }

    const response = await this.warehouseServiceClient
      .send(`${NATS_WAREHOUSE}.get_warehouses_by_keyword`, {
        keyword: keyword,
      })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }
}
