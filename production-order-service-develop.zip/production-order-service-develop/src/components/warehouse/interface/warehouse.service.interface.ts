import { GetListWarehouseExitsFloorRequestDto } from '../dto/request/get-warehouse-exits-floor.request.dto';
import { SuggestExportItemToWarehouseShelfFloorRequestDto } from '../dto/request/suggest-export-item-to-warehouse-shelf-floor.request.dto';
import { SuggestImportItemToWarehouseShelfFloorRequestDto } from '../dto/request/suggest-import-item-to-warehouse-shelf-floor.request.dto';
import { UpdateStockStatusOrderRequest } from '../dto/request/update-stock-status-order.request';
import {
  WarehouseResponseDto,
  WarehouseExistFloorResponseDto,
} from '../dto/response/warehouse.dto.response';

export interface WarehouseServiceInterface {
  getWarehouses(
    warehouseIds: number[],
    serialize?: boolean,
  ): Promise<WarehouseResponseDto[]>;
  updateStatusWarehouseStockMovement(
    data: UpdateStockStatusOrderRequest,
  ): Promise<any>;
  getDetailById(id: number): Promise<WarehouseResponseDto>;
  getWarehouseByCodes(codes: string[]): Promise<WarehouseResponseDto[]>;
  getListWarehouseExistFloor(
    request: GetListWarehouseExitsFloorRequestDto,
  ): Promise<WarehouseExistFloorResponseDto | any>;
  suggestItemImportToWarehouseShelfFloor(
    request: SuggestImportItemToWarehouseShelfFloorRequestDto,
  ): Promise<any>;
  getWarehouseDoorById(id: number): Promise<any>;
  getWarehouseDoorsByWarehouseIds(warehouseIds: number[]): Promise<any>;
  suggestItemExportToWarehouseShelfFloor(
    request: SuggestExportItemToWarehouseShelfFloorRequestDto,
  ): Promise<any>;
  getWarehouseStockMovementByOrderId(
    orderId: number,
    movementType: number,
  ): Promise<any>;
  getDetailMovementByOrderId(
    orderId: number,
    movementType: number,
  ): Promise<any>;
  getDetailMovementByOrderIdAndType(
    orderId: number,
    movementType: number,
    approveType: number,
  ): Promise<any>;
  importItemProductionOrder(request: any): Promise<any>;
  exportItemProductionOrder(request: any): Promise<any>;
  confirmProTransaction(request: any): Promise<any>;
  createMovementHistories(request: any): Promise<any>;
  getWarehousesByKeyword(keyword: string): Promise<any>;
}
