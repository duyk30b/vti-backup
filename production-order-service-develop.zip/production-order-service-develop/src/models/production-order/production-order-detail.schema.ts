import { DEFAULT_COLLATION } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import * as mongoose from 'mongoose';

@Schema({
  timestamps: true,
  collection: 'productionOrderDetails',
  collation: DEFAULT_COLLATION,
})
export class ProductionOrderDetailModel extends BaseModel {
  @Prop({
    type: String,
    required: false,
  })
  name: string;

  @Prop({
    type: mongoose.Schema.Types.ObjectId,
    required: false,
  })
  proId: string;

  @Prop({
    type: Number,
    required: false,
  })
  moItemId: number;

  @Prop({
    type: Number,
    required: false,
  })
  itemId: number;

  @Prop({
    type: Number,
    required: false,
  })
  bomVersionId: number;

  @Prop({
    type: Number,
    required: false,
  })
  quantity: number;

  @Prop({
    type: Number,
    required: false,
  })
  actualQuantity: number;

  @Prop({
    type: Number,
    required: false,
  })
  bomQuantity: number;

  @Prop({
    type: Number,
    required: false,
  })
  producedQuantity: number;

  @Prop({
    type: Number,
    required: false,
  })
  warehouseId: number;

  @Prop({
    type: Number,
    required: false,
  })
  itemConvertUnitId: number;
}

export const ProductionOrderDetailSchema = SchemaFactory.createForClass(
  ProductionOrderDetailModel,
);

ProductionOrderDetailSchema.virtual('productionOrder', {
  ref: 'ProductionOrderModel',
  localField: 'proId',
  foreignField: '_id',
  justOne: false,
});
