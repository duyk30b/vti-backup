import {
  ProductionOrderStatusEnum,
  ProductionOrderTypeEnum,
} from '@components/production-order/production-order.constant';
import { DEFAULT_COLLATION } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import * as mongoose from 'mongoose';
import {
  ProductionOrderDetailModel,
  ProductionOrderDetailSchema,
} from './production-order-detail.schema';

@Schema({
  timestamps: true,
  collection: 'productionOrders',
  collation: DEFAULT_COLLATION,
})
export class ProductionOrderModel extends BaseModel {
  @Prop({
    type: String,
    required: false,
  })
  name: string;

  @Prop({
    type: String,
    required: false,
  })
  code: string;

  @Prop({
    type: Number,
    required: false,
    enum: ProductionOrderStatusEnum,
    default: ProductionOrderStatusEnum.DRAFT,
  })
  status: number;

  @Prop({
    type: Number,
    required: false,
    enum: ProductionOrderTypeEnum,
  })
  type: number;

  @Prop({
    type: Number,
    required: false,
  })
  moId: number;

  @Prop({
    type: String,
    required: false,
  })
  moCode: string;

  @Prop({
    type: Number,
    required: false,
  })
  createdUserId: number;

  @Prop({
    type: Number,
    required: false,
  })
  requestUserId: number;

  @Prop({
    type: Date,
    required: false,
  })
  requestDate: Date;

  @Prop({
    type: String,
    required: false,
  })
  note: string;

  @Prop({
    type: Number,
    required: false,
  })
  approverId: Number;

  @Prop({
    type: [String],
    required: false,
  })
  fileIds: string[];

  @Prop({
    type: Date,
    required: false,
  })
  approvedAt: Date;

  @Prop({
    type: Date,
    required: false,
  })
  completedAt: Date;

  // @Prop({
  //   type: ProductionOrderDetailSchema,
  //   require: true,
  // })
  // productionOrderDetails: ProductionOrderDetailModel;
}

export const ProductionOrderSchema =
  SchemaFactory.createForClass(ProductionOrderModel);

ProductionOrderSchema.virtual('productionOrderDetails', {
  ref: 'ProductionOrderDetailModel',
  localField: '_id',
  foreignField: 'proId',
  justOne: false,
});
