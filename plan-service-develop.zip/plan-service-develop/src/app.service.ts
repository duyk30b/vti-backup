import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nService } from 'nestjs-i18n';

@Injectable()
export class AppService {
  constructor(private readonly i18n: I18nService) {}

  async ping(): Promise<any> {
    return new ResponseBuilder('pong plans')
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  getHealth(): any {
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage('This is plan-service')
      .build();
  }
}
