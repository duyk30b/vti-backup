export const LANG = {
  EN: 'en',
  VI: 'vi',
};

export const DEFAULT_LANG = LANG.VI;

export const WARNING_STATUS_ENUM = {
  CREATED: 1,
  CONFRMED: 2,
  REJECTED: 3,
  IN_PROGRESS: 4,
  COMPLETED: 5,
};

export const WARNING_TYPE_ENUM = {
  USER_REQUEST: 1,
  PERIOD_MANTANCE: 2,
  WARNING: 3,
};

export const DEVICE_ASIGNMENTS_STATUS_ENUM = {
  UN_USE: 0,
  IN_USE: 1,
  IN_MAINTAINING: 2,
  IN_CRAPPING: 3,
  WAITING_TO_RETURN: 4,
};
