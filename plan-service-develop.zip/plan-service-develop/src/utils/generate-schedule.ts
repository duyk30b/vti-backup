import { FORTMAT_DATE_MODERATION } from '@components/schedule/master-plan/master-plan.constant';
import { forEach, has, isEmpty, isNumber, min, sortBy, values } from 'lodash';
import * as moment from 'moment';
import { div, minus, mul, plus } from './common';

export const genScheduleByShifts = (
  planFrom,
  planTo,
  quantity,
  workCenterFreeTime,
  workCenterIds,
  workCenterSerialize,
  productionTimePerItem,
  planQuantity?,
  rate?,
) => {
  const lastTimePlanTo = moment(planTo).set({
    hour: 23,
    minute: 59,
    second: 59,
  });
  const diffDay = getDiffDay(planFrom, planTo);
  const workCentersSchedule = {};
  let remainQuantity = 0;
  loopDiffDay: for (let i = 0; i < diffDay; i++) {
    const executionDay = moment(planFrom).add(i, 'days').format('YYYY-MM-DD');
    let maxQuantityByPlan = quantity;
    const hasPlanQuantityByDay =
      !isEmpty(planQuantity) && has(planQuantity, executionDay);
    if (hasPlanQuantityByDay) {
      maxQuantityByPlan = plus(
        Math.floor(planQuantity[executionDay] * rate),
        remainQuantity,
      );
      remainQuantity = 0;
    }
    let totalQuantityPlanByDay = 0;
    loopWorkCenter: for (
      let keyWorkCenterId = 0;
      keyWorkCenterId < workCenterIds.length;
      keyWorkCenterId++
    ) {
      if (quantity <= 0) {
        break loopDiffDay;
      }
      const workCenterId = workCenterIds[keyWorkCenterId];
      if (
        !has(workCenterFreeTime, workCenterId) &&
        !has(workCenterFreeTime[workCenterId], executionDay) &&
        isEmpty(workCenterFreeTime[workCenterId][executionDay])
      ) {
        continue loopWorkCenter;
      }
      const workCenterScheduleDetails = {
        quantity: 0,
        workCenterId,
        workCenterDetailSchedules: [],
      };
      const { productivityIndex } = workCenterSerialize[workCenterId];
      const workCenterShifts = sortTime(
        values(workCenterFreeTime[workCenterId][executionDay]),
      );
      workCenterShifts.map((shift, indexShift) => {
        const workingMinute = getShiftDurationInPlan(
          planFrom,
          lastTimePlanTo,
          executionDay,
          shift,
          true,
        );
        const draffQuantity = genQuantityWorkCenter(
          workingMinute,
          productivityIndex,
          productionTimePerItem,
        );
        if (draffQuantity && quantity > 0 && maxQuantityByPlan > 0) {
          const quantityPlan = min([
            quantity,
            draffQuantity,
            maxQuantityByPlan,
          ]);
          totalQuantityPlanByDay = plus(totalQuantityPlanByDay, quantityPlan);
          const isExcessiveTime = draffQuantity < quantityPlan;
          let excutionFrom = shift.startAt;
          const firstShift = moment(planFrom).set(getTimes(shift.startAt));
          if (
            i === 0 &&
            indexShift === 0 &&
            moment(firstShift.format()).isBefore(planFrom)
          ) {
            excutionFrom = moment(planFrom).format('HH:mm:ss');
          }
          workCenterScheduleDetails.quantity = plus(
            workCenterScheduleDetails.quantity,
            quantityPlan,
          );
          workCenterScheduleDetails.workCenterDetailSchedules.push({
            quantity: quantityPlan,
            workCenterShiftScheduleId: shift.id,
            excutionFrom: excutionFrom,
            excutionTo: isExcessiveTime
              ? getEndTimeManufactureQuantityItem(
                  shift.startAt,
                  quantityPlan,
                  productionTimePerItem,
                  productivityIndex,
                  shift.workCenterShiftsRelaxTimes,
                )
              : shift.endAt,
          });
          quantity = minus(quantity, quantityPlan);
          delete workCenterFreeTime[workCenterId][executionDay][shift.id];
        }
      });
      if (workCenterScheduleDetails.workCenterDetailSchedules.length > 0) {
        if (!has(workCentersSchedule, executionDay)) {
          workCentersSchedule[executionDay] = [];
        }
        workCentersSchedule[executionDay].push(workCenterScheduleDetails);
      }
    }
    if (hasPlanQuantityByDay) {
      remainQuantity = plus(
        remainQuantity,
        minus(maxQuantityByPlan, totalQuantityPlanByDay),
      );
    }
  }

  return { workCentersSchedule, overQuantity: quantity };
};

const getEndTimeManufactureQuantityItem = (
  startAt,
  quantity,
  productionTimePerItem,
  productivityIndex,
  relaxTimes: any,
) => {
  let timeManufacture = mul(
    productionTimePerItem / (productivityIndex || 1),
    quantity,
  );
  if (isEmpty(relaxTimes)) {
    return getEndTime(startAt, timeManufacture);
  }
  const relaxTimesSort = sortTime(relaxTimes);
  let workingMinute = 0;

  if (workingMinute >= timeManufacture) {
    return getEndTime(startAt, timeManufacture);
  }

  for (let i = 0; i < relaxTimesSort.length; i++) {
    const relaxCurrent = relaxTimesSort[i];
    const timeRelax = shiftDuration(relaxCurrent);
    const startRelaxNext =
      i == relaxTimesSort.length - 1
        ? getEndTime(relaxCurrent.endAt, timeManufacture)
        : relaxTimesSort[i + 1].startAt;
    const minute = shiftDuration({
      startAt: relaxCurrent.endAt,
      endAt: startRelaxNext,
    });
    if (timeManufacture - minute > 0) {
      timeManufacture -= minute;
      workingMinute += minute + timeRelax;
    } else {
      workingMinute += timeManufacture;
      break;
    }
  }
  return getEndTime(startAt, workingMinute);
};

const getEndTime = (startAt, workingMinute) => {
  const { hour: hourStart, minute: minuteStart } = getTimes(startAt);
  const endAt = moment()
    .set({ hour: +hourStart, minute: +minuteStart, second: 0 })
    .add(workingMinute, 'minute')
    .format('HH:mm:ss');
  return endAt;
};

export const genQuantityWorkCenter = (
  workingMinute: number,
  productivityIndex: number,
  productionTimePerItem: number,
) => {
  if (productionTimePerItem <= 0) {
    return 0;
  }
  const timeManufacture = productionTimePerItem / (productivityIndex || 1);
  return Math.ceil(div(workingMinute || 0, timeManufacture));
};

export const getShiftDurationInPlan = (
  planFrom,
  planTo,
  day,
  shift,
  nightShift = false,
) => {
  const { startAt, endAt, workCenterShiftsRelaxTimes } = shift;
  if (isNumber(day)) {
    day = moment(planFrom).add(day, 'days').format('YYYY-MM-DD');
  }
  const dateStartAtInPlan = moment(day + ' ' + startAt).isSameOrAfter(planFrom)
    ? moment(day + ' ' + startAt)
    : moment(planFrom);
  let dateEndAtInPlan = moment(day + ' ' + endAt).isSameOrAfter(
    day + ' ' + startAt,
  )
    ? moment(day + ' ' + endAt)
    : nightShift
    ? moment(day + ' ' + endAt).add(1, 'days')
    : moment(day + ' 23:59:59');
  if (dateEndAtInPlan.isSameOrAfter(planTo)) {
    dateEndAtInPlan = moment(planTo);
  }
  if (dateStartAtInPlan.isSameOrAfter(dateEndAtInPlan)) {
    return 0;
  }
  const duration = shiftDuration({
    startAt: dateStartAtInPlan.format('HH:mm'),
    endAt: dateEndAtInPlan.format('HH:mm'),
  });
  let durationRelaxTime = 0;
  if (!isEmpty(workCenterShiftsRelaxTimes)) {
    forEach(workCenterShiftsRelaxTimes, (relax) => {
      const relaxTime = getShiftDurationInPlan(
        dateStartAtInPlan,
        dateEndAtInPlan,
        0,
        relax,
      );
      durationRelaxTime += relaxTime;
    });
  }
  return duration - durationRelaxTime;
};

export const getDiffDay = (planFrom, planTo) => {
  return (
    moment(moment(planTo).format('YYYY-MM-DD') + ' ' + '23:00:00').diff(
      moment(planFrom).format('YYYY-MM-DD') + ' ' + '00:00:00',
      'days',
    ) + 1
  );
};

export const shiftDuration = (shift) => {
  const { startAt, endAt } = shift;
  const startTime = getTimes(startAt);
  const endTime = getTimes(endAt);
  if (
    startTime.hour > endTime.hour ||
    (startTime.hour === endTime.hour && startTime.minute > endTime.minute)
  ) {
    const end = moment()
      .add(1, 'days')
      .set({
        hour: +endTime.hour,
        minute: +endTime.minute,
        second: 60,
      });
    const start = moment().set({
      hour: +startTime.hour,
      minute: +startTime.minute,
    });
    return end.diff(start, 'minutes');
  } else {
    return moment([endTime.hour, endTime.minute], 'HH:mm').diff(
      moment([startTime.hour, startTime.minute], 'HH:mm'),
      'minutes',
    );
  }
};

export const getTimes = (time: string /* hh:mm */) => {
  const [hour, minute] = time.split(':');
  return { hour: +hour, minute: +minute };
};

export const sortTime = (workCenterShifts) => {
  return sortBy(workCenterShifts, function (shift) {
    const { hour, minute } = getTimes(shift.startAt);
    return +moment().set({ hour: +hour, minute: +minute });
  });
};

export const createDateRange = (dateFrom, dateTo): any[] => {
  const dateRange = [];
  const diffDay = getDiffDay(dateFrom, dateTo);
  for (let i = 0; i < diffDay; i++) {
    dateRange.push(
      moment(dateFrom).add(i, 'day').format(FORTMAT_DATE_MODERATION),
    );
  }
  return dateRange;
};
