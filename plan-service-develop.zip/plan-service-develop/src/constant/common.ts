export enum APIPrefix {
  Version = 'api/v1',
}

export enum ScheduleEnum {
  SALE_ORDER_SCHEDULE = 1,
  ITEM_SCHEDULE = 2,
  ITEM_PRODUCING_STEP_SCHEDULE = 3,
  WORK_CENTER_SCHEDULE = 4,
  WORK_CENTER_DETAIL_SCHEDULE = 5,
}

export enum ModeTypeEnum {
  DELAY = 1,
  EVENLY_CAPACITY = 2,
  INPUT_CAPACITY = 3,
}

export enum MasterPlanStatusEnum {
  CREATED = 0,
  APPROVED = 1,
  REJECT = 2,
  IN_PROGRESS = 3,
  DONE = 4,
}

export enum ItemProducingStepStatusEnum {
  CREATED = 0,
  IN_PROGRESS = 1,
  DONE = 2,
}

export const DEFAULT_TIME_FORMAT = 'HH:mm:ss';
