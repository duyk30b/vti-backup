import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { I18nJsonLoader, I18nModule } from 'nestjs-i18n';
import * as path from 'path';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { APP_GUARD, APP_PIPE } from '@nestjs/core';
import { ValidationPipe } from '@core/pipe/validator.pipe';
import { FactoryCalendarModule } from '@components/factory-calendar/factory-calendar.module';
import { ConfigService } from '@config/config.service';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WorkCenterCalendarModule } from '@components/work-center-calendar/work-center-calendar.module';
import { SaleOrderScheduleModule } from '@components/schedule/sale-order-schedule/sale-order-schedule.module';
import { ProduceModule } from '@components/produce/produce.module';
import { ItemModule } from '@components/item/item.module';
import { SaleModule } from '@components/sale/sale.module';
import { MasterPlanModule } from '@components/schedule/master-plan/master-plan.module';
import { UserModule } from '@components/user/user.module';
import { MasterPlanModeratedListener } from './components/schedule/master-plan/listeners/master-plan-moderated.listener';
import { InitDataModule } from '@components/init-data/init-data.module';
import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { SnakeNamingStrategy } from 'typeorm-naming-strategies';
import { BootModule } from '@nestcloud/boot';
import { resolve } from 'path';
import { BOOT, CONSUL } from '@nestcloud/common';
import { ServiceModule } from '@nestcloud/service';
import { ConsulModule } from '@nestcloud/consul';
import { HttpClientModule } from '@core/components/http-client/http-client.module';
import { KongGatewayModule } from '@core/components/kong-gateway/kong-gateway.module';
import { AuthModule } from '@components/auth/auth.module';
import { AuthorizationGuard } from '@core/guards/authorization.guard';
import { isDevMode } from '@utils/helper';
import { RequestModule } from '@components/request/request.module';
import { NatsClientModule } from '@core/transporter/nats-transporter/nats-client.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),

    I18nModule.forRoot({
      fallbackLanguage: 'vi',
      loader: I18nJsonLoader,
      loaderOptions: {
        path: path.join(__dirname, '/i18n/'),
        watch: true,
      },
    }),
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: process.env.DATABASE_POSTGRES_HOST,
      port: parseInt(process.env.DATABASE_POSTGRES_PORT),
      username: process.env.DATABASE_POSTGRES_USERNAME,
      password: process.env.DATABASE_POSTGRES_PASSWORD,
      database: process.env.DATABASE_NAME,
      logging: isDevMode(),
      entities: ['dist/entities/**/*.entity.{ts,js}'],
      migrations: ['dist/database/migrations/*.{ts,js}'],
      subscribers: ['dist/observers/subscribers/*.subscriber.{ts,js}'],
      // We are using migrations, synchronize should be set to false.
      synchronize: false,
      // Run migrations automatically,
      // you can disable this if you prefer running migration manually.
      migrationsRun: false,
      extra: {
        max: parseInt(process.env.DATABASE_MAX_POOL) || 20,
      },
      namingStrategy: new SnakeNamingStrategy(),
    }),
    EventEmitterModule.forRoot(),
    BootModule.forRoot({
      filePath: resolve(__dirname, '../config.yaml'),
    }),
    ConsulModule.forRootAsync({ inject: [BOOT] }),
    ServiceModule.forRootAsync({ inject: [BOOT, CONSUL] }),
    HttpClientModule,
    KongGatewayModule.forRootAsync(),
    FactoryCalendarModule,
    WorkCenterCalendarModule,
    MasterPlanModule,
    AuthModule,
    SaleOrderScheduleModule,
    ProduceModule,
    ItemModule,
    SaleModule,
    UserModule,
    WarehouseModule,
    InitDataModule,
    RequestModule,
    NatsClientModule,
  ],
  controllers: [AppController],
  providers: [
    {
      provide: APP_PIPE,
      useClass: ValidationPipe,
    },
    {
      provide: APP_GUARD,
      useClass: AuthorizationGuard,
    },
    ConfigService,
    AppService,
    MasterPlanModeratedListener,
  ],
})
export class AppModule {}
