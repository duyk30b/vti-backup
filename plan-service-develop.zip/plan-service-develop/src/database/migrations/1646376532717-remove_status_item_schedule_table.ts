import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class removeStatusItemScheduleTable1646376532717
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('item_schedules', [
      new TableColumn({
        name: 'status',
        type: 'int',
        default: 0,
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumns('item_schedules', [
      new TableColumn({
        name: 'status',
        type: 'int',
        default: 0,
      }),
    ]);
  }
}
