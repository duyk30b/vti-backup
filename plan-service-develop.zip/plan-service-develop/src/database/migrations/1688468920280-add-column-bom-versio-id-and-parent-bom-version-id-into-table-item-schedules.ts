import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addColumnBomVersioIdAndParentBomVersionIdIntoTableItemSchedules1688468920280
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    return await queryRunner.addColumns('item_schedules', [
      new TableColumn({
        name: 'bom_version_id',
        type: 'int',
        isNullable: true,
      }),
      new TableColumn({
        name: 'parent_bom_version_id',
        type: 'int',
        isNullable: true,
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    return await queryRunner.dropColumns('item_schedules', [
      new TableColumn({
        name: 'bom_version_id',
        type: 'int',
        isNullable: true,
      }),
      new TableColumn({
        name: 'parent_bom_version_id',
        type: 'int',
        isNullable: true,
      }),
    ]);
  }
}
