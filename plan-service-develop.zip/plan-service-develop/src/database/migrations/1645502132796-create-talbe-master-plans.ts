import { MigrationInterface, QueryRunner, Table, TableColumn } from 'typeorm';

export class createTalbeMasterPlans1645502132796 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'master_plans',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'code',
            type: 'varchar',
            length: '20',
          },
          {
            name: 'name',
            type: 'varchar',
            length: '255',
          },
          {
            name: 'description',
            type: 'varchar',
            length: '255',
            isNullable: true,
          },
          {
            name: 'date_from',
            type: 'date',
          },
          {
            name: 'date_to',
            type: 'date',
          },
          {
            name: 'created_at',
            type: 'timestamptz',
            default: 'now()',
          },
          {
            name: 'updated_at',
            type: 'timestamptz',
            default: 'now()',
          },
        ],
      }),
      true,
    );

    await queryRunner.addColumns('sale_order_schedules', [
      new TableColumn({
        name: 'master_plan_id',
        type: 'int',
      }),
    ]);

    await queryRunner.query(
      'ALTER TABLE "sale_order_schedules" ADD CONSTRAINT "FK_SaleOrderSchedules_MasterPlans" FOREIGN KEY(master_plan_id) REFERENCES "master_plans"(id) ON DELETE CASCADE',
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      'ALTER TABLE "sale_order_schedules" DROP CONSTRAINT "FK_SaleOrderSchedules_MasterPlans";',
    );

    await queryRunner.dropColumns('sale_order_schedules', [
      new TableColumn({
        name: 'master_plan_id',
        type: 'int',
      }),
    ]);

    await queryRunner.dropTable('master_plans');
  }
}
