import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addLevelAndIsOverQuantityTableItemSchedule1644899323984
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumns('item_schedules', [
      new TableColumn({
        name: 'is_over_quantity',
        type: 'boolean',
        default: false,
      }),
      new TableColumn({
        name: 'level',
        type: 'int',
        default: 1,
      }),
    ]);

    await queryRunner.dropColumns('item_schedules', [
      new TableColumn({
        name: 'over_quantity',
        type: 'int',
        default: 0,
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('item_schedules', [
      new TableColumn({
        name: 'is_over_quantity',
        type: 'boolean',
        default: false,
      }),
      new TableColumn({
        name: 'level',
        type: 'int',
        default: 1,
      }),
    ]);

    await queryRunner.addColumns('item_schedules', [
      new TableColumn({
        name: 'over_quantity',
        type: 'int',
        default: 0,
      }),
    ]);
  }
}
