import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class updateColumnTableItemSchedules1644481525646
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('item_schedules', [
      new TableColumn({
        name: 'created_at',
        type: 'timestamptz',
      }),
      new TableColumn({
        name: 'updated_at',
        type: 'timestamptz',
      }),
    ]);

    await queryRunner.addColumns('item_schedules', [
      new TableColumn({
        name: 'created_at',
        type: 'timestamptz',
        default: 'now()',
      }),
      new TableColumn({
        name: 'updated_at',
        type: 'timestamptz',
        default: 'now()',
      }),
      new TableColumn({
        name: 'over_quantity',
        type: 'int',
        default: 0,
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('item_schedules', [
      new TableColumn({
        name: 'created_at',
        type: 'timestamptz',
        default: 'now()',
      }),
      new TableColumn({
        name: 'updated_at',
        type: 'timestamptz',
        default: 'now()',
      }),
      new TableColumn({
        name: 'over_quantity',
        type: 'int',
        default: 0,
      }),
    ]);

    await queryRunner.addColumns('item_schedules', [
      new TableColumn({
        name: 'created_at',
        type: 'timestamptz',
      }),
      new TableColumn({
        name: 'updated_at',
        type: 'timestamptz',
      }),
    ]);
  }
}
