import { MigrationInterface, QueryRunner } from 'typeorm';

export class alterSaleOrderIdColumnTypeRelatedToMasterPlansTable1687339566139
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.manager.query(
      `ALTER TABLE sale_order_schedules ALTER COLUMN sale_order_id TYPE varchar(255)`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.manager.query(
      `ALTER TABLE sale_order_schedules ALTER COLUMN sale_order_id TYPE int USING sale_order_id::integer`,
    );
  }
}
