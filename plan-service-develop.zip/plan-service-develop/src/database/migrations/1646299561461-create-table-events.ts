import { MigrationInterface, QueryRunner, Table, TableColumn } from 'typeorm';

export class createTableEvents1646299561461 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      'ALTER TABLE "event_factories" DROP CONSTRAINT "FK_EventFactories_FactoryCalendar";',
    );

    await queryRunner.addColumns('factory_calendar', [
      new TableColumn({
        name: 'factory_id',
        type: 'int',
      }),
    ]);

    await queryRunner.dropTable('event_factories');

    await queryRunner.createTable(
      new Table({
        name: 'events',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'factory_id',
            type: 'int',
          },
          {
            name: 'from',
            type: 'timestamptz',
          },
          {
            name: 'to',
            type: 'timestamptz',
          },
          {
            name: 'created_at',
            type: 'timestamptz',
          },
          {
            name: 'updated_at',
            type: 'timestamptz',
          },
        ],
      }),
      true,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable('events');
    await queryRunner.createTable(
      new Table({
        name: 'event_factories',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'factory_calendar_id',
            type: 'int',
          },
          {
            name: 'factory_id',
            type: 'int',
          },
        ],
      }),
      true,
    );

    await queryRunner.dropColumns('factory_calendar', [
      new TableColumn({
        name: 'factory_id',
        type: 'int',
      }),
    ]);

    await queryRunner.query(
      'ALTER TABLE "event_factories" ADD CONSTRAINT "FK_EventFactories_FactoryCalendar" FOREIGN KEY(factory_calendar_id) REFERENCES "factory_calendar"(id) ON DELETE CASCADE',
    );
  }
}
