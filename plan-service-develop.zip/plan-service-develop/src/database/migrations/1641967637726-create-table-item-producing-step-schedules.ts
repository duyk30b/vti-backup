import {
  MigrationInterface,
  QueryRunner,
  Table,
  TableForeignKey,
} from 'typeorm';

export class createTableItemProducingStepSchedules1641967637726
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'item_producing_step_schedules',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'item_schedule_id',
            type: 'int',
          },
          {
            name: 'producing_step_id',
            type: 'int',
          },
          {
            name: 'quantity',
            type: 'int',
            default: 0,
          },
          {
            name: 'actual_quantity',
            type: 'int',
            default: 0,
          },
          {
            name: 'error_quantity',
            type: 'int',
            default: 0,
          },
          {
            name: 'date_from',
            type: 'date',
            isNullable: true,
          },
          {
            name: 'date_to',
            type: 'date',
            isNullable: true,
          },
          {
            name: 'created_at',
            type: 'timestamptz',
          },
          {
            name: 'updated_at',
            type: 'timestamptz',
          },
        ],
      }),
      true,
    );

    await queryRunner.createForeignKey(
      'item_producing_step_schedules',
      new TableForeignKey({
        columnNames: ['item_schedule_id'],
        referencedTableName: 'item_schedules',
        referencedColumnNames: ['id'],
        onDelete: 'CASCADE',
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const table = await queryRunner.getTable('item_producing_step_schedules');
    const foreignKey = table.foreignKeys.find(
      (fk) => fk.columnNames.indexOf('item_schedule_id') !== -1,
    );
    await queryRunner.dropForeignKey(
      'item_producing_step_schedules',
      foreignKey,
    );

    await queryRunner.dropTable('item_producing_step_schedules');
  }
}
