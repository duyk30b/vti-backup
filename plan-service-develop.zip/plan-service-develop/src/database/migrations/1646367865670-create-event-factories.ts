import { MigrationInterface, QueryRunner, Table, TableColumn } from 'typeorm';

export class createEventFactories1646367865670 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'event_factories',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'event_id',
            type: 'int',
          },
          {
            name: 'factory_id',
            type: 'int',
          },
        ],
      }),
      true,
    );

    await queryRunner.query(
      'ALTER TABLE "event_factories" ADD CONSTRAINT "FK_Event_EventFactories" FOREIGN KEY(event_id) REFERENCES "events"(id) ON DELETE CASCADE',
    );

    await queryRunner.dropColumns('factory_calendar', [
      new TableColumn({
        name: 'code',
        type: 'varchar',
      }),
    ]);

    await queryRunner.dropColumns('events', [
      new TableColumn({
        name: 'factory_id',
        type: 'int',
      }),
    ]);

    await queryRunner.addColumns('events', [
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '20',
        isUnique: true,
      }),
      new TableColumn({
        name: 'title',
        type: 'varchar',
        length: '50',
      }),
      new TableColumn({
        name: 'description',
        type: 'varchar',
        length: '255',
        isNullable: true,
      }),
      new TableColumn({
        name: 'type',
        type: 'int',
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      'ALTER TABLE "event_factories" DROP CONSTRAINT "FK_Event_EventFactories";',
    );
    await queryRunner.dropTable('event_factories');

    await queryRunner.addColumns('factory_calendar', [
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '20',
        isUnique: true,
      }),
    ]);

    await queryRunner.addColumns('events', [
      new TableColumn({
        name: 'factory_id',
        type: 'int',
      }),
    ]);

    await queryRunner.dropColumns('events', [
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '20',
      }),
      new TableColumn({
        name: 'title',
        type: 'varchar',
        length: '50',
      }),
      new TableColumn({
        name: 'description',
        type: 'varchar',
        length: '255',
        isNullable: true,
      }),
      new TableColumn({
        name: 'type',
        type: 'int',
      }),
    ]);
  }
}
