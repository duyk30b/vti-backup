import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addColumnToMasterPlanSchedule1656148522445
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumn(
      'item_schedules',
      new TableColumn({
        name: 'master_plan_id',
        type: 'integer',
        isNullable: true,
      }),
    );

    await queryRunner.addColumns('item_producing_step_schedules', [
      new TableColumn({
        name: 'master_plan_id',
        type: 'integer',
        isNullable: true,
      }),
      new TableColumn({
        name: 'sale_order_schedule_id',
        type: 'integer',
        isNullable: true,
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn(
      'item_schedules',
      new TableColumn({
        name: 'master_plan_id',
        type: 'integer',
        isNullable: true,
      }),
    );

    await queryRunner.dropColumns('item_producing_step_schedules', [
      new TableColumn({
        name: 'master_plan_id',
        type: 'integer',
        isNullable: true,
      }),
      new TableColumn({
        name: 'sale_order_schedule_id',
        type: 'integer',
        isNullable: true,
      }),
    ]);
  }
}
