import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addManufacturingOrderIdToItemScheudlesTable1655799364373
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    return await queryRunner.addColumn(
      'item_schedules',
      new TableColumn({
        name: 'manufacturing_order_id',
        type: 'integer',
        isNullable: true,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    return await queryRunner.dropColumn(
      'item_schedules',
      new TableColumn({
        name: 'manufacturing_order_id',
        type: 'integer',
        isNullable: true,
      }),
    );
  }
}
