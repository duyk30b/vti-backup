import {
  MigrationInterface,
  QueryRunner,
  Table,
  TableForeignKey,
} from 'typeorm';

export class createTableItemSchedules1641967545771
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'item_schedules',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'sale_order_schedule_id',
            type: 'int',
          },
          {
            name: 'item_id',
            type: 'int',
          },
          {
            name: 'bom_id',
            type: 'int',
          },
          {
            name: 'parent_bom_id',
            type: 'int',
            isNullable: true,
          },
          {
            name: 'quantity',
            type: 'int',
            default: 0,
          },
          {
            name: 'actual_quantity',
            type: 'int',
            default: 0,
          },
          {
            name: 'error_quantity',
            type: 'int',
            default: 0,
          },
          {
            name: 'date_from',
            type: 'date',
            isNullable: true,
          },
          {
            name: 'date_to',
            type: 'date',
            isNullable: true,
          },
          {
            name: 'step_number',
            type: 'int',
            isNullable: true,
          },
          {
            name: 'created_at',
            type: 'timestamptz',
          },
          {
            name: 'updated_at',
            type: 'timestamptz',
          },
        ],
      }),
      true,
    );

    await queryRunner.createForeignKey(
      'item_schedules',
      new TableForeignKey({
        columnNames: ['sale_order_schedule_id'],
        referencedTableName: 'sale_order_schedules',
        referencedColumnNames: ['id'],
        onDelete: 'CASCADE',
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const table = await queryRunner.getTable('item_schedules');
    const foreignKey = table.foreignKeys.find(
      (fk) => fk.columnNames.indexOf('sale_order_schedule_id') !== -1,
    );
    await queryRunner.dropForeignKey('item_schedules', foreignKey);

    await queryRunner.dropTable('item_schedules');
  }
}
