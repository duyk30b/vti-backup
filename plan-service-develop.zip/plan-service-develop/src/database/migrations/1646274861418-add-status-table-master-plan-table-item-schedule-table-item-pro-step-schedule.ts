import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addStatusTableMasterPlanTableItemScheduleTableItemProStepSchedule1646274861418
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumns('master_plans', [
      new TableColumn({
        name: 'status',
        type: 'int',
        default: 0,
      }),
    ]);
    await queryRunner.addColumns('item_schedules', [
      new TableColumn({
        name: 'status',
        type: 'int',
        default: 0,
      }),
    ]);
    await queryRunner.addColumns('item_producing_step_schedules', [
      new TableColumn({
        name: 'status',
        type: 'int',
        default: 0,
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('master_plans', [
      new TableColumn({
        name: 'status',
        type: 'int',
        default: 0,
      }),
    ]);
    await queryRunner.dropColumns('item_schedules', [
      new TableColumn({
        name: 'status',
        type: 'int',
        default: 0,
      }),
    ]);
    await queryRunner.dropColumns('item_producing_step_schedules', [
      new TableColumn({
        name: 'status',
        type: 'int',
        default: 0,
      }),
    ]);
  }
}
