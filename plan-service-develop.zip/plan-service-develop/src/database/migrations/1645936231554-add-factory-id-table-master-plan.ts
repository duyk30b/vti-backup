import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addFactoryIdTableMasterPlan1645936231554
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumns('master_plans', [
      new TableColumn({
        name: 'factory_id',
        type: 'int',
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('master_plans', [
      new TableColumn({
        name: 'factory_id',
        type: 'int',
      }),
    ]);
  }
}
