import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class updateColumnTableWorkcenterDetailSchedules1644482614543
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('work_center_detail_schedules', [
      new TableColumn({
        name: 'created_at',
        type: 'timestamptz',
      }),
      new TableColumn({
        name: 'updated_at',
        type: 'timestamptz',
      }),
    ]);

    await queryRunner.addColumns('work_center_detail_schedules', [
      new TableColumn({
        name: 'created_at',
        type: 'timestamptz',
        default: 'now()',
      }),
      new TableColumn({
        name: 'updated_at',
        type: 'timestamptz',
        default: 'now()',
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('work_center_detail_schedules', [
      new TableColumn({
        name: 'created_at',
        type: 'timestamptz',
        default: 'now()',
      }),
      new TableColumn({
        name: 'updated_at',
        type: 'timestamptz',
        default: 'now()',
      }),
    ]);

    await queryRunner.addColumns('work_center_detail_schedules', [
      new TableColumn({
        name: 'created_at',
        type: 'timestamptz',
      }),
      new TableColumn({
        name: 'updated_at',
        type: 'timestamptz',
      }),
    ]);
  }
}
