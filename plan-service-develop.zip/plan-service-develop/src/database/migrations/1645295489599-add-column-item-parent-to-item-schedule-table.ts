import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addColumnItemParentToItemScheduleTable1645295489599
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumn(
      'item_schedules',
      new TableColumn({
        name: 'item_finish_id',
        type: 'int',
        isNullable: true,
        default: null,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn(
      'item_schedules',
      new TableColumn({
        name: 'item_finish_id',
        type: 'int',
        isNullable: true,
        default: null,
      }),
    );
  }
}
