import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addColumnMasterPlanToItemManufacturingOrdersTable1653387326390
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumns('item_manufacturing_orders', [
      new TableColumn({
        name: 'master_plan_id',
        type: 'int',
        isNullable: true,
      }),
      new TableColumn({
        name: 'sale_order_schedule_id',
        type: 'int',
        isNullable: true,
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('item_manufacturing_orders', [
      new TableColumn({
        name: 'master_plan_id',
        type: 'int',
        isNullable: true,
      }),
      new TableColumn({
        name: 'sale_order_schedule_id',
        type: 'int',
        isNullable: true,
      }),
    ]);
  }
}
