import {
  MigrationInterface,
  QueryRunner,
  Table,
  TableForeignKey,
} from 'typeorm';

export class createItemManufacturingOrderTable1645894028506
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'item_manufacturing_orders',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'item_schedule_id',
            type: 'int',
          },
          {
            name: 'item_id',
            type: 'int',
          },
          {
            name: 'mo_id',
            type: 'int',
          },
          {
            name: 'date_from',
            type: 'date',
          },
          {
            name: 'date_to',
            type: 'date',
          },
          {
            name: 'quantity',
            type: 'int',
            default: 0,
          },
          {
            name: 'created_at',
            type: 'timestamptz',
            default: 'now()',
          },
          {
            name: 'updated_at',
            type: 'timestamptz',
            default: 'now()',
          },
        ],
      }),
    );

    await queryRunner.createForeignKey(
      'item_manufacturing_orders',
      new TableForeignKey({
        columnNames: ['item_schedule_id'],
        referencedTableName: 'item_schedules',
        referencedColumnNames: ['id'],
        onDelete: 'CASCADE',
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const table = await queryRunner.getTable('item_manufacturing_orders');
    const foreignKey = table.foreignKeys.find(
      (fk) => fk.columnNames.indexOf('item_schedule_id') !== -1,
    );
    await queryRunner.dropForeignKey('item_manufacturing_orders', foreignKey);
    await queryRunner.dropTable('item_manufacturing_orders');
  }
}
