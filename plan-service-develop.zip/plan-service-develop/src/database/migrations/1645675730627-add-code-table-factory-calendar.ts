import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addCodeTableFactoryCalendar1645675730627
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumns('factory_calendar', [
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '20',
        isUnique: true,
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('factory_calendar', [
      new TableColumn({
        name: 'code',
        type: 'varchar',
        length: '20',
        isUnique: true,
      }),
    ]);
  }
}
