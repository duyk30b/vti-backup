import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class changeQuantityMaterial1684398164622 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.changeColumns('material_producing_step_schedules', [
      {
        oldColumn: new TableColumn({
          name: 'quantity',
          type: 'int',
          default: 0,
        }),
        newColumn: new TableColumn({
          name: 'quantity',
          type: 'decimal',
          precision: 20,
          scale: 2,
          default: 0,
        }),
      },
      {
        oldColumn: new TableColumn({
          name: 'actual_quantity',
          type: 'int',
          default: 0,
        }),
        newColumn: new TableColumn({
          name: 'actual_quantity',
          type: 'decimal',
          precision: 20,
          scale: 2,
          default: 0,
        }),
      },
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.changeColumns('material_producing_step_schedules', [
      {
        newColumn: new TableColumn({
          name: 'quantity',
          type: 'int',
          default: 0,
        }),
        oldColumn: new TableColumn({
          name: 'quantity',
          type: 'decimal',
          precision: 20,
          scale: 2,
          default: 0,
        }),
      },
      {
        newColumn: new TableColumn({
          name: 'actual_quantity',
          type: 'int',
          default: 0,
        }),
        oldColumn: new TableColumn({
          name: 'actual_quantity',
          type: 'decimal',
          precision: 20,
          scale: 2,
          default: 0,
        }),
      },
    ]);
  }
}
