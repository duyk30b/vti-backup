import {
  MigrationInterface,
  QueryRunner,
  Table,
  TableForeignKey,
} from 'typeorm';

export class addMaterialProducingStepSchedulesTable1653367374955
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'material_producing_step_schedules',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'item_producing_step_schedule_id',
            type: 'int',
          },
          {
            name: 'item_id',
            type: 'int',
          },
          {
            name: 'quantity',
            type: 'int',
            default: 0,
          },
          {
            name: 'actual_quantity',
            type: 'int',
            default: 0,
          },
        ],
      }),
      true,
    );

    await queryRunner.createForeignKey(
      'material_producing_step_schedules',
      new TableForeignKey({
        columnNames: ['item_producing_step_schedule_id'],
        referencedTableName: 'item_producing_step_schedules',
        referencedColumnNames: ['id'],
        onDelete: 'CASCADE',
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const table = await queryRunner.getTable(
      'material_producing_step_schedules',
    );

    const foreignKey = table.foreignKeys.find(
      (fk) => fk.columnNames.indexOf('item_producing_step_schedule_id') !== -1,
    );
    await queryRunner.dropForeignKey(
      'material_producing_step_schedules',
      foreignKey,
    );

    await queryRunner.dropTable('material_producing_step_schedules');
  }
}
