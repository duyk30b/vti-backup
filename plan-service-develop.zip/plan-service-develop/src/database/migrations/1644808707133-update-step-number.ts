import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class updateStepNumber1644808707133 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('item_schedules', [
      new TableColumn({
        name: 'step_number',
        type: 'int',
        isNullable: true,
      }),
    ]);

    await queryRunner.addColumns('item_producing_step_schedules', [
      new TableColumn({
        name: 'step_number',
        type: 'int',
        default: 0,
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumns('item_schedules', [
      new TableColumn({
        name: 'step_number',
        type: 'int',
        isNullable: true,
      }),
    ]);

    await queryRunner.dropColumns('item_producing_step_schedules', [
      new TableColumn({
        name: 'step_number',
        type: 'int',
        default: 0,
      }),
    ]);
  }
}
