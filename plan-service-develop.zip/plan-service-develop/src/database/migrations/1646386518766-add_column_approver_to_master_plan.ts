import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addColumnApproverToMasterPlan1646386518766
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumns('master_plans', [
      new TableColumn({
        name: 'approver_id',
        type: 'int',
        isNullable: true,
      }),
      new TableColumn({
        name: 'approved_at',
        type: 'timestamptz',
        isNullable: true,
      }),
    ]);
    await queryRunner.addColumns('item_schedules', [
      new TableColumn({
        name: 'status',
        type: 'int',
        default: 0,
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('master_plans', [
      new TableColumn({
        name: 'approver_id',
        type: 'int',
        isNullable: true,
      }),
      new TableColumn({
        name: 'approved_at',
        type: 'timestamptz',
        isNullable: true,
      }),
    ]);
    await queryRunner.dropColumns('item_schedules', [
      new TableColumn({
        name: 'status',
        type: 'int',
        default: 0,
      }),
    ]);
  }
}
