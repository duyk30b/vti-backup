import { MigrationInterface, QueryRunner, Table } from 'typeorm';

export class createTableFactoryWorkDays1646300553309
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'factory_work_days',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'factory_calendar_id',
            type: 'int',
          },
          {
            name: 'working_day',
            type: 'int',
          },
          {
            name: 'created_at',
            type: 'timestamptz',
          },
          {
            name: 'updated_at',
            type: 'timestamptz',
          },
        ],
      }),
      true,
    );

    await queryRunner.query(
      'ALTER TABLE "factory_work_days" ADD CONSTRAINT "FK_FactoryWorkDays_FactoryCalendar" FOREIGN KEY(factory_calendar_id) REFERENCES "factory_calendar"(id) ON DELETE CASCADE',
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      'ALTER TABLE "factory_work_days" DROP CONSTRAINT "FK_FactoryWorkDays_FactoryCalendar";',
    );
    await queryRunner.dropTable('factory_work_days');
  }
}
