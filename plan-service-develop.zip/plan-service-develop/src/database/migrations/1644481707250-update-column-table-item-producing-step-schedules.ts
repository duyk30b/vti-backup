import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class updateColumnTableItemProducingStepSchedules1644481707250
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('item_producing_step_schedules', [
      new TableColumn({
        name: 'created_at',
        type: 'timestamptz',
      }),
      new TableColumn({
        name: 'updated_at',
        type: 'timestamptz',
      }),
    ]);

    await queryRunner.addColumns('item_producing_step_schedules', [
      new TableColumn({
        name: 'created_at',
        type: 'timestamptz',
        default: 'now()',
      }),
      new TableColumn({
        name: 'updated_at',
        type: 'timestamptz',
        default: 'now()',
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('item_producing_step_schedules', [
      new TableColumn({
        name: 'created_at',
        type: 'timestamptz',
        default: 'now()',
      }),
      new TableColumn({
        name: 'updated_at',
        type: 'timestamptz',
        default: 'now()',
      }),
    ]);

    await queryRunner.addColumns('item_producing_step_schedules', [
      new TableColumn({
        name: 'created_at',
        type: 'timestamptz',
      }),
      new TableColumn({
        name: 'updated_at',
        type: 'timestamptz',
      }),
    ]);
  }
}
