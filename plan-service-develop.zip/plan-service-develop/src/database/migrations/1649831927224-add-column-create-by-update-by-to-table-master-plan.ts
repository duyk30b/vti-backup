import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addColumnCreateByUpdateByToTableMasterPlan1649831927224
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumns('master_plans', [
      new TableColumn({
        name: 'created_by',
        type: 'int',
        isNullable: true,
      }),
      new TableColumn({
        name: 'updated_by',
        type: 'int',
        isNullable: true,
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('master_plans', [
      new TableColumn({
        name: 'created_by',
        type: 'int',
        isNullable: true,
      }),
      new TableColumn({
        name: 'updated_by',
        type: 'int',
        isNullable: true,
      }),
    ]);
  }
}
