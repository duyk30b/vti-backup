import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addColumnPlanQuantityToMasterPlan1652413074156
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumn(
      'item_producing_step_schedules',
      new TableColumn({
        name: 'plan_quantity',
        type: 'int',
        default: 0,
      }),
    );
    await queryRunner.addColumn(
      'item_schedules',
      new TableColumn({
        name: 'need_to_manufacture',
        type: 'boolean',
        default: true,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn(
      'item_producing_step_schedules',
      new TableColumn({
        name: 'plan_quantity',
        type: 'int',
        default: 0,
      }),
    );
    await queryRunner.dropColumn(
      'item_schedules',
      new TableColumn({
        name: 'need_to_manufacture',
        type: 'boolean',
        default: true,
      }),
    );
  }
}
