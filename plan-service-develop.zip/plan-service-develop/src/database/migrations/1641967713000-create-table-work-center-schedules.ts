import {
  MigrationInterface,
  QueryRunner,
  Table,
  TableForeignKey,
} from 'typeorm';

export class createTableWorkCenterSchedules1641967713000
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'work_center_schedules',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'work_center_id',
            type: 'int',
          },
          {
            name: 'item_producing_step_schedule_id',
            type: 'int',
          },
          {
            name: 'quantity',
            type: 'int',
            default: 0,
          },
          {
            name: 'actual_quantity',
            type: 'int',
            default: 0,
          },
          {
            name: 'error_quantity',
            type: 'int',
            default: 0,
          },
          {
            name: 'excution_date',
            type: 'date',
          },
          {
            name: 'created_at',
            type: 'timestamptz',
          },
          {
            name: 'updated_at',
            type: 'timestamptz',
          },
        ],
      }),
      true,
    );

    await queryRunner.createForeignKey(
      'work_center_schedules',
      new TableForeignKey({
        columnNames: ['item_producing_step_schedule_id'],
        referencedTableName: 'item_producing_step_schedules',
        referencedColumnNames: ['id'],
        onDelete: 'CASCADE',
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const table = await queryRunner.getTable('work_center_schedules');
    const foreignKey = table.foreignKeys.find(
      (fk) => fk.columnNames.indexOf('item_producing_step_schedule_id') !== -1,
    );
    await queryRunner.dropForeignKey('work_center_schedules', foreignKey);
    await queryRunner.dropTable('work_center_schedules');
  }
}
