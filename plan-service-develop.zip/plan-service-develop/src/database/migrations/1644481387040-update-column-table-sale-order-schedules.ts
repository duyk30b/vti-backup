import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class updateColumnTableSaleOrderSchedules1644481387040
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('sale_order_schedules', [
      new TableColumn({
        name: 'date_from',
        type: 'date',
      }),
      new TableColumn({
        name: 'date_to',
        type: 'date',
      }),
      new TableColumn({
        name: 'created_at',
        type: 'timestamptz',
      }),
      new TableColumn({
        name: 'updated_at',
        type: 'timestamptz',
      }),
    ]);

    await queryRunner.addColumns('sale_order_schedules', [
      new TableColumn({
        name: 'date_from',
        type: 'date',
        isNullable: true,
      }),
      new TableColumn({
        name: 'date_to',
        type: 'date',
        isNullable: true,
      }),
      new TableColumn({
        name: 'created_at',
        type: 'timestamptz',
        default: 'now()',
      }),
      new TableColumn({
        name: 'updated_at',
        type: 'timestamptz',
        default: 'now()',
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('sale_order_schedules', [
      new TableColumn({
        name: 'date_from',
        type: 'date',
        isNullable: true,
      }),
      new TableColumn({
        name: 'date_to',
        type: 'date',
        isNullable: true,
      }),
      new TableColumn({
        name: 'created_at',
        type: 'timestamptz',
        default: 'now()',
      }),
      new TableColumn({
        name: 'updated_at',
        type: 'timestamptz',
        default: 'now()',
      }),
    ]);

    await queryRunner.addColumns('sale_order_schedules', [
      new TableColumn({
        name: 'date_from',
        type: 'date',
      }),
      new TableColumn({
        name: 'date_to',
        type: 'date',
      }),
      new TableColumn({
        name: 'created_at',
        type: 'timestamptz',
      }),
      new TableColumn({
        name: 'updated_at',
        type: 'timestamptz',
      }),
    ]);
  }
}
