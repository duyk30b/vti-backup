import { MigrationInterface, QueryRunner, Table } from 'typeorm';

export class createTableRelaxes1646300192516 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'relaxes',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'shift_id',
            type: 'int',
          },
          {
            name: 'title',
            type: 'varchar',
            length: '50',
          },
          {
            name: 'description',
            type: 'varchar',
            length: '255',
            isNullable: true,
          },
          {
            name: 'from',
            type: 'time',
          },
          {
            name: 'to',
            type: 'time',
          },
          {
            name: 'created_at',
            type: 'timestamptz',
          },
          {
            name: 'updated_at',
            type: 'timestamptz',
          },
        ],
      }),
      true,
    );

    await queryRunner.query(
      'ALTER TABLE "relaxes" ADD CONSTRAINT "FK_Relaxes_Shifts" FOREIGN KEY(shift_id) REFERENCES "shifts"(id) ON DELETE CASCADE',
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      'ALTER TABLE "relaxes" DROP CONSTRAINT "FK_Relaxes_Shifts";',
    );
    await queryRunner.dropTable('relaxes');
  }
}
