import { MigrationInterface, QueryRunner, Table } from 'typeorm';

export class createTableSaleOrderSchedules1641961306385
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'sale_order_schedules',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'sale_order_id',
            type: 'int',
          },
          {
            name: 'date_from',
            type: 'date',
          },
          {
            name: 'date_to',
            type: 'date',
          },
          {
            name: 'created_at',
            type: 'timestamptz',
          },
          {
            name: 'updated_at',
            type: 'timestamptz',
          },
        ],
      }),
      true,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable('sale_order_schedules');
  }
}
