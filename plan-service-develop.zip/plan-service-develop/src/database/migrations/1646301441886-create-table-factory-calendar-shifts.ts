import { MigrationInterface, QueryRunner, Table } from 'typeorm';

export class createTableFactoryCalendarShifts1646301441886
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'factory_calendar_shifts',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'factory_calendar_id',
            type: 'int',
          },
          {
            name: 'shift_id',
            type: 'int',
          },
        ],
      }),
      true,
    );

    await queryRunner.query(
      'ALTER TABLE "factory_calendar_shifts" ADD CONSTRAINT "FK_FactoryCalendarShifts_FactoryCalendar" FOREIGN KEY(factory_calendar_id) REFERENCES "factory_calendar"(id) ON DELETE CASCADE',
    );

    await queryRunner.query(
      'ALTER TABLE "factory_calendar_shifts" ADD CONSTRAINT "FK_FactoryCalendarShifts_Shifts" FOREIGN KEY(shift_id) REFERENCES "shifts"(id) ON DELETE CASCADE',
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      'ALTER TABLE "factory_calendar_shifts" DROP CONSTRAINT "FK_FactoryCalendarShifts_FactoryCalendar";',
    );
    await queryRunner.query(
      'ALTER TABLE "factory_calendar_shifts" DROP CONSTRAINT "FK_FactoryCalendarShifts_Shifts";',
    );
    await queryRunner.dropTable('factory_calendar_shifts');
  }
}
