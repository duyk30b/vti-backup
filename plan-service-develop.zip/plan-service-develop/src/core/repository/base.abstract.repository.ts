import { BaseInterfaceRepository } from './base.interface.repository';

import { DeleteResult, Repository, SelectQueryBuilder } from 'typeorm';
import { join } from 'lodash';

export abstract class BaseAbstractRepository<T>
  implements BaseInterfaceRepository<T>
{
  protected entity: Repository<T>;

  protected constructor(entity: Repository<T>) {
    this.entity = entity;
  }

  public async create(data: T | any): Promise<T> {
    return await this.entity.save(data);
  }

  public async update(data: T | any): Promise<T> {
    return await this.entity.save(data);
  }

  public async createMany(data: T[] | any): Promise<T[]> {
    return await this.entity.save(data);
  }

  public async findOneById(id: number): Promise<T> {
    const condition: any = {
      id: id,
    };
    return await this.entity.findOneBy(condition);
  }

  public async findByCondition(filterCondition: any): Promise<T[]> {
    return await this.entity.find({ where: filterCondition });
  }

  public async findOneByCondition(filterCondition: any): Promise<T> {
    return await this.entity.findOneBy(filterCondition);
  }

  public async findWithRelations(relations: any): Promise<T[]> {
    return await this.entity.find(relations);
  }

  public async findOneWithRelations(relations: any): Promise<any> {
    return await this.entity.findOne(relations);
  }

  public async findAll(): Promise<T[]> {
    return await this.entity.find();
  }

  public async remove(id: number): Promise<DeleteResult> {
    return await this.entity.delete(id);
  }

  public async removeByCondition(filterCondition: any): Promise<DeleteResult> {
    return await this.entity.delete(filterCondition);
  }

  public async countWithRelations(relations: any): Promise<number> {
    return await this.entity.count(relations);
  }

  public async findAndCount(filterCondition: any): Promise<any> {
    return await this.entity.findAndCount(filterCondition);
  }

  public async count(): Promise<any> {
    return await this.entity.count();
  }

  public buildTempTable(
    query: SelectQueryBuilder<any>,
    data: any[],
    alias: string,
    columns: string[],
  ): SelectQueryBuilder<any> {
    const values = this.toTempTableString(data, columns);
    const arrColumns = columns.map((record) => '"' + record + '"');
    return query
      .select(['i', ...arrColumns])
      .from(
        `(SELECT * FROM (VALUES ${values}) sort(i,${join(arrColumns, ',')}))`,
        alias,
      );
  }

  public toTempTableString(data: any[], columns: string[]) {
    return join(
      data.map((v, i) => {
        return `(${i},${join(
          columns.map((c) => this.toValue(v[c])),
          ',',
        )})`;
      }),
      ',',
    );
  }
  private toValue(value) {
    if (typeof value == 'string' || typeof value == 'object') {
      return `'${value}'`;
    } else {
      return value;
    }
  }
}
