import { DeleteResult } from 'typeorm';

export interface BaseInterfaceRepository<T> {
  create(data: T | any): Promise<T>;

  update(data: T | any): Promise<T>;

  createMany(data: T[]): Promise<T[]>;

  findOneById(id: number): Promise<T>;

  findByCondition(filterCondition: any): Promise<T[]>;

  findOneByCondition(filterCondition: any): Promise<T>;

  findAll(): Promise<T[]>;

  remove(id: number): Promise<DeleteResult>;

  removeByCondition(filterCondition: any): Promise<DeleteResult>;

  findWithRelations(relations: any): Promise<T[]>;

  findOneWithRelations(relations: any): Promise<T>;

  countWithRelations(relations: any): Promise<number>;

  findAndCount(filterCondition: any): Promise<any>;

  count(condition?: any): Promise<any>;
}
