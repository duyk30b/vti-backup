import { Expose } from 'class-transformer';

export class BasicResponseDto {
  @Expose()
  id: number;

  @Expose()
  code: string;

  @Expose()
  name: string;
}
