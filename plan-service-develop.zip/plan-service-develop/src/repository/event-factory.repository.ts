import { EventFactoryRepositoryInterface } from '@components/factory-calendar/interface/event-factory.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { EventFactoryEntity } from '@entities/factory-calendar/event-factories.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class EventFactoryRepository
  extends BaseAbstractRepository<EventFactoryEntity>
  implements EventFactoryRepositoryInterface
{
  constructor(
    @InjectRepository(EventFactoryEntity)
    private readonly eventFactoryRepository: Repository<EventFactoryEntity>,
  ) {
    super(eventFactoryRepository);
  }

  createEntity(param: any): EventFactoryEntity {
    const entity = new EventFactoryEntity();
    for (const key in param) {
      entity[key] = param[key];
    }
    return entity;
  }
}
