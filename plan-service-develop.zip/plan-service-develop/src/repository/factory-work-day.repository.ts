import { FactoryWorkDayRepositoryInterface } from '@components/factory-calendar/interface/factory-work-day.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { FactoryWorkDayEntity } from '@entities/factory-calendar/factory-work-day.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class FactoryWorkDayRepository
  extends BaseAbstractRepository<FactoryWorkDayEntity>
  implements FactoryWorkDayRepositoryInterface
{
  constructor(
    @InjectRepository(FactoryWorkDayEntity)
    private readonly factoryWorkDayRepository: Repository<FactoryWorkDayEntity>,
  ) {
    super(factoryWorkDayRepository);
  }

  createEntity(param: any): FactoryWorkDayEntity {
    const entity = new FactoryWorkDayEntity();
    for (const key in param) {
      entity[key] = param[key];
    }
    entity.createdAt = new Date();
    entity.updatedAt = new Date();
    return entity;
  }
}
