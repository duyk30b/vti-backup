import { MaterialProducingStepScheduleRepositoryInterface } from '@components/schedule/material-producing-step-schedule/interface/material-producing-step-schedule.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { MaterialProducingStepScheduleEntity } from '@entities/schedule/sale-order-schedule/material-producing-step-schedule.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class MaterialProducingStepScheduleRepository
  extends BaseAbstractRepository<MaterialProducingStepScheduleEntity>
  implements MaterialProducingStepScheduleRepositoryInterface
{
  constructor(
    @InjectRepository(MaterialProducingStepScheduleEntity)
    private readonly materialProducingStepScheduleRepository: Repository<MaterialProducingStepScheduleEntity>,
  ) {
    super(materialProducingStepScheduleRepository);
  }
}
