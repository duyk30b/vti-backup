import { ItemScheduleRepositoryInterface } from '@components/schedule/item-schedule/interface/item-schedule.repository.interface';
import { ItemScheduleRepositoryDto } from '@components/schedule/master-plan/dto/repository/item-schedule.dto';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { ItemProducingStepScheduleEntity } from '@entities/schedule/sale-order-schedule/item-producing-step-schedule.entity';
import { ItemScheduleEntity } from '@entities/schedule/sale-order-schedule/item-schedule.entity';
import { SaleOrderScheduleEntity } from '@entities/schedule/sale-order-schedule/sale-order-schedule.entity';
import { WorkCenterDetailScheduleEntity } from '@entities/schedule/work-center-schedule/work-center-detail-schedule.entity';
import { WorkCenterScheduleEntity } from '@entities/schedule/work-center-schedule/work-center-schedule.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class ItemScheduleRepository
  extends BaseAbstractRepository<ItemScheduleEntity>
  implements ItemScheduleRepositoryInterface
{
  constructor(
    @InjectRepository(ItemScheduleEntity)
    private readonly itemSchedulesRepository: Repository<ItemScheduleEntity>,
  ) {
    super(itemSchedulesRepository);
  }

  createEntity(
    bomId: number,
    parentBomId: number,
    parentBomVersionId: number,
    itemId: number,
    level: number,
    itemFinishId: number,
    quantity: number,
    dateFrom: any,
    dateTo: any,
    needToManufacture: boolean,
    bomVersionId: number,
  ): ItemScheduleEntity {
    const itemSchedule = new ItemScheduleEntity();
    itemSchedule.itemId = itemId;
    itemSchedule.bomId = bomId;
    itemSchedule.parentBomId = parentBomId;
    itemSchedule.parentBomVersionId = parentBomVersionId;
    itemSchedule.level = level;
    itemSchedule.quantity = quantity;
    itemSchedule.itemFinishId = itemFinishId;
    itemSchedule.actualQuantity = 0;
    itemSchedule.errorQuantity = 0;
    itemSchedule.isOverQuantity = false;
    itemSchedule.dateFrom = dateFrom;
    itemSchedule.dateTo = dateTo;
    itemSchedule.createdAt = new Date();
    itemSchedule.updatedAt = new Date();
    itemSchedule.needToManufacture = needToManufacture;
    itemSchedule.bomVersionId = bomVersionId;

    return itemSchedule;
  }

  updateEntity(
    param: any,
    itemSchedule?: ItemScheduleEntity,
  ): ItemScheduleEntity {
    let entity: any = null;
    if (itemSchedule) {
      entity = itemSchedule;
    } else {
      entity = new ItemScheduleEntity();
    }
    for (const key in param) {
      if (key !== 'itemProducingStepSchedules' && key !== 'updatedAt') {
        entity[key] = param[key];
      }
    }
    entity.updatedAt = new Date();
    return entity;
  }

  async findByIds(ids: number[]): Promise<ItemScheduleEntity[]> {
    return this.itemSchedulesRepository
      .createQueryBuilder('is')
      .select([
        'is.id AS "id"',
        'is.saleOrderScheduleId AS "saleOrderScheduleId"',
        'is.itemId AS "itemId"',
        'is.bomId AS "bomId"',
        'is.parentBomId AS "parentBomId"',
        'is.quantity AS "quantity"',
        'is.actualQuantity AS "actualQuantity"',
        'is.errorQuantity AS "errorQuantity"',
        'is.level AS "level"',
        'is.isOverQuantity AS "isOverQuantity"',
        'is.dateFrom AS "dateFrom"',
        'is.dateTo AS "dateTo"',
        'is.createdAt AS "createdAt"',
        'is.updatedAt AS "updatedAt"',
      ])
      .andWhere('is.id IN (:...ids)', {
        ids: ids,
      })
      .getRawMany();
  }

  async getScheduleByItemId(
    masterPlanId: number,
    saleOrderId: string,
    itemId: number,
  ): Promise<ItemScheduleRepositoryDto | any> {
    return this.itemSchedulesRepository
      .createQueryBuilder('is')
      .select([
        'is.id AS "id"',
        'is.saleOrderScheduleId AS "saleOrderScheduleId"',
        'is.masterPlanId AS "masterPlanId"',
        'is.itemId AS "itemId"',
        'is.itemFinishId AS "itemFinishId"',
        'is.bomId AS "bomId"',
        'is.parentBomId AS "parentBomId"',
        'is.quantity AS "quantity"',
        'is.actualQuantity AS "actualQuantity"',
        'is.errorQuantity AS "errorQuantity"',
        'is.level AS "level"',
        'is.isOverQuantity AS "isOverQuantity"',
        'is.dateFrom AS "dateFrom"',
        'is.dateTo AS "dateTo"',
        'is.createdAt AS "createdAt"',
        'is.updatedAt AS "updatedAt"',
        'is.needToManufacture AS "needToManufacture"',
        `CASE WHEN COUNT(q1) = 0 THEN '[]' ELSE json_agg(
        json_build_object('id', q1.id,
                          'itemScheduleId', q1.itemScheduleId,
                          'status', q1.status,
                          'producingStepId', q1.producingStepId,
                          'planQuantity', q1.planQuantity,
                          'quantity', q1.quantity,
                          'actualQuantity', q1.actualQuantity,
                          'errorQuantity', q1.errorQuantity,
                          'overQuantity', q1.overQuantity,
                          'stepNumber', q1.stepNumber,
                          'dateFrom', q1.dateFrom,
                          'dateTo', q1.dateTo,
                          'workCenterSchedules', q1.workCenterSchedules
                          )
      ) END AS "producingStepSchedules"`,
      ])
      .andWhere('is.item_finish_id = :itemId', {
        itemId,
      })
      .andWhere('sos.master_plan_id = :masterPlanId', {
        masterPlanId,
      })
      .andWhere('sos.saleOrderId = :saleOrderId', {
        saleOrderId,
      })
      .innerJoin(
        SaleOrderScheduleEntity,
        'sos',
        'sos.id = is.saleOrderScheduleId',
      )
      .innerJoin(
        (q1) => {
          q1.select([
            'ipss.id AS id',
            'ipss.itemScheduleId AS itemScheduleId',
            'ipss.status AS status',
            'ipss.producingStepId AS producingStepId',
            'ipss.quantity AS quantity',
            'ipss.planQuantity AS planQuantity',
            'ipss.actualQuantity AS actualQuantity',
            'ipss.errorQuantity AS errorQuantity',
            'ipss.overQuantity AS overQuantity',
            'ipss.stepNumber AS stepNumber',
            'ipss.dateFrom AS dateFrom',
            'ipss.dateTo AS dateTo',
            `CASE WHEN COUNT(q2) = 0 THEN '[]' ELSE json_agg(
              json_build_object('id', q2.id,
                                'workCenterId', q2.workCenterId,
                                'itemProducingStepScheduleId', q2.itemProducingStepScheduleId,
                                'quantity', q2.quantity,
                                'actualQuantity', q2.actualQuantity,
                                'errorQuantity', q2.errorQuantity,
                                'excutionDate', q2.excutionDate,
                                'workCenterDetailSchedules', q2.workCenterDetailSchedules
                                )
            ) END AS workCenterSchedules`,
          ])
            .from(ItemProducingStepScheduleEntity, 'ipss')
            .orderBy('ipss.step_number', 'ASC')
            .groupBy('ipss.id')
            .addGroupBy('ipss.itemScheduleId')
            .addGroupBy('ipss.planQuantity')
            .addGroupBy('ipss.status')
            .addGroupBy('ipss.producingStepId')
            .addGroupBy('ipss.quantity')
            .addGroupBy('ipss.actualQuantity')
            .addGroupBy('ipss.stepNumber')
            .addGroupBy('ipss.errorQuantity')
            .addGroupBy('ipss.overQuantity')
            .addGroupBy('ipss.dateFrom')
            .addGroupBy('ipss.dateTo');
          q1.leftJoin(
            (q2) => {
              q2.select([
                'wcs.id AS id',
                'wcs.workCenterId AS workCenterId',
                'wcs.itemProducingStepScheduleId AS itemProducingStepScheduleId',
                'wcs.quantity AS quantity',
                'wcs.actualQuantity AS actualQuantity',
                'wcs.errorQuantity AS errorQuantity',
                'wcs.excutionDate AS excutionDate',
                `CASE WHEN COUNT(wcds) = 0 THEN '[]' ELSE json_agg(
                  json_build_object('id', wcds.id,
                                    'workCenterShiftScheduleId', wcds.work_center_shift_schedule_id,
                                    'quantity', wcds.quantity,
                                    'actualQuantity', wcds.actual_quantity,
                                    'excutionFrom', wcds.excution_from,
                                    'excutionTo', wcds.excution_to
                                    )
                ) END AS workCenterDetailSchedules`,
              ])
                .from(WorkCenterScheduleEntity, 'wcs')
                .innerJoin(
                  WorkCenterDetailScheduleEntity,
                  'wcds',
                  'wcds.work_center_schedule_id = wcs.id',
                )
                .addGroupBy('wcs.id')
                .addGroupBy('wcs.workCenterId')
                .addGroupBy('wcs.itemProducingStepScheduleId')
                .addGroupBy('wcs.quantity')
                .addGroupBy('wcs.actualQuantity')
                .addGroupBy('wcs.errorQuantity')
                .addGroupBy('wcs.excutionDate');
              return q2;
            },
            'q2',
            'q2.itemProducingStepScheduleId = ipss.id',
          );
          return q1;
        },
        'q1',
        'q1.itemScheduleId = is.id',
      )
      .groupBy('is.id')
      .addGroupBy('is.saleOrderScheduleId')
      .addGroupBy('is.status')
      .addGroupBy('is.needToManufacture')
      .addGroupBy('is.level')
      .addGroupBy('is.itemFinishId')
      .addGroupBy('is.itemId')
      .addGroupBy('is.bomId')
      .addGroupBy('is.parentBomId')
      .addGroupBy('is.quantity')
      .addGroupBy('is.actualQuantity')
      .addGroupBy('is.errorQuantity')
      .addGroupBy('is.isOverQuantity')
      .addGroupBy('is.dateFrom')
      .addGroupBy('is.dateTo')
      .getRawMany();
  }
}
