import { WorkCenterDetailScheduleRepositoryInterface } from '@components/schedule/work-center-detail-schedule/interface/work-center-detail-schedule.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { ItemProducingStepScheduleEntity } from '@entities/schedule/sale-order-schedule/item-producing-step-schedule.entity';
import { ItemScheduleEntity } from '@entities/schedule/sale-order-schedule/item-schedule.entity';
import { SaleOrderScheduleEntity } from '@entities/schedule/sale-order-schedule/sale-order-schedule.entity';
import { WorkCenterDetailScheduleEntity } from '@entities/schedule/work-center-schedule/work-center-detail-schedule.entity';
import { WorkCenterScheduleEntity } from '@entities/schedule/work-center-schedule/work-center-schedule.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class WorkCenterDetailScheduleRepository
  extends BaseAbstractRepository<WorkCenterDetailScheduleEntity>
  implements WorkCenterDetailScheduleRepositoryInterface
{
  constructor(
    @InjectRepository(WorkCenterDetailScheduleEntity)
    private readonly workCenterDetailSchedulesRepository: Repository<WorkCenterDetailScheduleEntity>,
  ) {
    super(workCenterDetailSchedulesRepository);
  }

  createEntity(param: any): WorkCenterDetailScheduleEntity {
    const workCenterDetailSchedule = new WorkCenterDetailScheduleEntity();
    if (param.workCenterScheduleId) {
      workCenterDetailSchedule.workCenterScheduleId =
        param.workCenterScheduleId;
    }
    workCenterDetailSchedule.workCenterShiftScheduleId =
      param.workCenterShiftScheduleId;
    workCenterDetailSchedule.quantity = param.quantity ? param.quantity : 0;
    workCenterDetailSchedule.actualQuantity = 0;
    workCenterDetailSchedule.errorQuantity = 0;
    workCenterDetailSchedule.excutionFrom = param.excutionFrom;
    workCenterDetailSchedule.excutionTo = param.excutionTo;
    workCenterDetailSchedule.createdAt = new Date();
    workCenterDetailSchedule.updatedAt = new Date();
    return workCenterDetailSchedule;
  }

  updateEntity(
    param: any,
    workCenterDetailSchedule: WorkCenterDetailScheduleEntity,
  ): WorkCenterDetailScheduleEntity {
    for (const key in param) {
      if (key !== 'updatedAt') workCenterDetailSchedule[key] = param[key];
    }
    workCenterDetailSchedule.updatedAt = new Date();
    return workCenterDetailSchedule;
  }

  async findByIdsItemIdsSoId(
    soId: number,
    itemIds: number[],
    ids: number[],
  ): Promise<any> {
    return this.workCenterDetailSchedulesRepository
      .createQueryBuilder('wcds')
      .innerJoin(
        WorkCenterScheduleEntity,
        'wcs',
        'wcs.id = wcds.workCenterScheduleId',
      )
      .innerJoin(
        ItemProducingStepScheduleEntity,
        'ipss',
        'ipss.id = wcs.itemProducingStepScheduleId',
      )
      .innerJoin(ItemScheduleEntity, 'is', 'is.id = ipss.itemScheduleId')
      .innerJoin(
        SaleOrderScheduleEntity,
        'sos',
        'sos.id = is.saleOrderScheduleId',
      )
      .andWhere('sos.saleOrderId = :soId', {
        soId: soId,
      })
      .andWhere('is.itemId IN (:...itemIds)', {
        itemIds: itemIds,
      })
      .andWhere('wcds.id IN (:...ids)', {
        ids: ids,
      })
      .getRawMany();
  }

  /**
   *
   * @param masterPlanId
   * @param itemScheduleIds
   * @param ids
   * @returns
   */
  async findByItemScheduleIds(
    masterPlanId: number,
    itemScheduleIds: number[],
    ids: number[],
  ): Promise<any> {
    return this.workCenterDetailSchedulesRepository
      .createQueryBuilder('wcds')
      .innerJoin(
        WorkCenterScheduleEntity,
        'wcs',
        'wcs.id = wcds.workCenterScheduleId',
      )
      .innerJoin(
        ItemProducingStepScheduleEntity,
        'ipss',
        'ipss.id = wcs.itemProducingStepScheduleId',
      )
      .innerJoin(ItemScheduleEntity, 'is', 'is.id = ipss.itemScheduleId')
      .innerJoin(
        SaleOrderScheduleEntity,
        'sos',
        'sos.id = is.saleOrderScheduleId',
      )
      .andWhere('sos.master_plan_id = :masterPlanId', {
        masterPlanId: masterPlanId,
      })
      .andWhere('is.itemId IN (:...itemIds)', {
        itemIds: itemScheduleIds,
      })
      .andWhere('wcds.id IN (:...ids)', {
        ids: ids,
      })
      .getRawMany();
  }

  async findByIds(ids: number[]): Promise<any> {
    return this.workCenterDetailSchedulesRepository
      .createQueryBuilder('wcds')
      .select([
        'wcds.id AS "id"',
        'wcds.workCenterScheduleId AS "workCenterScheduleId"',
        'wcds.workCenterShiftScheduleId AS "workCenterShiftScheduleId"',
        'wcds.quantity AS "quantity"',
        'wcds.actualQuantity AS "actualQuantity"',
        'wcds.errorQuantity AS "errorQuantity"',
        'wcds.excutionFrom AS "excutionFrom"',
        'wcds.excutionTo AS "excutionTo"',
        'wcds.createdAt AS "createdAt"',
        'wcds.updatedAt AS "updatedAt"',
      ])
      .andWhere('wcds.id IN (:...ids)', {
        ids: ids,
      })
      .getRawMany();
  }
}
