import { WorkCenterCalendarRepositoryInterface } from '@components/work-center-calendar/interface/work-center-calendar.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { WorkCenterCalendarEntity } from '@entities/work-center-calendar/work-center-calendar.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class WorkCenterCalendarRepository
  extends BaseAbstractRepository<WorkCenterCalendarEntity>
  implements WorkCenterCalendarRepositoryInterface
{
  constructor(
    @InjectRepository(WorkCenterCalendarEntity)
    private readonly workCenterCalendarRepository: Repository<WorkCenterCalendarEntity>,
  ) {
    super(workCenterCalendarRepository);
  }

  createWorkCenterCalendar(param: any): WorkCenterCalendarEntity {
    const workCenterCalendar = new WorkCenterCalendarEntity();
    workCenterCalendar.title = param.title;
    workCenterCalendar.description = param.description;
    workCenterCalendar.from = param.from;
    workCenterCalendar.to = param.to;
    workCenterCalendar.type = param.type;
    workCenterCalendar.workCenterId = param.workCenterId;
    workCenterCalendar.createdAt = new Date();
    workCenterCalendar.updatedAt = new Date();
    return workCenterCalendar;
  }

  async isExist(param: any): Promise<any> {
    const { title, from, to, workCenterId } = param;
    const result = await this.workCenterCalendarRepository.find({
      where: {
        title: title,
        from: from,
        to: to,
        workCenterId: workCenterId,
      },
    });
    return result;
  }

  async getWorkCenterCalendars(param: any): Promise<any[]> {
    return await this.workCenterCalendarRepository
      .createQueryBuilder('wc')
      .select([
        'wc.id AS id',
        'wc.title AS title',
        'wc.description AS description',
        'wc.from AS from',
        'wc.to AS to',
        'wc.type AS type',
        'wc.work_center_id AS workCenterId',
      ])
      .andWhere('wc.from >= :pFrom::Date', {
        pFrom: param.from,
      })
      .andWhere('wc.to <= :pTo::Date', {
        pTo: param.to,
      })
      .andWhere('wc.work_center_id = :pWorkCenterId', {
        pWorkCenterId: param.workCenterId,
      })
      .getRawMany();
  }
}
