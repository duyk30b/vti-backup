import { ShiftRepositoryInterface } from '@components/factory-calendar/interface/shift.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { ShiftEntity } from '@entities/factory-calendar/shift.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class ShiftRepository
  extends BaseAbstractRepository<ShiftEntity>
  implements ShiftRepositoryInterface
{
  constructor(
    @InjectRepository(ShiftEntity)
    private readonly shiftRepository: Repository<ShiftEntity>,
  ) {
    super(shiftRepository);
  }

  createEntity(param: any): ShiftEntity {
    const entity = new ShiftEntity();
    for (const key in param) {
      entity[key] = param[key];
    }
    entity.createdAt = new Date();
    entity.updatedAt = new Date();
    return entity;
  }
}
