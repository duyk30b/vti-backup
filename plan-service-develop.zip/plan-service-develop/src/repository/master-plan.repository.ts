import { GetMasterPlanDetailRequestDto } from '@components/schedule/master-plan/dto/request/get-master-plan-detail.request.dto';
import { MasterPlanRepositoryInterface } from '@components/schedule/master-plan/interface/master-plan.repository.interface';
import { MasterPlanStatusEnum } from '@constant/common';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { ItemProducingStepScheduleEntity } from '@entities/schedule/sale-order-schedule/item-producing-step-schedule.entity';
import { ItemScheduleEntity } from '@entities/schedule/sale-order-schedule/item-schedule.entity';
import { MasterPlanEntity } from '@entities/schedule/master-plan/master-plan.entity';
import { SaleOrderScheduleEntity } from '@entities/schedule/sale-order-schedule/sale-order-schedule.entity';
import { WorkCenterScheduleEntity } from '@entities/schedule/work-center-schedule/work-center-schedule.entity';
import { WorkCenterDetailScheduleEntity } from '@entities/schedule/work-center-schedule/work-center-detail-schedule.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { EnumSort, escapeCharForSearch } from '@utils/common';
import { Repository } from 'typeorm';
import { isEmpty } from 'lodash';
import * as moment from 'moment';

@Injectable()
export class MasterPlanRepository
  extends BaseAbstractRepository<MasterPlanEntity>
  implements MasterPlanRepositoryInterface
{
  constructor(
    @InjectRepository(MasterPlanEntity)
    private readonly masterPlanRepository: Repository<MasterPlanEntity>,
  ) {
    super(masterPlanRepository);
  }

  createEntity(param: any): MasterPlanEntity {
    const masterPlanEntity = new MasterPlanEntity();
    masterPlanEntity.code = param.code;
    masterPlanEntity.name = param.name;
    masterPlanEntity.description = param.description;
    masterPlanEntity.dateFrom = param.dateFrom;
    masterPlanEntity.dateTo = param.dateTo;
    masterPlanEntity.factoryId = param.factoryId;
    masterPlanEntity.status = MasterPlanStatusEnum.CREATED;
    masterPlanEntity.createdAt = new Date();
    masterPlanEntity.updatedAt = new Date();
    masterPlanEntity.createdBy = param.userId;
    masterPlanEntity.updatedBy = param.userId;
    return masterPlanEntity;
  }

  updateEntity(param: any, masterPlan: MasterPlanEntity): MasterPlanEntity {
    for (const key in param) {
      if (
        key !== 'saleOrderSchedules' &&
        key !== 'updatedAt' &&
        key !== 'updatedBy'
      )
        masterPlan[key] = param[key];
    }
    masterPlan.updatedAt = new Date();
    masterPlan.updatedBy = param.userId;

    return masterPlan;
  }

  async getMasterPlans(params: any): Promise<any> {
    const query = this.masterPlanRepository
      .createQueryBuilder('mp')
      .select([
        'mp.id AS "id"',
        'mp.code AS "code"',
        'mp.status AS "status"',
        'mp.name AS "name"',
        'mp.description AS "description"',
        'mp.dateFrom AS "dateFrom"',
        'mp.dateTo AS "dateTo"',
        'mp.factoryId AS "factoryId"',
        'mp.createdAt AS "createdAt"',
        'mp.updatedAt AS "updatedAt"',
        `CASE WHEN COUNT(sos) = 0 THEN '[]' ELSE json_agg(
          json_build_object('id', sos.sale_order_id)
        ) END AS "saleOrderIds"`,
      ])
      .innerJoin(SaleOrderScheduleEntity, 'sos', 'sos.master_plan_id = mp.id')
      .addGroupBy('mp.id')
      .addGroupBy('mp.code')
      .addGroupBy('mp.factoryId')
      .addGroupBy('mp.status')
      .addGroupBy('mp.name')
      .addGroupBy('mp.description')
      .addGroupBy('mp.dateFrom')
      .addGroupBy('mp.dateTo')
      .addGroupBy('mp.createdAt')
      .addGroupBy('mp.updatedAt');

    if (!isEmpty(params.filter)) {
      params.filter.forEach((item) => {
        switch (item?.column) {
          case 'masterPlanIds':
            query.andWhere(`"mp"."id" IN (:...ids)`, {
              ids: item.text.split(','),
            });
            break;
          case 'code':
            query.andWhere(`lower("mp"."code") like lower(:code) escape '\\'`, {
              code: `%${escapeCharForSearch(item.text)}%`,
            });
            break;
          case 'name':
            query.andWhere(`lower("mp"."name") like lower(:name) escape '\\'`, {
              name: `%${escapeCharForSearch(item.text)}%`,
            });
            break;
          case 'soId':
            query.andWhere(`"sos"."sale_order_id" = :soId`, {
              soId: Number(item.text),
            });
            break;
          case 'soIds':
            query.andWhere(`"sos"."sale_order_id" IN (:...soIds)`, {
              soIds: item.text.split(','),
            });
            break;
          case 'planDate':
            query.andWhere(
              `"mp"."date_from" >= :dateFrom and "mp"."date_to" <= :dateTo`,
              {
                dateFrom: item.text.split('|')[0],
                dateTo: item.text.split('|')[1],
              },
            );
            break;
          case 'status':
            query.andWhere(`"mp"."status" IN(:...status)`, {
              status: item.text.split(','),
            });
            break;
          case 'createdAt':
            query.andWhere(
              `"mp"."created_at" between :createdFrom AND :createdTo`,
              {
                createdFrom: item.text[0],
                createdTo: item.text[1],
              },
            );
            break;
        }
      });
    }

    if (!isEmpty(params.sort)) {
      params.sort.forEach((item) => {
        switch (item?.column) {
          case 'id':
            query.orderBy('mp.id', item.order);
            break;
          case 'code':
            query.orderBy('mp.code', item.order);
            break;
          case 'name':
            query.orderBy('mp.name', item.order);
            break;
          case 'planDate':
            query
              .orderBy('mp.dateFrom', item.order)
              .orderBy('mp.dateTo', item.order);
            break;
          case 'status':
            query.orderBy('mp.status', item.order);
            break;
          case 'createdAt':
            query.orderBy('mp.created_at', item.order);
          default:
            break;
        }
      });
    } else {
      query.addOrderBy('mp.id', EnumSort.DESC);
    }

    if (params.keyword) {
      query.andWhere(
        `(
           LOWER("mp"."name") LIKE LOWER(:pkeyWord) escape '\\'
        OR LOWER("mp"."code") LIKE LOWER(:pkeyWord) escape '\\'
        )`,
        {
          pkeyWord: `%${escapeCharForSearch(params.keyword)}%`,
        },
      );
    }

    const result = params?.isGetAll
      ? await query.getRawMany()
      : await query.offset(params.skip).limit(params.take).getRawMany();
    const total = await query.getCount();

    return {
      result,
      total,
    };
  }

  /**
   *
   * @param request
   * @returns
   */
  async getDetailMasterPlan(
    request: GetMasterPlanDetailRequestDto,
  ): Promise<any> {
    const { masterPlanId, saleOrderId, planFrom, planTo, itemIds } = request;
    const query = this.masterPlanRepository
      .createQueryBuilder('mp')
      .select([
        'mp.id AS "id"',
        'mp.status AS "status"',
        'mp.code AS "code"',
        'mp.name AS "name"',
        'mp.factory_id AS "factoryId"',
        'mp.description AS "description"',
        'mp.dateFrom AS "dateFrom"',
        'mp.dateTo AS "dateTo"',
        'mp.createdAt AS "createdAt"',
        'mp.createdBy AS "createdBy"',
        'mp.updatedBy AS "updatedBy"',
        `CASE WHEN COUNT(qr) = 0 THEN '[]' ELSE json_agg(
        json_build_object('id', qr.id,
                          'masterPlanId', qr.masterPlanId,
                          'saleOrderId', qr.saleOrderId,
                          'dateFrom', qr.dateFrom,
                          'dateTo', qr.dateTo,
                          'itemSchedules', qr.itemSchedules
                          )
          ORDER BY qr.id
      ) END AS "saleOrderSchedules"`,
      ])
      .andWhere('mp.id = :masterPlanId', {
        masterPlanId: masterPlanId,
      })
      .addGroupBy('mp.id')
      .addGroupBy('mp.status')
      .addGroupBy('mp.code')
      .addGroupBy('mp.name')
      .addGroupBy('mp.description')
      .addGroupBy('mp.dateFrom')
      .addGroupBy('mp.dateTo')
      .leftJoin(
        (qr) => {
          qr.select([
            'sos.id AS id',
            'sos.masterPlanId AS masterPlanId',
            'sos.saleOrderId AS saleOrderId',
            'sos.dateFrom AS dateFrom',
            'sos.dateTo AS dateTo',
            `CASE WHEN COUNT(q) = 0 THEN '[]' ELSE json_agg(
            json_build_object('id', q.id,
                              'saleOrderScheduleId', q.saleOrderScheduleId,
                              'itemId', q.itemId,
                              'status', q.status,
                              'itemFinishId', q.itemFinishId,
                              'bomId', q.bomId,
                              'bomVersionId', q.bomVersionId,
                              'parentBomId', q.parentBomId,
                              'parentBomVersionId', q.parentBomVersionId,
                              'quantity', q.quantity,
                              'actualQuantity', q.actualQuantity,
                              'errorQuantity', q.errorQuantity,
                              'isOverQuantity', q.isOverQuantity,
                              'dateFrom', q.dateFrom,
                              'dateTo', q.dateTo,
                              'level', q.level,
                              'needToManufacture', q.needToManufacture,
                              'isOverQuantity', q.isOverQuantity,
                              'producingSteps', q.producingSteps
                              )
              ORDER BY q.id
          ) END AS itemSchedules`,
          ]).from(SaleOrderScheduleEntity, 'sos');
          qr.andWhere('sos.masterPlanId = :masterPlanId', {
            masterPlanId: masterPlanId,
          });
          if (saleOrderId) {
            qr.andWhere('sos.saleOrderId = :saleOrderId', {
              saleOrderId,
            });
          }
          qr.groupBy('sos.id')
            .addGroupBy('sos.masterPlanId')
            .addGroupBy('sos.saleOrderId')
            .addGroupBy('sos.dateFrom')
            .addGroupBy('sos.dateTo')
            .leftJoin(
              (q) => {
                q.select([
                  'is.id AS id',
                  'is.saleOrderScheduleId AS saleOrderScheduleId',
                  'is.itemFinishId AS itemFinishId',
                  'is.itemId AS itemId',
                  'is.status AS status',
                  'is.bomId AS bomId',
                  'is.bomVersionId AS bomVersionId',
                  'is.parentBomId AS parentBomId',
                  'is.parentBomVersionId AS parentBomVersionId',
                  'is.quantity AS quantity',
                  'is.actualQuantity AS actualQuantity',
                  'is.errorQuantity AS errorQuantity',
                  'is.isOverQuantity AS isOverQuantity',
                  'is.dateFrom AS dateFrom',
                  'is.dateTo AS dateTo',
                  'is.level AS level',
                  'is.needToManufacture AS needToManufacture',
                  `CASE WHEN COUNT(q1) = 0 THEN '[]' ELSE json_agg(
                  json_build_object('id', q1.id,
                                    'itemScheduleId', q1.itemScheduleId,
                                    'status', q1.status,
                                    'producingStepId', q1.producingStepId,
                                    'planQuantity', q1.planQuantity,
                                    'quantity', q1.quantity,
                                    'actualQuantity', q1.actualQuantity,
                                    'errorQuantity', q1.errorQuantity,
                                    'overQuantity', q1.overQuantity,
                                    'stepNumber', q1.stepNumber,
                                    'dateFrom', q1.dateFrom,
                                    'dateTo', q1.dateTo,
                                    'workCenterSchedules', q1.workCenterSchedules
                                    )
                ) END AS producingSteps`,
                ]).from(ItemScheduleEntity, 'is');
                if (itemIds) {
                  q.andWhere('is.item_finish_id IN (:...itemIds)', {
                    itemIds: itemIds.split(','),
                  });
                }
                q.groupBy('is.id')
                  .addGroupBy('is.saleOrderScheduleId')
                  .addGroupBy('is.status')
                  .addGroupBy('is.needToManufacture')
                  .addGroupBy('is.level')
                  .addGroupBy('is.itemFinishId')
                  .addGroupBy('is.itemId')
                  .addGroupBy('is.bomId')
                  .addGroupBy('is.parentBomId')
                  .addGroupBy('is.quantity')
                  .addGroupBy('is.actualQuantity')
                  .addGroupBy('is.errorQuantity')
                  .addGroupBy('is.isOverQuantity')
                  .addGroupBy('is.dateFrom')
                  .addGroupBy('is.dateTo');
                q.leftJoin(
                  (q1) => {
                    q1.select([
                      'ipss.id AS id',
                      'ipss.itemScheduleId AS itemScheduleId',
                      'ipss.status AS status',
                      'ipss.producingStepId AS producingStepId',
                      'ipss.quantity AS quantity',
                      'ipss.planQuantity AS planQuantity',
                      'ipss.actualQuantity AS actualQuantity',
                      'ipss.errorQuantity AS errorQuantity',
                      'ipss.overQuantity AS overQuantity',
                      'ipss.stepNumber AS stepNumber',
                      'ipss.dateFrom AS dateFrom',
                      'ipss.dateTo AS dateTo',
                      `CASE WHEN COUNT(q2) = 0 THEN '[]' ELSE json_agg(
                        json_build_object('id', q2.id,
                                          'workCenterId', q2.workCenterId,
                                          'itemProducingStepScheduleId', q2.itemProducingStepScheduleId,
                                          'quantity', q2.quantity,
                                          'actualQuantity', q2.actualQuantity,
                                          'errorQuantity', q2.errorQuantity,
                                          'excutionDate', q2.excutionDate,
                                          'workCenterDetailSchedules', q2.workCenterDetailSchedules
                                          )
                      ) END AS workCenterSchedules`,
                    ])
                      .from(ItemProducingStepScheduleEntity, 'ipss')
                      .orderBy('ipss.step_number', 'ASC')
                      .groupBy('ipss.id')
                      .addGroupBy('ipss.itemScheduleId')
                      .addGroupBy('ipss.planQuantity')
                      .addGroupBy('ipss.status')
                      .addGroupBy('ipss.producingStepId')
                      .addGroupBy('ipss.quantity')
                      .addGroupBy('ipss.actualQuantity')
                      .addGroupBy('ipss.stepNumber')
                      .addGroupBy('ipss.errorQuantity')
                      .addGroupBy('ipss.overQuantity')
                      .addGroupBy('ipss.dateFrom')
                      .addGroupBy('ipss.dateTo');
                    q1.leftJoin(
                      (q2) => {
                        q2.select([
                          'wcs.id AS id',
                          'wcs.workCenterId AS workCenterId',
                          'wcs.itemProducingStepScheduleId AS itemProducingStepScheduleId',
                          'wcs.quantity AS quantity',
                          'wcs.actualQuantity AS actualQuantity',
                          'wcs.errorQuantity AS errorQuantity',
                          'wcs.excutionDate AS excutionDate',
                          `CASE WHEN COUNT(wcds) = 0 THEN '[]' ELSE json_agg(
                            json_build_object('id', wcds.id,
                                              'workCenterShiftScheduleId', wcds.work_center_shift_schedule_id,
                                              'quantity', wcds.quantity,
                                              'actualQuantity', wcds.actual_quantity,
                                              'excutionFrom', wcds.excution_from,
                                              'excutionTo', wcds.excution_to
                                              )
                          ) END AS workCenterDetailSchedules`,
                        ])
                          .from(WorkCenterScheduleEntity, 'wcs')
                          .innerJoin(
                            WorkCenterDetailScheduleEntity,
                            'wcds',
                            'wcds.work_center_schedule_id = wcs.id',
                          )
                          .addGroupBy('wcs.id')
                          .addGroupBy('wcs.workCenterId')
                          .addGroupBy('wcs.itemProducingStepScheduleId')
                          .addGroupBy('wcs.quantity')
                          .addGroupBy('wcs.actualQuantity')
                          .addGroupBy('wcs.errorQuantity')
                          .addGroupBy('wcs.excutionDate');
                        if (planFrom && planTo) {
                          q2.andWhere(`wcs.excutionDate >= :planFrom`, {
                            planFrom: moment(planFrom).format('YYYY-MM-DD'),
                          }).andWhere(`wcs.excutionDate <= :planTo`, {
                            planTo: moment(planTo).format('YYYY-MM-DD'),
                          });
                        }
                        return q2;
                      },
                      'q2',
                      'q2.itemProducingStepScheduleId = ipss.id',
                    );
                    return q1;
                  },
                  'q1',
                  'q1.itemScheduleId = is.id',
                );

                return q;
              },
              'q',
              'q.saleOrderScheduleId = sos.id',
            );
          return qr;
        },
        'qr',
        'qr.masterPlanId = mp.id',
      );

    return await query.getRawOne();
  }
}
