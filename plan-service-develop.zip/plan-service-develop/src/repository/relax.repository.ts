import { RelaxRepositoryInterface } from '@components/factory-calendar/interface/relax.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { RelaxEntity } from '@entities/factory-calendar/relax.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class RelaxRepository
  extends BaseAbstractRepository<RelaxEntity>
  implements RelaxRepositoryInterface
{
  constructor(
    @InjectRepository(RelaxEntity)
    private readonly relaxRepository: Repository<RelaxEntity>,
  ) {
    super(relaxRepository);
  }

  createEntity(param: any): RelaxEntity {
    const entity = new RelaxEntity();
    for (const key in param) {
      entity[key] = param[key];
    }
    entity.createdAt = new Date();
    entity.updatedAt = new Date();
    return entity;
  }
}
