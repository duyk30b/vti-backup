import { SaleOrderScheduleRepositoryInterface } from '@components/schedule/sale-order-schedule/interface/sale-order-schedule.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { ItemProducingStepScheduleEntity } from '@entities/schedule/sale-order-schedule/item-producing-step-schedule.entity';
import { ItemScheduleEntity } from '@entities/schedule/sale-order-schedule/item-schedule.entity';
import { MasterPlanEntity } from '@entities/schedule/master-plan/master-plan.entity';
import { SaleOrderScheduleEntity } from '@entities/schedule/sale-order-schedule/sale-order-schedule.entity';
import { WorkCenterDetailScheduleEntity } from '@entities/schedule/work-center-schedule/work-center-detail-schedule.entity';
import { WorkCenterScheduleEntity } from '@entities/schedule/work-center-schedule/work-center-schedule.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { MasterPlanStatusEnum } from '@constant/common';
import { SaleOrderProgressReportRequestDto } from '@components/schedule/sale-order-schedule/dto/request/sale-order-progress-report.request.dto';
import { isEmpty } from 'lodash';

@Injectable()
export class SaleOrderScheduleRepository
  extends BaseAbstractRepository<SaleOrderScheduleEntity>
  implements SaleOrderScheduleRepositoryInterface
{
  constructor(
    @InjectRepository(SaleOrderScheduleEntity)
    private readonly saleOrderSchedulesRepository: Repository<SaleOrderScheduleEntity>,
  ) {
    super(saleOrderSchedulesRepository);
  }

  createEntity(
    soId: any,
    itemSchedules: any[],
    dateFrom: any,
    dateTo: any,
  ): SaleOrderScheduleEntity {
    const saleOrderSchedule = new SaleOrderScheduleEntity();
    saleOrderSchedule.saleOrderId = soId;
    saleOrderSchedule.dateFrom = dateFrom;
    saleOrderSchedule.dateTo = dateTo;
    saleOrderSchedule.createdAt = new Date();
    saleOrderSchedule.updatedAt = new Date();
    saleOrderSchedule.itemSchedules = itemSchedules;

    return saleOrderSchedule;
  }

  updateEntity(
    param: any,
    saleOrderSchedule: SaleOrderScheduleEntity,
  ): SaleOrderScheduleEntity {
    for (const key in param) {
      if (key !== 'itemSchedules' && key !== 'updatedAt')
        saleOrderSchedule[key] = param[key];
    }
    saleOrderSchedule.updatedAt = new Date();

    return saleOrderSchedule;
  }

  async getPlanScheduleBySoIdAndItemIds(
    soId: number,
    itemIds: any[],
    isOverSchedule: boolean,
  ): Promise<any> {
    const query = this.saleOrderSchedulesRepository
      .createQueryBuilder('sos')
      .select([
        'sos.id AS "id"',
        'mp.factory_id AS "factoryId"',
        'sos.saleOrderId AS "saleOrderId"',
        'sos.dateFrom AS "dateFrom"',
        'sos.dateTo AS "dateTo"',
        'sos.createdAt AS "createdAt"',
        'sos.updatedAt AS "updatedAt"',
        `CASE WHEN COUNT(q) = 0 THEN '[]' ELSE json_agg(
          json_build_object('id', q.id,
                            'saleOrderScheduleId', q.saleOrderScheduleId,
                            'itemId', q.itemId,
                            'itemFinishId', q.itemFinishId,
                            'bomId', q.bomId,
                            'parentBomId', q.parentBomId,
                            'quantity', q.quantity,
                            'actualQuantity', q.actualQuantity,
                            'errorQuantity', q.errorQuantity,
                            'isOverQuantity', q.isOverQuantity,
                            'dateFrom', q.dateFrom,
                            'dateTo', q.dateTo,
                            'level', q.level,
                            'createdAt', q.createdAt,
                            'updatedAt', q.updatedAt,
                            'itemProducingStepSchedules', q.itemProducingStepSchedules
                            )
            ORDER BY q.id
        ) END AS "itemSchedules"`,
      ])
      .innerJoin(MasterPlanEntity, 'mp', 'mp.id = sos.master_plan_id')
      .where('sos.saleOrderId = :saleOrderId', {
        saleOrderId: soId,
      });
    if (isOverSchedule) query.andWhere('q.overQuantity > 0');
    query
      .groupBy('sos.id')
      .addGroupBy('mp.factory_id')
      .addGroupBy('sos.saleOrderId')
      .addGroupBy('sos.dateFrom')
      .addGroupBy('sos.dateTo')
      .addGroupBy('sos.createdAt')
      .addGroupBy('sos.updatedAt')
      .leftJoin(
        (q) => {
          q.select([
            'is.id AS id',
            'is.saleOrderScheduleId AS saleOrderScheduleId',
            'is.itemFinishId AS itemFinishId',
            'is.itemId AS itemId',
            'is.bomId AS bomId',
            'is.parentBomId AS parentBomId',
            'is.quantity AS quantity',
            'is.actualQuantity AS actualQuantity',
            'is.errorQuantity AS errorQuantity',
            'is.isOverQuantity AS isOverQuantity',
            'is.dateFrom AS dateFrom',
            'is.dateTo AS dateTo',
            'is.level AS level',
            'is.createdAt AS createdAt',
            'is.updatedAt AS updatedAt',
            `CASE WHEN COUNT(q1) = 0 THEN '[]' ELSE json_agg(
                json_build_object('id', q1.id,
                                  'itemScheduleId', q1.itemScheduleId,
                                  'producingStepId', q1.producingStepId,
                                  'quantity', q1.quantity,
                                  'actualQuantity', q1.actualQuantity,
                                  'errorQuantity', q1.errorQuantity,
                                  'stepNumber', q1.stepNumber,
                                  'dateFrom', q1.dateFrom,
                                  'dateTo', q1.dateTo,
                                  'createdAt', q1.createdAt,
                                  'updatedAt', q1.updatedAt,
                                  'workCenterSchedules', q1.workCenterSchedules
                                  )
                  ORDER BY q1.id
              ) END AS itemProducingStepSchedules`,
          ]).from(ItemScheduleEntity, 'is');
          if (itemIds.length > 0)
            q.where('is.itemId IN (:...itemIds)', {
              itemIds: itemIds,
            });

          if (isOverSchedule) q.andWhere('is.overQuantity > 0');
          q.groupBy('is.id')
            .addGroupBy('is.saleOrderScheduleId')
            .addGroupBy('is.level')
            .addGroupBy('is.itemFinishId')
            .addGroupBy('is.itemId')
            .addGroupBy('is.bomId')
            .addGroupBy('is.parentBomId')
            .addGroupBy('is.quantity')
            .addGroupBy('is.actualQuantity')
            .addGroupBy('is.errorQuantity')
            .addGroupBy('is.isOverQuantity')
            .addGroupBy('is.dateFrom')
            .addGroupBy('is.dateTo')
            .addGroupBy('is.createdAt')
            .addGroupBy('is.updatedAt')
            .leftJoin(
              (q1) =>
                q1
                  .select([
                    'ipss.id AS id',
                    'ipss.itemScheduleId AS itemScheduleId',
                    'ipss.producingStepId AS producingStepId',
                    'ipss.quantity AS quantity',
                    'ipss.actualQuantity AS actualQuantity',
                    'ipss.errorQuantity AS errorQuantity',
                    'ipss.stepNumber AS stepNumber',
                    'ipss.dateFrom AS dateFrom',
                    'ipss.dateTo AS dateTo',
                    'ipss.createdAt AS createdAt',
                    'ipss.updatedAt AS updatedAt',
                    `CASE WHEN COUNT(q2) = 0 THEN '[]' ELSE json_agg(
                      json_build_object('id', q2.id,
                                        'workCenterId', q2.workCenterId,
                                        'itemProducingStepScheduleId', q2.itemProducingStepScheduleId,
                                        'quantity', q2.quantity,
                                        'actualQuantity', q2.actualQuantity,
                                        'errorQuantity', q2.errorQuantity,
                                        'excutionDate', q2.excutionDate,
                                        'createdAt', q2.createdAt,
                                        'updatedAt', q2.updatedAt,
                                        'workCenterDetailSchedules', q2.workCenterDetailSchedules
                                        )
                        ORDER BY q2.id
                    ) END AS workCenterSchedules`,
                  ])
                  .from(ItemProducingStepScheduleEntity, 'ipss')
                  .groupBy('ipss.id')
                  .addGroupBy('ipss.itemScheduleId')
                  .addGroupBy('ipss.producingStepId')
                  .addGroupBy('ipss.quantity')
                  .addGroupBy('ipss.actualQuantity')
                  .addGroupBy('ipss.stepNumber')
                  .addGroupBy('ipss.errorQuantity')
                  .addGroupBy('ipss.dateFrom')
                  .addGroupBy('ipss.dateTo')
                  .addGroupBy('ipss.createdAt')
                  .addGroupBy('ipss.updatedAt')
                  .leftJoin(
                    (q2) =>
                      q2
                        .select([
                          'wcs.id AS id',
                          'wcs.workCenterId AS workCenterId',
                          'wcs.itemProducingStepScheduleId AS itemProducingStepScheduleId',
                          'wcs.quantity AS quantity',
                          'wcs.actualQuantity AS actualQuantity',
                          'wcs.errorQuantity AS errorQuantity',
                          'wcs.excutionDate AS excutionDate',
                          'wcs.createdAt AS createdAt',
                          'wcs.updatedAt AS updatedAt',
                          `CASE WHEN COUNT(q3) = 0 THEN '[]' ELSE json_agg(
                            json_build_object('id', q3.id,
                                              'workCenterScheduleId', q3.workCenterScheduleId,
                                              'workCenterShiftScheduleId', q3.workCenterShiftScheduleId,
                                              'quantity', q3.quantity,
                                              'actualQuantity', q3.actualQuantity,
                                              'errorQuantity', q3.errorQuantity,
                                              'excutionFrom', q3.excutionFrom,
                                              'excutionTo', q3.excutionTo,
                                              'createdAt', q3.createdAt,
                                              'updatedAt', q3.updatedAt
                                              )
                              ORDER BY q3.id
                          ) END AS workCenterDetailSchedules`,
                        ])
                        .from(WorkCenterScheduleEntity, 'wcs')
                        .groupBy('wcs.id')
                        .addGroupBy('wcs.workCenterId')
                        .addGroupBy('wcs.itemProducingStepScheduleId')
                        .addGroupBy('wcs.quantity')
                        .addGroupBy('wcs.actualQuantity')
                        .addGroupBy('wcs.errorQuantity')
                        .addGroupBy('wcs.excutionDate')
                        .addGroupBy('wcs.createdAt')
                        .addGroupBy('wcs.updatedAt')
                        .leftJoin(
                          (q3) =>
                            q3
                              .select([
                                'wcds.id AS id',
                                'wcds.workCenterScheduleId AS workCenterScheduleId',
                                'wcds.workCenterShiftScheduleId AS workCenterShiftScheduleId',
                                'wcds.quantity AS quantity',
                                'wcds.actualQuantity AS actualQuantity',
                                'wcds.errorQuantity AS errorQuantity',
                                'wcds.excutionFrom AS excutionFrom',
                                'wcds.excutionTo AS excutionTo',
                                'wcds.createdAt AS createdAt',
                                'wcds.updatedAt AS updatedAt',
                              ])
                              .from(WorkCenterDetailScheduleEntity, 'wcds'),
                          'q3',
                          'q3.workCenterScheduleId = wcs.id',
                        ),
                    'q2',
                    'q2.itemProducingStepScheduleId = ipss.id',
                  ),
              'q1',
              'q1.itemScheduleId = is.id',
            );
          return q;
        },
        'q',
        'q.saleOrderScheduleId = sos.id',
      );
    return query.getRawOne();
  }

  /**
   *
   * @param saleOrderIds
   * @param masterPlanId
   * @returns
   */
  async checkExistSaleOrderIdActive(
    saleOrderIds: string[],
    masterPlanId?: number,
  ): Promise<boolean> {
    const query = this.saleOrderSchedulesRepository
      .createQueryBuilder('sos')
      .innerJoin(MasterPlanEntity, 'mp', 'mp.id = sos.master_plan_id')
      .where('mp.status <> :statusReject', {
        statusReject: MasterPlanStatusEnum.REJECT,
      })
      .andWhere('sos.sale_order_id IN (:...saleOrderIds)', { saleOrderIds });
    if (masterPlanId) {
      query.andWhere('sos.master_plan_id <> :masterPlanId', { masterPlanId });
    }
    const result = await query.getCount();
    return result > 0;
  }

  public async getSaleOrderProgressReport(
    request: SaleOrderProgressReportRequestDto,
  ): Promise<any> {
    const { id, itemIds, producingStepIds, workCenterIds, dateFrom, dateTo } =
      request;

    return await this.saleOrderSchedulesRepository
      .createQueryBuilder('sos')
      .select([
        `its.item_id as "itemId"`,
        `JSON_AGG(JSONB_BUILD_OBJECT('executionDate', its.execution_date, 'quantity', its.quantity, 'actualQuantity', its.actual_quantity, 'producingSteps', its.producing_steps) ORDER BY its.execution_date ASC) as calendar`,
      ])
      .innerJoin(
        (qb) => {
          qb.select([
            `its.item_id as item_id`,
            `its.sale_order_schedule_id as sale_order_schedule_id`,
            `ipss.execution_date as execution_date`,
            `SUM(ipss.quantity) as quantity`,
            `SUM(ipss.actual_quantity) as actual_quantity`,
            `JSON_AGG(JSONB_BUILD_OBJECT('id', ipss.producing_step_id, 'quantity', ipss.quantity, 'actualQuantity', ipss.actual_quantity, 'workCenters', ipss.work_centers)) as producing_steps`,
          ])
            .from(ItemScheduleEntity, 'its')
            .innerJoin(
              (qb1) => {
                qb1
                  .select([
                    `ipss.producing_step_id as producing_step_id`,
                    `ipss.item_schedule_id as item_schedule_id`,
                    `wcs.execution_date as execution_date`,
                    `SUM(wcs.quantity) as quantity`,
                    `SUM(wcs.actual_quantity) as actual_quantity`,
                    `JSON_AGG(JSONB_BUILD_OBJECT('id', wcs.work_center_id, 'quantity', wcs.quantity, 'actualQuantity', wcs.actual_quantity)) as work_centers`,
                  ])
                  .from(ItemProducingStepScheduleEntity, 'ipss')
                  .innerJoin(
                    (qb2) => {
                      qb2
                        .select([
                          `wcs.item_producing_step_schedule_id as item_producing_step_schedule_id`,
                          `wcs.excution_date as execution_date`,
                          `wcs.work_center_id as work_center_id`,
                          `wcs.quantity as quantity`,
                          `wcs.actual_quantity as actual_quantity`,
                        ])
                        .from(WorkCenterScheduleEntity, 'wcs');
                      if (workCenterIds && !isEmpty(workCenterIds)) {
                        qb2.andWhere(
                          'wcs.work_center_id IN(:...workCenterIds)',
                          {
                            workCenterIds: workCenterIds,
                          },
                        );
                      }

                      if (dateFrom) {
                        qb2.andWhere('wcs.excution_date >= :dateFrom', {
                          dateFrom: dateFrom,
                        });
                      }
                      if (dateTo) {
                        qb2.andWhere('wcs.excution_date <= :dateTo', {
                          dateTo: dateTo,
                        });
                      }
                      return qb2;
                    },
                    'wcs',
                    'wcs.item_producing_step_schedule_id = ipss.id',
                  )
                  .addGroupBy('ipss.producing_step_id')
                  .addGroupBy('ipss.item_schedule_id')
                  .addGroupBy('wcs.execution_date');
                if (producingStepIds && !isEmpty(producingStepIds)) {
                  qb1.andWhere(
                    'ipss.producing_step_id IN(:...producingStepIds)',
                    {
                      producingStepIds: producingStepIds,
                    },
                  );
                }

                return qb1;
              },
              'ipss',
              'ipss.item_schedule_id = its.id',
            )
            .addGroupBy('ipss.execution_date')
            .addGroupBy('its.item_id')
            .addGroupBy('its.sale_order_schedule_id');
          if (itemIds && !isEmpty(itemIds)) {
            qb.andWhere('its.item_id IN(:...itemIds)', {
              itemIds: itemIds,
            });
          }
          return qb;
        },
        'its',
        'its.sale_order_schedule_id = sos.id',
      )
      .addGroupBy('its.item_id')
      .where('sos.sale_order_id = :id', {
        id: id,
      })
      .getRawMany();
  }
}
