import { FactoryCalendarShiftRepositoryInterface } from '@components/factory-calendar/interface/factory-calendar-shift.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { FactoryCalendarShiftEntity } from '@entities/factory-calendar/factory-calendar-shift.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class FactoryCalendarShiftRepository
  extends BaseAbstractRepository<FactoryCalendarShiftEntity>
  implements FactoryCalendarShiftRepositoryInterface
{
  constructor(
    @InjectRepository(FactoryCalendarShiftEntity)
    private readonly factoryCalendarShiftRepository: Repository<FactoryCalendarShiftEntity>,
  ) {
    super(factoryCalendarShiftRepository);
  }

  createEntity(param: any): FactoryCalendarShiftEntity {
    const entity = new FactoryCalendarShiftEntity();
    for (const key in param) {
      entity[key] = param[key];
    }
    return entity;
  }
}
