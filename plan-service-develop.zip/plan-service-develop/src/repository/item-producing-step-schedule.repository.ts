import { ItemProducingStepScheduleRepositoryInterface } from '@components/schedule/item-producing-step-schedule/interface/item-producing-step-schedule.repository.interface';
import { ItemProducingStepStatusEnum } from '@constant/common';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { ItemProducingStepScheduleEntity } from '@entities/schedule/sale-order-schedule/item-producing-step-schedule.entity';
import { ItemScheduleEntity } from '@entities/schedule/sale-order-schedule/item-schedule.entity';
import { MasterPlanEntity } from '@entities/schedule/master-plan/master-plan.entity';
import { SaleOrderScheduleEntity } from '@entities/schedule/sale-order-schedule/sale-order-schedule.entity';
import { WorkCenterDetailScheduleEntity } from '@entities/schedule/work-center-schedule/work-center-detail-schedule.entity';
import { WorkCenterScheduleEntity } from '@entities/schedule/work-center-schedule/work-center-schedule.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { isEmpty } from 'lodash';
import { MaterialProducingStepScheduleEntity } from '../entities/schedule/sale-order-schedule/material-producing-step-schedule.entity';
import { mul } from '@utils/common';

@Injectable()
export class ItemProducingStepScheduleRepository
  extends BaseAbstractRepository<ItemProducingStepScheduleEntity>
  implements ItemProducingStepScheduleRepositoryInterface
{
  constructor(
    @InjectRepository(ItemProducingStepScheduleEntity)
    private readonly itemProducingStepScheduleRepository: Repository<ItemProducingStepScheduleEntity>,
  ) {
    super(itemProducingStepScheduleRepository);
  }

  createEntity(
    producingStepId: number,
    planQuantity: number,
    quantity: number,
    stepNumber: number,
    dateFrom,
    dateTo,
    materials?: any[],
  ): ItemProducingStepScheduleEntity {
    const itemProStepSchedule = new ItemProducingStepScheduleEntity();
    itemProStepSchedule.producingStepId = producingStepId;
    itemProStepSchedule.planQuantity = planQuantity;
    itemProStepSchedule.quantity = quantity;
    itemProStepSchedule.actualQuantity = 0;
    itemProStepSchedule.errorQuantity = 0;
    itemProStepSchedule.overQuantity = 0;
    itemProStepSchedule.stepNumber = stepNumber;
    itemProStepSchedule.status = ItemProducingStepStatusEnum.CREATED;
    itemProStepSchedule.dateFrom = dateFrom;
    itemProStepSchedule.dateTo = dateTo;
    itemProStepSchedule.createdAt = new Date();
    itemProStepSchedule.updatedAt = new Date();

    if (materials && !isEmpty(materials)) {
      itemProStepSchedule.materialProducingStepSchedules = materials.map(
        (material) => {
          const materialEntity = new MaterialProducingStepScheduleEntity();
          materialEntity.itemId = material.itemId;
          materialEntity.quantity = mul(material.quantity, planQuantity);

          return materialEntity;
        },
      );
    }

    return itemProStepSchedule;
  }

  updateEntity(
    param: any,
    itemProStepSchedule: ItemProducingStepScheduleEntity,
  ): ItemProducingStepScheduleEntity {
    for (const key in param) {
      if (key !== 'workCenterSchedules' && key !== 'updatedAt')
        itemProStepSchedule[key] = param[key];
    }
    itemProStepSchedule.updatedAt = new Date();
    return itemProStepSchedule;
  }

  async sumOverQuantityByMasterPlanId(masterPlanId: number): Promise<any> {
    return this.itemProducingStepScheduleRepository
      .createQueryBuilder('ipss')
      .select(['SUM(ipss.overQuantity) AS "totalOverQuantity"'])
      .innerJoin(ItemScheduleEntity, 'is', 'is.id = ipss.itemScheduleId')
      .innerJoin(
        SaleOrderScheduleEntity,
        'sos',
        'sos.id = is.saleOrderScheduleId',
      )
      .andWhere('sos.master_plan_id = :masterPlanId', {
        masterPlanId: masterPlanId,
      })
      .getRawOne();
  }

  async findByIds(ids: number[]): Promise<ItemProducingStepScheduleEntity[]> {
    return this.itemProducingStepScheduleRepository
      .createQueryBuilder('ipss')
      .select([
        'ipss.id AS "id"',
        'ipss.itemScheduleId AS "itemScheduleId"',
        'ipss.producingStepId AS "producingStepId"',
        'ipss.quantity AS "quantity"',
        'ipss.actualQuantity AS "actualQuantity"',
        'ipss.errorQuantity AS "errorQuantity"',
        'ipss.overQuantity AS "overQuantity"',
        'ipss.stepNumber AS "stepNumber"',
        'ipss.dateFrom AS "dateFrom"',
        'ipss.dateTo AS "dateTo"',
        'ipss.createdAt AS "createdAt"',
        'ipss.updatedAt AS "updatedAt"',
      ])
      .andWhere('ipss.id IN (:...ids)', {
        ids: ids,
      })
      .getRawMany();
  }

  async findByWorkCenterDetailScheduleIds(
    workCenterDetailScheduleIds: number[],
  ): Promise<any> {
    return this.itemProducingStepScheduleRepository
      .createQueryBuilder('ipss')
      .select([
        'ipss.id AS "id"',
        'ipss.quantity AS "quantity"',
        'ipss.overQuantity AS "overQuantity"',
        'wcds.id AS "workCenterDetailScheduleId"',
      ])
      .innerJoin(
        WorkCenterScheduleEntity,
        'wcs',
        'wcs.itemProducingStepScheduleId = ipss.id',
      )
      .innerJoin(
        WorkCenterDetailScheduleEntity,
        'wcds',
        'wcds.workCenterScheduleId = wcs.id',
      )
      .andWhere('wcds.id IN (:...workCenterDetailScheduleIds)', {
        workCenterDetailScheduleIds: workCenterDetailScheduleIds,
      })
      .getRawMany();
  }
  async getItemByIds(ids: number[]): Promise<any> {
    const query = this.itemProducingStepScheduleRepository
      .createQueryBuilder('ipss')
      .select([
        'ipss.id AS id',
        `"is".sale_order_id AS "saleOrderId"`,
        `"is".factory_id AS "factoryId"`,
        `"is".mp_status AS "masterPlanStatus"`,
        `"is".item_id AS "itemId"`,
        'ipss.itemScheduleId AS "itemScheduleId"',
        'ipss.producingStepId AS "producingStepId"',
        'ipss.quantity AS "quantity"',
        'ipss.actualQuantity AS "actualQuantity"',
        'ipss.overQuantity AS "overQuantity"',
        'ipss.errorQuantity AS "errorQuantity"',
        'ipss.stepNumber AS "stepNumber"',
        'ipss.dateFrom AS "dateFrom"',
        'ipss.dateTo AS "dateTo"',
        'ipss.createdAt AS "createdAt"',
        'ipss.updatedAt AS "updatedAt"',
        `CASE WHEN COUNT(q2) = 0 THEN '[]' ELSE json_agg(
                  json_build_object('id', q2.id,
                                    'workCenterId', q2."workCenterId",
                                    'itemProducingStepScheduleId', q2."itemProducingStepScheduleId",
                                    'quantity', q2."quantity",
                                    'actualQuantity', q2."actualQuantity",
                                    'errorQuantity', q2."errorQuantity",
                                    'excutionDate', q2."excutionDate",
                                    'createdAt', q2."createdAt",
                                    'updatedAt', q2."updatedAt",
                                    'workCenterDetailSchedules', q2."workCenterDetailSchedules"
                                    )
                    ORDER BY q2.id
                ) END AS "workCenterSchedules"`,
      ])
      .where('ipss.id IN (:...ids)', { ids })
      .innerJoin(
        (itemSchedule) =>
          itemSchedule
            .select([
              'sos.sale_order_id AS sale_order_id',
              'sos.master_plan_id AS master_plan_id',
              'mp.factory_id AS factory_id',
              'mp.status AS mp_status',
              '"is"."id" AS "id"',
              '"is".item_id AS item_id',
            ])
            .from(ItemScheduleEntity, 'is')
            .innerJoin(
              SaleOrderScheduleEntity,
              'sos',
              'sos.id = is.saleOrderScheduleId',
            )
            .innerJoin(MasterPlanEntity, 'mp', 'mp.id = sos.master_plan_id'),
        'is',
        '"is"."id" = ipss.itemScheduleId',
      )
      .leftJoin(
        (q2) =>
          q2
            .select([
              'wcs.id AS id',
              'wcs.workCenterId AS "workCenterId"',
              'wcs.itemProducingStepScheduleId AS "itemProducingStepScheduleId"',
              'wcs.quantity AS "quantity"',
              'wcs.actualQuantity AS "actualQuantity"',
              'wcs.errorQuantity AS "errorQuantity"',
              'wcs.excutionDate AS "excutionDate"',
              'wcs.createdAt AS "createdAt"',
              'wcs.updatedAt AS "updatedAt"',
              `CASE WHEN COUNT(q3) = 0 THEN '[]' ELSE json_agg(
                        json_build_object('id', q3.id,
                                          'workCenterScheduleId', q3."workCenterScheduleId",
                                          'workCenterShiftScheduleId', q3."workCenterShiftScheduleId",
                                          'quantity', q3."quantity",
                                          'actualQuantity', q3."actualQuantity",
                                          'errorQuantity', q3."errorQuantity",
                                          'excutionFrom', q3."excutionFrom",
                                          'excutionTo', q3."excutionTo",
                                          'createdAt', q3."createdAt",
                                          'updatedAt', q3."updatedAt"
                                          )
                          ORDER BY q3.id
                      ) END AS "workCenterDetailSchedules"`,
            ])
            .from(WorkCenterScheduleEntity, 'wcs')
            .groupBy('wcs.id')
            .addGroupBy('wcs.workCenterId')
            .addGroupBy('wcs.itemProducingStepScheduleId')
            .addGroupBy('wcs.quantity')
            .addGroupBy('wcs.actualQuantity')
            .addGroupBy('wcs.errorQuantity')
            .addGroupBy('wcs.excutionDate')
            .addGroupBy('wcs.createdAt')
            .addGroupBy('wcs.updatedAt')
            .orderBy('wcs.excutionDate', 'ASC')
            .leftJoin(
              (q3) =>
                q3
                  .select([
                    'wcds.id AS id',
                    'wcds.workCenterScheduleId AS "workCenterScheduleId"',
                    'wcds.workCenterShiftScheduleId AS "workCenterShiftScheduleId"',
                    'wcds.quantity AS "quantity"',
                    'wcds.actualQuantity AS "actualQuantity"',
                    'wcds.errorQuantity AS "errorQuantity"',
                    'wcds.excutionFrom AS "excutionFrom"',
                    'wcds.excutionTo AS "excutionTo"',
                    'wcds.createdAt AS "createdAt"',
                    'wcds.updatedAt AS "updatedAt"',
                  ])
                  .from(WorkCenterDetailScheduleEntity, 'wcds'),
              'q3',
              'q3."workCenterScheduleId" = wcs.id',
            ),
        'q2',
        'q2."itemProducingStepScheduleId" = ipss.id',
      )
      .groupBy('ipss.id')
      .addGroupBy('"is".factory_id')
      .addGroupBy('"is".sale_order_id')
      .addGroupBy('"is".mp_status')
      .addGroupBy('"is".item_id')
      .addGroupBy('ipss.itemScheduleId')
      .addGroupBy('ipss.producingStepId')
      .addGroupBy('ipss.quantity')
      .addGroupBy('ipss.actualQuantity')
      .addGroupBy('ipss.stepNumber')
      .addGroupBy('ipss.errorQuantity')
      .addGroupBy('ipss.overQuantity')
      .addGroupBy('ipss.dateFrom')
      .addGroupBy('ipss.dateTo')
      .addGroupBy('ipss.createdAt')
      .addGroupBy('ipss.updatedAt');
    return query.getRawMany();
  }
}
