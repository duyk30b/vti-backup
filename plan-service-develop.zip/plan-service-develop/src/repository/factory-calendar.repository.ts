import { CreateListFactoryCalendarRequestDto } from '@components/factory-calendar/dto/request/create-list-factory-calendar.request.dto';
import { SearchFactoryCalendarRequestDto } from '@components/factory-calendar/dto/request/search-factory-calendar.request.dto';
import { FactoryCalendarRepositoryInterface } from '@components/factory-calendar/interface/factory-calendar.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { FactoryCalendarShiftEntity } from '@entities/factory-calendar/factory-calendar-shift.entity';
import { FactoryCalendarEntity } from '@entities/factory-calendar/factory-calendar.entity';
import { FactoryWorkDayEntity } from '@entities/factory-calendar/factory-work-day.entity';
import { RelaxEntity } from '@entities/factory-calendar/relax.entity';
import { ShiftEntity } from '@entities/factory-calendar/shift.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Brackets, Repository } from 'typeorm';

@Injectable()
export class FactoryCalendarRepository
  extends BaseAbstractRepository<FactoryCalendarEntity>
  implements FactoryCalendarRepositoryInterface
{
  constructor(
    @InjectRepository(FactoryCalendarEntity)
    private readonly factoryCalendarRepository: Repository<FactoryCalendarEntity>,
  ) {
    super(factoryCalendarRepository);
  }

  createEntity(param: any): FactoryCalendarEntity {
    const factoryCalendar = new FactoryCalendarEntity();
    factoryCalendar.title = param.title;
    factoryCalendar.description = param.description;
    factoryCalendar.from = param.from;
    factoryCalendar.to = param.to;
    factoryCalendar.type = param.type;
    factoryCalendar.factoryId = param.factoryId;
    factoryCalendar.createdAt = new Date();
    factoryCalendar.updatedAt = new Date();
    return factoryCalendar;
  }

  updateEntity(
    param: any,
    factoryCalendar: FactoryCalendarEntity,
  ): FactoryCalendarEntity {
    for (const key in param) {
      if (key !== 'updatedAt') factoryCalendar[key] = param[key];
    }
    factoryCalendar.updatedAt = new Date();

    return factoryCalendar;
  }

  async isExist(param: any): Promise<any> {
    const { code } = param;
    const condition: any = {
      where: {
        code: code,
      },
    };
    const result = await this.factoryCalendarRepository.find(condition);
    return result;
  }

  async getFactoryCalendars(
    param: SearchFactoryCalendarRequestDto,
  ): Promise<any[]> {
    const { factoryId, from, to } = param;
    const query = this.factoryCalendarRepository
      .createQueryBuilder('fc')
      .select([
        'fc.id AS id',
        'fc.title AS title',
        'fc.description AS description',
        'fc.from AS from',
        'fc.to AS to',
        'fc.type AS type',
        `CASE WHEN COUNT (fc) = 0 THEN '[]' ELSE jsonb_agg(DISTINCT (SELECT fc."factory_id")) END AS "factoryIds"`,
        `CASE WHEN COUNT(fwe) = 0 THEN '[]' ELSE json_agg(
          DISTINCT jsonb_build_object('id', fwe.id,
                            'workingDay', fwe.workingDay
                            )
        ) END AS factoryWorkDays`,
        `CASE WHEN COUNT(q) = 0 THEN '[]' ELSE json_agg(
          DISTINCT jsonb_build_object('id', q.id,
                            'title', q.title,
                            'from', q.from,
                            'to', q.to,
                            'relaxes', q.relaxes
                            )
        ) END AS shifts`,
      ])
      .where(
        new Brackets((qb) =>
          qb.andWhere(
            new Brackets((qb) =>
              qb
                .orWhere(
                  new Brackets((qb) =>
                    qb
                      .andWhere('fc."from"::Date <= :pFrom::Date', {
                        pFrom: from,
                      })
                      .andWhere('fc."to"::Date >= :pFrom::Date', {
                        pFrom: from,
                      }),
                  ),
                )
                .orWhere(
                  new Brackets((qb) =>
                    qb
                      .andWhere('fc."to"::Date >= :pTo::Date', {
                        pTo: to,
                      })
                      .andWhere('fc."from"::Date <= :pTo::Date', {
                        pTo: to,
                      }),
                  ),
                )
                .orWhere(
                  new Brackets((qb) =>
                    qb
                      .andWhere('fc."from"::Date > :pFrom::Date', {
                        pFrom: from,
                      })
                      .andWhere('fc."to"::Date < :pTo::Date', { pTo: to }),
                  ),
                ),
            ),
          ),
        ),
      );

    query.groupBy('fc.id');
    if (factoryId)
      query.andWhere('fc.factoryId = :pFactoryId', {
        pFactoryId: Number(factoryId),
      });
    query
      .innerJoin(FactoryWorkDayEntity, 'fwe', 'fwe.factoryCalendarId = fc.id')
      .innerJoin(
        FactoryCalendarShiftEntity,
        'fcs',
        'fcs.factoryCalendarId = fc.id',
      )
      .innerJoin(ShiftEntity, 's', 's.id = fcs.shiftId')
      .innerJoin(
        (q) =>
          q
            .select([
              's.id AS id',
              's.title AS title',
              's.from AS from',
              's.to AS to',
              `CASE WHEN COUNT(r) = 0 THEN '[]' ELSE json_agg(
                DISTINCT jsonb_build_object('id', r.id,
                                  'title', r.title,
                                  'from', r.from,
                                  'to', r.to
                                  )
              ) END AS relaxes`,
            ])
            .from(ShiftEntity, 's')
            .innerJoin(RelaxEntity, 'r', 'r.shiftId = s.id')
            .addGroupBy('s.id')
            .addGroupBy('s.title')
            .addGroupBy('s.from')
            .addGroupBy('s.to'),
        'q',
        'q.id = s.id',
      );
    return await query.getRawMany();
  }

  async checkDuplicateSchedule(param: CreateListFactoryCalendarRequestDto) {
    const { factoryIds, from, to } = param;
    return this.factoryCalendarRepository
      .createQueryBuilder('fc')
      .select(['*'])
      .andWhere(
        new Brackets((qb) =>
          qb
            .andWhere('fc.factoryId In (:...pFactoryIds)', {
              pFactoryIds: factoryIds,
            })
            .andWhere(
              new Brackets((qb) =>
                qb
                  .orWhere(
                    new Brackets((qb) =>
                      qb
                        .andWhere('fc."from"::Date <= :pFrom::Date', {
                          pFrom: from,
                        })
                        .andWhere('fc."to"::Date >= :pFrom::Date', {
                          pFrom: from,
                        }),
                    ),
                  )
                  .orWhere(
                    new Brackets((qb) =>
                      qb
                        .andWhere('fc."to"::Date >= :pTo::Date', {
                          pTo: to,
                        })
                        .andWhere('fc."from"::Date <= :pTo::Date', {
                          pTo: to,
                        }),
                    ),
                  )
                  .orWhere(
                    new Brackets((qb) =>
                      qb
                        .andWhere('fc."from"::Date > :pFrom::Date', {
                          pFrom: from,
                        })
                        .andWhere('fc."to"::Date < :pTo::Date', { pTo: to }),
                    ),
                  ),
              ),
            ),
        ),
      )
      .getRawMany();
  }
}
