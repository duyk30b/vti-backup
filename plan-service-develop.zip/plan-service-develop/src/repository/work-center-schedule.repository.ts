import { WorkCenterScheduleRepositoryInterface } from '@components/schedule/work-center-schedule/interface/work-center-schedule.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { WorkCenterDetailScheduleEntity } from '@entities/schedule/work-center-schedule/work-center-detail-schedule.entity';
import { WorkCenterScheduleEntity } from '@entities/schedule/work-center-schedule/work-center-schedule.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ItemProducingStepScheduleEntity } from '@entities/schedule/sale-order-schedule/item-producing-step-schedule.entity';

@Injectable()
export class WorkCenterScheduleRepository
  extends BaseAbstractRepository<WorkCenterScheduleEntity>
  implements WorkCenterScheduleRepositoryInterface
{
  constructor(
    @InjectRepository(WorkCenterScheduleEntity)
    private readonly workCenterSchedulesRepository: Repository<WorkCenterScheduleEntity>,
  ) {
    super(workCenterSchedulesRepository);
  }

  createEntity(params: any): WorkCenterScheduleEntity {
    const workCenterSchedule = new WorkCenterScheduleEntity();
    workCenterSchedule.workCenterId = params.workCenterId;
    workCenterSchedule.itemProducingStepScheduleId =
      params.itemProducingStepScheduleId;
    workCenterSchedule.quantity = params.quantity;
    workCenterSchedule.actualQuantity = params.actualQuantity
      ? params.actualQuantity
      : 0;
    workCenterSchedule.errorQuantity = 0;
    workCenterSchedule.excutionDate = params.excutionDate;
    workCenterSchedule.createdAt = new Date();
    workCenterSchedule.updatedAt = new Date();
    if (params.workCenterDetailSchedules) {
      workCenterSchedule.workCenterDetailSchedules =
        params.workCenterDetailSchedules;
    }
    if (params.itemProducingStepScheduleId) {
      workCenterSchedule.itemProducingStepScheduleId =
        params.itemProducingStepScheduleId;
    }
    return workCenterSchedule;
  }

  updateEntity(
    param: any,
    workCenterSchedule: WorkCenterScheduleEntity,
  ): WorkCenterScheduleEntity {
    for (const key in param) {
      if (key !== 'workCenterDetailSchedules' && key !== 'updatedAt')
        workCenterSchedule[key] = param[key];
    }
    workCenterSchedule.updatedAt = new Date();
    return workCenterSchedule;
  }

  async findByIds(ids: number[]): Promise<WorkCenterScheduleEntity[]> {
    return this.workCenterSchedulesRepository
      .createQueryBuilder('wcs')
      .select([
        'wcs.id AS "id"',
        'wcs.workCenterId AS "workCenterId"',
        'wcs.itemProducingStepScheduleId AS "itemProducingStepScheduleId"',
        'wcs.quantity AS "quantity"',
        'wcs.actualQuantity AS "actualQuantity"',
        'wcs.errorQuantity AS "errorQuantity"',
        'wcs.excutionDate AS "excutionDate"',
        'wcs.createdAt AS "createdAt"',
        'wcs.updatedAt AS "updatedAt"',
      ])
      .andWhere('wcs.id IN (:...ids)', {
        ids: ids,
      })
      .getRawMany();
  }

  async findByWorkCenterDetailScheduleIds(
    workCenterDetailScheduleIds: number[],
  ): Promise<any> {
    return this.workCenterSchedulesRepository
      .createQueryBuilder('wcs')
      .select([
        'wcs.id AS "id"',
        'wcs.quantity AS "quantity"',
        'wcds.id AS "workCenterDetailScheduleId"',
      ])
      .innerJoin(
        WorkCenterDetailScheduleEntity,
        'wcds',
        'wcds.workCenterScheduleId = wcs.id',
      )
      .andWhere('wcds.id IN (:...workCenterDetailScheduleIds)', {
        workCenterDetailScheduleIds: workCenterDetailScheduleIds,
      })
      .getRawMany();
  }

  async findByWorkCenterDetailSchedule(
    workCenterDetailScheduleIds: number[],
  ): Promise<any> {
    return this.workCenterSchedulesRepository
      .createQueryBuilder('wcs')
      .select([
        'wcs.id AS "id"',
        'wcs.quantity AS "quantity"',
        'wcs.work_center_id AS "workCenterId"',
        'wcs.excution_date AS "excutionDate"',
        `wcs.item_producing_step_schedule_id as "itemProducingStepScheduleId"`,
        `(ipss.quantity + ipss.over_quantity) as "producingStepScheduleQuantity"`,
        `ipss.over_quantity as "producingStepScheduleOverQuantity"`,
        `ipss.quantity as "producingStepSchedulePlanningQuantity"`,
        `JSON_AGG(JSONB_BUILD_OBJECT('id', wcds.id, 'quantity', wcds.quantity, 'workCenterShiftScheduleId', wcds.work_center_shift_schedule_id, 'excutionFrom', wcds.excution_from, 'excutionTo', wcds.excution_to)) as "workCenterDetailSchedules"`,
      ])
      .innerJoin(
        WorkCenterDetailScheduleEntity,
        'wcds',
        'wcds.workCenterScheduleId = wcs.id',
      )
      .innerJoin(
        ItemProducingStepScheduleEntity,
        'ipss',
        'ipss.id = wcs.item_producing_step_schedule_id',
      )
      .andWhere('wcds.id IN (:...workCenterDetailScheduleIds)', {
        workCenterDetailScheduleIds: workCenterDetailScheduleIds,
      })
      .groupBy('wcs.id')
      .addGroupBy('ipss.over_quantity')
      .addGroupBy('ipss.quantity')
      .getRawMany();
  }

  async getWorkCenterScheduleByPlan(
    workCenterIds: number[],
    planFrom: any,
    isNotProducingStepSchedule?: number[],
  ): Promise<any[]> {
    const query = this.workCenterSchedulesRepository
      .createQueryBuilder('wcs')
      .select([
        'wcs.id AS id',
        'wcs.work_center_id AS "workCenterId"',
        'wcs.item_producing_step_schedule_id AS "itemProducingStepScheduleId"',
        'wcs.quantity AS quantity',
        `TO_CHAR(wcs.excution_date:: DATE, 'yyyy-mm-dd') AS "excutionDate"`,
        `CASE WHEN count(wcds) = 0 THEN '[]' ELSE JSON_AGG(JSON_BUILD_OBJECT('workCenterScheduleId', wcds.work_center_schedule_id, 'workCenterShiftScheduleId', wcds.work_center_shift_schedule_id, 'excutionFrom', wcds.excution_from, 'excutionTo', wcds.excution_to, 'quantity', wcds.quantity)) END AS "workCenterDetailSchedules"`,
      ])
      .leftJoin(
        (qb) =>
          qb
            .select([
              'wcds.work_center_schedule_id AS work_center_schedule_id',
              'wcds.work_center_shift_schedule_id AS work_center_shift_schedule_id',
              'wcds.excution_from AS excution_from',
              'wcds.excution_to AS excution_to',
              'wcds.quantity AS quantity',
            ])
            .from(WorkCenterDetailScheduleEntity, 'wcds'),
        'wcds',
        'wcds.work_center_schedule_id = wcs.id',
      )
      .where('wcs.work_center_id IN (:...workCenterIds)', { workCenterIds })
      .andWhere('wcs.excution_date >= :planFrom', { planFrom })
      .groupBy('wcs.id');
    if (isNotProducingStepSchedule) {
      query
        .innerJoin(
          ItemProducingStepScheduleEntity,
          'ipsc',
          'wcs.item_producing_step_schedule_id = ipsc.id',
        )
        .andWhere('ipsc.id NOT IN (:...isNotProducingStepSchedule)', {
          isNotProducingStepSchedule,
        });
    }
    return await query.getRawMany();
  }
}
