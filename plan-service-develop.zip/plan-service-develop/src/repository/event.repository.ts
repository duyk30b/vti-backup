import { EventRepositoryInterface } from '@components/factory-calendar/interface/event.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { EventFactoryEntity } from '@entities/factory-calendar/event-factories.entity';
import { EventEntity } from '@entities/factory-calendar/event.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class EventRepository
  extends BaseAbstractRepository<EventEntity>
  implements EventRepositoryInterface
{
  constructor(
    @InjectRepository(EventEntity)
    private readonly eventRepository: Repository<EventEntity>,
  ) {
    super(eventRepository);
  }

  createEntity(param: any): EventEntity {
    const entity = new EventEntity();
    for (const key in param) {
      entity[key] = param[key];
    }
    entity.createdAt = new Date();
    entity.updatedAt = new Date();
    return entity;
  }

  updateEntity(param: any, event: EventEntity): EventEntity {
    for (const key in param) {
      if (key !== 'updatedAt') event[key] = param[key];
    }
    event.updatedAt = new Date();
    return event;
  }

  async isExist(param: any): Promise<any> {
    const { code } = param;
    const result = await this.eventRepository.find({
      where: {
        code: code,
      },
    });
    return result;
  }

  async getEvents(param: any): Promise<any[]> {
    const query = this.eventRepository
      .createQueryBuilder('e')
      .select([
        'e.id AS id',
        'e.code AS code',
        'e.title AS title',
        'e.description AS description',
        'e.from AS from',
        'e.to AS to',
        'e.type AS type',
        `CASE WHEN COUNT (ef) = 0 THEN '[]' ELSE jsonb_agg(ef.factoryId) END AS "factoryIds"`,
      ])
      .innerJoin(EventFactoryEntity, 'ef', 'ef.eventId = e.id')
      .andWhere('e."from"::Date >= :pFrom::Date', {
        pFrom: param.from,
      })
      .andWhere('e."to"::Date <= :pTo::Date', {
        pTo: param.to,
      })
      .groupBy('e.id');
    return await query.getRawMany();
  }
}
