import { ItemManufacturingOrderRepositoryInterface } from '@components/schedule/master-plan/interface/item-manufacturing-order.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { ItemManufacturingOrderEntity } from '@entities/schedule/sale-order-schedule/item-manufacturing-order.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class ItemManufacturingOrderRepository
  extends BaseAbstractRepository<ItemManufacturingOrderEntity>
  implements ItemManufacturingOrderRepositoryInterface
{
  constructor(
    @InjectRepository(ItemManufacturingOrderEntity)
    private readonly itemManufacturingOrderRepository: Repository<ItemManufacturingOrderEntity>,
  ) {
    super(itemManufacturingOrderRepository);
  }
}
