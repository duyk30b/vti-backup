import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { NATS_PRODUCE } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { keyBy } from 'lodash';

@Injectable()
export class ProduceService implements ProduceServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  /**
   *
   * @param masterPlanId
   * @returns
   */
  public async handlerMasterPlanModerated(masterPlanId: number): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_PRODUCE}.handler_master_plan_moderated`,
      {
        masterPlanId,
      },
    );
  }

  /**
   *
   * @param itemIds
   * @returns
   */
  public async getBomTreeByItemIds(
    itemIds: number[],
    bomVersionIds: number[],
    factoryId?: number,
  ): Promise<any> {
    const payload = {
      itemIds,
      bomVersionIds,
      factoryId,
    };
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_boms_tree_by_item_ids`,
      payload,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    return response.data;
  }

  public async getBomByItemIds(
    itemIds: number[],
    isSerialize?: boolean,
  ): Promise<any> {
    const payload = {
      itemIds,
    };
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_bom_by_item_ids`,
      payload,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS)
      return isSerialize ? {} : [];
    return isSerialize ? keyBy(response.data, 'itemId') : response.data;
  }

  public async getProducingSteps(
    producingStepIds: number[],
    factoryId: number,
    routingIds?: number[],
  ): Promise<any> {
    const payload = {
      producingStepIds,
      factoryId,
      routingIds,
    };
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_producing_steps_and_work_center`,
      payload,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    return response.data;
  }

  async getListProducingStepByIds(
    producingIds: number[],
    isSerialize = false,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_list_producing_step_by_ids`,
      { ids: producingIds },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS)
      return isSerialize ? {} : [];
    return isSerialize ? keyBy(response.data, 'id') : response.data;
  }

  public async getWorkCenterByIds(
    workCenterIds: number[],
    isSerialize = false,
  ): Promise<any> {
    const workCenters = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_work_center_by_ids`,
      { ids: workCenterIds },
    );
    if (workCenters.statusCode !== ResponseCodeEnum.SUCCESS)
      return isSerialize ? {} : [];
    return isSerialize ? keyBy(workCenters.data, 'id') : workCenters.data;
  }

  public async getMaterialBomByIds(
    bomIds: number[],
    isSerialize = false,
  ): Promise<any> {
    const payload = {
      ids: bomIds,
    };
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_material_bom_by_ids`,
      payload,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS)
      return isSerialize ? {} : [];
    return isSerialize ? keyBy(response.data, 'id') : response.data;
  }

  async getMoByIds(ids: number[], isSerialize = false): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_list_mo_by_ids`,
      ids,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS)
      return isSerialize ? {} : [];
    return isSerialize ? keyBy(response.data, 'id') : response.data;
  }
}
