export interface ProduceServiceInterface {
  getBomTreeByItemIds(
    itemIds: number[],
    bomVersionIds: number[],
    factoryId?: number,
  ): Promise<any>;
  getBomByItemIds(itemIds: number[], isSerialize?: boolean): Promise<any>;
  getProducingSteps(
    producingStepIds: number[],
    factoryId: number,
    routingIds?: number[],
  ): Promise<any>;
  getWorkCenterByIds(
    workCenterIds: number[],
    isSerialize?: boolean,
  ): Promise<any>;
  getListProducingStepByIds(
    producingIds: number[],
    isSerialize?: boolean,
  ): Promise<any>;
  handlerMasterPlanModerated(masterPlanId: number): Promise<any>;
  getMaterialBomByIds(ids: number[], isSerialize?: boolean): Promise<any>;
  getMoByIds(ids: number[], isSerialize?: boolean): Promise<any>;
}
