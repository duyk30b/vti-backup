import { NATS_REQUEST } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Inject, Injectable } from '@nestjs/common';
import { REQUEST } from '@nestjs/core';
import { Request } from 'express';
import { isEmpty, keyBy } from 'lodash';
import { RequestServiceInterface } from './interface/request.service.interface';

@Injectable()
export class RequestService implements RequestServiceInterface {
  constructor(
    @Inject(REQUEST) private readonly req: Request,
    private readonly natsClientService: NatsClientService,
  ) {}

  async getRequestOrderByIds(ids: string[], serialize?: boolean): Promise<any> {
    if (isEmpty(ids)) return [];
    const response = await this.natsClientService.send(
      `${NATS_REQUEST}.get_manufacturing_request_orders`,
      {
        filter: [
          {
            column: 'ids',
            text: ids.join(','),
          },
        ],
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      if (serialize) {
        return {};
      } else {
        return [];
      }
    }
    if (serialize) {
      return keyBy(response.data, 'id');
    }
    return response.data;
  }

  async updateManufacturingRequestOrderIsHasPlan(
    manufacturingRequestOrderIds: string[],
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_REQUEST}.update_manufacturing_request_order_is_has_plan`,
      {
        ids: manufacturingRequestOrderIds,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    return response.data;
  }
}
