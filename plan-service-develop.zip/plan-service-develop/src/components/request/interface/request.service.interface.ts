export interface RequestServiceInterface {
  getRequestOrderByIds(ids: string[], serialize?: boolean): Promise<any>;
  updateManufacturingRequestOrderIsHasPlan(ids: string[]): Promise<any>;
}
