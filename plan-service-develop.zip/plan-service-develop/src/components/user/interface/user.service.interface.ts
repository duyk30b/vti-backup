export interface UserServiceInterface {
  getFactoriesByIds(ids, isSerialize?: boolean): Promise<any>;
  getUsersByIds(ids: number[], isSerialize?: boolean): Promise<any>;
}
