import { NATS_USER } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Inject, Injectable } from '@nestjs/common';
import { REQUEST } from '@nestjs/core';
import { Request } from 'express';
import { isEmpty, keyBy } from 'lodash';
import { UserServiceInterface } from './interface/user.service.interface';

@Injectable()
export class UserService implements UserServiceInterface {
  constructor(
    @Inject(REQUEST) private readonly req: Request,
    private readonly natsClientService: NatsClientService,
  ) {}

  async getFactoriesByIds(ids, isSerialize?: boolean): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_USER}.get_factory_by_ids`,
      {
        ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    return isSerialize ? keyBy(response.data, 'id') : response.data;
  }

  async getUsersByIds(ids: number[], isSerialize?: boolean): Promise<any> {
    if (isEmpty(ids)) {
      return isSerialize ? {} : [];
    }
    const response = await this.natsClientService.send(
      `${NATS_USER}.get_users_by_ids`,
      {
        userIds: ids,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return isSerialize ? keyBy(response.data, 'id') : response.data;
  }
}
