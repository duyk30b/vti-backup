import { NATS_SALE } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Inject, Injectable } from '@nestjs/common';
import { REQUEST } from '@nestjs/core';
import { Request } from 'express';
import { keyBy } from 'lodash';
import { UpdateProducedQuantityRequestDto } from './dto/request/update-produced-quantity.request.dto';
import { SaleServiceInterface } from './interface/sale.service.interface';

@Injectable()
export class SaleService implements SaleServiceInterface {
  constructor(
    @Inject(REQUEST) private readonly req: Request,
    private readonly natsClientService: NatsClientService,
  ) {}
  async getByIds(saleOrderIds: number[], isSerialize = false): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.get_sale_order_by_ids`,
      { ids: saleOrderIds },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS)
      return isSerialize ? {} : [];
    return isSerialize ? keyBy(response.data, 'id') : response.data;
  }

  async updateSoIsHasPlan(soIds: number[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.update_sale_order_is_has_plan`,
      { ids: soIds },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    return response.data;
  }

  async updateProducedQuantity(
    request: UpdateProducedQuantityRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_SALE}.update_produced_quantity`,
      request,
    );
    return response.statusCode === ResponseCodeEnum.SUCCESS;
  }
}
