import { UpdateProducedQuantityRequestDto } from '../dto/request/update-produced-quantity.request.dto';

export interface SaleServiceInterface {
  getByIds(itemIds: number[], isSerialize?: boolean): Promise<any>;
  updateSoIsHasPlan(soIds: number[]): Promise<any>;
  updateProducedQuantity(
    request: UpdateProducedQuantityRequestDto,
  ): Promise<any>;
}
