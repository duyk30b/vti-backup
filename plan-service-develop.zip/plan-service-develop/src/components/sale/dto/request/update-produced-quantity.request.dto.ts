import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsInt,
  IsMongoId,
  IsNotEmpty,
  Min,
  ValidateNested,
} from 'class-validator';

class ItemSaleOrder {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @Min(1)
  @IsInt()
  quantity: number;
}

export class UpdateProducedQuantityRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;

  @ApiProperty()
  @Type(() => ItemSaleOrder)
  @ArrayNotEmpty()
  @ValidateNested()
  @ArrayUnique((item: ItemSaleOrder) => item.itemId)
  items: ItemSaleOrder[];
}
