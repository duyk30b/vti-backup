import { NATS_PLAN } from '@config/nats.config';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Injectable,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { isEmpty } from 'lodash';
import { CreateFactoryCalendarRequestDto } from './dto/request/create-factory-calendar.request.dto';
import { CreateListFactoryCalendarRequestDto } from './dto/request/create-list-factory-calendar.request.dto';
import { DeleteFactoryCalendarRequestDto } from './dto/request/delete-factory-calendar.request.dto';
import { SearchFactoryCalendarRequestDto } from './dto/request/search-factory-calendar.request.dto';
import { UpdateFactoryCalendarRequestDto } from './dto/request/update-factory-calendar.request.dto';
import { FactoryCalendarServiceInterface } from './interface/factory-calendar.service.interface';

@Injectable()
@Controller('factory-calendars')
export class FactoryCalendarController {
  constructor(
    @Inject('FactoryCalendarServiceInterface')
    private readonly factoryCalendarServiceInterface: FactoryCalendarServiceInterface,
  ) {}

  // @MessagePattern(`${NATS_PLAN}.create_factory_calendar`)
  @Post('')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Tạo calendar nhà máy',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
  })
  async createEvent(
    @Body() payload: CreateFactoryCalendarRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.factoryCalendarServiceInterface.createEvent(request);
  }

  // @MessagePattern(`${NATS_PLAN}.update_factory_calendar`)
  @Put('')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Sửa calendar nhà máy',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  async updateEvent(
    @Body() payload: UpdateFactoryCalendarRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.factoryCalendarServiceInterface.updateEvent(request);
  }

  // @MessagePattern(`${NATS_PLAN}.delete_factory_calendar`)
  @Delete('/:id')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Xóa calendar nhà máy',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  async deleteEvent(@Param('id', new ParseIntPipe()) id): Promise<any> {
    return await this.factoryCalendarServiceInterface.deleteEvent({
      id,
    } as DeleteFactoryCalendarRequestDto);
  }

  // @MessagePattern(`${NATS_PLAN}.list_event`)
  @Get('/events')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Danh sách calendar nhà máy trong tháng',
  })
  @ApiResponse({
    status: 200,
    description: 'Search successfully',
  })
  async listEvent(
    @Query() payload: SearchFactoryCalendarRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.factoryCalendarServiceInterface.searchEvents(request);
  }

  // @MessagePattern(`${NATS_PLAN}.list_factory_calendar`)
  @Get('')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Danh sách calendar nhà máy trong tháng',
  })
  @ApiResponse({
    status: 200,
    description: 'Search successfully',
  })
  async listFactoryCalendar(
    @Query() payload: SearchFactoryCalendarRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.factoryCalendarServiceInterface.searchFactoryCalendar(
      request,
    );
  }

  // @MessagePattern(`${NATS_PLAN}.setup_factory_calendar`)
  @Post('/setup')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Điều độ nhập quantity',
  })
  @ApiResponse({
    status: 200,
    description: 'Moderation input successfully',
    type: CreateListFactoryCalendarRequestDto,
  })
  async setupFactoryCalendar(
    @Body() payload: CreateListFactoryCalendarRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.factoryCalendarServiceInterface.setupFactoryCalendar(
      request,
    );
  }

  @MessagePattern(`${NATS_PLAN}.factory_calendar_detail`)
  async getFactoryCalendarDetail(
    @Body() payload: SearchFactoryCalendarRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.factoryCalendarServiceInterface.getFactoryCalendarDetail(
      request,
    );
  }
  // @TODO: remove when refactor done
  @MessagePattern(`${NATS_PLAN}.factory_calendar_detail`)
  async getFactoryCalendarDetailTcp(
    @Body() payload: SearchFactoryCalendarRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.factoryCalendarServiceInterface.getFactoryCalendarDetail(
      request,
    );
  }
}
