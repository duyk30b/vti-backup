import { ResponseCodeEnum } from '@constant/response-code.enum';
import { EventEntity } from '@entities/factory-calendar/event.entity';
import { FactoryCalendarEntity } from '@entities/factory-calendar/factory-calendar.entity';
import { FactoryCalendarShiftEntity } from '@entities/factory-calendar/factory-calendar-shift.entity';
import { ShiftEntity } from '@entities/factory-calendar/shift.entity';
import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ResponseBuilder } from '@utils/response-builder';
import { difference, flatMap, isEmpty, uniq, keyBy } from 'lodash';
import { I18nService } from 'nestjs-i18n';
import { DataSource } from 'typeorm';
import { CreateFactoryCalendarRequestDto } from './dto/request/create-factory-calendar.request.dto';
import { CreateListFactoryCalendarRequestDto } from './dto/request/create-list-factory-calendar.request.dto';
import { UpdateFactoryCalendarRequestDto } from './dto/request/update-factory-calendar.request.dto';
import {
  FactoryTypeEnum,
  MILLISECONDS_PER_DAY,
} from './factory-calendar.constant';
import { EventFactoryRepositoryInterface } from './interface/event-factory.repository.interface';
import { EventRepositoryInterface } from './interface/event.repository.interface';
import { FactoryCalendarShiftRepositoryInterface } from './interface/factory-calendar-shift.repository.interface';
import { FactoryCalendarRepositoryInterface } from './interface/factory-calendar.repository.interface';
import { FactoryCalendarServiceInterface } from './interface/factory-calendar.service.interface';
import { FactoryWorkDayRepositoryInterface } from './interface/factory-work-day.repository.interface';
import { RelaxRepositoryInterface } from './interface/relax.repository.interface';
import { ShiftRepositoryInterface } from './interface/shift.repository.interface';
import { EventFactoryEntity } from '@entities/factory-calendar/event-factories.entity';
import { SearchFactoryCalendarRequestDto } from './dto/request/search-factory-calendar.request.dto';
import * as moment from 'moment';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
@Injectable()
export class FactoryCalendarService implements FactoryCalendarServiceInterface {
  constructor(
    @Inject('FactoryCalendarRepositoryInterface')
    private readonly factoryCalendarRepository: FactoryCalendarRepositoryInterface,

    @Inject('EventRepositoryInterface')
    private readonly eventRepository: EventRepositoryInterface,

    @Inject('EventFactoryRepositoryInterface')
    private readonly eventFactoryRepository: EventFactoryRepositoryInterface,

    @Inject('FactoryWorkDayRepositoryInterface')
    private readonly factoryWorkDayRepository: FactoryWorkDayRepositoryInterface,

    @Inject('ShiftRepositoryInterface')
    private readonly shiftRepository: ShiftRepositoryInterface,

    @Inject('RelaxRepositoryInterface')
    private readonly relaxRepository: RelaxRepositoryInterface,

    @Inject('FactoryCalendarShiftRepositoryInterface')
    private readonly factoryCalendarShiftRepository: FactoryCalendarShiftRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,
    private readonly i18n: I18nService,
  ) {}

  async createEvent(request: CreateFactoryCalendarRequestDto): Promise<any> {
    const { code, description, type, title, from, to, factoryIds } = request;
    if (new Date(from) > new Date(to)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.DATE_ERROR'))
        .build();
    }
    try {
      // check factory, user factory
      await this.checkUserFactory(request);

      // check event current
      const eventCurrent = await this.eventRepository.isExist({
        code: code,
      });

      if (eventCurrent.length > 0) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.EVENT_EXIST'))
          .build();
      }

      const eventEntity = await this.eventRepository.createEntity({
        code,
        description,
        type,
        title,
        from,
        to,
      });
      eventEntity.eventFactories = [];

      for (let i = 0; i < factoryIds.length; i++) {
        const factoryId = factoryIds[i];
        const eventFactoryEntity =
          await this.eventFactoryRepository.createEntity({
            factoryId,
          });
        eventEntity.eventFactories.push(eventFactoryEntity);
      }

      const response = await this.eventRepository.create(eventEntity);

      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (err) {
      console.log(err);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CREATE'))
        .build();
    }
  }

  async updateEvent(request: UpdateFactoryCalendarRequestDto): Promise<any> {
    try {
      const { id, from, to, factoryIds } = request;

      if (new Date(from) > new Date(to) || new Date(from) < new Date()) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.DATE_ERROR'))
          .build();
      }

      const event = await this.eventRepository.findOneById(id);
      if (!event) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.EVENT_NOT_EXIST'))
          .build();
      }
      await this.checkUserFactory(request);

      const eventUpdated = this.eventRepository.updateEntity(request, event);
      const eventFactoryEntities = factoryIds.map((factoryId) => {
        return this.eventFactoryRepository.createEntity({
          eventId: id,
          factoryId,
        });
      });

      const eventFactories = await this.eventFactoryRepository.findByCondition({
        eventId: id,
      });

      const queryRunner = await this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.delete(EventFactoryEntity, eventFactories);
        await queryRunner.manager.save(EventEntity, eventUpdated);
        await queryRunner.manager.save(
          EventFactoryEntity,
          eventFactoryEntities,
        );
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error)
          .build();
      } finally {
        await queryRunner.release();
      }

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (err) {
      console.log(err);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async deleteEvent(request: any): Promise<any> {
    try {
      // check event exist
      const eventExist = await this.eventRepository.findOneWithRelations({
        where: { id: request.id },
        relations: ['eventFactories'],
      });

      if (!eventExist) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.EVENT_NOT_EXIST'))
          .build();
      }

      await this.eventRepository.remove(eventExist.id);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (err) {
      console.log(err);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }
  }

  async searchEvents(request: any): Promise<any> {
    let response = await this.eventRepository.getEvents(request);
    if (request.factoryId) {
      response = response.filter((res) =>
        res.factoryIds.includes(+request.factoryId),
      );
    }
    const factoryIds = uniq(flatMap(response.map((i) => i.factoryIds)));
    const factories = await this.userService.getFactoriesByIds(factoryIds);
    const factoryMap = keyBy(factories, 'id');
    response = response.map((res) => {
      return {
        ...res,
        factories: res.factoryIds.map((factoryId) => {
          return {
            id: factoryId,
            name: factoryMap[factoryId]?.name,
          };
        }),
      };
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  async searchFactoryCalendar(request: any): Promise<any> {
    const response = await this.factoryCalendarRepository.getFactoryCalendars(
      request,
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  async checkUserFactory(request: any) {
    const { factoryIds = [], user } = request;
    const userFactoryIds = flatMap(user.factories, 'id');
    if (difference(factoryIds, userFactoryIds).length !== 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.SELECTED_FACTORIES_INVALID'),
        )
        .build();
    }
  }

  async setupFactoryCalendar(
    request: CreateListFactoryCalendarRequestDto,
  ): Promise<any> {
    try {
      const { description, from, to, factoryIds, workDays, shifts } = request;

      const totalTimeOfShift = shifts.reduce((acc, shift) => {
        const startShift = moment(shift.from, 'HH:mm');
        let endShift = moment(shift.to, 'HH:mm');
        if (endShift.isBefore(startShift)) {
          endShift = moment(shift.to, 'HH:mm').add(1, 'days');
        }
        return (acc += endShift.diff(startShift));
      }, 0);
      if (totalTimeOfShift !== MILLISECONDS_PER_DAY && shifts.length > 1) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.SHIFT_TIME_INVALID'))
          .build();
      }

      const isDuplicateRange =
        await this.factoryCalendarRepository.checkDuplicateSchedule(request);
      if (!isEmpty(isDuplicateRange)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.DUPLICATE_SCHEDULE'))
          .build();
      }
      const factoryCalendarEntities: any[] = [];
      const shiftEntities: any[] = [];
      const factoryCalendarShiftEntities: any[] = [];

      if (new Date(from) > new Date(to)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.START_TIME_LESS_THAN_END_TIME'),
          )
          .build();
      }

      for (let i = 0; i < shifts.length; i++) {
        const shift = shifts[i];
        const startShift = moment(shift.from, 'HH:mm');
        let endShift = moment(shift.to, 'HH:mm');
        if (shift.from > shift.to) {
          endShift = moment(shift.to, 'HH:mm').add(1, 'days');
        }
        const shiftEntity = await this.shiftRepository.createEntity({
          title: shift.title,
          from: shift.from,
          to: shift.to,
          description: description,
        });
        shiftEntity.relaxes = [];
        shiftEntities.push(shiftEntity);

        for (let j = 0; j < shift.relaxs.length; j++) {
          const relax = shift.relaxs[j];
          const startRelax = moment(relax.from, 'HH:mm');
          let endRelax = moment(relax.to, 'HH:mm');
          if (relax.to < relax.from) {
            endRelax = moment(relax.to, 'HH:mm').add(1, 'days');
          }
          if (
            startRelax.isAfter(endRelax) ||
            startShift.isAfter(startRelax) ||
            startShift.isAfter(endRelax) ||
            endShift.isBefore(startRelax) ||
            endShift.isBefore(endRelax)
          ) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(
                await this.i18n.translate('error.RELAX_TIME_INVALID'),
              )
              .build();
          }
          const relaxEntity = await this.relaxRepository.createEntity({
            title: relax.title,
            from: relax.from,
            to: relax.to,
            description: description,
          });
          shiftEntity.relaxes.push(relaxEntity);
        }
      }

      for (let i = 0; i < factoryIds.length; i++) {
        const factoryId = factoryIds[i];
        const factoryCalendarEntity =
          await this.factoryCalendarRepository.createEntity({
            title: description,
            description,
            from,
            to,
            factoryId,
            type: FactoryTypeEnum.WORKDAY,
          });
        factoryCalendarEntity.factoryWorkDays = [];
        factoryCalendarEntities.push(factoryCalendarEntity);

        for (let j = 0; j < workDays.length; j++) {
          const workDay = workDays[j];
          const factoryWorkDayEntity =
            await this.factoryWorkDayRepository.createEntity({
              workingDay: workDay,
            });
          factoryCalendarEntity.factoryWorkDays.push(factoryWorkDayEntity);
        }

        for (let j = 0; j < shiftEntities.length; j++) {
          const shiftEntity = shiftEntities[j];
          const factoryCalendarShiftEntity =
            await this.factoryCalendarShiftRepository.createEntity({
              factoryCalendar: factoryCalendarEntity,
              shift: shiftEntity,
            });
          factoryCalendarShiftEntities.push(factoryCalendarShiftEntity);
        }
      }

      const queryRunner = await this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(
          FactoryCalendarEntity,
          factoryCalendarEntities,
        );
        await queryRunner.manager.save(ShiftEntity, shiftEntities);
        await queryRunner.manager.save(
          FactoryCalendarShiftEntity,
          factoryCalendarShiftEntities,
        );
        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(error)
          .build();
      } finally {
        await queryRunner.release();
      }

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (err) {
      console.log(err);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CREATE'))
        .build();
    }
  }

  getDatesDays(startDate: Date, endDate: Date) {
    const dates = [];
    for (
      let currentDate = new Date(startDate);
      currentDate <= endDate;
      currentDate.setDate(currentDate.getDate() + 1)
    ) {
      dates.push(new Date(currentDate));
    }
    return { dates };
  }

  async getFactoryCalendarDetail(
    request: SearchFactoryCalendarRequestDto,
  ): Promise<any> {
    const factoryCalendar =
      await this.factoryCalendarRepository.getFactoryCalendars(request);

    return new ResponseBuilder(factoryCalendar)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }
}
