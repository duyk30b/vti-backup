import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { FactoryCalendarEntity } from '@entities/factory-calendar/factory-calendar.entity';
import { CreateListFactoryCalendarRequestDto } from '../dto/request/create-list-factory-calendar.request.dto';

export interface FactoryCalendarRepositoryInterface
  extends BaseInterfaceRepository<FactoryCalendarEntity> {
  createEntity(param: any): FactoryCalendarEntity;
  updateEntity(
    param: any,
    factoryCalendar: FactoryCalendarEntity,
  ): FactoryCalendarEntity;
  isExist(param: any): Promise<any>;
  getFactoryCalendars(param: any): Promise<any[]>;
  checkDuplicateSchedule(
    param: CreateListFactoryCalendarRequestDto,
  ): Promise<any[]>;
}
