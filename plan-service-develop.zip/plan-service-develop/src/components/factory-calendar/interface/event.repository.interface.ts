import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { EventEntity } from '@entities/factory-calendar/event.entity';

export interface EventRepositoryInterface
  extends BaseInterfaceRepository<EventEntity> {
  createEntity(param: any): EventEntity;
  updateEntity(param: any, event: EventEntity): EventEntity;
  isExist(param: any): Promise<any>;
  getEvents(param: any): Promise<any[]>;
}
