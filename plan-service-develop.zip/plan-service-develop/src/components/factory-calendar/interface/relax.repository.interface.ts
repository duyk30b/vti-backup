import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { RelaxEntity } from '@entities/factory-calendar/relax.entity';

export interface RelaxRepositoryInterface
  extends BaseInterfaceRepository<RelaxEntity> {
  createEntity(param: any): RelaxEntity;
}
