import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ShiftEntity } from '@entities/factory-calendar/shift.entity';

export interface ShiftRepositoryInterface
  extends BaseInterfaceRepository<ShiftEntity> {
  createEntity(param: any): ShiftEntity;
}
