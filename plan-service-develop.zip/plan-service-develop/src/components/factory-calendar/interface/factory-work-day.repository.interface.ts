import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { FactoryWorkDayEntity } from '@entities/factory-calendar/factory-work-day.entity';

export interface FactoryWorkDayRepositoryInterface
  extends BaseInterfaceRepository<FactoryWorkDayEntity> {
  createEntity(param: any): FactoryWorkDayEntity;
}
