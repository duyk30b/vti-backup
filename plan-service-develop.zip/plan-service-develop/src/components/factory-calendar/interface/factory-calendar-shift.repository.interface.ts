import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { FactoryCalendarShiftEntity } from '@entities/factory-calendar/factory-calendar-shift.entity';

export interface FactoryCalendarShiftRepositoryInterface
  extends BaseInterfaceRepository<FactoryCalendarShiftEntity> {
  createEntity(param: any): FactoryCalendarShiftEntity;
}
