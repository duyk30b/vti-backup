import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { EventFactoryEntity } from '@entities/factory-calendar/event-factories.entity';

export interface EventFactoryRepositoryInterface
  extends BaseInterfaceRepository<EventFactoryEntity> {
  createEntity(param: any): EventFactoryEntity;
}
