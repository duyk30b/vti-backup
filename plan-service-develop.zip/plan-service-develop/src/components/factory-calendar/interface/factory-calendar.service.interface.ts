import { CreateFactoryCalendarRequestDto } from '../dto/request/create-factory-calendar.request.dto';
import { CreateListFactoryCalendarRequestDto } from '../dto/request/create-list-factory-calendar.request.dto';
import { DeleteFactoryCalendarRequestDto } from '../dto/request/delete-factory-calendar.request.dto';
import { SearchFactoryCalendarRequestDto } from '../dto/request/search-factory-calendar.request.dto';
import { UpdateFactoryCalendarRequestDto } from '../dto/request/update-factory-calendar.request.dto';

export interface FactoryCalendarServiceInterface {
  createEvent(request: CreateFactoryCalendarRequestDto): Promise<any>;
  updateEvent(request: UpdateFactoryCalendarRequestDto): Promise<any>;
  deleteEvent(request: DeleteFactoryCalendarRequestDto): Promise<any>;
  searchEvents(request: SearchFactoryCalendarRequestDto): Promise<any>;
  searchFactoryCalendar(request: SearchFactoryCalendarRequestDto): Promise<any>;
  setupFactoryCalendar(
    request: CreateListFactoryCalendarRequestDto,
  ): Promise<any>;
  getFactoryCalendarDetail(
    request: SearchFactoryCalendarRequestDto,
  ): Promise<any>;
}
