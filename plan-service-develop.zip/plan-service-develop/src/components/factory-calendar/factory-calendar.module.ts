import { ConfigService } from '@config/config.service';
import { EventFactoryEntity } from '@entities/factory-calendar/event-factories.entity';
import { EventEntity } from '@entities/factory-calendar/event.entity';
import { FactoryCalendarShiftEntity } from '@entities/factory-calendar/factory-calendar-shift.entity';
import { FactoryCalendarEntity } from '@entities/factory-calendar/factory-calendar.entity';
import { FactoryWorkDayEntity } from '@entities/factory-calendar/factory-work-day.entity';
import { RelaxEntity } from '@entities/factory-calendar/relax.entity';
import { ShiftEntity } from '@entities/factory-calendar/shift.entity';
import { Module } from '@nestjs/common';
import { ClientProxyFactory } from '@nestjs/microservices';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EventFactoryRepository } from 'src/repository/event-factory.repository';
import { EventRepository } from 'src/repository/event.repository';
import { FactoryCalendarShiftRepository } from 'src/repository/factory-calendar-shift.repository';
import { FactoryCalendarRepository } from 'src/repository/factory-calendar.repository';
import { FactoryWorkDayRepository } from 'src/repository/factory-work-day.repository';
import { RelaxRepository } from 'src/repository/relax.repository';
import { ShiftRepository } from 'src/repository/shift.repository';
import { FactoryCalendarController } from './factory-calendar.controller';
import { FactoryCalendarService } from './factory-calendar.service';
@Module({
  imports: [
    TypeOrmModule.forFeature([
      FactoryCalendarEntity,
      EventFactoryEntity,
      EventEntity,
      FactoryWorkDayEntity,
      ShiftEntity,
      RelaxEntity,
      FactoryCalendarShiftEntity,
    ]),
  ],
  controllers: [FactoryCalendarController],
  providers: [
    {
      provide: 'FactoryCalendarRepositoryInterface',
      useClass: FactoryCalendarRepository,
    },
    {
      provide: 'FactoryCalendarServiceInterface',
      useClass: FactoryCalendarService,
    },
    {
      provide: 'EventFactoryRepositoryInterface',
      useClass: EventFactoryRepository,
    },
    {
      provide: 'EventRepositoryInterface',
      useClass: EventRepository,
    },
    {
      provide: 'FactoryWorkDayRepositoryInterface',
      useClass: FactoryWorkDayRepository,
    },
    {
      provide: 'ShiftRepositoryInterface',
      useClass: ShiftRepository,
    },
    {
      provide: 'RelaxRepositoryInterface',
      useClass: RelaxRepository,
    },
    {
      provide: 'FactoryCalendarShiftRepositoryInterface',
      useClass: FactoryCalendarShiftRepository,
    },
    ConfigService,
    {
      provide: 'USER_SERVICE',
      useFactory: (configService: ConfigService) => {
        const userServiceOptions = configService.get('userService');
        return ClientProxyFactory.create(userServiceOptions);
      },
      inject: [ConfigService],
    },
  ],
  exports: [],
})
export class FactoryCalendarModule {}
