import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { CalendarAbstractResponseDto } from './calendar.abstract.response.dto';

export class FactoryCalendarResponseDto extends CalendarAbstractResponseDto {
  @ApiProperty()
  @Expose()
  factoryId: number;
}
