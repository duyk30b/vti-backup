import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class CalendarAbstractResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  title: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  from: Date;

  @ApiProperty()
  @Expose()
  to: Date;

  @ApiProperty()
  @Expose()
  type: number;
}
