import { BaseDto } from '@core/dto/base.dto';
import { Expose } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';

export class DeleteFactoryCalendarBodyRequestDto extends BaseDto {}
export class DeleteFactoryCalendarRequestDto extends DeleteFactoryCalendarBodyRequestDto {
  @Expose()
  @IsInt()
  @IsNotEmpty({ message: 'Id lịch không được trống' })
  id: number;
}
