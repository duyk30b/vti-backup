import { Expose } from 'class-transformer';
import { IsArray, IsInt, IsNotEmpty } from 'class-validator';
import { FactoryCalendarAbstractRequestDto } from './factory-calendar.abstract.request.dto';

export class UpdateFactoryCalendarRequestDto extends FactoryCalendarAbstractRequestDto {
  @Expose()
  @IsInt()
  @IsNotEmpty({ message: 'Id lịch không được trống' })
  id: number;

  @Expose()
  @IsArray()
  @IsNotEmpty({ message: 'factoryIds không được trống' })
  factoryIds: number[];
}
