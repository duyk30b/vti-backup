import { BaseDto } from '@core/dto/base.dto';
import { Expose } from 'class-transformer';
import {
  IsDateString,
  IsNotEmpty,
  IsNumberString,
  IsOptional,
} from 'class-validator';

export class SearchFactoryCalendarRequestDto extends BaseDto {
  @Expose()
  @IsDateString()
  @IsNotEmpty({ message: 'Thời gian bắt đầu không được trống' })
  from: Date;

  @Expose()
  @IsDateString()
  @IsNotEmpty({ message: 'Thời gian kết thúc không được trống' })
  to: Date;

  @Expose()
  @IsNumberString()
  @IsOptional()
  factoryId: string;
}
