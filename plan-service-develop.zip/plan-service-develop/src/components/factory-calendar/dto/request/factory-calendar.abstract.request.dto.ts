import { FactoryTypeEnum } from '@components/factory-calendar/factory-calendar.constant';
import { BaseDto } from '@core/dto/base.dto';
import { Expose } from 'class-transformer';
import {
  IsDateString,
  IsEnum,
  IsNotEmpty,
  IsString,
  MaxLength,
} from 'class-validator';

export class FactoryCalendarAbstractRequestDto extends BaseDto {
  @Expose()
  @IsString()
  @MaxLength(20)
  @IsNotEmpty({ message: 'code không được trống' })
  code: string;

  @Expose()
  @IsString()
  @MaxLength(50)
  @IsNotEmpty({ message: 'Title không được trống' })
  title: string;

  @Expose()
  @IsString()
  @MaxLength(255)
  description: string;

  @Expose()
  @IsDateString()
  @IsNotEmpty({ message: 'Thời gian bắt đầu không được trống' })
  from: Date;

  @Expose()
  @IsDateString()
  @IsNotEmpty({ message: 'Thời gian kết thúc không được trống' })
  to: Date;

  @Expose()
  @IsEnum(FactoryTypeEnum)
  @IsNotEmpty({ message: 'Loại lịch không được trống' })
  type: number;

  @Expose()
  @IsNotEmpty()
  user: any;
}
