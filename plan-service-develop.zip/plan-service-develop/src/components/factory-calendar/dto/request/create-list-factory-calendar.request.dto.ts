import { BaseDto } from '@core/dto/base.dto';
import { Expose } from 'class-transformer';
import {
  ArrayMinSize,
  IsArray,
  IsDateString,
  IsMilitaryTime,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';

class Relax {
  @Expose()
  @IsString()
  @IsNotEmpty({ message: 'title không được trống' })
  title: string;

  @Expose()
  @IsMilitaryTime()
  @IsNotEmpty({ message: 'Thời gian bắt đầu không được trống' })
  from: string;

  @Expose()
  @IsMilitaryTime()
  @IsNotEmpty({ message: 'Thời gian kết thúc không được trống' })
  to: string;
}

class Shift {
  @Expose()
  @IsString()
  @IsNotEmpty({ message: 'title không được trống' })
  title: string;

  @Expose()
  @IsMilitaryTime()
  @IsNotEmpty({ message: 'Thời gian bắt đầu không được trống' })
  from: string;

  @Expose()
  @IsMilitaryTime()
  @IsNotEmpty({ message: 'Thời gian kết thúc không được trống' })
  to: string;

  @Expose()
  @IsArray()
  @IsOptional()
  relaxs: Relax[];
}

export class CreateListFactoryCalendarRequestDto extends BaseDto {
  @Expose()
  @IsString()
  @MaxLength(255)
  description: string;

  @Expose()
  @IsDateString()
  @IsNotEmpty({ message: 'Thời gian bắt đầu không được trống' })
  from: string;

  @Expose()
  @IsDateString()
  @IsNotEmpty({ message: 'Thời gian kết thúc không được trống' })
  to: string;

  @Expose()
  @IsArray()
  @IsNotEmpty({ message: 'factoryIds không được trống' })
  factoryIds: number[];

  @Expose()
  @IsArray()
  @ArrayMinSize(1, { message: 'Vui lòng chọn ngày trong tuần' })
  workDays: number[];

  @Expose()
  @IsArray()
  @IsOptional()
  shifts: Shift[];

  @Expose()
  @IsNotEmpty()
  user: any;
}
