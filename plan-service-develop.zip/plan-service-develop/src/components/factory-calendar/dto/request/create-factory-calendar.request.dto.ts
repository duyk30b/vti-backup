import { Expose } from 'class-transformer';
import { IsArray, IsNotEmpty } from 'class-validator';
import { FactoryCalendarAbstractRequestDto } from './factory-calendar.abstract.request.dto';

export class CreateFactoryCalendarRequestDto extends FactoryCalendarAbstractRequestDto {
  @Expose()
  @IsArray()
  @IsNotEmpty({ message: 'factoryIds không được trống' })
  factoryIds: number[];
}
