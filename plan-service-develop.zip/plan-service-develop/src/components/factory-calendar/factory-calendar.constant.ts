export enum FactoryTypeEnum {
  HOLIDAY = 0,
  WORKDAY = 1,
}

export const MILLISECONDS_PER_DAY = 86400000;
