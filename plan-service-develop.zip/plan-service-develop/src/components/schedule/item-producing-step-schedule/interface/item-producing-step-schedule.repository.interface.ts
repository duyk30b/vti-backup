import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ItemProducingStepScheduleEntity } from '@entities/schedule/sale-order-schedule/item-producing-step-schedule.entity';

export interface ItemProducingStepScheduleRepositoryInterface
  extends BaseInterfaceRepository<ItemProducingStepScheduleEntity> {
  createEntity(
    producingStepId: number,
    planQuantity: number,
    quantity: number,
    stepNumber: number,
    dateFrom,
    dateTo,
    materials?: any[],
  ): ItemProducingStepScheduleEntity;
  updateEntity(
    param: any,
    itemProducingStepSchedule: ItemProducingStepScheduleEntity,
  ): ItemProducingStepScheduleEntity;
  sumOverQuantityByMasterPlanId(masterPlanId: number): Promise<any>;
  findByIds(ids: number[]): Promise<ItemProducingStepScheduleEntity[]>;
  findByWorkCenterDetailScheduleIds(
    workCenterDetailScheduleIds: number[],
  ): Promise<any>;
  getItemByIds(ids: number[]): Promise<any>;
}
