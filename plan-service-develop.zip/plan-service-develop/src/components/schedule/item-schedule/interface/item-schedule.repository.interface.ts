import { ItemScheduleRepositoryDto } from '@components/schedule/master-plan/dto/repository/item-schedule.dto';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ItemScheduleEntity } from '@entities/schedule/sale-order-schedule/item-schedule.entity';

export interface ItemScheduleRepositoryInterface
  extends BaseInterfaceRepository<ItemScheduleEntity> {
  findByIds(ids: number[]): Promise<ItemScheduleEntity[]>;
  createEntity(
    bomId: number,
    parentBomId,
    parentBomVersionId,
    itemId: number,
    level: number,
    itemFinishId: number,
    quantity: number,
    dateFrom: any,
    dateTo: any,
    needToManufacture: boolean,
    bomVersionId: number,
  ): ItemScheduleEntity;
  updateEntity(
    param: any,
    itemSchedule?: ItemScheduleEntity,
  ): ItemScheduleEntity;
  getScheduleByItemId(
    masterPlanId: number,
    saleOrderId: string,
    itemId: number,
  ): Promise<ItemScheduleRepositoryDto | any>;
}
