import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { WorkCenterScheduleEntity } from '@entities/schedule/work-center-schedule/work-center-schedule.entity';

export interface WorkCenterScheduleRepositoryInterface
  extends BaseInterfaceRepository<WorkCenterScheduleEntity> {
  createEntity(workCenter): WorkCenterScheduleEntity;
  updateEntity(
    param: any,
    workCenterSchedule: WorkCenterScheduleEntity,
  ): WorkCenterScheduleEntity;
  findByIds(ids: number[]): Promise<WorkCenterScheduleEntity[]>;
  findByWorkCenterDetailScheduleIds(
    workCenterDetailScheduleIds: number[],
  ): Promise<any>;
  findByWorkCenterDetailSchedule(
    workCenterDetailScheduleIds: number[],
  ): Promise<any>;
  getWorkCenterScheduleByPlan(
    workCenterIds: number[],
    planFrom: any,
    isNotProducingStepSchedule?: number[],
  ): Promise<any[]>;
}
