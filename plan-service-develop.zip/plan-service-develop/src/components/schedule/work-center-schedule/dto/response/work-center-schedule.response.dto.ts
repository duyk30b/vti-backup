import { WorkCenterDetailSchedule } from '@components/schedule/work-center-detail-schedule/interface/dto/response/work-center-detail-schedule.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

export class WorkCenterSchedule {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  workCenterId: number;

  @ApiProperty()
  @Expose()
  itemProducingStepScheduleId: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  errorQuantity: number;

  @ApiProperty()
  @Expose()
  excutionDate: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: WorkCenterDetailSchedule })
  @Type(() => WorkCenterDetailSchedule)
  @Expose()
  workCenterDetailSchedules: WorkCenterDetailSchedule[];
}
