import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { WorkCenterDetailScheduleEntity } from '@entities/schedule/work-center-schedule/work-center-detail-schedule.entity';

export interface WorkCenterDetailScheduleRepositoryInterface
  extends BaseInterfaceRepository<WorkCenterDetailScheduleEntity> {
  createEntity(workCenter): WorkCenterDetailScheduleEntity;
  updateEntity(
    param: any,
    workCenterDetailSchedule: WorkCenterDetailScheduleEntity,
  ): WorkCenterDetailScheduleEntity;
  findByIdsItemIdsSoId(
    soId: number,
    itemId: number[],
    ids: number[],
  ): Promise<any>;
  findByItemScheduleIds(
    masterPlanId: number,
    itemScheduleIds: number[],
    ids: number[],
  ): Promise<any>;
  findByIds(ids: number[]): Promise<any>;
}
