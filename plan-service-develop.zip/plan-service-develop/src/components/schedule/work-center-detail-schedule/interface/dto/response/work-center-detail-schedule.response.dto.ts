import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class WorkCenterDetailSchedule {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  workCenterScheduleId: number;

  @ApiProperty()
  @Expose()
  workCenterShiftScheduleId: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  errorQuantity: number;

  @ApiProperty()
  @Expose()
  excutionFrom: number;

  @ApiProperty()
  @Expose()
  excutionTo: number;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;
}
