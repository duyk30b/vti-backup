import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { MaterialProducingStepScheduleEntity } from '@entities/schedule/sale-order-schedule/material-producing-step-schedule.entity';

export type MaterialProducingStepScheduleRepositoryInterface =
  BaseInterfaceRepository<MaterialProducingStepScheduleEntity>;
