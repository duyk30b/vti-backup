import { GetMasterPlanByCodeRequestDto } from '../dto/request/get-master-plan-by-code.request.dto';
import { GetPlanBySoIdScheduleRequestDto } from '../dto/request/get-plan-by-so-id.request.dto';
import { GetSaleOrderScheduleDetailRequestDto } from '../dto/request/get-sale-order-schedule-detail.request.dto';
import { SaleOrderProgressReportRequestDto } from '../dto/request/sale-order-progress-report.request.dto';

export interface SaleOrderScheduleServiceInterface {
  getPlanScheduleBySoId(request: GetPlanBySoIdScheduleRequestDto): Promise<any>;
  getPlanScheduleBySoIdAndItemIds(
    request: GetSaleOrderScheduleDetailRequestDto,
  ): Promise<any>;
  getOverSchedule(request: GetSaleOrderScheduleDetailRequestDto): Promise<any>;
  getMasterPlanByCode(request: GetMasterPlanByCodeRequestDto): Promise<any>;
  saleOrderProgressReport(
    request: SaleOrderProgressReportRequestDto,
  ): Promise<any>;
}
