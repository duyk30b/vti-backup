import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { SaleOrderScheduleEntity } from '@entities/schedule/sale-order-schedule/sale-order-schedule.entity';
import { SaleOrderProgressReportRequestDto } from '../dto/request/sale-order-progress-report.request.dto';

export interface SaleOrderScheduleRepositoryInterface
  extends BaseInterfaceRepository<SaleOrderScheduleEntity> {
  createEntity(
    soId: any,
    itemSchedules: any[],
    dateFrom: any,
    dateTo: any,
  ): SaleOrderScheduleEntity;
  updateEntity(
    param: any,
    saleOrderSchedule: SaleOrderScheduleEntity,
  ): SaleOrderScheduleEntity;
  getPlanScheduleBySoIdAndItemIds(
    soId: number,
    itemIds: any[],
    isOverSchedule: boolean,
  ): Promise<any>;
  checkExistSaleOrderIdActive(
    saleOrderIds: string[],
    masterPlanId?: number,
  ): Promise<boolean>;
  getSaleOrderProgressReport(
    request: SaleOrderProgressReportRequestDto,
  ): Promise<any>;
}
