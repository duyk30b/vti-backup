import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { I18nService } from 'nestjs-i18n';
import { ItemProducingStepScheduleRepositoryInterface } from '../item-producing-step-schedule/interface/item-producing-step-schedule.repository.interface';
import { ItemScheduleRepositoryInterface } from '../item-schedule/interface/item-schedule.repository.interface';
import { MasterPlanRepositoryInterface } from '../master-plan/interface/master-plan.repository.interface';
import { WorkCenterDetailScheduleRepositoryInterface } from '../work-center-detail-schedule/interface/work-center-detail-schedule.repository.interface';
import { WorkCenterScheduleRepositoryInterface } from '../work-center-schedule/interface/work-center-schedule.repository.interface';
import { GetMasterPlanByCodeRequestDto } from './dto/request/get-master-plan-by-code.request.dto';
import { GetPlanBySoIdScheduleRequestDto } from './dto/request/get-plan-by-so-id.request.dto';
import { GetSaleOrderScheduleDetailRequestDto } from './dto/request/get-sale-order-schedule-detail.request.dto';
import { UpdateScheduleRequestDto } from './dto/request/update-schedule.request.dto';
import { GetMasterPlanByCodeResponseDto } from './dto/response/get-master-plan-by-code.response.dto';
import { GetPlanBySoIdScheduleResponseDto } from './dto/response/get-plan-by-so-id.response.dto';
import { GetSaleOrderScheduleDetailResponseDto } from './dto/response/get-sale-order-schedule-detail.response.dto';
import { SaleOrderScheduleRepositoryInterface } from './interface/sale-order-schedule.repository.interface';
import { SaleOrderScheduleServiceInterface } from './interface/sale-order-schedule.service.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { SaleServiceInterface } from '@components/sale/interface/sale.service.interface';
import { ScheduleEnum } from '@constant/common';
import { SaleOrderProgressReportRequestDto } from './dto/request/sale-order-progress-report.request.dto';
import { map, flatMap, isEmpty, uniq } from 'lodash';
import { minus } from '@utils/common';
import { SaleOrderProgressReportResponseDto } from './dto/response/sale-order-progress-report.response.dto';

@Injectable()
export class SaleOrderScheduleService
  implements SaleOrderScheduleServiceInterface
{
  constructor(
    @Inject('SaleOrderScheduleRepositoryInterface')
    private readonly saleOrderScheduleRepository: SaleOrderScheduleRepositoryInterface,

    @Inject('ItemScheduleRepositoryInterface')
    private readonly itemScheduleRepository: ItemScheduleRepositoryInterface,

    @Inject('ItemProducingStepScheduleRepositoryInterface')
    private readonly itemProducingStepScheduleRepository: ItemProducingStepScheduleRepositoryInterface,

    @Inject('WorkCenterScheduleRepositoryInterface')
    private readonly workCenterScheduleRepository: WorkCenterScheduleRepositoryInterface,

    @Inject('WorkCenterDetailScheduleRepositoryInterface')
    private readonly workCenterDetailScheduleRepository: WorkCenterDetailScheduleRepositoryInterface,

    @Inject('ProduceServiceInterface')
    private readonly produceService: ProduceServiceInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    @Inject('SaleServiceInterface')
    private readonly saleService: SaleServiceInterface,

    @Inject('MasterPlanRepositoryInterface')
    private readonly masterPlanRepository: MasterPlanRepositoryInterface,

    private readonly i18n: I18nService,
  ) {}

  async getPlanScheduleBySoId(
    request: GetPlanBySoIdScheduleRequestDto,
  ): Promise<ResponsePayload<GetPlanBySoIdScheduleResponseDto | any>> {
    const { id } = request;
    const data = await this.saleOrderScheduleRepository.findOneByCondition({
      saleOrderId: id,
    });
    const response = plainToInstance(GetPlanBySoIdScheduleResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async getPlanScheduleBySoIdAndItemIds(
    request: GetSaleOrderScheduleDetailRequestDto,
  ): Promise<ResponsePayload<GetSaleOrderScheduleDetailResponseDto | any>> {
    const { soId, itemIds } = request;
    const data =
      await this.saleOrderScheduleRepository.getPlanScheduleBySoIdAndItemIds(
        soId,
        itemIds,
        false,
      );

    const response = plainToInstance(
      GetSaleOrderScheduleDetailResponseDto,
      data,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async update(request: UpdateScheduleRequestDto, type: number): Promise<any> {
    try {
      const { id } = request;
      let response: any = null;

      // SALE_ORDER_SCHEDULE
      if (type === ScheduleEnum.SALE_ORDER_SCHEDULE) {
        const saleOrderScheduleExist =
          await this.saleOrderScheduleRepository.findOneByCondition({
            id: id,
          });
        if (!saleOrderScheduleExist) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.NOT_FOUND)
            .withMessage(
              await this.i18n.translate('error.SALE_ORDER_SCHEDULE_NOT_EXIST'),
            )
            .build();
        }
        const saleOrderScheduleEntity =
          this.saleOrderScheduleRepository.updateEntity(
            request,
            saleOrderScheduleExist,
          );
        response = await this.saleOrderScheduleRepository.update(
          saleOrderScheduleEntity,
        );
      }

      // ITEM_SCHEDULE
      if (type === ScheduleEnum.ITEM_SCHEDULE) {
        const itemScheduleExist =
          await this.itemScheduleRepository.findOneByCondition({
            id: id,
          });
        if (!itemScheduleExist) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.NOT_FOUND)
            .withMessage(
              await this.i18n.translate('error.ITEM_SCHEDULE_NOT_EXIST'),
            )
            .build();
        }
        const itemScheduleEntity = this.itemScheduleRepository.updateEntity(
          request,
          itemScheduleExist,
        );
        response = await this.itemScheduleRepository.update(itemScheduleEntity);
      }

      // ITEM_PRODUCING_STEP_SCHEDULE
      if (type === ScheduleEnum.ITEM_PRODUCING_STEP_SCHEDULE) {
        const itemProducingStepScheduleExist =
          await this.itemProducingStepScheduleRepository.findOneByCondition({
            id: id,
          });
        if (!itemProducingStepScheduleExist) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.NOT_FOUND)
            .withMessage(
              await this.i18n.translate(
                'error.ITEM_PRODUCING_STEP_SCHEDULE_NOT_EXIST',
              ),
            )
            .build();
        }
        const itemProducingStepScheduleEntity =
          this.itemProducingStepScheduleRepository.updateEntity(
            request,
            itemProducingStepScheduleExist,
          );
        response = await this.itemProducingStepScheduleRepository.update(
          itemProducingStepScheduleEntity,
        );
      }

      // WORK_CENTER_SCHEDULE
      if (type === ScheduleEnum.WORK_CENTER_SCHEDULE) {
        const workCenterScheduleExist =
          await this.workCenterScheduleRepository.findOneByCondition({
            id: id,
          });
        if (!workCenterScheduleExist) {
          const workCenterScheduleEntity =
            this.workCenterScheduleRepository.createEntity(request);
          response = await this.workCenterScheduleRepository.create(
            workCenterScheduleEntity,
          );
        } else {
          const workCenterScheduleEntity =
            this.workCenterScheduleRepository.updateEntity(
              request,
              workCenterScheduleExist,
            );
          response = await this.workCenterScheduleRepository.update(
            workCenterScheduleEntity,
          );
        }
      }

      // WORK_CENTER_DETAIL_SCHEDULE
      if (type === ScheduleEnum.WORK_CENTER_DETAIL_SCHEDULE) {
        const workCenterDetailScheduleExist =
          await this.workCenterDetailScheduleRepository.findOneByCondition({
            id: id,
          });
        if (!workCenterDetailScheduleExist) {
          const workCenterDetailScheduleEntity =
            this.workCenterDetailScheduleRepository.createEntity(request);
          response = await this.workCenterDetailScheduleRepository.create(
            workCenterDetailScheduleEntity,
          );
        } else {
          const workCenterDetailScheduleEntity =
            this.workCenterDetailScheduleRepository.updateEntity(
              request,
              workCenterDetailScheduleExist,
            );
          response = await this.workCenterDetailScheduleRepository.update(
            workCenterDetailScheduleEntity,
          );
        }
      }

      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } catch (error) {
      console.log(error);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }
  }

  async getOverSchedule(
    request: GetSaleOrderScheduleDetailRequestDto,
  ): Promise<any> {
    const data =
      await this.saleOrderScheduleRepository.getPlanScheduleBySoIdAndItemIds(
        request.soId,
        request.itemIds,
        true,
      );
    let response: any = null;
    if (data)
      response = plainToInstance(GetSaleOrderScheduleDetailResponseDto, data, {
        excludeExtraneousValues: true,
      });
    return response;
  }

  async getMasterPlanByCode(
    request: GetMasterPlanByCodeRequestDto,
  ): Promise<any> {
    const { code } = request;
    const data = await this.masterPlanRepository.findOneByCondition({
      code: code,
    });
    const response = plainToInstance(GetMasterPlanByCodeResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async saleOrderProgressReport(
    request: SaleOrderProgressReportRequestDto,
  ): Promise<any> {
    const { moIds } = request;
    let itemIds;
    if (moIds) {
      const listMo = await this.produceService.getMoByIds(moIds);
      const moPlanBoms = flatMap(listMo.map((mo) => mo.moPlanBoms));
      itemIds = moPlanBoms.map((mpb) => mpb.itemId);
    }
    if (isEmpty(request.itemIds) && !isEmpty(itemIds)) {
      request.itemIds = itemIds;
    }
    const data =
      await this.saleOrderScheduleRepository.getSaleOrderProgressReport(
        request,
      );
    itemIds = map(data, 'itemId');
    const items = await this.itemService.getItemByIds(itemIds, true);

    const calendars = flatMap(map(data, 'calendar'));
    const tempProducingSteps = flatMap(map(calendars, 'producingSteps'));
    const tempWorkCenters = flatMap(map(tempProducingSteps, 'workCenters'));
    const producingStepIds = uniq(tempProducingSteps.map((i) => i.id));
    const workCenterIds = uniq(tempWorkCenters.map((i) => i.id));

    const producingStepMap =
      await this.produceService.getListProducingStepByIds(
        producingStepIds,
        true,
      );
    const workCenterMap = await this.produceService.getWorkCenterByIds(
      workCenterIds,
      true,
    );

    const result = data.map((d) => {
      d.item = items[d.itemId];
      let totalPlanQuantity = 0;
      let totalActualQuantity = 0;
      let totalLateQuantity = 0;

      d.calendar = d.calendar?.map((calendar) => {
        totalPlanQuantity += calendar.quantity;
        totalActualQuantity += calendar.actualQuantity;
        totalLateQuantity = minus(totalPlanQuantity, totalActualQuantity);

        return {
          executionDate: calendar.executionDate,
          planQuantity: calendar.quantity,
          actualQuantity: calendar.actualQuantity,
          lateQuantity: minus(calendar.quantity, calendar.actualQuantity),
          totalPlanQuantity: totalPlanQuantity,
          totalActualQuantity: totalActualQuantity,
          totalLateQuantity: totalLateQuantity,
          producingSteps: calendar.producingSteps.map((producingStep) => {
            return {
              ...producingStep,
              code: producingStepMap[`${producingStep.id}`]?.code,
              name: producingStepMap[`${producingStep.id}`]?.name,
              workCenters: producingStep.workCenters.map((workCenter) => {
                return {
                  ...workCenter,
                  code: workCenterMap[`${workCenter.id}`]?.code,
                  name: workCenterMap[`${workCenter.id}`]?.name,
                };
              }),
            };
          }),
        };
      });

      return d;
    });

    const response = plainToInstance(
      SaleOrderProgressReportResponseDto,
      result,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder()
      .withData(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }
}
