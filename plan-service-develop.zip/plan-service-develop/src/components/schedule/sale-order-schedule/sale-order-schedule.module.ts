import { ConfigService } from '@config/config.service';
import { ItemProducingStepScheduleEntity } from '@entities/schedule/sale-order-schedule/item-producing-step-schedule.entity';
import { ItemScheduleEntity } from '@entities/schedule/sale-order-schedule/item-schedule.entity';
import { MasterPlanEntity } from '@entities/schedule/master-plan/master-plan.entity';
import { SaleOrderScheduleEntity } from '@entities/schedule/sale-order-schedule/sale-order-schedule.entity';
import { WorkCenterDetailScheduleEntity } from '@entities/schedule/work-center-schedule/work-center-detail-schedule.entity';
import { WorkCenterScheduleEntity } from '@entities/schedule/work-center-schedule/work-center-schedule.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ItemProducingStepScheduleRepository } from 'src/repository/item-producing-step-schedule.repository';
import { ItemScheduleRepository } from 'src/repository/item-schedule.repository';
import { MasterPlanRepository } from 'src/repository/master-plan.repository';
import { SaleOrderScheduleRepository } from 'src/repository/sale-order-schedule.repository';
import { WorkCenterDetailScheduleRepository } from 'src/repository/work-center-detail-schedule.repository';
import { WorkCenterScheduleRepository } from 'src/repository/work-center-schedule.repository';
import { SaleOrderScheduleController } from './sale-order-schedule.controller';
import { SaleOrderScheduleService } from './sale-order-schedule.service';
@Module({
  imports: [
    TypeOrmModule.forFeature([
      SaleOrderScheduleEntity,
      ItemScheduleEntity,
      ItemProducingStepScheduleEntity,
      WorkCenterScheduleEntity,
      WorkCenterDetailScheduleEntity,
      MasterPlanEntity,
    ]),
  ],
  controllers: [SaleOrderScheduleController],
  providers: [
    {
      provide: 'SaleOrderScheduleRepositoryInterface',
      useClass: SaleOrderScheduleRepository,
    },
    {
      provide: 'SaleOrderScheduleServiceInterface',
      useClass: SaleOrderScheduleService,
    },
    {
      provide: 'ItemScheduleRepositoryInterface',
      useClass: ItemScheduleRepository,
    },
    {
      provide: 'ItemProducingStepScheduleRepositoryInterface',
      useClass: ItemProducingStepScheduleRepository,
    },
    {
      provide: 'WorkCenterScheduleRepositoryInterface',
      useClass: WorkCenterScheduleRepository,
    },
    {
      provide: 'WorkCenterDetailScheduleRepositoryInterface',
      useClass: WorkCenterDetailScheduleRepository,
    },
    {
      provide: 'MasterPlanRepositoryInterface',
      useClass: MasterPlanRepository,
    },
    ConfigService,
  ],
  exports: [],
})
export class SaleOrderScheduleModule {}
