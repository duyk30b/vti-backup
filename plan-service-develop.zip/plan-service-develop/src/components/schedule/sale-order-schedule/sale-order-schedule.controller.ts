import { NATS_PLAN } from '@config/nats.config';
import {
  Body,
  Controller,
  Get,
  Inject,
  Injectable,
  Param,
  ParseIntPipe,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty } from 'lodash';
import { GetMasterPlanByCodeRequestDto } from './dto/request/get-master-plan-by-code.request.dto';
import { GetPlanBySoIdScheduleRequestDto } from './dto/request/get-plan-by-so-id.request.dto';
import { GetSaleOrderScheduleDetailRequestDto } from './dto/request/get-sale-order-schedule-detail.request.dto';
import { SaleOrderProgressReportQueryRequestDto } from './dto/request/sale-order-progress-report.request.dto';
import { GetMasterPlanByCodeResponseDto } from './dto/response/get-master-plan-by-code.response.dto';
import { GetPlanBySoIdScheduleResponseDto } from './dto/response/get-plan-by-so-id.response.dto';
import { GetSaleOrderScheduleDetailResponseDto } from './dto/response/get-sale-order-schedule-detail.response.dto';
import { SaleOrderProgressReportResponseDto } from './dto/response/sale-order-progress-report.response.dto';
import { SaleOrderScheduleServiceInterface } from './interface/sale-order-schedule.service.interface';

@Injectable()
@Controller('sale-order-schedules')
export class SaleOrderScheduleController {
  constructor(
    @Inject('SaleOrderScheduleServiceInterface')
    private readonly saleOrderScheduleService: SaleOrderScheduleServiceInterface,
  ) {}

  @MessagePattern(`${NATS_PLAN}.get_so_schedule_by_so_id`)
  async getPlanScheduleBySoId(
    @Body() payload: GetPlanBySoIdScheduleRequestDto,
  ): Promise<ResponsePayload<GetPlanBySoIdScheduleResponseDto | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderScheduleService.getPlanScheduleBySoId(request);
  }
  // @TODO: remove when refactor done
  @MessagePattern(`${NATS_PLAN}.get_so_schedule_by_so_id`)
  async getPlanScheduleBySoIdTcp(
    @Body() payload: GetPlanBySoIdScheduleRequestDto,
  ): Promise<ResponsePayload<GetPlanBySoIdScheduleResponseDto | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderScheduleService.getPlanScheduleBySoId(request);
  }

  @MessagePattern(`${NATS_PLAN}.get_master_plan_by_item`)
  async getPlanScheduleBySoIdAndItemIds(
    @Body() payload: GetSaleOrderScheduleDetailRequestDto,
  ): Promise<ResponsePayload<GetSaleOrderScheduleDetailResponseDto | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderScheduleService.getPlanScheduleBySoIdAndItemIds(
      request,
    );
  }
  // @TODO: remove when refactor done
  @MessagePattern(`${NATS_PLAN}.get_master_plan_by_item`)
  async getPlanScheduleBySoIdAndItemIdsTcp(
    @Body() payload: GetSaleOrderScheduleDetailRequestDto,
  ): Promise<ResponsePayload<GetSaleOrderScheduleDetailResponseDto | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderScheduleService.getPlanScheduleBySoIdAndItemIds(
      request,
    );
  }

  @MessagePattern(`${NATS_PLAN}.get_master_plan_by_code`)
  async getMasterPlanByCode(
    @Body() payload: GetMasterPlanByCodeRequestDto,
  ): Promise<ResponsePayload<GetMasterPlanByCodeResponseDto | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderScheduleService.getMasterPlanByCode(request);
  }
  // @TODO: remove when refactor done
  @MessagePattern(`${NATS_PLAN}.get_master_plan_by_code`)
  async getMasterPlanByCodeTcp(
    @Body() payload: GetMasterPlanByCodeRequestDto,
  ): Promise<ResponsePayload<GetMasterPlanByCodeResponseDto | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.saleOrderScheduleService.getMasterPlanByCode(request);
  }

  // @MessagePattern(`${NATS_PLAN}.sale_order_progress_report`)
  @Get('/sale-orders/:id/progress/report')
  @ApiOperation({
    tags: ['Sale Order'],
    summary: 'Report',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Report',
    type: SaleOrderProgressReportResponseDto,
  })
  async saleOrderProgressReport(
    @Param('id', new ParseIntPipe()) id: number,
    @Query() payload: SaleOrderProgressReportQueryRequestDto,
  ): Promise<ResponsePayload<GetMasterPlanByCodeResponseDto | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.saleOrderScheduleService.saleOrderProgressReport({
      ...request,
      id,
    });
  }
}
