import { BasicResponseDto } from '@core/dto/response/basic.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class Item extends BasicResponseDto {}

class WorkCenter {
  @Expose()
  @ApiProperty()
  id: number;

  @Expose()
  @ApiProperty()
  name: string;

  @Expose()
  @ApiProperty()
  code: string;

  @Expose()
  @ApiProperty()
  quantity: number;

  @Expose()
  @ApiProperty()
  actualQuantity: number;
}

class ProducingStep {
  @Expose()
  @ApiProperty()
  id: number;

  @Expose()
  @ApiProperty()
  name: string;

  @Expose()
  @ApiProperty()
  code: string;

  @Expose()
  @ApiProperty()
  quantity: number;

  @Expose()
  @ApiProperty()
  actualQuantity: number;

  @Expose()
  @ApiProperty({ isArray: true, type: WorkCenter })
  @IsArray()
  @Type(() => WorkCenter)
  workCenters: WorkCenter[];
}
class Calendar {
  @Expose()
  @ApiProperty()
  executionDate: string;

  @Expose()
  @ApiProperty()
  planQuantity: number;

  @Expose()
  @ApiProperty()
  actualQuantity: number;

  @Expose()
  @ApiProperty()
  lateQuantity: number;

  @Expose()
  @ApiProperty()
  totalPlanQuantity: number;

  @Expose()
  @ApiProperty()
  totalActualQuantity: number;

  @Expose()
  @ApiProperty()
  totalLateQuantity: number;

  @Expose()
  @ApiProperty({ isArray: true, type: ProducingStep })
  @IsArray()
  @Type(() => ProducingStep)
  producingSteps: ProducingStep[];
}

export class SaleOrderProgressReportResponseDto {
  @Expose()
  @ApiProperty({ type: Item })
  @Type(() => Item)
  item: Item;

  @Expose()
  @ApiProperty({ isArray: true, type: Calendar })
  @IsArray()
  @Type(() => Calendar)
  calendar: Calendar[];
}
