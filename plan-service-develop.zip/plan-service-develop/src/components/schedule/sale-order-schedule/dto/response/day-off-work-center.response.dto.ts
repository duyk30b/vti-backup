export class DayOffWorkCenterResponse {
  workCenterId: number;
  from: Date;
  to: Date;
}
