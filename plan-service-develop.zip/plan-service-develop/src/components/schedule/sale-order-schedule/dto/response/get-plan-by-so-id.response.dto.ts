import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class GetPlanBySoIdScheduleResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  saleOrderId: string;

  @ApiProperty()
  @Expose()
  dateFrom: Date;

  @ApiProperty()
  @Expose()
  dateTo: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;
}
