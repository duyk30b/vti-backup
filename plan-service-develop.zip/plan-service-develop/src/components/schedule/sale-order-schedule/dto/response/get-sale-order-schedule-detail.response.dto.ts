import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class WorkCenterDetailSchedule {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  workCenterScheduleId: number;

  @ApiProperty()
  @Expose()
  workCenterShiftScheduleId: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  errorQuantity: number;

  @ApiProperty()
  @Expose()
  excutionFrom: number;

  @ApiProperty()
  @Expose()
  excutionTo: number;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;
}

class WorkCenterSchedule {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  workCenterId: number;

  @ApiProperty()
  @Expose()
  itemProducingStepScheduleId: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  errorQuantity: number;

  @ApiProperty()
  @Expose()
  excutionDate: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: WorkCenterDetailSchedule })
  @Type(() => WorkCenterDetailSchedule)
  @Expose()
  workCenterDetailSchedules: WorkCenterDetailSchedule[];
}

class ItemProducingStepSchedule {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemScheduleId: number;

  @ApiProperty()
  @Expose()
  producingStepId: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  errorQuantity: number;

  @ApiProperty()
  @Expose()
  dateFrom: Date;

  @ApiProperty()
  @Expose()
  dateTo: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: WorkCenterSchedule })
  @Type(() => WorkCenterSchedule)
  @Expose()
  workCenterSchedules: WorkCenterSchedule[];
}

class ItemSchedule {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  saleOrderScheduleId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  bomId: number;

  @ApiProperty()
  @Expose()
  parentBomId: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  errorQuantity: number;

  @ApiProperty()
  @Expose()
  overQuantity: number;

  @ApiProperty()
  @Expose()
  stepNumber: number;

  @ApiProperty()
  @Expose()
  dateFrom: Date;

  @ApiProperty()
  @Expose()
  dateTo: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: ItemProducingStepSchedule })
  @Type(() => ItemProducingStepSchedule)
  @Expose()
  itemProducingStepSchedules: ItemProducingStepSchedule[];
}

export class GetSaleOrderScheduleDetailResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  saleOrderId: string;

  @ApiProperty()
  @Expose()
  dateFrom: Date;

  @ApiProperty()
  @Expose()
  dateTo: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: ItemSchedule })
  @Type(() => ItemSchedule)
  @Expose()
  itemSchedules: ItemSchedule[];
}
