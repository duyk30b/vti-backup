import { BaseDto } from '@core/dto/base.dto';
import { Transform } from 'class-transformer';
import { IsDateString, IsInt, IsMongoId, IsNotEmpty } from 'class-validator';
import moment from 'moment';

export class ModerationEvenlyRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsInt()
  masterPlanId: number;

  @IsNotEmpty()
  @IsMongoId()
  saleOrderId: string;

  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @IsNotEmpty()
  @IsInt()
  itemProducingStepId: number;

  @IsNotEmpty()
  @IsDateString()
  dateFrom: Date;

  @IsNotEmpty()
  @IsDateString()
  dateTo: Date;
}
