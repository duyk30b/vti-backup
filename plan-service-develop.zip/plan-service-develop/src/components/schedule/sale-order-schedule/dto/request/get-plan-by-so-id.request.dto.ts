import { BaseDto } from '@core/dto/base.dto';
import { Expose } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';

export class GetPlanBySoIdScheduleRequestDto extends BaseDto {
  @Expose()
  @IsInt()
  @IsNotEmpty({ message: 'id không được trống' })
  id: number;
}
