import { Expose } from 'class-transformer';
import { IsDateString, IsInt, IsNotEmpty } from 'class-validator';

export class UpdateScheduleRequestDto {
  @Expose()
  @IsInt()
  @IsNotEmpty()
  id: number;

  @Expose()
  @IsInt()
  workCenterId?: number;

  @Expose()
  @IsInt()
  workCenterShiftScheduleId?: number;

  @Expose()
  @IsDateString()
  dateFrom?: Date;

  @Expose()
  @IsDateString()
  dateTo?: Date;

  @Expose()
  @IsDateString()
  excutionDate?: Date;

  @Expose()
  @IsInt()
  quantity?: number;
}
