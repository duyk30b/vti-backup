import { UpdateProducingStepScheduleDto } from '@components/schedule/master-plan/dto/other/update-producing-step-schedule.dto';
import { BaseDto } from '@core/dto/base.dto';
import { Expose, Type } from 'class-transformer';
import {
  IsArray,
  IsInt,
  IsNotEmpty,
  ValidateNested,
  IsOptional,
} from 'class-validator';

export class ModerationInputBodyRequestDto extends BaseDto {}
export class ModerationInputRequestDto extends ModerationInputBodyRequestDto {
  @Expose()
  @IsOptional()
  @IsInt()
  id: number;

  @Expose()
  @IsArray()
  @IsNotEmpty()
  @Type(() => UpdateProducingStepScheduleDto)
  @ValidateNested({ each: true })
  producingStepSchedules: UpdateProducingStepScheduleDto[];
}
