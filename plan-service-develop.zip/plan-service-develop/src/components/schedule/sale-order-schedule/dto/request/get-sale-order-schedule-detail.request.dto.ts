import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsArray,
  IsDate,
  IsInt,
  IsNotEmpty,
  IsOptional,
} from 'class-validator';

export class GetSaleOrderScheduleDetailRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty({ message: 'SoId không được trống' })
  soId: number;

  @ApiPropertyOptional({ type: Number })
  @IsArray()
  itemIds?: number[];

  @ApiProperty()
  @IsDate()
  @IsOptional()
  planFrom: Date;

  @ApiProperty()
  @IsDate()
  @IsOptional()
  planTo: Date;
}
