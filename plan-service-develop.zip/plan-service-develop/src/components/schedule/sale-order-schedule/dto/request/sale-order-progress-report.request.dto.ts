import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsDateString, IsOptional } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { Transform } from 'class-transformer';

export class SaleOrderProgressReportQueryRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @Transform(({ value }) => value.split(',').map((id) => Number(id)))
  moIds: number[];

  @ApiProperty()
  @IsOptional()
  @Transform(({ value }) => value.split(',').map((id) => Number(id)))
  itemIds: number[];

  @ApiProperty()
  @IsOptional()
  @Transform(({ value }) => value.split(',').map((id) => Number(id)))
  producingStepIds: number[];

  @ApiProperty()
  @IsOptional()
  @Transform(({ value }) => value.split(',').map((id) => Number(id)))
  workCenterIds: number[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  dateFrom: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  dateTo: string;
}
export class SaleOrderProgressReportRequestDto extends SaleOrderProgressReportQueryRequestDto {
  @ApiProperty()
  @IsOptional()
  id: number;
}
