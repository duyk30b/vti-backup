import { BaseDto } from '@core/dto/base.dto';
import { Expose, Type } from 'class-transformer';
import {
  IsArray,
  IsDateString,
  IsInt,
  IsMilitaryTime,
  IsMongoId,
  IsNotEmpty,
  IsNumber,
  IsNumberString,
  IsObject,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';

class SaleOrderDetail {
  @Expose()
  @IsInt()
  @IsNotEmpty({ message: 'itemId không được trống' })
  itemId: number;

  @Expose()
  @IsNotEmpty({ message: 'quantity không được trống' })
  quantity: number;

  @Expose()
  @IsNotEmpty({ message: 'quantity không được trống' })
  actualQuantity: number;
}

class SaleOrder {
  @Expose()
  @IsMongoId()
  @IsNotEmpty({ message: 'saleOrderId không được trống' })
  id: string;

  @Expose()
  @IsDateString()
  @IsNotEmpty({ message: 'deadline không được trống' })
  deadline: string;

  @Expose()
  @Type(() => SaleOrderDetail)
  @IsArray()
  soDetails: SaleOrderDetail[];
}
class ProducingStep {
  @Expose()
  @IsInt()
  @IsNotEmpty({ message: 'producingStepId không được trống' })
  producingStepId: number;

  @Expose()
  @IsNumber()
  @IsNotEmpty({ message: 'productionTimePerItem không được trống' })
  productionTimePerItem: number;
}
class BomDetail {
  @Expose()
  @IsInt()
  @IsNotEmpty({ message: 'itemId không được trống' })
  itemId: number;

  @Expose()
  @IsInt()
  @IsNotEmpty({ message: 'quantity không được trống' })
  quantity: number;
}

class WorkCenterShiftRelaxTime {
  @Expose()
  @IsInt()
  @IsNotEmpty({ message: 'id không được trống' })
  id: number;

  @Expose()
  @IsString()
  @IsNotEmpty({ message: 'name không được trống' })
  name: string;

  @Expose()
  @IsMilitaryTime({
    message: 'Thời gian bắt đầu ca không được trống và có định dạng là HH/MM',
  })
  @IsNotEmpty({ message: 'startAt không được trống' })
  startAt: string;

  @Expose()
  @IsMilitaryTime({
    message: 'Thời gian kết thúc ca không được trống và có định dạng là HH/MM',
  })
  @IsNotEmpty({ message: 'endAt không được trống' })
  endAt: string;
}

class WorkCenterShift {
  @Expose()
  @IsInt()
  @IsNotEmpty({ message: 'id không được trống' })
  id: number;

  @Expose()
  @IsString()
  @IsNotEmpty({ message: 'name không được trống' })
  name: string;

  @Expose()
  @IsNotEmpty({ message: 'startAt không được trống' })
  @IsMilitaryTime({
    message: 'Thời gian bắt đầu ca không được trống và có định dạng là HH/MM',
  })
  startAt: string;

  @Expose()
  @IsNotEmpty({ message: 'endAt không được trống' })
  @IsMilitaryTime({
    message: 'Thời gian kết thúc ca không được trống và có định dạng là HH/MM',
  })
  endAt: string;

  @Expose()
  @IsInt()
  @IsNotEmpty({ message: 'pricePerHour không được trống' })
  pricePerHour: number;

  @Expose()
  @Type(() => WorkCenterShiftRelaxTime)
  @IsArray()
  @IsNotEmpty({ message: 'workCenterShiftRelaxTime không được trống' })
  workCenterShiftRelaxTime: WorkCenterShiftRelaxTime[];
}
class WorkCenters {
  @Expose()
  @IsInt()
  @IsNotEmpty({ message: 'id không được trống' })
  id: number;

  @Expose()
  @IsString()
  @IsNotEmpty({ message: 'name không được trống' })
  name: string;

  @Expose()
  @IsNumberString()
  @IsNotEmpty({ message: 'productivityIndex không được trống' })
  productivityIndex: number;

  @Expose()
  @IsInt()
  @IsNotEmpty({ message: 'producingStepId không được trống' })
  producingStepId: number;

  @Expose()
  @Type(() => WorkCenterShift)
  @IsArray()
  @IsNotEmpty({ message: 'workCenterShift không được trống' })
  workCenterShift: WorkCenterShift[];
}

class Bom {
  @Expose()
  @IsInt()
  @IsNotEmpty({ message: 'bomId không được trống' })
  bomId: number;

  @Expose()
  @IsInt()
  @IsNotEmpty({ message: 'routingId không được trống' })
  routingId: number;

  @Expose()
  @IsInt()
  @IsNotEmpty({ message: 'itemId không được trống' })
  itemId: number;

  @Expose()
  quantity: any;

  @Expose()
  @IsInt()
  @IsNotEmpty({ message: 'stepNumber không được trống' })
  stepNumber: number;

  @Expose()
  @Type(() => BomDetail)
  @IsArray()
  @IsNotEmpty({ message: 'sub không được trống' })
  sub: BomDetail[];

  @Expose()
  @Type(() => ProducingStep)
  @IsArray()
  @IsNotEmpty({ message: 'proStep không được trống' })
  proStep: ProducingStep[];

  @Expose()
  @Type(() => Bom)
  @IsArray()
  @IsNotEmpty({ message: 'subBom không được trống' })
  subBom: Bom[];
}

export class SaleOrderScheduleRequestDto extends BaseDto {
  @Expose()
  @Type(() => SaleOrder)
  @IsObject()
  @IsNotEmpty({ message: 'So không được trống' })
  so: SaleOrder;

  @Expose()
  @Type(() => Bom)
  @IsArray()
  @IsNotEmpty({ message: 'boms không được trống' })
  boms: Bom[];

  @Expose()
  @Type(() => WorkCenters)
  @IsArray()
  @IsNotEmpty({ message: 'workCenters không được trống' })
  workCenters: WorkCenters[];

  @Expose()
  @IsNotEmpty()
  @IsInt()
  factoryId: number;

  @Expose()
  @IsNotEmpty()
  @MaxLength(20)
  @IsString()
  code: string;

  @Expose()
  @IsNotEmpty()
  @MaxLength(255)
  @IsString()
  name: string;

  @Expose()
  @IsOptional()
  @MaxLength(255)
  description?: string;

  @Expose()
  @IsNotEmpty()
  @IsDateString()
  dateFrom: string;

  @Expose()
  @IsNotEmpty()
  @IsDateString()
  dateTo: string;

  @Expose()
  @IsNotEmpty()
  @IsDateString()
  dateFromSo: string;

  @Expose()
  @IsNotEmpty()
  @IsInt()
  dateCompletion: number;
}
