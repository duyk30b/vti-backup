import { BaseDto } from '@core/dto/base.dto';
import { Expose } from 'class-transformer';
import { IsNotEmpty, IsString, MaxLength, IsInt } from 'class-validator';

export class GetMasterPlanByCodeRequestDto extends BaseDto {
  @Expose()
  @IsString()
  @MaxLength(20)
  @IsNotEmpty({ message: 'code không được trống' })
  code: string;
}
export class GetMasterPlanByIdRequestDto extends BaseDto {
  @Expose()
  @IsInt()
  id: number;
}
