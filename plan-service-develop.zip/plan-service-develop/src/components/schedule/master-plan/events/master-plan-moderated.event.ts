export class MasterPlanModeratedEvent {
  constructor({ id }) {
    this.id = id;
  }

  id: number;
}
