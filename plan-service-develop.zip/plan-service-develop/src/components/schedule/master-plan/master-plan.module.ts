import { ConfigService } from '@config/config.service';
import { ItemProducingStepScheduleEntity } from '@entities/schedule/sale-order-schedule/item-producing-step-schedule.entity';
import { ItemScheduleEntity } from '@entities/schedule/sale-order-schedule/item-schedule.entity';
import { MasterPlanEntity } from '@entities/schedule/master-plan/master-plan.entity';
import { SaleOrderScheduleEntity } from '@entities/schedule/sale-order-schedule/sale-order-schedule.entity';
import { WorkCenterDetailScheduleEntity } from '@entities/schedule/work-center-schedule/work-center-detail-schedule.entity';
import { WorkCenterScheduleEntity } from '@entities/schedule/work-center-schedule/work-center-schedule.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ItemProducingStepScheduleRepository } from 'src/repository/item-producing-step-schedule.repository';
import { ItemScheduleRepository } from 'src/repository/item-schedule.repository';
import { MasterPlanRepository } from 'src/repository/master-plan.repository';
import { SaleOrderScheduleRepository } from 'src/repository/sale-order-schedule.repository';
import { WorkCenterDetailScheduleRepository } from 'src/repository/work-center-detail-schedule.repository';
import { WorkCenterScheduleRepository } from 'src/repository/work-center-schedule.repository';
import { MasterPlanController } from './master-plan.controller';
import { MasterPlanService } from './master-plan.service';
import { ItemManufacturingOrderEntity } from '@entities/schedule/sale-order-schedule/item-manufacturing-order.entity';
import { ItemManufacturingOrderRepository } from 'src/repository/item-manufacturing-order.repository';
import { ProduceService } from '@components/produce/produce.service';
import { MasterPlanCreateScheduleListener } from './listeners/master-plan-create-schedule.listener';
import { MaterialProducingStepScheduleEntity } from '@entities/schedule/sale-order-schedule/material-producing-step-schedule.entity';
import { WarehouseService } from '@components/warehouse/warehouse.service';
import { MaterialProducingStepScheduleRepository } from 'src/repository/material-producing-step-schedule.repository';
import { RequestService } from '@components/request/request.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      MasterPlanEntity,
      SaleOrderScheduleEntity,
      ItemScheduleEntity,
      ItemProducingStepScheduleEntity,
      WorkCenterScheduleEntity,
      WorkCenterDetailScheduleEntity,
      ItemManufacturingOrderEntity,
      MaterialProducingStepScheduleEntity,
    ]),
  ],
  controllers: [MasterPlanController],
  providers: [
    {
      provide: 'MasterPlanServiceInterface',
      useClass: MasterPlanService,
    },
    {
      provide: 'ProduceServiceInterface',
      useClass: ProduceService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'MasterPlanRepositoryInterface',
      useClass: MasterPlanRepository,
    },
    {
      provide: 'SaleOrderScheduleRepositoryInterface',
      useClass: SaleOrderScheduleRepository,
    },
    {
      provide: 'ItemScheduleRepositoryInterface',
      useClass: ItemScheduleRepository,
    },
    {
      provide: 'ItemManufacturingOrderRepositoryInterface',
      useClass: ItemManufacturingOrderRepository,
    },
    {
      provide: 'ItemProducingStepScheduleRepositoryInterface',
      useClass: ItemProducingStepScheduleRepository,
    },
    {
      provide: 'WorkCenterScheduleRepositoryInterface',
      useClass: WorkCenterScheduleRepository,
    },
    {
      provide: 'WorkCenterDetailScheduleRepositoryInterface',
      useClass: WorkCenterDetailScheduleRepository,
    },
    {
      provide: 'RequestServiceInterface',
      useClass: RequestService,
    },
    {
      provide: 'MaterialProducingStepScheduleRepositoryInterface',
      useClass: MaterialProducingStepScheduleRepository,
    },
    ConfigService,
    MasterPlanCreateScheduleListener,
  ],
  exports: [],
})
export class MasterPlanModule {}
