import { GetMasterPlanByIdRequestDto } from '@components/schedule/sale-order-schedule/dto/request/get-master-plan-by-code.request.dto';
import { ModerationEvenlyRequestDto } from '@components/schedule/sale-order-schedule/dto/request/moderation-evenly.request.dto';
import { ModerationInputRequestDto } from '@components/schedule/sale-order-schedule/dto/request/moderation-input.request.dto';
import { ChangeStatusRequestDto } from '../dto/request/change-status.request.dto';
import { CreateMasterPlanRequestDto } from '../dto/request/create-master-plan.dto';
import { ManufacturingOrderConfirmedEvent } from '../dto/request/event/manufacturing-order-confirmed.event.request.dto';
import {
  UpdateMasterPlanActualQuantityRequestDto,
  UpdateMasterPlanItemScheduleActualQuantityRequestDto,
} from '../dto/request/event/update-master-plan-actual-quantiy.request.dto';
import { GetDetailItemProducingStepRequestDto } from '../dto/request/get-detail-item-producing-step.request.dto';
import { GetMasterPlanDetailRequestDto } from '../dto/request/get-master-plan-detail.request.dto';
import { GetMasterPlanRequestDto } from '../dto/request/get-master-plan.request.dto';
import { GetMOByMasterPlanRequestDto } from '../dto/request/get-mo-by-master-plan.request.dto';
import { SuggestModerationInputRequestDto } from '../dto/request/suggest-moderation-input.request.dto';
import { UpdateMasterPlanRequestDto } from '../dto/request/update-master-plan.dto';

export interface MasterPlanServiceInterface {
  create(request: CreateMasterPlanRequestDto): Promise<any>;
  update(request: UpdateMasterPlanRequestDto): Promise<any>;
  detail(request: GetMasterPlanDetailRequestDto): Promise<any>;
  getById(request: GetMasterPlanByIdRequestDto): Promise<any>;
  delete(id: number): Promise<any>;
  getMasterPlans(request: GetMasterPlanRequestDto): Promise<any>;
  approve(request: ChangeStatusRequestDto): Promise<any>;
  reject(request: ChangeStatusRequestDto): Promise<any>;
  submitModerationEvenly(request: ModerationEvenlyRequestDto): Promise<any>;
  submitExtendDeadlineModeration(
    request: ModerationEvenlyRequestDto,
  ): Promise<any>;
  previewModerationEvenly(request: ModerationEvenlyRequestDto): Promise<any>;
  moderationInputCapacity(request: ModerationInputRequestDto): Promise<any>;
  createPlan(soId: number): Promise<any>;
  getDetailItemsProducingStep(
    request: GetDetailItemProducingStepRequestDto,
  ): Promise<any>;
  suggestCustomModerations(
    request: GetDetailItemProducingStepRequestDto,
  ): Promise<any>;
  suggestModerationInput(
    request: SuggestModerationInputRequestDto,
  ): Promise<any>;
  getDetailFlatItems(request: GetMasterPlanDetailRequestDto): Promise<any>;
  manufacturingOrderConfirmedEvent(
    request: ManufacturingOrderConfirmedEvent,
  ): Promise<any>;
  getScheduleMasterPlan(request: GetMasterPlanDetailRequestDto): Promise<any>;
  updateMasterPlanActualQuantity(
    request: UpdateMasterPlanActualQuantityRequestDto,
  ): Promise<any>;
  updateMasterPlanItemScheduleActualQuantity(
    request: UpdateMasterPlanItemScheduleActualQuantityRequestDto,
  ): Promise<any>;
  getMOByMasterPlan(request: GetMOByMasterPlanRequestDto): Promise<any>;
}
