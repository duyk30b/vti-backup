import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ItemManufacturingOrderEntity } from '@entities/schedule/sale-order-schedule/item-manufacturing-order.entity';

export type ItemManufacturingOrderRepositoryInterface =
  BaseInterfaceRepository<ItemManufacturingOrderEntity>;
