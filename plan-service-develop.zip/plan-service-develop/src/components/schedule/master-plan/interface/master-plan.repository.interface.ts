import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { MasterPlanEntity } from '@entities/schedule/master-plan/master-plan.entity';

export interface MasterPlanRepositoryInterface
  extends BaseInterfaceRepository<MasterPlanEntity> {
  createEntity(param: any): MasterPlanEntity;
  updateEntity(param: any, masterPlan: MasterPlanEntity): MasterPlanEntity;
  getMasterPlans(params: any): Promise<any>;
  getDetailMasterPlan(params: any): Promise<any>;
}
