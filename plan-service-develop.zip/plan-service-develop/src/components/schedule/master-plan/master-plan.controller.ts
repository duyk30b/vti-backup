import { NATS_PLAN } from '@config/nats.config';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Injectable,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { GetMasterPlanByIdRequestDto } from '../sale-order-schedule/dto/request/get-master-plan-by-code.request.dto';
import { ModerationEvenlyRequestDto } from '../sale-order-schedule/dto/request/moderation-evenly.request.dto';
import {
  ModerationInputBodyRequestDto,
  ModerationInputRequestDto,
} from '../sale-order-schedule/dto/request/moderation-input.request.dto';
import { GetMasterPlanByCodeResponseDto } from '../sale-order-schedule/dto/response/get-master-plan-by-code.response.dto';
import { ChangeStatusQueryRequestDto } from './dto/request/change-status.request.dto';
import { CreateMasterPlanRequestDto } from './dto/request/create-master-plan.dto';
import {
  ManufacturingOrderConfirmedEvent,
  ManufacturingOrderConfirmedEventBodyDto,
} from './dto/request/event/manufacturing-order-confirmed.event.request.dto';
import {
  UpdateMasterPlanActualQuantityRequestDto,
  UpdateMasterPlanItemScheduleActualQuantityRequestDto,
} from './dto/request/event/update-master-plan-actual-quantiy.request.dto';
import { GetDetailItemProducingStepQueryRequestDto } from './dto/request/get-detail-item-producing-step.request.dto';
import {
  GetMasterPlanDetailQueryRequestDto,
  GetMasterPlanDetailRequestDto,
} from './dto/request/get-master-plan-detail.request.dto';
import { GetMasterPlanRequestDto } from './dto/request/get-master-plan.request.dto';
import { GetMOByMasterPlanRequestDto } from './dto/request/get-mo-by-master-plan.request.dto';
import { SuggestModerationInputQueryRequestDto } from './dto/request/suggest-moderation-input.request.dto';
import { UpdateMasterPlanBodyRequestDto } from './dto/request/update-master-plan.dto';
import {
  GetMasterPlanResponseDto,
  MasterPlanResponseDto,
} from './dto/response/get-master-plan.response.dto';
import { MasterPlanServiceInterface } from './interface/master-plan.service.interface';

@Injectable()
@Controller('')
export class MasterPlanController {
  constructor(
    @Inject('MasterPlanServiceInterface')
    private readonly masterPlanService: MasterPlanServiceInterface,
  ) {}

  // @MessagePattern(`${NATS_PLAN}.approve_master_plan`)
  @Put('master-plans/:id/approve')
  @ApiOperation({
    tags: ['Plans', 'Master Plan'],
    summary: 'Xác nhận kế hoạch',
    description: 'Xác nhận kế hoạch',
  })
  @ApiResponse({
    status: 200,
    description: 'Update status master plan success',
    type: SuccessResponse,
  })
  async approve(
    @Query() payload: ChangeStatusQueryRequestDto,
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.approve({ ...request, id });
  }

  // @MessagePattern(`${NATS_PLAN}.delete_master_plan`)
  @Delete('master-plans/:id')
  @ApiOperation({
    tags: ['Delete', 'Master Plan'],
    summary: '',
    description: 'Delete master plan by id',
  })
  @ApiResponse({
    status: 200,
    description: 'Get master plan successfully',
    type: SuccessResponse,
  })
  async delete(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<ResponsePayload<any>> {
    return await this.masterPlanService.delete(id);
  }

  // @MessagePattern(`${NATS_PLAN}.reject_master_plan`)
  @Put('master-plans/:id/reject')
  @ApiOperation({
    tags: ['Plans', 'Master Plan'],
    summary: 'Reject kế hoạch',
    description: 'Reject kế hoạch',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject Master Plan Success',
    type: SuccessResponse,
  })
  async reject(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: ChangeStatusQueryRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.reject({ ...request, id });
  }

  // @MessagePattern(`${NATS_PLAN}.create_master_plan`)
  @Post('master-plans/create')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'create master plan',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async createMasterPlan(
    @Body() payload: CreateMasterPlanRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.create(request);
  }

  // @MessagePattern(`${NATS_PLAN}.update_master_plan`)
  @Put('master-plans/:id')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'update master plan',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  public async updateMasterPlan(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() payload: UpdateMasterPlanBodyRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.update({ ...request, id });
  }

  // @MessagePattern(`${NATS_PLAN}.get_master_plans`)
  @Get('/master-plans')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'get list master plan',
  })
  @ApiResponse({
    status: 200,
    description: 'Get master plan successfully',
    type: GetMasterPlanResponseDto,
  })
  async getMasterPlans(
    @Query() payload: GetMasterPlanRequestDto,
  ): Promise<ResponsePayload<GetMasterPlanResponseDto | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.getMasterPlans(request);
  }

  // @MessagePattern(`${NATS_PLAN}.get_master_plan`)
  @Get('master-plans/:masterPlanId')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'get master plan by id',
  })
  @ApiResponse({
    status: 200,
    description: 'Get master plan successfully',
    type: MasterPlanResponseDto,
  })
  async getMasterPlan(
    @Param('masterPlanId', new ParseIntPipe()) masterPlanId: number,
    @Query() payload: GetMasterPlanDetailQueryRequestDto,
  ): Promise<ResponsePayload<GetMasterPlanResponseDto | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.detail({ ...request, masterPlanId });
  }

  @Post('/moderations/evenly')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Submit Điều độ lùi ngày',
  })
  @ApiResponse({
    status: 200,
    description: 'Moderation spread successfully',
  })
  async submitModerationEvenly(
    @Body() payload: ModerationEvenlyRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.submitExtendDeadlineModeration(request);
  }

  @MessagePattern(`${NATS_PLAN}.preview_moderation_evenly`)
  async previewModerationEvenlyTcp(
    @Body() payload: ModerationEvenlyRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.masterPlanService.previewModerationEvenly(request);
  }

  @Post('/moderations/evenly/preview')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Preview Điều độ lùi ngày',
  })
  @ApiResponse({
    status: 200,
    description: 'Moderation spread successfully',
  })
  // @MessagePattern(`${NATS_PLAN}.preview_moderation_evenly`)
  async previewModerationEvenly(
    @Body() payload: ModerationEvenlyRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.masterPlanService.previewModerationEvenly(request);
  }

  // @MessagePattern(`${NATS_PLAN}.moderation_input`)
  @Post('master-plans/:id/moderations/input')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Điều độ nhập quantity',
  })
  @ApiResponse({
    status: 200,
    description: 'Moderation input successfully',
    type: ModerationInputRequestDto,
  })
  async moderationInput(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() payload: ModerationInputBodyRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.masterPlanService.moderationInputCapacity({
      ...request,
      id,
    });
  }

  // @MessagePattern(`${NATS_PLAN}.create_schedule`)
  @Get('/create-schedule/:id')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Suggest Điều độ nhập quantity',
  })
  @ApiResponse({
    status: 200,
    description: 'Moderation input successfully',
    type: ModerationInputRequestDto,
  })
  async createSchedule(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    return await this.masterPlanService.createPlan(id);
  }

  // @MessagePattern(`${NATS_PLAN}.get_detail_item_producing_step`)
  @Get('master-plans/:masterPlanId/items-producing-step/detail')
  @ApiOperation({
    tags: ['Plan', 'PLAN'],
    summary: '',
    description: 'Get detail item producing step',
  })
  @ApiResponse({
    status: 200,
    description: 'Moderation input successfully',
    type: ModerationInputRequestDto,
  })
  async getDetailItemsProducingStep(
    @Param('masterPlanId', new ParseIntPipe()) masterPlanId: number,
    @Query() payload: GetDetailItemProducingStepQueryRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.getDetailItemsProducingStep({
      ...request,
      masterPlanId,
    });
  }

  @Get('master-plans/:masterPlanId/moderations/suggest-custom')
  @ApiOperation({
    tags: ['Plan', 'PLAN'],
    summary: '',
    description: 'Suggest custom moderation',
  })
  @ApiResponse({
    status: 200,
    description: 'Moderation input successfully',
    type: ModerationInputRequestDto,
  })
  async suggestCustomModerations(
    @Param('masterPlanId', new ParseIntPipe()) masterPlanId: number,
    @Query() payload: GetDetailItemProducingStepQueryRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.suggestCustomModerations({
      ...request,
      masterPlanId,
    });
  }

  // @MessagePattern(`${NATS_PLAN}.suggest_moderation_input`)
  @Get('master-plans/:masterPlanId/moderations/suggest-spread')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Suggest Điều độ nhập quantity',
  })
  @ApiResponse({
    status: 200,
    description: 'Moderation input successfully',
    type: ModerationInputRequestDto,
  })
  async suggestModerationInput(
    @Param('masterPlanId', new ParseIntPipe()) masterPlanId: number,
    @Query() payload: SuggestModerationInputQueryRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.suggestModerationInput({
      ...request,
      masterPlanId,
    });
  }

  // @MessagePattern(`${NATS_PLAN}.get_master_plan_flat_items`)
  @Get('master-plans/:masterPlanId/flat-items')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'get master plan by id flat items',
  })
  @ApiResponse({
    status: 200,
    description: 'Get master plan successfully',
    type: MasterPlanResponseDto,
  })
  async getDetailFlatItem(
    @Param('masterPlanId', new ParseIntPipe()) masterPlanId: number,
    @Query() payload: GetMasterPlanDetailQueryRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.getDetailFlatItems({
      ...request,
      masterPlanId,
    });
  }

  // @MessagePattern(`${NATS_PLAN}.manufacturing_order_confirmed_event`)
  @Put('master-plans/:id/events/manufacturing-orders/confirmed')
  @ApiOperation({
    tags: ['PLAN'],
    summary: '',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  async manufacturingOrderConfirmedEvent(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() payload: ManufacturingOrderConfirmedEventBodyDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.manufacturingOrderConfirmedEvent({
      ...request,
      id,
    });
  }

  @MessagePattern(`${NATS_PLAN}.get_master_plan_by_id`)
  async getMasterPlanById(
    @Body() payload: GetMasterPlanByIdRequestDto,
  ): Promise<ResponsePayload<GetMasterPlanByCodeResponseDto | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.getById(request);
  }
  // @TODO: remove when refactor done
  @MessagePattern(`${NATS_PLAN}.get_master_plan_by_id`)
  async getMasterPlanByIdTcp(
    @Body() payload: GetMasterPlanByIdRequestDto,
  ): Promise<ResponsePayload<GetMasterPlanByCodeResponseDto | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.getById(request);
  }

  // @MessagePattern(`${NATS_PLAN}.get_schedule_master_plan`)
  @Get('master-plans/:id/schedule')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'get master plan by id',
  })
  @ApiResponse({
    status: 200,
    description: 'Get master plan successfully',
    type: MasterPlanResponseDto,
  })
  async getScheduleMasterPlan(
    @Param('id', new ParseIntPipe()) id: number,
    @Query() payload: GetMasterPlanDetailQueryRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.getScheduleMasterPlan({
      ...request,
      masterPlanId: id,
    });
  }

  @MessagePattern(
    `${NATS_PLAN}.update_item_producing_step_schedule_actual_quantity`,
  )
  async updateItemProducingStepScheduleActualQuantity(
    @Body() payload: UpdateMasterPlanActualQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.updateMasterPlanActualQuantity(request);
  }
  // @TODO: remove when refactor done
  @MessagePattern(
    `${NATS_PLAN}.update_item_producing_step_schedule_actual_quantity`,
  )
  async updateItemProducingStepScheduleActualQuantityTcp(
    @Body() payload: UpdateMasterPlanActualQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.updateMasterPlanActualQuantity(request);
  }

  @MessagePattern(`${NATS_PLAN}.update_item_schedule_actual_quantity`)
  async updateItemScheduleActualQuantity(
    @Body() payload: UpdateMasterPlanItemScheduleActualQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.updateMasterPlanItemScheduleActualQuantity(
      request,
    );
  }
  // @TODO: remove when refactor done
  @MessagePattern(`${NATS_PLAN}.update_item_schedule_actual_quantity`)
  async updateItemScheduleActualQuantityTcp(
    @Body() payload: UpdateMasterPlanItemScheduleActualQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.updateMasterPlanItemScheduleActualQuantity(
      request,
    );
  }

  // @MessagePattern(`${NATS_PLAN}.get_mo_by_master_plan`)
  async getMOByMasterPlan(
    @Body() payload: GetMOByMasterPlanRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.getMOByMasterPlan(request);
  }
  // @TODO: remove when refactor done
  @MessagePattern(`${NATS_PLAN}.get_mo_by_master_plan`)
  async getMOByMasterPlanTcp(
    @Body() payload: GetMOByMasterPlanRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.getMOByMasterPlan(request);
  }

  //TODO remove when refactor done
  @MessagePattern(`${NATS_PLAN}.get_master_plans`)
  async getMasterPlansTcp(
    @Body() payload: GetMasterPlanRequestDto,
  ): Promise<ResponsePayload<GetMasterPlanResponseDto | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.getMasterPlans(request);
  }

  @MessagePattern(`${NATS_PLAN}.get_master_plan_flat_items`)
  async getDetailFlatItemTcp(
    @Body() payload: GetMasterPlanDetailRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.getDetailFlatItems({
      ...request,
    });
  }

  @MessagePattern(`${NATS_PLAN}.manufacturing_order_confirmed_event`)
  async manufacturingOrderConfirmedEventTcp(
    @Body() payload: ManufacturingOrderConfirmedEvent,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.masterPlanService.manufacturingOrderConfirmedEvent(
      request,
    );
  }
}
