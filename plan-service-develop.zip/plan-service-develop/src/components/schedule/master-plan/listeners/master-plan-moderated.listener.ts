import { ProduceService } from '@components/produce/produce.service';
import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';

@Injectable()
export class MasterPlanModeratedListener {
  constructor(
    @Inject('ProduceServiceInterface')
    protected readonly produceService: ProduceService,
  ) {}

  @OnEvent('master-plan.moderated')
  public async moderatedHanlder(data) {
    const { id } = data;

    await this.produceService.handlerMasterPlanModerated(id);
  }
}
