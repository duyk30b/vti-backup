import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { MasterPlanServiceInterface } from '../interface/master-plan.service.interface';

@Injectable()
export class MasterPlanCreateScheduleListener {
  constructor(
    @Inject('MasterPlanServiceInterface')
    protected readonly masterPlanService: MasterPlanServiceInterface,
  ) {}

  @OnEvent('master-plan.create-schedule')
  public async createSchedule(id: number) {
    await this.masterPlanService.createPlan(id);
  }
}
