import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { SaleServiceInterface } from '@components/sale/interface/sale.service.interface';
import { DEFAULT_TIME_FORMAT, MasterPlanStatusEnum } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import {
  clone,
  filter,
  find,
  first,
  flatMap,
  forEach,
  groupBy,
  has,
  isEmpty,
  keyBy,
  last,
  map,
  maxBy,
  orderBy,
  sumBy,
  uniq,
  values,
  isNil,
  isEqual,
  sortBy,
  max,
  min,
  findIndex,
  each,
  keys,
} from 'lodash';
import { I18nService } from 'nestjs-i18n';
import { ILike, In, Not } from 'typeorm';
import { ItemProducingStepScheduleRepositoryInterface } from '../item-producing-step-schedule/interface/item-producing-step-schedule.repository.interface';
import { ItemScheduleRepositoryInterface } from '../item-schedule/interface/item-schedule.repository.interface';
import { SaleOrderScheduleRepositoryInterface } from '../sale-order-schedule/interface/sale-order-schedule.repository.interface';
import { ChangeStatusRequestDto } from './dto/request/change-status.request.dto';
import { CreateMasterPlanRequestDto } from './dto/request/create-master-plan.dto';
import { MasterPlanRepositoryInterface } from './interface/master-plan.repository.interface';
import { MasterPlanServiceInterface } from './interface/master-plan.service.interface';
import {
  CAN_APPROVE_MASTER_PLAN_STATUS,
  CAN_CREATE_SCHEDULE_PLAN,
  CAN_DELETE_MASTER_PLAN_STATUS,
  CAN_MODERATION_MASTER_PLAN,
  CAN_REJECT_MASTER_PLAN_STATUS,
  CAN_UPDATE_MASTER_PLAN_STATUS,
  FORTMAT_DATE_MODERATION,
  MANUFACTURE_BEFORE_DAY_UP_LEVEL,
  MASTER_PLAN_GEN_SCHEDULE,
  MASTER_PLAN_IS_ACTIVE,
  ORDER_PERFORMANCE_PRODUCING_STEP,
  ORDER_STEP_NUMBER_PRODUCING_STEP,
  PLAN_TIME_FORMAT,
} from './master-plan.constant';
import * as moment from 'moment';
import { plainToInstance } from 'class-transformer';
import {
  createDateRange,
  genScheduleByShifts,
  getDiffDay,
  shiftDuration,
  sortTime,
} from '@utils/generate-schedule';
import { DayOffWorkCenterResponse } from '../sale-order-schedule/dto/response/day-off-work-center.response.dto';
import { WorkCenterScheduleRepositoryInterface } from '../work-center-schedule/interface/work-center-schedule.repository.interface';
import { ModerationEvenlyRequestDto } from '../sale-order-schedule/dto/request/moderation-evenly.request.dto';
import { WorkCenterScheduleEntity } from '@entities/schedule/work-center-schedule/work-center-schedule.entity';
import { ItemProducingStepScheduleEntity } from '@entities/schedule/sale-order-schedule/item-producing-step-schedule.entity';
import { ItemScheduleEntity } from '@entities/schedule/sale-order-schedule/item-schedule.entity';
import { DataSource } from 'typeorm';
import { ModerationInputRequestDto } from '../sale-order-schedule/dto/request/moderation-input.request.dto';
import { InjectDataSource } from '@nestjs/typeorm';
import { GetMasterPlanDetailRequestDto } from './dto/request/get-master-plan-detail.request.dto';
import { GetMasterPlanRequestDto } from './dto/request/get-master-plan.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import {
  GetMasterPlanResponseDto,
  MasterPlanListData,
  MasterPlanResponseDto,
} from './dto/response/get-master-plan.response.dto';
import { GetDetailItemProducingStepRequestDto } from './dto/request/get-detail-item-producing-step.request.dto';
import { SuggestModerationInputRequestDto } from './dto/request/suggest-moderation-input.request.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ManufacturingOrderConfirmedEvent } from './dto/request/event/manufacturing-order-confirmed.event.request.dto';
import { ItemManufacturingOrderRepositoryInterface } from './interface/item-manufacturing-order.repository.interface';
import { ItemManufacturingOrderEntity } from '@entities/schedule/sale-order-schedule/item-manufacturing-order.entity';
import { GetMasterPlanByIdRequestDto } from '../sale-order-schedule/dto/request/get-master-plan-by-code.request.dto';
import { GetMasterPlanByCodeResponseDto } from '../sale-order-schedule/dto/response/get-master-plan-by-code.response.dto';
import { UpdateMasterPlanRequestDto } from './dto/request/update-master-plan.dto';
import { MasterPlanEntity } from '@entities/schedule/master-plan/master-plan.entity';
import { SaleOrderScheduleEntity } from '@entities/schedule/sale-order-schedule/sale-order-schedule.entity';
import { MasterPlanScheduleResponseDto } from './dto/response/master-plan-schedule.response.dto';
import { div, minus, mul, plus } from '@utils/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import {
  UpdateMasterPlanActualQuantityRequestDto,
  UpdateMasterPlanItemScheduleActualQuantityRequestDto,
} from './dto/request/event/update-master-plan-actual-quantiy.request.dto';
import { ItemProducingStepScheduleResponseDto } from './dto/response/item-producing-step-schedule.response.dto';
import { WorkCenterDetailScheduleRepositoryInterface } from '../work-center-detail-schedule/interface/work-center-detail-schedule.repository.interface';
import { GetMOByMasterPlanRequestDto } from './dto/request/get-mo-by-master-plan.request.dto';
import { ItemManufacturingOrderResponseDto } from './dto/response/item-manufacturing-order.response.dto';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { MaterialProducingStepScheduleRepositoryInterface } from '../material-producing-step-schedule/interface/material-producing-step-schedule.repository.interface';
import { GetMaterialPlanByItemIdsRequestDto } from '@components/warehouse/dto/request/get-material-plan-by-item-ids.request.dto';
import { UpdateProducedQuantityRequestDto } from '@components/sale/dto/request/update-produced-quantity.request.dto';
import {
  ItemScheduleRepositoryDto,
  ProducingStepScheduleRepositoryDto,
} from './dto/repository/item-schedule.dto';
import { ApiError } from '@utils/api.error';
import { UpdateProducingStepScheduleDto } from './dto/other/update-producing-step-schedule.dto';
import { RequestService } from '@components/request/request.service';
import { WorkCenterDetailScheduleEntity } from '@entities/schedule/work-center-schedule/work-center-detail-schedule.entity';

@Injectable()
export class MasterPlanService implements MasterPlanServiceInterface {
  constructor(
    @Inject('MasterPlanRepositoryInterface')
    private readonly masterPlanRepository: MasterPlanRepositoryInterface,

    @Inject('SaleOrderScheduleRepositoryInterface')
    private readonly saleOrderScheduleRepository: SaleOrderScheduleRepositoryInterface,

    @Inject('ItemScheduleRepositoryInterface')
    private readonly itemScheduleRepository: ItemScheduleRepositoryInterface,

    @Inject('ItemProducingStepScheduleRepositoryInterface')
    private readonly itemProducingStepScheduleRepository: ItemProducingStepScheduleRepositoryInterface,

    @Inject('WorkCenterScheduleRepositoryInterface')
    private readonly workCenterScheduleRepository: WorkCenterScheduleRepositoryInterface,

    @Inject('WorkCenterDetailScheduleRepositoryInterface')
    private readonly workCenterDetailScheduleRepository: WorkCenterDetailScheduleRepositoryInterface,

    @Inject('ItemManufacturingOrderRepositoryInterface')
    private readonly itemManufacturingOrderRepository: ItemManufacturingOrderRepositoryInterface,

    @Inject('MaterialProducingStepScheduleRepositoryInterface')
    private readonly materialProducingStepScheduleRepository: MaterialProducingStepScheduleRepositoryInterface,

    @Inject('SaleServiceInterface')
    private readonly saleService: SaleServiceInterface,

    @Inject('ProduceServiceInterface')
    private readonly produceService: ProduceServiceInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,

    @Inject('RequestServiceInterface')
    private readonly requestService: RequestService,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nService,

    private readonly eventEmitter: EventEmitter2,
  ) {}

  /**
   *
   * @param id
   * @returns
   */
  public async delete(id: number): Promise<any> {
    const masterPlan = await this.masterPlanRepository.findOneById(id);

    if (!masterPlan) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_DELETE_MASTER_PLAN_STATUS.includes(masterPlan.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }

    try {
      await this.masterPlanRepository.remove(id);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(
          error
            ? error.message
            : await this.i18n.translate('error.INTERNAL_SERVER_ERROR'),
        )
        .build();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  async create(request: CreateMasterPlanRequestDto): Promise<any> {
    const { code } = request;
    const masterPlanByCode = await this.masterPlanRepository.findOneByCondition(
      {
        code: ILike(code),
      },
    );
    if (!isEmpty(masterPlanByCode)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_EXIST'))
        .build();
    }
    return await this.save(request);
  }

  /**
   *
   * @param request
   * @returns
   */
  async update(request: UpdateMasterPlanRequestDto): Promise<any> {
    const { id, code } = request;
    const masterPlan = await this.masterPlanRepository.findOneById(id);
    if (isEmpty(masterPlan)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_UPDATE_MASTER_PLAN_STATUS.includes(masterPlan.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.STATUS_CAN_NOT_UPDATE'))
        .build();
    }

    const masterPlanByCode = await this.masterPlanRepository.findOneByCondition(
      {
        code: ILike(code),
        id: Not(id),
      },
    );
    if (!isEmpty(masterPlanByCode)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_EXIST'))
        .build();
    }

    return await this.save(request, masterPlan);
  }

  /**
   *
   * @param request
   * @param masterPlan
   * @returns
   */
  private async save(
    request: CreateMasterPlanRequestDto,
    masterPlan?: MasterPlanEntity,
  ): Promise<any> {
    const {
      saleOrders,
      factoryId,
      code,
      name,
      description,
      dateFrom,
      dateTo,
      userId,
    } = request;

    if (new Date(dateFrom) > new Date(dateTo)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.DATE_ERROR'))
        .build();
    }
    const requestOrderIds = map(saleOrders, 'id');

    //const saleOrdersDetail = await this.saleService.getByIds(saleOrderIds);
    const requestOrdersDetail = await this.requestService.getRequestOrderByIds(
      requestOrderIds,
    );

    if (requestOrdersDetail.length !== requestOrderIds.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.SALE_ORDER_NOT_FOUND'))
        .build();
    }

    const saleOrderSchedules =
      await this.saleOrderScheduleRepository.checkExistSaleOrderIdActive(
        requestOrderIds,
        masterPlan?.id,
      );

    if (saleOrderSchedules) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.SALE_ORDER_ALREADY_EXISTS'),
        )
        .build();
    }

    let itemIds = [];
    let bomVersionIds = [];
    const soNotItem = [];
    requestOrdersDetail.forEach((requestOrder) => {
      if (
        !has(requestOrder, 'requestOrderDetails') ||
        isEmpty(requestOrder.requestOrderDetails)
      ) {
        soNotItem.push(requestOrder.id);
      }
      requestOrder.requestOrderDetails.forEach((detail) => {
        itemIds.push(detail.itemId);
        bomVersionIds.push(detail.bomVersionId);
      });
    });
    if (!isEmpty(soNotItem)) {
      return new ResponseBuilder({
        saleOrders: soNotItem,
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.SALE_ORDER_NOT_ITEM'))
        .build();
    }
    itemIds = uniq(itemIds);
    bomVersionIds = uniq(bomVersionIds);

    const boms = await this.produceService.getBomTreeByItemIds(
      itemIds,
      bomVersionIds,
      factoryId,
    );

    if (itemIds.length > boms.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ITEM_NOT_BOM'))
        .build();
    }

    const invalidProSteps = [];
    boms.forEach((bom) => {
      bom.proStep.forEach((proStep) => {
        if (isEmpty(proStep?.workCenters)) {
          invalidProSteps.push(proStep);
        }
      });
    });

    if (!isEmpty(invalidProSteps)) {
      return new ResponseBuilder({
        items: invalidProSteps,
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.NOT_FOUND_WORK_CENTER_IN_FACTORY'),
        )
        .build();
    }

    const bomsTree = this.genBomsTree(boms) as any;

    const bomsRequest = flatMap(map(saleOrders, 'items')) as any;

    const invalidBoms = bomsRequest
      .map((bom) => !this.validateBomTree(bomsTree, bom))
      .filter((bom) => bom);

    if (!isEmpty(invalidBoms)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BOM_INVALID'))
        .build();
    }

    // masterPlan
    const formatUtcDateFrom = moment(dateFrom).add(7, 'hours').toISOString();
    const formatUtcDateTo = moment(dateTo).add(7, 'hours').toISOString();
    const masterPlanEntity = this.masterPlanRepository.createEntity({
      code,
      name,
      description,
      dateFrom: formatUtcDateFrom,
      dateTo: formatUtcDateTo,
      factoryId,
      userId,
    });
    masterPlanEntity.saleOrderSchedules = [];

    try {
      requestOrdersDetail.forEach((saleOrder) => {
        const requestOrderDetails = saleOrder.requestOrderDetails;
        let itemSchedules = [];

        // saleOrderSchedule
        const saleOrderSchedule = this.saleOrderScheduleRepository.createEntity(
          saleOrder.id,
          itemSchedules,
          formatUtcDateFrom,
          formatUtcDateTo,
        );
        requestOrderDetails.forEach((soDetail) => {
          const bom = bomsTree.find(
            (bom) =>
              bom.itemId === soDetail.itemId &&
              bom.bomVersionId === soDetail.bomVersionId,
          );
          const bomRequest = bomsRequest.find(
            (bom) =>
              bom.itemId === soDetail.itemId &&
              bom.saleOrderId === soDetail.saleOrderId,
          );

          itemSchedules = [].concat(
            itemSchedules,
            this.createEntitiesItemScheduleByBomTree(
              bom,
              { ...bomRequest, bomVersionId: soDetail.bomVersionId },
              null,
              null,
              1,
              soDetail.itemId,
              formatUtcDateFrom,
              formatUtcDateTo,
              soDetail.quantity,
              true,
            ),
          );
        });

        saleOrderSchedule.itemSchedules = itemSchedules;
        masterPlanEntity.saleOrderSchedules.push(saleOrderSchedule);
      });
    } catch (error) {
      console.log(error);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CREATE'))
        .build();
    }

    let result;
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();

    try {
      if (!isEmpty(masterPlan)) {
        masterPlanEntity.id = masterPlan.id;
        await queryRunner.manager.delete(SaleOrderScheduleEntity, {
          masterPlanId: masterPlan.id,
        });
      }

      result = await queryRunner.manager.save(
        MasterPlanEntity,
        masterPlanEntity,
      );

      if (!isEmpty(result)) {
        const itemSchedules = [];
        const itemProducingStepSchedules = [];
        result.saleOrderSchedules.forEach((saleOrderSchedule) => {
          saleOrderSchedule?.itemSchedules.forEach((itemSchedule) => {
            itemSchedule.masterPlanId = result.id;
            itemSchedule.itemProducingStepSchedules =
              itemSchedule?.itemProducingStepSchedules.forEach(
                (itemProducingStepSchedule) => {
                  itemProducingStepSchedule.masterPlanId = result.id;
                  itemProducingStepSchedules.push(itemProducingStepSchedule);
                },
              );
            delete itemSchedule.itemProducingStepSchedules;
            itemSchedules.push({ ...itemSchedule });
          });
        });

        await queryRunner.manager.save(ItemScheduleEntity, itemSchedules);
        await queryRunner.manager.save(
          ItemProducingStepScheduleEntity,
          itemProducingStepSchedules,
        );
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(
          error
            ? error.message
            : await this.i18n.translate('error.INTERNAL_SERVER_ERROR'),
        )
        .build();
    } finally {
      await queryRunner.release();
    }

    // TODO bỏ comment sau
    // await this.eventEmitter.emit('master-plan.create-schedule', {
    //   id: masterPlan.id,
    // });

    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  createEntitiesItemScheduleByBomTree(
    bom,
    bomRequest,
    parentBomId,
    parentBomVersionId,
    level = 1,
    itemFinishId,
    dateFrom,
    dateTo,
    quantityItemParent,
    isProductionObject,
  ) {
    let itemScheduleEntities = [];
    const planQuantity = bom.quantity * quantityItemParent;
    const quantity = isProductionObject ? 0 : planQuantity;

    const itemScheduleEntity = this.itemScheduleRepository.createEntity(
      bom.bomId,
      parentBomId,
      parentBomVersionId,
      bom.itemId,
      level,
      itemFinishId,
      planQuantity,
      dateFrom,
      dateTo,
      isProductionObject,
      bomRequest.bomVersionId,
    );

    let previousEndDate = dateFrom;

    itemScheduleEntity.itemProducingStepSchedules = bom.proStep.map(
      (producingStep) => {
        const workingDays = Math.ceil(
          div(+planQuantity, producingStep.workingCapacity || 1),
        );

        const psDateTo = moment(previousEndDate)
          .add(workingDays - 1, 'days')
          .format(FORTMAT_DATE_MODERATION);

        // const producingStepScheduleDateTo =
        //   moment(psDateTo).isAfter(moment(dateTo)) || !psDateTo
        //     ? dateTo
        //     : psDateTo;

        const entity = this.itemProducingStepScheduleRepository.createEntity(
          producingStep.id,
          planQuantity,
          quantity,
          producingStep.stepNumber,
          previousEndDate,
          psDateTo,
          producingStep.materials,
        );

        previousEndDate = moment(psDateTo)
          .add(1, 'days')
          .format(FORTMAT_DATE_MODERATION);

        return entity;
      },
    );

    itemScheduleEntities.push(itemScheduleEntity);
    if (!isEmpty(bom.subBoms)) {
      for (let i = 0; i < bom.subBoms.length; i++) {
        const subBom = bom.subBoms[i];
        const subBomRequest =
          bomRequest?.subBoms?.length >= i + 1 ? bomRequest.subBoms[i] : {};
        itemScheduleEntities = [].concat(
          itemScheduleEntities,
          this.createEntitiesItemScheduleByBomTree(
            subBom,
            subBomRequest,
            bom.bomId,
            bom.bomVersionId,
            level + 1,
            itemFinishId,
            dateFrom,
            dateTo,
            planQuantity,
            !isProductionObject
              ? isProductionObject
              : subBomRequest?.isProductionObject ?? true,
          ),
        );
      }
    }
    return itemScheduleEntities;
  }

  /**
   *
   * @param bomsBase
   * @param itemBomRequest
   * @returns
   */
  private validateBomTree(bomsBase, itemBomRequest) {
    const itemBom = bomsBase.find(
      (bom) => bom.itemId === itemBomRequest.itemId,
    );

    if (isEmpty(itemBom)) {
      return false;
    }

    if (isEmpty(itemBomRequest.subBoms)) {
      return true;
    }

    return this.validateBom(itemBom, itemBomRequest);
  }

  /**
   *
   * @param bomBase
   * @param bomRequest
   * @returns
   */
  private validateBom(bomBase, bomRequest) {
    if (
      !isEqual(
        this.formatBomValidate(bomBase),
        this.formatBomValidate(bomRequest),
      )
    ) {
      return false;
    }
    if (bomBase?.subBoms?.length !== bomRequest?.subBoms?.length) {
      return false;
    }
    let validBom = true;
    if (!isEmpty(bomBase.subBoms)) {
      for (let i = 0; i < bomBase.subBoms.length; i++) {
        validBom = this.validateBom(
          orderBy(bomBase.subBoms[i], 'itemId'),
          orderBy(bomRequest.subBoms[i], 'itemId'),
        );
        if (!validBom) {
          break;
        }
      }
    }
    return validBom;
  }

  formatBomValidate(bom) {
    return {
      itemId: bom.itemId,
      subBoms: [],
    };
  }

  genBomsTree(boms: any, sub?: any) {
    const bomsTree = {};
    boms.forEach((bom) => {
      const bomId = bom.bomId;
      const key = `${bom.bomId}_${bom.bomVersionId}`;
      if (!has(bomsTree, `${bom.bomId}_${bom.bomVersionId}`)) {
        bomsTree[key] = {
          itemId: bom.itemId,
          bomId,
          bomVersionId: bom.bomVersionId,
          quantity: 1,
          routingId: bom.routingId,
          proStep: [],
          subBoms: [],
        };
      }
      const subItem = sub?.find((e) => e.itemId === bom.itemId);
      if (!isEmpty(subItem)) {
        bomsTree[key].quantity = subItem.quantity;
      }
      bom.proStep.forEach((proStepItem) => {
        bomsTree[key].proStep.push({
          ...proStepItem,
          stepNumber: bom.stepNumber,
        });
      });
      if (!isEmpty(bom.subBom) && isEmpty(bomsTree[key].subBoms)) {
        bomsTree[key].subBoms = this.genBomsTree(bom.subBom, bom.sub);
      }
    });
    return values(bomsTree);
  }

  /**
   *
   * @param request
   * @returns
   */
  async approve(request: ChangeStatusRequestDto): Promise<any> {
    const { id, userId } = request;
    const masterPlan = await this.masterPlanRepository.findOneWithRelations({
      where: {
        id: id,
      },
      relations: ['saleOrderSchedules'],
    });

    if (isEmpty(masterPlan)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_APPROVE_MASTER_PLAN_STATUS.includes(masterPlan.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.STATUS_CAN_NOT_UPDATE'))
        .build();
    }
    try {
      await this.createPlan(masterPlan.id);
      masterPlan.status = MasterPlanStatusEnum.APPROVED;
      masterPlan.approverId = userId;
      masterPlan.approvedAt = new Date().toISOString();
      await this.masterPlanRepository.update(masterPlan);
      const requestOrderIds = map(masterPlan.saleOrderSchedules, 'saleOrderId');
      await this.requestService.updateManufacturingRequestOrderIsHasPlan(
        requestOrderIds,
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  /**
   *
   * @param request
   * @returns
   */
  async reject(request: ChangeStatusRequestDto): Promise<any> {
    const { id, userId } = request;
    const masterPlan = await this.masterPlanRepository.findOneById(id);
    if (isEmpty(masterPlan)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_REJECT_MASTER_PLAN_STATUS.includes(masterPlan.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.STATUS_CAN_NOT_UPDATE'))
        .build();
    }
    try {
      masterPlan.status = MasterPlanStatusEnum.REJECT;
      masterPlan.approverId = userId;
      masterPlan.approvedAt = new Date().toISOString();
      await this.masterPlanRepository.update(masterPlan);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  /**
   *
   * @param masterPlan
   * @returns
   */
  private async generateSchedule(
    masterPlan: MasterPlanResponseDto,
  ): Promise<any> {
    const producingStepIds = [];
    const itemProducingStepScheduleIds = [];
    const itemSchedules = [];
    const bomIds = [];
    const itemIds = [];
    masterPlan.saleOrderSchedules.forEach((saleOrderSchedule) => {
      saleOrderSchedule.itemSchedules.forEach((item) => {
        itemSchedules.push(item);

        bomIds.push(item.bomId);
        itemIds.push(item.itemId);
        item.producingSteps.forEach((itemProducingStep) => {
          producingStepIds.push(itemProducingStep.producingStepId);
          itemProducingStepScheduleIds.push(itemProducingStep.id);
        });
      });
    });

    const boms = await this.produceService.getBomByItemIds(itemIds, false);
    const routingIds = [];
    boms.forEach((bom) => {
      routingIds.push(bom.routing.id);
    });
    const producingSteps = await this.produceService.getProducingSteps(
      producingStepIds,
      masterPlan.factoryId,
      routingIds,
    );

    const workCenterIds = [];
    const workCenterSerialize = {};
    const mapWorkCenterByProducingStep = {};
    const producingStepsSerialize = {};

    producingSteps.forEach((producingStep) => {
      producingStepsSerialize[producingStep.id] = producingStep;
      const worksCenterByProducingStep = [];
      producingStep.workCenters.forEach((workCenter) => {
        workCenterIds.push(workCenter.id);
        worksCenterByProducingStep.push(workCenter);
        workCenterSerialize[workCenter.id] = {
          ...workCenter,
          producingStepId: producingStep.id,
          productionTimePerItem: producingStep.productionTimePerItem,
        };
      });
      mapWorkCenterByProducingStep[producingStep.id] = orderBy(
        worksCenterByProducingStep,
        'actualWorkingCapacity',
        ORDER_PERFORMANCE_PRODUCING_STEP,
      ).map((workCenter) => workCenter.id);
    });

    if (isEmpty(workCenterIds)) {
      return new ResponseBuilder({})
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NO_MATCHING_WORK_CENTER'))
        .build();
    }
    const { groupItemsFormatByLevel: treeItems, levelMax } =
      this.formatItemsByLevel(itemSchedules);
    const schedulesInPlan = await this.genScheduleWorkCenterByPlan(
      workCenterIds,
      masterPlan.dateFrom,
      masterPlan.dateTo,
      workCenterSerialize,
    );

    const materialByProducingStepSchedule =
      await this.materialProducingStepScheduleRepository.findByCondition({
        itemProducingStepScheduleId: In(itemProducingStepScheduleIds),
      });
    const itemsMaterialPlan = {};
    materialByProducingStepSchedule.forEach((material) => {
      if (!has(itemsMaterialPlan, material.itemId)) {
        itemsMaterialPlan[material.itemId] = {
          itemId: material.itemId,
          quantity: 0,
        };
      }
      itemsMaterialPlan[material.itemId].quantity += material.quantity;
    });
    const requestGetMaterialPlan = new GetMaterialPlanByItemIdsRequestDto();
    requestGetMaterialPlan.items = values(itemsMaterialPlan);

    const materialPlanByItems =
      await this.warehouseService.getMaterialPlanByItemIds(
        requestGetMaterialPlan,
      );
    const serializeMaterialPlanByItem = keyBy(materialPlanByItems, 'itemId');
    const materialBoms = await this.produceService.getMaterialBomByIds(bomIds);
    const serializeMaterialBom = {};
    materialBoms.forEach((materialBom) => {
      materialBom?.bomProducingSteps?.forEach((bomProducingStep) => {
        const keyMaterialBom = `${materialBom.id}-${bomProducingStep.producingStepId}`;
        if (!has(serializeMaterialBom, keyMaterialBom)) {
          serializeMaterialBom[keyMaterialBom] = [];
        }
        serializeMaterialBom[keyMaterialBom].push(bomProducingStep);
      });
    });
    const schedules = {};
    const keyTreeItems = Object.keys(treeItems);
    try {
      looplevelTreeItem: for (
        let level = keyTreeItems.length;
        level > 0;
        level--
      ) {
        const items = treeItems[level];
        loopItems: for (
          let indexItem = 0;
          indexItem < items?.length;
          indexItem++
        ) {
          const item = items[indexItem];
          if (!item.needToManufacture) {
            continue loopItems;
          }
          let dateFrom = moment(masterPlan.dateFrom).format(
            'YYYY-MM-DD',
          ) as any;
          const dateTo = moment(masterPlan.dateTo).format('YYYY-MM-DD');
          let planQuantity = {};
          if (+level !== levelMax) {
            const itemsChild = treeItems[+level + 1].filter(
              (itemChild) =>
                itemChild.needToManufacture &&
                itemChild.parentBomId === item.bomId &&
                itemChild.itemFinishId === item.itemFinishId &&
                item.saleOrderScheduleId === itemChild.saleOrderScheduleId,
            );
            const schedulesChild = {};
            itemsChild.forEach((itemChild) => {
              schedulesChild[itemChild.id] = schedules[itemChild.id];
            });
            const { dateFromByItemChild, planQuantityItemParent } =
              this.calculateManufactureMinQuantityUpLevel(
                itemsChild,
                schedulesChild,
                item.quantity,
                dateFrom,
                dateTo,
              );
            if (!dateFromByItemChild) {
              continue loopItems;
            }
            dateFrom = dateFromByItemChild;
            planQuantity = planQuantityItemParent;
          }

          schedules[item.id] = {};
          const producingSteps = this.orderByProducingStepSchedules(
            item.producingSteps,
          );
          let prevProducingStep = {} as ItemProducingStepScheduleEntity;
          producingSteps.forEach((itemProducingStep) => {
            if (
              !isEmpty(prevProducingStep) &&
              prevProducingStep.stepNumber !== itemProducingStep.stepNumber
            ) {
              const prevProducingStepSchedule =
                schedules[item.id][prevProducingStep.id];
              dateFrom = itemProducingStep.dateFrom;
            }
            const workCenterIdsByProducingStep =
              mapWorkCenterByProducingStep[itemProducingStep.producingStepId];
            const keyMaterialBomPro = `${item.bomId}-${itemProducingStep.producingStepId}`;
            const { dateFromByMaterialPlan, planQuantityByMaterial } =
              this.calculateProducingStepScheduleByMaterialPlan(
                itemProducingStep.quantity,
                serializeMaterialBom[keyMaterialBomPro],
                serializeMaterialPlanByItem,
                dateFrom,
                dateTo,
              );
            const rate = div(itemProducingStep.planQuantity, item.quantity);
            schedules[item.id][itemProducingStep.id] = genScheduleByShifts(
              dateFrom,
              dateTo,
              itemProducingStep.planQuantity,
              schedulesInPlan,
              workCenterIdsByProducingStep,
              workCenterSerialize,
              producingStepsSerialize[itemProducingStep.producingStepId][
                'productionTimePerItem'
              ],
              planQuantity,
              rate,
            );
            prevProducingStep = itemProducingStep;
          });
        }
      }
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(
          error
            ? error?.message
            : await this.i18n.translate('error.INTERNAL_SERVER_ERROR'),
        )
        .build();
    }
    return schedules;
  }

  private calculateProducingStepScheduleByMaterialPlan(
    quantity,
    materialBom,
    materialPlan,
    dateFrom,
    dateTo,
  ) {
    const objScheduleItems = {};
    const objElementItems = {};
    const firstDays = [];
    let checkItemNotSchedule = false;
    forEach(materialBom, (material) => {
      if (!isEmpty(materialPlan[material.itemId]?.schedules)) {
        checkItemNotSchedule = true;
        return;
      }
      objElementItems[material.itemId] = {
        planQuantity: quantity * material.quantity,
        actualQuantity: material.actualQuantity,
      };
      let firstDateSchedule = dateFrom;
      materialPlan[material.itemId]?.schedules?.forEach((schedule) => {
        if (moment(schedule.date).isBefore(firstDateSchedule, 'day')) {
          firstDateSchedule = schedule.date;
        }
        if (!has(objScheduleItems, schedule.date)) {
          objScheduleItems[schedule.date] = [];
        }
        objScheduleItems[schedule.date] = {
          id: material.itemId,
          quantity: schedule.quantity,
        };
      });

      if (material.actualQuantity > 0) {
        if (!has(objScheduleItems, firstDateSchedule)) {
          objScheduleItems[firstDateSchedule] = {
            id: material.itemId,
            quantity: 0,
          };
        }
        objScheduleItems[firstDateSchedule].quantity += material.actualQuantity;
      }
      firstDays.push(first(sortBy(Object.keys(objScheduleItems), 'desc')));
    });

    const planQuantityItems = this.calculatePlanQuantityUpLevel(
      quantity,
      objScheduleItems,
      objElementItems,
      dateTo,
    );
    if (isEmpty(firstDays) || checkItemNotSchedule)
      return { dateFromByMaterialPlan: false, planQuantityByMaterial: false };
    const dateFromByMaterialPlan = moment(
      new Date(Math.max.apply(null, firstDays)),
    ).format('YYYY-MM-DD');
    const planQuantityByMaterial = {};
    Object.keys(planQuantityItems).forEach((day) => {
      if (moment(dateFromByMaterialPlan).isSameOrBefore(day)) {
        planQuantityByMaterial[day] = planQuantityItems[day];
      }
    });
    return { dateFromByMaterialPlan, planQuantityByMaterial };
  }

  private async formatMasterPlanSchedule(
    masterPlan: MasterPlanResponseDto,
  ): Promise<any> {
    const schedules = await this.generateSchedule(masterPlan);

    masterPlan.saleOrderSchedules.map((saleOrderSchedule) => {
      saleOrderSchedule.itemSchedules.map((item) => {
        let dateFrom = masterPlan.dateFrom.toString();
        let dateTo = masterPlan.dateTo.toString();
        let isOverQuantity = false;
        item.producingSteps.map((itemProducingStep) => {
          const workCenterScheduleEntites = [];

          let overQuantity = 0;
          if (
            has(schedules, item.id) &&
            has(schedules[item.id], itemProducingStep.id)
          ) {
            const schedule = schedules[item.id][itemProducingStep.id];
            overQuantity = schedule.overQuantity;
            dateFrom = Object.keys(schedule['workCentersSchedule'])[0];
            dateTo = Object.keys(schedule['workCentersSchedule'])[
              Object.keys(schedule['workCentersSchedule']).length - 1
            ];
            if (overQuantity > 0) isOverQuantity = true;
            Object.keys(schedule['workCentersSchedule']).forEach(
              (excutionDate) => {
                const workCenterSchedule =
                  schedule['workCentersSchedule'][excutionDate];
                workCenterSchedule.forEach((workCenter) => {
                  const workCenterScheduleEntity =
                    this.workCenterScheduleRepository.createEntity({
                      ...workCenter,
                      itemProducingStepScheduleId: itemProducingStep.id,
                      excutionDate,
                    });
                  workCenterScheduleEntites.push(workCenterScheduleEntity);
                });
              },
            );
          } else {
            isOverQuantity = true;
            overQuantity = item.quantity;
          }

          itemProducingStep.workCenterSchedules = workCenterScheduleEntites;
          // if (dateFrom) {
          //   itemProducingStep.dateFrom = new Date(dateFrom);
          // }
          // if (dateTo) {
          //   itemProducingStep.dateTo = new Date(dateTo);
          // }
          itemProducingStep.quantity = item.quantity - overQuantity;
          itemProducingStep.overQuantity = overQuantity;
          return itemProducingStep;
        });
        item.isOverQuantity = isOverQuantity;
        return item;
      });
      return saleOrderSchedule;
    });

    return masterPlan;
  }

  async createPlan(masterPlanId: number): Promise<any> {
    const masterPlan = await this.masterPlanRepository.getDetailMasterPlan({
      masterPlanId,
    });
    if (isEmpty(masterPlan)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CAN_CREATE_SCHEDULE_PLAN.includes(masterPlan.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }
    const schedules = await this.generateSchedule(masterPlan);
    if (has(schedules, 'statusCode')) {
      return schedules;
    }
    const itemSchedulesEntities = [];
    const itemsProducingStepEntities = [];
    const workCenterScheduleEntites = [];

    masterPlan.saleOrderSchedules.forEach((saleOrderSchedule) => {
      saleOrderSchedule.itemSchedules.forEach((item) => {
        let dateFrom = masterPlan.dateFrom;
        let dateTo = masterPlan.dateTo;
        let isOverQuantity = false;
        item.producingSteps.forEach((itemProducingStep) => {
          let overQuantity = 0;
          if (
            has(schedules, item.id) &&
            has(schedules[item.id], itemProducingStep.id)
          ) {
            const schedule = schedules[item.id][itemProducingStep.id];
            overQuantity = schedule.overQuantity;
            dateFrom = Object.keys(schedule['workCentersSchedule'])[0];
            dateTo = Object.keys(schedule['workCentersSchedule'])[
              Object.keys(schedule['workCentersSchedule']).length - 1
            ];
            if (overQuantity > 0) isOverQuantity = true;
            Object.keys(schedule['workCentersSchedule']).forEach(
              (excutionDate) => {
                const workCenterSchedule =
                  schedule['workCentersSchedule'][excutionDate];
                workCenterSchedule.forEach((workCenter) => {
                  const workCenterScheduleEntity =
                    this.workCenterScheduleRepository.createEntity({
                      ...workCenter,
                      itemProducingStepScheduleId: itemProducingStep.id,
                      excutionDate,
                    });
                  workCenterScheduleEntites.push(workCenterScheduleEntity);
                });
              },
            );
          } else {
            isOverQuantity = true;
          }
          itemsProducingStepEntities.push({
            ...itemProducingStep,
            // dateFrom,
            // dateTo,
            quantity: item.quantity - overQuantity,
            overQuantity,
          });
        });

        itemSchedulesEntities.push(
          this.itemScheduleRepository.updateEntity({
            ...item,
            // dateFrom,
            isOverQuantity,
          }),
        );
      });
    });
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();

    try {
      await queryRunner.manager.save(ItemScheduleEntity, itemSchedulesEntities);
      await queryRunner.manager.save(
        ItemProducingStepScheduleEntity,
        itemsProducingStepEntities,
      );
      await queryRunner.manager.save(
        WorkCenterScheduleEntity,
        workCenterScheduleEntites,
      );

      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(
          error
            ? error.message
            : await this.i18n.translate('error.INTERNAL_SERVER_ERROR'),
        )
        .build();
    } finally {
      await queryRunner.release();
    }
    const data = await this.masterPlanRepository.getDetailMasterPlan({
      masterPlanId,
    });
    const response = plainToInstance(MasterPlanResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private calculatePlanQuantityItemByProducingSteps(
    quantityItem,
    producingSteps,
    schedules,
    dateTo,
  ) {
    let checkProducingStepNotSchedule = false;
    const objElementProducingStep = {};
    const objScheduleProducingSteps = {};
    const firstDays = [];
    forEach(producingSteps, (producingStep) => {
      if (
        !has(schedules, producingStep.id) ||
        isEmpty(schedules[producingStep.id].workCentersSchedule)
      ) {
        checkProducingStepNotSchedule = true;
        return;
      }
      objElementProducingStep[producingStep.id] = {
        planQuantity: producingStep.planQuantity,
      };
      const schedule = schedules[producingStep.id].workCentersSchedule;
      const firstKey = first(Object.keys(schedule));
      if (schedule && firstKey) {
        firstDays.push(new Date(firstKey));
        Object.keys(schedule).forEach((scheduleDay) => {
          const scheduleByDay = schedule[scheduleDay];
          if (!has(objScheduleProducingSteps, scheduleDay)) {
            objScheduleProducingSteps[scheduleDay] = [];
          }
          objScheduleProducingSteps[scheduleDay].push({
            quantity: sumBy(scheduleByDay, 'quantity'),
            id: producingStep.id,
          });
        });
      }
    });
    const planQuantityProducingSteps = this.calculatePlanQuantityUpLevel(
      quantityItem,
      objScheduleProducingSteps,
      objElementProducingStep,
      dateTo,
    );
    return { planQuantityProducingSteps, checkProducingStepNotSchedule };
  }

  private calculateManufactureMinQuantityUpLevel(
    items,
    scheduleItems,
    quantityItemParent?,
    dateFrom?,
    dateTo?,
  ) {
    if (isEmpty(items)) {
      return { dateFromByItemChild: dateFrom, planQuantityItemParent: {} };
    }
    const firstDays = [];
    let checkItemNotSchedule = false;
    const objScheduleItems = {};
    const objElementItems = {};
    items.forEach((item) => {
      const { planQuantityProducingSteps, checkProducingStepNotSchedule } =
        this.calculatePlanQuantityItemByProducingSteps(
          item.quantity,
          item.producingSteps,
          scheduleItems[item.id],
          dateTo,
        );
      if (checkProducingStepNotSchedule) {
        checkItemNotSchedule = true;
        return;
      }
      Object.keys(planQuantityProducingSteps).forEach((scheduleDay) => {
        const quantityByDay = planQuantityProducingSteps[scheduleDay];
        if (!has(objScheduleItems, scheduleDay)) {
          objScheduleItems[scheduleDay] = [];
        }
        objScheduleItems[scheduleDay].push({
          quantity: quantityByDay,
          id: item.id,
        });
      });
      firstDays.push(first(sortBy(Object.keys(objScheduleItems), 'desc')));
      objElementItems[item.id] = {
        planQuantity: item.quantity,
      };
    });
    const planQuantityItems = this.calculatePlanQuantityUpLevel(
      quantityItemParent,
      objScheduleItems,
      objElementItems,
      dateTo,
    );
    if (isEmpty(firstDays) || checkItemNotSchedule)
      return { dateFromByItemChild: false, planQuantityItemParent: false };
    const dateFromByItemChild = moment(
      new Date(first(sortBy(firstDays, 'desc'))),
    ).format('YYYY-MM-DD');
    const planQuantityItemParent = {};
    Object.keys(planQuantityItems).forEach((day) => {
      if (moment(dateFromByItemChild).isSameOrBefore(day)) {
        planQuantityItemParent[day] = planQuantityItems[day];
      }
    });
    return { dateFromByItemChild, planQuantityItemParent };
  }

  private calculatePlanQuantityUpLevel(
    quantity: number,
    schedulesByDay: any,
    elements,
    dateTo,
  ): any {
    const planQuantity = {};
    const infoQuantity = {};
    Object.keys(schedulesByDay).forEach((executionDay) => {
      const schedules = schedulesByDay[executionDay];
      let manufactureQuantityByDay = 0;
      let flagFirstSchedule = true;
      schedules.forEach((schedule) => {
        if (!has(infoQuantity, schedule.id)) {
          const rate = div(elements[schedule.id].planQuantity, quantity);
          infoQuantity[schedule.id] = {
            remainQuantity: has(elements[schedule.id], 'actualQuantity')
              ? elements[schedule.id].actualQuantity
              : 0,
            rate: rate,
            planQuantity: elements[schedule.id].planQuantity,
          };
        }
        const infoQuantityCurrent = infoQuantity[schedule.id];
        const manufactureQuantity = infoQuantityCurrent
          ? Math.floor(
              div(
                plus(schedule.quantity, infoQuantityCurrent.remainQuantity),
                infoQuantity[schedule.id].rate,
              ),
            )
          : 0;
        if (flagFirstSchedule) {
          flagFirstSchedule = false;
          manufactureQuantityByDay = manufactureQuantity;
        }
        if (manufactureQuantity < manufactureQuantityByDay) {
          manufactureQuantityByDay = manufactureQuantity;
        }
      });

      planQuantity[executionDay] = manufactureQuantityByDay;

      Object.keys(elements).forEach((elementId) => {
        const infoQuantityCurrent = infoQuantity[elementId];
        const usedQuantity = infoQuantityCurrent
          ? mul(manufactureQuantityByDay, infoQuantityCurrent.rate)
          : 1;
        const quantityElementByDay = schedules.find(
          (schedule) => +schedule.id === +elementId,
        );
        const remainQuantity = minus(
          quantityElementByDay?.quantity || 0,
          usedQuantity,
        );
        if (has(infoQuantity, elementId)) {
          infoQuantity[elementId].remainQuantity = infoQuantityCurrent
            ? plus(remainQuantity, infoQuantityCurrent.remainQuantity)
            : 0;
          const actualQuantity = minus(
            infoQuantityCurrent.planQuantity,
            usedQuantity,
          );
          infoQuantity[elementId].planQuantity = actualQuantity;
        }
      });
    });
    const lastDaySChedule = last(Object.keys(schedulesByDay));
    let isSuccessPlan = true;
    Object.keys(infoQuantity).forEach((key) => {
      if (infoQuantity[key].actualQuantity > 0) {
        isSuccessPlan = false;
      }
    });
    if (moment(lastDaySChedule).isBefore(dateTo) && !isSuccessPlan) {
      const diffDay = getDiffDay(lastDaySChedule, dateTo);
      for (let i = 1; i <= diffDay; i++) {
        planQuantity[
          moment(lastDaySChedule).add(i, 'day').format('YYYY-MM-DD')
        ] = 0;
      }
    }
    return this.sortObjectByKey(planQuantity);
  }

  private sortObjectByKey(obj) {
    const objSort = {};
    each(keys(obj).sort(), (key) => {
      objSort[key] = obj[key];
    });
    return objSort;
  }

  private formatItemsByLevel(itemSchedules: any): any {
    const groupItemsByLevel = groupBy(
      itemSchedules,
      (itemSchedule) =>
        `${itemSchedule.itemFinishId}-${itemSchedule.saleOrderScheduleId}`,
    );
    const levelMax = Number(maxBy(itemSchedules, 'level')['level']);
    const groupItemsFormatByLevel = {};
    for (let i = 1; i <= levelMax; i++) {
      groupItemsFormatByLevel[i] = [];
    }
    // format level item by max level
    Object.keys(groupItemsByLevel).forEach((itemFinishId) => {
      const items = groupItemsByLevel[itemFinishId];
      const levelMaxByItem = maxBy(items, 'level')['level'];
      const diffLevel = levelMax - levelMaxByItem;
      items.forEach((item) => {
        groupItemsFormatByLevel[item.level + diffLevel].push(item);
      });
    });
    return { groupItemsFormatByLevel, levelMax };
  }

  private genTreeItem(
    itemSchedules: any,
    parentBomId = null,
    soId = null,
    itemFinishId = null,
  ): any {
    const items = {};
    itemSchedules.forEach((item) => {
      if (
        item.parentBomId === parentBomId &&
        (soId === null || item.saleOrderScheduleId === soId) &&
        (itemFinishId === null || item.itemFinishId === itemFinishId)
      ) {
        const subBom = this.genTreeItem(
          itemSchedules,
          item.bomId,
          item.saleOrderScheduleId,
          item.itemFinishId,
        );
        const key = `${item.itemId}-${item.saleOrderScheduleId}-${item.bomVersionId}`;
        items[key] = {
          ...item,
          subBom: subBom,
        };
      }
    });
    return values(items);
  }

  private async genScheduleWorkCenterByPlan(
    workCenterIds: number[],
    planFrom,
    planTo,
    workCenterSerialize,
    isNotProducingStepSchedule?: number[],
  ): Promise<any> {
    const scheduleWorkCenter =
      await this.workCenterScheduleRepository.getWorkCenterScheduleByPlan(
        workCenterIds,
        planFrom,
        isNotProducingStepSchedule,
      );
    const scheduleWorkCenterSerialize = {};
    scheduleWorkCenter.forEach((workCenter) => {
      if (!isEmpty(workCenter.workCenterDetailSchedules)) {
        if (!has(scheduleWorkCenterSerialize, workCenter.workCenterId)) {
          scheduleWorkCenterSerialize[workCenter.workCenterId] = {};
        }

        if (
          !has(
            scheduleWorkCenterSerialize[workCenter.workCenterId],
            workCenter.excutionDate,
          )
        ) {
          scheduleWorkCenterSerialize[workCenter.workCenterId][
            workCenter.excutionDate
          ] = {};
        }
        workCenter.workCenterDetailSchedules.forEach((detailSchedule) => {
          scheduleWorkCenterSerialize[workCenter.workCenterId][
            workCenter.excutionDate
          ][detailSchedule.workCenterShiftScheduleId] = detailSchedule;
        });
      }
    });
    const diffDay = getDiffDay(planFrom, planTo);
    // TODO: list day off work center
    const dayOffWorkCenter = [] as DayOffWorkCenterResponse[];
    const dayOffWorkCenterSerialize = groupBy(dayOffWorkCenter, 'workCenterId');
    const workCenterCalendar = {};
    workCenterIds.forEach((workCenterId) => {
      const scheduleDay = keyBy(
        sortTime(workCenterSerialize[workCenterId]['workCenterShifts']),
        'id',
      );
      // Format list day off work center
      let dayOffs = [];
      if (has(dayOffWorkCenterSerialize, workCenterId)) {
        dayOffWorkCenterSerialize[workCenterId].map((dayOff) => {
          const diffDayOff = getDiffDay(dayOff.from, dayOff.to);
          for (let j = 0; j < diffDayOff; j++) {
            dayOffs.push(moment(dayOff.from).add(j).format('YYYY-MM-DD'));
          }
        });
        dayOffs = uniq(dayOffs);
      }
      // gen list shift by day work center in plan
      workCenterCalendar[workCenterId] = {};
      const workingDayWorkCenter = has(
        scheduleWorkCenterSerialize,
        workCenterId,
      )
        ? scheduleWorkCenterSerialize[workCenterId]
        : {};
      for (let i = 0; i < diffDay; i++) {
        const day = moment(planFrom).add(i, 'day').format('YYYY-MM-DD');
        const scheduleDayClone = clone(scheduleDay);
        // remove shift working
        if (!isEmpty(workingDayWorkCenter) && has(workingDayWorkCenter, day)) {
          Object.keys(workingDayWorkCenter[day])?.forEach((shiftId) => {
            delete scheduleDayClone[shiftId];
          });
        }
        // remove day off
        if (dayOffs.includes(day)) {
          continue;
        }
        workCenterCalendar[workCenterId][day] = scheduleDayClone;
      }
    });
    return workCenterCalendar;
  }

  async submitModerationEvenly(
    request: ModerationEvenlyRequestDto,
  ): Promise<any> {
    const { masterPlanId, itemProducingStepId } = request;
    const dateFrom = moment(request.dateFrom).format(FORTMAT_DATE_MODERATION);
    const dateTo = moment(request.dateTo).format(FORTMAT_DATE_MODERATION);
    const masterPlan = await this.masterPlanRepository.getDetailMasterPlan({
      masterPlanId,
    });

    if (isEmpty(masterPlan)) {
      throw new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const dataItemSchedulesModeration = await this.moderationEvenly(
      request,
      masterPlan,
    );

    if (dataItemSchedulesModeration.statusCode !== ResponseCodeEnum.SUCCESS) {
      return dataItemSchedulesModeration;
    }

    const itemSchedulesModeration = dataItemSchedulesModeration.data;

    itemSchedulesModeration.forEach((itemSchedule) => {
      itemSchedule.producingSteps = itemSchedule.producingStepSchedules;
      delete itemSchedule.producingStepSchedules;
    });

    // Format schedule để tạo entity
    const producingStepSchedules: UpdateProducingStepScheduleDto[] = [];
    itemSchedulesModeration.forEach((itemSchedule) => {
      itemSchedule.producingSteps.forEach((producingStep) => {
        const producingStepSchedule = {
          producingStepScheduleId: producingStep.id,
          workCenterDetailSchedules: [],
        };
        producingStep.workCenterSchedules.forEach((workCenterSchedule) => {
          workCenterSchedule.workCenterDetailSchedules.forEach(
            (workCenterDetailSchedule) => {
              producingStepSchedule.workCenterDetailSchedules.push({
                workCenterId: workCenterSchedule.workCenterId,
                workCenterShiftScheduleId:
                  workCenterDetailSchedule.workCenterShiftScheduleId,
                date: workCenterSchedule.excutionDate,
                quantity: Math.floor(workCenterDetailSchedule.quantity),
              });
            },
          );
        });
        producingStepSchedules.push(producingStepSchedule);
      });
    });

    const dataProducingStepSchedules =
      await this.updateProducingStepScheduleEntities(
        masterPlan.factoryId,
        producingStepSchedules,
        false,
      );

    if (dataProducingStepSchedules.statusCode !== ResponseCodeEnum.SUCCESS) {
      return dataProducingStepSchedules;
    }

    const {
      itemProducingStepEntities,
      workCenterScheduleEntities,
      workCenterDetailScheduleEntites,
    } = dataProducingStepSchedules.data;

    itemProducingStepEntities.forEach((itemPs) => {
      if (itemPs.id === itemProducingStepId) {
        itemPs.dateFrom = dateFrom;
        itemPs.dateTo = dateTo;
      }
    });
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(itemProducingStepEntities);
      await queryRunner.manager.save(workCenterScheduleEntities);
      await queryRunner.manager.save(workCenterDetailScheduleEntites);
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    } finally {
      await queryRunner.release();
      // TODO: Kiểm tra lại để đồng bộ sang MO
      // await this.eventEmitter.emit('master-plan.moderated', {
      //   id: masterPlanId,
      // });
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async submitExtendDeadlineModeration(
    request: ModerationEvenlyRequestDto,
  ): Promise<any> {
    const { masterPlanId, itemProducingStepId } = request;
    const dateFrom = moment(request.dateFrom).format(FORTMAT_DATE_MODERATION);
    const dateTo = moment(request.dateTo).format(FORTMAT_DATE_MODERATION);
    const masterPlan = await this.masterPlanRepository.findOneWithRelations({
      where: {
        id: masterPlanId,
      },
      relations: [
        'saleOrderSchedules',
        'saleOrderSchedules.itemSchedules',
        'saleOrderSchedules.itemSchedules.itemProducingStepSchedules',
      ],
    });
    if (isEmpty(masterPlan)) {
      throw new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const itemProducingStepSchedule =
      await this.itemProducingStepScheduleRepository.findOneWithRelations({
        where: {
          id: itemProducingStepId,
        },
        relations: ['workCenterSchedules'],
      });
    if (isEmpty(itemProducingStepSchedule)) {
      throw new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const workCenterIds = uniq(
      map(itemProducingStepSchedule.workCenterSchedules, 'workCenterId'),
    );

    let workCenters = [];
    if (!isEmpty(workCenterIds)) {
      workCenters = await this.produceService.getWorkCenterByIds(
        workCenterIds,
        false,
      );
    }

    const bestPerformanceWorkCenter = workCenters.reduce((maxObj, obj) =>
      obj.actualWorkingCapacity > maxObj.actualWorkingCapacity ? obj : maxObj,
    );

    const existWorkCenterSchedules =
      itemProducingStepSchedule.workCenterSchedules;

    const existWorkCenterScheduleIds = map(existWorkCenterSchedules, 'id');

    let remainPlanQuantity = itemProducingStepSchedule.planQuantity;

    const workCenterSchedules = [];
    const diffDay = getDiffDay(dateFrom, dateTo);
    for (let indexDay = 0; indexDay < diffDay; indexDay++) {
      const day = moment(dateFrom).add(indexDay, 'day').format('YYYY-MM-DD');
      const isLastSchedule = day === dateTo;
      const existWorkCenterSchedule =
        itemProducingStepSchedule?.workCenterSchedules.find(
          (wcSchedule) =>
            moment(wcSchedule.excutionDate).format(FORTMAT_DATE_MODERATION) ===
            day,
        );

      const workCenterActualQuantity = !isEmpty(existWorkCenterSchedule)
        ? existWorkCenterSchedule.actualQuantity
        : 0;

      workCenters.forEach((workCenter) => {
        const isBestPerformanceWorkCenter =
          workCenter.id === bestPerformanceWorkCenter.id;

        const totalWorkingTime = workCenter.workCenterShifts.reduce(
          (total, shift) => {
            const duration = moment(shift.endAt, DEFAULT_TIME_FORMAT).diff(
              moment(shift.startAt, DEFAULT_TIME_FORMAT),
              'minutes',
            );
            return total + duration;
          },
          0,
        );

        const totalRelaxTime = workCenter.workCenterShiftRelaxTimes.reduce(
          (total, shiftRelax) => {
            const duration = moment(shiftRelax.endAt, DEFAULT_TIME_FORMAT).diff(
              moment(shiftRelax.startAt, DEFAULT_TIME_FORMAT),
              'minutes',
            );
            return total + duration;
          },
          0,
        );
        const actualWorkingTime = minus(totalWorkingTime, totalRelaxTime);
        // const actualWorkingCapacityInDay = mul(
        //   workCenter.actualWorkingCapacity || 1,
        //   actualWorkingTime || 1,
        // );

        let quantity = Math.min(
          remainPlanQuantity,
          workCenter.actualWorkingCapacity,
        );
        const isPrevDate = moment(day).isSameOrBefore(moment().endOf('day'));
        if (isPrevDate) {
          quantity = workCenterActualQuantity;
        }

        const workCenterShifts = workCenter?.workCenterShifts?.map((shift) => {
          const shiftWorkingTime = shiftDuration(shift);
          const shiftRelaxTimes = workCenter.workCenterShiftRelaxTimes?.filter(
            (shiftRelax) => shiftRelax.workCenterShiftId === shift.id,
          );

          const totalShiftRelaxTime = shiftRelaxTimes.reduce(
            (total, shiftRelax) => {
              const duration = moment(
                shiftRelax.endAt,
                DEFAULT_TIME_FORMAT,
              ).diff(
                moment(shiftRelax.startAt, DEFAULT_TIME_FORMAT),
                'minutes',
              );
              return total + duration;
            },
            0,
          );

          const actualShiftWorkingTime = minus(
            shiftWorkingTime,
            totalShiftRelaxTime,
          );

          const shiftWorkingPerDay = div(
            actualShiftWorkingTime,
            actualWorkingTime,
          );
          return this.workCenterDetailScheduleRepository.createEntity({
            workCenterShiftScheduleId: shift.id,
            excutionFrom: shift.startAt,
            excutionTo: shift.endAt,
            quantity:
              quantity > 0 ? Math.floor(mul(shiftWorkingPerDay, quantity)) : 0,
          });
        });
        remainPlanQuantity -= quantity;
        const wcScheduleDetail = {
          workCenterId: workCenter.id,
          excutionDate: day,
          itemProducingStepScheduleId: itemProducingStepId,
          quantity: quantity,
          workCenterDetailSchedules: workCenterShifts,
          actualQuantity: workCenterActualQuantity,
        };

        if (
          isBestPerformanceWorkCenter &&
          isLastSchedule &&
          remainPlanQuantity > 0
        ) {
          wcScheduleDetail.quantity = plus(
            wcScheduleDetail.quantity,
            remainPlanQuantity,
          );
          remainPlanQuantity = 0;
        }
        workCenterSchedules.push(wcScheduleDetail);
      });
    }

    const workCenterScheduleEntities = workCenterSchedules.map((wcSchedule) =>
      this.workCenterScheduleRepository.createEntity(wcSchedule),
    );
    itemProducingStepSchedule.dateFrom = moment.utc(dateFrom).toDate();
    itemProducingStepSchedule.dateTo = moment.utc(dateTo).toDate();
    const saleOrderScheduleEntities = [] as SaleOrderScheduleEntity[];
    const itemScheduleEntities = [] as ItemScheduleEntity[];
    masterPlan.saleOrderSchedules?.forEach((saleOrderSchedule) => {
      saleOrderSchedule.itemSchedules.forEach((itemSchedule) => {
        itemSchedule.itemProducingStepSchedules.forEach(
          (producingStepSchedule) => {
            if (producingStepSchedule.id === itemProducingStepSchedule.id) {
              producingStepSchedule.dateFrom =
                itemProducingStepSchedule.dateFrom;
              producingStepSchedule.dateTo = itemProducingStepSchedule.dateTo;
            }
          },
        );
        const producingStepScheduleEndDates = map(
          itemSchedule.itemProducingStepSchedules,
          'dateTo',
        );
        const maxPsScheduleEndDate = this.getMaxDate(
          producingStepScheduleEndDates,
        );
        itemSchedule.dateTo = maxPsScheduleEndDate.split('T')[0];
        itemScheduleEntities.push({ ...itemSchedule });
      });

      const itemScheduleEndDates = map(
        saleOrderSchedule.itemSchedules,
        'dateTo',
      );
      const maxItemScheduleEndDate = this.getMaxDate(itemScheduleEndDates);
      saleOrderSchedule.dateTo = maxItemScheduleEndDate.split('T')[0];
      saleOrderScheduleEntities.push({ ...saleOrderSchedule });
    });

    const saleOrderScheduleEndDates = map(
      masterPlan.saleOrderSchedules,
      'dateTo',
    );
    const maxSaleOrderScheduleEndDate = this.getMaxDate(
      saleOrderScheduleEndDates,
    );
    masterPlan.dateTo = maxSaleOrderScheduleEndDate.split('T')[0];

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(MasterPlanEntity, masterPlan);
      await queryRunner.manager.save(
        SaleOrderScheduleEntity,
        saleOrderScheduleEntities,
      );
      await queryRunner.manager.save(ItemScheduleEntity, itemScheduleEntities);
      await queryRunner.manager.save(
        ItemProducingStepScheduleEntity,
        itemProducingStepSchedule,
      );
      await queryRunner.manager.delete(WorkCenterScheduleEntity, {
        itemProducingStepScheduleId: itemProducingStepId,
      });
      await queryRunner.manager.delete(WorkCenterDetailScheduleEntity, {
        workCenterScheduleId: In(existWorkCenterScheduleIds),
      });
      await queryRunner.manager.save(workCenterScheduleEntities);
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    } finally {
      await queryRunner.release();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async previewModerationEvenly(
    request: ModerationEvenlyRequestDto,
  ): Promise<any> {
    const { masterPlanId } = request;
    const masterPlan = await this.masterPlanRepository.getDetailMasterPlan({
      masterPlanId,
    });

    if (isEmpty(masterPlan)) {
      throw new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const dataItemSchedulesModeration = await this.moderationEvenly(
      request,
      masterPlan,
    );

    if (dataItemSchedulesModeration.statusCode !== ResponseCodeEnum.SUCCESS) {
      return dataItemSchedulesModeration;
    }

    const itemSchedulesModeration = dataItemSchedulesModeration.data;

    itemSchedulesModeration.forEach((itemSchedule) => {
      itemSchedule.producingSteps = itemSchedule.producingStepSchedules;
      delete itemSchedule.producingStepSchedules;
    });

    masterPlan.saleOrderSchedules?.forEach((saleOrderSchedule) => {
      saleOrderSchedule.itemSchedules.forEach(
        (itemSchedule, indexItemSchedule) => {
          const itemScheduleModeration = itemSchedulesModeration.find(
            (item) => item.id === itemSchedule.id,
          );
          if (itemScheduleModeration) {
            saleOrderSchedule.itemSchedules[indexItemSchedule] =
              itemScheduleModeration;
          }
        },
      );

      const itemScheduleEndDates = map(
        saleOrderSchedule.itemSchedules,
        'dateTo',
      );
      const maxItemScheduleEndDate = this.getMaxDate(itemScheduleEndDates);

      saleOrderSchedule.dateTo = maxItemScheduleEndDate;
    });

    const saleOrderScheduleEndDates = map(
      masterPlan.saleOrderSchedules,
      'dateTo',
    );
    const maxSaleOrderScheduleEndDate = this.getMaxDate(
      saleOrderScheduleEndDates,
    );

    masterPlan.dateTo = maxSaleOrderScheduleEndDate;

    const response = await this.formatResponseDetailMasterPlan(masterPlan);

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async moderationEvenly(
    request: ModerationEvenlyRequestDto,
    masterPlan,
  ): Promise<any> {
    const { saleOrderId, itemId, itemProducingStepId } = request;
    const dateFrom = moment(request.dateFrom).format(FORTMAT_DATE_MODERATION);
    const dateTo = moment(request.dateTo).format(FORTMAT_DATE_MODERATION);

    const itemSchedules = await this.itemScheduleRepository.getScheduleByItemId(
      masterPlan.id,
      saleOrderId,
      itemId,
    );

    if (isEmpty(itemSchedules)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    let workCenterIds = [];
    let itemProducingStepCurrent: ProducingStepScheduleRepositoryDto,
      itemScheduleCurrent: ItemScheduleRepositoryDto;
    itemSchedules.forEach((itemSchedule) => {
      itemSchedule?.producingStepSchedules.forEach((producingStepSchedule) => {
        workCenterIds = [].concat(
          map(producingStepSchedule.workCenterSchedules, 'workCenterId'),
          workCenterIds,
        );
        if (producingStepSchedule.id === itemProducingStepId) {
          itemProducingStepCurrent = producingStepSchedule;
          itemScheduleCurrent = {
            ...itemSchedule,
            producingStepSchedules: this.orderByProducingStepSchedules(
              itemSchedule.producingStepSchedules,
            ),
          };
        }
      });
    });
    if (moment(dateFrom).isBefore(moment(itemProducingStepCurrent.dateFrom))) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.BACK_DATE_FROM_MODERATION'),
        )
        .build();
    }

    if (moment(dateTo).isBefore(moment().startOf('day'))) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BACK_DATE_TO_MODERATION'))
        .build();
    }

    if (!itemProducingStepCurrent) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const producingStep = first(
      await this.produceService.getProducingSteps(
        [itemProducingStepCurrent.producingStepId],
        masterPlan.factoryId,
      ),
    ) as any;

    // nếu CĐ cần điều độ không có schedule và có nhiều work center thì báo lỗi
    if (!itemProducingStepCurrent?.workCenterSchedules?.length) {
      if (producingStep?.workCenters?.length !== 1) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.NEED_TO_USE_MODERATION_INPUT_SELECT_ONE_WORK_CENTER',
            ),
          )
          .build();
      }
    }
    const { groupItemsFormatByLevel, levelMax } =
      this.formatItemsByLevel(itemSchedules);
    const levelItemScheduleCurrent = itemScheduleCurrent.level;

    let invalidScheduleItemChildEmpty = false;
    let invalidProducingStepOverLoad = false;
    itemScheduleCurrent.producingStepSchedules.forEach(
      (producingStepSchedule) => {
        if (
          producingStepSchedule.stepNumber < itemProducingStepCurrent.stepNumber
        ) {
          if (producingStepSchedule.quantity == 0) {
            invalidScheduleItemChildEmpty = true;
            return;
          }
          if (producingStepSchedule.overQuantity > 0) {
            invalidProducingStepOverLoad = true;
            return;
          }
        }
      },
    );

    const producingStepIds = [];
    const producingStepScheduleIds = [];

    Object.keys(itemSchedules).forEach((level) => {
      const itemSchedule = itemSchedules[level];
      if (+level > levelItemScheduleCurrent) {
        itemSchedule.producingStepSchedules.forEach((producingStepSchedule) => {
          if (producingStepSchedule.quantity == 0) {
            invalidScheduleItemChildEmpty = true;
            return;
          }
          if (producingStepSchedule.overQuantity > 0) {
            invalidProducingStepOverLoad = true;
            return;
          }
        });
      }
      if (+level < levelItemScheduleCurrent) {
        itemSchedule.producingStepSchedules.forEach((producingStepSchedule) => {
          producingStepIds.push(producingStepSchedule.producingStepId);
          producingStepScheduleIds.push(producingStepSchedule.id);
        });
      }
    });

    // nếu CĐ con không có schedule thì báo lỗi
    if (invalidScheduleItemChildEmpty) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.MODERATION_EVENLY_ERROR_BOM_CHILDREN_SCHEDULE_EMPTY',
          ),
        )
        .build();
    }

    // nếu công đoạn con đang quá tải thì báo lỗi
    if (invalidProducingStepOverLoad) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.MODERATION_EVENLY_ERROR_BOM_CHILDREN_SCHEDULE_EMPTY',
          ),
        )
        .build();
    }

    const normalizeWorkCenter = await this.produceService.getWorkCenterByIds(
      workCenterIds,
      true,
    );

    itemScheduleCurrent.producingStepSchedules =
      this.moderationEvenlyItemScheduleCurrent(
        itemScheduleCurrent,
        itemProducingStepCurrent,
        normalizeWorkCenter,
        dateFrom,
        dateTo,
        masterPlan,
      );
    const producingSteps = await this.produceService.getProducingSteps(
      producingStepIds,
      masterPlan.factoryId,
    );

    const mapWorkCenterByProducingStep = {};
    const producingStepsSerialize = {};
    const workCenterSerialize = {};
    producingSteps.forEach((producingStep) => {
      producingStepsSerialize[producingStep.id] = producingStep;
      const worksCenterByProducingStep = [];
      producingStep.workCenters.forEach((workCenter) => {
        workCenterIds.push(workCenter.id);
        worksCenterByProducingStep.push(workCenter);
        workCenterSerialize[workCenter.id] = {
          ...workCenter,
          producingStepId: producingStep.id,
          productionTimePerItem: producingStep.productionTimePerItem,
        };
      });
      mapWorkCenterByProducingStep[producingStep.id] = orderBy(
        worksCenterByProducingStep,
        'productionTimePerItem',
        ORDER_PERFORMANCE_PRODUCING_STEP,
      ).map((workCenter) => workCenter.id);
    });

    if (isEmpty(workCenterIds)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NO_MATCHING_WORK_CENTER'))
        .build();
    }

    const schedulesInPlan = await this.genScheduleWorkCenterByPlan(
      workCenterIds,
      masterPlan.dateFrom,
      masterPlan.dateTo,
      workCenterSerialize,
      producingStepScheduleIds,
    );

    looplevelTreeItem: for (
      let level = levelItemScheduleCurrent - 1;
      level > 0;
      level--
    ) {
      const items = groupItemsFormatByLevel[level];
      loopItems: for (
        let indexItem = 0;
        indexItem < items?.length;
        indexItem++
      ) {
        const item = items[indexItem];
        if (!item.needToManufacture) {
          continue loopItems;
        }
        let dateFrom = moment(masterPlan.dateFrom).format('YYYY-MM-DD') as any;
        const dateTo = moment(masterPlan.dateTo).format('YYYY-MM-DD');
        let planQuantity = {};
        if (+level !== levelMax) {
          const itemsChild = groupItemsFormatByLevel[+level + 1]
            .filter(
              (itemChild) =>
                itemChild.needToManufacture &&
                itemChild.parentBomId === item.bomId &&
                itemChild.itemFinishId === item.itemFinishId &&
                item.saleOrderScheduleId === itemChild.saleOrderScheduleId,
            )
            .map((item) => {
              if (item.id === itemScheduleCurrent.id) {
                item = itemScheduleCurrent;
              }
              return {
                ...item,
                producingSteps: item.producingStepSchedules,
              };
            });
          const schedulesChild = {};
          itemsChild.forEach((itemChild) => {
            if (itemChild.id === itemScheduleCurrent.id) {
              itemChild.producingStepSchedules =
                itemScheduleCurrent.producingStepSchedules;
            }
            schedulesChild[itemChild.id] = {};
            itemChild.producingStepSchedules.forEach(
              (producingStepSchedule) => {
                schedulesChild[itemChild.id][producingStepSchedule.id] =
                  isEmpty(producingStepSchedule.workCenterSchedules)
                    ? {}
                    : {
                        workCentersSchedule: groupBy(
                          producingStepSchedule.workCenterSchedules,
                          'excutionDate',
                        ),
                      };
              },
            );
          });
          const { dateFromByItemChild, planQuantityItemParent } =
            this.calculateManufactureMinQuantityUpLevel(
              itemsChild,
              schedulesChild,
              item.quantity,
              dateFrom,
              dateTo,
            );
          if (!dateFromByItemChild) {
            continue loopItems;
          }
          dateFrom = dateFromByItemChild;
          planQuantity = planQuantityItemParent;
        }

        const producingSteps = this.orderByProducingStepSchedules(
          item.producingStepSchedules,
        );
        let prevStepNumber = first(producingSteps).stepNumber;
        let currentStepNumber = prevStepNumber;
        loopProducingStep: for (
          let indexProducingStep = 0;
          indexProducingStep < producingSteps.length;
          indexProducingStep++
        ) {
          const itemProducingStep = producingSteps[indexProducingStep];
          if (itemProducingStep.stepNumber !== currentStepNumber) {
            prevStepNumber = currentStepNumber;
            currentStepNumber = itemProducingStep.stepNumber;
          }
          if (prevStepNumber !== currentStepNumber) {
            const prevProducingStepSchedule = producingSteps.filter(
              (producingStep) => producingStep.stepNumber === prevStepNumber,
            );
            dateFrom = max(
              map(
                flatMap(prevProducingStepSchedule, 'workCenterSchedules'),
                'excutionDate',
              ),
            );
          }
          const rate = div(item.quantity, itemProducingStep.planQuantity);
          itemProducingStep.workCenterSchedules.forEach(
            (workCenterSchedule) => {
              if (
                moment(workCenterSchedule.executionDate).isSameOrAfter(
                  dateFrom,
                  'day',
                )
              ) {
              }
            },
          );
          const workCenterIds = isEmpty(producingStep.workCenterSchedules)
            ? mapWorkCenterByProducingStep[itemProducingStep.producingStepId]
            : uniq(map(producingStep.workCenterSchedules, 'workCenterId'));
          const { workCentersSchedule, overQuantity } = genScheduleByShifts(
            dateFrom,
            dateTo,
            itemProducingStep.planQuantity,
            schedulesInPlan,
            workCenterIds,
            workCenterSerialize,
            producingStepsSerialize[itemProducingStep.producingStepId][
              'productionTimePerItem'
            ],
            planQuantity,
            rate,
          );
          producingSteps[indexProducingStep].overQuantity = overQuantity;
          const workCentersSchedules = [];
          Object.keys(workCentersSchedule).forEach((executionDay) => {
            const schedules = workCentersSchedule[executionDay];
            schedules.forEach((schedule) => {
              workCentersSchedules.push({
                executionDay: executionDay,
                workCenterId: schedule.id,
                quantity: schedule.quantity,
                workCenterDetailSchedules: schedule.workCenterDetailSchedules,
              });
            });
          });
          producingSteps[indexProducingStep].workCenterSchedules =
            workCentersSchedules;
          producingSteps[indexProducingStep].quantity = sumBy(
            workCentersSchedules,
            'quantity',
          );
        }
        groupItemsFormatByLevel[level][indexItem].producingStepSchedules =
          producingSteps;
      }
    }

    let serializeItemParent = keyBy([itemScheduleCurrent], 'bomId');
    loopLevelTreeItem: for (
      let level = levelItemScheduleCurrent + 1;
      level <= levelMax;
      level++
    ) {
      const items = groupItemsFormatByLevel[level].filter((item) =>
        has(serializeItemParent, item.parentBomId),
      );

      loopItems: for (
        let indexItem = 0;
        indexItem < items?.length;
        indexItem++
      ) {
        const item: ItemScheduleRepositoryDto = items[indexItem];
        const itemParent = serializeItemParent[item.parentBomId];
        const schedulesProducingStep = {};
        itemParent.producingStepSchedules.forEach((producingStepSchedule) => {
          schedulesProducingStep[producingStepSchedule.id] = {
            workCentersSchedule: groupBy(
              producingStepSchedule.workCenterSchedules,
              'excutionDate',
            ),
          };
        });
        const { planQuantityProducingSteps: planItemParent } =
          this.calculatePlanQuantityItemByProducingSteps(
            itemParent.quantity,
            itemParent.producingStepSchedules,
            schedulesProducingStep,
            item.dateTo,
          );
        const groupProducingStepByStepNumber = groupBy(
          item.producingStepSchedules,
          'stepNumber',
        );

        const stepMax = max(Object.keys(producingSteps));
        const rateItem = div(item.quantity, itemParent.quantity);

        let endDaySchedule;
        loopProducingStepMax: for (
          let indexProducingStepMax = 0;
          indexProducingStepMax <
          groupProducingStepByStepNumber[stepMax].length;
          indexProducingStepMax++
        ) {
          const producingStepSchedule =
            groupProducingStepByStepNumber[stepMax][indexProducingStepMax];
          const groupWorkCenterSheduleByDay = groupBy(
            producingStepSchedule.workCenterSchedules,
            'excutionDate',
          );
          const workCenterIdsByProducingStep = uniq(
            map(producingStepSchedule.workCenterSchedules, 'workCenterId'),
          );
          let remainQuantity = 0;
          loopPlanItem: for (const executionDay in planItemParent) {
            const dateTo = moment(executionDay, FORTMAT_DATE_MODERATION)
              .subtract(MANUFACTURE_BEFORE_DAY_UP_LEVEL, 'day')
              .format(FORTMAT_DATE_MODERATION);
            const dateFrom = endDaySchedule
              ? moment(endDaySchedule)
                  .add(1, 'day')
                  .format(FORTMAT_DATE_MODERATION)
              : min(Object.keys(groupWorkCenterSheduleByDay));
            const executionDayProducingStep = createDateRange(dateFrom, dateTo);
            endDaySchedule = dateTo;
            if (isEmpty(executionDayProducingStep)) {
              break loopItems;
            }
            let totalShift = 0;
            let quantityCurrent = remainQuantity;
            executionDayProducingStep.forEach((executionDay) => {
              groupWorkCenterSheduleByDay[executionDay]?.forEach(
                (workCenterShedule) => {
                  quantityCurrent = plus(
                    quantityCurrent,
                    workCenterShedule.quantity,
                  );
                },
              );
            });
            workCenterIdsByProducingStep.forEach((workCenterId) => {
              totalShift = plus(
                totalShift,
                normalizeWorkCenter[workCenterId]?.workCenterShifts.length,
              );
            });
            let quantityByItem = mul(
              div(producingStepSchedule.planQuantity, item.quantity),
              mul(planItemParent[executionDay], rateItem),
            );

            if (quantityCurrent > quantityByItem) {
              remainQuantity = plus(
                remainQuantity,
                minus(quantityCurrent, quantityByItem),
              );
              continue loopPlanItem;
            }
            const averageQuantity = Math.floor(
              div(
                quantityByItem,
                mul(totalShift, executionDayProducingStep.length),
              ),
            );

            executionDayProducingStep.forEach((excutionDate) => {
              const workCenterShedules = workCenterIdsByProducingStep.map(
                (workCenterId) => {
                  const workCenterDetailSchedules = normalizeWorkCenter[
                    workCenterId
                  ]?.workCenterShifts.map((shift) => {
                    return this.workCenterDetailScheduleRepository.createEntity(
                      {
                        workCenterShiftScheduleId: shift.id,
                        excutionFrom: shift.startAt,
                        excutionTo: shift.endAt,
                        quantity: averageQuantity,
                      },
                    );
                  });
                  return this.workCenterScheduleRepository.createEntity({
                    workCenterId,
                    itemProducingStepScheduleId: producingStepSchedule.id,
                    quantity: sumBy(workCenterDetailSchedules, 'quantity'),
                    excutionDate: excutionDate,
                    workCenterDetailSchedules: workCenterDetailSchedules,
                  });
                },
              );
              groupWorkCenterSheduleByDay[excutionDate] =
                workCenterShedules as any;
              quantityByItem = minus(
                quantityByItem,
                sumBy(workCenterShedules, 'quantity'),
              );
            });
            remainQuantity = 0;
            if (quantityByItem > 0) {
              const workCenterSheduleLastDay = last(
                groupWorkCenterSheduleByDay[dateTo],
              );
              workCenterSheduleLastDay.quantity = plus(
                workCenterSheduleLastDay.quantity,
                quantityByItem,
              );
              const lastShift = last(
                workCenterSheduleLastDay.workCenterDetailSchedules,
              );
              lastShift.quantity = plus(lastShift.quantity, quantityByItem);
            }
          }
          groupProducingStepByStepNumber[stepMax][
            indexProducingStepMax
          ].workCenterSchedules = flatMap(
            values(groupWorkCenterSheduleByDay),
          ) as any;
        }
        item.producingStepSchedules = flatMap(
          values(groupProducingStepByStepNumber),
        ) as any;
        items[indexItem] = item;
      }
      groupItemsFormatByLevel[level] = items;
      serializeItemParent = keyBy(items, 'bomId');
    }

    const flatFormatItemSchedules = values(flatMap(groupItemsFormatByLevel));
    flatFormatItemSchedules.forEach((itemSchedule) => {
      const producingStepEndDates = map(
        itemSchedule.producingStepSchedules,
        'dateTo',
      );
      const maxProducingStepEndDate = this.getMaxDate(producingStepEndDates);
      itemSchedule.dateTo = maxProducingStepEndDate;
    });

    return new ResponseBuilder(flatFormatItemSchedules)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private orderByProducingStepSchedules(producingStepSchedules) {
    return orderBy(
      producingStepSchedules,
      'stepNumber',
      ORDER_STEP_NUMBER_PRODUCING_STEP,
    );
  }

  private moderationEvenlyItemScheduleCurrent(
    itemScheduleCurrent: ItemScheduleRepositoryDto,
    producingStepScheduleCurrent: ProducingStepScheduleRepositoryDto,
    normalizeWorkCenter,
    dateFrom,
    dateTo,
    masterPlan,
  ): ProducingStepScheduleRepositoryDto[] {
    const isExtendDateTo = moment(dateTo).isAfter(
      moment(producingStepScheduleCurrent.dateTo),
    );
    producingStepScheduleCurrent = this.moderationSpread(
      producingStepScheduleCurrent,
      normalizeWorkCenter,
      dateFrom,
      dateTo,
    );
    const indexProducingStepCurrent = findIndex(
      itemScheduleCurrent.producingStepSchedules,
      ['id', producingStepScheduleCurrent.id],
    );
    itemScheduleCurrent.producingStepSchedules[indexProducingStepCurrent] =
      producingStepScheduleCurrent;
    const groupProducingStepScheduleByStepNumber = groupBy(
      itemScheduleCurrent.producingStepSchedules,
      'stepNumber',
    );
    const stepMin = +min(Object.keys(groupProducingStepScheduleByStepNumber));
    const stepMax = +max(Object.keys(groupProducingStepScheduleByStepNumber));
    for (
      let step = +producingStepScheduleCurrent.stepNumber - 1;
      step >= stepMin;
      step--
    ) {
      const dateTo = min(
        map(groupProducingStepScheduleByStepNumber[step + 1], 'dateTo'),
      );
      groupProducingStepScheduleByStepNumber[step].forEach(
        (producingStepSchedule) => {
          const isNarrowDateTo = moment(dateTo).isBefore(
            producingStepSchedule.dateTo,
          );
          const psScheduleDateTo = isNarrowDateTo
            ? dateTo
            : producingStepSchedule.dateTo;

          producingStepSchedule = this.moderationSpread(
            producingStepSchedule,
            normalizeWorkCenter,
            producingStepSchedule.dateFrom,
            psScheduleDateTo,
          );
        },
      );
    }

    for (
      let step = +producingStepScheduleCurrent.stepNumber + 1;
      step <= stepMax;
      step++
    ) {
      const lastDateTo = max(
        map(groupProducingStepScheduleByStepNumber[step - 1], 'dateTo'),
      );

      groupProducingStepScheduleByStepNumber[step].forEach(
        (producingStepSchedule) => {
          const nextProducingStepDateFrom = moment(lastDateTo)
            .add(1, 'days')
            .format(FORTMAT_DATE_MODERATION);

          const filteredNormalizeWorkCenter = Object.values(
            normalizeWorkCenter as { [key: string]: any },
          ).filter(
            (item) =>
              item?.producingStepId === producingStepSchedule.producingStepId,
          );

          const totalWorkingCapacity = filteredNormalizeWorkCenter
            ?.map((workCenter) => workCenter?.actualWorkingCapacity)
            ?.reduce((prev, cur) => plus(prev, cur), 0);

          // const workingCapacityPerDay = mul(
          //   totalWorkingCapacity,
          //   PLAN_TIME_FORMAT.DAY,
          // );
          const workingDays = Math.ceil(
            div(+producingStepSchedule.planQuantity, totalWorkingCapacity || 1),
          );
          const nextProducingStepDateTo = moment(nextProducingStepDateFrom)
            .add(workingDays - 1, 'days')
            .format(FORTMAT_DATE_MODERATION);
          // const masterPlanEndDate = moment(masterPlan.dateTo).format(
          //   FORTMAT_DATE_MODERATION,
          // );

          // const isOverPlanned = moment(masterPlanEndDate).isBefore(
          //   moment(nextProducingStepDateTo),
          // );

          // if (isOverPlanned) {
          //   nextProducingStepDateTo = masterPlanEndDate;
          // }
          producingStepSchedule = this.moderationSpread(
            producingStepSchedule,
            normalizeWorkCenter,
            nextProducingStepDateFrom,
            nextProducingStepDateTo,
          );
        },
      );
    }
    return flatMap(values(groupProducingStepScheduleByStepNumber));
  }
  /**
   * Điều độ set cứng
   * @param request
   * @returns
   */
  async moderationInputCapacity(
    request: ModerationInputRequestDto,
  ): Promise<any> {
    const { id, producingStepSchedules } = request;
    const masterPlan = await this.masterPlanRepository.findOneById(id);

    if (isEmpty(masterPlan)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_MODERATION_MASTER_PLAN.includes(masterPlan.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }

    const invalidDateMorderation = flatMap(
      map(producingStepSchedules, 'workCenterDetailSchedules'),
    ).filter(
      (workCenterDetailSchedule) =>
        moment(workCenterDetailSchedule.date).isBefore(
          moment().format(),
          'day',
        ) || moment(workCenterDetailSchedule.date).isAfter(masterPlan.dateTo),
    );

    if (!isEmpty(invalidDateMorderation)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.MODERATION_DATE_MUST_BE_GREATER_THAN_CURRENT_DATE',
          ),
        )
        .build();
    }

    const dataProducingStepSchedules =
      await this.updateProducingStepScheduleEntities(
        masterPlan.factoryId,
        producingStepSchedules,
      );

    if (dataProducingStepSchedules.statusCode !== ResponseCodeEnum.SUCCESS) {
      return dataProducingStepSchedules;
    }

    const {
      itemProducingStepEntities,
      workCenterScheduleEntities,
      workCenterDetailScheduleEntites,
    } = dataProducingStepSchedules.data;

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(itemProducingStepEntities);
      await queryRunner.manager.save(workCenterScheduleEntities);
      await queryRunner.manager.save(workCenterDetailScheduleEntites);
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    } finally {
      await queryRunner.release();
      // await this.eventEmitter.emit('master-plan.moderated', {
      //   id: id,
      // });
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async updateProducingStepScheduleEntities(
    factoryId,
    producingStepSchedules: UpdateProducingStepScheduleDto[],
    hasValidateQuantity = true,
  ): Promise<any> {
    const serializeWorkCenterSchedulesDetail = {};
    const producingStepScheduleIds = [];

    const prefixKey = '_';

    forEach(producingStepSchedules, (producingStepSchedule) => {
      producingStepScheduleIds.push(
        producingStepSchedule.producingStepScheduleId,
      );
      forEach(
        producingStepSchedule.workCenterDetailSchedules,
        (workCenterDetailSchedule) => {
          const keySchedule = [
            producingStepSchedule.producingStepScheduleId,
            workCenterDetailSchedule.date,
            workCenterDetailSchedule.workCenterId,
            workCenterDetailSchedule.workCenterShiftScheduleId,
          ].join(prefixKey);
          serializeWorkCenterSchedulesDetail[keySchedule] =
            workCenterDetailSchedule.quantity;
        },
      );
    });

    const itemProducingStepSchedules =
      await this.itemProducingStepScheduleRepository.findWithRelations({
        where: {
          id: In(producingStepScheduleIds),
        },
        relations: [
          'workCenterSchedules',
          'workCenterSchedules.workCenterDetailSchedules',
        ],
      });

    if (
      itemProducingStepSchedules.length !==
      uniq(producingStepScheduleIds).length
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.PRODUCING_STEP_SCHEDULE_NOT_FOUND'),
        )
        .build();
    }

    const producingStepIds = {};
    const itemProducingStepEntities = {};
    const workCenterScheduleEntities = {};
    const workCenterDetailScheduleEntites = [];
    const moderationPlanQuantityProducingStepSchedules = {};

    itemProducingStepSchedules.forEach((itemProducingStepSchedule) => {
      producingStepIds[itemProducingStepSchedule.id] =
        itemProducingStepSchedule.producingStepId;
      let itemProducingStepScheduleQuantity = 0;

      moderationPlanQuantityProducingStepSchedules[
        itemProducingStepSchedule.id
      ] = {
        planQuantity: itemProducingStepSchedule.planQuantity,
        quantity: 0,
      };
      // duyệt qua từng shift schedule đã có
      itemProducingStepSchedule?.workCenterSchedules?.forEach(
        (workCenterSchedule) => {
          let workCenterScheduleQuantity = 0;
          // Nếu shift schedule có thay đổi thì update quantity, nếu không có thì quantity = 0
          workCenterSchedule?.workCenterDetailSchedules.forEach(
            (workCenterDetailSchedule) => {
              const keySchedule = [
                itemProducingStepSchedule.id,
                workCenterSchedule.excutionDate,
                workCenterSchedule.workCenterId,
                workCenterDetailSchedule.workCenterShiftScheduleId,
              ].join(prefixKey);
              let moderationQuantity = workCenterDetailSchedule.quantity;
              const scheduleExist = has(
                serializeWorkCenterSchedulesDetail,
                keySchedule,
              );
              if (scheduleExist) {
                moderationQuantity =
                  serializeWorkCenterSchedulesDetail[keySchedule];
                // Nếu schedule request đã update sẽ xóa đi tránh tạo 2 lần
                delete serializeWorkCenterSchedulesDetail[keySchedule];
              }

              // Nếu schedule đã sản xuất rồi sẽ lấy actual quantity để validate
              moderationPlanQuantityProducingStepSchedules[
                itemProducingStepSchedule.id
              ].quantity = plus(
                moment(workCenterSchedule.excutionDate).isBefore(
                  moment().startOf('day').format(FORTMAT_DATE_MODERATION),
                  'day',
                )
                  ? workCenterDetailSchedule.actualQuantity
                  : moderationQuantity,
                moderationPlanQuantityProducingStepSchedules[
                  itemProducingStepSchedule.id
                ].quantity,
              );
              workCenterDetailSchedule.quantity = moderationQuantity;
              workCenterScheduleQuantity = plus(
                workCenterScheduleQuantity,
                moderationQuantity,
              );
              workCenterDetailScheduleEntites.push(workCenterDetailSchedule);
            },
          );
          itemProducingStepScheduleQuantity = plus(
            itemProducingStepScheduleQuantity,
            workCenterScheduleQuantity,
          );
          workCenterSchedule.quantity = workCenterScheduleQuantity;
          workCenterScheduleEntities[
            [
              itemProducingStepSchedule.id,
              workCenterSchedule.workCenterId,
              workCenterSchedule.excutionDate,
            ].join(prefixKey)
          ] = workCenterSchedule;
        },
      );
      // Update producing step schedule
      itemProducingStepSchedule.quantity = itemProducingStepScheduleQuantity;
      itemProducingStepSchedule.overQuantity = minus(
        itemProducingStepSchedule.planQuantity,
        itemProducingStepScheduleQuantity,
      );
      itemProducingStepEntities[itemProducingStepSchedule.id] =
        itemProducingStepSchedule;
    });

    const invalidWorkCenter = [];
    // Nếu có shift schedule mới thì tạo mới entity
    if (!isEmpty(serializeWorkCenterSchedulesDetail)) {
      const producingSteps = await this.produceService.getProducingSteps(
        values(producingStepIds),
        factoryId,
      );
      const serializeProducingStep = keyBy(producingSteps, 'id');
      Object.keys(serializeWorkCenterSchedulesDetail).forEach((keySchedule) => {
        const [
          itemProducingStepScheduleId,
          executionDate,
          workCenterId,
          workCenterShiftId,
        ] = keySchedule.split(prefixKey);

        const quantity = serializeWorkCenterSchedulesDetail[keySchedule];
        const key = [
          itemProducingStepScheduleId,
          workCenterId,
          executionDate,
        ].join(prefixKey);

        const producingStep =
          serializeProducingStep[producingStepIds[itemProducingStepScheduleId]];
        const workCenter = producingStep.workCenters.find(
          (workCenter) => workCenter.id === +workCenterId,
        );
        if (isEmpty(workCenter)) {
          invalidWorkCenter.push(workCenterId);
          return;
        }
        const shift = workCenter.workCenterShifts.find(
          (workCenterShift) => workCenterShift.id === +workCenterShiftId,
        );
        if (isEmpty(shift)) {
          invalidWorkCenter.push(workCenterId);
          return;
        }
        const workCenterDetailScheduleEntity =
          this.workCenterDetailScheduleRepository.createEntity({
            quantity,
            workCenterShiftScheduleId: workCenterShiftId,
            excutionTo: shift.endAt,
            excutionFrom: shift.startAt,
          });
        itemProducingStepEntities[itemProducingStepScheduleId].quantity = plus(
          itemProducingStepEntities[itemProducingStepScheduleId].quantity,
          quantity,
        );
        if (
          moment(
            itemProducingStepEntities[itemProducingStepScheduleId].dateTo,
          ).isBefore(executionDate)
        ) {
          itemProducingStepEntities[itemProducingStepScheduleId].dateTo =
            executionDate;
        }

        // Update lại dateFrom/dateTo của producing step schedule
        if (
          moment(
            itemProducingStepEntities[itemProducingStepScheduleId].dateFrom,
          ).isAfter(executionDate)
        ) {
          itemProducingStepEntities[itemProducingStepScheduleId].dateFrom =
            executionDate;
        }
        itemProducingStepEntities[itemProducingStepScheduleId].overQuantity =
          minus(
            itemProducingStepEntities[itemProducingStepScheduleId].planQuantity,
            itemProducingStepEntities[itemProducingStepScheduleId].quantity,
          );
        moderationPlanQuantityProducingStepSchedules[
          itemProducingStepScheduleId
        ].quantity = plus(
          moderationPlanQuantityProducingStepSchedules[
            itemProducingStepScheduleId
          ].quantity,
          quantity,
        );
        if (has(workCenterScheduleEntities, key)) {
          workCenterScheduleEntities[key].quantity = plus(
            workCenterScheduleEntities[key].quantity,
            quantity,
          );
        } else {
          workCenterScheduleEntities[key] =
            this.workCenterScheduleRepository.createEntity({
              quantity,
              workCenterId,
              itemProducingStepScheduleId,
              excutionDate: executionDate,
              workCenterDetailSchedules: [],
            });
        }
        // Nếu đã có work center schedule thì tạo mới shift schedule entity để tạo mới thông qua relations ngc lại sẽ tạo mới trực tiếp
        if (workCenterScheduleEntities[key]?.id) {
          workCenterDetailScheduleEntity.workCenterScheduleId =
            workCenterScheduleEntities[key].id;
          workCenterDetailScheduleEntites.push(workCenterDetailScheduleEntity);
        } else {
          workCenterScheduleEntities[key].workCenterDetailSchedules.push(
            workCenterDetailScheduleEntity,
          );
        }
      });
    }

    if (!isEmpty(invalidWorkCenter)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_CENTER_NOT_EXIST'))
        .build();
    }

    const invalidPlanQuantityProducingStepSchedules = values(
      moderationPlanQuantityProducingStepSchedules,
    ).filter((item: any) => item.quantity !== item.planQuantity);

    if (
      hasValidateQuantity &&
      !isEmpty(invalidPlanQuantityProducingStepSchedules)
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.MODERATION_QUANTITY_MUST_BE_EQUAL_PLAN_QUANTITY',
          ),
        )
        .build();
    }

    return new ResponseBuilder({
      itemProducingStepEntities: values(itemProducingStepEntities),
      workCenterScheduleEntities: values(workCenterScheduleEntities),
      workCenterDetailScheduleEntites: values(workCenterDetailScheduleEntites),
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async getMasterPlans(
    request: GetMasterPlanRequestDto,
  ): Promise<ResponsePayload<GetMasterPlanResponseDto | any>> {
    const {
      soId,
      itemIds,
      masterPlanId,
      skip,
      take,
      page,
      isGetAll,
      filter,
      keyword,
      sort,
    } = request;

    const temp: any[] = [];
    const arr = itemIds?.split(',');
    for (let i = 0; i < arr?.length; i++) {
      const element = arr[i];
      temp.push(Number(element));
    }
    const params = {
      soId,
      itemIds: temp,
      masterPlanId,
      isOverQuantity: false,
      skip,
      take,
      isGetAll,
      filter,
      keyword,
      sort,
    };
    const { result, total } = await this.masterPlanRepository.getMasterPlans(
      params,
    );

    let saleOrderIds = [];
    const factoryIds = [];
    result.forEach((masterPlan) => {
      saleOrderIds = saleOrderIds.concat(map(masterPlan.saleOrderIds, 'id'));
      factoryIds.push(masterPlan.factoryId);
    });

    const factoriesSerialize = await this.userService.getFactoriesByIds(
      uniq(factoryIds),
      true,
    );

    // const saleOrdersSerialize = await this.saleService.getByIds(
    //   uniq(saleOrderIds),
    //   true,
    // );
    const saleOrdersSerialize = await this.requestService.getRequestOrderByIds(
      uniq(saleOrderIds),
      true,
    );
    result.map((masterPlan) => {
      masterPlan['factory'] = has(factoriesSerialize, masterPlan.factoryId)
        ? factoriesSerialize[masterPlan.factoryId]
        : {};
      masterPlan['saleOrders'] = masterPlan.saleOrderIds
        .map((saleOrders) => {
          if (has(saleOrdersSerialize, saleOrders.id)) {
            return saleOrdersSerialize[saleOrders.id];
          }
        })
        .filter((saleOrder) => !isEmpty(saleOrder));
      return masterPlan;
    });

    const response = plainToInstance(MasterPlanListData, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder({
      masterPlans: response,
      meta: { total: total, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async detail(request: GetMasterPlanDetailRequestDto): Promise<any> {
    const { isActive } = request;
    const masterPlan: any = await this.masterPlanRepository.getDetailMasterPlan(
      request,
    );

    if (isEmpty(masterPlan)) {
      return new ResponseBuilder({})
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (isActive && !MASTER_PLAN_IS_ACTIVE.includes(masterPlan.status)) {
      return new ResponseBuilder({})
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (MASTER_PLAN_GEN_SCHEDULE.includes(masterPlan.status)) {
      await this.formatMasterPlanSchedule(masterPlan);
    }

    const response = await this.formatResponseDetailMasterPlan(masterPlan);

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async formatResponseDetailMasterPlan(
    masterPlan,
  ): Promise<ResponsePayload<MasterPlanResponseDto> | any> {
    const saleOrderIds: any[] = [];
    const itemIds: any[] = [];
    const producingStepIds: any[] = [];
    let workCenterIds: any[] = [];
    const itemSchedules = [];

    const userIds = uniq(
      [masterPlan.createdBy, masterPlan.updatedBy].filter(
        (userId) => !isNil(userId),
      ),
    );

    masterPlan.saleOrderSchedules?.forEach((saleOrderSchedule) => {
      saleOrderIds.push(saleOrderSchedule.saleOrderId);
      saleOrderSchedule?.itemSchedules?.forEach((itemSchedule) => {
        itemSchedules.push({
          ...itemSchedule,
          saleOrderId: saleOrderSchedule.saleOrderId,
        });
        itemIds.push(itemSchedule.itemId);
        itemSchedule?.producingSteps?.forEach((producingStep) => {
          producingStepIds.push(producingStep.producingStepId);
          workCenterIds = flatMap(
            workCenterIds,
            map(producingStep.workCenterSchedules, 'workCenterId'),
          );
        });
      });
    });

    const [
      serializeSaleOrder,
      serializeItem,
      serializeBom,
      serializeProducingStep,
      serializeWorkCenter,
      serializeFactory,
      serializeUser,
    ] = await Promise.all([
      //this.saleService.getByIds(saleOrderIds, true),
      this.requestService.getRequestOrderByIds(saleOrderIds, true),
      this.itemService.getItemByIds(itemIds, true),
      this.produceService.getBomByItemIds(itemIds, true),
      this.produceService.getListProducingStepByIds(producingStepIds, true),
      this.produceService.getWorkCenterByIds(workCenterIds, true),
      this.userService.getFactoriesByIds([masterPlan.factoryId], true),
      this.userService.getUsersByIds(userIds, true),
    ]);

    itemSchedules.forEach((itemSchedule) => {
      if (has(serializeBom, itemSchedule.itemId)) {
        itemSchedule.routing = serializeBom[itemSchedule.itemId]?.routing;
        itemSchedule.bom = serializeBom[itemSchedule.itemId];
      }
      if (has(serializeItem, itemSchedule.itemId)) {
        itemSchedule.itemName = serializeItem[itemSchedule.itemId]?.name;
        itemSchedule.itemCode = serializeItem[itemSchedule.itemId]?.code;
        itemSchedule.itemUnitName =
          serializeItem[itemSchedule.itemId]?.itemUnitName;
      }
      itemSchedule?.producingSteps?.forEach((producingStep) => {
        if (has(serializeProducingStep, producingStep.producingStepId)) {
          producingStep.producingStepName =
            serializeProducingStep[producingStep.producingStepId]?.name;
          producingStep.producingStepCode =
            serializeProducingStep[producingStep.producingStepId]?.code;
        }
        producingStep.workCenterSchedules.forEach((workCenterSchedule) => {
          if (has(serializeWorkCenter, workCenterSchedule.workCenterId)) {
            workCenterSchedule.workCenterName =
              serializeWorkCenter[workCenterSchedule.workCenterId]?.name;
          }
        });
      });
    });

    const treeItemSchedules = this.genTreeItem(itemSchedules, null);

    masterPlan.factory = has(serializeFactory, masterPlan.factoryId)
      ? serializeFactory[masterPlan.factoryId]
      : {};
    const saleOrdersBomTree = [];

    masterPlan.saleOrderSchedules.forEach((saleOrderSchedule) => {
      if (has(serializeSaleOrder, saleOrderSchedule.saleOrderId)) {
        saleOrderSchedule.saleOrderName =
          serializeSaleOrder[saleOrderSchedule.saleOrderId]?.name;
        saleOrderSchedule.saleOrderCode =
          serializeSaleOrder[saleOrderSchedule.saleOrderId]?.code;
      }
      const saleOrderBomTree = {
        id: saleOrderSchedule.saleOrderId,
        items: [],
      };
      saleOrderSchedule.itemSchedules = treeItemSchedules.filter(
        (item) => item.saleOrderScheduleId === saleOrderSchedule.id,
      );
      saleOrderSchedule.itemSchedules.forEach((itemSchedule) => {
        saleOrderBomTree.items.push(
          this.formatBomTreeItemSaleOrder(itemSchedule),
        );
      });
      saleOrdersBomTree.push(saleOrderBomTree);
    });

    return plainToInstance(
      MasterPlanResponseDto,
      {
        ...masterPlan,
        createdBy: {
          id: masterPlan.createdBy,
          fullname: has(serializeUser, masterPlan.createdBy)
            ? serializeUser[masterPlan.createdBy]?.fullName
            : null,
        },
        updatedBy: {
          id: masterPlan.updatedBy,
          fullname: has(serializeUser, masterPlan.updatedBy)
            ? serializeUser[masterPlan.updatedBy]?.fullName
            : null,
        },
        saleOrders: saleOrdersBomTree,
      },
      {
        excludeExtraneousValues: true,
      },
    );
  }

  formatBomTreeItemSaleOrder(itemSchedule) {
    const bomItem = {
      itemId: itemSchedule.itemId,
      isProductionObject: itemSchedule.needToManufacture,
      subBoms: [],
    };
    if (itemSchedule.subBom) {
      itemSchedule.subBom.forEach((itemSubBom) => {
        bomItem.subBoms.push(this.formatBomTreeItemSaleOrder(itemSubBom));
      });
    }
    return bomItem;
  }

  public async getDetailItemsProducingStep(
    request: GetDetailItemProducingStepRequestDto,
  ): Promise<any> {
    const { masterPlanId, itemProducingStepIds } = request;
    const masterPlan = await this.masterPlanRepository.getDetailMasterPlan({
      masterPlanId,
    });

    if (isEmpty(masterPlan)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const itemProducingSteps = [];
    if (MASTER_PLAN_GEN_SCHEDULE.includes(masterPlan.status)) {
      await this.formatMasterPlanSchedule(masterPlan);
    }
    masterPlan.saleOrderSchedules.forEach((saleOrderSchedule) => {
      saleOrderSchedule.itemSchedules.forEach((itemSchedule) => {
        itemSchedule.producingSteps.forEach((itemProducingStep) => {
          if (itemProducingStepIds.includes(itemProducingStep.id.toString())) {
            itemProducingSteps.push(itemProducingStep);
          }
        });
      });
    });
    if (
      isEmpty(itemProducingSteps) ||
      itemProducingSteps.length !== itemProducingStepIds.length
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    let workCenterIds = [];
    itemProducingSteps.forEach((itemProducingStep) => {
      itemProducingStep.workCenterSchedules.forEach((workCenter) => {
        workCenterIds.push(workCenter.workCenterId);
      });
    });
    if (isEmpty(workCenterIds)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NO_MATCHING_WORK_CENTER'))
        .build();
    }
    workCenterIds = uniq(workCenterIds);
    const producingStepIds = uniq(map(itemProducingSteps, 'producingStepId'));
    const producingSteps = await this.produceService.getProducingSteps(
      producingStepIds,
      masterPlan.factoryId,
    );
    const producingStepSerialize = keyBy(producingSteps, 'id');
    itemProducingSteps.map((itemProducingStep) => {
      const producingStep =
        producingStepSerialize[itemProducingStep.producingStepId];
      const data = this.formatScheduleByProducingStepSchedule(
        masterPlan.dateFrom,
        masterPlan.dateTo,
        producingStep?.workCenters,
        itemProducingStep.workCenterSchedules,
      );

      itemProducingStep['producingStepName'] = producingStep?.name;
      itemProducingStep.workCenterSchedules = data;
      return itemProducingStep;
    });

    const response = plainToInstance(
      ItemProducingStepScheduleResponseDto,
      itemProducingSteps,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async suggestCustomModerations(
    request: GetDetailItemProducingStepRequestDto,
  ): Promise<any> {
    const { masterPlanId, itemProducingStepIds } = request;
    const masterPlan = await this.masterPlanRepository.getDetailMasterPlan({
      masterPlanId,
    });
    if (isEmpty(masterPlan)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const itemProducingSteps = [];
    if (MASTER_PLAN_GEN_SCHEDULE.includes(masterPlan.status)) {
      await this.formatMasterPlanSchedule(masterPlan);
    }

    masterPlan.saleOrderSchedules.forEach((saleOrderSchedule) => {
      saleOrderSchedule.itemSchedules.forEach((itemSchedule) => {
        itemSchedule.producingSteps.forEach((itemProducingStep) => {
          if (itemProducingStepIds.includes(itemProducingStep.id.toString())) {
            itemProducingSteps.push(itemProducingStep);
          }
        });
      });
    });
    if (
      isEmpty(itemProducingSteps) ||
      itemProducingSteps.length !== itemProducingStepIds.length
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    let workCenterIds = [];
    itemProducingSteps.forEach((itemProducingStep) => {
      itemProducingStep.workCenterSchedules.forEach((workCenter) => {
        workCenterIds.push(workCenter.workCenterId);
      });
    });
    if (isEmpty(workCenterIds)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NO_MATCHING_WORK_CENTER'))
        .build();
    }
    workCenterIds = uniq(workCenterIds);
    const producingStepIds = uniq(map(itemProducingSteps, 'producingStepId'));
    const producingSteps = await this.produceService.getProducingSteps(
      producingStepIds,
      masterPlan.factoryId,
    );

    const workCenters = await this.produceService.getWorkCenterByIds(
      workCenterIds,
      true,
    );

    const producingStepSerialize = keyBy(producingSteps, 'id');
    itemProducingSteps.map((itemProducingStep) => {
      this.moderationSpread(
        itemProducingStep,
        workCenters,
        itemProducingStep.dateFrom,
        masterPlan.dateTo,
        true,
      );
      const producingStep =
        producingStepSerialize[itemProducingStep.producingStepId];
      const data = this.formatScheduleByProducingStepSchedule(
        masterPlan.dateFrom,
        masterPlan.dateTo,
        producingStep?.workCenters,
        itemProducingStep.workCenterSchedules,
      );
      itemProducingStep['producingStepName'] = producingStep?.name;
      itemProducingStep.workCenterSchedules = data;
      return itemProducingStep;
    });

    const response = plainToInstance(
      ItemProducingStepScheduleResponseDto,
      itemProducingSteps,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  formatScheduleByProducingStepSchedule(
    dateFrom,
    dateTo,
    workCenters,
    workCenterSchedules,
  ) {
    workCenterSchedules.forEach((wcSchedule) => {
      if (moment(wcSchedule.excutionDate).isBefore(moment().startOf('day'))) {
        wcSchedule.quantity = wcSchedule.actualQuantity;
      }
    });
    const diffDay = getDiffDay(dateFrom, dateTo);
    const data = [];
    const workCenterScheduleSerialize = keyBy(
      workCenterSchedules,
      (workCenterSchedule) =>
        `${workCenterSchedule.workCenterId}-${workCenterSchedule.excutionDate}`,
    );
    workCenters.forEach((workCenter) => {
      const workCenterSchedule = {
        id: null,
        quantity: 0,
        workCenterId: workCenter.id,
        workCenterDetailSchedules: workCenter.workCenterShifts.map((shift) => {
          return {
            id: null,
            quantity: 0,
            workCenterShiftScheduleId: shift.id,
          };
        }),
      };
      for (let indexDay = 0; indexDay < diffDay; indexDay++) {
        const day = moment(dateFrom).add(indexDay, 'day').format('YYYY-MM-DD');
        const key = `${workCenter.id}-${day}`;
        data.push({
          workCenterName: workCenter.name,
          excutionDate: day,
          ...(has(workCenterScheduleSerialize, key)
            ? workCenterScheduleSerialize[key]
            : workCenterSchedule),
        });
      }
    });
    return data;
  }

  /**
   *
   * @param request
   * @returns
   */
  public async suggestModerationInput(
    request: SuggestModerationInputRequestDto,
  ): Promise<any> {
    const { masterPlanId, itemProducingStepIds } = request;
    const masterPlan = await this.masterPlanRepository.getDetailMasterPlan({
      masterPlanId,
    });

    if (isEmpty(masterPlan)) {
      return new ResponseBuilder([])
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const itemProducingSteps = [];
    // TODO @longnq check lai xem nếu e bỏ chỗ này thì có sao k
    if (masterPlan.status === MasterPlanStatusEnum.CREATED) {
      await this.formatMasterPlanSchedule(masterPlan);
    }

    masterPlan.saleOrderSchedules.forEach((saleOrderSchedule) => {
      saleOrderSchedule.itemSchedules.forEach((itemSchedule) => {
        itemSchedule.producingSteps.forEach((itemProducingStep) => {
          if (itemProducingStepIds.includes(itemProducingStep.id.toString())) {
            itemProducingSteps.push(itemProducingStep);
          }
        });
      });
    });
    if (
      isEmpty(itemProducingSteps) ||
      itemProducingSteps.length !== itemProducingStepIds.length
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    let workCenterIds = [];
    itemProducingSteps.forEach((itemProducingStep) => {
      itemProducingStep.workCenterSchedules.forEach((workCenter) => {
        workCenterIds.push(workCenter.workCenterId);
      });
    });

    if (isEmpty(workCenterIds)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NO_MATCHING_WORK_CENTER'))
        .build();
    }
    workCenterIds = uniq(workCenterIds);
    const producingStepIds = uniq(map(itemProducingSteps, 'producingStepId'));
    const workCenters = await this.produceService.getWorkCenterByIds(
      workCenterIds,
      true,
    );
    const producingSteps = await this.produceService.getListProducingStepByIds(
      producingStepIds,
      true,
    );
    itemProducingSteps.forEach((itemProducingStep) => {
      this.moderationSpread(
        itemProducingStep,
        workCenters,
        itemProducingStep.dateFrom,
        masterPlan.dateTo,
      );
      itemProducingStep.producingStepName = has(
        producingSteps,
        itemProducingStep.producingStepId,
      )
        ? producingSteps[itemProducingStep.producingStepId]['name']
        : '';
      itemProducingStep.workCenterSchedules?.forEach((workCenter) => {
        workCenter.workCenterName = has(workCenters, workCenter.workCenterId)
          ? workCenters[workCenter.workCenterId]['name']
          : '';
      });
    });

    return new ResponseBuilder(itemProducingSteps)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private moderationSpread(
    itemProducingStep: ProducingStepScheduleRepositoryDto,
    normalizeWorkCenter,
    dateFrom?: string,
    dateTo?: string,
    isCustomModeration?: boolean,
  ): ProducingStepScheduleRepositoryDto {
    const overQuantity = +itemProducingStep.overQuantity;
    let flagSpreadByOver = overQuantity > 0;
    if (!dateFrom) {
      flagSpreadByOver = false;
      dateFrom = itemProducingStep.dateFrom;
    }
    if (!dateTo) {
      flagSpreadByOver = false;
      dateTo = itemProducingStep.dateTo;
    }
    // let totalShift = 0;
    const workCenterIds = uniq(
      map(itemProducingStep.workCenterSchedules, 'workCenterId'),
    );

    itemProducingStep.workCenterSchedules =
      itemProducingStep.workCenterSchedules.filter(
        (workCenterSchedule) =>
          moment(workCenterSchedule.excutionDate).isSameOrAfter(
            dateFrom,
            'day',
          ) &&
          moment(workCenterSchedule.excutionDate).isSameOrBefore(dateTo, 'day'),
      );
    let date = moment(dateFrom).format(FORTMAT_DATE_MODERATION);
    while (moment(date).isSameOrBefore(dateTo, 'day')) {
      if (
        isEmpty(
          itemProducingStep.workCenterSchedules.filter((workCenterSchedule) =>
            moment(workCenterSchedule.excutionDate).isSame(date, 'day'),
          ),
        )
      ) {
        workCenterIds.forEach((workCenterId) => {
          itemProducingStep.workCenterSchedules.push({
            itemProducingStepScheduleId: itemProducingStep.id,
            workCenterId,
            quantity: 0,
            actualQuantity: 0,
            excutionDate: date,
            workCenterDetailSchedules: normalizeWorkCenter[
              workCenterId
            ].workCenterShifts.map((workCenterShift) => ({
              workCenterShiftScheduleId: workCenterShift.id,
              quantity: 0,
              actualQuantity: 0,
              excutionFrom: workCenterShift.startAt,
              excutionTo: workCenterShift.endAt,
            })),
          });
        });
      }
      date = moment(date).add(1, 'day').format(FORTMAT_DATE_MODERATION);
    }

    // const validWorkCenterSchedules =
    // itemProducingStep.workCenterSchedules?.filter((wcSchedule) =>
    //     moment(wcSchedule.excutionDate).isSameOrAfter(moment().endOf('day')),
    //   );
    // let totalValidShift = 0;
    // if (!isEmpty(validWorkCenterSchedules)) {
    //   validWorkCenterSchedules.forEach((workCenter) => {
    //     if (!isEmpty(workCenter.workCenterDetailSchedules)) {
    //       totalValidShift += workCenter.workCenterDetailSchedules.length;
    //     }
    //   });
    // }
    // itemProducingStep.workCenterSchedules.forEach((workCenter) => {
    //   if (!isEmpty(workCenter.workCenterDetailSchedules)) {
    //     totalShift += workCenter.workCenterDetailSchedules.length;
    //   }
    // });

    const maxExecutionDate = itemProducingStep.workCenterSchedules
      .reduce((maxDate, obj) => {
        const currentDate = new Date(obj.excutionDate);
        return currentDate > maxDate ? currentDate : maxDate;
      }, new Date(0))
      .toISOString()
      .split('T')[0];

    const itemPsWorkCenterIds = uniq(
      map(itemProducingStep.workCenterSchedules, 'workCenterId'),
    );

    const normalizeWorkCenterBySteps = Object.values<{
      id: number;
      actualWorkingCapacity: number;
    }>(normalizeWorkCenter).filter((workCenter) =>
      itemPsWorkCenterIds.includes(workCenter.id),
    );

    const bestPerformanceWorkCenter = normalizeWorkCenterBySteps.reduce(
      (
        maxObj: { id: number; actualWorkingCapacity: number },
        obj: { id: number; actualWorkingCapacity: number },
      ) =>
        obj.actualWorkingCapacity > maxObj.actualWorkingCapacity ? obj : maxObj,
    ) as {
      id: number;
      actualWorkingCapacity: number;
    };

    let remainItemPsQuantity = minus(
      itemProducingStep.planQuantity,
      itemProducingStep.actualQuantity,
    );

    const orderWcSchedules = orderBy(
      itemProducingStep.workCenterSchedules,
      ['excutionDate'],
      ['asc'],
    );

    const nextWorkCenterExecuteDates = [];
    const workCenterSchedulesByCapacity = orderWcSchedules.map((wcSchedule) => {
      const workingCapacityPerDay = Math.ceil(
        normalizeWorkCenter[wcSchedule.workCenterId]?.actualWorkingCapacity,
      );

      const workCenterScheduleQuantity = Math.min(
        workingCapacityPerDay,
        remainItemPsQuantity,
      );

      const isPreviousDay = moment(wcSchedule.excutionDate)
        .add(7, 'hours')
        .isBefore(moment().startOf('day'));

      const isNextDay = moment(wcSchedule.excutionDate)
        .add(7, 'hours')
        .isAfter(moment().endOf('day'));

      wcSchedule.quantity = isPreviousDay
        ? wcSchedule.actualQuantity
        : workCenterScheduleQuantity;
      if (!isPreviousDay) {
        remainItemPsQuantity -= wcSchedule.quantity;
      }
      if (isNextDay) {
        nextWorkCenterExecuteDates.push({ ...wcSchedule });
      }
      return wcSchedule;
    });

    let spreadWorkCenterScheduleQuantity = 0;
    let overItemPsQuantity = 0;
    if (remainItemPsQuantity > 0 && !isEmpty(nextWorkCenterExecuteDates)) {
      spreadWorkCenterScheduleQuantity = Math.floor(
        div(remainItemPsQuantity, nextWorkCenterExecuteDates.length),
      );
      overItemPsQuantity =
        remainItemPsQuantity % nextWorkCenterExecuteDates.length;
    }
    const data = workCenterSchedulesByCapacity.map((workCenter) => {
      const isLastSchedule = workCenter.excutionDate === maxExecutionDate;
      const isBestPerformanceWorkCenter =
        workCenter.workCenterId === bestPerformanceWorkCenter.id;

      const isAfterCurrentDay = moment(workCenter.excutionDate)
        .add(7, 'hours')
        .isAfter(moment().endOf('day'));

      const isPreviousDay = moment(workCenter.excutionDate)
        .add(7, 'hours')
        .isBefore(moment().startOf('day'));

      let updateQuantity = workCenter.quantity;
      if (isAfterCurrentDay) {
        updateQuantity += !isCustomModeration
          ? spreadWorkCenterScheduleQuantity
          : 0;
      }

      let wcScheduleQuantity = updateQuantity;

      if (isBestPerformanceWorkCenter && isLastSchedule) {
        if (isCustomModeration) {
          wcScheduleQuantity = plus(
            updateQuantity || 0,
            remainItemPsQuantity || 0,
          );
        } else {
          wcScheduleQuantity = plus(
            updateQuantity || 0,
            overItemPsQuantity || 0,
          );
        }
      }

      if (
        wcScheduleQuantity > 0 &&
        !isEmpty(workCenter.workCenterDetailSchedules)
      ) {
        const totalShiftTime = workCenter.workCenterDetailSchedules.reduce(
          (total, scheduleShift) => {
            const diffTime = shiftDuration({
              startAt: scheduleShift.excutionFrom,
              endAt: scheduleShift.excutionTo,
            });
            return total + diffTime;
          },
          0,
        );

        workCenter.workCenterDetailSchedules =
          workCenter.workCenterDetailSchedules.map((shift) => {
            const shiftTime = shiftDuration({
              startAt: shift.excutionFrom,
              endAt: shift.excutionTo,
            });

            const shiftQuantityRate = div(shiftTime, totalShiftTime);
            const shiftQuantity = Math.floor(
              mul(wcScheduleQuantity, shiftQuantityRate),
            );

            return {
              ...shift,
              quantity: isPreviousDay ? shift.actualQuantity : shiftQuantity,
            };
          });
      }

      workCenter.quantity = wcScheduleQuantity;
      return workCenter;
    });
    // const remainQuantity = minus(
    //   remainItemPsQuantity,
    //   sumBy(itemProducingStep.workCenterSchedules, 'quantity'),
    // );
    // if (!isEmpty(itemProducingStep.workCenterSchedules)) {
    //   const lastShift = itemProducingStep.workCenterSchedules.find(
    //     (wcSchedule) => wcSchedule.excutionDate === maxExecutionDate,
    //   );
    //   lastShift['quantity'] = plus(remainQuantity, lastShift['quantity']);
    // }
    itemProducingStep.workCenterSchedules = data;
    itemProducingStep.dateFrom = !dateFrom
      ? min(map(itemProducingStep.workCenterSchedules, 'excutionDate'))
      : dateFrom;
    itemProducingStep.dateTo = !dateTo
      ? max(map(itemProducingStep.workCenterSchedules, 'excutionDate'))
      : dateTo;
    itemProducingStep.quantity = plus(overQuantity, itemProducingStep.quantity);
    itemProducingStep.overQuantity = minus(
      overQuantity,
      itemProducingStep.overQuantity,
    );
    return itemProducingStep;
  }

  /**
   *
   * @param request
   * @returns
   */
  async getDetailFlatItems(
    request: GetMasterPlanDetailRequestDto,
  ): Promise<any> {
    const masterPlan = await this.masterPlanRepository.getDetailMasterPlan(
      request,
    );
    if (isEmpty(masterPlan)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const response = plainToInstance(MasterPlanResponseDto, masterPlan, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  public async manufacturingOrderConfirmedEvent(
    request: ManufacturingOrderConfirmedEvent,
  ): Promise<any> {
    const { id, items, saleOrderId, dateFrom, dateTo, moId } = request;

    const masterPlan = await this.masterPlanRepository.findOneById(id);

    if (isEmpty(masterPlan)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const saleOrderSchedule =
      await this.saleOrderScheduleRepository.findOneWithRelations({
        where: {
          saleOrderId: saleOrderId,
          masterPlanId: id,
        },
        relations: ['itemSchedules'],
      });

    if (isEmpty(saleOrderSchedule)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.SALE_ORDER_SCHEDULE_NOT_EXIST'),
        )
        .build();
    }

    const itemIds = map(items, 'id');

    const { itemSchedules } = saleOrderSchedule;

    const itemSOSchedules = filter(itemSchedules, (itemSchedule) =>
      itemIds.includes(itemSchedule.itemId),
    );

    if (itemSOSchedules.length !== itemIds.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.SALE_ORDER_SCHEDULE_NOT_EXIST'),
        )
        .build();
    }

    const existItemManufacturingOrderSchedules =
      await this.itemManufacturingOrderRepository.findWithRelations({
        where: {
          itemId: In(itemIds),
          itemScheduleId: In(map(itemSOSchedules, 'id')),
        },
        order: {
          dateFrom: 'ASC',
        },
      });

    if (existItemManufacturingOrderSchedules.length) {
      itemSOSchedules.forEach((itemSOSchedule) => {
        const existItemManufacturingOrderSchedule = filter(
          existItemManufacturingOrderSchedules,
          (eIMOS) => eIMOS.itemId === itemSOSchedule.itemId,
        );
        const freeRange = [];
        let itemScheduleFrom = itemSOSchedule.dateFrom;
        const itemScheduleTo = itemSOSchedule.dateTo;
        existItemManufacturingOrderSchedule.forEach((imos, i) => {
          if (
            moment(itemScheduleFrom)
              .add(1, 'days')
              .isBefore(imos.dateFrom, 'day')
          ) {
            freeRange.push({
              dateFrom: itemScheduleFrom,
              dateTo: moment(imos.dateFrom)
                .add(-1, 'days')
                .format('YYYY-MM-DD'),
            });
          }
          itemScheduleFrom = imos.dateTo;

          if (i === existItemManufacturingOrderSchedule.length - 1) {
            if (moment(itemScheduleTo).isAfter(imos.dateTo, 'day')) {
              freeRange.push({
                dateFrom: moment(imos.dateTo)
                  .add(1, 'days')
                  .format('YYYY-MM-DD'),
                dateTo: itemScheduleTo,
              });
              itemScheduleFrom = imos.dateTo;
            }
          }
        });

        itemSOSchedule.freeRange = freeRange;
      });
    } else {
      itemSOSchedules.forEach((itemSOSchedule) => {
        itemSOSchedule.freeRange = [
          {
            dateFrom: itemSOSchedule.dateFrom,
            dateTo: itemSOSchedule.dateTo,
          },
        ];
      });
    }

    const itemManufacturingOrderEntities = [];
    const serializeItemSchedules = keyBy(itemSOSchedules, 'itemId');
    for (let i = 0; i < items.length; i++) {
      const serializeItemSchedule = serializeItemSchedules[items[i].id];
      const invalidTime = [];

      if (isEmpty(serializeItemSchedule.freeRange.length)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.FORBIDDEN)
          .withMessage(await this.i18n.translate('error.INVALID_PLAN_FROM'))
          .build();
      }

      for (let j = 0; j < serializeItemSchedule.freeRange.length; j++) {
        const fRange: any = serializeItemSchedule.freeRange[j];
        if (moment(fRange.dateFrom).isAfter(dateFrom, 'day')) {
          invalidTime.push(
            await this.i18n.translate('error.INVALID_PLAN_FROM'),
          );
        }

        if (moment(fRange.dateTo).isSameOrBefore(dateTo, 'day')) {
          invalidTime.push(await this.i18n.translate('error.INVALID_PLAN_TO'));
        }
      }

      if (invalidTime.length >= serializeItemSchedule.freeRange.length) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.FORBIDDEN)
          .withMessage(uniq(invalidTime).join('\n'))
          .build();
      }
      const itemManufacturingOrderEntity = new ItemManufacturingOrderEntity();
      itemManufacturingOrderEntity.itemId = items[i].id;
      itemManufacturingOrderEntity.itemScheduleId = serializeItemSchedule.id;
      itemManufacturingOrderEntity.moId = moId;
      itemManufacturingOrderEntity.quantity = items[i].quantity;
      itemManufacturingOrderEntity.dateFrom = dateFrom;
      itemManufacturingOrderEntity.dateTo = dateTo;
      itemManufacturingOrderEntity.masterPlanId = masterPlan.id;
      itemManufacturingOrderEntity.saleOrderScheduleId = saleOrderSchedule.id;

      itemManufacturingOrderEntities.push(itemManufacturingOrderEntity);
    }

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();

    try {
      await queryRunner.manager.save(itemManufacturingOrderEntities);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(
          error
            ? error.message
            : await this.i18n.translate('error.INTERNAL_SERVER_ERROR'),
        )
        .build();
    } finally {
      await queryRunner.release();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  async getById(request: GetMasterPlanByIdRequestDto): Promise<any> {
    const { id } = request;
    const data = await this.masterPlanRepository.findOneByCondition({
      id: id,
    });
    const response = plainToInstance(GetMasterPlanByCodeResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async getScheduleMasterPlan(
    request: GetMasterPlanDetailRequestDto,
  ): Promise<any> {
    const masterPlan: any = await this.masterPlanRepository.getDetailMasterPlan(
      request,
    );
    if (isEmpty(masterPlan)) {
      return new ResponseBuilder({})
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (MASTER_PLAN_GEN_SCHEDULE.includes(masterPlan.status)) {
      await this.formatMasterPlanSchedule(masterPlan);
    }

    const saleOrderIds = [];
    const itemIds = [];
    const producingStepIds = [];
    const workCenterIds = [];
    let dateFrom = masterPlan.dateFrom;
    let dateTo = masterPlan.dateTo;
    masterPlan.saleOrderSchedules.forEach((saleOrderSchedule) => {
      saleOrderIds.push(saleOrderSchedule.saleOrderId);
      saleOrderSchedule.itemSchedules.forEach((itemSchedule) => {
        itemIds.push(itemSchedule.itemId);
        itemSchedule.producingSteps.forEach((producingStep) => {
          if (moment(dateFrom).isAfter(producingStep.dateFrom)) {
            dateFrom = producingStep.dateFrom;
          }
          if (moment(dateTo).isBefore(producingStep.dateTo)) {
            dateTo = producingStep.dateTo;
          }
          producingStepIds.push(producingStep.producingStepId);
          producingStep?.workCenterSchedules?.forEach((workCenterSchedule) => {
            workCenterIds.push(workCenterSchedule.workCenterId);
          });
        });
      });
    });
    const saleOrdersSerialize = await this.requestService.getRequestOrderByIds(
      uniq(saleOrderIds),
      true,
    );

    const itemsSerialize = await this.itemService.getItemByIds(
      uniq(itemIds),
      true,
    );

    const producingStepsSerialize =
      await this.produceService.getListProducingStepByIds(
        uniq(producingStepIds),
        true,
      );

    const workCenterSerialize = await this.produceService.getWorkCenterByIds(
      uniq(workCenterIds),
      true,
    );

    masterPlan.saleOrderSchedules.map((saleOrderSchedule) => {
      saleOrderSchedule.saleOrderName =
        saleOrdersSerialize[saleOrderSchedule.saleOrderId].name;
      saleOrderSchedule.saleOrderCode =
        saleOrdersSerialize[saleOrderSchedule.saleOrderId].code;
      saleOrderSchedule.itemSchedules = saleOrderSchedule.itemSchedules.map(
        (itemSchedule) => {
          itemSchedule.itemName = itemsSerialize[itemSchedule.itemId]?.name;
          const quantityItemByDays = [];
          itemSchedule.producingSteps = itemSchedule.producingSteps.map(
            (producingStep) => {
              producingStep.producingStepName =
                producingStepsSerialize[producingStep.producingStepId].name;
              const schedules = producingStep.workCenterSchedules;
              const schedulesFormat = this.formatScheduleByExecutionDay(
                schedules,
                workCenterSerialize,
                dateFrom,
                dateTo,
                quantityItemByDays,
              );
              producingStep.workCenterSchedules = schedulesFormat;
              return producingStep;
            },
          );
          itemSchedule.quantityDays = {
            quantity: sumBy(values(quantityItemByDays), 'quantity'),
            days: values(quantityItemByDays),
          };
          return itemSchedule;
        },
      );
      return saleOrderSchedule;
    });

    const response = plainToInstance(
      MasterPlanScheduleResponseDto,
      masterPlan,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private formatScheduleByExecutionDay(
    schedules,
    workCenterSerialize,
    dateFrom,
    dateTo,
    quantityItemByDays,
  ) {
    const diffDay = getDiffDay(dateFrom, dateTo);
    const schedulesByWorkCenter = groupBy(schedules, 'workCenterId');
    const schedulesFormat = {};
    for (let i = 0; i < diffDay; i++) {
      const day = moment(dateFrom).add(i, 'day').format('YYYY-MM-DD');
      if (!has(quantityItemByDays, day)) {
        quantityItemByDays[day] = {
          executionDate: day,
          quantity: 0,
        };
      }
    }
    Object.keys(schedulesByWorkCenter).forEach((workCenterId) => {
      const scheduleWorkCenter = schedulesByWorkCenter[workCenterId];
      const scheduleByDayFormat = [];
      for (let i = 0; i < diffDay; i++) {
        const day = moment(dateFrom).add(i, 'day').format('YYYY-MM-DD');
        const scheduleByDay = scheduleWorkCenter.find(
          (schedule) => schedule.excutionDate === day,
        );
        const scheduleTemplate = {
          executionDate: day,
          quantity: 0,
        };
        if (!isEmpty(scheduleByDay)) {
          quantityItemByDays[day]['quantity'] += scheduleByDay.quantity;
          scheduleTemplate.quantity = scheduleByDay.quantity;
        }
        scheduleByDayFormat.push(scheduleTemplate);
      }
      schedulesFormat[workCenterId] = {
        workCenterId: workCenterId,
        workCenterName: workCenterSerialize[workCenterId].name,
        schedules: orderBy(scheduleByDayFormat, 'executionDate', 'asc'),
      };
    });
    return values(schedulesFormat);
  }

  /**
   *
   * @param request
   * @returns
   */
  public async updateMasterPlanActualQuantity(
    request: UpdateMasterPlanActualQuantityRequestDto,
  ): Promise<any> {
    const {
      masterPlanId,
      itemProducingStepScheduleId,
      masterPlanWorkCenterDailyScheduleShiftId,
      masterPlanWorkCenterDailyScheduleId,
      quantity,
      errorQuantity,
    } = request;

    const masterPlan = await this.masterPlanRepository.findOneById(
      masterPlanId,
    );

    if (!masterPlan) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const itemProducingStepSchedule =
      await this.itemProducingStepScheduleRepository.findOneWithRelations({
        where: {
          id: itemProducingStepScheduleId,
        },
        relations: ['itemSchedule', 'itemSchedule.saleOrderSchema'],
      });

    if (!itemProducingStepSchedule) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const workCenterDailySchedule =
      await this.workCenterScheduleRepository.findOneWithRelations({
        where: {
          id: masterPlanWorkCenterDailyScheduleId,
          itemProducingStepScheduleId: itemProducingStepScheduleId,
        },
        relations: ['workCenterDetailSchedules'],
      });

    if (!workCenterDailySchedule) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const workCenterDailyScheduleDetail = find(
      workCenterDailySchedule.workCenterDetailSchedules,
      (workCenterDetailSchedule) =>
        workCenterDetailSchedule.id ===
        masterPlanWorkCenterDailyScheduleShiftId,
    );

    // if (!workCenterDailyScheduleDetail) {
    //   return new ResponseBuilder()
    //     .withCode(ResponseCodeEnum.NOT_FOUND)
    //     .withMessage(await this.i18n.translate('error.NOT_FOUND'))
    //     .build();
    // }

    itemProducingStepSchedule.setProgressQuantity(quantity, errorQuantity);
    if (workCenterDailySchedule)
      workCenterDailySchedule.setProgressQuantity(quantity, errorQuantity);
    if (workCenterDailyScheduleDetail)
      workCenterDailyScheduleDetail.setProgressQuantity(
        quantity,
        errorQuantity,
      );

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();

    try {
      if (workCenterDailyScheduleDetail) {
        await queryRunner.manager.save(workCenterDailyScheduleDetail);
      }
      if (workCenterDailySchedule) {
        await queryRunner.manager.save(workCenterDailySchedule);
      }

      await queryRunner.manager.save(itemProducingStepSchedule);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(
          error
            ? error.message
            : await this.i18n.translate('error.INTERNAL_SERVER_ERROR'),
        )
        .build();
    } finally {
      await queryRunner.release();
    }

    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  public async updateMasterPlanItemScheduleActualQuantity(
    request: UpdateMasterPlanItemScheduleActualQuantityRequestDto,
  ): Promise<any> {
    const { masterPlanItemScheduleId, quantity } = request;

    const itemSchedule = await this.itemScheduleRepository.findOneWithRelations(
      {
        where: {
          id: masterPlanItemScheduleId,
        },
        relations: ['saleOrderSchema'],
      },
    );

    if (!itemSchedule) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    itemSchedule.actualQuantity = plus(
      itemSchedule.actualQuantity || 0,
      quantity,
    );

    try {
      await this.itemScheduleRepository.create(itemSchedule);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(
          error
            ? error.message
            : await this.i18n.translate('error.INTERNAL_SERVER_ERROR'),
        )
        .build();
    }
    if (itemSchedule.parentBomId === null) {
      const requestUpdateProducedQuantity =
        new UpdateProducedQuantityRequestDto();
      requestUpdateProducedQuantity.id =
        itemSchedule.saleOrderSchema.saleOrderId;
      requestUpdateProducedQuantity.items = [
        {
          itemId: itemSchedule.itemId,
          quantity: quantity,
        },
      ];
      // await this.saleService.updateProducedQuantity(
      //   requestUpdateProducedQuantity,
      // );
    }

    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async getMOByMasterPlan(request: GetMOByMasterPlanRequestDto): Promise<any> {
    const { masterPlanId } = request;
    const itemManufacturingOrders =
      await this.itemManufacturingOrderRepository.findByCondition({
        masterPlanId,
      });
    const response = plainToInstance(
      ItemManufacturingOrderResponseDto,
      itemManufacturingOrders,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private getMaxDate = (dateArray) => {
    const maxDate = dateArray.reduce((maxDate, date) => {
      const currentDate = new Date(date);
      return currentDate > maxDate ? currentDate : maxDate;
    }, new Date(0));
    return maxDate.toISOString();
  };
}
