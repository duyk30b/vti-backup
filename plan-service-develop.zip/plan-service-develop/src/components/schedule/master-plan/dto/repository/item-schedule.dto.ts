import { ItemProducingStepStatusEnum } from '@constant/common';

export class WorkCenterDetailScheduleRepositoryDto {
  id?: number;
  workCenterShiftScheduleId: number;
  itemProducingStepScheduleId: ItemProducingStepStatusEnum;
  quantity: number;
  actualQuantity?: number;
  excutionFrom: string;
  excutionTo: string;
}

export class WorkCenterScheduleRepositoryDto {
  id?: number;
  workCenterId: number;
  itemProducingStepScheduleId: ItemProducingStepStatusEnum;
  quantity: number;
  actualQuantity?: number;
  errorQuantity?: number;
  excutionDate: string;
  workCenterDetailSchedules: WorkCenterDetailScheduleRepositoryDto[];
}

export class ProducingStepScheduleRepositoryDto {
  id: number;
  itemScheduleId: number;
  status: ItemProducingStepStatusEnum;
  producingStepId: number;
  planQuantity: number;
  quantity: number;
  actualQuantity: number;
  errorQuantity: number;
  stepNumber: number;
  overQuantity: number;
  dateFrom: string;
  dateTo: string;
  createdAt: string;
  updatedAt: string;
  workCenterSchedules: WorkCenterScheduleRepositoryDto[];
}

export class ItemScheduleRepositoryDto {
  id: number;
  saleOrderScheduleId: number;
  masterPlanId: number;
  itemId: number;
  itemFinishId: number;
  bomId: number;
  parentBomId: number | null;
  quantity: number;
  actualQuantity: number;
  errorQuantity: number;
  level: number;
  isOverQuantity: boolean;
  dateFrom: string;
  dateTo: string;
  createdAt: string;
  updatedAt: string;
  needtoManufacture: boolean;
  producingStepSchedules: ProducingStepScheduleRepositoryDto[];
}
