import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';
import { uniq } from 'lodash';

export class SuggestModerationInputQueryRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @Transform((data) => uniq(data.value.split(',')))
  itemProducingStepIds: number[];
}
export class SuggestModerationInputRequestDto extends SuggestModerationInputQueryRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  masterPlanId: number;
}
