import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt } from 'class-validator';

export class DeleteMasterPlanRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  id: number;
}
