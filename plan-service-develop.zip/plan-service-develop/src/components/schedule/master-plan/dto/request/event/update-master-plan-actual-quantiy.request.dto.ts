import { BaseDto } from '@core/dto/base.dto';
import { Transform } from 'class-transformer';
import { IsInt, IsNumber, IsOptional } from 'class-validator';

export class UpdateMasterPlanActualQuantityRequestDto extends BaseDto {
  @IsInt()
  masterPlanId: number;

  @IsInt()
  itemProducingStepScheduleId: number;

  @IsInt()
  @IsOptional()
  masterPlanWorkCenterDailyScheduleShiftId: number;

  @IsInt()
  @IsOptional()
  masterPlanWorkCenterDailyScheduleId: number;

  @Transform(({ value }) => Number(value))
  @IsNumber()
  quantity: number;

  @Transform(({ value }) => Number(value))
  @IsOptional()
  @IsNumber()
  errorQuantity: number;
}

export class UpdateMasterPlanItemScheduleActualQuantityRequestDto extends BaseDto {
  @IsInt()
  masterPlanItemScheduleId: number;

  @Transform(({ value }) => Number(value))
  @IsNumber()
  quantity: number;
}
