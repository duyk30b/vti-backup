import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsBoolean,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

class ItemSchedule {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsBoolean()
  isProductionObject: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  subBoms: ItemSchedule[];
}
class SaleOrder {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  id: string;

  @ApiProperty()
  @ArrayNotEmpty()
  @ArrayUnique()
  items: ItemSchedule[];
}
export class CreateMasterPlanRequestDto extends BaseDto {
  @ApiProperty({ type: SaleOrder, isArray: true })
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => SaleOrder)
  saleOrders: SaleOrder[];

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  factoryId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  name: string;

  @ApiPropertyOptional()
  @IsOptional()
  description?: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  dateFrom: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  dateTo: string;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  dateFromSo: string;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  dateCompletion: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  userId: number;
}
