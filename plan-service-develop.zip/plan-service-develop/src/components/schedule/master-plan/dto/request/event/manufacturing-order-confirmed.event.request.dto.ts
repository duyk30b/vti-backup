import { ApiProperty } from '@nestjs/swagger';
import { BaseDto } from '@core/dto/base.dto';
import { Expose, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsNumber,
  IsDateString,
  IsInt,
  ValidateNested,
  IsOptional,
} from 'class-validator';

class SaleOrderItem {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  @IsNumber()
  quantity: number;
}

export class ManufacturingOrderConfirmedEventBodyDto extends BaseDto {}

export class ManufacturingOrderConfirmedEvent extends ManufacturingOrderConfirmedEventBodyDto {
  @ApiProperty()
  @Expose()
  @IsOptional()
  @IsInt()
  id: number;

  @ApiProperty()
  @Expose()
  saleOrderId: string;

  @ApiProperty()
  @Expose()
  moId: number;

  @ApiProperty({ isArray: true, type: SaleOrderItem })
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => SaleOrderItem)
  items: SaleOrderItem[];

  @ApiProperty()
  @IsDateString()
  dateFrom: Date;

  @ApiProperty()
  @IsDateString()
  dateTo: Date;
}
