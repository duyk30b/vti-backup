import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import {
  IsDate,
  IsEnum,
  IsNumberString,
  IsOptional,
  IsString,
} from 'class-validator';

export class GetMasterPlanRequestDto extends PaginationQuery {
  @ApiPropertyOptional()
  @IsNumberString()
  @IsOptional()
  soId: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll: string;

  @ApiPropertyOptional()
  @IsNumberString()
  @IsOptional()
  masterPlanId: string;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  itemIds?: string;

  @ApiProperty()
  @IsDate()
  @IsOptional()
  planFrom: Date;

  @ApiProperty()
  @IsDate()
  @IsOptional()
  planTo: Date;
}
