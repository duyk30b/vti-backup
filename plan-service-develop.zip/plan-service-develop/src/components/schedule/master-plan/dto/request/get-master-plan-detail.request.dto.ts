import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import {
  IsDateString,
  IsEnum,
  IsInt,
  IsMongoId,
  IsOptional,
  IsString,
} from 'class-validator';

export class GetMasterPlanDetailQueryRequestDto extends BaseDto {}
export class GetMasterPlanDetailRequestDto extends GetMasterPlanDetailQueryRequestDto {
  @ApiProperty()
  @IsInt()
  @IsOptional()
  masterPlanId: number;

  @ApiProperty()
  @IsOptional()
  @IsMongoId()
  saleOrderId: string;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  @IsEnum([0, 1])
  isActive: number;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  planFrom: Date;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  planTo: Date;

  @ApiProperty()
  @IsOptional()
  @IsString()
  itemIds: string;
}
