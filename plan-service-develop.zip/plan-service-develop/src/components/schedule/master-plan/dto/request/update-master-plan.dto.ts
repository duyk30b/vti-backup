import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsOptional } from 'class-validator';
import { CreateMasterPlanRequestDto } from './create-master-plan.dto';

export class UpdateMasterPlanBodyRequestDto extends CreateMasterPlanRequestDto {}
export class UpdateMasterPlanRequestDto extends UpdateMasterPlanBodyRequestDto {
  @ApiProperty()
  @IsOptional()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
