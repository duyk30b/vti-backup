import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';

export class GetDetailItemProducingStepQueryRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @Transform((data) => data.value.split(','))
  itemProducingStepIds: number[];
}
export class GetDetailItemProducingStepRequestDto extends GetDetailItemProducingStepQueryRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  masterPlanId: number;
}
