import { ApiProperty } from '@nestjs/swagger';
import { PagingResponse } from '@utils/paging.response';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';
import { IsOptional } from 'class-validator';

class WorkCenterDetailSchedule {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  workCenterScheduleId: number;

  @ApiProperty()
  @Expose()
  workCenterShiftScheduleId: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  errorQuantity: number;

  @ApiProperty()
  @Expose()
  excutionFrom: number;

  @ApiProperty()
  @Expose()
  excutionTo: number;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;
}

class WorkCenterSchedule {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  workCenterId: number;

  @ApiProperty()
  @Expose()
  workCenterName: string;

  @ApiProperty()
  @Expose()
  itemProducingStepScheduleId: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  errorQuantity: number;

  @ApiProperty()
  @Expose()
  excutionDate: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: WorkCenterDetailSchedule })
  @Type(() => WorkCenterDetailSchedule)
  @Expose()
  workCenterDetailSchedules: WorkCenterDetailSchedule[];
}

class ItemProducingStepSchedule {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemScheduleId: number;

  @ApiProperty()
  @Expose()
  producingStepId: number;

  @ApiProperty()
  @Expose()
  producingStepName: string;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  errorQuantity: number;

  @ApiProperty()
  @Expose()
  overQuantity: number;

  @ApiProperty()
  @Expose()
  dateFrom: Date;

  @ApiProperty()
  @Expose()
  dateTo: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: WorkCenterSchedule })
  @Type(() => WorkCenterSchedule)
  @Expose()
  workCenterSchedules: WorkCenterSchedule[];
}

class Routing {
  @Expose()
  name: string;

  @Expose()
  code: string;
}

class Bom {
  @Expose()
  name: string;

  @Expose()
  code: string;
}

class Factory {
  @Expose()
  id: number;

  @Expose()
  name: number;
}

class ItemSchedule {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  saleOrderScheduleId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  itemName: string;

  @ApiProperty()
  @Expose()
  itemCode: string;

  @ApiProperty()
  @Expose()
  itemUnitName: string;

  @ApiProperty()
  @Expose()
  bomId: number;

  @ApiProperty()
  @Expose()
  bomVersionId: number;

  @ApiProperty()
  @Expose()
  parentBomVersionId: number;

  @Expose()
  @Type(() => Bom)
  bom: Bom;

  @Expose()
  @Type(() => Routing)
  routing: Routing;

  @ApiProperty()
  @Expose()
  parentBomId: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  errorQuantity: number;

  @ApiProperty()
  @Expose()
  isOverQuantity: boolean;

  @ApiProperty()
  @Expose()
  level: boolean;

  @ApiProperty()
  @Expose()
  itemFinishId: number;

  @ApiProperty()
  @Expose()
  stepNumber: number;

  @ApiProperty()
  @Expose()
  dateFrom: Date;

  @ApiProperty()
  @Expose()
  dateTo: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: ItemSchedule })
  @Type(() => ItemSchedule)
  @Expose()
  subBom: ItemSchedule[];

  @ApiProperty({ type: ItemProducingStepSchedule })
  @Type(() => ItemProducingStepSchedule)
  @Expose()
  producingSteps: ItemProducingStepSchedule[];
}

class SaleOrderDetail {
  @Expose()
  id: string;

  @Expose()
  code: string;

  @Expose()
  name: string;
}

class SaleOrderSchedule {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  masterPlanId: number;

  @ApiProperty()
  @Expose()
  saleOrderId: string;

  @ApiProperty()
  @Expose()
  saleOrderName: string;

  @ApiProperty()
  @Expose()
  saleOrderCode: string;

  @ApiProperty()
  @Expose()
  dateFrom: Date;

  @ApiProperty()
  @Expose()
  dateTo: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: ItemSchedule })
  @Type(() => ItemSchedule)
  @Expose()
  itemSchedules: ItemSchedule[];
}

class UserCreateAndUpdate {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  fullname: string;
}

class ItemBomTree {
  @Expose()
  itemId: number;

  @Expose()
  isProductionObject: boolean;

  @Expose()
  @Type(() => ItemBomTree)
  subBoms: ItemBomTree[];
}
class SaleOrderBomTree {
  @Expose()
  id: number;

  @Type(() => ItemBomTree)
  @Expose()
  items: ItemBomTree[];
}

export class MasterPlanResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  factoryId: number;

  @Expose()
  @Type(() => Factory)
  factory: Factory;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  dateFrom: Date;

  @ApiProperty()
  @Expose()
  dateTo: Date;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty()
  @Type(() => UserCreateAndUpdate)
  @Expose()
  @IsOptional()
  createdBy: UserCreateAndUpdate;

  @ApiProperty()
  @Type(() => UserCreateAndUpdate)
  @Expose()
  @IsOptional()
  updatedBy: UserCreateAndUpdate;

  @ApiProperty({ type: SaleOrderSchedule })
  @Type(() => SaleOrderSchedule)
  @Expose()
  saleOrderSchedules: SaleOrderSchedule[];

  @Type(() => SaleOrderBomTree)
  @Expose()
  saleOrders: SaleOrderBomTree[];
}
export class MasterPlanListData extends PagingResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  dateFrom: Date;

  @ApiProperty()
  @Expose()
  dateTo: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty({ type: SaleOrderSchedule })
  @Type(() => SaleOrderSchedule)
  @Expose()
  saleOrderSchedules: SaleOrderSchedule[];

  @Expose()
  @Type(() => Factory)
  factory: Factory;

  @Expose()
  @Type(() => SaleOrderDetail)
  saleOrders: SaleOrderDetail[];
}

export class GetMasterPlanResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: MasterPlanListData;
}
