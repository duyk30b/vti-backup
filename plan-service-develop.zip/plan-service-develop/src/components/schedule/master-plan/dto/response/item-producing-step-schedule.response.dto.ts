import { Expose, Type } from 'class-transformer';

class WorkCenterDetailSchedules {
  @Expose()
  id: number;

  @Expose()
  quantity: number;

  @Expose()
  workCenterShiftScheduleId: number;
}

class WorkCenterSchedules {
  @Expose()
  id: number;

  @Expose()
  workCenterId: number;

  @Expose()
  workCenterName: string;

  @Expose()
  excutionDate: string;

  @Expose()
  quantity: number;

  @Expose()
  @Type(() => WorkCenterDetailSchedules)
  workCenterDetailSchedules: WorkCenterDetailSchedules[];
}

export class ItemProducingStepScheduleResponseDto {
  @Expose()
  id: number;

  @Expose()
  itemScheduleId: number;

  @Expose()
  status: number;

  @Expose()
  producingStepId: number;

  @Expose()
  producingStepName: string;

  @Expose()
  planQuantity: number;

  @Expose()
  quantity: number;

  @Expose()
  actualQuantity: number;

  @Expose()
  errorQuantity: number;

  @Expose()
  overQuantity: number;

  @Expose()
  stepNumber: number;

  @Expose()
  dateFrom: string;

  @Expose()
  dateTo: string;

  @Expose()
  @Type(() => WorkCenterSchedules)
  workCenterSchedules: WorkCenterSchedules[];
}
