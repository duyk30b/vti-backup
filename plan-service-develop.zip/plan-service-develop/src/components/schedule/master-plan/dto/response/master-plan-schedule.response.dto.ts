import { ApiProperty } from '@nestjs/swagger';
import { plus } from '@utils/common';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Transform, Type } from 'class-transformer';
import { sumBy } from 'lodash';

class WorkCenterScheduleByDay {
  @Expose()
  executionDate: string;

  @Expose()
  quantity: number;
}

class WorkCenterSchedule {
  @ApiProperty()
  @Expose()
  workCenterId: number;

  @ApiProperty()
  @Expose()
  workCenterName: string;

  @ApiProperty()
  @Expose()
  @Transform((data) => sumBy(data.obj.schedules, 'quantity'))
  quantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  errorQuantity: number;

  @Expose()
  @Type(() => WorkCenterScheduleByDay)
  schedules: WorkCenterScheduleByDay[];
}
class QuantityByDay {
  @Expose()
  executionDate: string;

  @Expose()
  quantity: number;
}

class QuantityByDays {
  @Expose()
  quantity: number;

  @Expose()
  @Type(() => QuantityByDay)
  days: QuantityByDay[];
}

class ItemProducingStepSchedule {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemScheduleId: number;

  @ApiProperty()
  @Expose()
  producingStepId: number;

  @ApiProperty()
  @Expose()
  producingStepName: string;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  @Transform((data) => plus(data.obj.quantity, data.obj.overQuantity))
  planQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  errorQuantity: number;

  @ApiProperty()
  @Expose()
  overQuantity: number;

  @ApiProperty()
  @Expose()
  dateFrom: Date;

  @ApiProperty()
  @Expose()
  dateTo: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: WorkCenterSchedule })
  @Type(() => WorkCenterSchedule)
  @Expose()
  workCenterSchedules: WorkCenterSchedule[];
}

class ItemSchedule {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  saleOrderScheduleId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  itemName: string;

  @ApiProperty()
  @Expose()
  itemUnitName: string;

  @ApiProperty()
  @Expose()
  bomId: number;

  @ApiProperty()
  @Expose()
  parentBomId: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  errorQuantity: number;

  @ApiProperty()
  @Expose()
  isOverQuantity: boolean;

  @ApiProperty()
  @Expose()
  level: boolean;

  @ApiProperty()
  @Expose()
  stepNumber: number;

  @ApiProperty()
  @Expose()
  dateFrom: Date;

  @ApiProperty()
  @Expose()
  dateTo: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: ItemSchedule })
  @Type(() => ItemSchedule)
  @Expose()
  subBom: ItemSchedule[];

  @ApiProperty({ type: ItemProducingStepSchedule })
  @Type(() => ItemProducingStepSchedule)
  @Expose()
  producingSteps: ItemProducingStepSchedule[];

  @Expose()
  @Type(() => QuantityByDays)
  quantityDays: QuantityByDays;
}

class SaleOrderSchedule {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  masterPlanId: number;

  @ApiProperty()
  @Expose()
  saleOrderId: string;

  @ApiProperty()
  @Expose()
  saleOrderName: string;

  @ApiProperty()
  @Expose()
  saleOrderCode: string;

  @ApiProperty()
  @Expose()
  dateFrom: Date;

  @ApiProperty()
  @Expose()
  dateTo: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: ItemSchedule })
  @Type(() => ItemSchedule)
  @Expose()
  itemSchedules: ItemSchedule[];
}
export class MasterPlanScheduleResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  factoryId: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  dateFrom: Date;

  @ApiProperty()
  @Expose()
  dateTo: Date;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: SaleOrderSchedule })
  @Type(() => SaleOrderSchedule)
  @Expose()
  saleOrderSchedules: SaleOrderSchedule[];
}
