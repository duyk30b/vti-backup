import { ItemScheduleRepositoryDto } from '../repository/item-schedule.dto';

export class TreeItemScheduleDto extends ItemScheduleRepositoryDto {
  subBom: TreeItemScheduleDto[];
}
