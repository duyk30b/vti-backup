import {
  IsArray,
  IsDate,
  IsInt,
  IsNotEmpty,
  Min,
  ValidateNested,
} from 'class-validator';

class WorkCenterDetailSchedule {
  @IsInt()
  @IsNotEmpty()
  workCenterId: number;

  @IsNotEmpty()
  @IsInt()
  workCenterShiftScheduleId: number;

  @IsNotEmpty()
  @IsDate()
  date: string;

  @IsInt()
  @Min(0)
  @IsNotEmpty()
  quantity: number;
}

export class UpdateProducingStepScheduleDto {
  @IsInt()
  @IsNotEmpty()
  producingStepScheduleId: number;

  @IsArray()
  @IsNotEmpty()
  @ValidateNested()
  workCenterDetailSchedules: WorkCenterDetailSchedule[];
}
