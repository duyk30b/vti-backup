import { ProducingStepScheduleRepositoryDto } from '../repository/item-schedule.dto';

export class TreeProducingStepScheduleDto extends ProducingStepScheduleRepositoryDto {
  subs: ProducingStepScheduleRepositoryDto[];
}
