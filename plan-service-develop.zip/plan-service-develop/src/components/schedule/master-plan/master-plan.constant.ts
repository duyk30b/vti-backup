import { MasterPlanStatusEnum } from '@constant/common';

export const CAN_APPROVE_MASTER_PLAN_STATUS = [MasterPlanStatusEnum.CREATED];

export const CAN_UPDATE_MASTER_PLAN_STATUS = [MasterPlanStatusEnum.CREATED];

export const CAN_REJECT_MASTER_PLAN_STATUS = [MasterPlanStatusEnum.CREATED];

export const CAN_DELETE_MASTER_PLAN_STATUS = [
  MasterPlanStatusEnum.CREATED,
  MasterPlanStatusEnum.REJECT,
];

export const CAN_MODERATION_MASTER_PLAN = [
  MasterPlanStatusEnum.APPROVED,
  MasterPlanStatusEnum.IN_PROGRESS,
];

export const CAN_CREATE_SCHEDULE_PLAN = [MasterPlanStatusEnum.CREATED];

export const MASTER_PLAN_IS_ACTIVE = [
  MasterPlanStatusEnum.APPROVED,
  MasterPlanStatusEnum.IN_PROGRESS,
  MasterPlanStatusEnum.DONE,
];

export const MASTER_PLAN_GEN_SCHEDULE = [
  MasterPlanStatusEnum.CREATED,
  MasterPlanStatusEnum.REJECT,
];

export const MANUFACTURE_BEFORE_DAY_UP_LEVEL = 1;

export const FORTMAT_DATE_MODERATION = 'YYYY-MM-DD';

export const ORDER_STEP_NUMBER_PRODUCING_STEP = 'asc';

export const ORDER_LEVEL_ITEM_SCHEDULE = 'desc';

export const ORDER_PERFORMANCE_PRODUCING_STEP = 'desc';

export const PLAN_TIME_FORMAT = {
  MIN: 1,
  HOURS: 60,
  DAY: 24 * 60,
};
