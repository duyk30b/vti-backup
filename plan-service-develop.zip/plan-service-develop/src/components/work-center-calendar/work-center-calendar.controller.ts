import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Injectable,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { isEmpty } from 'lodash';
import { CreateWorkCenterCalendarRequestDto } from './dto/request/create-work-center-calendar.request.dto';
import { SearchWorkCenterCalendarRequestDto } from './dto/request/search-work-center-calendar.request.dto';
import { UpdateWorkCenterCalendarRequestDto } from './dto/request/update-work-center-calendar.request.dto';
import { WorkCenterCalendarServiceInterface } from './interface/work-center-calendar.service.interface';

@Injectable()
@Controller('work-center-calendars')
export class WorkCenterCalendarController {
  constructor(
    @Inject('WorkCenterCalendarServiceInterface')
    private readonly workCenterCalendarServiceInterface: WorkCenterCalendarServiceInterface,
  ) {}

  @Post('')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Tạo calendar phân xưởng',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
  })
  async create(
    @Body() payload: CreateWorkCenterCalendarRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.workCenterCalendarServiceInterface.create(request);
  }

  @Put('')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Sửa calendar phân xưởng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  async update(
    @Body() payload: UpdateWorkCenterCalendarRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.workCenterCalendarServiceInterface.update(request);
  }

  @Delete('/:id')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Xóa calendar phân xưởng',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  async delete(@Param('id', new ParseIntPipe()) id: number): Promise<any> {
    return await this.workCenterCalendarServiceInterface.delete({
      id: id,
    });
  }

  @Get('')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Danh sách calendar phân xưởng trong tháng',
  })
  @ApiResponse({
    status: 200,
    description: 'Search successfully',
  })
  async list(
    @Query() payload: SearchWorkCenterCalendarRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.workCenterCalendarServiceInterface.search(request);
  }
}
