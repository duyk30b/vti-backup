import { CalendarAbstractResponseDto } from '@components/factory-calendar/dto/response/calendar.abstract.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class WorkCenterCalendarResponseDto extends CalendarAbstractResponseDto {
  @ApiProperty()
  @Expose()
  workCenterId: number;
}
