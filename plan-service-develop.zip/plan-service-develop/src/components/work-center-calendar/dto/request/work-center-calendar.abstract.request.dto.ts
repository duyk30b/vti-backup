import { WorkCenterTypeEnum } from '@components/work-center-calendar/work-center-calendar.constant';
import { BaseDto } from '@core/dto/base.dto';
import { Expose } from 'class-transformer';
import {
  IsDateString,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsString,
  MaxLength,
} from 'class-validator';

export class WorkCenterCalendarAbstractRequestDto extends BaseDto {
  @Expose()
  @IsString()
  @MaxLength(50)
  @IsNotEmpty({ message: 'Title không được trống' })
  title: string;

  @Expose()
  @IsString()
  @MaxLength(255)
  description: string;

  @Expose()
  @IsDateString()
  @IsNotEmpty({ message: 'Thời gian bắt đầu không được trống' })
  from: Date;

  @Expose()
  @IsDateString()
  @IsNotEmpty({ message: 'Thời gian kết thúc không được trống' })
  to: Date;

  @Expose()
  @IsEnum(WorkCenterTypeEnum)
  @IsNotEmpty({ message: 'Loại lịch không được trống' })
  type: number;

  @Expose()
  @IsInt()
  @IsNotEmpty({ message: 'Id phân xưởng không được trống' })
  workCenterId: number;
}
