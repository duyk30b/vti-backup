import { BaseDto } from '@core/dto/base.dto';
import { Expose } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';

export class DeleteWorkCenterCalendarBodyRequestDto extends BaseDto {}
export class DeleteWorkCenterCalendarRequestDto extends DeleteWorkCenterCalendarBodyRequestDto {
  @Expose()
  @IsInt()
  @IsNotEmpty({ message: 'Id lịch không được trống' })
  id: number;
}
