import { BaseDto } from '@core/dto/base.dto';
import { Expose } from 'class-transformer';
import { IsDateString, IsNotEmpty, IsNumberString } from 'class-validator';

export class SearchWorkCenterCalendarRequestDto extends BaseDto {
  @Expose()
  @IsDateString()
  @IsNotEmpty({ message: 'Thời gian bắt đầu không được trống' })
  from: Date;

  @Expose()
  @IsDateString()
  @IsNotEmpty({ message: 'Thời gian kết thúc không được trống' })
  to: Date;

  @Expose()
  @IsNumberString()
  @IsNotEmpty({ message: 'Id phân xưởng không được trống' })
  workCenterId: number;
}
