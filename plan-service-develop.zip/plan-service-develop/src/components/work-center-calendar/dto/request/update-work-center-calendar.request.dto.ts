import { Expose } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';
import { WorkCenterCalendarAbstractRequestDto } from './work-center-calendar.abstract.request.dto';

export class UpdateWorkCenterCalendarRequestDto extends WorkCenterCalendarAbstractRequestDto {
  @Expose()
  @IsInt()
  @IsNotEmpty({ message: 'Id lịch không được trống' })
  id: number;
}
