import { WorkCenterCalendarAbstractRequestDto } from './work-center-calendar.abstract.request.dto';

export class CreateWorkCenterCalendarRequestDto extends WorkCenterCalendarAbstractRequestDto {}
