export enum WorkCenterTypeEnum {
  HOLIDAY = 0,
  WORKDAY = 1,
}
