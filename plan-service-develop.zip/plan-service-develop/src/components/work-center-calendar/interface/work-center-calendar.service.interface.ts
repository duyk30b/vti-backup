export interface WorkCenterCalendarServiceInterface {
  create(request: any): Promise<any>;
  update(request: any): Promise<any>;
  delete(request: any): Promise<any>;
  search(request: any): Promise<any>;
}
