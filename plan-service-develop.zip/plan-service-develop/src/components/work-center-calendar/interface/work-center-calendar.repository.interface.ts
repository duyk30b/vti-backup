import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { WorkCenterCalendarEntity } from '@entities/work-center-calendar/work-center-calendar.entity';

export interface WorkCenterCalendarRepositoryInterface
  extends BaseInterfaceRepository<WorkCenterCalendarEntity> {
  createWorkCenterCalendar(param: any): WorkCenterCalendarEntity;
  isExist(param: any): Promise<any>;
  getWorkCenterCalendars(param: any): Promise<any[]>;
}
