import { ConfigService } from '@config/config.service';
import { WorkCenterCalendarEntity } from '@entities/work-center-calendar/work-center-calendar.entity';
import { Module } from '@nestjs/common';
import { ClientProxyFactory } from '@nestjs/microservices';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WorkCenterCalendarRepository } from 'src/repository/work-center-calendar.repository';
import { WorkCenterCalendarController } from './work-center-calendar.controller';
import { WorkCenterCalendarService } from './work-center-calendar.service';
@Module({
  imports: [TypeOrmModule.forFeature([WorkCenterCalendarEntity])],
  controllers: [WorkCenterCalendarController],
  providers: [
    {
      provide: 'WorkCenterCalendarRepositoryInterface',
      useClass: WorkCenterCalendarRepository,
    },
    {
      provide: 'WorkCenterCalendarServiceInterface',
      useClass: WorkCenterCalendarService,
    },
    ConfigService,
    {
      provide: 'PRODUCE_SERVICE',
      useFactory: (configService: ConfigService) => {
        const productServiceOptions = configService.get('produceService');
        return ClientProxyFactory.create(productServiceOptions);
      },
      inject: [ConfigService],
    },
  ],
  exports: [],
})
export class WorkCenterCalendarModule {}
