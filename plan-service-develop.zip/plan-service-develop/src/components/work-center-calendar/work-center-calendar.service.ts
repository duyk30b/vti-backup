import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { I18nService } from 'nestjs-i18n';
import { WorkCenterCalendarResponseDto } from './dto/response/work-center-calendar.response.dto';
import { WorkCenterCalendarRepositoryInterface } from './interface/work-center-calendar.repository.interface';
import { WorkCenterCalendarServiceInterface } from './interface/work-center-calendar.service.interface';

@Injectable()
export class WorkCenterCalendarService
  implements WorkCenterCalendarServiceInterface
{
  constructor(
    @Inject('WorkCenterCalendarRepositoryInterface')
    private readonly workCenterCalendarRepository: WorkCenterCalendarRepositoryInterface,
    @Inject('PRODUCE_SERVICE')
    private readonly i18n: I18nService,
    private readonly natsClientService: NatsClientService,
  ) {}

  async create(request: any): Promise<any> {
    try {
      // check work_center, work_center user
      const workCenterIsExist = await this.checkUserWorkCenter(request);

      if (workCenterIsExist) {
        return workCenterIsExist;
      }

      // check work center calendar current
      const workCenterCalendarCurrent =
        await this.workCenterCalendarRepository.isExist({
          title: request.title,
          from: request.from,
          to: request.to,
          workCenterId: request.workCenterId,
        });

      if (workCenterCalendarCurrent.length > 0) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.WORK_CENTER_CALENDAR_EXIST'),
          )
          .build();
      }

      const workCenterCalendarEntity =
        await this.workCenterCalendarRepository.createWorkCenterCalendar(
          request,
        );

      const response = await this.workCenterCalendarRepository.create(
        workCenterCalendarEntity,
      );

      const result = plainToInstance(WorkCenterCalendarResponseDto, response, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } catch (err) {
      console.log(err);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CREATE'))
        .build();
    }
  }

  async update(request: any): Promise<any> {
    try {
      // check work_center calendar exist
      const workCenterCalendar =
        await this.workCenterCalendarRepository.findOneById(request.id);

      if (!workCenterCalendar) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.WORK_CENTER_CALENDAR_NOT_EXIST'),
          )
          .build();
      }

      // check work_center, user work_center
      const workCenterIsExist = await this.checkUserWorkCenter(request);
      if (workCenterIsExist) {
        return workCenterIsExist;
      }

      // map workCenterCalendar
      workCenterCalendar.title = request.title;
      workCenterCalendar.from = request.from;
      workCenterCalendar.to = request.to;
      workCenterCalendar.description = request.description;
      workCenterCalendar.type = request.type;
      workCenterCalendar.workCenterId = request.workCenterId;
      workCenterCalendar.updatedAt = new Date();

      const response = await this.workCenterCalendarRepository.update(
        workCenterCalendar,
      );

      const result = plainToInstance(WorkCenterCalendarResponseDto, response, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } catch (err) {
      console.log(err);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }
  }

  async delete(request: any): Promise<any> {
    try {
      // check work center calendar exist
      const workCenterCalendar =
        await this.workCenterCalendarRepository.findOneById(request.id);

      if (!workCenterCalendar) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.WORK_CENTER_CALENDAR_NOT_EXIST'),
          )
          .build();
      }

      // check work_center, user work_center
      const workCenterIsExist = await this.checkUserWorkCenter({
        workCenterId: workCenterCalendar.workCenterId,
        userId: request.userId,
      });
      if (workCenterIsExist) {
        return workCenterIsExist;
      }

      await this.workCenterCalendarRepository.remove(workCenterCalendar.id);

      return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
    } catch (err) {
      console.log(err);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }
  }

  async search(request: any): Promise<any> {
    const response =
      await this.workCenterCalendarRepository.getWorkCenterCalendars(request);
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async checkUserWorkCenter(request: any) {
    let result: any = null;
    const workCenterIsExist = await this.natsClientService.send(
      'is_exist_work_center',
      {
        id: request.workCenterId,
        userId: request.userId,
      },
    );
    if (workCenterIsExist.statusCode === ResponseCodeEnum.EXIST) {
      result = new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_CENTER_NOT_EXIST'))
        .build();
    }
    if (workCenterIsExist.statusCode === ResponseCodeEnum.NOT_EXIST) {
      result = new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.USER_NOT_EXIST'))
        .build();
    }
    if (workCenterIsExist.statusCode !== ResponseCodeEnum.SUCCESS) {
      result = new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
    return result;
  }
}
