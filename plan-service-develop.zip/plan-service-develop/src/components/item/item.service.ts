import { NATS_ITEM } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Inject, Injectable } from '@nestjs/common';
import { REQUEST } from '@nestjs/core';
import { Request } from 'express';
import { keyBy } from 'lodash';
import { ItemServiceInterface } from './interface/item.service.interface';

@Injectable()
export class ItemService implements ItemServiceInterface {
  constructor(
    @Inject('ITEM_SERVICE_CLIENT')
    @Inject(REQUEST)
    private readonly req: Request,
    private readonly natsClientService: NatsClientService,
  ) {}
  async getItemByIds(itemIds: number[], isSerialize = false): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_items_by_ids`,
      {
        itemIds: itemIds,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS)
      return isSerialize ? {} : [];
    return isSerialize ? keyBy(response.data, 'id') : response.data;
  }
}
