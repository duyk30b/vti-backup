export interface ItemServiceInterface {
  getItemByIds(itemIds: number[], isSerialize?: boolean): Promise<any>;
}
