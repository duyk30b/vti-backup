import { Injectable } from '@nestjs/common';
import { AuthServiceInterface } from '@components/auth/interface/auth.service.interface';
import { genericRetryStrategy } from '@utils/rxjs-util';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { NATS_AUTH } from '@config/nats.config';

@Injectable()
export class AuthService implements AuthServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async validateToken(token: string, permissionCode: string): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_AUTH}.validate_token`,
      {
        permissionCode,
        token,
      },
    );
    return response;
  }
}
