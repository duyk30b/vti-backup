import { NATS_WAREHOUSE } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Inject, Injectable } from '@nestjs/common';
import { REQUEST } from '@nestjs/core';
import { ClientProxy } from '@nestjs/microservices';
import { Request } from 'express';
import { GetMaterialPlanByItemIdsRequestDto } from './dto/request/get-material-plan-by-item-ids.request.dto';
import { MaterialPlanResponseDto } from './dto/response/material-plan.response.dto';
import { WarehouseServiceInterface } from './interface/warehouse.service.interface';

@Injectable()
export class WarehouseService implements WarehouseServiceInterface {
  constructor(
    @Inject(REQUEST) private readonly req: Request,
    private readonly natsClientService: NatsClientService,
  ) {}

  async getMaterialPlanByItemIds(
    request: GetMaterialPlanByItemIdsRequestDto,
  ): Promise<MaterialPlanResponseDto[] | any> {
    const response = await this.natsClientService.send(
      `${NATS_WAREHOUSE}.get_material_plan_by_item_ids`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    return response.data;
  }
}
