import { Expose, Type } from 'class-transformer';

class ScheduleMaterial {
  @Expose()
  date: Date;

  @Expose()
  quantity: number;
}

export class MaterialPlanResponseDto {
  @Expose()
  itemId: number;

  @Expose()
  actualQuantity: number;

  @Expose()
  @Type(() => ScheduleMaterial)
  schedules: ScheduleMaterial[];
}
