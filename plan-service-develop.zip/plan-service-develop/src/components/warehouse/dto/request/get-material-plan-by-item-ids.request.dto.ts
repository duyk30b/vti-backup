import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsInt,
  IsNotEmpty,
  ValidateNested,
} from 'class-validator';

class MaterialItem {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  quantity: number;
}

export class GetMaterialPlanByItemIdsRequestDto {
  @ApiProperty()
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => MaterialItem)
  items: MaterialItem[];
}
