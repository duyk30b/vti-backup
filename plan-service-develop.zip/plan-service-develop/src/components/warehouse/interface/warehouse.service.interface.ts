import { GetMaterialPlanByItemIdsRequestDto } from '../dto/request/get-material-plan-by-item-ids.request.dto';
import { MaterialPlanResponseDto } from '../dto/response/material-plan.response.dto';

export interface WarehouseServiceInterface {
  getMaterialPlanByItemIds(
    request: GetMaterialPlanByItemIdsRequestDto,
  ): Promise<MaterialPlanResponseDto | any>;
}
