import { MasterPlanStatusEnum } from '@constant/common';
import {
  Column,
  Entity,
  JoinColumn,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { SaleOrderScheduleEntity } from '../sale-order-schedule/sale-order-schedule.entity';

@Entity({ name: 'master_plans' })
export class MasterPlanEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
  })
  code: string;

  @Column({
    type: 'varchar',
  })
  name: string;

  @Column({
    type: 'varchar',
  })
  description: string;

  @Column({
    type: 'int',
  })
  factoryId: number;

  @Column({
    type: 'int',
    default: MasterPlanStatusEnum.CREATED,
    enum: MasterPlanStatusEnum,
  })
  status: number;

  @Column({
    type: 'date',
  })
  dateFrom: Date;

  @Column({
    type: 'date',
  })
  dateTo: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
  })
  createdAt: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
  })
  updatedAt: Date;

  @Column({
    type: 'int',
    nullable: true,
  })
  createdBy: number;

  @Column({
    type: 'int',
    nullable: true,
  })
  updatedBy: number;

  @Column({
    type: 'int',
    nullable: true,
  })
  approverId: number;

  @Column({
    type: 'date',
    nullable: true,
  })
  approvedAt: string;

  @OneToMany(
    () => SaleOrderScheduleEntity,
    (saleOrderSchedules) => saleOrderSchedules.masterPlanSchema,
    { cascade: ['insert'] },
  )
  @JoinColumn({
    name: 'id',
    referencedColumnName: 'sale_order_schedule_id',
  })
  saleOrderSchedules: SaleOrderScheduleEntity[];
}
