import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { ItemScheduleEntity } from './item-schedule.entity';
import { MasterPlanEntity } from '../master-plan/master-plan.entity';

@Entity({ name: 'sale_order_schedules' })
export class SaleOrderScheduleEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'int',
    name: 'master_plan_id',
  })
  masterPlanId: number;

  @Column({
    type: 'varchar',
    nullable: false,
    name: 'sale_order_id',
  })
  saleOrderId: string;

  @Column({
    type: 'date',
    nullable: false,
    name: 'date_from',
  })
  dateFrom: Date;

  @Column({
    type: 'date',
    nullable: false,
    name: 'date_to',
  })
  dateTo: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
    name: 'created_at',
  })
  createdAt: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
    name: 'updated_at',
  })
  updatedAt: Date;

  @ManyToOne(
    () => MasterPlanEntity,
    (masterPlanSchema) => masterPlanSchema.saleOrderSchedules,
  )
  @JoinColumn({
    name: 'master_plan_id',
    referencedColumnName: 'id',
  })
  masterPlanSchema: MasterPlanEntity;

  @OneToMany(
    () => ItemScheduleEntity,
    (itemSchedules) => itemSchedules.saleOrderSchema,
    { cascade: ['insert'] },
  )
  @JoinColumn({
    name: 'id',
    referencedColumnName: 'sale_order_schedule_id',
  })
  itemSchedules: ItemScheduleEntity[];
}
