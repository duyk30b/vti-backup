import {
  Column,
  Entity,
  JoinColumn,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { ItemProducingStepScheduleEntity } from './item-producing-step-schedule.entity';

@Entity({ name: 'item_manufacturing_orders' })
export class ItemManufacturingOrderEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'int',
    name: 'master_plan_id',
  })
  masterPlanId: number;

  @Column({
    type: 'int',
    name: 'sale_order_schedule_id',
  })
  saleOrderScheduleId: number;

  @Column({
    type: 'int',
    name: 'item_schedule_id',
  })
  itemScheduleId: number;

  @Column({
    type: 'int',
    name: 'item_id',
  })
  itemId: number;

  @Column({
    type: 'int',
    name: 'mo_id',
  })
  moId: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'quantity',
  })
  quantity: number;

  @Column({
    type: 'date',
    nullable: false,
    name: 'date_from',
  })
  dateFrom: Date;

  @Column({
    type: 'date',
    nullable: false,
    name: 'date_to',
  })
  dateTo: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
    name: 'created_at',
  })
  createdAt: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
    name: 'updated_at',
  })
  updatedAt: Date;

  @OneToMany(
    () => ItemProducingStepScheduleEntity,
    (itemProducingStepSchedules) => itemProducingStepSchedules.itemSchedule,
    { cascade: ['insert'] },
  )
  @JoinColumn({
    name: 'id',
    referencedColumnName: 'item_schedule_id',
  })
  itemProducingStepSchedules: ItemProducingStepScheduleEntity[];
}
