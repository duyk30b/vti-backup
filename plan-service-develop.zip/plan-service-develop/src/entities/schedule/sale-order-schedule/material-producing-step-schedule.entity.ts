import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { ItemProducingStepScheduleEntity } from './item-producing-step-schedule.entity';

@Entity({ name: 'material_producing_step_schedules' })
export class MaterialProducingStepScheduleEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'item_producing_step_schedule_id',
  })
  itemProducingStepScheduleId: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'item_id',
  })
  itemId: number;

  @Column({
    type: 'decimal',
    precision: 20,
    scale: 2,
    default: 0,
  })
  quantity: number;

  @Column({
    type: 'decimal',
    precision: 20,
    scale: 2,
    default: 0,
  })
  actualQuantity: number;

  @ManyToOne(
    () => ItemProducingStepScheduleEntity,
    (itemProducingStepSchedule) =>
      itemProducingStepSchedule.materialProducingStepSchedules,
  )
  @JoinColumn({
    name: 'item_producing_step_schedule_id',
    referencedColumnName: 'id',
  })
  itemProducingStepSchedule: ItemProducingStepScheduleEntity;
}
