import { ItemProducingStepStatusEnum } from '@constant/common';
import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { ItemScheduleEntity } from './item-schedule.entity';
import { WorkCenterScheduleEntity } from '../work-center-schedule/work-center-schedule.entity';
import { plus } from '@utils/common';
import { MaterialProducingStepScheduleEntity } from './material-producing-step-schedule.entity';

@Entity({ name: 'item_producing_step_schedules' })
export class ItemProducingStepScheduleEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'item_schedule_id',
  })
  itemScheduleId: number;

  @Column({
    type: 'int',
    nullable: false,
  })
  saleOrderScheduleId: number;

  @Column({
    type: 'int',
    nullable: false,
  })
  masterPlanId: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'producing_step_id',
  })
  producingStepId: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'quantity',
  })
  quantity: number;

  @Column({
    type: 'int',
    nullable: true,
    name: 'plan_quantity',
    default: 0,
  })
  planQuantity: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'over_quantity',
  })
  overQuantity: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'actual_quantity',
  })
  actualQuantity: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'error_quantity',
  })
  errorQuantity: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'step_number',
  })
  stepNumber: number;

  @Column({
    type: 'int',
    default: ItemProducingStepStatusEnum.CREATED,
    enum: ItemProducingStepStatusEnum,
  })
  status: number;

  @Column({
    type: 'date',
    nullable: false,
    name: 'date_from',
  })
  dateFrom: Date;

  @Column({
    type: 'date',
    nullable: false,
    name: 'date_to',
  })
  dateTo: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
    name: 'created_at',
  })
  createdAt: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
    name: 'updated_at',
  })
  updatedAt: Date;

  @ManyToOne(
    () => ItemScheduleEntity,
    (itemSchedule) => itemSchedule.itemProducingStepSchedules,
  )
  @JoinColumn({
    name: 'item_schedule_id',
    referencedColumnName: 'id',
  })
  itemSchedule: ItemScheduleEntity;

  @OneToMany(
    () => WorkCenterScheduleEntity,
    (workCenterSchedules) => workCenterSchedules.itemProducingStepSchedule,
    { cascade: ['insert', 'remove'] },
  )
  @JoinColumn({
    name: 'id',
    referencedColumnName: 'item_producing_step_schedule_id',
  })
  workCenterSchedules: WorkCenterScheduleEntity[];

  @OneToMany(
    () => MaterialProducingStepScheduleEntity,
    (materialProducingStepSchedules) =>
      materialProducingStepSchedules.itemProducingStepSchedule,
    { cascade: ['insert', 'remove'] },
  )
  @JoinColumn({
    name: 'id',
    referencedColumnName: 'material_producing_step_schedule_id',
  })
  materialProducingStepSchedules: MaterialProducingStepScheduleEntity[];

  public async setProgressQuantity(
    quantity: number,
    errorQuantity: number,
  ): Promise<any> {
    this.actualQuantity = plus(this.actualQuantity || 0, quantity || 0);
    this.errorQuantity = plus(this.errorQuantity || 0, errorQuantity || 0);

    return this;
  }
}
