import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { ItemProducingStepScheduleEntity } from './item-producing-step-schedule.entity';
import { SaleOrderScheduleEntity } from './sale-order-schedule.entity';

@Entity({ name: 'item_schedules' })
export class ItemScheduleEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'sale_order_schedule_id',
  })
  saleOrderScheduleId: number;

  @Column({
    type: 'int',
    nullable: false,
  })
  masterPlanId: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'item_id',
  })
  itemId: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'bom_id',
  })
  bomId: number;

  @Column({
    type: 'int',
  })
  bomVersionId: number;

  @Column({
    type: 'int',
    nullable: true,
    name: 'parent_bom_id',
  })
  parentBomId: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'parent_bom_version_id',
  })
  parentBomVersionId: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'quantity',
  })
  quantity: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'actual_quantity',
  })
  actualQuantity: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'error_quantity',
  })
  errorQuantity: number;

  @Column({
    type: 'int',
    name: 'level',
    default: 1,
  })
  level: number;

  @Column({
    type: 'int',
    name: 'is_over_quantity',
    default: false,
  })
  isOverQuantity: boolean;

  @Column({
    type: 'int',
    name: 'item_finish_id',
    default: null,
  })
  itemFinishId: number;

  @Column({
    type: 'int',
  })
  status: number;

  @Column({
    type: 'date',
    nullable: false,
    name: 'date_from',
  })
  dateFrom: Date;

  @Column({
    type: 'date',
    nullable: false,
    name: 'date_to',
  })
  dateTo: Date;

  @Column({
    type: 'boolean',
    name: 'need_to_manufacture',
    default: true,
  })
  needToManufacture: boolean;

  @Column({
    type: 'timestamptz',
    nullable: false,
    name: 'created_at',
  })
  createdAt: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
    name: 'updated_at',
  })
  updatedAt: Date;

  @ManyToOne(
    () => SaleOrderScheduleEntity,
    (saleOrderSchema) => saleOrderSchema.itemSchedules,
  )
  @JoinColumn({
    name: 'sale_order_schedule_id',
    referencedColumnName: 'id',
  })
  saleOrderSchema: SaleOrderScheduleEntity;

  @OneToMany(
    () => ItemProducingStepScheduleEntity,
    (itemProducingStepSchedules) => itemProducingStepSchedules.itemSchedule,
    { cascade: ['insert'] },
  )
  @JoinColumn({
    name: 'id',
    referencedColumnName: 'item_schedule_id',
  })
  itemProducingStepSchedules: ItemProducingStepScheduleEntity[];
  freeRange: any[];
}
