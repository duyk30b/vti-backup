import { plus } from '@utils/common';
import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { WorkCenterScheduleEntity } from './work-center-schedule.entity';

@Entity({ name: 'work_center_detail_schedules' })
export class WorkCenterDetailScheduleEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'work_center_schedule_id',
  })
  workCenterScheduleId: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'work_center_shift_schedule_id',
  })
  workCenterShiftScheduleId: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'quantity',
  })
  quantity: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'actual_quantity',
  })
  actualQuantity: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'error_quantity',
  })
  errorQuantity: number;

  @Column({
    type: 'time',
    nullable: false,
    name: 'excution_from',
  })
  excutionFrom: Date;

  @Column({
    type: 'time',
    nullable: false,
    name: 'excution_to',
  })
  excutionTo: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
    name: 'created_at',
  })
  createdAt: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
    name: 'updated_at',
  })
  updatedAt: Date;

  @ManyToOne(
    () => WorkCenterScheduleEntity,
    (workCenterSchedule) => workCenterSchedule.workCenterDetailSchedules,
  )
  @JoinColumn({
    name: 'work_center_schedule_id',
    referencedColumnName: 'id',
  })
  workCenterSchedule: WorkCenterScheduleEntity;

  public async setProgressQuantity(
    quantity: number,
    errorQuantity: number,
  ): Promise<any> {
    this.actualQuantity = plus(this.actualQuantity || 0, quantity || 0);
    this.errorQuantity = plus(this.errorQuantity || 0, errorQuantity || 0);

    return this;
  }
}
