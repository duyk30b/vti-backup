import { plus } from '@utils/common';
import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { ItemProducingStepScheduleEntity } from '../sale-order-schedule/item-producing-step-schedule.entity';
import { WorkCenterDetailScheduleEntity } from './work-center-detail-schedule.entity';

@Entity({ name: 'work_center_schedules' })
export class WorkCenterScheduleEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'work_center_id',
  })
  workCenterId: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'item_producing_step_schedule_id',
  })
  itemProducingStepScheduleId: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'quantity',
  })
  quantity: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'actual_quantity',
  })
  actualQuantity: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'error_quantity',
  })
  errorQuantity: number;

  @Column({
    type: 'date',
    nullable: false,
    name: 'excution_date',
  })
  excutionDate: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
    name: 'created_at',
  })
  createdAt: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
    name: 'updated_at',
  })
  updatedAt: Date;

  @ManyToOne(
    () => ItemProducingStepScheduleEntity,
    (itemProducingStepSchedule) =>
      itemProducingStepSchedule.workCenterSchedules,
  )
  @JoinColumn({
    name: 'item_producing_step_schedule_id',
    referencedColumnName: 'id',
  })
  itemProducingStepSchedule: ItemProducingStepScheduleEntity;

  @OneToMany(
    () => WorkCenterDetailScheduleEntity,
    (workCenterDetailSchedule) => workCenterDetailSchedule.workCenterSchedule,
    { cascade: ['insert'] },
  )
  @JoinColumn({
    name: 'id',
    referencedColumnName: 'work_center_schedule_id',
  })
  workCenterDetailSchedules: WorkCenterDetailScheduleEntity[];

  public async setProgressQuantity(
    quantity: number,
    errorQuantity: number,
  ): Promise<any> {
    this.actualQuantity = plus(this.actualQuantity || 0, quantity || 0);
    this.errorQuantity = plus(this.errorQuantity || 0, errorQuantity || 0);

    return this;
  }
}
