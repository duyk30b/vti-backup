import { WorkCenterTypeEnum } from '@components/work-center-calendar/work-center-calendar.constant';
import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ name: 'work_center_calendar' })
export class WorkCenterCalendarEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
    nullable: false,
  })
  title: string;

  @Column({
    type: 'varchar',
    nullable: true,
  })
  description: string;

  @Column({
    type: 'timestamptz',
    nullable: false,
  })
  from: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
  })
  to: Date;

  @Column({
    type: 'enum',
    enum: WorkCenterTypeEnum,
    default: WorkCenterTypeEnum.HOLIDAY,
  })
  type: number;

  @Column({
    type: 'int',
    nullable: false,
    name: 'work_center_id',
  })
  workCenterId: number;

  @Column({
    type: 'timestamptz',
    nullable: false,
    name: 'created_at',
  })
  createdAt: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
    name: 'updated_at',
  })
  updatedAt: Date;
}
