import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { FactoryCalendarEntity } from './factory-calendar.entity';

@Entity({ name: 'factory_work_days' })
export class FactoryWorkDayEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'int',
    nullable: false,
  })
  factoryCalendarId: number;

  @Column({
    type: 'int',
    nullable: false,
  })
  workingDay: number;

  @Column({
    type: 'timestamptz',
    nullable: false,
    name: 'created_at',
  })
  createdAt: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
    name: 'updated_at',
  })
  updatedAt: Date;

  @ManyToOne(
    () => FactoryCalendarEntity,
    (factoryCalendar) => factoryCalendar.factoryWorkDays,
  )
  @JoinColumn({
    name: 'factory_calendar_id',
    referencedColumnName: 'id',
  })
  factoryCalendar: FactoryCalendarEntity;
}
