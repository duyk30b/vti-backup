import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { EventEntity } from './event.entity';

@Entity({ name: 'event_factories' })
export class EventFactoryEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'int',
  })
  eventId: number;

  @Column({
    type: 'int',
  })
  factoryId: number;

  @ManyToOne(() => EventEntity, (event) => event.eventFactories)
  @JoinColumn({
    name: 'event_id',
    referencedColumnName: 'id',
  })
  event: EventEntity;
}
