import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { FactoryCalendarEntity } from './factory-calendar.entity';
import { ShiftEntity } from './shift.entity';

@Entity({ name: 'factory_calendar_shifts' })
export class FactoryCalendarShiftEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'int',
    nullable: false,
  })
  factoryCalendarId: number;

  @Column({
    type: 'int',
    nullable: false,
  })
  shiftId: number;

  @ManyToOne(
    () => FactoryCalendarEntity,
    (factoryCalendar) => factoryCalendar.factoryCalendarShifts,
  )
  @JoinColumn({
    name: 'factory_calendar_id',
    referencedColumnName: 'id',
  })
  factoryCalendar: FactoryCalendarEntity;

  @ManyToOne(() => ShiftEntity, (shift) => shift.factoryCalendarShifts)
  @JoinColumn({
    name: 'shift_id',
    referencedColumnName: 'id',
  })
  shift: ShiftEntity;
}
