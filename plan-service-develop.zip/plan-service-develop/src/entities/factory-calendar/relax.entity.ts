import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { ShiftEntity } from './shift.entity';

@Entity({ name: 'relaxes' })
export class RelaxEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'int',
    nullable: false,
  })
  shiftId: number;

  @Column({
    type: 'varchar',
    nullable: false,
  })
  title: string;

  @Column({
    type: 'varchar',
    nullable: true,
  })
  description: string;

  @Column({
    type: 'time',
    nullable: false,
  })
  from: Date;

  @Column({
    type: 'time',
    nullable: false,
  })
  to: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
  })
  createdAt: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
  })
  updatedAt: Date;

  @ManyToOne(() => ShiftEntity, (shift) => shift.relaxes)
  @JoinColumn({
    name: 'shift_id',
    referencedColumnName: 'id',
  })
  shift: ShiftEntity;
}
