import {
  Column,
  Entity,
  JoinColumn,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { FactoryCalendarShiftEntity } from './factory-calendar-shift.entity';
import { RelaxEntity } from './relax.entity';

@Entity({ name: 'shifts' })
export class ShiftEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
    nullable: false,
  })
  title: string;

  @Column({
    type: 'varchar',
    nullable: true,
  })
  description: string;

  @Column({
    type: 'time',
    nullable: false,
  })
  from: Date;

  @Column({
    type: 'time',
    nullable: false,
  })
  to: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
  })
  createdAt: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
  })
  updatedAt: Date;

  @OneToMany(() => RelaxEntity, (relaxes) => relaxes.shift, {
    cascade: ['insert'],
  })
  @JoinColumn({
    name: 'id',
    referencedColumnName: 'shift_id',
  })
  relaxes: RelaxEntity[];

  @OneToMany(
    () => FactoryCalendarShiftEntity,
    (factoryCalendarShifts) => factoryCalendarShifts.shift,
    {
      cascade: ['insert'],
    },
  )
  @JoinColumn({
    name: 'id',
    referencedColumnName: 'shift_id',
  })
  factoryCalendarShifts: FactoryCalendarShiftEntity[];
}
