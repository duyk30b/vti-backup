import { FactoryTypeEnum } from '@components/factory-calendar/factory-calendar.constant';
import {
  Column,
  Entity,
  JoinColumn,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { FactoryCalendarShiftEntity } from './factory-calendar-shift.entity';
import { FactoryWorkDayEntity } from './factory-work-day.entity';

@Entity({ name: 'factory_calendar' })
export class FactoryCalendarEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'int',
    nullable: false,
  })
  factoryId: number;

  @Column({
    type: 'varchar',
    nullable: false,
  })
  title: string;

  @Column({
    type: 'varchar',
    nullable: true,
  })
  description: string;

  @Column({
    type: 'timestamptz',
    nullable: false,
  })
  from: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
  })
  to: Date;

  @Column({
    type: 'enum',
    enum: FactoryTypeEnum,
    default: FactoryTypeEnum.HOLIDAY,
  })
  type: number;

  @Column({
    type: 'timestamptz',
    nullable: false,
    name: 'created_at',
  })
  createdAt: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
    name: 'updated_at',
  })
  updatedAt: Date;

  @OneToMany(
    () => FactoryWorkDayEntity,
    (factoryWorkDays) => factoryWorkDays.factoryCalendar,
    { cascade: ['insert'] },
  )
  @JoinColumn({
    name: 'id',
    referencedColumnName: 'factory_calendar_id',
  })
  factoryWorkDays: FactoryWorkDayEntity[];

  @OneToMany(
    () => FactoryCalendarShiftEntity,
    (factoryCalendarShifts) => factoryCalendarShifts.factoryCalendar,
    { cascade: ['insert'] },
  )
  @JoinColumn({
    name: 'id',
    referencedColumnName: 'factory_calendar_id',
  })
  factoryCalendarShifts: FactoryCalendarShiftEntity[];
}
