import {
  Column,
  Entity,
  JoinColumn,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { EventFactoryEntity } from './event-factories.entity';

@Entity({ name: 'events' })
export class EventEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
    nullable: false,
  })
  code: string;

  @Column({
    type: 'varchar',
    nullable: false,
  })
  title: string;

  @Column({
    type: 'varchar',
    nullable: true,
  })
  description: string;

  @Column({
    type: 'int',
    nullable: true,
  })
  type: number;

  @Column({
    type: 'timestamptz',
    nullable: false,
  })
  from: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
  })
  to: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
    name: 'created_at',
  })
  createdAt: Date;

  @Column({
    type: 'timestamptz',
    nullable: false,
    name: 'updated_at',
  })
  updatedAt: Date;

  @OneToMany(
    () => EventFactoryEntity,
    (eventFactories) => eventFactories.event,
    { cascade: ['insert'] },
  )
  @JoinColumn({
    name: 'id',
    referencedColumnName: 'event_id',
  })
  eventFactories: EventFactoryEntity[];
}
