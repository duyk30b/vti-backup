import { ALLOW_MIME_TYPE } from './../constant/common';
import { MAX_SIZE_FILE } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
} from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { getFileSize } from '@utils/file-upload.util';
import { I18nRequestScopeService } from 'nestjs-i18n';

@Injectable()
export class ValidateFileInterceptor implements NestInterceptor {
  constructor(private readonly i18n: I18nRequestScopeService) {}
  async intercept(context: ExecutionContext, next: CallHandler) {
    const request = context.getArgByIndex(0);
    const { body } = request;
    const maxFileSize = body.allowFileSize || MAX_SIZE_FILE;

    if (body.allowMimetype && !ALLOW_MIME_TYPE.includes(body.allowMimetype)) {
      return of(
        new ResponseBuilder()
          .withMessage(this.i18n.translate('error.MIMETYPE_NOT_ACCEPT'))
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .build(),
      );
    }
    if (!body.file && !body.files) {
      return of(
        new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage('error.FILE_IS_REQUIRED')
          .build(),
      );
    }
    const files = body.file || body.files;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (getFileSize(file) > maxFileSize) {
        return of(
          new ResponseBuilder()
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(this.i18n.translate('error.FILE_SIZE_INVALID'))
            .build(),
        );
      }
      if (
        (body.allowMimetype && file.mimetype !== body.allowMimetype) ||
        !ALLOW_MIME_TYPE.includes(file.mimetype)
      ) {
        return of(
          new ResponseBuilder()
            .withMessage(this.i18n.translate('error.MIMETYPE_NOT_ACCEPT'))
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .build(),
        );
      }
    }
    const now = Date.now();
    return next
      .handle()
      .pipe(tap(() => console.log(`After... ${Date.now() - now}ms`)));
  }
}
