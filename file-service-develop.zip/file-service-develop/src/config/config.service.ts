export class ConfigService {
  private readonly envConfig: { [key: string]: any } = null;

  constructor() {
    this.envConfig = {
      port: process.env.SERVER_PORT,
      httpPort: process.env.SERVER_HTTP_PORT,
    };

    this.envConfig.fileUrl = {
      options: {
        url: process.env.FILE_URL || '10.1.14.17:30222/api/v1/files',
      },
    };
  }

  get(key: string): any {
    return this.envConfig[key];
  }
}
