import * as dotenv from 'dotenv';
dotenv.config();

export enum APIPrefix {
  Version = 'api/v1',
}

//permission
export enum StatusPermission {
  ACTIVE = 1,
  INACTIVE = 0,
}

export const jwtConstants = {
  acessTokenSecret: process.env.JWT_ACESS_TOKEN_SECRET,
  acessTokenExpiresIn: process.env.JWT_ACESS_TOKEN_EXPIRES_IN || 1800,
  refeshTokenSecret: process.env.JWT_RESFRESH_TOKEN_SECRET,
  refeshTokenExpiresIn: process.env.JWT_RESFRESH_TOKEN_EXPIRES_IN || 2000,
  refeshTokenExpiresMaxIn:
    process.env.JWT_RESFRESH_TOKEN_EXPIRES_MAX_IN || 432000,
};

export const SUPER_ADMIN = {
  code: '000000001',
  username: 'admin',
  password: 'snp1234567',
  email: 'admin@smartwms.vti.com.vn',
  fullName: 'Admin',
};

export enum SortOrder {
  Ascending = 1,
  Descending = -1,
}

export const SORT_CONST = {
  ASCENDING: 'asc',
  DESCENDING: 'desc',
};

export const FORMAT_CODE_PERMISSION = 'USER_';

export const MIMETYPE_CAN_RETURN_URL = [
  'image/gif',
  'image/jpeg',
  'image/png',
  'image/jpg',
];

export const MAX_SIZE_FILE = 4096;

export const ALLOW_MIME_TYPE = (process.env.ALLOW_MIME_TYPE || '').split(',');
