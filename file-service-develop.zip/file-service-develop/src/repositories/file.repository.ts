import { FileRepositoryInterface } from '@components/file/interfaces/file.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { SingleFileModel } from 'src/models/files/single-file.model';

@Injectable()
export class FileRepository
  extends BaseAbstractRepository<SingleFileModel>
  implements FileRepositoryInterface
{
  constructor(
    @InjectModel('SingleFileModel')
    private readonly singleFileModel: Model<SingleFileModel>,
  ) {
    super(singleFileModel);
  }

  createEntity(
    params: any,
    isReturnUrl = false,
    fileUrl: string,
  ): SingleFileModel {
    const fileEntity = new this.singleFileModel();
    fileEntity.service = params.service;
    fileEntity.createdBy = params.createdBy;
    fileEntity.resource = params.resource;
    fileEntity.mimeType = params.mimeType;
    fileEntity.isReturnUrl = isReturnUrl;
    fileEntity.fileUrl = fileUrl;
    fileEntity.fileNameRaw = params.fileNameRaw;
    return fileEntity;
  }
}
