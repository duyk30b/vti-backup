import { extname } from 'path';

export interface File {
  data: any;
  fieldname: string;
  originalname: string;
  encoding: string;
  mimetype: string;
  size?: number;
  destination?: string;
  filename?: string;
  path?: string;
  buffer?: Buffer;
  stream?: NodeJS.ReadableStream;
}

// export const File = createParamDecorator(
//   (_data: unknown, ctx: ExecutionContext) => {
//     const req = ctx.switchToHttp().getRequest() as FastifyRequest;
//     const file = req.incomingFile;
//     return file;
//   },
// );

export const editFileName = (req: any, file: File, callback) => {
  const name = file.originalname.split('.')[0];
  const fileExtName = extname(file.originalname);
  const randomName = Array(4)
    .fill(null)
    .map(() => Math.round(Math.random() * 16).toString(16))
    .join('');
  callback(null, `${name}-${randomName}${fileExtName}`);
};

export const imageFileFilter = (req: any, file: File, callback) => {
  if (!file.originalname.match(/\.(jpg|jpeg|png|gif)$/)) {
    return callback(new Error('Only image files are allowed!'), false);
  }
  callback(null, true);
};

export const getFileSize = (file) => {
  return (file?.data.toString().length || 0) / 1024;
};
