import { v4 as uuidv4 } from 'uuid';

export const renderLink = (payload: any) => {
  const { _id } = payload;
  return _id.toString();
};

export const renderFileName = (file: any) => {
  const { filename } = file;
  const arr = filename.split('.');
  return `${uuidv4()}.${arr[arr.length - 1]}`;
};
