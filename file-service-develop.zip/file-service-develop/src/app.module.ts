import { KongGatewayModule } from './core/components/kong-gateway/kong-gateway.module';
import { BootModule } from '@nestcloud/boot';
import DatabaseConfigService from '@config/database.config';
import filesystem from '@config/filesystem';
import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { StorageModule } from '@squareboat/nest-storage';
import { I18nModule } from 'nestjs-i18n';
import * as path from 'path';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { FileModule } from './components/file/file.module';
import { HttpClientModule } from '@core/components/http-client/http-client.module';
import { CoreModule } from '@core/core.module';
import { ValidationPipe } from '@core/pipe/validation.pipe';
import { APP_PIPE } from '@nestjs/core';
import { ConsulModule } from '@nestcloud/consul';
import { ServiceModule } from '@nestcloud/service';
import { BOOT, CONSUL } from '@nestcloud/common';
@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      expandVariables: true,
      load: [filesystem],
    }),
    I18nModule.forRoot({
      fallbackLanguage: 'vi',
      loaderOptions: {
        path: path.join(__dirname, '/i18n/'),
        watch: true,
      },
    }),
    MongooseModule.forRootAsync({
      useClass: DatabaseConfigService,
    }),
    BootModule.forRoot({
      filePath: path.resolve(__dirname, '../config.yaml'),
    }),
    HttpClientModule,
    ConsulModule.forRootAsync({ inject: [BOOT] }),
    ServiceModule.forRootAsync({ inject: [BOOT, CONSUL] }),
    KongGatewayModule.forRootAsync(),
    CoreModule,
    StorageModule.registerAsync({
      imports: [ConfigService],
      useFactory: (config: ConfigService) => {
        return config.get('filesystem');
      },
      inject: [ConfigService],
    }),
    FileModule,
  ],
  controllers: [AppController],
  providers: [
    {
      provide: APP_PIPE,
      useClass: ValidationPipe,
    },
    AppService,
  ],
})
export class AppModule {}
