import { MIMETYPE_CAN_RETURN_URL } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject } from '@nestjs/common';
import { renderLink } from '@utils/helper';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToClass } from 'class-transformer';
import { MultipleFileUploadRequestDto } from './dto/request/upload-multiple-file.request.dto';
import { SingleFileResponseDto } from './dto/response/upload-single-file.response.dto';
import { FileServiceAbstract } from './file.service.abstract';
import { FileRepositoryInterface } from './interfaces/file.repository.interface';

export class MultipleFileService extends FileServiceAbstract {
  constructor(
    @Inject('FileRepositoryInterface')
    private readonly singleFileRepository: FileRepositoryInterface,
  ) {
    super();
  }
  public async upload(request: MultipleFileUploadRequestDto): Promise<any> {
    try {
      const { files, service, resource, userId } = request;
      const listUrl = [];

      for (let index = 0; index < files.length; index++) {
        const file = files[index];
        listUrl.push((await this.saveFile(file, service, resource))?.path);
      }

      const fileEntities = listUrl.map((url, index) => {
        return this.singleFileRepository.createEntity(
          {
            service: service,
            resource: resource,
            createdBy: userId,
            mimeType: files[index]?.mimetype,
            fileNameRaw: files[index]?.filename,
          },
          MIMETYPE_CAN_RETURN_URL.includes(files[index]?.mimetype),
          url,
        );
      });
      const res = await this.singleFileRepository.createMany(fileEntities);
      const renderUrl = res.map((link) => renderLink(link));
      const response = plainToClass(SingleFileResponseDto, renderUrl, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } catch (e) {
      console.log(e);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .build();
    }
  }
}
