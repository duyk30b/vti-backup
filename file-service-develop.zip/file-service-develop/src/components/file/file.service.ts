import { Response } from 'express';
import { Inject } from '@nestjs/common';
import { SingleFileRequestDto } from './dto/request/upload-singer-file.request.dto';
import { SingleFileResponseDto } from './dto/response/upload-single-file.response.dto';
import { plainToClass, plainToInstance } from 'class-transformer';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { FileRepositoryInterface } from './interfaces/file.repository.interface';
import { MIMETYPE_CAN_RETURN_URL } from '@constant/common';
import { renderLink } from '@utils/helper';
import * as path from 'path';
import * as fs from 'fs';
import { FileServiceAbstract } from './file.service.abstract';
import { Types } from 'mongoose';
import { GetFilesRequestDto } from './dto/request/get-files.request.dto';
import { isEmpty } from 'lodash';
import { GetFilesByIdsResponse } from './dto/response/get-files-by-ids.response.dto';
import { ConfigService } from '@config/config.service';
export class FileService extends FileServiceAbstract {
  protected readonly urlConfig: any;
  protected readonly url: string;
  constructor(
    @Inject('FileRepositoryInterface')
    private readonly singleFileRepository: FileRepositoryInterface,

    @Inject('ConfigServiceInterface')
    private readonly configService: ConfigService,
  ) {
    super();
    this.configService = new ConfigService();
    this.urlConfig = this.configService.get('fileUrl');
    this.url = `http://${this.urlConfig?.options?.url}`;
  }

  // Upload single File
  public async upload(request: SingleFileRequestDto): Promise<any> {
    try {
      const { file, service, resource, userId } = request;
      const fileData = file[0] || {};
      const fileUrl = await this.saveFile(fileData, service, resource);
      const singleFileDoc = this.singleFileRepository.createEntity(
        {
          mimeType: fileData.mimetype,
          service: service,
          resource: resource,
          createdBy: userId,
        },
        MIMETYPE_CAN_RETURN_URL.includes(fileData.mimetype),
        fileUrl.path,
      );

      const resultTemp = await this.singleFileRepository.create(singleFileDoc);
      const result = {
        ...resultTemp,
        fileUrl: renderLink(resultTemp),
      };

      const response = plainToClass(SingleFileResponseDto, result, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } catch (e) {
      console.log(e);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .build();
    }
  }

  async getFile(id: string, res: Response): Promise<any> {
    try {
      if (Types.ObjectId.isValid(id)) {
        const fileInf = await this.singleFileRepository.findOneById(id);
        if (!fileInf) {
          return res
            .status(404)
            .send({ statusCode: 404, message: 'FILE_NOT_FOUND' });
        }
        const fileUrl = path.resolve(process.cwd(), `${fileInf.fileUrl}`);
        if (fs.existsSync(fileUrl)) {
          const file = fs.readFileSync(path.resolve(fileUrl));
          res.type(fileInf.mimeType);
          return res.send(file);
        }
      }
      return res
        .status(404)
        .send({ statusCode: 404, message: 'FILE_NOT_FOUND' });
    } catch (e) {
      console.log(e);
      return res
        .status(404)
        .send({ statusCode: 404, message: 'FILE_NOT_FOUND' });
    }
  }

  async getFiles(request: GetFilesRequestDto, res: Response): Promise<any> {
    const ids = request.ids.split(',').filter((e) => Types.ObjectId.isValid(e));

    if (!isEmpty(ids)) {
      try {
        const fileInfo = await this.singleFileRepository.findWithCondition({
          _id: { $in: ids },
        });
        fileInfo?.forEach((file) => {
          file.fileUrl = `${this.url}/${file._id}`;
        });
        const dataRes = plainToInstance(GetFilesByIdsResponse, fileInfo, {
          excludeExtraneousValues: true,
        });

        return res.send({
          statusCode: ResponseCodeEnum.SUCCESS,
          data: dataRes,
        });
      } catch (error) {
        return res.send({
          statusCode: ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        });
      }
    }
    return res.send({
      statusCode: ResponseCodeEnum.NOT_FOUND,
      data: [],
    });
  }
}
