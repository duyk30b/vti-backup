import { ConfigService } from '@config/config.service';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { FileRepository } from '@repositories/file.repository';
import { SingleFileSchema } from 'src/models/files/single-file.schema';
import { FileController } from './file.controller';
import { FileService } from './file.service';
import { MultipleFileService } from './multiple-files.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'SingleFileModel', schema: SingleFileSchema },
    ]),
  ],
  providers: [
    {
      provide: 'SingleFileServiceInterface',
      useClass: FileService,
    },
    {
      provide: 'MultipleServiceInterface',
      useClass: MultipleFileService,
    },
    {
      provide: 'ConfigServiceInterface',
      useClass: ConfigService,
    },

    {
      provide: 'FileRepositoryInterface',
      useClass: FileRepository,
    },
  ],
  controllers: [FileController],
  exports: [MongooseModule],
})
export class FileModule {}
