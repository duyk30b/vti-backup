import { isEmpty } from 'lodash';
import {
  Body,
  Controller,
  Get,
  Inject,
  Param,
  Post,
  Query,
  Res,
  UseInterceptors,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { Response } from 'express';
import { ValidateFileInterceptor } from 'src/interceptors/validate-file.interceptor';
import { MultipleFileUploadRequestDto } from './dto/request/upload-multiple-file.request.dto';
import { SingleFileRequestDto } from './dto/request/upload-singer-file.request.dto';
import { MultipleFileResponseDto } from './dto/response/upload-multiple-file.response.dto';
import { SingleFileResponseDto } from './dto/response/upload-single-file.response.dto';
import { FileServiceInterface } from './interfaces/file.service.interface';
import { GetFilesRequestDto } from './dto/request/get-files.request.dto';

@Controller()
export class FileController {
  constructor(
    @Inject('SingleFileServiceInterface')
    private readonly fileService: FileServiceInterface,

    @Inject('MultipleServiceInterface')
    private readonly multipleFileService: FileServiceInterface,
  ) {}

  @UseInterceptors(ValidateFileInterceptor)
  @Post('/single-file')
  @ApiOperation({
    tags: ['File'],
    summary: 'Upload File',
    description: 'Upload single file',
  })
  @ApiResponse({
    status: 200,
    description: 'Upload successfully',
    type: SingleFileResponseDto,
  })
  async uploadSingle(@Body() payload: SingleFileRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (!isEmpty(responseError)) {
      return responseError;
    }
    return await this.fileService.upload(request);
  }

  @UseInterceptors(ValidateFileInterceptor)
  @Post('/multiple-files')
  @ApiOperation({
    tags: ['File'],
    summary: 'Upload multiple file',
    description: 'Upload multiple file',
  })
  @ApiResponse({
    status: 200,
    description: 'Upload successfully',
    type: MultipleFileResponseDto,
  })
  async uploadMultiple(
    @Body() payload: MultipleFileUploadRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (!isEmpty(responseError)) {
      return responseError;
    }
    return await this.multipleFileService.upload(request);
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['File'],
    summary: 'Get file',
    description: 'Get file',
  })
  @ApiResponse({
    status: 200,
  })
  async getFile(@Param('id') id: string, @Res() res: Response): Promise<any> {
    return await this.fileService.getFile(id, res);
  }

  @Get('/info')
  @ApiOperation({
    tags: ['File'],
    summary: 'Get files',
    description: 'Get files',
  })
  @ApiResponse({
    status: 200,
  })
  async getFiles(
    @Query() payload: GetFilesRequestDto,
    @Res() res: Response,
  ): Promise<any> {
    const { request, responseError } = payload;

    console.log(payload);
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.fileService.getFiles(request, res);
  }
}
