import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { SingleFileModel } from 'src/models/files/single-file.model';

export interface FileRepositoryInterface
  extends BaseAbstractRepository<SingleFileModel> {
  createEntity(
    params: any,
    isReturnUrl: boolean,
    fileUrl: string,
  ): SingleFileModel;
}
