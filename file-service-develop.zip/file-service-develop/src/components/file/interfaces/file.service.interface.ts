import { Response } from 'express';
import { GetFilesRequestDto } from '../dto/request/get-files.request.dto';
import { MultipleFileUploadRequestDto } from '../dto/request/upload-multiple-file.request.dto';
import { SingleFileRequestDto } from '../dto/request/upload-singer-file.request.dto';
export interface FileServiceInterface {
  upload(
    params: SingleFileRequestDto | MultipleFileUploadRequestDto,
  ): Promise<any>;
  getFile(id: string, res: Response): Promise<any>;
  getFiles(ids: GetFilesRequestDto, res: Response): Promise<any>;
}
