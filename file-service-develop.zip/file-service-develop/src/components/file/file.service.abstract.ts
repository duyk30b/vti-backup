import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Storage } from '@squareboat/nest-storage';
import { getToday } from '@utils/common';
import { File } from '@utils/file-upload.util';
import { renderFileName } from '@utils/helper';
import { ResponseBuilder } from '@utils/response-builder';

export class FileServiceAbstract {
  public async saveFile(
    file: File,
    service: string,
    resource: string,
  ): Promise<any> {
    try {
      const disk = process.env.STORAGE_DISK;
      const fileName = renderFileName(file);
      const fileUrl = await Storage.disk(disk).put(
        `${service}/${resource}/${getToday()}/${fileName}`,
        file.data,
      );
      Storage.disk(disk).url(fileUrl.path);
      return fileUrl;
    } catch (e) {
      console.log(e);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .build();
    }
  }
}
