import { ApiProperty } from '@nestjs/swagger';
import { File } from '@utils/file-upload.util';
import { IsNotEmpty } from 'class-validator';
import { UploadRequestDto } from './upload-file.request.dto';

export class SingleFileRequestDto extends UploadRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  file: File;
}
