import { ApiProperty } from '@nestjs/swagger';
import { File } from '@utils/file-upload.util';
import { Type } from 'class-transformer';
import { ArrayNotEmpty, ValidateNested } from 'class-validator';
import { FileType, UploadRequestDto } from './upload-file.request.dto';

export class MultipleFileUploadRequestDto extends UploadRequestDto {
  @ApiProperty()
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => FileType)
  files: File[];
}
