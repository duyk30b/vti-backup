import { IsNoSqlId } from 'src/validator/is-nosql-id.validator';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class GetFileRequestDto extends BaseDto {
  @ApiProperty()
  @IsNoSqlId()
  @IsNotEmpty()
  id: string;
}
