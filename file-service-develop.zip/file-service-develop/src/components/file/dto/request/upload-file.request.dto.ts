import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { File } from '@utils/file-upload.util';
import { Transform } from 'class-transformer';

import {
  IsNotEmpty,
  IsNumber,
  IsNumberString,
  IsOptional,
  IsString,
} from 'class-validator';

export class FileType implements File {
  data: ArrayBuffer;
  fieldname: string;
  originalname: string;
  encoding: string;
  mimetype: string;
  size?: number;
  destination?: string;
  filename?: string;
  path?: string;
  buffer?: Buffer;
  stream?: NodeJS.ReadableStream;
}

export class UploadRequestDto extends BaseDto {
  @ApiProperty()
  @IsString()
  @IsOptional()
  allowMimetype: string;

  @ApiProperty()
  @IsOptional()
  @IsNumberString()
  allowFileSize: number;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  service: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  resource: string;
}
