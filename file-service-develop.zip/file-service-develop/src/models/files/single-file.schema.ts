import { Schema } from 'mongoose';

export const SingleFileSchema = new Schema(
  {
    service: {
      type: String,
    },
    fileUrl: {
      type: String,
    },
    fileNameRaw: {
      type: String,
    },
    mimeType: {
      type: String,
    },
    resource: {
      type: String,
    },
    createdBy: {
      type: Number,
    },
    isReturnUrl: {
      type: Boolean,
      default: false,
    },
    deletedAt: {
      type: Date,
      required: false,
      default: null,
    },
  },
  {
    timestamps: true,
    collection: 'files',
  },
);
