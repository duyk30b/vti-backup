import { BaseModel } from '@core/model/base.model';
export interface SingleFileModel extends BaseModel {
  mimeType: string;
  service: string;
  resource: string;
  fileUrl: string;
  fileNameRaw: string;
  createdBy: number;
  deletedAt: Date;
  isReturnUrl: boolean;
}
