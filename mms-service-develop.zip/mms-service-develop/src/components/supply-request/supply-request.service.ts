import { UpdateSupplyRequest } from './dto/request/update-supply-request.request';
import { JobRepositoryInterface } from '@components/job/interface/job.repository.interface';
import { SupplyRepositoryInterface } from '@components/supply/interface/supply.repository.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ListSupplyRequestQuery } from './dto/request/list-supply-request.query';
import { ListSupplyRequestResponse } from './dto/response/list-supply-request.response';
import { SupplyRequestRepositoryInterface } from './interface/supply-request.repository.interface';
import { SupplyRequestServiceInterface } from './interface/supply-request.service.interface';
import {
  JOB_CAN_REQUEST_SUPPLY,
  SUPPLY_REQUEST_CONST,
  SUPPLY_REQUEST_STATUS_ENUM,
  SUPPLY_REQUEST_TYPE_ENUM,
} from './supply-request.constant';
import { DetailSupplyRequestResponse } from './dto/response/detail-supply-request.response';
import { map, keyBy, flatMap, uniq, compact, isEmpty } from 'lodash';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateStatusSupplyRequest } from './dto/request/update-status-supply-request.request';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { CreateSupplyRequestBody } from './dto/request/create-supply-request.request';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';
import { InventoryRepositoryInterface } from '@components/warehouse/interface/inventory.repository.interface';
import { minus, plus } from '@utils/common';
import { GetInventoryByWarehousesAndAssetsRequestDto } from '@components/warehouse/dto/request/get-inventories-by-warehouses-assets.request.dto';
import { returnStockQuantity } from 'src/helper/code.helper';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ACTIVE_ENUM } from '@constant/common';
import { Job } from 'src/models/job/job.model';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';

@Injectable()
export class SupplyRequestService implements SupplyRequestServiceInterface {
  constructor(
    @Inject('SupplyRequestRepositoryInterface')
    private readonly supplyRequestRepository: SupplyRequestRepositoryInterface,

    @Inject('SupplyRepositoryInterface')
    private readonly supplyRepository: SupplyRepositoryInterface,

    @Inject('JobRepositoryInterface')
    private readonly jobRepository: JobRepositoryInterface,

    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,

    @Inject('InventoryRepositoryInterface')
    private readonly inventoryRepository: InventoryRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(
    payload: CreateSupplyRequestBody,
  ): Promise<ResponsePayload<any>> {
    const { type } = payload;

    const checkValidateData = await this.validateWithPermission(payload, type);
    if (checkValidateData.statusCode !== ResponseCodeEnum.SUCCESS) {
      return checkValidateData;
    }
    const { request } = checkValidateData.data;
    const prefixCode =
      request.type === SUPPLY_REQUEST_TYPE_ENUM.PROVIDE
        ? SUPPLY_REQUEST_CONST.CODE_SUPPLY_REQUEST.PREFIX
        : SUPPLY_REQUEST_CONST.CODE_SUPPLY_RETURN.PREFIX;
    request.code = await this.supplyRequestRepository.generateNextCodeWithYear(
      prefixCode,
    );
    const document = await this.supplyRequestRepository.createDocument(request);
    const dataSave = await document.save();
    const dataReturn = plainToInstance(BasicResponseDto, dataSave, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async list(request: ListSupplyRequestQuery): Promise<ResponsePayload<any>> {
    const { data, count } = await this.supplyRequestRepository.list(request);
    const factoryIds = uniq(compact(map(data, 'factoryId')));
    const factories = await this.userService.getFactoryList([
      { column: 'factoryIds', text: factoryIds },
    ]);
    const factoryMap = keyBy(factories, 'id');
    data.forEach((item) => {
      item.factory = factoryMap[item.factoryId];
    });
    const dataReturn = plainToInstance(ListSupplyRequestResponse, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PaginationResponse>({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async delete(request: IdParamDto): Promise<ResponsePayload<any>> {
    const { id } = request;
    try {
      const document = await this.supplyRequestRepository.findOneWithPopulate(
        { ...request.permissionCondition, _id: id },
        [{ path: 'warehouse' }, { path: 'request', populate: 'warehouse' }],
      );
      if (!document) {
        return new ApiError(
          ResponseCodeEnum.NOT_ACCEPTABLE,
          await this.i18n.translate('error.NOT_ACCEPTABLE'),
        ).toResponse();
      }

      if (document.status === SUPPLY_REQUEST_STATUS_ENUM.CONFIRM) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.CAN_NOT_DELETE'),
        ).toResponse();
      }
      await this.supplyRequestRepository.softDelete(request.id);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }
  }

  async detail(request: IdParamDto): Promise<ResponsePayload<any>> {
    const supplyRequest: any =
      await this.supplyRequestRepository.findOneWithPopulate(
        { ...request.permissionCondition, _id: request.id },
        [
          {
            path: 'supplies.supply',
            populate: 'supplyGroup vendor supplyType',
          },
          { path: 'jobs', populate: 'device' },
          { path: 'request', populate: 'warehouse' },
          { path: 'warehouse' },
        ],
      );

    if (isEmpty(supplyRequest)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.SUPPLY_REQUEST_NOT_FOUND'),
      ).toResponse();
    }
    const unitIds = map(supplyRequest.supplies, (e) => e.supply.unitId);
    const units = await this.itemService.getListUnit([
      {
        column: 'ids',
        text: uniq(unitIds).toString(),
      },
    ]);
    const unitMap = keyBy(units, 'id');
    if (supplyRequest.type === SUPPLY_REQUEST_TYPE_ENUM.RETURN) {
      const supplyProvidedMap = keyBy(
        supplyRequest?.request?.supplies,
        'supplyId',
      );
      supplyRequest.supplies.forEach((supply) => {
        supply.providedQuantity =
          supplyProvidedMap[supply.supplyId]?.quantity || 0;
      });
    }

    if (supplyRequest.type === SUPPLY_REQUEST_TYPE_ENUM.PROVIDE) {
      await this.getInventorySupplyByRequests(supplyRequest);
    }
    supplyRequest.supplies = supplyRequest.supplies.map((e) => ({
      ...e,
      ...e.supply,
      unit: unitMap[e.supply?.unitId],
    }));
    if (supplyRequest.requestedBy) {
      const user = await this.userService.getDetailUser(
        supplyRequest.requestedBy,
      );
      supplyRequest.requestedBy = user;
    }

    const dataReturn = plainToInstance(
      DetailSupplyRequestResponse,
      supplyRequest,
      { excludeExtraneousValues: true },
    );
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateStatus(
    request: UpdateStatusSupplyRequest,
  ): Promise<ResponsePayload<any>> {
    const supplyRequest =
      await this.supplyRequestRepository.findOneWithPopulate(
        { ...request.permissionCondition, _id: request.id },
        [{ path: 'warehouse' }, { path: 'request', populate: 'warehouse' }],
      );
    if (!supplyRequest) {
      return new ApiError(
        ResponseCodeEnum.NOT_ACCEPTABLE,
        await this.i18n.translate('error.NOT_ACCEPTABLE'),
      ).toResponse();
    }

    if (supplyRequest.status !== SUPPLY_REQUEST_STATUS_ENUM.WAITING) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_UPDATE_STATUS'),
      ).toResponse();
    }
    if (
      supplyRequest.type === SUPPLY_REQUEST_TYPE_ENUM.RETURN &&
      request.status === SUPPLY_REQUEST_STATUS_ENUM.CONFIRM
    ) {
      // check y/c cấp đã được trả chưa
      if (
        supplyRequest?.['request']?.status !==
        SUPPLY_REQUEST_STATUS_ENUM.COMPLETED
      ) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.SUPPLY_PROVIDE_REQUEST_INVALID'),
        ).toResponse();
      } else {
        await this.supplyRequestRepository.updateById(supplyRequest.requestId, {
          $set: { status: SUPPLY_REQUEST_STATUS_ENUM.AWAIT_RETURN },
        });
      }
    }
    await this.supplyRequestRepository.updateById(request.id, {
      $set: { status: request.status },
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async update(payload: UpdateSupplyRequest): Promise<any> {
    const { id } = payload;

    const supplyRequest =
      await this.supplyRequestRepository.findOneWithPopulate(
        { ...payload.permissionCondition, _id: id },
        [{ path: 'warehouse' }, { path: 'request', populate: 'warehouse' }],
      );
    if (!supplyRequest) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.SUPPLY_REQUEST_NOT_FOUND'),
        )
        .build();
    }

    if (supplyRequest.status !== SUPPLY_REQUEST_STATUS_ENUM.WAITING) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.STATUS_INVALID'))
        .build();
    }

    const checkValidateData = await this.validateWithPermission(
      payload,
      supplyRequest.type,
    );
    if (checkValidateData.statusCode !== ResponseCodeEnum.SUCCESS) {
      return checkValidateData;
    }
    const { request } = checkValidateData.data;
    const document = await this.supplyRequestRepository.updateDocument(
      supplyRequest,
      request,
    );

    await this.supplyRequestRepository.findByIdAndUpdate(id, document);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async validateWithPermission(
    request: any,
    type: number,
  ): Promise<ResponsePayload<{ request?: CreateSupplyRequestBody }>> {
    const conditionJob: any = {};

    const { supplies, jobIds, requestId, warehouseId } = request;
    const supplyIds = map(supplies, 'supplyId');

    if (type === SUPPLY_REQUEST_TYPE_ENUM.PROVIDE) {
      let jobs: Job[];
      if (!isEmpty(jobIds)) {
        jobs = await this.jobRepository.findAllWithPopulate(
          {
            _id: { $in: jobIds },
            ...conditionJob,
            status: { $in: JOB_CAN_REQUEST_SUPPLY },
          },
          'device',
        );
        if (jobs?.length < jobIds?.length) {
          return new ApiError(
            ResponseCodeEnum.NOT_FOUND,
            await this.i18n.translate('error.JOB_NOT_FOUND'),
          ).toResponse();
        }
      }
      // validate supplies exists
      const supplyExists = await this.supplyRepository.findAllByCondition({
        _id: { $in: supplyIds },
      });

      if (supplyExists.length < supplyIds.length) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.SUPPLY_NOT_FOUND'))
          .build();
      }
      const warehouse = await this.warehouseRepository.findOneByCondition({
        ...request.permissionCondition,
        _id: warehouseId,
        active: ACTIVE_ENUM.ACTIVE,
      });
      if (!warehouse) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'),
        ).toResponse();
      }
      request.factoryId = warehouse.factoryId;
    }
    // with supply provide request update supplyInserts
    else {
      const supplyRequest =
        await this.supplyRequestRepository.findOneByCondition({
          ...request.permissionCondition,
          _id: requestId,
        });
      if (!supplyRequest) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.SUPPLY_REQUEST_PROVIDE_NOT_FOUND'),
          )
          .build();
      }
      const supplyRequestMap = keyBy(supplyRequest.supplies, 'supplyId');
      const quantityInvalid = supplies.find(
        (e) => e.quantity > (supplyRequestMap[e.supplyId]?.quantity ?? 0),
      );
      if (quantityInvalid) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.QUANTITY_RETURN_INVALID'),
          )
          .build();
      }
      request.factoryId = supplyRequest?.factoryId;
    }
    return new ResponseBuilder({ request })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  // lấy tồn kho của vtpt theo kho của yêu cầu cấp
  async getInventorySupplyByRequests(supplyRequest) {
    const supplyIds = map(supplyRequest.supplies, 'supplyId');
    const supplyInventories =
      await this.inventoryRepository.getInventoryByWarehousesAndAssets({
        assetIds: supplyIds,
        warehouseIds: [
          supplyRequest.warehouse?._id ?? supplyRequest.request?.warehouseId,
        ],
      } as GetInventoryByWarehousesAndAssetsRequestDto);
    const supplyInventoryMap = keyBy(supplyInventories, '_id.assetId');

    // lấy số lượng vtpt đã kế hoạch
    const supplyRequestPlanned =
      await this.supplyRequestRepository.findAllByCondition({
        'supplies.supplyId': { $in: supplyIds },
        type: SUPPLY_REQUEST_TYPE_ENUM.PROVIDE,
        warehouseId:
          supplyRequest.warehouse?._id ?? supplyRequest.request?.warehouseId,
        status: SUPPLY_REQUEST_STATUS_ENUM.CONFIRM,
      });
    const supplyPlannedInventoryMap = {};
    flatMap(supplyRequestPlanned, 'supplies').forEach((supply) => {
      const key = supply.supplyId?.toString();
      supplyPlannedInventoryMap[key] = plus(
        supplyPlannedInventoryMap[key] || 0,
        supply.quantity,
      );
    });

    const supplyInventory = {};
    supplyIds.forEach((supplyId) => {
      const stockQuantity = returnStockQuantity(
        supplyInventoryMap[supplyId]?.stockQuantity || 0,
      );
      const minStockQuantity =
        supplyInventoryMap[supplyId]?.minStockQuantity || 0;
      const availableStockQuantity = returnStockQuantity(
        minus(
          minus(stockQuantity || 0, supplyPlannedInventoryMap[supplyId] || 0),
          minStockQuantity || 0,
        ),
      );
      supplyInventory[supplyId] = {
        stockQuantity,
        minStockQuantity,
        availableStockQuantity,
      };
    });
    supplyRequest.supplies = supplyRequest?.supplies.map((supply) => {
      return {
        supply,
        ...supply,
        ...supplyInventory[supply.supplyId],
      };
    });
    return supplyRequest;
  }
}
