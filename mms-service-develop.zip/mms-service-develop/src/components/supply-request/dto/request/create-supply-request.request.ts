import {
  SUPPLY_REQUEST_CONST,
  SUPPLY_REQUEST_TYPE_ENUM,
} from '@components/supply-request/supply-request.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsDateString,
  IsEnum,
  IsMongoId,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  Min,
  ValidateIf,
  ValidateNested,
} from 'class-validator';
import { IsNotBlank } from 'src/validator/is-not-blank.validator';

class SupplyRequestDetail {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  supplyId: string;

  @ApiProperty()
  @Min(1)
  @IsNumber()
  @IsNotEmpty()
  quantity: number;
}
export class CreateSupplyRequestBody extends BaseDto {
  code: string;

  factoryId: number;

  @ApiProperty()
  @IsString()
  @MaxLength(SUPPLY_REQUEST_CONST.NAME.MAX_LENGTH)
  @IsNotEmpty()
  @IsNotBlank()
  name: string;

  @ValidateIf((data) => data.type === SUPPLY_REQUEST_TYPE_ENUM.RETURN)
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  requestId: string;

  @ValidateIf((data) => data.type === SUPPLY_REQUEST_TYPE_ENUM.PROVIDE)
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  warehouseId: string;

  @ApiProperty()
  @IsEnum(SUPPLY_REQUEST_TYPE_ENUM)
  @IsNotEmpty()
  type: number;

  @ValidateIf((data) => data.type === SUPPLY_REQUEST_TYPE_ENUM.PROVIDE)
  @ApiProperty()
  @IsOptional()
  @ArrayUnique()
  @IsArray()
  jobIds: string[];

  @ApiProperty()
  @IsString()
  @MaxLength(SUPPLY_REQUEST_CONST.DESCRIPTION.MAX_LENGTH)
  @IsOptional()
  description: string;

  @ApiProperty()
  @IsDateString()
  @IsOptional()
  expectDate: Date;

  @ApiProperty({ type: SupplyRequestDetail, isArray: true })
  @ArrayUnique((e: SupplyRequestDetail) => e.supplyId)
  @Type(() => SupplyRequestDetail)
  @ValidateNested({ each: true })
  @ArrayNotEmpty()
  supplies: SupplyRequestDetail[];
}
