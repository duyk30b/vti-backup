import { GET_ALL_ENUM } from '@constant/common';
import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { Transform } from 'class-transformer';
import { IsEnum, IsOptional, IsString } from 'class-validator';

export class ListSupplyRequestQuery extends PaginationQuery {
  @ApiProperty()
  @IsEnum(GET_ALL_ENUM)
  @Transform((data) => parseInt(data.value))
  @IsOptional()
  isGetAll: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  queryIds: string;
}
