import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateSupplyRequestBody } from './create-supply-request.request';
export class UpdateSupplyRequestBodyDto extends CreateSupplyRequestBody {}
export class UpdateSupplyRequest extends UpdateSupplyRequestBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
