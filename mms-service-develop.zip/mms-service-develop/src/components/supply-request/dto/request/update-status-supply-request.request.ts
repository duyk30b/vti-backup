import { SUPPLY_REQUEST_STATUS_ENUM } from '@components/supply-request/supply-request.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateSupplyRequestBody } from './create-supply-request.request';
export class UpdateSupplyRequestBodyDto extends CreateSupplyRequestBody {}
export class UpdateStatusSupplyRequest extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;

  @ApiProperty()
  @IsEnum(SUPPLY_REQUEST_STATUS_ENUM)
  @IsNotEmpty()
  status: number;
}
