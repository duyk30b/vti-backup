import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';

export class RequestDetailDto extends BasicResponseDto {
  @ApiProperty({ type: BasicResponseDto })
  @Expose({ name: 'warehouse' })
  @Type(() => BasicResponseDto)
  exportWarehouse: BasicResponseDto;
}

export class JobResponse extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  device: BasicResponseDto;
}

export class ListSupplyRequestResponse extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  warehouse: BasicResponseDto;

  @ApiProperty({ type: JobResponse, isArray: true })
  @Expose()
  @Type(() => JobResponse)
  jobs: JobResponse[];

  @ApiProperty({ type: RequestDetailDto })
  @Expose()
  @Type(() => RequestDetailDto)
  request: RequestDetailDto;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Expose()
  @Type(() => BasicSqlDocumentResponse)
  factory: BasicSqlDocumentResponse;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  createdAt: Date;
}

export class ListSupplyRequestResponseDto extends PaginationResponse {
  @ApiProperty({ type: ListSupplyRequestResponse, isArray: true })
  @Expose()
  items: ListSupplyRequestResponse[];
}
