import { DeviceBasicResponseDto } from '@components/device/dto/response/device-basic.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { BasicUserResponseDto } from '@utils/dto/response/basic-user.response.dto';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class DetailSupplyRequest extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  nameOther: string;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  unit: BasicSqlDocumentResponse;
  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  vendor: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  supplyGroup: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  supplyType: BasicResponseDto;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  stockQuantity: number;

  @ApiProperty()
  @Expose()
  minStockQuantity: number;

  @ApiProperty()
  @Expose()
  availableStockQuantity: number;

  @ApiProperty()
  @Expose()
  providedQuantity: number;

  @ApiProperty()
  @Expose()
  usedQuantity: number;
}

class DetailRequestTicket extends BasicResponseDto {
  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  warehouse: BasicResponseDto;
}
class JobDetail extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty({ type: DeviceBasicResponseDto })
  @Expose()
  @Type(() => DeviceBasicResponseDto)
  device: DeviceBasicResponseDto;
}
export class DetailSupplyRequestResponse extends BasicResponseDto {
  @ApiProperty({ type: JobDetail, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => JobDetail)
  jobs: JobDetail[];

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  warehouse: BasicResponseDto;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  expectDate: Date;

  @ApiProperty({ type: DetailRequestTicket })
  @Expose()
  @Type(() => DetailRequestTicket)
  request: DetailRequestTicket;

  @ApiProperty({ type: DetailSupplyRequest, isArray: true })
  @Expose()
  @Type(() => DetailSupplyRequest)
  @IsArray()
  supplies: DetailSupplyRequest[];

  @ApiProperty({ type: BasicUserResponseDto })
  @Type(() => BasicUserResponseDto)
  @Expose()
  requestedBy: BasicUserResponseDto;
}
