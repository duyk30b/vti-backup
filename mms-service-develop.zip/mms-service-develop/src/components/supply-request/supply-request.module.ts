import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { SupplyRequestSchema } from 'src/models/supply-request/supply-request.schema';
import { JobRepository } from 'src/repository/job/job.repository';
import { SupplyRequestRepository } from 'src/repository/supply-request/supply-request.repository';
import { MaintenanceTeamRepository } from 'src/repository/maintenance-team/maintenance-team.repository';
import { SupplyRepository } from 'src/repository/supply/supply.repository';
import { SupplyRequestController } from './supply-request.controller';
import { SupplyRequestService } from './supply-request.service';
import { DeviceRequestRepository } from 'src/repository/device-request/device-request-ticket.repository';
import { DeviceRepository } from 'src/repository/device/device.repository';
import { DeviceGroupRepository } from 'src/repository/device-group/device-group.repository';
import { DeviceGroupSchema } from 'src/models/device-group/device-group.schema';
import { SupplyGroupSchema } from 'src/models/supply-group/supply-group.schema';
import { SupplyGroupRepository } from 'src/repository/supply-group/supply-group.repository';
import { SupplySchema } from 'src/models/supply/supply.schema';
import { JobSchema } from 'src/models/job/job.schema';
import { MaintenanceTeamSchema } from 'src/models/maintenance-team/maintenance-team.schema';
import { DeviceRequestSchema } from 'src/models/device-request/device-request-ticket.schema';
import { DeviceSchema } from 'src/models/device/device.schema';
import { WarehouseSchema } from 'src/models/warehouse/warehouse.schema';
import { WarehouseRepository } from 'src/repository/warehouse/warehouse.repository';
import { InventoryRepository } from 'src/repository/warehouse-inventories/inventory.repository';
import { InventorySchema } from 'src/models/warehouse-inventories/inventory.schema';
import { ItemModule } from '@components/item/item.module';
@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'DeviceRequest', schema: DeviceRequestSchema },
      { name: 'MaintenanceTeam', schema: MaintenanceTeamSchema },
      { name: 'SupplyRequest', schema: SupplyRequestSchema },
      { name: 'DeviceGroup', schema: DeviceGroupSchema },
      { name: 'SupplyGroup', schema: SupplyGroupSchema },
      { name: 'Supply', schema: SupplySchema },
      { name: 'Job', schema: JobSchema },
      { name: 'Device', schema: DeviceSchema },
      { name: 'Warehouse', schema: WarehouseSchema },
      { name: 'Inventory', schema: InventorySchema },
    ]),
    ItemModule,
  ],
  controllers: [SupplyRequestController],
  providers: [
    {
      provide: 'SupplyRequestRepositoryInterface',
      useClass: SupplyRequestRepository,
    },
    {
      provide: 'SupplyRequestServiceInterface',
      useClass: SupplyRequestService,
    },
    {
      provide: 'SupplyRepositoryInterface',
      useClass: SupplyRepository,
    },
    {
      provide: 'DeviceGroupRepositoryInterface',
      useClass: DeviceGroupRepository,
    },
    {
      provide: 'SupplyGroupRepositoryInterface',
      useClass: SupplyGroupRepository,
    },
    {
      provide: 'JobRepositoryInterface',
      useClass: JobRepository,
    },
    {
      provide: 'MaintenanceTeamRepositoryInterface',
      useClass: MaintenanceTeamRepository,
    },
    {
      provide: 'DeviceRequestRepositoryInterface',
      useClass: DeviceRequestRepository,
    },
    {
      provide: 'DeviceRepositoryInterface',
      useClass: DeviceRepository,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    {
      provide: 'InventoryRepositoryInterface',
      useClass: InventoryRepository,
    },
  ],
  exports: [
    MongooseModule,
    {
      provide: 'SupplyRequestServiceInterface',
      useClass: SupplyRequestService,
    },
  ],
})
export class SupplyRequestModule {}
