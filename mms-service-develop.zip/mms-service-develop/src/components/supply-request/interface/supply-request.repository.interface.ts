import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { SupplyRequest } from 'src/models/supply-request/supply-request.model';
import { ListSupplyRequestQuery } from '../dto/request/list-supply-request.query';
import { UpdateSupplyRequestBodyDto } from '../dto/request/update-supply-request.request';
import { CreateSupplyRequestBody } from '../dto/request/create-supply-request.request';

export interface SupplyRequestRepositoryInterface
  extends BaseInterfaceRepository<SupplyRequest> {
  createDocument(request: CreateSupplyRequestBody): Promise<SupplyRequest>;
  updateDocument(
    document: SupplyRequest,
    request: UpdateSupplyRequestBodyDto,
  ): Promise<SupplyRequest>;
  list(request: ListSupplyRequestQuery): Promise<any>;
}
