import { ResponsePayload } from '@utils/response-payload';
import { ListSupplyRequestQuery } from '../dto/request/list-supply-request.query';
import { UpdateSupplyRequestBodyDto } from '../dto/request/update-supply-request.request';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateStatusSupplyRequest } from '../dto/request/update-status-supply-request.request';
import { CreateSupplyRequestBody } from '../dto/request/create-supply-request.request';
import { SupplyRequest } from 'src/models/supply-request/supply-request.model';

export interface SupplyRequestServiceInterface {
  create(request: CreateSupplyRequestBody): Promise<ResponsePayload<any>>;
  update(request: UpdateSupplyRequestBodyDto): Promise<ResponsePayload<any>>;
  updateStatus(
    request: UpdateStatusSupplyRequest,
  ): Promise<ResponsePayload<any>>;
  list(request: ListSupplyRequestQuery): Promise<ResponsePayload<any>>;
  delete(request: IdParamDto): Promise<ResponsePayload<any>>;
  detail(request: IdParamDto): Promise<ResponsePayload<any>>;
  getInventorySupplyByRequests(
    supplyRequest: SupplyRequest,
  ): Promise<ResponsePayload<any>>;
}
