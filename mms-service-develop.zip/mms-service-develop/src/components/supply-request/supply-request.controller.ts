import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
  UseInterceptors,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { ListSupplyRequestQuery } from './dto/request/list-supply-request.query';
import { UpdateSupplyRequestBodyDto } from './dto/request/update-supply-request.request';
import { DetailSupplyRequestResponse } from './dto/response/detail-supply-request.response';
import { SupplyRequestServiceInterface } from './interface/supply-request.service.interface';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { SUPPLY_REQUEST_STATUS_ENUM } from './supply-request.constant';
import { CreateSupplyRequestBody } from './dto/request/create-supply-request.request';
import { ListSupplyRequestResponseDto } from './dto/response/list-supply-request.response';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CONFIRM_SUPPLY_REQUEST_TICKET_PERMISSION,
  CREATE_SUPPLY_REQUEST_TICKET_PERMISSION,
  DELETE_SUPPLY_REQUEST_TICKET_PERMISSION,
  DETAIL_SUPPLY_REQUEST_TICKET_PERMISSION,
  LIST_SUPPLY_REQUEST_PERMISSION,
  UPDATE_SUPPLY_REQUEST_TICKET_PERMISSION,
} from '@utils/permissions/supply-request';
import { PermissionInterceptor } from '@core/interceptors/permission.interceptor';
import {
  CREATE_WAREHOUSE_IMPORT_REQUEST_PERMISSION,
  UPDATE_WAREHOUSE_IMPORT_REQUEST_PERMISSION,
} from '@utils/permissions/warehouse-import-request';
import {
  CREATE_WAREHOUSE_EXPORT_REQUEST_PERMISSION,
  UPDATE_WAREHOUSE_EXPORT_REQUEST_PERMISSION,
} from '@utils/permissions/warehouse-export-request';

@Controller('supply-request')
export class SupplyRequestController {
  constructor(
    @Inject('SupplyRequestServiceInterface')
    private readonly supplyRequestService: SupplyRequestServiceInterface,
  ) {}

  @PermissionCode(
    CREATE_SUPPLY_REQUEST_TICKET_PERMISSION.code,
    UPDATE_SUPPLY_REQUEST_TICKET_PERMISSION.code,
    LIST_SUPPLY_REQUEST_PERMISSION.code,
    DETAIL_SUPPLY_REQUEST_TICKET_PERMISSION.code,
  )
  @UseInterceptors(PermissionInterceptor)
  @Post('/')
  @ApiOperation({
    tags: ['Supply Request'],
    summary: 'Tạo yêu cầu vật tư phụ tùng',
    description: 'Tạo yêu cầu vật tư phụ tùng',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async createRequestProvide(
    @Body() payload: CreateSupplyRequestBody,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.supplyRequestService.create(request);
  }

  @PermissionCode(
    LIST_SUPPLY_REQUEST_PERMISSION.code,
    CREATE_WAREHOUSE_IMPORT_REQUEST_PERMISSION.code,
    UPDATE_WAREHOUSE_IMPORT_REQUEST_PERMISSION.code,
    CREATE_WAREHOUSE_EXPORT_REQUEST_PERMISSION.code,
    UPDATE_WAREHOUSE_EXPORT_REQUEST_PERMISSION.code,
  )
  @UseInterceptors(PermissionInterceptor)
  @Get('/')
  @ApiOperation({
    tags: ['Supply Request'],
    summary: 'Danh sách yêu cầu vật tư phụ tùng',
    description: 'Danh sách yêu cầu vật tư phụ tùng',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListSupplyRequestResponseDto,
  })
  async list(@Query() payload: ListSupplyRequestQuery): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.supplyRequestService.list(request);
  }

  @PermissionCode(
    DETAIL_SUPPLY_REQUEST_TICKET_PERMISSION.code,
    CREATE_SUPPLY_REQUEST_TICKET_PERMISSION.code,
    UPDATE_SUPPLY_REQUEST_TICKET_PERMISSION.code,
    CREATE_WAREHOUSE_IMPORT_REQUEST_PERMISSION.code,
    UPDATE_WAREHOUSE_IMPORT_REQUEST_PERMISSION.code,
    UPDATE_WAREHOUSE_EXPORT_REQUEST_PERMISSION.code,
    CREATE_WAREHOUSE_EXPORT_REQUEST_PERMISSION.code,
    CREATE_SUPPLY_REQUEST_TICKET_PERMISSION.code,
    UPDATE_SUPPLY_REQUEST_TICKET_PERMISSION.code,
  )
  @UseInterceptors(PermissionInterceptor)
  @Get('/:id')
  @ApiOperation({
    tags: ['Supply Request'],
    summary: 'Chi tiết yêu cầu vật tư phụ tùng',
    description: 'Chi tiết yêu cầu vật tư phụ tùng',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailSupplyRequestResponse,
  })
  async detail(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.supplyRequestService.detail(request);
  }

  @PermissionCode(
    UPDATE_SUPPLY_REQUEST_TICKET_PERMISSION.code,
    LIST_SUPPLY_REQUEST_PERMISSION.code,
  )
  @UseInterceptors(PermissionInterceptor)
  @Put('/:id')
  @ApiOperation({
    tags: ['Supply Request'],
    summary: 'Cập nhật yêu cầu vtpt',
    description: 'Cập nhật yêu cầu vtpt',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async update(
    @Param() param: IdParamDto,
    @Body() payload: UpdateSupplyRequestBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    const {
      request: { id },
      responseError: responseParamError,
    } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }

    return await this.supplyRequestService.update({ ...request, id });
  }

  @PermissionCode(DELETE_SUPPLY_REQUEST_TICKET_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Supply Request'],
    summary: 'Xóa yêu cầu vật tư phụ tùng',
    description: 'Xóa yêu cầu vật tư phụ tùng',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async delete(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.supplyRequestService.delete(request);
  }

  @PermissionCode(CONFIRM_SUPPLY_REQUEST_TICKET_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Supply Request'],
    summary: 'Xác nhận yêu cầu vật tư phụ tùng',
    description: 'Xác nhận yêu cầu vật tư phụ tùng',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async confirm(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.supplyRequestService.updateStatus({
      ...request,
      status: SUPPLY_REQUEST_STATUS_ENUM.CONFIRM,
    });
  }

  @PermissionCode(CONFIRM_SUPPLY_REQUEST_TICKET_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Supply Request'],
    summary: 'Từ Chối yêu cầu vật tư phụ tùng',
    description: 'Từ Chối yêu cầu vật tư phụ tùng',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async reject(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.supplyRequestService.updateStatus({
      ...request,
      status: SUPPLY_REQUEST_STATUS_ENUM.REJECT,
    });
  }
}
