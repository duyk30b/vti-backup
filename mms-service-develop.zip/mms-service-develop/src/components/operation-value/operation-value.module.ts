import { UserModule } from '@components/user/user.module';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import {
  OperationIndex,
  OperationIndexSchema,
} from 'src/models/operation-index/operation-index.schema';
import {
  OperationValue,
  OperationValueSchema,
} from 'src/models/operation-value/operation-value.schema';
import { OperationIndexRepository } from 'src/repository/operation-index/operation-index.repository';
import { OperationValueRepository } from 'src/repository/operation-value/operation-value.repository';
import { OperationValueController } from './operation-value.controller';
import { OperationValueService } from './operation-value.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: OperationValue.name, schema: OperationValueSchema },
      { name: OperationIndex.name, schema: OperationIndexSchema },
    ]),
    UserModule,
  ],
  controllers: [OperationValueController],
  providers: [
    {
      provide: 'OperationValueRepositoryInterface',
      useClass: OperationValueRepository,
    },
    {
      provide: 'OperationIndexRepositoryInterface',
      useClass: OperationIndexRepository,
    },
    {
      provide: 'OperationValueServiceInterface',
      useClass: OperationValueService,
    },
  ],
  exports: [
    MongooseModule,
    {
      provide: 'OperationValueRepositoryInterface',
      useClass: OperationValueRepository,
    },
    {
      provide: 'OperationValueServiceInterface',
      useClass: OperationValueService,
    },
  ],
})
export class OperationValueModule {}
