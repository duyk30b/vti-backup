import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { OperationValue } from 'src/models/operation-value/operation-value.schema';
import { CreateOperationValueRequest } from '../dto/request/create-operation-value.request';
import { GetDetailOperationValueByFactoryRequest } from '../dto/request/detail-operation-value-by-factory.request';
import { GetDetailOperationValueRequest } from '../dto/request/detail-operation-value.request';
import { GetListOperationValueQuery } from '../dto/request/get-list-operation-value.query';
import { UpdateOperationValueBodyDto } from '../dto/request/update-operation-value.request';

export interface OperationValueRepositoryInterface
  extends BaseAbstractRepository<OperationValue> {
  createEntity(request: CreateOperationValueRequest): OperationValue;
  updateEntity(
    entity: OperationValue,
    request: UpdateOperationValueBodyDto,
  ): OperationValue;
  detail(
    request: GetDetailOperationValueRequest &
      GetDetailOperationValueByFactoryRequest,
  ): Promise<any>;
  list(
    request: GetListOperationValueQuery,
  ): Promise<{ result: any[]; count: number }>;
  export(request: GetListOperationValueQuery): Promise<any[]>;
}
