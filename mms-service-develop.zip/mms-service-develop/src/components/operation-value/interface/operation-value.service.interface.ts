import { CreateOperationValueRequest } from '@components/operation-value/dto/request/create-operation-value.request';
import { GetListOperationValueQuery } from '@components/operation-value/dto/request/get-list-operation-value.query';
import { UpdateOperationValueRequest } from '@components/operation-value/dto/request/update-operation-value.request';
import { ResponsePayload } from '@utils/response-payload';
import { GetDetailOperationValueByFactoryRequest } from '../dto/request/detail-operation-value-by-factory.request';
import { GetDetailOperationValueRequest } from '../dto/request/detail-operation-value.request';

export interface OperationValueServiceInterface {
  create(request: CreateOperationValueRequest): Promise<ResponsePayload<any>>;
  update(request: UpdateOperationValueRequest): Promise<ResponsePayload<any>>;
  detail(
    request: GetDetailOperationValueRequest &
      GetDetailOperationValueByFactoryRequest,
  ): Promise<ResponsePayload<any>>;
  list(request: GetListOperationValueQuery): Promise<ResponsePayload<any>>;
}
