import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { GetListOperationValueQuery } from './dto/request/get-list-operation-value.query';
import { CreateOperationValueRequest } from './dto/request/create-operation-value.request';
import { UpdateOperationValueRequest } from './dto/request/update-operation-value.request';
import { DetailOperationValueResponse } from './dto/response/detail-operation-value.response';
import { OperationValueRepositoryInterface } from './interface/operation-value.repository.interface';
import { OperationValueServiceInterface } from './interface/operation-value.service.interface';
import { difference, isEmpty, keyBy, map } from 'lodash';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { REPORT_TYPE_ENUM } from '@constant/common';
import * as moment from 'moment';
import { OperationIndexRepositoryInterface } from '@components/operation-index/interface/operation-index.repository.interface';
import { ListOperationValueResponse } from './dto/response/list-operation-value.response';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { GetDetailOperationValueRequest } from './dto/request/detail-operation-value.request';
import { GetDetailOperationValueByFactoryRequest } from './dto/request/detail-operation-value-by-factory.request';

@Injectable()
export class OperationValueService implements OperationValueServiceInterface {
  constructor(
    @Inject('OperationValueRepositoryInterface')
    private readonly operationValueRepository: OperationValueRepositoryInterface,

    @Inject('OperationIndexRepositoryInterface')
    private readonly operationIndexRepository: OperationIndexRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(
    request: CreateOperationValueRequest,
  ): Promise<ResponsePayload<any>> {
    try {
      const validate = await this.validateBeforeSave(request);
      if (validate.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validate;
      }
      const document = this.operationValueRepository.createEntity(request);
      const operationValue = await document.save();
      const dataReturn = plainToInstance(BasicResponseDto, operationValue, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async update(
    request: UpdateOperationValueRequest,
  ): Promise<ResponsePayload<any>> {
    try {
      const { id } = request;
      let operationValue =
        await this.operationValueRepository.findOneByCondition({ _id: id });

      if (!operationValue) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }
      const validate = await this.validateBeforeSave(request, request.id);
      if (validate.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validate;
      }

      operationValue = this.operationValueRepository.updateEntity(
        operationValue,
        request,
      );
      operationValue = await this.operationValueRepository.findByIdAndUpdate(
        id,
        operationValue,
      );
      const dataReturn = plainToInstance(BasicResponseDto, operationValue, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async validateBeforeSave(request: CreateOperationValueRequest, id = null) {
    const { date, factoryId, operationIndexes } = request;

    const operationIndexExists =
      await this.operationIndexRepository.findAllByCondition({
        deletedAt: null,
        factoryIds: factoryId,
      });
    const keyPairExists = operationIndexExists.flatMap((index) =>
      index.parameters.map((parameter) => index._id + parameter._id),
    );
    const keyPairInserts = operationIndexes.flatMap((index) =>
      index.parameters.map(
        (parameter) => index.operationIndexId + parameter.parameterId,
      ),
    );
    const isDiff = !isEmpty(difference(keyPairInserts, keyPairExists));
    if (isDiff) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!id) {
      const dataExist = await this.operationValueRepository.findOneByCondition({
        date: {
          $gte: moment(date).startOf('day').toDate(),
          $lte: moment(date).endOf('day').toDate(),
        },
        factoryId,
      });
      if (dataExist) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.DATE_CREATED_OPERATION_VALUE'),
        ).toResponse();
      }
    }

    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async detail(
    request: GetDetailOperationValueRequest &
      GetDetailOperationValueByFactoryRequest,
  ): Promise<ResponsePayload<any>> {
    const { factoryId, startDate, endDate } = request;
    const isDateValid = moment(startDate).isSameOrBefore(moment(endDate));
    if (!isDateValid) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.INVALID_RANGE_DATE'),
      ).toResponse();
    }

    const result = await this.operationValueRepository.detail(request);
    if (!result) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const factory = await this.userService.getFactoryById(factoryId);

    const dataReturn = plainToInstance(
      DetailOperationValueResponse,
      {
        factory: factory,
        startDate: moment(startDate).toDate(),
        endDate: moment(endDate).toDate(),
        operationIndexes: result.map((e) => {
          const parameterMap = keyBy(e.parameters, 'parameterId');
          e.operationIndex?.parameters?.forEach(
            (parameter) =>
              (parameter.value =
                parameterMap[parameter['_id'].toString()]?.value),
          );
          return e.operationIndex;
        }),
      },
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async list(
    request: GetListOperationValueQuery,
  ): Promise<ResponsePayload<any>> {
    const { timeUnit, keyword } = request;
    let searchFactory = [];
    if (keyword) {
      searchFactory = await this.userService.getFactoryList(undefined, keyword);
      if (isEmpty(searchFactory)) {
        return new ResponseBuilder({
          items: [],
          meta: { total: 0, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
      }
    }

    const { result, count } = await this.operationValueRepository.list(request);
    const factoryIds = map(result, 'factoryId');
    const factories = await this.userService.getFactoryList([
      {
        column: 'factoryIds',
        text: factoryIds,
      },
    ]);
    const factoryMap = keyBy(factories, 'id');

    let startDate, endDate: Date;
    if (timeUnit !== REPORT_TYPE_ENUM.DAY) {
      const date = request.filter?.find((item) => item.column === 'date');
      startDate = moment(date?.text.split('|')[0]).toDate();
      endDate = moment(date?.text.split('|')[1]).toDate();
    }

    result.forEach((e) => {
      e.factory = factoryMap[e.factoryId];
      e.startDate = startDate ?? moment(e.date).toDate();
      e.endDate = endDate ?? moment(e.date).toDate();
    });
    const dataReturn = plainToInstance(ListOperationValueResponse, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
