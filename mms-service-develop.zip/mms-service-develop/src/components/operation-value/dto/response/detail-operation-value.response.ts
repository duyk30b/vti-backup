import { ACTIVE_ENUM } from '@constant/common';
import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { Expose, Type } from 'class-transformer';

export class ParameterResponse extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  value: string;
}

export class OperationIndexResponse extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  unit: string;

  @ApiProperty()
  @Expose()
  active: ACTIVE_ENUM;

  @ApiProperty({ type: ParameterResponse, isArray: true })
  @Type(() => ParameterResponse)
  @Expose()
  parameters: ParameterResponse;
}
export class DetailOperationValueResponse extends BasicResponseDto {
  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  factory: BasicSqlDocumentResponse;

  @ApiProperty({ type: OperationIndexResponse, isArray: true })
  @Type(() => OperationIndexResponse)
  @Expose()
  operationIndexes: OperationIndexResponse;
}
