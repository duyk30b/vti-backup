import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';

export class ListOperationValueResponse extends BasicResponseDto {
  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  factory: BasicSqlDocumentResponse;

  @ApiProperty()
  @Expose()
  startDate: Date;

  @ApiProperty()
  @Expose()
  endDate: Date;
}
export class GetListOperationValueResponse extends PaginationResponse {
  @ApiProperty({ type: ListOperationValueResponse, isArray: true })
  @Type(() => ListOperationValueResponse)
  @Expose()
  items: ListOperationValueResponse;
}
