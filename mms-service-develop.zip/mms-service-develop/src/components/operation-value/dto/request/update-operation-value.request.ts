import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsMongoId } from 'class-validator';
import { CreateOperationValueRequest } from './create-operation-value.request';

export class UpdateOperationValueBodyDto extends CreateOperationValueRequest {}
export class UpdateOperationValueRequest extends UpdateOperationValueBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
