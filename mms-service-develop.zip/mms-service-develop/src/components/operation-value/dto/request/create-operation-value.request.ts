import { OPERATION_VALUE_CONST } from '@components/operation-value/operation-value.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsDateString,
  IsInt,
  IsMongoId,
  IsNotEmpty,
  Max,
  Min,
  ValidateNested,
} from 'class-validator';

class Parameter extends BaseDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  parameterId: string;

  @ApiProperty()
  @IsInt()
  @Min(OPERATION_VALUE_CONST.VALUE.MIN)
  @Max(OPERATION_VALUE_CONST.VALUE.MAX)
  @IsNotEmpty()
  value: number;
}

class OperationIndex extends BaseDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  operationIndexId: string;

  @ApiProperty({ type: Parameter, isArray: true })
  @Type(() => Parameter)
  @ArrayUnique((data) => data.parameterId)
  @ValidateNested({ each: true })
  @ArrayNotEmpty()
  parameters: Parameter[];
}

export class CreateOperationValueRequest extends BaseDto {
  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  date: string;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  factoryId: number;

  @ApiProperty({ type: OperationIndex, isArray: true })
  @ArrayNotEmpty()
  @Type(() => OperationIndex)
  @ValidateNested({ each: true })
  @ArrayUnique((data) => data.operationIndexId)
  operationIndexes: OperationIndex[];
}
