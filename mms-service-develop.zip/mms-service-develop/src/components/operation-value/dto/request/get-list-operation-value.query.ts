import { REPORT_TYPE_ENUM } from '@constant/common';
import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { Transform } from 'class-transformer';
import { IsEnum, IsNotEmpty } from 'class-validator';

export class GetListOperationValueQuery extends PaginationQuery {
  @ApiProperty()
  @IsEnum(REPORT_TYPE_ENUM)
  @Transform(({ value }) => +value)
  @IsNotEmpty()
  timeUnit: number;
}
