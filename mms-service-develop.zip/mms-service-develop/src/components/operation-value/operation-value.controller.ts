import { PermissionCode } from '@core/decorator/get-code.decorator';
import { PermissionInterceptor } from '@core/interceptors/permission.interceptor';
import {
  Body,
  Controller,
  Get,
  Inject,
  Injectable,
  Param,
  Post,
  Put,
  Query,
  UseInterceptors,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { mergePayload } from '@utils/common';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import {
  DETAIL_OPERATION_VALUE_PERMISSION,
  CREATE_OPERATION_VALUE_PERMISSION,
  UPDATE_OPERATION_VALUE_PERMISSION,
  LIST_OPERATION_VALUE_PERMISSION,
} from '@utils/permissions/operation-value';
import { isEmpty } from 'lodash';
import { CreateOperationValueRequest } from './dto/request/create-operation-value.request';
import { GetDetailOperationValueByFactoryRequest } from './dto/request/detail-operation-value-by-factory.request';
import { GetDetailOperationValueRequest } from './dto/request/detail-operation-value.request';
import { GetListOperationValueQuery } from './dto/request/get-list-operation-value.query';
import { UpdateOperationValueBodyDto } from './dto/request/update-operation-value.request';
import { DetailOperationValueResponse } from './dto/response/detail-operation-value.response';
import { GetListOperationValueResponse } from './dto/response/list-operation-value.response';
import { OperationValueServiceInterface } from './interface/operation-value.service.interface';

@Injectable()
@Controller('/operation-value')
export class OperationValueController {
  constructor(
    @Inject('OperationValueServiceInterface')
    private readonly OperationValueService: OperationValueServiceInterface,
  ) {}

  @PermissionCode(CREATE_OPERATION_VALUE_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Post('/')
  @ApiOperation({
    tags: ['Operation Value'],
    summary: 'Định nghĩa giá trị vận hành',
    description: 'Định nghĩa giá trị vận hành',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: BasicResponseDto,
  })
  async create(@Body() payload: CreateOperationValueRequest): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.OperationValueService.create(request);
  }

  @PermissionCode(UPDATE_OPERATION_VALUE_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Put('/:id')
  @ApiOperation({
    tags: ['Operation Value'],
    summary: 'Cập nhật giá trị vận hành',
    description: 'Cập nhật giá trị vận hành',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: BasicResponseDto,
  })
  async update(
    @Param() param: IdParamDto,
    @Body() payload: UpdateOperationValueBodyDto,
  ): Promise<any> {
    const { request, responseError } = mergePayload(payload, param);
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.OperationValueService.update(request);
  }

  @PermissionCode(
    DETAIL_OPERATION_VALUE_PERMISSION.code,
    UPDATE_OPERATION_VALUE_PERMISSION.code,
  )
  @UseInterceptors(PermissionInterceptor)
  @Get('/:factoryId')
  @ApiOperation({
    tags: ['Operation Value'],
    summary: 'Chi tiết giá trị vận hành',
    description: 'Chi tiết giá trị vận hành',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailOperationValueResponse,
  })
  async detail(
    @Param() param: GetDetailOperationValueByFactoryRequest,
    @Query() query: GetDetailOperationValueRequest,
  ): Promise<any> {
    const { request, responseError } = mergePayload(query, param);
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.OperationValueService.detail(request);
  }

  @PermissionCode(LIST_OPERATION_VALUE_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get('/')
  @ApiOperation({
    tags: ['Operation Value'],
    summary: 'Danh sách giá trị vận hành',
    description: 'Danh sách giá trị vận hành',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetListOperationValueResponse,
  })
  async list(@Query() query: GetListOperationValueQuery): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.OperationValueService.list(request);
  }
}
