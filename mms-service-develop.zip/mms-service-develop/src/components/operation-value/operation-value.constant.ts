export const OPERATION_VALUE_CONST = {
  VALUE: {
    MAX: 9999999999,
    MIN: 0,
  },
};
