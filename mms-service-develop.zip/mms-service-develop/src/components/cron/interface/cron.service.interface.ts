export interface CronServiceInterface {
  cronJobPeriodChecklist();
  cronJobPeriodChecklistWarning();
  cronJobMaintain();
  cronJobMaintainWarning();
  cronWarningJobAccreditation();
  cronOverdueJob();
  cronShowJob();
  cronAutoCompleteJob();
}
