import { Controller, Get, Inject, Injectable } from '@nestjs/common';
import { CronServiceInterface } from './interface/cron.service.interface';

@Injectable()
@Controller('cron')
export class CronController {
  constructor(
    @Inject('CronServiceInterface')
    private readonly cronService: CronServiceInterface,
  ) {}

  @Get('/job-checklist')
  async cronJobPeriodChecklist(): Promise<any> {
    return await this.cronService.cronJobPeriodChecklist();
  }

  @Get('/warning-checklist')
  async cronJobPeriodChecklistWarning(): Promise<any> {
    return await this.cronService.cronJobPeriodChecklistWarning();
  }

  @Get('/job-maintain')
  async cronJobMaintain(): Promise<any> {
    return await this.cronService.cronJobMaintain();
  }

  @Get('/warning-maintain')
  async cronJobMaintainWarning(): Promise<any> {
    return await this.cronService.cronJobMaintainWarning();
  }

  @Get('/warning-accreditation')
  async cronWarningJobAccreditation(): Promise<any> {
    return await this.cronService.cronWarningJobAccreditation();
  }

  @Get('/job-to-overdue')
  async cronChangeJobToOverdue(): Promise<any> {
    return await this.cronService.cronOverdueJob();
  }

  @Get('/show-job')
  async cronShowJob(): Promise<any> {
    return await this.cronService.cronShowJob();
  }

  @Get('/auto-complete-job')
  async cronAutoCompleteJob(): Promise<any> {
    return await this.cronService.cronAutoCompleteJob();
  }
}
