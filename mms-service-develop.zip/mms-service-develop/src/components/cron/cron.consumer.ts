import { I18nService } from 'nestjs-i18n';
import { Process, Processor } from '@nestjs/bull';
import { Job } from 'bull';
import {
  CREATE_WARNING_QUEUE_PROCESSOR,
  NUMBER_RECORD,
  CREATE_JOB_MAINTAIN_DEVICE_PROCESS,
  CREATE_JOB_PERIOD_CHECKLIST_PROCESS,
  CREATE_WARNING_MAINTAIN_DEVICE_PROCESS,
  CREATE_WARNING_PERIOD_CHECKLIST_PROCESS,
  CREATE_WARNING_ACCREDITATION_PROCESS,
  SHOW_JOB_PROCESS,
  DEFINE_DAY,
  OVERDUE_JOB_PROCESS,
  AUTO_COMPLETE_JOB,
  EXECUTE_TIME_DEFAULT,
  STOP_TIME_DEFAULT,
} from './cron.constants';
import { DeviceRepositoryInterface } from '@components/device/interface/device.repository.interface';
import { Inject } from '@nestjs/common';
import * as moment from 'moment';
import {
  JOB_CONST,
  JOB_EVENTS_ENUM,
  JOB_STATUS_ENUM,
  JOB_TYPE_ENUM,
  RESULT_ENUM,
} from '@components/job/job.constant';
import { OBLIGATORY_ENUM, SUNDAY_DAY } from '@constant/common';
import { has, keyBy, map, uniq } from 'lodash';
import { JobRepositoryInterface } from '@components/job/interface/job.repository.interface';
import { Types } from 'mongoose';
import {
  WARNING_EVENTS_ENUM,
  WARNING_STATUS_ENUM,
} from '@components/warning/warning.constant';
import { WarningRepositoryInterface } from '@components/warning/interface/warning.repository.interface';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { EventRequestDto } from '@components/notification/dto/event.request.dto';
import { FORMAT_DATE_NUMBER } from '@utils/constant';
import { HISTORY_ACTION_ENUM } from '@components/history/history.constant';
import { CheckListTemplateRepositoryInterface } from '@components/checklist-template/interface/checklist-template.repository.interface';
import { DeviceTemplateScheduleRepositoryInterface } from '@components/device/interface/device-template-schedule.repository.interface';
import { DeviceTemplateSchedule } from 'src/models/device-template-schedule/device-template-schedule.model';
import { SettingJobRepositoryInterface } from '@components/setting/interface/setting-job.repository.interface';
import { AUTO_GENERATE_JOB_ON_SUNDAY } from '@components/setting/setting.constant';
import { SettingJob } from 'src/models/setting-job/setting-job.model';

@Processor(CREATE_WARNING_QUEUE_PROCESSOR)
export class WarningConsumer {
  constructor(
    @Inject('DeviceRepositoryInterface')
    private deviceRepository: DeviceRepositoryInterface,

    @Inject('DeviceTemplateScheduleRepositoryInterface')
    private deviceTemplateScheduleRepository: DeviceTemplateScheduleRepositoryInterface,

    @Inject('JobRepositoryInterface')
    private jobRepository: JobRepositoryInterface,

    @Inject('WarningRepositoryInterface')
    private warningRepository: WarningRepositoryInterface,

    @Inject('ChecklistTemplateRepositoryInterface')
    private checklistTemplateRepository: CheckListTemplateRepositoryInterface,

    @Inject('SettingJobRepositoryInterface')
    private settingJobRepository: SettingJobRepositoryInterface,

    private readonly eventEmitter: EventEmitter2,

    private readonly i18n: I18nService,
  ) {}

  private skipJobSunday(jobConfiguration: SettingJob, schedule: any) {
    const autoGenerateOnSunday =
      jobConfiguration?.autoGenerateOnSunday ?? AUTO_GENERATE_JOB_ON_SUNDAY.YES;
    //  update nextSchedule schedule
    if (moment(schedule?.nextSchedule).isBefore(moment(), 'day')) {
      schedule.nextSchedule = moment().startOf('day').toDate();
    }
    if (
      autoGenerateOnSunday === AUTO_GENERATE_JOB_ON_SUNDAY.NO &&
      moment(schedule.nextSchedule).day() === SUNDAY_DAY
    ) {
      return true;
    }
    return false;
  }

  getConditionForCronJob(date: number) {
    return {
      // get with timezone_local
      $or: [
        {
          $or: [
            { periodic: { $lt: date } },
            { periodic: { $eq: DEFINE_DAY.ONE_DAY } },
          ],
          nextSchedule: {
            $lte: parseInt(moment().format(FORMAT_DATE_NUMBER)),
          },
        },
        {
          periodic: {
            $ne: DEFINE_DAY.ONE_DAY,
            $gte: date,
            $lt: DEFINE_DAY.NINETY_DAY,
          },
          nextSchedule: {
            $lte: parseInt(
              moment().add(date, 'day').format(FORMAT_DATE_NUMBER),
            ),
          },
        },
      ],
    };
  }

  @Process(CREATE_JOB_PERIOD_CHECKLIST_PROCESS)
  async createJobPeriodChecklist(job: Job): Promise<any> {
    const { date } = job.data;

    const { result: schedules } =
      await this.deviceTemplateScheduleRepository.getDeviceByChecklistDuration(
        this.getConditionForCronJob(date),
        NUMBER_RECORD,
      );

    const checkListJobName = await this.i18n.translate('text.checkListJobName');
    const messageCreatedJob = await this.i18n.translate(
      'text.SYSTEM_CREATE_PERIOD_CHECKLIST_JOB',
    );

    const dataInserts = [];
    const deviceIds = uniq(map(schedules, 'deviceId'));
    const deviceTemplateSchedules =
      await this.deviceTemplateScheduleRepository.findAllByCondition({
        deviceId: { $in: deviceIds },
      });
    const checklistMap = {};
    const jobConfiguration = await this.settingJobRepository.findOneByCondition(
      { type: JOB_TYPE_ENUM.PERIOD_CHECKLIST },
    );
    schedules.forEach((schedule) => {
      const checklist = schedule.periodChecklist;
      if (this.skipJobSunday(jobConfiguration, checklist)) {
        return;
      }

      checklist.lastSchedule = checklist.nextSchedule;
      checklist.nextSchedule = moment(checklist.nextSchedule)
        .startOf('day')
        .add(checklist.periodic, 'day')
        .toDate();
      checklistMap[checklist._id] = checklist;
      // add job
      dataInserts.push({
        name: checkListJobName
          .replace('{deviceName}', schedule.device?.name ?? '')
          .substr(0, JOB_CONST.NAME.MAX_LENGTH),
        description: checklist.title,
        status: JOB_STATUS_ENUM.NON_ASSIGN,
        planFrom: checklist.lastSchedule,
        planTo: checklist.nextSchedule,
        jobTypeId: checklist.templateId,
        obligatory: checklist.obligatory,
        type: JOB_TYPE_ENUM.PERIOD_CHECKLIST,
        histories: [
          {
            createdAt: new Date(),
            action: HISTORY_ACTION_ENUM.CREATE,
            content: messageCreatedJob,
            status: JOB_STATUS_ENUM.NON_ASSIGN,
          },
        ],
        deviceId: schedule.deviceId,
      });
    });
    const jobDocuments = await this.jobRepository.createEntities(dataInserts);

    const jobs = await this.jobRepository.createMany(jobDocuments);
    jobs.forEach((job) => {
      this.eventEmitter.emit(
        JOB_EVENTS_ENUM.CREATE,
        new EventRequestDto({
          id: job._id,
          name: job.name,
          code: job.code,
          entityType: job.type,
          fromUserId: null,
        }),
      );
    });
    const data = deviceTemplateSchedules.map((templateSchedule) => {
      templateSchedule.periodChecklist.forEach((e, index) => {
        if (has(checklistMap, e._id)) {
          templateSchedule.periodChecklist.splice(
            index,
            1,
            checklistMap[e._id],
          );
        }
      });
      return {
        updateOne: {
          filter: {
            _id: templateSchedule._id,
          },
          update: {
            $set: { periodChecklist: templateSchedule.periodChecklist },
          },
          upsert: false,
        },
      };
    });
    await this.deviceTemplateScheduleRepository.bulkWrite(data);
    return;
  }

  @Process(CREATE_WARNING_PERIOD_CHECKLIST_PROCESS)
  async createWarningPeriodChecklist(job: Job): Promise<any> {
    const { date } = job.data;
    const { result: schedules } =
      await this.deviceTemplateScheduleRepository.getDeviceByChecklistDuration(
        {
          periodic: {
            $gte: DEFINE_DAY.NINETY_DAY,
          },
          nextSchedule: {
            $lte: parseInt(
              moment()
                .add(date || DEFINE_DAY.THREE_DAY, 'day')
                .format(FORMAT_DATE_NUMBER),
            ),
          },
        },
        NUMBER_RECORD,
      );

    const checkListWarningName = await this.i18n.translate(
      'text.checkListWarningName',
    );

    const dataInserts = [];
    const deviceIds = uniq(map(schedules, 'deviceId'));
    const deviceTemplateSchedules =
      await this.deviceTemplateScheduleRepository.findAllByCondition({
        deviceId: { $in: deviceIds },
      });
    const checklistMap = {};
    const jobConfiguration = await this.settingJobRepository.findOneByCondition(
      { type: JOB_TYPE_ENUM.PERIOD_CHECKLIST },
    );
    schedules.forEach((schedule) => {
      const checklist = schedule.periodChecklist;
      //  update checklist schedule
      if (this.skipJobSunday(jobConfiguration, checklist)) {
        return;
      }
      checklist.lastSchedule = checklist.nextSchedule;
      checklist.nextSchedule = moment(checklist.nextSchedule)
        .startOf('day')
        .add(checklist.periodic, 'day')
        .toDate();
      checklistMap[checklist._id] = checklist;

      dataInserts.push({
        warningTypeId: checklist.templateId,
        name: checkListWarningName
          .replace('{deviceName}', schedule.device?.name ?? '')
          .substr(0, JOB_CONST.NAME.MAX_LENGTH),
        description: checklist.title,
        status: WARNING_STATUS_ENUM.WAITING,
        obligatory: checklist.obligatory,
        planDate: checklist.nextSchedule,
        type: JOB_TYPE_ENUM.PERIOD_CHECKLIST,
        deviceId: schedule.deviceId,
      });
    });

    const warningDocuments = await this.warningRepository.createEntities(
      dataInserts,
    );
    const warnings: any = await this.warningRepository.create(warningDocuments);

    warnings.forEach((e) => {
      this.eventEmitter.emit(
        WARNING_EVENTS_ENUM.CREATE,
        new EventRequestDto({
          id: e?._id,
          code: e?.code,
          name: e?.name,
        }),
      );
    });

    const data = deviceTemplateSchedules.map((templateSchedule) => {
      templateSchedule.periodChecklist.forEach((e, index) => {
        if (has(checklistMap, e._id)) {
          templateSchedule.periodChecklist.splice(
            index,
            1,
            checklistMap[e._id],
          );
        }
      });
      return {
        updateOne: {
          filter: {
            _id: templateSchedule._id,
          },
          update: {
            $set: { periodChecklist: templateSchedule.periodChecklist },
          },
          upsert: false,
        },
      };
    });
    await this.deviceTemplateScheduleRepository.bulkWrite(data);
    return;
  }

  @Process(SHOW_JOB_PROCESS)
  async cronShowJob(): Promise<any> {
    const jobs = await this.jobRepository.findAllByCondition(
      {
        isShow: false,
        planFrom: {
          $lte: moment().endOf('day').add(DEFINE_DAY.THREE_DAY, 'day').toDate(),
        },
      },
      NUMBER_RECORD,
    );

    await this.jobRepository.findAllAndUpdate(
      {
        _id: {
          $in: jobs.map((e) => new Types.ObjectId(e._id)),
        },
      },
      {
        isShow: true,
      },
    );
    return;
  }

  @Process(CREATE_JOB_MAINTAIN_DEVICE_PROCESS)
  async createJobMaintain(job: Job): Promise<any> {
    const { date } = job.data;
    const { result: schedules } =
      await this.deviceTemplateScheduleRepository.getDeviceByMaintainDuration(
        this.getConditionForCronJob(date),
        NUMBER_RECORD,
      );
    const dataInserts = [];
    const deviceIds = uniq(map(schedules, 'deviceId'));
    const templateSchedules =
      await this.deviceTemplateScheduleRepository.findAllByCondition({
        deviceId: { $in: deviceIds },
      });
    const maintainJobName = await this.i18n.translate('text.maintainJobName');
    const messageCreatedJob = await this.i18n.translate(
      'text.SYSTEM_CREATE_MAINTAIN_JOB',
    );
    const maintainMap = {};
    const jobConfiguration = await this.settingJobRepository.findOneByCondition(
      {
        type: JOB_TYPE_ENUM.MAINTAIN,
      },
    );
    schedules.forEach((schedule) => {
      const maintain = schedule.maintain;
      //  update maintain schedule
      if (this.skipJobSunday(jobConfiguration, maintain)) {
        return;
      }
      maintain.lastSchedule = maintain.nextSchedule;
      maintain.nextSchedule = moment(maintain.nextSchedule)
        .startOf('day')
        .add(maintain.periodic, 'day')
        .toDate();
      maintainMap[maintain._id] = maintain;
      // add job
      dataInserts.push({
        name: maintainJobName
          .replace('{deviceName}', schedule.device?.name ?? '')
          .substr(0, JOB_CONST.NAME.MAX_LENGTH),
        description: maintain.title,
        status: JOB_STATUS_ENUM.NON_ASSIGN,
        planFrom: maintain.lastSchedule,
        planTo: maintain.nextSchedule,
        jobTypeId: maintain.templateId,
        obligatory: maintain.obligatory,
        type: JOB_TYPE_ENUM.MAINTAIN,
        histories: [
          {
            createdAt: new Date(),
            action: HISTORY_ACTION_ENUM.CREATE,
            content: messageCreatedJob,
            status: JOB_STATUS_ENUM.NON_ASSIGN,
          },
        ],
        deviceId: schedule.deviceId,
      });
    });
    const jobDocuments = await this.jobRepository.createEntities(dataInserts);

    const jobs = await this.jobRepository.createMany(jobDocuments);
    jobs.forEach((job) => {
      this.eventEmitter.emit(
        JOB_EVENTS_ENUM.CREATE,
        new EventRequestDto({
          id: job._id,
          name: job.name,
          code: job.code,
          entityType: job.type,
          fromUserId: null,
        }),
      );
    });
    const data = templateSchedules.map((templateSchedule) => {
      templateSchedule.maintain.forEach((e, index) => {
        if (has(maintainMap, e._id)) {
          templateSchedule.maintain.splice(index, 1, maintainMap[e._id]);
        }
      });
      return {
        updateOne: {
          filter: {
            deviceId: templateSchedule.deviceId,
          },
          update: {
            $set: { maintain: templateSchedule.maintain },
          },
          upsert: false,
        },
      };
    });

    await this.deviceTemplateScheduleRepository.bulkWrite(data);
    return;
  }

  @Process(CREATE_WARNING_MAINTAIN_DEVICE_PROCESS)
  async createWarningMaintain(job: Job): Promise<any> {
    const { date } = job.data;

    const { result: schedules } =
      await this.deviceTemplateScheduleRepository.getDeviceByMaintainDuration(
        {
          periodic: {
            $gte: DEFINE_DAY.NINETY_DAY,
          },
          nextSchedule: {
            $lte: parseInt(
              moment().add(date, 'day').format(FORMAT_DATE_NUMBER),
            ),
          },
        },
        NUMBER_RECORD,
      );

    const dataInserts = [];
    const deviceIds = uniq(map(schedules, 'deviceId'));
    const templateSchedules =
      await this.deviceTemplateScheduleRepository.findAllByCondition({
        deviceId: { $in: deviceIds },
      });
    const maintainWarningName = await this.i18n.translate(
      'text.maintainWarningName',
    );
    const maintainMap = {};
    const jobConfiguration = await this.settingJobRepository.findOneByCondition(
      { type: JOB_TYPE_ENUM.MAINTAIN },
    );
    schedules.forEach((schedule) => {
      const maintain = schedule.maintain;
      //  update maintain schedule
      if (this.skipJobSunday(jobConfiguration, maintain)) {
        return;
      }
      maintain.lastSchedule = maintain.nextSchedule;
      maintain.nextSchedule = moment(maintain.nextSchedule)
        .startOf('day')
        .add(maintain.periodic, 'day')
        .toDate();
      maintainMap[maintain._id] = maintain;
      dataInserts.push({
        warningTypeId: maintain.templateId,
        name: maintainWarningName
          .replace('{deviceName}', schedule.device?.name ?? '')
          .substr(0, JOB_CONST.NAME.MAX_LENGTH),
        description: maintain.title,
        obligatory: maintain.obligatory,
        status: WARNING_STATUS_ENUM.WAITING,
        planDate: maintain.nextSchedule,
        type: JOB_TYPE_ENUM.MAINTAIN,
        deviceId: schedule.deviceId,
      });
    });
    const warningDocuments = await this.warningRepository.createEntities(
      dataInserts,
    );
    const warnings: any = await this.warningRepository.create(warningDocuments);

    warnings.forEach((e) => {
      this.eventEmitter.emit(
        WARNING_EVENTS_ENUM.CREATE,
        new EventRequestDto({
          id: e?._id,
          code: e?.code,
          name: e?.name,
        }),
      );
    });

    const data = templateSchedules.map((templateSchedule) => {
      templateSchedule.maintain.forEach((e, index) => {
        if (has(maintainMap, e._id)) {
          templateSchedule.maintain.splice(index, 1, maintainMap[e._id]);
        }
      });
      return {
        updateOne: {
          filter: {
            _id: templateSchedule._id,
          },
          update: {
            $set: { maintain: templateSchedule.maintain },
          },
          upsert: false,
        },
      };
    });

    await this.deviceTemplateScheduleRepository.bulkWrite(data);
    return;
  }

  @Process(CREATE_WARNING_ACCREDITATION_PROCESS)
  async createWarningAccreditation(job: Job): Promise<any> {
    const { date } = job.data;

    const schedules: DeviceTemplateSchedule[] =
      await this.deviceTemplateScheduleRepository.getDeviceByAccreditationDuration(
        {
          nextSchedule: {
            $lte: parseInt(
              moment()
                .add(date || DEFINE_DAY.SEVEN_DAY, 'day')
                .format(FORMAT_DATE_NUMBER),
            ),
          },
        },
        NUMBER_RECORD,
      );

    const dataInserts = [];

    const warningName = await this.i18n.translate(
      'text.SYSTEM_CREATE_WARNING_ACCREDITATION',
    );
    const jobConfiguration = await this.settingJobRepository.findOneByCondition(
      { type: JOB_TYPE_ENUM.ACCREDITATION },
    );
    schedules.forEach((schedule) => {
      const accreditationTemplate: any = schedule.accreditation;
      if (this.skipJobSunday(jobConfiguration, accreditationTemplate)) {
        return;
      }
      dataInserts.push({
        warningTypeId: accreditationTemplate?.templateId,
        name: warningName
          .replace('{deviceName}', schedule['device']?.name ?? '')
          .substr(0, JOB_CONST.NAME.MAX_LENGTH),
        description: warningName
          .replace('{deviceName}', schedule['device']?.name ?? '')
          .substr(0, JOB_CONST.NAME.MAX_LENGTH),
        type: JOB_TYPE_ENUM.ACCREDITATION,
        planDate: accreditationTemplate?.nextSchedule,
        deviceId: schedule.deviceId,
        status: WARNING_STATUS_ENUM.WAITING,
        obligatory: accreditationTemplate.obligatory,
        details: schedule['accreditationTemplate']?.details?.map((item) => ({
          title: item.title,
          description: item.description,
          obligatory: item.obligatory,
        })),
      });
      schedule.accreditation.lastSchedule = accreditationTemplate?.nextSchedule;
      schedule.accreditation.nextSchedule = moment(
        accreditationTemplate?.nextSchedule,
      )
        .add(accreditationTemplate.periodic, 'day')
        .toDate();
    });
    const warningDocuments = await this.warningRepository.createEntities(
      dataInserts,
    );
    const warnings: any = await this.warningRepository.create(warningDocuments);

    warnings.forEach((e) => {
      this.eventEmitter.emit(
        WARNING_EVENTS_ENUM.CREATE,
        new EventRequestDto({
          id: e?._id,
          code: e?.code,
          name: e?.name,
        }),
      );
    });
    const data = schedules.map((schedule) => {
      return {
        updateOne: {
          filter: {
            _id: schedule._id,
          },
          update: {
            $set: { accreditation: schedule.accreditation },
          },
          upsert: false,
        },
      };
    });
    await this.deviceTemplateScheduleRepository.bulkWrite(data);
    return;
  }

  @Process(OVERDUE_JOB_PROCESS)
  async cronOverdueJob(): Promise<any> {
    const { result: jobs } = await this.jobRepository.getJobToCron(
      {
        planTo: {
          $lt: parseInt(moment().format(FORMAT_DATE_NUMBER)),
        },
        status: {
          $nin: [JOB_STATUS_ENUM.COMPLETED, JOB_STATUS_ENUM.RESOLVED],
        },
        obligatory: OBLIGATORY_ENUM.YES,
        isOverdue: false,
      },
      NUMBER_RECORD,
    );

    const jobIds = map(jobs, '_id');
    await this.jobRepository.findAllAndUpdate(
      { _id: { $in: jobIds } },
      { isOverdue: true },
    );
  }

  @Process(AUTO_COMPLETE_JOB)
  async cronAutoCompleteJob(): Promise<any> {
    const { result: jobs } = await this.jobRepository.getJobToCron(
      {
        planTo: { $lt: parseInt(moment().format(FORMAT_DATE_NUMBER)) },
        status: {
          $nin: [JOB_STATUS_ENUM.RESOLVED],
        },
        obligatory: OBLIGATORY_ENUM.NO,
        type: {
          $in: [JOB_TYPE_ENUM.MAINTAIN, JOB_TYPE_ENUM.PERIOD_CHECKLIST],
        },
      },
      NUMBER_RECORD,
    );

    const bulkOps = [];
    const history: any = {
      action: HISTORY_ACTION_ENUM.UPDATE,
      content: await this.i18n.translate('text.JOB_AUTO_COMPLETE'),
      status: JOB_STATUS_ENUM.RESOLVED,
    };
    const checklistTemplateIds = map(
      jobs.filter((e) => e.type === JOB_TYPE_ENUM.PERIOD_CHECKLIST),
      'jobTypeId',
    );
    const checklistTemplates =
      await this.checklistTemplateRepository.findAllByCondition({
        _id: { $in: checklistTemplateIds },
      });
    const checklistTemplateMap = keyBy(checklistTemplates, '_id');
    const deviceIdUpdate = [];
    const resolveJobData = {
      executionDateFrom: new Date(),
      executionDateTo: new Date(),
      status: JOB_STATUS_ENUM.RESOLVED,
      stopTime: STOP_TIME_DEFAULT,
      executionTime: EXECUTE_TIME_DEFAULT,
    };
    jobs?.forEach((job) => {
      if (job.type === JOB_TYPE_ENUM.MAINTAIN) {
        deviceIdUpdate.push(job.deviceId);
        bulkOps.push({
          updateOne: {
            filter: {
              _id: job._id,
            },
            update: {
              $set: resolveJobData,
              $push: {
                histories: history,
              },
            },

            upsert: false,
          },
        });
      } else if (job.type === JOB_TYPE_ENUM.PERIOD_CHECKLIST) {
        // các mục của checklistTemplate mặc định là đạt
        const result = {
          result: RESULT_ENUM.PASS,
          details: checklistTemplateMap[job.jobTypeId]?.details?.map((el) => ({
            title: el.title,
            obligatory: el.obligatory,
            status: RESULT_ENUM.PASS,
          })),
        };
        bulkOps.push({
          updateOne: {
            filter: {
              _id: job._id,
            },
            update: {
              $set: {
                ...resolveJobData,
                result,
              },
              $push: {
                histories: history,
              },
            },
            upsert: false,
          },
        });
      }
    });
    await this.deviceRepository.findAllAndUpdate(
      {
        _id: { $in: deviceIdUpdate },
      },
      {
        lastMaintenanceDate: new Date(),
      },
    );
    await this.jobRepository.bulkWrite(bulkOps);
    return;
  }
}
