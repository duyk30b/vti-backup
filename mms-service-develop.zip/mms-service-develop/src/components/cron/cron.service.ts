import {
  CREATE_JOB_MAINTAIN_DEVICE_PROCESS,
  CREATE_JOB_PERIOD_CHECKLIST_PROCESS,
  CREATE_WARNING_MAINTAIN_DEVICE_PROCESS,
  CREATE_WARNING_PERIOD_CHECKLIST_PROCESS,
  CREATE_WARNING_ACCREDITATION_PROCESS,
  CREATE_WARNING_QUEUE_PROCESSOR,
  NUMBER_RECORD,
  SHOW_JOB_PROCESS,
  DEFINE_DAY,
  OVERDUE_JOB_PROCESS,
  AUTO_COMPLETE_JOB,
  TIMEOUT_QUEUE,
  CRON_JOB_ENUM,
} from '@components/cron/cron.constants';
import { Inject, Injectable } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import * as moment from 'moment';
import { Queue } from 'bull';
import { InjectQueue } from '@nestjs/bull';
import { JobRepositoryInterface } from '@components/job/interface/job.repository.interface';
import { CronServiceInterface } from './interface/cron.service.interface';
import { SettingJobRepositoryInterface } from '@components/setting/interface/setting-job.repository.interface';
import { JOB_STATUS_ENUM, JOB_TYPE_ENUM } from '@components/job/job.constant';
import { SETTING_JOB_PERIOD_ENUM } from '@components/setting/setting.constant';
import { OBLIGATORY_ENUM } from '@constant/common';
import { FORMAT_DATE_NUMBER, TIMEZONE_LOCAL } from '@utils/constant';
import { DeviceTemplateScheduleRepositoryInterface } from '@components/device/interface/device-template-schedule.repository.interface';
import { cronJobTimeByElement } from '@utils/common';
@Injectable()
export class CronService implements CronServiceInterface {
  constructor(
    @Inject('DeviceTemplateScheduleRepositoryInterface')
    private deviceTemplateScheduleRepository: DeviceTemplateScheduleRepositoryInterface,

    @Inject('JobRepositoryInterface')
    private jobRepository: JobRepositoryInterface,

    @Inject('SettingJobRepositoryInterface')
    private settingJobRepository: SettingJobRepositoryInterface,

    @InjectQueue(CREATE_WARNING_QUEUE_PROCESSOR)
    private createWarningQueue: Queue,
  ) {}

  private async getDateSetting(
    type: JOB_TYPE_ENUM,
    period: SETTING_JOB_PERIOD_ENUM,
  ) {
    const setting = await this.settingJobRepository.findOneByCondition({
      type,
    });

    const result = setting?.details?.find((e) => e.period === period);

    return result?.beforeDate;
  }

  getConditionForCronJob(date: number) {
    return {
      // get with timezone_local
      $or: [
        {
          $or: [
            { periodic: { $lt: date } },
            { periodic: { $eq: DEFINE_DAY.ONE_DAY } },
          ],
          nextSchedule: {
            $lte: parseInt(moment().format(FORMAT_DATE_NUMBER)),
          },
        },
        {
          periodic: {
            $ne: DEFINE_DAY.ONE_DAY,
            $gte: date,
            $lt: DEFINE_DAY.NINETY_DAY,
          },
          nextSchedule: {
            $lte: parseInt(
              moment().add(date, 'day').format(FORMAT_DATE_NUMBER),
            ),
          },
        },
      ],
    };
  }

  @Cron(cronJobTimeByElement(CRON_JOB_ENUM.CHECKLIST_JOB), {
    name: 'cron_job_period_checklist',
    timeZone: TIMEZONE_LOCAL,
  })
  async cronJobPeriodChecklist() {
    console.info(
      `cron job sinh công việc kiểm tra định kì... `,
      moment().format('DD-MM-YYYY'),
    );

    const date =
      (await this.getDateSetting(
        JOB_TYPE_ENUM.PERIOD_CHECKLIST,
        SETTING_JOB_PERIOD_ENUM.LESS_THAN_THREE_MONTH,
      )) || DEFINE_DAY.THREE_DAY;

    // Đếm thiết bị cần tạo công việc kiểm tra định kỳ hôm nay
    const { count } =
      await this.deviceTemplateScheduleRepository.getDeviceByChecklistDuration(
        this.getConditionForCronJob(date),
      );
    if (!count) {
      return;
    }
    let number = 1;
    if (count > NUMBER_RECORD) {
      number = Math.ceil(count / NUMBER_RECORD);
    }
    for (let page = 0; page < number; page++) {
      const queue = await this.createWarningQueue.add(
        CREATE_JOB_PERIOD_CHECKLIST_PROCESS,
        {
          date,
        },
        { timeout: TIMEOUT_QUEUE },
      );
      await queue.finished();
    }
  }

  @Cron(cronJobTimeByElement(CRON_JOB_ENUM.CHECKLIST_WARNING), {
    name: 'cron_job_period_checklist_warning',
    timeZone: TIMEZONE_LOCAL,
  })
  async cronJobPeriodChecklistWarning() {
    // @TODO skip maintenance-plan
    console.info(
      `cron job sinh cảnh báo kiểm tra định kì... `,
      moment().format('DD-MM-YYYY'),
    );

    const date =
      (await this.getDateSetting(
        JOB_TYPE_ENUM.PERIOD_CHECKLIST,
        SETTING_JOB_PERIOD_ENUM.MORE_THAN_THREE_MONTH,
      )) || DEFINE_DAY.THREE_DAY;

    // Đếm thiết bị cần tạo cảnh báo kiểm tra định kỳ hôm nay
    const { count } =
      await this.deviceTemplateScheduleRepository.getDeviceByChecklistDuration({
        periodic: {
          $gte: DEFINE_DAY.NINETY_DAY,
        },
        nextSchedule: {
          $lte: parseInt(moment().add(date, 'day').format(FORMAT_DATE_NUMBER)),
        },
      });
    if (!count) {
      return;
    }
    let number = 1;
    if (count > NUMBER_RECORD) {
      number = Math.ceil(count / NUMBER_RECORD);
    }
    for (let page = 0; page < number; page++) {
      const queue = await this.createWarningQueue.add(
        CREATE_WARNING_PERIOD_CHECKLIST_PROCESS,
        { date },
        { timeout: TIMEOUT_QUEUE },
      );
      await queue.finished();
    }
  }

  @Cron(cronJobTimeByElement(CRON_JOB_ENUM.SHOW_JOB), {
    name: 'cron_show_job',
    timeZone: TIMEZONE_LOCAL,
  })
  async cronShowJob() {
    // Đếm công việc trong kế hoạch để hiển thị
    const count = await this.jobRepository.count({
      isShow: false,
      planFrom: {
        $lte: moment().endOf('day').add(DEFINE_DAY.THREE_DAY, 'day').toDate(),
      },
    });

    if (!count) {
      return;
    }
    let number = 1;
    if (count > NUMBER_RECORD) {
      number = Math.ceil(count / NUMBER_RECORD);
    }
    for (let page = 0; page < number; page++) {
      const queue = await this.createWarningQueue.add(
        SHOW_JOB_PROCESS,
        {},
        { timeout: TIMEOUT_QUEUE },
      );
      await queue.finished();
    }
  }

  @Cron(cronJobTimeByElement(CRON_JOB_ENUM.MAINTAIN_JOB), {
    name: 'cron_job_maintain',
    timeZone: TIMEZONE_LOCAL,
  })
  async cronJobMaintain() {
    // @TODO skip maintenance-plan
    console.info(
      `cron job sinh công việc bảo dưỡng ngày... `,
      moment().format('DD-MM-YYYY'),
    );

    const date =
      (await this.getDateSetting(
        JOB_TYPE_ENUM.MAINTAIN,
        SETTING_JOB_PERIOD_ENUM.LESS_THAN_THREE_MONTH,
      )) || DEFINE_DAY.THREE_DAY;

    // Đếm thiết bị có duration nhỏ hơn 3 ngày hoặc nhỏ hơn 90 ngày để taọ công việc bảo trì
    const { count } =
      await this.deviceTemplateScheduleRepository.getDeviceByMaintainDuration(
        this.getConditionForCronJob(date),
      );
    if (!count) {
      return;
    }
    let number = 1;
    if (count > NUMBER_RECORD) {
      number = Math.ceil(count / NUMBER_RECORD);
    }
    for (let page = 0; page < number; page++) {
      const queue = await this.createWarningQueue.add(
        CREATE_JOB_MAINTAIN_DEVICE_PROCESS,
        {
          date,
        },
        { timeout: TIMEOUT_QUEUE },
      );
      await queue.finished();
    }
  }

  @Cron(cronJobTimeByElement(CRON_JOB_ENUM.MAINTAIN_WARNING), {
    name: 'cron_job_maintain_warning',
    timeZone: TIMEZONE_LOCAL,
  })
  async cronJobMaintainWarning() {
    console.info(
      `cron job sinh cảnh báo bảo dưỡng ngày... `,
      moment().format('DD-MM-YYYY'),
    );

    const date =
      (await this.getDateSetting(
        JOB_TYPE_ENUM.MAINTAIN,
        SETTING_JOB_PERIOD_ENUM.MORE_THAN_THREE_MONTH,
      )) || DEFINE_DAY.THREE_DAY;

    // Đếm thiết bị có duration lớn hơn 90 ngày để taọ cảnh báo bảo trì
    const { count } =
      await this.deviceTemplateScheduleRepository.getDeviceByMaintainDuration({
        periodic: {
          $gte: DEFINE_DAY.NINETY_DAY,
        },
        nextSchedule: {
          $lte: parseInt(moment().add(date, 'day').format(FORMAT_DATE_NUMBER)),
        },
      });

    if (!count) {
      return;
    }
    let number = 1;
    if (count > NUMBER_RECORD) {
      number = Math.ceil(count / NUMBER_RECORD);
    }
    for (let page = 0; page < number; page++) {
      const queue = await this.createWarningQueue.add(
        CREATE_WARNING_MAINTAIN_DEVICE_PROCESS,
        {
          date,
        },
        { timeout: TIMEOUT_QUEUE },
      );
      await queue.finished();
    }
  }

  @Cron(cronJobTimeByElement(CRON_JOB_ENUM.ACCREDITATION_WARNING), {
    name: 'cron_job_accreditation_warning',
    timeZone: TIMEZONE_LOCAL,
  })
  async cronWarningJobAccreditation() {
    console.info(
      `cron job sinh cảnh báo kiểm định ngày... `,
      moment().format('DD-MM-YYYY'),
    );
    const date = await this.getDateSetting(
      JOB_TYPE_ENUM.ACCREDITATION,
      SETTING_JOB_PERIOD_ENUM.MORE_THAN_THREE_MONTH,
    );

    const count =
      await this.deviceTemplateScheduleRepository.countDeviceByAccreditationDuration(
        {
          nextSchedule: {
            $lte: parseInt(
              moment()
                .endOf('day')
                .add(date || DEFINE_DAY.SEVEN_DAY, 'day')
                .format(FORMAT_DATE_NUMBER),
            ),
          },
        },
      );
    if (!count) {
      return;
    }
    let number = 1;
    if (count > NUMBER_RECORD) {
      number = Math.ceil(count / NUMBER_RECORD);
    }
    for (let page = 0; page < number; page++) {
      const queue = await this.createWarningQueue.add(
        CREATE_WARNING_ACCREDITATION_PROCESS,
        {
          date,
        },
        { timeout: TIMEOUT_QUEUE },
      );
      await queue.finished();
    }
  }

  @Cron(cronJobTimeByElement(CRON_JOB_ENUM.OVERDUE_JOB), {
    name: 'cron_overdue_job',
    timeZone: TIMEZONE_LOCAL,
  })
  async cronOverdueJob() {
    const timeOverdue = moment().format(FORMAT_DATE_NUMBER);
    console.info('cron job cv quá hạn ngày... ', timeOverdue);
    const { count } = await this.jobRepository.getJobToCron({
      planTo: { $lt: +timeOverdue },
      status: {
        $nin: [JOB_STATUS_ENUM.COMPLETED, JOB_STATUS_ENUM.RESOLVED],
      },
      isOverdue: false,
      obligatory: OBLIGATORY_ENUM.YES,
    });

    if (!count) {
      return;
    }

    let number = 1;
    if (count > NUMBER_RECORD) {
      number = Math.ceil(count / NUMBER_RECORD);
    }
    for (let page = 0; page < number; page++) {
      const queue = await this.createWarningQueue.add(
        OVERDUE_JOB_PROCESS,
        {},
        { timeout: TIMEOUT_QUEUE },
      );
      await queue.finished();
    }
  }

  @Cron(cronJobTimeByElement(CRON_JOB_ENUM.AUTO_COMPLETE_JOB), {
    name: 'cron_auto_complete_job',
    timeZone: TIMEZONE_LOCAL,
  })
  async cronAutoCompleteJob() {
    const currentDate = moment().format(FORMAT_DATE_NUMBER);
    console.info('cron auto resolve job ngày... ', currentDate);
    const { count } = await this.jobRepository.getJobToCron({
      planTo: { $lt: +currentDate },
      status: {
        $nin: [JOB_STATUS_ENUM.RESOLVED],
      },
      obligatory: OBLIGATORY_ENUM.NO,
    });

    if (!count) {
      return;
    }
    let number = 1;
    if (count > NUMBER_RECORD) {
      number = Math.ceil(count / NUMBER_RECORD);
    }
    for (let page = 0; page < number; page++) {
      const queue = await this.createWarningQueue.add(
        AUTO_COMPLETE_JOB,
        {},
        { timeout: TIMEOUT_QUEUE },
      );
      await queue.finished();
    }
  }
}
