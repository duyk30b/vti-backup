import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { DeviceRepository } from 'src/repository/device/device.repository';
import { CREATE_WARNING_QUEUE_PROCESSOR } from './cron.constants';
import { CronController } from './cron.controller';
import { CronService } from './cron.service';
import { BullModule } from '@nestjs/bull';
import { WarningConsumer } from './cron.consumer';
import { JobRepository } from 'src/repository/job/job.repository';
import { JobSchema } from 'src/models/job/job.schema';
import { WarningRepository } from 'src/repository/warning/warning.repository';
import { WarningSchema } from 'src/models/warning/warning.schema';
import { SettingJobRepository } from 'src/repository/setting/setting-job.repository';
import { SettingJobSchema } from 'src/models/setting-job/setting-job.schema';
import { CheckListTemplateRepository } from 'src/repository/checklist-template/checklist-template.repository';
import { ChecklistTemplateSchema } from 'src/models/checklist-template/checklist-template.schema';
import { DeviceTemplateScheduleSchema } from 'src/models/device-template-schedule/device-template-schedule.schema';
import { DeviceTemplateScheduleRepository } from 'src/repository/device-template-schedule/device-template-schedule.repository';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'Job', schema: JobSchema },
      { name: 'DeviceTemplateSchedule', schema: DeviceTemplateScheduleSchema },
      { name: 'Warning', schema: WarningSchema },
      { name: 'SettingJob', schema: SettingJobSchema },
      { name: 'CheckListTemplate', schema: ChecklistTemplateSchema },
    ]),
    BullModule.registerQueue({
      name: CREATE_WARNING_QUEUE_PROCESSOR,
    }),
  ],
  controllers: [CronController],
  providers: [
    {
      provide: 'CronServiceInterface',
      useClass: CronService,
    },
    {
      provide: 'DeviceRepositoryInterface',
      useClass: DeviceRepository,
    },
    {
      provide: 'DeviceTemplateScheduleRepositoryInterface',
      useClass: DeviceTemplateScheduleRepository,
    },
    {
      provide: 'JobRepositoryInterface',
      useClass: JobRepository,
    },
    {
      provide: 'WarningRepositoryInterface',
      useClass: WarningRepository,
    },
    {
      provide: 'ChecklistTemplateRepositoryInterface',
      useClass: CheckListTemplateRepository,
    },
    {
      provide: 'SettingJobRepositoryInterface',
      useClass: SettingJobRepository,
    },
    WarningConsumer,
  ],
  exports: [],
})
export class CronModule {}
