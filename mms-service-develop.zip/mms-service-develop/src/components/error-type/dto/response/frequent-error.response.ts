import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { Expose } from 'class-transformer';

export class FrequentErrorResponseDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  priority: number;

  @ApiProperty()
  @Expose()
  active: number;

  @ApiProperty()
  @Expose()
  countError: number;
}
