import { CreateErrorTypeRequest } from './create-error-type.request';
import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';

export class UpdateErrorTypeBodyDto extends CreateErrorTypeRequest {}

export class UpdateErrorTypeRequest extends UpdateErrorTypeBodyDto {
  @ApiProperty({ description: 'id loại lỗi' })
  @IsMongoId()
  @IsNotEmpty()
  id: string;
}
