import { DeviceRepositoryInterface } from '@components/device/interface/device.repository.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { keyBy } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { getCurrentCodeByLastRecord } from 'src/helper/code.helper';
import {
  getDataInsert,
  getDataToUpdateError,
  getDataUpdate,
} from 'src/helper/import.helper';
import { CreateErrorTypeRequest } from './dto/request/create-error-type.request';
import { DetailErrorTypeRequest } from './dto/request/detail-error-type.request';
import { GetFrequentErrorRequestDto } from './dto/request/get-frequent-error.request';
import { GetListErrorTypeQuery } from './dto/request/get-list-error-type.query';
import { UpdateErrorTypeRequest } from './dto/request/update-error-type.request';
import { DetailErrorTypeResponse } from './dto/response/detail-error-type.response';
import { FrequentErrorResponseDto } from './dto/response/frequent-error.response';
import {
  ERROR_TYPE_CONST,
  ERROR_TYPE_PRIORITY_ENUM,
} from './error-type.constant';
import { ErrorTypeRepositoryInterface } from './interface/error-type.repository.interface';
import { ErrorTypeServiceInterface } from './interface/error-type.service.interface';

@Injectable()
export class ErrorTypeService implements ErrorTypeServiceInterface {
  constructor(
    @Inject('ErrorTypeRepositoryInterface')
    private readonly errorTypeRepository: ErrorTypeRepositoryInterface,

    @Inject('DeviceRepositoryInterface')
    private readonly deviceRepository: DeviceRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateErrorTypeRequest): Promise<ResponsePayload<any>> {
    try {
      request.code = await this.errorTypeRepository.generateNextCode(
        ERROR_TYPE_CONST.CODE.PREFIX,
      );
      const errorTypeEntity = this.errorTypeRepository.createEntity(request);
      const dataSave = await errorTypeEntity.save();
      const dataReturn = plainToInstance(BasicResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }
  }

  async update(request: UpdateErrorTypeRequest): Promise<ResponsePayload<any>> {
    try {
      let errorTypeEntity = await this.errorTypeRepository.findOneById(
        request.id,
      );

      if (!errorTypeEntity) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      errorTypeEntity = await this.errorTypeRepository.updateEntity(
        errorTypeEntity,
        request,
      );

      await this.errorTypeRepository.findByIdAndUpdate(
        request.id,
        errorTypeEntity,
      );

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INTENAL_ERROR'))
        .build();
    }
  }

  async detail(request: DetailErrorTypeRequest): Promise<ResponsePayload<any>> {
    try {
      const errorTypeEntity = await this.errorTypeRepository.findOneById(
        request.id,
      );

      if (!errorTypeEntity) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      const dataReturn = plainToInstance(
        DetailErrorTypeResponse,
        errorTypeEntity,
        {
          excludeExtraneousValues: true,
        },
      );

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INTENAL_ERROR'))
        .build();
    }
  }

  async list(request: GetListErrorTypeQuery): Promise<ResponsePayload<any>> {
    const { data, count } = await this.errorTypeRepository.list(request);

    const dataReturn = plainToInstance(DetailErrorTypeResponse, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder({
      result: dataReturn,
      meta: { total: count, page: request.page, size: request.limit },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async delete(request: IdParamDto): Promise<ResponsePayload<any>> {
    try {
      const { id } = request;
      const document = await this.errorTypeRepository.findOneById(id);

      if (!document) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }
      await this.errorTypeRepository.softDelete(request.id);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async updateStatus(request: UpdateActiveStatusPayload): Promise<any> {
    const { id, status } = request;
    const errorType = await this.errorTypeRepository.findOneById(id);
    if (!errorType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    await this.errorTypeRepository.findByIdAndUpdate(id, {
      $set: { active: status },
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async frequentError(
    request: GetFrequentErrorRequestDto & IdParamDto,
  ): Promise<ResponsePayload<any>> {
    const device = await this.deviceRepository.findOneById(request.id);

    if (!device) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const errorTypes = await this.errorTypeRepository.getFrequentError(request);

    const dataReturn = plainToInstance(FrequentErrorResponseDto, errorTypes, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder({ items: dataReturn })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const priority = new Map();
    priority.set('Thấp', ERROR_TYPE_PRIORITY_ENUM.LOW);
    priority.set('Trung bình', ERROR_TYPE_PRIORITY_ENUM.MEDIUM);
    priority.set('Cao', ERROR_TYPE_PRIORITY_ENUM.HIGH);
    data.forEach((item) => (item.priority = priority.get(item.priority)));

    const textAdd = await this.i18n.translate('import.common.add');
    const codePrefix = ERROR_TYPE_CONST.CODE.PREFIX;
    const lastRecord = await this.errorTypeRepository.lastRecord();
    const codeCurrent = getCurrentCodeByLastRecord(codePrefix, lastRecord);

    const dataInsert = getDataInsert(data, codePrefix, codeCurrent, textAdd);
    const { dataToUpdate, codesUpdate } = getDataUpdate(data, textAdd);

    const codeUpdateExists = await this.errorTypeRepository.findAllByCondition({
      code: { $in: codesUpdate },
    });
    const codeUpdateMap = keyBy(codeUpdateExists, 'code');

    const { dataError, dataUpdate } = getDataToUpdateError(
      dataToUpdate,
      codeUpdateMap,
    );

    const bulkOps = [...dataInsert, ...dataUpdate].map((doc) => ({
      updateOne: {
        filter: { code: doc.code },
        update: doc,
        upsert: true,
      },
    }));

    const dataSuccess = await this.errorTypeRepository.bulkWrite(bulkOps);

    return { dataError, dataSuccess };
  }
}
