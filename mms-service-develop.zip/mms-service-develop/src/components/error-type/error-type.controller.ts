import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Injectable,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { ErrorTypeServiceInterface } from './interface/error-type.service.interface';
import { CreateErrorTypeRequest } from './dto/request/create-error-type.request';
import { DetailErrorTypeRequest } from './dto/request/detail-error-type.request';
import { UpdateErrorTypeBodyDto } from './dto/request/update-error-type.request';
import { DetailErrorTypeResponse } from './dto/response/detail-error-type.response';
import { GetListErrorTypeQuery } from './dto/request/get-list-error-type.query';
import { ListErrorTypeResponse } from './dto/response/list-error-type.response';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { ACTIVE_ENUM } from '@constant/common';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CREATE_ERROR_TYPE_PERMISSION,
  DETAIL_ERROR_TYPE_PERMISSION,
  LIST_ERROR_TYPE_PERMISSION,
  UPDATE_ERROR_TYPE_PERMISSION,
  UPDATE_STATUS_ERROR_TYPE_PERMISSION,
} from '@utils/permissions/error-type';
import { GetFrequentErrorRequestDto } from './dto/request/get-frequent-error.request';
import {
  CREATE_DEVICE_GROUP_PERMISSION,
  UPDATE_DEVICE_GROUP_PERMISSION,
} from '@utils/permissions/device-group';

@Injectable()
@Controller('error-types')
export class ErrorTypeController {
  constructor(
    @Inject('ErrorTypeServiceInterface')
    private readonly errorTypeService: ErrorTypeServiceInterface,
  ) {}

  @PermissionCode(CREATE_ERROR_TYPE_PERMISSION.code)
  @Post('/')
  @ApiOperation({
    tags: ['Error Type'],
    summary: 'Định nghĩa loại lỗi',
    description: 'Định nghĩa loại lỗi',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async create(@Body() payload: CreateErrorTypeRequest): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.errorTypeService.create(request);
  }

  @PermissionCode(UPDATE_ERROR_TYPE_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Error Type'],
    summary: 'Update error type',
    description: 'Update an existing error type',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  async update(
    @Param() param: DetailErrorTypeRequest,
    @Body() payload: UpdateErrorTypeBodyDto,
  ): Promise<any> {
    const { request: requestParam, responseError: responseParamError } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.errorTypeService.update({
      id: requestParam.id,
      ...request,
    });
  }

  @PermissionCode(DETAIL_ERROR_TYPE_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Error Type'],
    summary: 'Detail error type',
    description: 'Detail error type',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailErrorTypeResponse,
  })
  async detail(@Param() param: DetailErrorTypeRequest): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.errorTypeService.detail(request);
  }

  @PermissionCode(
    LIST_ERROR_TYPE_PERMISSION.code,
    CREATE_DEVICE_GROUP_PERMISSION.code,
    UPDATE_DEVICE_GROUP_PERMISSION.code,
  )
  @Get('/')
  @ApiOperation({
    tags: ['Error Type'],
    summary: 'List error type',
    description: 'List error type',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListErrorTypeResponse,
  })
  async list(@Query() query: GetListErrorTypeQuery): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.errorTypeService.list(request);
  }

  @Delete('/:id')
  @ApiOperation({
    tags: ['Error Type'],
    summary: 'Xóa loại lỗi',
    description: 'Xóa loại lỗi',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async delete(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.errorTypeService.delete(request);
  }

  @PermissionCode(UPDATE_STATUS_ERROR_TYPE_PERMISSION.code)
  @Put('/:id/active')
  @ApiOperation({
    tags: ['Error Type'],
    summary: 'Active Error Type',
    description: 'Active Error Type',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async active(@Param() payload: IdParamDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.errorTypeService.updateStatus({
      ...request,
      status: ACTIVE_ENUM.ACTIVE,
    });
  }

  @PermissionCode(UPDATE_STATUS_ERROR_TYPE_PERMISSION.code)
  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Error Type'],
    summary: 'Inactive Error Type',
    description: 'Inactive Error Type',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async inactive(@Param() payload: IdParamDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.errorTypeService.updateStatus({
      ...request,
      status: ACTIVE_ENUM.INACTIVE,
    });
  }

  @Get('/:id/frequent-error')
  @ApiOperation({
    tags: ['Error Type'],
    summary: 'Lỗi thường gặp',
    description: 'Lỗi thường gặp',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async frequentError(
    @Param() param: IdParamDto,
    @Query() query: GetFrequentErrorRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    const { request: requestParam, responseError: responseErrorParam } = param;

    if (
      (responseError && !isEmpty(responseError)) ||
      (responseErrorParam && !isEmpty(responseErrorParam))
    ) {
      return responseError || responseError;
    }

    request.id = requestParam.id;

    return await this.errorTypeService.frequentError(request);
  }
}
