import { UserService } from '@components/user/user.service';
import { Module } from '@nestjs/common';
import { JobSchema } from 'src/models/job/job.schema';
import { JobRepository } from 'src/repository/job/job.repository';
import { MongooseModule } from '@nestjs/mongoose';
import { DeviceSchema } from 'src/models/device/device.schema';
import { DeviceRepository } from 'src/repository/device/device.repository';
import { DashboardController } from './dashboard.controller';
import { DashboardService } from './dashboard.service';
import { DeviceGroupRepository } from 'src/repository/device-group/device-group.repository';
import { TransferRequestRepository } from 'src/repository/transfer-request/transfer-request.repository';
import { TransferRequestSchema } from 'src/models/transfer-request/transfer-request.schema';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'Device', schema: DeviceSchema }]),
    MongooseModule.forFeature([{ name: 'Job', schema: JobSchema }]),
    MongooseModule.forFeature([
      { name: 'TransferRequest', schema: TransferRequestSchema },
    ]),
  ],
  controllers: [DashboardController],
  providers: [
    {
      provide: 'DashboardServiceInterface',
      useClass: DashboardService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'DeviceRepositoryInterface',
      useClass: DeviceRepository,
    },
    {
      provide: 'JobRepositoryInterface',
      useClass: JobRepository,
    },
    {
      provide: 'TransferRequestRepositoryInterface',
      useClass: TransferRequestRepository,
    },
    {
      provide: 'DeviceGroupRepositoryInterface',
      useClass: DeviceGroupRepository,
    },
  ],
})
export class DashboardModule {}
