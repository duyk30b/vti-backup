import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { Transform } from 'class-transformer';
import { IsArray, IsOptional } from 'class-validator';

export class DashboardRequestDto extends PaginationQuery {
  @ApiProperty()
  @IsOptional()
  @IsArray()
  @Transform(({ value }) => {
    if (value instanceof Array) {
      return value;
    }
    return value ? value?.split(',')?.map((e) => +e) : [];
  })
  factoryIds: number[];
}
