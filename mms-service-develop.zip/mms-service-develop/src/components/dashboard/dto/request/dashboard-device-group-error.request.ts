import { REPORT_TYPE_ENUM } from '@constant/common';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsDateString, IsEnum, IsNotEmpty, IsOptional } from 'class-validator';
import { DashboardRequestDto } from './dashboard.request.dto';

export class DashboardDeviceGroupErrorRequest extends DashboardRequestDto {
  @IsEnum(REPORT_TYPE_ENUM)
  @Transform((data) => Number(data.value))
  @IsNotEmpty()
  reportType: REPORT_TYPE_ENUM;

  @ApiPropertyOptional()
  @IsDateString()
  @IsOptional()
  startDate: Date;

  @ApiPropertyOptional()
  @IsDateString()
  @IsOptional()
  endDate: Date;
}
