import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsDateString, IsEnum, IsOptional } from 'class-validator';
import { REPORT_TYPE_ENUM } from '@constant/common';
import { Transform } from 'class-transformer';
import { DashboardRequestDto } from './dashboard.request.dto';

export class JobDashboardRequestDto extends DashboardRequestDto {
  @IsEnum(REPORT_TYPE_ENUM)
  @Transform((data) => Number(data.value))
  @IsNotEmpty()
  reportType: REPORT_TYPE_ENUM;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  startDate: Date;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  endDate: Date;
}
