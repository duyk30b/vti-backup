import { PaginationQuery } from '@utils/dto/request/pagination.query';

export class DashboardDeviceUseStatusByAreaRequestDto extends PaginationQuery {}
