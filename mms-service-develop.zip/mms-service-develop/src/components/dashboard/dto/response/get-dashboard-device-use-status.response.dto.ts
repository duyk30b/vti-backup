import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class GetDashboardDeviceUseStatusResponseDto {
  @ApiProperty()
  @Expose()
  totalUsing: number;

  @ApiProperty()
  @Expose()
  totalPreventive: number;

  @ApiProperty()
  @Expose()
  totalBroken: number;

  @ApiProperty()
  @Expose()
  totalAwaitClearance: number;
}
