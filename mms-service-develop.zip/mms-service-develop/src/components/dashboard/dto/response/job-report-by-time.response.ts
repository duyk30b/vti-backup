import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';
import * as moment from 'moment';

export class RangeDate {
  @Expose()
  @ApiProperty()
  @Transform((data) => moment(data.value).startOf('day'))
  startDate: Date;

  @Expose()
  @ApiProperty()
  @Transform((data) => moment(data.value).endOf('day'))
  endDate: Date;
}

export class CountReport {
  @Expose()
  @ApiProperty()
  type: number;

  @Expose()
  @ApiProperty()
  count: number;
}

export class JobReportByTimeResponse {
  @Expose()
  @ApiProperty()
  reportType: number;

  @Expose()
  @ApiProperty()
  tag: number;

  @Expose()
  @ApiProperty({ type: RangeDate })
  @Type(() => RangeDate)
  rangeDate: RangeDate;

  @Expose()
  @ApiProperty({ type: CountReport, isArray: true })
  @Type(() => CountReport)
  countReport: CountReport[];
}
