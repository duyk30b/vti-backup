import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class SummaryTransferDashboardResponse {
  @Expose()
  @ApiProperty()
  all: number;

  @Expose()
  @ApiProperty()
  awaiting: number;

  @Expose()
  @ApiProperty()
  confirmed: number;

  @Expose()
  @ApiProperty()
  rejected: number;

  @Expose()
  @ApiProperty()
  completed: number;
}
