import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { Expose, Transform } from 'class-transformer';

export class DashboardDeviceGroupErrorResponse extends BasicResponseDto {
  @ApiProperty()
  @Transform(({ obj }) => obj.repairRequest.length)
  @Expose()
  countError: number;
}
