import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { Expose, plainToInstance, Transform, Type } from 'class-transformer';

class Device extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  serial: string;

  @ApiProperty()
  @Expose()
  deviceStatus: number;
}

export class DashboardDeviceUseStatusByAreaResponseDto {
  @Type(() => BasicResponseDto)
  @ApiProperty({ type: BasicResponseDto })
  @Transform(({ obj }) =>
    plainToInstance(BasicResponseDto, obj?._id, {
      excludeExtraneousValues: true,
    }),
  )
  @Expose()
  area: BasicResponseDto;

  @Type(() => Device)
  @ApiProperty({ type: Device, isArray: true })
  @Expose()
  devices: Device[];
}
