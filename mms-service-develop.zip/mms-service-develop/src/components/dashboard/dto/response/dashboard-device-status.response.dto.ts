import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class DashboardDeviceStatusResponseDto {
  @ApiProperty()
  @Expose()
  total: number;

  @ApiProperty()
  @Expose()
  totalActive: number;

  @ApiProperty()
  @Expose()
  totalStop: number;

  @ApiProperty()
  @Expose()
  totalError: number;

  @ApiProperty()
  @Expose()
  totalOff: number;
}
