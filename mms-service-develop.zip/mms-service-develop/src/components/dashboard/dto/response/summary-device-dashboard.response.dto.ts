import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class SummaryDeviceDashboardResponse {
  @Expose()
  @ApiProperty()
  allDevice: number;

  @Expose()
  @ApiProperty()
  usingDevice: number;

  @Expose()
  @ApiProperty()
  preventiveDevice: number;

  @Expose()
  @ApiProperty()
  brokenDevice: number;

  @Expose()
  @ApiProperty()
  awaitClearanceDevice: number;
}
