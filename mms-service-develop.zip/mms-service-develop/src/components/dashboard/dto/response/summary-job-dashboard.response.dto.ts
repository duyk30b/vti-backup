import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class SummaryJobDashboardResponse {
  @Expose()
  @ApiProperty()
  allJob: number;

  @Expose()
  @ApiProperty()
  nonAssignJob: number;

  @Expose()
  @ApiProperty()
  waitConfirmJob: number;

  @Expose()
  @ApiProperty()
  inProgressJob: number;

  @Expose()
  @ApiProperty()
  completedJob: number;

  @Expose()
  @ApiProperty()
  resolvedJob: number;

  @Expose()
  @ApiProperty()
  isOverdueJob: number;
}
