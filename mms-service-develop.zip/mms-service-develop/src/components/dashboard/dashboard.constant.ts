export enum REPORT_UNIT_TEXT_ENUM {
  DAY = 'day',
  WEEK = 'isoWeek',
  MONTH = 'month',
}

export enum DASHBOARD_TYPE_ENUM {
  WEEK,
  MONTH,
  QUARTER,
}
