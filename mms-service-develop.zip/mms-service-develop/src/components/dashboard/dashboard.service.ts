import { JobRepositoryInterface } from '@components/job/interface/job.repository.interface';
import { JOB_STATUS_ENUM, JOB_TYPE_ENUM } from '@components/job/job.constant';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { DEVICE_STATUS_STATE_ENUM } from '@components/device-status/device-status.constant';
import { DeviceRepositoryInterface } from '@components/device/interface/device.repository.interface';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { plus } from '@utils/common';
import * as moment from 'moment';
import {
  DASHBOARD_TYPE_ENUM,
  REPORT_UNIT_TEXT_ENUM,
} from './dashboard.constant';
import { JobDashboardRequestDto } from './dto/request/job-dashboard.request.dto';
import { JobReportByTimeResponse } from './dto/response/job-report-by-time.response';
import { SummaryDeviceDashboardResponse } from './dto/response/summary-device-dashboard.response.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DashboardRequestDto } from './dto/request/dashboard.request.dto';
import { DashboardDeviceStatusResponseDto } from './dto/response/dashboard-device-status.response.dto';
import { DashboardServiceInterface } from './interface/dashboard.service.interface';
import { DashboardDeviceGroupErrorRequest } from './dto/request/dashboard-device-group-error.request';
import { DeviceGroupRepositoryInterface } from '@components/device-group/interface/device-group.repository.interface';
import { DashboardDeviceGroupErrorResponse } from './dto/response/dashboard-device-group-error.response';
import { DEVICE_STATUS_ENUM } from '@components/device/device.constant';
import { GetDashboardDeviceUseStatusResponseDto } from './dto/response/get-dashboard-device-use-status.response.dto';
import { DashboardDeviceUseStatusByAreaRequestDto } from './dto/request/get-dashboard-device-use-status-by-area.request.dto';
import { DashboardDeviceUseStatusByAreaResponseDto } from './dto/response/dashboard-device-use-status-by-area.response.dto';
import { SummaryJobDashboardResponse } from './dto/response/summary-job-dashboard.response.dto';
import { TransferRequestRepositoryInterface } from '@components/transfer-request/interface/transfer-request.repository.interface';
import { SummaryTransferDashboardResponse } from './dto/response/summary-transfer-dashboard.response.dto';

@Injectable()
export class DashboardService implements DashboardServiceInterface {
  constructor(
    @Inject('DeviceRepositoryInterface')
    private readonly deviceRepository: DeviceRepositoryInterface,

    @Inject('JobRepositoryInterface')
    private readonly jobRepository: JobRepositoryInterface,

    @Inject('TransferRequestRepositoryInterface')
    private readonly transferRequestRepository: TransferRequestRepositoryInterface,

    @Inject('DeviceGroupRepositoryInterface')
    private readonly deviceGroupRepository: DeviceGroupRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async getSummaryDevice(request: DashboardRequestDto): Promise<any> {
    const allDevice = await this.deviceRepository.countDeviceDashboard(request);

    const dataResult = plainToInstance(
      SummaryDeviceDashboardResponse,
      allDevice,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(dataResult)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getHistoryJob(request: JobDashboardRequestDto): Promise<any> {
    try {
      if (
        request.startDate &&
        request.endDate &&
        moment(request.startDate) >= moment(request.endDate)
      ) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.INVALID_DATE_RANGE'),
        ).toResponse();
      }

      const { listRangeDate, startDate, endDate } = this.getRangeDateByDateType(
        request.reportType,
        request.startDate,
        request.endDate,
      );
      const historyJob = await this.jobRepository.historyJobDashboard({
        startDate,
        endDate,
        factoryIds: request.factoryIds,
      });
      const reportData: JobReportByTimeResponse[] = [];

      listRangeDate.forEach((rangeDate, index) => {
        const rangeDateJob = historyJob?.filter((e) => {
          return (
            Number(moment(e.planFrom).format('YYYYMMDD')) >=
              Number(rangeDate.startDate) &&
            Number(moment(e.planFrom).format('YYYYMMDD')) <=
              Number(rangeDate.endDate)
          );
        });
        const typeJob = new Map();
        Object.keys(JOB_TYPE_ENUM).forEach((el: any) => {
          if (el == +el) typeJob.set(+el, 0);
        });

        rangeDateJob.forEach((e) => {
          switch (e?.type) {
            case JOB_TYPE_ENUM.MAINTAIN:
              typeJob.set(
                JOB_TYPE_ENUM.MAINTAIN,
                plus(typeJob.get(JOB_TYPE_ENUM.MAINTAIN), 1),
              );
              break;

            case JOB_TYPE_ENUM.UNEXPECTED_REPAIR:
              typeJob.set(
                JOB_TYPE_ENUM.UNEXPECTED_REPAIR,
                plus(typeJob.get(JOB_TYPE_ENUM.UNEXPECTED_REPAIR), 1),
              );
              break;
            case JOB_TYPE_ENUM.PERIOD_CHECKLIST:
              typeJob.set(
                JOB_TYPE_ENUM.PERIOD_CHECKLIST,
                plus(typeJob.get(JOB_TYPE_ENUM.PERIOD_CHECKLIST), 1),
              );
              break;
            case JOB_TYPE_ENUM.ACCREDITATION:
              typeJob.set(
                JOB_TYPE_ENUM.ACCREDITATION,
                plus(+typeJob.get(JOB_TYPE_ENUM.ACCREDITATION), 1),
              );
              break;
            case JOB_TYPE_ENUM.INSTALLATION:
              typeJob.set(
                JOB_TYPE_ENUM.INSTALLATION,
                plus(+typeJob.get(JOB_TYPE_ENUM.INSTALLATION), 1),
              );
              break;
            default:
              break;
          }
        });

        const countReport = Array.from(typeJob).map(([key, value]) => ({
          type: key,
          count: value,
        }));
        reportData.push({
          reportType: request.reportType,
          tag: index,
          countReport,
          rangeDate,
        });
      });
      const returnReportData = plainToInstance(
        JobReportByTimeResponse,
        reportData,
        {
          excludeExtraneousValues: true,
        },
      );
      return new ResponseBuilder(returnReportData)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getProgressJob(request: JobDashboardRequestDto) {
    try {
      if (
        request.startDate &&
        request.endDate &&
        moment(request.startDate) >= moment(request.endDate)
      ) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.INVALID_DATE_RANGE'),
        ).toResponse();
      }

      const { listRangeDate, startDate, endDate } = this.getRangeDateByDateType(
        request.reportType,
        request.startDate,
        request.endDate,
      );

      const progressJob = await this.jobRepository.progressJobDashboard({
        startDate,
        endDate,
        factoryIds: request.factoryIds,
      });

      const reportData: JobReportByTimeResponse[] = [];

      listRangeDate.forEach((rangeDate, index) => {
        const rangeDateJob = progressJob?.filter((e) => {
          return (
            Number(moment(e?.history?.createdAt).format('YYYYMMDD')) >=
              Number(rangeDate.startDate) &&
            Number(moment(e?.history?.createdAt).format('YYYYMMDD')) <=
              Number(rangeDate.endDate)
          );
        });
        const statusJob = new Map();
        Object.keys(JOB_STATUS_ENUM).forEach((el: any) => {
          if (el == +el) statusJob.set(+el, 0);
        });

        rangeDateJob.forEach((e) => {
          switch (e?.status) {
            case JOB_STATUS_ENUM.COMPLETED:
              statusJob.set(
                JOB_STATUS_ENUM.COMPLETED,
                plus(statusJob.get(JOB_STATUS_ENUM.COMPLETED), 1),
              );
              break;

            case JOB_STATUS_ENUM.RESOLVED:
              statusJob.set(
                JOB_STATUS_ENUM.RESOLVED,
                plus(statusJob.get(JOB_STATUS_ENUM.RESOLVED), 1),
              );
              break;
            case JOB_STATUS_ENUM.IN_PROGRESS:
              statusJob.set(
                JOB_STATUS_ENUM.IN_PROGRESS,
                plus(statusJob.get(JOB_STATUS_ENUM.IN_PROGRESS), 1),
              );
              break;
            case JOB_STATUS_ENUM.WAIT_CONFIRM:
              statusJob.set(
                JOB_STATUS_ENUM.WAIT_CONFIRM,
                plus(statusJob.get(JOB_STATUS_ENUM.WAIT_CONFIRM), 1),
              );
              break;
            default:
              break;
          }
        });
        const countReport = Array.from(statusJob).map(([key, value]) => ({
          type: key,
          count: value,
        }));
        reportData.push({
          reportType: request.reportType,
          tag: index,
          countReport,
          rangeDate,
        });
      });
      const returnReportData = plainToInstance(
        JobReportByTimeResponse,
        reportData,
        {
          excludeExtraneousValues: true,
        },
      );
      return new ResponseBuilder(returnReportData)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error.message || error)
        .build();
    }
  }

  async dashboardDeviceStatus(
    request: DashboardRequestDto,
  ): Promise<ResponsePayload<any>> {
    const result = await this.deviceRepository.dashboardDeviceStatus(request);

    const statistical = {
      total: 0,
      totalActive: 0,
      totalStop: 0,
      totalError: 0,
      totalOff: 0,
    };

    result.forEach((item) => {
      const count = item?.count || 0;
      statistical.total += count;
      switch (item._id) {
        case DEVICE_STATUS_STATE_ENUM.ACTIVE:
          statistical.totalActive += count;
          break;
        case DEVICE_STATUS_STATE_ENUM.STOP:
          statistical.totalStop += count;
          break;
        case DEVICE_STATUS_STATE_ENUM.ERROR:
          statistical.totalError += count;
          break;
        case DEVICE_STATUS_STATE_ENUM.OFF:
          statistical.totalOff += count;
          break;
        default:
          break;
      }
    });

    const dataReturn = plainToInstance(
      DashboardDeviceStatusResponseDto,
      statistical,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async deviceGroupError(
    request: DashboardDeviceGroupErrorRequest,
  ): Promise<ResponsePayload<any>> {
    const { startDate, endDate, reportType } = request;
    const { from, to } = this.getDate(startDate, endDate, reportType);

    const data = await this.deviceGroupRepository.deviceGroupError({
      ...request,
      startDate: from,
      endDate: to,
    });
    const dataReturn = plainToInstance(
      DashboardDeviceGroupErrorResponse,
      data,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private getDate(startDate: Date, endDate: Date, reportType: number): any {
    const from = startDate
      ? moment(startDate)
      : reportType === DASHBOARD_TYPE_ENUM.MONTH
      ? moment().startOf('month')
      : reportType === DASHBOARD_TYPE_ENUM.QUARTER
      ? moment().startOf('quarter')
      : moment().startOf('isoWeek');

    const to = endDate
      ? moment(endDate)
      : reportType === DASHBOARD_TYPE_ENUM.MONTH
      ? moment().endOf('month')
      : reportType === DASHBOARD_TYPE_ENUM.QUARTER
      ? moment().endOf('quarter')
      : moment().endOf('isoWeek');
    return { from, to };
  }

  async dashboardDeviceUseStatus(
    request: DashboardRequestDto,
  ): Promise<ResponsePayload<any>> {
    const result = await this.deviceRepository.dashboardDeviceUseStatus(
      request,
    );

    const statistical = {
      totalUsing: 0,
      totalPreventive: 0,
      totalBroken: 0,
      totalAwaitClearance: 0,
    };

    result.forEach((item) => {
      switch (+item._id?.status) {
        case DEVICE_STATUS_ENUM.USING:
          statistical.totalUsing += item.count;
          break;
        case DEVICE_STATUS_ENUM.PREVENTIVE:
          statistical.totalPreventive = item.count;
          break;
        case DEVICE_STATUS_ENUM.BROKEN:
          statistical.totalBroken = item.count;
          break;
        case DEVICE_STATUS_ENUM.AWAIT_CLEARANCE:
          statistical.totalAwaitClearance = item.count;
          break;
        default:
          break;
      }
    });

    const dataReturn = plainToInstance(
      GetDashboardDeviceUseStatusResponseDto,
      statistical,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private getRangeDateByDateType(
    reportType: number,
    startDate?: Date,
    endDate?: Date,
  ): {
    listRangeDate: any[];
    startDate: Date;
    endDate: Date;
  } {
    const listRangeDate = [];
    let unit = REPORT_UNIT_TEXT_ENUM.DAY;
    switch (reportType) {
      case DASHBOARD_TYPE_ENUM.MONTH:
        unit = REPORT_UNIT_TEXT_ENUM.WEEK;
        break;
      case DASHBOARD_TYPE_ENUM.QUARTER:
        unit = REPORT_UNIT_TEXT_ENUM.MONTH;
        break;
      default:
        break;
    }

    const { from, to } = this.getDate(startDate, endDate, reportType);

    for (
      let date = from.clone();
      date.isSameOrBefore(to, 'day');
      date.add(1, 'day')
    ) {
      const endOfMonth = date.clone().endOf('month').format('YYYYMMDD');
      const startDate = date.clone().format('YYYYMMDD');
      const endDate = date.endOf(unit).format('YYYYMMDD');
      listRangeDate.push({
        startDate,
        endDate: endOfMonth < endDate ? endOfMonth : endDate,
      });
    }
    return { listRangeDate, startDate: from.toDate(), endDate: to.toDate() };
  }

  async dashboardDeviceUseStatusByArea(
    request: DashboardDeviceUseStatusByAreaRequestDto,
  ): Promise<ResponsePayload<any>> {
    const deviceStatuses =
      await this.deviceRepository.dashboardDeviceUseStatusByArea(request);

    const dataReturn = plainToInstance(
      DashboardDeviceUseStatusByAreaResponseDto,
      deviceStatuses,
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async jobSummary(request: DashboardRequestDto): Promise<any> {
    const result = await this.jobRepository.countJobForDashboard(request);
    const dataResult = plainToInstance(
      SummaryJobDashboardResponse,
      result ?? {},
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(dataResult)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async transferSummary(request: DashboardRequestDto): Promise<any> {
    const result =
      await this.transferRequestRepository.countTransferRequestDashboard(
        request,
      );

    const data = plainToInstance(
      SummaryTransferDashboardResponse,
      result ?? {},
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
