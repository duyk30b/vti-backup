import { JobDashboardRequestDto } from '../dto/request/job-dashboard.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { DashboardRequestDto } from '../dto/request/dashboard.request.dto';
import { DashboardDeviceGroupErrorRequest } from '../dto/request/dashboard-device-group-error.request';
import { DashboardDeviceUseStatusByAreaRequestDto } from '../dto/request/get-dashboard-device-use-status-by-area.request.dto';

export interface DashboardServiceInterface {
  getSummaryDevice(request: DashboardRequestDto): Promise<any>;
  getProgressJob(request: JobDashboardRequestDto): Promise<any>;
  getHistoryJob(request: JobDashboardRequestDto): Promise<any>;
  dashboardDeviceStatus(
    request: DashboardRequestDto,
  ): Promise<ResponsePayload<any>>;
  deviceGroupError(
    request: DashboardDeviceGroupErrorRequest,
  ): Promise<ResponsePayload<any>>;
  dashboardDeviceUseStatus(
    query: DashboardRequestDto,
  ): Promise<ResponsePayload<any>>;
  dashboardDeviceUseStatusByArea(
    request: DashboardDeviceUseStatusByAreaRequestDto,
  ): Promise<ResponsePayload<any>>;
  jobSummary(request: DashboardRequestDto): Promise<any>;
  transferSummary(request: DashboardRequestDto): Promise<any>;
}
