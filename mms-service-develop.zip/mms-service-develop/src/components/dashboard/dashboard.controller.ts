import {
  Controller,
  Get,
  Inject,
  Injectable,
  Query,
  UseInterceptors,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { ResponsePayload } from '@utils/response-payload';
import { DashboardRequestDto } from './dto/request/dashboard.request.dto';
import { DashboardDeviceStatusResponseDto } from './dto/response/dashboard-device-status.response.dto';
import { isEmpty } from 'lodash';
import { JobDashboardRequestDto } from './dto/request/job-dashboard.request.dto';
import { JobReportByTimeResponse } from './dto/response/job-report-by-time.response';
import { SummaryDeviceDashboardResponse } from './dto/response/summary-device-dashboard.response.dto';
import { DashboardServiceInterface } from './interface/dashboard.service.interface';
import { DashboardDeviceGroupErrorRequest } from './dto/request/dashboard-device-group-error.request';
import { DashboardDeviceGroupErrorResponse } from './dto/response/dashboard-device-group-error.response';
import { DashboardDeviceUseStatusByAreaRequestDto } from './dto/request/get-dashboard-device-use-status-by-area.request.dto';
import { DashboardDeviceUseStatusByAreaResponseDto } from './dto/response/dashboard-device-use-status-by-area.response.dto';
import { SummaryJobDashboardResponse } from './dto/response/summary-job-dashboard.response.dto';
import { PermissionInterceptor } from '@core/interceptors/permission.interceptor';

@Injectable()
@Controller('dashboard')
export class DashboardController {
  constructor(
    @Inject('DashboardServiceInterface')
    private readonly dashboardService: DashboardServiceInterface,
  ) {}

  @UseInterceptors(PermissionInterceptor)
  @Get('/summary-device')
  @ApiOperation({
    tags: ['Dashboard'],
    summary: 'Summary Device  Dashboard',
    description: 'Summary Device  Dashboard',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SummaryDeviceDashboardResponse,
  })
  async getSummaryDevice(@Query() param: DashboardRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return this.dashboardService.getSummaryDevice(request);
  }

  @UseInterceptors(PermissionInterceptor)
  @Get('/progress-job')
  @ApiOperation({
    tags: ['Dashboard'],
    summary: 'Progress Job Dashboard',
    description: 'Progress Job Dashboard',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: JobReportByTimeResponse,
  })
  async progressJob(@Query() param: JobDashboardRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return this.dashboardService.getProgressJob(request);
  }

  @UseInterceptors(PermissionInterceptor)
  @Get('/history-job')
  @ApiOperation({
    tags: ['Dashboard'],
    summary: 'History Job  Dashboard',
    description: 'History Job  Dashboard',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: JobReportByTimeResponse,
  })
  async historyJob(@Query() param: JobDashboardRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return this.dashboardService.getHistoryJob(request);
  }

  @UseInterceptors(PermissionInterceptor)
  @Get('device-status')
  @ApiOperation({
    tags: ['Dashboard'],
    summary: 'Dashboard trạng thái thiết bị',
    description: 'Thống kê trạng thái vận hành thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DashboardDeviceStatusResponseDto,
  })
  async dashboardDeviceStatus(
    @Query() query: DashboardRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = query;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.dashboardService.dashboardDeviceStatus(request);
  }

  @UseInterceptors(PermissionInterceptor)
  @Get('device-group-error')
  @ApiOperation({
    tags: ['Dashboard'],
    summary: 'Dashboard danh mục thiết bị hay xảy ra lỗi',
    description: 'Dashboard danh mục thiết bị hay xảy ra lỗi',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DashboardDeviceGroupErrorResponse,
  })
  async deviceGroupError(
    @Query() query: DashboardDeviceGroupErrorRequest,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = query;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.dashboardService.deviceGroupError(request);
  }

  @UseInterceptors(PermissionInterceptor)
  @Get('device-use-status')
  @ApiOperation({
    tags: ['Dashboard'],
    summary: 'Dashboard trạng thái sử dụng thiết bị',
    description: 'Thống kê trạng thái sử dụng thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DashboardDeviceStatusResponseDto,
  })
  async dashboardDeviceUseStatus(
    @Query() query: DashboardRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = query;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.dashboardService.dashboardDeviceUseStatus(request);
  }

  @UseInterceptors(PermissionInterceptor)
  @Get('device-use-status-by-area')
  @ApiOperation({
    tags: ['Dashboard'],
    summary: 'Dashboard trạng thái sử dụng thiết bị theo khu vực',
    description: 'Thống kê trạng thái sử dụng thiết bị theo khu vực',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DashboardDeviceUseStatusByAreaResponseDto,
  })
  async dashboardDeviceUseStatusByArea(
    @Query() query: DashboardDeviceUseStatusByAreaRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return this.dashboardService.dashboardDeviceUseStatusByArea(request);
  }

  @UseInterceptors(PermissionInterceptor)
  @Get('/summary-job')
  @ApiOperation({
    tags: ['Dashboard'],
    summary: 'Summary Job  Dashboard',
    description: 'Summary Job  Dashboard',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SummaryJobDashboardResponse,
  })
  async getJobSummary(@Query() param: DashboardRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return this.dashboardService.jobSummary(request);
  }

  @UseInterceptors(PermissionInterceptor)
  @Get('/summary-transfer')
  @ApiOperation({
    tags: ['Dashboard'],
    summary: 'Summary Transfer Request  Dashboard',
    description: 'Summary Transfer Request  Dashboard',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SummaryJobDashboardResponse,
  })
  async getTransferSummary(@Query() param: DashboardRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return this.dashboardService.transferSummary(request);
  }
}
