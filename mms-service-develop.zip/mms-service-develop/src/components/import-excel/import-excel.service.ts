import { SupplyGroupServiceInterface } from '@components/supply-group/interface/supply-group.service.interface';
import { AttributeTypeServiceInterface } from './../attribute-type/interface/attribute-type.service.interface';
import { SupplyServiceInterface } from './../supply/interface/supply.service.interface';
import { InstallationTemplateServiceInterface } from './../installation-template/interface/installation-template.service.interface';
import { TypeEnum } from '@components/export/export.constant';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { Workbook } from 'exceljs';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ImportExcelRequest } from './dto/import-excel.request';
import { ImportExcelServiceInterface } from './interface/import-excel.service.interface';
import { uniq, isEmpty, compact, has, groupBy, isNull } from 'lodash';
import {
  TEMPLATE_DEVICE_GROUP,
  TEMPLATE_MAINTENANCE_ATTRIBUTE,
  TEMPLATE_ATTRIBUTE_TYPE,
  TEMPLATE_SUPPLY,
  TEMPLATE_CHECK_LIST,
  TEMPLATE_CHECK_LIST_DETAIL,
  TEMPLATE_INSTALLATION,
  TEMPLATE_INSTALLATION_DETAIL,
  MAINTENANCE_TEAM,
  TEMPLATE_AREA,
  TEMPLATE_ERROR_TYPE,
  TEMPLATE_VENDOR,
  TEMPLATE_DEVICE_TYPE,
  TEMPLATE_DEVICE,
  TEMPLATE_ARTICLE_DEVICE_GROUP,
  TEMPLATE_DEVICE_GROUP_SUPPLIES,
  TEMPLATE_DEVICE_GROUP_MAINTENANCE_INDEX,
  TEMPLATE_SUPPLY_GROUP,
  MAINTENANCE_TEMPLATE,
  MAINTENANCE_TEMPLATE_DETAIL,
  TEMPLATE_ACCREDITATION,
  TEMPLATE_ACCREDITATION_DETAIL,
  ACTION_IMPORT_KEY,
  MAINTENANCE_TEAM_MEMBER,
  TEMPLATE_DEVICE_NAME,
  TEMPLATE_INVENTORY_ASSET,
  TEMPLATE_WAREHOUSE,
} from './import-excel.constant';
import { getDataDuplicate } from '@utils/common';
import { DeviceGroupServiceInterface } from '@components/device-group/interface/device-group.service.interface';
import { MaintenanceAttributeServiceInterface } from '@components/maintenance-attribute/interface/maintenance-attribute.service.interface';
import { CheckListTemplateServiceInterface } from '@components/checklist-template/interface/checklist-template.service.interface';
import { MaintenanceTeamServiceInterface } from '@components/maintenance-team/interface/maintenance-team.service.interface';
import { AreaServiceInterface } from '@components/area/interface/area.service.interface';
import { ErrorTypeServiceInterface } from '@components/error-type/interface/error-type.service.interface';
import { VendorServiceInterface } from '@components/vendor/interface/vendor.service.interface';
import { DeviceServiceInterface } from '@components/device/interface/device.service.interface';
import { DeviceTypeServiceInterface } from '@components/device-type/interface/device-type.service.interface';
import { ArticleDeviceGroupServiceInterface } from '@components/article-device-group/interface/article-device-group.service.interface';
import { CAN_FIXABLE_ENUM } from '@components/device-group/device-group.constant';
import { OBLIGATORY_ENUM } from '@constant/common';
import { MaintenanceTemplateServiceInterface } from '@components/maintenance-template/interface/maintenance-template.service.interface';
import {
  MAINTENANCE_JOB_TYPE,
  MAINTENANCE_PERIOD_UNIT,
} from '@components/maintenance-template/maintenance-template.constant';
import { AccreditationTemplateServiceInterface } from '@components/accreditation-template/interface/accreditotion-template.service.interface';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { DeviceNameServiceInterface } from '@components/device-name/interface/device-name.service.interface';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';
import { SupplyRepositoryInterface } from '@components/supply/interface/supply.repository.interface';
import { InventoryRepositoryInterface } from '@components/warehouse/interface/inventory.repository.interface';

@Injectable()
export class ImportExcelService implements ImportExcelServiceInterface {
  constructor(
    @Inject('MaintenanceTeamServiceInterface')
    private readonly maintenanceTeamService: MaintenanceTeamServiceInterface,

    @Inject('MaintenanceAttributeServiceInterface')
    private readonly maintenanceAttributeService: MaintenanceAttributeServiceInterface,

    @Inject('AttributeTypeServiceInterface')
    private readonly attributeTypeService: AttributeTypeServiceInterface,

    @Inject('SupplyServiceInterface')
    private readonly supplyService: SupplyServiceInterface,

    @Inject('CheckListTemplateServiceInterface')
    private readonly checkListTemplateService: CheckListTemplateServiceInterface,

    @Inject('DeviceGroupServiceInterface')
    private readonly deviceGroupService: DeviceGroupServiceInterface,

    @Inject('SupplyGroupServiceInterface')
    private readonly supplyGroupService: SupplyGroupServiceInterface,

    @Inject('InstallationTemplateServiceInterface')
    private readonly installationTemplateService: InstallationTemplateServiceInterface,

    @Inject('AreaServiceInterface')
    private readonly areaService: AreaServiceInterface,

    @Inject('ErrorTypeServiceInterface')
    private readonly errorTypeService: ErrorTypeServiceInterface,

    @Inject('VendorServiceInterface')
    private readonly vendorService: VendorServiceInterface,

    @Inject('DeviceTypeServiceInterface')
    private readonly deviceTypeService: DeviceTypeServiceInterface,

    @Inject('DeviceNameServiceInterface')
    private readonly deviceNameService: DeviceNameServiceInterface,

    @Inject('DeviceServiceInterface')
    private readonly deviceService: DeviceServiceInterface,

    @Inject('ArticleDeviceGroupServiceInterface')
    private readonly articleDeviceGroupService: ArticleDeviceGroupServiceInterface,

    @Inject('MaintenanceTemplateServiceInterface')
    private readonly maintenanceTemplateService: MaintenanceTemplateServiceInterface,

    @Inject('AccreditationTemplateServiceInterface')
    private readonly accreditationTemplateService: AccreditationTemplateServiceInterface,

    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,

    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,

    @Inject('InventoryRepositoryInterface')
    private readonly InventoryRepository: InventoryRepositoryInterface,

    @Inject('SupplyRepositoryInterface')
    private readonly SupplyRepository: SupplyRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async import(payload: ImportExcelRequest): Promise<any> {
    const { type, files, user } = payload;

    const workbook = new Workbook();
    await workbook.xlsx.load(Buffer.from(files[0].data));
    switch (type) {
      case TypeEnum.DEVICE_GROUP:
        return await this.importDeviceGroups(workbook);
      case TypeEnum.SUPPLY_GROUP:
        return await this.importSupplyGroups(workbook);
      case TypeEnum.MAINTENANCE_ATTRIBUTE:
        return await this.importMaintenanceAttributes(workbook);
      case TypeEnum.ATTRIBUTE_TYPE:
        return await this.importAttributeType(workbook);
      case TypeEnum.SUPPLY:
        return await this.importSupplies(workbook, user);
      case TypeEnum.ACCREDITATION_TEMPLATE:
        return await this.importAccreditationTemplates(workbook);
      case TypeEnum.CHECKLIST_TEMPLATE:
        return await this.importCheckListTemplates(workbook);
      case TypeEnum.INSTALLATION_TEMPLATE:
        return await this.importInstallationTemplates(workbook);
      case TypeEnum.MAINTENANCE_TEAM:
        return await this.importMaintenanceTeam(workbook);
      case TypeEnum.AREA:
        return await this.importAreas(workbook);
      case TypeEnum.ERROR_TYPE:
        return await this.importErrorTypes(workbook);
      case TypeEnum.VENDOR:
        return await this.importVendor(workbook);
      case TypeEnum.DEVICE_TYPE:
        return await this.importDeviceType(workbook);
      case TypeEnum.DEVICE:
        return await this.importDevices(workbook, user);
      case TypeEnum.ARTICLE_DEVICE_GROUP:
        return await this.importArticleDeviceGroups(workbook);
      case TypeEnum.MAINTENANCE_TEMPLATE:
        return await this.importMaintenanceTemplates(workbook);
      case TypeEnum.WAREHOUSE:
        return await this.importWarehouse(workbook);
      case TypeEnum.DEVICE_NAME:
        return await this.importDeviceName(workbook);
      default:
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
    }
  }

  private async importDeviceGroups(workbook: any): Promise<any> {
    const header = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.deviceGroup.code'),
      name: await this.i18n.translate('import.deviceGroup.name'),
      installationTemplateCode: await this.i18n.translate(
        'import.deviceGroup.installationTemplateCode',
      ),
      accreditationTemplateCode: await this.i18n.translate(
        'import.deviceGroup.accreditationTemplateCode',
      ),
      errorTypeCodes: await this.i18n.translate(
        'import.deviceGroup.errorTypeCodes',
      ),
      articleDeviceGroupCode: await this.i18n.translate(
        'import.deviceGroup.articleDeviceGroupCode',
      ),
      maintenanceAttributeCode: await this.i18n.translate(
        'import.deviceGroup.maintenanceAttributeCode',
      ),
      attributeTypeCodes: await this.i18n.translate(
        'import.deviceGroup.attributeTypeCodes',
      ),
      maintenanceTemplateCode: await this.i18n.translate(
        'import.deviceGroup.maintenanceTemplateCode',
      ),
      frequency: await this.i18n.translate('import.deviceGroup.frequency'),
      canUpdateStatus: await this.i18n.translate(
        'import.deviceGroup.canUpdateStatus',
      ),
      symbol: await this.i18n.translate('import.deviceGroup.symbol'),
      normGenerateJob: await this.i18n.translate(
        'import.deviceGroup.normGenerateJob',
      ),
    };

    const headerSupplies = {
      deviceGroupCode: await this.i18n.translate(
        'import.deviceGroup.supplies.deviceGroupCode',
      ),
      supplyCode: await this.i18n.translate(
        'import.deviceGroup.supplies.supplyCode',
      ),
      quantity: await this.i18n.translate(
        'import.deviceGroup.supplies.quantity',
      ),
      estimateUsedTime: await this.i18n.translate(
        'import.deviceGroup.supplies.estimateUsedTime',
      ),
      canFixable: await this.i18n.translate(
        'import.deviceGroup.supplies.canFixable',
      ),
    };

    const headerMaintenanceIndex = {
      deviceGroupCode: await this.i18n.translate(
        'import.deviceGroup.supplies.deviceGroupCode',
      ),
      supplyCode: await this.i18n.translate(
        'import.deviceGroup.maintenanceIndex.supplyCode',
      ),
      maintenanceFrequency: await this.i18n.translate(
        'import.deviceGroup.maintenanceIndex.maintenanceFrequency',
      ),
      mtbf: await this.i18n.translate(
        'import.deviceGroup.maintenanceIndex.mtbf',
      ),
      mttr: await this.i18n.translate(
        'import.deviceGroup.maintenanceIndex.mttr',
      ),
      mtta: await this.i18n.translate(
        'import.deviceGroup.maintenanceIndex.mtta',
      ),
      mttf: await this.i18n.translate(
        'import.deviceGroup.maintenanceIndex.mttf',
      ),
    };

    const [data, resultError] = await this.handleWorkbook(
      workbook,
      TEMPLATE_DEVICE_GROUP,
      header,
      await this.i18n.translate('import.sheetName.Sheet1'),
    );

    const [dataSupplies, resultSuppliesError] = await this.handleWorkbook(
      workbook,
      TEMPLATE_DEVICE_GROUP_SUPPLIES,
      headerSupplies,
      await this.i18n.translate('import.sheetName.Sheet2'),
    );

    const [dataMaintenanceIndex, resultMaintenanceIndexError] =
      await this.handleWorkbook(
        workbook,
        TEMPLATE_DEVICE_GROUP_MAINTENANCE_INDEX,
        headerMaintenanceIndex,
        await this.i18n.translate('import.sheetName.Sheet3'),
      );
    if (
      data[0]?.statusCode === ResponseCodeEnum.NOT_FOUND ||
      dataSupplies[0]?.statusCode === ResponseCodeEnum.NOT_FOUND ||
      dataMaintenanceIndex[0]?.statusCode === ResponseCodeEnum.NOT_FOUND
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          `${data[0]?.message ?? ''}, ${dataSupplies[0]?.message ?? ''}, ${
            dataMaintenanceIndex[0]?.message ?? ''
          }`,
        )
        .build();
    }
    const textYes = await this.i18n.translate('export.common.yes');

    const supplies = dataSupplies.reduce((supplies, el) => {
      const canFixable =
        el.canFixable === textYes ? CAN_FIXABLE_ENUM.YES : CAN_FIXABLE_ENUM.NO;
      supplies[el.deviceGroupCode] = has(supplies, el.deviceGroupCode)
        ? supplies[el.deviceGroupCode].concat({ ...el, canFixable })
        : [{ ...el, canFixable }];
      return supplies;
    }, {});

    const maintenanceIndex = dataMaintenanceIndex.reduce(
      (maintenanceIndex, el) => {
        maintenanceIndex[el.deviceGroupCode] = has(
          maintenanceIndex,
          el.deviceGroupCode,
        )
          ? maintenanceIndex[el.deviceGroupCode].concat(el)
          : [el];
        return maintenanceIndex;
      },
      {},
    );

    data.forEach((el, index) => {
      data[index].canUpdateStatus =
        el.canUpdateStatus === textYes
          ? CAN_FIXABLE_ENUM.YES
          : CAN_FIXABLE_ENUM.NO;
      if (has(maintenanceIndex, el.code)) {
        data[index].maintenanceIndex = maintenanceIndex[el.code];
      }
      if (has(supplies, el.code)) {
        data[index].supplies = supplies[el.code];
      }
    });
    const { dataError, dataSuccess } = await this.deviceGroupService.import(
      data,
    );
    if (!isEmpty(dataError)) {
      return new ResponseBuilder({
        dataSuccess,
        dataError: [
          ...resultError,
          ...resultMaintenanceIndexError,
          ...resultSuppliesError,
          ...dataError,
        ],
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    return new ResponseBuilder({
      dataSuccess,
      dataError: [
        ...resultError,
        ...resultMaintenanceIndexError,
        ...resultSuppliesError,
        ...dataError,
      ],
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async importSupplyGroups(workbook: any): Promise<any> {
    const header = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.supplyGroup.code'),
      name: await this.i18n.translate('import.supplyGroup.name'),
      description: await this.i18n.translate('import.supplyGroup.description'),
    };

    const [data, resultError] = await this.handleWorkbook(
      workbook,
      TEMPLATE_SUPPLY_GROUP,
      header,
      await this.i18n.translate('import.sheetName.Sheet1'),
    );

    if (data[0]?.statusCode === ResponseCodeEnum.NOT_FOUND) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(data[0]?.message)
        .build();
    }
    const { dataError, dataSuccess } = await this.supplyGroupService.import(
      data,
    );

    return new ResponseBuilder({
      dataSuccess,
      dataError: [...resultError, ...dataError],
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async importMaintenanceAttributes(workbook: any): Promise<any> {
    const header = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.maintenanceAttribute.code'),
      name: await this.i18n.translate('import.maintenanceAttribute.name'),
      description: await this.i18n.translate(
        'import.maintenanceAttribute.description',
      ),
    };

    const [data, resultError] = await this.handleWorkbook(
      workbook,
      TEMPLATE_MAINTENANCE_ATTRIBUTE,
      header,
      await this.i18n.translate('import.sheetName.Sheet1'),
    );

    if (data[0]?.statusCode === ResponseCodeEnum.NOT_FOUND) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(data[0]?.message)
        .build();
    }

    const { dataError, dataSuccess } =
      await this.maintenanceAttributeService.import(data);

    if (!isEmpty(dataError)) {
      return new ResponseBuilder({
        dataSuccess,
        dataError: [...resultError, ...dataError],
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    return new ResponseBuilder({
      dataSuccess,
      dataError: [...resultError, ...dataError],
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async importAttributeType(workbook: any): Promise<any> {
    const header = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.attributeType.code'),
      name: await this.i18n.translate('import.attributeType.name'),
      description: await this.i18n.translate(
        'import.attributeType.description',
      ),
      unitCode: await this.i18n.translate('import.attributeType.unitCode'),
    };

    const [data, resultError] = await this.handleWorkbook(
      workbook,
      TEMPLATE_ATTRIBUTE_TYPE,
      header,
      await this.i18n.translate('import.sheetName.Sheet1'),
    );

    if (data[0]?.statusCode === ResponseCodeEnum.NOT_FOUND) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(data[0]?.message)
        .build();
    }

    const { dataError, dataSuccess } = await this.attributeTypeService.import(
      data,
    );

    if (!isEmpty(dataError)) {
      return new ResponseBuilder({
        dataSuccess,
        dataError: [...resultError, ...dataError],
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    return new ResponseBuilder({
      dataSuccess,
      dataError: [...resultError, ...dataError],
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async importSupplies(workbook: any, user: any): Promise<any> {
    const header = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.supply.code'),
      name: await this.i18n.translate('import.supply.name'),
      nameOther: await this.i18n.translate('import.supply.nameOther'),
      supplyTypeName: await this.i18n.translate('import.supply.supplyTypeName'),
      supplyGroupCode: await this.i18n.translate(
        'import.supply.supplyGroupCode',
      ),
      unitCode: await this.i18n.translate('import.supply.unitCode'),
      vendorCode: await this.i18n.translate('import.supply.vendorCode'),
      price: await this.i18n.translate('import.supply.price'),
      description: await this.i18n.translate('import.supply.description'),
    };

    const [data, resultError] = await this.handleWorkbook(
      workbook,
      TEMPLATE_SUPPLY,
      header,
      await this.i18n.translate('import.sheetName.Sheet1'),
    );

    if (data[0]?.statusCode === ResponseCodeEnum.NOT_FOUND) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(data[0]?.message)
        .build();
    }

    const { dataError, dataSuccess } = await this.supplyService.import(
      data,
      user,
    );

    if (!isEmpty(dataError)) {
      return new ResponseBuilder({
        dataSuccess,
        dataError: [...resultError, ...dataError],
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    return new ResponseBuilder({
      dataSuccess,
      dataError: [...resultError, ...dataError],
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async importCheckListTemplates(workbook: any): Promise<any> {
    const headerCheckListTemplate = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.checklistTemplate.code'),
      name: await this.i18n.translate('import.checklistTemplate.name'),
      description: await this.i18n.translate(
        'import.checklistTemplate.description',
      ),
    };

    const headerCheckListDetail = {
      templateCode: await this.i18n.translate('import.checklistTemplate.code'),
      title: await this.i18n.translate(
        'import.checklistTemplate.details.title',
      ),
      description: await this.i18n.translate(
        'import.checklistTemplate.details.description',
      ),
      obligatoryStr: await this.i18n.translate(
        'import.checklistTemplate.details.obligatory',
      ),
    };

    const [dataCheckList, resultErrorCheckList] = await this.handleWorkbook(
      workbook,
      TEMPLATE_CHECK_LIST,
      headerCheckListTemplate,
      await this.i18n.translate('import.sheetName.Sheet1'),
    );

    const [dataDetail, resultError] = await this.handleWorkbook(
      workbook,
      TEMPLATE_CHECK_LIST_DETAIL,
      headerCheckListDetail,
      await this.i18n.translate('import.sheetName.Sheet2'),
    );
    if (
      dataCheckList[0]?.statusCode === ResponseCodeEnum.NOT_FOUND ||
      dataDetail[0]?.statusCode === ResponseCodeEnum.NOT_FOUND
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(dataCheckList[0]?.message || dataDetail[0]?.message)
        .build();
    }

    const yes = await this.i18n.translate('import.obligatory.yes');

    const detailMapByCode = dataDetail.reduce((preMap, detail) => {
      detail.obligatory =
        detail.obligatoryStr === yes ? OBLIGATORY_ENUM.YES : OBLIGATORY_ENUM.NO;

      preMap[detail.templateCode] = has(preMap, detail.templateCode)
        ? preMap[detail.templateCode].concat(detail)
        : [detail];
      return preMap;
    }, {});
    dataCheckList.forEach((checkList, index) => {
      dataCheckList[index].details = detailMapByCode[checkList.code] ?? [];
    });
    const { dataError, dataSuccess } =
      await this.checkListTemplateService.import(dataCheckList);

    if (!isEmpty(dataError)) {
      return new ResponseBuilder({
        dataSuccess,
        dataError: [...resultError, ...resultErrorCheckList, ...dataError],
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    return new ResponseBuilder({
      dataSuccess,
      dataError: [...resultError, ...resultErrorCheckList, ...dataError],
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async importAccreditationTemplates(workbook: any): Promise<any> {
    const headerAccreditationTemplate = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.accreditationTemplate.code'),
      name: await this.i18n.translate('import.accreditationTemplate.name'),
      periodic: await this.i18n.translate(
        'import.accreditationTemplate.periodic',
      ),
      activeTime: await this.i18n.translate(
        'import.accreditationTemplate.activeTime',
      ),
      description: await this.i18n.translate(
        'import.accreditationTemplate.description',
      ),
    };

    const headerAccreditationDetail = {
      templateCode: await this.i18n.translate(
        'import.accreditationTemplate.code',
      ),
      title: await this.i18n.translate(
        'import.accreditationTemplate.details.title',
      ),
      obligatoryStr: await this.i18n.translate(
        'import.accreditationTemplate.details.obligatory',
      ),
      description: await this.i18n.translate(
        'import.accreditationTemplate.details.description',
      ),
    };

    const [dataAccreditation, resultErrorAccreditation] =
      await this.handleWorkbook(
        workbook,
        TEMPLATE_ACCREDITATION,
        headerAccreditationTemplate,
        await this.i18n.translate('import.sheetName.Sheet1'),
      );

    const [dataDetail, resultErrorDetail] = await this.handleWorkbook(
      workbook,
      TEMPLATE_ACCREDITATION_DETAIL,
      headerAccreditationDetail,
      await this.i18n.translate('import.sheetName.Sheet2'),
    );
    if (
      dataAccreditation[0]?.statusCode === ResponseCodeEnum.NOT_FOUND ||
      dataDetail[0]?.statusCode === ResponseCodeEnum.NOT_FOUND
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(dataAccreditation[0]?.message || dataDetail[0]?.message)
        .build();
    }

    const yes = await this.i18n.translate('import.obligatory.yes');

    const detailMapByCode = dataDetail.reduce((preMap, detail) => {
      detail.obligatory =
        detail.obligatoryStr === yes ? OBLIGATORY_ENUM.YES : OBLIGATORY_ENUM.NO;

      preMap[detail.templateCode] = has(preMap, detail.templateCode)
        ? preMap[detail.templateCode].concat(detail)
        : [detail];
      return preMap;
    }, {});
    dataAccreditation.forEach((Accreditation, index) => {
      dataAccreditation[index].details =
        detailMapByCode[Accreditation.code] ?? [];
    });
    const { dataError, dataSuccess } =
      await this.accreditationTemplateService.import(dataAccreditation);

    if (!isEmpty(dataError)) {
      return new ResponseBuilder({
        dataSuccess,
        dataError: [
          ...resultErrorAccreditation,
          ...resultErrorDetail,
          ...dataError,
        ],
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    return new ResponseBuilder({
      dataSuccess,
      dataError: [
        ...resultErrorDetail,
        ...resultErrorAccreditation,
        ...dataError,
      ],
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async importInstallationTemplates(workbook: any): Promise<any> {
    const headerInstallationTemplate = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.installationTemplate.code'),
      name: await this.i18n.translate('import.installationTemplate.name'),
      description: await this.i18n.translate(
        'import.installationTemplate.description',
      ),
    };

    const headerInstallationDetail = {
      templateCode: await this.i18n.translate(
        'import.installationTemplate.code',
      ),
      title: await this.i18n.translate(
        'import.installationTemplate.detail.title',
      ),
      obligatoryStr: await this.i18n.translate(
        'import.installationTemplate.detail.obligatory',
      ),
      description: await this.i18n.translate(
        'import.installationTemplate.detail.description',
      ),
    };

    const [dataInstallation, resultErrorInstallation] =
      await this.handleWorkbook(
        workbook,
        TEMPLATE_INSTALLATION,
        headerInstallationTemplate,
        await this.i18n.translate('import.sheetName.Sheet1'),
      );
    const [dataDetail, resultErrorDetail] = await this.handleWorkbook(
      workbook,
      TEMPLATE_INSTALLATION_DETAIL,
      headerInstallationDetail,
      await this.i18n.translate('import.sheetName.Sheet2'),
    );

    if (
      dataInstallation[0]?.statusCode === ResponseCodeEnum.NOT_FOUND ||
      dataDetail[0]?.statusCode === ResponseCodeEnum.NOT_FOUND
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(dataInstallation[0]?.message || dataDetail[0]?.message)
        .build();
    }

    const textObligatoryYes = await this.i18n.translate(
      'import.obligatory.yes',
    );

    const detailMapByCode = dataDetail.reduce((preMap, detail) => {
      detail.obligatory =
        detail.obligatoryStr === textObligatoryYes
          ? OBLIGATORY_ENUM.YES
          : OBLIGATORY_ENUM.NO;

      preMap[detail.templateCode] = has(preMap, detail.templateCode)
        ? preMap[detail.templateCode].concat(detail)
        : [detail];
      return preMap;
    }, {});
    dataInstallation.forEach((installation, index) => {
      dataInstallation[index].details =
        detailMapByCode[installation.code] ?? [];
    });
    const { dataError, dataSuccess } =
      await this.installationTemplateService.import(dataInstallation);

    if (!isEmpty(dataError)) {
      return new ResponseBuilder({
        dataSuccess,
        dataError: [
          ...resultErrorDetail,
          ...resultErrorInstallation,
          ...dataError,
        ],
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    return new ResponseBuilder({
      dataSuccess,
      dataError: [
        ...resultErrorDetail,
        ...resultErrorInstallation,
        ...dataError,
      ],
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async importMaintenanceTemplates(workbook: any): Promise<any> {
    const headerMaintenanceTemplate = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.maintenanceTemplate.code'),
      name: await this.i18n.translate('import.maintenanceTemplate.name'),
      description: await this.i18n.translate(
        'import.maintenanceTemplate.description',
      ),
    };

    const headerMaintenanceDetail = {
      templateCode: await this.i18n.translate(
        'import.maintenanceTemplate.code',
      ),
      title: await this.i18n.translate(
        'import.maintenanceTemplate.detail.title',
      ),
      jobType: await this.i18n.translate(
        'import.maintenanceTemplate.detail.jobType',
      ),
      description: await this.i18n.translate(
        'import.maintenanceTemplate.detail.description',
      ),
      checklistTemplateCode: await this.i18n.translate(
        'import.maintenanceTemplate.detail.checklistTemplateCode',
      ),
      periodTime: await this.i18n.translate(
        'import.maintenanceTemplate.detail.periodTime',
      ),
      activeTime: await this.i18n.translate(
        'import.maintenanceTemplate.detail.activeTime',
      ),
      timeUnit: await this.i18n.translate(
        'import.maintenanceTemplate.detail.timeUnit',
      ),
      obligatory: await this.i18n.translate(
        'import.maintenanceTemplate.detail.obligatory',
      ),
    };

    const [dataMaintenance, resultErrorMaintenance] = await this.handleWorkbook(
      workbook,
      MAINTENANCE_TEMPLATE,
      headerMaintenanceTemplate,
      await this.i18n.translate('import.sheetName.Sheet1'),
    );
    const [dataDetail, resultError] = await this.handleWorkbook(
      workbook,
      MAINTENANCE_TEMPLATE_DETAIL,
      headerMaintenanceDetail,
      await this.i18n.translate('import.sheetName.Sheet2'),
    );

    if (
      dataMaintenance[0]?.statusCode === ResponseCodeEnum.NOT_FOUND ||
      dataDetail[0]?.statusCode === ResponseCodeEnum.NOT_FOUND
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(dataMaintenance[0]?.message || dataDetail[0]?.message)
        .build();
    }

    const textObligatoryYes = await this.i18n.translate(
      'import.obligatory.yes',
    );
    const checkType = await this.i18n.translate(
      'import.maintenanceTemplate.detail.check',
    );
    const timeUnit = new Map();
    timeUnit.set('Ngày', MAINTENANCE_PERIOD_UNIT.DAY);
    timeUnit.set('Tháng', MAINTENANCE_PERIOD_UNIT.MONTH);
    timeUnit.set('Năm', MAINTENANCE_PERIOD_UNIT.YEAR);

    const detailMapByCode = dataDetail.reduce((total, detail) => {
      detail.obligatory =
        detail.obligatory === textObligatoryYes
          ? OBLIGATORY_ENUM.YES
          : OBLIGATORY_ENUM.NO;
      detail.jobType =
        detail.jobType === checkType
          ? MAINTENANCE_JOB_TYPE.CHECK
          : MAINTENANCE_JOB_TYPE.MAINTENANCE;
      detail.timeUnit = timeUnit.get(detail.timeUnit);
      total[detail.templateCode] = has(total, detail.templateCode)
        ? total[detail.templateCode].concat(detail)
        : [detail];
      return total;
    }, {});
    dataMaintenance.forEach((Maintenance, index) => {
      dataMaintenance[index].details = detailMapByCode[Maintenance.code] ?? [];
    });
    const { dataError, dataSuccess } =
      await this.maintenanceTemplateService.import(dataMaintenance);

    if (!isEmpty(dataError)) {
      return new ResponseBuilder({
        dataSuccess,
        dataError: [...resultError, ...dataError, ...resultErrorMaintenance],
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    return new ResponseBuilder({
      dataSuccess,
      dataError: [...resultError, ...dataError, ...resultErrorMaintenance],
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async importMaintenanceTeam(workbook: any): Promise<any> {
    const headerMaintenanceTeam = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.maintenanceTeam.code'),
      name: await this.i18n.translate('import.maintenanceTeam.name'),
      factoryCode: await this.i18n.translate(
        'import.maintenanceTeam.factoryCode',
      ),
      deviceGroupCodes: await this.i18n.translate(
        'import.maintenanceTeam.deviceGroupCodes',
      ),
      areaCodes: await this.i18n.translate('import.maintenanceTeam.areaCodes'),
      description: await this.i18n.translate(
        'import.maintenanceTeam.description',
      ),
    };

    const headerMaintenanceTeamMember = {
      maintenanceTeamCode: await this.i18n.translate(
        'import.maintenanceTeam.code',
      ),
      username: await this.i18n.translate(
        'import.maintenanceTeam.members.username',
      ),
      role: await this.i18n.translate('import.maintenanceTeam.members.role'),
      areaCodes: await this.i18n.translate(
        'import.maintenanceTeam.members.areaCodes',
      ),
      deviceGroupCodes: await this.i18n.translate(
        'import.maintenanceTeam.members.deviceGroupCodes',
      ),
    };

    const [dataMaintenanceTeam, resultErrorMaintenanceTeam] =
      await this.handleWorkbook(
        workbook,
        MAINTENANCE_TEAM,
        headerMaintenanceTeam,
        await this.i18n.translate('import.sheetName.Sheet1'),
      );

    const [dataMember, resultErrorMember] = await this.handleWorkbook(
      workbook,
      MAINTENANCE_TEAM_MEMBER,
      headerMaintenanceTeamMember,
      await this.i18n.translate('import.sheetName.Sheet2'),
    );
    if (
      dataMaintenanceTeam[0]?.statusCode === ResponseCodeEnum.NOT_FOUND ||
      dataMember[0]?.statusCode === ResponseCodeEnum.NOT_FOUND
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(dataMaintenanceTeam[0]?.message || dataMember[0]?.message)
        .build();
    }

    const memberMapByCode = groupBy(dataMember, 'maintenanceTeamCode');
    dataMaintenanceTeam.forEach((maintenanceTeam, index) => {
      dataMaintenanceTeam[index].members =
        memberMapByCode[maintenanceTeam.code] ?? [];
    });
    const { dataError, dataSuccess } = await this.maintenanceTeamService.import(
      dataMaintenanceTeam,
    );

    if (!isEmpty(dataError)) {
      return new ResponseBuilder({
        dataSuccess,
        dataError: [
          ...resultErrorMaintenanceTeam,
          ...resultErrorMember,
          ...dataError,
        ],
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    return new ResponseBuilder({
      dataSuccess,
      dataError: [
        ...resultErrorMaintenanceTeam,
        ...resultErrorMember,
        ...dataError,
      ],
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async handleWorkbook(
    workbook: any,
    template: any,
    header: any,
    sheetName: any,
  ) {
    const sizeHeader = Object.keys(header).length;
    const templateMap = new Map(
      Object.keys(template).map((key) => [key, template[key]]),
    );
    const templateKeyMap = new Map(
      Object.keys(template).map((key, index) => [index, key]),
    );
    const worksheet = workbook.getWorksheet(sheetName);
    return await this.getDataWorksheet(
      worksheet,
      templateMap,
      templateKeyMap,
      sizeHeader,
      header,
    );
  }

  private async getDataWorksheet(
    worksheet,
    templateMap,
    templateKeyMap,
    sizeHeader,
    header,
  ) {
    const data: any[] = [];
    let dataError = [];
    let isData = false;
    for (let i = 1; i <= worksheet?.rowCount; i++) {
      const row = worksheet.getRow(i);
      if (isData) {
        const obj: any = {};
        let error = false;
        obj['line'] = i;
        if (!row.cellCount) {
          break;
        }
        for (let j = 0; j < row.cellCount; j++) {
          const cell = row.getCell(j + 1);
          const cellValue =
            templateMap.get(templateKeyMap.get(j))?.type === 'string'
              ? cell.value?.toString()?.trim()
              : cell.value;
          obj[templateKeyMap.get(j)] = cellValue;

          error = await this.validateDataCell(
            header,
            templateMap.get(templateKeyMap.get(j)),
            cellValue,
          );
          if (error) {
            if (templateKeyMap.get(j) === ACTION_IMPORT_KEY.action.key) {
              return await this.validateDataUniqueCode(
                data,
                dataError,
                templateMap.get('code'),
              );
            }
            break;
          }
        }
        if (error) {
          dataError = dataError.concat({
            ...obj,
            action: obj.action?.toLocaleLowerCase(),
          });
          error = false;
        } else {
          data.push({ ...obj, action: obj.action?.toLocaleLowerCase() });
        }
      }
      if (row.cellCount === sizeHeader && !isData) {
        isData = true;
        for (let j = 0; j < row.cellCount; j++) {
          const cell = row.getCell(j + 1);

          if (header[templateKeyMap.get(j)] !== cell.value) {
            return [
              [
                {
                  statusCode: ResponseCodeEnum.NOT_FOUND,
                  message: await this.i18n.translate(
                    'error.HEADER_TEMPLATE_ERROR',
                    {
                      args: {
                        currentCell: cell.value ?? '',
                        headerCell: header[templateKeyMap.get(j)],
                      },
                    },
                  ),
                },
              ],
              [],
            ];
          }
        }
      }
      if (row.cellCount !== sizeHeader && !isData && row.cellCount !== 0) {
        return [
          [
            {
              statusCode: ResponseCodeEnum.NOT_FOUND,
              message: await this.i18n.translate(
                'error.HEADER_LENGTH_TEMPLATE_ERROR',
              ),
            },
          ],
        ];
      }
    }
    if (isEmpty(data) && isEmpty(dataError)) {
      return [
        [
          {
            statusCode: ResponseCodeEnum.NOT_FOUND,
            message: await this.i18n.translate('error.NOT_FOUND'),
          },
        ],
      ];
    }
    return await this.validateDataUniqueCode(
      data,
      dataError,
      templateMap.get('code'),
    );
  }

  async validateDataCell(header, template, value) {
    let error: any = '';
    // check not null
    if (template?.notNull) {
      if (
        (template?.type === 'string' && !value?.length) ||
        (isEmpty(value) && isNull(value))
      ) {
        error = true;
      }
    }

    // check key
    if (
      template?.key === TEMPLATE_DEVICE_GROUP.action.key &&
      value?.toLocaleLowerCase() !==
        (await this.i18n.translate('import.common.add').toLocaleLowerCase()) &&
      value?.toLocaleLowerCase() !==
        (await this.i18n.translate('import.common.edit'))
    ) {
      error = true;
    }

    // check string max length
    if (template?.maxLength && template.type === 'string') {
      error =
        value?.toString()?.trim()?.length > template.maxLength ? true : error;
    }
    return error;
  }

  async validateDataUniqueCode(
    data: any[],
    dataError: any[],
    templateCode: any,
  ) {
    const listCode = compact(
      data.map((i) => {
        return i?.code;
      }),
    );
    if (isEmpty(listCode) || templateCode?.unique === false)
      return [data, dataError];
    let dataDuplicate = getDataDuplicate(listCode);
    dataDuplicate = uniq(dataDuplicate);
    if (dataDuplicate.length > 0) {
      const newData: any[] = [];
      let newDataError = [...dataError];
      for (let i = 0; i < data.length; i++) {
        const item = data[i];
        if (dataDuplicate.includes(item.code)) {
          newDataError = newDataError.concat({
            ...item,
            action: item.action?.toLocaleLowerCase(),
          });
        } else {
          newData.push(item);
        }
      }
      return [newData, newDataError];
    }

    return [data, dataError];
  }

  private async importAreas(workbook: any): Promise<any> {
    const header = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.area.code'),
      name: await this.i18n.translate('import.area.name'),
      description: await this.i18n.translate('import.area.description'),
      factoryCode: await this.i18n.translate('import.area.factoryCode'),
    };
    const [data, resultError] = await this.handleWorkbook(
      workbook,
      TEMPLATE_AREA,
      header,
      await this.i18n.translate('import.sheetName.Sheet1'),
    );
    if (data[0]?.statusCode === ResponseCodeEnum.NOT_FOUND) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(data[0]?.message)
        .build();
    }

    const { dataError, dataSuccess } = await this.areaService.import(data);

    if (!isEmpty(dataError)) {
      return new ResponseBuilder({
        dataSuccess,
        dataError: [...resultError, ...dataError],
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    return new ResponseBuilder({
      dataSuccess,
      dataError: [...resultError, ...dataError],
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async importWarehouse(workbook: any): Promise<any> {
    const warehouseText = await this.i18n.translate('import.warehouse');
    const header = {
      action: await this.i18n.translate('import.common.action'),
      code: warehouseText.code,
      name: warehouseText.name,
      factoryCode: warehouseText.factoryCode,
      description: warehouseText.description,
    };

    const headerInventory = {
      warehouseCode: warehouseText.code,
      assetCode: warehouseText.inventoryAsset.assetCode,
      minStockQuantity: warehouseText.inventoryAsset.minStockQuantity,
      maxStockQuantity: warehouseText.inventoryAsset.maxStockQuantity,
    };

    const [data, resultError] = await this.handleWorkbook(
      workbook,
      TEMPLATE_WAREHOUSE,
      header,
      await this.i18n.translate('import.sheetName.Sheet1'),
    );

    if (data[0]?.statusCode === ResponseCodeEnum.NOT_FOUND) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(data[0]?.message)
        .build();
    }

    const [assetData, assetResultError] = await this.handleWorkbook(
      workbook,
      TEMPLATE_INVENTORY_ASSET,
      headerInventory,
      await this.i18n.translate('import.sheetName.Sheet2'),
    );
    if (assetData[0]?.statusCode === ResponseCodeEnum.NOT_FOUND) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(data[0]?.message)
        .build();
    }

    const { dataError, dataSuccess } = await this.warehouseService.import(
      data,
      assetData,
    );
    const status = isEmpty([...resultError, ...assetResultError, ...dataError])
      ? ResponseCodeEnum.SUCCESS
      : ResponseCodeEnum.BAD_REQUEST;
    return new ResponseBuilder({
      dataSuccess,
      dataError: [...resultError, ...assetResultError, ...dataError],
    })
      .withCode(status)
      .build();
  }

  private async importErrorTypes(workbook: any): Promise<any> {
    const header = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.errorType.code'),
      name: await this.i18n.translate('import.errorType.name'),
      description: await this.i18n.translate('import.errorType.description'),
      priority: await this.i18n.translate('import.errorType.priority'),
    };

    const [dataErrorType, resultError] = await this.handleWorkbook(
      workbook,
      TEMPLATE_ERROR_TYPE,
      header,
      await this.i18n.translate('import.sheetName.Sheet1'),
    );

    if (dataErrorType[0]?.statusCode === ResponseCodeEnum.NOT_FOUND) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(dataErrorType[0]?.message || dataErrorType[0]?.message)
        .build();
    }

    const { dataError, dataSuccess } = await this.errorTypeService.import(
      dataErrorType,
    );

    if (!isEmpty(dataError)) {
      return new ResponseBuilder({
        dataSuccess,
        dataError: [...resultError, ...dataError],
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    return new ResponseBuilder({
      dataSuccess,
      dataError: [...resultError, ...dataError],
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async importVendor(workbook: any): Promise<any> {
    const header = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.vendor.code'),
      name: await this.i18n.translate('import.vendor.name'),
      description: await this.i18n.translate('import.vendor.description'),
      address: await this.i18n.translate('import.vendor.address'),
      email: await this.i18n.translate('import.vendor.email'),
      phone: await this.i18n.translate('import.vendor.phone'),
      fax: await this.i18n.translate('import.vendor.fax'),
      taxCode: await this.i18n.translate('import.vendor.taxCode'),
      contactUser: await this.i18n.translate('import.vendor.contactUser'),
    };

    const [data, resultError] = await this.handleWorkbook(
      workbook,
      TEMPLATE_VENDOR,
      header,
      await this.i18n.translate('import.sheetName.Sheet1'),
    );

    if (data[0]?.statusCode === ResponseCodeEnum.NOT_FOUND) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(data[0]?.message)
        .build();
    }

    const { dataError, dataSuccess } = await this.vendorService.import(data);

    if (!isEmpty(dataError)) {
      return new ResponseBuilder({
        dataSuccess,
        dataError: [...resultError, ...dataError],
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    return new ResponseBuilder({
      dataSuccess,
      dataError: [...resultError, ...dataError],
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async importDeviceType(workbook: any): Promise<any> {
    const header = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.deviceType.code'),
      name: await this.i18n.translate('import.deviceType.name'),
      description: await this.i18n.translate('import.deviceType.description'),
    };

    const [data, resultError] = await this.handleWorkbook(
      workbook,
      TEMPLATE_DEVICE_TYPE,
      header,
      await this.i18n.translate('import.sheetName.Sheet1'),
    );
    if (data[0]?.statusCode === ResponseCodeEnum.NOT_FOUND) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(data[0]?.message)
        .build();
    }

    const { dataError, dataSuccess } = await this.deviceTypeService.import(
      data,
    );
    if (!isEmpty(dataError)) {
      return new ResponseBuilder({
        dataSuccess,
        dataError: [...resultError, ...dataError],
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    return new ResponseBuilder({
      dataSuccess,
      dataError: [...resultError, ...dataError],
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async importDeviceName(workbook: any): Promise<any> {
    const header = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.deviceName.code'),
      name: await this.i18n.translate('import.deviceName.name'),
      description: await this.i18n.translate('import.deviceName.description'),
    };

    const [data, resultError] = await this.handleWorkbook(
      workbook,
      TEMPLATE_DEVICE_NAME,
      header,
      await this.i18n.translate('import.sheetName.Sheet1'),
    );
    if (data[0]?.statusCode === ResponseCodeEnum.NOT_FOUND) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(data[0]?.message)
        .build();
    }

    const { dataError, dataSuccess } = await this.deviceNameService.import(
      data,
    );
    if (!isEmpty(dataError)) {
      return new ResponseBuilder({
        dataSuccess,
        dataError: [...resultError, ...dataError],
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    return new ResponseBuilder({
      dataSuccess,
      dataError: [...resultError, ...dataError],
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async importDevices(workbook: any, user: any): Promise<any> {
    const header = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.device.code'),
      deviceNameCode: await this.i18n.translate('import.device.deviceNameCode'),
      serial: await this.i18n.translate('import.device.serial'),
      actualSerial: await this.i18n.translate('import.device.actualSerial'),
      factoryCode: await this.i18n.translate('import.device.factoryCode'),
      areaCode: await this.i18n.translate('import.device.areaCode'),
      model: await this.i18n.translate('import.device.model'),
      vendorCode: await this.i18n.translate('import.device.vendorCode'),
      brand: await this.i18n.translate('import.device.brand'),
      creationDate: await this.i18n.translate('import.device.creationDate'),
      identificationNo: await this.i18n.translate(
        'import.device.identificationNo',
      ),
      deviceGroupCode: await this.i18n.translate(
        'import.device.deviceGroupCode',
      ),
      warehouseCode: await this.i18n.translate('import.device.warehouseCode'),
      depreciation: await this.i18n.translate('import.device.depreciation'),
      type: await this.i18n.translate('import.device.type'),
      manufactureDate: await this.i18n.translate(
        'import.device.manufactureDate',
      ),
      warrantyPeriod: await this.i18n.translate('import.device.warrantyPeriod'),
      initAccreditationDate: await this.i18n.translate(
        'import.device.initAccreditationDate',
      ),
      initMaintenanceDate: await this.i18n.translate(
        'import.device.initMaintenanceDate',
      ),
    };

    const [data, resultError] = await this.handleWorkbook(
      workbook,
      TEMPLATE_DEVICE,
      header,
      await this.i18n.translate('import.sheetName.Sheet1'),
    );

    if (data[0]?.statusCode === ResponseCodeEnum.NOT_FOUND) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(data[0]?.message)
        .build();
    }
    const { dataError, dataSuccess } = await this.deviceService.import(
      data,
      user,
    );

    if (!isEmpty(dataError)) {
      return new ResponseBuilder({
        dataSuccess,
        dataError: [...resultError, ...dataError],
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    return new ResponseBuilder({
      dataSuccess,
      dataError: [...resultError, ...dataError],
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async importArticleDeviceGroups(workbook: any): Promise<any> {
    const header = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.articleDeviceGroup.code'),
      name: await this.i18n.translate('import.articleDeviceGroup.name'),
      description: await this.i18n.translate(
        'import.articleDeviceGroup.description',
      ),
    };
    const [data, resultError] = await this.handleWorkbook(
      workbook,
      TEMPLATE_ARTICLE_DEVICE_GROUP,
      header,
      await this.i18n.translate('import.sheetName.Sheet1'),
    );

    if (data[0]?.statusCode === ResponseCodeEnum.NOT_FOUND) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(data[0]?.message)
        .build();
    }

    const { dataError, dataSuccess } =
      await this.articleDeviceGroupService.import(data);
    if (!isEmpty(dataError)) {
      return new ResponseBuilder({
        dataSuccess,
        dataError: [...resultError, ...dataError],
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    return new ResponseBuilder({
      dataSuccess,
      dataError: [...resultError, ...dataError],
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }
}
