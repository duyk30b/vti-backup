import { TypeEnum } from '@components/export/export.constant';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { PermissionWithRoleInterceptor } from '@core/interceptors/permission-with-role.interceptor';
import {
  Body,
  Controller,
  Inject,
  Post,
  UseInterceptors,
} from '@nestjs/common';
import { ApiConsumes, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IMPORT_ACCREDITATION_TEMPLATE_PERMISSION } from '@utils/permissions/accreditation-template';
import { IMPORT_AREA_PERMISSION } from '@utils/permissions/area';
import { IMPORT_ARTICLE_DEVICE_GROUP_PERMISSION } from '@utils/permissions/article-device-group';
import { IMPORT_ATTRIBUTE_TYPE_PERMISSION } from '@utils/permissions/attribute-type';
import { IMPORT_CHECKLIST_TEMPLATE_PERMISSION } from '@utils/permissions/checklist-template';
import { IMPORT_DEVICE_PERMISSION } from '@utils/permissions/device';
import { IMPORT_DEVICE_GROUP_PERMISSION } from '@utils/permissions/device-group';
import { IMPORT_DEVICE_TYPE_PERMISSION } from '@utils/permissions/device-type';
import { IMPORT_ERROR_TYPE_PERMISSION } from '@utils/permissions/error-type';
import { IMPORT_INSTALLATION_TEMPLATE_PERMISSION } from '@utils/permissions/installation-template';
import { IMPORT_MAINTENANCE_ATTRIBUTE_PERMISSION } from '@utils/permissions/maintenance-attribute';
import { IMPORT_MAINTENANCE_TEAM_PERMISSION } from '@utils/permissions/maintenance-team';
import { IMPORT_MAINTENANCE_TEMPLATE_PERMISSION } from '@utils/permissions/maintenance-template';
import { IMPORT_SUPPLY_PERMISSION } from '@utils/permissions/supply';
import { IMPORT_SUPPLY_GROUP_PERMISSION } from '@utils/permissions/supply-group';
import { IMPORT_VENDOR_PERMISSION } from '@utils/permissions/vendor';
import { isEmpty } from 'lodash';
import { ImportExcelRequest } from './dto/import-excel.request';
import { ImportExcelServiceInterface } from './interface/import-excel.service.interface';

@Controller('import')
export class ImportExcelController {
  constructor(
    @Inject('ImportExcelServiceInterface')
    private readonly importExcelService: ImportExcelServiceInterface,
  ) {}

  @PermissionCode(IMPORT_ACCREDITATION_TEMPLATE_PERMISSION.code)
  @Post(`/${TypeEnum.ACCREDITATION_TEMPLATE}`)
  @ApiOperation({
    tags: ['Import'],
    summary: 'Import accreditation',
    description: 'Import accreditation excel',
  })
  @ApiResponse({
    status: 200,
    description: 'Post import successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async importAccreditation(
    @Body() payload: ImportExcelRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importExcelService.import({
      ...request,
      type: TypeEnum.ACCREDITATION_TEMPLATE,
    });
  }

  @PermissionCode(IMPORT_AREA_PERMISSION.code)
  @Post(`/${TypeEnum.AREA}`)
  @ApiOperation({
    tags: ['Import'],
    summary: 'Import area',
    description: 'Import area excel',
  })
  @ApiResponse({
    status: 200,
    description: 'Post import successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async importarea(@Body() payload: ImportExcelRequest): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importExcelService.import({
      ...request,
      type: TypeEnum.AREA,
    });
  }

  @PermissionCode(IMPORT_ARTICLE_DEVICE_GROUP_PERMISSION.code)
  @Post(`/${TypeEnum.ARTICLE_DEVICE_GROUP}`)
  @ApiOperation({
    tags: ['Import'],
    summary: 'Import ArticleDeviceGroup',
    description: 'Import ArticleDeviceGroup excel',
  })
  @ApiResponse({
    status: 200,
    description: 'Post import successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async importArticleDeviceGroup(
    @Body() payload: ImportExcelRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importExcelService.import({
      ...request,
      type: TypeEnum.ARTICLE_DEVICE_GROUP,
    });
  }

  @PermissionCode(IMPORT_ATTRIBUTE_TYPE_PERMISSION.code)
  @Post(`/${TypeEnum.ATTRIBUTE_TYPE}`)
  @ApiOperation({
    tags: ['Import'],
    summary: 'Import AttributeType',
    description: 'Import AttributeType excel',
  })
  @ApiResponse({
    status: 200,
    description: 'Post import successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async importAttributeType(
    @Body() payload: ImportExcelRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importExcelService.import({
      ...request,
      type: TypeEnum.ATTRIBUTE_TYPE,
    });
  }

  @PermissionCode(IMPORT_CHECKLIST_TEMPLATE_PERMISSION.code)
  @Post(`/${TypeEnum.CHECKLIST_TEMPLATE}`)
  @ApiOperation({
    tags: ['Import'],
    summary: 'Import Checklist',
    description: 'Import Checklist excel',
  })
  @ApiResponse({
    status: 200,
    description: 'Post import successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async importChecklist(
    @Body() payload: ImportExcelRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importExcelService.import({
      ...request,
      type: TypeEnum.CHECKLIST_TEMPLATE,
    });
  }

  @PermissionCode(IMPORT_DEVICE_PERMISSION.code)
  @UseInterceptors(PermissionWithRoleInterceptor)
  @Post(`/${TypeEnum.DEVICE}`)
  @ApiOperation({
    tags: ['Import'],
    summary: 'Import Device',
    description: 'Import Device excel',
  })
  @ApiResponse({
    status: 200,
    description: 'Post import successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async importDevice(@Body() payload: ImportExcelRequest): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importExcelService.import({
      ...request,
      type: TypeEnum.DEVICE,
    });
  }

  @PermissionCode(IMPORT_DEVICE_GROUP_PERMISSION.code)
  @Post(`/${TypeEnum.DEVICE_GROUP}`)
  @ApiOperation({
    tags: ['Import'],
    summary: 'Import DeviceGroup',
    description: 'Import DeviceGroup excel',
  })
  @ApiResponse({
    status: 200,
    description: 'Post import successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async importDeviceGroup(
    @Body() payload: ImportExcelRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importExcelService.import({
      ...request,
      type: TypeEnum.DEVICE_GROUP,
    });
  }

  @PermissionCode(IMPORT_DEVICE_TYPE_PERMISSION.code)
  @Post(`/${TypeEnum.DEVICE_TYPE}`)
  @ApiOperation({
    tags: ['Import'],
    summary: 'Import DeviceType',
    description: 'Import DeviceType excel',
  })
  @ApiResponse({
    status: 200,
    description: 'Post import successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async importDeviceType(
    @Body() payload: ImportExcelRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importExcelService.import({
      ...request,
      type: TypeEnum.DEVICE_TYPE,
    });
  }

  @PermissionCode(IMPORT_ERROR_TYPE_PERMISSION.code)
  @Post(`/${TypeEnum.ERROR_TYPE}`)
  @ApiOperation({
    tags: ['Import'],
    summary: 'Import ErrorType',
    description: 'Import ErrorType excel',
  })
  @ApiResponse({
    status: 200,
    description: 'Post import successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async importErrorType(
    @Body() payload: ImportExcelRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importExcelService.import({
      ...request,
      type: TypeEnum.ERROR_TYPE,
    });
  }

  @PermissionCode(IMPORT_INSTALLATION_TEMPLATE_PERMISSION.code)
  @Post(`/${TypeEnum.INSTALLATION_TEMPLATE}`)
  @ApiOperation({
    tags: ['Import'],
    summary: 'Import Installation',
    description: 'Import Installation excel',
  })
  @ApiResponse({
    status: 200,
    description: 'Post import successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async importInstallation(
    @Body() payload: ImportExcelRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importExcelService.import({
      ...request,
      type: TypeEnum.INSTALLATION_TEMPLATE,
    });
  }

  @PermissionCode(IMPORT_MAINTENANCE_ATTRIBUTE_PERMISSION.code)
  @Post(`/${TypeEnum.MAINTENANCE_ATTRIBUTE}`)
  @ApiOperation({
    tags: ['Import'],
    summary: 'Import MaintenanceAttribute',
    description: 'Import MaintenanceAttribute excePl',
  })
  @ApiResponse({
    status: 200,
    description: 'Post import successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async importMaintenanceAttribute(
    @Body() payload: ImportExcelRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importExcelService.import({
      ...request,
      type: TypeEnum.MAINTENANCE_ATTRIBUTE,
    });
  }

  @PermissionCode(IMPORT_MAINTENANCE_TEAM_PERMISSION.code)
  @Post(`/${TypeEnum.MAINTENANCE_TEAM}`)
  @ApiOperation({
    tags: ['Import'],
    summary: 'Import MaintenanceTeam',
    description: 'Import MaintenanceTeam excel',
  })
  @ApiResponse({
    status: 200,
    description: 'Post import successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async importMaintenanceTeam(
    @Body() payload: ImportExcelRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importExcelService.import({
      ...request,
      type: TypeEnum.MAINTENANCE_TEAM,
    });
  }

  @PermissionCode(IMPORT_MAINTENANCE_TEMPLATE_PERMISSION.code)
  @Post(`/${TypeEnum.MAINTENANCE_TEMPLATE}`)
  @ApiOperation({
    tags: ['Import'],
    summary: 'Import Maintenance',
    description: 'Import Maintenance excel',
  })
  @ApiResponse({
    status: 200,
    description: 'Post import successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async importMaintenance(
    @Body() payload: ImportExcelRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importExcelService.import({
      ...request,
      type: TypeEnum.MAINTENANCE_TEMPLATE,
    });
  }

  @PermissionCode(IMPORT_SUPPLY_PERMISSION.code)
  @Post(`/${TypeEnum.SUPPLY}`)
  @ApiOperation({
    tags: ['Import'],
    summary: 'Import Supply',
    description: 'Import Supply excel',
  })
  @ApiResponse({
    status: 200,
    description: 'Post import successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async importSupply(@Body() payload: ImportExcelRequest): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importExcelService.import({
      ...request,
      type: TypeEnum.SUPPLY,
    });
  }
  @PermissionCode(IMPORT_SUPPLY_GROUP_PERMISSION.code)
  @Post(`/${TypeEnum.SUPPLY_GROUP}`)
  @ApiOperation({
    tags: ['Import'],
    summary: 'Import SupplyGroup',
    description: 'Import SupplyGroup excel',
  })
  @ApiResponse({
    status: 200,
    description: 'Post import successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async importSupplyGroup(
    @Body() payload: ImportExcelRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importExcelService.import({
      ...request,
      type: TypeEnum.SUPPLY_GROUP,
    });
  }

  @PermissionCode(IMPORT_VENDOR_PERMISSION.code)
  @Post(`/${TypeEnum.VENDOR}`)
  @ApiOperation({
    tags: ['Import'],
    summary: 'Import Vendor',
    description: 'Import Vendor excel',
  })
  @ApiResponse({
    status: 200,
    description: 'Post import successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async importVendor(@Body() payload: ImportExcelRequest): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importExcelService.import({
      ...request,
      type: TypeEnum.VENDOR,
    });
  }

  @Post(`/${TypeEnum.WAREHOUSE}`)
  @ApiOperation({
    tags: ['Import'],
    summary: 'Import Warehouse',
    description: 'Import Warehouse excel',
  })
  @ApiResponse({
    status: 200,
    description: 'Post import successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async importWarehouse(
    @Body() payload: ImportExcelRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importExcelService.import({
      ...request,
      type: TypeEnum.WAREHOUSE,
    });
  }

  @Post(`/${TypeEnum.DEVICE_NAME}`)
  @ApiOperation({
    tags: ['Import'],
    summary: 'Import Device Name',
    description: 'Import Device Name excel',
  })
  @ApiResponse({
    status: 200,
    description: 'Post import successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async importDeviceName(
    @Body() payload: ImportExcelRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importExcelService.import({
      ...request,
      type: TypeEnum.DEVICE_NAME,
    });
  }

  @Post(`/${TypeEnum.INVENTORY_SUPPLY}`)
  @ApiOperation({
    tags: ['Import'],
    summary: 'Import Device Name',
    description: 'Import Device Name excel',
  })
  @ApiResponse({
    status: 200,
    description: 'Post import successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async importInventory(
    @Body() payload: ImportExcelRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.importExcelService.import({
      ...request,
      type: TypeEnum.INVENTORY_SUPPLY,
    });
  }
}
