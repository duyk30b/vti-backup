import { INSTALLATION_TEMPLATE_CONST } from './../installation-template/installation-template.constant';
import { MAINTENANCE_ATTRIBUTE_CONST } from '@components/maintenance-attribute/maintenance-attribute.constant';
import { SUPPLY_GROUP_CONST } from '@components/supply-group/supply-group.constant';
import { SUPPLY_CONST } from '@components/supply/supply.constant';
import { CHECKLIST_TEMPLATE_CONST } from '@components/checklist-template/checklist-template.constant';
import { MAINTENANCE_TEAM_CONST } from '@components/maintenance-team/maintenance-team.constant';
import { DEVICE_GROUP_CONST } from '@components/device-group/device-group.constant';
import { ERROR_TYPE_CONST } from '@components/error-type/error-type.constant';
import { ATTRIBUTE_TYPE_CONST } from '@components/attribute-type/attribute-type.constant';
import { VENDOR_CONST } from '@components/vendor/vendor.constant';
import { AREA_CONST } from '@components/area/area.constant';
import { DEVICE_CONST } from '@components/device/device.constant';
import { ACCREDITATION_TEMPLATE_CONST } from '@components/accreditation-template/accreditation-template.constant';
import { DEVICE_TYPE_CONST } from '@components/device-type/device-type.constant';
import { ARTICLE_DEVICE_GROUP_CONST } from '@components/article-device-group/article-device-group.constant';
import { MAINTENANCE_TEMPLATE_CONST } from '@components/maintenance-template/maintenance-template.constant';
import { TypeEnum } from '@components/export/export.constant';
import { DEVICE_NAME_CONST } from '@components/device-name/device-name.constant';
import { WAREHOUSE_CONST } from '@components/warehouse/warehouse.constant';
import { UNIT_CONST } from '@components/item/item.constant';

export const ACTION_IMPORT_KEY = {
  action: {
    key: 'action',
    notNull: true,
  },
};

export const CAN_IMPORT_WITHOUT_ROLE_ADMIN = [TypeEnum.SUPPLY];

export const TEMPLATE_DEVICE_GROUP = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    minLength: DEVICE_GROUP_CONST.CODE.MIN_LENGTH,
    maxLength: DEVICE_GROUP_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: DEVICE_GROUP_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },

  installationTemplateCode: {
    key: 'installationTemplateCode',
    type: 'string',
    minLength: INSTALLATION_TEMPLATE_CONST.CODE.MIN_LENGTH,
    maxLength: INSTALLATION_TEMPLATE_CONST.CODE.MAX_LENGTH,
    notNull: false,
  },
  accreditationTemplateCode: {
    key: 'accreditationTemplateCode',
    type: 'string',
    minLength: ACCREDITATION_TEMPLATE_CONST.CODE.MIN_LENGTH,
    maxLength: ACCREDITATION_TEMPLATE_CONST.CODE.MAX_LENGTH,
    notNull: false,
  },
  errorTypeCodes: {
    key: 'errorTypeCodes',
    type: 'string',
    notNull: true,
  },
  articleDeviceGroupCode: {
    key: 'articleDeviceGroupCode',
    type: 'string',
    minLength: ARTICLE_DEVICE_GROUP_CONST.CODE.MIN_LENGTH,
    maxLength: ARTICLE_DEVICE_GROUP_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  maintenanceAttributeCode: {
    key: 'maintenanceAttributeCode',
    type: 'string',
    minLength: MAINTENANCE_ATTRIBUTE_CONST.CODE.MIN_LENGTH,
    maxLength: MAINTENANCE_ATTRIBUTE_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  attributeTypeCodes: {
    key: 'attributeTypeCodes',
    type: 'string',
    notNull: true,
  },
  maintenanceTemplateCode: {
    key: 'maintenanceTemplateCode',
    type: 'string',
    minLength: MAINTENANCE_TEMPLATE_CONST.CODE.MIN_LENGTH,
    maxLength: MAINTENANCE_TEMPLATE_CONST.CODE.MAX_LENGTH,
    notNull: false,
  },
  frequency: {
    key: 'frequency',
    type: 'number',
    notNull: true,
  },
  canUpdateStatus: {
    key: 'canUpdateStatus',
    type: 'string',
    notNull: true,
  },
  symbol: {
    key: 'symbol',
    type: 'string',
    notNull: true,
  },
  normGenerateJob: {
    key: 'normGenerateJob',
    type: 'number',
    notNull: false,
  },
};
export const TEMPLATE_DEVICE_GROUP_SUPPLIES = {
  deviceGroupCode: {
    key: 'deviceGroupCode',
    type: 'string',
    minLength: DEVICE_GROUP_CONST.CODE.MIN_LENGTH,
    maxLength: DEVICE_GROUP_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },

  supplyCode: {
    key: 'supplyCode',
    type: 'string',
    minLength: SUPPLY_CONST.CODE.MIN_LENGTH,
    maxLength: SUPPLY_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  quantity: {
    key: 'quantity',
    type: 'number',
    notNull: true,
  },
  estimateUsedTime: {
    key: 'estimateUsedTime',
    type: 'number',
    notNull: true,
  },
  canFixable: {
    key: 'canFixable',
    type: 'string',
    notNull: true,
  },
};
export const TEMPLATE_DEVICE_GROUP_MAINTENANCE_INDEX = {
  deviceGroupCode: {
    key: 'deviceGroupCode',
    type: 'string',
    minLength: DEVICE_GROUP_CONST.CODE.MIN_LENGTH,
    maxLength: DEVICE_GROUP_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  supplyCode: {
    key: 'supplyCode',
    type: 'string',
    minLength: DEVICE_GROUP_CONST.CODE.MIN_LENGTH,
    maxLength: DEVICE_GROUP_CONST.CODE.MAX_LENGTH,
    notNull: false,
  },
  maintenanceFrequency: {
    key: 'maintenanceFrequency',
    type: 'number',
    notNull: false,
  },

  mtbf: {
    key: 'mtbf',
    type: 'number',
    notNull: true,
  },
  mttr: {
    key: 'mttr',
    type: 'number',
    notNull: true,
  },
  mtta: {
    key: 'mtta',
    type: 'number',
    notNull: true,
  },
  mttf: {
    key: 'mttf',
    type: 'number',
    notNull: true,
  },
};

export const TEMPLATE_MAINTENANCE_ATTRIBUTE = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    minLength: MAINTENANCE_ATTRIBUTE_CONST.CODE.MIN_LENGTH,
    maxLength: MAINTENANCE_ATTRIBUTE_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: MAINTENANCE_ATTRIBUTE_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: MAINTENANCE_ATTRIBUTE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
};

export const TEMPLATE_ATTRIBUTE_TYPE = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    minLength: ATTRIBUTE_TYPE_CONST.CODE.MIN_LENGTH,
    maxLength: ATTRIBUTE_TYPE_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: ATTRIBUTE_TYPE_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: ATTRIBUTE_TYPE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
  unitCode: {
    key: 'unit',
    type: 'string',
    minLength: UNIT_CONST.CODE.MIN_LENGTH,
    maxLength: UNIT_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
};

export const TEMPLATE_SUPPLY = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    minLength: SUPPLY_CONST.CODE.MIN_LENGTH,
    maxLength: SUPPLY_CONST.CODE.MAX_LENGTH,
    notNull: true,
    unique: false,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: SUPPLY_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  nameOther: {
    key: 'nameOther',
    type: 'string',
    maxLength: SUPPLY_CONST.NAME.MAX_LENGTH,
    notNull: false,
  },
  supplyTypeName: {
    key: 'supplyTypeName',
    type: 'string',
    notNull: true,
  },
  supplyGroupCode: {
    key: 'supplyGroupCode',
    type: 'string',
    minLength: SUPPLY_GROUP_CONST.CODE.MIN_LENGTH,
    maxLength: SUPPLY_GROUP_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  unitCode: {
    key: 'unitCode',
    type: 'string',
    minLength: UNIT_CONST.CODE.MIN_LENGTH,
    maxLength: UNIT_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  vendorCode: {
    key: 'vendorCode',
    type: 'string',
    minLength: VENDOR_CONST.CODE.MIN_LENGTH,
    maxLength: VENDOR_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  price: {
    key: 'price',
    type: 'number',
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: SUPPLY_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
};

export const TEMPLATE_SUPPLY_GROUP = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    minLength: SUPPLY_CONST.CODE.MIN_LENGTH,
    maxLength: SUPPLY_CONST.CODE.MAX_LENGTH,
    notNull: true,
    unique: false,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: SUPPLY_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: SUPPLY_GROUP_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
};

export const TEMPLATE_CHECK_LIST = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    minLength: CHECKLIST_TEMPLATE_CONST.CODE.MIN_LENGTH,
    maxLength: CHECKLIST_TEMPLATE_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: CHECKLIST_TEMPLATE_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: CHECKLIST_TEMPLATE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
};

export const TEMPLATE_CHECK_LIST_DETAIL = {
  templateCode: {
    key: 'templateCode',
    type: 'string',
    minLength: CHECKLIST_TEMPLATE_CONST.CODE.MIN_LENGTH,
    maxLength: CHECKLIST_TEMPLATE_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  title: {
    key: 'title',
    type: 'string',
    maxLength: CHECKLIST_TEMPLATE_CONST.TITLE.MAX_LENGTH,
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: CHECKLIST_TEMPLATE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: true,
  },
  obligatoryStr: {
    key: 'obligatoryStr',
    type: 'string',
    maxLength: 25,
    notNull: true,
  },
};

export const TEMPLATE_INSTALLATION = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    minLength: INSTALLATION_TEMPLATE_CONST.CODE.MIN_LENGTH,
    maxLength: INSTALLATION_TEMPLATE_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: INSTALLATION_TEMPLATE_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: INSTALLATION_TEMPLATE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
};

export const TEMPLATE_INSTALLATION_DETAIL = {
  templateCode: {
    key: 'templateCode',
    type: 'string',
    minLength: INSTALLATION_TEMPLATE_CONST.CODE.MIN_LENGTH,
    maxLength: INSTALLATION_TEMPLATE_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  title: {
    key: 'title',
    type: 'string',
    maxLength: INSTALLATION_TEMPLATE_CONST.TITLE.MAX_LENGTH,
    notNull: true,
  },
  obligatoryStr: {
    key: 'obligatoryStr',
    type: 'string',
    maxLength: 25,
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: INSTALLATION_TEMPLATE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
};

export const MAINTENANCE_TEMPLATE = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    minLength: MAINTENANCE_TEMPLATE_CONST.CODE.MIN_LENGTH,
    maxLength: MAINTENANCE_TEMPLATE_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: MAINTENANCE_TEMPLATE_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: MAINTENANCE_TEMPLATE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
};

export const MAINTENANCE_TEMPLATE_DETAIL = {
  templateCode: {
    key: 'templateCode',
    type: 'string',
    minLength: MAINTENANCE_TEMPLATE_CONST.CODE.MIN_LENGTH,
    maxLength: MAINTENANCE_TEMPLATE_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  title: {
    key: 'title',
    type: 'string',
    maxLength: MAINTENANCE_TEMPLATE_CONST.TITLE.MAX_LENGTH,
    notNull: true,
  },
  jobType: {
    key: 'jobType',
    type: 'string',
    notNull: false,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: MAINTENANCE_TEMPLATE_CONST.TITLE.MAX_LENGTH,
    notNull: false,
  },
  checklistTemplateCode: {
    key: 'checklistTemplateCode',
    type: 'string',
    maxLength: MAINTENANCE_TEMPLATE_CONST.TITLE.MAX_LENGTH,
    notNull: false,
  },
  periodTime: {
    key: 'periodTime',
    type: 'number',
    notNull: true,
  },
  activeTime: {
    key: 'activeTime',
    type: 'number',
    notNull: true,
  },
  timeUnit: {
    key: 'timeUnit',
    type: 'string',
    notNull: false,
  },
  obligatory: {
    key: 'obligatory',
    type: 'string',
    maxLength: 25,
    notNull: true,
  },
};

export const MAINTENANCE_TEAM = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    maxLength: MAINTENANCE_TEAM_CONST.CODE.MAX_LENGTH,
    minLength: MAINTENANCE_TEAM_CONST.CODE.MIN_LENGTH,
    notNull: true,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: MAINTENANCE_TEAM_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  factoryCode: {
    key: 'factoryCode',
    type: 'string',
    minLength: MAINTENANCE_TEAM_CONST.CODE.MIN_LENGTH,
    maxLength: MAINTENANCE_TEAM_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  deviceGroupCodes: {
    key: 'deviceGroupCodes',
    type: 'string',
    notNull: true,
  },
  areaCodes: {
    key: 'areaCodes',
    type: 'string',
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: MAINTENANCE_TEAM_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
};

export const MAINTENANCE_TEAM_MEMBER = {
  maintenanceTeamCode: {
    key: 'maintenanceTeamCode',
    type: 'string',
    notNull: true,
  },
  username: {
    key: 'username',
    type: 'string',
    notNull: true,
  },
  role: {
    key: 'role',
    type: 'string',
    notNull: true,
  },
  areaCodes: {
    key: 'areaCodes',
    type: 'string',
    notNull: true,
  },
  deviceGroupCodes: {
    key: 'deviceGroupCodes',
    type: 'string',
    notNull: true,
  },
};

export const TEMPLATE_AREA = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    minLength: AREA_CONST.CODE.MIN_LENGTH,
    maxLength: AREA_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: AREA_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: AREA_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
  factoryCode: {
    key: 'factoryCode',
    type: ' string',
    notNull: true,
  },
};

export const TEMPLATE_WAREHOUSE = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    minLength: WAREHOUSE_CONST.CODE.MIN_LENGTH,
    maxLength: WAREHOUSE_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: WAREHOUSE_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  factoryCode: {
    key: 'factoryCode',
    type: 'string',
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: WAREHOUSE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
};

export const TEMPLATE_INVENTORY_ASSET = {
  warehouseCode: {
    key: 'warehouseCode',
    type: 'string',
    notNull: true,
  },
  assetCode: {
    key: 'assetCode',
    type: 'string',
    notNull: true,
  },
  minStockQuantity: {
    key: 'minStockQuantity',
    type: 'number',
    notNull: true,
  },
  maxStockQuantity: {
    key: 'maxStockQuantity',
    type: 'number',
    notNull: true,
  },
};

export const TEMPLATE_ERROR_TYPE = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    minLength: ERROR_TYPE_CONST.CODE.MIN_LENGTH,
    maxLength: ERROR_TYPE_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: ERROR_TYPE_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: ERROR_TYPE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
  priority: {
    key: 'priority',
    type: 'string',
    notNull: true,
  },
};

export const TEMPLATE_VENDOR = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    minLength: VENDOR_CONST.CODE.MIN_LENGTH,
    maxLength: VENDOR_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: VENDOR_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: VENDOR_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
  address: {
    key: 'address',
    type: 'string',
    maxLength: VENDOR_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
  email: {
    key: 'email',
    type: 'string',
    maxLength: VENDOR_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
  phone: {
    key: 'phone',
    type: 'string',
    maxLength: 13,
    notNull: false,
  },
  fax: {
    key: 'fax',
    type: 'string',
    maxLength: VENDOR_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
  taxCode: {
    key: 'taxCode',
    type: 'string',
    maxLength: VENDOR_CONST.TAX_CODE.MAX_LENGTH,
    notNull: false,
  },
  contactUser: {
    key: 'contactUser',
    type: 'string',
    maxLength: VENDOR_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
};
export const TEMPLATE_DEVICE_TYPE = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    maxLength: DEVICE_TYPE_CONST.CODE.MAX_LENGTH,
    minLength: DEVICE_TYPE_CONST.CODE.MIN_LENGTH,
    notNull: true,
    unique: false,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: DEVICE_TYPE_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: DEVICE_TYPE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
};

export const TEMPLATE_DEVICE_NAME = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    maxLength: DEVICE_NAME_CONST.CODE.MAX_LENGTH,
    minLength: DEVICE_NAME_CONST.CODE.MIN_LENGTH,
    notNull: true,
    unique: false,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: DEVICE_NAME_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: DEVICE_NAME_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
};

export const TEMPLATE_DEVICE = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    maxLength: DEVICE_CONST.CODE.MAX_LENGTH,
    notNull: true,
    unique: false,
  },
  deviceNameCode: {
    key: 'deviceNameCode',
    type: 'string',
    maxLength: DEVICE_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  serial: {
    key: 'serial',
    type: 'string',
    maxLength: DEVICE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: true,
  },
  actualSerial: {
    key: 'actualSerial',
    type: 'string',
    maxLength: DEVICE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
  factoryCode: {
    key: 'factoryCode',
    type: 'string',
    maxLength: DEVICE_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  areaCode: {
    key: 'areaCode',
    type: 'string',
    length: DEVICE_CONST.CODE.MAX_LENGTH,
    notNull: false,
  },
  model: {
    key: 'model',
    type: 'string',
    maxLength: DEVICE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
  vendorCode: {
    key: 'vendorCode',
    type: 'string',
    length: DEVICE_CONST.CODE.MAX_LENGTH,
    notNull: false,
  },
  brand: {
    key: 'brand',
    type: 'string',
    maxLength: DEVICE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
  creationDate: {
    key: 'creationDate',
    type: 'string',
    maxLength: DEVICE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
  identificationNo: {
    key: 'identificationNo',
    type: 'string',
    maxLength: DEVICE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: true,
  },
  deviceGroupCode: {
    key: 'deviceGroupCode',
    type: 'string',
    length: DEVICE_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  warehouseCode: {
    key: 'warehouseCode',
    type: 'string',
    length: DEVICE_CONST.CODE.MAX_LENGTH,
    notNull: false,
  },
  depreciation: {
    key: 'depreciation',
    type: 'number',
    notNull: false,
  },
  type: {
    key: 'type',
    type: 'string',
    notNull: false,
  },
  manufactureDate: {
    key: 'manufactureDate',
    type: 'string',
    maxLength: DEVICE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
  warrantyPeriod: {
    key: 'warrantyPeriod',
    type: 'number',
    maxLength: DEVICE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
  initAccreditationDate: {
    key: 'initAccreditationDate',
    type: 'string',
    maxLength: DEVICE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: true,
  },
  initMaintenanceDate: {
    key: 'initMaintenanceDate',
    type: 'string',
    maxLength: DEVICE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: true,
  },
};

export const TEMPLATE_ARTICLE_DEVICE_GROUP = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    maxLength: ARTICLE_DEVICE_GROUP_CONST.CODE.MAX_LENGTH,
    minLength: ARTICLE_DEVICE_GROUP_CONST.CODE.MIN_LENGTH,
    notNull: true,
    unique: false,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: ARTICLE_DEVICE_GROUP_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: ARTICLE_DEVICE_GROUP_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
};

export const TEMPLATE_ACCREDITATION = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    minLength: ACCREDITATION_TEMPLATE_CONST.CODE.MIN_LENGTH,
    maxLength: ACCREDITATION_TEMPLATE_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: ACCREDITATION_TEMPLATE_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  periodic: {
    key: 'periodic',
    type: 'number',
    notNull: true,
  },
  activeTime: {
    key: 'activeTime',
    type: 'number',
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: ACCREDITATION_TEMPLATE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
};

export const TEMPLATE_ACCREDITATION_DETAIL = {
  templateCode: {
    key: 'templateCode',
    type: 'string',
    minLength: ACCREDITATION_TEMPLATE_CONST.CODE.MIN_LENGTH,
    maxLength: ACCREDITATION_TEMPLATE_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  title: {
    key: 'title',
    type: 'string',
    maxLength: ACCREDITATION_TEMPLATE_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  obligatoryStr: {
    key: 'obligatoryStr',
    type: 'string',
    maxLength: 25,
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: ACCREDITATION_TEMPLATE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
};
