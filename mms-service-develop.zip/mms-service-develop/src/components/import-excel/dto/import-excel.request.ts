import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional } from 'class-validator';

export class File {
  filename: string;
  data: ArrayBuffer;
  encoding: string;
  mimetype: string;
  limit: boolean;
}

export class ImportExcelRequest extends BaseDto {
  @ApiProperty()
  @IsOptional()
  type: number;

  @ApiProperty()
  @IsNotEmpty()
  files: File[];
}
