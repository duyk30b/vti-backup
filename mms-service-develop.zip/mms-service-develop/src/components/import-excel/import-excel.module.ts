import { SupplyGroupService } from '@components/supply-group/supply-group.service';
import { MaintenanceAttributeRepository } from 'src/repository/maintenance-attribute/maintenance-attribute.repository';
import { MaintenanceAttributeService } from '@components/maintenance-attribute/maintenance-attribute.service';
import { MaintenanceAttributeSchema } from 'src/models/maintenance-attribute/maintenance-attribute.schema';
import { AttributeTypeSchema } from 'src/models/attribute-type/attribute-type.schema';
import { AttributeTypeRepository } from 'src/repository/attribute-type/attribute-type.repository';
import { AttributeTypeService } from './../attribute-type/attribute-type.service';
import { SupplyGroupRepository } from 'src/repository/supply-group/supply-group.repository';
import { SupplyRepository } from 'src/repository/supply/supply.repository';
import { SupplyService } from './../supply/supply.service';
import { CheckListTemplateService } from './../checklist-template/checklist-template.service';
import { HistoryModule } from '@components/history/history.module';
import { UserService } from '@components/user/user.service';
import { Global, Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { DeviceGroupSchema } from 'src/models/device-group/device-group.schema';
import { MaintenanceTeamSchema } from 'src/models/maintenance-team/maintenance-team.schema';
import { SupplyGroupSchema } from 'src/models/supply-group/supply-group.schema';
import { DeviceGroupRepository } from 'src/repository/device-group/device-group.repository';
import { MaintenanceTeamRepository } from 'src/repository/maintenance-team/maintenance-team.repository';
import { ImportExcelController } from './import-excel.controller';
import { ImportExcelService } from './import-excel.service';
import { SupplySchema } from 'src/models/supply/supply.schema';
import { ChecklistTemplateSchema } from 'src/models/checklist-template/checklist-template.schema';
import { CheckListTemplateRepository } from 'src/repository/checklist-template/checklist-template.repository';
import { InstallationTemplateService } from '@components/installation-template/installation-template.service';
import { InstallationTemplateSchema } from 'src/models/installation-template/installation-template.schema';
import { InstallationTemplateRepository } from 'src/repository/installation-template/installation-template.repository';
import { MaintenanceTeamService } from '@components/maintenance-team/maintenance-team.service';
import { AreaService } from '@components/area/area.service';
import { AreaRepository } from 'src/repository/area/area.repository';
import { AreaSchema } from 'src/models/area/area.schema';
import { ErrorTypeSchema } from 'src/models/error-type/error-type.schema';
import { ErrorTypeRepository } from 'src/repository/error-type/error-type.repository';
import { ErrorTypeService } from '@components/error-type/error-type.service';
import { VendorService } from '@components/vendor/vendor.service';
import { VendorSchema } from 'src/models/vendor/vendor.schema';
import { VendorRepository } from 'src/repository/vendor/vendor.repository';
import { DeviceTypeService } from '@components/device-type/device-type.service';
import { DeviceTypeRepository } from 'src/repository/device-type/device-type.repository';
import { DeviceTypeSchema } from 'src/models/device-type/device-type.schema';
import { DeviceService } from '@components/device/device.service';
import { DeviceAssignmentRepository } from 'src/repository/device-assignment/device-assignment.repository';
import { JobRepository } from 'src/repository/job/job.repository';
import { DeviceAssignmentSchema } from 'src/models/device-assignment/device-assignment.schema';
import { JobSchema } from 'src/models/job/job.schema';
import { AccreditationTemplateRepository } from 'src/repository/accreditation-template/accreditation-template.repository';
import { AccreditationTemplateService } from '@components/accreditation-template/accreditation-template.service';
import { AccreditationTemplateSchema } from 'src/models/accreditation-template/accreditation-template.schema';
import { DeviceStatusSchema } from 'src/models/device-status/device-status.schema';
import { DeviceStatusRepository } from 'src/repository/device-status/device-status.repository';
import { ArticleDeviceGroupSchema } from 'src/models/article-device-group/article-device-group.schema';
import { ArticleDeviceGroupRepository } from 'src/repository/article-device-group/article-device-group.repository';
import { ArticleDeviceGroupService } from '@components/article-device-group/article-device-group.service';
import { DeviceGroupModule } from '@components/device-group/device-group.module';
import { MaintenanceIndexRepository } from 'src/repository/maintenance-index/maintenance-index.repository';
import { MaintenanceIndexSchema } from 'src/models/maintenance-index/maintenance-index.schema';
import { MaintenanceTemplateModule } from '@components/maintenance-template/maintenance-template.module';
import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { ConfigService } from '@config/config.service';
import { HistoryRepository } from 'src/repository/history/history.repository';
import { HistorySchema } from 'src/models/history/history.schema';
import { DeviceGroupCountService } from '@components/device-group-count/device-group-count.service';
import { DeviceGroupCountRepository } from 'src/repository/device-group-count/device-group-count.repository';
import { DeviceGroupCountSchema } from 'src/models/device-group-count/device-group-count.schema';
import { InventoryRepository } from 'src/repository/warehouse-inventories/inventory.repository';
import { DeviceNameSchema } from 'src/models/device-name/device-name.schema';
import { DeviceNameRepository } from 'src/repository/device-name/device-name.repository';
import { DeviceNameService } from '@components/device-name/device-name.service';
import { InventorySchema } from 'src/models/warehouse-inventories/inventory.schema';
import { DeviceModule } from '@components/device/device.module';
import { SupplyTypeRepository } from 'src/repository/supply-type/supply-type.repository';
import { SupplyTypeSchema } from 'src/models/supply-type/supply-type.schema';

@Global()
@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'DeviceGroup', schema: DeviceGroupSchema },
      { name: 'MaintenanceTeam', schema: MaintenanceTeamSchema },
      { name: 'SupplyGroup', schema: SupplyGroupSchema },
      { name: 'MaintenanceAttribute', schema: MaintenanceAttributeSchema },
      { name: 'AttributeType', schema: AttributeTypeSchema },
      { name: 'Supply', schema: SupplySchema },
      { name: 'SupplyGroup', schema: SupplyGroupSchema },
      { name: 'CheckListTemplate', schema: ChecklistTemplateSchema },
      { name: 'InstallationTemplate', schema: InstallationTemplateSchema },
      { name: 'Area', schema: AreaSchema },
      { name: 'ErrorTypeModel', schema: ErrorTypeSchema },
      { name: 'VendorModel', schema: VendorSchema },
      { name: 'DeviceType', schema: DeviceTypeSchema },
      { name: 'DeviceName', schema: DeviceNameSchema },
      { name: 'DeviceAssignment', schema: DeviceAssignmentSchema },
      { name: 'Job', schema: JobSchema },
      {
        name: 'AccreditationTemplateModel',
        schema: AccreditationTemplateSchema,
      },
      { name: 'DeviceStatus', schema: DeviceStatusSchema },
      { name: 'ArticleDeviceGroup', schema: ArticleDeviceGroupSchema },
      { name: 'MaintenanceIndex', schema: MaintenanceIndexSchema },
      { name: 'History', schema: HistorySchema },
      { name: 'DeviceGroupCount', schema: DeviceGroupCountSchema },
      { name: 'Inventory', schema: InventorySchema },
      { name: 'SupplyType', schema: SupplyTypeSchema },
    ]),
    HistoryModule,
    DeviceGroupModule,
    MaintenanceTemplateModule,
    WarehouseModule,
    DeviceModule,
  ],
  exports: [
    {
      provide: 'ImportExcelServiceInterface',
      useClass: ImportExcelService,
    },
  ],
  providers: [
    {
      provide: 'ImportExcelServiceInterface',
      useClass: ImportExcelService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'SupplyGroupServiceInterface',
      useClass: SupplyGroupService,
    },
    {
      provide: 'SupplyGroupRepositoryInterface',
      useClass: SupplyGroupRepository,
    },
    {
      provide: 'MaintenanceAttributeServiceInterface',
      useClass: MaintenanceAttributeService,
    },
    {
      provide: 'MaintenanceAttributeRepositoryInterface',
      useClass: MaintenanceAttributeRepository,
    },
    {
      provide: 'AttributeTypeServiceInterface',
      useClass: AttributeTypeService,
    },
    {
      provide: 'AttributeTypeRepositoryInterface',
      useClass: AttributeTypeRepository,
    },
    {
      provide: 'SupplyServiceInterface',
      useClass: SupplyService,
    },
    {
      provide: 'SupplyRepositoryInterface',
      useClass: SupplyRepository,
    },
    {
      provide: 'SupplyGroupRepositoryInterface',
      useClass: SupplyGroupRepository,
    },
    {
      provide: 'DeviceGroupRepositoryInterface',
      useClass: DeviceGroupRepository,
    },
    {
      provide: 'CheckListTemplateRepositoryInterface',
      useClass: CheckListTemplateRepository,
    },
    {
      provide: 'CheckListTemplateServiceInterface',
      useClass: CheckListTemplateService,
    },
    {
      provide: 'CheckListTemplateRepositoryInterface',
      useClass: CheckListTemplateRepository,
    },
    {
      provide: 'MaintenanceTeamRepositoryInterface',
      useClass: MaintenanceTeamRepository,
    },
    {
      provide: 'InstallationTemplateServiceInterface',
      useClass: InstallationTemplateService,
    },
    {
      provide: 'InstallationTemplateRepositoryInterface',
      useClass: InstallationTemplateRepository,
    },
    {
      provide: 'AccreditationTemplateServiceInterface',
      useClass: AccreditationTemplateService,
    },
    {
      provide: 'AccreditationTemplateRepositoryInterface',
      useClass: AccreditationTemplateRepository,
    },
    {
      provide: 'MaintenanceTeamServiceInterface',
      useClass: MaintenanceTeamService,
    },
    {
      provide: 'AreaRepositoryInterface',
      useClass: AreaRepository,
    },
    {
      provide: 'AreaServiceInterface',
      useClass: AreaService,
    },
    {
      provide: 'ErrorTypeRepositoryInterface',
      useClass: ErrorTypeRepository,
    },
    {
      provide: 'ErrorTypeServiceInterface',
      useClass: ErrorTypeService,
    },
    {
      provide: 'VendorServiceInterface',
      useClass: VendorService,
    },
    {
      provide: 'VendorRepositoryInterface',
      useClass: VendorRepository,
    },
    {
      provide: 'DeviceTypeServiceInterface',
      useClass: DeviceTypeService,
    },
    {
      provide: 'DeviceTypeRepositoryInterface',
      useClass: DeviceTypeRepository,
    },
    {
      provide: 'DeviceNameServiceInterface',
      useClass: DeviceNameService,
    },
    {
      provide: 'DeviceNameRepositoryInterface',
      useClass: DeviceNameRepository,
    },
    {
      provide: 'DeviceServiceInterface',
      useClass: DeviceService,
    },
    {
      provide: 'DeviceAssignmentRepositoryInterface',
      useClass: DeviceAssignmentRepository,
    },
    {
      provide: 'JobRepositoryInterface',
      useClass: JobRepository,
    },
    {
      provide: 'DeviceStatusRepositoryInterface',
      useClass: DeviceStatusRepository,
    },
    {
      provide: 'ArticleDeviceGroupRepositoryInterface',
      useClass: ArticleDeviceGroupRepository,
    },
    {
      provide: 'ArticleDeviceGroupServiceInterface',
      useClass: ArticleDeviceGroupService,
    },
    {
      provide: 'MaintenanceIndexRepositoryInterface',
      useClass: MaintenanceIndexRepository,
    },
    {
      provide: 'HistoryRepositoryInterface',
      useClass: HistoryRepository,
    },
    {
      provide: 'DeviceGroupCountServiceInterface',
      useClass: DeviceGroupCountService,
    },
    {
      provide: 'DeviceGroupCountRepositoryInterface',
      useClass: DeviceGroupCountRepository,
    },
    {
      provide: 'InventoryRepositoryInterface',
      useClass: InventoryRepository,
    },
    {
      provide: 'SupplyTypeRepositoryInterface',
      useClass: SupplyTypeRepository,
    },
    ConfigService,
  ],
  controllers: [ImportExcelController],
})
export class ImportExcelModule {}
