import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class DetailMaintenanceIndexResponse {
  @ApiProperty()
  @Expose()
  mttr: number;

  @ApiProperty()
  @Expose()
  mtta: number;

  @ApiProperty()
  @Expose()
  mttf: number;

  @ApiProperty()
  @Expose()
  mtbf: number;

  @ApiProperty()
  @Expose()
  maintenanceDateLatest: Date;

  @ApiProperty()
  @Expose()
  maintenanceDateNext: Date;

  @ApiProperty()
  @Expose()
  accreditationDateLatest: Date;

  @ApiProperty()
  @Expose()
  accreditationDateNext: Date;
}
