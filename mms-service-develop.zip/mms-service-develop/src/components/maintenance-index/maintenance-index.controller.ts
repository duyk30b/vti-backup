import { Controller, Inject, Injectable } from '@nestjs/common';
import { MaintenanceIndexServiceInterface } from './interface/maintenance-index.service.interface';

@Injectable()
@Controller('maintenance-index')
export class MaintenanceIndexController {
  constructor(
    @Inject('MaintenanceIndexServiceInterface')
    private readonly maintenanceIndexService: MaintenanceIndexServiceInterface,
  ) {}
}
