import { Inject, Injectable } from '@nestjs/common';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { MaintenanceIndexRepositoryInterface } from './interface/maintenance-index.repository.interface';
import { MaintenanceIndexServiceInterface } from './interface/maintenance-index.service.interface';

@Injectable()
export class MaintenanceIndexService
  implements MaintenanceIndexServiceInterface
{
  constructor(
    @Inject('MaintenanceIndexRepositoryInterface')
    private readonly maintenanceIndexRepository: MaintenanceIndexRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}
}
