export interface MaintenanceIndexServiceInterface {}
