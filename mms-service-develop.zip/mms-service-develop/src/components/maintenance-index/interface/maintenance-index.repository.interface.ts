import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { MaintenanceIndex } from 'src/models/maintenance-index/maintenance-index.model';

export interface MaintenanceIndexRepositoryInterface
  extends BaseInterfaceRepository<MaintenanceIndex> {
  createEntities(data: any): MaintenanceIndex[];
}
