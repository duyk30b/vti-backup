import { MongooseModule } from '@nestjs/mongoose';
import { Module } from '@nestjs/common';
import { MaintenanceIndexSchema } from 'src/models/maintenance-index/maintenance-index.schema';
import { MaintenanceIndexController } from './maintenance-index.controller';
import { MaintenanceIndexRepository } from 'src/repository/maintenance-index/maintenance-index.repository';
import { MaintenanceIndexService } from './maintenance-index.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'MaintenanceIndex', schema: MaintenanceIndexSchema },
    ]),
  ],
  controllers: [MaintenanceIndexController],
  providers: [
    {
      provide: 'MaintenanceIndexRepositoryInterface',
      useClass: MaintenanceIndexRepository,
    },
    {
      provide: 'MaintenanceIndexServiceInterface',
      useClass: MaintenanceIndexService,
    },
  ],
  exports: [
    {
      provide: 'MaintenanceIndexServiceInterface',
      useClass: MaintenanceIndexService,
    },
    {
      provide: 'MaintenanceIndexRepositoryInterface',
      useClass: MaintenanceIndexRepository,
    },
  ],
})
export class MaintenanceIndexModule {}
