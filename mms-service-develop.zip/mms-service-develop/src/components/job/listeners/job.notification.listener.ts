import { DeviceRepositoryInterface } from '@components/device/interface/device.repository.interface';
import { MaintenanceTeamRepositoryInterface } from '@components/maintenance-team/interface/maintenance-team.repository.interface';
import { MAINTENANCE_TEAM_ROLE } from '@components/maintenance-team/maintenance-team.constant';
import { EventRequestDto } from '@components/notification/dto/event.request.dto';
import { PushNotificationRequestDto } from '@components/notification/dto/notification.request.dto';
import { NotificationServiceInterface } from '@components/notification/interface/notification.service.interface';
import {
  NOTIFICATION_ENTITY_ENUM,
  TYPE_NOTIFICATION_RENDER_ACTION_ENUM,
} from '@components/notification/notification.const';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { DATE_FORMAT_NOTIFICATION } from '@constant/common';
import { NotificationListenerAbstract } from '@core/abstracts/notification.listener.abstract';
import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { flatMap, map, uniq } from 'lodash';
import * as moment from 'moment';
import { I18nService } from 'nestjs-i18n';
import { JobRepositoryInterface } from '../interface/job.repository.interface';
import { JOB_EVENTS_ENUM, JOB_STATUS_ENUM } from '../job.constant';
import { JobUtilInterface } from '@components/job/interface/job.util.interface';

@Injectable()
export class JobNotificationListener extends NotificationListenerAbstract {
  constructor(
    @Inject('NotificationServiceInterface')
    protected readonly notificationService: NotificationServiceInterface,
    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,
    @Inject('JobRepositoryInterface')
    protected readonly jobRepository: JobRepositoryInterface,
    @Inject('DeviceRepositoryInterface')
    protected readonly deviceRepository: DeviceRepositoryInterface,
    @Inject('MaintenanceTeamRepositoryInterface')
    protected readonly maintenanceTeamRepository: MaintenanceTeamRepositoryInterface,
    @Inject('JobUtilInterface')
    private readonly jobUtil: JobUtilInterface,
    private readonly i18n: I18nService,
  ) {
    super(notificationService);
  }

  @OnEvent(JOB_EVENTS_ENUM.CREATE)
  public async handleCreateJob(event: EventRequestDto) {
    try {
      const notificationRequest = new PushNotificationRequestDto();
      const { id } = event;
      const job = await this.jobRepository.findOneById(id);
      notificationRequest.title = await this.i18n.translate(
        'message.defineJob.notification.createJobTitle',
      );
      notificationRequest.action =
        // noti created thì action(điều hướng) sang assignment
        TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_ASSIGNMENT;
      const device = await this.deviceRepository.findOneById(job.deviceId);

      notificationRequest.content = (
        await this.i18n.translate(
          'message.defineJob.notification.createJobContent',
        )
      )
        .replace(
          '{type}',
          await this.i18n.translate(`message.defineJob.type.${job.type}`),
        )
        .replace(
          '{date}',
          moment(job.createdAt).format(DATE_FORMAT_NOTIFICATION),
        )
        .replace('{deviceCode}', device.code);
      notificationRequest.payload = this.generatePayload(
        event,
        NOTIFICATION_ENTITY_ENUM.JOB_LIST,
      );
      // @TODO filter maintenanceTeam with area
      const maintenanceTeams =
        await this.maintenanceTeamRepository.findAllByCondition({
          deviceGroupIds: device.deviceGroupId,
          factoryId: device.factoryId,
        });
      const leaders = flatMap(maintenanceTeams, 'members').filter(
        (member) => member.role === MAINTENANCE_TEAM_ROLE.LEADER,
      );

      const userIds = [...(map(leaders, 'userId') ?? [])];
      notificationRequest.userIds = userIds;
      notificationRequest.createdBy = event.fromUserId;

      return [
        await super.sendWebNotification(notificationRequest),
        await super.sendAppNotification(notificationRequest),
      ];
    } catch (error) {
      console.error(error);
    }
  }

  @OnEvent(JOB_EVENTS_ENUM.ASSIGNMENT)
  public async handleAssignmentJob(event: EventRequestDto) {
    try {
      const notificationRequest = new PushNotificationRequestDto();
      const { id, fromUserId } = event;
      const user = await this.userService.getDetailUser(fromUserId);
      const job = await this.jobRepository.findOneById(id);

      const { fullName, username } = user;
      notificationRequest.title = await this.i18n.translate(
        'message.defineJob.notification.assignmentTitle',
      );
      notificationRequest.content = (
        await this.i18n.translate(
          'message.defineJob.notification.assignmentContent',
        )
      )
        .replace('{username}', fullName || username)
        .replace('{code}', job.code);
      notificationRequest.action =
        // noti assigned thì action(điều hướng) sang xác nhận từ chối
        TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_CONFIRM_AND_REJECT;
      notificationRequest.payload = this.generatePayload(
        event,
        NOTIFICATION_ENTITY_ENUM.JOB_DETAIL,
      );
      notificationRequest.userIds = await this.jobUtil.getAssignMemberIds(
        job?.assign,
      );
      notificationRequest.createdBy = fromUserId;

      return [
        await super.sendWebNotification(notificationRequest),
        await super.sendAppNotification(notificationRequest),
      ];
    } catch (error) {
      console.error(error);
    }
  }

  @OnEvent(JOB_EVENTS_ENUM.CONFIRM)
  public async handleConfirmJob(event: EventRequestDto) {
    try {
      const notificationRequest = new PushNotificationRequestDto();
      const { id, fromUserId } = event;
      const user = await this.userService.getDetailUser(fromUserId);
      const job = await this.jobRepository.findOneById(id);

      const { fullName, username } = user;
      notificationRequest.title = await this.i18n.translate(
        'message.defineJob.notification.confirmTitle',
      );
      notificationRequest.content = (
        await this.i18n.translate(
          'message.defineJob.notification.confirmContent',
        )
      )
        .replace('{username}', fullName || username)
        .replace('{code}', job.code);
      notificationRequest.action =
        TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_VIEW;
      notificationRequest.payload = this.generatePayload(
        event,
        NOTIFICATION_ENTITY_ENUM.JOB_DETAIL,
      );

      const leader = await this.jobUtil.getAssignMaintenanceTeamLeader(
        job?.assign,
      );
      notificationRequest.userIds = [leader?.userId];
      notificationRequest.createdBy = fromUserId;

      return [
        await super.sendWebNotification(notificationRequest),
        await super.sendAppNotification(notificationRequest),
      ];
    } catch (error) {
      console.error(error);
    }
  }

  @OnEvent(JOB_EVENTS_ENUM.IN_PROGRESS)
  public async handleInProgressJob(event: EventRequestDto) {
    try {
      const notificationRequest = new PushNotificationRequestDto();
      const { id, fromUserId } = event;
      const user = await this.userService.getDetailUser(fromUserId);
      const job = await this.jobRepository.findOneById(id);

      const { fullName, username } = user;
      notificationRequest.title = await this.i18n.translate(
        'message.defineJob.notification.inProgressTitle',
      );
      notificationRequest.content = (
        await this.i18n.translate(
          'message.defineJob.notification.inProgressContent',
        )
      )
        .replace('{username}', fullName || username)
        .replace('{code}', job.code);
      notificationRequest.action =
        TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_VIEW;
      notificationRequest.payload = this.generatePayload(
        event,
        NOTIFICATION_ENTITY_ENUM.JOB_DETAIL,
      );

      const leader = await this.jobUtil.getAssignMaintenanceTeamLeader(
        job?.assign,
      );
      notificationRequest.userIds = [leader?.userId];
      notificationRequest.createdBy = fromUserId;
      return [
        await super.sendWebNotification(notificationRequest),
        await super.sendAppNotification(notificationRequest),
      ];
    } catch (error) {
      console.error(error);
    }
  }

  @OnEvent(JOB_EVENTS_ENUM.REJECT)
  public async handleRejectJob(event: EventRequestDto) {
    try {
      const notificationRequest = new PushNotificationRequestDto();
      const { id, fromUserId } = event;
      const user = await this.userService.getDetailUser(fromUserId);
      const job = await this.jobRepository.findOneById(id);

      const { fullName, username } = user;
      notificationRequest.title = await this.i18n.translate(
        'message.defineJob.notification.rejectTitle',
      );
      notificationRequest.content = (
        await this.i18n.translate(
          'message.defineJob.notification.rejectContent',
        )
      )
        .replace('{username}', fullName || username)
        .replace('{code}', job.code);
      notificationRequest.action =
        TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_VIEW;
      notificationRequest.payload = this.generatePayload(
        event,
        NOTIFICATION_ENTITY_ENUM.JOB_DETAIL,
      );

      // find leader of member
      const maintenanceTeam =
        await this.maintenanceTeamRepository.findOneByCondition({
          'members.userId': fromUserId,
        });
      const leader = maintenanceTeam?.members?.find(
        (member) => member.role === MAINTENANCE_TEAM_ROLE.LEADER,
      );
      notificationRequest.userIds = [leader?.userId];
      notificationRequest.createdBy = fromUserId;

      return [
        await super.sendWebNotification(notificationRequest),
        await super.sendAppNotification(notificationRequest),
      ];
    } catch (error) {
      console.error(error);
    }
  }

  @OnEvent(JOB_EVENTS_ENUM.COMPLETE)
  public async handleCompleteJob(event: EventRequestDto) {
    try {
      const notificationRequest = new PushNotificationRequestDto();
      const { id, fromUserId } = event;
      const user = await this.userService.getDetailUser(fromUserId);
      const job = await this.jobRepository.findOneById(id);

      const { fullName, username } = user;
      notificationRequest.title = await this.i18n.translate(
        'message.defineJob.notification.completeTitle',
      );
      notificationRequest.content = (
        await this.i18n.translate(
          'message.defineJob.notification.completeContent',
        )
      )
        .replace('{username}', fullName || username)
        .replace('{code}', job.code);
      notificationRequest.action =
        TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_VIEW;
      notificationRequest.payload = this.generatePayload(
        event,
        NOTIFICATION_ENTITY_ENUM.JOB_DETAIL,
      );

      const leader = await this.jobUtil.getAssignMaintenanceTeamLeader(
        job?.assign,
      );
      notificationRequest.userIds = [leader?.userId];
      notificationRequest.createdBy = fromUserId;

      return [
        await super.sendWebNotification(notificationRequest),
        await super.sendAppNotification(notificationRequest),
      ];
    } catch (error) {
      console.error(error);
    }
  }

  @OnEvent(JOB_EVENTS_ENUM.RESOLVE)
  public async handleResolveJob(event: EventRequestDto) {
    try {
      const notificationRequest = new PushNotificationRequestDto();
      const { id, fromUserId } = event;
      const job = await this.jobRepository.findOneById(id);
      const user = await this.userService.getDetailUser(fromUserId);
      const notificationResolve = await this.i18n.translate(
        `message.defineJob.notification.${
          job.isNeedAccept ? 'resolveContent' : 'resolveAutoContent'
        }`,
        {
          args: {
            code: job.code,
            username: user.username,
          },
        },
      );

      notificationRequest.title = await this.i18n.translate(
        'message.defineJob.notification.resolveTitle',
      );
      notificationRequest.content = notificationResolve;
      notificationRequest.action =
        TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_VIEW;
      notificationRequest.payload = this.generatePayload(
        event,
        NOTIFICATION_ENTITY_ENUM.JOB_DETAIL,
      );
      if (!job.isNeedAccept) {
        const leader = await this.jobUtil.getAssignMaintenanceTeamLeader(
          job?.assign,
        );
        notificationRequest.userIds = [leader?.userId];
      } else {
        notificationRequest.userIds = await this.jobUtil.getAssignMemberIds(
          job?.assign,
        );
      }
      notificationRequest.createdBy = fromUserId;

      return [
        await super.sendWebNotification(notificationRequest),
        await super.sendAppNotification(notificationRequest),
      ];
    } catch (error) {
      console.error(error);
    }
  }

  @OnEvent(JOB_EVENTS_ENUM.REWORK)
  public async handleReworkJob(event: EventRequestDto) {
    try {
      const notificationRequest = new PushNotificationRequestDto();
      const { id, fromUserId } = event;
      const user = await this.userService.getDetailUser(fromUserId);
      const job = await this.jobRepository.findOneById(id);

      const { fullName, username } = user;
      notificationRequest.title = await this.i18n.translate(
        'message.defineJob.notification.reworkTitle',
      );
      notificationRequest.content = (
        await this.i18n.translate(
          'message.defineJob.notification.reworkContent',
        )
      )
        .replace('{username}', fullName || username)
        .replace('{code}', job.code);
      notificationRequest.action =
        TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_CONFIRM_AND_REJECT;
      notificationRequest.payload = this.generatePayload(
        event,
        NOTIFICATION_ENTITY_ENUM.JOB_DETAIL,
      );

      notificationRequest.userIds = await this.jobUtil.getAssignMemberIds(
        job?.assign,
      );
      notificationRequest.createdBy = fromUserId;

      return [
        await super.sendWebNotification(notificationRequest),
        await super.sendAppNotification(notificationRequest),
      ];
    } catch (error) {
      console.error(error);
    }
  }

  @OnEvent(JOB_EVENTS_ENUM.UPDATE_STATUS)
  public async onUpdateStatusJob(event: EventRequestDto) {
    try {
      const notificationRequest = new PushNotificationRequestDto();
      const { id, code, fromUserId } = event;
      const user = await this.userService.getDetailUser(fromUserId);
      const job = await this.jobRepository.findOneById(id);

      const { username } = user;
      const jobStatusText = await this.i18n.translate('text.JOB_STATUS');
      const jobStatusMap = new Map();
      jobStatusMap.set(JOB_STATUS_ENUM.NON_ASSIGN, jobStatusText.NON_ASSIGN);
      jobStatusMap.set(
        JOB_STATUS_ENUM.WAIT_CONFIRM,
        jobStatusText.WAIT_CONFIRM,
      );
      jobStatusMap.set(JOB_STATUS_ENUM.IN_PROGRESS, jobStatusText.IN_PROGRESS);
      jobStatusMap.set(JOB_STATUS_ENUM.REJECT, jobStatusText.REJECT);
      jobStatusMap.set(JOB_STATUS_ENUM.CONFIRM, jobStatusText.CONFIRM);
      jobStatusMap.set(JOB_STATUS_ENUM.COMPLETED, jobStatusText.COMPLETED);
      jobStatusMap.set(JOB_STATUS_ENUM.RESOLVED, jobStatusText.RESOLVED);
      notificationRequest.title = await this.i18n.translate(
        'message.defineJob.notification.updateStatusTitle',
      );
      notificationRequest.content = await this.i18n.translate(
        'message.defineJob.notification.updateStatusContent',
        {
          args: {
            username: username,
            code,
            newStatus: jobStatusMap.get(job.status).toLocaleLowerCase(),
          },
        },
      );
      let action: TYPE_NOTIFICATION_RENDER_ACTION_ENUM;
      switch (job.status) {
        case JOB_STATUS_ENUM.WAIT_CONFIRM:
          action =
            TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_CONFIRM_AND_REJECT;
          break;
        case JOB_STATUS_ENUM.NON_ASSIGN:
          action = TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_ASSIGNMENT;
          break;
        case JOB_STATUS_ENUM.CONFIRM:
          action = TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_VIEW;
          break;
        default:
          break;
      }
      notificationRequest.action = action;
      notificationRequest.payload = this.generatePayload(
        event,
        NOTIFICATION_ENTITY_ENUM.JOB_DETAIL,
      );
      const leader = await this.jobUtil.getAssignMaintenanceTeamLeader(
        job?.assign,
      );
      const memberIds = await this.jobUtil.getAssignMemberIds(job?.assign);
      notificationRequest.userIds = uniq([...memberIds, leader.userId]);
      notificationRequest.createdBy = fromUserId;

      return [
        await super.sendWebNotification(notificationRequest),
        await super.sendAppNotification(notificationRequest),
      ];
    } catch (error) {
      console.error(error);
    }
  }
}
