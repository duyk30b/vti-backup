import {
  Controller,
  Injectable,
  Get,
  Inject,
  Put,
  Query,
  Param,
  Body,
  UseInterceptors,
} from '@nestjs/common';
import { JobServiceInterface } from './interface/job.service.interface';
import { ApiConsumes, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { ListJobDataResponseDto } from './dto/response/list-job-data.response.dto';
import { ResponsePayload } from '@utils/response-payload';
import { GetListJobRequestDto } from './dto/request/get-list-job.request.dto';
import { isEmpty } from 'lodash';
import { SuccessResponse } from '@utils/success.response.dto';
import { ExecuteJobFormData } from './dto/request/execute-job.request.dto';
import { JobAssignmentRequestDto } from './dto/request/job-assignment.request.dto';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { JobRejectBodyDto } from './dto/request/job-reject.param.dto';
import { mergePayload } from '@utils/common';
import { ApproveJobRequestDto } from './dto/request/approve-job.request.dto';
import { DetailJobResponse } from './dto/response/detail-job.response.dto';
import { JobQueryDto } from './dto/request/job.query.dto';
import { UpdateJobPlanRequestDto } from './dto/request/job-plan.request.dto';
import { GetSuppliesByJob } from './dto/request/get-supplies-by-job.param.dto';
import { GetSuppliesByJobResponse } from './dto/response/get-supplies-by-job.response.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  APPROVE_JOB_PERMISSION,
  ASSIGNMENT_JOB_PERMISSION,
  DETAIL_JOB_PERMISSION,
  EXECUTE_JOB_PERMISSION,
  LIST_JOB_PERMISSION,
  QUICK_ASSIGN_JOB_PERMISSION,
  UPDATE_JOB_PERMISSION,
  UPDATE_STATUS_JOB_PERMISSION,
  UPDATE_TIME_JOB_PERMISSION,
} from '@utils/permissions/job';
import { DETAIL_DEVICE_PERMISSION } from '@utils/permissions/device';
import { JOB_ACTION_REJECT, JOB_ACTION_ENUM } from './job.constant';
import { UpdateStatusJobParamDto } from './dto/request/update-status-job.param';
import { JobAddReasonBodyDto } from './dto/request/add-reason-job.request.dto copy';
import { QuickAssignJobsRequestDto } from './dto/request/quick-assign-jobs.request.dto';
import { UpdateResolvedJobTimeRequestDto } from './dto/request/update-resolve-job-time.request.dto';
import { PermissionWithRoleInterceptor } from '@core/interceptors/permission-with-role.interceptor';
import {
  CREATE_SUPPLY_REQUEST_TICKET_PERMISSION,
  UPDATE_SUPPLY_REQUEST_TICKET_PERMISSION,
} from '@utils/permissions/supply-request';
import { CREATE_REPAIR_REQUEST_PERMISSION } from '@utils/permissions/repair-request';

@Injectable()
@Controller('jobs')
export class JobController {
  constructor(
    @Inject('JobServiceInterface')
    private readonly jobService: JobServiceInterface,
  ) {}

  @PermissionCode(
    LIST_JOB_PERMISSION.code,
    CREATE_SUPPLY_REQUEST_TICKET_PERMISSION.code,
    UPDATE_SUPPLY_REQUEST_TICKET_PERMISSION.code,
    CREATE_REPAIR_REQUEST_PERMISSION.code,
  )
  @UseInterceptors(PermissionWithRoleInterceptor)
  @Get('')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'Danh sách công việc',
    description: 'Danh sách công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'List Item',
    type: ListJobDataResponseDto,
  })
  async listJob(
    @Query() payload: GetListJobRequestDto,
  ): Promise<ResponsePayload<ListJobDataResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.jobService.list(request);
  }

  @PermissionCode(DETAIL_DEVICE_PERMISSION.code)
  @Get('/histories-of-device')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'Lịch sử công việc của thiết bị',
    description: 'Lịch sử công việc của thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'List Item',
    type: ListJobDataResponseDto,
  })
  async listJobOfDevice(
    @Query() payload: GetListJobRequestDto,
  ): Promise<ResponsePayload<ListJobDataResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.jobService.list(request, true);
  }

  @PermissionCode(ASSIGNMENT_JOB_PERMISSION.code)
  @UseInterceptors(PermissionWithRoleInterceptor)
  @Put('/:id/assignments')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'Phân công công việc',
    description: 'Phân công công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Update job',
    type: SuccessResponse,
  })
  async jobsAssignment(
    @Query() query: JobQueryDto,
    @Param() param: IdParamDto,
    @Body() payload: JobAssignmentRequestDto,
  ): Promise<any> {
    const { request, responseError } = mergePayload(
      mergePayload(query, param),
      payload,
    );

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.jobService.assignment(request);
  }

  @PermissionCode(UPDATE_STATUS_JOB_PERMISSION.code)
  @Put('/:id/status/:status')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'Update status',
    description: 'Cập nhật trạng thái công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Update status',
    type: SuccessResponse,
  })
  async updateStatusJob(@Param() param: UpdateStatusJobParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.jobService.changeStatus(request);
  }

  @PermissionCode(UPDATE_STATUS_JOB_PERMISSION.code)
  @UseInterceptors(PermissionWithRoleInterceptor)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'Update status',
    description: 'Cập nhật trạng thái công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Update status',
    type: SuccessResponse,
  })
  async rejectJob(
    @Query() query: JobQueryDto,
    @Param() param: IdParamDto,
    @Body() body: JobRejectBodyDto,
  ): Promise<any> {
    const { request: requestBody, responseError: responseErrorBody } = body;
    if (responseErrorBody && !isEmpty(responseErrorBody)) {
      return responseErrorBody;
    }
    const { request, responseError } = mergePayload(param, query);
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.jobService.updateStatus({
      ...request,
      ...requestBody,
      action: JOB_ACTION_REJECT,
    });
  }

  @PermissionCode(UPDATE_STATUS_JOB_PERMISSION.code)
  @UseInterceptors(PermissionWithRoleInterceptor)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'Update status',
    description: 'Xác nhận công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Update status',
    type: SuccessResponse,
  })
  async confirmJob(
    @Query() query: JobQueryDto,
    @Param() param: IdParamDto,
  ): Promise<any> {
    const { request, responseError } = mergePayload(param, query);
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.jobService.updateStatus({
      ...request,
      action: JOB_ACTION_ENUM.CONFIRM,
    });
  }

  @PermissionCode(UPDATE_STATUS_JOB_PERMISSION.code)
  @UseInterceptors(PermissionWithRoleInterceptor)
  @Put('/:id/in-progress')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'Update status',
    description: 'Xác nhận công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Update status',
    type: SuccessResponse,
  })
  async inprogressJob(
    @Query() query: JobQueryDto,
    @Param() param: IdParamDto,
  ): Promise<any> {
    const { request, responseError } = mergePayload(param, query);
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.jobService.updateStatus({
      ...request,
      action: JOB_ACTION_ENUM.IN_PROGRESS,
    });
  }

  @PermissionCode(UPDATE_STATUS_JOB_PERMISSION.code)
  @UseInterceptors(PermissionWithRoleInterceptor)
  @Put('/:id/rework')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'Update status',
    description: 'Từ chối công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Update status',
    type: SuccessResponse,
  })
  async reworkJob(
    @Query() query: JobQueryDto,
    @Param() param: IdParamDto,
    @Body() body: JobRejectBodyDto,
  ): Promise<any> {
    const { request: requestBody, responseError: responseErrorBody } = body;
    if (responseErrorBody && !isEmpty(responseErrorBody)) {
      return responseErrorBody;
    }
    const { request, responseError } = mergePayload(param, query);
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.jobService.updateStatus({
      ...request,
      ...requestBody,
      action: JOB_ACTION_ENUM.REWORK,
    });
  }

  @PermissionCode(EXECUTE_JOB_PERMISSION.code)
  @UseInterceptors(PermissionWithRoleInterceptor)
  @Put('/:id/execute')
  @ApiConsumes('multipart/form-data')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'Execute job',
    description: 'Execute job',
  })
  @ApiResponse({
    status: 200,
    description: 'Execute job',
    type: SuccessResponse,
  })
  async execute(
    @Query() query: JobQueryDto,
    @Param() param: IdParamDto,
    @Body() body: ExecuteJobFormData,
  ): Promise<any> {
    const payload = mergePayload(mergePayload(param, query), body);

    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.jobService.execute(request);
  }

  @PermissionCode(APPROVE_JOB_PERMISSION.code)
  @UseInterceptors(PermissionWithRoleInterceptor)
  @Put('/:id/approve')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'Approve job',
    description: 'Approve job',
  })
  @ApiResponse({
    status: 200,
    description: 'Approve job',
    type: SuccessResponse,
  })
  async approve(
    @Param() param: IdParamDto,
    @Body() body: ApproveJobRequestDto,
    @Query() query: JobQueryDto,
  ): Promise<any> {
    const payload = mergePayload(mergePayload(param, body), query);
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.jobService.approve(request);
  }

  @PermissionCode(DETAIL_JOB_PERMISSION.code, EXECUTE_JOB_PERMISSION.code)
  @UseInterceptors(PermissionWithRoleInterceptor)
  @Get('/:id')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'Detail job',
    description: 'Detail job',
  })
  @ApiResponse({
    status: 200,
    description: 'Detail job',
    type: DetailJobResponse,
  })
  async detail(@Param() param: IdParamDto): Promise<ResponsePayload<any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.jobService.detail(request);
  }

  @PermissionCode(UPDATE_JOB_PERMISSION.code)
  @Put('/plan')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'Sửa ngày dự kiến',
    description: 'Sửa ngày dự kiến',
  })
  @ApiResponse({
    status: 200,
    description: 'Update job',
    type: SuccessResponse,
  })
  async updateJobPlan(@Body() payload: UpdateJobPlanRequestDto): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.jobService.updateJobPlan(request);
  }

  @Get('/:id/supplies/:warehouseId')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'Danh sách vật tư phụ tùng theo công việc',
    description: 'Danh sách vật tư phụ tùng theo công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Success response',
    type: GetSuppliesByJobResponse,
  })
  async getSuppliesByJob(@Param() param: GetSuppliesByJob): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.jobService.getSuppliesByJob(request);
  }

  @Put('/:id/reason')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'Add reason fob job inprogress',
    description: 'Add reason fob job inprogress',
  })
  @ApiResponse({
    status: 200,
    description: 'Add reason fob job inprogress',
    type: SuccessResponse,
  })
  async addReasonJobInprogress(
    @Param() param: IdParamDto,
    @Body() body: JobAddReasonBodyDto,
  ): Promise<any> {
    const payload = mergePayload(body, param);

    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.jobService.addReasonJobInprogress(request);
  }

  @PermissionCode(QUICK_ASSIGN_JOB_PERMISSION.code)
  @UseInterceptors(PermissionWithRoleInterceptor)
  @Put('/quick-assign')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'Quick assign for jobs',
    description: 'Quick assign for jobs',
  })
  @ApiResponse({
    status: 200,
    description: 'Quick assign for jobs',
    type: SuccessResponse,
  })
  async quickAssignJobs(@Body() body: QuickAssignJobsRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.jobService.quickAssignJobs(request);
  }

  @PermissionCode(UPDATE_TIME_JOB_PERMISSION.code)
  @UseInterceptors(PermissionWithRoleInterceptor)
  @Put('/:id/update-time')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'Update time for resolve job',
    description: 'Update time for resolve job',
  })
  @ApiResponse({
    status: 200,
    description: 'Update time for resolve job',
    type: SuccessResponse,
  })
  async updateResolvedJobTime(
    @Param() param: IdParamDto,
    @Body() body: UpdateResolvedJobTimeRequestDto,
  ): Promise<any> {
    const payload = mergePayload(body, param);

    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.jobService.updateResolvedJobTime(request);
  }
}
