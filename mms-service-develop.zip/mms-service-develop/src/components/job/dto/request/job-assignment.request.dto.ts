import { JOB_CONST } from '@components/job/job.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsBoolean,
  IsDateString,
  IsInt,
  IsMongoId,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';

export class JobAssignmentRequestDto extends BaseDto {
  @ApiProperty()
  @IsString()
  @IsMongoId()
  @IsNotEmpty()
  assignTeamId: string;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  assignUserId: number;

  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  planFrom: Date;

  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  planTo: Date;

  @ApiPropertyOptional()
  @IsBoolean()
  @IsOptional()
  isNeedAccept: boolean;

  @ApiProperty()
  @IsString()
  @MaxLength(JOB_CONST.REASON.MAX_LENGTH)
  @IsOptional()
  reason: string;
}
