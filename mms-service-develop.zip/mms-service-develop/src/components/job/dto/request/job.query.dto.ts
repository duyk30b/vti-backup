import { IsOptional } from 'class-validator';

export class JobQueryDto {
  @IsOptional()
  assignIds: string[];

  @IsOptional()
  checkPermission: boolean;
}
