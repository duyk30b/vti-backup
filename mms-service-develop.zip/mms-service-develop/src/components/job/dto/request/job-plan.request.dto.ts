import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsDateString,
  IsMongoId,
  IsNotEmpty,
  ValidateNested,
} from 'class-validator';

class UpdateJobPlanDetailRequestDto {
  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  planFrom: Date;

  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  planTo: Date;

  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  jobId: string;
}

export class UpdateJobPlanRequestDto extends BaseDto {
  @ApiProperty({
    type: UpdateJobPlanDetailRequestDto,
    isArray: true,
  })
  @ArrayUnique((item: UpdateJobPlanDetailRequestDto) => item.jobId)
  @ValidateNested({ each: true })
  @Type(() => UpdateJobPlanDetailRequestDto)
  @ArrayNotEmpty()
  items: UpdateJobPlanDetailRequestDto[];

  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  maintenancePlanId: string;
}
