import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayUnique,
  IsMongoId,
  IsNotEmpty,
  ValidateNested,
} from 'class-validator';
import { JobAssignmentRequestDto } from './job-assignment.request.dto';

class QuickAssignJob extends JobAssignmentRequestDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  jobId: string;
}

export class QuickAssignJobsRequestDto extends BaseDto {
  @ApiProperty({ type: QuickAssignJob, isArray: true })
  @Type(() => QuickAssignJob)
  @ValidateNested({ each: true })
  @ArrayUnique((data) => data.jobId)
  @IsNotEmpty()
  jobs: QuickAssignJob[];
}
