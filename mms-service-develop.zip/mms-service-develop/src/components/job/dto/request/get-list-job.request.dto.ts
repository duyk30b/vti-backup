import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { IsOptional } from 'class-validator';
import { MaintenanceTeam } from 'src/models/maintenance-team/maintenance-team.model';

export class GetListJobRequestDto extends PaginationQuery {
  @IsOptional()
  assignIds: string[];

  @IsOptional()
  checkPermission: boolean;

  @IsOptional()
  maintenanceTeam: MaintenanceTeam;
}
