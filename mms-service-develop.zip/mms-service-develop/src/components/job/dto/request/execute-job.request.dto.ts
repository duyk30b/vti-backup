import {
  JOB_CONST,
  JOB_TYPE_MAINTENANCE_ENUM,
  RESULT_ENUM,
} from '@components/job/job.constant';
import { OBLIGATORY_ENUM } from '@constant/common';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { plainToInstance, Transform, Type } from 'class-transformer';
import {
  IsDateString,
  IsEnum,
  IsInt,
  IsMongoId,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';

class InstallationTemplateDetail {
  @ApiProperty()
  @MaxLength(JOB_CONST.TITLE.MAX_LENGTH)
  @IsString()
  @IsNotEmpty()
  title: string;

  @ApiPropertyOptional()
  @MaxLength(JOB_CONST.DESCRIPTION.MAX_LENGTH)
  @IsString()
  @IsOptional()
  description: string;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  value: string;

  @ApiPropertyOptional({ enum: OBLIGATORY_ENUM })
  @IsEnum(OBLIGATORY_ENUM)
  @IsOptional()
  obligatory: OBLIGATORY_ENUM;

  @ApiPropertyOptional({ enum: RESULT_ENUM })
  @IsEnum(RESULT_ENUM)
  @IsOptional()
  status: RESULT_ENUM;
}

class CheckListTemplateDetail {
  @ApiProperty()
  @MaxLength(JOB_CONST.TITLE.MAX_LENGTH)
  @IsString()
  @IsNotEmpty()
  title: string;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  value: string;

  @ApiPropertyOptional({ enum: RESULT_ENUM })
  @IsEnum(RESULT_ENUM)
  @IsOptional()
  status: RESULT_ENUM;
}

class Supply {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  supplyId: string;

  @ApiPropertyOptional({ enum: JOB_TYPE_MAINTENANCE_ENUM })
  @IsEnum(JOB_TYPE_MAINTENANCE_ENUM)
  @IsOptional()
  maintenanceType: JOB_TYPE_MAINTENANCE_ENUM;

  @ApiPropertyOptional()
  @IsInt()
  @IsOptional()
  quantity: number;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  description: string;
}

class JobInformation {
  @ApiPropertyOptional({ enum: JOB_TYPE_MAINTENANCE_ENUM })
  @IsEnum(JOB_TYPE_MAINTENANCE_ENUM)
  @IsOptional()
  maintenanceType: JOB_TYPE_MAINTENANCE_ENUM;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  description: string;
}

export class ExecuteJobRequestDto {
  @ApiPropertyOptional()
  @IsDateString()
  @IsOptional()
  executionDateFrom: Date;

  @ApiPropertyOptional()
  @IsDateString()
  @IsOptional()
  executionDateTo: Date;

  @ApiPropertyOptional({ enum: RESULT_ENUM })
  @IsEnum(RESULT_ENUM)
  @IsOptional()
  result: RESULT_ENUM;

  @ApiPropertyOptional({
    type: InstallationTemplateDetail,
    isArray: true,
  })
  @Type(() => InstallationTemplateDetail)
  @IsOptional()
  installationTemplateDetails: InstallationTemplateDetail[];

  @ApiPropertyOptional({
    type: InstallationTemplateDetail,
    isArray: true,
  })
  @Type(() => InstallationTemplateDetail)
  @IsOptional()
  accreditationTemplateDetails: InstallationTemplateDetail[];

  @ApiPropertyOptional({
    type: CheckListTemplateDetail,
    isArray: true,
  })
  @Type(() => CheckListTemplateDetail)
  @IsOptional()
  checklistDetails: CheckListTemplateDetail[];

  @ApiPropertyOptional({
    type: Supply,
    isArray: true,
  })
  @Type(() => Supply)
  @IsOptional()
  supplies: Supply[];

  @ApiPropertyOptional({
    type: JobInformation,
  })
  @Type(() => JobInformation)
  @IsOptional()
  information: JobInformation;
}

export class ExecuteJobFormData extends BaseDto {
  @ApiProperty({
    type: ExecuteJobRequestDto,
    description: `
    {
      "executionDateFrom": "2022-10-18T09:30:11.880Z",
      "executionDateTo": "2022-10-18T09:30:11.880Z",
      "result": 1,
      "installationTemplateDetails": [
        {
          "title": "string",
          "description": "string",
          "value": "string",
          "obligatory": "NO",
          "status": 1
        }
      ],
      "accreditationTemplateDetails": [
        {
          "title": "string",
          "description": "string",
          "value": "string",
          "obligatory": "NO",
          "status": 1
        }
      ],
      "checklistDetails": [
        {
          "title": "string",
          "value": "string",
          "status": 1
        }
      ],
      "supplies": [
        {
          "supplyId": "string",
          "maintenanceType": 1,
          "quantity": 0,
          "description": "string"
        }
      ],
      "information": {
        "maintenanceType": 1,
        "description": "string"
      }
    }`,
  })
  @ValidateNested({ each: true })
  @Transform(({ value }) => {
    return plainToInstance(ExecuteJobRequestDto, JSON.parse(value));
  })
  @Type(() => ExecuteJobRequestDto)
  data: ExecuteJobRequestDto;

  @ApiPropertyOptional({
    type: String,
    format: 'binary',
  })
  @IsOptional()
  file: any;
}
