import { BaseDto } from '@core/dto/base.dto';
import { JOB_CONST } from '@components/job/job.constant';
import { ApiProperty } from '@nestjs/swagger';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { IsOptional, IsString, MaxLength } from 'class-validator';

export class JobRejectParamDto extends IdParamDto {}

export class JobRejectBodyDto extends BaseDto {
  @ApiProperty()
  @IsString()
  @MaxLength(JOB_CONST.REASON.MAX_LENGTH)
  @IsOptional()
  reason: string;
}
