import { JOB_STATUS_ENUM } from '@components/job/job.constant';
import { ApiProperty } from '@nestjs/swagger';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { Transform } from 'class-transformer';
import { IsEnum, IsNotEmpty, IsNumber } from 'class-validator';

export class UpdateStatusJobParamDto extends IdParamDto {
  @ApiProperty({ enum: JOB_STATUS_ENUM })
  @IsEnum(JOB_STATUS_ENUM)
  @IsNumber()
  @IsNotEmpty()
  @Transform(({ value }) => +value)
  status: number;
}
