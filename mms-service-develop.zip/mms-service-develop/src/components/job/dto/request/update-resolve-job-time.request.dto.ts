import { JOB_CONST } from '@components/job/job.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
} from 'class-validator';

export class UpdateResolvedJobTimeRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  @Max(JOB_CONST.EXECUTE_TIME.MAX)
  @Min(JOB_CONST.EXECUTE_TIME.MIN)
  @IsNotEmpty()
  executionTime: number;

  @ApiProperty()
  @IsInt()
  @Max(JOB_CONST.STOP_TIME.MAX)
  @Min(JOB_CONST.STOP_TIME.MIN)
  @IsOptional()
  stopTime: number;

  @ApiPropertyOptional()
  @IsString()
  @MaxLength(JOB_CONST.REASON.MAX_LENGTH)
  @IsOptional()
  reason: string;
}
