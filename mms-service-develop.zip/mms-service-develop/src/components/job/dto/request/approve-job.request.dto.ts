import { JOB_CONST } from '@components/job/job.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty, IsOptional, Max, Min } from 'class-validator';

export class ApproveJobRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  @Max(JOB_CONST.EXECUTE_TIME.MAX)
  @Min(JOB_CONST.EXECUTE_TIME.MIN)
  @IsNotEmpty()
  executionTime: number;

  @ApiProperty()
  @IsInt()
  @Max(JOB_CONST.EXECUTE_TIME.MAX)
  @Min(JOB_CONST.EXECUTE_TIME.MIN)
  @IsOptional()
  stopTime: number;
}
