import { JOB_CONST } from '@components/job/job.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString, MaxLength } from 'class-validator';

export class JobAddReasonBodyDto extends BaseDto {
  @ApiProperty()
  @IsString()
  @MaxLength(JOB_CONST.REASON.MAX_LENGTH)
  @IsNotEmpty()
  reason: string;
}
