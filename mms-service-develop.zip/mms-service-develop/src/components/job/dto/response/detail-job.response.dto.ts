import { DetailAccreditationTemplateResponseDto } from '@components/accreditation-template/dto/response/detail-accreditation-response.dto';
import { DetailCheckListTemplateResponseDto } from '@components/checklist-template/dto/response/detail-checklist-template.response.dto';
import { DeviceBasicResponseDto } from '@components/device/dto/response/device-basic.response.dto';
import { DetailInstallationTemplateResponse } from '@components/installation-template/dto/response/detail-installation-template.response';
import { JOB_STATUS_ENUM, JOB_TYPE_ENUM } from '@components/job/job.constant';
import { DetailRepairRequestResponse } from '@components/repair-request/dto/response/detail-repair-request.response';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { HistoryResponse } from '@utils/dto/response/history.response';
import { Expose, plainToInstance, Transform, Type } from 'class-transformer';
import { first, keyBy } from 'lodash';
import { BasicUserResponseDto } from '@utils/dto/response/basic-user.response.dto';

class SupplyResponse {
  @ApiProperty()
  @Transform(({ obj }) => obj?.supplyId?.toString())
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  stockQuantity: number;

  @ApiProperty()
  @Expose()
  estimateUsedTime: number;

  @ApiProperty()
  @Expose()
  nameOther: string;

  @ApiProperty()
  @Expose()
  canFixable: number;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  unit: BasicSqlDocumentResponse;
}

class DeviceResponse extends DeviceBasicResponseDto {
  @ApiProperty()
  @Expose()
  model: string;

  @ApiProperty({ type: SupplyResponse, isArray: true })
  @Transform(({ obj }) => {
    const supplyMap = keyBy(obj?.listSupply, '_id');
    const supplies = obj?.supplies?.map((e) => ({
      ...e,
      id: e?.supplyId?.toString(),
      name: supplyMap[e?.supplyId?.toString()]?.name,
      nameOther: supplyMap[e?.supplyId?.toString()]?.nameOther,
      code: supplyMap[e?.supplyId?.toString()]?.code,
      type: supplyMap[e?.supplyId?.toString()]?.type,
      unit: obj.unitMap[supplyMap[e?.supplyId?.toString()]?.unitId],
    }));

    return plainToInstance(SupplyResponse, supplies, {
      excludeExtraneousValues: true,
    });
  })
  @Type(() => SupplyResponse)
  @Expose()
  supplies: SupplyResponse[];

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  area: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  warehouse: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  factory: BasicResponseDto;
}

class ResultDetailResponse extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  title: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  value: string;

  @ApiProperty()
  @Expose()
  obligatory: number;

  @ApiProperty()
  @Expose()
  status: number;
}

export class AssignResponse {
  @ApiProperty()
  @Expose()
  @Type(() => BasicUserResponseDto)
  user: BasicUserResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  team: BasicResponseDto;
}

class JobResultResponse {
  @ApiProperty()
  @Expose()
  result: number;

  @ApiProperty()
  @Expose()
  maintenanceType: number;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty({ type: ResultDetailResponse, isArray: true })
  @Type(() => ResultDetailResponse)
  @Expose()
  details: ResultDetailResponse[];
}

class JobSupplyResponse extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  maintenanceType: number;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  unit: BasicSqlDocumentResponse;

  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Expose()
  supplyGroup: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Expose()
  supplyType: BasicResponseDto;

  @ApiProperty()
  @Expose()
  nameOther: string;
}

// @TODO: fix return transform
const transformJobTemplateType = (obj) => {
  switch (obj.type) {
    case JOB_TYPE_ENUM.PERIOD_CHECKLIST:
      return plainToInstance(
        DetailCheckListTemplateResponseDto,
        obj?.checklistTemplate,
        {
          excludeExtraneousValues: true,
        },
      );
    case JOB_TYPE_ENUM.UNEXPECTED_REPAIR:
      return plainToInstance(DetailRepairRequestResponse, obj?.repairRequest, {
        excludeExtraneousValues: true,
      });
    case JOB_TYPE_ENUM.ACCREDITATION:
      return plainToInstance(
        DetailAccreditationTemplateResponseDto,
        obj?.accreditationTemplate,
        {
          excludeExtraneousValues: true,
        },
      );
    case JOB_TYPE_ENUM.INSTALLATION:
      return plainToInstance(
        DetailInstallationTemplateResponse,
        obj?.installationTemplate,
        {
          excludeExtraneousValues: true,
        },
      );
    default:
      return {};
  }
};

class SupplyRequest extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  status: number;
}

export class DetailJobResponse extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  planFrom: Date;

  @ApiProperty()
  @Expose()
  planTo: Date;

  @ApiProperty()
  @Expose()
  executionDateFrom: Date;

  @ApiProperty()
  @Expose()
  executionDateTo: Date;

  @ApiProperty()
  @Expose()
  executionTime: number;

  @ApiProperty()
  @Expose()
  stopTime: number;

  @ApiProperty({ type: AssignResponse })
  @Type(() => AssignResponse)
  @Expose()
  assign: AssignResponse;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty()
  @Expose()
  imageUrl: string;

  @ApiProperty()
  @Expose()
  fileName: string;

  @ApiProperty()
  @Transform(({ obj }) => transformJobTemplateType(obj))
  @Expose()
  jobTypeTemplate: any;

  @ApiProperty({ type: JobResultResponse })
  @Type(() => JobResultResponse)
  @Expose()
  result: JobResultResponse;

  @ApiProperty({ type: JobSupplyResponse, isArray: true })
  @Transform(({ obj }) => {
    const supplyMap = keyBy(obj?.listSupply, '_id');
    const supplies = obj?.['supplies']?.map((e) => ({
      ...e,
      ...supplyMap[e?.supplyId?.toString()],
      unit: obj.unitMap[supplyMap[e?.supplyId?.toString()]?.unitId],
      supplyType: first(supplyMap[e?.supplyId?.toString()]?.supplyType),
      supplyGroup: first(supplyMap[e?.supplyId?.toString()]?.supplyGroup),
    }));

    return plainToInstance(JobSupplyResponse, supplies, {
      excludeExtraneousValues: true,
    });
  })
  @Type(() => JobSupplyResponse)
  @Expose()
  supplies: JobSupplyResponse[];

  @ApiProperty({ type: DeviceResponse })
  @Type(() => DeviceResponse)
  @Expose()
  device: DeviceResponse;

  @ApiProperty({ type: HistoryResponse, isArray: true })
  @Type(() => HistoryResponse)
  @Transform((data) => {
    return data.value.reverse();
  })
  @Expose()
  histories: HistoryResponse[];

  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Expose()
  warning: BasicResponseDto;

  @ApiProperty()
  @Transform(
    ({ obj }) =>
      obj?.histories.find(
        (history) => history.status === JOB_STATUS_ENUM.IN_PROGRESS,
      )?.createdAt,
  )
  @Expose()
  confirmedAt: Date;

  @ApiProperty()
  @Expose()
  isNeedAccept: boolean;

  @ApiProperty()
  @Expose()
  isOverdue: boolean;

  @ApiProperty({ type: SupplyRequest, isArray: true })
  @Type(() => SupplyRequest)
  @Expose()
  supplyRequests: SupplyRequest[];

  @ApiProperty()
  @Expose()
  canUpdateJobTime: boolean;
}
