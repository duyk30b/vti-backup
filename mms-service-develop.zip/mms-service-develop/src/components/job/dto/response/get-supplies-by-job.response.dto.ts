import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';

export class GetSuppliesByJobResponseDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  nameOther: string;

  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Expose()
  vendor: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Expose()
  supplyGroup: BasicResponseDto;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  unit: BasicSqlDocumentResponse;

  @ApiProperty()
  @Expose()
  stockQuantity: number;

  @ApiProperty()
  @Expose()
  minStockQuantity: number;

  @ApiProperty()
  @Expose()
  availableStockQuantity: number;
}

export class GetSuppliesByJobResponse extends SuccessResponse {
  @ApiProperty({ type: GetSuppliesByJobResponseDto, isArray: true })
  @Expose()
  data: GetSuppliesByJobResponseDto[];
}
