import { first } from 'lodash';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, plainToInstance, Transform, Type } from 'class-transformer';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { DeviceBasicResponseDto } from '@components/device/dto/response/device-basic.response.dto';
import { AssignResponse } from '@components/job/dto/response/detail-job.response.dto';

export class ListJobResponseDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty({ type: DeviceBasicResponseDto })
  @Type(() => DeviceBasicResponseDto)
  @Transform(
    ({ obj }) =>
      plainToInstance(DeviceBasicResponseDto, first(obj.device), {
        excludeExtraneousValues: true,
      }) || {},
  )
  @Expose()
  device: DeviceBasicResponseDto;

  @ApiProperty({ type: AssignResponse })
  @Expose()
  @Type(() => AssignResponse)
  assign: AssignResponse;

  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Expose()
  warning: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Expose()
  repairRequest: BasicResponseDto;

  @ApiProperty()
  @Expose()
  planFrom: Date;

  @ApiProperty()
  @Expose()
  planTo: Date;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  isOverdue: boolean;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  canUpdateJobTime: boolean;
}
