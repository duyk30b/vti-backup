import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { ListJobResponseDto } from './list-job.response.dto';
import { PaginationResponse } from '@utils/dto/response/pagination.response';

export class ListJobDataResponseDto extends PaginationResponse {
  @ApiProperty({
    type: ListJobResponseDto,
    isArray: true,
  })
  @Expose()
  items: ListJobResponseDto[];
}
