import { DetailJobResponse } from './detail-job.response.dto';

export class UpdateJobAssignmentResponseDto extends DetailJobResponse {}
