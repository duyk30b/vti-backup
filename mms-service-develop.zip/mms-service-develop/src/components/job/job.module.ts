import { SupplyRequestRepository } from 'src/repository/supply-request/supply-request.repository';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { JobSchema } from 'src/models/job/job.schema';
import { JobRepository } from 'src/repository/job/job.repository';
import { JobController } from './job.controller';
import { JobService } from './job.service';
import { RepairRequestRepository } from 'src/repository/repair-request/repair-request.repository';
import { RepairRequestSchema } from 'src/models/repair-request/repair-request.schema';
import { MaintenanceTeamSchema } from 'src/models/maintenance-team/maintenance-team.schema';
import { MaintenanceTeamRepository } from 'src/repository/maintenance-team/maintenance-team.repository';
import { MaintenanceTemplateSchema } from 'src/models/maintenance-template/maintenance-template.schema';
import { MaintenanceTemplateRepository } from 'src/repository/maintenance-template/maintenance-template.repository';
import { AccreditationTemplateSchema } from 'src/models/accreditation-template/accreditation-template.schema';
import { AccreditationTemplateRepository } from 'src/repository/accreditation-template/accreditation-template.repository';
import { MaintenanceIndexRepository } from 'src/repository/maintenance-index/maintenance-index.repository';
import { MaintenanceIndexSchema } from 'src/models/maintenance-index/maintenance-index.schema';
import { DeviceRepository } from 'src/repository/device/device.repository';
import { JobUtil } from './job.util';
import { DeviceGroupRepository } from 'src/repository/device-group/device-group.repository';
import { CheckListTemplateRepository } from 'src/repository/checklist-template/checklist-template.repository';
import { ChecklistTemplateSchema } from 'src/models/checklist-template/checklist-template.schema';
import { NotificationService } from '@components/notification/notification.service';
import { ConfigService } from '@config/config.service';
import { JobNotificationListener } from './listeners/job.notification.listener';
import { DeviceAssignmentRepository } from 'src/repository/device-assignment/device-assignment.repository';
import { DeviceRequestRepository } from 'src/repository/device-request/device-request-ticket.repository';
import { InventoryRepository } from 'src/repository/warehouse-inventories/inventory.repository';
import { SupplyRepository } from 'src/repository/supply/supply.repository';
import { WarningRepository } from 'src/repository/warning/warning.repository';
import { WarningSchema } from 'src/models/warning/warning.schema';
import { InventorySchema } from 'src/models/warehouse-inventories/inventory.schema';
import { HistoryRepository } from 'src/repository/history/history.repository';
import { HistorySchema } from 'src/models/history/history.schema';
import { DeviceAssignmentModule } from '@components/device-assignment/device-assignment.module';
import { ItemModule } from '@components/item/item.module';
@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'Job', schema: JobSchema },
      { name: 'RepairRequest', schema: RepairRequestSchema },
      { name: 'MaintenanceTeam', schema: MaintenanceTeamSchema },
      { name: 'MaintenanceTemplate', schema: MaintenanceTemplateSchema },
      {
        name: 'AccreditationTemplateModel',
        schema: AccreditationTemplateSchema,
      },
      { name: 'MaintenanceIndex', schema: MaintenanceIndexSchema },
      { name: 'CheckListTemplate', schema: ChecklistTemplateSchema },
      { name: 'Inventory', schema: InventorySchema },
      { name: 'Warning', schema: WarningSchema },
      { name: 'History', schema: HistorySchema },
    ]),
    DeviceAssignmentModule,
    ItemModule,
  ],
  controllers: [JobController],
  providers: [
    {
      provide: 'JobRepositoryInterface',
      useClass: JobRepository,
    },
    {
      provide: 'JobServiceInterface',
      useClass: JobService,
    },
    {
      provide: 'RepairRequestRepositoryInterface',
      useClass: RepairRequestRepository,
    },
    {
      provide: 'MaintenanceTeamRepositoryInterface',
      useClass: MaintenanceTeamRepository,
    },
    {
      provide: 'MaintenanceTemplateRepositoryInterface',
      useClass: MaintenanceTemplateRepository,
    },
    {
      provide: 'AccreditationTemplateRepositoryInterface',
      useClass: AccreditationTemplateRepository,
    },
    {
      provide: 'MaintenanceIndexRepositoryInterface',
      useClass: MaintenanceIndexRepository,
    },
    {
      provide: 'DeviceRepositoryInterface',
      useClass: DeviceRepository,
    },
    {
      provide: 'JobUtilInterface',
      useClass: JobUtil,
    },
    {
      provide: 'DeviceGroupRepositoryInterface',
      useClass: DeviceGroupRepository,
    },
    {
      provide: 'InventoryRepositoryInterface',
      useClass: InventoryRepository,
    },
    {
      provide: 'NotificationServiceInterface',
      useClass: NotificationService,
    },
    {
      provide: 'CheckListTemplateRepositoryInterface',
      useClass: CheckListTemplateRepository,
    },
    {
      provide: 'DeviceAssignmentRepositoryInterface',
      useClass: DeviceAssignmentRepository,
    },
    {
      provide: 'DeviceRequestRepositoryInterface',
      useClass: DeviceRequestRepository,
    },
    {
      provide: 'SupplyRequestRepositoryInterface',
      useClass: SupplyRequestRepository,
    },
    {
      provide: 'SupplyRepositoryInterface',
      useClass: SupplyRepository,
    },
    ConfigService,
    JobNotificationListener,
    {
      provide: 'WarningRepositoryInterface',
      useClass: WarningRepository,
    },
    {
      provide: 'HistoryRepositoryInterface',
      useClass: HistoryRepository,
    },
  ],
  exports: [
    MongooseModule,
    {
      provide: 'JobRepositoryInterface',
      useClass: JobRepository,
    },
  ],
})
export class JobModule {}
