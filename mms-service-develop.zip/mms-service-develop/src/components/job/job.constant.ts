import { CODE_REGEX } from '@constant/common';

export enum JOB_STATUS_ENUM {
  NON_ASSIGN,
  WAIT_CONFIRM,
  CONFIRM,
  IN_PROGRESS,
  REJECT,
  COMPLETED,
  RESOLVED,
}

export enum JOB_TYPE_ENUM {
  MAINTAIN,
  UNEXPECTED_REPAIR,
  PERIOD_CHECKLIST,
  INSTALLATION,
  ACCREDITATION,
  MAINTENANCE,
}

export enum CHECKLIST_STATUS_ENUM {
  CREATED = 1,
  CONFIRMED = 2,
  REJECTED = 3,
}

export enum JOB_TYPE_MAINTENANCE_ENUM {
  REPLACE,
  MAINTENANCE,
  BROKEN,
}

export const JOB_CODE_PREFIX = 'P';

export const JOB_CODE_CONST = {
  MAX_LENGTH: 20,
  COLUMN: 'code',
  PAD_CHAR: '0',
  DEFAULT_CODE: '0',
  PREFIX: 'P',
};

export enum RESULT_ENUM {
  FAILED,
  PASS,
}

export enum MANDATORY_ENUM {
  NO,
  YES,
}

export const JOB_CONST = {
  DESCRIPTION: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
  TITLE: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
  CODE: {
    MAX_LENGTH: 20,
    COLUMN: 'code',
    REGEX: CODE_REGEX,
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  REASON: {
    MAX_LENGTH: 255,
    COLUMN: 'reason',
  },
  EXECUTE_TIME: {
    MAX: 525600,
    MIN: 1,
    COLUMN: 'executeTime',
  },
  STOP_TIME: {
    MAX: 525600,
    MIN: 0,
    COLUMN: 'stopTime',
  },
};
export const JOB_STATUS_CAN_DELETE = [
  JOB_STATUS_ENUM.NON_ASSIGN,
  JOB_STATUS_ENUM.REJECT,
  JOB_STATUS_ENUM.WAIT_CONFIRM,
];

export enum JOB_ACTION_ENUM {
  CONFIRM = 'confirm',
  IN_PROGRESS = 'inProgress',
  REWORK = 'rework',
  REJECT = 'reject',
}

export const JOB_ACTION_REJECT = 'reject';

export enum JOB_HISTORY_ENUM {
  NO,
  YES,
}

export enum JOB_EVENTS_ENUM {
  CREATE = 'job.create',
  ASSIGNMENT = 'job.assignment',
  CONFIRM = 'job.confirm',
  IN_PROGRESS = 'job.in-progress',
  REJECT = 'job.reject',
  COMPLETE = 'job.complete',
  RESOLVE = 'job.resolve',
  REWORK = 'job.rework',
  NEED_ASSIGNMENT = 'job.need-assignment',
  JOB_INSTALLATION_CREATE = 'job.job-installation-create',
  UPDATE_STATUS = 'job.update-status',
}
