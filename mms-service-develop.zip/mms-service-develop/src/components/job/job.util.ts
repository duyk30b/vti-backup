import { DeviceRepositoryInterface } from '@components/device/interface/device.repository.interface';
import { MaintenanceIndexRepositoryInterface } from '@components/maintenance-index/interface/maintenance-index.repository.interface';
import { RepairRequestRepositoryInterface } from '@components/repair-request/interface/repair-request.repository.interface';
import { Inject, Injectable } from '@nestjs/common';
import { div, plus } from '@utils/common';
import { identity, isEmpty, pickBy } from 'lodash';
import * as moment from 'moment';
import { Assign, Job } from 'src/models/job/job.model';
import { JobRepositoryInterface } from './interface/job.repository.interface';
import { JobUtilInterface } from './interface/job.util.interface';
import {
  JOB_STATUS_ENUM,
  JOB_TYPE_ENUM,
  JOB_TYPE_MAINTENANCE_ENUM,
} from './job.constant';
import { MaintenanceTeamRepositoryInterface } from '@components/maintenance-team/interface/maintenance-team.repository.interface';
import { ROLE } from '@constant/common';
import { MAINTENANCE_TEAM_ROLE } from '@components/maintenance-team/maintenance-team.constant';
import {
  MaintenanceTeam,
  MaintenanceTeamMember,
} from '../../models/maintenance-team/maintenance-team.model';
import { LeanDocument } from 'mongoose';

@Injectable()
export class JobUtil implements JobUtilInterface {
  constructor(
    @Inject('JobRepositoryInterface')
    private readonly jobRepository: JobRepositoryInterface,
    @Inject('RepairRequestRepositoryInterface')
    private readonly repairRequestRepository: RepairRequestRepositoryInterface,
    @Inject('DeviceRepositoryInterface')
    private readonly deviceRepository: DeviceRepositoryInterface,
    @Inject('MaintenanceIndexRepositoryInterface')
    private readonly maintenanceIndexRepository: MaintenanceIndexRepositoryInterface,
    @Inject('MaintenanceTeamRepositoryInterface')
    private readonly maintenanceTeamRepository: MaintenanceTeamRepositoryInterface,
  ) {}

  async calculateMaintenanceIndexDevice(job: Job): Promise<any> {
    const mtta = await this.handleMtta(job, [job.deviceId]);
    const mttf = await this.calculateMttf(job);
    const mttr = await this.handleMttr(job, [job.deviceId]);
    const mtbf = await this.handleMtbf(job, [job.deviceId]);
    return pickBy(
      {
        mtta,
        mttf,
        mttr,
        mtbf,
      },
      identity,
    );
  }

  async calculateMaintenanceIndexDeviceGroup(
    job: Job,
    deviceGroup: any,
  ): Promise<any> {
    const deviceIds = await this.getDeviceIds(deviceGroup._id);

    const mtta = await this.handleMtta(job, deviceIds);
    const mttr = await this.handleMttr(job, deviceIds);
    const mtbf = await this.handleMtbf(job, deviceIds);
    const mttf = await this.calculateMttfGroup(job);

    return pickBy(
      {
        mtta,
        mttf,
        mttr,
        mtbf,
      },
      identity,
    );
  }

  private async calculateMttf(job: Job): Promise<any> {
    switch (job.result.maintenanceType) {
      case JOB_TYPE_MAINTENANCE_ENUM.REPLACE:
        const device = await this.deviceRepository.findOneById(job.deviceId);

        const repairRequest = await this.repairRequestRepository.findOneById(
          job.jobTypeId,
        );

        const timeCreated = repairRequest
          ? repairRequest.createdAt
          : job.createdAt;

        return moment(timeCreated).diff(moment(device.createdAt), 'hour');
      default:
        return null;
    }
  }

  private async calculateMttfGroup(job: Job): Promise<any> {
    switch (job.result.maintenanceType) {
      case JOB_TYPE_MAINTENANCE_ENUM.REPLACE:
        const device = await this.deviceRepository.findOneById(job.deviceId);

        if (!device) return null;

        const devices = await this.deviceRepository.findAllByCondition({
          deviceGroupId: device.deviceGroupId,
        });
        if (isEmpty(devices)) return null;

        const deviceIds = devices.map((e) => e._id);

        const maintenanceIndexes =
          await this.maintenanceIndexRepository.findAllByCondition({
            deviceId: {
              $in: deviceIds,
            },
          });

        if (isEmpty(maintenanceIndexes)) return null;

        const totalMttf = maintenanceIndexes.reduce(
          (total, item) => plus(total || 0, item.mttf || 0),
          0,
        );

        const countDevice = await this.deviceRepository.count({
          deviceGroupId: device.deviceGroupId,
        });

        return div(totalMttf || 0, countDevice || 1);
      default:
        return null;
    }
  }

  private async getDeviceIds(deviceGroupId: string): Promise<any> {
    const devices = await this.deviceRepository.findAllByCondition({
      deviceGroupId: deviceGroupId,
    });
    if (isEmpty(devices)) return null;

    return devices.map((e) => e._id);
  }

  private async handleMtta(job: Job, deviceIds: string[]): Promise<any> {
    switch (job.result.maintenanceType) {
      case JOB_TYPE_MAINTENANCE_ENUM.REPLACE: {
        const jobs = await this.jobRepository.findAllWithPopulate(
          {
            deviceId: {
              $in: deviceIds,
            },
            status: JOB_STATUS_ENUM.RESOLVED,
            type: JOB_TYPE_ENUM.UNEXPECTED_REPAIR,
            'result.maintenanceType': JOB_TYPE_MAINTENANCE_ENUM.REPLACE,
          },
          {
            path: 'jobType',
          },
        );

        // Tính thời gian phát hiện sự cố
        const total = jobs.reduce((total, item) => {
          // Thời gian xác nhận công việc
          const timeConfirmed = item.histories.find(
            (e) => e.status === JOB_STATUS_ENUM.IN_PROGRESS,
          )?.createdAt;

          // item['jobType']?.createdAt: thời gian tạo yêu cầu sửa chữa
          return plus(
            total || 0,
            moment(timeConfirmed).diff(
              moment(item['jobType']?.createdAt ?? item.createdAt),
              'hour',
            ),
          );
        }, 0);

        // Đếm số lần hỏng
        const countJob = await this.jobRepository.count({
          deviceId: {
            $in: deviceIds,
          },
          type: JOB_TYPE_ENUM.UNEXPECTED_REPAIR,
          'result.maintenanceType': JOB_TYPE_MAINTENANCE_ENUM.REPLACE,
          status: JOB_STATUS_ENUM.RESOLVED,
        });

        return div(total || 0, countJob || 1);
      }

      case JOB_TYPE_MAINTENANCE_ENUM.MAINTENANCE: {
        const countJob = await this.jobRepository.count({
          deviceId: {
            $in: deviceIds,
          },
          type: JOB_TYPE_ENUM.UNEXPECTED_REPAIR,
          'result.maintenanceType': JOB_TYPE_MAINTENANCE_ENUM.MAINTENANCE,
          status: JOB_STATUS_ENUM.RESOLVED,
        });

        const jobs = await this.jobRepository.findAllWithPopulate(
          {
            deviceId: {
              $in: deviceIds,
            },
            status: JOB_STATUS_ENUM.RESOLVED,
            type: JOB_TYPE_ENUM.UNEXPECTED_REPAIR,
            'result.maintenanceType': JOB_TYPE_MAINTENANCE_ENUM.MAINTENANCE,
          },
          {
            path: 'jobType',
          },
        );

        // Tính thời gian phát hiện sự cố
        const total = jobs.reduce((total, item) => {
          // Thời gian xác nhận công việc
          const timeConfirmed = item.histories.find(
            (e) => e.status === JOB_STATUS_ENUM.IN_PROGRESS,
          )?.createdAt;

          // item['jobType']?.createdAt: thời gian tạo yêu cầu sửa chữa
          return plus(
            total || 0,
            moment(timeConfirmed).diff(
              moment(item['jobType']?.createdAt ?? item.createdAt),
              'hour',
            ),
          );
        }, 0);

        return div(total || 0, countJob || 1);
      }
      default:
        return null;
    }
  }

  private async handleMttr(job: Job, deviceIds: string[]): Promise<any> {
    switch (job.result.maintenanceType) {
      case JOB_TYPE_MAINTENANCE_ENUM.REPLACE: {
        const jobs = await this.jobRepository.findAllByCondition({
          deviceId: {
            $in: deviceIds,
          },
          status: JOB_STATUS_ENUM.RESOLVED,
          type: {
            $in: [JOB_TYPE_ENUM.UNEXPECTED_REPAIR, JOB_TYPE_ENUM.MAINTAIN],
          },
          'result.maintenanceType': JOB_TYPE_MAINTENANCE_ENUM.REPLACE,
        });

        // Thời gian thực hiện công việc
        const total = jobs.reduce(
          (total, item) => plus(total || 0, item.executionTime || 0),
          0,
        );

        // Số lần hỏng
        const countJob = await this.jobRepository.count({
          deviceId: {
            $in: deviceIds,
          },
          type: JOB_TYPE_ENUM.UNEXPECTED_REPAIR,
          'result.maintenanceType': JOB_TYPE_MAINTENANCE_ENUM.REPLACE,
          status: JOB_STATUS_ENUM.RESOLVED,
        });

        return div(total || 0, countJob || 1);
      }
      case JOB_TYPE_MAINTENANCE_ENUM.MAINTENANCE: {
        const jobs = await this.jobRepository.findAllByCondition({
          deviceId: {
            $in: deviceIds,
          },
          status: JOB_STATUS_ENUM.RESOLVED,
          type: {
            $in: [JOB_TYPE_ENUM.UNEXPECTED_REPAIR, JOB_TYPE_ENUM.MAINTAIN],
          },
          'result.maintenanceType': JOB_TYPE_MAINTENANCE_ENUM.MAINTENANCE,
        });

        // Thời gian thực hiện công việc
        const total = jobs.reduce(
          (total, item) => plus(total || 0, item.executionTime || 0),
          0,
        );

        // Số lần hỏng
        const countJob = await this.jobRepository.count({
          deviceId: job.deviceId,
          type: {
            $in: [JOB_TYPE_ENUM.UNEXPECTED_REPAIR, JOB_TYPE_ENUM.MAINTAIN],
          },
          'result.maintenanceType': JOB_TYPE_MAINTENANCE_ENUM.MAINTENANCE,
          status: JOB_STATUS_ENUM.RESOLVED,
        });

        return div(total || 0, countJob || 1);
      }
      default:
        return null;
    }
  }

  private async handleMtbf(job: Job, deviceIds: string[]): Promise<any> {
    switch (job.result.maintenanceType) {
      case JOB_TYPE_MAINTENANCE_ENUM.MAINTENANCE:
        const jobs = await this.jobRepository.findAllWithPopulate(
          {
            deviceId: {
              $in: deviceIds,
            },
            status: JOB_STATUS_ENUM.RESOLVED,
            type: {
              $in: [JOB_TYPE_ENUM.UNEXPECTED_REPAIR, JOB_TYPE_ENUM.MAINTAIN],
            },
            'result.maintenanceType': JOB_TYPE_MAINTENANCE_ENUM.MAINTENANCE,
          },
          {
            path: 'jobType',
          },
        );

        let total = 0;
        for (let i = 0; i < jobs.length; i++) {
          const item = jobs[i];
          // Lấy công việc trước đó
          const beforeJob = await this.jobRepository.getBeforeJob(
            item._id,
            item.deviceId,
            JOB_TYPE_ENUM.UNEXPECTED_REPAIR,
            item.createdAt,
          );
          let device;
          if (!beforeJob) {
            device = await this.deviceRepository.findOneById(item.deviceId);
          }

          // Tìm thời gian tạo thiết bị hoặc thời gian xác nhận công việc trước đó
          const createdTime = beforeJob
            ? beforeJob.histories.find(
                (e) => e.status === JOB_STATUS_ENUM.IN_PROGRESS,
              )?.createdAt
            : device?.createdAt;

          total = plus(
            total || 0,
            moment(item['jobType']?.createdAt).diff(
              moment(createdTime),
              'hour',
            ) || 0,
          );
        }

        const countJob = await this.jobRepository.count({
          deviceId: {
            $in: deviceIds,
          },
          type: {
            $in: [JOB_TYPE_ENUM.UNEXPECTED_REPAIR, JOB_TYPE_ENUM.MAINTAIN],
          },
          'result.maintenanceType': JOB_TYPE_MAINTENANCE_ENUM.MAINTENANCE,
          status: JOB_STATUS_ENUM.RESOLVED,
        });

        return div(total || 0, countJob || 1);
      default:
        return null;
    }
  }

  async getAssignMaintenanceTeam(assign: Assign): Promise<MaintenanceTeam> {
    const filter = { _id: assign.teamId };
    if (assign.userId) filter['members.userId'] = assign.userId;
    return this.maintenanceTeamRepository.findOneByCondition(filter);
  }

  async getAssignMaintenanceTeamLeader(
    assign: Assign,
  ): Promise<MaintenanceTeamMember> {
    const maintenanceTeam = await this.getAssignMaintenanceTeam(assign);
    return maintenanceTeam?.members?.find(
      (member) => member.role === MAINTENANCE_TEAM_ROLE.LEADER,
    );
  }

  async getAssignMemberIds(assign: Assign): Promise<number[]> {
    if (assign.userId) return [+assign.userId];
    const maintenanceTeam = await this.getAssignMaintenanceTeam(assign);
    return maintenanceTeam?.members?.map((m) => +m.userId);
  }

  checkHasAssignPermission(job: LeanDocument<Job>, user: any): boolean {
    if (!job?.assign?.teamId) {
      return false;
    }

    if (job.assign.userId) {
      return user.id === job.assign.userId;
    }

    return (
      user?.maintenanceTeam?._id &&
      user.maintenanceTeam._id.toString() === job.assign.teamId.toString()
    );
  }

  checkIsAssignLeader(job: LeanDocument<Job>, user: any): boolean {
    return (
      job?.assign?.teamId &&
      user.role === ROLE.LEADER &&
      user.maintenanceTeam._id.toString() === job.assign.teamId.toString()
    );
  }

  checkIsAssignManager(job: LeanDocument<Job>, user: any): boolean {
    const factoryIds = Array.isArray(user?.factoryIds) ? user.factoryIds : [];
    const factoryId = job.device?.factoryId;
    const deviceGroupIds = Array.isArray(user?.maintenanceTeam?.deviceGroupIds)
      ? user.maintenanceTeam.deviceGroupIds
      : [];
    const deviceGroupId = job.device?.deviceGroupId?.toString();

    if (user.role === ROLE.ADMIN) {
      return true;
    }

    if (user.role === ROLE.FACTORY_MANAGER && factoryIds.includes(factoryId)) {
      return true;
    }

    return (
      user.role === ROLE.LEADER &&
      factoryIds.includes(factoryId) &&
      deviceGroupIds.includes(deviceGroupId)
    );
  }
}
