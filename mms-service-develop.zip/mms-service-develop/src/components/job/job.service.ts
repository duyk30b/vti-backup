import { DEVICE_STATUS_ENUM } from '@components/device/device.constant';
import { GetSuppliesByJobResponseDto } from './dto/response/get-supplies-by-job.response.dto';
import { Inject, Injectable } from '@nestjs/common';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { JobRepositoryInterface } from './interface/job.repository.interface';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { GetListJobRequestDto } from './dto/request/get-list-job.request.dto';
import {
  ceil,
  difference,
  first,
  flatMap,
  identity,
  isEmpty,
  keyBy,
  map,
  merge,
  pickBy,
  uniq,
} from 'lodash';
import { plainToInstance } from 'class-transformer';
import { JobServiceInterface } from './interface/job.service.interface';
import { JobAssignmentRequestDto } from './dto/request/job-assignment.request.dto';
import { ApiError } from '@utils/api.error';
import { UserService } from '@components/user/user.service';
import {
  JOB_ACTION_ENUM,
  JOB_ACTION_REJECT,
  JOB_EVENTS_ENUM,
  JOB_TYPE_MAINTENANCE_ENUM,
} from './job.constant';
import { JOB_STATUS_ENUM, JOB_TYPE_ENUM } from '@components/job/job.constant';
import { ApproveJobRequestDto } from './dto/request/approve-job.request.dto';
import { DetailJobResponse } from './dto/response/detail-job.response.dto';
import { ListJobResponseDto } from './dto/response/list-job.response.dto';
import {
  HISTORY_ACTION_ENUM,
  HISTORY_REASON_REF_ENUM,
  HISTORY_REF_ENUM,
} from '@components/history/history.constant';
import * as moment from 'moment';
import { ResponsePayload } from '@utils/response-payload';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { RepairRequestRepositoryInterface } from '@components/repair-request/interface/repair-request.repository.interface';
import { ExecuteJobFormData } from './dto/request/execute-job.request.dto';
import { REPAIR_REQUEST_STATUS_ENUM } from '@components/repair-request/repair-request.constant';
import { MaintenanceIndexRepositoryInterface } from '@components/maintenance-index/interface/maintenance-index.repository.interface';
import { DeviceRepositoryInterface } from '@components/device/interface/device.repository.interface';
import { JobUtilInterface } from './interface/job.util.interface';
import { DeviceGroupRepositoryInterface } from '@components/device-group/interface/device-group.repository.interface';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { JobQueryDto } from './dto/request/job.query.dto';
import { UpdateJobPlanRequestDto } from './dto/request/job-plan.request.dto';
import { DeviceAssignmentRepositoryInterface } from '@components/device-assignment/interface/device-assignment.repository.interface';
import {
  DEVICE_ASSIGNMENT_EVENTS_ENUM,
  DEVICE_ASSIGNMENTS_STATUS_ENUM,
} from '@components/device-assignment/device-assignment.constant';
import { DeviceRequestRepositoryInterface } from '@components/device-request/interface/device-request-ticket.repository.interface';
import { minus } from '@utils/common';
import { FileResource } from '@components/file/file.constant';
import { FileServiceInterface } from '@components/file/interface/file.service.interface';
import { GetSuppliesByJob } from './dto/request/get-supplies-by-job.param.dto';
import { GetInventoryByWarehousesAndAssetsRequestDto } from '@components/warehouse/dto/request/get-inventories-by-warehouses-assets.request.dto';
import { SUPPLY_REQUEST_STATUS_ENUM } from '@components/supply-request/supply-request.constant';
import { SupplyRequestRepositoryInterface } from '@components/supply-request/interface/supply-request.repository.interface';
import { InventoryRepositoryInterface } from '@components/warehouse/interface/inventory.repository.interface';
import { WarningRepositoryInterface } from '@components/warning/interface/warning.repository.interface';
import { WARNING_STATUS_ENUM } from '@components/warning/warning.constant';
import { ConfigService } from '@config/config.service';
import { FORMAT_DATE_UNDERSCORE } from '@utils/constant';
import { ACTIVE_ENUM, ROLE } from '@constant/common';
import { EventRequestDto } from '@components/notification/dto/event.request.dto';
import { MaintenanceTeamRepositoryInterface } from '@components/maintenance-team/interface/maintenance-team.repository.interface';
import { HistoryRepositoryInterface } from '@components/history/interface/history.repository.interface';
import { DeviceAssignmentServiceInterface } from '@components/device-assignment/interface/device-assignment.service.interface';
import { Job } from 'src/models/job/job.model';
import { JobAddReasonBodyDto } from './dto/request/add-reason-job.request.dto copy';
import { Device } from 'src/models/device/device.model';
import { QuickAssignJobsRequestDto } from './dto/request/quick-assign-jobs.request.dto';
import { UpdateResolvedJobTimeRequestDto } from './dto/request/update-resolve-job-time.request.dto';
import { UpdateStatusJobParamDto } from './dto/request/update-status-job.param';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { MaintenanceTeam } from '../../models/maintenance-team/maintenance-team.model';

@Injectable()
export class JobService implements JobServiceInterface {
  constructor(
    @Inject('JobRepositoryInterface')
    private readonly jobRepository: JobRepositoryInterface,
    private readonly i18n: I18nRequestScopeService,
    @Inject('UserServiceInterface')
    private readonly userService: UserService,
    @Inject('RepairRequestRepositoryInterface')
    private readonly repairRequestRepository: RepairRequestRepositoryInterface,
    @Inject('InventoryRepositoryInterface')
    private readonly inventoryRepository: InventoryRepositoryInterface,
    @Inject('MaintenanceIndexRepositoryInterface')
    private readonly maintenanceIndexRepository: MaintenanceIndexRepositoryInterface,
    @Inject('SupplyRequestRepositoryInterface')
    private readonly supplyRequestRepository: SupplyRequestRepositoryInterface,
    @Inject('DeviceRepositoryInterface')
    private readonly deviceRepository: DeviceRepositoryInterface,
    @Inject('DeviceGroupRepositoryInterface')
    private readonly deviceGroupRepository: DeviceGroupRepositoryInterface,
    @Inject('DeviceAssignmentRepositoryInterface')
    private readonly deviceAssignmentRepository: DeviceAssignmentRepositoryInterface,
    @Inject('DeviceRequestRepositoryInterface')
    private readonly deviceRequestRepository: DeviceRequestRepositoryInterface,
    @Inject('WarningRepositoryInterface')
    private readonly warningRepository: WarningRepositoryInterface,
    @Inject('MaintenanceTeamRepositoryInterface')
    private readonly maintenanceTeamRepository: MaintenanceTeamRepositoryInterface,
    @Inject('DeviceAssignmentServiceInterface')
    private readonly deviceAssignmentService: DeviceAssignmentServiceInterface,
    @Inject('FileServiceInterface')
    private readonly fileService: FileServiceInterface,
    @Inject('JobUtilInterface')
    private readonly jobUtil: JobUtilInterface,
    @Inject('HistoryRepositoryInterface')
    private readonly historyRepository: HistoryRepositoryInterface,
    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,
    private readonly eventEmitter: EventEmitter2,
    private readonly configService: ConfigService,
  ) {}

  protected readonly fileUri = this.configService.get('fileUri');

  async list(
    request: GetListJobRequestDto,
    isHistoryJob,
  ): Promise<ResponsePayload<any>> {
    const { user } = request;
    let isEmptyResult = false;
    if (!isHistoryJob) {
      switch (user.role) {
        case ROLE.FACTORY_MANAGER:
          {
            const devices = await this.deviceRepository.findAllByCondition({
              factoryId: { $in: user.factoryIds },
            });

            const deviceIds = devices.map((e) => e._id.toString());
            if (isEmpty(deviceIds)) {
              isEmptyResult = true;
            } else {
              request.filter = [
                ...(request.filter || []),
                {
                  column: 'deviceIds',
                  text: deviceIds.join(','),
                },
              ];
            }
          }
          break;
        case ROLE.LEADER:
          {
            const devices = await this.deviceRepository.findAllByCondition({
              deviceGroupId: {
                $in: user.maintenanceTeam?.deviceGroupIds,
              },
              factoryId: { $in: user.factoryIds },
            });
            const deviceIds = devices.map((e) => e._id.toString());
            if (isEmpty(deviceIds)) {
              isEmptyResult = true;
            } else {
              request.filter = [
                ...(request.filter || []),
                {
                  column: 'deviceIds',
                  text: deviceIds.join(','),
                },
              ];
            }
          }
          break;
        case ROLE.MEMBER:
          {
            request.filter = [
              ...(request.filter || []),
              {
                column: 'myJob',
                text: '1',
              },
            ];
          }
          break;
        case ROLE.OTHER:
          isEmptyResult = true;
          break;
        default:
          break;
      }
    }
    if (isEmptyResult) {
      return new ResponseBuilder<any>({
        items: [],
        meta: { page: 1, total: 0 },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    const { data, total } = await this.jobRepository.list(request);

    const assignUserIdsSet = new Set();
    const assignTeamIdsSet = new Set();

    data.forEach((j) => {
      if (j?.assign?.userId) {
        assignUserIdsSet.add(j?.assign?.userId);
      }
      assignTeamIdsSet.add(j?.assign?.teamId?.toString());
    });

    const assignUserIds = [...assignUserIdsSet];
    const assignTeamIds = [...assignTeamIdsSet];

    const _users = assignUserIds.length
      ? this.userService.getList([
          { column: 'userIds', text: assignUserIds.join(',') },
        ])
      : [];
    const _teams = assignTeamIds.length
      ? this.maintenanceTeamRepository.findAllByCondition({
          _id: { $in: assignTeamIds },
        })
      : [];

    const [users, teams] = await Promise.all([_users, _teams]);

    const userMap = keyBy(users, 'id');
    const teamMap = keyBy(teams, '_id');

    const res = data.map((job) => ({
      ...job,
      assign: {
        ...job.assign,
        user: userMap[job?.assign?.userId],
        team: teamMap[job?.assign?.teamId],
      },
    }));

    const dataReturn = plainToInstance(ListJobResponseDto, res, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder({
      items: dataReturn,
      meta: { page: request.page, total: total },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async assignment(
    request: JobAssignmentRequestDto & JobQueryDto & IdParamDto,
  ): Promise<ResponsePayload<any>> {
    const {
      assignUserId,
      assignTeamId,
      user,
      planFrom,
      planTo,
      isNeedAccept,
      id,
      reason,
    } = request;

    if (!assignTeamId) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    const job = await this.jobRepository.findOneByCondition({
      _id: id,
      isShow: true,
    });

    if (!job) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const isStatusValid = this.checkStatusValid(
      job.status,
      JOB_STATUS_ENUM.WAIT_CONFIRM,
    );
    if (!isStatusValid) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.JOB_STATUS_INVALID'))
        .build();
    }

    const device = await this.deviceRepository.findOneById(job.deviceId);

    if (!device) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.BAD_REQUEST'),
      ).toResponse();
    }

    if (device.active !== ACTIVE_ENUM.ACTIVE) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.DEVICE_INACTIVE'))
        .build();
    }

    const isJobManager = this.jobUtil.checkIsAssignManager(
      {
        ...job,
        device,
      },
      user,
    );

    if (!isJobManager) {
      return new ApiError(
        ResponseCodeEnum.NOT_ACCEPTABLE,
        await this.i18n.translate('error.NOT_ACCEPTABLE'),
      ).toResponse();
    }

    const maintenanceTeam =
      await this.maintenanceTeamRepository.findOneByCondition({
        _id: assignTeamId,
      });

    if (!this.checkIsValidAssign(maintenanceTeam, assignUserId)) {
      return new ApiError(
        ResponseCodeEnum.NOT_ACCEPTABLE,
        await this.i18n.translate('error.CANNOT_ASSIGN_FOR_USER'),
      ).toResponse();
    }

    const assignee = assignUserId
      ? await this.userService.getDetailUser(assignUserId)
      : maintenanceTeam;

    if (!assignee) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const history = {
      userId: user?.id,
      action: HISTORY_ACTION_ENUM.UPDATE,
      createdAt: new Date(),
      content: (await this.i18n.translate('text.userAssignedJobTo'))
        .replace('{username}', user.username)
        .replace('{assignee}', assignee.username || assignee.name),
      status: JOB_STATUS_ENUM.WAIT_CONFIRM,
      reason,
    };

    const jobSaved = await this.jobRepository.findByIdAndUpdate(job._id, {
      status: JOB_STATUS_ENUM.WAIT_CONFIRM,
      assign: {
        userId: assignUserId,
        teamId: assignTeamId,
      },
      planFrom,
      planTo,
      isNeedAccept: Boolean(isNeedAccept),
      $push: { histories: history },
    });

    this.eventEmitter.emit(
      JOB_EVENTS_ENUM.ASSIGNMENT,
      new EventRequestDto({
        id: jobSaved._id,
        code: jobSaved.code,
        name: jobSaved.name,
        entityType: job.type,
        fromUserId: request.user.id,
      }),
    );

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private checkIsValidAssign(
    maintenanceTeam: MaintenanceTeam,
    userId?: number,
  ): boolean {
    if (userId) {
      const members = Array.isArray(maintenanceTeam?.members)
        ? maintenanceTeam.members
        : [];
      return members.length && members.some((m) => m.userId === userId);
    }
    return true;
  }

  private checkStatusValid(oldStatus: number, newStatus: number): boolean {
    switch (newStatus) {
      case JOB_STATUS_ENUM.CONFIRM:
        return oldStatus === JOB_STATUS_ENUM.WAIT_CONFIRM;
      case JOB_STATUS_ENUM.IN_PROGRESS:
        return (
          oldStatus === JOB_STATUS_ENUM.CONFIRM ||
          oldStatus === JOB_STATUS_ENUM.COMPLETED
        );
      case JOB_STATUS_ENUM.REJECT:
        return oldStatus === JOB_STATUS_ENUM.WAIT_CONFIRM;
      case JOB_STATUS_ENUM.WAIT_CONFIRM:
        return (
          oldStatus === JOB_STATUS_ENUM.NON_ASSIGN ||
          oldStatus === JOB_STATUS_ENUM.REJECT
        );
      default:
        return false;
    }
  }

  async updateStatus(params: any): Promise<ResponsePayload<any>> {
    const { id, action, user, reason } = params;
    const job = await this.jobRepository.findOneByCondition({
      _id: id,
      isShow: true,
    });
    if (!job) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const device = await this.deviceRepository.findOneById(job.deviceId);

    if (device && device.active !== ACTIVE_ENUM.ACTIVE) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.DEVICE_INACTIVE'))
        .build();
    }

    let status = 0;
    let contentHistory = '';
    const dataUpdate: any = {};

    if (
      [
        JOB_ACTION_ENUM.IN_PROGRESS,
        JOB_ACTION_ENUM.CONFIRM,
        JOB_ACTION_ENUM.REJECT,
      ].includes(action)
    ) {
      const hasPermission = this.jobUtil.checkHasAssignPermission(job, user);
      if (!hasPermission) {
        return new ApiError(
          ResponseCodeEnum.NOT_ACCEPTABLE,
          await this.i18n.translate('error.NOT_ACCEPTABLE'),
        ).toResponse();
      }
    }

    if (action === JOB_ACTION_ENUM.REWORK) {
      const hasPermission = this.jobUtil.checkIsAssignLeader(job, user);
      if (!hasPermission) {
        return new ApiError(
          ResponseCodeEnum.NOT_ACCEPTABLE,
          await this.i18n.translate('error.NOT_ACCEPTABLE'),
        ).toResponse();
      }
    }

    switch (action) {
      case JOB_ACTION_ENUM.CONFIRM:
        status = JOB_STATUS_ENUM.CONFIRM;
        contentHistory = await this.i18n
          .translate('text.userConfirmedJob')
          .replace('{username}', user?.username);
        break;
      case JOB_ACTION_ENUM.IN_PROGRESS:
        status = JOB_STATUS_ENUM.IN_PROGRESS;
        contentHistory = await this.i18n
          .translate('text.userInProgressJob')
          .replace('{username}', user?.username);
        break;
      case JOB_ACTION_ENUM.REJECT:
        status = JOB_STATUS_ENUM.REJECT;
        contentHistory = await this.i18n
          .translate('text.userHasRejectedJob')
          .replace('{username}', user?.username);
        break;
      case JOB_ACTION_ENUM.REWORK:
        dataUpdate.result = null;
        status = JOB_STATUS_ENUM.IN_PROGRESS;
        contentHistory = await this.i18n
          .translate('text.userReworkJob')
          .replace('{username}', user?.username);
        break;
      default:
        break;
    }

    const isStatusValid = this.checkStatusValid(job.status, status);
    if (!isStatusValid) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.JOB_STATUS_INVALID'))
        .build();
    }

    const history = {
      userId: user?.id,
      action: HISTORY_ACTION_ENUM.UPDATE,
      createdAt: new Date(),
      content: contentHistory,
      status: status,
      reason,
    };

    const newJob = await this.jobRepository.findByIdAndUpdate(job._id, {
      ...dataUpdate,
      status,
      $push: {
        histories: history,
      },
    });
    const eventPayload = new EventRequestDto({
      id: job._id,
      code: job.code,
      name: job.name,
      entityType: job.type,
      fromUserId: params.user.id,
    });
    switch (action) {
      case JOB_ACTION_ENUM.CONFIRM:
        this.eventEmitter.emit(JOB_EVENTS_ENUM.CONFIRM, eventPayload);
        break;
      case JOB_ACTION_ENUM.IN_PROGRESS:
        this.eventEmitter.emit(JOB_EVENTS_ENUM.IN_PROGRESS, eventPayload);
        break;
      case JOB_ACTION_REJECT:
        this.eventEmitter.emit(JOB_EVENTS_ENUM.REJECT, eventPayload);
        break;
      case JOB_ACTION_ENUM.REWORK:
        this.eventEmitter.emit(JOB_EVENTS_ENUM.REWORK, eventPayload);
        break;
      default:
        break;
    }

    if (job.warningId) {
      this.handleUpdateWarning(job.warningId, newJob);
    }
    if (job.type === JOB_TYPE_ENUM.UNEXPECTED_REPAIR) {
      await this.updateRepairRequestByJobStatus(job.jobTypeId, status);
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async changeStatus(
    params: UpdateStatusJobParamDto,
  ): Promise<ResponsePayload<any>> {
    const { id, status, user } = params;
    const job = await this.jobRepository.findOneByCondition({
      _id: id,
      isShow: true,
    });
    if (!job) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const device = await this.deviceRepository.findOneById(job.deviceId);
    if (device && device.active !== ACTIVE_ENUM.ACTIVE) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.DEVICE_INACTIVE'))
        .build();
    }
    const oldStatus = job.status;
    const eventPayload = new EventRequestDto({
      id: job._id,
      code: job.code,
      name: job.name,
      entityType: job.type,
      fromUserId: user.id,
    });
    const updateData: any = {
      status,
    };
    switch (status) {
      case JOB_STATUS_ENUM.NON_ASSIGN:
        if (
          oldStatus !== JOB_STATUS_ENUM.WAIT_CONFIRM &&
          oldStatus !== JOB_STATUS_ENUM.IN_PROGRESS &&
          oldStatus !== JOB_STATUS_ENUM.CONFIRM
        ) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(await this.i18n.translate('error.JOB_STATUS_INVALID'))
            .build();
        }
        updateData.assign = null;
        updateData.isNeedAccept = null;
        updateData.planFrom = null;
        updateData.planTo = null;
        break;
      case JOB_STATUS_ENUM.WAIT_CONFIRM:
        if (
          oldStatus !== JOB_STATUS_ENUM.IN_PROGRESS &&
          oldStatus !== JOB_STATUS_ENUM.CONFIRM
        ) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(await this.i18n.translate('error.JOB_STATUS_INVALID'))
            .build();
        }
        break;
      case JOB_STATUS_ENUM.CONFIRM:
        if (oldStatus !== JOB_STATUS_ENUM.IN_PROGRESS) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(await this.i18n.translate('error.JOB_STATUS_INVALID'))
            .build();
        }
        break;
      default:
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.BAD_REQUEST'),
        ).toResponse();
    }

    if (oldStatus === JOB_STATUS_ENUM.IN_PROGRESS) {
      updateData.executionTime = null;
      if (job.warningId) {
        await this.warningRepository.findByIdAndUpdate(job.warningId, {
          status: WARNING_STATUS_ENUM.CONFIRMED,
        });
      }
      if (job.type === JOB_TYPE_ENUM.UNEXPECTED_REPAIR) {
        await this.updateRepairRequestByJobStatus(
          job.jobTypeId,
          JOB_STATUS_ENUM.CONFIRM,
        );
      }
    }
    const jobStatusText = await this.i18n.translate('text.JOB_STATUS');
    const jobStatusMap = new Map();
    jobStatusMap.set(JOB_STATUS_ENUM.NON_ASSIGN, jobStatusText.NON_ASSIGN);
    jobStatusMap.set(JOB_STATUS_ENUM.WAIT_CONFIRM, jobStatusText.WAIT_CONFIRM);
    jobStatusMap.set(JOB_STATUS_ENUM.CONFIRM, jobStatusText.CONFIRM);
    jobStatusMap.set(JOB_STATUS_ENUM.IN_PROGRESS, jobStatusText.IN_PROGRESS);
    jobStatusMap.set(JOB_STATUS_ENUM.REJECT, jobStatusText.REJECT);
    jobStatusMap.set(JOB_STATUS_ENUM.COMPLETED, jobStatusText.COMPLETED);
    jobStatusMap.set(JOB_STATUS_ENUM.RESOLVED, jobStatusText.RESOLVED);
    const history = {
      userId: user?.id,
      action:
        oldStatus === JOB_STATUS_ENUM.IN_PROGRESS
          ? HISTORY_ACTION_ENUM.CHANGE_STATUS_IN_PROGRESS
          : HISTORY_ACTION_ENUM.UPDATE,
      createdAt: new Date(),
      content: await this.i18n.translate('text.userHasUpdateStatusJob', {
        args: {
          username: user.username,
          oldStatus: jobStatusMap.get(oldStatus).toLocaleLowerCase(),
          newStatus: jobStatusMap.get(status).toLocaleLowerCase(),
        },
      }),
      status: status,
    };
    await this.jobRepository.findByIdAndUpdate(job._id, {
      ...updateData,
      $push: { histories: history },
    });
    this.eventEmitter.emit(JOB_EVENTS_ENUM.UPDATE_STATUS, eventPayload);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async execute(
    request: ExecuteJobFormData & IdParamDto & JobQueryDto,
  ): Promise<ResponsePayload<any>> {
    const { data } = request;

    const job = await this.jobRepository.findOneByCondition({
      _id: request.id,
      isShow: true,
    });

    if (!job) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const device = await this.deviceRepository.findOneById(job.deviceId);

    if (device && device.active !== ACTIVE_ENUM.ACTIVE) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.DEVICE_INACTIVE'))
        .build();
    }

    if (job.status !== JOB_STATUS_ENUM.IN_PROGRESS) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.JOB_STATUS_INVALID'),
      ).toResponse();
    }

    const hasPermission = this.jobUtil.checkHasAssignPermission(
      job,
      request.user,
    );

    if (!hasPermission) {
      return new ApiError(
        ResponseCodeEnum.NOT_ACCEPTABLE,
        await this.i18n.translate('error.NOT_ACCEPTABLE'),
      ).toResponse();
    }
    const status = job.isNeedAccept
      ? JOB_STATUS_ENUM.COMPLETED
      : JOB_STATUS_ENUM.RESOLVED;
    const content = (
      await this.i18n.translate(
        `text.${
          job.isNeedAccept ? 'userHasExecutedJob' : 'executedJobNoApprove'
        }`,
      )
    ).replace('{username}', request.user.username);

    const history = {
      content,
      userId: request.user.id,
      createdAt: new Date(),
      action: HISTORY_ACTION_ENUM.UPDATE,
      status,
    };
    let historyForExecuteTime: any;
    job.histories.forEach((e) => {
      if (e.action === HISTORY_ACTION_ENUM.CHANGE_STATUS_IN_PROGRESS) {
        historyForExecuteTime = null;
      }
      if (e.status === JOB_STATUS_ENUM.IN_PROGRESS && !historyForExecuteTime) {
        historyForExecuteTime = e;
      }
    });
    const executionTime = ceil(
      moment().diff(moment(historyForExecuteTime?.createdAt), 'second') / 60,
    );
    const stopTime = ceil(
      moment().diff(
        moment(
          job.histories.find((e) => e.status === JOB_STATUS_ENUM.IN_PROGRESS)
            ?.createdAt,
        ),
        'second',
      ) / 60,
    );

    let dataUpdate: any = {};

    switch (job.type) {
      case JOB_TYPE_ENUM.INSTALLATION:
        dataUpdate = {
          status: status,
          executionDateFrom: data.executionDateFrom,
          executionDateTo: data.executionDateTo,
          executionTime,
          result: {
            result: data.result,
            details: data.installationTemplateDetails,
          },
          $push: { histories: history },
        };
        break;
      case JOB_TYPE_ENUM.PERIOD_CHECKLIST:
        {
          dataUpdate = {
            status: status,
            executionDateFrom: data.executionDateFrom,
            executionDateTo: data.executionDateTo,
            executionTime,
            stopTime,
            result: {
              result: data.result,
              details: data.checklistDetails,
            },
            $push: { histories: history },
          };
        }
        break;
      case JOB_TYPE_ENUM.UNEXPECTED_REPAIR:
        const repairRequest = await this.repairRequestRepository.findOneById(
          job.jobTypeId,
        );
        const repairRequestStopTime = ceil(
          moment().diff(repairRequest.createdAt, 'second') / 60,
        );
        dataUpdate = {
          status: status,
          executionDateFrom: data.executionDateFrom,
          executionDateTo: data.executionDateTo,
          executionTime,
          stopTime: repairRequestStopTime,
          supplies: data.supplies,
          result: {
            maintenanceType: data.information?.maintenanceType,
            description: data.information?.description,
          },
          $push: { histories: history },
        };
        await this.updateRepairRequestByJobStatus(job.jobTypeId, status, {
          supplies: data.supplies,
          executionTime,
          stopTime: repairRequestStopTime,
          executedBy: request.user.id,
        });

        break;
      case JOB_TYPE_ENUM.MAINTAIN:
        dataUpdate = {
          status: status,
          executionDateFrom: data.executionDateFrom,
          executionDateTo: data.executionDateTo,
          executionTime,
          stopTime,
          supplies: data.supplies,
          result: {
            maintenanceType: data.information?.maintenanceType,
            description: data.information?.description,
          },
          $push: { histories: history },
        };

        break;
      case JOB_TYPE_ENUM.ACCREDITATION:
        let imageUrl = '';
        let fileExtension = '';
        if (request?.file) {
          const response = await this.fileService.uploadFile(
            first(request.file),
            FileResource.ACCREDITATION,
          );

          if (!response?.fileUrl) {
            return new ApiError(
              ResponseCodeEnum.BAD_REQUEST,
              await this.i18n.translate('error.UPLOAD_FILE_ERROR'),
            ).toResponse();
          }

          imageUrl = response.fileUrl;
          fileExtension = response.fileExtension;
        }

        const device = await this.deviceRepository.findOneById(job.deviceId);

        dataUpdate = {
          imageUrl,
          fileName: `ket_qua_kiem_dinh_${device?.code}_${
            job.code
          }_${moment().format(FORMAT_DATE_UNDERSCORE)}.${fileExtension}`,
          status: status,
          executionDateFrom: data.executionDateFrom,
          executionDateTo: data.executionDateTo,
          executionTime,
          stopTime,
          supplies: data.supplies,
          result: {
            result: data.result,
            details: data.accreditationTemplateDetails,
          },
          $push: { histories: history },
        };

        break;
      default:
        break;
    }

    const newJob = await this.jobRepository.findByIdAndUpdate(
      request.id,
      dataUpdate,
    );
    if (job.warningId) {
      this.handleUpdateWarning(job.warningId, newJob);
    }

    if (!job.isNeedAccept) {
      await this.handleWhenJobResolve(newJob, request);
    } else {
      this.eventEmitter.emit(
        JOB_EVENTS_ENUM.COMPLETE,
        new EventRequestDto({
          id: job._id,
          code: job.code,
          name: job.name,
          entityType: job.type,
          fromUserId: request.user.id,
        }),
      );
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async approve(
    request: ApproveJobRequestDto & IdParamDto & JobQueryDto,
  ): Promise<ResponsePayload<any>> {
    const job = await this.jobRepository.findOneByCondition({
      _id: request.id,
      isShow: true,
    });

    if (!job) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const deviceExist = await this.deviceRepository.findOneById(job.deviceId);

    if (deviceExist && deviceExist.active !== ACTIVE_ENUM.ACTIVE) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.DEVICE_INACTIVE'))
        .build();
    }

    const hasPermission = this.jobUtil.checkIsAssignLeader(job, request.user);

    if (!hasPermission) {
      return new ApiError(
        ResponseCodeEnum.NOT_ACCEPTABLE,
        await this.i18n.translate('error.NOT_ACCEPTABLE'),
      ).toResponse();
    }

    if (job.status !== JOB_STATUS_ENUM.COMPLETED) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.JOB_STATUS_INVALID'),
      ).toResponse();
    }

    const history = {
      content: (await this.i18n.translate('text.approveJob')).replace(
        '{username}',
        request.user.username,
      ),
      userId: request.user.id,
      createdAt: new Date(),
      action: HISTORY_ACTION_ENUM.UPDATE,
      status: JOB_STATUS_ENUM.RESOLVED,
    };

    const newJob = await this.jobRepository.findByIdAndUpdate(request.id, {
      status: JOB_STATUS_ENUM.RESOLVED,
      executionTime: request?.executionTime || null,
      stopTime: request?.stopTime || null,
      $push: { histories: history },
    });
    await this.handleWhenJobResolve(newJob, request);
    const maintenanceIndex =
      await this.maintenanceIndexRepository.findOneByCondition({
        deviceId: job.deviceId,
        supplyId: null,
      });

    const maintenanceIndexDevice =
      await this.jobUtil.calculateMaintenanceIndexDevice(job);

    // Cap nhat thong tin bao tri
    if (maintenanceIndex)
      await this.maintenanceIndexRepository.findByIdAndUpdate(
        maintenanceIndex._id,
        maintenanceIndexDevice,
      );
    const device = await this.deviceRepository.findOneById(job.deviceId);

    const deviceGroup = await this.deviceGroupRepository.findOneById(
      device.deviceGroupId,
    );

    const maintenanceIndexDeviceGroup =
      await this.jobUtil.calculateMaintenanceIndexDeviceGroup(job, deviceGroup);

    deviceGroup.maintenanceIndex.forEach((e) => {
      if (!e.supplyId) {
        e = merge(e, maintenanceIndexDeviceGroup);
      }
    });

    await this.deviceGroupRepository.findByIdAndUpdate(
      deviceGroup._id,
      deviceGroup,
    );

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async handleWhenJobResolve(newJob: Job, request) {
    switch (newJob.type) {
      case JOB_TYPE_ENUM.INSTALLATION:
        await this.handleResolvedJobInstallation(newJob);
        break;
      case JOB_TYPE_ENUM.UNEXPECTED_REPAIR:
        await this.updateRepairRequestByJobStatus(
          newJob.jobTypeId,
          newJob.status,
        );
        await this.updateStatusDeviceWhenReplace(newJob, request.user);
        break;

      case JOB_TYPE_ENUM.MAINTAIN:
        await this.updateStatusDeviceWhenReplace(newJob, request.user);
        await this.deviceRepository.findByIdAndUpdate(newJob.deviceId, {
          lastMaintenanceDate: new Date(),
        });
        break;

      case JOB_TYPE_ENUM.ACCREDITATION:
        await this.deviceRepository.findByIdAndUpdate(newJob.deviceId, {
          lastAccreditationDate: new Date(),
        });
        break;
      default:
        break;
    }

    if (newJob.warningId) {
      await this.handleUpdateWarning(newJob.warningId, newJob);
    }

    this.eventEmitter.emit(
      JOB_EVENTS_ENUM.RESOLVE,
      new EventRequestDto({
        id: newJob._id,
        code: newJob.code,
        name: newJob.name,
        entityType: newJob.type,
        fromUserId: request.user.id,
      }),
    );
  }

  async detail(request: IdParamDto): Promise<any> {
    const { user } = request;

    const job = await this.jobRepository.detail(request.id);

    if (isEmpty(job)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.JOB_NOT_FOUND'),
      ).toResponse();
    }

    const hasAssignPermission = this.jobUtil.checkHasAssignPermission(
      job,
      user,
    );
    const isAssignManager = this.jobUtil.checkIsAssignManager(job, user);

    if (!hasAssignPermission && !isAssignManager) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.JOB_NOT_FOUND'),
      ).toResponse();
    }

    if (!isEmpty(job.assign) && job.assign?.teamId) {
      job.assign.user = await this.userService.getDetailUser(job.assign.userId);
      job.assign.team = await this.maintenanceTeamRepository.findOneByCondition(
        { _id: job.assign?.teamId },
      );
    }
    if (job.device.factoryId) {
      const factory = await this.userService.getFactoryById(
        job.device.factoryId,
      );
      job.device.factory = factory || {};
    }
    const unitIds = [];

    const supplyIds = [];
    job.device.listSupply.forEach((e) => {
      supplyIds.push(e._id);
      unitIds.push(e.unitId);
    });
    job.listSupply.forEach((e) => {
      unitIds.push(e.unitId);
    });
    const units = await this.itemService.getListUnit([
      {
        column: 'ids',
        text: uniq(unitIds).toString(),
      },
    ]);
    const unitMap = keyBy(units, 'id');
    const inventories = await this.inventoryRepository.findAllByCondition({
      assetId: {
        $in: supplyIds,
      },
    });

    const inventoryMap = keyBy(inventories, 'assetId');

    job.device.supplies.forEach((supply) => {
      supply.stockQuantity =
        inventoryMap[supply.supplyId.toString()]?.stockQuantity || 0;
    });
    job.device.unitMap = unitMap;

    const dataReturn = plainToInstance(
      DetailJobResponse,
      { ...job, unitMap },
      {
        excludeExtraneousValues: true,
      },
    );

    dataReturn.imageUrl = dataReturn.imageUrl
      ? `${this.fileUri}${dataReturn.imageUrl}`
      : '';

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateJobPlan(
    request: UpdateJobPlanRequestDto,
  ): Promise<ResponsePayload<any>> {
    const condition = request.items.map((e) => ({
      _id: e.jobId,
      isShow: false,
      maintenancePlanId: request.maintenancePlanId,
      status: JOB_STATUS_ENUM.NON_ASSIGN,
    }));

    const jobs = await this.jobRepository.findAllByCondition({
      $or: condition,
    });

    if (condition.length !== jobs.length) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.BAD_REQUEST'),
      ).toResponse();
    }

    const jobMap = keyBy(request.items, 'jobId');

    const data = jobs.map((job) => {
      return {
        updateOne: {
          filter: { _id: job._id },
          update: {
            ...job,
            planFrom: jobMap[job._id.toString()].planFrom,
            planTo: jobMap[job._id.toString()].planTo,
          },
          upsert: false,
        },
      };
    });

    await this.jobRepository.bulkWrite(data);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getSuppliesByJob(request: GetSuppliesByJob): Promise<any> {
    const { id, warehouseId } = request;
    const job: any = await this.jobRepository.findOneWithPopulate({ _id: id }, [
      {
        path: 'device',
        populate: {
          path: 'deviceGroup',
          populate: {
            path: 'supplies.supply',
            populate: 'supplyGroup vendor',
          },
        },
      },
    ]);
    if (!job) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const unitIds = map(
      job.device?.deviceGroup?.supplies,
      (e) => e?.supply?.unitId,
    );
    const units = await this.itemService.getListUnit([
      {
        column: 'ids',
        text: unitIds.toString(),
      },
    ]);
    const unitMap = keyBy(units, 'id');
    const suppliesMap = keyBy(job?.device?.deviceGroup?.supplies, 'supplyId');
    const supplyIds = Object.keys(suppliesMap);

    // lấy tồn kho của vtpt
    const supplyInventories =
      await this.inventoryRepository.getInventoryByWarehousesAndAssets({
        assetIds: supplyIds,
        warehouseIds: [warehouseId],
      } as GetInventoryByWarehousesAndAssetsRequestDto);
    const supplyInventoryMap = keyBy(supplyInventories, '_id.assetId');

    // lấy số lượng vtpt đã kế hoạch
    const supplyRequest = await this.supplyRequestRepository.findAllByCondition(
      {
        'supplies.supplyId': { $in: supplyIds },
        status: SUPPLY_REQUEST_STATUS_ENUM.CONFIRM,
      },
    );
    const supplyPlannedInventoryMap = keyBy(
      flatMap(supplyRequest, 'supplies'),
      'supplyId',
    );

    const supplyInventory = supplyIds.map((supplyId) => {
      const stockQuantity = supplyInventoryMap[supplyId]?.stockQuantity || 0;
      const minStockQuantity =
        supplyInventoryMap[supplyId]?.minStockQuantity || 0;
      const availableStockQuantity = minus(
        minus(
          stockQuantity || 0,
          supplyPlannedInventoryMap[supplyId]?.quantity || 0,
        ),
        minStockQuantity || 0,
      );
      return {
        ...suppliesMap[supplyId],
        ...suppliesMap[supplyId]?.supply,
        unit: unitMap[suppliesMap[supplyId]?.supply?.unitId],
        stockQuantity,
        minStockQuantity,
        availableStockQuantity,
      };
    });

    const res = plainToInstance(GetSuppliesByJobResponseDto, supplyInventory, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(res)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async addReasonJobInprogress(
    request: JobAddReasonBodyDto & IdParamDto,
  ): Promise<any> {
    const { id, reason } = request;
    const job = await this.jobRepository.findOneWithPopulate(
      {
        _id: id,
      },
      'device',
    );
    const { user } = request;
    const hasPermission = this.jobUtil.checkHasAssignPermission(
      job,
      request.user,
    );
    if (!hasPermission) {
      return new ApiError(
        ResponseCodeEnum.NOT_ACCEPTABLE,
        await this.i18n.translate('error.NOT_ACCEPTABLE'),
      ).toResponse();
    }
    if (job.status !== JOB_STATUS_ENUM.IN_PROGRESS) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.JOB_STATUS_INVALID'),
      ).toResponse();
    }
    const history = {
      userId: user?.id,
      action: HISTORY_ACTION_ENUM.UPDATE,
      createdAt: new Date(),
      content: await this.i18n.translate('text.userAddReason', {
        args: { username: user.username },
      }),
      status: JOB_STATUS_ENUM.IN_PROGRESS,
      reason,
    };
    await this.jobRepository.findByIdAndUpdate(id, {
      $push: { histories: history },
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async quickAssignJobs(
    request: QuickAssignJobsRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { user, jobs } = request;

    const jobExists = await this.jobRepository.findAllWithPopulate(
      {
        _id: { $in: map(jobs, 'jobId') },
        isShow: true,
        status: {
          $in: [JOB_STATUS_ENUM.NON_ASSIGN, JOB_STATUS_ENUM.REJECT],
        },
      },
      'device',
    );

    if (jobExists?.length !== jobs.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const jobMap = keyBy(jobExists, '_id');

    const isJobManagers = jobs.every((j) => {
      return this.jobUtil.checkIsAssignManager(jobMap[j.jobId], user);
    });

    if (!isJobManagers) {
      return new ApiError(
        ResponseCodeEnum.NOT_ACCEPTABLE,
        await this.i18n.translate('error.NOT_ACCEPTABLE'),
      ).toResponse();
    }

    const isDeviceValid = jobs.every(
      (j) => jobMap[j.jobId]?.device?.active === ACTIVE_ENUM.ACTIVE,
    );

    if (!isDeviceValid) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.DEVICE_INACTIVE'))
        .build();
    }

    const assignTeamIds = uniq(map(jobs, 'assignTeamId')).filter(Boolean);
    const assignUserIds = uniq(map(jobs, 'assignUserId')).filter(Boolean);

    const maintenanceTeams =
      await this.maintenanceTeamRepository.findAllByCondition({
        _id: { $in: assignTeamIds },
      });
    const users = await this.userService.getList([
      { column: 'userIds', text: assignUserIds.join(',') },
    ]);

    if (users?.length !== assignUserIds.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const teamMap = keyBy(maintenanceTeams, '_id');
    const userMap = keyBy(users, 'id');

    const isValidAssigns = jobs.every((j) => {
      return this.checkIsValidAssign(teamMap[j.assignTeamId], j.assignUserId);
    });

    if (!isValidAssigns) {
      return new ApiError(
        ResponseCodeEnum.NOT_ACCEPTABLE,
        await this.i18n.translate('error.CANNOT_ASSIGN_FOR_USER'),
      ).toResponse();
    }

    const assignContent = await this.i18n.translate('text.userAssignedJobTo');
    const writes = jobs.map((j) => {
      const job = jobMap[j.jobId];
      const assignee = j.assignUserId
        ? userMap[j.assignUserId]
        : teamMap[j.assignTeamId];
      const history = {
        userId: user?.id,
        action: HISTORY_ACTION_ENUM.UPDATE,
        createdAt: new Date(),
        content: assignContent
          .replace('{username}', user.username)
          .replace('{assignee}', assignee.username || assignee.name),
        status: JOB_STATUS_ENUM.WAIT_CONFIRM,
      };

      this.eventEmitter.emit(
        JOB_EVENTS_ENUM.ASSIGNMENT,
        new EventRequestDto({
          id: job._id,
          code: job.code,
          name: job.name,
          entityType: job.type,
          fromUserId: request.user.id,
        }),
      );

      return {
        updateOne: {
          filter: { _id: j.jobId },
          update: {
            status: JOB_STATUS_ENUM.WAIT_CONFIRM,
            assign: {
              userId: j.assignUserId,
              teamId: j.assignTeamId,
            },
            planFrom: j.planFrom,
            planTo: j.planTo,
            isNeedAccept: j.isNeedAccept,
            $push: { histories: history },
          },
          upsert: true,
        },
      };
    });

    await this.jobRepository.bulkWrite(writes);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateResolvedJobTime(
    request: UpdateResolvedJobTimeRequestDto & IdParamDto,
  ): Promise<any> {
    const { user, id, executionTime, stopTime, reason } = request;
    let deviceIds = [];
    switch (user.role) {
      case ROLE.FACTORY_MANAGER:
        {
          const devices = await this.deviceRepository.findAllByCondition({
            factoryId: { $in: user.factoryIds },
          });
          deviceIds = devices.map((e) => e._id.toString());
        }
        break;
      case ROLE.LEADER:
        const devices = await this.deviceRepository.findAllByCondition({
          deviceGroupId: {
            $in: request.user?.maintenanceTeam?.deviceGroupIds || [],
          },
          factoryId: { $in: user.factoryIds },
        });
        deviceIds = devices.map((e) => e._id.toString());
        break;
    }
    const job = await this.jobRepository.findOneByCondition({
      _id: id,
      histories: {
        $not: { $elemMatch: { action: HISTORY_ACTION_ENUM.UPDATE_TIME } },
      },
      status: JOB_STATUS_ENUM.RESOLVED,
      isNeedAccept: false,
      deviceId: { $in: deviceIds },
    });
    if (!job) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const history = {
      content: await this.i18n.translate('text.updateJobTime', {
        args: { username: user.username },
      }),
      userId: request.user.id,
      createdAt: new Date(),
      reason,
      action: HISTORY_ACTION_ENUM.UPDATE_TIME,
      status: JOB_STATUS_ENUM.RESOLVED,
    };

    await this.jobRepository.findByIdAndUpdate(request.id, {
      executionTime,
      stopTime,
      reason,
      $push: { histories: history },
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private getWarningStatusByJobStatus(status): any {
    switch (status) {
      case JOB_STATUS_ENUM.IN_PROGRESS:
        return WARNING_STATUS_ENUM.IN_PROGRESS;
      case JOB_STATUS_ENUM.COMPLETED:
        return WARNING_STATUS_ENUM.COMPLETED;
      case JOB_STATUS_ENUM.RESOLVED:
        return WARNING_STATUS_ENUM.RESOLVE;
      case JOB_STATUS_ENUM.REJECT:
        return WARNING_STATUS_ENUM.REJECTED;
      default:
        return null;
    }
  }

  private async handleResolvedJobInstallation(job) {
    const jobs = await this.jobRepository.findAllByCondition({
      deviceAssignmentId: job.deviceAssignmentId,
      status: JOB_STATUS_ENUM.RESOLVED,
      type: JOB_TYPE_ENUM.INSTALLATION,
    });

    const deviceInstalled = jobs.map((e) => e.deviceId.toString());

    const deviceAssignment =
      await this.deviceAssignmentRepository.findOneWithPopulate(
        {
          _id: job.deviceAssignmentId,
        },
        [
          {
            path: 'details.device',
            populate: 'deviceGroup',
          },
        ],
      );
    // update area when device is assign and installed
    const areaId = deviceAssignment.details.find(
      (e) => e.deviceId.toString() === job.deviceId.toString(),
    )?.areaId;
    const deviceExist = await this.deviceRepository.findOneById(job.deviceId);

    const newObject = {
      areaId,
      status: DEVICE_STATUS_ENUM.USING,
    } as Device;
    const objectPairs = [
      {
        oldObject: deviceExist,
        newObject,
      },
    ];
    const userIdChange = job.histories[0]?.userId;
    await this.historyRepository.logHistoryForDocuments(
      objectPairs,
      HISTORY_REF_ENUM.DEVICE,
      userIdChange,
      HISTORY_REASON_REF_ENUM.DEVICE_ASSIGNMENT,
      job.deviceAssignmentId,
    );
    await this.deviceRepository.findByIdAndUpdate(job.deviceId, newObject);

    const deviceIdsNeedInstall = [];
    deviceAssignment.details.forEach((e) => {
      if (e['device']?.deviceGroup?.installationTemplateId) {
        deviceIdsNeedInstall.push(e.deviceId.toString());
      }
    });
    // khi các thiết bị thuộc phân công đã được lắp đặt hết thì cập nhật trạng thái phân công => hoàn thành
    const isInstallDone = isEmpty(
      difference(deviceIdsNeedInstall, deviceInstalled),
    );
    if (isInstallDone) {
      await this.deviceAssignmentRepository.findByIdAndUpdate(
        job.deviceAssignmentId,
        {
          status: DEVICE_ASSIGNMENTS_STATUS_ENUM.COMPLETED,
        },
      );
      this.eventEmitter.emit(
        DEVICE_ASSIGNMENT_EVENTS_ENUM.COMPLETED,
        new EventRequestDto({
          id: deviceAssignment._id,
          code: deviceAssignment.code,
          name: '',
        }),
      );
      await this.deviceAssignmentService.completedDeviceRequest(
        deviceAssignment.deviceRequestId,
      );
    }
  }

  private async handleUpdateWarning(warningId, job) {
    let dataUpdate: any = {};
    const warningStatus = this.getWarningStatusByJobStatus(job.status);
    switch (warningStatus) {
      case WARNING_STATUS_ENUM.COMPLETED:
        dataUpdate = {
          completedDate: new Date(),
          details: job?.result?.details?.map((e) => ({
            title: e?.title,
            description: e?.description,
            status: e?.status,
            result: e?.status,
            subtitle: e?.subtitle,
            obligatory: e?.obligatory,
          })),
        };
        break;

      case WARNING_STATUS_ENUM.RESOLVE:
        dataUpdate = {
          completedDate: job.isNeedAccept ? null : new Date(),
          details: job?.result?.details?.map((e) => ({
            title: e?.title,
            description: e?.description,
            status: e?.status,
            result: e?.status,
            subtitle: e?.subtitle,
            obligatory: e?.obligatory,
          })),
        };
        break;

      case WARNING_STATUS_ENUM.IN_PROGRESS:
        dataUpdate = {
          actualExecutionDate: new Date(),
        };
        break;
      default:
        break;
    }
    dataUpdate = pickBy(
      {
        ...dataUpdate,
        status: warningStatus,
      },
      identity,
    );
    await this.warningRepository.findByIdAndUpdate(warningId, dataUpdate);
  }

  private async updateStatusDeviceWhenReplace(job: Job, user: any) {
    if (job.result?.maintenanceType === JOB_TYPE_MAINTENANCE_ENUM.REPLACE) {
      const device = await this.deviceRepository.findOneById(job.deviceId);
      // update status
      await this.historyRepository.logHistoryForDocuments(
        [
          {
            oldObject: { device },
            newObject: { status: DEVICE_STATUS_ENUM.BROKEN },
          },
        ],
        HISTORY_REF_ENUM.DEVICE,
        user.id,
      );
      await this.deviceRepository.findByIdAndUpdate(device._id, {
        status: DEVICE_STATUS_ENUM.BROKEN,
      });
    }
  }

  private async updateRepairRequestByJobStatus(
    id: string,
    jobStatus: JOB_STATUS_ENUM,
    dataUpdate = {},
  ) {
    let repairRequestStatus: REPAIR_REQUEST_STATUS_ENUM;
    switch (jobStatus) {
      case JOB_STATUS_ENUM.CONFIRM:
      case JOB_STATUS_ENUM.WAIT_CONFIRM:
      case JOB_STATUS_ENUM.NON_ASSIGN:
        repairRequestStatus = REPAIR_REQUEST_STATUS_ENUM.CONFIRMED;
        break;
      case JOB_STATUS_ENUM.IN_PROGRESS:
        repairRequestStatus = REPAIR_REQUEST_STATUS_ENUM.IN_PROGRESS;
        break;
      case JOB_STATUS_ENUM.COMPLETED:
        repairRequestStatus = REPAIR_REQUEST_STATUS_ENUM.COMPLETED;
        break;
      case JOB_STATUS_ENUM.RESOLVED:
        repairRequestStatus = REPAIR_REQUEST_STATUS_ENUM.RESOLVED;
        break;
      case JOB_STATUS_ENUM.REJECT:
        repairRequestStatus = REPAIR_REQUEST_STATUS_ENUM.REJECT;
        break;
      default:
        return null;
    }
    if (repairRequestStatus) {
      await this.repairRequestRepository.findByIdAndUpdate(id, {
        ...dataUpdate,
        status: repairRequestStatus,
      });
    }
  }
}
