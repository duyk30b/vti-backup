import { JobAssignmentRequestDto } from './../dto/request/job-assignment.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { ExecuteJobFormData } from '../dto/request/execute-job.request.dto';
import { ApproveJobRequestDto } from '../dto/request/approve-job.request.dto';
import { GetListJobRequestDto } from '../dto/request/get-list-job.request.dto';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { JobQueryDto } from '../dto/request/job.query.dto';
import { UpdateJobPlanRequestDto } from '../dto/request/job-plan.request.dto';
import { GetSuppliesByJob } from '../dto/request/get-supplies-by-job.param.dto';
import { JobAddReasonBodyDto } from '../dto/request/add-reason-job.request.dto copy';
import { QuickAssignJobsRequestDto } from '../dto/request/quick-assign-jobs.request.dto';
import { UpdateResolvedJobTimeRequestDto } from '../dto/request/update-resolve-job-time.request.dto';

export interface JobServiceInterface {
  execute(
    request: ExecuteJobFormData & IdParamDto & JobQueryDto,
  ): Promise<ResponsePayload<any>>;
  approve(
    request: ApproveJobRequestDto & IdParamDto & JobQueryDto,
  ): Promise<ResponsePayload<any>>;
  detail(request: IdParamDto): Promise<ResponsePayload<any>>;
  list(
    request: GetListJobRequestDto,
    isHistoryJob?: boolean,
  ): Promise<ResponsePayload<any>>;
  assignment(
    request: JobAssignmentRequestDto & JobQueryDto & IdParamDto,
  ): Promise<ResponsePayload<any>>;
  updateStatus(params: any): Promise<ResponsePayload<any>>;
  changeStatus(params: any): Promise<ResponsePayload<any>>;
  updateJobPlan(
    request: UpdateJobPlanRequestDto,
  ): Promise<ResponsePayload<any>>;
  getSuppliesByJob(request: GetSuppliesByJob): Promise<any>;
  addReasonJobInprogress(
    request: JobAddReasonBodyDto & IdParamDto,
  ): Promise<any>;
  quickAssignJobs(
    request: QuickAssignJobsRequestDto,
  ): Promise<ResponsePayload<any>>;
  updateResolvedJobTime(
    request: UpdateResolvedJobTimeRequestDto & IdParamDto,
  ): Promise<any>;
}
