import { Assign, Job } from 'src/models/job/job.model';
import {
  MaintenanceTeam,
  MaintenanceTeamMember,
} from '../../../models/maintenance-team/maintenance-team.model';
import { LeanDocument } from 'mongoose';

export interface JobUtilInterface {
  calculateMaintenanceIndexDevice(job: Job): Promise<any>;

  calculateMaintenanceIndexDeviceGroup(
    job: Job,
    deviceGroup: any,
  ): Promise<any>;

  getAssignMaintenanceTeam(assign: Assign): Promise<MaintenanceTeam>;

  getAssignMaintenanceTeamLeader(
    assign: Assign,
  ): Promise<MaintenanceTeamMember>;

  getAssignMemberIds(assign: Assign): Promise<number[]>;

  checkHasAssignPermission(job: LeanDocument<Job>, user: any): boolean;

  checkIsAssignLeader(job: LeanDocument<Job>, user: any): boolean;

  checkIsAssignManager(job: LeanDocument<Job>, user: any): boolean;
}
