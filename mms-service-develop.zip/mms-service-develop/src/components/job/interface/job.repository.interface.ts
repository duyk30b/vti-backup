import { DashboardRequestDto } from '@components/dashboard/dto/request/dashboard.request.dto';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { Job } from 'src/models/job/job.model';
import { GetListJobRequestDto } from '../dto/request/get-list-job.request.dto';
export interface JobRepositoryInterface extends BaseInterfaceRepository<Job> {
  createEntity(data: any): Promise<Job>;
  createEntities(data: any[]): Promise<Job[]>;
  detail(id: string): Promise<any>;
  list(payload: GetListJobRequestDto): Promise<any>;
  getBeforeJob(
    jobId: string,
    deviceId: string,
    type: number,
    createdAt: Date,
  ): Promise<Job>;
  countJobToCompleted(): Promise<any>;
  progressJobDashboard(request: any): Promise<any>;
  historyJobDashboard(request: any): Promise<any>;
  maintenancePlanReport(request: any): Promise<any>;
  deviceMaintenanceReport(request: any): Promise<any>;
  getJobToCron(
    conditions: any,
    limit?: number,
  ): Promise<{ result: Job[]; count: number }>;
  getCurrentJobCode(): Promise<{ codePrefix: string; codeCurrent: number }>;
  countJobForDashboard(request: DashboardRequestDto): Promise<any>;
}
