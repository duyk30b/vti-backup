import {
  Controller,
  Get,
  Inject,
  Injectable,
  Param,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { isEmpty } from 'lodash';
import { GetDeviceSynthesisReportRequest } from './dto/request/get-device-synthesis-report.request';
import { GetDeviceUseStatusReportRequest } from './dto/request/get-device-use-status-report.request.dto';
import { ReportTransferTicketRequest } from './dto/request/report-transfer-ticket.request';
import { GetDeviceUseStatusReportResponse } from './dto/response/get-device-use-status-report.response.dto';
import { ReportTransferTicketResponse } from './dto/response/report-transfer-ticket.response';
import { ReportServiceInterface } from './interface/report.service.interface';
import { GetMaintenancePlanReportRequest } from './dto/request/get-maintenance-plan-report.request';
import { ListDeviceMaintenanceReportResponse } from './dto/response/device-maintenance-report.response.dto';
import { GetDeviceMaintenanceReportRequest } from './dto/request/get-device-maintenance-report.request';
import { GetReportDeviceUseStatusDetailRequestDto } from './dto/request/get-report-device-use-status-detail.request';
import { GetReportDeviceUseStatusDetailParamDto } from './dto/request/get-report-device-use-status-detail.param.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { SuccessResponse } from '@utils/success.response.dto';
import { ReportDetailTransferTicketResponse } from './dto/response/report-detail-transfer-ticket.response';
import { ReportDetailTransferTicketRequest } from './dto/request/detail-report-transfer-ticket.request';
import {
  DETAIL_REPORT_DEVICE_STATUS_PERMISSION,
  EXPORT_DETAIL_REPORT_DEVICE_STATUS_PERMISSION,
  EXPORT_SYNTHESIS_REPORT_DEVICE_STATUS_PERMISSION,
  SYNTHESIS_REPORT_DEVICE_STATUS_PERMISSION,
} from '@utils/permissions/report-device-status';
import { REPORT_LIST_DEVICE_SYNTHESIS_PERMISSION } from '@utils/permissions/report-device';
import {
  REPORT_DETAIL_DEVICE_TRANSFER_PERMISSION,
  REPORT_LIST_DEVICE_TRANSFER_PERMISSION,
} from '@utils/permissions/report-device-transfer';
import { REPORT_LIST_DEVICE_MAINTENANCE_PERMISSION } from '@utils/permissions/report-device-maintenance';
import { ListReportNewInvestmentDeviceResponse } from './dto/response/get-report-new-investment-device.response.dto';
import { LIST_REPORT_NEW_INVESTMENT_DEVICE_PERMISSION } from '@utils/permissions/report-new-investment-device';
import {
  EXPORT_MAINTENANCE_PLAN_PERMISSION,
  GANTT_CHART_PLAN_PERMISSION,
} from '@utils/permissions/maintenance-plan';
import { ListDeviceSynthesisReportResponse } from './dto/response/list-device-synthesis-report.response.dto';

@Injectable()
@Controller('/reports')
export class ReportController {
  constructor(
    @Inject('ReportServiceInterface')
    private reportService: ReportServiceInterface,
  ) {}

  @PermissionCode(SYNTHESIS_REPORT_DEVICE_STATUS_PERMISSION.code)
  @Get('/device-status')
  @ApiOperation({
    tags: ['Report'],
    summary: 'Báo cáo tổng hợp tình trạng sử dụng thiết bị',
    description: 'Báo cáo tổng hợp tình trạng sử dụng thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: GetDeviceUseStatusReportResponse,
  })
  async getDeviceUseStatus(
    @Query() query: GetDeviceUseStatusReportRequest,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.reportService.getDeviceUseStatus(request);
  }

  @PermissionCode(REPORT_LIST_DEVICE_SYNTHESIS_PERMISSION.code)
  @Get('/device-synthesis')
  @ApiOperation({
    tags: ['Report'],
    summary: 'Tổng hợp máy móc thiết bị',
    description: 'Tổng hợp máy móc thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: ListDeviceSynthesisReportResponse,
  })
  async getDeviceSynthesis(
    @Query() query: GetDeviceSynthesisReportRequest,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.reportService.getDeviceSynthesis(request);
  }

  @PermissionCode(REPORT_LIST_DEVICE_TRANSFER_PERMISSION.code)
  @Get('/transfer-ticket')
  @ApiOperation({
    tags: ['Report'],
    summary: 'Báo cáo tổng hợp thiết bị điều chuyển',
    description: 'Báo cáo tổng hợp thiết bị điều chuyển',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: ReportTransferTicketResponse,
  })
  async reportTransferTicket(
    @Query() query: ReportTransferTicketRequest,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.reportService.reportTransferTicket(request);
  }

  @PermissionCode(REPORT_DETAIL_DEVICE_TRANSFER_PERMISSION.code)
  @Get('/detail-transfer-ticket')
  @ApiOperation({
    tags: ['Report'],
    summary: 'Báo cáo chi tiết thiết bị điều chuyển',
    description: 'Báo cáo chi tiết thiết bị điều chuyển',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: ReportDetailTransferTicketResponse,
  })
  async reportTransferTicketDetail(
    @Query() query: ReportDetailTransferTicketRequest,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.reportService.reportDetailTransferTicket(request);
  }

  @PermissionCode(REPORT_LIST_DEVICE_MAINTENANCE_PERMISSION.code)
  @Get('/device-maintenance')
  @ApiOperation({
    tags: ['Report'],
    summary: 'Tổng hợp kết quả bảo trì, bảo dưỡng thiết bị',
    description: 'Tổng hợp kết quả bảo trì, bảo dưỡng thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: ListDeviceMaintenanceReportResponse,
  })
  async getDeviceMaintenance(
    @Query() query: GetDeviceMaintenanceReportRequest,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.reportService.getDeviceMaintenance(request);
  }

  @PermissionCode(DETAIL_REPORT_DEVICE_STATUS_PERMISSION.code)
  @Get('/device-status-detail/:factoryId')
  @ApiOperation({
    tags: ['Report'],
    summary: 'Báo cáo chi tiết tình trạng sử dụng thiết bị',
    description: 'Báo cáo chi tiết tình trạng sử dụng thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: GetDeviceUseStatusReportResponse,
  })
  async getDeviceUseStatusDetail(
    @Query() query: GetReportDeviceUseStatusDetailRequestDto,
    @Param() param: GetReportDeviceUseStatusDetailParamDto,
  ): Promise<any> {
    const { request, responseError } = query;
    const { request: parameter, responseError: responseErrorParam } = param;

    if (
      (responseError && !isEmpty(responseError)) ||
      (responseErrorParam && !isEmpty(responseErrorParam))
    ) {
      return responseError || responseErrorParam;
    }
    request.factoryId = parameter.factoryId;
    return await this.reportService.reportDeviceUseStatusDetail(request);
  }

  @PermissionCode(GANTT_CHART_PLAN_PERMISSION.code)
  @Get('/maintenance-plan')
  @ApiOperation({
    tags: ['Report'],
    summary: 'Quản lý kế hoạch bảo trì, bảo dưỡng',
    description: 'Quản lý kế hoạch bảo trì, bảo dưỡng',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: ReportTransferTicketResponse,
  })
  async reportMaintenancePlan(
    @Query() query: GetMaintenancePlanReportRequest,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.reportService.getMaintenancePlan(request);
  }

  @PermissionCode(EXPORT_MAINTENANCE_PLAN_PERMISSION.code)
  @Get('/maintenance-plan-export')
  @ApiOperation({
    tags: ['Report'],
    summary: 'Xuất excel lịch xích bảo trì, bảo dưỡng',
    description: 'Xuất excel lịch xích bảo trì, bảo dưỡng',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: SuccessResponse,
  })
  async exportMaintenancePlan(
    @Query() query: GetMaintenancePlanReportRequest,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.reportService.exportMaintenancePlan(request);
  }

  @PermissionCode(EXPORT_SYNTHESIS_REPORT_DEVICE_STATUS_PERMISSION.code)
  @Get('/device-use-status-export')
  @ApiOperation({
    tags: ['Report'],
    summary: 'Xuất excel báo cáo tình trạng sử dụng máy',
    description: 'Xuất excel báo cáo tình trạng sử dụng máy',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: SuccessResponse,
  })
  async exportDeviceUseStatus(
    @Query() query: GetDeviceUseStatusReportRequest,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.reportService.exportDeviceUseStatus(request);
  }

  @PermissionCode(EXPORT_DETAIL_REPORT_DEVICE_STATUS_PERMISSION.code)
  @Get('/device-use-status-detail-export/:factoryId')
  @ApiOperation({
    tags: ['Report'],
    summary: 'Xuất excel chi tiết tình trạng sử dụng máy',
    description: 'Xuất excel chi tiết tình trạng sử dụng máy',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: SuccessResponse,
  })
  async exportDeviceUseStatusDetail(
    @Query() query: GetReportDeviceUseStatusDetailRequestDto,
    @Param() param: GetReportDeviceUseStatusDetailParamDto,
  ): Promise<any> {
    const { request, responseError } = query;
    const { request: parameter, responseError: responseErrorParam } = param;

    if (
      (responseError && !isEmpty(responseError)) ||
      (responseErrorParam && !isEmpty(responseErrorParam))
    ) {
      return responseError || responseErrorParam;
    }
    request.factoryId = parameter.factoryId;
    return await this.reportService.exportDeviceUseStatusDetail(request);
  }

  @PermissionCode(LIST_REPORT_NEW_INVESTMENT_DEVICE_PERMISSION.code)
  @Get('/new-investment-device')
  @ApiOperation({
    tags: ['Report'],
    summary: 'Báo cáo máy đầu tư mới',
    description: 'Báo cáo máy đầu tư mới',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: ListReportNewInvestmentDeviceResponse,
  })
  async reportNewInvestmentDevice(
    @Query() query: GetReportDeviceUseStatusDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.reportService.reportNewInvestmentDevice(request);
  }
}
