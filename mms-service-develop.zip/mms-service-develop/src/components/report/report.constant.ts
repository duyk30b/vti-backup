import { JOB_STATUS_ENUM } from '@components/job/job.constant';

export enum REPORT_UNIT_TEXT_ENUM {
  DAY = 'day',
  WEEK = 'isoWeek',
  MONTH = 'month',
  QUARTER = 'quarter',
  YEAR = 'year',
}

export enum REPORT_UNIT_TYPE_ENUM {
  MONTH,
  QUARTER,
}

export enum MAINTENANCE_PLAN_UNIT_TYPE_ENUM {
  MONTH,
  YEAR,
}

export enum REPORT_JOB_TYPE_ENUM {
  PERIOD_MAINTENANCE, // bảo trì
  MAINTENANCE, // bảo dưỡng
}

export const COMPLETE_MAINTENANCE_JOB = [
  JOB_STATUS_ENUM.COMPLETED,
  JOB_STATUS_ENUM.RESOLVED,
];

export const RESOLVED_MAINTENANCE_JOB = [JOB_STATUS_ENUM.RESOLVED];

export enum JOB_REPORT_STATUS_ENUM {
  UN_RESOLVE,
  IN_PROGRESS,
  RESOLVED,
  NO_JOB,
}

export enum JOB_COLOR_STATUS_ENUM {
  UN_RESOLVE = '999999',
  IN_PROGRESS = 'FFD54F',
  RESOLVED = '00E0FFh',
}
