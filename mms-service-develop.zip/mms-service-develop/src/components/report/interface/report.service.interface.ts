import { ResponsePayload } from '@utils/response-payload';
import { ReportDetailTransferTicketRequest } from '../dto/request/detail-report-transfer-ticket.request';
import { GetDeviceMaintenanceReportRequest } from '../dto/request/get-device-maintenance-report.request';
import { GetDeviceSynthesisReportRequest } from '../dto/request/get-device-synthesis-report.request';
import { GetDeviceUseStatusReportRequest } from '../dto/request/get-device-use-status-report.request.dto';
import { GetMaintenancePlanReportRequest } from '../dto/request/get-maintenance-plan-report.request';
import { GetReportNewInvestmentDevice } from '../dto/request/get-report-new-investment-device.request';
import { GetReportDeviceUseStatusDetailParamDto } from '../dto/request/get-report-device-use-status-detail.param.dto';
import { GetReportDeviceUseStatusDetailRequestDto } from '../dto/request/get-report-device-use-status-detail.request';
import { ReportTransferTicketRequest } from '../dto/request/report-transfer-ticket.request';

export interface ReportServiceInterface {
  getDeviceUseStatus(
    request: GetDeviceUseStatusReportRequest,
  ): Promise<ResponsePayload<any>>;
  getDeviceSynthesis(
    request: GetDeviceSynthesisReportRequest,
  ): Promise<ResponsePayload<any>>;
  reportTransferTicket(
    request: ReportTransferTicketRequest,
  ): Promise<ResponsePayload<any>>;
  reportDetailTransferTicket(
    request: ReportDetailTransferTicketRequest,
  ): Promise<ResponsePayload<any>>;
  getMaintenancePlan(
    request: GetMaintenancePlanReportRequest,
  ): Promise<ResponsePayload<any>>;
  getDeviceMaintenance(
    request: GetDeviceMaintenanceReportRequest,
  ): Promise<ResponsePayload<any>>;
  reportDeviceUseStatusDetail(
    request: GetReportDeviceUseStatusDetailRequestDto &
      GetReportDeviceUseStatusDetailParamDto,
  ): Promise<ResponsePayload<any>>;
  exportMaintenancePlan(
    request: GetMaintenancePlanReportRequest,
  ): Promise<ResponsePayload<any>>;
  exportDeviceUseStatus(
    request: GetDeviceUseStatusReportRequest,
  ): Promise<ResponsePayload<any>>;
  exportDeviceUseStatusDetail(
    request: GetReportDeviceUseStatusDetailRequestDto &
      GetReportDeviceUseStatusDetailParamDto,
  ): Promise<ResponsePayload<any>>;
  reportNewInvestmentDevice(
    request: GetReportNewInvestmentDevice,
  ): Promise<ResponsePayload<any>>;
}
