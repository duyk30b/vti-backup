import { UserService } from '@components/user/user.service';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { DeviceSchema } from 'src/models/device/device.schema';
import { JobSchema } from 'src/models/job/job.schema';
import { HistorySchema } from 'src/models/history/history.schema';
import { DeviceRepository } from 'src/repository/device/device.repository';
import { JobRepository } from 'src/repository/job/job.repository';
import { TransferTicketRepository } from 'src/repository/transfer-ticket/transfer-ticket.repository';
import { HistoryRepository } from 'src/repository/history/history.repository';
import { ReportController } from './report.controller';
import { ReportService } from './report.service';
import { DeviceGroupRepository } from 'src/repository/device-group/device-group.repository';
import { DeviceAssignmentRepository } from 'src/repository/device-assignment/device-assignment.repository';
import { MaintenancePlanRepository } from 'src/repository/maintenance-plan/maintenance-plan.repository';
import { MaintenancePlanSchema } from 'src/models/maintenance-plan/maintenance-plan.schema';
import { ItemModule } from '@components/item/item.module';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'Device', schema: DeviceSchema },
      { name: 'Job', schema: JobSchema },
      { name: 'History', schema: HistorySchema },
      { name: 'MaintenancePlan', schema: MaintenancePlanSchema },
    ]),
    ItemModule,
  ],
  providers: [
    {
      provide: 'ReportServiceInterface',
      useClass: ReportService,
    },
    {
      provide: 'JobRepositoryInterface',
      useClass: JobRepository,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'DeviceRepositoryInterface',
      useClass: DeviceRepository,
    },
    {
      provide: 'TransferTicketRepositoryInterface',
      useClass: TransferTicketRepository,
    },
    {
      provide: 'HistoryRepositoryInterface',
      useClass: HistoryRepository,
    },
    {
      provide: 'DeviceGroupRepositoryInterface',
      useClass: DeviceGroupRepository,
    },
    {
      provide: 'DeviceAssignmentRepositoryInterface',
      useClass: DeviceAssignmentRepository,
    },
    {
      provide: 'MaintenancePlanRepositoryInterface',
      useClass: MaintenancePlanRepository,
    },
  ],
  controllers: [ReportController],
  exports: [
    MongooseModule,
    {
      provide: 'ReportServiceInterface',
      useClass: ReportService,
    },
  ],
})
export class ReportModule {}
