import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsNotEmpty, IsNumber } from 'class-validator';

export class GetReportDeviceUseStatusDetailParamDto extends BaseDto {
  @ApiProperty()
  @IsNumber()
  @Transform((data) => parseInt(data.value))
  @IsNotEmpty()
  factoryId: number;
}
