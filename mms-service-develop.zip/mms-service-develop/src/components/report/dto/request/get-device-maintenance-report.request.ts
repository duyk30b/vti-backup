import {
  REPORT_JOB_TYPE_ENUM,
  REPORT_UNIT_TYPE_ENUM,
} from '@components/report/report.constant';
import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { Transform } from 'class-transformer';
import {
  IsDateString,
  IsEnum,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator';

export class GetDeviceMaintenanceReportRequest extends PaginationQuery {
  @ApiProperty()
  @IsOptional()
  @IsString()
  queryIds: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(REPORT_UNIT_TYPE_ENUM)
  @IsNumber()
  @Transform((data) => parseInt(data.value))
  reportUnitType: number;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  startDate: Date;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  endDate: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(REPORT_JOB_TYPE_ENUM)
  @Transform((data) => parseInt(data.value))
  @IsNumber()
  type: number;
}
