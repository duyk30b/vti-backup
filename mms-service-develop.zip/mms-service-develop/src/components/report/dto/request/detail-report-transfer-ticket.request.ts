import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { Transform } from 'class-transformer';
import { IsNotEmpty, IsNumber } from 'class-validator';

export class ReportDetailTransferTicketRequest extends PaginationQuery {
  @ApiProperty()
  @IsNumber()
  @Transform((data) => +data.value)
  @IsNotEmpty()
  fromFactoryId: number;

  @ApiProperty()
  @IsNumber()
  @Transform((data) => +data.value)
  @IsNotEmpty()
  toFactoryId: number;
}
