import {
  MAINTENANCE_PLAN_UNIT_TYPE_ENUM,
  REPORT_JOB_TYPE_ENUM,
} from '@components/report/report.constant';
import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { Transform } from 'class-transformer';
import {
  IsDateString,
  IsEnum,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator';

export class GetMaintenancePlanReportRequest extends PaginationQuery {
  @ApiProperty()
  @IsOptional()
  @IsString()
  queryIds: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(MAINTENANCE_PLAN_UNIT_TYPE_ENUM)
  @IsNumber()
  @Transform((data) => parseInt(data.value))
  reportUnitType: number;

  @ApiProperty()
  @IsOptional()
  @IsEnum(REPORT_JOB_TYPE_ENUM)
  @Transform(() => REPORT_JOB_TYPE_ENUM.PERIOD_MAINTENANCE)
  @IsNumber()
  type: number;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  startDate: string;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  endDate: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  checklistTemplateId: string;
}
