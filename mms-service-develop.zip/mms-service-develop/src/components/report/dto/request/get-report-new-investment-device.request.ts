import { PaginationQuery } from '@utils/dto/request/pagination.query';

export class GetReportNewInvestmentDevice extends PaginationQuery {}
