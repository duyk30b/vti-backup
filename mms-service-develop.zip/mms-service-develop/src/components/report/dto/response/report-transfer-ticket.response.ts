import { ApiProperty } from '@nestjs/swagger';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { Expose, Type } from 'class-transformer';

export class ReportTransferTicketResponse {
  @ApiProperty()
  @Expose()
  totalBuy: number;

  @ApiProperty()
  @Expose()
  totalRent: number;

  @ApiProperty({
    type: BasicSqlDocumentResponse,
  })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  toFactory: BasicSqlDocumentResponse;

  @ApiProperty({
    type: BasicSqlDocumentResponse,
  })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  fromFactory: BasicSqlDocumentResponse;
}
