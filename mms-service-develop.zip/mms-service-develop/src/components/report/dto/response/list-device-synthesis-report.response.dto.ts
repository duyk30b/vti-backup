import { IS_FIXED_ASSET } from '@components/device/device.constant';
import { DEVICE_STATUS_STATE_ENUM } from '@components/device-status/device-status.constant';

import { ApiProperty } from '@nestjs/swagger';
import { div } from '@utils/common';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Transform, Type } from 'class-transformer';
import { DeviceBasicResponseDto } from '@components/device/dto/response/device-basic.response.dto';

export class DetailDeviceSynthesisResponse extends DeviceBasicResponseDto {
  @ApiProperty()
  @Expose()
  actualSerial: string;

  @ApiProperty()
  @Expose()
  creationDate: Date;

  @ApiProperty()
  @Expose()
  model: string;

  @ApiProperty()
  @Expose()
  manufacturer: string;

  @ApiProperty()
  @Expose()
  isFixedAsset: IS_FIXED_ASSET;

  @ApiProperty()
  @Expose()
  @Transform((data) => div(data.value ?? 0, 30))
  depreciation: number;

  @ApiProperty()
  @Expose()
  assetType: number;

  @ApiProperty()
  @Expose()
  manager: string;

  @ApiProperty()
  @Expose()
  user: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  articleDeviceGroup: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  deviceGroup: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  deviceType: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  warehouse: BasicResponseDto;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Expose()
  @Type(() => BasicSqlDocumentResponse)
  factory: BasicSqlDocumentResponse;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Expose()
  @Type(() => BasicSqlDocumentResponse)
  originFactory: BasicSqlDocumentResponse;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  vendor: BasicResponseDto;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  unit: BasicSqlDocumentResponse;

  @ApiProperty()
  @Transform(({ value }) => value?.status ?? DEVICE_STATUS_STATE_ENUM.ACTIVE)
  @Expose()
  deviceStatus: number;
}

export class ListDeviceSynthesisReportResponse extends PaginationResponse {
  @ApiProperty({ type: DetailDeviceSynthesisResponse, isArray: true })
  @Type(() => DetailDeviceSynthesisResponse)
  @Expose()
  items: DetailDeviceSynthesisResponse[];
}
