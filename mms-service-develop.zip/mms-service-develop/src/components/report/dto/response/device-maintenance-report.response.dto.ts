import { ApiProperty } from '@nestjs/swagger';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';

export class reportByUnit {
  @Expose()
  @ApiProperty()
  tag: number;

  @Expose()
  @ApiProperty()
  plan: number;

  @Expose()
  @ApiProperty()
  actual: number;

  @Expose()
  @ApiProperty()
  scale: number;

  @Expose()
  @ApiProperty()
  startDate: string;

  @Expose()
  @ApiProperty()
  endDate: string;
}

export class DeviceMaintenanceReportResponse {
  @Expose()
  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Type(() => BasicSqlDocumentResponse)
  factory: BasicSqlDocumentResponse;

  @Expose()
  @ApiProperty({ type: reportByUnit, isArray: true })
  reportByUnits: reportByUnit[];
}

export class ListDeviceMaintenanceReportResponse extends PaginationResponse {
  @Expose()
  @ApiProperty({ type: reportByUnit, isArray: true })
  @Type(() => DeviceMaintenanceReportResponse)
  items: DeviceMaintenanceReportResponse[];
}
