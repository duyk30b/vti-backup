import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';

class DeviceGroupResponseDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  total: number;

  @ApiProperty()
  @Expose()
  totalUsing: number;

  @ApiProperty()
  @Expose()
  totalPreventive: number;

  @ApiProperty()
  @Expose()
  totalBroken: number;

  @ApiProperty()
  @Expose()
  totalAwaitClearance: number;
}

export class GetReportDeviceUseStatusDetailResponseDto extends PaginationResponse {
  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  factory: BasicSqlDocumentResponse;

  @ApiProperty({ type: DeviceGroupResponseDto, isArray: true })
  @Type(() => DeviceGroupResponseDto)
  @Expose()
  items: DeviceGroupResponseDto[];
}
