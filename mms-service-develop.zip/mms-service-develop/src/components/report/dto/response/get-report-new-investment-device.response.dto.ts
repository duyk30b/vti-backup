import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';

export class ReportNewInvestmentDeviceResponse extends BasicResponseDto {
  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  factory: BasicSqlDocumentResponse;

  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Expose()
  vendor: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Expose()
  deviceName: BasicResponseDto;

  @ApiProperty()
  @Expose()
  manufacturer: string;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  model: string;

  @ApiProperty()
  @Expose()
  serial: string;

  @ApiProperty()
  @Expose()
  actualSerial: string;

  @ApiProperty()
  @Expose()
  capitalizationDate: Date;

  @ApiProperty()
  @Expose()
  company: string;
}

export class ListReportNewInvestmentDeviceResponse extends PaginationResponse {
  @ApiProperty({ type: ReportNewInvestmentDeviceResponse, isArray: true })
  @Type(() => ReportNewInvestmentDeviceResponse)
  @Expose()
  items: ReportNewInvestmentDeviceResponse[];
}
