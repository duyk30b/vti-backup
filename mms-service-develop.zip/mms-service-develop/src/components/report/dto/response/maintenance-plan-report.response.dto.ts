import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';

class ReportByUnit {
  @Expose()
  @ApiProperty()
  tag: number;

  @Expose()
  @ApiProperty()
  startDate: Date;

  @Expose()
  @ApiProperty()
  endDate: Date;

  @Expose()
  @ApiProperty()
  status: number;

  @Expose()
  @ApiProperty()
  jobId: string;
}

class Job {
  @Expose()
  @ApiProperty()
  category: string;

  @Expose()
  @ApiProperty({ type: ReportByUnit, isArray: true })
  @Type(() => ReportByUnit)
  reportByUnits: ReportByUnit[];
}

export class MaintenancePlanReportResponse {
  @Expose()
  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  device: BasicResponseDto;

  @Expose()
  @ApiProperty({ type: Job, isArray: true })
  @Type(() => Job)
  jobs: Job[];
}

export class ListMaintenancePlanReportResponse extends PaginationResponse {
  @Expose()
  @ApiProperty({ type: MaintenancePlanReportResponse, isArray: true })
  @Type(() => MaintenancePlanReportResponse)
  items: MaintenancePlanReportResponse[];
}
