import { ApiProperty } from '@nestjs/swagger';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';

export class DeviceUseStatusResponseDto {
  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  factory: BasicSqlDocumentResponse;

  @ApiProperty()
  @Expose()
  total: number;

  @ApiProperty()
  @Expose()
  totalUsing: number;

  @ApiProperty()
  @Expose()
  totalPreventive: number;

  @ApiProperty()
  @Expose()
  totalBroken: number;

  @ApiProperty()
  @Expose()
  totalAwaitClearance: number;
}

export class GetDeviceUseStatusReportResponse extends PaginationResponse {
  @ApiProperty({ type: DeviceUseStatusResponseDto, isArray: true })
  @Type(() => DeviceUseStatusResponseDto)
  @Expose()
  items: DeviceUseStatusResponseDto[];
}
