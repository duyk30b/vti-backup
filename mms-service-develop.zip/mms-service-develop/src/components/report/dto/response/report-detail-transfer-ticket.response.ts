import { DeviceBasicResponseDto } from '@components/device/dto/response/device-basic.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { Expose, Transform, Type } from 'class-transformer';

export class ReportDetailTransferTicketResponse extends DeviceBasicResponseDto {
  @ApiProperty()
  @Expose()
  manufacturer: string;

  @ApiProperty()
  @Expose()
  model: string;

  @ApiProperty()
  @Expose()
  actualserial: string;

  @ApiProperty()
  @Expose()
  unit: string;

  @ApiProperty()
  @Transform(() => 1)
  @Expose()
  quantity: number;

  @ApiProperty({
    type: BasicSqlDocumentResponse,
  })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  toFactory: BasicSqlDocumentResponse;

  @ApiProperty({
    type: BasicSqlDocumentResponse,
  })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  fromFactory: BasicSqlDocumentResponse;

  @ApiProperty()
  @Expose()
  transferDate: Date;

  @ApiProperty()
  @Expose()
  returnDate: Date;

  @ApiProperty()
  @Expose()
  transferType: number;
}
