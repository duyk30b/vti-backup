import { DeviceRepositoryInterface } from '@components/device/interface/device.repository.interface';
import { TransferTicketRepositoryInterface } from '@components/transfer-ticket/interface/transfer-ticket.repository.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import {
  compact,
  first,
  flatMap,
  groupBy,
  has,
  keyBy,
  map,
  uniq,
} from 'lodash';
import { GetDeviceSynthesisReportRequest } from './dto/request/get-device-synthesis-report.request';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ReportTransferTicketRequest } from './dto/request/report-transfer-ticket.request';
import { ReportTransferTicketResponse } from './dto/response/report-transfer-ticket.response';
import { ReportServiceInterface } from './interface/report.service.interface';
import { GetDeviceMaintenanceReportRequest } from './dto/request/get-device-maintenance-report.request';
import { GetDeviceUseStatusReportRequest } from './dto/request/get-device-use-status-report.request.dto';
import { DeviceMaintenanceReportResponse } from './dto/response/device-maintenance-report.response.dto';
import { div, mul, paginate, plus } from '@utils/common';
import { DeviceUseStatusResponseDto } from './dto/response/get-device-use-status-report.response.dto';
import { ResponsePayload } from '@utils/response-payload';
import { GetMaintenancePlanReportRequest } from './dto/request/get-maintenance-plan-report.request';
import {
  MAINTENANCE_PLAN_UNIT_TYPE_ENUM,
  REPORT_JOB_TYPE_ENUM,
  REPORT_UNIT_TEXT_ENUM,
  JOB_REPORT_STATUS_ENUM,
  REPORT_UNIT_TYPE_ENUM,
  JOB_COLOR_STATUS_ENUM,
} from './report.constant';
import * as moment from 'moment';
import { JobRepositoryInterface } from '@components/job/interface/job.repository.interface';
import { JOB_TYPE_ENUM } from '@components/job/job.constant';
import { MaintenancePlanReportResponse } from './dto/response/maintenance-plan-report.response.dto';
import { GetReportDeviceUseStatusDetailRequestDto } from './dto/request/get-report-device-use-status-detail.request';
import { GetReportDeviceUseStatusDetailParamDto } from './dto/request/get-report-device-use-status-detail.param.dto';
import { DeviceGroupRepositoryInterface } from '@components/device-group/interface/device-group.repository.interface';
import { GetReportDeviceUseStatusDetailResponseDto } from './dto/response/get-report-device-use-status-detail.response.dto';
import { Alignment, Borders, Font, Workbook } from 'exceljs';
import { EXCEL_STYLE, ROW, SHEET } from '@components/export/export.constant';
import { ReportDetailTransferTicketRequest } from './dto/request/detail-report-transfer-ticket.request';
import { ReportDetailTransferTicketResponse } from './dto/response/report-detail-transfer-ticket.response';
import { DeviceAssignmentRepositoryInterface } from '@components/device-assignment/interface/device-assignment.repository.interface';
import { MaintenancePlanRepositoryInterface } from '@components/maintenance-plan/interface/maintenance-plan.repository.interface';
import { GetReportNewInvestmentDevice } from './dto/request/get-report-new-investment-device.request';
import { ReportNewInvestmentDeviceResponse } from './dto/response/get-report-new-investment-device.response.dto';
import { DetailDeviceSynthesisResponse } from './dto/response/list-device-synthesis-report.response.dto';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';

@Injectable()
export class ReportService implements ReportServiceInterface {
  constructor(
    @Inject('DeviceRepositoryInterface')
    private readonly deviceRepository: DeviceRepositoryInterface,

    @Inject('DeviceGroupRepositoryInterface')
    private readonly deviceGroupRepository: DeviceGroupRepositoryInterface,

    @Inject('TransferTicketRepositoryInterface')
    private readonly transferTicketRepository: TransferTicketRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('JobRepositoryInterface')
    private readonly jobRepository: JobRepositoryInterface,

    @Inject('DeviceAssignmentRepositoryInterface')
    private readonly deviceAssignmentRepository: DeviceAssignmentRepositoryInterface,

    @Inject('MaintenancePlanRepositoryInterface')
    private readonly maintenancePlanRepository: MaintenancePlanRepositoryInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    private i18n: I18nRequestScopeService,
  ) {}

  async getDeviceUseStatus(
    request: GetDeviceUseStatusReportRequest,
  ): Promise<any> {
    const { result: reportDevices, count } =
      await this.deviceRepository.reportDeviceUseStatus(request);
    const reportDeviceMap = keyBy(reportDevices, '_id');
    const factoryIdReturns = map(reportDeviceMap, '_id');

    const factories = await this.userService.getFactoryList([
      { column: 'factoryIds', text: factoryIdReturns },
    ]);

    const result = factories.map((factory) => {
      return {
        factory: factory,
        total: reportDeviceMap[factory.id]?.total ?? 0,
        totalUsing: reportDeviceMap[factory.id]?.totalUsing ?? 0,
        totalPreventive: reportDeviceMap[factory.id]?.totalPreventive ?? 0,
        totalBroken: reportDeviceMap[factory.id]?.totalBroken ?? 0,
        totalAwaitClearance:
          reportDeviceMap[factory.id]?.totalAwaitClearance ?? 0,
      };
    });

    const dataReturn = plainToInstance(DeviceUseStatusResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder({
      items: dataReturn,
      meta: {
        total: count || 0,
        page: request.page,
      },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getDeviceSynthesis(
    request: GetDeviceSynthesisReportRequest,
  ): Promise<ResponsePayload<any>> {
    const { devices, count } =
      await this.deviceRepository.getDeviceSynthesisReport(request);

    //  get region and interRegion by factory
    const resFactoryIds = compact(
      uniq(flatMap(devices, (e) => [e.factoryId, e.originFactoryId])),
    );
    const factories = await this.userService.getFactoryList([
      { column: 'factoryIds', text: resFactoryIds },
    ]);
    const factoryMap = keyBy(factories, 'id');

    const deviceIds = [];
    const unitIds = [];
    devices.forEach((e) => {
      deviceIds.push(e._id);
      unitIds.push(e.unitId);
    });
    const units = await this.itemService.getListUnit([
      {
        column: 'ids',
        text: uniq(unitIds).toString(),
      },
    ]);
    const unitMap = keyBy(units, 'id');
    const deviceAssignments =
      await this.deviceAssignmentRepository.findAllByCondition({
        'details.deviceId': {
          $in: deviceIds,
        },
      });

    const deviceAssignmentMap = {};
    deviceAssignments.forEach((deviceAssignment) => {
      deviceAssignment.details.forEach((e) => {
        deviceAssignmentMap[e.deviceId.toString()] = deviceAssignment;
      });
    });

    devices.forEach((el) => {
      el.factory = factoryMap[el.factoryId];
      el.originFactory = factoryMap[el.originFactoryId];
      el.user = deviceAssignmentMap[el._id.toString()]?.assignUser;
      el.unit = unitMap[el.unitId];
    });
    const response = plainToInstance(DetailDeviceSynthesisResponse, devices, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async reportTransferTicket(
    request: ReportTransferTicketRequest,
  ): Promise<ResponsePayload<any>> {
    const { data, total } =
      await this.transferTicketRepository.reportTransferTicket(request);

    const factoryIds = data.map((e) => [e.fromFactoryId, e.toFactoryId]).flat();

    const factories = await this.userService.getFactoryList([
      {
        column: 'factoryIds',
        text: factoryIds,
      },
    ]);

    const factoryMap = keyBy(factories, 'id');

    data.forEach((e) => {
      e.fromFactory = factoryMap[e.fromFactoryId];
      e.toFactory = factoryMap[e.toFactoryId];
    });

    const dataReturn = plainToInstance(ReportTransferTicketResponse, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: total, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async reportDetailTransferTicket(
    request: ReportDetailTransferTicketRequest,
  ): Promise<ResponsePayload<any>> {
    const { data: transferTickets, total } =
      await this.transferTicketRepository.reportDetailTransferTicket(request);

    const factoryIds = [request.toFactoryId, request.fromFactoryId];
    const factories = await this.userService.getFactoryList([
      {
        column: 'factoryIds',
        text: factoryIds,
      },
    ]);
    const factoryMap = keyBy(factories, 'id');

    const unitIds = map(transferTickets, (e) => e.device?.unitId);
    const units = await this.itemService.getListUnit([
      {
        column: 'ids',
        text: uniq(unitIds).toString(),
      },
    ]);
    const unitMap = keyBy(units, 'id');

    const result = transferTickets.map((transferTicket) => ({
      ...transferTicket.device,
      unit: unitMap[transferTicket.device?.unitId]?.name,
      toFactory: has(factoryMap, request.toFactoryId)
        ? factoryMap[request.toFactoryId]
        : null,
      fromFactory: has(factoryMap, request.fromFactoryId)
        ? factoryMap[request.fromFactoryId]
        : null,
      transferDate: transferTicket.transferDate,
      returnDate: transferTicket.estimatedReturnDate,
      transferType: transferTicket.transferRequest?.type,
    }));

    const dataReturn = plainToInstance(
      ReportDetailTransferTicketResponse,
      result,
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: total, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getDeviceMaintenance(
    request: GetDeviceMaintenanceReportRequest,
  ): Promise<ResponsePayload<any>> {
    const { page, take, reportUnitType, type } = request;

    const { listRangeDate, startDate, endDate } = this.getRangeDateByDateType(
      reportUnitType,
      request.startDate,
      request.endDate,
    );
    // check type
    if (type === REPORT_JOB_TYPE_ENUM.PERIOD_MAINTENANCE) {
      request.type = JOB_TYPE_ENUM.MAINTAIN;
    } else {
      // @TODO add bảo dưỡng
      request.type = JOB_TYPE_ENUM.MAINTAIN;
    }
    const deviceMaintenance = await this.jobRepository.deviceMaintenanceReport({
      ...request,
      startDate,
      endDate,
    });

    // convert data by factoryId (report list by factory)
    const deviceMaintenanceMap = groupBy(deviceMaintenance, '_id.factoryId');
    const values = Object.values(deviceMaintenanceMap);
    const total = values.length;

    const deviceMaintenanceRes = paginate(values, take, page);
    const resFactoryIds = deviceMaintenanceRes.map(
      (el) => el[0]?._id.factoryId,
    );
    const factories = await this.userService.getFactoryList([
      {
        column: 'factoryIds',
        text: resFactoryIds,
      },
    ]);
    const factoryMap = keyBy(factories, 'id');
    const reportData: DeviceMaintenanceReportResponse[] = [];
    // map aver deviceMaintenanceRes by factory
    deviceMaintenanceRes.forEach((deviceMaintenances) => {
      const factoryId = deviceMaintenances[0]?._id?.factoryId;
      // foreach by list rangeDate
      const reportByUnits = [];
      listRangeDate.forEach((rangeDate, index) => {
        let plan = 0;
        let actual = 0;
        // foreach by  deviceMaintenance list of factoryId
        deviceMaintenances?.forEach((deviceMaintenance) => {
          const dateToNumber = Number(
            moment(deviceMaintenance._id?.rangedate).format('YYYYMMDD'),
          );
          if (
            dateToNumber >= Number(rangeDate.startDate) &&
            dateToNumber <= Number(rangeDate.endDate)
          ) {
            plan += deviceMaintenance.plan ?? 0;
            actual += deviceMaintenance.actual ?? 0;
          }
        });
        const scale = plan !== 0 ? mul(div(actual, plan), 100) : plan;
        reportByUnits.push({
          tag: index,
          plan,
          actual,
          scale,
          startDate:
            index === 0
              ? moment(startDate).format('YYYYMMDD')
              : rangeDate.startDate,
          endDate: rangeDate.endDate,
        });
      });
      const factory = factoryMap[factoryId];
      reportData.push({
        factory,
        reportByUnits,
      });
    });
    const returnReportData = plainToInstance(
      DeviceMaintenanceReportResponse,
      reportData,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder({
      items: returnReportData,
      meta: { total, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getMaintenancePlan(
    request: GetMaintenancePlanReportRequest,
  ): Promise<ResponsePayload<any>> {
    const { reportUnitType, type, filter } = request;
    if (request.startDate && request.endDate) {
      if (moment(request.startDate).isSameOrAfter(moment(request.endDate))) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.INVALID_DATE_RANGE'))
          .build();
      }
    }
    if (
      (!request.startDate || !request.endDate) &&
      filter?.find((item) => item.column === 'maintenancePlanId')
    ) {
      const maintenancePlan = await this.maintenancePlanRepository.findOneById(
        request.filter.find((item) => item.column === 'maintenancePlanId')
          ?.text,
      );
      if (maintenancePlan) {
        request.startDate = maintenancePlan.planFrom.toISOString();
        request.endDate = maintenancePlan.planTo.toISOString();
      }
    }

    const { endDate, startDate, listRangeDate } =
      this.getRangeDateForMaintenancePlan(
        reportUnitType,
        request.startDate,
        request.endDate,
      );
    const maintenancePlan = await this.jobRepository.maintenancePlanReport({
      ...request,
      endDate,
      startDate,
    });
    // check type
    if (type === REPORT_JOB_TYPE_ENUM.PERIOD_MAINTENANCE) {
      request.type = JOB_TYPE_ENUM.MAINTAIN;
    } else {
      // @TODO add bảo dưỡng
      request.type = JOB_TYPE_ENUM.MAINTENANCE;
    }
    const undefinedJobTitle = await this.i18n.translate(
      'message.undefinedJobTitle',
    );
    // convert data by deviceId (report list by device)
    const maintenancePlanMap = groupBy(maintenancePlan, '_id.deviceId');
    const values = Object.values(maintenancePlanMap);
    const reportData: MaintenancePlanReportResponse[] = [];
    // foreach with deviceId
    values.forEach((jobByDevice) => {
      const device = jobByDevice[0]?.device;
      const jobs = [];
      // foreach with each job in one device
      jobByDevice.forEach((job) => {
        const reportByUnits = [];
        const category = job._id?.category ?? undefinedJobTitle;
        // foreach with each rangedate in each job
        listRangeDate.forEach((rangeDate, index) => {
          // find status of job in rangeDate
          let status = null;
          let newStatus = 0;
          let jobId: string = null;
          job.reportByUnit?.forEach((jobByUnit) => {
            const dateToNumber = Number(
              moment(jobByUnit.planFrom).format('YYYYMMDD'),
            );
            if (
              dateToNumber >= Number(rangeDate.startDate) &&
              dateToNumber <= Number(rangeDate.endDate)
            ) {
              jobId = jobByUnit.jobId?.toString();
              newStatus = jobByUnit.status;
              if (status !== null && status !== newStatus) {
                status = JOB_REPORT_STATUS_ENUM.IN_PROGRESS;
              } else {
                status = newStatus;
              }
            }
          });
          reportByUnits.push({
            tag: index,
            jobId,
            status: status ?? JOB_REPORT_STATUS_ENUM.NO_JOB,
            startDate: moment(rangeDate.startDate).startOf('day').toDate(),
            endDate: moment(rangeDate.endDate).endOf('day').toDate(),
          });
        });
        jobs.push({ category, reportByUnits });
      });
      reportData.push({
        device,
        jobs,
      });
    });
    const returnReportData = plainToInstance(
      MaintenancePlanReportResponse,
      reportData,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(returnReportData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private getRangeDateForMaintenancePlan(
    reportType: number,
    startDate?: string,
    endDate?: string,
  ): {
    listRangeDate: any[];
    startDate: Date;
    endDate: Date;
  } {
    const listRangeDate = [];
    const unit =
      reportType === MAINTENANCE_PLAN_UNIT_TYPE_ENUM.MONTH
        ? REPORT_UNIT_TEXT_ENUM.DAY
        : REPORT_UNIT_TEXT_ENUM.WEEK;
    const unitTotal =
      reportType === MAINTENANCE_PLAN_UNIT_TYPE_ENUM.MONTH
        ? REPORT_UNIT_TEXT_ENUM.MONTH
        : REPORT_UNIT_TEXT_ENUM.YEAR;

    const from = startDate ? moment(startDate) : moment().startOf(unitTotal);
    const to = endDate ? moment(endDate) : moment().endOf(unitTotal);
    for (
      let date = from.clone();
      date.isSameOrBefore(to, 'day');
      date = date.clone().add(1, 'day')
    ) {
      const endYear = date.clone().endOf('year').format('YYYYMMDD');
      const startDate = date.format('YYYYMMDD');
      const endDate = date.endOf(unit).format('YYYYMMDD');
      listRangeDate.push({
        startDate,
        endDate: endDate < endYear ? endDate : endYear,
      });
    }
    return { listRangeDate, startDate: from.toDate(), endDate: to.toDate() };
  }

  private getRangeDateByDateType(
    reportType: number,
    startDate?: Date,
    endDate?: Date,
  ): {
    listRangeDate: any[];
    startDate: Date;
    endDate: Date;
  } {
    const listRangeDate = [];
    const unit =
      reportType === REPORT_UNIT_TYPE_ENUM.MONTH
        ? REPORT_UNIT_TEXT_ENUM.MONTH
        : REPORT_UNIT_TEXT_ENUM.QUARTER;

    const from = startDate
      ? moment(startDate)
      : moment().year(moment().year()).startOf('year');
    const to = endDate
      ? moment(endDate)
      : moment().year(moment().year()).endOf('year');

    for (
      let date = from.clone();
      date.isSameOrBefore(to, 'day');
      date = date.clone().add(1, unit)
    ) {
      const endDate = date.clone().endOf(unit).format('YYYYMMDD');
      let startDate: string;
      if (date.isSame(from)) {
        startDate = '';
      } else {
        startDate = date.clone().format('YYYYMMDD');
      }
      listRangeDate.push({
        startDate,
        endDate,
      });
    }
    return { listRangeDate, startDate: from.toDate(), endDate: to.toDate() };
  }

  async reportDeviceUseStatusDetail(
    request: GetReportDeviceUseStatusDetailRequestDto &
      GetReportDeviceUseStatusDetailParamDto,
  ): Promise<ResponsePayload<any>> {
    const factory = await this.userService.getFactoryById(request.factoryId);

    if (!factory) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const deviceGroupsReport =
      await this.deviceGroupRepository.reportDeviceUseStatusDetail(request);

    const result = {
      factory: factory,
      items: deviceGroupsReport.data,
      meta: {
        total: deviceGroupsReport.count,
        page: request.page,
      },
    };

    const dataReturn = plainToInstance(
      GetReportDeviceUseStatusDetailResponseDto,
      result,
      { excludeExtraneousValues: true },
    );
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async exportMaintenancePlan(
    request: GetMaintenancePlanReportRequest,
  ): Promise<ResponsePayload<any>> {
    const { filter, reportUnitType } = request;
    const { data: reports } = await this.getMaintenancePlan(request);
    if (
      (!request.startDate || !request.endDate) &&
      filter?.find((item) => item.column === 'maintenancePlanId')
    ) {
      const maintenancePlan = await this.maintenancePlanRepository.findOneById(
        request.filter.find((item) => item.column === 'maintenancePlanId')
          ?.text,
      );
      if (maintenancePlan) {
        request.startDate = maintenancePlan.planFrom.toISOString();
        request.endDate = maintenancePlan.planTo.toISOString();
      }
    }

    const { listRangeDate } = this.getRangeDateForMaintenancePlan(
      reportUnitType,
      request.startDate,
      request.endDate,
    );
    const unitTypeText = await this.i18n.translate(
      'export.reportMaintenancePlan.unitType',
    );
    const reportMaintenancePlan = await this.i18n.translate(
      'export.reportMaintenancePlan',
    );
    const reportByUnits = {};

    const titleUnit = [];
    let month = moment(listRangeDate[0]?.startDate).month();
    let unit =
      reportUnitType === REPORT_UNIT_TYPE_ENUM.MONTH
        ? moment(listRangeDate[0]?.startDate).date()
        : moment(listRangeDate[0]?.startDate).isoWeek();

    const unitWidth = 4;
    let endColumnMerge = 2;
    let startColumnMerge = 3;
    const workbook = new Workbook();
    const worksheet = workbook.addWorksheet('Sheet1');
    // create header row one
    const headerRowOne = worksheet.getRow(3);
    headerRowOne.values = [
      reportMaintenancePlan.name,
      reportMaintenancePlan.jobTitle,
    ];

    listRangeDate.forEach((e, index) => {
      if (moment(e.startDate).month() !== month) {
        // merge unit header
        worksheet.mergeCellsWithoutStyle(
          3,
          startColumnMerge,
          3,
          endColumnMerge,
        );
        headerRowOne.getCell(startColumnMerge).value = `${unitTypeText.month} ${
          month + 1
        }`;
        headerRowOne.getCell(startColumnMerge).style = {
          font: <Font>EXCEL_STYLE.TITLE_FONT,
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER,
          border: <Partial<Borders>>EXCEL_STYLE.BORDER_ALL,
        };

        startColumnMerge = endColumnMerge + 1;
        unit =
          reportUnitType === REPORT_UNIT_TYPE_ENUM.MONTH
            ? moment(e.startDate).date()
            : moment(e.startDate).isoWeek();
        month = moment(e.startDate).month();
      }
      titleUnit.push({
        key: 'unit' + index,
        width: unitWidth,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: unit,
      });
      endColumnMerge++;
      unit++;
    });
    worksheet.mergeCellsWithoutStyle(3, startColumnMerge, 3, endColumnMerge);
    headerRowOne.getCell(startColumnMerge).value = `${unitTypeText.month} ${
      month + 1
    }`;

    headerRowOne.eachCell(function (cell) {
      cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
      cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
    });
    // end header row one
    const subHeader = [
      {
        key: 'name',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.reportMaintenancePlanSub.name',
        ),
      },
      {
        key: 'content',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.reportMaintenancePlanSub.jobTitle',
        ),
      },
      ...titleUnit,
    ];
    const items = [];
    reports?.forEach((report) => {
      report.jobs?.map((job) => {
        job.reportByUnits?.map((el) => {
          const keyByDate = `unit${el.tag}`;
          reportByUnits[keyByDate] = el.status === 3 ? '' : el.status;
        });
        items.push({
          name: report.device?.name ?? '',
          content: job.category ?? '',
          ...reportByUnits,
          id: report.device?.id,
        });
      });
    });
    const countRowData = ROW.COUNT_START_ROW;
    let preDeviceId = items[0]?.id;
    //  row start data
    let fromRow = 5;
    let toRow = 0;
    let count = 0;
    const title = await this.i18n.translate(
      'export.reportMaintenancePlan.title',
    );
    const styleUnitMap = new Map();
    styleUnitMap.set(JOB_REPORT_STATUS_ENUM.IN_PROGRESS, {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: JOB_COLOR_STATUS_ENUM.IN_PROGRESS },
    });
    styleUnitMap.set(JOB_REPORT_STATUS_ENUM.RESOLVED, {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: JOB_COLOR_STATUS_ENUM.RESOLVED },
    });
    styleUnitMap.set(JOB_REPORT_STATUS_ENUM.UN_RESOLVE, {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: JOB_COLOR_STATUS_ENUM.UN_RESOLVE },
    });

    const titleRow = worksheet.getRow(1);
    titleRow.values = [title];
    titleRow.font = <Font>EXCEL_STYLE.TITLE_FONT;

    const headerRowTwo = worksheet.getRow(4);
    headerRowTwo.values = subHeader.map((header) => header.title);
    headerRowTwo.eachCell(function (cell) {
      cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
      cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
    });
    items.forEach((element) => {
      worksheet.columns = subHeader;

      worksheet
        .addRow({
          ...element,
        })
        .eachCell(function (cell) {
          cell.fill = styleUnitMap.get(cell.value);
          if (cell.fill) {
            cell.value = '';
          }
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          cell.font = <Font>EXCEL_STYLE.DEFAULT_FONT;
        });
      // merge name of device
      if (element.id !== preDeviceId) {
        toRow = plus(fromRow, count);
        worksheet.mergeCells(fromRow, 1, toRow, 1);
        preDeviceId = element.id;
        count = 0;
        fromRow = plus(toRow, 1);
      } else if (
        element.id === preDeviceId &&
        countRowData !== ROW.COUNT_START_ROW
      ) {
        count++;
      }
      if (countRowData === items.length) {
        toRow = plus(fromRow, count);
        worksheet.mergeCells(fromRow, 1, toRow, 1);
      }
    });
    if (workbook?.xlsx) {
      await workbook.xlsx.writeFile('excel.xlsx');
      const file = await workbook.xlsx.writeBuffer();
      return new ResponseBuilder(file)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.NOT_FOUND)
      .withMessage(await this.i18n.translate('error.NOT_FOUND'))
      .build();
  }

  async exportDeviceUseStatus(
    request: GetDeviceUseStatusReportRequest,
  ): Promise<ResponsePayload<any>> {
    const {
      data: { items: reports },
    } = await this.getDeviceUseStatus(request);
    const statusDetail = await this.i18n.translate(
      'export.deviceUseStatus.status',
    );
    const quantityText = await this.i18n.translate(
      'export.deviceUseStatus.quantity',
    );
    const scaleText = await this.i18n.translate('export.deviceUseStatus.scale');
    const statusValues = Object.values(statusDetail);
    const headerStatusDetail = Object.entries(statusDetail).flatMap(
      ([key, value]) => [
        {
          title: '',
        },
        {
          key: key,
          width: 20,
          style: {
            alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
          },
          title: value?.toString(),
        },
      ],
    );
    const subHeaderStatusDetail = Object.keys(statusDetail).flatMap((key) => [
      {
        key: key + 'Quantity',
        width: 10,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: quantityText,
      },
      {
        key: key + 'Scale',
        width: 10,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: scaleText,
      },
    ]);

    const header = [
      {
        key: 'stt',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceUseStatus.stt'),
      },
      {
        key: 'useUnit',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceUseStatus.useUnit'),
      },
      {
        key: 'total',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceUseStatus.total'),
      },
      ...headerStatusDetail,
      {
        key: 'note',
        width: 0,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceUseStatus.note'),
      },
    ];
    const subHeader = [
      {
        key: 'stt',
        width: 5,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceUseStatus.stt'),
      },
      {
        key: 'useUnit',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceUseStatus.useUnit'),
      },
      {
        key: 'total',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceUseStatus.total'),
      },
      ...subHeaderStatusDetail,
      {
        key: 'note',
        width: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceUseStatus.note'),
      },
    ];

    let items = [];
    const reportMap = groupBy(reports, 'interRegion.id');
    const reportTotal = new Map();
    const firstChar = 65;

    reports.forEach((el) => {
      if (reportTotal.has(el.interRegion?.id)) {
        const detailReportTotal = reportTotal.get(el.interRegion?.id);
        reportTotal.set(el.interRegion?.id, {
          total: detailReportTotal.total + el.total,
          using: detailReportTotal.using + el.totalUsing,
          preventive: detailReportTotal.preventive + el.totalPreventive,
          broken: detailReportTotal.broken + el.totalBroken,
          awaitClearance:
            detailReportTotal.awaitClearance + el.totalAwaitClearance,
        });
      } else {
        reportTotal.set(el.interRegion?.id, {
          total: el.total,
          using: el.totalUsing,
          preventive: el.totalPreventive,
          broken: el.totalBroken,
          awaitClearance: el.totalAwaitClearance,
        });
      }
    });
    const companyTotal = {
      total: 0,
      using: 0,
      preventive: 0,
      broken: 0,
      awaitClearance: 0,
    };
    Object.entries(reportMap).forEach(([key, reportByFactory], index) => {
      const currentTotal = reportTotal.get(key) ?? {};
      let regions = [];
      // tổng dữ liệu của công ty
      Object.keys(currentTotal).forEach((el) => {
        companyTotal[el] += currentTotal[el];
      });

      const subReports = reportByFactory.map((el, index) => {
        regions = regions.concat(
          el.region?.name?.split(' ').length === 1
            ? el.region?.name
            : el.region?.name
                ?.split(' ')
                .reduce((total, cur) => total + cur[0], ''),
        );
        return {
          stt: plus(index, 1),
          useUnit: el.factory?.name ?? '',
          total: el.total,
          usingQuantity: el.totalUsing,
          preventiveQuantity: el.totalPreventive,
          brokenQuantity: el.totalBroken,
          awaitClearanceQuantity: el.totalAwaitClearance,
          ...this.calculateScale({
            total: el.total,
            using: el.totalUsing,
            preventive: el.totalPreventive,
            broken: el.totalBroken,
            awaitClearance: el.totalAwaitClearance,
          }),
          note: '',
        };
      });
      const nameUseUnit = `${String.fromCharCode(index + firstChar)}.${
        reportByFactory[0]?.interRegion?.name ?? ''
      } (Vùng ${uniq(compact(regions)).join('+')})`;
      items.push({
        stt: '',
        useUnit: nameUseUnit,
        total: currentTotal.total,
        usingQuantity: currentTotal.using,
        preventiveQuantity: currentTotal.preventive,
        brokenQuantity: currentTotal.broken,
        awaitClearanceQuantity: currentTotal.awaitClearance,
        ...this.calculateScale(currentTotal),
        note: '',
      });
      items = items.concat(subReports);
    });

    items.push({
      stt: '',
      useUnit: await this.i18n.translate('export.deviceUseStatus.companyTotal'),
      total: companyTotal.total,
      usingQuantity: companyTotal.using,
      preventiveQuantity: companyTotal.preventive,
      brokenQuantity: companyTotal.broken,
      awaitClearanceQuantity: companyTotal.awaitClearance,
      ...this.calculateScale(companyTotal),
      note: '',
    });

    const workbook = new Workbook();
    let countRowData = ROW.COUNT_START_ROW;
    let countSheet = SHEET.START_SHEET;
    const title = await this.i18n.translate('export.deviceUseStatus.title');
    let checkInterRegionName = false;
    items.forEach((element) => {
      let worksheet = workbook.getWorksheet(SHEET.NAME + countSheet);
      if (countRowData == ROW.COUNT_START_ROW) {
        worksheet = workbook.addWorksheet(SHEET.NAME + countSheet);

        const titleRow = worksheet.getRow(1);
        titleRow.values = [title];
        titleRow.font = <Font>EXCEL_STYLE.TITLE_FONT;

        const headerRowOne = worksheet.getRow(3);
        headerRowOne.values = header.map((header) => header.title);
        headerRowOne.eachCell(function (cell) {
          const curruntCol = parseInt(cell.col);
          const currentValue = cell.value.toString();
          if (statusValues.includes(cell.value.toString())) {
            worksheet.mergeCells(3, curruntCol - 1, 3, curruntCol);
            cell.value = currentValue;
          }
          cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
          cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        });

        const headerRowTwo = worksheet.getRow(4);
        headerRowTwo.values = subHeader.map((header) => header.title);
        headerRowTwo.eachCell(function (cell) {
          const curruntCol = parseInt(cell.col);
          if (![quantityText, scaleText].includes(cell.value.toString())) {
            worksheet.mergeCells(3, curruntCol, 4, curruntCol);
          }
          cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
          cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        });
      }
      worksheet.columns = subHeader;

      worksheet
        .addRow({
          ...element,
        })
        .eachCell(function (cell) {
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          cell.font = <Font>EXCEL_STYLE.DEFAULT_FONT;
          if (cell.col == '1' && cell.value === '') {
            checkInterRegionName = true;
          }
          if (checkInterRegionName && cell.col == '2') {
            cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
            checkInterRegionName = false;
          }
          if (
            parseInt(cell.value?.toString()[0]) === +cell.value?.toString()[0]
          ) {
            cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
          }
        });

      countRowData++;
      if (countRowData == ROW.COUNT_END_ROW) {
        countSheet++;
        countRowData = ROW.COUNT_START_ROW;
      }
    });
    if (workbook?.xlsx) {
      const file = await workbook.xlsx.writeBuffer();
      return new ResponseBuilder(file)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.NOT_FOUND)
      .withMessage(await this.i18n.translate('error.NOT_FOUND'))
      .build();
  }

  calculateScale(data: any) {
    const { total, ...dataElements } = data;
    const values: number[] = Object.values(dataElements);
    const keys: string[] = Object.keys(dataElements);
    const result: any = {};
    if (total === 0) {
      values.forEach((el, index) => (result[`${keys[index]}Scale`] = `${0}%`));
    } else {
      values.reduce((remainCurrent, el, index) => {
        const currentScale = Math.round(div(el, total) * 100);
        if (currentScale > remainCurrent) {
          result[`${keys[index]}Scale`] = `${remainCurrent}%`;
        } else {
          result[`${keys[index]}Scale`] = `${currentScale}%`;
          return (remainCurrent -= currentScale);
        }
      }, 100);
    }
    return result;
  }

  async exportDeviceUseStatusDetail(
    request: GetReportDeviceUseStatusDetailRequestDto &
      GetReportDeviceUseStatusDetailParamDto,
  ): Promise<ResponsePayload<any>> {
    const { data } = await this.reportDeviceUseStatusDetail(request);
    const deviceUseStatusDetail = await this.i18n.translate(
      'export.deviceUseStatusDetail',
    );
    const header = [
      {
        key: 'stt',
        width: 5,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: deviceUseStatusDetail.stt,
      },
      {
        key: 'name',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: deviceUseStatusDetail.name,
      },
      {
        key: 'quantity',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: deviceUseStatusDetail.quantity,
      },
      {
        key: 'using',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: deviceUseStatusDetail.using,
      },
      {
        key: 'preventive',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: deviceUseStatusDetail.preventive,
      },
      {
        key: 'broken',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: deviceUseStatusDetail.broken,
      },
      {
        key: 'awaitClearance',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: deviceUseStatusDetail.awaitClearance,
      },
      {
        key: 'problem',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: deviceUseStatusDetail.problem,
      },
    ];
    const total = {
      total: 0,
      totalUsing: 0,
      totalPreventive: 0,
      totalBroken: 0,
      totalAwaitClearance: 0,
    };
    const statusKeys = Object.keys(total);
    const factory = data?.factory?.name ?? '';
    const results = data?.items ?? [];
    results.forEach((el) => {
      statusKeys.forEach((key) => {
        total[key] += el[key] ?? 0;
      });
    });
    const items = [];
    let scaleTotal = {};
    if (total.total === 0) {
      scaleTotal = {
        quantity: '0%',
        using: '0%',
        preventive: '0%',
        broken: '0%',
        awaitClearance: '0%',
      };
    } else {
      const {
        totalUsingScale: using,
        totalPreventiveScale: preventive,
        totalBrokenScale: broken,
        totalAwaitClearanceScale: awaitClearance,
      } = this.calculateScale(total);
      scaleTotal = {
        quantity: '100%',
        using,
        preventive,
        broken,
        awaitClearance,
      };
    }
    items.push({
      stt: '',
      name: '',
      unit: '',
      ...scaleTotal,
      problem: '',
    });
    items.push({
      stt: '',
      name: '',
      quantity: total.total,
      using: total.totalUsing,
      preventive: total.totalPreventive,
      broken: total.totalBroken,
      awaitClearance: total.totalAwaitClearance,
      problem: '',
    });

    results.forEach((el, index) => {
      items.push({
        stt: plus(index, 1),
        name: el.name ?? '',
        quantity: el.total,
        using: el.totalUsing,
        preventive: el.totalPreventive,
        broken: el.totalBroken,
        awaitClearance: el.totalAwaitClearance,
        problem: '',
      });
    });

    const workbook = new Workbook();
    let countRowData = ROW.COUNT_START_ROW;
    let countSheet = SHEET.START_SHEET;
    let rowTotal = '';
    const title = `${deviceUseStatusDetail.title} ${factory}`;
    items.forEach((element) => {
      let worksheet = workbook.getWorksheet(SHEET.NAME + countSheet);
      if (countRowData == ROW.COUNT_START_ROW) {
        worksheet = workbook.addWorksheet(SHEET.NAME + countSheet);

        const titleRow = worksheet.getRow(1);
        titleRow.values = [title];
        titleRow.font = <Font>EXCEL_STYLE.TITLE_FONT;

        const headerRowOne = worksheet.getRow(3);
        headerRowOne.height = 40;
        headerRowOne.values = header.map((header) => header.title);
        headerRowOne.eachCell(function (cell) {
          cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
          cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        });
      }
      worksheet.columns = header;
      worksheet
        .addRow({
          ...element,
        })
        .eachCell(function (cell) {
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          cell.font = <Font>EXCEL_STYLE.DEFAULT_FONT;
          if (+cell.col === 1 && cell.value === '') {
            worksheet.mergeCells(+cell.row, 1, +cell.row, 2);
            rowTotal = cell.row;
          }
          if (cell.row === rowTotal) {
            cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
          }
          if (
            +cell.value.toString()[0] === parseInt(cell.value.toString()[0])
          ) {
            cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
          }
        });

      countRowData++;
      if (countRowData == ROW.COUNT_END_ROW) {
        countSheet++;
        countRowData = ROW.COUNT_START_ROW;
      }
    });
    if (workbook?.xlsx) {
      await workbook.xlsx.writeFile('excel.xlsx');
      const file = await workbook.xlsx.writeBuffer();
      return new ResponseBuilder(file)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.NOT_FOUND)
      .withMessage(await this.i18n.translate('error.NOT_FOUND'))
      .build();
  }

  async reportNewInvestmentDevice(
    request: GetReportNewInvestmentDevice,
  ): Promise<ResponsePayload<any>> {
    const { result: reportDevices, count } =
      await this.deviceRepository.reportNewInvestmentDevice(request);
    const factoryIdReturns = map(reportDevices, 'factoryId');

    const factories = await this.userService.getFactoryList([
      { column: 'factoryIds', text: uniq(factoryIdReturns) },
    ]);
    const factoryMap = keyBy(factories, 'id');
    reportDevices.forEach((device) => {
      device.factory = factoryMap[device.factoryId];
      device.vendor = first(device.vendor);
      device.deviceName = first(device.deviceName);
      device.capitalizationDate = device.capitalizationDate || device.createdAt;
    });

    const dataReturn = plainToInstance(
      ReportNewInvestmentDeviceResponse,
      reportDevices,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder({
      items: dataReturn,
      meta: {
        total: count || 0,
        page: request.page,
      },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
