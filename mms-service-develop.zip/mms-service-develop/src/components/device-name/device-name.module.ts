import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { DeviceNameSchema } from 'src/models/device-name/device-name.schema';
import { DeviceNameRepository } from 'src/repository/device-name/device-name.repository';
import { DeviceRepository } from 'src/repository/device/device.repository';
import { DeviceNameController } from './device-name.controller';
import { DeviceNameService } from './device-name.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'DeviceName', schema: DeviceNameSchema },
    ]),
  ],
  providers: [
    {
      provide: 'DeviceNameRepositoryInterface',
      useClass: DeviceNameRepository,
    },
    {
      provide: 'DeviceRepositoryInterface',
      useClass: DeviceRepository,
    },
    {
      provide: 'DeviceNameServiceInterface',
      useClass: DeviceNameService,
    },
  ],
  controllers: [DeviceNameController],
  exports: [
    MongooseModule,
    {
      provide: 'DeviceNameRepositoryInterface',
      useClass: DeviceNameRepository,
    },
    {
      provide: 'DeviceNameServiceInterface',
      useClass: DeviceNameService,
    },
  ],
})
export class DeviceNameModule {}
