import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';
import { DetailDeviceNameResponse } from './detail-device-name.dto';

export class ListDeviceNameResponse extends PaginationResponse {
  @Expose()
  @ApiProperty({ type: DetailDeviceNameResponse, isArray: true })
  @Type(() => DetailDeviceNameResponse)
  items: DetailDeviceNameResponse[];
}
