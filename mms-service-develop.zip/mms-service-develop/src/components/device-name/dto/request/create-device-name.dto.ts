import { DEVICE_NAME_CONST } from '@components/device-name/device-name.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';
import { IsNotBlank } from 'src/validator/is-not-blank.validator';

export class CreateDeviceNameRequestDto extends BaseDto {
  code: string;

  @ApiProperty()
  @MaxLength(DEVICE_NAME_CONST.NAME.MAX_LENGTH)
  @IsNotBlank()
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiPropertyOptional()
  @MaxLength(DEVICE_NAME_CONST.DESCRIPTION.MAX_LENGTH)
  @IsString()
  @IsOptional()
  description: string;
}
