import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateDeviceNameRequestDto } from './create-device-name.dto';

export class UpdateDeviceNameRequestDto extends CreateDeviceNameRequestDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  id: string;
}
