import { CODE_REGEX } from '@constant/common';

export const DEVICE_NAME_CONST = {
  CODE: {
    MAX_LENGTH: 20,
    MIN_LENGTH: 6,
    COLUMN: 'code',
    PAD_CHAR: '0',
    PREFIX: 'TTB',
    REGEX: CODE_REGEX,
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
};
