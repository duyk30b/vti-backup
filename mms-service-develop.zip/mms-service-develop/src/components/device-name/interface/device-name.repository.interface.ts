import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { DeviceName } from 'src/models/device-name/device-name.model';
import { ListDeviceNameRequestDto } from '../dto/request/list-device-name.dto';

export interface DeviceNameRepositoryInterface
  extends BaseAbstractRepository<DeviceName> {
  createEntity(request: any): DeviceName;
  updateEntity(deviceType: DeviceName, request: any): DeviceName;
  list(request: ListDeviceNameRequestDto): Promise<any>;
}
