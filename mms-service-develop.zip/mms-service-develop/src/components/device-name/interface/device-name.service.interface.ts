import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreateDeviceNameRequestDto } from '../dto/request/create-device-name.dto';
import { ListDeviceNameRequestDto } from '../dto/request/list-device-name.dto';
import { UpdateDeviceNameRequestDto } from '../dto/request/update-device-name.dto';
import { ListDeviceNameResponse } from '../dto/response/list-device-name.dto';

export interface DeviceNameServiceInterface {
  create(data: CreateDeviceNameRequestDto): Promise<ResponsePayload<any>>;
  update(request: UpdateDeviceNameRequestDto): Promise<ResponsePayload<any>>;
  updateStatus(
    request: UpdateActiveStatusPayload,
  ): Promise<ResponsePayload<any>>;
  list(
    request: ListDeviceNameRequestDto,
  ): Promise<ResponsePayload<ListDeviceNameResponse>>;
  detail(request: IdParamDto): Promise<ResponsePayload<any>>;
  import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }>;
}
