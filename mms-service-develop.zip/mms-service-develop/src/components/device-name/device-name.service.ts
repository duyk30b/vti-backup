import { DeviceRepositoryInterface } from '@components/device/interface/device.repository.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { plus } from '@utils/common';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { has, keyBy } from 'lodash';
import { Types } from 'mongoose';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { generateCodeByPreviousCode } from 'src/helper/code.helper';
import { DEVICE_NAME_CONST } from './device-name.constant';
import { CreateDeviceNameRequestDto } from './dto/request/create-device-name.dto';
import { ListDeviceNameRequestDto } from './dto/request/list-device-name.dto';
import { UpdateDeviceNameRequestDto } from './dto/request/update-device-name.dto';
import { DetailDeviceNameResponse } from './dto/response/detail-device-name.dto';
import { DeviceNameRepositoryInterface } from './interface/device-name.repository.interface';
import { DeviceNameServiceInterface } from './interface/device-name.service.interface';

@Injectable()
export class DeviceNameService implements DeviceNameServiceInterface {
  constructor(
    @Inject('DeviceNameRepositoryInterface')
    private readonly deviceNameRepository: DeviceNameRepositoryInterface,

    @Inject('DeviceRepositoryInterface')
    private readonly deviceRepository: DeviceRepositoryInterface,

    private i18n: I18nRequestScopeService,
  ) {}

  async import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const dataInsert = [];
    const dataToUpdate = [];
    const codesUpdate = [];
    const dataError = [];
    const textAdd = await this.i18n.translate('import.common.add');

    const deviceNameConst = DEVICE_NAME_CONST.CODE;
    const lastRecord = await this.deviceNameRepository.lastRecord();
    const codeCurrent =
      Number(lastRecord.code?.replace(deviceNameConst.PREFIX, '')) || 0;
    data.forEach((item, index) => {
      if (item.action === textAdd) {
        item.code = generateCodeByPreviousCode(
          deviceNameConst.PREFIX,
          plus(codeCurrent, index),
        );
        dataInsert.push(item);
      } else {
        dataToUpdate.push(item);
        codesUpdate.push(item.code);
      }
    });
    const deviceNameCodeUpdateExists =
      await this.deviceNameRepository.findAllByCondition({
        code: { $in: codesUpdate },
      });

    const deviceNameUpdateMap = keyBy(deviceNameCodeUpdateExists, 'code');

    const dataUpdate = [];
    dataToUpdate.forEach((item) => {
      if (!has(deviceNameUpdateMap, item.code)) {
        dataError.push(item);
      } else {
        dataUpdate.push(item);
      }
    });

    const deviceTypeDocument = [...dataInsert, ...dataUpdate];
    const bulkOps = deviceTypeDocument.map((doc) => ({
      updateOne: {
        filter: { code: doc.code },
        update: {
          $set: {
            code: doc.code,
            name: doc.name,
            description: doc.description,
          },
        },
        upsert: true,
      },
    }));
    const dataSuccess = await this.deviceNameRepository.bulkWrite(bulkOps);

    return {
      dataError,
      dataSuccess,
    };
  }

  async create(
    data: CreateDeviceNameRequestDto,
  ): Promise<ResponsePayload<any>> {
    try {
      const validate = await this.validateBeforeSave(data);
      if (validate.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validate;
      }
      const deviceNameConst = DEVICE_NAME_CONST.CODE;
      const lastRecord = await this.deviceNameRepository.lastRecord();
      const codeCurrent =
        Number(lastRecord.code?.replace(deviceNameConst.PREFIX, '')) || 0;
      data.code = generateCodeByPreviousCode(
        deviceNameConst.PREFIX,
        codeCurrent,
      );

      const newObjectName = this.deviceNameRepository.createEntity(data);
      const dataSave = await newObjectName.save();
      const dataReturn = plainToInstance(BasicResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CREATE '))
        .build();
    }
  }

  async update(
    request: UpdateDeviceNameRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, ...data } = request;
    try {
      const validate = await this.validateBeforeSave(request, true);
      if (validate.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validate;
      }
      let deviceName = await this.deviceNameRepository.findOneById(id);
      if (!deviceName) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.DEVICE_NAME_NOT_FOUND'))
          .build();
      }

      deviceName = this.deviceNameRepository.updateEntity(deviceName, data);
      await this.deviceNameRepository.findByIdAndUpdate(id, deviceName);
      await this.deviceRepository.findAllAndUpdate(
        { deviceNameId: id },
        { $set: { name: deviceName.name } },
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }
  }

  async updateStatus(
    request: UpdateActiveStatusPayload,
  ): Promise<ResponsePayload<any>> {
    const { id, status } = request;

    try {
      const deviceName = await this.deviceNameRepository.findOneById(id);
      if (!deviceName) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.DEVICE_NAME_NOT_FOUND'))
          .build();
      }

      await this.deviceNameRepository.findByIdAndUpdate(id, {
        $set: { active: status },
      });

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }
  }

  async list(request: ListDeviceNameRequestDto): Promise<ResponsePayload<any>> {
    try {
      const { data, count } = await this.deviceNameRepository.list(request);
      const dataReturn = plainToInstance(DetailDeviceNameResponse, data, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder({
        items: dataReturn,
        meta: { page: request.page, total: count },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async detail(request: IdParamDto): Promise<ResponsePayload<any>> {
    try {
      const deviceName = await this.deviceNameRepository.findOneByCondition({
        _id: request.id,
      });
      if (!deviceName) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.DEVICE_NAME_NOT_FOUND'))
          .build();
      }
      const dataReturn = plainToInstance(DetailDeviceNameResponse, deviceName, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  private async validateBeforeSave(request: any, isUpdate = false) {
    const conditionValidateNameUnique = isUpdate
      ? {
          _id: { $ne: new Types.ObjectId(request.id) },
          name: { $regex: new RegExp(`^${request.name}$`, 'i') },
        }
      : { name: { $regex: new RegExp(`^${request.name}$`, 'i') } };

    const existsDeviceName = await this.deviceNameRepository.findOneByCondition(
      conditionValidateNameUnique,
    );
    if (existsDeviceName) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.DEVICE_NAME_HAS_EXISTS'))
        .build();
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
