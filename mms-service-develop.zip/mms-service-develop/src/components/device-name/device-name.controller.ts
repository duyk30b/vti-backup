import { ACTIVE_ENUM } from '@constant/common';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  Body,
  Controller,
  Get,
  Inject,
  Injectable,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import {
  CREATE_DEVICE_PERMISSION,
  UPDATE_DEVICE_PERMISSION,
} from '@utils/permissions/device';
import {
  CREATE_DEVICE_NAME_PERMISSION,
  DETAIL_DEVICE_NAME_PERMISSION,
  LIST_DEVICE_NAME_PERMISSION,
  UPDATE_DEVICE_NAME_PERMISSION,
  UPDATE_STATUS_DEVICE_NAME_PERMISSION,
} from '@utils/permissions/device-name';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateDeviceNameRequestDto } from './dto/request/create-device-name.dto';
import { ListDeviceNameRequestDto } from './dto/request/list-device-name.dto';
import { DetailDeviceNameResponse } from './dto/response/detail-device-name.dto';
import { ListDeviceNameResponse } from './dto/response/list-device-name.dto';
import { DeviceNameServiceInterface } from './interface/device-name.service.interface';

@Injectable()
@Controller('/device-name')
export class DeviceNameController {
  constructor(
    @Inject('DeviceNameServiceInterface')
    private deviceNameService: DeviceNameServiceInterface,
  ) {}

  @PermissionCode(CREATE_DEVICE_NAME_PERMISSION.code)
  @Post()
  @ApiOperation({
    tags: ['Device Name'],
    summary: 'Create Device Name',
    description: 'Create Device Name',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: SuccessResponse,
  })
  async create(@Body() body: CreateDeviceNameRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceNameService.create(request);
  }

  @PermissionCode(
    LIST_DEVICE_NAME_PERMISSION.code,
    CREATE_DEVICE_PERMISSION.code,
    UPDATE_DEVICE_PERMISSION.code,
  )
  @Get()
  @ApiOperation({
    tags: ['Device Name'],
    summary: 'List Device Name',
    description: 'List Device Name',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: ListDeviceNameResponse,
  })
  async list(@Query() query: ListDeviceNameRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceNameService.list(request);
  }

  @PermissionCode(DETAIL_DEVICE_NAME_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Device Name'],
    summary: 'Detail Device Name',
    description: 'Detail Device Name',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: DetailDeviceNameResponse,
  })
  async detail(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceNameService.detail(request);
  }

  @PermissionCode(UPDATE_DEVICE_NAME_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Device Name'],
    summary: 'Update Device Name',
    description: 'Update Device Name',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: SuccessResponse,
  })
  async update(
    @Param() param: IdParamDto,
    @Body() body: CreateDeviceNameRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    const {
      request: { id },
      responseError: responseErrorParam,
    } = param;
    if (responseErrorParam && !isEmpty(responseErrorParam)) {
      return responseErrorParam;
    }

    return await this.deviceNameService.update({ ...request, id });
  }

  @PermissionCode(UPDATE_STATUS_DEVICE_NAME_PERMISSION.code)
  @Put('/:id/active')
  @ApiOperation({
    tags: ['Device Name'],
    summary: 'Active Device Name',
    description: 'Active Device Name',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: SuccessResponse,
  })
  async active(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceNameService.updateStatus({
      status: ACTIVE_ENUM.ACTIVE,
      ...request,
    });
  }

  @PermissionCode(UPDATE_STATUS_DEVICE_NAME_PERMISSION.code)
  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Device Name'],
    summary: 'Inactive Device Name',
    description: 'Inactive Device Name',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: SuccessResponse,
  })
  async inactive(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceNameService.updateStatus({
      status: ACTIVE_ENUM.INACTIVE,
      ...request,
    });
  }
}
