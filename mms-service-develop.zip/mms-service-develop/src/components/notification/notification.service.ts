import { NATS_NOTIFICATION } from '@config/nats.config';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { PushNotificationRequestDto } from './dto/notification.request.dto';
import { NotificationServiceInterface } from './interface/notification.service.interface';

@Injectable()
export class NotificationService implements NotificationServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async pushNotification(request: PushNotificationRequestDto): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_NOTIFICATION}.createNotification`,
      request,
    );
    return response;
  }
}
