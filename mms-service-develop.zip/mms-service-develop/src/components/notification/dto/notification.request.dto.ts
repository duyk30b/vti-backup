import { NOTIFICATION_ENTITY_ENUM } from '../notification.const';

export class PushNotificationRequestDto {
  title: string;
  content: string;
  templateId?: string;
  executionDate?: string;
  type: string;
  action: string;
  payload?: Payload;
  userIds?: number[];
  createdBy: number;
}

export class Payload {
  id: string;
  name: string;
  code: string;
  entityType: number;
  entity: NOTIFICATION_ENTITY_ENUM;
}
