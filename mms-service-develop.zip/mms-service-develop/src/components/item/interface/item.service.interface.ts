export interface ItemServiceInterface {
  getListUnit(filter: any): Promise<any>;
  getUnitById(id: number): Promise<any>;
}
