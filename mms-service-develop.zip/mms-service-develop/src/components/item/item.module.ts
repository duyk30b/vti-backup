import { ItemController } from '@components/item/item.controller';
import { ConfigService } from '@config/config.service';
import { Global, Module } from '@nestjs/common';
import { ItemService } from './item.service';

@Global()
@Module({
  imports: [],
  exports: ['ItemServiceInterface'],
  providers: [
    ConfigService,
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
  ],
  controllers: [ItemController],
})
export class ItemModule {}
