import { Controller, Inject } from '@nestjs/common';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';

@Controller('')
export class ItemController {
  constructor(
    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,
  ) {}
}
