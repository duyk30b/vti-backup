import { NATS_ITEM } from '@config/nats.config';
import { GET_ALL_ENUM } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { getFilterToRequest } from '@utils/common';
import { ItemServiceInterface } from './interface/item.service.interface';

@Injectable()
export class ItemService implements ItemServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}
  async getListUnit(filter: any): Promise<any> {
    const params = {
      filter: getFilterToRequest(filter),
      isGetAll: GET_ALL_ENUM.YES.toString(),
    };
    try {
      const response = await this.natsClientService.send(
        `${NATS_ITEM}.get_list_item_unit_setting`,
        params,
      );

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }
      return response.data.items;
    } catch (err) {
      return [];
    }
  }
  async getUnitById(id: number): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_ITEM}.get_item_unit_setting_detail`,
        id,
      );
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return null;
      }
      return response.data;
    } catch (err) {
      return null;
    }
  }
}
