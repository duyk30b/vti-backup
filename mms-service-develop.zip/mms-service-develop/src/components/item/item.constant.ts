export const UNIT_CONST = {
  CODE: {
    MAX_LENGTH: 20,
    MIN_LENGTH: 1,
  },
};
