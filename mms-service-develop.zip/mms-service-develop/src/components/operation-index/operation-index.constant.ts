import { ACTIVE_ENUM, CODE_REGEX } from '@constant/common';

export const OPERATION_INDEX_CONST = {
  CODE: {
    MAX_LENGTH: 20,
    MIN_LENGTH: 6,
    COLUMN: 'code',
    REGEX: CODE_REGEX,
    PREFIX: 'CSP',
  },
  NAME: { MIN_LENGTH: 1, MAX_LENGTH: 255, COLUMN: 'name' },
  UNIT: { MIN_LENGTH: 1, MAX_LENGTH: 255, COLUMN: 'unit' },
  ACTIVE: {
    COLUMN: 'active',
    ENUM: ACTIVE_ENUM,
  },
};
