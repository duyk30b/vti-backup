import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import {
  OperationIndex,
  OperationIndexSchema,
} from 'src/models/operation-index/operation-index.schema';
import { OperationIndexRepository } from 'src/repository/operation-index/operation-index.repository';
import { OperationIndexController } from './operation-index.controller';
import { OperationIndexService } from './operation-index.service';
import { UserService } from '@components/user/user.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: OperationIndex.name, schema: OperationIndexSchema },
    ]),
  ],
  controllers: [OperationIndexController],
  providers: [
    {
      provide: 'OperationIndexRepositoryInterface',
      useClass: OperationIndexRepository,
    },
    {
      provide: 'OperationIndexServiceInterface',
      useClass: OperationIndexService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
  ],
  exports: [
    MongooseModule,
    {
      provide: 'OperationIndexRepositoryInterface',
      useClass: OperationIndexRepository,
    },
    {
      provide: 'OperationIndexServiceInterface',
      useClass: OperationIndexService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
  ],
})
export class OperationIndexModule {}
