import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { OperationIndex } from 'src/models/operation-index/operation-index.schema';
import { CreateOperationIndexRequest } from '../dto/request/create-operation-index.request';
import { GetListOperationIndexQuery } from '../dto/request/get-list-operation-index.query';
import { UpdateOperationIndexBodyDto } from '../dto/request/update-operation-index.request';

export interface OperationIndexRepositoryInterface
  extends BaseAbstractRepository<OperationIndex> {
  createEntity(request: CreateOperationIndexRequest): OperationIndex;
  updateEntity(
    entity: OperationIndex,
    request: UpdateOperationIndexBodyDto,
  ): OperationIndex;
  list(
    request: GetListOperationIndexQuery,
  ): Promise<{ result: OperationIndex[]; count: number }>;
}
