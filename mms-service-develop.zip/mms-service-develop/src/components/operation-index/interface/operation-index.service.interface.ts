import { CreateOperationIndexRequest } from '@components/operation-index/dto/request/create-operation-index.request';
import { GetListOperationIndexQuery } from '@components/operation-index/dto/request/get-list-operation-index.query';
import { UpdateOperationIndexRequest } from '@components/operation-index/dto/request/update-operation-index.request';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { UpdateStatusOperationIndexRequest } from '../dto/request/update-status-operation-index.request';

export interface OperationIndexServiceInterface {
  create(request: CreateOperationIndexRequest): Promise<ResponsePayload<any>>;
  update(request: UpdateOperationIndexRequest): Promise<ResponsePayload<any>>;
  detail(request: IdParamDto): Promise<ResponsePayload<any>>;
  list(request: GetListOperationIndexQuery): Promise<ResponsePayload<any>>;
  updateStatus(request: UpdateStatusOperationIndexRequest): Promise<any>;
}
