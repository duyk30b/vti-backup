import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { GetListOperationIndexQuery } from './dto/request/get-list-operation-index.query';
import { CreateOperationIndexRequest } from './dto/request/create-operation-index.request';
import { UpdateOperationIndexRequest } from './dto/request/update-operation-index.request';
import { DetailOperationIndexResponse } from './dto/response/detail-operation-index.response';
import { OperationIndexRepositoryInterface } from './interface/operation-index.repository.interface';
import { OperationIndexServiceInterface } from './interface/operation-index.service.interface';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { OPERATION_INDEX_CONST } from './operation-index.constant';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { UpdateStatusOperationIndexRequest } from './dto/request/update-status-operation-index.request';
import { flatMap, isEmpty, keyBy, uniq } from 'lodash';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';

@Injectable()
export class OperationIndexService implements OperationIndexServiceInterface {
  constructor(
    @Inject('OperationIndexRepositoryInterface')
    private readonly operationIndexRepository: OperationIndexRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}
  async updateStatus(request: UpdateStatusOperationIndexRequest): Promise<any> {
    const { active, id } = request;
    const operationIndex = await this.operationIndexRepository.findOneById(id);
    if (!operationIndex) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    await this.operationIndexRepository.findByIdAndUpdate(id, {
      $set: { active },
    });
    const dataReturn = plainToInstance(BasicResponseDto, operationIndex, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async create(
    request: CreateOperationIndexRequest,
  ): Promise<ResponsePayload<any>> {
    try {
      const validate = await this.validateBeforeSave(request);
      if (validate.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validate;
      }

      request.code = await this.operationIndexRepository.generateNextCode(
        OPERATION_INDEX_CONST.CODE.PREFIX,
      );
      const document = this.operationIndexRepository.createEntity(request);
      const operationIndex = await document.save();
      const dataReturn = plainToInstance(BasicResponseDto, operationIndex, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async update(
    request: UpdateOperationIndexRequest,
  ): Promise<ResponsePayload<any>> {
    try {
      const { id } = request;
      let operationIndex = await this.operationIndexRepository.findOneById(id);
      if (!operationIndex) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }
      const validate = await this.validateBeforeSave(request);
      if (validate.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validate;
      }

      operationIndex = this.operationIndexRepository.updateEntity(
        operationIndex,
        request,
      );
      operationIndex = await this.operationIndexRepository.findByIdAndUpdate(
        id,
        operationIndex,
      );
      const dataReturn = plainToInstance(BasicResponseDto, operationIndex, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async validateBeforeSave(request: CreateOperationIndexRequest) {
    const { factoryIds } = request;
    const factories = await this.userService.getFactoryList([
      { column: 'factoryIds', text: factoryIds },
    ]);
    if (factories.length !== factoryIds.length) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    return new ApiError(ResponseCodeEnum.SUCCESS).toResponse();
  }

  async detail(request: IdParamDto): Promise<ResponsePayload<any>> {
    try {
      const operationIndex = await this.operationIndexRepository.findOneById(
        request.id,
      );

      if (!operationIndex) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }
      const factories = await this.userService.getFactoryList([
        {
          column: 'factoryIds',
          text: operationIndex.factoryIds,
        },
      ]);
      const dataReturn = plainToInstance(
        DetailOperationIndexResponse,
        { ...operationIndex, factories },
        { excludeExtraneousValues: true },
      );

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async list(
    request: GetListOperationIndexQuery,
  ): Promise<ResponsePayload<any>> {
    const { result, count } = await this.operationIndexRepository.list(request);
    let data = result;
    if (!isEmpty(result)) {
      const factoryIds = uniq(flatMap(result, 'factoryIds'));
      const factories = await this.userService.getFactoryList([
        {
          column: 'factoryIds',
          text: factoryIds,
        },
      ]);
      const factoryMap = keyBy(factories, 'id');
      data = result?.map((item) => {
        item['factories'] = item?.factoryIds?.map(
          (factoryId) => factoryMap[factoryId],
        );
        return item;
      });
    }
    const dataReturn = plainToInstance(DetailOperationIndexResponse, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async delete(request: IdParamDto): Promise<any> {
    const operationIndex = await this.operationIndexRepository.findOneById(
      request.id,
    );

    if (!operationIndex) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    await this.operationIndexRepository.softDelete(request.id);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
