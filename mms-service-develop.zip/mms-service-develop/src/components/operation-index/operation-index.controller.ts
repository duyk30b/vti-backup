import { ACTIVE_ENUM } from '@constant/common';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  Body,
  Controller,
  Get,
  Inject,
  Injectable,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { mergePayload } from '@utils/common';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import {
  DETAIL_OPERATION_INDEX_PERMISSION,
  CREATE_OPERATION_INDEX_PERMISSION,
  UPDATE_OPERATION_INDEX_PERMISSION,
  LIST_OPERATION_INDEX_PERMISSION,
  UPDATE_STATUS_OPERATION_INDEX_PERMISSION,
} from '@utils/permissions/operation-index';
import {
  CREATE_OPERATION_VALUE_PERMISSION,
  UPDATE_OPERATION_VALUE_PERMISSION,
} from '@utils/permissions/operation-value';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateOperationIndexRequest } from './dto/request/create-operation-index.request';
import { GetListOperationIndexQuery } from './dto/request/get-list-operation-index.query';
import { UpdateOperationIndexBodyDto } from './dto/request/update-operation-index.request';
import { DetailOperationIndexResponse } from './dto/response/detail-operation-index.response';
import { ListOperationIndexResponse } from './dto/response/list-operation-index.response';
import { OperationIndexServiceInterface } from './interface/operation-index.service.interface';

@Injectable()
@Controller('/operation-index')
export class OperationIndexController {
  constructor(
    @Inject('OperationIndexServiceInterface')
    private readonly operationIndexService: OperationIndexServiceInterface,
  ) {}

  @PermissionCode(CREATE_OPERATION_INDEX_PERMISSION.code)
  @Post('/')
  @ApiOperation({
    tags: ['Operation Index'],
    summary: 'Định nghĩa chỉ số vận hành',
    description: 'Định nghĩa chỉ số vận hành',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: BasicResponseDto,
  })
  async create(@Body() payload: CreateOperationIndexRequest): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.operationIndexService.create(request);
  }

  @PermissionCode(UPDATE_OPERATION_INDEX_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Operation Index'],
    summary: 'Cập nhật chỉ số vận hành',
    description: 'Cập nhật chỉ số vận hành',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: BasicResponseDto,
  })
  async update(
    @Param() param: IdParamDto,
    @Body() payload: UpdateOperationIndexBodyDto,
  ): Promise<any> {
    const { request, responseError } = mergePayload(payload, param);
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.operationIndexService.update(request);
  }

  @PermissionCode(
    DETAIL_OPERATION_INDEX_PERMISSION.code,
    UPDATE_OPERATION_INDEX_PERMISSION.code,
  )
  @Get('/:id')
  @ApiOperation({
    tags: ['Operation Index'],
    summary: 'Chi tiết chỉ số vận hành',
    description: 'Chi tiết chỉ số vận hành',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailOperationIndexResponse,
  })
  async detail(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.operationIndexService.detail(request);
  }

  @PermissionCode(
    LIST_OPERATION_INDEX_PERMISSION.code,
    CREATE_OPERATION_VALUE_PERMISSION.code,
    UPDATE_OPERATION_VALUE_PERMISSION.code,
  )
  @Get('/')
  @ApiOperation({
    tags: ['Operation Index'],
    summary: 'Danh sách chỉ số vận hành',
    description: 'Danh sách chỉ số vận hành',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListOperationIndexResponse,
  })
  async list(@Query() query: GetListOperationIndexQuery): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.operationIndexService.list(request);
  }

  @PermissionCode(UPDATE_STATUS_OPERATION_INDEX_PERMISSION.code)
  @Put('/:id/active')
  @ApiOperation({
    tags: ['Operation Index'],
    summary: 'Kích hoạt chỉ số vận hành',
    description: 'Kích hoạt chỉ số vận hành',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async active(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.operationIndexService.updateStatus({
      ...request,
      active: ACTIVE_ENUM.ACTIVE,
    });
  }

  @PermissionCode(UPDATE_STATUS_OPERATION_INDEX_PERMISSION.code)
  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Operation Index'],
    summary: 'Khóa chỉ số vận hành',
    description: 'Khóa chỉ số vận hành',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async inactive(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.operationIndexService.updateStatus({
      ...request,
      active: ACTIVE_ENUM.INACTIVE,
    });
  }
}
