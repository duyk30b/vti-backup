import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsMongoId } from 'class-validator';
import { CreateOperationIndexRequest } from './create-operation-index.request';

export class UpdateOperationIndexBodyDto extends CreateOperationIndexRequest {}
export class UpdateOperationIndexRequest extends UpdateOperationIndexBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
