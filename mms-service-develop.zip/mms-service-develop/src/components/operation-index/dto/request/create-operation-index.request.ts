import { OPERATION_INDEX_CONST } from '@components/operation-index/operation-index.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsMongoId,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import { IsNotBlank } from 'src/validator/is-not-blank.validator';

export class Parameter extends BaseDto {
  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  id: string;

  @MaxLength(OPERATION_INDEX_CONST.NAME.MAX_LENGTH)
  @IsNotBlank()
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  name: string;

  @ApiProperty()
  @MaxLength(OPERATION_INDEX_CONST.NAME.MAX_LENGTH)
  @IsString()
  @IsOptional()
  description: string;
}

export class CreateOperationIndexRequest extends BaseDto {
  code: string;

  @ApiProperty()
  @MaxLength(OPERATION_INDEX_CONST.NAME.MAX_LENGTH)
  @IsNotBlank()
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty()
  @IsArray()
  @ArrayNotEmpty()
  factoryIds: number[];

  @ApiProperty()
  @MaxLength(OPERATION_INDEX_CONST.UNIT.MAX_LENGTH)
  @IsString()
  @IsNotEmpty()
  unit: string;

  @ApiProperty({ type: Parameter, isArray: true })
  @ArrayNotEmpty()
  @Type(() => Parameter)
  @ValidateNested({ each: true })
  @ArrayUnique((data) => data.name)
  parameters: Parameter[];
}
