import { PaginationQuery } from '@utils/dto/request/pagination.query';

export class GetListOperationIndexQuery extends PaginationQuery {}
