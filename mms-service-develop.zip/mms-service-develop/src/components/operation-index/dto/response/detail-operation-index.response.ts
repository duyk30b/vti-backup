import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { Expose, Type } from 'class-transformer';

export class ParameterResponse extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  name: string;
}
export class DetailOperationIndexResponse extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  unit: string;

  @ApiProperty()
  @Expose()
  active: number;

  @ApiProperty({ type: BasicSqlDocumentResponse, isArray: true })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  factories: BasicSqlDocumentResponse[];

  @ApiProperty({ type: ParameterResponse, isArray: true })
  @Type(() => ParameterResponse)
  @Expose()
  parameters: ParameterResponse;
}
