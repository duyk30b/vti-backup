import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';
import { DetailOperationIndexResponse } from './detail-operation-index.response';

export class ListOperationIndexResponse extends PaginationResponse {
  @ApiProperty({ type: DetailOperationIndexResponse, isArray: true })
  @Type(() => DetailOperationIndexResponse)
  @Expose()
  items: DetailOperationIndexResponse[];
}
