import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
export class GetListSupplyGroupRequestDto extends PaginationQuery {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  isGetAll: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  queryIds: string;
}
