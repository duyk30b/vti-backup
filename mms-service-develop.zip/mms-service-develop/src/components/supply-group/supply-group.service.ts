import { Inject, Injectable } from '@nestjs/common';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { SupplyGroupServiceInterface } from '@components/supply-group/interface/supply-group.service.interface';
import { SupplyGroupRepositoryInterface } from '@components/supply-group/interface/supply-group.repository.interface';
import { plainToInstance } from 'class-transformer';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { CreateSupplyGroupRequestDto } from '@components/supply-group/dto/request/create-supply-group.request.dto';
import { GetListSupplyGroupRequestDto } from '@components/supply-group/dto/request/get-list-supply-group.request.dto';
import { GetDetailSupplyGroupResponseDto } from '@components/supply-group/dto/response/get-detail-supply-group.response.dto';
import { keyBy, has } from 'lodash';
import { GET_ALL_ENUM } from '@constant/common';
import { DetailSupplyGroupRequestDto } from './dto/request/detail-supply-group.request.dto';
import { UpdateSupplyGroupRequestDto } from './dto/request/update-supply-group.request.dto';
import { SUPPLY_GROUP_CONST } from './supply-group.constant';
import { generateCodeByPreviousCode } from 'src/helper/code.helper';
import { plus } from '@utils/common';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';

@Injectable()
export class SupplyGroupService implements SupplyGroupServiceInterface {
  constructor(
    @Inject('SupplyGroupRepositoryInterface')
    private readonly supplyGroupRepository: SupplyGroupRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateSupplyGroupRequestDto): Promise<any> {
    try {
      const supplyGroupCode = SUPPLY_GROUP_CONST.CODE;
      const lastRecord = await this.supplyGroupRepository.lastRecord();
      const codeCurrent =
        +lastRecord.code?.replace(supplyGroupCode.PREFIX, '') || 0;
      request.code = generateCodeByPreviousCode(
        supplyGroupCode.PREFIX,
        codeCurrent,
      );
      const supplyGroup = this.supplyGroupRepository.createDocument(request);
      const dataSave = await supplyGroup.save();
      const dataReturn = plainToInstance(BasicResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getList(request: GetListSupplyGroupRequestDto): Promise<any> {
    if (parseInt(request.isGetAll) == GET_ALL_ENUM.YES) {
      const response = await this.supplyGroupRepository.findAll();
      if (!response) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.SUPPLY_GROUP_NOT_FOUND'),
          )
          .build();
      }
      const result = plainToInstance(
        GetDetailSupplyGroupResponseDto,
        response,
        {
          excludeExtraneousValues: true,
        },
      );
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } else {
      const { data, count } = await this.supplyGroupRepository.getList(request);
      const response = plainToInstance(GetDetailSupplyGroupResponseDto, data, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder<PaginationResponse>({
        items: response,
        meta: { total: count, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
  }

  async detail(request: DetailSupplyGroupRequestDto): Promise<any> {
    const { id } = request;
    const response = await this.supplyGroupRepository.findOneById(id);
    if (!response) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.SUPPLY_GROUP_NOT_FOUND'))
        .build();
    }

    const result = plainToInstance(GetDetailSupplyGroupResponseDto, response, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async update(request: UpdateSupplyGroupRequestDto): Promise<any> {
    try {
      const { id } = request;
      let supplyGroup = await this.supplyGroupRepository.findOneById(id);
      if (!supplyGroup) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.SUPPLY_GROUP_NOT_FOUND'),
          )
          .build();
      }
      supplyGroup = this.supplyGroupRepository.updateEntity(
        supplyGroup,
        request,
      );
      await this.supplyGroupRepository.findByIdAndUpdate(id, supplyGroup);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }
  }

  async import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const dataInsert = [];
    const dataToUpdate = [];
    const codesUpdate = [];
    const textAdd = await this.i18n.translate('import.common.add');
    const supplyGroupCode = SUPPLY_GROUP_CONST.CODE;
    const lastRecord = await this.supplyGroupRepository.lastRecord();
    const codeCurrent =
      +lastRecord.code?.replace(supplyGroupCode.PREFIX, '') || 0;
    data.forEach((item, index) => {
      if (item.action === textAdd) {
        item.code = generateCodeByPreviousCode(
          supplyGroupCode.PREFIX,
          plus(codeCurrent, index),
        );
        dataInsert.push(item);
      } else {
        dataToUpdate.push(item);
        codesUpdate.push(item.code);
      }
    });
    const supplyGroupCodeUpdateExists =
      await this.supplyGroupRepository.findAllByCondition({
        code: { $in: codesUpdate },
      });
    const supplyGroupUpdateMap = keyBy(supplyGroupCodeUpdateExists, 'code');
    const dataError = [];
    const dataUpdate = [];
    dataToUpdate.forEach((item) => {
      if (!has(supplyGroupUpdateMap, item.code)) {
        dataError.push(item);
      } else {
        dataUpdate.push(item);
      }
    });
    const bulkOps = [...dataInsert, ...dataUpdate].map((doc) => ({
      updateOne: {
        filter: {
          code: doc.code,
        },
        update: doc,
        upsert: true,
      },
    }));

    const dataSuccess = await this.supplyGroupRepository.bulkWrite(bulkOps);

    return {
      dataError,
      dataSuccess,
    };
  }

  async updateStatus(request: UpdateActiveStatusPayload): Promise<any> {
    const { id, status } = request;
    const supplyGroup = await this.supplyGroupRepository.findOneById(id);
    if (!supplyGroup) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    await this.supplyGroupRepository.findByIdAndUpdate(id, {
      $set: {
        active: status,
      },
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'));
  }
}
