import { SuccessResponse } from './../../utils/success.response.dto';
import {
  Controller,
  Inject,
  Injectable,
  Query,
  Param,
  Get,
  Body,
  Post,
  Put,
  UseInterceptors,
} from '@nestjs/common';
import { isEmpty } from 'lodash';
import { DeviceStatusServiceInterface } from './interface/device-status.service.interface';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { CreateDeviceStatusRequestDto } from './dto/request/create-device-status.request.dto';
import {
  GetDetailDeviceStatusOfDateRequestDto,
  GetDetailDeviceStatusParamDto,
} from './dto/request/get-detail-device-status-of-date.request';
import { ResponsePayload } from '@utils/response-payload';
import { GetDetailDeviceStatusOfDeviceRequestDto } from './dto/request/get-detail-device-status-of-device.request.dto';
import { GetListDeviceWithStatusRequestDto } from './dto/request/get-list-device-with-status.request.dto';
import { CreateManyDeviceStatusRequestDto } from './dto/request/create-many-device-status.request.dto';
import { GetListDeviceStatusByDevice } from './dto/response/get-detail-device-status-of-device.response.dto';
import { ListDeviceStatusByDateResponseDto } from './dto/response/get-detail-device-status-of-date.response.dto';
import { GetListDeviceStatusResponseDto } from './dto/response/get-list-device-with-status.response.dto';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { GetDetailOfDeviceStatusResponseDto } from './dto/response/get-detail-of-device-status.response.dto';
import { UpdateDeviceStatusBodyDto } from './dto/request/update-device-status.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CREATE_DEVICE_STATUS_PERMISSION,
  DETAIL_DEVICE_STATUS_PERMISSION,
  LIST_DEVICE_STATUS_PERMISSION,
  UPDATE_DEVICE_STATUS_PERMISSION,
} from '@utils/permissions/device-status';
import { PermissionInterceptor } from '@core/interceptors/permission.interceptor';
@Injectable()
@Controller('device-status')
export class DeviceStatusController {
  constructor(
    @Inject('DeviceStatusServiceInterface')
    private readonly deviceStatusService: DeviceStatusServiceInterface,
  ) {}

  @PermissionCode(CREATE_DEVICE_STATUS_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Post()
  @ApiOperation({
    tags: ['Device status'],
    summary: 'Thêm lịch sử hoạt động thiết bị cho app',
    description: 'Thêm lịch sử hoạt động thiết bị cho app',
  })
  @ApiResponse({
    status: 200,
    description: 'Added device status',
    type: SuccessResponse,
  })
  async create(@Body() payload: CreateDeviceStatusRequestDto): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceStatusService.create(request);
  }

  @PermissionCode(CREATE_DEVICE_STATUS_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Post('/multiple')
  @ApiOperation({
    tags: ['Device status'],
    summary: 'Cập nhật lịch sử hoạt động thiết bị cho web',
    description: 'Cập nhật lịch sử hoạt động thiết bị cho web',
  })
  @ApiResponse({
    status: 200,
    description: 'Changed device status',
  })
  async createMany(
    @Body() payload: CreateManyDeviceStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceStatusService.createMany(request);
  }

  @PermissionCode(DETAIL_DEVICE_STATUS_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get('/:deviceId/get-by-date')
  @ApiOperation({
    tags: ['Device status'],
    summary: 'Lấy chi tiết lịch sử hoạt động thiết bị theo ngày',
    description: 'Lấy chi tiết lịch sử hoạt động thiết bị theo ngày',
  })
  @ApiResponse({
    status: 200,
    description: 'Get detail device status',
    type: ListDeviceStatusByDateResponseDto,
  })
  async detailOfDate(
    @Param() param: GetDetailDeviceStatusParamDto,
    @Query() payload: GetDetailDeviceStatusOfDateRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    const { request: paramRequest, responseError: responseParamError } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }

    request.deviceId = paramRequest.deviceId;
    return await this.deviceStatusService.detailOfDate(request);
  }

  @PermissionCode(DETAIL_DEVICE_STATUS_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get('/:id/detail-status')
  @ApiOperation({
    tags: ['Device status'],
    summary: 'Lấy chi tiết lịch sử hoạt động thiết bị theo Id',
    description: 'Lấy chi tiết lịch sử hoạt động thiết bị theo Id',
  })
  @ApiResponse({
    status: 200,
    description: 'Get detail device status by id',
    type: GetDetailOfDeviceStatusResponseDto,
  })
  async detailOfDeviceStatus(
    @Param() param: IdParamDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.deviceStatusService.detailOfStatus(request);
  }

  @PermissionCode(DETAIL_DEVICE_STATUS_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get('/:deviceId')
  @ApiOperation({
    tags: ['Device status'],
    summary: 'Lấy chi tiết lịch sử hoạt động thiết bị',
    description: 'Lấy chi tiết lịch sử hoạt động thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Get detail device status',
    type: GetListDeviceStatusByDevice,
  })
  async detailOfDevice(
    @Param() param: GetDetailDeviceStatusParamDto,
    @Query() query: GetDetailDeviceStatusOfDeviceRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = query;
    const { request: parameter, responseError: responseErrorParam } = param;

    if (
      (responseError && !isEmpty(responseError)) ||
      (responseErrorParam && !isEmpty(responseErrorParam))
    ) {
      return responseError || responseErrorParam;
    }

    return await this.deviceStatusService.detailOfDevice(
      parameter.deviceId,
      request,
    );
  }

  @PermissionCode(LIST_DEVICE_STATUS_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get()
  @ApiOperation({
    tags: ['Device status'],
    summary: 'Lấy danh sách lịch sử hoạt động thiết bị',
    description: 'Lấy danh sách lịch sử hoạt động thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Get list device with status',
    type: GetListDeviceStatusResponseDto,
  })
  async listDeviceWithStatus(
    @Query() query: GetListDeviceWithStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.deviceStatusService.listDeviceWithStatus(request);
  }

  @PermissionCode(UPDATE_DEVICE_STATUS_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Put('/:id')
  @ApiOperation({
    tags: ['Device status'],
    summary: 'Cập nhật lịch sử hoạt động thiết bị cho app',
    description: 'Cập nhật lịch sử hoạt động thiết bị cho app',
  })
  @ApiResponse({
    status: 200,
    description: 'Changed device status',
    type: SuccessResponse,
  })
  async update(
    @Body() body: UpdateDeviceStatusBodyDto,
    @Param() param: IdParamDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    const {
      request: { id },
      responseError: responseParamError,
    } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }
    request.id = id;
    return await this.deviceStatusService.update(request);
  }
}
