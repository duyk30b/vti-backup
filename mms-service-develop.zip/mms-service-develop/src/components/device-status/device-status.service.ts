import { DeviceRepositoryInterface } from '@components/device/interface/device.repository.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { CreateDeviceStatusRequestDto } from './dto/request/create-device-status.request.dto';
import { DeviceStatusRepositoryInterface } from './interface/device-status.repository.interface';
import { DeviceStatusServiceInterface } from './interface/device-status.service.interface';
import { ResponsePayload } from '@utils/response-payload';
import { difference, isEmpty, keyBy, map, uniq } from 'lodash';
import * as moment from 'moment';
import { GetDetailDeviceStatusOfDateResponseDto } from './dto/response/get-detail-device-status-of-date.response.dto';
import { GetDetailDeviceStatusOfDeviceRequestDto } from './dto/request/get-detail-device-status-of-device.request.dto';
import { GetDetailDeviceStatusOfDeviceResponseDto } from './dto/response/get-detail-device-status-of-device.response.dto';
import { GetListDeviceWithStatusRequestDto } from './dto/request/get-list-device-with-status.request.dto';
import { GetListDeviceWithStatusResponseDto } from './dto/response/get-list-device-with-status.response.dto';
import { CreateManyDeviceStatusRequestDto } from './dto/request/create-many-device-status.request.dto';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { Types } from 'mongoose';
import { GetDetailOfDeviceStatusResponseDto } from './dto/response/get-detail-of-device-status.response.dto';
import { UpdateDeviceStatusRequestDto } from './dto/request/update-device-status.request.dto';
import { ACTIVE_ENUM } from '@constant/common';
import {
  DEVICE_STATUS_CAN_CREATE_STATE,
  DEVICE_STATUS_STATE_ENUM,
} from './device-status.constant';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { Device } from 'src/models/device/device.model';
import { DeviceStatusModel } from 'src/models/device-status/device-status.model';
import { DeviceTemplateScheduleRepositoryInterface } from '@components/device/interface/device-template-schedule.repository.interface';
import { GENERATE_JOB_BY_ENUM } from '@components/device-group/device-group.constant';
import { returnStockQuantity } from 'src/helper/code.helper';
import { TemplateDetail } from 'src/models/device-template-schedule/device-template-schedule.model';
import {
  JOB_CONST,
  JOB_EVENTS_ENUM,
  JOB_STATUS_ENUM,
  JOB_TYPE_ENUM,
} from '@components/job/job.constant';
import { HISTORY_ACTION_ENUM } from '@components/history/history.constant';
import { JobRepositoryInterface } from '@components/job/interface/job.repository.interface';
import { EventRequestDto } from '@components/notification/dto/event.request.dto';
import { EventEmitter2 } from '@nestjs/event-emitter';

@Injectable()
export class DeviceStatusService implements DeviceStatusServiceInterface {
  constructor(
    @Inject('DeviceStatusRepositoryInterface')
    private readonly deviceStatusRepository: DeviceStatusRepositoryInterface,

    @Inject('DeviceRepositoryInterface')
    private readonly deviceRepository: DeviceRepositoryInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    @Inject('DeviceTemplateScheduleRepositoryInterface')
    private readonly deviceTemplateScheduleRepository: DeviceTemplateScheduleRepositoryInterface,

    @Inject('JobRepositoryInterface')
    private readonly jobRepository: JobRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,

    private readonly eventEmitter: EventEmitter2,
  ) {}

  async create(
    request: CreateDeviceStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { startTime, endTime, deviceId, attributeTypes, status } = request;
    if (!moment(startTime, true).isBefore(moment(endTime, true))) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    const device = await this.deviceRepository.findOneWithPopulate(
      {
        ...request.permissionCondition,
        _id: deviceId,
        active: ACTIVE_ENUM.ACTIVE,
      },
      {
        path: 'deviceGroup',
      },
    );

    if (!device) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!DEVICE_STATUS_CAN_CREATE_STATE.includes(device.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.DEVICE_STATUS_INVALID'))
        .build();
    }

    const attributeTypeIds = map(attributeTypes, 'attributeTypeId');
    const isDiff = !isEmpty(
      difference(
        attributeTypeIds,
        device['deviceGroup']?.attributeTypeIds?.map((e) => e.toString()),
      ),
    );

    if (isDiff) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    const deviceStatusExisted =
      await this.deviceStatusRepository.findOneByCondition({
        deviceId,
        $or: [
          {
            $and: [
              {
                startTime: {
                  $gte: startTime,
                },
              },
              {
                startTime: {
                  $lte: endTime,
                },
              },
            ],
          },
          {
            startTime: {
              $lte: startTime,
            },
            endTime: {
              $gte: startTime,
            },
          },
        ],
      });

    if (deviceStatusExisted) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.DUPLICATE_TIME_INFO_ACTIVE'),
        )
        .build();
    }

    await this.updateActiveTimeForDevice(status, device, startTime, endTime);

    const deviceStatusEntity =
      this.deviceStatusRepository.createEntity(request);

    const dataSave = await deviceStatusEntity.save();

    const dataReturn = plainToInstance(BasicResponseDto, dataSave, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async createMany(
    request: CreateManyDeviceStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { deviceId, date, deviceStatuses } = request;
    const device = await this.deviceRepository.findOneWithPopulate(
      {
        ...request.permissionCondition,
        _id: deviceId,
        active: ACTIVE_ENUM.ACTIVE,
      },
      {
        path: 'deviceGroup',
      },
    );

    if (!device) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!DEVICE_STATUS_CAN_CREATE_STATE.includes(device.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.DEVICE_STATUS_INVALID'))
        .build();
    }

    const conditions = {
      $or: [],
    };
    for (let i = 0; i < deviceStatuses.length; i++) {
      const { startTime, endTime, attributeTypes } = deviceStatuses[i];
      if (
        !moment(startTime, true).isBefore(moment(endTime, true)) ||
        !moment(startTime, true).isSame(date, 'day') ||
        !moment(endTime, true).isSame(date, 'day')
      ) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
          .build();
      }

      const attributeTypeIds = map(attributeTypes, 'attributeTypeId');

      const isDiff = !isEmpty(
        difference(
          attributeTypeIds,
          device['deviceGroup']?.attributeTypeIds.map((e) => e.toString()),
        ),
      );

      if (isDiff) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
          .build();
      }

      for (let j = i + 1; j < deviceStatuses.length; j++) {
        if (
          moment(deviceStatuses[j].startTime).isBetween(startTime, endTime) ||
          moment(startTime).isBetween(
            deviceStatuses[j].startTime,
            deviceStatuses[j].endTime,
          ) ||
          moment(startTime).isSame(deviceStatuses[j].startTime) ||
          moment(startTime).isSame(deviceStatuses[j].endTime) ||
          moment(endTime).isSame(deviceStatuses[j].startTime) ||
          moment(endTime).isSame(deviceStatuses[j].endTime)
        ) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(
              await this.i18n.translate('error.DUPLICATE_TIME_INFO_ACTIVE'),
            )
            .build();
        }
      }

      conditions.$or = conditions.$or.concat([
        {
          startTime: {
            $lte: startTime,
          },
          endTime: {
            $gte: startTime,
          },
        },
        {
          startTime: {
            $gte: startTime,
          },
          endTime: {
            $lte: endTime,
          },
        },
        {
          startTime: {
            $lte: endTime,
          },
          endTime: {
            $gte: endTime,
          },
        },
        {
          startTime: {
            $lte: startTime,
          },
          endTime: {
            $gte: endTime,
          },
        },
      ]);
    }

    const deviceStatusExisted =
      await this.deviceStatusRepository.findOneByCondition({
        ...conditions,
        deviceId,
      });

    if (deviceStatusExisted) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.DUPLICATE_TIME_INFO_ACTIVE'),
        )
        .build();
    }

    const deviceStatusEntities = this.deviceStatusRepository.createEntities(
      deviceStatuses.map((deviceStatus) => ({
        ...deviceStatus,
        deviceId: deviceId,
        date: date,
        userId: request.user.id,
      })),
    );

    await this.deviceStatusRepository.create(deviceStatusEntities);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async detailOfDate(request: any): Promise<ResponsePayload<any>> {
    const { deviceId } = request;

    const device = await this.deviceRepository.findOneByCondition({
      ...request.permissionCondition,
      _id: deviceId,
      active: ACTIVE_ENUM.ACTIVE,
    });

    if (!device) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const { data, count } = await this.deviceStatusRepository.detailOfDate(
      request,
    );
    const deviceStatusReturn = plainToInstance(
      GetDetailDeviceStatusOfDateResponseDto,
      data,
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder({
      items: deviceStatusReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async detailOfDevice(
    deviceId: string,
    request: GetDetailDeviceStatusOfDeviceRequestDto,
  ): Promise<ResponsePayload<any>> {
    const device = await this.deviceRepository.findOneByCondition({
      ...request.permissionCondition,
      _id: deviceId,
      active: ACTIVE_ENUM.ACTIVE,
    });
    if (!device) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const { data, count } = await this.deviceStatusRepository.detailOfDevice(
      deviceId,
      request,
    );

    const deviceStatusReturn = plainToInstance(
      GetDetailDeviceStatusOfDeviceResponseDto,
      data,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder({
      items: deviceStatusReturn,
      meta: {
        total: count,
        page: request.page,
      },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async listDeviceWithStatus(
    request: GetListDeviceWithStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { result: devices, count } =
      await this.deviceRepository.listDeviceWithStatus(request);

    const dataReturn = plainToInstance(
      GetListDeviceWithStatusResponseDto,
      devices,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
  async detailOfStatus(request: IdParamDto): Promise<ResponsePayload<any>> {
    const { id } = request;
    const deviceStatus = await this.deviceStatusRepository.findOneWithPopulate(
      {
        _id: new Types.ObjectId(id),
      },
      {
        path: 'attributeTypes.attributeType',
      },
    );
    if (!deviceStatus) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const unitIds = map(
      deviceStatus.attributeTypes,
      (e) => e['attributeType']?.unitId,
    );
    const units = await this.itemService.getListUnit([
      {
        column: 'ids',
        text: uniq(unitIds).toString(),
      },
    ]);
    const unitMap = keyBy(units, 'id');
    deviceStatus.attributeTypes.forEach(
      (e) => (e['attributeType'].unit = unitMap[e['attributeType']?.unitId]),
    );

    const device = await this.deviceRepository.findOneByCondition({
      _id: deviceStatus.deviceId,
      active: ACTIVE_ENUM.ACTIVE,
    });

    if (!device) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const deviceStatusReturn = plainToInstance(
      GetDetailOfDeviceStatusResponseDto,
      deviceStatus,
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder(deviceStatusReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async update(
    request: UpdateDeviceStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { startTime, endTime, deviceId, attributeTypes, id, status } =
      request;

    const device = await this.deviceRepository.findOneWithPopulate(
      {
        ...request.permissionCondition,
        _id: deviceId,
        active: ACTIVE_ENUM.ACTIVE,
      },
      {
        path: 'deviceGroup',
      },
    );

    if (!device) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const deviceStatus = await this.deviceStatusRepository.findOneById(id);
    if (!deviceStatus) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!moment(startTime, true).isBefore(moment(endTime, true))) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    const attributeTypeIds = map(attributeTypes, 'attributeTypeId');
    const isDiff = !isEmpty(
      difference(
        attributeTypeIds,
        device['deviceGroup']?.attributeTypeIds?.map((e) => e.toString()),
      ),
    );

    if (isDiff) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    const deviceStatusExisted =
      await this.deviceStatusRepository.findOneByCondition({
        _id: { $ne: id },
        deviceId,
        $or: [
          {
            $and: [
              {
                startTime: {
                  $gte: startTime,
                },
              },
              {
                startTime: {
                  $lte: endTime,
                },
              },
            ],
          },
          {
            startTime: {
              $lte: startTime,
            },
            endTime: {
              $gte: startTime,
            },
          },
        ],
      });

    if (deviceStatusExisted) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.DUPLICATE_TIME_INFO_ACTIVE'),
        )
        .build();
    }
    await this.updateActiveTimeForDevice(
      status,
      device,
      startTime,
      endTime,
      deviceStatus,
    );
    const deviceStatusEntity = this.deviceStatusRepository.updateEntity(
      deviceStatus,
      request,
    );
    await this.deviceStatusRepository.findByIdAndUpdate(id, deviceStatusEntity);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async updateActiveTimeForDevice(
    status: DEVICE_STATUS_STATE_ENUM,
    device: Device,
    startTime: string | Date,
    endTime: string | Date,
    deviceStatus?: DeviceStatusModel,
  ) {
    let startTimeOld: string | Date;
    let endTimeOld: string | Date;
    if (
      device.generateJobBy !== GENERATE_JOB_BY_ENUM.ACTIVE_TIME ||
      !(
        status === DEVICE_STATUS_STATE_ENUM.ACTIVE ||
        deviceStatus?.status === DEVICE_STATUS_STATE_ENUM.ACTIVE
      )
    ) {
      return;
    }
    const lastDeviceStatus = await this.deviceStatusRepository.lastRecord(
      { endTime: -1 },
      { deviceId: device._id },
    );
    const lastActiveTime = moment(endTime).isAfter(
      moment(lastDeviceStatus.endTime),
    )
      ? endTime
      : lastDeviceStatus.endTime;
    const deviceTemplateSchedule =
      await this.deviceTemplateScheduleRepository.findOneByCondition({
        deviceId: device._id,
      });

    let activeTimeCoefficient = 1;

    if (
      deviceStatus?.status === DEVICE_STATUS_STATE_ENUM.ACTIVE &&
      status === DEVICE_STATUS_STATE_ENUM.ACTIVE
    ) {
      // nếu update time cùng active
      startTimeOld = deviceStatus.startTime;
      endTimeOld = deviceStatus.endTime;
    } else if (deviceStatus?.status === DEVICE_STATUS_STATE_ENUM.ACTIVE) {
      // nếu chuyển cái cũ active về out active
      startTime = deviceStatus.startTime;
      endTime = deviceStatus.endTime;
      activeTimeCoefficient = -1;
    }
    const dataInserts = [];
    // maintenance
    const maintenanceSchedules = deviceTemplateSchedule.maintain;
    const maintainJobName = await this.i18n.translate('text.maintainJobName');
    const messageCreatedJob = await this.i18n.translate(
      'text.SYSTEM_CREATE_MAINTAIN_JOB',
    );

    await this.addJobs(
      maintenanceSchedules,
      device,
      lastActiveTime,
      startTime,
      endTime,
      startTimeOld,
      endTimeOld,
      dataInserts,
      activeTimeCoefficient,
      maintainJobName,
      messageCreatedJob,
    );
    // @TODO create job checklist and accreditation
    if (!isEmpty(dataInserts)) {
      const jobDocuments = await this.jobRepository.createEntities(dataInserts);
      const jobs = await this.jobRepository.createMany(jobDocuments);
      jobs.forEach((job) => {
        this.eventEmitter.emit(
          JOB_EVENTS_ENUM.CREATE,
          new EventRequestDto({
            id: job._id,
            name: job.name,
            code: job.code,
            entityType: job.type,
            fromUserId: null,
          }),
        );
      });
    }

    await this.deviceTemplateScheduleRepository.findAllAndUpdate(
      { deviceId: device._id },
      { maintain: maintenanceSchedules },
    );
  }

  private async addJobs(
    schedules: TemplateDetail[],
    device: Device,
    lastActiveTime: string | Date,
    startTime: string | Date,
    endTime: string | Date,
    startTimeOld: string | Date,
    endTimeOld: string | Date,
    dataInserts: any[],
    activeTimeCoefficient: number,
    jobName: string,
    messageCreatedJob: string,
  ) {
    schedules.forEach((e) => {
      let diffTimeOld = 0;
      let diffTime = 0;
      if (moment(e.lastSchedule).isSameOrBefore(moment(endTime))) {
        // nếu bảo trì cuối cùng nhỏ hơn endTime thì tính
        diffTime =
          ((moment(e.lastSchedule).isSameOrBefore(moment(startTime))
            ? moment(endTime).diff(moment(startTime), 'minutes')
            : moment(endTime).diff(moment(e.lastSchedule), 'minutes')) *
            activeTimeCoefficient) /
          60;
      }
      if (
        startTimeOld &&
        endTimeOld &&
        moment(e.lastSchedule).isSameOrBefore(moment(endTimeOld))
      ) {
        // nếu bảo trì cuối cùng nhỏ hơn endTimeOld thì tính
        diffTimeOld =
          (moment(e.lastSchedule).isSameOrBefore(moment(startTimeOld))
            ? moment(endTimeOld).diff(moment(startTimeOld), 'minutes')
            : moment(endTimeOld).diff(moment(e.lastSchedule), 'minutes')) / 60;
      }

      const actualActiveTime = returnStockQuantity(
        (e.actualActiveTime || 0) + diffTime - diffTimeOld,
      );
      if (actualActiveTime >= (e.activeTime * device.normGenerateJob) / 100) {
        dataInserts.push({
          name: jobName
            .replace('{deviceName}', device?.name ?? '')
            .substring(0, JOB_CONST.NAME.MAX_LENGTH),
          description: e.title,
          status: JOB_STATUS_ENUM.NON_ASSIGN,
          planFrom: lastActiveTime,
          planTo: lastActiveTime,
          jobTypeId: e.templateId,
          obligatory: e.obligatory,
          type: JOB_TYPE_ENUM.MAINTAIN,
          histories: [
            {
              createdAt: new Date(),
              action: HISTORY_ACTION_ENUM.CREATE,
              content: messageCreatedJob,
              status: JOB_STATUS_ENUM.NON_ASSIGN,
            },
          ],
          deviceId: device._id,
        });
        //  update lại schedule
        e.actualActiveTime = 0;
        e.lastSchedule = moment(lastActiveTime).toDate();
        e.nextSchedule = moment(lastActiveTime)
          .add(e.periodic, 'days')
          .toDate();
      } else {
        e.actualActiveTime = actualActiveTime;
      }
    });
  }
}
