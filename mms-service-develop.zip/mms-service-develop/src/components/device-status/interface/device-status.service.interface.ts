import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreateDeviceStatusRequestDto } from '../dto/request/create-device-status.request.dto';
import { CreateManyDeviceStatusRequestDto } from '../dto/request/create-many-device-status.request.dto';
import { GetDetailDeviceStatusOfDateRequestDto } from '../dto/request/get-detail-device-status-of-date.request';
import { GetDetailDeviceStatusOfDeviceRequestDto } from '../dto/request/get-detail-device-status-of-device.request.dto';
import { GetListDeviceWithStatusRequestDto } from '../dto/request/get-list-device-with-status.request.dto';
import { UpdateDeviceStatusRequestDto } from '../dto/request/update-device-status.request.dto';

export interface DeviceStatusServiceInterface {
  create(payload: CreateDeviceStatusRequestDto): Promise<ResponsePayload<any>>;
  createMany(
    request: CreateManyDeviceStatusRequestDto,
  ): Promise<ResponsePayload<any>>;
  detailOfDate(
    payload: GetDetailDeviceStatusOfDateRequestDto,
  ): Promise<ResponsePayload<any>>;
  detailOfStatus(payload: IdParamDto): Promise<ResponsePayload<any>>;
  detailOfDevice(
    deviceId: string,
    request: GetDetailDeviceStatusOfDeviceRequestDto,
  ): Promise<ResponsePayload<any>>;
  listDeviceWithStatus(
    request: GetListDeviceWithStatusRequestDto,
  ): Promise<ResponsePayload<any>>;
  update(request: UpdateDeviceStatusRequestDto): Promise<ResponsePayload<any>>;
}
