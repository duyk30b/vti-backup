import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { DeviceStatusModel } from '../../../models/device-status/device-status.model';
import { GetDetailDeviceStatusOfDateRequestDto } from '../dto/request/get-detail-device-status-of-date.request';
import { GetDetailDeviceStatusOfDeviceRequestDto } from '../dto/request/get-detail-device-status-of-device.request.dto';

export interface DeviceStatusRepositoryInterface
  extends BaseInterfaceRepository<DeviceStatusModel> {
  createEntity(data: any): DeviceStatusModel;
  updateEntity(deviceStatus: DeviceStatusModel, data: any): DeviceStatusModel;
  createEntities(request: any): DeviceStatusModel;
  detailOfDate(request: GetDetailDeviceStatusOfDateRequestDto): Promise<any>;
  findLatest(deviceId: string): Promise<any>;
  detailOfDevice(
    deviceId: string,
    request: GetDetailDeviceStatusOfDeviceRequestDto,
  ): Promise<any>;
}
