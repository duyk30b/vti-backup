import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { DeviceStatusService } from './device-status.service';
import { DeviceStatusRepository } from '../../repository/device-status/device-status.repository';
import { DeviceStatusSchema } from '../../models/device-status/device-status.schema';
import { DeviceStatusController } from './device-status.controller';
import { DeviceRepository } from 'src/repository/device/device.repository';
import { ItemModule } from '@components/item/item.module';
import { DeviceTemplateScheduleSchema } from 'src/models/device-template-schedule/device-template-schedule.schema';
import { DeviceTemplateScheduleRepository } from 'src/repository/device-template-schedule/device-template-schedule.repository';
import { JobSchema } from 'src/models/job/job.schema';
import { JobRepository } from 'src/repository/job/job.repository';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'DeviceStatus', schema: DeviceStatusSchema },
      {
        name: 'DeviceTemplateSchedule',
        schema: DeviceTemplateScheduleSchema,
      },
      { name: 'Job', schema: JobSchema },
    ]),
    ItemModule,
  ],
  controllers: [DeviceStatusController],
  providers: [
    {
      provide: 'DeviceStatusRepositoryInterface',
      useClass: DeviceStatusRepository,
    },
    {
      provide: 'DeviceRepositoryInterface',
      useClass: DeviceRepository,
    },
    {
      provide: 'DeviceStatusServiceInterface',
      useClass: DeviceStatusService,
    },
    {
      provide: 'DeviceTemplateScheduleRepositoryInterface',
      useClass: DeviceTemplateScheduleRepository,
    },
    {
      provide: 'JobRepositoryInterface',
      useClass: JobRepository,
    },
  ],
  exports: [
    MongooseModule,
    {
      provide: 'DeviceStatusServiceInterface',
      useClass: DeviceStatusService,
    },
    {
      provide: 'DeviceRepositoryInterface',
      useClass: DeviceRepository,
    },
  ],
})
export class DeviceStatusModule {}
