import { DEVICE_STATUS_ENUM } from '@components/device/device.constant';

export enum DEVICE_STATUS_STATE_ENUM {
  ACTIVE, // Đang hoạt động
  STOP, // Dừng
  ERROR, // Lỗi
  OFF, // Tắt
}

export const DEVICE_STATUS_CONST = {
  ACTIVE_TIME: {
    MIN: 1,
    MAX: 1000000000,
  },
};

export const ACTION_NAME = 'deviceStatus.createNewActivity';

export const DEVICE_STATUS_CAN_CREATE_STATE = [DEVICE_STATUS_ENUM.USING];
