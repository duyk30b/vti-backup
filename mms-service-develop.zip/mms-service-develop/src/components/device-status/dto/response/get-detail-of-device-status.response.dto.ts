import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { Expose, plainToInstance, Transform, Type } from 'class-transformer';

class ListAttributeType extends BaseResponseDto {
  @ApiProperty()
  @Transform(({ obj }) => obj?.attributeType?._id?.toString())
  @Expose()
  attributeTypeId: string;

  @ApiProperty()
  @Transform(({ obj }) => obj?.attributeType?.name)
  @Expose()
  attributeTypeName: string;

  @ApiProperty()
  @Transform(({ obj }) => obj?.attributeType?.code)
  @Expose()
  attributeTypeCode: string;

  @ApiProperty()
  @Expose()
  value: number;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Expose()
  @Type(() => BasicSqlDocumentResponse)
  @Transform(({ obj }) =>
    plainToInstance(BasicSqlDocumentResponse, obj?.attributeType?.unit, {
      excludeExtraneousValues: true,
    }),
  )
  unit: BasicSqlDocumentResponse;
}

export class GetDetailOfDeviceStatusResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  startTime: Date;

  @ApiProperty()
  @Expose()
  endTime: Date;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty({ isArray: true, type: ListAttributeType })
  @Expose()
  @Type(() => ListAttributeType)
  attributeTypes: ListAttributeType[];
}
