import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';

export class GetDetailDeviceStatusOfDateResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  startTime: Date;

  @ApiProperty()
  @Expose()
  endTime: Date;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  activeTime: number;
}

export class ListDeviceStatusByDateResponseDto extends PaginationResponse {
  @ApiProperty({ type: GetDetailDeviceStatusOfDateResponseDto, isArray: true })
  @Expose()
  @Type(() => GetDetailDeviceStatusOfDateResponseDto)
  items: GetDetailDeviceStatusOfDateResponseDto[];
}
