import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';

export class GetDetailDeviceStatusOfDeviceResponseDto {
  @ApiProperty()
  @Expose({ name: '_id' })
  date: Date;

  @ApiProperty()
  @Expose()
  actionTime: number;

  @ApiProperty()
  @Expose()
  breakTime: number;
}

export class GetListDeviceStatusByDevice extends PaginationResponse {
  @ApiProperty({
    type: GetDetailDeviceStatusOfDeviceResponseDto,
    isArray: true,
  })
  @Expose()
  @Type(() => GetDetailDeviceStatusOfDeviceResponseDto)
  items: GetDetailDeviceStatusOfDeviceResponseDto[];
}
