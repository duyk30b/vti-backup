import { DEVICE_STATUS_STATE_ENUM } from '@components/device-status/device-status.constant';
import { DeviceBasicResponseDto } from '@components/device/dto/response/device-basic.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Transform, Type } from 'class-transformer';
import { first, isEmpty } from 'lodash';

export class GetListDeviceWithStatusResponseDto extends DeviceBasicResponseDto {
  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Expose()
  deviceGroup: BasicResponseDto;

  @ApiProperty()
  @Transform(({ obj }) =>
    isEmpty(obj['deviceStatus'])
      ? DEVICE_STATUS_STATE_ENUM.ACTIVE
      : first(obj['deviceStatus'])['status'],
  )
  @Expose()
  deviceStatus: number;
}

export class GetListDeviceStatusResponseDto extends PaginationResponse {
  @ApiProperty({ type: GetListDeviceWithStatusResponseDto, isArray: true })
  @Expose()
  @Type(() => GetListDeviceWithStatusResponseDto)
  items: GetListDeviceWithStatusResponseDto[];
}
