import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform } from 'class-transformer';

export class DeviceResponseDto {
  @ApiProperty()
  @Transform(({ obj }) => obj._id.toString())
  @Expose()
  deviceId: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  serial: string;

  @ApiProperty()
  @Expose({ name: 'name' })
  deviceName: string;

  @ApiProperty()
  @Expose()
  date: Date;

  @ApiProperty()
  @Expose()
  identificationNo: string;
}
