import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateDeviceStatusRequestDto } from './create-device-status.request.dto';

export class UpdateDeviceStatusBodyDto extends CreateDeviceStatusRequestDto {}

export class UpdateDeviceStatusRequestDto extends UpdateDeviceStatusBodyDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  id: string;
}
