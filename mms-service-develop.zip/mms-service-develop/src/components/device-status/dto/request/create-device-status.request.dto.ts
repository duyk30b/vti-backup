import { DEVICE_STATUS_STATE_ENUM } from '@components/device-status/device-status.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsDateString,
  IsEnum,
  IsMongoId,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  Min,
  ValidateNested,
} from 'class-validator';

class AttributeType {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  attributeTypeId: string;

  @ApiProperty()
  @IsNumber()
  @Min(1)
  @IsOptional()
  value: number;
}
export class CreateDeviceStatusRequestDto extends BaseDto {
  @ApiProperty({ example: 0, description: 'device status' })
  @IsEnum(DEVICE_STATUS_STATE_ENUM)
  @IsNotEmpty()
  status: number;

  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  deviceId: string;

  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  startTime: string;

  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  endTime: string;

  @ApiProperty({ type: AttributeType, isArray: true })
  @ValidateNested({ each: true })
  @Type(() => AttributeType)
  @ArrayUnique((data) => data.attributeTypeId)
  @ArrayNotEmpty()
  attributeTypes: AttributeType[];
}
