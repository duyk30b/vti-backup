import { DEVICE_STATUS_STATE_ENUM } from '@components/device-status/device-status.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  IsArray,
  IsDateString,
  IsEnum,
  IsMongoId,
  IsNotEmpty,
  IsNumber,
} from 'class-validator';
import * as moment from 'moment';

class AttributeType {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  atrributeTypeId: string;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  value: number;
}

class CreateDeviceStatusDto {
  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  startTime: Date;

  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  endTime: Date;

  @ApiProperty()
  @IsEnum(DEVICE_STATUS_STATE_ENUM)
  @IsNotEmpty()
  status: number;

  @ApiProperty({ type: AttributeType, isArray: true })
  @Type(() => AttributeType)
  @IsArray()
  @IsNotEmpty()
  attributeTypes: AttributeType[];
}

export class CreateManyDeviceStatusRequestDto extends BaseDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  deviceId: string;

  @ApiProperty()
  @IsDateString()
  @Transform((v) => moment(v.value).startOf('day').toISOString())
  @IsNotEmpty()
  date: Date;

  @ApiProperty({ type: CreateDeviceStatusDto, isArray: true })
  @Type(() => CreateDeviceStatusDto)
  @IsArray()
  @IsNotEmpty()
  deviceStatuses: CreateDeviceStatusDto[];
}
