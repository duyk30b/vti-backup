import { PaginationQuery } from '@utils/dto/request/pagination.query';

export class GetListDeviceWithStatusRequestDto extends PaginationQuery {}
