import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { IsMongoId, IsNotEmpty } from 'class-validator';

export class GetDetailDeviceStatusOfDateRequestDto extends PaginationQuery {}

export class GetDetailDeviceStatusParamDto extends BaseDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  deviceId: string;
}
