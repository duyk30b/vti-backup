import { PaginationQuery } from '@utils/dto/request/pagination.query';

export class GetDetailDeviceStatusOfDeviceRequestDto extends PaginationQuery {}
