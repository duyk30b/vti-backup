import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ACTIVE_ENUM } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { plus } from '@utils/helper';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { compact, has, keyBy, map, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import {
  generateCodeByPreviousCode,
  getCurrentCodeByLastRecord,
} from 'src/helper/code.helper';
import { AREA_CONST } from './area.constant';
import { CreateAreaRequest } from './dto/request/create-area.request';
import { DetailAreaRequest } from './dto/request/detail-area.request';
import { GetListAreaQuery } from './dto/request/get-list-area.query';
import { InactiveAreasRequest } from './dto/request/inactive-areas.request';
import { UpdateAreaRequest } from './dto/request/update-area.request';
import { DetailAreaResponse } from './dto/response/detail-area.response';
import { AreaRepositoryInterface } from './interface/area.repository.interface';
import { AreaServiceInterface } from './interface/area.service.interface';

@Injectable()
export class AreaService implements AreaServiceInterface {
  constructor(
    @Inject('AreaRepositoryInterface')
    private readonly areaRepository: AreaRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateAreaRequest): Promise<ResponsePayload<any>> {
    try {
      const factory = await this.userService.getFactoryById(request.factoryId);
      if (!factory) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.FACTORY_NOT_FOUND'),
        ).toResponse();
      }

      request.code = await this.areaRepository.generateNextCode(
        AREA_CONST.CODE.PREFIX,
      );
      const areaEntity = this.areaRepository.createEntity(request);
      const dataSave = await areaEntity.save();
      const dataReturn = plainToInstance(BasicResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.error(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CREATE'))
        .build();
    }
  }

  async update(request: UpdateAreaRequest): Promise<ResponsePayload<any>> {
    try {
      let areaEntity = await this.areaRepository.findOneById(request.id);

      if (!areaEntity) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      const factory = await this.userService.getFactoryById(request.factoryId);
      if (!factory) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.FACTORY_NOT_FOUND'),
        ).toResponse();
      }

      areaEntity = await this.areaRepository.updateEntity(areaEntity, request);

      await this.areaRepository.findByIdAndUpdate(request.id, areaEntity);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.error(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }
  }

  async import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const dataToInsert = [];
    const dataToUpdate = [];
    const codesUpdate = [];
    const factoryCodes = [];
    const textAdd = await this.i18n.translate('import.common.add');
    const codePrefix = AREA_CONST.CODE.PREFIX;
    const lastRecord = await this.areaRepository.lastRecord();
    const codeCurrent = getCurrentCodeByLastRecord(codePrefix, lastRecord);

    data.forEach((item, index) => {
      if (item.action === textAdd) {
        item.code = generateCodeByPreviousCode(
          codePrefix,
          plus(codeCurrent, index),
        );
        dataToInsert.push(item);
      } else {
        dataToUpdate.push(item);
        codesUpdate.push(item.code);
      }
      factoryCodes.push(item.factoryCode);
    });

    const areaCodeUpdateExists = await this.areaRepository.findAllByCondition({
      code: { $in: codesUpdate },
    });
    const areaUpdateMap = keyBy(areaCodeUpdateExists, 'code');

    const filter = [];
    filter.push({
      column: 'codes',
      text: factoryCodes,
    });
    const factories = await this.userService.getFactoryList(filter);
    const factoryMap = keyBy(factories, 'code');

    const dataError = [];
    const dataInsert = [];
    const dataUpdate = [];
    dataToInsert.forEach((item) => {
      if (!has(factoryMap, item.factoryCode)) {
        dataError.push(item);
      } else {
        dataInsert.push(item);
      }
    });
    dataToUpdate.forEach((item) => {
      if (!has(areaUpdateMap, item.code)) {
        dataError.push(item);
      } else if (!has(factoryMap, item.factoryCode)) {
        dataError.push(item);
      } else {
        dataUpdate.push(item);
      }
    });

    const areaDocument = [...dataInsert, ...dataUpdate];
    const bulkOps = areaDocument.map((doc) => ({
      updateOne: {
        filter: { code: doc.code },
        update: {
          code: doc.code,
          name: doc.name,
          description: doc.description,
          factoryId: factoryMap[doc.factoryCode].id,
        },
        upsert: true,
      },
    }));

    const dataSuccess = await this.areaRepository.bulkWrite(bulkOps);

    return { dataError, dataSuccess };
  }

  async detail(
    request: DetailAreaRequest,
  ): Promise<ResponsePayload<DetailAreaResponse | any>> {
    const { id } = request;
    const area = await this.areaRepository.findOneById(id);
    if (!area) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.AREA_NOT_FOUND'))
        .build();
    }
    const factory = await this.userService.getFactoryById(area.factoryId);
    if (!factory) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.FACTORY_NOT_FOUND'))
        .build();
    }
    const response = plainToInstance(
      DetailAreaResponse,
      {
        ...area,
        factory,
      },
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async list(request: GetListAreaQuery): Promise<ResponsePayload<any>> {
    const { data, count } = await this.areaRepository.list(request);

    const factoryIds = compact(uniq(map(data, 'factoryId')));
    const factories = await this.userService.getFactoryList([
      {
        column: 'factoryIds',
        text: factoryIds,
      },
    ]);
    const factoriesMap = keyBy(factories, 'id');

    data.forEach((element) => {
      element.factory = factoriesMap[element.factoryId];
    });

    const dataReturn = plainToInstance(DetailAreaResponse, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateActiveStatus(request: UpdateActiveStatusPayload): Promise<any> {
    const { id, status } = request;
    const area = await this.areaRepository.findOneById(id);
    if (!area) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }

    if (status === ACTIVE_ENUM.ACTIVE) {
      const factory = await this.userService.getFactoryById(area.factoryId);
      if (factory?.active === ACTIVE_ENUM.INACTIVE) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.FACTORY_INACTIVE'))
          .build();
      }
    }

    await this.areaRepository.findByIdAndUpdate(id, {
      $set: { active: status },
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async inactiveByFactoryId(
    request: InactiveAreasRequest,
  ): Promise<ResponsePayload<any>> {
    await this.areaRepository.findAllAndUpdate(
      { factoryId: request.factoryId },
      {
        $set: { active: ACTIVE_ENUM.INACTIVE },
      },
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
