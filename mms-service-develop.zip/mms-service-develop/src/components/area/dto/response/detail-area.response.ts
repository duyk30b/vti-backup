import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { Expose, Type } from 'class-transformer';

export class DetailAreaResponse extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  factory: BasicSqlDocumentResponse;

  @ApiProperty()
  @Expose()
  active: number;
}
