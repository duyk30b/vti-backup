import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';
import { DetailAreaResponse } from './detail-area.response';

export class ListAreaResponse extends PaginationResponse {
  @ApiProperty({ type: DetailAreaResponse, isArray: true })
  @Expose()
  @Type(() => DetailAreaResponse)
  items: DetailAreaResponse[];
}
