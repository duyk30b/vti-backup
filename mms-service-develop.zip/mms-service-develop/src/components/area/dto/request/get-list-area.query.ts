import { ApiPropertyOptional } from '@nestjs/swagger';
import { IS_MASTER_DATA } from '@utils/constant';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { Transform } from 'class-transformer';
import { IsEnum, IsNumber, IsOptional, IsString } from 'class-validator';

export class GetListAreaQuery extends PaginationQuery {
  @ApiPropertyOptional({
    example: '[{"id": "1"},{ "id": "2"}]',
  })
  @IsOptional()
  @IsString()
  queryIds?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  @IsEnum(IS_MASTER_DATA)
  @Transform(({ value }) => +value)
  isMasterData?: number;
}
