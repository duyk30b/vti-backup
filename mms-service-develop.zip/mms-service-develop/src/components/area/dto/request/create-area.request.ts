import { AREA_CONST } from '@components/area/area.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';
import { IsNotBlank } from 'src/validator/is-not-blank.validator';

export class CreateAreaRequest extends BaseDto {
  code: string;

  @ApiProperty({ description: 'Tên của khu vực' })
  @MaxLength(AREA_CONST.NAME.MAX_LENGTH)
  @IsNotBlank()
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({ description: 'Mô tả của khu vực' })
  @IsString()
  @MaxLength(AREA_CONST.DESCRIPTION.MAX_LENGTH)
  @IsOptional()
  description: string;

  @ApiProperty({ description: 'Id của nhà máy' })
  @IsInt()
  @IsNotEmpty()
  factoryId: number;
}
