import { CreateAreaRequest } from './create-area.request';

import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';

export class UpdateAreaBodyDto extends CreateAreaRequest {}

export class UpdateAreaRequest extends UpdateAreaBodyDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  id: string;
}
