import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class InactiveAreasRequest extends BaseDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  factoryId: number;
}
