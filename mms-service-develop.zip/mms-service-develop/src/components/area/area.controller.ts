import { ACTIVE_ENUM } from '@constant/common';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { PermissionInterceptor } from '@core/interceptors/permission.interceptor';
import {
  Body,
  Controller,
  Get,
  Inject,
  Injectable,
  Param,
  Post,
  Put,
  Query,
  UseInterceptors,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import {
  CREATE_AREA_PERMISSION,
  DETAIL_AREA_PERMISSION,
  LIST_AREA_PERMISSION,
  UPDATE_AREA_PERMISSION,
  UPDATE_STATUS_AREA_PERMISSION,
} from '@utils/permissions/area';
import {
  CREATE_DEVICE_PERMISSION,
  UPDATE_DEVICE_PERMISSION,
} from '@utils/permissions/device';
import {
  CREATE_DEVICE_ASSIGNMENT_PERMISSION,
  UPDATE_DEVICE_ASSIGNMENT_PERMISSION,
} from '@utils/permissions/device-assignment';
import {
  CREATE_MAINTENANCE_PLAN_PERMISSION,
  UPDATE_MAINTENANCE_PLAN_PERMISSION,
} from '@utils/permissions/maintenance-plan';
import {
  CREATE_MAINTENANCE_TEAM_PERMISSION,
  UPDATE_MAINTENANCE_TEAM_PERMISSION,
} from '@utils/permissions/maintenance-team';
import { CREATE_REPAIR_REQUEST_PERMISSION } from '@utils/permissions/repair-request';
import {
  CREATE_UPDATE_INVENTORY_PERMISSION,
  UPDATE_UPDATE_INVENTORY_PERMISSION,
} from '@utils/permissions/update-inventory-ticket';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateAreaRequest } from './dto/request/create-area.request';
import { DetailAreaRequest } from './dto/request/detail-area.request';
import { GetListAreaQuery } from './dto/request/get-list-area.query';
import { InactiveAreasRequest } from './dto/request/inactive-areas.request';
import { UpdateAreaBodyDto } from './dto/request/update-area.request';
import { DetailAreaResponse } from './dto/response/detail-area.response';
import { ListAreaResponse } from './dto/response/list-area.response';
import { AreaServiceInterface } from './interface/area.service.interface';

@Injectable()
@Controller('areas')
export class AreaController {
  constructor(
    @Inject('AreaServiceInterface')
    private readonly areaService: AreaServiceInterface,
  ) {}

  @PermissionCode(CREATE_AREA_PERMISSION.code)
  @Post('')
  @ApiOperation({
    tags: ['Area'],
    summary: 'Định nghĩa vùng',
    description: 'Định nghĩa vùng',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async create(@Body() payload: CreateAreaRequest): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.areaService.create(request);
  }

  @PermissionCode(DETAIL_AREA_PERMISSION.code, UPDATE_AREA_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Area'],
    summary: 'Detail Area',
    description: 'Detail Area',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailAreaResponse,
  })
  async detail(@Param() param: DetailAreaRequest): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.areaService.detail(request);
  }

  @PermissionCode(UPDATE_AREA_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Area'],
    summary: 'Update Area',
    description: 'Update an existing area',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  async update(
    @Param() param: IdParamDto,
    @Body() payload: UpdateAreaBodyDto,
  ): Promise<any> {
    const { request: requestParam, responseError: responseParamError } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.areaService.update({
      id: requestParam.id,
      ...request,
    });
  }

  @PermissionCode(
    LIST_AREA_PERMISSION.code,
    CREATE_DEVICE_PERMISSION.code,
    UPDATE_DEVICE_PERMISSION.code,
    UPDATE_DEVICE_ASSIGNMENT_PERMISSION.code,
    CREATE_DEVICE_ASSIGNMENT_PERMISSION.code,
    CREATE_MAINTENANCE_PLAN_PERMISSION.code,
    UPDATE_MAINTENANCE_PLAN_PERMISSION.code,
    CREATE_REPAIR_REQUEST_PERMISSION.code,
    CREATE_UPDATE_INVENTORY_PERMISSION.code,
    UPDATE_UPDATE_INVENTORY_PERMISSION.code,
    CREATE_MAINTENANCE_TEAM_PERMISSION.code,
    UPDATE_MAINTENANCE_TEAM_PERMISSION.code,
  )
  @UseInterceptors(PermissionInterceptor)
  @Get('/')
  @ApiOperation({
    tags: ['Area'],
    summary: 'List Area',
    description: 'List Area',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListAreaResponse,
  })
  async list(@Query() query: GetListAreaQuery): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.areaService.list(request);
  }

  @PermissionCode(UPDATE_STATUS_AREA_PERMISSION.code)
  @Put('/:id/active')
  @ApiOperation({
    tags: ['Area'],
    summary: 'List Area',
    description: 'List Area',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async active(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.areaService.updateActiveStatus({
      ...request,
      status: ACTIVE_ENUM.ACTIVE,
    });
  }

  @PermissionCode(UPDATE_STATUS_AREA_PERMISSION.code)
  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Area'],
    summary: 'List Area',
    description: 'List Area',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async inactive(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.areaService.updateActiveStatus({
      ...request,
      status: ACTIVE_ENUM.INACTIVE,
    });
  }

  @PermissionCode(UPDATE_STATUS_AREA_PERMISSION.code)
  @Put('/inactive-many-status')
  @ApiOperation({
    tags: ['Area'],
    summary: 'Inactive many Area',
    description: 'Inactive many Area',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async inactiveManyStatus(@Body() body: InactiveAreasRequest): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.areaService.inactiveByFactoryId(request);
  }
}
