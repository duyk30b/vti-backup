import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Area } from 'src/models/area/area.model';
import { CreateAreaRequest } from '../dto/request/create-area.request';
import { GetListAreaQuery } from '../dto/request/get-list-area.query';
import { UpdateAreaRequest } from '../dto/request/update-area.request';

export interface AreaRepositoryInterface extends BaseAbstractRepository<Area> {
  createEntity(request: CreateAreaRequest): Area;
  updateEntity(entity: Area, request: UpdateAreaRequest): Area;
  list(request: GetListAreaQuery): Promise<any>;
}
