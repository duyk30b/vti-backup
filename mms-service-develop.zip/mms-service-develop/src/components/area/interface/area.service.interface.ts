import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreateAreaRequest } from '../dto/request/create-area.request';
import { DetailAreaRequest } from '../dto/request/detail-area.request';
import { GetListAreaQuery } from '../dto/request/get-list-area.query';
import { InactiveAreasRequest } from '../dto/request/inactive-areas.request';
import { UpdateAreaRequest } from '../dto/request/update-area.request';

export interface AreaServiceInterface {
  create(request: CreateAreaRequest): Promise<ResponsePayload<any>>;
  update(request: UpdateAreaRequest): Promise<ResponsePayload<any>>;
  detail(request: DetailAreaRequest): Promise<ResponsePayload<any>>;
  list(request: GetListAreaQuery): Promise<ResponsePayload<any>>;
  updateActiveStatus(
    request: UpdateActiveStatusPayload,
  ): Promise<ResponsePayload<any>>;
  inactiveByFactoryId(
    request: InactiveAreasRequest,
  ): Promise<ResponsePayload<any>>;
  import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }>;
}
