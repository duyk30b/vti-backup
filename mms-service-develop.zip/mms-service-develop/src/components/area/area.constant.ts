import { CODE_REGEX } from '@constant/common';

export const AREA_CONST = {
  DESCRIPTION: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
  CODE: {
    MAX_LENGTH: 20,
    MIN_LENGTH: 6,
    COLUMN: 'code',
    REGEX: CODE_REGEX,
    PREFIX: 'KVUC',
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
};
