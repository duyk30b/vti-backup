import { CreateMaintenanceAttributeRequestDto } from '@components/maintenance-attribute/dto/request/create-maintenance-attribute.request.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';

export class UpdateMaintenanceAttributeBody extends CreateMaintenanceAttributeRequestDto {}
export class UpdateMaintenanceAttributeRequestDto extends UpdateMaintenanceAttributeBody {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
