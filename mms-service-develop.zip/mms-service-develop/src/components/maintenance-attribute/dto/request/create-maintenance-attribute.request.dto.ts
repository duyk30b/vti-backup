import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { MAINTENANCE_ATTRIBUTE_CONST } from '@components/maintenance-attribute/maintenance-attribute.constant';
import { IsNotBlank } from 'src/validator/is-not-blank.validator';

export class CreateMaintenanceAttributeRequestDto extends BaseDto {
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @MaxLength(MAINTENANCE_ATTRIBUTE_CONST.NAME.MAX_LENGTH)
  @IsNotBlank()
  @IsString()
  name: string;

  @ApiProperty()
  @IsString()
  @MaxLength(MAINTENANCE_ATTRIBUTE_CONST.DESCRIPTION.MAX_LENGTH)
  @IsOptional()
  description: string;
}
