import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';
import { GetDetailMaintenanceAttributeResponseDto } from './get-detail-maintenance-attribute.response.dto';

export class GetListAllMaintenanceAttributeResponseDto extends PaginationResponse {
  @ApiProperty({
    type: GetDetailMaintenanceAttributeResponseDto,
    isArray: true,
  })
  @Expose()
  @Type(() => GetDetailMaintenanceAttributeResponseDto)
  items: GetDetailMaintenanceAttributeResponseDto[];
}
