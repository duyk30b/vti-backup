import { CODE_REGEX } from '@constant/common';

export const MAINTENANCE_ATTRIBUTE_CONST = {
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
  CODE: {
    MIN_LENGTH: 6,
    MAX_LENGTH: 20,
    COLUMN: 'code',
    REGEX: CODE_REGEX,
    PREFIX: 'TTBT',
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
};
