import { Inject, Injectable } from '@nestjs/common';
import { MaintenanceAttributeServiceInterface } from '@components/maintenance-attribute/interface/maintenance-attribute.service.interface';
import { MaintenanceAttributeRepositoryInterface } from '@components/maintenance-attribute/interface/maintenance-attribute.repository.interface';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { plainToInstance } from 'class-transformer';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { CreateMaintenanceAttributeRequestDto } from '@components/maintenance-attribute/dto/request/create-maintenance-attribute.request.dto';
import { GetDetailMaintenanceAttributeResponseDto } from '@components/maintenance-attribute/dto/response/get-detail-maintenance-attribute.response.dto';
import { UpdateMaintenanceAttributeRequestDto } from '@components/maintenance-attribute/dto/request/update-maintenance-attribute.request.dto';
import { GetListMaintenanceAttributeRequestDto } from '@components/maintenance-attribute/dto/request/get-list-maintenance-attribute.request.dto';
import { GET_ALL_ENUM } from '@constant/common';
import { GetListAllMaintenanceAttributeResponseDto } from '@components/maintenance-attribute/dto/response/get-list-all-maintenance-attribute.response.dto';
import { keyBy } from 'lodash';
import { DetailMaintenanceAttributeRequestDto } from './dto/request/detail-maintenance-attribute.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { MAINTENANCE_ATTRIBUTE_CONST } from './maintenance-attribute.constant';
import { getCurrentCodeByLastRecord } from 'src/helper/code.helper';
import {
  getDataInsert,
  getDataToUpdateError,
  getDataUpdate,
} from 'src/helper/import.helper';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';

@Injectable()
export class MaintenanceAttributeService
  implements MaintenanceAttributeServiceInterface
{
  constructor(
    @Inject('MaintenanceAttributeRepositoryInterface')
    private readonly maintenanceAttributeRepository: MaintenanceAttributeRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateMaintenanceAttributeRequestDto): Promise<any> {
    try {
      request.code = await this.maintenanceAttributeRepository.generateNextCode(
        MAINTENANCE_ATTRIBUTE_CONST.CODE.PREFIX,
      );
      const maintenanceAttributeDocument =
        this.maintenanceAttributeRepository.createDocument(request);

      const dataSave = await maintenanceAttributeDocument.save();
      const dataReturn = plainToInstance(BasicResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getList(request: GetListMaintenanceAttributeRequestDto): Promise<any> {
    if (parseInt(request.isGetAll) == GET_ALL_ENUM.YES) {
      const response = await this.maintenanceAttributeRepository.findAll();

      const result = plainToInstance(
        GetListAllMaintenanceAttributeResponseDto,
        response,
        { excludeExtraneousValues: true },
      );
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } else {
      const { result, count } =
        await this.maintenanceAttributeRepository.getList(request);
      const response = plainToInstance(
        GetDetailMaintenanceAttributeResponseDto,
        result,
        {
          excludeExtraneousValues: true,
        },
      );
      return new ResponseBuilder<PaginationResponse>({
        items: response,
        meta: { total: count, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
  }

  async detail(request: DetailMaintenanceAttributeRequestDto): Promise<any> {
    const { id } = request;
    const response = await this.maintenanceAttributeRepository.findOneById(id);
    if (!response) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const result = plainToInstance(
      GetDetailMaintenanceAttributeResponseDto,
      response,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async update(request: UpdateMaintenanceAttributeRequestDto): Promise<any> {
    const { id } = request;
    const maintenanceAttribute =
      await this.maintenanceAttributeRepository.findOneById(id);
    if (!maintenanceAttribute) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    try {
      const maintenanceAttributeEntity =
        this.maintenanceAttributeRepository.updateEntity(
          maintenanceAttribute,
          request,
        );
      await this.maintenanceAttributeRepository.findByIdAndUpdate(
        id,
        maintenanceAttributeEntity,
      );

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async updateStatus(request: UpdateActiveStatusPayload): Promise<any> {
    const { id, status } = request;
    const maintenanceAttribute =
      await this.maintenanceAttributeRepository.findOneById(id);
    if (!maintenanceAttribute) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    await this.maintenanceAttributeRepository.findByIdAndUpdate(id, {
      $set: { active: status },
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const textAdd = await this.i18n.translate('import.common.add');
    const codePrefix = MAINTENANCE_ATTRIBUTE_CONST.CODE.PREFIX;
    const lastRecord = await this.maintenanceAttributeRepository.lastRecord();
    const codeCurrent = getCurrentCodeByLastRecord(codePrefix, lastRecord);

    const dataInsert = getDataInsert(data, codePrefix, codeCurrent, textAdd);
    const { dataToUpdate, codesUpdate } = getDataUpdate(data, textAdd);

    const codeUpdateExists =
      await this.maintenanceAttributeRepository.findAllByCondition({
        code: { $in: codesUpdate },
      });
    const codeUpdateMap = keyBy(codeUpdateExists, 'code');

    const { dataError, dataUpdate } = getDataToUpdateError(
      dataToUpdate,
      codeUpdateMap,
    );

    const bulkOps = [...dataInsert, ...dataUpdate].map((doc) => ({
      updateOne: {
        filter: { code: doc.code },
        update: doc,
        upsert: true,
      },
    }));

    const dataSuccess = await this.maintenanceAttributeRepository.bulkWrite(
      bulkOps,
    );

    return { dataError, dataSuccess };
  }
}
