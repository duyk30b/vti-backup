import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { MaintenanceAttributeSchema } from '../../models/maintenance-attribute/maintenance-attribute.schema';
import { MaintenanceAttributeController } from '@components/maintenance-attribute/maintenance-attribute.controller';
import { MaintenanceAttributeRepository } from '../../repository/maintenance-attribute/maintenance-attribute.repository';
import { MaintenanceAttributeService } from '@components/maintenance-attribute/maintenance-attribute.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'MaintenanceAttribute', schema: MaintenanceAttributeSchema },
    ]),
  ],
  controllers: [MaintenanceAttributeController],
  providers: [
    {
      provide: 'MaintenanceAttributeRepositoryInterface',
      useClass: MaintenanceAttributeRepository,
    },
    {
      provide: 'MaintenanceAttributeServiceInterface',
      useClass: MaintenanceAttributeService,
    },
  ],
  exports: [
    {
      provide: 'MaintenanceAttributeRepositoryInterface',
      useClass: MaintenanceAttributeRepository,
    },
    {
      provide: 'MaintenanceAttributeServiceInterface',
      useClass: MaintenanceAttributeService,
    },
  ],
})
export class MaintenanceAttributeModule {}
