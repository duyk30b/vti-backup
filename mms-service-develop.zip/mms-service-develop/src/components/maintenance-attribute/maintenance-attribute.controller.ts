import { GetListAllMaintenanceAttributeResponseDto } from '@components/maintenance-attribute/dto/response/get-list-all-maintenance-attribute.response.dto';
import {
  Body,
  Controller,
  Get,
  Inject,
  Injectable,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MaintenanceAttributeServiceInterface } from '@components/maintenance-attribute/interface/maintenance-attribute.service.interface';
import { isEmpty } from 'lodash';
import { CreateMaintenanceAttributeRequestDto } from '@components/maintenance-attribute/dto/request/create-maintenance-attribute.request.dto';
import { GetListMaintenanceAttributeRequestDto } from '@components/maintenance-attribute/dto/request/get-list-maintenance-attribute.request.dto';
import { UpdateMaintenanceAttributeBody } from '@components/maintenance-attribute/dto/request/update-maintenance-attribute.request.dto';
import { DetailMaintenanceAttributeRequestDto } from './dto/request/detail-maintenance-attribute.request.dto';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { GetDetailMaintenanceAttributeResponseDto } from './dto/response/get-detail-maintenance-attribute.response.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import {
  CREATE_MAINTENANCE_ATTRIBUTE_PERMISSION,
  UPDATE_STATUS_MAINTENANCE_ATTRIBUTE_PERMISSION,
} from '@utils/permissions/maintenance-attribute';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  DETAIL_MAINTENANCE_ATTRIBUTE_PERMISSION,
  LIST_MAINTENANCE_ATTRIBUTE_PERMISSION,
  UPDATE_MAINTENANCE_ATTRIBUTE_PERMISSION,
} from '@utils/permissions/maintenance-attribute';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { ACTIVE_ENUM } from '@constant/common';
import {
  CREATE_DEVICE_GROUP_PERMISSION,
  UPDATE_DEVICE_GROUP_PERMISSION,
} from '@utils/permissions/device-group';

@Injectable()
@Controller('maintenance-attributes')
export class MaintenanceAttributeController {
  constructor(
    @Inject('MaintenanceAttributeServiceInterface')
    private readonly maintenanceAttributeService: MaintenanceAttributeServiceInterface,
  ) {}

  @PermissionCode(CREATE_MAINTENANCE_ATTRIBUTE_PERMISSION.code)
  @Post('')
  @ApiOperation({
    tags: ['Maintenance Attribute'],
    summary: 'Create Maintenance Attribute',
    description: 'Create a new Maintenance Attribute',
  })
  @ApiResponse({
    status: 200,
    description: 'Created successfully',
    type: SuccessResponse,
  })
  async create(
    @Body() payload: CreateMaintenanceAttributeRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenanceAttributeService.create(request);
  }

  @PermissionCode(
    LIST_MAINTENANCE_ATTRIBUTE_PERMISSION.code,
    CREATE_DEVICE_GROUP_PERMISSION.code,
    UPDATE_DEVICE_GROUP_PERMISSION.code,
  )
  @Get('')
  @ApiOperation({
    tags: ['Maintenance Attribute'],
    summary: 'List Of Maintenance Attribute',
    description: 'List Of Maintenance Attribute',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListAllMaintenanceAttributeResponseDto,
  })
  async getList(
    @Query() payload: GetListMaintenanceAttributeRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenanceAttributeService.getList(request);
  }

  @PermissionCode(DETAIL_MAINTENANCE_ATTRIBUTE_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Maintenance Attribute'],
    summary: 'Detail Maintenance Attribute',
    description: 'Detail Maintenance Attribute',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetDetailMaintenanceAttributeResponseDto,
  })
  async detail(
    @Param() param: DetailMaintenanceAttributeRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenanceAttributeService.detail(request);
  }

  @PermissionCode(UPDATE_MAINTENANCE_ATTRIBUTE_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Maintenance Attribute'],
    summary: 'Update Maintenance Attribute',
    description: 'Update an existing Maintenance Attribute',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  async update(
    @Param() param: IdParamDto,
    @Body() payload: UpdateMaintenanceAttributeBody,
  ): Promise<any> {
    const { request: requestParam, responseError: responseErrorParam } = param;
    if (responseErrorParam && !isEmpty(responseErrorParam)) {
      return responseErrorParam;
    }

    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenanceAttributeService.update({
      _id: requestParam.id,
      ...request,
    });
  }

  @PermissionCode(UPDATE_STATUS_MAINTENANCE_ATTRIBUTE_PERMISSION.code)
  @Put('/:id/active')
  @ApiOperation({
    tags: ['Maintenance Attribute'],
    summary: 'Active Maintenance Attribute',
    description: 'Active Maintenance Attribute',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async active(@Param() payload: IdParamDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenanceAttributeService.updateStatus({
      ...request,
      status: ACTIVE_ENUM.ACTIVE,
    });
  }

  @PermissionCode(UPDATE_STATUS_MAINTENANCE_ATTRIBUTE_PERMISSION.code)
  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Maintenance Attribute'],
    summary: 'Inactive Maintenance Attribute',
    description: 'Inactive Maintenance Attribute',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async inactive(@Param() payload: IdParamDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenanceAttributeService.updateStatus({
      ...request,
      status: ACTIVE_ENUM.INACTIVE,
    });
  }
}
