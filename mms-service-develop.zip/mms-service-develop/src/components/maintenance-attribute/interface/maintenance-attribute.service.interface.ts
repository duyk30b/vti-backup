import { GetListMaintenanceAttributeRequestDto } from '@components/maintenance-attribute/dto/request/get-list-maintenance-attribute.request.dto';
import { UpdateMaintenanceAttributeRequestDto } from '@components/maintenance-attribute/dto/request/update-maintenance-attribute.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { DetailMaintenanceAttributeRequestDto } from '../dto/request/detail-maintenance-attribute.request.dto';

export interface MaintenanceAttributeServiceInterface {
  create(payload: any): Promise<any>;
  getList(request: GetListMaintenanceAttributeRequestDto): Promise<any>;
  detail(request: DetailMaintenanceAttributeRequestDto): Promise<any>;
  update(request: UpdateMaintenanceAttributeRequestDto): Promise<any>;
  import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }>;
  updateStatus(payload: UpdateActiveStatusPayload): Promise<any>;
}
