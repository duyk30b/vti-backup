import { UpdateMaintenanceAttributeBody } from '@components/maintenance-attribute/dto/request/update-maintenance-attribute.request.dto';
import { CreateMaintenanceAttributeRequestDto } from '@components/maintenance-attribute/dto/request/create-maintenance-attribute.request.dto';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { MaintenanceAttribute } from 'src/models/maintenance-attribute/maintenance-attribute.model';

export interface MaintenanceAttributeRepositoryInterface
  extends BaseInterfaceRepository<MaintenanceAttribute> {
  getList(payload): Promise<any>;
  createDocument(
    param: CreateMaintenanceAttributeRequestDto,
  ): MaintenanceAttribute;
  updateEntity(
    entity: MaintenanceAttribute,
    param: UpdateMaintenanceAttributeBody,
  ): MaintenanceAttribute;
}
