import { AccreditationTemplateRepositoryInterface } from '@components/accreditation-template/interface/accreditation-template.repository.interface';
import { JOB_TYPE_ENUM } from '@components/job/job.constant';
import { MaintenanceTemplateRepositoryInterface } from '@components/maintenance-template/interface/maintenance-template.repository.interface';
import { MAINTENANCE_JOB_TYPE } from '@components/maintenance-template/maintenance-template.constant';
import { SettingJobRepositoryInterface } from '@components/setting/interface/setting-job.repository.interface';
import { SettingServiceInterface } from '@components/setting/interface/setting.service.interface';
import { SETTING_JOB_PERIOD_ENUM } from '@components/setting/setting.constant';
import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { getLastDateOfDevice, getNextDateCreateJob } from '@utils/common';
import { keyBy } from 'lodash';
import { DEVICE_TEMPLATE_SCHEDULE_EVENT_ENUM } from '../device.constant';
import { DeviceTemplateScheduleRepositoryInterface } from '../interface/device-template-schedule.repository.interface';
import { DeviceRepositoryInterface } from '../interface/device.repository.interface';

@Injectable()
export class DeviceTemplateScheduleListener {
  constructor(
    @Inject('DeviceTemplateScheduleRepositoryInterface')
    protected readonly deviceTemplateScheduleRepository: DeviceTemplateScheduleRepositoryInterface,

    @Inject('SettingServiceInterface')
    private readonly settingService: SettingServiceInterface,

    @Inject('MaintenanceTemplateRepositoryInterface')
    private readonly maintenanceTemplateRepository: MaintenanceTemplateRepositoryInterface,

    @Inject('AccreditationTemplateRepositoryInterface')
    private readonly accreditationTemplateRepository: AccreditationTemplateRepositoryInterface,

    @Inject('DeviceRepositoryInterface')
    private readonly deviceRepository: DeviceRepositoryInterface,

    @Inject('SettingJobRepositoryInterface')
    private readonly settingJobRepository: SettingJobRepositoryInterface,
  ) {}

  @OnEvent(DEVICE_TEMPLATE_SCHEDULE_EVENT_ENUM.DEVICE_GROUP_UPDATE)
  async onDeviceGroupUpdate(body) {
    const {
      deviceGroupOld,
      maintenanceTemplateId,
      accreditationTemplateId,
      normGenerateJob,
      generateJobBy,
    } = body;
    const devices = await this.deviceRepository.findAllByCondition({
      deviceGroupId: deviceGroupOld._id,
    });

    const bulkOps = [];
    const bulkOpsDevice = [];
    const jobConfiguration = await this.settingJobRepository.findAllByCondition(
      {
        type: {
          $in: [
            JOB_TYPE_ENUM.ACCREDITATION,
            JOB_TYPE_ENUM.PERIOD_CHECKLIST,
            JOB_TYPE_ENUM.MAINTAIN,
          ],
        },
      },
    );
    if (
      deviceGroupOld.accreditationTemplateId?.toString() !==
      accreditationTemplateId?.toString()
    ) {
      const autoGenerateJobOnSunday = this.getConfigurationGenerateJob(
        jobConfiguration,
        JOB_TYPE_ENUM.ACCREDITATION,
      );
      const accreditationTemplate =
        await this.accreditationTemplateRepository.findOneById(
          accreditationTemplateId,
        );
      // tính thông báo trước bao nhiêu ngày
      const checkBeforeDateForAccreditation =
        await this.settingService.getDateSetting(
          JOB_TYPE_ENUM.ACCREDITATION,
          SETTING_JOB_PERIOD_ENUM.MORE_THAN_THREE_MONTH,
        );
      devices.forEach((device) => {
        const lastAccreditationDate = getLastDateOfDevice(
          device,
          'accreditation',
        );
        let accreditation = null;
        if (accreditationTemplate) {
          accreditation = {
            templateId: accreditationTemplate._id,
            title: accreditationTemplate.name,
            lastSchedule: lastAccreditationDate,
            periodic: accreditationTemplate.periodic,
            activeTime: accreditationTemplate.activeTime,
            nextSchedule: getNextDateCreateJob(
              checkBeforeDateForAccreditation,
              accreditationTemplate.periodic,
              lastAccreditationDate,
              autoGenerateJobOnSunday,
            ),
          };
        }
        bulkOps.push({
          updateOne: {
            filter: { deviceId: device._id },
            update: {
              $set: {
                deviceId: device._id,
                accreditation,
                accreditationTemplateId: accreditationTemplateId ?? null,
              },
            },
            upsert: true,
          },
        });
        bulkOpsDevice.push({
          updateOne: {
            filter: { _id: device._id },
            update: {
              $set: {
                accreditationTemplateId: accreditationTemplateId ?? null,
              },
            },
            upsert: false,
          },
        });
      });
    }
    // update lại các template
    if (
      deviceGroupOld.maintenanceTemplateId?.toString() !==
      maintenanceTemplateId?.toString()
    ) {
      const autoGenerateJobChecklistOnSunday = this.getConfigurationGenerateJob(
        jobConfiguration,
        JOB_TYPE_ENUM.PERIOD_CHECKLIST,
      );
      const autoGenerateJobMaintainOnSunday = this.getConfigurationGenerateJob(
        jobConfiguration,
        JOB_TYPE_ENUM.MAINTAIN,
      );
      const maintenanceTemplate =
        await this.maintenanceTemplateRepository.findOneById(
          maintenanceTemplateId,
        );
      // tính thông báo trước bao nhiêu ngày
      const checkBeforeDateForMaintain =
        await this.settingService.getDateSetting(
          JOB_TYPE_ENUM.MAINTAIN,
          SETTING_JOB_PERIOD_ENUM.LESS_THAN_THREE_MONTH,
        );

      const checkBeforeDateForChecklist =
        await this.settingService.getDateSetting(
          JOB_TYPE_ENUM.PERIOD_CHECKLIST,
          SETTING_JOB_PERIOD_ENUM.LESS_THAN_THREE_MONTH,
        );
      // job checklist & maintenance
      devices.forEach((device) => {
        if (
          device.maintenanceTemplateId?.toString() !==
          deviceGroupOld.maintenanceTemplateId?.toString()
        ) {
          return;
        }
        const maintain = [];
        const periodChecklist = [];

        maintenanceTemplate?.details?.forEach((e) => {
          const lastMaintenanceDate = getLastDateOfDevice(
            device,
            'maintenance',
          );
          if (e.type === MAINTENANCE_JOB_TYPE.CHECK) {
            periodChecklist.push({
              templateId: e.checklistTemplateId,
              title: e.title,
              periodic: e.periodTime,
              activeTime: e.activeTime,
              obligatory: e.obligatory,
              nextSchedule: getNextDateCreateJob(
                checkBeforeDateForChecklist,
                e.periodTime,
                lastMaintenanceDate,
                autoGenerateJobChecklistOnSunday,
              ),
              lastSchedule: lastMaintenanceDate,
            });
          } else if (e.type === MAINTENANCE_JOB_TYPE.MAINTENANCE) {
            maintain.push({
              templateId: e['_id'],
              title: e.title,
              periodic: e.periodTime,
              activeTime: e.activeTime,
              obligatory: e.obligatory,
              nextSchedule: getNextDateCreateJob(
                checkBeforeDateForMaintain,
                e.periodTime,
                lastMaintenanceDate,
                autoGenerateJobMaintainOnSunday,
              ),
              lastSchedule: lastMaintenanceDate,
            });
          }
        });

        bulkOps.push({
          updateOne: {
            filter: { deviceId: device._id },
            update: {
              $set: {
                deviceId: device._id,
                periodChecklist,
                maintain,
              },
            },
            upsert: true,
          },
        });
        bulkOpsDevice.push({
          updateOne: {
            filter: { _id: device._id },
            update: {
              $set: {
                maintenanceTemplateId: maintenanceTemplateId ?? null,
              },
            },
            upsert: false,
          },
        });
      });
    }

    if (
      deviceGroupOld.normGenerateJob?.toString() !== normGenerateJob?.toString()
    ) {
      devices.forEach((device) => {
        if (
          device.normGenerateJob?.toString() ===
          deviceGroupOld.normGenerateJob?.toString()
        ) {
          bulkOpsDevice.push({
            updateOne: {
              filter: { _id: device._id },
              update: {
                $set: {
                  normGenerateJob,
                  generateJobBy,
                },
              },
              upsert: false,
            },
          });
        }
      });
    }

    await this.deviceTemplateScheduleRepository.bulkWrite(bulkOps);
    await this.deviceRepository.bulkWrite(bulkOpsDevice);
  }

  @OnEvent(DEVICE_TEMPLATE_SCHEDULE_EVENT_ENUM.MAINTENANCE_TEMPLATE_UPDATE)
  async onMaintenanceTemplateUpdate(body) {
    const { devices, maintenanceDetails } = body;
    // tính thông báo trước bao nhiêu ngày
    const checkBeforeDateForMaintain = await this.settingService.getDateSetting(
      JOB_TYPE_ENUM.MAINTAIN,
      SETTING_JOB_PERIOD_ENUM.LESS_THAN_THREE_MONTH,
    );
    const jobConfiguration = await this.settingJobRepository.findAllByCondition(
      {
        type: { $in: [JOB_TYPE_ENUM.PERIOD_CHECKLIST, JOB_TYPE_ENUM.MAINTAIN] },
      },
    );
    const autoGenerateJobChecklistOnSunday = this.getConfigurationGenerateJob(
      jobConfiguration,
      JOB_TYPE_ENUM.PERIOD_CHECKLIST,
    );
    const autoGenerateJobMaintainOnSunday = this.getConfigurationGenerateJob(
      jobConfiguration,
      JOB_TYPE_ENUM.MAINTAIN,
    );
    const checkBeforeDateForChecklist =
      await this.settingService.getDateSetting(
        JOB_TYPE_ENUM.PERIOD_CHECKLIST,
        SETTING_JOB_PERIOD_ENUM.LESS_THAN_THREE_MONTH,
      );
    const bulkOps = [];
    devices.forEach((device) => {
      const maintenanceDeviceMap =
        keyBy(
          [
            ...(device.deviceTemplateSchedule?.maintain ?? []),
            ...(device.deviceTemplateSchedule?.periodChecklist ?? []),
          ],
          'templateId',
        ) ?? {};
      const maintain = [];
      const periodChecklist = [];
      // chuyển _id and checklistTemplateId => _id
      maintenanceDetails?.forEach((e) => {
        if (e.check === MAINTENANCE_JOB_TYPE.CHECK) {
          e._id = e.checklistTemplateId;
        }
        const templateOld = maintenanceDeviceMap[e._id];
        if (templateOld) {
          // nếu đã có thì lấy theo last hiện tại
          if (e.type === MAINTENANCE_JOB_TYPE.CHECK) {
            periodChecklist.push({
              title: e.title,
              templateId: e._id,
              periodic: e.periodTime,
              activeTime: e.activeTime,
              actualActiveTime: templateOld.actualActiveTime,
              obligatory: e.obligatory,
              nextSchedule: getNextDateCreateJob(
                checkBeforeDateForChecklist,
                e.periodTime,
                templateOld.lastSchedule,
                autoGenerateJobChecklistOnSunday,
              ),
              lastSchedule: templateOld.lastSchedule,
            });
          } else if (e.type === MAINTENANCE_JOB_TYPE.MAINTENANCE) {
            maintain.push({
              title: e.title,
              templateId: e._id,
              periodic: e.periodTime,
              activeTime: e.activeTime,
              actualActiveTime: templateOld.actualActiveTime,
              obligatory: e.obligatory,
              nextSchedule: getNextDateCreateJob(
                checkBeforeDateForMaintain,
                e.periodTime,
                templateOld.lastSchedule,
                autoGenerateJobMaintainOnSunday,
              ),
              lastSchedule: templateOld.lastSchedule,
            });
          }
        } else {
          // nếu chưa có mẫu phiếu thì lấy theo last của device
          const lastMaintenanceDate = getLastDateOfDevice(
            device,
            'maintenance',
          );
          if (e.type === MAINTENANCE_JOB_TYPE.CHECK) {
            periodChecklist.push({
              templateId: e.checklistTemplateId,
              title: e.title,
              periodic: e.periodTime,
              activeTime: e.activeTime,
              actualActiveTime: e.actualActiveTime,
              obligatory: e.obligatory,
              nextSchedule: getNextDateCreateJob(
                checkBeforeDateForChecklist,
                e.periodTime,
                lastMaintenanceDate,
                autoGenerateJobChecklistOnSunday,
              ),
              lastSchedule: lastMaintenanceDate,
            });
          } else if (e.type === MAINTENANCE_JOB_TYPE.MAINTENANCE) {
            maintain.push({
              templateId: e._id,
              title: e.title,
              periodic: e.periodTime,
              activeTime: e.activeTime,
              actualActiveTime: e.actualActiveTime,
              obligatory: e.obligatory,
              nextSchedule: getNextDateCreateJob(
                checkBeforeDateForMaintain,
                e.periodTime,
                lastMaintenanceDate,
                autoGenerateJobMaintainOnSunday,
              ),
              lastSchedule: lastMaintenanceDate,
            });
          }
        }
      });
      bulkOps.push({
        updateOne: {
          filter: { deviceId: device._id },
          update: { $set: { maintain, periodChecklist } },
          upsert: true,
        },
      });
    });
    await this.deviceTemplateScheduleRepository.bulkWrite(bulkOps);
  }

  @OnEvent(DEVICE_TEMPLATE_SCHEDULE_EVENT_ENUM.ACCREDITATION_UPDATE)
  async onAccreditationTemplateUpdate(body) {
    const { devices, accreditationTemplate } = body;
    const jobConfiguration = await this.settingJobRepository.findAllByCondition(
      { type: { $in: [JOB_TYPE_ENUM.ACCREDITATION] } },
    );
    const autoGenerateJobOnSunday = this.getConfigurationGenerateJob(
      jobConfiguration,
      JOB_TYPE_ENUM.ACCREDITATION,
    );
    const bulkOps = [];
    // tính thông báo trước bao nhiêu ngày
    const checkBeforeDateForAccreditation =
      await this.settingService.getDateSetting(
        JOB_TYPE_ENUM.ACCREDITATION,
        SETTING_JOB_PERIOD_ENUM.MORE_THAN_THREE_MONTH,
      );
    devices.forEach((device) => {
      const lastSchedule =
        device.deviceTemplateSchedule?.accreditation?.lastSchedule;
      const accreditation = {
        templateId: accreditationTemplate._id,
        title: accreditationTemplate.name,
        periodic: accreditationTemplate.periodic,
        activeTime: accreditationTemplate.activeTime,
        actualActiveTime:
          device.deviceTemplateSchedule?.accreditation.actualActiveTime,
        lastSchedule,
        nextSchedule: getNextDateCreateJob(
          checkBeforeDateForAccreditation,
          accreditationTemplate.periodic,
          lastSchedule,
          autoGenerateJobOnSunday,
        ),
      };

      bulkOps.push({
        updateOne: {
          filter: { deviceId: device._id },
          update: { $set: { accreditation } },
          upsert: true,
        },
      });
    });
    await this.deviceTemplateScheduleRepository.bulkWrite(bulkOps);
  }

  private getConfigurationGenerateJob = (jobConfiguration = [], jobType) => {
    return jobConfiguration.find((job) => job.type === jobType)
      ?.autoGenerateOnSunday;
  };
}
