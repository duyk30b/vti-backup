import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { DEVICE_EVENT_ENUM } from '../device.constant';
import { DeviceRepositoryInterface } from '../interface/device.repository.interface';

@Injectable()
export class DeviceListener {
  constructor(
    @Inject('DeviceRepositoryInterface')
    private readonly deviceRepository: DeviceRepositoryInterface,
  ) {}

  @OnEvent(DEVICE_EVENT_ENUM.RESET_NUMERICAL_ORDER)
  async onResetNumericalOrder(factoryChangeDeviceIds: string[]) {
    await this.deviceRepository.findAllAndUpdate(
      { _id: { $in: factoryChangeDeviceIds } },
      { numericalOrder: null },
    );
  }
}
