import { DeviceGroupRepository } from 'src/repository/device-group/device-group.repository';
import { DeviceGroupSchema } from 'src/models/device-group/device-group.schema';
import { DeviceRequestSchema } from 'src/models/device-request/device-request-ticket.schema';
import { SupplySchema } from 'src/models/supply/supply.schema';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { DeviceController } from '@components/device/device.controller';
import { DeviceSchema } from '../../models/device/device.schema';
import { DeviceRepository } from '../../repository/device/device.repository';
import { DeviceService } from '@components/device/device.service';
import { HistoryService } from '@components/history/history.service';
import { UserModule } from '@components/user/user.module';
import { JobRepository } from 'src/repository/job/job.repository';
import { DeviceAssignmentRepository } from 'src/repository/device-assignment/device-assignment.repository';
import { VendorRepository } from 'src/repository/vendor/vendor.repository';
import { VendorSchema } from 'src/models/vendor/vendor.schema';
import { AreaSchema } from 'src/models/area/area.schema';
import { AreaRepository } from 'src/repository/area/area.repository';
import { MaintenanceIndexRepository } from 'src/repository/maintenance-index/maintenance-index.repository';
import { MaintenanceIndexSchema } from 'src/models/maintenance-index/maintenance-index.schema';
import { DeviceStatusRepository } from 'src/repository/device-status/device-status.repository';
import { DeviceStatusSchema } from 'src/models/device-status/device-status.schema';
import { WarehouseSchema } from 'src/models/warehouse/warehouse.schema';
import { DeviceTypeSchema } from 'src/models/device-type/device-type.schema';
import { WarehouseRepository } from 'src/repository/warehouse/warehouse.repository';
import { DeviceTypeRepository } from 'src/repository/device-type/device-type.repository';
import { ConfigService } from '@config/config.service';
import { HistoryRepository } from 'src/repository/history/history.repository';
import { HistorySchema } from 'src/models/history/history.schema';
import { JobSchema } from 'src/models/job/job.schema';
import { DeviceAssignmentSchema } from 'src/models/device-assignment/device-assignment.schema';
import { MaintenanceTeamSchema } from 'src/models/maintenance-team/maintenance-team.schema';
import { SupplyRepository } from 'src/repository/supply/supply.repository';
import { DeviceGroupCountService } from '@components/device-group-count/device-group-count.service';
import { DeviceGroupCountRepository } from 'src/repository/device-group-count/device-group-count.repository';
import { DeviceGroupCountSchema } from 'src/models/device-group-count/device-group-count.schema';
import { DeviceNameSchema } from 'src/models/device-name/device-name.schema';
import { DeviceNameRepository } from 'src/repository/device-name/device-name.repository';
import { SettingModule } from '@components/setting/setting.module';
import { InventoryRepository } from 'src/repository/warehouse-inventories/inventory.repository';
import { InventorySchema } from 'src/models/warehouse-inventories/inventory.schema';
import { DeviceTemplateScheduleSchema } from 'src/models/device-template-schedule/device-template-schedule.schema';
import { DeviceTemplateScheduleRepository } from 'src/repository/device-template-schedule/device-template-schedule.repository';
import { DeviceTemplateScheduleListener } from './listener/device-template-schedule.listener';
import { MaintenanceTemplateRepository } from 'src/repository/maintenance-template/maintenance-template.repository';
import { MaintenanceTemplateSchema } from 'src/models/maintenance-template/maintenance-template.schema';
import { AccreditationTemplateRepository } from 'src/repository/accreditation-template/accreditation-template.repository';
import { AccreditationTemplateSchema } from 'src/models/accreditation-template/accreditation-template.schema';
import { SettingJobRepository } from 'src/repository/setting/setting-job.repository';
import { DeviceListener } from './listener/device.listener';
import { ItemModule } from '@components/item/item.module';
@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'Device', schema: DeviceSchema },
      { name: 'VendorModel', schema: VendorSchema },
      { name: 'Area', schema: AreaSchema },
      { name: 'MaintenanceIndex', schema: MaintenanceIndexSchema },
      { name: 'DeviceStatus', schema: DeviceStatusSchema },
      { name: 'Warehouse', schema: WarehouseSchema },
      { name: 'DeviceType', schema: DeviceTypeSchema },
      { name: 'History', schema: HistorySchema },
      { name: 'Supply', schema: SupplySchema },
      { name: 'Job', schema: JobSchema },
      { name: 'DeviceAssignment', schema: DeviceAssignmentSchema },
      { name: 'DeviceRequest', schema: DeviceRequestSchema },
      { name: 'MaintenanceTeam', schema: MaintenanceTeamSchema },
      { name: 'DeviceGroupTeam', schema: DeviceGroupSchema },
      { name: 'DeviceGroupCount', schema: DeviceGroupCountSchema },
      { name: 'DeviceName', schema: DeviceNameSchema },
      { name: 'Inventory', schema: InventorySchema },
      {
        name: 'DeviceTemplateSchedule',
        schema: DeviceTemplateScheduleSchema,
      },
      { name: 'MaintenanceTemplate', schema: MaintenanceTemplateSchema },
      {
        name: 'AccreditationTemplateModel',
        schema: AccreditationTemplateSchema,
      },
    ]),
    UserModule,
    SettingModule,
    ItemModule,
  ],
  controllers: [DeviceController],
  providers: [
    {
      provide: 'HistoryServiceInterface',
      useClass: HistoryService,
    },
    {
      provide: 'DeviceRepositoryInterface',
      useClass: DeviceRepository,
    },
    {
      provide: 'DeviceServiceInterface',
      useClass: DeviceService,
    },
    {
      provide: 'JobRepositoryInterface',
      useClass: JobRepository,
    },
    {
      provide: 'DeviceAssignmentRepositoryInterface',
      useClass: DeviceAssignmentRepository,
    },
    {
      provide: 'VendorRepositoryInterface',
      useClass: VendorRepository,
    },
    {
      provide: 'AreaRepositoryInterface',
      useClass: AreaRepository,
    },
    {
      provide: 'MaintenanceIndexRepositoryInterface',
      useClass: MaintenanceIndexRepository,
    },
    {
      provide: 'DeviceStatusRepositoryInterface',
      useClass: DeviceStatusRepository,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    {
      provide: 'DeviceTypeRepositoryInterface',
      useClass: DeviceTypeRepository,
    },
    {
      provide: 'DeviceGroupRepositoryInterface',
      useClass: DeviceGroupRepository,
    },
    {
      provide: 'InventoryRepositoryInterface',
      useClass: InventoryRepository,
    },
    {
      provide: 'DeviceNameRepositoryInterface',
      useClass: DeviceNameRepository,
    },
    {
      provide: 'HistoryRepositoryInterface',
      useClass: HistoryRepository,
    },
    {
      provide: 'SupplyRepositoryInterface',
      useClass: SupplyRepository,
    },
    {
      provide: 'DeviceGroupCountServiceInterface',
      useClass: DeviceGroupCountService,
    },
    {
      provide: 'DeviceGroupCountRepositoryInterface',
      useClass: DeviceGroupCountRepository,
    },
    {
      provide: 'DeviceTemplateScheduleRepositoryInterface',
      useClass: DeviceTemplateScheduleRepository,
    },
    {
      provide: 'AccreditationTemplateRepositoryInterface',
      useClass: AccreditationTemplateRepository,
    },
    {
      provide: 'MaintenanceTemplateRepositoryInterface',
      useClass: MaintenanceTemplateRepository,
    },
    {
      provide: 'SettingJobRepositoryInterface',
      useClass: SettingJobRepository,
    },
    ConfigService,
    DeviceTemplateScheduleListener,
    DeviceListener,
  ],
  exports: [
    MongooseModule,
    {
      provide: 'DeviceRepositoryInterface',
      useClass: DeviceRepository,
    },
    {
      provide: 'DeviceServiceInterface',
      useClass: DeviceService,
    },
    {
      provide: 'DeviceTemplateScheduleRepositoryInterface',
      useClass: DeviceTemplateScheduleRepository,
    },
    SettingModule,
  ],
})
export class DeviceModule {}
