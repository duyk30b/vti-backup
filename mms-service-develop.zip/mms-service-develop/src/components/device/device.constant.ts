import { CODE_REGEX } from '@constant/common';

export const DEVICE_CONST = {
  CODE: {
    MAX_LENGTH: 20,
    MIN_LENGTH: 6,
    MAX_LENGTH_PAD: 6,
    NUMBER_PAD: 1000000,
    NUMBER_PAD_STRING: '0000000',
    MAX_LENGTH_BODY: 18,
    COLUMN: 'code',
    PAD_CHAR: '0',
    PREFIX: '02',
    REGEX: CODE_REGEX,
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  STATUS: {
    COLUMN: 'status',
  },
  MODEL: {
    MAX_LENGTH: 255,
    COLUMN: 'model',
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
  DEVICE_GROUP: {
    COLUMN: 'deviceGroup',
  },
  DEVICE_GROUP_ID: {
    COLUMN: 'deviceGroupId',
  },
  VENDOR: {
    MAX_LENGTH: 255,
    COLUMN: 'vendor',
  },
  BRAND: {
    MAX_LENGTH: 255,
    COLUMN: 'brand',
  },
  COLL: 'devices',
  ID: {
    COLUMN: '_id',
  },
};

export enum ResponsibleSubjectType {
  User,
  MaintenanceTeam,
}
export const DEVICE_NAME = 'device';
export const DEVICE_HEADER = [
  {
    from: 'i',
  },
  {
    from: '_id',
  },
  {
    from: 'code',
  },
  {
    from: 'name',
  },
  {
    from: 'description',
  },
  {
    from: 'status',
  },
  {
    from: 'model',
  },
  {
    from: 'deviceGroupName',
  },
  {
    from: 'periodicInspectionTime',
  },
  {
    from: 'frequency',
  },
  {
    from: 'price',
  },
  {
    from: 'maintenanceAttribute',
  },
  {
    from: 'type',
  },
  {
    from: 'vendor',
  },
  {
    from: 'brand',
  },
  {
    from: 'importDate',
  },
  {
    from: 'productionDate',
  },
  {
    from: 'warrantyPeriod',
  },
  {
    from: 'maintenancePeriod',
  },
  {
    from: 'mttaIndex',
  },
  {
    from: 'mttfIndex',
  },
  {
    from: 'mtbfIndex',
  },
  {
    from: 'mttrIndex',
  },
  {
    from: 'createdAt',
  },
  {
    from: 'updatedAt',
  },
  {
    from: 'responsibleUser',
  },
];

export const IMPORT_DEVICE_CONST = {
  FILE_NAME: 'import_device_template.xlsx',
  ENTITY_KEY: 'device',
  COLUMNS: [
    'code',
    'name',
    'description',
    'price',
    'deviceGroupName',
    'isForManufacturing',
    'maintenanceAttributeName',
    'frequency',
    'periodicInspectionTime',
    'responsibleUser',
    'responsibleMaintenanceTeam',
  ],
  REQUIRED_FIELDS: [
    'code',
    'name',
    'deviceGroupName',
    'isForManufacturing',
    'maintenanceAttributeName',
    'frequency',
    'periodicInspectionTime',
  ],
};

export const DEVICE_DETAIL_HEADER = [
  {
    from: 'i',
  },
  {
    from: 'code',
  },
  {
    from: 'supply',
  },
  {
    from: 'supplyType',
  },
  {
    from: 'quantity',
  },
  {
    from: 'useDate',
  },
  {
    from: 'maintenancePeriod',
  },
  {
    from: 'mttaIndex',
  },
  {
    from: 'mttfIndex',
  },
  {
    from: 'mtbfIndex',
  },
  {
    from: 'mttrIndex',
  },
];

export enum DeviceType {
  Normal,
  ForManufacture,
}

export const DEFAULT_DEVICE_UNIT_CODE = 'CA';

export enum ASSET_TYPE_ENUM {
  RENT,
  BUY,
}

export enum IS_FIXED_ASSET {
  NO, //MMSx
  YES, //WFX
}

// @TODO: confirm status
export enum DEVICE_STATUS_ENUM {
  USING,
  USELESS,
  PREVENTIVE,
  BROKEN,
  AWAIT_CLEARANCE,
}

export enum ASSET_MAINTENANCE_TYPE_ENUM {
  DEVICE,
  SUPPLY,
}

export enum FILTER_IS_OVERDUE_ENUM {
  ALL,
  OVERDUE,
  NOT_OVERDUE,
}

export enum DEVICE_TEMPLATE_SCHEDULE_EVENT_ENUM {
  ACCREDITATION_UPDATE = 'template-schedule.accreditation-update',
  MAINTENANCE_TEMPLATE_UPDATE = 'template-schedule.maintenance-template-update',
  DEVICE_GROUP_UPDATE = 'template-schedule.device-group-update',
}

export enum DEVICE_EVENT_ENUM {
  RESET_NUMERICAL_ORDER = 'device.reset-order-numerical',
}
