import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DeviceServiceInterface } from '@components/device/interface/device.service.interface';
import { DeviceRepositoryInterface } from '@components/device/interface/device.repository.interface';
import { plainToInstance } from 'class-transformer';
import { CreateDeviceFormData } from '@components/device/dto/request/create-device.request.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { GetListDevicesRequestDto } from '@components/device/dto/request/list-devices.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { UpdateDeviceRequestDto } from '@components/device/dto/request/update-device.request.dto';
import {
  ASSET_MAINTENANCE_TYPE_ENUM,
  ASSET_TYPE_ENUM,
  DEVICE_CONST,
  DEVICE_STATUS_ENUM,
} from '@components/device/device.constant';
import {
  compact,
  countBy,
  differenceBy,
  first,
  groupBy,
  has,
  isEmpty,
  isNil,
  keyBy,
  map,
  maxBy,
  minBy,
  uniq,
} from 'lodash';
import { VendorRepositoryInterface } from '@components/vendor/interface/vendor.repository.interface';
import { ListDeviceResponse } from './dto/response/list-device.response';
import { ApiError } from '@utils/api.error';
import { DetailDeviceResponse } from './dto/response/detail-device.response';
import { DeviceGroupRepositoryInterface } from '@components/device-group/interface/device-group.repository.interface';
import { JOB_STATUS_ENUM, JOB_TYPE_ENUM } from '@components/job/job.constant';
import {
  ACTIVE_ENUM,
  DATE_FORMAT_IMPORT,
  GET_ALL_ENUM,
  ROLE,
} from '@constant/common';
import { JobRepositoryInterface } from '@components/job/interface/job.repository.interface';
import { SupplyByDeviceResponse } from './dto/response/supply-by-device.response';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { ScanDeviceParamDto } from './dto/request/scan-device.param.dto';
import { UpdateStatusDeviceRequestDto } from './dto/request/update-status-device.request.dto';
import { UpdateLocationDeviceRequestDto } from './dto/request/update-location-device.request.dto';
import { MAINTENANCE_JOB_TYPE } from '@components/maintenance-template/maintenance-template.constant';
import { MaintenanceIndexRepositoryInterface } from '@components/maintenance-index/interface/maintenance-index.repository.interface';
import { AreaRepositoryInterface } from '@components/area/interface/area.repository.interface';
import { DeviceStatusRepositoryInterface } from '@components/device-status/interface/device-status.repository.interface';
import { DeviceActivityHistoryResponseDto } from './dto/response/device-activity-history.response.dto';
import { GetDeviceActivityHistoryRequestDto } from './dto/request/get-device-activity-history.request.dto';
import { ScanDeviceResponseDto } from './dto/response/scan-device.response.dto';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';
import * as moment from 'moment';
import { FileServiceInterface } from '@components/file/interface/file.service.interface';
import { FileResource } from '@components/file/file.constant';
import { ConfigService } from '@config/config.service';
import { HistoryRepositoryInterface } from '@components/history/interface/history.repository.interface';
import { SupplyRepositoryInterface } from '@components/supply/interface/supply.repository.interface';
import { MaintenanceInfoResponseDto } from './dto/response/maintenance-info.response';
import { GenerateDeviceQrCodeRequest } from './dto/request/generate-device-qr-code.request.dto';
import {
  getLastDateOfDevice,
  getNextDateCreateJob,
  minus,
  plus,
} from '@utils/common';
import { DeviceGroupCountRepositoryInterface } from '@components/device-group-count/interface/device-group-count.repository.interface';
import { DeviceGroupCountServiceInterface } from '@components/device-group-count/interface/device-group-count.service.interface';
import { DeviceNameRepositoryInterface } from '@components/device-name/interface/device-name.repository.interface';
import { SettingServiceInterface } from '@components/setting/interface/setting.service.interface';
import { SETTING_JOB_PERIOD_ENUM } from '@components/setting/setting.constant';
import { Types } from 'mongoose';
import { Device } from 'src/models/device/device.model';
import { InventoryRepositoryInterface } from '@components/warehouse/interface/inventory.repository.interface';
import { MIN_STOCK_INVENTORY } from '@components/update-warehouse-inventory-ticket/update-inventory-ticket.constant';
import { ASSET_INVENTORY_ENUM } from '@components/warehouse/warehouse.constant';
import { DeviceTemplateScheduleRepositoryInterface } from './interface/device-template-schedule.repository.interface';
import { MaintenanceTemplateRepositoryInterface } from '@components/maintenance-template/interface/maintenance-template.repository.interface';
import { DeviceTemplateSchedule } from 'src/models/device-template-schedule/device-template-schedule.model';
import {
  HISTORY_REF_ENUM,
  FIELDS_LOG_HISTORY,
} from '@components/history/history.constant';
import { getDataDuplicate } from '@utils/common';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { SettingJobRepositoryInterface } from '@components/setting/interface/setting-job.repository.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
@Injectable()
export class DeviceService implements DeviceServiceInterface {
  constructor(
    @Inject('DeviceRepositoryInterface')
    private readonly deviceRepository: DeviceRepositoryInterface,

    @Inject('DeviceStatusRepositoryInterface')
    private readonly deviceStatusRepository: DeviceStatusRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('VendorRepositoryInterface')
    private readonly vendorRepository: VendorRepositoryInterface,

    @Inject('DeviceGroupRepositoryInterface')
    private readonly deviceGroupRepository: DeviceGroupRepositoryInterface,

    @Inject('DeviceNameRepositoryInterface')
    private readonly deviceNameRepository: DeviceNameRepositoryInterface,

    @Inject('JobRepositoryInterface')
    private readonly jobRepository: JobRepositoryInterface,

    @Inject('AreaRepositoryInterface')
    private readonly areaRepository: AreaRepositoryInterface,

    @Inject('MaintenanceIndexRepositoryInterface')
    private readonly maintenanceIndexRepository: MaintenanceIndexRepositoryInterface,

    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,

    @Inject('SupplyRepositoryInterface')
    private readonly supplyRepository: SupplyRepositoryInterface,

    @Inject('FileServiceInterface')
    private readonly fileService: FileServiceInterface,

    @Inject('DeviceGroupCountServiceInterface')
    private readonly deviceGroupCountService: DeviceGroupCountServiceInterface,

    @Inject('DeviceGroupCountRepositoryInterface')
    private readonly deviceGroupCountRepository: DeviceGroupCountRepositoryInterface,

    @Inject('HistoryRepositoryInterface')
    private readonly historyRepository: HistoryRepositoryInterface,

    @Inject('SettingServiceInterface')
    private readonly settingService: SettingServiceInterface,

    @Inject('InventoryRepositoryInterface')
    private readonly inventoryRepository: InventoryRepositoryInterface,

    @Inject('DeviceTemplateScheduleRepositoryInterface')
    private readonly deviceTemplateScheduleRepository: DeviceTemplateScheduleRepositoryInterface,

    @Inject('MaintenanceTemplateRepositoryInterface')
    private readonly maintenanceTemplateRepository: MaintenanceTemplateRepositoryInterface,

    @Inject('SettingJobRepositoryInterface')
    private readonly settingJobRepository: SettingJobRepositoryInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    private readonly i18n: I18nRequestScopeService,

    private readonly configService: ConfigService,
  ) {}

  protected readonly fileUri = this.configService.get('fileUri');

  async updateLocation(
    request: UpdateLocationDeviceRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { areaId, factoryId, id } = request;

    // user must is admin or user's factory is factory selected
    try {
      const device = await this.deviceRepository.findOneByCondition({
        ...request.permissionCondition,
        _id: id,
      });

      // device must exists
      if (!device)
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.DEVICE_NOT_FOUND'))
          .build();

      // if updating device's factory, factory must exists
      if (factoryId) {
        const factory = await this.userService.getFactoryById(factoryId);
        if (!factory) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.NOT_FOUND)
            .withMessage(await this.i18n.translate('error.FACTORY_NOT_FOUND'))
            .build();
        }
      }

      // if updating device's area, area must exists and in the selected factory
      if (areaId) {
        const area = await this.areaRepository.findOneById(areaId);
        if (!area || area.factoryId !== (factoryId ?? device.factoryId)) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.NOT_FOUND)
            .withMessage(await this.i18n.translate('error.AREA_NOT_EXIST'))
            .build();
        }
      }

      // update data
      await this.deviceRepository.findByIdAndUpdate(id, {
        $set: { areaId, factoryId },
      });

      // save logs
      await this.historyRepository.logHistoryForDocuments(
        [
          {
            oldObject: device,
            newObject: request,
          },
        ],
        HISTORY_REF_ENUM.DEVICE,
        request.userId,
      );

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  async updateStatus(
    request: UpdateStatusDeviceRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, status } = request;

    try {
      const device = await this.deviceRepository.findOneByCondition({
        ...request.permissionCondition,
        _id: id,
      });

      if (!device) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.DEVICE_NOT_FOUND'))
          .build();
      }
      //save history change device status
      await this.historyRepository.logHistoryForDocuments(
        [{ oldObject: { device }, newObject: { status } }],
        HISTORY_REF_ENUM.DEVICE,
        request.userId,
      );
      // update device's status
      await this.deviceRepository.findByIdAndUpdate(id, { status });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  async create(request: CreateDeviceFormData): Promise<any> {
    const { data } = request;
    const validate = await this.validateBeforeSave(request);
    if (validate.statusCode !== ResponseCodeEnum.SUCCESS) {
      return validate;
    }

    try {
      // serial and identificationNo of device is unique
      const isExistsDeviceSerialAndIdentificationNo =
        await this.deviceRepository.findOneByCondition({
          serial: data.serial,
          identificationNo: data.identificationNo,
        });
      if (isExistsDeviceSerialAndIdentificationNo) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.DEVICE_CAN_NOT_DUPLICATE_SERIAL_AND_IDENTIFICATION',
            ),
          )
          .build();
      }

      // if has device's vendor, vendor must exists
      if (data?.vendorId) {
        const vendor = await this.vendorRepository.findOneById(data.vendorId);
        if (!vendor) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.NOT_FOUND)
            .withMessage(await this.i18n.translate('error.VENDOR_NOT_FOUND'))
            .build();
        }
      }

      // device's device group, device group must exists
      const deviceGroup = await this.deviceGroupRepository.findOneWithPopulate(
        { _id: data.deviceGroupId },
        {
          path: 'installationTemplate accreditationTemplate maintenanceTemplate',
        },
      );
      if (!deviceGroup) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.DEVICE_GROUP_NOT_FOUND'),
          )
          .build();
      }

      // if has device's unit, unit must exists
      if (data?.unitId) {
        const unit = await this.itemService.getUnitById(data?.unitId);
        if (!unit) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.NOT_FOUND)
            .withMessage(await this.i18n.translate('error.UNIT_NOT_FOUND'))
            .build();
        }
      }

      // if request has device's image, upload device's image and save url
      if (request?.file) {
        const response = await this.fileService.uploadFile(
          first(request.file),
          FileResource.DEVICE,
        );
        if (!response?.fileUrl) {
          return new ApiError(
            ResponseCodeEnum.BAD_REQUEST,
            await this.i18n.translate('error.UPLOAD_FILE_ERROR'),
          ).toResponse();
        }
        data.imageUrl = response.fileUrl;
      }

      // get device group's current code
      let code: any =
        await this.deviceGroupCountService.countDeviceByDeviceGroup(
          data.deviceGroupId,
        );
      const count = code;

      // device's code = device group's symbol + code
      code = plus(code, 1)
        .toString()
        .padStart(
          DEVICE_CONST.CODE.MAX_LENGTH_PAD,
          DEVICE_CONST.CODE.NUMBER_PAD_STRING,
        );
      data.code = `${deviceGroup.symbol}${code}`;
      // update device group's current code
      await this.deviceGroupCountService.update(
        data.deviceGroupId,
        plus(count, 1),
      );

      // if has device name id, device name id must exists
      const deviceName = await this.deviceNameRepository.findOneById(
        data.deviceNameId,
      );
      if (!deviceName) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.DEVICE_NAME_NOT_FOUND'))
          .build();
      }
      data.name = deviceName.name;

      let maintenanceTemplate;
      if (data.maintenanceTemplateId) {
        maintenanceTemplate =
          await this.maintenanceTemplateRepository.findOneById(
            data.maintenanceTemplateId,
          );
        if (!maintenanceTemplate) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.NOT_FOUND)
            .withMessage(
              await this.i18n.translate('error.MAINTENANCE_TEMPLATE_NOT_EXIST'),
            )
            .build();
        }
      }

      // create a device and assign to history
      const supplies = data.supplies;
      const existSupplyDiff = !isEmpty(
        differenceBy(supplies, deviceGroup?.supplies, (data) =>
          data.supplyId?.toString(),
        ),
      );
      if (existSupplyDiff) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.SUPPLY_NOT_FOUND'))
          .build();
      }

      if (data.warehouseId) {
        const warehouse = await this.warehouseRepository.findOneByCondition({
          ...request.permissionCondition,
          _id: data.warehouseId,
        });
        if (!warehouse) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.NOT_FOUND)
            .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
            .build();
        }
        await this.updateWarehouseInventoryWhenCreateDevice(data);
      }

      const deviceDocument = this.deviceRepository.createDocument(
        data,
        supplies,
      );
      const device = await this.deviceRepository.create(deviceDocument);

      // add template schedules for device
      await this.handleTemplateDevice(
        device,
        deviceGroup['accreditationTemplate'],
        maintenanceTemplate,
      );

      await this.historyRepository.logHistoryForDocuments(
        [{ oldObject: null, newObject: device }],
        HISTORY_REF_ENUM.DEVICE,
        request.userId,
      );

      // Create maintenance index
      const maintenanceIndex = this.maintenanceIndexRepository.createEntities(
        deviceGroup.maintenanceIndex?.map((e) => ({
          ...e,
          deviceId: device._id,
        })),
      );
      await this.maintenanceIndexRepository.create(maintenanceIndex);

      const dataReturn = plainToInstance(BasicResponseDto, device, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      console.error(err);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CREATE'))
        .build();
    }
  }

  async validateBeforeSave(request: CreateDeviceFormData, id?: string) {
    const {
      data: { numericalOrder, factoryId },
      factoryIds,
    } = request;
    const updateCondition = id ? { _id: { $ne: id } } : {};
    if (numericalOrder && factoryId) {
      const numericalOrderExist =
        await this.deviceRepository.findOneByCondition({
          factoryId,
          numericalOrder,
          ...updateCondition,
        });
      if (numericalOrderExist) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.ORDER_NUMERICAL_EXIST_IN_FACTORY'),
        ).toResponse();
      }
    }
    // factory must exists
    const factory = await this.userService.getFactoryById(factoryId);
    if (!factory || !(isEmpty(factoryIds) || factoryIds.includes(factoryId))) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.FACTORY_NOT_FOUND'))
        .build();
    }

    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async handleTemplateDevice(
    device,
    accreditationTemplate,
    maintenanceTemplate,
  ): Promise<DeviceTemplateSchedule> {
    // tính thông báo trước bao nhiêu ngày
    const checkBeforeDateForMaintain = await this.settingService.getDateSetting(
      JOB_TYPE_ENUM.MAINTAIN,
      SETTING_JOB_PERIOD_ENUM.LESS_THAN_THREE_MONTH,
    );

    const checkBeforeDateForChecklist =
      await this.settingService.getDateSetting(
        JOB_TYPE_ENUM.PERIOD_CHECKLIST,
        SETTING_JOB_PERIOD_ENUM.LESS_THAN_THREE_MONTH,
      );

    const checkBeforeDateForAccreditation =
      await this.settingService.getDateSetting(
        JOB_TYPE_ENUM.ACCREDITATION,
        SETTING_JOB_PERIOD_ENUM.MORE_THAN_THREE_MONTH,
      );
    const jobConfiguration = await this.settingJobRepository.findAllByCondition(
      {
        type: {
          $in: [
            JOB_TYPE_ENUM.ACCREDITATION,
            JOB_TYPE_ENUM.PERIOD_CHECKLIST,
            JOB_TYPE_ENUM.MAINTAIN,
          ],
        },
      },
    );
    let accreditation: any = {};
    const maintain = [];
    const periodChecklist = [];
    // job accreditation
    if (accreditationTemplate) {
      const autoGenerateJobOnSunday = this.getConfigurationGenerateJob(
        jobConfiguration,
        JOB_TYPE_ENUM.ACCREDITATION,
      );
      const lastAccreditationDate = getLastDateOfDevice(
        device,
        'accreditation',
      );
      accreditation = {
        templateId: accreditationTemplate._id,
        title: accreditationTemplate.name,
        lastSchedule: lastAccreditationDate,
        nextSchedule: getNextDateCreateJob(
          checkBeforeDateForAccreditation,
          accreditationTemplate.periodic,
          lastAccreditationDate,
          autoGenerateJobOnSunday,
        ),
        activeTime: accreditationTemplate.activeTime,
        periodic: accreditationTemplate.periodic,
      };
    }
    // job checklist & maintenance
    if (maintenanceTemplate) {
      const lastMaintenanceDate = getLastDateOfDevice(device, 'maintenance');
      const autoGenerateJobChecklistOnSunday = this.getConfigurationGenerateJob(
        jobConfiguration,
        JOB_TYPE_ENUM.PERIOD_CHECKLIST,
      );
      const autoGenerateJobMaintainOnSunday = this.getConfigurationGenerateJob(
        jobConfiguration,
        JOB_TYPE_ENUM.MAINTAIN,
      );
      maintenanceTemplate.details?.forEach((e) => {
        if (e.type === MAINTENANCE_JOB_TYPE.CHECK) {
          periodChecklist.push({
            templateId: e.checklistTemplateId,
            title: e.title,
            nextSchedule: getNextDateCreateJob(
              checkBeforeDateForChecklist,
              e.periodTime,
              lastMaintenanceDate,
              autoGenerateJobChecklistOnSunday,
            ),
            periodic: e.periodTime,
            activeTime: e.activeTime,
            obligatory: e.obligatory,
            lastSchedule: lastMaintenanceDate,
          });
        } else if (e.type === MAINTENANCE_JOB_TYPE.MAINTENANCE) {
          maintain.push({
            templateId: e['_id'],
            title: e.title,
            periodic: e.periodTime,
            activeTime: e.activeTime,
            obligatory: e.obligatory,
            nextSchedule: getNextDateCreateJob(
              checkBeforeDateForMaintain,
              e.periodTime,
              lastMaintenanceDate,
              autoGenerateJobMaintainOnSunday,
            ),
            lastSchedule: lastMaintenanceDate,
          });
        }
      });
    }
    await this.deviceRepository.findByIdAndUpdate(device._id, {
      accreditationTemplateId: accreditationTemplate?._id ?? null,
      maintenanceTemplateId: maintenanceTemplate?._id ?? null,
    });
    const bulkOps = [
      {
        updateOne: {
          filter: { deviceId: device._id },
          update: {
            $set: {
              deviceId: device._id,
              accreditation,
              maintain,
              periodChecklist,
            },
          },
          upsert: true,
        },
      },
    ];
    await this.deviceTemplateScheduleRepository.bulkWrite(bulkOps);
    return;
  }

  private getConfigurationGenerateJob = (jobConfiguration = [], jobType) => {
    return jobConfiguration.find((job) => job.type === jobType)
      ?.autoGenerateOnSunday;
  };

  async list(request: GetListDevicesRequestDto): Promise<any> {
    if (+request.isGetAll === GET_ALL_ENUM.YES) {
      const { result } = await this.deviceRepository.list(request);
      const factoryIds = [];
      const unitIds = [];
      result.forEach((e) => {
        factoryIds.push(e.factoryId);
        unitIds.push(e.unitId);
      });

      const factories = await this.userService.getFactoryList([
        {
          column: 'factoryIds',
          text: factoryIds,
        },
      ]);

      const factoryMap = keyBy(factories, 'id');

      const units = await this.itemService.getListUnit([
        {
          column: 'ids',
          text: unitIds.toString(),
        },
      ]);
      const unitMap = keyBy(units, 'id');
      result.forEach((e) => {
        e.unit = unitMap[e.unitId];
        e.factory = factoryMap[e.factoryId];
      });

      const dataReturn = plainToInstance(ListDeviceResponse, result, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    const { result, count } = await this.deviceRepository.list(request);

    const factoryIds = result.map((e) => e.factoryId);

    const factories = await this.userService.getFactoryList([
      {
        column: 'factoryIds',
        text: factoryIds,
      },
    ]);

    const factoryMap = keyBy(factories, 'id');

    result.forEach((e) => {
      e.factory = factoryMap[e.factoryId];
    });

    const dataReturn = plainToInstance(ListDeviceResponse, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async update(request: UpdateDeviceRequestDto & IdParamDto): Promise<any> {
    const { data, id } = request;
    const validate = await this.validateBeforeSave(request, id);
    if (validate.statusCode !== ResponseCodeEnum.SUCCESS) {
      return validate;
    }
    const deviceExist = await this.deviceRepository.findOneByCondition({
      _id: id,
    });
    if (!deviceExist)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.DEVICE_NOT_FOUND'))
        .build();

    // if device manage by wfx then cannot update some field: isFixedAsset, identificationNo, deviceGroupId, deviceNameId, serial, factoryId, model, creationDate, unitId, manufacturer
    if (
      deviceExist.isFixedAsset &&
      data.identificationNo !== deviceExist.identificationNo &&
      data.deviceGroupId !== deviceExist.deviceGroupId &&
      data.deviceNameId !== deviceExist.deviceNameId &&
      data.serial !== deviceExist.serial &&
      data.factoryId !== deviceExist.factoryId &&
      data.model !== deviceExist.model &&
      data.creationDate !== deviceExist.creationDate &&
      data.unitId !== deviceExist.unitId &&
      data.manufacturer !== deviceExist.manufacturer
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.DATA_ON_WFX_CANNOT_UPDATE'),
        )
        .build();
    }

    const isExistsDeviceSerialAndIdentificationNo =
      await this.deviceRepository.findOneByCondition({
        serial: data.serial,
        identificationNo: data.identificationNo,
        _id: { $ne: new Types.ObjectId(data['id']) },
      });
    if (isExistsDeviceSerialAndIdentificationNo) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.DEVICE_CAN_NOT_DUPLICATE_SERIAL_AND_IDENTIFICATION',
          ),
        )
        .build();
    }
    const deviceName = await this.deviceNameRepository.findOneById(
      data.deviceNameId,
    );
    if (!deviceName) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.DEVICE_NAME_NOT_FOUND'))
        .build();
    }
    data.name = deviceName.name;

    if (data.vendorId) {
      const vendor = await this.vendorRepository.findOneById(data.vendorId);
      if (!vendor) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.VENDOR_NOT_FOUND'))
          .build();
      }
    }

    if (data?.unitId) {
      const unit = await this.itemService.getUnitById(data?.unitId);
      if (!unit) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.UNIT_NOT_FOUND'))
          .build();
      }
    }

    if (data.maintenanceTemplateId) {
      const maintenanceTemplate =
        await this.maintenanceTemplateRepository.findOneById(
          data.maintenanceTemplateId,
        );
      if (!maintenanceTemplate) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.MAINTENANCE_TEMPLATE_NOT_EXIST'),
          )
          .build();
      }
    }

    const deviceGroup = await this.deviceGroupRepository.findOneWithPopulate(
      { _id: data.deviceGroupId },
      {
        path: 'installationTemplate accreditationTemplate maintenanceTemplate',
      },
    );
    if (!deviceGroup) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.DEVICE_GROUP_NOT_FOUND'))
        .build();
    }

    // if updating device's status to active, some field: deviceTypeId, deviceGroupId, device group's supplies, initMaintenanceDate must be exists or not empty
    if (
      data.active === ACTIVE_ENUM.ACTIVE &&
      (isEmpty(data.deviceTypeId) ||
        isEmpty(data.deviceGroupId) ||
        isEmpty(deviceGroup.supplies) ||
        isEmpty(data.initMaintenanceDate))
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CANNOT_ACTIVE_DEVICE'))
        .build();
    }

    try {
      if (!isNil(request?.file) && typeof request?.file !== 'string') {
        const response = await this.fileService.uploadFile(
          first(request.file),
          FileResource.DEVICE,
        );
        if (!response?.fileUrl) {
          return new ApiError(
            ResponseCodeEnum.BAD_REQUEST,
            await this.i18n.translate('error.UPLOAD_FILE_ERROR'),
          ).toResponse();
        }
        data.file = response.fileUrl;
      }
      if (!isNil(request?.file) && typeof request?.file === 'string') {
        data.file = request?.file?.replace(this.fileUri, '');
      }

      let code = null;
      let count = 0;
      if (!deviceExist.code) {
        code = await this.deviceGroupCountService.countDeviceByDeviceGroup(
          data.deviceGroupId,
        );
        count = code;
        if (code < DEVICE_CONST.CODE.NUMBER_PAD) {
          code = plus(code, 1)
            .toString()
            .padStart(
              DEVICE_CONST.CODE.MAX_LENGTH_PAD,
              DEVICE_CONST.CODE.NUMBER_PAD_STRING,
            );
        }
        data.code = `${deviceGroup.symbol}${code}`;
      }

      const supplies = data.supplies;
      const existSupplyDiff = !isEmpty(
        differenceBy(supplies, deviceGroup?.supplies, (data) =>
          data.supplyId?.toString(),
        ),
      );
      if (existSupplyDiff) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.SUPPLY_NOT_FOUND'))
          .build();
      }
      if (
        !moment(deviceExist.initMaintenanceDate).isSame(
          moment(data.initMaintenanceDate),
        ) ||
        !moment(deviceExist.initAccreditationDate).isSame(
          moment(data.initAccreditationDate),
        )
      ) {
        // update template schedules for device
        await this.handleTemplateDevice(
          { ...data, _id: id },
          deviceGroup['accreditationTemplate'],
          deviceGroup['maintenanceTemplate'],
        );
      }

      if (
        data.maintenanceTemplateId?.toString() !==
        deviceExist.maintenanceTemplateId?.toString()
      ) {
        const maintenanceTemplate =
          await this.maintenanceTemplateRepository.findOneById(
            data.maintenanceTemplateId,
          );
        await this.handleTemplateDevice(
          deviceExist,
          deviceGroup['accreditationTemplate'],
          maintenanceTemplate,
        );
      }

      const deviceUpdate = this.deviceRepository.updateDocument(
        { ...deviceExist } as Device,
        {
          ...data,
          supplies,
        },
      );

      // update inventory device
      let bulkOps = [];
      const curInventoryWarehouseOld =
        await this.inventoryRepository.findOneByCondition({
          assetId: deviceExist.deviceGroupId,
          warehouseId: deviceExist.warehouseId,
        });
      const curInventoryWarehouseUpdate =
        await this.inventoryRepository.findOneByCondition({
          assetId: deviceUpdate.deviceGroupId,
          warehouseId: deviceUpdate.warehouseId,
        });
      if (
        deviceExist.warehouseId &&
        deviceUpdate.warehouseId &&
        deviceExist.warehouseId.toString() !==
          deviceUpdate.warehouseId.toString()
      ) {
        bulkOps = [
          { inventory: curInventoryWarehouseOld, device: deviceExist },
          { inventory: curInventoryWarehouseUpdate, device: deviceUpdate },
        ].map((el, index) => {
          const stockQuantity =
            index === 0
              ? minus(el.inventory?.stockQuantity || 0, 1)
              : plus(el.inventory?.stockQuantity || 0, 1);
          return {
            updateOne: {
              filter: {
                assetId: el.device.deviceGroupId,
                warehouseId: el.device.warehouseId,
              },
              update: {
                assetId: el.device.deviceGroupId,
                warehouseId: el.device.warehouseId,
                assetType: ASSET_INVENTORY_ENUM.DEVICE_GROUP,
                stockQuantity: stockQuantity > 0 ? stockQuantity : 0,
              },
              upsert: true,
            },
          };
        });
      } else if (deviceExist.warehouseId && !deviceUpdate.warehouseId) {
        const stockQuantity = minus(
          curInventoryWarehouseOld?.stockQuantity || 0,
          1,
        );

        bulkOps = [
          {
            updateOne: {
              filter: {
                assetId: deviceExist.deviceGroupId,
                warehouseId: deviceExist.warehouseId,
              },
              update: {
                assetId: deviceExist.deviceGroupId,
                warehouseId: deviceExist.warehouseId,
                assetType: ASSET_INVENTORY_ENUM.DEVICE_GROUP,
                stockQuantity: stockQuantity > 0 ? stockQuantity : 0,
              },
              upsert: true,
            },
          },
        ];
      } else if (!deviceExist.warehouseId && deviceUpdate.warehouseId) {
        const stockQuantity = plus(
          curInventoryWarehouseUpdate?.stockQuantity || 0,
          1,
        );
        bulkOps = [
          {
            updateOne: {
              filter: {
                assetId: deviceUpdate.deviceGroupId,
                warehouseId: deviceUpdate.warehouseId,
              },
              update: {
                assetId: deviceUpdate.deviceGroupId,
                warehouseId: deviceUpdate.warehouseId,
                assetType: ASSET_INVENTORY_ENUM.DEVICE_GROUP,
                stockQuantity: stockQuantity,
              },
              upsert: true,
            },
          },
        ];
      }
      await this.inventoryRepository.bulkWrite(bulkOps);

      await this.deviceRepository.findByIdAndUpdate(data['id'], deviceUpdate);
      if (code)
        await this.deviceGroupCountService.update(
          data.deviceGroupId,
          plus(count, 1),
        );

      await this.historyRepository.logHistoryForDocuments(
        [{ oldObject: deviceExist, newObject: deviceUpdate }],
        HISTORY_REF_ENUM.DEVICE,
        request.userId,
      );

      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } catch (err) {
      console.error(err);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }
  }

  async delete(request: IdParamDto): Promise<ResponsePayload<any>> {
    try {
      const document = await this.deviceRepository.findOneByCondition({
        ...request.permissionCondition,
        _id: request.id,
      });

      if (!document) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      this.deviceRepository.softDelete(request.id);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async detail(request: IdParamDto): Promise<ResponsePayload<any>> {
    const device = await this.deviceRepository.findOneWithPopulate(
      { ...request.permissionCondition, _id: request.id },
      [
        {
          path: 'vendor warehouse area deviceType deviceName originWarehouse maintenanceTemplate',
        },
        { path: 'supplies.supply', populate: 'supplyType' },
        {
          path: 'deviceGroup',
          populate: [
            {
              path: 'installationTemplate accreditationTemplate articleDeviceGroup maintenanceTemplate maintenanceIndex.supply attributeTypes deviceType',
            },
            { path: 'supplies.supply', populate: 'supplyType' },
          ],
        },
        {
          path: 'histories',
          populate: [
            {
              path: 'oldObjectValue newObjectValue reason.reason',
            },
          ],
        },
      ],
    );

    if (!device) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    device['unit'] = await this.itemService.getUnitById(device?.unitId);
    const userIds = [];
    const factoryIds = [device?.factoryId, device?.originFactoryId];
    device?.['histories']?.forEach((e) => {
      userIds.push(e.createdBy);
      if (
        e.valueField === FIELDS_LOG_HISTORY.FACTORY_ID ||
        e.valueField === FIELDS_LOG_HISTORY.ORIGIN_FACTORY_ID
      ) {
        factoryIds.push(+e.oldValue, +e.newValue);
      }
    });
    const users = await this.userService.getList([
      { column: 'userIds', text: uniq(userIds).join(',') },
    ]);
    const userMap = keyBy(users, 'id');
    const factories = await this.userService.getFactoryList([
      {
        column: 'factoryIds',
        text: uniq(factoryIds),
      },
    ]);
    const factoryMap = keyBy(factories, 'id');
    device['factory'] = factoryMap[device?.factoryId];
    device['originFactory'] = factoryMap[device?.originFactoryId];

    const maintenanceIndex =
      await this.maintenanceIndexRepository.findOneByCondition({
        deviceId: device._id,
        supplyId: null,
      });
    const templateSchedule =
      await this.deviceTemplateScheduleRepository.findOneByCondition({
        deviceId: device._id,
      });
    const maintenanceDateLatest = getLastDateOfDevice(device, 'maintenance');
    const accreditationDateLatest = getLastDateOfDevice(
      device,
      'accreditation',
    );
    const maintenanceDateNext =
      minBy(templateSchedule?.maintain, 'nextSchedule')?.nextSchedule || '';

    const accreditationDateNext = templateSchedule?.accreditation?.nextSchedule;
    if (maintenanceIndex) {
      maintenanceIndex['maintenanceDateLatest'] = maintenanceDateLatest;
      maintenanceIndex['maintenanceDateNext'] = maintenanceDateNext;
      maintenanceIndex['accreditationDateLatest'] = accreditationDateLatest;
      maintenanceIndex['accreditationDateNext'] = accreditationDateNext;
      device['maintenanceIndex'] = maintenanceIndex;
    } else {
      device['maintenanceIndex'] = null;
    }
    device['deviceType'] = device['deviceGroup']['deviceType'];
    device.lastMaintenanceDate = maintenanceDateLatest;
    device.lastAccreditationDate = accreditationDateLatest;
    // add histories for device
    const systemName = await this.i18n.translate('text.SYSTEM_NAME');
    const system = {
      id: 0,
      username: systemName,
      fullname: systemName,
    };
    device['histories']?.forEach((e) => {
      if (
        e.valueField === FIELDS_LOG_HISTORY.FACTORY_ID ||
        e.valueField === FIELDS_LOG_HISTORY.ORIGIN_FACTORY_ID
      ) {
        e.oldObjectValue = factoryMap[e.oldValue?.toString()];
        e.newObjectValue = factoryMap[e.newValue?.toString()];
      }
      e.createdBy = userMap[e.createdBy?.toString()] ?? system;
    });

    const historyGroupMap = groupBy(
      device['histories'],
      (e) => e.createdAt.toString() + e.createdBy.id,
    );
    const newHistories = [];
    Object.values(historyGroupMap).forEach((e) => {
      const historyDetail = first(e);
      newHistories.unshift({ ...historyDetail, contents: e });
    });
    const dataReturn = plainToInstance(
      DetailDeviceResponse,
      { ...device, histories: newHistories },
      { excludeExtraneousValues: true },
    );

    dataReturn.imageUrl = dataReturn.imageUrl
      ? `${this.fileUri}${dataReturn.imageUrl}`
      : '';

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async import(
    data: any,
    user: any,
  ): Promise<{ dataSuccess: any; dataError: any[] }> {
    const dataToInsert = [];
    const dataToUpdate = [];
    const factoryCodes = [];
    const areaCodes = [null];
    const deviceNameCodes = [];
    const vendorCodes = [null];
    const deviceGroupCodes = [];
    const deviceTypeCodes = [null];
    const warehouseCodes = [null];
    const codesUpdate = [null];
    const textAdd = await this.i18n.translate('import.common.add');
    const insertDeviceKeyPairs: any[] = [{ _id: null }];
    data.forEach((item) => {
      factoryCodes.push(item.factoryCode);
      deviceNameCodes.push(item.deviceNameCode);
      areaCodes.push(item.areaCode);
      vendorCodes.push(item.vendorCode);
      deviceGroupCodes.push(item.deviceGroupCode);
      deviceTypeCodes.push(item.deviceTypeCode);
      warehouseCodes.push(item.warehouseCode);

      if (item.action === textAdd) {
        dataToInsert.push(item);
        insertDeviceKeyPairs.push({
          serial: item.serial,
          identificationNo: item.identificationNo,
        });
      } else {
        dataToUpdate.push(item);
        codesUpdate.push(item.code);
      }
    });
    // validate
    const factories = await this.userService.getFactoryList([
      {
        column: 'codes',
        text: compact(uniq(factoryCodes)),
      },
    ]);
    const factoryMap = keyBy(factories, 'code');

    const areas = await this.areaRepository.findAllByCondition({
      code: { $in: compact(uniq(areaCodes)) },
    });
    const areaMap = keyBy(areas, 'code');

    const deviceNames = await this.deviceNameRepository.findAllByCondition({
      code: { $in: compact(uniq(deviceNameCodes)) },
    });
    const deviceNameMap = keyBy(deviceNames, 'code');

    const vendors = await this.vendorRepository.findAllByCondition({
      code: { $in: compact(uniq(vendorCodes)) },
    });
    const vendorMap = keyBy(vendors, 'code');

    const deviceGroups = await this.deviceGroupRepository.findAllWithPopulate(
      {
        code: { $in: compact(uniq(deviceGroupCodes)) },
      },
      { path: 'accreditationTemplate maintenanceTemplate' },
    );
    const deviceGroupMap = keyBy(deviceGroups, 'code');

    const warehouses = await this.warehouseRepository.findAllByCondition({
      code: { $in: compact(uniq(warehouseCodes)) },
    });
    const warehouseMap = keyBy(warehouses, 'code');
    // check unique serial-identificationNo
    const duplicateKeyPairs = getDataDuplicate(
      insertDeviceKeyPairs.map((e) => `${e?.serial}-${e?.identificationNo}`),
    );
    const duplicateKeyPairMap: any = {};
    duplicateKeyPairs.forEach((e) => (duplicateKeyPairMap[e] = ''));
    const deviveExists = await this.deviceRepository.findAllByCondition({
      $or: insertDeviceKeyPairs,
    });
    deviveExists.forEach(
      (e) => (duplicateKeyPairMap[`${e.serial}-${e.identificationNo}`] = ''),
    );
    // end

    const deviceCodeUpdateExists =
      await this.deviceRepository.findAllByCondition({
        code: {
          $in: codesUpdate,
        },
      });

    const deviceUpdateMap = keyBy(deviceCodeUpdateExists, 'code');

    const dataError = [];
    const dataInsert = [];
    const dataUpdate = [];
    const checkCode = (arrMap, checkCode: string, factoryId?: number) =>
      checkCode
        ? !has(arrMap, checkCode) ||
          (factoryId && arrMap[checkCode].factoryId !== factoryId)
        : false;
    const isInvalidData = (item) => {
      return (
        !has(factoryMap, item.factoryCode) ||
        !has(deviceNameMap, item.deviceNameCode) ||
        !has(deviceGroupMap, item.deviceGroupCode) ||
        checkCode(vendorMap, item.vendorCode) ||
        checkCode(areaMap, item.areaCode, factoryMap[item.factoryCode]?.id) ||
        checkCode(
          warehouseMap,
          item.warehouseCode,
          factoryMap[item.factoryCode]?.id,
        ) ||
        (item.creationDate &&
          !moment(item.creationDate, DATE_FORMAT_IMPORT).isValid()) ||
        (item.manufactureDate &&
          !moment(item.manufactureDate, DATE_FORMAT_IMPORT).isValid()) ||
        !moment(item.initAccreditationDate, DATE_FORMAT_IMPORT).isValid() ||
        !moment(item.initMaintenanceDate, DATE_FORMAT_IMPORT).isValid()
      );
    };
    const countDevices =
      await this.deviceGroupCountService.countDeviceByDeviceGroupIds(
        deviceGroups.map((e) => e._id.toString()),
      );

    const countDeviceMap = keyBy(countDevices, 'deviceGroupId');
    const indexByDeviceGroup = {};

    dataToInsert.forEach((item) => {
      const key = deviceGroupMap[item.deviceGroupCode]?._id?.toString();
      const currCount = countDeviceMap[key]?.count;
      if (!has(indexByDeviceGroup, key))
        indexByDeviceGroup[key] = currCount || 0;
      if (
        has(duplicateKeyPairMap, `${item.serial}-${item.identificationNo}`) ||
        isInvalidData(item) ||
        (user.role !== ROLE.ADMIN && !user.factoryIds?.includes(item.factoryId))
      ) {
        dataError.push(item);
      } else {
        const key = deviceGroupMap[item.deviceGroupCode]?._id?.toString();
        let code: number | string = countDeviceMap[key]?.count;
        if (code < DEVICE_CONST.CODE.NUMBER_PAD) {
          code = plus(indexByDeviceGroup[key], 1)
            .toString()
            .padStart(
              DEVICE_CONST.CODE.MAX_LENGTH_PAD,
              DEVICE_CONST.CODE.NUMBER_PAD_STRING,
            );
        }
        item.code = `${
          deviceGroupMap[item.deviceGroupCode]?.symbol || ''
        }${code}`;
        indexByDeviceGroup[key] = plus(indexByDeviceGroup[key], 1);
        item.maintenanceTemplateId =
          deviceGroupMap[item.deviceGroupCode]?.maintenanceTemplateId;
        dataInsert.push(item);
      }
    });

    dataToUpdate.forEach((item) => {
      if (!has(deviceUpdateMap, item.code) || isInvalidData(item)) {
        dataError.push(item);
      } else {
        dataUpdate.push(item);
      }
    });
    const textRent = await this.i18n.translate('import.device.rent');
    const bulkInserts = dataInsert.map((doc) => {
      return {
        insertOne: {
          document: {
            ...doc,
            manufactureDate: doc.manufactureDate
              ? moment(doc.manufactureDate, DATE_FORMAT_IMPORT).toDate()
              : null,
            creationDate: doc.creationDate
              ? moment(doc.creationDate, DATE_FORMAT_IMPORT).toDate()
              : null,
            manufacturer: doc.brand,
            assetType:
              doc.type === textRent
                ? ASSET_TYPE_ENUM.RENT
                : ASSET_TYPE_ENUM.BUY,
            factoryId: factoryMap[doc.factoryCode]?.id,
            originFactoryId: factoryMap[doc.factoryCode]?.id,
            name: deviceNameMap[doc.deviceNameCode].name,
            deviceNameId: deviceNameMap[doc.deviceNameCode]?._id,
            areaId: areaMap[doc.areaCode]?._id,
            vendorId: vendorMap[doc.vendorCode]?._id,
            deviceGroupId: deviceGroupMap[doc.deviceGroupCode]?._id,
            deviceTypeId: deviceGroupMap[doc.deviceGroupCode]?.deviceTypeId,
            warehouseId: warehouseMap[doc.warehouseCode]?._id,
            supplies: deviceGroupMap[doc.deviceGroupCode]?.supplies,
            initAccreditationDate: moment(
              doc.initAccreditationDate,
              DATE_FORMAT_IMPORT,
            ).toDate(),
            initMaintenanceDate: moment(
              doc.initMaintenanceDate,
              DATE_FORMAT_IMPORT,
            ).toDate(),
            status: DEVICE_STATUS_ENUM.PREVENTIVE,
          },
        },
      };
    });
    const bulkUpdates = dataUpdate.map((doc) => {
      const deviceExist = deviceUpdateMap[doc.code];
      const initAccreditationDate =
        deviceExist.initAccreditationDate ??
        moment(doc.initAccreditationDate, DATE_FORMAT_IMPORT).toDate();
      const initMaintenanceDate =
        deviceExist.initMaintenanceDate ??
        moment(doc.initMaintenanceDate, DATE_FORMAT_IMPORT).toDate();

      return {
        updateOne: {
          filter: {
            code: doc.code,
            deviceGroupId: deviceGroupMap[doc.deviceGroupCode],
          },
          update: {
            ...doc,
            manufactureDate: doc.manufactureDate
              ? moment(doc.manufactureDate, DATE_FORMAT_IMPORT).toDate()
              : null,
            creationDate: doc.creationDate
              ? moment(doc.creationDate, DATE_FORMAT_IMPORT).toDate()
              : null,
            manufacturer: doc.brand,
            assetType:
              doc.type === textRent
                ? ASSET_TYPE_ENUM.RENT
                : ASSET_TYPE_ENUM.BUY,
            factoryId: factoryMap[doc.factoryCode]?.id,
            name: deviceNameMap[doc.deviceNameCode].name,
            deviceNameId: deviceNameMap[doc.deviceNameCode]?._id,
            areaId: areaMap[doc.areaCode]?._id ?? null,
            vendorId: vendorMap[doc.vendorCode]?._id ?? null,
            deviceTypeId: deviceGroupMap[doc.deviceGroupCode]?.deviceTypeId,
            warehouseId: warehouseMap[doc.warehouseCode]?._id ?? null,
            initAccreditationDate,
            initMaintenanceDate,
          },
          upsert: false,
        },
      };
    });
    let inventoryUpdateKeyPairs = [];
    const objectPairs = [];
    bulkUpdates.forEach((e) => {
      objectPairs.push({
        oldObject: deviceUpdateMap[e.updateOne.filter.code],
        newObject: e.updateOne.update,
      });
      inventoryUpdateKeyPairs.push(
        {
          deviceGroupId:
            deviceUpdateMap[e.updateOne.filter.code]?.deviceGroupId,
          warehouseId: deviceUpdateMap[e.updateOne.filter.code]?.warehouseId,
        },
        {
          deviceGroupId:
            deviceUpdateMap[e.updateOne.filter.code]?.deviceGroupId,
          warehouseId: e.updateOne.update?.warehouseId,
        },
      );
    });
    const dataSuccess = await this.deviceRepository.bulkWrite(bulkUpdates);
    const deviceInserted = await this.deviceRepository.bulkWrite(bulkInserts);

    // update template for newObject
    const newObjects = await this.deviceRepository.findAllWithPopulate(
      { _id: { $in: deviceInserted.result?.insertedIds } },
      [
        {
          path: 'deviceGroup',
          populate: 'accreditationTemplate maintenanceTemplate',
        },
      ],
    );

    newObjects?.forEach((e) => {
      objectPairs.push({ oldObject: null, newObject: e });
      inventoryUpdateKeyPairs.push({
        deviceGroupId: e?.deviceGroupId,
        warehouseId: e?.warehouseId,
      });
    });
    // update inventory
    inventoryUpdateKeyPairs = inventoryUpdateKeyPairs.filter((el) => {
      return el.deviceGroupId && el.warehouseId;
    });
    if (!isEmpty(inventoryUpdateKeyPairs)) {
      const deviceInventories = await this.deviceRepository.findAllByCondition({
        $or: inventoryUpdateKeyPairs,
      });
      const inventoriesUpdate = countBy(
        deviceInventories,
        (el) => `${el.deviceGroupId}-${el.warehouseId}`,
      );
      const bulkInventory = inventoryUpdateKeyPairs.map((el) => {
        const inventoryCur =
          inventoriesUpdate[`${el.deviceGroupId}-${el.warehouseId}`];
        return {
          updateOne: {
            filter: {
              assetId: el.deviceGroupId,
              warehouseId: el.warehouseId,
            },
            update: {
              assetType: ASSET_INVENTORY_ENUM.DEVICE_GROUP,
              stockQuantity: inventoryCur ?? 0,
            },
            upsert: true,
          },
        };
      });
      await this.inventoryRepository.bulkWrite(bulkInventory);
    }
    // log history
    await this.historyRepository.logHistoryForDocuments(
      objectPairs,
      HISTORY_REF_ENUM.DEVICE,
      user.id,
    );
    await this.addTemplateForNewObject(newObjects);
    const deviceGroupUpdate = countDevices.map((doc) => ({
      updateOne: {
        filter: {
          deviceGroupId: doc.deviceGroupId,
        },
        update: {
          ...doc,
          count:
            indexByDeviceGroup[doc.deviceGroupId.toString()] > 0
              ? indexByDeviceGroup[doc.deviceGroupId.toString()]
              : doc.count,
        },
        upsert: false,
      },
    }));

    await this.deviceGroupCountRepository.bulkWrite(deviceGroupUpdate);
    return {
      dataSuccess: {
        nMatched: dataSuccess.result.nMatched,
        nUpserted: deviceInserted.result.nInserted,
      },
      dataError,
    };
  }

  private async addTemplateForNewObject(newObjects: Device[]) {
    const bulkOps = [];
    const bulkOpsDevice = [];
    const lastAccreditationDate = new Date();
    const lastMaintenanceDate = new Date();
    // tính thông báo trước bao nhiêu ngày
    const checkBeforeDateForMaintain = await this.settingService.getDateSetting(
      JOB_TYPE_ENUM.MAINTAIN,
      SETTING_JOB_PERIOD_ENUM.LESS_THAN_THREE_MONTH,
    );
    const checkBeforeDateForChecklist =
      await this.settingService.getDateSetting(
        JOB_TYPE_ENUM.PERIOD_CHECKLIST,
        SETTING_JOB_PERIOD_ENUM.LESS_THAN_THREE_MONTH,
      );
    const checkBeforeDateForAccreditation =
      await this.settingService.getDateSetting(
        JOB_TYPE_ENUM.ACCREDITATION,
        SETTING_JOB_PERIOD_ENUM.MORE_THAN_THREE_MONTH,
      );

    const jobConfiguration = await this.settingJobRepository.findAllByCondition(
      {
        type: {
          $in: [
            JOB_TYPE_ENUM.ACCREDITATION,
            JOB_TYPE_ENUM.PERIOD_CHECKLIST,
            JOB_TYPE_ENUM.MAINTAIN,
          ],
        },
      },
    );
    newObjects.forEach((device) => {
      const deviceGroup = device['deviceGroup'];
      const maintenanceTemplate = deviceGroup?.maintenanceTemplate;
      const accreditationTemplate = deviceGroup?.accreditationTemplate;
      const maintain = [];
      const periodChecklist = [];
      let accreditation = null;
      if (accreditationTemplate) {
        const autoGenerateJobOnSunday = this.getConfigurationGenerateJob(
          jobConfiguration,
          JOB_TYPE_ENUM.ACCREDITATION,
        );
        accreditation = {
          templateId: accreditationTemplate._id,
          title: accreditationTemplate.name,
          lastSchedule: lastAccreditationDate,
          periodic: accreditationTemplate.periodic,
          activeTime: accreditationTemplate.activeTime,
          nextSchedule: getNextDateCreateJob(
            checkBeforeDateForAccreditation,
            accreditationTemplate.periodic,
            lastAccreditationDate,
            autoGenerateJobOnSunday,
          ),
        };
      }
      if (maintenanceTemplate) {
        const autoGenerateJobChecklistOnSunday =
          this.getConfigurationGenerateJob(
            jobConfiguration,
            JOB_TYPE_ENUM.PERIOD_CHECKLIST,
          );
        const autoGenerateJobMaintainOnSunday =
          this.getConfigurationGenerateJob(
            jobConfiguration,
            JOB_TYPE_ENUM.MAINTAIN,
          );
        maintenanceTemplate?.details?.forEach((e) => {
          if (e.type === MAINTENANCE_JOB_TYPE.CHECK) {
            periodChecklist.push({
              templateId: e.checklistTemplateId,
              title: e.title,
              periodic: e.periodTime,
              activeTime: e.activeTime,
              obligatory: e.obligatory,
              nextSchedule: getNextDateCreateJob(
                checkBeforeDateForChecklist,
                e.periodTime,
                lastMaintenanceDate,
                autoGenerateJobChecklistOnSunday,
              ),
              lastSchedule: lastMaintenanceDate,
            });
          } else if (e.type === MAINTENANCE_JOB_TYPE.MAINTENANCE) {
            maintain.push({
              templateId: e['_id'],
              title: e.title,
              periodic: e.periodTime,
              activeTime: e.activeTime,
              obligatory: e.obligatory,
              nextSchedule: getNextDateCreateJob(
                checkBeforeDateForMaintain,
                e.periodTime,
                lastMaintenanceDate,
                autoGenerateJobMaintainOnSunday,
              ),
              lastSchedule: lastMaintenanceDate,
            });
          }
        });
      }
      bulkOps.push({
        updateOne: {
          filter: { deviceId: device._id },
          update: {
            $set: {
              deviceId: device._id,
              periodChecklist,
              maintain,
              accreditation,
            },
          },
          upsert: true,
        },
      });
      bulkOpsDevice.push({
        updateOne: {
          filter: { _id: device._id },
          update: {
            $set: {
              accreditationTemplateId: accreditationTemplate._id ?? null,
              maintenanceTemplateId: maintenanceTemplate?._id ?? null,
            },
          },
          upsert: false,
        },
      });
    });
    await this.deviceRepository.bulkWrite(bulkOpsDevice);
    await this.deviceTemplateScheduleRepository.bulkWrite(bulkOps);
  }

  async getSuppliesByDevice(
    request: IdParamDto,
  ): Promise<ResponsePayload<any>> {
    const device = await this.deviceRepository.findOneWithPopulate(
      { _id: request.id },
      {
        path: 'deviceGroup',
        populate: { path: 'supplies.supply' },
      },
    );

    const supplies = device['deviceGroup']?.supplies || [];

    const dataReturn = plainToInstance(SupplyByDeviceResponse, supplies, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async scan(request: ScanDeviceParamDto): Promise<ResponsePayload<any>> {
    const device = await this.deviceRepository.findOneWithPopulate(
      { code: request.code },
      [
        { path: 'vendor warehouse area' },
        {
          path: 'deviceGroup',
          populate: {
            path: 'supplies.supply installationTemplate accreditationTemplate articleDeviceGroup maintenanceTemplate maintenanceIndex.supply errorTypes',
          },
        },
      ],
    );

    if (!device) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const factory = await this.userService.getFactoryById(device.factoryId);
    if (factory) {
      device['factory'] = factory;
    }
    const maintenanceIndex =
      await this.maintenanceIndexRepository.findOneByCondition({
        deviceId: device._id,
        supplyId: null,
      });
    const templateSchedule =
      await this.deviceTemplateScheduleRepository.findOneByCondition({
        deviceId: device._id,
      });

    if (maintenanceIndex) {
      maintenanceIndex['maintenanceDateLatest'] = maxBy(
        templateSchedule?.maintain,
        'lastSchedule',
      )?.lastSchedule;
      maintenanceIndex['maintenanceDateNext'] = minBy(
        templateSchedule?.maintain,
        'nextSchedule',
      )?.nextSchedule;
      maintenanceIndex['accreditationDateLatest'] =
        templateSchedule?.accreditation?.lastSchedule;
      maintenanceIndex['accreditationDateLatest'] =
        templateSchedule?.accreditation?.nextSchedule;
      device['maintenanceIndex'] = maintenanceIndex;
    } else {
      device['maintenanceIndex'] = null;
    }

    const dataReturn = plainToInstance(ScanDeviceResponseDto, device, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getActivities(
    request: GetDeviceActivityHistoryRequestDto & IdParamDto,
  ): Promise<ResponsePayload<any>> {
    const deviceStatuses =
      await this.deviceStatusRepository.findAllWithPopulate(
        { deviceId: request.id },
        {
          path: 'attributeTypes.attributeTypeId',
        },
        request.skip,
        request.limit,
        { startTime: -1 },
      );

    const userIds = uniq(map(deviceStatuses, 'createdBy'));
    const users = await this.userService.getList([
      { column: 'userIds', text: userIds.join(',') },
    ]);
    const userMap = keyBy(users, 'id');

    const result = deviceStatuses.map((deviceStatus) => ({
      ...deviceStatus,
      createdBy: userMap[deviceStatus.createdBy],
    }));

    const dataReturn = plainToInstance(
      DeviceActivityHistoryResponseDto,
      result,
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async maintenanceInfo(request: IdParamDto): Promise<ResponsePayload<any>> {
    const device = await this.deviceRepository.findOneByCondition({
      _id: request.id,
    });

    if (!device) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const maintenanceIndexes =
      await this.maintenanceIndexRepository.findAllByCondition({
        deviceId: request.id,
      });
    if (isEmpty(maintenanceIndexes)) {
      return new ResponseBuilder<any>({
        items: [],
        meta: { page: 1, total: 0 },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const templateSchedule =
      await this.deviceTemplateScheduleRepository.findOneByCondition({
        deviceId: request.id,
      });

    const job = await this.jobRepository.findOneByCondition({
      deviceId: request.id,
      type: JOB_TYPE_ENUM.MAINTAIN,
      status: JOB_STATUS_ENUM.RESOLVED,
    });

    const supplyIds = compact(uniq(map(maintenanceIndexes, 'supplyId')));
    const supplies = await this.supplyRepository.findAllByCondition({
      id: {
        $in: supplyIds,
      },
    });
    const supplyMap = keyBy(supplies, '_id');

    const result = [];
    maintenanceIndexes.forEach((maintenanceIndex) => {
      if (!maintenanceIndex.supplyId) {
        result.push({
          asset: {
            id: maintenanceIndex.supplyId || maintenanceIndex.deviceId,
            type: maintenanceIndex.supplyId
              ? ASSET_MAINTENANCE_TYPE_ENUM.SUPPLY
              : ASSET_MAINTENANCE_TYPE_ENUM.DEVICE,
            name: maintenanceIndex.supplyId
              ? has(supplyMap, maintenanceIndex.supplyId)
                ? supplyMap[maintenanceIndex.supplyId].name
                : ''
              : device.name,
          },
          planDate:
            minBy(templateSchedule?.maintain, 'nextSchedule')?.nextSchedule ||
            device.createdAt,
          planDateByMtbf: (job?.updatedAt
            ? moment(job?.updatedAt)
            : moment(device.createdAt)
          )
            .add(maintenanceIndex.mtbf, 'hour')
            .toDate(),
          planDateByMttf: (job?.updatedAt
            ? moment(job?.updatedAt)
            : moment(device.createdAt)
          )
            .add(maintenanceIndex.mttf, 'hour')
            .toDate(),
          mttr: maintenanceIndex.mttr,
          mtta: maintenanceIndex.mtta,
        });
      }
    });

    const dataResult = plainToInstance(MaintenanceInfoResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder({ items: dataResult })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async generateDeviceQrCode(
    request: GenerateDeviceQrCodeRequest,
  ): Promise<any> {
    const deviceCodes = request.items.map((item) => item.code);

    const devices = await this.deviceRepository.findAllByCondition({
      code: { $in: deviceCodes },
    });

    if (!devices.length) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const quantityByCode = new Map();
    request.items.forEach((e) => {
      quantityByCode.set(e.code, e.quantity);
    });

    let responseString = '';

    devices.forEach((e) => {
      const quantityQrCode = quantityByCode.get(e.code) || 0;
      for (let i = 0; i < quantityQrCode; i++) {
        const capitalisation = e?.capitalizationDate
          ? moment(e?.capitalizationDate).format('yyyy')
          : moment(e?.createdAt).format('yyyy');
        const str = `
        ^XA
        ^FX--title--^FS
          ^CFZN,1,45
          ^CI28
          ^LH0,0^FS
          ^A@N,70,70,E:SOU000.TTF
          ^FO90,80
          ^FB900,2,0,L^FH
          ^FD${e.name}^FS

          ^FX--QRCode--^FS
          ^FO800,250          
          ^BQN,2,20,80^FDLA
          ^FDQA,${e.code}^FS
        
        ^FX--Nội dung--^FS
          ^CI28
          ^FO90,250
          ^A@N,55,55,E:SOU000.TTF
          ^FB$700,2,0,L,0
          ^FDModel: ${e?.model}^FS

          ^FO90,380
          ^A@N,55,55,E:SOU000.TTF
          ^FB$900,1,0,L,0
          ^FDNăm SD: ${capitalisation}^FS

          ^FO90,460
          ^A@N,55,55,E:SOU000.TTF
          ^FB$700,3,0,L,0
          ^FDSố máy: ${e?.actualSerial ?? e?.serial}^FS
        ^FX--border box--^FS  
          ^FO10,10^GB1200,600,10^FS
        ^XZ`;
        responseString += str;
      }
    });

    return new ResponseBuilder(responseString)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  private async updateWarehouseInventoryWhenCreateDevice(data) {
    const curInventory = await this.inventoryRepository.findOneByCondition({
      assetId: data.deviceGroupId,
      warehouseId: data.warehouseId,
    });
    const stockQuantity = plus(curInventory?.stockQuantity || 0, 1);
    const bulkOps = [
      {
        updateOne: {
          filter: {
            assetId: data.deviceGroupId,
            warehouseId: data.warehouseId,
          },
          update: {
            assetId: data.deviceGroupId,
            warehouseId: data.warehouseId,
            assetType: ASSET_INVENTORY_ENUM.DEVICE_GROUP,
            maxStockQuantity:
              curInventory?.maxStockQuantity || MIN_STOCK_INVENTORY,
            minStockQuantity:
              curInventory?.minStockQuantity || MIN_STOCK_INVENTORY,
            stockQuantity: stockQuantity,
          },
          upsert: true,
        },
      },
    ];
    await this.inventoryRepository.bulkWrite(bulkOps);
  }
}
