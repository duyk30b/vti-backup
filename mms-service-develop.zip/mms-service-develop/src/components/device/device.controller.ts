import {
  Controller,
  Injectable,
  Inject,
  Body,
  Query,
  Param,
  Post,
  Put,
  Get,
  Delete,
  UseInterceptors,
} from '@nestjs/common';
import { isEmpty } from 'lodash';
import { GetListDevicesRequestDto } from '@components/device/dto/request/list-devices.request.dto';
import { DeviceServiceInterface } from '@components/device/interface/device.service.interface';
import { CreateDeviceFormData } from '@components/device/dto/request/create-device.request.dto';
import { UpdateDeviceRequestDto } from '@components/device/dto/request/update-device.request.dto';
import { ApiConsumes, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { GetListDevicesResponseDto } from './dto/response/get-list-devices.response.dto';
import {
  CREATE_DEVICE_PERMISSION,
  DETAIL_DEVICE_PERMISSION,
  LIST_DEVICE_PERMISSION,
  UPDATE_DEVICE_PERMISSION,
  UPDATE_LOCATION_DEVICE_PERMISSION,
  UPDATE_STATUS_DEVICE_PERMISSION,
} from '@utils/permissions/device';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateStatusDeviceRequestDto } from './dto/request/update-status-device.request.dto';
import { UpdateLocationDeviceBodyDto } from './dto/request/update-location-device.request.dto';
import { ScanDeviceParamDto } from './dto/request/scan-device.param.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { DetailDeviceResponse } from './dto/response/detail-device.response';
import { GetDeviceActivityHistoryRequestDto } from './dto/request/get-device-activity-history.request.dto';
import { DeviceActivityHistoryResponseDto } from './dto/response/device-activity-history.response.dto';
import { GenerateDeviceQrCodeResponse } from './dto/response/generate-device-qr-code.response.dto';
import { GenerateDeviceQrCodeRequest } from './dto/request/generate-device-qr-code.request.dto';
import { MaintenanceInfoResponseDto } from './dto/response/maintenance-info.response';
import { mergePayload } from '@utils/common';
import { PermissionInterceptor } from '@core/interceptors/permission.interceptor';
import {
  CREATE_DEVICE_ASSIGNMENT_PERMISSION,
  UPDATE_DEVICE_ASSIGNMENT_PERMISSION,
} from '@utils/permissions/device-assignment';
import {
  CREATE_MAINTENANCE_PLAN_PERMISSION,
  UPDATE_MAINTENANCE_PLAN_PERMISSION,
} from '@utils/permissions/maintenance-plan';
import { CREATE_REPAIR_REQUEST_PERMISSION } from '@utils/permissions/repair-request';
import {
  CREATE_WAREHOUSE_IMPORT_PERMISSION,
  UPDATE_WAREHOUSE_IMPORT_PERMISSION,
} from '@utils/permissions/warehouse-import';
import {
  CREATE_UPDATE_INVENTORY_PERMISSION,
  UPDATE_UPDATE_INVENTORY_PERMISSION,
} from '@utils/permissions/update-inventory-ticket';
import {
  CREATE_TRANSFER_TICKET_PERMISSION,
  UPDATE_TRANSFER_TICKET_PERMISSION,
} from '@utils/permissions/transfer-ticket';
import { DETAIL_DEVICE_STATUS_PERMISSION } from '@utils/permissions/device-status';

@Injectable()
@Controller('devices')
export class DeviceController {
  constructor(
    @Inject('DeviceServiceInterface')
    private readonly deviceService: DeviceServiceInterface,
  ) {}

  @PermissionCode(
    LIST_DEVICE_PERMISSION.code,
    UPDATE_DEVICE_ASSIGNMENT_PERMISSION.code,
    CREATE_DEVICE_ASSIGNMENT_PERMISSION.code,
    CREATE_MAINTENANCE_PLAN_PERMISSION.code,
    UPDATE_MAINTENANCE_PLAN_PERMISSION.code,
    CREATE_REPAIR_REQUEST_PERMISSION.code,
    CREATE_WAREHOUSE_IMPORT_PERMISSION.code,
    UPDATE_WAREHOUSE_IMPORT_PERMISSION.code,
    CREATE_UPDATE_INVENTORY_PERMISSION.code,
    UPDATE_UPDATE_INVENTORY_PERMISSION.code,
    UPDATE_TRANSFER_TICKET_PERMISSION.code,
    CREATE_TRANSFER_TICKET_PERMISSION.code,
  )
  @UseInterceptors(PermissionInterceptor)
  @Get('')
  @ApiOperation({
    tags: ['Devices'],
    summary: 'Danh sách thiết bị',
    description: 'Danh sách thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetListDevicesResponseDto,
  })
  async list(@Query() query: GetListDevicesRequestDto): Promise<any> {
    const { request, responseError } = query;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.deviceService.list(request);
  }

  @PermissionCode(CREATE_DEVICE_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Post('')
  @ApiConsumes('multipart/form-data')
  @ApiOperation({
    tags: ['Devices'],
    summary: 'Tạo thiết bị',
    description: 'Tạo thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: Number,
  })
  async create(@Body() payload: CreateDeviceFormData): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.deviceService.create(request);
  }

  @ApiOperation({
    tags: ['Devices'],
    summary: 'Xóa thiết bị',
    description: 'Xóa thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
  })
  @Delete('/:id')
  async delete(@Param() payload: IdParamDto): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.deviceService.delete(request);
  }

  @PermissionCode(DETAIL_DEVICE_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @ApiOperation({
    tags: ['Devices'],
    summary: 'Scan chi tiết thiết bị',
    description: 'Scan chi tiết thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailDeviceResponse,
  })
  @Get('/:code/scan')
  async scan(@Param() payload: ScanDeviceParamDto): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.deviceService.scan(request);
  }

  @PermissionCode(
    DETAIL_DEVICE_PERMISSION.code,
    UPDATE_DEVICE_PERMISSION.code,
    CREATE_REPAIR_REQUEST_PERMISSION.code,
    DETAIL_DEVICE_STATUS_PERMISSION.code,
  )
  @UseInterceptors(PermissionInterceptor)
  @ApiOperation({
    tags: ['Devices'],
    summary: 'Chi tiết thiết bị',
    description: 'Chi tiết thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailDeviceResponse,
  })
  @Get('/:id')
  async detail(@Param() payload: IdParamDto): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.deviceService.detail(request);
  }

  @ApiOperation({
    tags: ['Devices'],
    summary: 'Danh sách vật tư phụ tùng theo thiết bị',
    description: 'Danh sách vật tư phụ tùng theo thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
  })
  @Get('/:id/supplies')
  async getSuppliesByDevice(@Param() payload: IdParamDto): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.deviceService.getSuppliesByDevice(request);
  }

  @PermissionCode(UPDATE_DEVICE_PERMISSION.code, UPDATE_DEVICE_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @ApiOperation({
    tags: ['Devices'],
    summary: 'Sửa thiết bị',
    description: 'Sửa thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  @Put('/:id')
  @ApiConsumes('multipart/form-data')
  async update(
    @Body() payload: UpdateDeviceRequestDto,
    @Param() param: IdParamDto,
  ): Promise<any> {
    const { request, responseError } = mergePayload(payload, param);
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.deviceService.update(request);
  }

  @PermissionCode(UPDATE_STATUS_DEVICE_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @ApiOperation({
    tags: ['Devices'],
    summary: 'Cập nhật trạng thái thiết bị',
    description: 'Cập nhật trạng thái thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  @Put('/:id/:status')
  async updateStatus(
    @Param() param: UpdateStatusDeviceRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.deviceService.updateStatus(request);
  }

  @PermissionCode(UPDATE_LOCATION_DEVICE_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @ApiOperation({
    tags: ['Devices'],
    summary: 'Sửa vị trí thiết bị',
    description: 'Sửa vị trí thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  @Put('/:id/location')
  async updateLocation(
    @Param() param: IdParamDto,
    @Body() body: UpdateLocationDeviceBodyDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    const {
      request: { id },
      responseError: responseParamError,
    } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }

    return await this.deviceService.updateLocation({ ...request, id });
  }

  @UseInterceptors(PermissionInterceptor)
  @ApiOperation({
    tags: ['Devices'],
    summary: 'Lịch sử hoạt động của thiết bị',
    description: 'Lịch sử hoạt động của thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DeviceActivityHistoryResponseDto,
    isArray: true,
  })
  @Get('/:id/activity')
  async getActivities(
    @Param() param: IdParamDto,
    @Query() query: GetDeviceActivityHistoryRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    const { request: parameter, responseError: responseErrorParam } = param;
    if (
      (responseError && !isEmpty(responseError)) ||
      (responseErrorParam && !isEmpty(responseErrorParam))
    ) {
      return responseError || responseErrorParam;
    }

    return await this.deviceService.getActivities({
      id: parameter.id,
      ...request,
    });
  }

  @ApiOperation({
    tags: ['Devices'],
    summary: 'Thông tin bảo trì thiết bị',
    description: 'Thông tin bảo trì thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: MaintenanceInfoResponseDto,
    isArray: true,
  })
  @Get('/:id/maintenance-info')
  async maintenanceInfo(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceService.maintenanceInfo(request);
  }

  @Post('/generate-qr-code')
  @ApiOperation({
    tags: ['Devices'],
    summary: 'Tạo mã qr device code',
    description: 'Tạo mã qr device code',
  })
  @ApiResponse({
    status: 200,
    description: 'Generate successfully',
    type: GenerateDeviceQrCodeResponse,
  })
  async generateDeviceQrCode(
    @Body() payload: GenerateDeviceQrCodeRequest,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceService.generateDeviceQrCode(request);
  }
}
