import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class AssetResponseDto {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  name: string;
}
export class MaintenanceInfoResponseDto {
  @ApiProperty({ type: AssetResponseDto })
  @Type(() => AssetResponseDto)
  @Expose()
  asset: AssetResponseDto;

  @ApiProperty()
  @Expose()
  planDate: Date;

  @ApiProperty()
  @Expose()
  planDateByMtbf: Date;

  @ApiProperty()
  @Expose()
  planDateByMttf: Date;

  @ApiProperty()
  @Expose()
  mttr: number;

  @ApiProperty()
  @Expose()
  mtta: number;
}
