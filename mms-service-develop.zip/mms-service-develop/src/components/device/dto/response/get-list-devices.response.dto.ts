import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { ListDeviceResponse } from './list-device.response';
import { PaginationResponse } from '@utils/dto/response/pagination.response';

export class GetListDevicesResponseDto extends PaginationResponse {
  @ApiProperty({
    type: ListDeviceResponse,
    isArray: true,
  })
  @Expose()
  @Type(() => ListDeviceResponse)
  items: ListDeviceResponse[];
}
