import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { Expose, Transform, Type } from 'class-transformer';
import { first } from 'lodash';
import { DeviceBasicResponseDto } from './device-basic.response.dto';

export class ListDeviceResponse extends DeviceBasicResponseDto {
  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Transform(({ value }) => first(value))
  @Type(() => BasicResponseDto)
  deviceGroup: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Transform(({ value }) => first(value))
  @Type(() => BasicResponseDto)
  vendor: BasicResponseDto;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Expose()
  @Type(() => BasicSqlDocumentResponse)
  factory: BasicSqlDocumentResponse;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Transform(({ value }) => first(value))
  @Type(() => BasicResponseDto)
  warehouse: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Transform(({ value }) => first(value))
  @Type(() => BasicResponseDto)
  area: BasicResponseDto;

  @ApiProperty()
  @Expose()
  model: string;

  @ApiProperty()
  @Expose()
  actualSerial: string;

  @ApiProperty()
  @Expose()
  manufacturer: string;

  @ApiProperty()
  @Expose()
  price: number;

  @ApiProperty()
  @Expose()
  assetType: number;

  @ApiProperty()
  @Expose()
  isFixedAsset: number;

  @ApiProperty()
  @Expose()
  active: number;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  unit: BasicSqlDocumentResponse;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Transform(({ value }) => first(value))
  @Type(() => BasicResponseDto)
  articleDeviceGroup: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Transform(({ value }) => first(value))
  @Type(() => BasicResponseDto)
  deviceType: BasicResponseDto;

  @ApiProperty()
  @Expose()
  @Transform(({ obj }) => obj?.capitalizationDate || obj?.createdAt)
  capitalizationDate: Date;

  @ApiProperty()
  @Expose()
  canCreateTransferTicket: number;
}
