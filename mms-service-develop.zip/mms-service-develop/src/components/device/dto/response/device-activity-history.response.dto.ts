import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class UserDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  username: string;

  @ApiProperty()
  @Expose()
  fullName: string;
}

export class DeviceActivityHistoryResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  startTime: Date;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty({ type: UserDto })
  @Type(() => UserDto)
  @Expose()
  createdBy: UserDto;
}
