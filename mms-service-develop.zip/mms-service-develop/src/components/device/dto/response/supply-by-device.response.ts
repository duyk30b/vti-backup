import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { Expose, plainToInstance, Transform } from 'class-transformer';

export class SupplyByDeviceResponse extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  estimateUsedTime: number;

  @ApiProperty({
    type: BasicResponseDto,
  })
  @Transform(({ obj }) =>
    plainToInstance(BasicResponseDto, obj?.supply, {
      excludeExtraneousValues: true,
    }),
  )
  @Expose()
  supply: BasicResponseDto;
}
