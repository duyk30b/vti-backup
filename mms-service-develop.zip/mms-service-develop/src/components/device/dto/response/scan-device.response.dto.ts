import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { Expose, Transform, Type, plainToInstance } from 'class-transformer';
import { DetailCheckListTemplateResponseDto } from '@components/checklist-template/dto/response/detail-checklist-template.response.dto';
import { DetailInstallationTemplateResponse } from '@components/installation-template/dto/response/detail-installation-template.response';
import { DetailAccreditationTemplateResponseDto } from '@components/accreditation-template/dto/response/detail-accreditation-response.dto';
import { DetailMaintenanceIndexResponse } from '@components/maintenance-index/dto/response/detail-maintenance-index.response';

class DetailSupplyResponse {
  @ApiProperty()
  @Expose()
  @Transform((data) => data.obj.supply._id.toString())
  id: string;

  @ApiProperty()
  @Expose()
  @Transform((data) => data.obj.supply.name)
  name: string;

  @ApiProperty()
  @Expose()
  @Transform((data) => data.obj.supply.code)
  code: string;

  @ApiProperty()
  @Expose()
  @Transform((data) => data.obj.supply.type)
  type: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  estimateUsedTime: number;

  @ApiProperty()
  @Expose()
  canFixable: number;
}

class DetailDeviceGroupResponse extends BasicResponseDto {
  @ApiProperty({
    type: DetailCheckListTemplateResponseDto,
  })
  @Type(() => DetailCheckListTemplateResponseDto)
  @Expose()
  checkListTemplate: DetailCheckListTemplateResponseDto;

  @ApiProperty({
    type: DetailInstallationTemplateResponse,
  })
  @Type(() => DetailInstallationTemplateResponse)
  @Expose()
  installationTemplate: DetailInstallationTemplateResponse;

  @ApiProperty({
    type: DetailAccreditationTemplateResponseDto,
  })
  @Type(() => DetailAccreditationTemplateResponseDto)
  @Expose()
  accreditationTemplate: DetailAccreditationTemplateResponseDto;

  @ApiProperty({ type: BasicResponseDto, isArray: true })
  @Type(() => BasicResponseDto)
  @Expose()
  @Transform(({ obj }) =>
    plainToInstance(BasicResponseDto, obj?.errorTypes, {
      excludeExtraneousValues: true,
    }),
  )
  errorType: BasicResponseDto;

  @ApiProperty({
    type: DetailSupplyResponse,
    isArray: true,
  })
  @Type(() => DetailSupplyResponse)
  @Expose()
  supplies: DetailSupplyResponse[];
}

export class ScanDeviceResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  serial: string;

  @ApiProperty()
  @Expose()
  model: string;

  @ApiProperty()
  @Expose()
  manufacturer: string;

  @ApiProperty()
  @Expose()
  brand: string;

  @ApiProperty()
  @Expose()
  depreciation: number;

  @ApiProperty()
  @Expose()
  price: number;

  @ApiProperty()
  @Expose()
  assetType: number;

  @ApiProperty()
  @Expose()
  warrantyPeriod: number;

  @ApiProperty()
  @Expose()
  isFixedAsset: number;

  @ApiProperty()
  @Expose()
  manufactureDate: Date;

  @ApiProperty()
  @Expose()
  creationDate: Date;

  @ApiProperty()
  @Expose()
  yearOfMake: string;

  @ApiProperty()
  @Expose()
  identificationNo: string;

  @ApiProperty({ type: DetailDeviceGroupResponse })
  @Type(() => DetailDeviceGroupResponse)
  @Expose()
  deviceGroup: DetailDeviceGroupResponse;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Expose()
  @Type(() => BasicSqlDocumentResponse)
  factory: BasicSqlDocumentResponse;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  area: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  vendor: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  warehouse: BasicResponseDto;

  @ApiProperty({ type: DetailMaintenanceIndexResponse })
  @Type(() => DetailMaintenanceIndexResponse)
  @Expose()
  maintenanceIndex: DetailMaintenanceIndexResponse;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  unit: BasicSqlDocumentResponse;

  @ApiProperty()
  @Expose()
  @Transform(({ obj }) => obj?.capitalizationDate || obj?.createdAt)
  capitalizationDate: Date;
}
