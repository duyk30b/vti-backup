import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { Expose, Transform, Type, plainToInstance } from 'class-transformer';
import { DetailCheckListTemplateResponseDto } from '@components/checklist-template/dto/response/detail-checklist-template.response.dto';
import { DetailInstallationTemplateResponse } from '@components/installation-template/dto/response/detail-installation-template.response';
import { DetailAccreditationTemplateResponseDto } from '@components/accreditation-template/dto/response/detail-accreditation-response.dto';
import { DetailErrorTypeResponse } from '@components/error-type/dto/response/detail-error-type.response';
import { DetailMaintenanceIndexResponse } from '@components/maintenance-index/dto/response/detail-maintenance-index.response';
import { SupplyTypeDto } from '@components/supply/dto/response/get-all-supply.response.dto';
import { GetMaintenanceTemplateResponseDto } from '@components/maintenance-template/dto/response/get-maintenance-template.response.dto';
import { GetHistoryDetailResponseDto } from '@components/history/dto/response/get-history-detail.response.dto';
import { DeviceBasicResponseDto } from './device-basic.response.dto';

class DetailSupplyResponse {
  @ApiProperty()
  @Expose()
  @Transform((data) => data.obj.supply._id.toString())
  id: string;

  @ApiProperty()
  @Expose()
  @Transform((data) => data.obj.supply.name)
  name: string;

  @ApiProperty()
  @Expose()
  @Transform((data) => data.obj.supply.nameOther)
  nameOther: string;

  @ApiProperty()
  @Expose()
  @Transform((data) => data.obj.supply.code)
  code: string;

  @ApiProperty()
  @Expose()
  @Transform((data) => data.obj.supply.type)
  type: number;

  @ApiProperty()
  @Expose()
  @Transform(({ obj }) =>
    plainToInstance(SupplyTypeDto, obj?.supply?.supplyType, {
      excludeExtraneousValues: true,
    }),
  )
  supplyType: SupplyTypeDto;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  estimateUsedTime: number;

  @ApiProperty()
  @Expose()
  canFixable: number;
}

class DetailDeviceGroupResponse extends BasicResponseDto {
  @ApiProperty({
    type: DetailCheckListTemplateResponseDto,
  })
  @Type(() => DetailCheckListTemplateResponseDto)
  @Expose()
  checkListTemplate: DetailCheckListTemplateResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Expose()
  deviceType: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Expose()
  articleDeviceGroup: BasicResponseDto;

  @ApiProperty({ type: DetailInstallationTemplateResponse })
  @Type(() => DetailInstallationTemplateResponse)
  @Expose()
  installationTemplate: DetailInstallationTemplateResponse;

  @ApiProperty({ type: DetailAccreditationTemplateResponseDto })
  @Type(() => DetailAccreditationTemplateResponseDto)
  @Expose()
  accreditationTemplate: DetailAccreditationTemplateResponseDto;

  @ApiProperty({ type: GetMaintenanceTemplateResponseDto })
  @Type(() => GetMaintenanceTemplateResponseDto)
  @Expose()
  maintenanceTemplate: GetMaintenanceTemplateResponseDto;

  @ApiProperty({
    type: DetailErrorTypeResponse,
    isArray: true,
  })
  @Type(() => DetailErrorTypeResponse)
  @Expose()
  errorType: DetailErrorTypeResponse[];

  @ApiProperty({
    type: DetailSupplyResponse,
    isArray: true,
  })
  @Type(() => DetailSupplyResponse)
  @Expose()
  supplies: DetailSupplyResponse[];

  @ApiProperty({ type: BasicResponseDto, isArray: true })
  @Type(() => BasicResponseDto)
  @Expose()
  attributeTypes: BasicResponseDto[];
}

export class DetailDeviceResponse extends DeviceBasicResponseDto {
  @ApiProperty()
  @Expose()
  actualSerial: string;

  @ApiProperty()
  @Expose()
  model: string;

  @ApiProperty()
  @Transform(({ value }) => value ?? '')
  @Expose()
  manufacturer: string;

  @ApiProperty()
  @Expose()
  @Transform(({ obj }) => obj?.capitalizationDate || obj?.createdAt)
  capitalizationDate: Date;

  @ApiProperty()
  @Expose()
  brand: string;

  @ApiProperty()
  @Expose()
  depreciation: number;

  @ApiProperty()
  @Expose()
  price: number;

  @ApiProperty()
  @Expose()
  assetType: number;

  @ApiProperty()
  @Expose()
  warrantyPeriod: number;

  @ApiProperty()
  @Expose()
  isFixedAsset: number;

  @ApiProperty()
  @Expose()
  manufactureDate: Date;

  @ApiProperty()
  @Expose()
  creationDate: Date;

  @ApiProperty()
  @Expose()
  initAccreditationDate: Date;

  @ApiProperty()
  @Expose()
  initMaintenanceDate: Date;

  @ApiProperty()
  @Expose()
  lastAccreditationDate: Date;

  @ApiProperty()
  @Expose()
  lastMaintenanceDate: Date;

  @ApiProperty()
  @Expose()
  yearOfMake: string;

  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Expose()
  deviceType: BasicResponseDto;

  @ApiProperty({ type: DetailDeviceGroupResponse })
  @Type(() => DetailDeviceGroupResponse)
  @Expose()
  deviceGroup: DetailDeviceGroupResponse;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Expose()
  @Type(() => BasicSqlDocumentResponse)
  factory: BasicSqlDocumentResponse;

  @ApiProperty()
  @Expose()
  numericalOrder: number;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Expose()
  @Type(() => BasicSqlDocumentResponse)
  originFactory: BasicSqlDocumentResponse;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  area: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  vendor: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  warehouse: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  originWarehouse: BasicResponseDto;

  @Type(() => BasicSqlDocumentResponse)
  @ApiProperty()
  @Expose()
  unit: BasicSqlDocumentResponse;

  @ApiProperty({ type: DetailMaintenanceIndexResponse })
  @Type(() => DetailMaintenanceIndexResponse)
  @Expose()
  maintenanceIndex: DetailMaintenanceIndexResponse;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  imageUrl: string;

  @ApiProperty({
    type: DetailSupplyResponse,
    isArray: true,
  })
  @Type(() => DetailSupplyResponse)
  @Expose()
  supplies: DetailSupplyResponse[];

  @ApiProperty()
  @Expose()
  active: number;

  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Expose()
  deviceName: BasicResponseDto;

  @ApiProperty()
  @Expose()
  generateJobBy: number;

  @ApiProperty()
  @Expose()
  normGenerateJob: number;

  @ApiProperty({ type: GetMaintenanceTemplateResponseDto })
  @Type(() => GetMaintenanceTemplateResponseDto)
  @Expose()
  maintenanceTemplate: GetMaintenanceTemplateResponseDto;

  @ApiProperty({ type: GetHistoryDetailResponseDto, isArray: true })
  @Type(() => GetHistoryDetailResponseDto)
  @Expose()
  histories: GetHistoryDetailResponseDto[];
}
