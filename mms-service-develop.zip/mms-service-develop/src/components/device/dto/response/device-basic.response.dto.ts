import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { Expose } from 'class-transformer';

export class DeviceBasicResponseDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  serial: string;

  @ApiProperty()
  @Expose()
  identificationNo: string;
}
