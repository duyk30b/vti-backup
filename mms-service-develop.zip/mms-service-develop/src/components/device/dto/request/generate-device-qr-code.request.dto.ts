import { DEVICE_CONST } from '@components/device/device.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsInt,
  IsNotEmpty,
  IsString,
  Matches,
  Min,
} from 'class-validator';
import { IsNotBlank } from 'src/validator/is-not-blank.validator';

class Item {
  @ApiProperty()
  @IsString()
  @Matches(DEVICE_CONST.CODE.REGEX)
  @IsNotBlank()
  @IsNotEmpty()
  code: string;

  @ApiProperty()
  @IsInt()
  @Min(1)
  @IsNotEmpty()
  quantity: number;
}

export class GenerateDeviceQrCodeRequest extends BaseDto {
  @ApiProperty({ type: Item, isArray: true })
  @ArrayUnique<Item>((e: Item) => e.code)
  @Type(() => Item)
  @ArrayNotEmpty()
  items: Item[];
}
