import { PaginationQuery } from '@utils/dto/request/pagination.query';

export class GetDeviceUseStatusReportRequest extends PaginationQuery {}
