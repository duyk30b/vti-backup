import { CreateDeviceFormData } from './create-device.request.dto';

export class UpdateDeviceRequestDto extends CreateDeviceFormData {}
