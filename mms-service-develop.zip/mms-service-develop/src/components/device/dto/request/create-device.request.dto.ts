import { DEVICE_STATUS_ENUM } from './../../device.constant';
import {
  IsEnum,
  IsInt,
  IsNumber,
  IsNotEmpty,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
  IsDateString,
  IsMongoId,
  ValidateNested,
  ArrayUnique,
} from 'class-validator';
import {
  ASSET_TYPE_ENUM,
  DEVICE_CONST,
} from '@components/device/device.constant';
import { BaseDto } from '@core/dto/base.dto';
import { IsNotBlank } from 'src/validator/is-not-blank.validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { plainToInstance, Transform, Type } from 'class-transformer';
import { ACTIVE_ENUM } from '@constant/common';
import {
  CAN_FIXABLE_ENUM,
  DEVICE_GROUP_CONST,
  GENERATE_JOB_BY_ENUM,
} from '@components/device-group/device-group.constant';

class Supply {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  supplyId: string;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  quantity: number;

  @ApiProperty()
  @IsInt()
  @IsOptional()
  estimateUsedTime: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(CAN_FIXABLE_ENUM)
  canFixable: number;
}

export class CreateDeviceRequestDto {
  code: string;

  name: string;

  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  originWarehouseId: string;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  originFactoryId: number;

  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  deviceNameId: string;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  capitalizationDate: Date;

  @ApiProperty()
  @IsEnum(DEVICE_STATUS_ENUM)
  @IsOptional()
  status: number;

  @ApiProperty()
  @IsEnum(ACTIVE_ENUM)
  @IsOptional()
  active: ACTIVE_ENUM;

  @IsMongoId()
  @IsNotEmpty()
  deviceGroupId: string;

  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  deviceTypeId: string;

  @ApiProperty()
  @IsString()
  @IsNotBlank()
  @IsNotEmpty()
  serial: string;

  @ApiProperty()
  @IsString()
  @IsOptional()
  actualSerial: string;

  @ApiProperty({ enum: ASSET_TYPE_ENUM })
  @IsEnum(ASSET_TYPE_ENUM)
  @IsNotEmpty()
  assetType: ASSET_TYPE_ENUM;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  factoryId: number;

  @ApiProperty()
  @IsInt()
  @IsOptional()
  numericalOrder: number;

  @ApiPropertyOptional()
  @MaxLength(DEVICE_CONST.MODEL.MAX_LENGTH)
  @IsString()
  @IsOptional()
  model: string;

  @ApiProperty()
  @Min(1)
  @Max(Number.MAX_SAFE_INTEGER)
  @IsNumber()
  @IsOptional()
  price: number;

  @ApiPropertyOptional()
  @IsNumber()
  @IsOptional()
  depreciation: number;

  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  vendorId: string;

  @ApiPropertyOptional()
  @MaxLength(DEVICE_CONST.MODEL.MAX_LENGTH)
  @IsString()
  @IsOptional()
  manufacturer: string;

  @ApiProperty()
  @IsInt()
  @Transform(({ value }) => +value)
  @IsOptional()
  warrantyPeriod: number;

  @ApiProperty()
  @IsDateString()
  @IsOptional()
  manufactureDate: Date;

  @ApiProperty()
  @IsDateString()
  @IsOptional()
  creationDate: Date;

  @ApiProperty()
  @IsDateString()
  @IsOptional()
  initAccreditationDate: Date;

  @ApiProperty()
  @IsDateString()
  @IsOptional()
  initMaintenanceDate: Date;

  @ApiProperty()
  @IsString()
  @IsOptional()
  yearOfMake: string;

  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  areaId: string;

  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  warehouseId: string;

  @ApiProperty()
  @IsInt()
  @IsOptional()
  unitId: number;

  @ApiProperty()
  @IsString()
  @MaxLength(DEVICE_CONST.MODEL.MAX_LENGTH)
  @IsOptional()
  identificationNo: string;

  @ApiProperty({
    type: String,
    format: 'binary',
  })
  @IsOptional()
  file: any;

  imageUrl?: string;

  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  maintenanceTemplateId: string;

  installationTemplateId: string;

  accreditationTemplateId: string;

  @ApiProperty()
  @IsEnum(GENERATE_JOB_BY_ENUM)
  @IsOptional()
  generateJobBy: number;

  @ApiProperty()
  @Min(DEVICE_GROUP_CONST.NORM_GENERATE_JOB.MIN)
  @Max(DEVICE_GROUP_CONST.NORM_GENERATE_JOB.MAX)
  @IsNumber()
  @IsOptional()
  normGenerateJob: number;

  @ApiProperty({ type: Supply, isArray: true })
  @Type(() => Supply)
  @ValidateNested({ each: true })
  @ArrayUnique((data) => data.supplyId)
  @IsNotEmpty()
  supplies: Supply[];
}

export class CreateDeviceFormData extends BaseDto {
  @ApiProperty({
    type: CreateDeviceRequestDto,
    description: `
    {
      "name": "string",
      "status": 0,
      "deviceTypeId": "string",
      "serial": "string",
      "assetType": 1,
      "factoryId": 0,
      "model": "string",
      "price": 0,
      "depreciation": 0,
      "vendorId": "string",
      "manufacturer": "string",
      "warrantyPeriod": 0,
      "manufactureDate": "2022-10-18T09:11:56.059Z",
      "creationDate": "2022-10-18T09:11:56.059Z",
      "yearOfMake": "string",
      "areaId": "string",
      "warehouseId": "string",
      "unitId": "string",
      "identificationNo": "string",
      "active": ACTIVE_ENUM,
      "deviceNameId": "string",
      "capitalizationDate: "2022-10-18T09:11:56.059Z"
    }`,
  })
  @ValidateNested({ each: true })
  @Transform(({ value }) => {
    return plainToInstance(CreateDeviceRequestDto, JSON.parse(value));
  })
  @Type(() => CreateDeviceRequestDto)
  data: CreateDeviceRequestDto;

  @ApiProperty({
    type: String,
    format: 'binary',
  })
  @IsOptional()
  file: any;
}
