import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsMongoId, IsNotEmpty, IsString } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { DEVICE_STATUS_ENUM } from '@components/device/device.constant';
import { Transform } from 'class-transformer';
import { parseInt } from 'lodash';

export class UpdateStatusDeviceRequestDto extends BaseDto {
  @ApiProperty()
  @IsString()
  @IsMongoId()
  @IsNotEmpty()
  id: string;

  @ApiProperty()
  @IsEnum(DEVICE_STATUS_ENUM)
  @Transform((data) => parseInt(data.value))
  @IsNotEmpty()
  status: number;
}
