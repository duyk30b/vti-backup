import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString } from 'class-validator';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { GET_ALL_ENUM } from '@constant/common';
import { Transform } from 'class-transformer';
import { IS_GET_ALL_FACTORY } from '@utils/constant';

export class GetListDevicesRequestDto extends PaginationQuery {
  @ApiProperty({
    enum: ['0', '1'],
  })
  @IsEnum(GET_ALL_ENUM)
  @Transform(({ value }) => +value)
  @IsOptional()
  isGetAll: GET_ALL_ENUM;

  @ApiPropertyOptional({
    example: ['1', '2'],
  })
  @IsOptional()
  @IsString()
  queryIds?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => +value)
  @IsEnum(IS_GET_ALL_FACTORY)
  isGetAllFactory?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => +value)
  isMasterData?: number;
}
