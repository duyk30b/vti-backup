import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsMongoId, IsOptional } from 'class-validator';

export class UpdateLocationDeviceBodyDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  @IsOptional()
  factoryId: number;

  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  areaId: string;
}

export class UpdateLocationDeviceRequestDto extends UpdateLocationDeviceBodyDto {
  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  id: string;
}
