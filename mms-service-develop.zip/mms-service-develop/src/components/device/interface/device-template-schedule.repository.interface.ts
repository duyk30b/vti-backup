import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { DeviceTemplateSchedule } from 'src/models/device-template-schedule/device-template-schedule.model';

export interface DeviceTemplateScheduleRepositoryInterface
  extends BaseInterfaceRepository<DeviceTemplateSchedule> {
  createEntity(data: DeviceTemplateSchedule): DeviceTemplateSchedule;
  getDeviceByMaintainDuration(
    condition: any,
    limit?: number,
  ): Promise<{ result: any[]; count: number }>;
  getDeviceByChecklistDuration(
    condition: any,
    limit?: number,
  ): Promise<{ result: any[]; count: number }>;
  countDeviceByAccreditationDuration(condition: any): Promise<any>;
  getDeviceByAccreditationDuration(
    condition: any,
    limit?: number,
  ): Promise<any>;
}
