import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { GetListDevicesRequestDto } from '@components/device/dto/request/list-devices.request.dto';
import { CreateDeviceRequestDto } from '@components/device/dto/request/create-device.request.dto';
import { Device } from 'src/models/device/device.model';
import { GetListDeviceWithStatusRequestDto } from '@components/device-status/dto/request/get-list-device-with-status.request.dto';
import { DashboardRequestDto } from '@components/dashboard/dto/request/dashboard.request.dto';
import { GetDeviceSynthesisReportRequest } from '@components/report/dto/request/get-device-synthesis-report.request';
import { GetDeviceUseStatusReportRequest } from '../dto/request/get-device-use-status.request.dto';
import { DashboardDeviceUseStatusByAreaRequestDto } from '@components/dashboard/dto/request/get-dashboard-device-use-status-by-area.request.dto';
import { GetInventoryByWarehouseAndDeviceGroupRequestDto } from '@components/warehouse/dto/request/get-inventories-by-warehouse-and-device-group.request.dto';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { GetReportNewInvestmentDevice } from '@components/report/dto/request/get-report-new-investment-device.request';

export interface DeviceRepositoryInterface
  extends BaseInterfaceRepository<Device> {
  list(request: GetListDevicesRequestDto): Promise<any>;
  createDocument(request: CreateDeviceRequestDto, supplies: any): Device;
  detail(id: string): Promise<any>;
  updateDocument(device: Device, request: any): Device;
  listDeviceWithStatus(
    request: GetListDeviceWithStatusRequestDto,
  ): Promise<any>;
  countDeviceDashboard(request: DashboardRequestDto): Promise<any>;
  dashboardDeviceStatus(request: DashboardRequestDto): Promise<any>;
  getDeviceSynthesisReport(
    request: GetDeviceSynthesisReportRequest,
  ): Promise<any>;
  reportDeviceUseStatus(request: GetDeviceUseStatusReportRequest): Promise<any>;
  dashboardDeviceUseStatus(request: DashboardRequestDto): Promise<any>;
  dashboardDeviceUseStatusByArea(
    request: DashboardDeviceUseStatusByAreaRequestDto,
  ): Promise<any>;
  getDeviceByWarehouseAndDeviceGroup(
    query: PaginationQuery,
    request: GetInventoryByWarehouseAndDeviceGroupRequestDto,
  ): Promise<any>;
  reportNewInvestmentDevice(
    request: GetReportNewInvestmentDevice,
  ): Promise<any>;
}
