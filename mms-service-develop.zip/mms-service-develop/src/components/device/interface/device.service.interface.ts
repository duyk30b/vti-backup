import { GetListDevicesRequestDto } from '@components/device/dto/request/list-devices.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreateDeviceFormData } from '@components/device/dto/request/create-device.request.dto';
import { UpdateDeviceRequestDto } from '@components/device/dto/request/update-device.request.dto';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateStatusDeviceRequestDto } from '../dto/request/update-status-device.request.dto';
import { UpdateLocationDeviceRequestDto } from '../dto/request/update-location-device.request.dto';
import { ScanDeviceParamDto } from '../dto/request/scan-device.param.dto';
import { GetDeviceActivityHistoryRequestDto } from '../dto/request/get-device-activity-history.request.dto';
import { GenerateDeviceQrCodeRequest } from '../dto/request/generate-device-qr-code.request.dto';

export interface DeviceServiceInterface {
  list(request: GetListDevicesRequestDto): Promise<ResponsePayload<any>>;
  create(request: CreateDeviceFormData): Promise<ResponsePayload<any>>;
  update(request: UpdateDeviceRequestDto): Promise<ResponsePayload<any>>;
  updateStatus(
    request: UpdateStatusDeviceRequestDto,
  ): Promise<ResponsePayload<any>>;

  updateLocation(
    request: UpdateLocationDeviceRequestDto,
  ): Promise<ResponsePayload<any>>;
  delete(request: IdParamDto): Promise<ResponsePayload<any>>;
  detail(request: IdParamDto): Promise<ResponsePayload<any>>;
  getSuppliesByDevice(request: IdParamDto): Promise<ResponsePayload<any>>;
  import(
    request: any,
    user: any,
  ): Promise<{ dataSuccess: any; dataError: any[] }>;
  scan(request: ScanDeviceParamDto): Promise<ResponsePayload<any>>;
  getActivities(
    request: GetDeviceActivityHistoryRequestDto & IdParamDto,
  ): Promise<any>;
  maintenanceInfo(request: any): Promise<ResponsePayload<any>>;
  generateDeviceQrCode(request: GenerateDeviceQrCodeRequest): Promise<any>;
}
