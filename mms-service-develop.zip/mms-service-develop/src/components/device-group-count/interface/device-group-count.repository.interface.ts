import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { DeviceGroupCount } from 'src/models/device-group-count/device-group-count.model';

export interface DeviceGroupCountRepositoryInterface
  extends BaseInterfaceRepository<DeviceGroupCount> {}
