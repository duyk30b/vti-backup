import { DeviceGroupCount } from 'src/models/device-group-count/device-group-count.model';

export interface DeviceGroupCountServiceInterface {
  countDeviceByDeviceGroup(deviceGroupId: string): Promise<number>;
  update(deviceGroupId: string, count: number): Promise<void>;
  countDeviceByDeviceGroupIds(
    deviceGroupIds: string[],
  ): Promise<DeviceGroupCount[]>;
}
