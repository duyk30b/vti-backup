import { MongooseModule } from '@nestjs/mongoose';
import { Module } from '@nestjs/common';
import { DeviceGroupCountController } from './device-group-count.controller';
import { DeviceGroupCountService } from './device-group-count.service';
import { DeviceGroupCountSchema } from 'src/models/device-group-count/device-group-count.schema';
import { DeviceGroupCountRepository } from 'src/repository/device-group-count/device-group-count.repository';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'DeviceGroupCount', schema: DeviceGroupCountSchema },
    ]),
  ],
  controllers: [DeviceGroupCountController],
  providers: [
    {
      provide: 'DeviceGroupCountRepositoryInterface',
      useClass: DeviceGroupCountRepository,
    },
  ],
  exports: [
    MongooseModule,
    {
      provide: 'DeviceGroupCountRepositoryInterface',
      useClass: DeviceGroupCountRepository,
    },
    {
      provide: 'DeviceGroupCountServiceInterface',
      useClass: DeviceGroupCountService,
    },
  ],
})
export class DeviceGroupCountModule {}
