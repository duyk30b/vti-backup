import { Inject, Injectable } from '@nestjs/common';
import { Types } from 'mongoose';
import { difference, isEmpty } from 'lodash';
import { DeviceGroupCountRepositoryInterface } from './interface/device-group-count.repository.interface';
import { DeviceGroupCountServiceInterface } from './interface/device-group-count.service.interface';
import { DeviceGroupCount } from 'src/models/device-group-count/device-group-count.model';
@Injectable()
export class DeviceGroupCountService
  implements DeviceGroupCountServiceInterface
{
  constructor(
    @Inject('DeviceGroupCountRepositoryInterface')
    private readonly deviceGroupCountRepository: DeviceGroupCountRepositoryInterface,
  ) {}

  async countDeviceByDeviceGroup(deviceGroupId: string): Promise<number> {
    let deviceGroupCount =
      await this.deviceGroupCountRepository.findOneByCondition({
        deviceGroupId: new Types.ObjectId(deviceGroupId),
      });

    if (!deviceGroupCount) {
      deviceGroupCount = await this.deviceGroupCountRepository.create({
        deviceGroupId,
        count: 0,
      });
    }

    return deviceGroupCount?.count || 0;
  }

  async countDeviceByDeviceGroupIds(
    deviceGroupIds: string[],
  ): Promise<DeviceGroupCount[]> {
    const deviceGroupCounts =
      await this.deviceGroupCountRepository.findAllByCondition({
        deviceGroupId: {
          $in: deviceGroupIds.map((e) => new Types.ObjectId(e)),
        },
      });

    const newObjectGroupCounts = difference(
      deviceGroupIds,
      deviceGroupCounts.map((e) => e.deviceGroupId.toString()),
    );

    if (!isEmpty(newObjectGroupCounts)) {
      await this.deviceGroupCountRepository.createMany(
        newObjectGroupCounts.map((e) => ({
          deviceGroupId: e,
          count: 0,
        })),
      );
    }

    return await this.deviceGroupCountRepository.findAllByCondition({
      deviceGroupId: {
        $in: deviceGroupIds.map((e) => new Types.ObjectId(e)),
      },
    });
  }

  async update(deviceGroupId: string, count: number): Promise<void> {
    const deviceGroupCount =
      await this.deviceGroupCountRepository.findOneByCondition({
        deviceGroupId: new Types.ObjectId(deviceGroupId),
      });

    if (!deviceGroupCount) {
      await this.deviceGroupCountRepository.create({
        deviceGroupId,
        count: 0,
      });
    } else {
      await this.deviceGroupCountRepository.findByIdAndUpdate(
        deviceGroupCount._id,
        {
          count,
        },
      );
    }
  }
}
