import { Controller, Inject } from '@nestjs/common';
import { DeviceGroupCountServiceInterface } from './interface/device-group-count.service.interface';
@Controller('device-group-counts')
export class DeviceGroupCountController {
  constructor(
    @Inject('DeviceGroupCountServiceInterface')
    private readonly deviceGroupService: DeviceGroupCountServiceInterface,
  ) {}
}
