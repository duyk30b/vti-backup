import { FileModule } from '@components/file/file.module';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { InstallationTemplateSchema } from 'src/models/installation-template/installation-template.schema';
import { InstallationTemplateRepository } from 'src/repository/installation-template/installation-template.repository';
import { InstallationTemplateController } from './installation-template.controller';
import { InstallationTemplateService } from './installation-template.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'InstallationTemplate', schema: InstallationTemplateSchema },
    ]),
    FileModule,
  ],
  controllers: [InstallationTemplateController],
  providers: [
    {
      provide: 'InstallationTemplateRepositoryInterface',
      useClass: InstallationTemplateRepository,
    },
    {
      provide: 'InstallationTemplateServiceInterface',
      useClass: InstallationTemplateService,
    },
  ],
  exports: [MongooseModule],
})
export class InstallationTemplateModule {}
