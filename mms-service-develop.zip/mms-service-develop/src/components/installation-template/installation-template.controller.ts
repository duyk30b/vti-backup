import { ACTIVE_ENUM } from '@constant/common';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  Body,
  Controller,
  Get,
  Inject,
  Injectable,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import {
  CREATE_DEVICE_GROUP_PERMISSION,
  UPDATE_DEVICE_GROUP_PERMISSION,
} from '@utils/permissions/device-group';
import {
  CREATE_INSTALLATION_TEMPLATE_PERMISSION,
  DETAIL_INSTALLATION_TEMPLATE_PERMISSION,
  LIST_INSTALLATION_TEMPLATE_PERMISSION,
  UPDATE_INSTALLATION_TEMPLATE_PERMISSION,
  UPDATE_STATUS_INSTALLATION_TEMPLATE_PERMISSION,
} from '@utils/permissions/installation-template';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { GetListInstallationTemplateQuery } from './dto/query/get-list-installation-template.query';
import { CreateInstallationTemplateRequest } from './dto/request/create-installation-template.request';
import { UpdateInstallationTemplateBodyDto } from './dto/request/update-installation-template.request';
import { DetailInstallationTemplateResponse } from './dto/response/detail-installation-template.response';
import { InstallationTemplateServiceInterface } from './interface/installation-template.service.interface';

@Injectable()
@Controller('installation-templates')
export class InstallationTemplateController {
  constructor(
    @Inject('InstallationTemplateServiceInterface')
    private readonly installationTemplateService: InstallationTemplateServiceInterface,
  ) {}

  @PermissionCode(CREATE_INSTALLATION_TEMPLATE_PERMISSION.code)
  @Post('')
  @ApiOperation({
    tags: ['Installation template'],
    summary: 'Tạo phiếu lắp đặt',
    description: 'Tạo phiếu lắp đặt',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async create(
    @Body() payload: CreateInstallationTemplateRequest,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.installationTemplateService.create(request);
  }

  @PermissionCode(DETAIL_INSTALLATION_TEMPLATE_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Installation template'],
    summary: 'Chi tiết phiếu lắp đặt',
    description: 'Chi tiết phiếu lắp đặt',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailInstallationTemplateResponse,
  })
  async detail(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.installationTemplateService.detail(request);
  }

  @PermissionCode(UPDATE_INSTALLATION_TEMPLATE_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Installation template'],
    summary: 'Cập nhật phiếu lắp đặt',
    description: 'Cập nhật phiếu lắp đặt',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async update(
    @Param() payload: IdParamDto,
    @Body() body: UpdateInstallationTemplateBodyDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    const { request: param, responseError: paramError } = payload;
    if (paramError && !isEmpty(paramError)) {
      return paramError;
    }

    return await this.installationTemplateService.update({
      ...request,
      id: param.id,
    });
  }

  @PermissionCode(
    LIST_INSTALLATION_TEMPLATE_PERMISSION.code,
    CREATE_DEVICE_GROUP_PERMISSION.code,
    UPDATE_DEVICE_GROUP_PERMISSION.code,
  )
  @Get('')
  @ApiOperation({
    tags: ['Installation template'],
    summary: 'Danh sách phiếu lắp đặt',
    description: 'Danh sách phiếu lắp đặt',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: null,
  })
  async list(@Query() payload: GetListInstallationTemplateQuery): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.installationTemplateService.list(request);
  }

  @PermissionCode(UPDATE_STATUS_INSTALLATION_TEMPLATE_PERMISSION.code)
  @Put('/:id/active')
  @ApiOperation({
    tags: ['Installation template'],
    summary: 'Active phiếu lắp đặt',
    description: 'Active phiếu lắp đặt',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async active(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.installationTemplateService.updateStatus({
      status: ACTIVE_ENUM.ACTIVE,
      ...request,
    });
  }

  @PermissionCode(UPDATE_STATUS_INSTALLATION_TEMPLATE_PERMISSION.code)
  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Installation template'],
    summary: 'inActive phiếu lắp đặt',
    description: 'inActive phiếu lắp đặt',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async inactive(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.installationTemplateService.updateStatus({
      status: ACTIVE_ENUM.INACTIVE,
      ...request,
    });
  }
}
