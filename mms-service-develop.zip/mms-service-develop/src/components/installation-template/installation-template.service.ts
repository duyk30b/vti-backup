import { keyBy, map, isEmpty, difference } from 'lodash';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { GetListInstallationTemplateQuery } from './dto/query/get-list-installation-template.query';
import { CreateInstallationTemplateRequest } from './dto/request/create-installation-template.request';
import { UpdateInstallationTemplateRequest } from './dto/request/update-installation-template.request';
import { DetailInstallationTemplateResponse } from './dto/response/detail-installation-template.response';
import { InstallationTemplateRepositoryInterface } from './interface/installation-template.repository';
import { InstallationTemplateServiceInterface } from './interface/installation-template.service.interface';
import { UpdateStatusInstallationTemplateRequest } from './dto/request/update-status-installation-template.request';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { INSTALLATION_TEMPLATE_CONST } from './installation-template.constant';
import { getCurrentCodeByLastRecord } from 'src/helper/code.helper';
import {
  getDataInsert,
  getDataToUpdateError,
  getDataUpdate,
} from 'src/helper/import.helper';
import { FileServiceInterface } from '@components/file/interface/file.service.interface';
import { FileResource } from '@components/file/file.constant';
import { ConfigService } from '@config/config.service';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';

@Injectable()
export class InstallationTemplateService
  implements InstallationTemplateServiceInterface
{
  private readonly configService: ConfigService;
  private readonly fileUri: string;
  constructor(
    @Inject('InstallationTemplateRepositoryInterface')
    private readonly installationTemplateRepository: InstallationTemplateRepositoryInterface,

    @Inject('FileServiceInterface')
    private readonly fileService: FileServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {
    this.configService = new ConfigService();
    this.fileUri = this.configService.get('fileUri');
  }
  async updateStatus(
    request: UpdateStatusInstallationTemplateRequest,
  ): Promise<ResponsePayload<any>> {
    const { status, id } = request;
    const installationTemplate =
      await this.installationTemplateRepository.findOneById(id);
    if (!installationTemplate) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    await this.installationTemplateRepository.findByIdAndUpdate(id, {
      $set: { active: status },
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async create(
    request: CreateInstallationTemplateRequest,
  ): Promise<ResponsePayload<any>> {
    const { data, files } = request;
    try {
      if (!isEmpty(files)) {
        const fileIds = await this.fileService.uploadFiles(
          files ?? [],
          FileResource.INSTALLATION,
        );
        if (fileIds?.length !== files.length) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(await this.i18n.translate('error.UPLOAD_FILE_ERROR'))
            .build();
        }
        data.fileIds = fileIds;
      }
      data.code = await this.installationTemplateRepository.generateNextCode(
        INSTALLATION_TEMPLATE_CONST.CODE.PREFIX,
      );
      const document = this.installationTemplateRepository.createDocument(data);
      const dataSave = await document.save();
      const dataReturn = plainToInstance(BasicResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async detail(request: IdParamDto): Promise<ResponsePayload<any>> {
    const document =
      await this.installationTemplateRepository.findOneByCondition({
        _id: request.id,
        deletedAt: null,
      });

    if (!document) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (!isEmpty(document?.fileIds)) {
      const fileInfos = await this.fileService.getFileInfoByIds(
        document?.fileIds,
      );
      document['fileUrls'] = fileInfos.map((file) => ({
        ...file,
        fileUrl: this.fileUri + file?.id,
      }));
    }
    const dataReturn = plainToInstance(
      DetailInstallationTemplateResponse,
      document,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async update(
    request: UpdateInstallationTemplateRequest,
  ): Promise<ResponsePayload<any>> {
    const { files, data, fileUrls } = request;
    try {
      let installationTemplate =
        await this.installationTemplateRepository.findOneById(request.id);

      if (!installationTemplate) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      let fileIds = [];
      if (!isEmpty(files)) {
        fileIds = await this.fileService.uploadFiles(
          files ?? [],
          FileResource.INSTALLATION,
        );
        if (fileIds?.length !== files.length) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(await this.i18n.translate('error.UPLOAD_FILE_ERROR'))
            .build();
        }
      }
      const fileIdsBody = map(fileUrls, 'id') ?? [];
      const filesNotFound = difference(
        fileIdsBody,
        installationTemplate.fileIds?.map((el) => el.toString()),
      );
      if (!isEmpty(filesNotFound)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.FILE_NOT_FOUND'))
          .build();
      }
      data.fileIds = fileIds.concat(fileIdsBody);

      installationTemplate = this.installationTemplateRepository.updateEntity(
        installationTemplate,
        data,
      );
      await this.installationTemplateRepository.findByIdAndUpdate(
        request.id,
        installationTemplate,
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }
  }

  async list(
    request: GetListInstallationTemplateQuery,
  ): Promise<ResponsePayload<any>> {
    const { data, count } = await this.installationTemplateRepository.list(
      request,
    );

    const dataReturn = plainToInstance(
      DetailInstallationTemplateResponse,
      data,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder({
      result: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const textAdd = await this.i18n.translate('import.common.add');
    const codePrefix = INSTALLATION_TEMPLATE_CONST.CODE.PREFIX;
    const lastRecord = await this.installationTemplateRepository.lastRecord();
    const codeCurrent = getCurrentCodeByLastRecord(codePrefix, lastRecord);

    const dataInsert = getDataInsert(data, codePrefix, codeCurrent, textAdd);
    const { dataToUpdate, codesUpdate } = getDataUpdate(data, textAdd);

    const codeUpdateExists =
      await this.installationTemplateRepository.findAllByCondition({
        code: { $in: codesUpdate },
      });
    const codeUpdateMap = keyBy(codeUpdateExists, 'code');

    const { dataError, dataUpdate } = getDataToUpdateError(
      dataToUpdate,
      codeUpdateMap,
    );
    // check duplicate
    const isTitleDuplicate = (doc) => {
      return (
        new Set(map(doc.details, (data) => data.title?.toLocaleLowerCase()))
          .size !== doc.details?.length
      );
    };
    const bulkOps = [];
    [...dataInsert, ...dataUpdate].forEach((doc) => {
      if (isTitleDuplicate(doc)) {
        dataError.push(doc);
      } else {
        bulkOps.push({
          updateOne: {
            filter: { code: doc.code },
            update: doc,
            upsert: true,
          },
        });
      }
    });
    const dataSuccess = await this.installationTemplateRepository.bulkWrite(
      bulkOps,
    );

    return { dataError, dataSuccess };
  }
}
