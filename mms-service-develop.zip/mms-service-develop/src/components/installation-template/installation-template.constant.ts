import { CODE_REGEX } from '@constant/common';

export const INSTALLATION_TEMPLATE_CONST = {
  DESCRIPTION: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
  CODE: {
    MAX_LENGTH: 20,
    MIN_LENGTH: 6,
    COLUMN: 'code',
    REGEX: CODE_REGEX,
    PREFIX: 'PLD',
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  TITLE: {
    MAX_LENGTH: 50,
    COLUMN: 'title',
  },
};
