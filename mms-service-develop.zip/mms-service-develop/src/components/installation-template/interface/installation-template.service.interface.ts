import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { GetListInstallationTemplateQuery } from '../dto/query/get-list-installation-template.query';
import { CreateInstallationTemplateRequest } from '../dto/request/create-installation-template.request';
import { UpdateInstallationTemplateRequest } from '../dto/request/update-installation-template.request';
import { UpdateStatusInstallationTemplateRequest } from '../dto/request/update-status-installation-template.request';

export interface InstallationTemplateServiceInterface {
  create(
    request: CreateInstallationTemplateRequest,
  ): Promise<ResponsePayload<any>>;
  detail(request: IdParamDto): Promise<ResponsePayload<any>>;

  update(
    request: UpdateInstallationTemplateRequest,
  ): Promise<ResponsePayload<any>>;

  updateStatus(
    request: UpdateStatusInstallationTemplateRequest,
  ): Promise<ResponsePayload<any>>;
  list(
    request: GetListInstallationTemplateQuery,
  ): Promise<ResponsePayload<any>>;
  import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }>;
}
