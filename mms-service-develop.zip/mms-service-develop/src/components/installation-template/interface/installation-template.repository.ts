import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InstallationTemplate } from 'src/models/installation-template/installation-template.model';
import { GetListInstallationTemplateQuery } from '../dto/query/get-list-installation-template.query';
import { DataBodyInstallationTemplate } from '../dto/request/create-installation-template.request';
import { LisInstallationTemplateResponse } from '../dto/response/list-installation-template.response';

export interface InstallationTemplateRepositoryInterface
  extends BaseAbstractRepository<InstallationTemplate> {
  createDocument(request: DataBodyInstallationTemplate): InstallationTemplate;
  updateEntity(
    entity: InstallationTemplate,
    request: DataBodyInstallationTemplate,
  ): InstallationTemplate;
  list(
    request: GetListInstallationTemplateQuery,
  ): Promise<LisInstallationTemplateResponse>;
}
