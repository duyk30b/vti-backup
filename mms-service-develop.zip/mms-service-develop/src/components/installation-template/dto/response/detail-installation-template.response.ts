import { BaseResponseDto } from '@core/dto/base.response.dto';
import { OBLIGATORY_ENUM } from '@constant/common';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { FileUrlResponseDto } from '@utils/dto/response/file-url.response.dto';

class DetailInstallationTemplateDetail extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  title: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  obligatory: OBLIGATORY_ENUM;
}

export class DetailInstallationTemplateResponse extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  active: number;

  @ApiProperty({
    type: FileUrlResponseDto,
    isArray: true,
  })
  @Expose()
  @Type(() => FileUrlResponseDto)
  fileUrls: FileUrlResponseDto[];

  @ApiProperty({ type: DetailInstallationTemplateDetail, isArray: true })
  @Type(() => DetailInstallationTemplateDetail)
  @Expose()
  details: DetailInstallationTemplateDetail[];
}
