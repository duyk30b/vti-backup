import { ApiProperty } from '@nestjs/swagger';
import { FileUrlParamDto } from '@utils/dto/request/file-url.request.dto';
import { Transform, Type } from 'class-transformer';
import {
  IsMongoId,
  IsNotEmpty,
  IsOptional,
  ValidateNested,
} from 'class-validator';
import { CreateInstallationTemplateRequest } from './create-installation-template.request';

export class UpdateInstallationTemplateBodyDto extends CreateInstallationTemplateRequest {
  @ApiProperty()
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => FileUrlParamDto)
  @Transform(({ value }) => JSON.parse(value))
  fileUrls: FileUrlParamDto[];
}

export class UpdateInstallationTemplateRequest extends UpdateInstallationTemplateBodyDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  id: string;
}
