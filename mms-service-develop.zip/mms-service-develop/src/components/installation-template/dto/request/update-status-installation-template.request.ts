import { ACTIVE_ENUM } from '@constant/common';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsMongoId, IsNotEmpty } from 'class-validator';

export class UpdateStatusInstallationTemplateRequest extends BaseDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  id: string;

  @ApiProperty()
  @IsEnum(ACTIVE_ENUM)
  @IsNotEmpty()
  status: number;
}
