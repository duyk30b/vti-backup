import { INSTALLATION_TEMPLATE_CONST } from '@components/installation-template/installation-template.constant';
import { OBLIGATORY_ENUM } from '@constant/common';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { MIME_TYPES_FOR_TEMPLATE } from '@utils/constant';
import { plainToClass, Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsEnum,
  IsMongoId,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import { IsNotBlank } from 'src/validator/is-not-blank.validator';

class CreateInstallationTemplateDetail {
  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  id: string;

  @ApiProperty()
  @MaxLength(INSTALLATION_TEMPLATE_CONST.NAME.MAX_LENGTH)
  @IsString()
  @IsNotEmpty()
  title: string;

  @MaxLength(INSTALLATION_TEMPLATE_CONST.DESCRIPTION.MAX_LENGTH)
  @IsString()
  @IsOptional()
  description: string;

  @IsEnum(OBLIGATORY_ENUM)
  @IsOptional()
  obligatory: OBLIGATORY_ENUM;
}

export class DataBodyInstallationTemplate extends BaseDto {
  code: string;

  @ApiProperty()
  @MaxLength(INSTALLATION_TEMPLATE_CONST.NAME.MAX_LENGTH)
  @IsString()
  @IsNotEmpty()
  @IsNotBlank()
  name: string;

  @ApiProperty()
  @MaxLength(INSTALLATION_TEMPLATE_CONST.DESCRIPTION.MAX_LENGTH)
  @IsString()
  @IsOptional()
  description: string;

  fileIds: string[];

  @ApiProperty({ type: CreateInstallationTemplateDetail, isArray: true })
  @Type(() => CreateInstallationTemplateDetail)
  @ValidateNested({ each: true })
  @ArrayNotEmpty()
  details: CreateInstallationTemplateDetail[];
}

export class File {
  filename: string;
  data: ArrayBuffer;
  encoding: string;
  @IsEnum(MIME_TYPES_FOR_TEMPLATE)
  mimetype: string;
  limit: boolean;
}

export class CreateInstallationTemplateRequest extends BaseDto {
  @ApiProperty({ type: DataBodyInstallationTemplate })
  @Type(() => DataBodyInstallationTemplate)
  @ValidateNested({ each: true })
  @Transform(({ value }) =>
    plainToClass(DataBodyInstallationTemplate, JSON.parse(value)),
  )
  @IsNotEmpty()
  data: DataBodyInstallationTemplate;

  @ApiProperty()
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => File)
  files: File[];
}
