import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { DeviceTypeSchema } from 'src/models/device-type/device-type.schema';
import { DeviceTypeRepository } from 'src/repository/device-type/device-type.repository';
import { DeviceTypeController } from './device-type.controller';
import { DeviceTypeService } from './device-type.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'DeviceType', schema: DeviceTypeSchema },
    ]),
  ],
  providers: [
    {
      provide: 'DeviceTypeRepositoryInterface',
      useClass: DeviceTypeRepository,
    },
    {
      provide: 'DeviceTypeServiceInterface',
      useClass: DeviceTypeService,
    },
  ],
  controllers: [DeviceTypeController],
  exports: [
    MongooseModule,
    {
      provide: 'DeviceTypeRepositoryInterface',
      useClass: DeviceTypeRepository,
    },
    {
      provide: 'DeviceTypeServiceInterface',
      useClass: DeviceTypeService,
    },
  ],
})
export class DeviceTypeModule {}
