import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { DeviceType } from 'src/models/device-type/device-type.model';
import { ListDeviceTypeRequestDto } from '../dto/request/list-device-type.dto';

export interface DeviceTypeRepositoryInterface
  extends BaseAbstractRepository<DeviceType> {
  createEntity(request: any): DeviceType;
  updateEntity(deviceType: DeviceType, request: any): DeviceType;
  list(request: ListDeviceTypeRequestDto): Promise<any>;
}
