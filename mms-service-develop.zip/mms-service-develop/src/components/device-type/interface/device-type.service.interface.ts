import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreateDeviceTypeRequestDto } from '../dto/request/create-device-type.dto';
import { ListDeviceTypeRequestDto } from '../dto/request/list-device-type.dto';
import { UpdateDeviceTypeRequestDto } from '../dto/request/update-device-type.dto';
import { ListDeviceTypeResponse } from '../dto/response/list-device-type.dto';

export interface DeviceTypeServiceInterface {
  create(data: CreateDeviceTypeRequestDto): Promise<ResponsePayload<any>>;
  update(request: UpdateDeviceTypeRequestDto): Promise<ResponsePayload<any>>;
  updateStatus(
    request: UpdateActiveStatusPayload,
  ): Promise<ResponsePayload<any>>;
  list(
    request: ListDeviceTypeRequestDto,
  ): Promise<ResponsePayload<ListDeviceTypeResponse>>;
  detail(request: IdParamDto): Promise<ResponsePayload<any>>;
  import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }>;
}
