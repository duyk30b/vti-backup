import { ACTIVE_ENUM } from '@constant/common';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  Body,
  Controller,
  Get,
  Inject,
  Injectable,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import {
  CREATE_DEVICE_GROUP_PERMISSION,
  UPDATE_DEVICE_GROUP_PERMISSION,
} from '@utils/permissions/device-group';
import {
  CREATE_DEVICE_TYPE_PERMISSION,
  DETAIL_DEVICE_TYPE_PERMISSION,
  LIST_DEVICE_TYPE_PERMISSION,
  UPDATE_DEVICE_TYPE_PERMISSION,
  UPDATE_STATUS_DEVICE_TYPE_PERMISSION,
} from '@utils/permissions/device-type';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateDeviceTypeRequestDto } from './dto/request/create-device-type.dto';
import { ListDeviceTypeRequestDto } from './dto/request/list-device-type.dto';
import { DetailDeviceTypeResponse } from './dto/response/detail-device-type.dto';
import { ListDeviceTypeResponse } from './dto/response/list-device-type.dto';
import { DeviceTypeServiceInterface } from './interface/device-type.service.interface';

@Injectable()
@Controller('/device-type')
export class DeviceTypeController {
  constructor(
    @Inject('DeviceTypeServiceInterface')
    private deviceTypeService: DeviceTypeServiceInterface,
  ) {}

  // create
  @PermissionCode(CREATE_DEVICE_TYPE_PERMISSION.code)
  @Post()
  @ApiOperation({
    tags: ['Device Type'],
    summary: 'Create Device Type',
    description: 'Create Device Type',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: SuccessResponse,
  })
  async create(@Body() body: CreateDeviceTypeRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceTypeService.create(request);
  }

  // list
  @PermissionCode(
    LIST_DEVICE_TYPE_PERMISSION.code,
    CREATE_DEVICE_GROUP_PERMISSION.code,
    UPDATE_DEVICE_GROUP_PERMISSION.code,
  )
  @Get()
  @ApiOperation({
    tags: ['Device Type'],
    summary: 'List Device Type',
    description: 'List Device Type',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: ListDeviceTypeResponse,
  })
  async list(@Query() query: ListDeviceTypeRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceTypeService.list(request);
  }

  // detail
  @PermissionCode(DETAIL_DEVICE_TYPE_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Device Type'],
    summary: 'Detail Device Type',
    description: 'Detail Device Type',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: DetailDeviceTypeResponse,
  })
  async detail(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceTypeService.detail(request);
  }

  // update
  @PermissionCode(UPDATE_DEVICE_TYPE_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Device Type'],
    summary: 'Update Device Type',
    description: 'Update Device Type',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: SuccessResponse,
  })
  async update(
    @Param() param: IdParamDto,
    @Body() body: CreateDeviceTypeRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    const {
      request: { id },
      responseError: responseErrorParam,
    } = param;
    if (responseErrorParam && !isEmpty(responseErrorParam)) {
      return responseErrorParam;
    }

    return await this.deviceTypeService.update({ ...request, id });
  }

  // update status
  @PermissionCode(UPDATE_STATUS_DEVICE_TYPE_PERMISSION.code)
  @Put('/:id/active')
  @ApiOperation({
    tags: ['Device Type'],
    summary: 'Active Device Type',
    description: 'Active Device Type',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: SuccessResponse,
  })
  async active(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceTypeService.updateStatus({
      status: ACTIVE_ENUM.ACTIVE,
      ...request,
    });
  }

  // update status
  @PermissionCode(UPDATE_STATUS_DEVICE_TYPE_PERMISSION.code)
  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Device Type'],
    summary: 'Inactive Device Type',
    description: 'Inactive Device Type',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: SuccessResponse,
  })
  async inactive(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceTypeService.updateStatus({
      status: ACTIVE_ENUM.INACTIVE,
      ...request,
    });
  }
}
