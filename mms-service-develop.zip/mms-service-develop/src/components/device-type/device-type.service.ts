import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { getDataDuplicate, plus } from '@utils/common';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { has, keyBy, map } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { generateCodeByPreviousCode } from 'src/helper/code.helper';
import { DEVICE_TYPE_CONST } from './device-type.constant';
import { CreateDeviceTypeRequestDto } from './dto/request/create-device-type.dto';
import { ListDeviceTypeRequestDto } from './dto/request/list-device-type.dto';
import { UpdateDeviceTypeRequestDto } from './dto/request/update-device-type.dto';
import { DetailDeviceTypeResponse } from './dto/response/detail-device-type.dto';
import { DeviceTypeRepositoryInterface } from './interface/device-type.repository.interface';
import { DeviceTypeServiceInterface } from './interface/device-type.service.interface';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';

@Injectable()
export class DeviceTypeService implements DeviceTypeServiceInterface {
  constructor(
    @Inject('DeviceTypeRepositoryInterface')
    private readonly deviceTypeRepository: DeviceTypeRepositoryInterface,

    private i18n: I18nRequestScopeService,
  ) {}

  async import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const dataInsert = [];
    const dataUpdate = [];
    const dataToInsert = [];
    const dataToUpdate = [];
    const codesUpdate = [];
    const dataError = [];
    const textAdd = await this.i18n.translate('import.common.add');
    let count = 0;

    const deviceTypeConst = DEVICE_TYPE_CONST.CODE;
    const lastRecord = await this.deviceTypeRepository.lastRecord();
    const codeCurrent =
      Number(lastRecord.code?.replace(deviceTypeConst.PREFIX, '')) || 0;
    data.forEach((item) => {
      if (item.action === textAdd) {
        item.code = generateCodeByPreviousCode(
          deviceTypeConst.PREFIX,
          plus(codeCurrent, count++),
        );
        dataToInsert.push(item);
      } else {
        dataToUpdate.push(item);
        codesUpdate.push(item.code);
      }
    });
    const deviceTypeCodeUpdateExists =
      await this.deviceTypeRepository.findAllByCondition({
        code: { $in: codesUpdate },
      });

    const deviceTypeUpdateMap = keyBy(deviceTypeCodeUpdateExists, 'code');

    const names = map([...dataToUpdate, ...dataToInsert], 'name');
    const nameDuplicate = getDataDuplicate(names);
    const nameExists = await this.deviceTypeRepository.findAllByCondition({
      name: { $in: names },
    });
    const nameExistMap = keyBy(nameExists, 'name');
    dataToInsert.forEach((item) => {
      if (has(nameExistMap, item.name) || has(nameDuplicate, item.name)) {
        dataError.push(item);
      } else {
        dataInsert.push(item);
      }
    });
    dataToUpdate.forEach((item) => {
      if (
        !has(deviceTypeUpdateMap, item.code) ||
        has(nameDuplicate, item.name)
      ) {
        dataError.push(item);
      } else {
        dataUpdate.push(item);
      }
    });

    const deviceTypeDocument = [...dataInsert, ...dataUpdate];
    const bulkOps = deviceTypeDocument.map((doc) => ({
      updateOne: {
        filter: {
          code: doc.code,
        },
        update: {
          $set: {
            code: doc.code,
            name: doc.name,
            description: doc.description,
          },
        },
        upsert: true,
      },
    }));
    const dataSuccess = await this.deviceTypeRepository.bulkWrite(bulkOps);

    return {
      dataError,
      dataSuccess,
    };
  }

  async create(
    data: CreateDeviceTypeRequestDto,
  ): Promise<ResponsePayload<any>> {
    try {
      const deviceTypeConst = DEVICE_TYPE_CONST.CODE;
      const lastRecord = await this.deviceTypeRepository.lastRecord();
      const codeCurrent =
        Number(lastRecord.code?.replace(deviceTypeConst.PREFIX, '')) || 0;
      data.code = generateCodeByPreviousCode(
        deviceTypeConst.PREFIX,
        codeCurrent,
      );
      const validate = await this.validateBeforeSave(data);
      if (validate.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validate;
      }

      const newObjectType = this.deviceTypeRepository.createEntity(data);
      const dataSave = await newObjectType.save();
      const dataReturn = plainToInstance(BasicResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CREATE '))
        .build();
    }
  }

  async update(
    request: UpdateDeviceTypeRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, ...data } = request;
    try {
      let deviceType = await this.deviceTypeRepository.findOneById(id);
      if (!deviceType) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.DEVICE_TYPE_NOT_FOUND'))
          .build();
      }

      const validate = await this.validateBeforeSave(request, true);
      if (validate.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validate;
      }
      deviceType = this.deviceTypeRepository.updateEntity(deviceType, data);
      await this.deviceTypeRepository.findByIdAndUpdate(id, deviceType);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }
  }

  async updateStatus(
    request: UpdateActiveStatusPayload,
  ): Promise<ResponsePayload<any>> {
    const { id, status } = request;

    try {
      const deviceType = await this.deviceTypeRepository.findOneById(id);
      if (!deviceType) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.DEVICE_TYPE_NOT_FOUND'))
          .build();
      }

      await this.deviceTypeRepository.findByIdAndUpdate(id, {
        $set: { active: status },
      });

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }
  }

  async list(request: ListDeviceTypeRequestDto): Promise<ResponsePayload<any>> {
    try {
      const { data, count } = await this.deviceTypeRepository.list(request);
      const dataReturn = plainToInstance(DetailDeviceTypeResponse, data, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder({
        items: dataReturn,
        meta: { page: request.page, total: count },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async detail(request: IdParamDto): Promise<ResponsePayload<any>> {
    try {
      const deviceType = await this.deviceTypeRepository.findOneByCondition({
        _id: request.id,
      });
      if (!deviceType) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.DEVICE_TYPE_NOT_FOUND'))
          .build();
      }
      const dataReturn = plainToInstance(DetailDeviceTypeResponse, deviceType, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  private async validateBeforeSave(request: any, isUpdate = false) {
    const conditionValidateNameUnique = isUpdate
      ? {
          name: { $regex: new RegExp(`^${request.name}$`, 'i') },
          _id: { $ne: request.id },
        }
      : {
          name: { $regex: new RegExp(`^${request.name}$`, 'i') },
        };
    const existsData = await this.deviceTypeRepository.findOneByCondition(
      conditionValidateNameUnique,
    );
    if (existsData) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.DEVICE_TYPE_NAME_HAS_EXISTS'),
        )
        .build();
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
