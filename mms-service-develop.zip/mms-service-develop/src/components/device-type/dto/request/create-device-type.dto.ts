import { DEVICE_TYPE_CONST } from '@components/device-type/device-type.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';
import { IsNotBlank } from 'src/validator/is-not-blank.validator';

export class CreateDeviceTypeRequestDto extends BaseDto {
  code: string;

  @ApiProperty()
  @MaxLength(DEVICE_TYPE_CONST.NAME.MAX_LENGTH)
  @IsString()
  @IsNotBlank()
  @IsNotEmpty()
  name: string;

  @ApiPropertyOptional()
  @MaxLength(DEVICE_TYPE_CONST.DESCRIPTION.MAX_LENGTH)
  @IsString()
  @IsOptional()
  description: string;
}
