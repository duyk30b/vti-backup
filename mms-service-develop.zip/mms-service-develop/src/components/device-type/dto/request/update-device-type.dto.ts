import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateDeviceTypeRequestDto } from './create-device-type.dto';

export class UpdateDeviceTypeRequestDto extends CreateDeviceTypeRequestDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  id: string;
}
