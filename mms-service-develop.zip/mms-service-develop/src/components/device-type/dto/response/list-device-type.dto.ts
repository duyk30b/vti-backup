import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';
import { DetailDeviceTypeResponse } from './detail-device-type.dto';

export class ListDeviceTypeResponse extends PaginationResponse {
  @Expose()
  @ApiProperty({ type: DetailDeviceTypeResponse, isArray: true })
  @Type(() => DetailDeviceTypeResponse)
  items: DetailDeviceTypeResponse[];
}
