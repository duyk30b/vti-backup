import { CODE_REGEX } from '@constant/common';

export const DEVICE_TYPE_CONST = {
  CODE: {
    MAX_LENGTH: 20,
    MIN_LENGTH: 6,
    COLUMN: 'code',
    PAD_CHAR: '0',
    PREFIX: 'KTB',
    REGEX: CODE_REGEX,
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
};
