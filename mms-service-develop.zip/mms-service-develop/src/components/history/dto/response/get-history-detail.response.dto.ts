import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsEnum } from 'class-validator';
import { HISTORY_ACTION_ENUM } from '@components/history/history.constant';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { UserResponseDto } from '@components/user/dto/response/user.response.dto';

class Reason {
  @ApiProperty()
  @Expose()
  reasonRef: string;

  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Expose()
  reason: BasicResponseDto;
}

class ContentResponse {
  @ApiProperty()
  @Expose()
  oldValue: string;

  @ApiProperty()
  @Expose()
  newValue: string;

  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Expose()
  oldObjectValue: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Expose()
  newObjectValue: BasicResponseDto;

  @ApiProperty()
  @Expose()
  valueField: string;
}

export class GetHistoryDetailResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  userId: number;

  @ApiProperty()
  @Expose()
  username: string;

  @ApiProperty()
  @Expose()
  @IsEnum(HISTORY_ACTION_ENUM)
  action: number;

  @ApiProperty()
  @Expose()
  objectRef: string;

  @ApiProperty({ type: ContentResponse, isArray: true })
  @Type(() => ContentResponse)
  @Expose()
  contents: ContentResponse[];

  @ApiProperty({ type: UserResponseDto })
  @Type(() => UserResponseDto)
  @Expose()
  createdBy: UserResponseDto;

  @ApiProperty({ type: Reason })
  @Type(() => Reason)
  @Expose()
  reason: Reason;
}
