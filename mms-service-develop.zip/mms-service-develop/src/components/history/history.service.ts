import { Inject, Injectable } from '@nestjs/common';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { HistoryServiceInterface } from '@components/history/interface/history.service.interface';

@Injectable()
export class HistoryService implements HistoryServiceInterface {
  constructor(
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,
  ) {}
}
