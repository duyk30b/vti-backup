export interface HistoryServiceInterface {}
