import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { History } from 'src/models/history/history.model';
import { HISTORY_REF_ENUM, HISTORY_REASON_REF_ENUM } from '../history.constant';

export interface HistoryRepositoryInterface
  extends BaseAbstractRepository<History> {
  createDocument(param: any): History;
  logHistoryForDocuments(
    objectPairs: { oldObject: any; newObject: any }[],
    documentRef: HISTORY_REF_ENUM,
    userId: number,
    reasonRef?: HISTORY_REASON_REF_ENUM,
    reasonId?: string,
  ): Promise<any>;
}
