import { MongooseModule } from '@nestjs/mongoose';
import { Module } from '@nestjs/common';
import { MaintenancePlanController } from './maintenance-plan.controller';
import { MaintenancePlanSchema } from 'src/models/maintenance-plan/maintenance-plan.schema';
import { MaintenancePlanRepository } from 'src/repository/maintenance-plan/maintenance-plan.repository';
import { MaintenancePlanService } from './maintenance-plan.service';
import { DeviceRepository } from 'src/repository/device/device.repository';
import { JobRepository } from 'src/repository/job/job.repository';
import { JobSchema } from 'src/models/job/job.schema';
import { DeviceGroupRepository } from 'src/repository/device-group/device-group.repository';
import { SupplyRepository } from 'src/repository/supply/supply.repository';
import { WarehouseSchema } from 'src/models/warehouse/warehouse.schema';
import { WarehouseRepository } from 'src/repository/warehouse/warehouse.repository';
import { InventorySchema } from 'src/models/warehouse-inventories/inventory.schema';
import { InventoryRepository } from 'src/repository/warehouse-inventories/inventory.repository';
import { DeviceTemplateScheduleRepository } from 'src/repository/device-template-schedule/device-template-schedule.repository';
import { DeviceTemplateScheduleSchema } from 'src/models/device-template-schedule/device-template-schedule.schema';
import { SettingJobRepository } from 'src/repository/setting/setting-job.repository';
import { SettingJobSchema } from 'src/models/setting-job/setting-job.schema';
import { ItemModule } from '@components/item/item.module';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'MaintenancePlan', schema: MaintenancePlanSchema },
      { name: 'Job', schema: JobSchema },
      { name: 'DeviceTemplateSchedule', schema: DeviceTemplateScheduleSchema },
      { name: 'Warehouse', schema: WarehouseSchema },
      { name: 'Inventory', schema: InventorySchema },
      { name: 'SettingJob', schema: SettingJobSchema },
    ]),
    ItemModule,
  ],
  controllers: [MaintenancePlanController],
  providers: [
    {
      provide: 'MaintenancePlanRepositoryInterface',
      useClass: MaintenancePlanRepository,
    },
    {
      provide: 'MaintenancePlanServiceInterface',
      useClass: MaintenancePlanService,
    },
    {
      provide: 'DeviceRepositoryInterface',
      useClass: DeviceRepository,
    },
    {
      provide: 'InventoryRepositoryInterface',
      useClass: InventoryRepository,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    {
      provide: 'JobRepositoryInterface',
      useClass: JobRepository,
    },
    {
      provide: 'DeviceGroupRepositoryInterface',
      useClass: DeviceGroupRepository,
    },
    {
      provide: 'DeviceTemplateScheduleRepositoryInterface',
      useClass: DeviceTemplateScheduleRepository,
    },
    {
      provide: 'SupplyRepositoryInterface',
      useClass: SupplyRepository,
    },
    {
      provide: 'SettingJobRepositoryInterface',
      useClass: SettingJobRepository,
    },
  ],
  exports: [
    {
      provide: 'MaintenancePlanServiceInterface',
      useClass: MaintenancePlanService,
    },
    {
      provide: 'MaintenancePlanRepositoryInterface',
      useClass: MaintenancePlanRepository,
    },
  ],
})
export class MaintenancePlanModule {}
