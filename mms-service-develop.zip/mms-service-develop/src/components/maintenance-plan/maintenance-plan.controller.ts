import { DeviceBasicResponseDto } from '@components/device/dto/response/device-basic.response.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { PermissionInterceptor } from '@core/interceptors/permission.interceptor';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Injectable,
  Param,
  Post,
  Put,
  Query,
  UseInterceptors,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { mergePayload } from '@utils/common';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import {
  CREATE_MAINTENANCE_PLAN_PERMISSION,
  DELETE_MAINTENANCE_PLAN_PERMISSION,
  DETAIL_MAINTENANCE_PLAN_PERMISSION,
  LIST_MAINTENANCE_PLAN_PERMISSION,
  UPDATE_MAINTENANCE_PLAN_PERMISSION,
  UPDATE_STATUS_MAINTENANCE_PLAN_PERMISSION,
} from '@utils/permissions/maintenance-plan';
import {
  CREATE_PLAN_PERMISSION,
  UPDATE_PLAN_PERMISSION,
} from '@utils/permissions/plan';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { ListMaintenancePlanQuery } from './dto/query/list-maintenance-plan.query';
import { CreateMaintenancePlanRequest } from './dto/request/create-maintenance-plan.request';
import { DetailMaintenancePlanByDeviceParamDto } from './dto/request/detail-maintenance-plan-by-device.request';
import { UpdateMaintenancePlanRequest } from './dto/request/update-maintenance-plan.request';
import { UpdateStatusMaintenancePlanParamDto } from './dto/request/update-status-maintenance-plan.request';
import { ListDataMaintenancePlanResponse } from './dto/response/list-maintenance-plan.response';
import { MaintenancePlanServiceInterface } from './interface/maintenance-plan.service.interface';

@Injectable()
@Controller('maintenance-plans')
export class MaintenancePlanController {
  constructor(
    @Inject('MaintenancePlanServiceInterface')
    private readonly maintenancePlanService: MaintenancePlanServiceInterface,
  ) {}

  @PermissionCode(CREATE_MAINTENANCE_PLAN_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Post('')
  @ApiOperation({
    tags: ['Maintenance Plan'],
    summary: 'Create maintenance plan',
    description: 'Create maintenance plan',
  })
  @ApiResponse({
    status: 200,
    description: 'Created successfully',
    type: SuccessResponse,
  })
  async create(@Body() payload: CreateMaintenancePlanRequest): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenancePlanService.create(request);
  }

  @PermissionCode(
    UPDATE_MAINTENANCE_PLAN_PERMISSION.code,
    DETAIL_MAINTENANCE_PLAN_PERMISSION.code,
  )
  @UseInterceptors(PermissionInterceptor)
  @Put('/:id')
  @ApiOperation({
    tags: ['Maintenance Plan'],
    summary: 'Update maintenance plan',
    description: 'Update maintenance plan',
  })
  @ApiResponse({
    status: 200,
    description: 'Updated successfully',
    type: SuccessResponse,
  })
  async update(
    @Body() payload: UpdateMaintenancePlanRequest,
    @Param() param: IdParamDto,
  ): Promise<any> {
    const { request, responseError } = mergePayload(payload, param);
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenancePlanService.update(request);
  }

  @PermissionCode(DELETE_MAINTENANCE_PLAN_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Maintenance Plan'],
    summary: 'Delete maintenance plan',
    description: 'Delete maintenance plan',
  })
  @ApiResponse({
    status: 200,
    description: 'Deleted successfully',
    type: SuccessResponse,
  })
  async delete(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenancePlanService.delete(request);
  }

  @PermissionCode(
    LIST_MAINTENANCE_PLAN_PERMISSION.code,
    CREATE_PLAN_PERMISSION.code,
    UPDATE_PLAN_PERMISSION.code,
  )
  @UseInterceptors(PermissionInterceptor)
  @Get('')
  @ApiOperation({
    tags: ['Maintenance Plan'],
    summary: 'List maintenance plan',
    description: 'List maintenance plan',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ListDataMaintenancePlanResponse,
  })
  async list(@Query() query: ListMaintenancePlanQuery): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenancePlanService.list(request);
  }

  @PermissionCode(
    DETAIL_MAINTENANCE_PLAN_PERMISSION.code,
    UPDATE_MAINTENANCE_PLAN_PERMISSION.code,
    CREATE_PLAN_PERMISSION.code,
    UPDATE_PLAN_PERMISSION.code,
  )
  @UseInterceptors(PermissionInterceptor)
  @Get('/:id')
  @ApiOperation({
    tags: ['Maintenance Plan'],
    summary: 'Chi tiết kế hoạch bảo trì',
    description: 'Chi tiết kế hoạch bảo trì',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ListDataMaintenancePlanResponse,
  })
  async detail(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenancePlanService.detail(request);
  }

  @PermissionCode(UPDATE_STATUS_MAINTENANCE_PLAN_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Put('/:id/:action')
  @ApiOperation({
    tags: ['Maintenance Plan'],
    summary: 'Change status maintenance plan',
    description: 'Change status maintenance plan',
  })
  @ApiResponse({
    status: 200,
    description: 'Update status',
    type: SuccessResponse,
  })
  async changeStatus(
    @Param() param: UpdateStatusMaintenancePlanParamDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenancePlanService.changeStatus(request);
  }

  @PermissionCode(DETAIL_MAINTENANCE_PLAN_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get('/:id/:deviceId/device')
  @ApiOperation({
    tags: ['Maintenance Plan'],
    summary: 'Detail by device maintenance plan',
    description: 'Detail by device maintenance plan',
  })
  @ApiResponse({
    status: 200,
    description: 'Update status',
    type: SuccessResponse,
  })
  async detailByDevice(
    @Param() param: DetailMaintenancePlanByDeviceParamDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenancePlanService.detailByDevice(request);
  }

  @Get('/:id/supplies')
  @ApiOperation({
    tags: ['Maintenance Plan'],
    summary: 'Danh sách dự trù vtpt theo kế hoạch bảo trì',
    description: 'Danh sách dự trù vtpt theo kế hoạch bảo trì',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ListDataMaintenancePlanResponse,
  })
  async suppliesByPlan(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenancePlanService.suppliesByPlan(request);
  }

  @PermissionCode(UPDATE_MAINTENANCE_PLAN_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get('/:id/devices')
  @ApiOperation({
    tags: ['Maintenance Plan'],
    summary: 'List device by maintenance plan id',
    description: 'List device by maintenance plan id',
  })
  @ApiResponse({
    status: 200,
    description: 'Get list successfully',
    type: DeviceBasicResponseDto,
  })
  async listDeviceByPlan(
    @Query() query: PaginationQuery,
    @Param() param: IdParamDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    const { request: id, responseError: responseParamError } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }
    request.id = id;
    return await this.maintenancePlanService.listDeviceByPlan(request);
  }
}
