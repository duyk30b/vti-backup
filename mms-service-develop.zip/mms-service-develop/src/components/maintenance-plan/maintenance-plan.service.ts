import { DeviceRepositoryInterface } from '@components/device/interface/device.repository.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import {
  difference,
  flatMap,
  flatMapDeep,
  isEmpty,
  keyBy,
  map,
  uniq,
} from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { CreateMaintenancePlanRequest } from './dto/request/create-maintenance-plan.request';
import { UpdateMaintenancePlanRequest } from './dto/request/update-maintenance-plan.request';
import { MaintenancePlanRepositoryInterface } from './interface/maintenance-plan.repository.interface';
import { MaintenancePlanServiceInterface } from './interface/maintenance-plan.service.interface';
import * as moment from 'moment';
import {
  MAINTENANCE_PLAN_ACTION_ENUM,
  MAINTENANCE_PLAN_CODE_CONST,
  MAINTENANCE_PLAN_STATUS_ENUM,
} from './maintenance-plan.constant';
import { ListMaintenancePlanQuery } from './dto/query/list-maintenance-plan.query';
import { plainToInstance } from 'class-transformer';
import { ListMaintenancePlanResponse } from './dto/response/list-maintenance-plan.response';
import { DetailMaintenancePlanResponse } from './dto/response/detail-maintenance-plan.response';
import { UpdateStatusMaintenancePlanParamDto } from './dto/request/update-status-maintenance-plan.request';
import { JOB_STATUS_ENUM, JOB_TYPE_ENUM } from '@components/job/job.constant';
import { ACTIVE_ENUM, SUNDAY_DAY } from '@constant/common';
import { JobRepositoryInterface } from '@components/job/interface/job.repository.interface';
import { MaintenancePlan } from 'src/models/maintenance-plan/maintenance-plan.model';
import { DetailMaintenancePlanByDeviceParamDto } from './dto/request/detail-maintenance-plan-by-device.request';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { Types } from 'mongoose';
import { DeviceGroupRepositoryInterface } from '@components/device-group/interface/device-group.repository.interface';
import { SupplyRepositoryInterface } from '@components/supply/interface/supply.repository.interface';
import { ListSupplyByMaintenancePlanResponse } from './dto/response/list-supply-by-maintenance-plan.response';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { DeviceBasicResponseDto } from '@components/device/dto/response/device-basic.response.dto';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';
import { InventoryRepositoryInterface } from '@components/warehouse/interface/inventory.repository.interface';
import { DEFINE_DAY } from '@components/cron/cron.constants';
import { HISTORY_ACTION_ENUM } from '@components/history/history.constant';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { SettingJobRepositoryInterface } from '@components/setting/interface/setting-job.repository.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';

@Injectable()
export class MaintenancePlanService implements MaintenancePlanServiceInterface {
  constructor(
    @Inject('MaintenancePlanRepositoryInterface')
    private readonly maintenancePlanRepository: MaintenancePlanRepositoryInterface,

    @Inject('DeviceRepositoryInterface')
    private readonly deviceRepository: DeviceRepositoryInterface,

    @Inject('JobRepositoryInterface')
    private readonly jobRepository: JobRepositoryInterface,

    @Inject('DeviceGroupRepositoryInterface')
    private readonly deviceGroupRepository: DeviceGroupRepositoryInterface,

    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,

    @Inject('InventoryRepositoryInterface')
    private readonly inventoryRepository: InventoryRepositoryInterface,

    @Inject('SupplyRepositoryInterface')
    private readonly supplyRepository: SupplyRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('SettingJobRepositoryInterface')
    private readonly settingJobRepository: SettingJobRepositoryInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(
    request: CreateMaintenancePlanRequest,
  ): Promise<ResponsePayload<any>> {
    const validate = await this.validateBeforeSave(request);
    if (validate.statusCode !== ResponseCodeEnum.SUCCESS) {
      return new ApiError(validate.responseCode, validate.message).toResponse();
    }
    request.code =
      await this.maintenancePlanRepository.generateNextCodeWithYear(
        MAINTENANCE_PLAN_CODE_CONST.PREFIX,
      );
    const maintenancePlanDocument =
      this.maintenancePlanRepository.createDocument(request);

    const dataSave = await this.maintenancePlanRepository.create(
      maintenancePlanDocument,
    );
    const dataReturn = plainToInstance(BasicResponseDto, dataSave, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async update(
    request: UpdateMaintenancePlanRequest & IdParamDto,
  ): Promise<ResponsePayload<any>> {
    const maintenancePlan =
      await this.maintenancePlanRepository.findOneByCondition({
        ...request.permissionCondition,
        _id: request.id,
      });

    if (!maintenancePlan) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (maintenancePlan.status === MAINTENANCE_PLAN_STATUS_ENUM.CONFIRMED) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.BAD_REQUEST'),
      ).toResponse();
    }

    const validate = await this.validateBeforeSave(request, request.id);
    if (validate.statusCode !== ResponseCodeEnum.SUCCESS) {
      return new ApiError(validate.responseCode, validate.message).toResponse();
    }

    const maintenancePlanDocument =
      this.maintenancePlanRepository.updateDocument(maintenancePlan, request);

    await this.maintenancePlanRepository.findByIdAndUpdate(
      request.id,
      maintenancePlanDocument,
    );

    return new ResponseBuilder()
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async validateBeforeSave(
    request: CreateMaintenancePlanRequest,
    id: string = null,
  ): Promise<any> {
    const isValidDate = this.validateDateRange(
      request.planFrom,
      request.planTo,
    );

    if (!isValidDate) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.INVALID_RANGE_DATE'),
      ).toResponse();
    }
    const deviceIds = [];
    const deviceGroupIds = [];
    request.details.forEach((e) => {
      deviceIds.push(e.deviceId);
      deviceGroupIds.push(e.deviceGroupId);
    });
    let conditionMaintenancePlanTime: any = {
      factoryId: request.factoryId,
      'details.deviceId': { $in: deviceIds },

      $or: [
        {
          planFrom: {
            $lte: moment(request.planFrom).endOf('day').toDate(),
          },
          planTo: {
            $gte: moment(request.planFrom).startOf('day').toDate(),
          },
        },
        {
          planFrom: {
            $lte: moment(request.planTo).endOf('day').toDate(),
          },
          planTo: {
            $gte: moment(request.planTo).startOf('day').toDate(),
          },
        },
        {
          planFrom: {
            $gte: moment(request.planFrom).startOf('day').toDate(),
          },
          planTo: {
            $lte: moment(request.planTo).endOf('day').toDate(),
          },
        },
      ],
    };

    if (id) {
      conditionMaintenancePlanTime = {
        ...conditionMaintenancePlanTime,
        _id: { $ne: new Types.ObjectId(id) },
      };
    }

    const maintenancePlanExistTime =
      await this.maintenancePlanRepository.findOneByCondition(
        conditionMaintenancePlanTime,
      );

    if (maintenancePlanExistTime) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.INVALID_MAINTENANCE_PLAN_TIME'),
      ).toResponse();
    }

    const isValidDeviceTimes = await this.validateDeviceTime(
      request.details,
      request.factoryId,
    );

    if (!isValidDeviceTimes) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.BAD_REQUEST'),
      ).toResponse();
    }
    const deviceGroupFilter = {};
    if (!isEmpty(request?.deviceGroupIds)) {
      deviceGroupFilter['_id'] = {
        $in: request.deviceGroupIds.map((e) => new Types.ObjectId(e)),
      };
    }
    if (!isEmpty(request?.articleDeviceGroupIds)) {
      deviceGroupFilter['articleDeviceGroupId'] = {
        $in: request?.articleDeviceGroupIds.map((e) => new Types.ObjectId(e)),
      };
    }

    const deviceGroups = await this.deviceGroupRepository.findAllByCondition(
      deviceGroupFilter,
    );

    const deviceGroupExistIds = deviceGroups.map((e) => e._id.toString());

    if (!isEmpty(request.deviceGroupIds)) {
      const isDiff = !isEmpty(
        difference(request.deviceGroupIds, deviceGroupExistIds),
      );
      if (isDiff) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.BAD_REQUEST'),
        ).toResponse();
      }
    }

    const deviceFilter = {
      factoryId: request.factoryId,
      active: ACTIVE_ENUM.ACTIVE,
    };
    if (!isEmpty(request.deviceGroupIds)) {
      deviceFilter['deviceGroupId'] = {
        $in: request.deviceGroupIds.map((e) => new Types.ObjectId(e)),
      };
    } else {
      deviceFilter['deviceGroupId'] = {
        $in: deviceGroupExistIds.map((e) => new Types.ObjectId(e)),
      };
    }
    if (!isEmpty(request.areaIds)) {
      deviceFilter['areaId'] = {
        $in: request.areaIds.map((e) => new Types.ObjectId(e)),
      };
    }

    const devices = await this.deviceRepository.findAllByCondition(
      deviceFilter,
    );
    const deviceIdExists = devices.map((e) => e._id.toString());

    const isDiffDevice = !isEmpty(difference(deviceIds, deviceIdExists));
    const isDiffDeviceGroup = !isEmpty(
      difference(deviceGroupIds, deviceGroupExistIds),
    );

    if (isDiffDevice || isDiffDeviceGroup) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate(
          'error.DEVICE_OR_DEVICE_GROUP_NOT_IN_FACTORY_SELECTED',
        ),
      ).toResponse();
    }

    let flag = true;
    for (let i = 0; i < request.details.length; i++) {
      const detail = request.details[i];
      if (
        !(
          moment(detail.fromDate).isSameOrAfter(
            moment(request.planFrom),
            'day',
          ) &&
          moment(detail.toDate).isSameOrBefore(moment(request.planTo), 'day') &&
          moment(detail.fromDate).isSameOrBefore(moment(detail.toDate), 'day')
        )
      ) {
        flag = false;
        break;
      }
    }

    if (!flag) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.BAD_REQUEST'),
      ).toResponse();
    }
    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async delete(request: IdParamDto): Promise<ResponsePayload<any>> {
    const maintenancePlan =
      await this.maintenancePlanRepository.findOneByCondition({
        ...request.permissionCondition,
        _id: request.id,
      });

    if (!maintenancePlan) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (maintenancePlan.status === MAINTENANCE_PLAN_STATUS_ENUM.CONFIRMED) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.BAD_REQUEST'),
      ).toResponse();
    }

    await this.maintenancePlanRepository.softDelete(request.id);

    return new ResponseBuilder()
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async list(request: ListMaintenancePlanQuery): Promise<ResponsePayload<any>> {
    const { total, data } = await this.maintenancePlanRepository.list(request);

    const dataReturn = plainToInstance(ListMaintenancePlanResponse, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder({
      items: dataReturn,
      meta: { page: request.page, total: total },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async detail(request: IdParamDto): Promise<ResponsePayload<any>> {
    const maintenancePlan =
      await this.maintenancePlanRepository.findOneWithPopulate(
        { ...request.permissionCondition, _id: request.id },
        [
          {
            path: 'articleDeviceGroups deviceGroups areas details.deviceGroup',
          },
          {
            path: 'details.device',
            populate: {
              path: 'areaId',
            },
          },
        ],
      );

    if (!maintenancePlan) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const factory = await this.userService.getFactoryById(
      maintenancePlan?.factoryId,
    );

    maintenancePlan['factory'] = factory;

    const dataReturn = plainToInstance(
      DetailMaintenancePlanResponse,
      maintenancePlan,
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder(dataReturn)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async changeStatus(
    request: UpdateStatusMaintenancePlanParamDto,
  ): Promise<ResponsePayload<any>> {
    const { action } = request;

    const maintenancePlan =
      await this.maintenancePlanRepository.findOneByCondition({
        ...request.permissionCondition,
        _id: request.id,
      });
    if (!maintenancePlan) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const status = this.getStatusByAction(action);

    const isStatusValid = this.checkStatusValid(maintenancePlan.status, status);

    if (!isStatusValid) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INVALID_STATUS'))
        .build();
    }

    if (status === MAINTENANCE_PLAN_STATUS_ENUM.CONFIRMED) {
      await this.createJob(maintenancePlan);
    }

    await this.maintenancePlanRepository.findByIdAndUpdate(
      maintenancePlan._id,
      {
        status: status,
      },
    );

    return new ResponseBuilder()
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async detailByDevice(
    request: DetailMaintenancePlanByDeviceParamDto,
  ): Promise<ResponsePayload<any>> {
    const maintenancePlan =
      await this.maintenancePlanRepository.findOneWithPopulate(
        { ...request.permissionCondition, _id: request.id },
        [
          { path: 'articleDeviceGroup deviceGroup area details.deviceGroup' },
          {
            path: 'details.device',
            populate: {
              path: 'areaId',
            },
          },
        ],
      );

    if (!maintenancePlan) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const dataReturn = plainToInstance(
      DetailMaintenancePlanResponse,
      maintenancePlan,
      { excludeExtraneousValues: true },
    );

    dataReturn.device = dataReturn.details.find(
      (e) => e.device.id === request.deviceId,
    );

    if (!dataReturn.device) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    delete dataReturn.details;

    return new ResponseBuilder(dataReturn)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async suppliesByPlan(request: IdParamDto): Promise<any> {
    const { id } = request;

    const maintenancePlan =
      await this.maintenancePlanRepository.findOneByCondition({
        _id: id,
      });
    if (!maintenancePlan) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const jobs = await this.jobRepository.findAllWithPopulate(
      { maintenancePlanId: id },
      { path: 'device' },
    );
    const listSupply = flatMapDeep(jobs, 'device.supplies');
    const countSupplies = {};
    listSupply.forEach((supply) => {
      if (countSupplies[supply.supplyId]) {
        countSupplies[supply.supplyId] += supply.quantity;
      } else {
        countSupplies[supply.supplyId] = supply.quantity;
      }
    });
    const supplyIds = Object.keys(countSupplies);
    const warehouses = await this.warehouseRepository.findAllByCondition({
      factoryId: maintenancePlan?.factoryId,
    });
    const supplyInventories =
      await this.inventoryRepository.getInventoryByWarehousesAndAssets({
        warehouseIds: map(warehouses, '_id'),
        assetIds: supplyIds,
      });
    const supplyInventoryMap = keyBy(supplyInventories, '_id.assetId');
    const supplies = await this.supplyRepository.findAllWithPopulate(
      { _id: { $in: supplyIds } },
      ['supplyGroup', 'vendor', 'supplyType'],
    );
    const unitIds = map(supplies, 'unitId');
    const units = await this.itemService.getListUnit([
      {
        column: 'ids',
        text: uniq(unitIds).toString(),
      },
    ]);
    const unitMap = keyBy(units, 'id');
    supplies.forEach((supply) => {
      supply['quantity'] = countSupplies[supply?._id];
      supply['maxStockQuantity'] =
        supplyInventoryMap[supply._id.toString()]?.maxStockQuantity ?? 0;
      supply['minStockQuantity'] =
        supplyInventoryMap[supply._id.toString()]?.minStockQuantity ?? 0;
      supply['stockQuantity'] =
        supplyInventoryMap[supply._id.toString()]?.stockQuantity ?? 0;
      supply['unit'] = unitMap[supply.unitId];
    });

    const dataReturn = plainToInstance(
      ListSupplyByMaintenancePlanResponse,
      supplies,
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder({ items: dataReturn })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private checkStatusValid(oldStatus: number, newStatus: number): boolean {
    switch (newStatus) {
      case MAINTENANCE_PLAN_STATUS_ENUM.CONFIRMED:
      case MAINTENANCE_PLAN_STATUS_ENUM.REJECTED:
        return oldStatus === MAINTENANCE_PLAN_STATUS_ENUM.WAITING_CONFIRM;
      default:
        return false;
    }
  }

  private getStatusByAction(action: string): number {
    switch (action) {
      case MAINTENANCE_PLAN_ACTION_ENUM.CONFIRM:
        return MAINTENANCE_PLAN_STATUS_ENUM.CONFIRMED;
      case MAINTENANCE_PLAN_ACTION_ENUM.REJECT:
        return MAINTENANCE_PLAN_STATUS_ENUM.REJECTED;
      default:
        return MAINTENANCE_PLAN_STATUS_ENUM.WAITING_CONFIRM;
    }
  }

  private async validateDeviceTime(
    details: any[],
    factoryId: number,
  ): Promise<boolean> {
    const conditionDevice = [];
    details.forEach((e) => {
      const fromDate = moment(e.fromDate).startOf('day').toDate();
      const toDate = moment(e.toDate).endOf('day').toDate();
      conditionDevice.push({
        $and: [
          { status: MAINTENANCE_PLAN_STATUS_ENUM.CONFIRMED },
          { 'details.deviceId': e.deviceId },
          {
            $or: [
              {
                'details.fromDate': { $lte: fromDate },
                'details.toDate': { $gte: fromDate },
              },
              {
                'details.fromDate': { $lte: toDate },
                'details.toDate': { $gte: toDate },
              },
              {
                'details.fromDate': { $lte: fromDate },
                'details.toDate': { $gte: toDate },
              },
            ],
          },
        ],
      });
    });

    const maintenancePlanExistDate =
      await this.maintenancePlanRepository.findOneByCondition({
        factoryId,
        $or: conditionDevice,
      });

    if (maintenancePlanExistDate) {
      return false;
    }
    return true;
  }

  private async createJob(maintenancePlan: MaintenancePlan): Promise<any> {
    const deviceIds = maintenancePlan.details.map((e) => e.deviceId);
    const deviceTimeMap = keyBy(maintenancePlan.details, 'deviceId');

    const devices = await this.deviceRepository.findAllWithPopulate(
      {
        _id: {
          $in: deviceIds,
        },
        active: ACTIVE_ENUM.ACTIVE,
      },
      'deviceTemplateSchedule maintenanceTemplate',
    );
    const dataInserts = [];
    const maintainJobName = await this.i18n.translate('text.maintainJobName');
    const messageCreatedJob = await this.i18n.translate(
      'text.SYSTEM_CREATE_MAINTAIN_JOB',
    );
    const jobConfiguration = await this.settingJobRepository.findAllByCondition(
      { type: { $in: [JOB_TYPE_ENUM.MAINTAIN] } },
    );
    const autoGenerateJobMaintainOnSunday = this.getConfigurationGenerateJob(
      jobConfiguration,
      JOB_TYPE_ENUM.MAINTAIN,
    );
    devices.forEach((device) => {
      const maintenancePlanDevice = deviceTimeMap[device._id.toString()];
      const maintainTemplate = keyBy(
        device['maintenanceTemplate']?.details,
        '_id',
      );
      for (
        let i = moment(maintenancePlanDevice.fromDate).clone();
        i.isSameOrBefore(moment(maintenancePlanDevice.toDate), 'day');
        i.add(1, 'day')
      ) {
        if (autoGenerateJobMaintainOnSunday && i.day() === SUNDAY_DAY) {
          continue;
        }
        const jobMaintain = device['deviceTemplateSchedule']?.maintain?.filter(
          (e) => {
            return i.diff(moment(e.nextSchedule), 'day') >= 0;
          },
        );
        jobMaintain?.forEach((e) => {
          e.lastSchedule = e.nextSchedule;
          e.nextSchedule = i
            .clone()
            .add(maintainTemplate[e.templateId]?.periodTime, 'day')
            .toDate();
          const isShow = i.isSameOrBefore(
            moment().add(DEFINE_DAY.THREE_DAY, 'day'),
            'day',
          );

          dataInserts.push({
            name: maintainJobName.replace('{deviceName}', device.name ?? ''),
            description: e.title,
            status: JOB_STATUS_ENUM.NON_ASSIGN,
            jobTypeId: e.templateId,
            planFrom: i.toDate(),
            planTo: e.nextSchedule,
            isShow,
            obligatory: e.obligatory,
            maintenancePlanId: maintenancePlan._id,
            type: JOB_TYPE_ENUM.MAINTAIN,
            histories: [
              {
                createdAt: new Date(),
                action: HISTORY_ACTION_ENUM.CREATE,
                content: messageCreatedJob,
                status: JOB_STATUS_ENUM.NON_ASSIGN,
              },
            ],
            deviceId: device._id,
          });
        });
      }
    });

    const jobDocuments = await this.jobRepository.createEntities(dataInserts);
    await this.jobRepository.create(jobDocuments);
  }

  private validateDateRange(fromDate: Date, toDate: Date): boolean {
    if (moment(toDate).isBefore(moment(fromDate), 'day')) {
      return false;
    }

    if (!moment().isSameOrBefore(moment(fromDate), 'day')) {
      return false;
    }

    if (moment(toDate).diff(moment(fromDate), 'year') > 1) {
      return false;
    }

    return true;
  }

  async listDeviceByPlan(
    request: IdParamDto & PaginationQuery,
  ): Promise<ResponsePayload<any>> {
    const result = await this.maintenancePlanRepository.listDevices(request);
    const res = plainToInstance(
      DeviceBasicResponseDto,
      flatMap(result, 'device'),
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder({ items: res })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private getConfigurationGenerateJob = (jobConfiguration = [], jobType) => {
    return jobConfiguration.find((job) => job.type === jobType)
      ?.autoGenerateOnSunday;
  };
}
