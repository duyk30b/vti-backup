import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty, ApiResponseProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Transform } from 'class-transformer';

export class ListMaintenancePlanResponse extends BaseResponseDto {
  @ApiResponseProperty()
  @Expose()
  code: string;

  @ApiResponseProperty()
  @Expose()
  name: string;

  @ApiResponseProperty()
  @Expose()
  planFrom: Date;

  @ApiResponseProperty()
  @Expose()
  planTo: Date;

  @ApiResponseProperty()
  @Transform(({ obj }) => obj?.details?.length)
  @Expose()
  countDevice: number;

  @ApiResponseProperty()
  @Expose()
  status: number;
}

export class ListDataMaintenancePlanResponse extends PaginationResponse {
  @ApiProperty({
    isArray: true,
    type: ListMaintenancePlanResponse,
  })
  @Expose()
  items: ListMaintenancePlanResponse[];
}
