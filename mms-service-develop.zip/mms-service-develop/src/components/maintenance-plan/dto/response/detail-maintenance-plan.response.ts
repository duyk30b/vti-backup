import { DeviceBasicResponseDto } from '@components/device/dto/response/device-basic.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty, ApiResponseProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { Expose, plainToInstance, Transform, Type } from 'class-transformer';

class DeviceMaintenancePlanDetailResponse extends DeviceBasicResponseDto {
  @ApiResponseProperty()
  @Expose()
  code: string;

  @ApiResponseProperty()
  @Expose()
  name: string;

  @ApiResponseProperty({
    type: BasicResponseDto,
  })
  @Transform(({ obj }) =>
    plainToInstance(BasicResponseDto, obj?.areaId, {
      excludeExtraneousValues: true,
    }),
  )
  @Expose()
  area: BasicResponseDto;
}

class DetailMaintenancePlanDetailResponse {
  @ApiResponseProperty({
    type: BasicResponseDto,
  })
  @Type(() => BasicResponseDto)
  @Expose()
  deviceGroup: BasicResponseDto;

  @ApiResponseProperty({
    type: DeviceMaintenancePlanDetailResponse,
  })
  @Type(() => DeviceMaintenancePlanDetailResponse)
  @Expose()
  device: DeviceMaintenancePlanDetailResponse;

  @ApiResponseProperty()
  @Expose()
  fromDate: Date;

  @ApiResponseProperty()
  @Expose()
  toDate: Date;
}

export class DetailMaintenancePlanResponse extends BaseResponseDto {
  @ApiResponseProperty()
  @Expose()
  code: string;

  @ApiResponseProperty()
  @Expose()
  name: string;

  @ApiResponseProperty()
  @Expose()
  planFrom: Date;

  @ApiResponseProperty()
  @Expose()
  planTo: Date;

  @ApiResponseProperty()
  @Expose()
  status: number;

  @ApiProperty({
    type: BasicResponseDto,
    isArray: true,
  })
  @Type(() => BasicResponseDto)
  @Expose()
  deviceGroups: BasicResponseDto[];

  @ApiResponseProperty({
    type: BasicSqlDocumentResponse,
  })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  factory: BasicSqlDocumentResponse;

  @ApiProperty({
    type: BasicResponseDto,
    isArray: true,
  })
  @Type(() => BasicResponseDto)
  @Expose()
  articleDeviceGroups: BasicResponseDto[];

  @ApiProperty({
    type: BasicResponseDto,
    isArray: true,
  })
  @Type(() => BasicResponseDto)
  @Expose()
  areas: BasicResponseDto[];

  @ApiProperty({
    type: DetailMaintenancePlanDetailResponse,
    isArray: true,
  })
  @Type(() => DetailMaintenancePlanDetailResponse)
  @Expose()
  details: DetailMaintenancePlanDetailResponse[];

  @ApiProperty({
    type: DetailMaintenancePlanDetailResponse,
  })
  @Type(() => DetailMaintenancePlanDetailResponse)
  @Expose()
  device: DetailMaintenancePlanDetailResponse;
}
