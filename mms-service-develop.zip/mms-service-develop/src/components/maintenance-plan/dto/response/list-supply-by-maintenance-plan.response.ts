import { SupplyTypeDto } from '@components/supply/dto/response/get-all-supply.response.dto';
import { ApiProperty, ApiResponseProperty } from '@nestjs/swagger';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { Expose, Type } from 'class-transformer';

export class ListSupplyByMaintenancePlanResponse extends BasicResponseDto {
  @ApiResponseProperty()
  @Expose()
  quantity: number;

  @ApiResponseProperty()
  @Expose()
  vendor: BasicResponseDto;

  @ApiResponseProperty()
  @Expose()
  supplyGroup: BasicResponseDto;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  unit: BasicSqlDocumentResponse;

  @ApiProperty({ type: SupplyTypeDto })
  @Type(() => SupplyTypeDto)
  @Expose()
  supplyType: SupplyTypeDto;

  @ApiResponseProperty()
  @Expose()
  price: number;

  @ApiResponseProperty()
  @Expose()
  maxStockQuantity: number;

  @ApiResponseProperty()
  @Expose()
  minStockQuantity: number;

  @ApiResponseProperty()
  @Expose()
  stockQuantity: number;
}
