import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsDateString,
  IsInt,
  IsMongoId,
  IsNotEmpty,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

class CreateMaintenanceDetailRequest {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  deviceGroupId: string;

  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  deviceId: string;

  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  fromDate: Date;

  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  toDate: Date;
}

export class CreateMaintenancePlanRequest extends BaseDto {
  code: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  planFrom: Date;

  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  planTo: Date;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  factoryId: number;

  @ApiProperty()
  @IsMongoId({ each: true })
  @IsArray()
  @IsOptional()
  articleDeviceGroupIds: string[];

  @ApiProperty()
  @IsMongoId({ each: true })
  @IsArray()
  @IsOptional()
  deviceGroupIds: string[];

  @ApiProperty()
  @IsMongoId({ each: true })
  @IsArray()
  @IsOptional()
  areaIds: string[];

  @ApiProperty({
    isArray: true,
    type: CreateMaintenanceDetailRequest,
  })
  @ArrayUnique((item: CreateMaintenanceDetailRequest) => item.deviceId)
  @ValidateNested({ each: true })
  @ArrayNotEmpty()
  details: CreateMaintenanceDetailRequest[];
}
