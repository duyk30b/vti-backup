import { MAINTENANCE_PLAN_ACTION_ENUM } from '@components/maintenance-plan/maintenance-plan.constant';
import { ApiProperty } from '@nestjs/swagger';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { IsEnum, IsNotEmpty } from 'class-validator';

export class UpdateStatusMaintenancePlanParamDto extends IdParamDto {
  @ApiProperty({
    enum: MAINTENANCE_PLAN_ACTION_ENUM,
  })
  @IsEnum(MAINTENANCE_PLAN_ACTION_ENUM)
  @IsNotEmpty()
  action: string;
}
