import { CreateMaintenancePlanRequest } from './create-maintenance-plan.request';

export class UpdateMaintenancePlanRequest extends CreateMaintenancePlanRequest {}
