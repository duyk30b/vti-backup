import { ApiProperty } from '@nestjs/swagger';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { IsMongoId, IsNotEmpty } from 'class-validator';

export class DetailMaintenancePlanByDeviceParamDto extends IdParamDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  deviceId: string;
}
