import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { MaintenancePlan } from 'src/models/maintenance-plan/maintenance-plan.model';
import { ListMaintenancePlanQuery } from '../dto/query/list-maintenance-plan.query';
import { CreateMaintenancePlanRequest } from '../dto/request/create-maintenance-plan.request';
import { UpdateMaintenancePlanRequest } from '../dto/request/update-maintenance-plan.request';

export interface MaintenancePlanRepositoryInterface
  extends BaseInterfaceRepository<MaintenancePlan> {
  createDocument(request: CreateMaintenancePlanRequest): MaintenancePlan;
  updateDocument(
    document: MaintenancePlan,
    request: UpdateMaintenancePlanRequest,
  ): MaintenancePlan;
  list(request: ListMaintenancePlanQuery): Promise<any>;
  listDevices(request: any): Promise<any>;
}
