import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { ListMaintenancePlanQuery } from '../dto/query/list-maintenance-plan.query';
import { CreateMaintenancePlanRequest } from '../dto/request/create-maintenance-plan.request';
import { DetailMaintenancePlanByDeviceParamDto } from '../dto/request/detail-maintenance-plan-by-device.request';
import { UpdateMaintenancePlanRequest } from '../dto/request/update-maintenance-plan.request';
import { UpdateStatusMaintenancePlanParamDto } from '../dto/request/update-status-maintenance-plan.request';

export interface MaintenancePlanServiceInterface {
  create(request: CreateMaintenancePlanRequest): Promise<ResponsePayload<any>>;
  update(
    request: UpdateMaintenancePlanRequest & IdParamDto,
  ): Promise<ResponsePayload<any>>;
  delete(request: IdParamDto): Promise<ResponsePayload<any>>;
  list(request: ListMaintenancePlanQuery): Promise<ResponsePayload<any>>;
  detail(request: IdParamDto): Promise<ResponsePayload<any>>;
  changeStatus(
    request: UpdateStatusMaintenancePlanParamDto,
  ): Promise<ResponsePayload<any>>;
  detailByDevice(
    request: DetailMaintenancePlanByDeviceParamDto,
  ): Promise<ResponsePayload<any>>;
  suppliesByPlan(request: IdParamDto): Promise<ResponsePayload<any>>;
  listDeviceByPlan(request: IdParamDto): Promise<ResponsePayload<any>>;
}
