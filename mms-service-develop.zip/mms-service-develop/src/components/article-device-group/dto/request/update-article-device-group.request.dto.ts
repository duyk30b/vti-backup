import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateArticleDeviceGroupRequestDto } from './create-article-device-group.request.dto';

export class UpdateArticleDeviceGroupRequestDto extends CreateArticleDeviceGroupRequestDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  id: string;
}
