import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { IsMongoId, IsOptional } from 'class-validator';

export class ListArticleDeviceGroupRequestDto extends PaginationQuery {
  @ApiPropertyOptional()
  @IsMongoId()
  @IsOptional()
  queryIds?: string;
}
