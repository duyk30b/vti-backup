import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { plus } from '@utils/common';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { has, keyBy } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { generateCodeByPreviousCode } from 'src/helper/code.helper';
import { ARTICLE_DEVICE_GROUP_CONST } from './article-device-group.constant';
import { CreateArticleDeviceGroupRequestDto } from './dto/request/create-article-device-group.request.dto';
import { ListArticleDeviceGroupRequestDto } from './dto/request/list-article-device-group.request.dto';
import { UpdateArticleDeviceGroupRequestDto } from './dto/request/update-article-device-group.request.dto';
import { DetailArticleDeviceGroupResponse } from './dto/response/detail-article-device-group.response.dto';
import { ArticleDeviceGroupRepositoryInterface } from './interface/article-device-group.repository.interface';
import { ArticleDeviceGroupServiceInterface } from './interface/article-device-group.service.interface';

@Injectable()
export class ArticleDeviceGroupService
  implements ArticleDeviceGroupServiceInterface
{
  constructor(
    @Inject('ArticleDeviceGroupRepositoryInterface')
    private readonly articleDeviceGroupRepository: ArticleDeviceGroupRepositoryInterface,

    private i18n: I18nRequestScopeService,
  ) {}

  async create(
    data: CreateArticleDeviceGroupRequestDto,
  ): Promise<ResponsePayload<any>> {
    try {
      const articleDeviceGroup = ARTICLE_DEVICE_GROUP_CONST.CODE;
      const lastRecord = await this.articleDeviceGroupRepository.lastRecord();
      const codeCurrent =
        Number(lastRecord.code?.replace(articleDeviceGroup.PREFIX, '')) || 0;
      data.code = generateCodeByPreviousCode(
        articleDeviceGroup.PREFIX,
        codeCurrent,
      );

      const newArticleDeviceGroup =
        this.articleDeviceGroupRepository.createEntity(data);
      const dataSave = await newArticleDeviceGroup.save();

      const dataReturn = plainToInstance(BasicResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CREATE '))
        .build();
    }
  }

  async update(
    request: UpdateArticleDeviceGroupRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, ...data } = request;

    try {
      let articleDeviceGroup =
        await this.articleDeviceGroupRepository.findOneById(id);

      articleDeviceGroup = this.articleDeviceGroupRepository.updateEntity(
        articleDeviceGroup,
        data,
      );
      await this.articleDeviceGroupRepository.findByIdAndUpdate(
        id,
        articleDeviceGroup,
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }
  }

  async updateStatus(
    request: UpdateActiveStatusPayload,
  ): Promise<ResponsePayload<any>> {
    const { id, status } = request;

    try {
      const articleDeviceGroup =
        await this.articleDeviceGroupRepository.findOneById(id);
      if (!articleDeviceGroup) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.ARTICLE_DEVICE_GROUP_NOT_FOUND'),
          )
          .build();
      }

      await this.articleDeviceGroupRepository.findByIdAndUpdate(id, {
        $set: { active: status },
      });

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }
  }

  async list(
    request: ListArticleDeviceGroupRequestDto,
  ): Promise<ResponsePayload<any>> {
    try {
      const { data, count } = await this.articleDeviceGroupRepository.list(
        request,
      );

      const dataReturn = plainToInstance(
        DetailArticleDeviceGroupResponse,
        data,
        {
          excludeExtraneousValues: true,
        },
      );
      return new ResponseBuilder({
        items: dataReturn,
        meta: { page: request.page, total: count },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async detail(request: IdParamDto): Promise<ResponsePayload<any>> {
    try {
      const articleDeviceGroup =
        await this.articleDeviceGroupRepository.findOneById(request.id);
      if (!articleDeviceGroup) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.ARTICLE_DEVICE_GROUP_NOT_FOUND'),
          )
          .build();
      }

      const dataReturn = plainToInstance(
        DetailArticleDeviceGroupResponse,
        articleDeviceGroup,
        {
          excludeExtraneousValues: true,
        },
      );

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const dataInsert = [];
    const dataToUpdate = [];
    const codesUpdate = [];
    const dataError = [];
    const textAdd = await this.i18n.translate('import.common.add');
    const lastRecord = await this.articleDeviceGroupRepository.lastRecord();
    const articleDeviceGroup = ARTICLE_DEVICE_GROUP_CONST.CODE;
    const codeCurrent =
      +lastRecord.code?.replace(articleDeviceGroup.PREFIX, '') || 0;
    let count = 0;
    data.forEach((item) => {
      if (item.action === textAdd) {
        item.code = generateCodeByPreviousCode(
          articleDeviceGroup.PREFIX,
          plus(codeCurrent, count++),
        );
        dataInsert.push(item);
      } else {
        dataToUpdate.push(item);
        codesUpdate.push(item.code);
      }
    });

    const articleDeviceGroupCodeUpdateExists =
      await this.articleDeviceGroupRepository.findAllByCondition({
        code: { $in: codesUpdate },
      });

    const articleDeviceGroupUpdateMap = keyBy(
      articleDeviceGroupCodeUpdateExists,
      'code',
    );

    const dataUpdate = [];
    dataToUpdate.forEach((item) => {
      if (!has(articleDeviceGroupUpdateMap, item.code)) {
        dataError.push(item);
      } else {
        dataUpdate.push(item);
      }
    });

    const articleDeviceGroupDocument = [...dataInsert, ...dataUpdate];

    const bulkOps = articleDeviceGroupDocument.map((doc) => ({
      updateOne: {
        filter: {
          code: doc.code,
        },
        update: {
          $set: {
            code: doc.code,
            name: doc.name,
            description: doc.description,
          },
        },
        upsert: true,
      },
    }));
    const dataSuccess = await this.articleDeviceGroupRepository.bulkWrite(
      bulkOps,
    );

    return {
      dataError,
      dataSuccess,
    };
  }
}
