import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ArticleDeviceGroupSchema } from 'src/models/article-device-group/article-device-group.schema';
import { ArticleDeviceGroupRepository } from 'src/repository/article-device-group/article-device-group.repository';
import { ArticleDeviceGroupController } from './article-device-group.controller';
import { ArticleDeviceGroupService } from './article-device-group.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'ArticleDeviceGroup', schema: ArticleDeviceGroupSchema },
    ]),
  ],
  providers: [
    {
      provide: 'ArticleDeviceGroupRepositoryInterface',
      useClass: ArticleDeviceGroupRepository,
    },

    {
      provide: 'ArticleDeviceGroupServiceInterface',
      useClass: ArticleDeviceGroupService,
    },
  ],
  controllers: [ArticleDeviceGroupController],
  exports: [
    MongooseModule,
    {
      provide: 'ArticleDeviceGroupRepositoryInterface',
      useClass: ArticleDeviceGroupRepository,
    },
    {
      provide: 'ArticleDeviceGroupServiceInterface',
      useClass: ArticleDeviceGroupService,
    },
  ],
})
export class ArticleDeviceGroupModule {}
