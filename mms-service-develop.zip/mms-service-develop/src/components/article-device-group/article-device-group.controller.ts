import { ACTIVE_ENUM } from '@constant/common';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  Body,
  Controller,
  Get,
  Inject,
  Injectable,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import {
  CREATE_ARTICLE_DEVICE_GROUP_PERMISSION,
  DETAIL_ARTICLE_DEVICE_GROUP_PERMISSION,
  LIST_ARTICLE_DEVICE_GROUP_PERMISSION,
  UPDATE_ARTICLE_DEVICE_GROUP_PERMISSION,
  UPDATE_STATUS_ARTICLE_DEVICE_GROUP_PERMISSION,
} from '@utils/permissions/article-device-group';
import {
  CREATE_DEVICE_GROUP_PERMISSION,
  UPDATE_DEVICE_GROUP_PERMISSION,
} from '@utils/permissions/device-group';
import {
  CREATE_MAINTENANCE_PLAN_PERMISSION,
  UPDATE_MAINTENANCE_PLAN_PERMISSION,
} from '@utils/permissions/maintenance-plan';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateArticleDeviceGroupRequestDto } from './dto/request/create-article-device-group.request.dto';
import { ListArticleDeviceGroupRequestDto } from './dto/request/list-article-device-group.request.dto';
import { DetailArticleDeviceGroupResponse } from './dto/response/detail-article-device-group.response.dto';
import { ListArticleDeviceGroupResponse } from './dto/response/list-article-device-group.response.dto';
import { ArticleDeviceGroupServiceInterface } from './interface/article-device-group.service.interface';

@Injectable()
@Controller('/article-device-group')
export class ArticleDeviceGroupController {
  constructor(
    @Inject('ArticleDeviceGroupServiceInterface')
    private articelDeviceGroupService: ArticleDeviceGroupServiceInterface,
  ) {}

  // create
  @PermissionCode(CREATE_ARTICLE_DEVICE_GROUP_PERMISSION.code)
  @Post()
  @ApiOperation({
    tags: ['Article Device Group'],
    summary: 'Create  Article Device Group',
    description: 'Create  Article Device Group',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: SuccessResponse,
  })
  async create(@Body() body: CreateArticleDeviceGroupRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.articelDeviceGroupService.create(request);
  }

  // list
  @PermissionCode(
    LIST_ARTICLE_DEVICE_GROUP_PERMISSION.code,
    CREATE_MAINTENANCE_PLAN_PERMISSION.code,
    UPDATE_MAINTENANCE_PLAN_PERMISSION.code,
    CREATE_DEVICE_GROUP_PERMISSION.code,
    UPDATE_DEVICE_GROUP_PERMISSION.code,
  )
  @Get()
  @ApiOperation({
    tags: ['Article Device Group'],
    summary: 'List  Article Device Group',
    description: 'List  Article Device Group',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: ListArticleDeviceGroupResponse,
  })
  async list(@Query() query: ListArticleDeviceGroupRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.articelDeviceGroupService.list(request);
  }

  // detail
  @PermissionCode(DETAIL_ARTICLE_DEVICE_GROUP_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Article Device Group'],
    summary: 'Detail  Article Device Group',
    description: 'Detail  Article Device Group',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: DetailArticleDeviceGroupResponse,
  })
  async detail(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.articelDeviceGroupService.detail(request);
  }

  // update
  @PermissionCode(UPDATE_ARTICLE_DEVICE_GROUP_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Article Device Group'],
    summary: 'Update  Article Device Group',
    description: 'Update  Article Device Group',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: SuccessResponse,
  })
  async update(
    @Param() param: IdParamDto,
    @Body() body: CreateArticleDeviceGroupRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    const {
      request: { id },
      responseError: responseErrorParam,
    } = param;
    if (responseErrorParam && !isEmpty(responseErrorParam)) {
      return responseErrorParam;
    }

    return await this.articelDeviceGroupService.update({ ...request, id });
  }

  // update status
  @PermissionCode(UPDATE_STATUS_ARTICLE_DEVICE_GROUP_PERMISSION.code)
  @Put('/:id/active')
  @ApiOperation({
    tags: ['Article Device Group'],
    summary: 'Active  Article Device Group',
    description: 'Active  Article Device Group',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: SuccessResponse,
  })
  async active(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.articelDeviceGroupService.updateStatus({
      status: ACTIVE_ENUM.ACTIVE,
      ...request,
    });
  }

  // update status
  @PermissionCode(UPDATE_STATUS_ARTICLE_DEVICE_GROUP_PERMISSION.code)
  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Article Device Group'],
    summary: 'Inactive  Article Device Group',
    description: 'Inactive  Article Device Group',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: SuccessResponse,
  })
  async inactive(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.articelDeviceGroupService.updateStatus({
      status: ACTIVE_ENUM.INACTIVE,
      ...request,
    });
  }
}
