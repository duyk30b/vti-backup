import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreateArticleDeviceGroupRequestDto } from '../dto/request/create-article-device-group.request.dto';
import { ListArticleDeviceGroupRequestDto } from '../dto/request/list-article-device-group.request.dto';
import { UpdateArticleDeviceGroupRequestDto } from '../dto/request/update-article-device-group.request.dto';

import { ListArticleDeviceGroupResponse } from '../dto/response/list-article-device-group.response.dto';

export interface ArticleDeviceGroupServiceInterface {
  create(
    data: CreateArticleDeviceGroupRequestDto,
  ): Promise<ResponsePayload<any>>;
  update(
    request: UpdateArticleDeviceGroupRequestDto,
  ): Promise<ResponsePayload<any>>;
  updateStatus(
    request: UpdateActiveStatusPayload,
  ): Promise<ResponsePayload<any>>;
  list(
    request: ListArticleDeviceGroupRequestDto,
  ): Promise<ResponsePayload<ListArticleDeviceGroupResponse>>;
  detail(request: IdParamDto): Promise<ResponsePayload<any>>;
  import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }>;
}
