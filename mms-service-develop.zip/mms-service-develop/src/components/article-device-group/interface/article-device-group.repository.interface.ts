import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { ArticleDeviceGroup } from 'src/models/article-device-group/article-device-group.model';
import { ListArticleDeviceGroupRequestDto } from '../dto/request/list-article-device-group.request.dto';

export interface ArticleDeviceGroupRepositoryInterface
  extends BaseAbstractRepository<ArticleDeviceGroup> {
  createEntity(request: any): ArticleDeviceGroup;
  updateEntity(
    deviceType: ArticleDeviceGroup,
    request: any,
  ): ArticleDeviceGroup;
  list(request: ListArticleDeviceGroupRequestDto): Promise<any>;
}
