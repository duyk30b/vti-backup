import { MAINTENANCE_TEAM_CONST } from '@components/maintenance-team/maintenance-team.constant';
import { AreaRepositoryInterface } from '@components/area/interface/area.repository.interface';
import { DeviceGroupRepositoryInterface } from '@components/device-group/interface/device-group.repository.interface';
import { MaintenanceTeamServiceInterface } from '@components/maintenance-team/interface/maintenance-team.service.interface';
import { MaintenanceTeamRepositoryInterface } from '@components/maintenance-team/interface/maintenance-team.repository.interface';
import { Inject, Injectable } from '@nestjs/common';
import {
  compact,
  flatMap,
  has,
  identity,
  intersectionBy,
  isEmpty,
  keyBy,
  map,
  pickBy,
  uniq,
} from 'lodash';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { plainToInstance } from 'class-transformer';
import { CreateMaintenanceTeamRequestDto } from '@components/maintenance-team/dto/request/create-maintenance-team.request.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { GetDetailMaintenanceTeamResponseDto } from '@components/maintenance-team/dto/response/get-detail-maintenance-team.response.dto';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { UpdateMaintenanceTeamRequestDto } from '@components/maintenance-team/dto/request/update-maintenance-team.request.dto';
import { GetAllMaintenanceTeamAndUserResponseDto } from '@components/maintenance-team/dto/response/get-all-maintenance-team-and-user.response.dto';
import { GetListMaintenanceTeamRequestDto } from '@components/maintenance-team/dto/request/get-list-maintenace-team.request.dto';
import { GetListAllMaintenanceTeamAndUserRequestDto } from '@components/maintenance-team/dto/request/get-list-all-maintenance-team-and-user.request.dto';
import { ResponsibleSubjectType } from '@components/device/device.constant';
import { DEPARTMENT_PERMISSION_SETTING } from '@utils/permissions/department-permission-setting';
import { USER_ROLE_SETTING_NAME } from '@utils/permissions/user-role-setting';
import {
  MAINTENANCE_TEAM_ROLE,
  NUMBER_LEADER_OF_TEAM,
  USER_ROLE_SETTING_ADMIN_CODE,
} from './maintenance-team.constant';
import { GET_ALL_ENUM, ME_DEPARTMENT_CODE, ROLE } from '@constant/common';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { IdParamSqlDto } from '@utils/dto/request/param-id-sql.request.dto';
import { PermissionTeamQuery } from '@utils/dto/request/permission-team.query';
import { MaintenanceTeam } from 'src/models/maintenance-team/maintenance-team.model';
import { DeviceRepositoryInterface } from '@components/device/interface/device.repository.interface';
import {
  generateCodeByPreviousCode,
  getCurrentCodeByLastRecord,
} from 'src/helper/code.helper';
import { plus } from '@utils/helper';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { BasicUserResponseDto } from '@utils/dto/response/basic-user.response.dto';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { Types } from 'mongoose';

@Injectable()
export class MaintenanceTeamService implements MaintenanceTeamServiceInterface {
  constructor(
    @Inject('MaintenanceTeamRepositoryInterface')
    private readonly maintenanceTeamRepository: MaintenanceTeamRepositoryInterface,
    @Inject('DeviceGroupRepositoryInterface')
    private readonly deviceGroupRepository: DeviceGroupRepositoryInterface,
    @Inject('DeviceRepositoryInterface')
    private readonly deviceRepository: DeviceRepositoryInterface,
    @Inject('AreaRepositoryInterface')
    private readonly areaRepository: AreaRepositoryInterface,
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,
    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateMaintenanceTeamRequestDto): Promise<any> {
    try {
      request.code = await this.maintenanceTeamRepository.generateNextCode(
        MAINTENANCE_TEAM_CONST.CODE.PREFIX,
      );
      const validateRequest = await this.validateMaintenanceTeamRequest(
        request,
      );

      if (validateRequest.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validateRequest;
      }

      const maintenanceTeamDocument =
        this.maintenanceTeamRepository.createDocument(request);
      const dataSave = await maintenanceTeamDocument.save();

      const dataReturn = plainToInstance(BasicResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getListAllUserAndAllMaintenanceTeam(
    request: GetListAllMaintenanceTeamAndUserRequestDto,
  ): Promise<any> {
    let isFullPermission = false;
    let isIT = false;
    let isITLeader = false;
    if (request.isGetAll === GET_ALL_ENUM.NO) {
      for (let i = 0; i < request.user.departmentSettings.length; i++) {
        const department = request.user.departmentSettings[i];
        if (DEPARTMENT_PERMISSION_SETTING.ADMIN === department.id)
          isFullPermission = true;
        else if (DEPARTMENT_PERMISSION_SETTING.IT === department.id) {
          isIT = true;
        }
      }
      if (isIT)
        for (let i = 0; i < request.user.userRoleSettings.length; i++) {
          const role = request.user.userRoleSettings[i];
          if (role.name === USER_ROLE_SETTING_NAME.LEADER) isITLeader = true;
        }
    }

    let condition: any = {
      isDeleted: false,
    };

    if (
      request.isGetAll === GET_ALL_ENUM.NO &&
      isIT &&
      !isITLeader &&
      !isFullPermission
    ) {
      condition = {
        isDeleted: false,
        'members.userId': request.user.id,
        'members.role': MAINTENANCE_TEAM_ROLE.LEADER,
      };
    }

    let userIds = [];
    const userList = await this.userService.getList({
      isGetAll: '1',
      filter: [
        {
          column: 'departmentCode',
          text: ME_DEPARTMENT_CODE,
        },
      ],
    });
    const maintenanceTeam =
      await this.maintenanceTeamRepository.findAllByCondition(condition);
    if (maintenanceTeam) {
      userList.responsibleMaintenanceTeams = maintenanceTeam;
      if (
        request.isGetAll === GET_ALL_ENUM.NO &&
        isIT &&
        !isITLeader &&
        !isFullPermission
      )
        userIds = maintenanceTeam
          .map((e) => e.members.map((v) => v.userId))
          .flat();
      for (const item of userList.responsibleMaintenanceTeams) {
        item.type = ResponsibleSubjectType.MaintenanceTeam;
      }
    } else {
      userList.responsibleMaintenanceTeams = '';
    }

    const users = await this.userService.getList([
      { column: 'userIds', text: userIds.join(',') },
    ]);
    if (
      request.isGetAll === GET_ALL_ENUM.NO &&
      isIT &&
      !isITLeader &&
      !isFullPermission
    ) {
      for (const item of users) {
        item.type = ResponsibleSubjectType.User;
      }
      userList.responsibleUsers = users;
    } else if (userList) {
      for (const item of userList.data) {
        item.type = ResponsibleSubjectType.User;
      }
      userList.responsibleUsers = userList.data;
    } else {
      userList.responsibleUsers = null;
    }

    const response = plainToInstance(
      GetAllMaintenanceTeamAndUserResponseDto,
      userList,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async list(request: GetListMaintenanceTeamRequestDto): Promise<any> {
    const { result, count } = await this.maintenanceTeamRepository.getList(
      request,
    );

    const factoryIds = compact(uniq(map(result, 'factoryId')));
    let factoryMap;
    if (factoryIds) {
      const factories = await this.userService.getFactoryList([
        {
          column: 'factoryIds',
          text: factoryIds,
        },
      ]);
      factoryMap = keyBy(factories, 'id');
    }

    const userIds = map(flatMap(result, 'members'), 'userId');
    const users = await this.userService.getList([
      { column: 'userIds', text: userIds.join(',') },
    ]);
    const userMap = keyBy(users, 'id');
    const response = plainToInstance(
      GetDetailMaintenanceTeamResponseDto,
      result.map((data) => {
        return {
          ...data,
          members: data.members.map((member) => ({
            user: userMap[member.userId],
            userId: member.userId,
            role: member.role,
            deviceGroups: member.deviceGroups,
            areas: member.areas,
          })),
          factory: factoryMap[data.factoryId],
        };
      }),
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder<PaginationResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async detail(request: IdParamDto): Promise<any> {
    const response = await this.maintenanceTeamRepository.findOneWithPopulate(
      { ...request.permissionCondition, _id: request.id },
      ['areas', 'deviceGroups', 'members.deviceGroups', 'members.areas'],
    );
    if (!response) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const userIds = uniq(map(response?.members, 'userId'));
    const users = await this.userService.getList([
      { column: 'userIds', text: userIds.join(',') },
    ]);

    const userMap = keyBy(users, 'id');
    const factory = await this.userService.getFactoryById(response.factoryId);
    if (!factory) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.FACTORY_NOT_FOUND'))
        .build();
    }

    const result = plainToInstance(
      GetDetailMaintenanceTeamResponseDto,
      {
        ...response,
        factory,
        members: response.members.map((member) => ({
          ...member,
          user: userMap[member?.userId],
        })),
      },
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async update(request: UpdateMaintenanceTeamRequestDto): Promise<any> {
    const { id } = request;

    const maintenanceTeam =
      await this.maintenanceTeamRepository.findOneByCondition({
        ...request.permissionCondition,
        _id: id,
      });
    if (!maintenanceTeam) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const validateRequest = await this.validateMaintenanceTeamRequest(
      request,
      maintenanceTeam,
    );
    if (validateRequest.statusCode !== ResponseCodeEnum.SUCCESS) {
      return validateRequest;
    }
    try {
      const maintenanceTeamUpdate =
        this.maintenanceTeamRepository.updateDocument(maintenanceTeam, request);
      await this.maintenanceTeamRepository.findByIdAndUpdate(
        id,
        maintenanceTeamUpdate,
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const codePrefix = MAINTENANCE_TEAM_CONST.CODE.PREFIX;
    const lastRecord = await this.maintenanceTeamRepository.lastRecord();
    const codeCurrent = getCurrentCodeByLastRecord(codePrefix, lastRecord);
    const textAdd = await this.i18n.translate('import.common.add');

    const dataToInsert = [];
    const dataToUpdate = [];
    const codesUpdate = [];

    data.forEach((item, index) => {
      item.areaCodes = item.areaCodes?.split(',');
      item.deviceGroupCodes = item.deviceGroupCodes?.split(',');
      item.members?.forEach((member) => {
        member.areaCodes = member.areaCodes?.split(',');
        member.deviceGroupCodes = member.deviceGroupCodes?.split(',');
      });
      if (item.action === textAdd) {
        item.code = generateCodeByPreviousCode(
          codePrefix,
          plus(codeCurrent, index),
        );
        dataToInsert.push(item);
      } else {
        dataToUpdate.push(item);
        codesUpdate.push(item.code);
      }
    });

    const maintenanceTeamCodeUpdateExists =
      await this.maintenanceTeamRepository.findAllByCondition({
        code: { $in: codesUpdate },
      });

    const maintenanceTeamUpdateMap = keyBy(
      maintenanceTeamCodeUpdateExists,
      'code',
    );
    const usernames = map(flatMap(data, 'members'), 'username');
    const users = await this.userService.getList([
      {
        column: 'usernames',
        text: usernames,
      },
    ]);
    const userIds = map(users, 'id');
    const userMap = keyBy(users, 'username');
    // get list maintenance team

    const maintenanceTeams: any =
      await this.maintenanceTeamRepository.findAllByCondition({
        'members.userId': { $in: userIds },
      });
    const userMapById = keyBy(users, 'id');

    maintenanceTeams.forEach((data) => {
      data.members.forEach((member) => {
        member.username = userMapById[member.userId]?.username;
        member.userId = member.userId;
      });
    });
    // factory
    const factoryCodes = compact(uniq(data.map((item) => item.factoryCode)));
    const factories = await this.userService.getFactoryList([
      {
        column: 'factoryCodes',
        text: factoryCodes,
      },
    ]);
    const factoryMap = keyBy(factories, 'code');
    // area
    const areaCodes = compact(uniq(data.flatMap((el) => el.areaCodes)));
    const areas = await this.areaRepository.findAllByCondition({
      code: {
        $in: areaCodes,
      },
    });
    const areaMap = keyBy(areas, 'code');
    // deviceGroup
    const deviceGroupCodes = compact(
      uniq(data.flatMap((el) => el.deviceGroupCodes)),
    );
    const deviceGroups = await this.deviceGroupRepository.findAllByCondition({
      code: {
        $in: deviceGroupCodes,
      },
    });
    const deviceGroupMap = keyBy(deviceGroups, 'code');

    const dataError = [];
    const dataInsert = [];
    const dataUpdate = [];
    const leaderText = await this.i18n.translate(
      'import.maintenanceTeam.members.leader',
    );

    function checkCode(arrMap, arrCheck): boolean {
      return arrCheck?.every((el) => {
        return has(arrMap, el);
      });
    }

    // check user exists in maintenance another
    function checkMembers(maintenanceTeam: MaintenanceTeam) {
      let anotherMaintenanceTeams = maintenanceTeams;
      if (maintenanceTeam['action'] !== textAdd) {
        anotherMaintenanceTeams = maintenanceTeams.filter((el) => {
          return el.code !== maintenanceTeam.code;
        });
      }
      // check member exist and not duplicate
      if (
        maintenanceTeam.members?.length !==
        compact(
          uniq(
            maintenanceTeam.members.map((el) => userMap[el['username']]?.id),
          ),
        ).length
      ) {
        return false;
      }
      // check members not exist in maintenance teams another
      if (
        isEmpty(
          intersectionBy(
            maintenanceTeam.members,
            anotherMaintenanceTeams.flatMap((el) => el.members),
            'username',
          ),
        ) &&
        isEmpty(
          intersectionBy(
            maintenanceTeam.members,
            [...dataInsert, ...dataUpdate].flatMap((el) => el.members),
            'username',
          ),
        )
      ) {
        return true;
      }
      return false;
    }

    // check num leader in team
    function checkLeader(members: any[]) {
      const leader = members.filter((member) => member.role === leaderText);
      if (leader.length === NUMBER_LEADER_OF_TEAM) {
        return true;
      }
      return false;
    }

    dataToInsert.forEach((item) => {
      if (
        !has(factoryMap, item.factoryCode) ||
        !checkCode(areaMap, item.areaCodes) ||
        !checkCode(deviceGroupMap, item.deviceGroupCodes) ||
        !checkCode(
          areaMap,
          item.members?.flatMap((el) => el.areaCodes),
        ) ||
        !checkCode(
          deviceGroupMap,
          item.members?.flatMap((el) => el.deviceGroupCodes),
        ) ||
        !checkMembers(item) ||
        !checkLeader(item.members)
      ) {
        dataError.push(item);
      } else {
        dataInsert.push(item);
      }
    });

    dataToUpdate.forEach((item) => {
      if (
        !has(maintenanceTeamUpdateMap, item.code) ||
        !has(factoryMap, item.factoryCode) ||
        !checkCode(areaMap, item.areaCodes) ||
        !checkCode(deviceGroupMap, item.deviceGroupCodes) ||
        !checkCode(
          areaMap,
          item.members?.flatMap((el) => el.areaCodes),
        ) ||
        !checkCode(
          deviceGroupMap,
          item.members?.flatMap((el) => el.deviceGroupCodes),
        ) ||
        !checkMembers(item) ||
        !checkLeader(item.members)
      ) {
        dataError.push(item);
      } else {
        dataUpdate.push(item);
      }
    });

    const bulkOps = [...dataInsert, ...dataUpdate].map((doc) => {
      const members = doc.members?.map((el) => ({
        ...el,
        userId: userMap[el.username]?.id,
        role:
          el.role === leaderText
            ? MAINTENANCE_TEAM_ROLE.LEADER
            : MAINTENANCE_TEAM_ROLE.MEMBER,
        areaIds: doc.areaCodes?.map((el) => areaMap[el]?._id),
        deviceGroupIds: doc.deviceGroupCodes?.map(
          (el) => deviceGroupMap[el]?._id,
        ),
      }));
      return {
        updateOne: {
          filter: { code: doc.code },
          update: {
            ...doc,
            members: members,
            areaIds: doc.areaCodes?.map((el) => areaMap[el]?._id),
            factoryId: factoryMap[doc.factoryCode]?.id,
            deviceGroupIds: doc.deviceGroupCodes?.map(
              (el) => deviceGroupMap[el]?._id,
            ),
          },
          upsert: true,
        },
      };
    });

    const dataSuccess = await this.maintenanceTeamRepository.bulkWrite(bulkOps);

    return { dataError, dataSuccess };
  }

  async updateStatus(request: UpdateActiveStatusPayload): Promise<any> {
    const { id, status } = request;

    const maintenanceTeam =
      await this.maintenanceTeamRepository.findOneByCondition({
        ...request.permissionCondition,
        _id: id,
      });
    if (!maintenanceTeam) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }

    await this.maintenanceTeamRepository.findByIdAndUpdate(id, {
      $set: { active: status },
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'));
  }

  private async validateMaintenanceTeamRequest(
    request: CreateMaintenanceTeamRequestDto,
    maintenanceTeam?: MaintenanceTeam,
  ): Promise<any> {
    const { members, factoryId } = request;

    const numberLeaderOfTeam = members.filter(
      (member) => member.role === MAINTENANCE_TEAM_ROLE.LEADER,
    );
    if (numberLeaderOfTeam.length !== NUMBER_LEADER_OF_TEAM) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          (
            await this.i18n.translate(
              'error.MAINTENANCE_TEAM_HAS_NUMBER_LEADER',
            )
          ).replace(`:number_leader`, `${NUMBER_LEADER_OF_TEAM}`),
        )
        .build();
    }

    const factory = await this.userService.getFactoryById(factoryId);
    if (!factory) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.FACTORY_NOT_FOUND'))
        .build();
    }

    // validate user phải tồn tại & thuộc đội cơ điện của nhà máy đươc chọn
    const userIds = map(members, 'userId');
    const users = await this.userService.getList([
      {
        column: 'userIds',
        text: userIds.join(','),
      },
      {
        column: 'factoryId',
        text: factoryId,
      },
      {
        column: 'departmentCode',
        text: ME_DEPARTMENT_CODE,
      },
    ]);

    const userAdmin = users.find((user) =>
      user.userRoleSettings.find(
        (roleSetting) => roleSetting.code === USER_ROLE_SETTING_ADMIN_CODE,
      ),
    );

    if (userAdmin) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INVALID_MEMBER'))
        .build();
    }

    if (users.length < userIds.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.MEMBER_MUST_BE_HAS_IN_FACTORY_AND_ME_DEPARTMENT',
          ),
        )
        .build();
    }

    let condition: any = {
      'members.userId': {
        $in: userIds,
      },
    };

    if (maintenanceTeam) {
      condition = {
        'members.userId': {
          $in: userIds,
        },
        _id: {
          $ne: maintenanceTeam._id,
        },
      };
    }

    const checkUserExistsInAnotherTeam =
      await this.maintenanceTeamRepository.findAllByCondition(condition);
    if (!isEmpty(checkUserExistsInAnotherTeam)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.USER_EXISTS_IN_ANOTHER_TEAM'),
        )
        .build();
    }
    // validate nhóm thiết bị tồn tại
    const deviceGroupIds = uniq(flatMap(members, 'deviceGroupIds'));
    const deviceGroups = await this.deviceGroupRepository.findAllByCondition({
      _id: { $in: deviceGroupIds },
    });
    if (deviceGroups.length < deviceGroupIds.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.DEVICE_GROUP_NOT_FOUND'))
        .build();
    }

    // validate khu vực tồn tại
    const areaIds = uniq(flatMap(members, 'areaIds'));
    const areas = await this.areaRepository.findAllByCondition({
      _id: { $in: areaIds },
      factoryId: +factoryId,
    });
    if (areas.length < areaIds.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.AREA_NOT_FOUND'))
        .build();
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getUsersByTeam(
    request: IdParamDto & PermissionTeamQuery,
  ): Promise<any> {
    const maintenanceTeam = await this.maintenanceTeamRepository.findOneById(
      request.id,
    );

    if (!maintenanceTeam || !maintenanceTeam?.members?.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.MAINTENANCE_TEAM_NOT_FOUND'),
        )
        .build();
    }

    const userIds = map(maintenanceTeam.members, 'userId');

    const users = await this.userService.getList([
      {
        column: 'userIds',
        text: userIds.toString(),
      },
    ]);

    const userMap = keyBy(users, 'id');

    const usersResponse = maintenanceTeam.members.map((e) => userMap[e.userId]);

    const dataReturn = plainToInstance(BasicUserResponseDto, usersResponse, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder({
      items: dataReturn,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getMaintenanceTeamByUser(request: IdParamSqlDto): Promise<any> {
    const maintenanceTeam =
      await this.maintenanceTeamRepository.findOneByCondition({
        'members.userId': request.id,
      });

    return new ResponseBuilder(maintenanceTeam)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  // ở đây gọi để check role user không phân quyền
  async getRoleUserInTeam(request: IdParamSqlDto): Promise<any> {
    const maintenanceTeam =
      await this.maintenanceTeamRepository.findOneByCondition({
        'members.userId': request.id,
      });
    return new ResponseBuilder(maintenanceTeam || {})
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getUsersToAssign(request: IdParamDto): Promise<any> {
    const device = await this.deviceRepository.findOneById(request.id);

    if (!device) {
      return new ResponseBuilder<any>({
        items: [],
        meta: { page: 1, total: 0 },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    let condition: any = {};
    // @TODO filter with deviceGroup and area in member
    switch (request.user.role) {
      case ROLE.ADMIN:
        {
          condition = {
            factoryId: device.factoryId,
          };
        }
        break;
      case ROLE.FACTORY_MANAGER:
        {
          condition = {
            factoryId: { $in: request.user.factoryIds },
          };
        }
        break;
      case ROLE.LEADER:
        {
          condition = {
            factoryId: { $in: request.user.factoryIds },
            _id: new Types.ObjectId(request.user?.maintenanceTeam?._id),
          };
        }
        break;
      default:
        return new ResponseBuilder<any>({
          items: [],
          meta: { page: 1, total: 0 },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
    }

    const members =
      await this.maintenanceTeamRepository.getMemberByDeviceGroupAndArea(
        device.deviceGroupId,
        device.areaId,
        condition,
      );
    const userIds = map(members, 'userId');
    const users = await this.userService.getList([
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ]);

    const dataReturn = plainToInstance(BasicUserResponseDto, users, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder({
      items: dataReturn,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getTeamsToAssign(request: IdParamDto): Promise<any> {
    const { id, user } = request;
    const device = await this.deviceRepository.findOneById(id);

    if (!device) {
      return new ResponseBuilder<any>({
        items: [],
        meta: { page: 1, total: 0 },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    let condition: any = {};
    switch (user.role) {
      case ROLE.ADMIN:
        {
          condition = {
            factoryId: device.factoryId,
          };
        }
        break;
      case ROLE.FACTORY_MANAGER:
        {
          condition = {
            factoryId: { $in: user.factoryIds },
          };
        }
        break;
      case ROLE.LEADER:
        {
          condition = {
            factoryId: { $in: user.factoryIds },
          };
        }
        break;
      case ROLE.MEMBER:
        condition = {
          factoryId: { $in: user.factoryIds },
          members: {
            $elemMatch: {
              userId: user.id,
              deviceGroupIds: new Types.ObjectId(device.deviceGroupId),
              ...(device.areaId
                ? { areaIds: new Types.ObjectId(device.areaId) }
                : {}),
            },
          },
        };
        break;
      default:
        return new ResponseBuilder<any>({
          items: [],
          meta: { page: 1, total: 0 },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
    }
    condition = {
      ...condition,
      ...pickBy(
        {
          deviceGroupIds: new Types.ObjectId(device.deviceGroupId),
          areaIds: device.areaId ? new Types.ObjectId(device.areaId) : null,
        },
        identity,
      ),
    };
    const teams = await this.maintenanceTeamRepository.findAllByCondition(
      condition,
    );
    const response = plainToInstance(BasicResponseDto, teams, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<any>({
      items: response,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getResponsibleUsers(request: PaginationQuery): Promise<any> {
    const { user } = request;

    if (![ROLE.ADMIN, ROLE.FACTORY_MANAGER, ROLE.LEADER].includes(user.role)) {
      return new ResponseBuilder(
        plainToInstance(BasicUserResponseDto, [user], {
          excludeExtraneousValues: true,
        }),
      )
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const conditionMap = {
      [ROLE.ADMIN]: {},
      [ROLE.FACTORY_MANAGER]: { factoryId: { $in: user.factoryIds } },
      [ROLE.LEADER]: { factoryId: { $in: user.factoryIds } },
    };
    const condition = conditionMap[user.role];
    const maintenanceTeams =
      await this.maintenanceTeamRepository.findAllByCondition(condition);

    const userIds = uniq(map(flatMap(maintenanceTeams, 'members'), 'userId'));
    const users = await this.userService.getList([
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ]);
    const response = plainToInstance(BasicUserResponseDto, users, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
