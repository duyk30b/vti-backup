import { UpdateMaintenanceTeamBodyDto } from '@components/maintenance-team/dto/request/update-maintenance-team.request.dto';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { MaintenanceTeam } from 'src/models/maintenance-team/maintenance-team.model';

export interface MaintenanceTeamRepositoryInterface
  extends BaseInterfaceRepository<MaintenanceTeam> {
  getList(payload): Promise<any>;
  getMemberByDeviceGroupAndArea(
    deviceGroupId: string,
    areaId?: string,
    condition?: any,
  ): Promise<any>;
  createDocument(param: any): MaintenanceTeam;
  updateDocument(
    document: MaintenanceTeam,
    data: UpdateMaintenanceTeamBodyDto,
  ): MaintenanceTeam;
}
