import { GetListMaintenanceTeamRequestDto } from '@components/maintenance-team/dto/request/get-list-maintenace-team.request.dto';
import { UpdateMaintenanceTeamRequestDto } from '@components/maintenance-team/dto/request/update-maintenance-team.request.dto';
import { GetListAllMaintenanceTeamAndUserRequestDto } from '@components/maintenance-team/dto/request/get-list-all-maintenance-team-and-user.request.dto';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { IdParamSqlDto } from '@utils/dto/request/param-id-sql.request.dto';
import { PermissionTeamQuery } from '@utils/dto/request/permission-team.query';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';

export interface MaintenanceTeamServiceInterface {
  create(payload: any): Promise<any>;
  list(request: GetListMaintenanceTeamRequestDto): Promise<any>;
  detail(request: IdParamDto): Promise<any>;
  update(request: UpdateMaintenanceTeamRequestDto): Promise<any>;
  getListAllUserAndAllMaintenanceTeam(
    request: GetListAllMaintenanceTeamAndUserRequestDto,
  ): Promise<any>;
  import(request: any): Promise<any>;
  updateStatus(request: UpdateActiveStatusPayload): Promise<any>;
  getUsersByTeam(request: IdParamDto & PermissionTeamQuery): Promise<any>;
  getUsersToAssign(request: IdParamDto): Promise<any>;
  getTeamsToAssign(request: IdParamDto): Promise<any>;
  getMaintenanceTeamByUser(request: IdParamSqlDto): Promise<any>;
  getRoleUserInTeam(request: IdParamSqlDto): Promise<any>;
  getResponsibleUsers(request: PaginationQuery): Promise<any>;
}
