import { CODE_REGEX } from '@constant/common';

export const MAINTENANCE_TEAM_CONST = {
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
  CODE: {
    MAX_LENGTH: 20,
    MIN_LENGTH: 6,
    COLUMN: 'code',
    REGEX: CODE_REGEX,
    PREFIX: 'DBT',
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  TYPE: {
    EXTERNAL: 0,
    INTERNAL: 1,
  },
};

export enum MAINTENANCE_TEAM_ROLE {
  LEADER,
  MEMBER,
}

export const NUMBER_LEADER_OF_TEAM = 1;
export const USER_ROLE_SETTING_ADMIN_CODE = '01';
