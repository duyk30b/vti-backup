import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsEnum,
  IsInt,
  IsMongoId,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import {
  MAINTENANCE_TEAM_CONST,
  MAINTENANCE_TEAM_ROLE,
} from '@components/maintenance-team/maintenance-team.constant';
import { IsNotBlank } from 'src/validator/is-not-blank.validator';

export class MaintenanceTeamMemberRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  userId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  @IsEnum(MAINTENANCE_TEAM_ROLE)
  role: number;

  @ApiProperty()
  @IsArray()
  @ArrayNotEmpty()
  @ArrayUnique()
  @IsMongoId({ each: true })
  areaIds: string[];

  @ApiProperty()
  @IsArray()
  @ArrayNotEmpty()
  @ArrayUnique()
  @IsNotEmpty()
  @IsMongoId({ each: true })
  deviceGroupIds: string[];
}

export class CreateMaintenanceTeamRequestDto extends BaseDto {
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @MaxLength(MAINTENANCE_TEAM_CONST.NAME.MAX_LENGTH)
  @IsNotBlank()
  @IsString()
  name: string;

  @ApiProperty()
  @IsString()
  @MaxLength(MAINTENANCE_TEAM_CONST.DESCRIPTION.MAX_LENGTH)
  @IsOptional()
  description: string;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  factoryId: number;

  @ApiProperty()
  @IsArray()
  @ArrayNotEmpty()
  @IsMongoId({ each: true })
  @IsNotEmpty()
  areaIds: string[];

  @ApiProperty()
  @IsArray()
  @ArrayNotEmpty()
  @IsMongoId({ each: true })
  @IsNotEmpty()
  deviceGroupIds: string[];

  @ApiProperty()
  @IsNotEmpty()
  @ValidateNested()
  @IsArray()
  @ArrayNotEmpty()
  @ArrayUnique((data: MaintenanceTeamMemberRequestDto) => data.userId)
  @Type(() => MaintenanceTeamMemberRequestDto)
  members: MaintenanceTeamMemberRequestDto[];
}
