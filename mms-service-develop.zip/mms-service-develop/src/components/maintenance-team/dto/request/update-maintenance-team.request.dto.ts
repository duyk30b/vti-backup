import { CreateMaintenanceTeamRequestDto } from './create-maintenance-team.request.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsMongoId } from 'class-validator';

export class UpdateMaintenanceTeamBodyDto extends CreateMaintenanceTeamRequestDto {}
export class UpdateMaintenanceTeamRequestDto extends UpdateMaintenanceTeamBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
