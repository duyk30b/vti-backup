import { GET_ALL_ENUM } from '@constant/common';
import { BaseDto } from '@core/dto/base.dto';
import { IsEnum, IsOptional } from 'class-validator';

export class GetListAllMaintenanceTeamAndUserRequestDto extends BaseDto {
  @IsEnum(GET_ALL_ENUM)
  @IsOptional()
  isGetAll: number;
}
