import { IsOptional, IsString } from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';

export class GetListMaintenanceTeamRequestDto extends PaginationQuery {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  isGetAll: string;

  @ApiPropertyOptional({
    example: '1,2,3',
  })
  @IsOptional()
  @IsString()
  queryIds?: string;
}
