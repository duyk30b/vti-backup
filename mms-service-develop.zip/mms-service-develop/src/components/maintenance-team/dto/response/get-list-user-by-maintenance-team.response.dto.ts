import { ApiProperty } from '@nestjs/swagger';
import { BasicUserResponseDto } from '@utils/dto/response/basic-user.response.dto';
import { Expose } from 'class-transformer';

export class GetListUserByMaintenanceTeamResponseDto {
  @ApiProperty({
    type: BasicUserResponseDto,
    isArray: true,
  })
  @Expose()
  items: BasicUserResponseDto[];
}
