import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { GetListMaintenanceTeamMemberResponseDto } from './get-list-maintenance-team-member.response.dto';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { IsArray } from 'class-validator';

export class GetDetailMaintenanceTeamResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty()
  @Expose()
  active: number;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Expose()
  @Type(() => BasicSqlDocumentResponse)
  factory: BasicSqlDocumentResponse;

  @ApiProperty({ type: BasicResponseDto, isArray: true })
  @Expose()
  @Type(() => BasicResponseDto)
  deviceGroups: BasicResponseDto[];

  @ApiProperty({ type: BasicResponseDto, isArray: true })
  @Expose()
  @Type(() => BasicResponseDto)
  areas: BasicResponseDto[];

  @ApiProperty({ type: GetListMaintenanceTeamMemberResponseDto, isArray: true })
  @Expose()
  @Type(() => GetListMaintenanceTeamMemberResponseDto)
  @IsArray()
  members: GetListMaintenanceTeamMemberResponseDto[];
}
