import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { MAINTENANCE_TEAM_ROLE } from '@components/maintenance-team/maintenance-team.constant';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';
import { IsEnum } from 'class-validator';

export class GetListMaintenanceTeamMemberResponseDto {
  @ApiProperty()
  @Expose()
  userId: number;

  @ApiProperty()
  @Expose()
  @Transform(({ obj }) => obj.user?.username)
  username: string;

  @ApiProperty()
  @Expose()
  @Transform(({ obj }) => obj.user?.fullName)
  fullname: string;

  @ApiProperty()
  @Expose()
  @IsEnum(MAINTENANCE_TEAM_ROLE)
  role: number;

  @ApiProperty({ type: BasicResponseDto, isArray: true })
  @Expose()
  @Type(() => BasicResponseDto)
  deviceGroups: BasicResponseDto[];

  @ApiProperty({ type: BasicResponseDto, isArray: true })
  @Expose()
  @Type(() => BasicResponseDto)
  areas: BasicResponseDto[];
}
