import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
class MaintenanceTeam extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Expose()
  @Type(() => BasicSqlDocumentResponse)
  factory: BasicSqlDocumentResponse;
}
class UserList {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  username: string;

  @ApiProperty()
  @Expose()
  type: number;
}

export class GetAllMaintenanceTeamAndUserResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => MaintenanceTeam)
  responsibleMaintenanceTeams: MaintenanceTeam[];

  @ApiProperty()
  @Expose()
  @Type(() => UserList)
  responsibleUsers: UserList[];
}
