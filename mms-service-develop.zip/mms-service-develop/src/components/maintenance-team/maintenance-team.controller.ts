import {
  Controller,
  Injectable,
  Inject,
  Post,
  Get,
  Query,
  Param,
  Put,
  UseInterceptors,
} from '@nestjs/common';
import { Body } from '@nestjs/common';
import { MaintenanceTeamServiceInterface } from '@components/maintenance-team/interface/maintenance-team.service.interface';
import { CreateMaintenanceTeamRequestDto } from '@components/maintenance-team/dto/request/create-maintenance-team.request.dto';
import { isEmpty } from 'lodash';
import { UpdateMaintenanceTeamBodyDto } from '@components/maintenance-team/dto/request/update-maintenance-team.request.dto';
import { GetListMaintenanceTeamRequestDto } from '@components/maintenance-team/dto/request/get-list-maintenace-team.request.dto';
import { GetListAllMaintenanceTeamAndUserRequestDto } from '@components/maintenance-team/dto/request/get-list-all-maintenance-team-and-user.request.dto';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import {
  CREATE_MAINTENANCE_TEAM_PERMISSION,
  DETAIL_MAINTENANCE_TEAM_PERMISSION,
  LIST_MAINTENANCE_TEAM_PERMISSION,
  UPDATE_MAINTENANCE_TEAM_PERMISSION,
  UPDATE_STATUS_MAINTENANCE_TEAM_PERMISSION,
} from '@utils/permissions/maintenance-team';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { ACTIVE_ENUM } from '@constant/common';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { GetDetailMaintenanceTeamResponseDto } from './dto/response/get-detail-maintenance-team.response.dto';
import { GetListUserByMaintenanceTeamResponseDto } from './dto/response/get-list-user-by-maintenance-team.response.dto';
import { IdParamSqlDto } from '@utils/dto/request/param-id-sql.request.dto';
import { PermissionTeamQuery } from '@utils/dto/request/permission-team.query';
import { mergePayload } from '@utils/common';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { PermissionWithRoleInterceptor } from '@core/interceptors/permission-with-role.interceptor';
import { PermissionInterceptor } from '@core/interceptors/permission.interceptor';

@Injectable()
@Controller('maintenance-teams')
export class MaintenanceTeamController {
  constructor(
    @Inject('MaintenanceTeamServiceInterface')
    private readonly maintenanceTeamService: MaintenanceTeamServiceInterface,
  ) {}

  // @MessagePattern('create_maintenance_team')
  @PermissionCode(CREATE_MAINTENANCE_TEAM_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Post('')
  @ApiOperation({
    tags: ['Maintenance Team'],
    summary: 'Create Maintenance Team',
    description: 'Create Maintenance Team',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async create(@Body() payload: CreateMaintenanceTeamRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenanceTeamService.create(request);
  }

  @Get('/:id/members')
  @UseInterceptors(PermissionWithRoleInterceptor)
  @ApiOperation({
    tags: ['Maintenance Team'],
    summary: 'List member of maintenance team',
    description: 'List member of maintenance team',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListUserByMaintenanceTeamResponseDto,
  })
  async getUsersByTeam(
    @Param() param: IdParamDto,
    @Query() query: PermissionTeamQuery,
  ): Promise<any> {
    const { request, responseError } = mergePayload(param, query);
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.maintenanceTeamService.getUsersByTeam(request);
  }

  @UseInterceptors(PermissionWithRoleInterceptor)
  @Get('/:id/assignments')
  @ApiOperation({
    tags: ['Maintenance Team'],
    summary: 'List member to assign',
    description: 'List member to assign',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListUserByMaintenanceTeamResponseDto,
  })
  async getUsersToAssign(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.maintenanceTeamService.getUsersToAssign(request);
  }

  @UseInterceptors(PermissionWithRoleInterceptor)
  @Get('/:id/assignment-teams')
  @ApiOperation({
    tags: ['Maintenance Team'],
    summary: 'List member to assign',
    description: 'List member to assign',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListUserByMaintenanceTeamResponseDto,
  })
  async getTeamsToAssign(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.maintenanceTeamService.getTeamsToAssign(request);
  }

  @Get('/:id/user')
  @ApiOperation({
    tags: ['Maintenance Team'],
    summary: 'List member of maintenance team',
    description: 'List member of maintenance team',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListUserByMaintenanceTeamResponseDto,
  })
  async getMaintenanceTeamByUser(@Param() param: IdParamSqlDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.maintenanceTeamService.getMaintenanceTeamByUser(request);
  }

  @Get('/:id/role-user')
  @ApiOperation({
    tags: ['Maintenance Team'],
    summary: 'Role of user in maintenance team',
    description: 'Role of user in maintenance team',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: SuccessResponse,
  })
  async getRoleUserInTeam(@Param() param: IdParamSqlDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.maintenanceTeamService.getRoleUserInTeam(request);
  }

  @PermissionCode(LIST_MAINTENANCE_TEAM_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get('/list')
  @ApiOperation({
    tags: ['Maintenance Team'],
    summary: 'List Of MaintenanceTeam',
    description: 'List Of Maintenance Team',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetDetailMaintenanceTeamResponseDto,
  })
  async getList(
    @Query() payload: GetListMaintenanceTeamRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenanceTeamService.list(request);
  }

  @Get('/maintenance-teams-and-users')
  @ApiOperation({
    tags: ['Maintenance Team'],
    summary: 'List Of MaintenanceTeam and User',
    description: 'List Of Maintenance Team and User',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: null,
  })
  async getListAllMaintenanceTeamsAndUsers(
    @Query() payload: GetListAllMaintenanceTeamAndUserRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.maintenanceTeamService.getListAllUserAndAllMaintenanceTeam(
      request,
    );
  }

  @PermissionCode(
    DETAIL_MAINTENANCE_TEAM_PERMISSION.code,
    UPDATE_MAINTENANCE_TEAM_PERMISSION.code,
  )
  @UseInterceptors(PermissionInterceptor)
  @Get('/:id')
  @ApiOperation({
    tags: ['Maintenance Team'],
    summary: 'Detail Maintenance Team',
    description: 'Detail Maintenance Team',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetDetailMaintenanceTeamResponseDto,
  })
  async detail(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenanceTeamService.detail(request);
  }

  @PermissionCode(UPDATE_MAINTENANCE_TEAM_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Put('/:id')
  @ApiOperation({
    tags: ['Maintenance Team'],
    summary: 'Update MaintenanceTeam',
    description: 'Update an existing Maintenance Team',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  async update(
    @Param() param: IdParamDto,
    @Body() payload: UpdateMaintenanceTeamBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    const { request: requestParam, responseError: responseParamError } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }

    return await this.maintenanceTeamService.update({
      id: requestParam.id,
      ...request,
    });
  }

  @PermissionCode(UPDATE_STATUS_MAINTENANCE_TEAM_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Put('/:id/active')
  @ApiOperation({
    tags: ['Maintenance Team'],
    summary: 'Active Maintenance Team',
    description: 'Active Maintenance Team',
  })
  @ApiResponse({
    status: 200,
    description: 'Active successfully',
    type: SuccessResponse,
  })
  async active(@Param() payload: IdParamDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenanceTeamService.updateStatus({
      ...request,
      status: ACTIVE_ENUM.ACTIVE,
    });
  }

  @PermissionCode(UPDATE_STATUS_MAINTENANCE_TEAM_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Maintenance Team'],
    summary: 'InActive Maintenance Team',
    description: 'InActive Maintenance Team',
  })
  @ApiResponse({
    status: 200,
    description: 'InActive successfully',
    type: SuccessResponse,
  })
  async inactive(@Param() payload: IdParamDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenanceTeamService.updateStatus({
      ...request,
      status: ACTIVE_ENUM.INACTIVE,
    });
  }

  @UseInterceptors(PermissionWithRoleInterceptor)
  @Get('/responsible-user')
  @ApiOperation({
    tags: ['Maintenance Team'],
    summary: 'Lấy danh sách người chịu trách nhiệm',
    description: 'Lấy danh sách người chịu trách nhiệm',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully',
    type: GetListUserByMaintenanceTeamResponseDto,
  })
  async getResponsibleUsers(@Query() query: PaginationQuery): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenanceTeamService.getResponsibleUsers(request);
  }
}
