import { NotificationService } from '@components/notification/notification.service';
import { Module } from '@nestjs/common';
import { ConfigService } from '@config/config.service';
import { MongooseModule } from '@nestjs/mongoose';
import { AreaSchema } from 'src/models/area/area.schema';
import { DeviceAssignmentSchema } from 'src/models/device-assignment/device-assignment.schema';
import { DeviceRequestSchema } from 'src/models/device-request/device-request-ticket.schema';
import { DeviceSchema } from 'src/models/device/device.schema';
import { JobSchema } from 'src/models/job/job.schema';
import { WarehouseExportSchema } from 'src/models/warehouse-export/warehouse-export.schema';
import { AreaRepository } from 'src/repository/area/area.repository';
import { DeviceAssignmentRepository } from 'src/repository/device-assignment/device-assignment.repository';
import { DeviceGroupRepository } from 'src/repository/device-group/device-group.repository';
import { DeviceRequestRepository } from 'src/repository/device-request/device-request-ticket.repository';
import { DeviceRepository } from 'src/repository/device/device.repository';
import { JobRepository } from 'src/repository/job/job.repository';
import { WarehouseExportRepository } from 'src/repository/warehouse-export/warehouse-export.repository';
import { DeviceAssignmentController } from './device-assignment.controller';
import { DeviceAssignmentService } from './device-assignment.service';
import { DeviceAssignmentNotificationListener } from './listeners/device-assignment.notification.listener';
import { MaintenanceTeamRepository } from 'src/repository/maintenance-team/maintenance-team.repository';
import { MaintenanceTeamSchema } from 'src/models/maintenance-team/maintenance-team.schema';
import { WarehouseImportRepository } from 'src/repository/warehouse-import/warehouse-import.repository';
import { HistoryRepository } from 'src/repository/history/history.repository';
import { HistorySchema } from 'src/models/history/history.schema';
@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'DeviceAssignment', schema: DeviceAssignmentSchema },
      { name: 'Area', schema: AreaSchema },
      { name: 'Device', schema: DeviceSchema },
      { name: 'DeviceRequest', schema: DeviceRequestSchema },
      { name: 'Job', schema: JobSchema },
      { name: 'WarehouseExport', schema: WarehouseExportSchema },
      { name: 'MaintenanceTeam', schema: MaintenanceTeamSchema },
      { name: 'History', schema: HistorySchema },
    ]),
  ],
  controllers: [DeviceAssignmentController],
  providers: [
    {
      provide: 'DeviceAssignmentRepositoryInterface',
      useClass: DeviceAssignmentRepository,
    },
    {
      provide: 'DeviceAssignmentServiceInterface',
      useClass: DeviceAssignmentService,
    },
    {
      provide: 'DeviceRequestRepositoryInterface',
      useClass: DeviceRequestRepository,
    },
    {
      provide: 'AreaRepositoryInterface',
      useClass: AreaRepository,
    },
    {
      provide: 'DeviceRepositoryInterface',
      useClass: DeviceRepository,
    },
    {
      provide: 'JobRepositoryInterface',
      useClass: JobRepository,
    },
    {
      provide: 'WarehouseExportRepositoryInterface',
      useClass: WarehouseExportRepository,
    },
    {
      provide: 'DeviceGroupRepositoryInterface',
      useClass: DeviceGroupRepository,
    },
    ConfigService,
    {
      provide: 'NotificationServiceInterface',
      useClass: NotificationService,
    },
    {
      provide: 'MaintenanceTeamRepositoryInterface',
      useClass: MaintenanceTeamRepository,
    },
    {
      provide: 'WarehouseImportRepositoryInterface',
      useClass: WarehouseImportRepository,
    },
    {
      provide: 'HistoryRepositoryInterface',
      useClass: HistoryRepository,
    },
    DeviceAssignmentNotificationListener,
  ],
  exports: [
    MongooseModule,
    {
      provide: 'DeviceAssignmentRepositoryInterface',
      useClass: DeviceAssignmentRepository,
    },
    {
      provide: 'DeviceAssignmentServiceInterface',
      useClass: DeviceAssignmentService,
    },
  ],
})
export class DeviceAssignmentModule {}
