import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';

export class ScanDeviceRequest extends BaseDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  code: string;
}
