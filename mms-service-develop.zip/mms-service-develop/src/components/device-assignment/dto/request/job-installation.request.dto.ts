import { EventRequestDto } from '@components/notification/dto/event.request.dto';
export class JobInstallationEventRequestDto extends EventRequestDto {
  constructor({ id, name, code, entityType, fromUserId, deviceGroupId }) {
    super({ id, name, code, entityType, fromUserId });
    this.deviceGroupId = deviceGroupId;
  }
  deviceGroupId: string;
}
