import {
  IsNotEmpty,
  IsMongoId,
  IsDateString,
  ArrayNotEmpty,
  ValidateNested,
  ArrayUnique,
  IsOptional,
  IsString,
} from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';

class CreateDeviceAssignmentDetailRequestDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  deviceId: string;

  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  areaId: string;
}

export class CreateDeviceAssignmentRequestDto extends BaseDto {
  code: string;

  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  deviceRequestId: string;

  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  warehouseExportId: string;

  @ApiPropertyOptional()
  @IsDateString()
  @IsOptional()
  assignDate: Date;

  @ApiProperty()
  @IsString()
  @IsOptional()
  assignUser: string;

  @ApiProperty({ type: CreateDeviceAssignmentDetailRequestDto, isArray: true })
  @ArrayUnique<CreateDeviceAssignmentDetailRequestDto>(
    (item: CreateDeviceAssignmentDetailRequestDto) => item.deviceId,
  )
  @ValidateNested({ each: true })
  @Type(() => CreateDeviceAssignmentDetailRequestDto)
  @ArrayNotEmpty()
  details: CreateDeviceAssignmentDetailRequestDto[];
}
