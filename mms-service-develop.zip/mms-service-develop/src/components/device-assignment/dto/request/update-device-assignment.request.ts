import { CreateDeviceAssignmentRequestDto } from './create-device-assignment.request';

export class UpdateDeviceAssignmentRequestDto extends CreateDeviceAssignmentRequestDto {}
