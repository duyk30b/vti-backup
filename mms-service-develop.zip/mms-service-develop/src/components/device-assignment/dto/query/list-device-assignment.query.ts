import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { IsArray, IsOptional } from 'class-validator';

export class ListDeviceAssignmentQuery extends PaginationQuery {
  @ApiPropertyOptional()
  @IsArray()
  @IsOptional()
  queryIds?: string;
}
