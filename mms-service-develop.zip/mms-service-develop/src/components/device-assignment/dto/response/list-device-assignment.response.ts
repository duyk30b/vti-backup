import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, plainToInstance, Transform, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { first } from 'lodash';

class DeviceDetail extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  serial: string;

  @ApiProperty()
  @Expose()
  identificationNo: string;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Transform(({ obj }) =>
    plainToInstance(BasicResponseDto, first(obj?.deviceGroup), {
      excludeExtraneousValues: true,
    }),
  )
  deviceGroup: BasicResponseDto;
}

export class ListDeviceAssignmentResponse extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty({ type: DeviceDetail, isArray: true })
  @Expose()
  @Type(() => DeviceDetail)
  @IsArray()
  devices: DeviceDetail[];

  @ApiProperty({
    type: BasicResponseDto,
  })
  @Expose()
  @Transform(({ value }) => first(value))
  @Type(() => BasicResponseDto)
  deviceRequest: BasicResponseDto;

  @ApiProperty({
    type: BasicSqlDocumentResponse,
  })
  @Expose()
  @Type(() => BasicSqlDocumentResponse)
  factory: BasicSqlDocumentResponse;
}

export class ListDeviceAssignmentResponseDto extends PaginationResponse {
  @ApiProperty({ type: ListDeviceAssignmentResponse, isArray: true })
  @Expose()
  items: ListDeviceAssignmentResponse;
}
