import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform } from 'class-transformer';

export class ScanDeviceResponse extends BaseResponseDto {
  @ApiProperty()
  @Transform(
    ({ obj }) => obj.deviceAssignment?.details[0]?.device?.serial ?? '',
  )
  @Expose()
  serial: string;

  @ApiProperty()
  @Transform(
    ({ obj }) =>
      obj.deviceAssignment?.details[0]?.device?._id?.toString() ?? '',
  )
  @Expose()
  deviceId: string;

  @ApiProperty()
  @Transform(({ obj }) => obj.deviceAssignment?._id?.toString() ?? '')
  @Expose()
  deviceAssignmentId: string;

  @ApiProperty()
  @Transform(({ obj }) => obj.deviceAssignment?.details[0]?.device?.name ?? '')
  @Expose()
  deviceName: string;

  @ApiProperty()
  @Transform(({ obj }) => obj.deviceAssignment?.details[0]?.device?.model ?? '')
  @Expose()
  model: string;

  @ApiProperty()
  @Transform(({ obj }) => obj.deviceAssignment?.details[0]?.area?.name ?? '')
  @Expose()
  areaName: string;
}
