import { DeviceBasicResponseDto } from '@components/device/dto/response/device-basic.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { Expose, plainToInstance, Transform, Type } from 'class-transformer';

class DetailDeviceAssignmentDetailResponse {
  @ApiProperty({ type: DeviceBasicResponseDto })
  @Expose()
  @Type(() => DeviceBasicResponseDto)
  device: DeviceBasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  @Transform(({ obj }) =>
    plainToInstance(BasicResponseDto, obj?.device?.deviceGroup, {
      excludeExtraneousValues: true,
    }),
  )
  deviceGroup: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  area: BasicResponseDto;
}

export class DetailDeviceAssignmentResponse extends BasicResponseDto {
  @ApiProperty({
    type: BasicResponseDto,
  })
  @Type(() => BasicResponseDto)
  @Expose()
  deviceRequest: BasicResponseDto;

  @ApiProperty({
    type: BasicResponseDto,
  })
  @Type(() => BasicResponseDto)
  @Expose()
  warehouseExport: BasicResponseDto;

  @ApiProperty()
  @Expose()
  assignDate: Date;

  @ApiProperty()
  @Expose()
  assignUser: string;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  factory: BasicSqlDocumentResponse;

  @ApiProperty({
    type: DetailDeviceAssignmentDetailResponse,
    isArray: true,
  })
  @Type(() => DetailDeviceAssignmentDetailResponse)
  @Expose()
  details: DetailDeviceAssignmentDetailResponse[];
}
