import { CODE_REGEX } from '@constant/common';

export const DEVICE_ASSIGNMENT_CONST = {
  CODE: {
    LENGTH: 20,
    COLUMN: 'code',
    PAD_CHAR: '0',
    PREFIX: 'PCTB',
    DEFAULT_CODE: 0,
    REGEX: CODE_REGEX,
  },
};

export enum WorkTimeDataSourceEnum {
  MES,
  INPUT,
  IOT,
}

export enum DEVICE_ASSIGNMENTS_STATUS_ENUM {
  WAIT_CONFIRM,
  CONFIRMED,
  REJECT,
  COMPLETED,
}

export const DEVICE_ASSIGNMENT_CODE_CONST = {
  MAX_LENGTH: 20,
  COLUMN: 'code',
  PAD_CHAR: '0',
  DEFAULT_CODE: '0',
};

export const DEVICE_ASSIGNMENTS_STATUS_CAN_UPDATE = [
  DEVICE_ASSIGNMENTS_STATUS_ENUM.WAIT_CONFIRM,
];

export const DEVICE_ASSIGNMENTS_STATUS_CAN_DELETE = [
  DEVICE_ASSIGNMENTS_STATUS_ENUM.WAIT_CONFIRM,
];

export const DEVICE_ASSIGNMENT_ACTION_CONFIRMED = 'confirmed';
export const DEVICE_ASSIGNMENT_ACTION_REJECTED = 'rejected';

export const DEVICE_ASSIGNMENT_ACTION = [
  DEVICE_ASSIGNMENT_ACTION_CONFIRMED,
  DEVICE_ASSIGNMENT_ACTION_REJECTED,
];

export enum DEVICE_ASSIGNMENT_EVENTS_ENUM {
  CREATED = 'device-assignment.created',
  APPROVED = 'device-assignment.approved',
  REJECTED = 'device-assignment.rejected',
  COMPLETED = 'device-assignment.completed',
}
