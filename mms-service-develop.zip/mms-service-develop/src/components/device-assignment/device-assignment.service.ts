import { AreaRepositoryInterface } from '@components/area/interface/area.repository.interface';
import { DeviceGroupRepositoryInterface } from '@components/device-group/interface/device-group.repository.interface';
import {
  DEVICE_REQUEST_EVENTS_ENUM,
  DEVICE_REQUEST_STATUS_ENUM,
} from '@components/device-request/device-request.constant';
import { DeviceRequestRepositoryInterface } from '@components/device-request/interface/device-request-ticket.repository.interface';
import { DEVICE_STATUS_ENUM } from '@components/device/device.constant';
import { DeviceRepositoryInterface } from '@components/device/interface/device.repository.interface';
import {
  HISTORY_ACTION_ENUM,
  HISTORY_REASON_REF_ENUM,
  HISTORY_REF_ENUM,
} from '@components/history/history.constant';
import { HistoryRepositoryInterface } from '@components/history/interface/history.repository.interface';
import { JobRepositoryInterface } from '@components/job/interface/job.repository.interface';
import {
  JOB_EVENTS_ENUM,
  JOB_STATUS_ENUM,
  JOB_TYPE_ENUM,
} from '@components/job/job.constant';
import { EventRequestDto } from '@components/notification/dto/event.request.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { WarehouseExportRepositoryInterface } from '@components/warehouse-export/interface/warehouse-export.repository.interface';
import { ACTIVE_ENUM } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { ApiError } from '@utils/api.error';
import { plus } from '@utils/common';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import {
  compact,
  difference,
  groupBy,
  has,
  isEmpty,
  keyBy,
  uniq,
} from 'lodash';
import { Types } from 'mongoose';
import { I18nRequestScopeService } from 'nestjs-i18n';
import {
  DEVICE_ASSIGNMENTS_STATUS_CAN_DELETE,
  DEVICE_ASSIGNMENTS_STATUS_CAN_UPDATE,
  DEVICE_ASSIGNMENTS_STATUS_ENUM,
  DEVICE_ASSIGNMENT_ACTION_CONFIRMED,
  DEVICE_ASSIGNMENT_ACTION_REJECTED,
  DEVICE_ASSIGNMENT_CONST,
  DEVICE_ASSIGNMENT_EVENTS_ENUM,
} from './device-assignment.constant';
import { ListDeviceAssignmentQuery } from './dto/query/list-device-assignment.query';
import { CreateDeviceAssignmentRequestDto } from './dto/request/create-device-assignment.request';
import { JobInstallationEventRequestDto } from './dto/request/job-installation.request.dto';
import { ScanDeviceRequest } from './dto/request/scan-device.request';
import { UpdateDeviceAssignmentRequestDto } from './dto/request/update-device-assignment.request';
import { UpdateStatusDeviceAssignmentRequestDto } from './dto/request/update-status-device-assignment.request';
import { DetailDeviceAssignmentResponse } from './dto/response/detail-device-assignment.response.dto';
import { ListDeviceAssignmentResponse } from './dto/response/list-device-assignment.response';
import { ScanDeviceResponse } from './dto/response/scan-device.response';
import { DeviceAssignmentRepositoryInterface } from './interface/device-assignment.repository.interface';
import { DeviceAssignmentServiceInterface } from './interface/device-assignment.service.interface';

@Injectable()
export class DeviceAssignmentService
  implements DeviceAssignmentServiceInterface
{
  constructor(
    @Inject('DeviceAssignmentRepositoryInterface')
    private readonly deviceAssignmentRepository: DeviceAssignmentRepositoryInterface,

    @Inject('DeviceRequestRepositoryInterface')
    private readonly deviceRequestRepository: DeviceRequestRepositoryInterface,

    @Inject('DeviceRepositoryInterface')
    private readonly deviceRepository: DeviceRepositoryInterface,

    @Inject('AreaRepositoryInterface')
    private readonly areaRepository: AreaRepositoryInterface,

    @Inject('JobRepositoryInterface')
    private readonly jobRepository: JobRepositoryInterface,

    @Inject('WarehouseExportRepositoryInterface')
    private readonly warehouseExportRepository: WarehouseExportRepositoryInterface,

    @Inject('DeviceGroupRepositoryInterface')
    private readonly deviceGroupRepository: DeviceGroupRepositoryInterface,

    @Inject('HistoryRepositoryInterface')
    private readonly historyRepository: HistoryRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    private readonly i18n: I18nRequestScopeService,

    private readonly eventEmitter: EventEmitter2,
  ) {}

  async update(
    request: UpdateDeviceAssignmentRequestDto & IdParamDto,
  ): Promise<ResponsePayload<any>> {
    const deviceAssignmentExist =
      await this.deviceAssignmentRepository.findOneById(request.id);

    if (!deviceAssignmentExist) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (
      !DEVICE_ASSIGNMENTS_STATUS_CAN_UPDATE.includes(
        deviceAssignmentExist.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.DEVICE_ASSIGNMENT_STATUS_INVALID'),
        )
        .build();
    }

    const validateData = await this.validateData(request, true);
    if (validateData.statusCode !== ResponseCodeEnum.SUCCESS) {
      return validateData;
    }

    // @TODO: validate maintenance team with area

    await this.deviceAssignmentRepository.findByIdAndUpdate(request.id, {
      deviceRequestId: request.deviceRequestId,
      warehouseExportId: request.warehouseExportId,
      assignDate: request.assignDate,
      assignUser: request.assignUser,
      details: request.details.map((detail) => ({
        deviceId: detail.deviceId,
        areaId: detail.areaId,
      })),
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async delete(request: IdParamDto): Promise<ResponsePayload<any>> {
    const deviceAssignmentExist =
      await this.deviceAssignmentRepository.findOneById(request.id);

    if (!deviceAssignmentExist) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const deviceRequest = await this.deviceRequestRepository.findOneByCondition(
      { _id: deviceAssignmentExist.deviceRequestId },
    );

    if (!deviceRequest) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (
      !DEVICE_ASSIGNMENTS_STATUS_CAN_DELETE.includes(
        deviceAssignmentExist.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.DEVICE_ASSIGNMENT_STATUS_INVALID'),
        )
        .build();
    }

    await this.deviceAssignmentRepository.softDelete(request.id);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async detail(request: IdParamDto): Promise<ResponsePayload<any>> {
    const deviceAssignment =
      await this.deviceAssignmentRepository.findOneWithPopulate(
        { _id: request.id },
        [
          {
            path: 'deviceRequest',
          },
          {
            path: 'warehouseExport',
          },
          { path: 'details.device', populate: { path: 'deviceGroup' } },
          { path: 'details.area' },
        ],
      );

    if (!deviceAssignment) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (deviceAssignment['deviceRequest']?.factoryId) {
      const factory = await this.userService.getFactoryById(
        deviceAssignment['deviceRequest']?.factoryId,
      );

      deviceAssignment['factory'] = factory ?? {};
    }

    const dataReturn = plainToInstance(
      DetailDeviceAssignmentResponse,
      deviceAssignment,
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async changeStatus(
    request: UpdateStatusDeviceAssignmentRequestDto,
  ): Promise<ResponsePayload<any>> {
    const deviceAssignment =
      await this.deviceAssignmentRepository.findOneWithPopulate(
        {
          _id: request.id,
        },
        [
          {
            path: 'deviceRequest',
          },
          {
            path: 'details.device',
            populate: 'deviceGroup',
          },
        ],
      );

    if (!deviceAssignment) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    let status = this.getDeviceAssignmentStatusByAction(request.action);

    const isStatusValid = this.checkStatusValid(
      deviceAssignment.status,
      status,
    );
    if (!isStatusValid) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.DEVICE_ASSIGNMENT_STATUS_INVALID'),
        )
        .build();
    }
    const deviceIdsDoNotNeedInstall = [];
    const bulkOps = [];
    const objectPairs = [];
    const deviceUpdateMap: any = {};
    const deviceNeedInstallation = compact(
      deviceAssignment.details.map((device) => {
        if (!device['device']?.deviceGroup?.installationTemplateId) {
          deviceIdsDoNotNeedInstall.push(device.deviceId);
          // update area when device is assign
          bulkOps.push({
            updateOne: {
              filter: { _id: device.deviceId },
              update: {
                $set: {
                  areaId: device.areaId,
                  status: DEVICE_STATUS_ENUM.USING,
                },
              },
              upsert: false,
            },
          });
          deviceUpdateMap[device.deviceId] = {
            _id: device.deviceId,
            areaId: device.areaId,
            status: DEVICE_STATUS_ENUM.USING,
          };
        }

        return device['device']?.deviceGroup?.installationTemplateId;
      }),
    );

    if (!isEmpty(deviceIdsDoNotNeedInstall)) {
      const oldDevices = await this.deviceRepository.findAllByCondition({
        _id: { $in: deviceIdsDoNotNeedInstall },
      });
      oldDevices?.forEach((e) => {
        const newObject = deviceUpdateMap[e._id.toString()];
        objectPairs.push({
          oldObject: e,
          newObject,
        });
      });
      // update area when device is assign
      await this.deviceRepository.bulkWrite(bulkOps);
      await this.historyRepository.logHistoryForDocuments(
        objectPairs as any,
        HISTORY_REF_ENUM.DEVICE,
        request.userId,
        HISTORY_REASON_REF_ENUM.DEVICE_ASSIGNMENT,
        request.id,
      );
    }

    if (
      isEmpty(deviceNeedInstallation) &&
      status === DEVICE_ASSIGNMENTS_STATUS_ENUM.CONFIRMED
    ) {
      status = DEVICE_ASSIGNMENTS_STATUS_ENUM.COMPLETED;
      this.eventEmitter.emit(
        DEVICE_ASSIGNMENT_EVENTS_ENUM.APPROVED,
        new EventRequestDto({
          id: deviceAssignment._id,
          code: deviceAssignment.code,
          name: '',
          fromUserId: request.user.id,
        }),
      );
      this.eventEmitter.emit(
        DEVICE_ASSIGNMENT_EVENTS_ENUM.COMPLETED,
        new EventRequestDto({
          id: deviceAssignment._id,
          code: deviceAssignment.code,
          name: '',
        }),
      );
      // after device assignment to completed => check device provide request to completed
      await this.completedDeviceRequest(deviceAssignment.deviceRequestId);
    } else if (status === DEVICE_ASSIGNMENTS_STATUS_ENUM.CONFIRMED) {
      await this.createInstallationJob(deviceAssignment, request.user);
      this.eventEmitter.emit(
        DEVICE_ASSIGNMENT_EVENTS_ENUM.APPROVED,
        new EventRequestDto({
          id: deviceAssignment._id,
          code: deviceAssignment.code,
          name: '',
          fromUserId: request.user.id,
        }),
      );
    } else if (status === DEVICE_ASSIGNMENTS_STATUS_ENUM.REJECT) {
      this.eventEmitter.emit(
        DEVICE_ASSIGNMENT_EVENTS_ENUM.REJECTED,
        new EventRequestDto({
          id: deviceAssignment._id,
          code: deviceAssignment.code,
          name: '',
          fromUserId: request.user.id,
        }),
      );
    }

    await this.deviceAssignmentRepository.findByIdAndUpdate(request.id, {
      status,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async create(
    request: CreateDeviceAssignmentRequestDto,
  ): Promise<ResponsePayload<any>> {
    const validateData = await this.validateData(request);
    if (validateData.statusCode !== ResponseCodeEnum.SUCCESS) {
      return validateData;
    }
    request.code =
      await this.deviceAssignmentRepository.generateNextCodeWithYear(
        DEVICE_ASSIGNMENT_CONST.CODE.PREFIX,
      );
    const deviceAssignmentDocument =
      await this.deviceAssignmentRepository.createDocument(request);

    const deviceAssignment = await deviceAssignmentDocument.save();
    const dataReturn = plainToInstance(BasicResponseDto, deviceAssignment, {
      excludeExtraneousValues: true,
    });
    this.eventEmitter.emit(
      DEVICE_ASSIGNMENT_EVENTS_ENUM.CREATED,
      new EventRequestDto({
        id: deviceAssignment._id,
        code: deviceAssignment.code,
        name: '',
        fromUserId: request.user.id,
      }),
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async validateData(request: any, isUpdate = false) {
    const { deviceRequestId } = request;
    const conditionDeviceAssignment = {
      deviceRequestId,
      status: {
        $ne: DEVICE_ASSIGNMENTS_STATUS_ENUM.REJECT,
      },
      _id: { $ne: isUpdate ? request.id : null },
    };

    // validate tồn tại yêu cầu thiết bị
    const deviceRequest = await this.deviceRequestRepository.findOneByCondition(
      { ...request.permissionCondition, _id: deviceRequestId },
    );
    if (!deviceRequest) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.DEVICE_REQUEST_TICKET_NOT_FOUND'),
      ).toResponse();
    }

    const deviceIds = [];
    const areaIds = [];

    request.details.forEach((item) => {
      deviceIds.push(item.deviceId);
      areaIds.push(item.areaId);
    });

    const devices = await this.deviceRepository.findAllByCondition({
      ...request.permissionCondition,
      _id: {
        $in: deviceIds,
      },
      deviceGroupId: {
        $in: deviceRequest.deviceGroupRequest?.map((e) => e.deviceGroupId),
      },
      active: ACTIVE_ENUM.ACTIVE,
    });

    if (devices.length !== uniq(deviceIds).length) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.DEVICE_NOT_FOUND'),
      ).toResponse();
    }

    const deviceGroupBy = groupBy(devices, 'deviceGroupId');

    const areas = await this.areaRepository.findAllByCondition({
      ...request.permissionCondition,
      _id: {
        $in: areaIds,
      },
    });

    if (areas.length !== uniq(areaIds).length) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.AREA_NOT_EXIST'),
      ).toResponse();
    }

    if (request.warehouseExportId) {
      const warehouseExport = await this.warehouseExportRepository.findOneById(
        request.warehouseExportId,
      );

      if (!warehouseExport) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      const isDiff = !isEmpty(
        difference(
          uniq(deviceIds),
          warehouseExport.devices?.map((el) => el.deviceId?.toString()),
        ),
      );

      if (isDiff) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
          .build();
      }
    }

    const deviceAssignmentExists =
      await this.deviceAssignmentRepository.findAllByCondition(
        conditionDeviceAssignment,
      );

    if (!isEmpty(deviceAssignmentExists)) {
      const deviceExistIds = [];
      deviceAssignmentExists.forEach((e) => {
        e.details.forEach((detail) => {
          deviceExistIds.push(detail.deviceId);
        });
      });

      const devices = await this.deviceRepository.findAllByCondition({
        ...request.permissionCondition,
        _id: {
          $in: deviceExistIds,
        },
        active: ACTIVE_ENUM.ACTIVE,
      });

      const deviceExistGroupBy = groupBy(devices, 'deviceGroupId');

      let flag = false;

      deviceRequest.deviceGroupRequest.forEach((e) => {
        if (
          plus(
            deviceExistGroupBy[e.deviceGroupId]?.length || 0,
            deviceGroupBy[e.deviceGroupId]?.length || 0,
          ) > e.quantity
        ) {
          flag = true;
        }
      });

      if (flag) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.EXCEED_THE_REQUIRED_QUANTITY'),
        ).toResponse();
      }
    }
    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async list(
    request: ListDeviceAssignmentQuery,
  ): Promise<ResponsePayload<any>> {
    const { result, count } = await this.deviceAssignmentRepository.list(
      request,
    );

    const factoryIds = [];

    result.map((e) => {
      if (!isEmpty(e.deviceRequest) && e.deviceRequest[0]?.factoryId) {
        factoryIds.push(e.deviceRequest[0]?.factoryId);
      }
    });

    const factories = await this.userService.getFactoryList([
      {
        column: 'factoryIds',
        text: factoryIds,
      },
    ]);

    const factoryMap = keyBy(factories, 'id');

    result.forEach((e) => {
      e.factory = !isEmpty(e.deviceRequest[0])
        ? factoryMap[e.deviceRequest[0]?.factoryId]
        : {};
    });

    const dataReturn = plainToInstance(ListDeviceAssignmentResponse, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PaginationResponse>({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async scan(request: ScanDeviceRequest): Promise<ResponsePayload<any>> {
    const device = await this.deviceRepository.findOneByCondition({
      code: request.code,
      active: ACTIVE_ENUM.ACTIVE,
    });

    if (!device) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const deviceAssignment =
      await this.deviceAssignmentRepository.findOneWithPopulate(
        { 'details.deviceId': device._id },
        {
          path: 'details.area details.device',
        },
      );

    if (!deviceAssignment) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const dataReturn = plainToInstance(
      ScanDeviceResponse,
      {
        deviceAssignment,
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  private checkStatusValid(oldStatus: number, newStatus: number) {
    switch (newStatus) {
      case DEVICE_ASSIGNMENTS_STATUS_ENUM.CONFIRMED:
        return oldStatus === DEVICE_ASSIGNMENTS_STATUS_ENUM.WAIT_CONFIRM;
      case DEVICE_ASSIGNMENTS_STATUS_ENUM.REJECT:
        return oldStatus !== DEVICE_ASSIGNMENTS_STATUS_ENUM.CONFIRMED;
      default:
        return false;
    }
  }

  private getDeviceAssignmentStatusByAction(action: string): number {
    switch (action) {
      case DEVICE_ASSIGNMENT_ACTION_CONFIRMED:
        return DEVICE_ASSIGNMENTS_STATUS_ENUM.CONFIRMED;
      case DEVICE_ASSIGNMENT_ACTION_REJECTED:
        return DEVICE_ASSIGNMENTS_STATUS_ENUM.REJECT;
      default:
        return DEVICE_ASSIGNMENTS_STATUS_ENUM.WAIT_CONFIRM;
    }
  }

  private async createInstallationJob(
    deviceAssignment: any,
    user: any,
  ): Promise<any> {
    const jobName = await this.i18n.translate('text.installationJobName');
    const messageCreatedJob = await this.i18n.translate('text.CREATED_JOB');

    const deviceGroupIds = deviceAssignment.details.map(
      (e) => e.device?.deviceGroupId,
    );

    const deviceGroups = await this.deviceGroupRepository.findAllByCondition({
      _id: {
        $in: deviceGroupIds,
      },
    });

    const deviceGroupMap = keyBy(deviceGroups, '_id');

    const dataInserts = [];
    const deviceIds = [];
    deviceAssignment.details.forEach((e) => {
      if (
        has(deviceGroupMap, e.device?.deviceGroupId?.toString()) &&
        deviceGroupMap[e.device?.deviceGroupId?.toString()]
          ?.installationTemplateId
      ) {
        this.eventEmitter.emit(
          JOB_EVENTS_ENUM.JOB_INSTALLATION_CREATE,
          new JobInstallationEventRequestDto({
            id: deviceAssignment._id,
            code: deviceAssignment.code,
            name: '',
            entityType: e?.type,
            fromUserId: user.id,
            deviceGroupId: e.device?.deviceGroupId,
          }),
        );
        dataInserts.push({
          name: jobName.replace('{deviceName}', e.device?.name ?? ''),
          status: JOB_STATUS_ENUM.NON_ASSIGN,
          type: JOB_TYPE_ENUM.INSTALLATION,
          deviceAssignmentId: deviceAssignment._id,
          histories: [
            {
              userId: user.id,
              action: HISTORY_ACTION_ENUM.CREATE,
              content: messageCreatedJob.replace('{username}', user.username),
              status: JOB_STATUS_ENUM.NON_ASSIGN,
            },
          ],
          deviceId: e.device?._id,
          areaId: e.device?.areaId,
          jobTypeId:
            deviceGroupMap[e.device?.deviceGroupId?.toString()]
              ?.installationTemplateId,
        });
      } else deviceIds.push(new Types.ObjectId(e?.device?._id));
    });

    const jobDocuments = await this.jobRepository.createEntities(dataInserts);
    const jobs: any = await this.jobRepository.create(jobDocuments);
    jobs.forEach((e) => {
      this.eventEmitter.emit(
        JOB_EVENTS_ENUM.CREATE,
        new EventRequestDto({
          id: e?._id,
          name: e?.name,
          code: e?.code,
          entityType: e?.type,
          fromUserId: user?.id,
        }),
      );
    });

    return jobs;
  }

  async completedDeviceRequest(deviceRequestId: any): Promise<any> {
    const deviceRequest =
      await this.deviceRequestRepository.findOneWithPopulate(
        { _id: deviceRequestId },
        'deviceGroupRequest.deviceGroup',
      );

    const countDevice =
      deviceRequest.deviceGroupRequest?.reduce(
        (total, el) =>
          el['deviceGroup']?.installationTemplateId
            ? plus(total, el.quantity || 0)
            : total,
        0,
      ) || 0;

    const deviceAssignmentByDeviceRequest =
      await this.deviceAssignmentRepository.findAllByCondition({
        deviceRequestId: deviceRequestId,
      });

    const jobByDeviceRequest = await this.jobRepository.findAllByCondition({
      deviceAssignmentId: {
        $in: deviceAssignmentByDeviceRequest?.map((e) => e._id) || [],
      },
      status: JOB_STATUS_ENUM.RESOLVED,
      type: JOB_TYPE_ENUM.INSTALLATION,
    });
    if (jobByDeviceRequest?.length === countDevice) {
      await this.deviceRequestRepository.findByIdAndUpdate(deviceRequestId, {
        status: DEVICE_REQUEST_STATUS_ENUM.COMPLETED,
      });
      this.eventEmitter.emit(
        DEVICE_REQUEST_EVENTS_ENUM.COMPLETED,
        new EventRequestDto({
          id: deviceRequest._id,
          code: deviceRequest.code,
          name: '',
          entityType: deviceRequest.type,
        }),
      );
    }
  }
}
