import { JOB_EVENTS_ENUM } from '@components/job/job.constant';
import { MaintenanceTeamRepositoryInterface } from '@components/maintenance-team/interface/maintenance-team.repository.interface';
import { MAINTENANCE_TEAM_ROLE } from '@components/maintenance-team/maintenance-team.constant';
import { EventRequestDto } from '@components/notification/dto/event.request.dto';
import { PushNotificationRequestDto } from '@components/notification/dto/notification.request.dto';
import { NotificationServiceInterface } from '@components/notification/interface/notification.service.interface';
import {
  NOTIFICATION_ENTITY_ENUM,
  TYPE_NOTIFICATION_RENDER_ACTION_ENUM,
} from '@components/notification/notification.const';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { NotificationListenerAbstract } from '@core/abstracts/notification.listener.abstract';
import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { map } from 'lodash';
import { I18nService } from 'nestjs-i18n';
import { DEVICE_ASSIGNMENT_EVENTS_ENUM } from '../device-assignment.constant';
import { JobInstallationEventRequestDto } from '../dto/request/job-installation.request.dto';
import { DeviceAssignmentRepositoryInterface } from '../interface/device-assignment.repository.interface';

@Injectable()
export class DeviceAssignmentNotificationListener extends NotificationListenerAbstract {
  constructor(
    @Inject('NotificationServiceInterface')
    protected readonly notificationService: NotificationServiceInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('DeviceAssignmentRepositoryInterface')
    private readonly deviceAssignmentRepository: DeviceAssignmentRepositoryInterface,

    @Inject('MaintenanceTeamRepositoryInterface')
    private readonly maintenanceTeamRepository: MaintenanceTeamRepositoryInterface,

    private readonly i18n: I18nService,
  ) {
    super(notificationService);
  }

  @OnEvent(DEVICE_ASSIGNMENT_EVENTS_ENUM.CREATED)
  public async handleCreateDeviceAssignment(event: EventRequestDto) {
    const notificationRequest = new PushNotificationRequestDto();
    const { id, code, fromUserId } = event;
    const user = await this.userService.getDetailUser(fromUserId);
    const { fullName, username } = user;
    notificationRequest.title = await this.i18n.translate(
      'message.defineDeviceAssignment.notification.createTitle',
    );
    notificationRequest.content = await this.i18n.translate(
      'message.defineDeviceAssignment.notification.createdContent',
      { args: { username: fullName || username, code } },
    );
    notificationRequest.action =
      // noti created thì action(điều hướng) sang confirm and reject
      TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_CONFIRM_AND_REJECT;
    notificationRequest.payload = this.generatePayload(
      event,
      NOTIFICATION_ENTITY_ENUM.DEVICE_ASSIGN_DETAIL,
    );

    const deviceAssignment =
      await this.deviceAssignmentRepository.findOneWithPopulate(
        {
          _id: id,
        },
        'deviceRequest',
      );
    const users = await this.userService.getListFactoryManager(
      deviceAssignment?.['deviceRequest']?.factoryId,
    );
    const userIds = map(users, 'id');
    notificationRequest.userIds = userIds;
    notificationRequest.createdBy = event.fromUserId;
    return [await super.sendWebNotification(notificationRequest)];
  }

  @OnEvent(DEVICE_ASSIGNMENT_EVENTS_ENUM.APPROVED)
  public async handleApproveDeviceAssigment(event: EventRequestDto) {
    const notificationRequest = new PushNotificationRequestDto();
    const { id, code, fromUserId } = event;
    const user = await this.userService.getDetailUser(fromUserId);
    const { fullName, username } = user;
    notificationRequest.title = await this.i18n.translate(
      'message.defineDeviceAssignment.notification.approveTitle',
    );
    notificationRequest.content = await this.i18n.translate(
      'message.defineDeviceAssignment.notification.approveContent',
      {
        args: {
          username: fullName || username,
          code,
        },
      },
    );
    notificationRequest.action =
      TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_VIEW;
    notificationRequest.payload = this.generatePayload(
      event,
      NOTIFICATION_ENTITY_ENUM.DEVICE_ASSIGN_DETAIL,
    );

    const deviceAssignment =
      await this.deviceAssignmentRepository.findOneWithPopulate(
        {
          _id: id,
        },
        'deviceRequest',
      );
    const users = await this.userService.getListFactoryManager(
      deviceAssignment['deviceRequest'].factoryId,
    );
    const userIds = map(users, 'id');
    notificationRequest.userIds = userIds;
    notificationRequest.createdBy = event.fromUserId;
    return [await super.sendWebNotification(notificationRequest)];
  }

  @OnEvent(DEVICE_ASSIGNMENT_EVENTS_ENUM.REJECTED)
  public async handleRejectDeviceAssigment(event: EventRequestDto) {
    const notificationRequest = new PushNotificationRequestDto();
    const { id, code, fromUserId } = event;
    const user = await this.userService.getDetailUser(fromUserId);
    const { fullName, username } = user;
    notificationRequest.title = await this.i18n.translate(
      'message.defineDeviceAssignment.notification.rejectTitle',
    );
    notificationRequest.content = await this.i18n.translate(
      'message.defineDeviceAssignment.notification.rejectContent',
      {
        args: {
          username: fullName || username,
          code,
        },
      },
    );
    notificationRequest.action =
      TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_VIEW;
    notificationRequest.payload = this.generatePayload(
      event,
      NOTIFICATION_ENTITY_ENUM.DEVICE_ASSIGN_DETAIL,
    );

    const deviceAssignment =
      await this.deviceAssignmentRepository.findOneWithPopulate(
        {
          _id: id,
        },
        'deviceRequest',
      );
    const users = await this.userService.getListFactoryManager(
      deviceAssignment['deviceRequest']?.factoryId,
    );
    const userIds = map(users, 'id');
    notificationRequest.userIds = userIds;
    notificationRequest.createdBy = event.fromUserId;
    return [await super.sendWebNotification(notificationRequest)];
  }

  @OnEvent(JOB_EVENTS_ENUM.JOB_INSTALLATION_CREATE)
  public async handleCreateJobInstallation(
    event: JobInstallationEventRequestDto,
  ) {
    const notificationRequest = new PushNotificationRequestDto();
    const { id, code, deviceGroupId } = event;
    notificationRequest.title = await this.i18n.translate(
      'message.defineDeviceAssignment.notification.approveTitle',
    );

    notificationRequest.action =
      // noti created thì action(điều hướng) sang assignment
      TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_ASSIGNMENT;
    notificationRequest.payload = this.generatePayload(
      event,
      NOTIFICATION_ENTITY_ENUM.JOB_LIST,
    );

    notificationRequest.content = await this.i18n.translate(
      'message.defineJob.notification.jobsInstallationContent',
      {
        args: {
          code,
        },
      },
    );
    const deviceAssignment =
      await this.deviceAssignmentRepository.findOneWithPopulate(
        {
          _id: id,
        },
        'deviceRequest',
      );
    const maintenanceTeams =
      await this.maintenanceTeamRepository.findAllByCondition({
        factoryId: deviceAssignment['deviceRequest']?.factoryId,
        deviceGroupIds: deviceGroupId,
      });
    const userIds = maintenanceTeams?.map(
      (team) =>
        team.members.find((m) => m.role === MAINTENANCE_TEAM_ROLE.LEADER)
          ?.userId,
    );
    notificationRequest.userIds = userIds;
    notificationRequest.createdBy = event.fromUserId;

    return [await super.sendWebNotification(notificationRequest)];
  }

  @OnEvent(DEVICE_ASSIGNMENT_EVENTS_ENUM.COMPLETED)
  public async handleCompleteDeviceAssigment(event: EventRequestDto) {
    const notificationRequest = new PushNotificationRequestDto();
    const { id, code } = event;
    notificationRequest.title = await this.i18n.translate(
      'message.defineDeviceAssignment.notification.completeTitle',
    );
    notificationRequest.content = await this.i18n.translate(
      'message.defineDeviceAssignment.notification.completeContent',
      {
        args: {
          code,
        },
      },
    );
    notificationRequest.action =
      TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_VIEW;
    notificationRequest.payload = this.generatePayload(
      event,
      NOTIFICATION_ENTITY_ENUM.DEVICE_ASSIGN_DETAIL,
    );

    const deviceAssignment =
      await this.deviceAssignmentRepository.findOneWithPopulate(
        {
          _id: id,
        },
        'deviceRequest',
      );
    const users = await this.userService.getListFactoryManager(
      deviceAssignment['deviceRequest'].factoryId,
    );
    const userIds = map(users, 'id');
    notificationRequest.userIds = userIds;
    notificationRequest.createdBy = event.fromUserId;
    return [await super.sendWebNotification(notificationRequest)];
  }
}
