import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  Controller,
  Injectable,
  Inject,
  Post,
  Body,
  Query,
  Get,
  Delete,
  Put,
  Param,
  UseInterceptors,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import {
  CREATE_DEVICE_ASSIGNMENT_PERMISSION,
  DELETE_DEVICE_ASSIGNMENT_PERMISSION,
  DETAIL_DEVICE_ASSIGNMENT_PERMISSION,
  LIST_DEVICE_ASSIGNMENT_PERMISSION,
  UPDATE_DEVICE_ASSIGNMENT_PERMISSION,
  UPDATE_STATUS_DEVICE_ASSIGNMENT_PERMISSION,
} from '@utils/permissions/device-assignment';
import { isEmpty } from 'lodash';
import { ListDeviceAssignmentQuery } from './dto/query/list-device-assignment.query';
import { CreateDeviceAssignmentRequestDto } from './dto/request/create-device-assignment.request';
import { UpdateDeviceAssignmentRequestDto } from './dto/request/update-device-assignment.request';
import { UpdateStatusDeviceAssignmentRequestDto } from './dto/request/update-status-device-assignment.request';
import { ScanDeviceRequest } from './dto/request/scan-device.request';
import { DeviceAssignmentServiceInterface } from './interface/device-assignment.service.interface';
import { DetailDeviceAssignmentResponse } from './dto/response/detail-device-assignment.response.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { ListDeviceAssignmentResponseDto } from './dto/response/list-device-assignment.response';
import {
  DEVICE_ASSIGNMENT_ACTION_CONFIRMED,
  DEVICE_ASSIGNMENT_ACTION_REJECTED,
} from './device-assignment.constant';
import { PermissionInterceptor } from '@core/interceptors/permission.interceptor';

@Injectable()
@Controller('device-assignments')
export class DeviceAssignmentController {
  constructor(
    @Inject('DeviceAssignmentServiceInterface')
    private readonly deviceAssignmentService: DeviceAssignmentServiceInterface,
  ) {}

  @PermissionCode(
    CREATE_DEVICE_ASSIGNMENT_PERMISSION.code,
    UPDATE_DEVICE_ASSIGNMENT_PERMISSION.code,
  )
  @UseInterceptors(PermissionInterceptor)
  @Post('')
  @ApiOperation({
    tags: ['Device Assignment'],
    summary: 'Tạo phân công thiết bị',
    description: 'Tạo phân công thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async create(
    @Body() payload: CreateDeviceAssignmentRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceAssignmentService.create(request);
  }

  @PermissionCode(DETAIL_DEVICE_ASSIGNMENT_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get('/:id')
  @ApiOperation({
    tags: ['Device Assignment'],
    summary: 'Chi tiết phân công thiết bị',
    description: 'Chi tiết phân công thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailDeviceAssignmentResponse,
  })
  async detail(@Param() payload: IdParamDto): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceAssignmentService.detail(request);
  }

  @PermissionCode(DETAIL_DEVICE_ASSIGNMENT_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get('/:code/scan')
  @ApiOperation({
    tags: ['Device Assignment'],
    summary: 'Scan phân công thiết bị',
    description: 'Scan phân công thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: Number,
  })
  async scan(@Param() payload: ScanDeviceRequest): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceAssignmentService.scan(request);
  }

  @PermissionCode(UPDATE_DEVICE_ASSIGNMENT_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Put('/:id')
  @ApiOperation({
    tags: ['Device Assignment'],
    summary: 'Chi tiết phân công thiết bị',
    description: 'Chi tiết phân công thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: Number,
  })
  async update(
    @Param() payload: IdParamDto,
    @Body() body: UpdateDeviceAssignmentRequestDto,
  ): Promise<any> {
    const { request, responseError } = { ...payload, ...body };

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceAssignmentService.update(request);
  }

  @PermissionCode(UPDATE_STATUS_DEVICE_ASSIGNMENT_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Put('/:id/confirmed')
  @ApiOperation({
    tags: ['Device Assignment'],
    summary: 'Xác nhận phân công thiết bị',
    description: 'Xác nhận phân công thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: Number,
  })
  async confirm(
    @Param() payload: UpdateStatusDeviceAssignmentRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.action = DEVICE_ASSIGNMENT_ACTION_CONFIRMED;
    return await this.deviceAssignmentService.changeStatus(request);
  }

  @PermissionCode(UPDATE_STATUS_DEVICE_ASSIGNMENT_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Put('/:id/rejected')
  @ApiOperation({
    tags: ['Device Assignment'],
    summary: 'Từ chối phân công thiết bị',
    description: 'Từ chối phân công thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: Number,
  })
  async reject(
    @Param() payload: UpdateStatusDeviceAssignmentRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.action = DEVICE_ASSIGNMENT_ACTION_REJECTED;
    return await this.deviceAssignmentService.changeStatus(request);
  }

  @PermissionCode(DELETE_DEVICE_ASSIGNMENT_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Device Assignment'],
    summary: 'Chi tiết phân công thiết bị',
    description: 'Chi tiết phân công thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: Number,
  })
  async delete(@Param() payload: IdParamDto): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceAssignmentService.delete(request);
  }

  @PermissionCode(LIST_DEVICE_ASSIGNMENT_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get('')
  @ApiOperation({
    tags: ['Device Assignment'],
    summary: 'Danh sách phân công thiết bị',
    description: 'Danh sách phân công thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListDeviceAssignmentResponseDto,
  })
  async list(@Query() payload: ListDeviceAssignmentQuery): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceAssignmentService.list(request);
  }
}
