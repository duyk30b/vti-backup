import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { ListDeviceAssignmentQuery } from '../dto/query/list-device-assignment.query';
import { CreateDeviceAssignmentRequestDto } from '../dto/request/create-device-assignment.request';
import { ScanDeviceRequest } from '../dto/request/scan-device.request';
import { UpdateDeviceAssignmentRequestDto } from '../dto/request/update-device-assignment.request';
import { UpdateStatusDeviceAssignmentRequestDto } from '../dto/request/update-status-device-assignment.request';

export interface DeviceAssignmentServiceInterface {
  create(
    request: CreateDeviceAssignmentRequestDto,
  ): Promise<ResponsePayload<any>>;
  list(request: ListDeviceAssignmentQuery): Promise<ResponsePayload<any>>;
  update(
    request: UpdateDeviceAssignmentRequestDto & IdParamDto,
  ): Promise<ResponsePayload<any>>;
  delete(request: IdParamDto): Promise<ResponsePayload<any>>;
  detail(request: IdParamDto): Promise<ResponsePayload<any>>;
  scan(request: ScanDeviceRequest): Promise<ResponsePayload<any>>;
  changeStatus(
    request: UpdateStatusDeviceAssignmentRequestDto,
  ): Promise<ResponsePayload<any>>;
  completedDeviceRequest(deviceRequestId: string): Promise<any>;
}
