import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { DeviceAssignment } from 'src/models/device-assignment/device-assignment.model';
import { ListDeviceAssignmentQuery } from '../dto/query/list-device-assignment.query';
import { CreateDeviceAssignmentRequestDto } from '../dto/request/create-device-assignment.request';
export interface DeviceAssignmentRepositoryInterface
  extends BaseInterfaceRepository<DeviceAssignment> {
  createDocument(
    request: CreateDeviceAssignmentRequestDto,
  ): Promise<DeviceAssignment>;
  list(request: ListDeviceAssignmentQuery): Promise<any>;
  listToExport(request: ListDeviceAssignmentQuery): Promise<any>;
}
