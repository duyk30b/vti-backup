import { HttpException, Injectable } from '@nestjs/common';
import * as FormData from 'form-data';
import { FileResource } from './file.constant';
import { UploadFileRequest } from './dto/upload-file.request';
import { FileServiceInterface } from './interface/file.service.interface';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { first } from 'lodash';
import { HttpService } from '@nestjs/axios';
import { InjectService } from '@nestcloud/service';
import { catchError, firstValueFrom, map, of, retry } from 'rxjs';
import { genericRetryStrategy } from '@utils/rxjs-util';

@Injectable()
export class FileService implements FileServiceInterface {
  private httpConfig;
  private endpoint;

  constructor(
    private httpClientService: HttpService,

    @InjectService()
    private readonly service: any,

    private readonly i18n: I18nRequestScopeService,
  ) {
    this.endpoint = '/api/v1/files';
    this.httpConfig = {
      scalingDuration: 1000,
      excludedStatusCodes: [409],
      callInternalService: true,
      serviceName: 'file-service',
    };
  }

  async generateUrlInternalService(
    serviceName: string,
    url: string,
  ): Promise<string> {
    const servers = this.service.getServiceServers(serviceName, {
      passing: true,
    });

    const server = servers[Math.floor(Math.random() * servers.length)];

    return `http://${server.address}:${server.port}${url}`;
  }

  async uploadFiles(files: any[], resource: string): Promise<any> {
    const form = new FormData();
    form.append('service', 'mms-service');
    form.append('resource', resource);
    files.forEach((file) => {
      form.append('files', Buffer.from(file.data), {
        filename: file.filename,
      });
    });

    const url = await this.generateUrlInternalService(
      this.httpConfig.serviceName,
      `${this.endpoint}/multiple-files`,
    );

    const result = await firstValueFrom(
      this.httpClientService
        .post(url, form, {
          ...form.getHeaders(),
        })
        .pipe(
          map((response) => response.data),
          retry(
            genericRetryStrategy({
              scalingDuration: 1000,
              excludedStatusCodes: [409],
            }),
          ),
          catchError((error) => of(error)),
        ),
    );
    if (result.statusCode === ResponseCodeEnum.SUCCESS) {
      return result.data;
    } else {
      throw new HttpException(result.message, result.statusCode);
    }
  }

  async uploadFile(file: any, resource: string): Promise<any> {
    const form = new FormData();
    form.append('service', 'mms-service');
    form.append('resource', resource);
    form.append('file', Buffer.from(file.data), {
      filename: file.filename,
    });

    const url = await this.generateUrlInternalService(
      this.httpConfig.serviceName,
      `${this.endpoint}/single-file`,
    );

    const result = await firstValueFrom(
      this.httpClientService
        .post(url, form, {
          ...form.getHeaders(),
        })
        .pipe(
          map((response) => response.data),
          retry(
            genericRetryStrategy({
              scalingDuration: 1000,
              excludedStatusCodes: [409],
            }),
          ),
          catchError((error) => of(error)),
        ),
    );
    return result.data;
  }

  async upload(request: UploadFileRequest): Promise<any> {
    const response = await this.uploadFile(
      first(request.file),
      FileResource.MMS,
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getFileInfoByIds(ids: string[]): Promise<any> {
    const url = await this.generateUrlInternalService(
      this.httpConfig.serviceName,
      `${this.endpoint}/info`,
    );

    const res = await firstValueFrom(
      this.httpClientService
        .get(url, {
          params: {
            ids: ids.join(','),
          },
        })
        .pipe(
          map((response) => response),
          retry(
            genericRetryStrategy({
              scalingDuration: 1000,
              excludedStatusCodes: [409],
            }),
          ),
          catchError((error) => of(error)),
        ),
    );
    if (res?.data?.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return res.data.data;
  }
}
