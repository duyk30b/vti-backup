import { UploadFileRequest } from '../dto/upload-file.request';

export interface FileServiceInterface {
  uploadFiles(files: any[], resource: string): Promise<any>;
  uploadFile(file: any, resource: string): Promise<any>;
  upload(request: UploadFileRequest): Promise<any>;
  getFileInfoByIds(ids: string[]): Promise<any>;
}
