import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsOptional } from 'class-validator';

export class UploadFileRequest extends BaseDto {
  @ApiProperty({
    type: String,
    format: 'binary',
  })
  @IsOptional()
  file: any;
}
