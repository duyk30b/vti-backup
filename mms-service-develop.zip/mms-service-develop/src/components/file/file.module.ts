import { HttpModule } from '@nestjs/axios';
import { Global, Module } from '@nestjs/common';
import { FileController } from './file.controller';
import { FileService } from './file.service';

@Global()
@Module({
  imports: [HttpModule],
  exports: [
    {
      provide: 'FileServiceInterface',
      useClass: FileService,
    },
  ],
  providers: [
    {
      provide: 'FileServiceInterface',
      useClass: FileService,
    },
  ],
  controllers: [FileController],
})
export class FileModule {}
