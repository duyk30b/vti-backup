import { Body, Controller, Inject, Injectable, Post } from '@nestjs/common';
import { ApiConsumes, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { UploadFileRequest } from './dto/upload-file.request';
import { FileServiceInterface } from './interface/file.service.interface';

@Injectable()
@Controller('files')
export class FileController {
  constructor(
    @Inject('FileServiceInterface')
    private readonly fileService: FileServiceInterface,
  ) {}

  @Post('')
  @ApiConsumes('multipart/form-data')
  @ApiOperation({
    tags: ['Files'],
    summary: 'Upload file',
    description: 'Upload file',
  })
  @ApiResponse({
    status: 200,
    description: 'Upload file',
    type: SuccessResponse,
  })
  async upload(@Body() payload: UploadFileRequest): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.fileService.upload(request);
  }
}
