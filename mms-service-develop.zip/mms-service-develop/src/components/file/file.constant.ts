export const FileResource = {
  MMS: 'MMS',
  DEVICE: 'DEVICE',
  ACCREDITATION: 'ACCREDITATION',
  INSTALLATION: 'INSTALLATION',
  CHECKLIST: 'CHECKLIST',
  MAINTENANCE_TEMPLATE: 'MAINTENANCE_TEMPLATE',
};

export const UPLOAD_FILE_ENPOINT = {
  MULTIPLE: 'files/multiple-files',
  SINGLE: 'files/single-file',
};
