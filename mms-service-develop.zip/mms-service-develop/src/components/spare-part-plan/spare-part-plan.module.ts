import { SparePartPlanRepository } from 'src/repository/spare-part-plan/spare-part-plan.repository';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { SparePartPlanSchema } from 'src/models/spare-part-plan/spare-part-plan.schema';
import { InventoryRepository } from 'src/repository/warehouse-inventories/inventory.repository';
import { SparePartPlanController } from './spare-part-plan.controller';
import { SparePartPlanService } from './spare-part-plan.service';
import { MaintenancePlanRepository } from 'src/repository/maintenance-plan/maintenance-plan.repository';
import { MaintenancePlanSchema } from 'src/models/maintenance-plan/maintenance-plan.schema';
import { InventorySchema } from 'src/models/warehouse-inventories/inventory.schema';
import { ItemModule } from '@components/item/item.module';
import { SettingSignatureSchema } from 'src/models/setting-signature/setting-signature.schema';
import { SettingSignatureRepository } from 'src/repository/setting/setting-signature.repository';
@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'SparePartPlan', schema: SparePartPlanSchema },
      { name: 'MaintenancePlan', schema: MaintenancePlanSchema },
      { name: 'Inventory', schema: InventorySchema },
      { name: 'SettingSignature', schema: SettingSignatureSchema },
    ]),
    ItemModule,
  ],
  controllers: [SparePartPlanController],
  providers: [
    {
      provide: 'SparePartPlanRepositoryInterface',
      useClass: SparePartPlanRepository,
    },
    {
      provide: 'SparePartPlanServiceInterface',
      useClass: SparePartPlanService,
    },
    {
      provide: 'InventoryRepositoryInterface',
      useClass: InventoryRepository,
    },
    {
      provide: 'MaintenancePlanRepositoryInterface',
      useClass: MaintenancePlanRepository,
    },
    {
      provide: 'SettingSignatureRepositoryInterface',
      useClass: SettingSignatureRepository,
    },
  ],
  exports: [
    MongooseModule,
    {
      provide: 'SparePartPlanRepositoryInterface',
      useClass: SparePartPlanRepository,
    },
    {
      provide: 'SparePartPlanServiceInterface',
      useClass: SparePartPlanService,
    },
  ],
})
export class SparePartPlanModule {}
