import { InventoryRepositoryInterface } from '@components/warehouse/interface/inventory.repository.interface';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { groupBy, keyBy, map, sortBy, sumBy, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import {
  SPARE_PART_PLAN_CONST,
  SPARE_PART_PLAN_STATUS_CAN_DELETE,
  SPARE_PART_PLAN_STATUS_CAN_UPDATE,
  SPARE_PART_PLAN_STATUS_ENUM,
} from './spare-part-plan.constant';
import { CreateSparePartPlanRequest } from './dto/request/create-spare-part-plan.request';
import { DetailSparePartPlanRequest } from './dto/request/detail-spare-part-plan.request';
import { GetSparePartPlanQuery } from './dto/request/get-list-spare-part-plan.query';
import { UpdateSparePartPlanBodyDto } from './dto/request/update-spare-part-plan.request';
import { DetailSparePartPlanResponse } from './dto/response/detail-spare-part-plan.response';
import { SparePartPlanServiceInterface } from './interface/spare-part-plan.service.interface';
import { SparePartPlanRepositoryInterface } from './interface/spare-part-plan.repository.interface';
import { GetListSparePartPlanResponse } from './dto/response/list-spare-part-plan.response';
import { MaintenancePlanRepositoryInterface } from '@components/maintenance-plan/interface/maintenance-plan.repository.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { EXCEL_STYLE, SHEET } from '@components/export/export.constant';
import { Alignment, Borders, Font, Workbook } from 'exceljs';
import { mul, plus } from '@utils/helper';
import * as moment from 'moment';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { returnStockQuantity } from 'src/helper/code.helper';
import {
  addExportSignature,
  convertWithCommas,
} from 'src/helper/export.helper';
import { SETTING_SIGNATURE_TYPE_ENUM } from '@components/setting/setting.constant';
import { SettingSignatureRepositoryInterface } from '@components/setting/interface/setting-signature.repository.interface';

@Injectable()
export class SparePartPlanService implements SparePartPlanServiceInterface {
  constructor(
    @Inject('SparePartPlanRepositoryInterface')
    private readonly sparePartPlanRepository: SparePartPlanRepositoryInterface,

    @Inject('InventoryRepositoryInterface')
    private readonly inventoryRepository: InventoryRepositoryInterface,

    @Inject('MaintenancePlanRepositoryInterface')
    private readonly maintenancePlanRepository: MaintenancePlanRepositoryInterface,

    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    @Inject('SettingSignatureRepositoryInterface')
    private readonly settingSignatureRepository: SettingSignatureRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(
    request: CreateSparePartPlanRequest,
  ): Promise<ResponsePayload<any>> {
    const { maintenancePlanId } = request;
    try {
      request.code =
        await this.sparePartPlanRepository.generateNextCodeWithYear(
          SPARE_PART_PLAN_CONST.CODE.PREFIX,
        );

      if (maintenancePlanId) {
        const maintenancePlan =
          await this.maintenancePlanRepository.findOneById(maintenancePlanId);
        if (!maintenancePlan)
          return new ApiError(
            ResponseCodeEnum.NOT_FOUND,
            await this.i18n.translate('error.NOT_FOUND'),
          ).toResponse();
      }

      //@ToDo: validate supplies exists
      const assetProjectionEntity =
        this.sparePartPlanRepository.createEntity(request);
      const dataSave = await assetProjectionEntity.save();
      const dataReturn = plainToInstance(BasicResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.error(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async update(
    request: UpdateSparePartPlanBodyDto & IdParamDto,
  ): Promise<ResponsePayload<any>> {
    try {
      const { id, maintenancePlanId } = request;

      const condition = { _id: id } as any;

      let assetProjectionEntity =
        await this.sparePartPlanRepository.findOneByCondition(condition);

      if (!assetProjectionEntity) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      if (
        !SPARE_PART_PLAN_STATUS_CAN_UPDATE.includes(
          assetProjectionEntity.status,
        )
      ) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.STATUS_PLAN_INVALID'),
        ).toResponse();
      }

      if (maintenancePlanId) {
        const maintenancePlan =
          await this.maintenancePlanRepository.findOneById(maintenancePlanId);
        if (!maintenancePlan)
          return new ApiError(
            ResponseCodeEnum.NOT_FOUND,
            await this.i18n.translate('error.NOT_FOUND'),
          ).toResponse();
      }

      //@ToDo: validate supplies exists

      assetProjectionEntity = await this.sparePartPlanRepository.updateEntity(
        assetProjectionEntity,
        request,
      );

      await this.sparePartPlanRepository.findByIdAndUpdate(
        request.id,
        assetProjectionEntity,
      );

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async detail(
    request: DetailSparePartPlanRequest,
  ): Promise<ResponsePayload<DetailSparePartPlanResponse | any>> {
    const assetProjection = await this.sparePartPlanRepository.detail({
      ...request.permissionCondition,
      deletedAt: null,
      _id: request.id,
    });

    if (!assetProjection) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.AREA_NOT_FOUND'))
        .build();
    }
    const unitIds = map(assetProjection.supplies, (e) => e['supply']?.unitId);
    const units = await this.itemService.getListUnit([
      {
        column: 'ids',
        text: uniq(unitIds).toString(),
      },
    ]);
    const unitMap = keyBy(units, 'id');
    //trai phang vtpt
    assetProjection.supplies.forEach((detailSupply) => {
      detailSupply.supplyType = detailSupply.supply.supplyType;
      detailSupply.supplyGroup = detailSupply.supply.supplyGroup;
      detailSupply.unit = unitMap[detailSupply.supply?.unitId];
    });

    //lay so luong ton kho cua tai san
    let assetIds = [];
    assetIds = assetProjection.supplies.map(
      (detailSupply) => detailSupply.supplyId,
    );

    const factory = await this.userService.getFactoryById(
      assetProjection.factoryId,
    );
    assetProjection.factory = factory;

    const warehouses = await this.warehouseRepository.findAllByCondition({
      factoryId: assetProjection.factoryId,
    });
    const warehouseIds = warehouses.map((warehouse) => warehouse._id);
    const inventories =
      await this.inventoryRepository.getInventoryByWarehousesAndAssets({
        warehouseIds,
        assetIds,
      });
    const inventoryMap = keyBy(inventories, '_id.assetId');

    assetProjection.supplies.forEach((detailSupply) => {
      const minStockQuantity =
        inventoryMap[detailSupply.supplyId]?.minStockQuantity || 0;
      const stockQuantity =
        inventoryMap[detailSupply.supplyId]?.stockQuantity || 0;
      const extraProposalQuantity = returnStockQuantity(
        detailSupply.proposalQuantity - stockQuantity + minStockQuantity,
      );

      detailSupply.stockQuantity = stockQuantity;
      detailSupply.minStockQuantity = minStockQuantity;
      detailSupply.extraProposalQuantity = extraProposalQuantity;
      detailSupply.intoMoney = mul(extraProposalQuantity, detailSupply.price);
    });

    const response = plainToInstance(
      DetailSparePartPlanResponse,
      assetProjection,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async list(request: GetSparePartPlanQuery): Promise<ResponsePayload<any>> {
    const { data, count } = await this.sparePartPlanRepository.list(request);

    const dataReturn = plainToInstance(GetListSparePartPlanResponse, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async confirm(request: IdParamDto): Promise<ResponsePayload<any>> {
    const assetProjection =
      await this.sparePartPlanRepository.findOneByCondition({
        ...request.permissionCondition,
        _id: request.id,
      });

    if (!assetProjection) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (assetProjection.status !== SPARE_PART_PLAN_STATUS_ENUM.AWAITING) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.ASSET_PROJECTION_STATUS_INVALID'),
      ).toResponse();
    }

    await this.sparePartPlanRepository.findByIdAndUpdate(request.id, {
      $set: {
        status: SPARE_PART_PLAN_STATUS_ENUM.CONFIRMED,
      },
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async delete(request: IdParamDto): Promise<any> {
    const assetProjection =
      await this.sparePartPlanRepository.findOneByCondition({
        ...request.permissionCondition,
        _id: request.id,
      });

    if (!assetProjection) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!SPARE_PART_PLAN_STATUS_CAN_DELETE.includes(assetProjection.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.ASSET_PROJECTION_STATUS_INVALID'),
        )
        .build();
    }
    try {
      await this.sparePartPlanRepository.softDelete(request.id);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async reject(request: IdParamDto): Promise<ResponsePayload<any>> {
    const assetProjection =
      await this.sparePartPlanRepository.findOneByCondition({
        ...request.permissionCondition,
        _id: request.id,
      });

    if (!assetProjection) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (assetProjection.status !== SPARE_PART_PLAN_STATUS_ENUM.AWAITING) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.ASSET_PROJECTION_STATUS_INVALID'),
      ).toResponse();
    }

    await this.sparePartPlanRepository.findByIdAndUpdate(request.id, {
      $set: {
        status: SPARE_PART_PLAN_STATUS_ENUM.REJECTED,
      },
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async export(request: IdParamDto): Promise<any> {
    const { data } = await this.detail(request);
    if (!data) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const sparePartPlan = await this.i18n.translate('export.sparePartPlan');
    const header = [
      {
        key: 'stt',
        width: 5,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: sparePartPlan.stt,
      },
      {
        key: 'code',
        width: 15,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: sparePartPlan.code,
      },
      {
        key: 'name',
        width: 25,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: sparePartPlan.name,
      },
      {
        key: 'unit',
        width: 10,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: sparePartPlan.unit,
      },
      {
        key: 'proposalQuantity',
        width: 10,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: sparePartPlan.proposalQuantity,
      },
      {
        key: 'stockQuantity',
        width: 10,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: sparePartPlan.stockQuantity,
      },
      {
        key: 'extraProposalQuantity',
        width: 10,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: sparePartPlan.extraProposalQuantity,
      },
      {
        key: 'price',
        width: 15,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: sparePartPlan.price,
      },
      {
        key: 'intoMoney',
        width: 15,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: sparePartPlan.intoMoney,
      },
      {
        key: 'note',
        width: 15,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: sparePartPlan.note,
      },
    ];

    // data main of table
    const items = [];
    const supplies = sortBy(data.supplies, 'supplyType.name');
    let total = 0;
    let preSupplyType = '';
    let countSupplyType = 1;
    const supplyGroupByType = groupBy(supplies, 'supplyType.name');
    supplies?.forEach((el, index) => {
      if (preSupplyType !== el.supplyType.name) {
        preSupplyType = el.supplyType.name;
        items.push({
          stt: `${countSupplyType++}. ${preSupplyType}`,
          intoMoney: convertWithCommas(
            sumBy(supplyGroupByType[preSupplyType], (e) => e.intoMoney ?? 0) ??
              0,
          ),
        });
      }
      total += el.intoMoney ?? 0;
      items.push({
        stt: plus(index, 1),
        code: el.supply.code ?? '',
        name: el.supply.name ?? '',
        unit: el.unit?.name ?? '',
        proposalQuantity: el.proposalQuantity ?? '',
        stockQuantity: el.stockQuantity ?? '',
        extraProposalQuantity: el.extraProposalQuantity ?? '',
        price: convertWithCommas(el.price ?? 0),
        intoMoney: convertWithCommas(el.intoMoney ?? 0),
        note: el.description ?? '',
      });
    });

    // set header
    const workbook = new Workbook();
    const countSheet = SHEET.START_SHEET;
    const title = sparePartPlan.title;

    let worksheet = workbook.getWorksheet(SHEET.NAME + countSheet);
    let currentRow = null;
    let currentRowMerge = null;
    worksheet = workbook.addWorksheet(SHEET.NAME + countSheet);
    worksheet.columns = header;
    const headerData = [
      { stt: sparePartPlan.company, intoMoney: sparePartPlan.form },
      {
        stt: `${sparePartPlan.factory} ${data.factory?.name}`.toLocaleUpperCase(),
        intoMoney: sparePartPlan.dateFormat,
      },
    ];
    // write header to excel
    headerData.forEach((element) => {
      currentRow = worksheet.addRow(element);
      currentRow.height = EXCEL_STYLE.TITLE_HEIGHT;
      currentRow.eachCell(function (cell, col) {
        cell.font = <Font>EXCEL_STYLE.DEFAULT_FONT;
        if (col === 1) {
          currentRowMerge = cell.row;
          cell.font = <Font>EXCEL_STYLE.HEADER_FONT;
          worksheet.mergeCellsWithoutStyle(
            currentRowMerge,
            1,
            currentRowMerge,
            4,
          );
        }
        if (col === 9 || (col === 1 && +cell.row === 2)) {
          cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
        }
      });
    });
    worksheet.mergeCells(2, 9, 2, 10);
    // write title to excel
    const titleRow = worksheet.getRow(3);
    titleRow.getCell(1).value = title;
    worksheet.mergeCells(3, 1, 3, 10);
    titleRow.font = <Font>EXCEL_STYLE.HEADER_FONT;
    titleRow.height = EXCEL_STYLE.TITLE_HEIGHT;
    titleRow.getCell(1).alignment = <Partial<Alignment>>(
      EXCEL_STYLE.ALIGN_CENTER
    );
    const titleRowTwo = worksheet.getRow(4);
    titleRowTwo.getCell(1).value = `${sparePartPlan.month} ${moment(
      data.fromDate,
    ).month()}-${moment(data.fromDate).year()}`;
    worksheet.mergeCells(4, 1, 4, 10);
    titleRowTwo.font = <Font>EXCEL_STYLE.HEADER_FONT;
    titleRowTwo.height = EXCEL_STYLE.TITLE_HEIGHT;
    titleRowTwo.getCell(1).alignment = <Partial<Alignment>>(
      EXCEL_STYLE.ALIGN_CENTER
    );

    const headerRowOne = worksheet.getRow(7);
    headerRowOne.values = header.map((header) => header.title);
    headerRowOne.eachCell(function (cell) {
      cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
      cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
    });
    // create table data
    items.forEach((element) => {
      if (typeof element.stt !== 'number') {
        const curRow = +worksheet.addRow(element).getCell(1).row;
        worksheet.mergeCells(curRow, 1, curRow, 8);
        worksheet.getRow(curRow).eachCell(function (cell) {
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
        });
      } else {
        worksheet.addRow(element).eachCell(function (cell) {
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          cell.font = <Font>EXCEL_STYLE.DEFAULT_FONT;
        });
      }
    });
    // total money
    const totalRow = +worksheet
      .addRow({
        stt: sparePartPlan.moneyTotal,
        intoMoney: convertWithCommas(total),
      })
      .getCell(1).row;
    worksheet.mergeCells(totalRow, 1, totalRow, 8);
    worksheet.getRow(totalRow).eachCell(function (cell) {
      cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
      cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
    });
    // table for checklist
    worksheet.addRows([[], []]);
    const checklistTitleRow = +worksheet
      .addRow([sparePartPlan.checklistTitle])
      .getCell(1).row;
    worksheet.mergeCells(checklistTitleRow, 1, checklistTitleRow, 4);
    const checklistData = Object.keys(sparePartPlan.checklist).map(
      (e: string) => ({
        stt: sparePartPlan.checklist[e],
        intoMoney: convertWithCommas(data.checklist[e]),
      }),
    );
    checklistData.forEach((element) => {
      const curRow = +worksheet.addRow(element).getCell(1).row;
      worksheet.mergeCells(curRow, 1, curRow, 8);
      worksheet.getRow(curRow).eachCell(function (cell) {
        cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
      });
    });
    // add signatures
    const signatures = (
      await this.settingSignatureRepository.findOneByCondition({
        type: SETTING_SIGNATURE_TYPE_ENUM.SPARE_PART_PLAN,
      })
    )?.details;
    if (signatures?.length > 0) {
      addExportSignature(worksheet, signatures, header.length);
    }
    if (workbook?.xlsx) {
      await workbook.xlsx.writeFile('excel.xlsx');
      const file = await workbook.xlsx.writeBuffer();
      return new ResponseBuilder(file)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    }
    return new ResponseBuilder()
      .withMessage(await this.i18n.translate('error.NOT_FOUND'))
      .withCode(ResponseCodeEnum.NOT_FOUND)
      .build();
  }
}
