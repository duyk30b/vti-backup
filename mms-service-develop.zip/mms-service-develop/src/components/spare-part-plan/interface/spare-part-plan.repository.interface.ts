import { UpdateSparePartPlanBodyDto } from '../dto/request/update-spare-part-plan.request';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { SparePartPlan } from 'src/models/spare-part-plan/spare-part-plan.model';
import { CreateSparePartPlanRequest } from '../dto/request/create-spare-part-plan.request';
import { GetSparePartPlanQuery } from '../dto/request/get-list-spare-part-plan.query';

export interface SparePartPlanRepositoryInterface
  extends BaseAbstractRepository<SparePartPlan> {
  createEntity(request: CreateSparePartPlanRequest): SparePartPlan;
  updateEntity(
    entity: SparePartPlan,
    request: UpdateSparePartPlanBodyDto,
  ): SparePartPlan;
  list(request: GetSparePartPlanQuery): Promise<any>;
  detail(condition: any): Promise<any>;
}
