import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreateSparePartPlanRequest } from '../dto/request/create-spare-part-plan.request';
import { DetailSparePartPlanRequest } from '../dto/request/detail-spare-part-plan.request';
import { GetSparePartPlanQuery } from '../dto/request/get-list-spare-part-plan.query';
import { UpdateSparePartPlanBodyDto } from '../dto/request/update-spare-part-plan.request';

export interface SparePartPlanServiceInterface {
  create(request: CreateSparePartPlanRequest): Promise<ResponsePayload<any>>;
  update(request: UpdateSparePartPlanBodyDto): Promise<ResponsePayload<any>>;
  detail(request: DetailSparePartPlanRequest): Promise<ResponsePayload<any>>;
  list(request: GetSparePartPlanQuery): Promise<ResponsePayload<any>>;
  confirm(request: IdParamDto): Promise<any>;
  delete(request: IdParamDto): Promise<any>;
  reject(request: IdParamDto): Promise<ResponsePayload<any>>;
  export(request: IdParamDto): Promise<ResponsePayload<any>>;
}
