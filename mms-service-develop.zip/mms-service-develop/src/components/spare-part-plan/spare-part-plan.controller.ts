import { PermissionCode } from '@core/decorator/get-code.decorator';
import { PermissionInterceptor } from '@core/interceptors/permission.interceptor';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Injectable,
  Param,
  Post,
  Put,
  Query,
  UseInterceptors,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import {
  CREATE_PLAN_PERMISSION,
  DELETE_PLAN_PERMISSION,
  DETAIL_PLAN_PERMISSION,
  EXPORT_PLAN_PERMISSION,
  LIST_PLAN_PERMISSION,
  UPDATE_PLAN_PERMISSION,
  UPDATE_STATUS_PLAN_PERMISSION,
} from '@utils/permissions/plan';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateSparePartPlanRequest } from './dto/request/create-spare-part-plan.request';
import { DetailSparePartPlanRequest } from './dto/request/detail-spare-part-plan.request';
import { GetSparePartPlanQuery } from './dto/request/get-list-spare-part-plan.query';
import { UpdateSparePartPlanBodyDto } from './dto/request/update-spare-part-plan.request';
import { DetailSparePartPlanResponse } from './dto/response/detail-spare-part-plan.response';
import { ListSparePartPlanResponse } from './dto/response/list-spare-part-plan.response';
import { SparePartPlanServiceInterface } from './interface/spare-part-plan.service.interface';

@Injectable()
@Controller('/spare-part-plan')
export class SparePartPlanController {
  constructor(
    @Inject('SparePartPlanServiceInterface')
    private readonly sparePartPlanService: SparePartPlanServiceInterface,
  ) {}

  @PermissionCode(CREATE_PLAN_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Post('')
  @ApiOperation({
    tags: ['Spare Part Plan'],
    summary: 'Định nghĩa dự trù tài sản',
    description: 'Định nghĩa dự trù tài sản',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async create(@Body() payload: CreateSparePartPlanRequest): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.sparePartPlanService.create(request);
  }

  @PermissionCode(DETAIL_PLAN_PERMISSION.code, UPDATE_PLAN_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get('/:id')
  @ApiOperation({
    tags: ['Spare Part Plan'],
    summary: 'Detail Asset Projection',
    description: 'Detail Asset Projection',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailSparePartPlanResponse,
  })
  async detail(@Param() param: DetailSparePartPlanRequest): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.sparePartPlanService.detail(request);
  }

  @PermissionCode(UPDATE_PLAN_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Put('/:id')
  @ApiOperation({
    tags: ['Spare Part Plan'],
    summary: 'Update Asset Projection',
    description: 'Update an existing asset projection',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  async update(
    @Param() param: IdParamDto,
    @Body() payload: UpdateSparePartPlanBodyDto,
  ): Promise<any> {
    const { request: requestParam, responseError: responseParamError } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.sparePartPlanService.update({
      id: requestParam.id,
      ...request,
    });
  }

  @PermissionCode(LIST_PLAN_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get('/')
  @ApiOperation({
    tags: ['Spare Part Plan'],
    summary: 'List Asset Projection',
    description: 'List Asset Projection',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListSparePartPlanResponse,
  })
  async list(@Query() query: GetSparePartPlanQuery): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.sparePartPlanService.list(request);
  }

  @PermissionCode(DELETE_PLAN_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @ApiOperation({
    tags: ['Spare Part Plan'],
    summary: 'Xóa dự trù tài sản',
    description: 'Xóa dự trù tài sản',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  @Delete('/:id')
  async delete(@Param() payload: IdParamDto): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.sparePartPlanService.delete(request);
  }

  @PermissionCode(UPDATE_STATUS_PLAN_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Spare Part Plan'],
    summary: 'Xác nhận dự trù tài sản',
    description: 'Xác nhận dự trù tài sản',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async confirm(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.sparePartPlanService.confirm(request);
  }

  @PermissionCode(UPDATE_STATUS_PLAN_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Spare Part Plan'],
    summary: '',
    description: 'Từ chối dự trù tài sản',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: SuccessResponse,
  })
  async reject(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.sparePartPlanService.reject(request);
  }

  @PermissionCode(EXPORT_PLAN_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get('/:id/export')
  @ApiOperation({
    tags: ['Spare Part Plan'],
    summary: 'Export Asset Projection',
    description: 'Export Asset Projection',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async export(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.sparePartPlanService.export(request);
  }
}
