import { CODE_REGEX } from '@constant/common';

export const SPARE_PART_PLAN_CONST = {
  DESCRIPTION: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
  CODE: {
    MIN_LENGTH: 6,
    MAX_LENGTH: 20,
    COLUMN: 'code',
    REGEX: CODE_REGEX,
    PREFIX: 'KHDT',
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  PROPOSAL_QUANTITY: {
    MIN: 1,
  },
  EXTRA_PROPOSAL_QUANTITY: {
    MIN: 0,
  },
  PRICE: {
    MIN: 0,
  },
};

export enum SPARE_PART_PLAN_STATUS_ENUM {
  AWAITING,
  CONFIRMED,
  REJECTED,
}

export const SPARE_PART_PLAN_STATUS_CAN_DELETE = [
  SPARE_PART_PLAN_STATUS_ENUM.AWAITING,
];

export const SPARE_PART_PLAN_STATUS_CAN_UPDATE = [
  SPARE_PART_PLAN_STATUS_ENUM.AWAITING,
];
