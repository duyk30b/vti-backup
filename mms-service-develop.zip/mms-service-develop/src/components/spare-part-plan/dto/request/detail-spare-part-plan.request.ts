import { IdParamDto } from '@utils/dto/request/param-id.request.dto';

export class DetailSparePartPlanRequest extends IdParamDto {}
