import { CreateSparePartPlanRequest } from './create-spare-part-plan.request';

export class UpdateSparePartPlanBodyDto extends CreateSparePartPlanRequest {}
