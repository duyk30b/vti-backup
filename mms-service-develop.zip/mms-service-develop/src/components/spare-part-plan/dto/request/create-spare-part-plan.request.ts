import { SPARE_PART_PLAN_CONST } from '@components/spare-part-plan/spare-part-plan.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsDateString,
  IsInt,
  IsMongoId,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';
import { IsNotBlank } from 'src/validator/is-not-blank.validator';

export class SupplyPlan {
  @ApiProperty({ description: 'Số lượng đề xuất' })
  @IsNotEmpty()
  @IsInt()
  @Min(SPARE_PART_PLAN_CONST.PROPOSAL_QUANTITY.MIN)
  proposalQuantity: number;

  @ApiProperty({ description: 'Số lượng đề xuất thêm' })
  @IsOptional()
  @IsInt()
  @Min(SPARE_PART_PLAN_CONST.EXTRA_PROPOSAL_QUANTITY.MIN)
  extraProposalQuantity: number;

  @ApiProperty({ description: 'Giá' })
  @IsNotEmpty()
  @IsNumber()
  @Min(SPARE_PART_PLAN_CONST.PRICE.MIN)
  price: number;

  @ApiProperty({ description: 'ghi chú' })
  @IsOptional()
  @IsString()
  @MaxLength(SPARE_PART_PLAN_CONST.DESCRIPTION.MAX_LENGTH)
  description: string;

  @ApiProperty({ description: 'Id vật tư phụ tùng' })
  @IsNotEmpty()
  @IsMongoId()
  supplyId: string;
}

export class Checklist {
  @ApiProperty({ description: 'Doanh thu kế hoạch' })
  @IsNotEmpty()
  @IsNumber()
  @Min(SPARE_PART_PLAN_CONST.PRICE.MIN)
  revenue: number;

  @ApiProperty({ description: 'Tỷ giá' })
  @IsNotEmpty()
  @IsNumber()
  @Min(SPARE_PART_PLAN_CONST.PRICE.MIN)
  rate: number;

  @ApiProperty({ description: 'P.QLTBM đề xuất duyệt tổng chi phí dự trù' })
  @IsNotEmpty()
  @IsNumber()
  @Min(SPARE_PART_PLAN_CONST.PRICE.MIN)
  totalCostConfirmed: number;

  @ApiProperty({
    description: 'P.QLTBM đề xuất duyệt tổng chi phí dự trù khác',
  })
  @IsNotEmpty()
  @IsNumber()
  @Min(SPARE_PART_PLAN_CONST.PRICE.MIN)
  otherTotalCostConfirmed: number;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  @Min(SPARE_PART_PLAN_CONST.PRICE.MIN)
  revenueVnd: number;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  @Min(SPARE_PART_PLAN_CONST.PRICE.MIN)
  totalCostSparePart: number;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  @Min(SPARE_PART_PLAN_CONST.PRICE.MIN)
  totalCostSparePartPerRevenue: number;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  @Min(SPARE_PART_PLAN_CONST.PRICE.MIN)
  totalCostOther: number;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  @Min(SPARE_PART_PLAN_CONST.PRICE.MIN)
  totalCostOtherPerRevenue: number;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  @Min(SPARE_PART_PLAN_CONST.PRICE.MIN)
  totalCostSuggest: number;
}

export class CreateSparePartPlanRequest extends BaseDto {
  code: string;

  @ApiProperty()
  @MaxLength(SPARE_PART_PLAN_CONST.NAME.MAX_LENGTH)
  @IsNotBlank()
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  fromDate: Date;

  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  toDate: Date;

  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  maintenancePlanId: string;

  @ApiProperty({ type: SupplyPlan, isArray: true })
  @Type(() => SupplyPlan)
  @IsNotEmpty()
  @IsArray()
  @ValidateNested({ each: true })
  supplies: SupplyPlan[];

  @ApiProperty({ type: Checklist })
  @Type(() => Checklist)
  @IsNotEmpty()
  checklist: Checklist;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  factoryId: number;
}
