import { SupplyTypeDto } from 'src/components/supply/dto/response/get-all-supply.response.dto';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { Expose, Type } from 'class-transformer';

export class SupplyPlan {
  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Expose()
  supplyGroup: BasicResponseDto;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Type(() => BasicSqlDocumentResponse)
  @Expose()
  unit: BasicSqlDocumentResponse;

  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Expose()
  supply: BasicResponseDto;

  @ApiProperty({ type: SupplyTypeDto })
  @Type(() => SupplyTypeDto)
  @Expose()
  supplyType: SupplyTypeDto;

  @ApiProperty()
  @Expose()
  proposalQuantity: number;

  @ApiProperty()
  @Expose()
  stockQuantity: number;

  @ApiProperty()
  @Expose()
  minStockQuantity: number;

  @ApiProperty()
  @Expose()
  extraProposalQuantity: number;

  @ApiProperty()
  @Expose()
  price: number;

  @ApiProperty()
  @Expose()
  intoMoney: number;

  @ApiProperty()
  @Expose()
  description: string;
}

export class Checklist {
  @ApiProperty()
  @Expose()
  revenue: number;

  @ApiProperty()
  @Expose()
  rate: number;

  @ApiProperty()
  @Expose()
  revenueVnd: number;

  @ApiProperty()
  @Expose()
  totalCostSparePart: number;

  @ApiProperty()
  @Expose()
  totalCostSparePartPerRevenue: number;

  @ApiProperty()
  @Expose()
  totalCostConfirmed: number;

  @ApiProperty()
  @Expose()
  totalCostOther: number;

  @ApiProperty()
  @Expose()
  totalCostOtherPerRevenue: number;

  @ApiProperty()
  @Expose()
  otherTotalCostConfirmed: number;

  @ApiProperty()
  @Expose()
  totalCostSuggest: number;
}

export class DetailSparePartPlanResponse extends BasicResponseDto {
  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  maintenancePlan: BasicResponseDto;

  @ApiProperty()
  @Expose()
  fromDate: Date;

  @ApiProperty()
  @Expose()
  toDate: Date;

  @ApiProperty()
  @Expose()
  status: Date;

  @ApiProperty({ isArray: true, type: SupplyPlan })
  @Type(() => SupplyPlan)
  @Expose()
  supplies: SupplyPlan[];

  @ApiProperty({ type: Checklist })
  @Expose()
  @Type(() => Checklist)
  checklist: Checklist;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Expose()
  @Type(() => BasicSqlDocumentResponse)
  factory: BasicSqlDocumentResponse;
}
