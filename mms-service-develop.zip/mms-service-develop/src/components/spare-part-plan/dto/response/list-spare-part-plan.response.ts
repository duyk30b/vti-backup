import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Transform, Type } from 'class-transformer';

export class GetListSparePartPlanResponse extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  fromDate: Date;

  @ApiProperty()
  @Expose()
  toDate: Date;

  @ApiProperty()
  @Expose()
  @Transform(({ obj }) => obj.checklist.totalCostSuggest || 0)
  totalCost: number;

  @ApiProperty()
  @Expose()
  totalCostConfirmed: number;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  status: number;
}

export class ListSparePartPlanResponse extends PaginationResponse {
  @ApiProperty({ type: GetListSparePartPlanResponse, isArray: true })
  @Expose()
  @Type(() => GetListSparePartPlanResponse)
  items: GetListSparePartPlanResponse[];
}
