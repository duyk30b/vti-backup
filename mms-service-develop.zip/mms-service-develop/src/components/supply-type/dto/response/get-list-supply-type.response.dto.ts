import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';
import { GetDetailSupplyResponseDto } from './get-detail-supply-type.response.dto';

export class ListTypeSupplyResponseDto extends PaginationResponse {
  @ApiProperty({ type: GetDetailSupplyResponseDto, isArray: true })
  @Expose()
  @Type(() => GetDetailSupplyResponseDto)
  items: GetDetailSupplyResponseDto[];
}
