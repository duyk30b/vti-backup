import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { plainToInstance } from 'class-transformer';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { SupplyTypeServiceInterface } from './interface/supply-type.service.interface';
import { SupplyTypeRepositoryInterface } from './interface/supply-type.repository.interface';
import { GetListSupplyTypeRequestDto } from './dto/request/get-list-supply-type.request.dto';
import { GetDetailSupplyResponseDto } from '@components/supply/dto/response/get-detail-supply.response.dto';

@Injectable()
export class SupplyTypeService implements SupplyTypeServiceInterface {
  constructor(
    @Inject('SupplyTypeRepositoryInterface')
    private readonly supplyTypeRepository: SupplyTypeRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async getList(request: GetListSupplyTypeRequestDto): Promise<any> {
    const { result, count } = await this.supplyTypeRepository.getList(request);
    const dataReturn = plainToInstance(GetDetailSupplyResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PaginationResponse>({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
