export enum SUPPLY_STATUS_CONSTANT {
  AWAITING,
  CONFIRMED,
  COMPLETED,
}
export const STATUS_TO_DELETE_OR_UPDATE_SUPPLY = [
  SUPPLY_STATUS_CONSTANT.AWAITING,
];

export enum SUPPLY_TYPE_ENUM {
  SUPPLY, // vật tư
  ACCESSORY, // phụ tùng
  TOOLS, // công cụ dụng cụ
  STATIONERY, // văn phòng phẩm
}

export enum SUPPLY_TYPE_TEXT_ENUM {
  SUPPLY = 'vật tư',
  ACCESSORY = 'phụ tùng',
  TOOLS = 'công cụ dụng cụ',
  STATIONERY = 'văn phòng phẩm',
}

export const SUPPLY_TYPE_CONST = {
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  TYPE: { ENUM: SUPPLY_TYPE_ENUM },
};
