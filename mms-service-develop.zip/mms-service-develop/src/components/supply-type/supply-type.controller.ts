import { Controller, Injectable, Get, Inject, Query } from '@nestjs/common';
import { SupplyTypeServiceInterface } from './interface/supply-type.service.interface';
import { isEmpty } from 'lodash';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { ListTypeSupplyResponseDto } from './dto/response/get-list-supply-type.response.dto';
import { GetListSupplyTypeRequestDto } from './dto/request/get-list-supply-type.request.dto';

@Injectable()
@Controller('supply-types')
export class SupplyTypeController {
  constructor(
    @Inject('SupplyTypeServiceInterface')
    private readonly supplyTypeService: SupplyTypeServiceInterface,
  ) {}

  @Get('/')
  @ApiOperation({
    tags: ['Supply'],
    summary: 'List Supply',
    description: 'List Supply',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListTypeSupplyResponseDto,
  })
  async getList(@Query() payload: GetListSupplyTypeRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.supplyTypeService.getList(request);
  }
}
