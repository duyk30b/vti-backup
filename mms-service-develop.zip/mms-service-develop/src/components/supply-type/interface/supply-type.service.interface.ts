import { GetListSupplyRequestDto } from '@components/supply/dto/request/get-list-supply.request.dto';

export interface SupplyTypeServiceInterface {
  getList(request: GetListSupplyRequestDto): Promise<any>;
}
