import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { SupplyType } from 'src/models/supply-type/supply-type.model';
import { GetListSupplyTypeRequestDto } from '../dto/request/get-list-supply-type.request.dto';

export interface SupplyTypeRepositoryInterface
  extends BaseInterfaceRepository<SupplyType> {
  getList(request: GetListSupplyTypeRequestDto): Promise<any>;
}
