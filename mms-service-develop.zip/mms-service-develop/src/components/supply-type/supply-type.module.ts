import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { SupplyTypeController } from './supply-type.controller';
import { UserModule } from '@components/user/user.module';
import { SupplyTypeSchema } from 'src/models/supply-type/supply-type.schema';
import { SupplyTypeService } from './supply-type.service';
import { SupplyTypeRepository } from 'src/repository/supply-type/supply-type.repository';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'SupplyType', schema: SupplyTypeSchema },
    ]),
    UserModule,
  ],
  controllers: [SupplyTypeController],
  providers: [
    {
      provide: 'SupplyTypeServiceInterface',
      useClass: SupplyTypeService,
    },
    {
      provide: 'SupplyTypeRepositoryInterface',
      useClass: SupplyTypeRepository,
    },
  ],
  exports: [
    MongooseModule,
    {
      provide: 'SupplyTypeServiceInterface',
      useClass: SupplyTypeService,
    },
    {
      provide: 'SupplyTypeRepositoryInterface',
      useClass: SupplyTypeRepository,
    },
  ],
})
export class SupplyTypeModule {}
