import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { AttributeTypeSchema } from 'src/models/attribute-type/attribute-type.schema';
import { AttributeTypeRepository } from 'src/repository/attribute-type/attribute-type.repository';
import { AttributeTypeController } from './attribute-type.controller';
import { AttributeTypeService } from './attribute-type.service';
import { DeviceGroupRepository } from 'src/repository/device-group/device-group.repository';
import { DeviceGroupSchema } from 'src/models/device-group/device-group.schema';
import { ItemModule } from '@components/item/item.module';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'AttributeType', schema: AttributeTypeSchema },
      { name: 'DeviceGroup', schema: DeviceGroupSchema },
    ]),
    ItemModule,
  ],
  controllers: [AttributeTypeController],
  providers: [
    {
      provide: 'AttributeTypeRepositoryInterface',
      useClass: AttributeTypeRepository,
    },
    {
      provide: 'AttributeTypeServiceInterface',
      useClass: AttributeTypeService,
    },
    {
      provide: 'DeviceGroupRepositoryInterface',
      useClass: DeviceGroupRepository,
    },
  ],
  exports: [
    MongooseModule,
    {
      provide: 'AttributeTypeRepositoryInterface',
      useClass: AttributeTypeRepository,
    },
    {
      provide: 'AttributeTypeServiceInterface',
      useClass: AttributeTypeService,
    },
  ],
})
export class AttributeTypeModule {}
