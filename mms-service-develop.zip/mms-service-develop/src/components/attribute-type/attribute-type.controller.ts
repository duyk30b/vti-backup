import {
  Body,
  Query,
  Param,
  Controller,
  Inject,
  Injectable,
  Post,
  Put,
  Get,
} from '@nestjs/common';
import { isEmpty } from 'lodash';
import { GetListAttributeTypeQuery } from './dto/request/get-list-attribute-type.query';
import { CreateAttributeTypeRequest } from './dto/request/create-attribute-type.request';
import { DetailAttributeTypeRequest } from './dto/request/detail-attribute-type.request';
import { UpdateAttributeTypeBodyDto } from './dto/request/update-attribute-type.request';
import { AttributeTypeServiceInterface } from './interface/attribute-type.service.interface';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { DetailAttributeTypeResponse } from './dto/response/detail-attribute-type.response';
import { ListAttributeTypeResponse } from './dto/response/list-attribute-type.response';
import { ACTIVE_ENUM } from '@constant/common';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CREATE_ATTRIBUTE_TYPE_PERMISSION,
  DETAIL_ATTRIBUTE_TYPE_PERMISSION,
  LIST_ATTRIBUTE_TYPE_PERMISSION,
  UPDATE_ATTRIBUTE_TYPE_PERMISSION,
  UPDATE_STATUS_ATTRIBUTE_TYPE_PERMISSION,
} from '@utils/permissions/attribute-type';
import {
  CREATE_DEVICE_GROUP_PERMISSION,
  UPDATE_DEVICE_GROUP_PERMISSION,
} from '@utils/permissions/device-group';

@Injectable()
@Controller('/attribute-type')
export class AttributeTypeController {
  constructor(
    @Inject('AttributeTypeServiceInterface')
    private readonly attributeTypeService: AttributeTypeServiceInterface,
  ) {}

  @PermissionCode(CREATE_ATTRIBUTE_TYPE_PERMISSION.code)
  @Post('/')
  @ApiOperation({
    tags: ['Attribute Type'],
    summary: 'Định nghĩa loại giá trị',
    description: 'Định nghĩa loại giá trị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async create(@Body() payload: CreateAttributeTypeRequest): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.attributeTypeService.create(request);
  }

  @PermissionCode(UPDATE_ATTRIBUTE_TYPE_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Attribute Type'],
    summary: 'Cập nhật loại giá trị',
    description: 'Cập nhật loại giá trị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async update(
    @Param('id') id: string,
    @Body() payload: UpdateAttributeTypeBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.attributeTypeService.update({
      id,
      ...request,
    });
  }

  @PermissionCode(
    DETAIL_ATTRIBUTE_TYPE_PERMISSION.code,
    UPDATE_ATTRIBUTE_TYPE_PERMISSION.code,
  )
  @Get('/:id')
  @ApiOperation({
    tags: ['Attribute Type'],
    summary: 'Chi tiết loại giá trị',
    description: 'Chi tiết loại giá trị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailAttributeTypeResponse,
  })
  async detail(@Param() param: DetailAttributeTypeRequest): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.attributeTypeService.detail(request);
  }

  @PermissionCode(
    LIST_ATTRIBUTE_TYPE_PERMISSION.code,
    CREATE_DEVICE_GROUP_PERMISSION.code,
    UPDATE_DEVICE_GROUP_PERMISSION.code,
  )
  @Get('/')
  @ApiOperation({
    tags: ['Attribute Type'],
    summary: 'Danh sách loại giá trị',
    description: 'Danh sách loại giá trị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListAttributeTypeResponse,
  })
  async list(@Query() query: GetListAttributeTypeQuery): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.attributeTypeService.list(request);
  }

  @PermissionCode(UPDATE_STATUS_ATTRIBUTE_TYPE_PERMISSION.code)
  @Put('/:id/active')
  @ApiOperation({
    tags: ['Attribute Type'],
    summary: 'Active Attribute Type',
    description: 'Active Attribute Type',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async active(@Param() payload: IdParamDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.attributeTypeService.updateStatus({
      ...request,
      status: ACTIVE_ENUM.ACTIVE,
    });
  }

  @PermissionCode(UPDATE_STATUS_ATTRIBUTE_TYPE_PERMISSION.code)
  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Attribute Type'],
    summary: 'Inactive Attribute Type',
    description: 'Inactive Attribute Type',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async inactive(@Param() payload: IdParamDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.attributeTypeService.updateStatus({
      ...request,
      status: ACTIVE_ENUM.INACTIVE,
    });
  }
}
