import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { keyBy, uniq, has, map, compact } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { GetListAttributeTypeQuery } from './dto/request/get-list-attribute-type.query';
import { CreateAttributeTypeRequest } from './dto/request/create-attribute-type.request';
import { DetailAttributeTypeRequest } from './dto/request/detail-attribute-type.request';
import { UpdateAttributeTypeRequest } from './dto/request/update-attribute-type.request';
import { DetailAttributeTypeResponse } from './dto/response/detail-attribute-type.response';
import { AttributeTypeRepositoryInterface } from './interface/attribute-type.repository.interface';
import { AttributeTypeServiceInterface } from './interface/attribute-type.service.interface';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { ATTRIBUTE_TYPE_CONST } from './attribute-type.constant';
import {
  generateCodeByPreviousCode,
  getCurrentCodeByLastRecord,
} from 'src/helper/code.helper';
import { plus } from '@utils/common';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';

@Injectable()
export class AttributeTypeService implements AttributeTypeServiceInterface {
  constructor(
    @Inject('AttributeTypeRepositoryInterface')
    private readonly attributeTypeRepository: AttributeTypeRepositoryInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(
    request: CreateAttributeTypeRequest,
  ): Promise<ResponsePayload<any>> {
    request.code = await this.attributeTypeRepository.generateNextCode(
      ATTRIBUTE_TYPE_CONST.CODE.PREFIX,
    );

    const unit = await this.itemService.getUnitById(request.unitId);
    if (!unit) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.UNIT_NOT_FOUND'),
      ).toResponse();
    }
    try {
      const document = this.attributeTypeRepository.createEntity(request);
      const dataSave = await document.save();
      const dataReturn = plainToInstance(BasicResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async update(
    request: UpdateAttributeTypeRequest,
  ): Promise<ResponsePayload<any>> {
    try {
      const { id } = request;
      let attributeType = await this.attributeTypeRepository.findOneById(id);

      if (!attributeType) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      const unit = await this.itemService.getUnitById(request.unitId);
      if (!unit) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.UNIT_NOT_FOUND'),
        ).toResponse();
      }

      attributeType = this.attributeTypeRepository.updateEntity(
        attributeType,
        request,
      );
      await this.attributeTypeRepository.findByIdAndUpdate(id, attributeType);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async detail(
    request: DetailAttributeTypeRequest,
  ): Promise<ResponsePayload<any>> {
    try {
      const attributeType = await this.attributeTypeRepository.findOneById(
        request.id,
      );

      if (!attributeType) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }
      const unit = await this.itemService.getUnitById(attributeType.unitId);
      const dataReturn = plainToInstance(
        DetailAttributeTypeResponse,
        { ...attributeType, unit },
        {
          excludeExtraneousValues: true,
        },
      );

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async list(
    request: GetListAttributeTypeQuery,
  ): Promise<ResponsePayload<any>> {
    const { data, count } = await this.attributeTypeRepository.list(request);
    const unitIds = data.map((e) => e.unitId);
    const units = await this.itemService.getListUnit([
      {
        column: 'ids',
        text: unitIds.toString(),
      },
    ]);
    const unitMap = keyBy(units, 'id');
    data.forEach((e) => {
      e['unit'] = unitMap[e.unitId];
    });

    const dataReturn = plainToInstance(DetailAttributeTypeResponse, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const codePrefix = ATTRIBUTE_TYPE_CONST.CODE.PREFIX;
    const lastRecord = await this.attributeTypeRepository.lastRecord();
    const codeCurrent = getCurrentCodeByLastRecord(codePrefix, lastRecord);
    const textAdd = await this.i18n.translate('import.common.add');

    const dataToUpdate = [];
    const dataToInsert = [];
    const codesUpdate = [];

    data.forEach((item, index) => {
      if (item.action === textAdd) {
        item.code = generateCodeByPreviousCode(
          codePrefix,
          plus(codeCurrent, index),
        );
        dataToInsert.push(item);
      } else {
        dataToUpdate.push(item);
        codesUpdate.push(item.code);
      }
    });

    const attributeTypeCodeUpdateExists =
      await this.attributeTypeRepository.findAllByCondition({
        code: { $in: codesUpdate },
      });
    const attributeTypeUpdateMap = keyBy(attributeTypeCodeUpdateExists, 'code');
    const unitCodes = compact(uniq(map(data, 'unitCode')));
    const units = await this.itemService.getListUnit([
      {
        column: 'codes',
        text: unitCodes?.toString(),
      },
    ]);
    const unitMap = keyBy(units, 'code');
    const dataError = [];
    const dataInsert = [];
    const dataUpdate = [];
    dataToInsert.forEach((item) => {
      if (!has(unitMap, item.unitCode)) {
        dataError.push(item);
      } else {
        dataInsert.push(item);
      }
    });
    dataToUpdate.forEach((item) => {
      if (
        !has(attributeTypeUpdateMap, item.code) ||
        !has(unitMap, item.unitCode)
      ) {
        dataError.push(item);
      } else {
        dataUpdate.push(item);
      }
    });

    const attributeTypeDocument = [...dataInsert, ...dataUpdate];
    const bulkOps = attributeTypeDocument.map((doc) => ({
      updateOne: {
        filter: { code: doc.code },
        update: {
          code: doc.code,
          name: doc.name,
          description: doc.description,
          unitId: unitMap[doc.unitCode]._id,
        },
        upsert: true,
      },
    }));

    const dataSuccess = await this.attributeTypeRepository.bulkWrite(bulkOps);
    return { dataError, dataSuccess };
  }

  async updateStatus(request: UpdateActiveStatusPayload): Promise<any> {
    const { id, status } = request;
    const attributeType = await this.attributeTypeRepository.findOneById(id);
    if (!attributeType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    await this.attributeTypeRepository.findByIdAndUpdate(id, {
      $set: { active: status },
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
