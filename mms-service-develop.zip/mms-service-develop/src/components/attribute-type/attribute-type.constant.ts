import { ACTIVE_ENUM, CODE_REGEX } from '@constant/common';

export const ATTRIBUTE_TYPE_CONST = {
  DESCRIPTION: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
  CODE: {
    MAX_LENGTH: 20,
    MIN_LENGTH: 6,
    COLUMN: 'code',
    REGEX: CODE_REGEX,
    PREFIX: 'LGT',
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  UNIT: {
    COLUMN: 'unit',
  },
  ACTIVE: {
    COLUMN: 'active',
    ENUM: ACTIVE_ENUM,
  },
};
