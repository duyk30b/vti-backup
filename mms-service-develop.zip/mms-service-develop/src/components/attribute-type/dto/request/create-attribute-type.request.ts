import { ATTRIBUTE_TYPE_CONST } from '@components/attribute-type/attribute-type.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  IsInt,
} from 'class-validator';
import { IsNotBlank } from 'src/validator/is-not-blank.validator';

export class CreateAttributeTypeRequest extends BaseDto {
  code: string;

  @MaxLength(ATTRIBUTE_TYPE_CONST.NAME.MAX_LENGTH)
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  @IsNotBlank()
  name: string;

  @ApiProperty()
  @MaxLength(ATTRIBUTE_TYPE_CONST.DESCRIPTION.MAX_LENGTH)
  @IsString()
  @IsOptional()
  description: string;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  unitId: number;
}
