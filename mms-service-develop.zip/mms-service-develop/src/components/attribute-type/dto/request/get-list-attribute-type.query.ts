import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { IsOptional, IsString } from 'class-validator';

export class GetListAttributeTypeQuery extends PaginationQuery {
  @ApiProperty()
  @IsString()
  @IsOptional()
  queryIds: string;
}
