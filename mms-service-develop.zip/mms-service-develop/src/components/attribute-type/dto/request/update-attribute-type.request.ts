import { ApiProperty } from '@nestjs/swagger';
import { CreateAttributeTypeRequest } from '@components/attribute-type/dto/request/create-attribute-type.request';
import { IsNotEmpty, IsMongoId } from 'class-validator';

export class UpdateAttributeTypeBodyDto extends CreateAttributeTypeRequest {}
export class UpdateAttributeTypeRequest extends UpdateAttributeTypeBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
