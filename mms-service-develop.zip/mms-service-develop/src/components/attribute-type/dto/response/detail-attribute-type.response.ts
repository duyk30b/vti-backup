import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { Expose, Type } from 'class-transformer';

export class DetailAttributeTypeResponse extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  active: number;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @Type(() => BasicSqlDocumentResponse)
  @ApiProperty()
  @Expose()
  unit: BasicSqlDocumentResponse;
}
