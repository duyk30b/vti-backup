import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { DeviceGroup } from 'src/models/device-group/device-group.model';
import { GetListDeviceGroupRequestDto } from '@components/device-group/dto/request/get-list-device-group.request.dto';
import { GetReportDeviceUseStatusDetailRequestDto } from '@components/report/dto/request/get-report-device-use-status-detail.request';
import { GetReportDeviceUseStatusDetailParamDto } from '@components/report/dto/request/get-report-device-use-status-detail.param.dto';

export interface DeviceGroupRepositoryInterface
  extends BaseInterfaceRepository<DeviceGroup> {
  getList(request: GetListDeviceGroupRequestDto): Promise<any>;
  listToExport(request: GetListDeviceGroupRequestDto): Promise<any>;
  createDocument(param: any): DeviceGroup;
  updateEntity(entity: DeviceGroup, request: any): DeviceGroup;
  reportDeviceUseStatusDetail(
    request: GetReportDeviceUseStatusDetailRequestDto &
      GetReportDeviceUseStatusDetailParamDto,
  ): Promise<any>;
  deviceGroupError(request: any): Promise<any>;
}
