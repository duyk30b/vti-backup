import { GetListDeviceGroupRequestDto } from '@components/device-group/dto/request/get-list-device-group.request.dto';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { UpdateDeviceGroupRequest } from '../dto/request/update-device-group.request.dto';

export interface DeviceGroupServiceInterface {
  getList(request: GetListDeviceGroupRequestDto): Promise<any>;
  create(payload: any): Promise<any>;
  detail(request: IdParamDto): Promise<any>;
  update(request: UpdateDeviceGroupRequest): Promise<any>;
  import(request: any): Promise<{ dataSuccess: any[]; dataError: any[] }>;
  updateStatus(request: UpdateActiveStatusPayload): Promise<any>;
}
