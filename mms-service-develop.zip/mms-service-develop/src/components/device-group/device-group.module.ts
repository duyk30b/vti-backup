import { DeviceTypeSchema } from 'src/models/device-type/device-type.schema';
import { DeviceTypeRepository } from 'src/repository/device-type/device-type.repository';
import { WarehouseRepository } from './../../repository/warehouse/warehouse.repository';
import { DeviceRepository } from './../../repository/device/device.repository';
import { MongooseModule } from '@nestjs/mongoose';
import { Module } from '@nestjs/common';
import { DeviceGroupSchema } from '../../models/device-group/device-group.schema';
import { DeviceGroupService } from '@components/device-group/device-group.service';
import { DeviceGroupRepository } from '../../repository/device-group/device-group.repository';
import { DeviceGroupController } from '@components/device-group/device-group.controller';
import { MaintenanceTeamModule } from '@components/maintenance-team/maintenance-team.module';
import { CheckListTemplateRepository } from 'src/repository/checklist-template/checklist-template.repository';
import { CheckListTemplateModule } from '@components/checklist-template/checklist-template.module';
import { InstallationTemplateModule } from '@components/installation-template/installation-template.module';
import { ErrorTypeModule } from '@components/error-type/error-type.module';
import { InstallationTemplateRepository } from 'src/repository/installation-template/installation-template.repository';
import { ErrorTypeRepository } from 'src/repository/error-type/error-type.repository';
import { AccreditationTemplateRepository } from 'src/repository/accreditation-template/accreditation-template.repository';
import { AccreditationTemplateModule } from '@components/accreditation-template/accreditation-template.module';
import { ArticleDeviceGroupRepository } from 'src/repository/article-device-group/article-device-group.repository';
import { ArticleDeviceGroupSchema } from 'src/models/article-device-group/article-device-group.schema';
import { MaintenanceAttributeSchema } from 'src/models/maintenance-attribute/maintenance-attribute.schema';
import { AttributeTypeSchema } from 'src/models/attribute-type/attribute-type.schema';
import { MaintenanceTemplateSchema } from 'src/models/maintenance-template/maintenance-template.schema';
import { MaintenanceAttributeRepository } from 'src/repository/maintenance-attribute/maintenance-attribute.repository';
import { AttributeTypeRepository } from 'src/repository/attribute-type/attribute-type.repository';
import { MaintenanceTemplateRepository } from 'src/repository/maintenance-template/maintenance-template.repository';
import { SupplySchema } from 'src/models/supply/supply.schema';
import { SupplyRepository } from 'src/repository/supply/supply.repository';
import { SettingModule } from '@components/setting/setting.module';
import { DeviceTemplateScheduleRepository } from 'src/repository/device-template-schedule/device-template-schedule.repository';
import { DeviceTemplateScheduleSchema } from 'src/models/device-template-schedule/device-template-schedule.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'DeviceGroup', schema: DeviceGroupSchema },
      { name: 'ArticleDeviceGroup', schema: ArticleDeviceGroupSchema },
      { name: 'MaintenanceAttribute', schema: MaintenanceAttributeSchema },
      { name: 'AttributeType', schema: AttributeTypeSchema },
      { name: 'MaintenanceTemplate', schema: MaintenanceTemplateSchema },
      { name: 'Supply', schema: SupplySchema },
      { name: 'DeviceType', schema: DeviceTypeSchema },
      { name: 'DeviceTemplateSchedule', schema: DeviceTemplateScheduleSchema },
    ]),
    MaintenanceTeamModule,
    CheckListTemplateModule,
    InstallationTemplateModule,
    ErrorTypeModule,
    AccreditationTemplateModule,
    SettingModule,
  ],
  controllers: [DeviceGroupController],
  providers: [
    {
      provide: 'DeviceGroupRepositoryInterface',
      useClass: DeviceGroupRepository,
    },
    {
      provide: 'DeviceGroupServiceInterface',
      useClass: DeviceGroupService,
    },
    {
      provide: 'DeviceRepositoryInterface',
      useClass: DeviceRepository,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    {
      provide: 'CheckListTemplateRepositoryInterface',
      useClass: CheckListTemplateRepository,
    },
    {
      provide: 'InstallationTemplateRepositoryInterface',
      useClass: InstallationTemplateRepository,
    },
    {
      provide: 'AccreditationTemplateRepositoryInterface',
      useClass: AccreditationTemplateRepository,
    },
    {
      provide: 'ErrorTypeRepositoryInterface',
      useClass: ErrorTypeRepository,
    },

    {
      provide: 'MaintenanceAttributeRepositoryInterface',
      useClass: MaintenanceAttributeRepository,
    },
    {
      provide: 'AttributeTypeRepositoryInterface',
      useClass: AttributeTypeRepository,
    },
    {
      provide: 'MaintenanceTemplateRepositoryInterface',
      useClass: MaintenanceTemplateRepository,
    },
    {
      provide: 'ArticleDeviceGroupRepositoryInterface',
      useClass: ArticleDeviceGroupRepository,
    },

    {
      provide: 'SupplyRepositoryInterface',
      useClass: SupplyRepository,
    },
    {
      provide: 'ArticleDeviceGroupRepositoryInterface',
      useClass: ArticleDeviceGroupRepository,
    },
    {
      provide: 'DeviceTemplateScheduleRepositoryInterface',
      useClass: DeviceTemplateScheduleRepository,
    },
    {
      provide: 'DeviceTypeRepositoryInterface',
      useClass: DeviceTypeRepository,
    },
  ],
  exports: [
    MongooseModule,
    {
      provide: 'DeviceGroupRepositoryInterface',
      useClass: DeviceGroupRepository,
    },
    {
      provide: 'DeviceGroupServiceInterface',
      useClass: DeviceGroupService,
    },
  ],
})
export class DeviceGroupModule {}
