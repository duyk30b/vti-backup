import { ACTIVE_ENUM } from '@constant/common';

import { CODE_REGEX } from '@constant/common';

export const DEVICE_GROUP_CONST = {
  ID: {
    COLUMN: '_id',
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
  CODE: {
    MIN_LENGTH: 6,
    MAX_LENGTH: 20,
    COLUMN: 'code',
    PREFIX: 'NTB',
    REGEX: CODE_REGEX,
  },
  SYMBOL: {
    MIN_LENGTH: 1,
    MAX_LENGTH: 10,
    COLUMN: 'symbol',
    REGEX: CODE_REGEX,
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  QUANTITY: {
    MIN: 1,
    MAX: 999,
  },
  ACTIVE: {
    COLUMN: 'active',
    ENUM: ACTIVE_ENUM,
  },
  COLL: 'deviceGroups',
  NORM_GENERATE_JOB: {
    MIN: 1,
    MAX: 100,
  },
};
export enum DeviceGroupStatusConstant {
  AWAITING,
  CONFIRMED,
  COMPLETED,
}

export enum MAINTENANCE_INFO_TYPE_ENUM {
  DEVICE_GROUP,
  ACCESSORY,
}
export enum CAN_FIXABLE_ENUM {
  NO,
  YES,
}

export enum GENERATE_JOB_BY_ENUM {
  ACTIVE_TIME,
  PERIOD_TIME,
}

export enum CAN_UPDATE_STATUS {
  NO,
  YES,
}

export const STATUS_TO_DELETE_OR_UPDATE_DEVICE_GROUP = [
  DeviceGroupStatusConstant.AWAITING,
];
export const DEVICE_GROUP_NAME = 'device-group';
export const DEVICE_GROUP_HEADER = [
  {
    from: 'i',
  },
  {
    from: '_id',
  },
  {
    from: 'code',
  },
  {
    from: 'name',
  },
  {
    from: 'description',
  },
  {
    from: 'active',
  },
  {
    from: 'createdAt',
  },
  {
    from: 'updatedAt',
  },
];

export const IMPORT_DEVICE_GROUP_CONST = {
  FILE_NAME: 'import_device_group_template.xlsx',
  ENTITY_KEY: 'device-group',
  COLUMNS: ['code', 'name', 'description'],
  REQUIRED_FIELDS: ['code', 'name'],
};
