import { DeviceGroupServiceInterface } from '@components/device-group/interface/device-group.service.interface';
import { DeviceGroupRepositoryInterface } from '@components/device-group/interface/device-group.repository.interface';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { CreateDeviceGroupRequestDto } from '@components/device-group/dto/request/create-device-group.request.dto';
import { compact, differenceBy, has, isEmpty, keyBy, map, uniq } from 'lodash';
import { GetListDeviceGroupRequestDto } from '@components/device-group/dto/request/get-list-device-group.request.dto';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { plainToInstance } from 'class-transformer';
import { GetDetailDeviceGroupResponseDto } from '@components/device-group/dto/response/get-detail-device-group.response.dto';
import { ACTIVE_ENUM, GET_ALL_ENUM } from '@constant/common';
import { UpdateDeviceGroupActiveStatusPayload } from './dto/request/update-device-group-status.request';
import { InstallationTemplateRepositoryInterface } from '@components/installation-template/interface/installation-template.repository';
import { ErrorTypeRepositoryInterface } from '@components/error-type/interface/error-type.repository.interface';
import { AccreditationTemplateRepositoryInterface } from '@components/accreditation-template/interface/accreditation-template.repository.interface';
import { ArticleDeviceGroupRepositoryInterface } from '@components/article-device-group/interface/article-device-group.repository.interface';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateDeviceGroupRequest } from './dto/request/update-device-group.request.dto';
import { SupplyRepositoryInterface } from '@components/supply/interface/supply.repository.interface';
import { MaintenanceTemplateRepositoryInterface } from '@components/maintenance-template/interface/maintenance-template.repository.interface';
import { MaintenanceAttributeRepositoryInterface } from '@components/maintenance-attribute/interface/maintenance-attribute.repository.interface';
import { AttributeTypeRepositoryInterface } from '@components/attribute-type/interface/attribute-type.repository.interface';
import { ListDeviceGroupResponseDto } from './dto/response/list-device-group.response.dto';
import {
  DEVICE_GROUP_CONST,
  MAINTENANCE_INFO_TYPE_ENUM,
} from './device-group.constant';
import { Types } from 'mongoose';
import { generateCodeByPreviousCode } from 'src/helper/code.helper';
import { getDataDuplicate, plus } from '@utils/common';
import { DeviceTypeRepositoryInterface } from '@components/device-type/interface/device-type.repository.interface';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { DEVICE_TEMPLATE_SCHEDULE_EVENT_ENUM } from '@components/device/device.constant';

@Injectable()
export class DeviceGroupService implements DeviceGroupServiceInterface {
  constructor(
    @Inject('DeviceGroupRepositoryInterface')
    private readonly deviceGroupRepository: DeviceGroupRepositoryInterface,

    @Inject('InstallationTemplateRepositoryInterface')
    private readonly installationTemplateRepository: InstallationTemplateRepositoryInterface,

    @Inject('AccreditationTemplateRepositoryInterface')
    private readonly accreditationTemplateRepository: AccreditationTemplateRepositoryInterface,

    @Inject('ErrorTypeRepositoryInterface')
    private readonly errorTypeRepository: ErrorTypeRepositoryInterface,

    @Inject('DeviceTypeRepositoryInterface')
    private readonly deviceTypeRepository: DeviceTypeRepositoryInterface,

    @Inject('ArticleDeviceGroupRepositoryInterface')
    private readonly articleDeviceGroupRepository: ArticleDeviceGroupRepositoryInterface,

    @Inject('AttributeTypeRepositoryInterface')
    private readonly attributeTypeRepository: AttributeTypeRepositoryInterface,

    @Inject('MaintenanceAttributeRepositoryInterface')
    private readonly maintenanceAttributeRepository: MaintenanceAttributeRepositoryInterface,

    @Inject('MaintenanceTemplateRepositoryInterface')
    private readonly maintenanceTemplateRepository: MaintenanceTemplateRepositoryInterface,

    @Inject('SupplyRepositoryInterface')
    private readonly supplyRepository: SupplyRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,

    private readonly eventEmitter: EventEmitter2,
  ) {}

  async create(request: CreateDeviceGroupRequestDto): Promise<any> {
    try {
      const validate = await this.validateBeforeSave(request);
      if (validate.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validate;
      }

      const deviceGroupDocument =
        this.deviceGroupRepository.createDocument(request);
      const dataSave = await deviceGroupDocument.save();

      const dataReturn = plainToInstance(BasicResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CREATE'))
        .build();
    }
  }

  async getList(request: GetListDeviceGroupRequestDto): Promise<any> {
    if (request.isGetAll == GET_ALL_ENUM.YES) {
      const response = await this.deviceGroupRepository.findAll();

      const result = plainToInstance(BasicResponseDto, response, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } else {
      const { result, count } = await this.deviceGroupRepository.getList(
        request,
      );

      const response = plainToInstance(ListDeviceGroupResponseDto, result, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder<PaginationResponse>({
        items: response,
        meta: { total: count, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
  }

  async detail(request: IdParamDto): Promise<any> {
    const { id } = request;
    const result = await this.deviceGroupRepository.findOneWithPopulate(
      { _id: id },
      [
        'installationTemplate',
        'accreditationTemplate',
        'errorTypes',
        'articleDeviceGroup',
        'maintenanceAttribute',
        'deviceType',
        'attributeTypes',
        'maintenanceTemplate',
        'maintenanceIndex.supply',
        { path: 'supplies.supply', populate: 'supplyType vendor' },
      ],
    );
    if (!result) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.DEVICE_GROUP_NOT_FOUND'))
        .build();
    }
    const response = plainToInstance(GetDetailDeviceGroupResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async update(request: UpdateDeviceGroupRequest): Promise<any> {
    const {
      id,
      accreditationTemplateId,
      maintenanceTemplateId,
      normGenerateJob,
      generateJobBy,
    } = request;
    const deviceGroup = await this.deviceGroupRepository.findOneById(id);
    if (!deviceGroup) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.DEVICE_GROUP_NOT_FOUND'))
        .build();
    }
    const validate = await this.validateBeforeSave(request, false);
    if (validate.statusCode !== ResponseCodeEnum.SUCCESS) {
      return validate;
    }
    this.eventEmitter.emit(
      DEVICE_TEMPLATE_SCHEDULE_EVENT_ENUM.DEVICE_GROUP_UPDATE,
      {
        deviceGroupOld: { ...deviceGroup },
        maintenanceTemplateId,
        accreditationTemplateId,
        normGenerateJob,
        generateJobBy,
      },
    );
    try {
      const result = this.deviceGroupRepository.updateEntity(
        deviceGroup,
        request,
      );
      await this.deviceGroupRepository.findByIdAndUpdate(id, result);
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const dataToInsert = [];
    const dataToUpdate = [];
    const codesUpdate = [];
    const textAdd = await this.i18n.translate('import.common.add');

    const deviceGroupConst = DEVICE_GROUP_CONST.CODE;
    const lastRecord = await this.deviceGroupRepository.lastRecord();
    const codeCurrent =
      +lastRecord.code?.replace(deviceGroupConst.PREFIX, '') || 0;
    data.forEach((item, index) => {
      item.errorTypeCodes = item.errorTypeCodes?.split(',');
      item.attributeTypeCodes = item.attributeTypeCodes?.split(',');
      if (item.action === textAdd) {
        item.code = generateCodeByPreviousCode(
          deviceGroupConst.PREFIX,
          plus(codeCurrent, index),
        );
        dataToInsert.push(item);
      } else {
        dataToUpdate.push(item);
        codesUpdate.push(item.code);
      }
    });

    const deviceGroupCodeUpdateExists =
      await this.deviceGroupRepository.findAllByCondition({
        code: {
          $in: codesUpdate,
        },
      });
    const deviceGroupUpdateMap = keyBy(deviceGroupCodeUpdateExists, 'code');
    const installationTemplateCodes = compact(
      uniq(data.map((item) => item.installationTemplateCode)),
    );
    const installationTemplates =
      await this.installationTemplateRepository.findAllByCondition({
        code: {
          $in: installationTemplateCodes,
        },
      });
    const installationTemplateMap = keyBy(installationTemplates, 'code');

    const accreditationTemplateCodes = compact(
      uniq(data.map((item) => item.accreditationTemplateCode)),
    );
    const accreditationTemplates =
      await this.accreditationTemplateRepository.findAllByCondition({
        code: {
          $in: accreditationTemplateCodes,
        },
      });
    const accreditationTemplateMap = keyBy(accreditationTemplates, 'code');

    // error type
    const errorTypeCodes = compact(
      uniq(data.reduce((total, item) => total.concat(item.errorTypeCodes), [])),
    );
    const errorTypes = await this.errorTypeRepository.findAllByCondition({
      code: {
        $in: errorTypeCodes,
      },
    });
    const errorTypeMap = keyBy(errorTypes, 'code');

    const articleDeviceGroupCodes = compact(
      uniq(data.map((item) => item.articleDeviceGroupCode)),
    );
    const articleDeviceGroups =
      await this.articleDeviceGroupRepository.findAllByCondition({
        code: {
          $in: articleDeviceGroupCodes,
        },
      });
    const articleDeviceGroupMap = keyBy(articleDeviceGroups, 'code');

    const maintenanceAttributeCodes = compact(
      uniq(data.map((item) => item.maintenanceAttributeCode)),
    );
    const maintenanceAttributes =
      await this.maintenanceAttributeRepository.findAllByCondition({
        code: {
          $in: maintenanceAttributeCodes,
        },
      });
    const maintenanceAttributeMap = keyBy(maintenanceAttributes, 'code');

    // attributeType
    const attributeTypeCodes = compact(
      uniq(
        data.reduce((total, item) => total.concat(item.attributeTypeCodes), []),
      ),
    );
    const attributeTypes =
      await this.attributeTypeRepository.findAllByCondition({
        code: {
          $in: attributeTypeCodes,
        },
      });
    const attributeTypeMap = keyBy(attributeTypes, 'code');

    // supplies
    const supplyCodes = data.reduce(
      (total, item) => total.concat(map(item.supplies, 'supplyCode')),
      [],
    );
    const supplyCodeUniqs = compact(uniq(supplyCodes));

    const supplies = await this.supplyRepository.findAllWithPopulate(
      {
        code: {
          $in: supplyCodeUniqs,
        },
      },
      'supplyType',
    );
    const supplyMap = keyBy(supplies, 'code');

    const maintenanceTemplateCodes = compact(
      uniq(data.map((item) => item.maintenanceTemplateCode)),
    );
    const maintenanceTemplates =
      await this.maintenanceTemplateRepository.findAllByCondition({
        code: {
          $in: maintenanceTemplateCodes,
        },
      });
    const maintenanceTemplateMap = keyBy(maintenanceTemplates, 'code');

    const dataError = [];
    const dataInsert = [];
    const dataUpdate = [];
    // check duplicate name, symbol
    const duplicateName = getDataDuplicate(map(dataToInsert, 'name'));
    const duplicateSymbol = getDataDuplicate(map(dataToInsert, 'symbol'));
    function checkCode(arrMap, arrCheck): boolean {
      return arrCheck?.every((el) => {
        return has(arrMap, el);
      });
    }

    function checkType(arrCheck): boolean {
      return arrCheck?.every((el) => {
        return supplyMap[el.supplyCode]
          ? supplyMap[el.supplyCode].supplyType?.type ===
              MAINTENANCE_INFO_TYPE_ENUM.ACCESSORY
          : true;
      });
    }
    accreditationTemplateMap[undefined as any] = null;
    maintenanceTemplateMap[undefined as any] = null;
    installationTemplateMap[undefined as any] = null;
    dataToInsert.forEach((item) => {
      if (
        !has(maintenanceAttributeMap, item.maintenanceAttributeCode) ||
        !has(installationTemplateMap, item.installationTemplateCode) ||
        !checkCode(errorTypeMap, item.errorTypeCodes) ||
        !has(maintenanceTemplateMap, item.maintenanceTemplateCode) ||
        !has(accreditationTemplateMap, item.accreditationTemplateCode) ||
        !checkCode(attributeTypeMap, item.attributeTypeCodes) ||
        !has(articleDeviceGroupMap, item.articleDeviceGroupCode) ||
        !isEmpty(
          differenceBy(
            item.maintenanceIndex?.filter((el) => !isEmpty(el.supplyCode)),
            item.supplies,
            'supplyCode',
          ),
        ) ||
        !checkCode(
          supplyMap,
          item.supplies?.map((el) => el.supplyCode),
        ) ||
        !checkType(item.maintenanceIndex) ||
        duplicateName.includes(item.name) ||
        duplicateSymbol.includes(item.symbol)
      ) {
        dataError.push(item);
      } else {
        dataInsert.push(item);
      }
    });

    dataToUpdate.forEach((item) => {
      if (
        !has(deviceGroupUpdateMap, item.code) ||
        !has(maintenanceAttributeMap, item.maintenanceAttributeCode) ||
        !has(installationTemplateMap, item.installationTemplateCode) ||
        !checkCode(attributeTypeMap, item.attributeTypeCodes) ||
        !has(maintenanceTemplateMap, item.maintenanceTemplateCode) ||
        !has(accreditationTemplateMap, item.accreditationTemplateCode) ||
        !checkCode(errorTypeMap, item.errorTypeCodes) ||
        !has(articleDeviceGroupMap, item.articleDeviceGroupCode) ||
        !isEmpty(
          differenceBy(
            item.maintenanceIndex?.filter((el) => !isEmpty(el.supplyCode)),
            item.supplies,
            'supplyCode',
          ),
        ) ||
        !checkCode(
          supplyMap,
          item.supplies?.map((el) => el.supplyCode),
        ) ||
        !checkType(item.maintenanceIndex) ||
        duplicateName.includes(item.name) ||
        duplicateSymbol.includes(item.symbol) ||
        !isEmpty(getDataDuplicate(map(item.supplies, 'supplyCode'))) ||
        !isEmpty(getDataDuplicate(map(item.maintenanceIndex, 'supplyCode')))
      ) {
        dataError.push(item);
      } else {
        this.eventEmitter.emit(
          DEVICE_TEMPLATE_SCHEDULE_EVENT_ENUM.DEVICE_GROUP_UPDATE,
          {
            deviceGroupOld: deviceGroupUpdateMap[item.code],
            maintenanceTemplateId:
              maintenanceTemplateMap[item.maintenanceTemplateCode]?._id,
            accreditationTemplateId:
              accreditationTemplateMap[item.accreditationTemplateCode]?._id,
            normGenerateJob: item.normGenerateJob,
          },
        );
        dataUpdate.push(item);
      }
    });

    const bulkOps = [...dataInsert, ...dataUpdate].map((doc) => {
      const supplies = doc.supplies?.map((el) => ({
        ...el,
        supplyId: supplyMap[el.supplyCode]?._id,
      }));
      const maintenanceIndex = doc.maintenanceIndex?.map((el) => ({
        ...el,
        supplyId: supplyMap[el.supplyCode]?._id,
      }));
      return {
        updateOne: {
          filter: { code: doc.code },
          update: {
            ...doc,
            supplies: supplies,
            maintenanceIndex: maintenanceIndex,
            maintenanceAttributeId:
              maintenanceAttributeMap[doc.maintenanceAttributeCode]?._id,
            maintenanceTemplateId:
              maintenanceTemplateMap[doc.maintenanceTemplateCode]?._id ?? null,
            //  errorTypeIds []
            errorTypeIds: doc.errorTypeCodes?.map(
              (el) => errorTypeMap[el]?._id,
            ),
            //  attributeTypeIds []
            attributeTypeIds: doc.attributeTypeCodes?.map(
              (el) => attributeTypeMap[el]?._id,
            ),
            installationTemplateId:
              installationTemplateMap[doc.installationTemplateCode]?._id ??
              null,
            accreditationTemplateId:
              accreditationTemplateMap[doc.accreditationTemplateCode]?._id ??
              null,
            articleDeviceGroupId:
              articleDeviceGroupMap[doc.articleDeviceGroupCode]?._id,
          },
          upsert: true,
        },
      };
    });

    const dataSuccess = await this.deviceGroupRepository.bulkWrite(bulkOps);

    return {
      dataError,
      dataSuccess,
    };
  }

  async updateStatus(
    request: UpdateDeviceGroupActiveStatusPayload,
  ): Promise<any> {
    const { id, status } = request;
    const deviceGroup = await this.deviceGroupRepository.findOneById(id);
    if (!deviceGroup) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (
      status === ACTIVE_ENUM.ACTIVE &&
      (isEmpty(deviceGroup.supplies) ||
        !deviceGroup.deviceTypeId ||
        !deviceGroup.articleDeviceGroupId ||
        !deviceGroup.symbol ||
        !deviceGroup.maintenanceAttributeId ||
        !deviceGroup.frequency ||
        isEmpty(deviceGroup.errorTypeIds) ||
        isEmpty(deviceGroup.attributeTypeIds) ||
        isEmpty(deviceGroup.maintenanceIndex))
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.CANNOT_ACTIVE_DEVICE_GROUP'),
        )
        .build();
    }
    await this.deviceGroupRepository.findByIdAndUpdate(id, {
      $set: { active: status },
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async validateBeforeSave(request: any, isCreate = true) {
    const {
      installationTemplateId,
      accreditationTemplateId,
      errorTypeIds,
      articleDeviceGroupId,
      maintenanceAttributeId,
      attributeTypeIds,
      maintenanceTemplateId,
      supplies,
      symbol,
      deviceTypeId,
      name,
    } = request;

    if (installationTemplateId) {
      const existedInstallationTemplate =
        await this.installationTemplateRepository.findOneById(
          installationTemplateId,
        );
      if (!existedInstallationTemplate) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.INSTALLATION_TEMPLATE_NOT_FOUND'),
          )
          .build();
      }
    }

    const existsDeviceGroupNameCondition: any = {
      name: { $regex: new RegExp(`^${name}$`, 'i') },
      deletedAt: null,
    };
    const existsSymbolCondition: any = { symbol, deletedAt: null };

    if (request?.id && !isCreate) {
      existsDeviceGroupNameCondition.id = {
        $ne: new Types.ObjectId(request.id),
      };
      existsSymbolCondition.id = { $ne: new Types.ObjectId(request.id) };
    }
    const existsDeviceGroupName =
      await this.deviceGroupRepository.findOneByCondition(
        existsDeviceGroupNameCondition,
      );
    if (existsDeviceGroupName) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.DEVICE_GROUP_NAME_HAS_EXISTS'),
        )
        .build();
    }

    const existedSymbol = await this.deviceGroupRepository.findOneByCondition(
      existsSymbolCondition,
    );
    if (existedSymbol) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.DEVICE_GROUP_SYMBOL_EXISTED'),
        )
        .build();
    }

    const existedDeviceType = await this.deviceTypeRepository.findOneById(
      deviceTypeId,
    );
    if (!existedDeviceType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.DEVICE_TYPE_NOT_FOUND'))
        .build();
    }

    if (accreditationTemplateId) {
      const existedAccreditationTemplate =
        await this.accreditationTemplateRepository.findOneById(
          accreditationTemplateId,
        );
      if (!existedAccreditationTemplate) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.ACCREDITATION_TEMPLATE_NOT_FOUND'),
          )
          .build();
      }
    }

    const existedErrorType = await this.errorTypeRepository.findAllByCondition({
      _id: { $in: errorTypeIds },
    });
    if (existedErrorType.length < errorTypeIds.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.ERROR_TYPE_NOT_FOUND'))
        .build();
    }

    const articleDeviceGroup =
      await this.articleDeviceGroupRepository.findOneById(articleDeviceGroupId);
    if (!articleDeviceGroup) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.ARTICLE_DEVICE_GROUP_NOT_FOUND'),
        )
        .build();
    }
    const maintenanceAttribute =
      await this.maintenanceAttributeRepository.findOneById(
        maintenanceAttributeId,
      );
    if (!maintenanceAttribute) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.MAINTENANCE_ATTRIBUTE_NOT_FOUND'),
        )
        .build();
    }

    const attributeType = await this.attributeTypeRepository.findAllByCondition(
      {
        _id: { $in: attributeTypeIds },
      },
    );
    if (attributeType.length < attributeTypeIds.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.ATTRIBUTE_TYPE_NOT_EXIST'),
        )
        .build();
    }

    if (maintenanceTemplateId) {
      const maintenanceTemplate =
        await this.maintenanceTemplateRepository.findOneById(
          maintenanceTemplateId,
        );
      if (!maintenanceTemplate) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.MAINTENANCE_TEMPLATE_NOT_EXIST'),
          )
          .build();
      }
    }

    const supplyIds = map(supplies, 'supplyId');
    const supplyExists = await this.supplyRepository.findAllByCondition({
      _id: { $in: supplyIds },
    });
    if (supplyExists?.length < supplyIds.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.SUPPLY_NOT_FOUND'))
        .build();
    }

    if (isCreate) {
      const deviceGroupConst = DEVICE_GROUP_CONST.CODE;
      const lastRecord = await this.deviceGroupRepository.lastRecord();
      const codeCurrent =
        +lastRecord.code?.replace(deviceGroupConst.PREFIX, '') || 0;
      request.code = generateCodeByPreviousCode(
        deviceGroupConst.PREFIX,
        codeCurrent,
      );
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
