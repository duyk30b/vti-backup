import { SupplyTypeDto } from '@components/supply/dto/response/get-all-supply.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type, plainToInstance } from 'class-transformer';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { IsArray } from 'class-validator';

class Supply {
  @Expose()
  @Transform((v) => v.obj?.supply?.type)
  type: number;

  @ApiProperty()
  @Expose()
  @Transform((v) => v.obj?.supply?._id?.toString())
  id: string;

  @ApiProperty()
  @Expose()
  @Transform((v) => v.obj?.supply?.code)
  code: string;

  @ApiProperty()
  @Expose()
  @Transform((v) => v.obj?.supply?.name)
  name: string;

  @ApiProperty()
  @Expose()
  @Transform((v) => v.obj?.supply?.nameOther)
  nameOther: string;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  @Transform((v) =>
    plainToInstance(BasicResponseDto, v.obj?.supply?.vendor, {
      excludeExtraneousValues: true,
    }),
  )
  vendor: BasicResponseDto;

  @ApiProperty()
  @Expose()
  @Transform((v) => v.obj?.supply?.supplyType)
  supplyType: SupplyTypeDto;
}

class SupplyDetail extends Supply {
  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  estimateUsedTime: number;

  @ApiProperty()
  @Expose()
  canFixable: number;
}

class MaintenanceIndex extends Supply {
  @ApiProperty()
  @Expose()
  maintenanceFrequency: number;

  @ApiProperty()
  @Expose()
  mtbf: number;

  @ApiProperty()
  @Expose()
  mttr: number;

  @ApiProperty()
  @Expose()
  mtta: number;

  @ApiProperty()
  @Expose()
  mttf: number;
}

export class GetDetailDeviceGroupResponseDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  active: number;

  @ApiProperty()
  @Expose()
  symbol: string;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  deviceType: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  installationTemplate: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  accreditationTemplate: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  errorTypes: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  articleDeviceGroup: BasicResponseDto;

  @ApiProperty({ type: SupplyDetail, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => SupplyDetail)
  supplies: SupplyDetail[];

  @ApiProperty()
  @Expose()
  frequency: number;

  @ApiProperty({ type: BasicResponseDto, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => BasicResponseDto)
  attributeTypes: BasicResponseDto[];

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  maintenanceAttribute: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  maintenanceTemplate: BasicResponseDto;

  @ApiProperty()
  @Expose()
  canUpdateStatus: number;

  @ApiProperty({ type: MaintenanceIndex, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => MaintenanceIndex)
  maintenanceIndex: MaintenanceIndex[];

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty()
  @Expose()
  generateJobBy: number;

  @ApiProperty()
  @Expose()
  normGenerateJob: number;
}
