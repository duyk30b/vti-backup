import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsEnum,
  IsInt,
  IsMongoId,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Length,
  Matches,
  Max,
  MaxLength,
  Min,
  ValidateIf,
  ValidateNested,
} from 'class-validator';
import {
  CAN_FIXABLE_ENUM,
  CAN_UPDATE_STATUS,
  DEVICE_GROUP_CONST,
  GENERATE_JOB_BY_ENUM,
  MAINTENANCE_INFO_TYPE_ENUM,
} from '@components/device-group/device-group.constant';
import { IsNotBlank } from 'src/validator/is-not-blank.validator';
import { Type } from 'class-transformer';

class MaintenanceIndex {
  @ValidateIf((data) => data.type === MAINTENANCE_INFO_TYPE_ENUM.ACCESSORY)
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  supplyId: string;

  @ApiProperty()
  @IsNumber()
  @IsOptional()
  maintenanceFrequency: number;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  mtbf: number;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  mttr: number;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  mtta: number;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  mttf: number;
}

class Supply {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  supplyId: string;

  @ApiProperty()
  @IsInt()
  @Min(1)
  quantity: number;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  estimateUsedTime: number;

  @ApiProperty()
  @IsEnum(CAN_FIXABLE_ENUM)
  @IsNotEmpty()
  canFixable: number;
}
export class CreateDeviceGroupRequestDto extends BaseDto {
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @MaxLength(DEVICE_GROUP_CONST.NAME.MAX_LENGTH)
  @IsString()
  @IsNotBlank()
  name: string;

  @ApiProperty()
  @IsNotEmpty()
  @Length(
    DEVICE_GROUP_CONST.SYMBOL.MIN_LENGTH,
    DEVICE_GROUP_CONST.SYMBOL.MAX_LENGTH,
  )
  @IsString()
  @Matches(DEVICE_GROUP_CONST.SYMBOL.REGEX)
  @IsNotBlank()
  symbol: string;

  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  deviceTypeId: string;

  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  installationTemplateId: string;

  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  accreditationTemplateId: string;

  @ApiProperty()
  @IsMongoId({ each: true })
  @ArrayUnique()
  @IsNotEmpty()
  errorTypeIds: string[];

  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  articleDeviceGroupId: string;

  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  maintenanceAttributeId: string;

  @ApiProperty()
  @IsMongoId({ each: true })
  @ArrayUnique()
  @ArrayNotEmpty()
  attributeTypeIds: string[];

  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  maintenanceTemplateId: string;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  frequency: number;

  @ApiProperty()
  @IsEnum(CAN_UPDATE_STATUS)
  @IsNotEmpty()
  canUpdateStatus: number;

  @ApiProperty()
  @IsEnum(GENERATE_JOB_BY_ENUM)
  @IsOptional()
  generateJobBy: number;

  @ApiProperty()
  @Min(DEVICE_GROUP_CONST.NORM_GENERATE_JOB.MIN)
  @Max(DEVICE_GROUP_CONST.NORM_GENERATE_JOB.MAX)
  @IsNumber()
  @IsOptional()
  normGenerateJob: number;

  @ApiProperty({ type: MaintenanceIndex, isArray: true })
  @Type(() => MaintenanceIndex)
  @ValidateNested({ each: true })
  @ArrayUnique((data) => data.supplyId)
  @IsNotEmpty()
  maintenanceIndex: MaintenanceIndex[];

  @ApiProperty({ type: Supply, isArray: true })
  @ValidateNested({ each: true })
  @IsArray()
  @ArrayUnique((e) => e.supplyId)
  @Type(() => Supply)
  @IsOptional()
  supplies: Supply[];
}
