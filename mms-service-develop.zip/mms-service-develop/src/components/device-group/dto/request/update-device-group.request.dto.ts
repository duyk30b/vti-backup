import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateDeviceGroupRequestDto } from './create-device-group.request.dto';

export class UpdateDeviceGroupBody extends CreateDeviceGroupRequestDto {}
export class UpdateDeviceGroupRequest extends UpdateDeviceGroupBody {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  id: string;
}
