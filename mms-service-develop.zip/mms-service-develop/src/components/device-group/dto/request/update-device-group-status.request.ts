import { DEVICE_GROUP_CONST } from '@components/device-group/device-group.constant';
import { BaseDto } from '@core/dto/base.dto';
import { IsEnum, IsMongoId, IsNotEmpty } from 'class-validator';

export class UpdateDeviceGroupActiveStatusPayload extends BaseDto {
  @IsNotEmpty()
  @IsMongoId()
  id: string;

  @IsNotEmpty()
  @IsEnum(DEVICE_GROUP_CONST.ACTIVE.ENUM)
  status: number;
}
