import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString } from 'class-validator';
import { GET_ALL_ENUM } from '@constant/common';
import { Transform } from 'class-transformer';
export class GetListDeviceGroupRequestDto extends PaginationQuery {
  @ApiPropertyOptional()
  @IsOptional()
  @Transform((data) => parseInt(data.value))
  @IsEnum(GET_ALL_ENUM)
  isGetAll: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  queryIds: string;
}
