import { CheckListTemplateRepositoryInterface } from '@components/checklist-template/interface/checklist-template.repository.interface';
import { DEVICE_TEMPLATE_SCHEDULE_EVENT_ENUM } from '@components/device/device.constant';
import { FileResource } from '@components/file/file.constant';
import { FileServiceInterface } from '@components/file/interface/file.service.interface';
import { ConfigService } from '@config/config.service';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { plus } from '@utils/helper';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { compact, difference, has, isEmpty, keyBy, map, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import {
  generateCodeByPreviousCode,
  getCurrentCodeByLastRecord,
} from 'src/helper/code.helper';
import { CreateMaintenanceTemplateRequestDto } from './dto/request/create-maintenance-template.request.dto';
import { GetListMaintenanceTemplateRequestDto } from './dto/request/get-list-maintenance-template.request.dto';
import { UpdateMaintenanceTemplateRequestDto } from './dto/request/update-maintenance-template.request.dto';
import { GetListMaintenanceTemplateResponseDto } from './dto/response/get-list-maintenance-template.response.dto';
import { GetMaintenanceTemplateResponseDto } from './dto/response/get-maintenance-template.response.dto';
import { MaintenanceTemplateRepositoryInterface } from './interface/maintenance-template.repository.interface';
import { MaintenanceTemplateServiceInterface } from './interface/maintenance-template.service.interface';
import {
  MAINTENANCE_JOB_TYPE,
  MAINTENANCE_TEMPLATE_CONST,
} from './maintenance-template.constant';

@Injectable()
export class MaintenanceTemplateService
  implements MaintenanceTemplateServiceInterface
{
  private readonly configService: ConfigService;
  private readonly fileUri: string;

  constructor(
    private readonly i18n: I18nRequestScopeService,

    @Inject('MaintenanceTemplateRepositoryInterface')
    private readonly maintenanceTemplateRepository: MaintenanceTemplateRepositoryInterface,

    @Inject('FileServiceInterface')
    private readonly fileService: FileServiceInterface,

    @Inject('ChecklistTemplateRepositoryInterface')
    private readonly checklistTemplateRepository: CheckListTemplateRepositoryInterface,

    private readonly eventEmitter: EventEmitter2,
  ) {
    this.configService = new ConfigService();
    this.fileUri = this.configService.get('fileUri');
  }

  async create(
    payload: CreateMaintenanceTemplateRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { data, files } = payload;
    data.code = await this.maintenanceTemplateRepository.generateNextCode(
      MAINTENANCE_TEMPLATE_CONST.CODE.PREFIX,
    );
    if (!isEmpty(files)) {
      const fileIds = await this.fileService.uploadFiles(
        files,
        FileResource.MAINTENANCE_TEMPLATE,
      );
      if (fileIds?.length !== files.length) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.UPLOAD_FILE_ERROR'))
          .build();
      }
      data.fileIds = fileIds;
    }

    const maintenanceTemplateEntity =
      this.maintenanceTemplateRepository.createEntity(data);
    const dataSave = await maintenanceTemplateEntity.save();

    const dataReturn = plainToInstance(BasicResponseDto, dataSave, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async update(
    request: UpdateMaintenanceTemplateRequestDto & IdParamDto,
  ): Promise<ResponsePayload<any>> {
    const { data, files, id, fileUrls } = request;
    const maintenanceTemplateExisted =
      await this.maintenanceTemplateRepository.findOneById(id);
    if (!maintenanceTemplateExisted) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    let fileIds = [];
    if (!isEmpty(files)) {
      fileIds = await this.fileService.uploadFiles(
        files ?? [],
        FileResource.MAINTENANCE_TEMPLATE,
      );
      if (fileIds?.length !== files.length) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.UPLOAD_FILE_ERROR'))
          .build();
      }
    }
    const fileIdsBody = map(fileUrls, 'id') ?? [];
    const filesNotFound = difference(
      fileIdsBody,
      maintenanceTemplateExisted.fileIds?.map((el) => el.toString()),
    );
    if (!isEmpty(filesNotFound)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.FILE_NOT_FOUND'))
        .build();
    }
    data.fileIds = fileIds.concat(fileIdsBody);
    const maintenanceTemplateEntity =
      this.maintenanceTemplateRepository.updateEntity(
        maintenanceTemplateExisted,
        data,
      );
    const newMaintenanceTemplate =
      await this.maintenanceTemplateRepository.findByIdAndUpdate(
        id,
        maintenanceTemplateEntity,
      );
    const devices =
      await this.maintenanceTemplateRepository.getTemplateScheduleByTemplate(
        id,
      );
    this.eventEmitter.emit(
      DEVICE_TEMPLATE_SCHEDULE_EVENT_ENUM.MAINTENANCE_TEMPLATE_UPDATE,
      {
        devices,
        maintenanceDetails: newMaintenanceTemplate.details,
      },
    );

    const dataReturn = plainToInstance(
      BasicResponseDto,
      newMaintenanceTemplate,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateActiveStatus(
    payload: UpdateActiveStatusPayload,
  ): Promise<ResponsePayload<any>> {
    const { id, status } = payload;
    const maintenanceTemplateExisted =
      await this.maintenanceTemplateRepository.findOneById(id);
    if (!maintenanceTemplateExisted) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    await this.maintenanceTemplateRepository.updateById(id, {
      active: status,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async list(
    payload: GetListMaintenanceTemplateRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { data, count } = await this.maintenanceTemplateRepository.list(
      payload,
    );

    const dataReturn = plainToInstance(
      GetListMaintenanceTemplateResponseDto,
      data,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: payload.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async detail(id: string): Promise<ResponsePayload<any>> {
    const maintenanceTemplate =
      await this.maintenanceTemplateRepository.findOneWithPopulate(
        { _id: id },
        {
          path: 'details.checklistTemplate',
        },
      );

    if (!maintenanceTemplate) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!isEmpty(maintenanceTemplate?.fileIds)) {
      const fileInfos = await this.fileService.getFileInfoByIds(
        maintenanceTemplate?.fileIds,
      );
      maintenanceTemplate['fileUrls'] = fileInfos.map((file) => ({
        ...file,
        fileUrl: this.fileUri + file?.id,
      }));
    }
    const dataReturn = plainToInstance(
      GetMaintenanceTemplateResponseDto,
      maintenanceTemplate,
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const dataToInsert = [];
    const dataToUpdate = [];
    const codesUpdate = [];

    const textAdd = await this.i18n.translate('import.common.add');
    const codePrefix = MAINTENANCE_TEMPLATE_CONST.CODE.PREFIX;
    const lastRecord = await this.maintenanceTemplateRepository.lastRecord();
    const codeCurrent = getCurrentCodeByLastRecord(codePrefix, lastRecord);
    let checklistTemplateCodes = [];

    data.forEach((item, index) => {
      checklistTemplateCodes = checklistTemplateCodes.concat(
        map(item.details, 'checklistTemplateCode'),
      );
      if (item.action === textAdd) {
        item.code = generateCodeByPreviousCode(
          codePrefix,
          plus(codeCurrent, index),
        );
        dataToInsert.push(item);
      } else {
        dataToUpdate.push(item);
        codesUpdate.push(item.code);
      }
    });

    const checklistTemplateExists =
      await this.checklistTemplateRepository.findAllByCondition({
        code: { $in: compact(uniq(checklistTemplateCodes)) },
      });
    const checklistTemplateMap = keyBy(checklistTemplateExists, 'code');

    const maintenanceTemplateCodeUpdateExists =
      await this.maintenanceTemplateRepository.findAllByCondition({
        code: { $in: codesUpdate },
      });
    const maintenanceTemplateUpdateMap = keyBy(
      maintenanceTemplateCodeUpdateExists,
      'code',
    );

    const dataError = [];
    const dataInsert = [];
    const dataUpdate = [];
    function checkChecklistTemplate(details: any[]) {
      let result = true;
      details.forEach((el) => {
        if (
          el.jobType === MAINTENANCE_JOB_TYPE.CHECK &&
          !has(checklistTemplateMap, el.checklistTemplateCode)
        ) {
          result = false;
        }
      });
      return result;
    }
    dataToInsert.forEach((item) => {
      if (!checkChecklistTemplate(item.details ?? [])) {
        dataError.push(item);
      } else {
        dataInsert.push(item);
      }
    });
    dataToUpdate.forEach((item) => {
      if (
        !has(maintenanceTemplateUpdateMap, item.code) ||
        !checkChecklistTemplate(item.details ?? [])
      ) {
        dataError.push(item);
      } else {
        dataUpdate.push(item);
      }
    });

    const bulkOps = [...dataInsert, ...dataUpdate].map((item) => ({
      updateOne: {
        filter: {
          code: item.code,
        },
        update: {
          code: item.code,
          name: item.name,
          description: item.description,
          details: item.details?.map((el) => ({
            title: el.title,
            type: el.jobType,
            description: el.description,
            periodTime: el.periodTime,
            activeTime: el.activeTime,
            timeUnit: el.timeUnit,
            obligatory: el.obligatory,
            checklistTemplateId:
              checklistTemplateMap[el.checklistTemplateCode]?._id,
          })),
        },
        upsert: true,
      },
    }));
    const dataSuccess = await this.maintenanceTemplateRepository.bulkWrite(
      bulkOps,
    );
    return { dataError, dataSuccess };
  }
}
