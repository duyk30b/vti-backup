import { CODE_REGEX } from '@constant/common';

export enum MAINTENANCE_PERIOD_UNIT {
  DAY,
  MONTH,
  YEAR,
}

export enum MAINTENANCE_JOB_TYPE {
  CHECK,
  MAINTENANCE,
  ACCREDITATION,
}

export const MAINTENANCE_TEMPLATE_CONST = {
  CODE: {
    MAX_LENGTH: 20,
    MIN_LENGTH: 6,
    COLUMN: 'code',
    REGEX: CODE_REGEX,
    PREFIX: 'HDBT',
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
  PERIOD_TIME: {
    MIN: 1,
    COLUMN: 'periodTime',
  },
  TITLE: {
    MAX_LENGTH: 255,
    COLUMN: 'title',
  },
};
