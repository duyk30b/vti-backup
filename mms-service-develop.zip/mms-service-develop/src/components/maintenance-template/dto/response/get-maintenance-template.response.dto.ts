import { DetailCheckListTemplateResponseDto } from '@components/checklist-template/dto/response/detail-checklist-template.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { FileUrlResponseDto } from '@utils/dto/response/file-url.response.dto';
import { Expose, Type } from 'class-transformer';

export class MaintenanceTemplateDetailDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  title: string;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  periodTime: number;

  @ApiProperty()
  @Expose()
  activeTime: number;

  @ApiProperty()
  @Expose()
  timeUnit: number;

  @ApiProperty()
  @Expose()
  obligatory: number;

  @ApiProperty({ type: DetailCheckListTemplateResponseDto })
  @Expose()
  @Type(() => DetailCheckListTemplateResponseDto)
  checklistTemplate: DetailCheckListTemplateResponseDto;
}

export class GetMaintenanceTemplateResponseDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  active: number;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty({
    type: FileUrlResponseDto,
    isArray: true,
  })
  @Expose()
  @Type(() => FileUrlResponseDto)
  fileUrls: FileUrlResponseDto[];

  @ApiProperty({ type: MaintenanceTemplateDetailDto, isArray: true })
  @Type(() => MaintenanceTemplateDetailDto)
  @Expose()
  details: MaintenanceTemplateDetailDto[];
}
