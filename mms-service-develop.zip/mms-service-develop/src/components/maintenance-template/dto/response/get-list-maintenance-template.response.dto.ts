import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { Expose } from 'class-transformer';

export class GetListMaintenanceTemplateResponseDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  active: number;

  @ApiProperty()
  @Expose()
  description: string;
}
