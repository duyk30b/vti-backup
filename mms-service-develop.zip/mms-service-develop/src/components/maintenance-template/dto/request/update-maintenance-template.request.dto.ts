import { ApiProperty } from '@nestjs/swagger';
import { FileUrlParamDto } from '@utils/dto/request/file-url.request.dto';
import { Transform, Type } from 'class-transformer';
import { IsOptional, ValidateNested } from 'class-validator';
import { CreateMaintenanceTemplateRequestDto } from './create-maintenance-template.request.dto';

export class UpdateMaintenanceTemplateRequestDto extends CreateMaintenanceTemplateRequestDto {
  @ApiProperty()
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => FileUrlParamDto)
  @Transform(({ value }) => JSON.parse(value))
  fileUrls: FileUrlParamDto[];
}
