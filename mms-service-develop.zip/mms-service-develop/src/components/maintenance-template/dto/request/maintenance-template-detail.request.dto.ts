import { DEVICE_STATUS_CONST } from '@components/device-status/device-status.constant';
import {
  MAINTENANCE_JOB_TYPE,
  MAINTENANCE_PERIOD_UNIT,
  MAINTENANCE_TEMPLATE_CONST,
} from '@components/maintenance-template/maintenance-template.constant';
import { OBLIGATORY_ENUM } from '@constant/common';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsEnum,
  IsInt,
  IsMongoId,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  Min,
  ValidateIf,
} from 'class-validator';

export class MaintenanceTemplateDetailRequestDto {
  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  id: string;

  @ApiProperty()
  @MaxLength(MAINTENANCE_TEMPLATE_CONST.TITLE.MAX_LENGTH)
  @IsString()
  @IsNotEmpty()
  title: string;

  @ApiProperty()
  @IsEnum(MAINTENANCE_JOB_TYPE)
  @IsInt()
  @IsNotEmpty()
  type: number;

  @ApiPropertyOptional()
  @MaxLength(MAINTENANCE_TEMPLATE_CONST.DESCRIPTION.MAX_LENGTH)
  @IsString()
  @IsOptional()
  description: string;

  @ValidateIf((obj) => obj.type === MAINTENANCE_JOB_TYPE.CHECK)
  @ApiPropertyOptional()
  @IsMongoId()
  @IsNotEmpty()
  checklistTemplateId: string;

  @ApiProperty()
  @Min(MAINTENANCE_TEMPLATE_CONST.PERIOD_TIME.MIN)
  @IsInt()
  @IsNotEmpty()
  periodTime: number;

  @ApiProperty()
  @Min(DEVICE_STATUS_CONST.ACTIVE_TIME.MIN)
  @IsNumber()
  @IsNotEmpty()
  activeTime: number;

  @ApiProperty()
  @IsEnum(MAINTENANCE_PERIOD_UNIT)
  @IsInt()
  @IsNotEmpty()
  timeUnit: number;

  @ApiProperty()
  @IsEnum(OBLIGATORY_ENUM)
  @IsInt()
  @IsNotEmpty()
  obligatory: number;
}
