import { MAINTENANCE_TEMPLATE_CONST } from '@components/maintenance-template/maintenance-template.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { MIME_TYPES_FOR_TEMPLATE } from '@utils/constant';
import { plainToClass, Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import { IsNotBlank } from 'src/validator/is-not-blank.validator';
import { MaintenanceTemplateDetailRequestDto } from './maintenance-template-detail.request.dto';

export class DataBodyMaintenanceTemplate extends BaseDto {
  code: string;

  @ApiProperty()
  @MaxLength(MAINTENANCE_TEMPLATE_CONST.NAME.MAX_LENGTH)
  @IsNotEmpty()
  @IsNotBlank()
  @IsString()
  name: string;

  @ApiPropertyOptional()
  @MaxLength(MAINTENANCE_TEMPLATE_CONST.DESCRIPTION.MAX_LENGTH)
  @IsString()
  @IsOptional()
  description: string;

  fileIds: string[];

  @ApiProperty({
    type: MaintenanceTemplateDetailRequestDto,
    isArray: true,
    description: 'Chi tiết',
  })
  @ArrayUnique((e: MaintenanceTemplateDetailRequestDto) => e.title)
  @ValidateNested({ each: true })
  @Type(() => MaintenanceTemplateDetailRequestDto)
  @ArrayNotEmpty()
  @IsArray()
  @IsNotEmpty()
  details: MaintenanceTemplateDetailRequestDto[];
}

export class File {
  filename: string;
  data: ArrayBuffer;
  encoding: string;
  @IsEnum(MIME_TYPES_FOR_TEMPLATE, { message: 'MIMETYPE_NOT_ACCEPT' })
  mimetype: string;
  limit: boolean;
}
export class CreateMaintenanceTemplateRequestDto extends BaseDto {
  @ApiProperty({ type: DataBodyMaintenanceTemplate })
  @Type(() => DataBodyMaintenanceTemplate)
  @Transform(({ value }) =>
    plainToClass(DataBodyMaintenanceTemplate, JSON.parse(value)),
  )
  @ValidateNested({ each: true })
  @IsNotEmpty()
  data: DataBodyMaintenanceTemplate;

  @ApiProperty()
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => File)
  files: File[];
}
