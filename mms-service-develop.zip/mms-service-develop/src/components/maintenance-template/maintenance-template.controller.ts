import { ACTIVE_ENUM } from '@constant/common';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  Body,
  Controller,
  Get,
  Inject,
  Injectable,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import {
  CREATE_DEVICE_PERMISSION,
  UPDATE_DEVICE_PERMISSION,
} from '@utils/permissions/device';
import {
  CREATE_DEVICE_GROUP_PERMISSION,
  UPDATE_DEVICE_GROUP_PERMISSION,
} from '@utils/permissions/device-group';
import {
  CREATE_MAINTENANCE_TEMPLATE_PERMISSION,
  DETAIL_MAINTENANCE_TEMPLATE_PERMISSION,
  LIST_MAINTENANCE_TEMPLATE_PERMISSION,
  UPDATE_MAINTENANCE_TEMPLATE_PERMISSION,
  UPDATE_STATUS_MAINTENANCE_TEMPLATE_PERMISSION,
} from '@utils/permissions/maintenance-template';
import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateMaintenanceTemplateRequestDto } from './dto/request/create-maintenance-template.request.dto';
import { GetListMaintenanceTemplateRequestDto } from './dto/request/get-list-maintenance-template.request.dto';
import { UpdateMaintenanceTemplateRequestDto } from './dto/request/update-maintenance-template.request.dto';
import { GetListMaintenanceTemplateResponseDto } from './dto/response/get-list-maintenance-template.response.dto';
import { GetMaintenanceTemplateResponseDto } from './dto/response/get-maintenance-template.response.dto';
import { MaintenanceTemplateServiceInterface } from './interface/maintenance-template.service.interface';

@Injectable()
@Controller('maintenance-templates')
export class MaintenanceTemplateController {
  constructor(
    @Inject('MaintenanceTemplateServiceInterface')
    private readonly maintenanceTemplateService: MaintenanceTemplateServiceInterface,
  ) {}

  @PermissionCode(CREATE_MAINTENANCE_TEMPLATE_PERMISSION.code)
  @Post('/')
  @ApiOperation({
    tags: ['Maintenance Template'],
    summary: 'Create Maintenance Template',
    description: 'Create Maintenance Template',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async create(
    @Body() payload: CreateMaintenanceTemplateRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.maintenanceTemplateService.create(request);
  }

  @PermissionCode(UPDATE_MAINTENANCE_TEMPLATE_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Maintenance Template'],
    summary: 'Update Maintenance Template',
    description: 'Update Maintenance Template',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async update(
    @Param() params: IdParamDto,
    @Body() payload: UpdateMaintenanceTemplateRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    const { request: parameter, responseError: responseErrorParam } = params;

    if (
      (responseError && !isEmpty(responseError)) ||
      (responseErrorParam && !isEmpty(responseErrorParam))
    ) {
      return responseError || responseErrorParam;
    }

    return this.maintenanceTemplateService.update({
      id: parameter.id,
      ...request,
    });
  }

  @PermissionCode(UPDATE_STATUS_MAINTENANCE_TEMPLATE_PERMISSION.code)
  @Put('/:id/active')
  @ApiOperation({
    tags: ['Maintenance Template'],
    summary: 'Active maintenance template',
    description: 'Active maintenance template',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async active(@Param() param: IdParamDto): Promise<ResponsePayload<any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenanceTemplateService.updateActiveStatus({
      ...request,
      status: ACTIVE_ENUM.ACTIVE,
    });
  }

  @PermissionCode(UPDATE_STATUS_MAINTENANCE_TEMPLATE_PERMISSION.code)
  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Maintenance Template'],
    summary: 'Inactive maintenance template',
    description: 'Inactive maintenance template',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async inactive(@Param() param: IdParamDto): Promise<ResponsePayload<any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.maintenanceTemplateService.updateActiveStatus({
      ...request,
      status: ACTIVE_ENUM.INACTIVE,
    });
  }

  @PermissionCode(
    LIST_MAINTENANCE_TEMPLATE_PERMISSION.code,
    CREATE_DEVICE_PERMISSION.code,
    UPDATE_DEVICE_PERMISSION.code,
    CREATE_DEVICE_GROUP_PERMISSION.code,
    UPDATE_DEVICE_GROUP_PERMISSION.code,
  )
  @Get('/')
  @ApiOperation({
    tags: ['Maintenance Template'],
    summary: 'List maintenance template',
    description: 'List maintenance template',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetListMaintenanceTemplateResponseDto,
  })
  async list(
    @Query() payload: GetListMaintenanceTemplateRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.maintenanceTemplateService.list(request);
  }

  @PermissionCode(
    DETAIL_MAINTENANCE_TEMPLATE_PERMISSION.code,
    UPDATE_MAINTENANCE_TEMPLATE_PERMISSION.code,
  )
  @Get('/:id')
  @ApiOperation({
    tags: ['Maintenance Template'],
    summary: 'Detail maintenance template',
    description: 'Detail maintenance template',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetMaintenanceTemplateResponseDto,
  })
  async detail(@Param('id') id: string) {
    return this.maintenanceTemplateService.detail(id);
  }
}
