import { FileModule } from '@components/file/file.module';
import { SettingModule } from '@components/setting/setting.module';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ChecklistTemplateSchema } from 'src/models/checklist-template/checklist-template.schema';
import { DeviceTemplateScheduleSchema } from 'src/models/device-template-schedule/device-template-schedule.schema';
import { DeviceSchema } from 'src/models/device/device.schema';
import { MaintenanceTemplateSchema } from 'src/models/maintenance-template/maintenance-template.schema';
import { CheckListTemplateRepository } from 'src/repository/checklist-template/checklist-template.repository';
import { DeviceTemplateScheduleRepository } from 'src/repository/device-template-schedule/device-template-schedule.repository';
import { DeviceRepository } from 'src/repository/device/device.repository';
import { MaintenanceTemplateRepository } from 'src/repository/maintenance-template/maintenance-template.repository';
import { MaintenanceTemplateController } from './maintenance-template.controller';
import { MaintenanceTemplateService } from './maintenance-template.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'MaintenanceTemplate', schema: MaintenanceTemplateSchema },
      { name: 'CheckListTemplate', schema: ChecklistTemplateSchema },
      { name: 'Device', schema: DeviceSchema },
      { name: 'DeviceTemplateSchedule', schema: DeviceTemplateScheduleSchema },
    ]),
    SettingModule,
    FileModule,
  ],
  controllers: [MaintenanceTemplateController],
  providers: [
    {
      provide: 'MaintenanceTemplateRepositoryInterface',
      useClass: MaintenanceTemplateRepository,
    },
    {
      provide: 'DeviceTemplateScheduleRepositoryInterface',
      useClass: DeviceTemplateScheduleRepository,
    },
    {
      provide: 'DeviceRepositoryInterface',
      useClass: DeviceRepository,
    },
    {
      provide: 'ChecklistTemplateRepositoryInterface',
      useClass: CheckListTemplateRepository,
    },
    {
      provide: 'MaintenanceTemplateServiceInterface',
      useClass: MaintenanceTemplateService,
    },
  ],
  exports: [
    {
      provide: 'MaintenanceTemplateRepositoryInterface',
      useClass: MaintenanceTemplateRepository,
    },
    {
      provide: 'MaintenanceTemplateServiceInterface',
      useClass: MaintenanceTemplateService,
    },
  ],
})
export class MaintenanceTemplateModule {}
