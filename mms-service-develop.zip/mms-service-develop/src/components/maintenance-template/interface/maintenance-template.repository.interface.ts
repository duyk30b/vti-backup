import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { MaintenanceTemplate } from 'src/models/maintenance-template/maintenance-template.model';
import { DataBodyMaintenanceTemplate } from '../dto/request/create-maintenance-template.request.dto';
import { GetListMaintenanceTemplateRequestDto } from '../dto/request/get-list-maintenance-template.request.dto';

export interface MaintenanceTemplateRepositoryInterface
  extends BaseInterfaceRepository<MaintenanceTemplate> {
  createEntity(payload: DataBodyMaintenanceTemplate): MaintenanceTemplate;
  updateEntity(
    entity: MaintenanceTemplate,
    payload: DataBodyMaintenanceTemplate,
  ): MaintenanceTemplate;
  list(request: GetListMaintenanceTemplateRequestDto): Promise<any>;
  list(request: GetListMaintenanceTemplateRequestDto): Promise<any>;
  getTemplateScheduleByTemplate(id: string): Promise<any>;
}
