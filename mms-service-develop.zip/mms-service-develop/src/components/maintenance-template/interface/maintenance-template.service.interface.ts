import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreateMaintenanceTemplateRequestDto } from '../dto/request/create-maintenance-template.request.dto';
import { GetListMaintenanceTemplateRequestDto } from '../dto/request/get-list-maintenance-template.request.dto';
import { UpdateMaintenanceTemplateRequestDto } from '../dto/request/update-maintenance-template.request.dto';

export interface MaintenanceTemplateServiceInterface {
  create(
    payload: CreateMaintenanceTemplateRequestDto,
  ): Promise<ResponsePayload<any>>;
  update(
    request: UpdateMaintenanceTemplateRequestDto & IdParamDto,
  ): Promise<ResponsePayload<any>>;
  updateActiveStatus(
    payload: UpdateActiveStatusPayload,
  ): Promise<ResponsePayload<any>>;
  list(
    payload: GetListMaintenanceTemplateRequestDto,
  ): Promise<ResponsePayload<any>>;
  detail(id: string): Promise<ResponsePayload<any>>;
  import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }>;
}
