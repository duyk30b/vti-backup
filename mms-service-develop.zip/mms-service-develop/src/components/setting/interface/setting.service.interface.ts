import { JOB_TYPE_ENUM } from '@components/job/job.constant';
import { ResponsePayload } from '@utils/response-payload';
import { CreateSettingJobRequestDto } from '../dto/request/create-setting-job.request.dto';
import { CreateSettingSignatureRequestDto } from '../dto/request/create-setting-signature.request.dto';
import { DetailSettingJobParamDto } from '../dto/request/detail-setting-job.param.dto';
import { DetailSettingSignatureParamDto } from '../dto/request/detail-setting-signature.param.dto';
import { SETTING_JOB_PERIOD_ENUM } from '../setting.constant';

export interface SettingServiceInterface {
  createSettingSignature(
    request: CreateSettingSignatureRequestDto,
  ): Promise<ResponsePayload<any>>;
  detailByType(
    request: DetailSettingSignatureParamDto,
  ): Promise<ResponsePayload<any>>;
  createSettingJob(
    request: CreateSettingJobRequestDto,
  ): Promise<ResponsePayload<any>>;
  detailSettingJobByType(
    request: DetailSettingJobParamDto,
  ): Promise<ResponsePayload<any>>;

  getDateSetting(
    type: JOB_TYPE_ENUM,
    period: SETTING_JOB_PERIOD_ENUM,
  ): Promise<number>;
}
