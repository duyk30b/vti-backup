import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { SettingSignature } from 'src/models/setting-signature/setting-signature.model';

export interface SettingSignatureRepositoryInterface
  extends BaseAbstractRepository<SettingSignature> {
  createDocument(request: any): SettingSignature;
  updateDocument(request: any, entity: SettingSignature): SettingSignature;
}
