import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { SettingJob } from 'src/models/setting-job/setting-job.model';

export interface SettingJobRepositoryInterface
  extends BaseAbstractRepository<SettingJob> {
  createDocument(request: any): SettingJob;
}
