import { JOB_TYPE_ENUM } from '@components/job/job.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsEnum, IsNotEmpty } from 'class-validator';

export class DetailSettingJobParamDto extends BaseDto {
  @ApiProperty()
  @IsEnum(JOB_TYPE_ENUM)
  @Transform((data) => +data.value)
  @IsNotEmpty()
  type: number;
}
