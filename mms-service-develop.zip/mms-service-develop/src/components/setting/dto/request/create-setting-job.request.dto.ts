import { JOB_TYPE_ENUM } from '@components/job/job.constant';
import {
  SETTING_JOB_PERIOD_ENUM,
  AUTO_GENERATE_JOB_ON_SUNDAY,
} from '@components/setting/setting.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsPositive,
  IsString,
  ValidateNested,
} from 'class-validator';

class CreateSettingJobDetailRequestDto {
  @ApiProperty()
  @IsEnum(SETTING_JOB_PERIOD_ENUM)
  @Transform(({ value }) => +value)
  @IsNotEmpty()
  period: SETTING_JOB_PERIOD_ENUM;

  @ApiProperty()
  @IsPositive()
  @IsNotEmpty()
  beforeDate: number;
}
export class CreateSettingJobRequestDto extends BaseDto {
  @ApiProperty()
  @IsEnum(JOB_TYPE_ENUM)
  @Transform((data) => +data.value)
  @IsNotEmpty()
  type: number;

  @ApiProperty()
  @IsString()
  @IsOptional()
  description: string;

  @ApiProperty({ type: CreateSettingJobDetailRequestDto, isArray: true })
  @ArrayUnique<CreateSettingJobDetailRequestDto>(
    (item: CreateSettingJobDetailRequestDto) => item.period,
  )
  @ValidateNested({ each: true })
  @Type(() => CreateSettingJobDetailRequestDto)
  @ArrayNotEmpty()
  details: CreateSettingJobDetailRequestDto[];

  @ApiProperty()
  @IsEnum(AUTO_GENERATE_JOB_ON_SUNDAY)
  @IsNotEmpty()
  autoGenerateOnSunday: AUTO_GENERATE_JOB_ON_SUNDAY;
}
