import { SETTING_SIGNATURE_TYPE_ENUM } from '@components/setting/setting.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import { IsEnum, IsNotEmpty, IsString, ValidateNested } from 'class-validator';

class SignatureDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  role: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  name: string;
}
export class CreateSettingSignatureRequestDto extends BaseDto {
  @ApiProperty()
  @IsEnum(SETTING_SIGNATURE_TYPE_ENUM)
  @Transform((data) => parseInt(data.value))
  @IsNotEmpty()
  type: number;

  @ApiProperty({ type: SignatureDto, isArray: true })
  @Type(() => SignatureDto)
  @ValidateNested({ each: true })
  @IsNotEmpty()
  details: SignatureDto[];
}
