import { SETTING_SIGNATURE_TYPE_ENUM } from '@components/setting/setting.constant';
import { BaseDto } from '@core/dto/base.dto';
import { Transform } from 'class-transformer';
import { IsEnum, IsNotEmpty } from 'class-validator';

export class DetailSettingSignatureParamDto extends BaseDto {
  @IsEnum(SETTING_SIGNATURE_TYPE_ENUM)
  @Transform((data) => parseInt(data.value))
  @IsNotEmpty()
  type: number;
}
