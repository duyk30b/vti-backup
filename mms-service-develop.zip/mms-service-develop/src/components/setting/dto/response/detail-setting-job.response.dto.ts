import {
  AUTO_GENERATE_JOB_ON_SUNDAY,
  SETTING_JOB_PERIOD_ENUM,
} from '@components/setting/setting.constant';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class SettingJobDetail {
  @ApiProperty()
  @Expose()
  period: SETTING_JOB_PERIOD_ENUM;

  @ApiProperty()
  @Expose()
  isNotification: boolean;

  @ApiProperty()
  @Expose()
  isWarning: boolean;

  @ApiProperty()
  @Expose()
  isJob: boolean;

  @ApiProperty()
  @Expose()
  beforeDate: number;
}
export class DetailSettingJobResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty({ type: SettingJobDetail, isArray: true })
  @Type(() => SettingJobDetail)
  @Expose()
  details: SettingJobDetail[];

  @ApiProperty()
  @Expose()
  autoGenerateOnSunday: AUTO_GENERATE_JOB_ON_SUNDAY;
}
