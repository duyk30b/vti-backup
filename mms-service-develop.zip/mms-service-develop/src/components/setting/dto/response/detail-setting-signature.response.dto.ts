import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class SignatureDto {
  @ApiProperty()
  @Expose()
  role: string;

  @ApiProperty()
  @Expose()
  name: string;
}
export class DetailSettingSignatureResponseDto extends BaseResponseDto {
  @Expose()
  @ApiProperty()
  type: number;

  @ApiProperty({ type: SignatureDto, isArray: true })
  @Type(() => SignatureDto)
  @Expose()
  details: SignatureDto[];
}
