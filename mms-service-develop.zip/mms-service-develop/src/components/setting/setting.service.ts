import { JOB_TYPE_ENUM } from '@components/job/job.constant';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { CreateSettingJobRequestDto } from './dto/request/create-setting-job.request.dto';
import { CreateSettingSignatureRequestDto } from './dto/request/create-setting-signature.request.dto';
import { DetailSettingJobParamDto } from './dto/request/detail-setting-job.param.dto';
import { DetailSettingSignatureParamDto } from './dto/request/detail-setting-signature.param.dto';
import { DetailSettingJobResponseDto } from './dto/response/detail-setting-job.response.dto';
import { DetailSettingSignatureResponseDto } from './dto/response/detail-setting-signature.response.dto';
import { SettingJobRepositoryInterface } from './interface/setting-job.repository.interface';
import { SettingSignatureRepositoryInterface } from './interface/setting-signature.repository.interface';
import { SettingServiceInterface } from './interface/setting.service.interface';
import {
  SETTING_JOB_ACTION_ENUM,
  SETTING_JOB_PERIOD_ENUM,
} from './setting.constant';

@Injectable()
export class SettingService implements SettingServiceInterface {
  constructor(
    @Inject('SettingSignatureRepositoryInterface')
    private readonly settingSignatureRepository: SettingSignatureRepositoryInterface,

    @Inject('SettingJobRepositoryInterface')
    private readonly settingJobRepository: SettingJobRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async createSettingSignature(
    request: CreateSettingSignatureRequestDto,
  ): Promise<ResponsePayload<any>> {
    const settingSignature =
      await this.settingSignatureRepository.findOneByCondition({
        type: request.type,
      });

    if (settingSignature) {
      const settingSignatureEntity =
        this.settingSignatureRepository.updateDocument(
          request,
          settingSignature,
        );
      await this.settingSignatureRepository.updateById(
        settingSignature._id,
        settingSignatureEntity,
      );
    } else {
      const settingSignatureEntity =
        this.settingSignatureRepository.createDocument(request);
      await this.settingSignatureRepository.create(settingSignatureEntity);
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async detailByType(
    request: DetailSettingSignatureParamDto,
  ): Promise<ResponsePayload<any>> {
    const settingSignature =
      await this.settingSignatureRepository.findOneByCondition({
        type: request.type,
      });

    if (!settingSignature) {
      return new ResponseBuilder({})
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const dataReturn = plainToInstance(
      DetailSettingSignatureResponseDto,
      settingSignature,
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private mapPeriodToBoolean(
    period: SETTING_JOB_PERIOD_ENUM,
    action: SETTING_JOB_ACTION_ENUM,
  ) {
    switch (action) {
      case SETTING_JOB_ACTION_ENUM.IS_JOB:
        switch (period) {
          case SETTING_JOB_PERIOD_ENUM.LESS_THAN_THREE_MONTH:
            return true;
          case SETTING_JOB_PERIOD_ENUM.MORE_THAN_THREE_MONTH:
            return false;
          case SETTING_JOB_PERIOD_ENUM.ONE_DAY:
            return true;
          case SETTING_JOB_PERIOD_ENUM.OTHER:
            // @TODO
            return false;
          default:
            return false;
        }
      case SETTING_JOB_ACTION_ENUM.IS_NOTIFICATION:
        switch (period) {
          case SETTING_JOB_PERIOD_ENUM.LESS_THAN_THREE_MONTH:
            return true;
          case SETTING_JOB_PERIOD_ENUM.MORE_THAN_THREE_MONTH:
            return true;
          case SETTING_JOB_PERIOD_ENUM.ONE_DAY:
            return true;
          case SETTING_JOB_PERIOD_ENUM.OTHER:
            // @TODO
            return true;
          default:
            return true;
        }
      case SETTING_JOB_ACTION_ENUM.IS_WARNING:
        switch (period) {
          case SETTING_JOB_PERIOD_ENUM.LESS_THAN_THREE_MONTH:
            return false;
          case SETTING_JOB_PERIOD_ENUM.MORE_THAN_THREE_MONTH:
            return true;
          case SETTING_JOB_PERIOD_ENUM.ONE_DAY:
            return false;
          case SETTING_JOB_PERIOD_ENUM.OTHER:
            // @TODO
            return false;
          default:
            return false;
        }
      default:
        return false;
    }
  }

  async createSettingJob(
    request: CreateSettingJobRequestDto,
  ): Promise<ResponsePayload<any>> {
    const settingJob = await this.settingJobRepository.findOneByCondition({
      type: request.type,
    });

    const dataSetting = {
      ...request,
      details: request.details.map((e) => ({
        period: e.period,
        isNotification: this.mapPeriodToBoolean(
          e.period,
          SETTING_JOB_ACTION_ENUM.IS_NOTIFICATION,
        ),
        isWarning: this.mapPeriodToBoolean(
          e.period,
          SETTING_JOB_ACTION_ENUM.IS_WARNING,
        ),
        isJob: this.mapPeriodToBoolean(
          e.period,
          SETTING_JOB_ACTION_ENUM.IS_JOB,
        ),
        beforeDate: e.beforeDate,
      })),
      autoGenerateOnSunday: request.autoGenerateOnSunday,
    };

    if (settingJob) {
      await this.settingJobRepository.findByIdAndUpdate(
        settingJob._id,
        dataSetting,
      );
    } else {
      const settingJobEntity =
        this.settingJobRepository.createDocument(dataSetting);
      await this.settingJobRepository.create(settingJobEntity);
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async detailSettingJobByType(
    request: DetailSettingJobParamDto,
  ): Promise<ResponsePayload<any>> {
    const settingJob = await this.settingJobRepository.findOneByCondition({
      type: request.type,
    });

    if (!settingJob) {
      return new ResponseBuilder({})
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const dataReturn = plainToInstance(
      DetailSettingJobResponseDto,
      settingJob,
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getDateSetting(type: JOB_TYPE_ENUM, period: SETTING_JOB_PERIOD_ENUM) {
    const setting = await this.settingJobRepository.findOneByCondition({
      type,
    });
    const result = setting?.details?.find((e) => e.period === period);

    return result?.beforeDate;
  }
}
