import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { SettingJobSchema } from 'src/models/setting-job/setting-job.schema';
import { SettingSignatureSchema } from 'src/models/setting-signature/setting-signature.schema';
import { SettingJobRepository } from 'src/repository/setting/setting-job.repository';
import { SettingSignatureRepository } from 'src/repository/setting/setting-signature.repository';
import { SettingController } from './setting.controller';
import { SettingService } from './setting.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'SettingSignature', schema: SettingSignatureSchema },
      { name: 'SettingJob', schema: SettingJobSchema },
    ]),
  ],
  controllers: [SettingController],
  providers: [
    {
      provide: 'SettingSignatureRepositoryInterface',
      useClass: SettingSignatureRepository,
    },
    {
      provide: 'SettingJobRepositoryInterface',
      useClass: SettingJobRepository,
    },
    {
      provide: 'SettingServiceInterface',
      useClass: SettingService,
    },
  ],
  exports: [
    MongooseModule,
    {
      provide: 'SettingSignatureRepositoryInterface',
      useClass: SettingSignatureRepository,
    },
    {
      provide: 'SettingJobRepositoryInterface',
      useClass: SettingJobRepository,
    },
    {
      provide: 'SettingServiceInterface',
      useClass: SettingService,
    },
  ],
})
export class SettingModule {}
