import { PermissionCode } from '@core/decorator/get-code.decorator';
import { Body, Controller, Get, Inject, Param, Post } from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import {
  CREATE_CONFIG_SIGNATURE_PERMISSION,
  DETAIL_CONFIG_SIGNATURE_PERMISSION,
} from '@utils/permissions/config-signature';
import {
  DETAIL_SETTING_JOB_PERMISSION,
  UPDATE_SETTING_JOB_PERMISSION,
} from '@utils/permissions/setting-job';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateSettingJobRequestDto } from './dto/request/create-setting-job.request.dto';
import { CreateSettingSignatureRequestDto } from './dto/request/create-setting-signature.request.dto';
import { DetailSettingJobParamDto } from './dto/request/detail-setting-job.param.dto';
import { DetailSettingSignatureParamDto } from './dto/request/detail-setting-signature.param.dto';
import { DetailSettingJobResponseDto } from './dto/response/detail-setting-job.response.dto';
import { DetailSettingSignatureResponseDto } from './dto/response/detail-setting-signature.response.dto';
import { SettingServiceInterface } from './interface/setting.service.interface';

@Controller('/setting')
export class SettingController {
  constructor(
    @Inject('SettingServiceInterface')
    private readonly settingService: SettingServiceInterface,
  ) {}

  @Post('/signature')
  @PermissionCode(CREATE_CONFIG_SIGNATURE_PERMISSION.code)
  @ApiOperation({
    tags: ['Setting'],
    summary: 'Tạo chữ ký',
    description: 'Tạo chữ ký',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async create(
    @Body() payload: CreateSettingSignatureRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.settingService.createSettingSignature(request);
  }

  @Get('/signature/:type')
  @PermissionCode(DETAIL_CONFIG_SIGNATURE_PERMISSION.code)
  @ApiOperation({
    tags: ['Setting'],
    summary: 'Chi tiết chữ ký',
    description: 'Chi tiết chữ ký',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailSettingSignatureResponseDto,
  })
  async detailByType(
    @Param() param: DetailSettingSignatureParamDto,
  ): Promise<any> {
    const { request, responseError } = param;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.settingService.detailByType(request);
  }

  @Post('/job')
  @PermissionCode(UPDATE_SETTING_JOB_PERMISSION.code)
  @ApiOperation({
    tags: ['Setting'],
    summary: 'Cài đặt công việc',
    description: 'Cài đặt công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async createSettingJob(
    @Body() payload: CreateSettingJobRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.settingService.createSettingJob(request);
  }

  @Get('/job/:type')
  @PermissionCode(DETAIL_SETTING_JOB_PERMISSION.code)
  @ApiOperation({
    tags: ['Setting'],
    summary: 'Chi tiết cài đặt công việc',
    description: 'Chi tiết cài đặt công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailSettingJobResponseDto,
  })
  async detailSettingJobByType(
    @Param() param: DetailSettingJobParamDto,
  ): Promise<any> {
    const { request, responseError } = param;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.settingService.detailSettingJobByType(request);
  }
}
