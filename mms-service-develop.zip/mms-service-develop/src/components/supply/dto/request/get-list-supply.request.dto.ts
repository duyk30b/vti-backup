import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';
export class GetListSupplyRequestDto extends PaginationQuery {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  isGetAll: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  queryIds: string;
}
