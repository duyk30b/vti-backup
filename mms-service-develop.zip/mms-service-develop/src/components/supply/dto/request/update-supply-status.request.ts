import { SUPPLY_CONST } from '@components/supply/supply.constant';
import { BaseDto } from '@core/dto/base.dto';
import { IsEnum, IsMongoId, IsNotEmpty } from 'class-validator';

export class UpdateSupplyActiveStatusPayload extends BaseDto {
  @IsNotEmpty()
  @IsMongoId()
  id: string;

  @IsNotEmpty()
  @IsEnum(SUPPLY_CONST.ACTIVE.ENUM)
  status: number;
}
