import { ApiProperty } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  Min,
  IsMongoId,
  IsEnum,
  IsInt,
} from 'class-validator';
import {
  SUPPLY_CONST,
  SUPPLY_TYPE_ENUM,
} from '@components/supply/supply.constant';
import { BaseDto } from '@core/dto/base.dto';
import { IsNotBlank } from 'src/validator/is-not-blank.validator';
export class CreateSupplyRequestDto extends BaseDto {
  code: string;

  @ApiProperty({ description: 'Tên của vật tư' })
  @IsString()
  @MaxLength(SUPPLY_CONST.NAME.MAX_LENGTH)
  @IsNotBlank()
  @IsNotEmpty()
  name: string;

  @ApiProperty({ description: 'Tên khác' })
  @IsString()
  @IsOptional()
  @MaxLength(SUPPLY_CONST.DESCRIPTION.MAX_LENGTH)
  nameOther: string;

  @ApiProperty({ description: 'Giá của vật tư' })
  @IsNumber()
  @Min(1)
  @IsNotEmpty()
  price: number;

  @ApiProperty({ description: 'Loại vật tư' })
  @IsEnum(SUPPLY_TYPE_ENUM)
  @IsNotEmpty()
  type: number;

  @ApiProperty({ description: 'id loại vtpt' })
  @IsMongoId()
  @IsNotEmpty()
  supplyTypeId: string;

  @ApiProperty({ description: 'Mô tả' })
  @IsString()
  @IsOptional()
  @MaxLength(SUPPLY_CONST.DESCRIPTION.MAX_LENGTH)
  description: string;

  @ApiProperty({ description: 'Mã của đơn vị tính' })
  @IsInt()
  @IsNotEmpty()
  unitId: number;

  @ApiProperty({ description: 'Mã của nhà máy' })
  @IsString()
  @IsMongoId()
  @IsNotEmpty()
  supplyGroupId: string;

  @IsString()
  @IsMongoId()
  @IsOptional()
  vendorId: string;
}
