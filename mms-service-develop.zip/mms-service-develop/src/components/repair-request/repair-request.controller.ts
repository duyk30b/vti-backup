import { PermissionCode } from '@core/decorator/get-code.decorator';
import { PermissionWithRoleInterceptor } from '@core/interceptors/permission-with-role.interceptor';
import { PermissionInterceptor } from '@core/interceptors/permission.interceptor';
import {
  Body,
  Controller,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
  UseInterceptors,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import {
  CREATE_REPAIR_REQUEST_PERMISSION,
  DETAIL_REPAIR_REQUEST_PERMISSION,
  LIST_REPAIR_REQUEST_PERMISSION,
  UPDATE_STATUS_REPAIR_REQUEST_PERMISSION,
} from '@utils/permissions/repair-request';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { ListRepairRequestQuery } from './dto/query/list-repair-request.query';
import { CreateRepairRequestRequestDto } from './dto/request/create-repair-request.request';
import { UpdateStatusRepairRequestRequestDto } from './dto/request/update-status-repair-request.request';
import { DetailRepairRequestResponse } from './dto/response/detail-repair-request.response';
import { ListRepairRequestResponse } from './dto/response/list-repair-request.response';
import { RepairRequestServiceInterface } from './interface/repair-request.service.interface';

@Controller('repair-requests')
export class RepairRequestController {
  constructor(
    @Inject('RepairRequestServiceInterface')
    private readonly repairRequestService: RepairRequestServiceInterface,
  ) {}

  @PermissionCode(CREATE_REPAIR_REQUEST_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Post()
  @ApiOperation({
    tags: ['Repair Request'],
    summary: 'Tạo yêu cầu sửa chữa đột xuất',
    description: 'Tạo yêu cầu sửa chữa đột xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async create(@Body() payload: CreateRepairRequestRequestDto): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.repairRequestService.create(request);
  }

  @PermissionCode(UPDATE_STATUS_REPAIR_REQUEST_PERMISSION.code)
  @UseInterceptors(PermissionWithRoleInterceptor)
  @Put('/:id/:action')
  @ApiOperation({
    tags: ['Repair Request'],
    summary: 'Thay đổi trạng thái yêu cầu sửa chữa đột xuất',
    description: 'Thay đổi trạng thái yêu cầu sửa chữa đột xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async changeStatus(
    @Param() payload: UpdateStatusRepairRequestRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.repairRequestService.changeStatus(request);
  }

  @PermissionCode(DETAIL_REPAIR_REQUEST_PERMISSION.code)
  @UseInterceptors(PermissionWithRoleInterceptor)
  @Get('/:id')
  @ApiOperation({
    tags: ['Repair Request'],
    summary: 'Chi tiết yêu cầu sửa chữa đột xuất',
    description: 'Chi tiết yêu cầu sửa chữa đột xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailRepairRequestResponse,
  })
  async detail(@Param() payload: IdParamDto): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.repairRequestService.detail(request);
  }

  @PermissionCode(LIST_REPAIR_REQUEST_PERMISSION.code)
  @UseInterceptors(PermissionWithRoleInterceptor)
  @Get()
  @ApiOperation({
    tags: ['Repair Request'],
    summary: 'Danh sách yêu cầu sửa chữa đột xuất',
    description: 'Danh sách yêu cầu sửa chữa đột xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListRepairRequestResponse,
  })
  async list(@Query() payload: ListRepairRequestQuery): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.repairRequestService.list(request);
  }
}
