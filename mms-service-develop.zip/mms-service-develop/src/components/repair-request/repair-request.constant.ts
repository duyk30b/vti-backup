import { CODE_REGEX } from '@constant/common';

export enum REPAIR_REQUEST_PRIORITY_ENUM {
  LOW,
  MEDIUM,
  HIGHT,
}

export const REPAIR_REQUEST_CONST = {
  DESCRIPTION: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
  CODE: {
    LENGTH: 20,
    COLUMN: 'code',
    REGEX: CODE_REGEX,
    PREFIX: 'YCSC',
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
};

export const REPAIR_REQUEST_CODE_PREFIX = 'M';

export const REPAIR_REQUEST_CODE_CONST = {
  MAX_LENGTH: 20,
  COLUMN: 'code',
  PAD_CHAR: '0',
  DEFAULT_CODE: '0',
};

export enum REPAIR_REQUEST_STATUS_ENUM {
  WAIT_CONFIRM,
  CONFIRMED,
  REJECT,
  IN_PROGRESS,
  COMPLETED,
  RESOLVED,
}

export const REPAIR_REQUEST_ACTION_CONFIRMED = 'confirmed';
export const REPAIR_REQUEST_ACTION_REJECTED = 'rejected';

export const REPAIR_REQUEST_ACTION = [
  REPAIR_REQUEST_ACTION_CONFIRMED,
  REPAIR_REQUEST_ACTION_REJECTED,
];

export enum REPAIR_REQUEST_EVENTS_ENUM {
  CREATED = 'repair-request.created',
  CONFIRMED = 'repair-request.confirmed',
  REJECTED = 'repair-request.rejected',
  LEADER_CREATE_JOB_REPAIR = 'repair-request.leader-create-job-repair',
  MEMBER_CREATE_JOB_REPAIR = 'repair-request.member-create-job-repair',
}
