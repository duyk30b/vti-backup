import { NotificationService } from '@components/notification/notification.service';
import { ConfigService } from '@config/config.service';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { DeviceAssignmentSchema } from 'src/models/device-assignment/device-assignment.schema';
import { ErrorTypeSchema } from 'src/models/error-type/error-type.schema';
import { JobSchema } from 'src/models/job/job.schema';
import { RepairRequestSchema } from 'src/models/repair-request/repair-request.schema';
import { DeviceAssignmentRepository } from 'src/repository/device-assignment/device-assignment.repository';
import { ErrorTypeRepository } from 'src/repository/error-type/error-type.repository';
import { JobRepository } from 'src/repository/job/job.repository';
import { RepairRequestRepository } from 'src/repository/repair-request/repair-request.repository';
import { RepairRequestNotificationListener } from './listeners/repair-request.notification.listener';
import { RepairRequestController } from './repair-request.controller';
import { RepairRequestService } from './repair-request.service';
import { MaintenanceTeamRepository } from 'src/repository/maintenance-team/maintenance-team.repository';
import { MaintenanceTeamSchema } from 'src/models/maintenance-team/maintenance-team.schema';
import { DeviceSchema } from 'src/models/device/device.schema';
import { DeviceRepository } from 'src/repository/device/device.repository';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: 'RepairRequest',
        schema: RepairRequestSchema,
      },
      {
        name: 'ErrorTypeModel',
        schema: ErrorTypeSchema,
      },
      {
        name: 'DeviceAssignment',
        schema: DeviceAssignmentSchema,
      },
      {
        name: 'Job',
        schema: JobSchema,
      },
      {
        name: 'MaintenanceTeam',
        schema: MaintenanceTeamSchema,
      },
      {
        name: 'Device',
        schema: DeviceSchema,
      },
    ]),
  ],
  controllers: [RepairRequestController],
  providers: [
    {
      provide: 'RepairRequestRepositoryInterface',
      useClass: RepairRequestRepository,
    },
    {
      provide: 'RepairRequestServiceInterface',
      useClass: RepairRequestService,
    },
    {
      provide: 'ErrorTypeRepositoryInterface',
      useClass: ErrorTypeRepository,
    },
    {
      provide: 'DeviceAssignmentRepositoryInterface',
      useClass: DeviceAssignmentRepository,
    },
    {
      provide: 'DeviceRepositoryInterface',
      useClass: DeviceRepository,
    },
    {
      provide: 'MaintenanceTeamRepositoryInterface',
      useClass: MaintenanceTeamRepository,
    },
    {
      provide: 'JobRepositoryInterface',
      useClass: JobRepository,
    },
    ConfigService,
    {
      provide: 'NotificationServiceInterface',
      useClass: NotificationService,
    },
    RepairRequestNotificationListener,
  ],
  exports: [
    MongooseModule,
    {
      provide: 'RepairRequestRepositoryInterface',
      useClass: RepairRequestRepository,
    },
    {
      provide: 'RepairRequestServiceInterface',
      useClass: RepairRequestService,
    },
  ],
})
export class RepairRequestModule {}
