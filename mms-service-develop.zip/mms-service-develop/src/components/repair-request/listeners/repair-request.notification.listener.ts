import { MaintenanceTeamRepositoryInterface } from '@components/maintenance-team/interface/maintenance-team.repository.interface';
import { MAINTENANCE_TEAM_ROLE } from '@components/maintenance-team/maintenance-team.constant';
import { PushNotificationRequestDto } from '@components/notification/dto/notification.request.dto';
import { NotificationEventInterface } from '@components/notification/interface/notification.event.interface';
import { NotificationServiceInterface } from '@components/notification/interface/notification.service.interface';
import {
  NOTIFICATION_ENTITY_ENUM,
  TYPE_NOTIFICATION_RENDER_ACTION_ENUM,
} from '@components/notification/notification.const';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { NotificationListenerAbstract } from '@core/abstracts/notification.listener.abstract';
import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { I18nService } from 'nestjs-i18n';
import { RepairRequestRepositoryInterface } from '../interface/repair-request.repository.interface';
import { REPAIR_REQUEST_EVENTS_ENUM } from '../repair-request.constant';

@Injectable()
export class RepairRequestNotificationListener extends NotificationListenerAbstract {
  constructor(
    @Inject('NotificationServiceInterface')
    protected readonly notificationService: NotificationServiceInterface,
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('RepairRequestRepositoryInterface')
    private readonly repairRequestRepository: RepairRequestRepositoryInterface,

    @Inject('MaintenanceTeamRepositoryInterface')
    private readonly maintenanceTeamRepository: MaintenanceTeamRepositoryInterface,

    private readonly i18n: I18nService,
  ) {
    super(notificationService);
  }

  @OnEvent(REPAIR_REQUEST_EVENTS_ENUM.CREATED)
  public async onCreateRepairRequest(event: NotificationEventInterface) {
    const notificationRequest = new PushNotificationRequestDto();
    const { id, fromUserId } = event;
    const user = await this.userService.getDetailUser(fromUserId);
    const { fullName, username } = user;
    const repairRequest =
      await this.repairRequestRepository.findOneWithPopulate(
        { _id: id },
        { path: 'device' },
      );
    notificationRequest.title = await this.i18n.translate(
      'message.defineRepairRequest.notification.createTitle',
    );
    notificationRequest.content = await this.i18n.translate(
      'message.defineRepairRequest.notification.createContent',
      {
        args: {
          username: fullName || username,
          deviceCode: repairRequest?.['device']?.code,
        },
      },
    );

    const maintenanceTeams =
      await this.maintenanceTeamRepository.findAllByCondition({
        deviceGroupIds: repairRequest?.['device']?.deviceGroupId,
        factoryId: repairRequest?.['device']?.factoryId,
        areaIds: repairRequest?.['device']?.areaId,
      });

    const userIds = maintenanceTeams.map(
      (el) =>
        el.members.find((m) => m.role === MAINTENANCE_TEAM_ROLE.LEADER).userId,
    );

    notificationRequest.action =
      // noti created thì action(điều hướng) sang xác nhận từ chối
      TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_CONFIRM_AND_REJECT;
    notificationRequest.payload = this.generatePayload(
      event,
      NOTIFICATION_ENTITY_ENUM.REPAIR_REQUEST_DETAIL,
    );
    notificationRequest.userIds = userIds;
    notificationRequest.createdBy = event.fromUserId;
    return [
      await super.sendAppNotification(notificationRequest),
      await super.sendWebNotification(notificationRequest),
    ];
  }

  @OnEvent(REPAIR_REQUEST_EVENTS_ENUM.REJECTED)
  public async onRejectRepairRequest(event: NotificationEventInterface) {
    const notificationRequest = new PushNotificationRequestDto();
    const { id, fromUserId } = event;
    const user = await this.userService.getDetailUser(fromUserId);
    const { fullName, username } = user;
    const repairRequest =
      await this.repairRequestRepository.findOneWithPopulate(
        { _id: id },
        {
          path: 'device',
        },
      );
    notificationRequest.title = await this.i18n.translate(
      'message.defineRepairRequest.notification.rejectTitle',
    );
    notificationRequest.content = await this.i18n.translate(
      'message.defineRepairRequest.notification.rejectContent',
      {
        args: {
          username: fullName || username,
          deviceCode: repairRequest['device']?.code,
        },
      },
    );

    notificationRequest.action =
      TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_VIEW;
    notificationRequest.payload = this.generatePayload(
      event,
      NOTIFICATION_ENTITY_ENUM.REPAIR_REQUEST_DETAIL,
    );
    notificationRequest.userIds = [repairRequest.requestedBy];
    notificationRequest.createdBy = event.fromUserId;

    return [
      await super.sendWebNotification(notificationRequest),
      await super.sendAppNotification(notificationRequest),
    ];
  }

  @OnEvent(REPAIR_REQUEST_EVENTS_ENUM.CONFIRMED)
  public async onConfirmRepairRequest(event: NotificationEventInterface) {
    const notificationRequest = new PushNotificationRequestDto();
    const { code } = event;
    const repairRequest =
      await this.repairRequestRepository.findOneWithPopulate(
        { code },
        {
          path: 'device',
        },
      );
    notificationRequest.title = await this.i18n.translate(
      'message.defineRepairRequest.notification.confirmTitle',
    );
    notificationRequest.content = await this.i18n.translate(
      'message.defineRepairRequest.notification.confirmContent',
      {
        args: {
          deviceCode: repairRequest['device']?.code,
        },
      },
    );

    notificationRequest.action =
      TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_VIEW;
    notificationRequest.payload = this.generatePayload(
      event,
      NOTIFICATION_ENTITY_ENUM.REPAIR_REQUEST_DETAIL,
    );

    notificationRequest.userIds = [repairRequest.requestedBy];
    notificationRequest.createdBy = event.fromUserId;
    return [
      await super.sendWebNotification(notificationRequest),
      await super.sendAppNotification(notificationRequest),
    ];
  }

  @OnEvent(REPAIR_REQUEST_EVENTS_ENUM.LEADER_CREATE_JOB_REPAIR)
  public async onJobRepairCreated(event: NotificationEventInterface) {
    const notificationRequest = new PushNotificationRequestDto();
    const { code } = event;
    const repairRequest =
      await this.repairRequestRepository.findOneWithPopulate(
        { code },
        {
          path: 'device',
        },
      );
    notificationRequest.title = await this.i18n.translate(
      'message.defineRepairRequest.notification.confirmTitle',
    );
    notificationRequest.content = await this.i18n.translate(
      'message.defineRepairRequest.notification.jobCreatedContent',
      {
        args: {
          deviceCode: repairRequest['device']?.code,
        },
      },
    );

    notificationRequest.action =
      TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_ASSIGNMENT;
    notificationRequest.payload = this.generatePayload(
      event,
      NOTIFICATION_ENTITY_ENUM.JOB_DETAIL,
    );
    const maintenanceTeams =
      await this.maintenanceTeamRepository.findAllByCondition({
        deviceGroupIds: repairRequest['device']?.deviceGroupId,
        areaIds: repairRequest['device']?.areaId,
        factoryId: repairRequest?.['device']?.factoryId,
      });

    const userIds = maintenanceTeams.map(
      (el) =>
        el.members.find((m) => m.role === MAINTENANCE_TEAM_ROLE.LEADER).userId,
    );
    notificationRequest.userIds = [...userIds];
    notificationRequest.createdBy = event.fromUserId;
    return [
      await super.sendWebNotification(notificationRequest),
      await super.sendAppNotification(notificationRequest),
    ];
  }

  @OnEvent(REPAIR_REQUEST_EVENTS_ENUM.MEMBER_CREATE_JOB_REPAIR)
  public async onJobRepairAssignment(event: NotificationEventInterface) {
    const notificationRequest = new PushNotificationRequestDto();
    const { code, fromUserId } = event;
    const repairRequest =
      await this.repairRequestRepository.findOneWithPopulate(
        { code },
        {
          path: 'device',
        },
      );
    notificationRequest.title = await this.i18n.translate(
      'message.defineRepairRequest.notification.confirmTitle',
    );
    notificationRequest.content = await this.i18n.translate(
      'message.defineRepairRequest.notification.jobAssignmentContent',
      {
        args: {
          deviceCode: repairRequest['device']?.code,
        },
      },
    );

    notificationRequest.payload = this.generatePayload(
      event,
      NOTIFICATION_ENTITY_ENUM.JOB_DETAIL,
    );
    notificationRequest.createdBy = event.fromUserId;

    const maintenanceTeams =
      await this.maintenanceTeamRepository.findAllByCondition({
        deviceGroupIds: repairRequest['device']?.deviceGroupId,
        areaIds: repairRequest['device']?.areaId,
        factoryId: repairRequest?.['device']?.factoryId,
      });
    const leaderIds = maintenanceTeams.map(
      (el) =>
        el.members.find((m) => m.role === MAINTENANCE_TEAM_ROLE.LEADER).userId,
    );
    const memberNotification = {
      ...notificationRequest,
      action: TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_CONFIRM_AND_REJECT,
      userIds: [fromUserId],
    };
    const leaderNotification = {
      ...notificationRequest,
      action: TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_VIEW,
      userIds: leaderIds,
    };

    return [
      await super.sendWebNotification(memberNotification),
      await super.sendAppNotification(memberNotification),
      await super.sendWebNotification(leaderNotification),
      await super.sendAppNotification(leaderNotification),
    ];
  }
}
