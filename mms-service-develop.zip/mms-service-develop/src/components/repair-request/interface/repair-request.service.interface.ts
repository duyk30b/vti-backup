import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { ListRepairRequestQuery } from '../dto/query/list-repair-request.query';
import { CreateRepairRequestRequestDto } from '../dto/request/create-repair-request.request';
import { UpdateStatusRepairRequestRequestDto } from '../dto/request/update-status-repair-request.request';

export interface RepairRequestServiceInterface {
  create(request: CreateRepairRequestRequestDto): Promise<ResponsePayload<any>>;
  changeStatus(
    request: UpdateStatusRepairRequestRequestDto,
  ): Promise<ResponsePayload<any>>;
  list(request: ListRepairRequestQuery): Promise<ResponsePayload<any>>;
  detail(request: IdParamDto): Promise<ResponsePayload<any>>;
}
