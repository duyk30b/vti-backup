import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { RepairRequest } from 'src/models/repair-request/repair-request.model';
import { ListRepairRequestQuery } from '../dto/query/list-repair-request.query';

export interface RepairRequestRepositoryInterface
  extends BaseInterfaceRepository<RepairRequest> {
  createEntity(data: any): Promise<RepairRequest>;
  list(request: ListRepairRequestQuery): Promise<any>;
}
