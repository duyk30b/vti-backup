import { IsEnum, IsMongoId, IsNotEmpty, IsString } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { REPAIR_REQUEST_ACTION } from '@components/repair-request/repair-request.constant';

export class UpdateStatusRepairRequestRequestDto extends BaseDto {
  @IsString()
  @IsNotEmpty()
  @IsMongoId()
  id: string;

  @IsEnum(REPAIR_REQUEST_ACTION)
  @IsNotEmpty()
  action: string;
}
