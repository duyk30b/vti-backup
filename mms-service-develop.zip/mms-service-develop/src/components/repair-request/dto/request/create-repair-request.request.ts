import { REPAIR_REQUEST_PRIORITY_ENUM } from '@components/repair-request/repair-request.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsEnum,
  IsMongoId,
  IsNotEmpty,
  IsOptional,
  IsString,
} from 'class-validator';

export class CreateRepairRequestRequestDto extends BaseDto {
  code: string;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  name: string;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  description: string;

  @ApiPropertyOptional()
  @IsEnum(REPAIR_REQUEST_PRIORITY_ENUM)
  @IsOptional()
  priority: REPAIR_REQUEST_PRIORITY_ENUM;

  @ApiPropertyOptional()
  @IsMongoId()
  @IsOptional()
  errorTypeId: string;

  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  deviceId: string;

  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  accreditationJobId: string;
}
