import { DeviceBasicResponseDto } from '@components/device/dto/response/device-basic.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { BasicUserResponseDto } from '@utils/dto/response/basic-user.response.dto';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { HistoryResponse } from '@utils/dto/response/history.response';
import { Expose, plainToInstance, Transform, Type } from 'class-transformer';
import { keyBy } from 'lodash';

class SupplyResponse {
  @ApiProperty()
  @Expose({ name: 'supplyId' })
  id: string;

  @ApiProperty()
  @Transform(({ obj }) => obj.supply?.name ?? '')
  @Expose()
  name: string;

  @ApiProperty()
  @Transform(({ obj }) => obj.supply?.code ?? '')
  @Expose()
  code: string;

  @ApiProperty()
  @Transform(({ obj }) => obj.supply?.nameOther ?? '')
  @Expose()
  nameOther: string;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  maintenanceType: number;
}

export class DeviceResponseDto extends DeviceBasicResponseDto {
  @ApiProperty()
  @Expose()
  model: string;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  area: BasicResponseDto;
}

export class DetailRepairRequestResponse extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  priority: number;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  executionTime: number;

  @ApiProperty()
  @Expose()
  stopTime: number;

  @ApiProperty({ type: SupplyResponse, isArray: true })
  @Transform(({ obj }) => {
    const supplyMap = keyBy(obj.listSupply, '_id');
    const supplies = obj.supplies?.map((e) => ({
      ...e,
      supplyId: e?.supplyId?.toString(),
      supplyName: supplyMap[e?.supplyId?.toString()]?.name,
      supplyCode: supplyMap[e?.supplyId?.toString()]?.code,
    }));
    return plainToInstance(SupplyResponse, supplies || [], {
      excludeExtraneousValues: true,
    });
  })
  @Expose()
  supplies: SupplyResponse[];

  @ApiProperty({ type: BasicUserResponseDto })
  @Type(() => BasicUserResponseDto)
  @Expose()
  requestedBy: BasicUserResponseDto;

  @ApiProperty({ type: BasicUserResponseDto })
  @Type(() => BasicUserResponseDto)
  @Expose()
  executedBy: BasicUserResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Expose()
  area: BasicResponseDto;

  @ApiProperty({
    type: BasicResponseDto,
  })
  @Type(() => BasicResponseDto)
  @Expose()
  errorType: BasicResponseDto;

  @ApiProperty({ type: DeviceResponseDto })
  @Type(() => DeviceResponseDto)
  @Expose()
  device: DeviceResponseDto;

  @ApiProperty({
    type: BasicResponseDto,
  })
  @Type(() => BasicResponseDto)
  @Expose()
  accreditationJob: BasicResponseDto;

  @ApiProperty({
    type: HistoryResponse,
    isArray: true,
  })
  @Type(() => HistoryResponse)
  @Transform((data) => {
    return data.value.sort((a, b) => b.createdAt - a.createdAt);
  })
  @Expose()
  histories: HistoryResponse[];
}
