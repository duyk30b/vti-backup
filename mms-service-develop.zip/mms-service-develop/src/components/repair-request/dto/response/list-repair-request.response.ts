import { DeviceBasicResponseDto } from '@components/device/dto/response/device-basic.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { Expose, plainToInstance, Transform, Type } from 'class-transformer';
import { first } from 'lodash';

class CreatedByResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  username: string;

  @ApiProperty()
  @Expose()
  fullName: string;
}

export class DeviceResponseDto extends DeviceBasicResponseDto {
  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Transform(({ obj }) =>
    plainToInstance(BasicResponseDto, first(obj?.area), {
      excludeExtraneousValues: true,
    }),
  )
  @Type(() => BasicResponseDto)
  area: BasicResponseDto;
}

export class ListRepairRequestResponse extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  priority: number;

  @ApiProperty({ type: CreatedByResponse })
  @Type(() => CreatedByResponse)
  @Expose()
  requestedBy: CreatedByResponse;

  @ApiProperty({ type: DeviceResponseDto })
  @Expose()
  @Transform(({ obj }) =>
    plainToInstance(DeviceResponseDto, first(obj?.device), {
      excludeExtraneousValues: true,
    }),
  )
  @Type(() => DeviceResponseDto)
  device: DeviceResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Transform(({ obj }) =>
    plainToInstance(BasicResponseDto, first(obj?.area), {
      excludeExtraneousValues: true,
    }),
  )
  @Expose()
  area: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Type(() => BasicResponseDto)
  @Transform(({ obj }) =>
    plainToInstance(BasicResponseDto, first(obj?.accreditationJob), {
      excludeExtraneousValues: true,
    }),
  )
  @Expose()
  accreditationJob: BasicResponseDto;

  @ApiProperty()
  @Expose()
  status: number;
}
