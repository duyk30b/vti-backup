import { DeviceRepositoryInterface } from '@components/device/interface/device.repository.interface';
import { ErrorTypeRepositoryInterface } from '@components/error-type/interface/error-type.repository.interface';
import { HISTORY_ACTION_ENUM } from '@components/history/history.constant';
import { JobRepositoryInterface } from '@components/job/interface/job.repository.interface';
import {
  JOB_STATUS_ENUM,
  JOB_TYPE_ENUM,
  RESULT_ENUM,
} from '@components/job/job.constant';
import { MaintenanceTeamRepositoryInterface } from '@components/maintenance-team/interface/maintenance-team.repository.interface';
import { MAINTENANCE_TEAM_ROLE } from '@components/maintenance-team/maintenance-team.constant';
import { EventRequestDto } from '@components/notification/dto/event.request.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ACTIVE_ENUM, ROLE } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { ApiError } from '@utils/api.error';
import { IS_ACTION_ENUM } from '@utils/constant';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { compact, keyBy } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { Device } from 'src/models/device/device.model';
import { ListRepairRequestQuery } from './dto/query/list-repair-request.query';
import { CreateRepairRequestRequestDto } from './dto/request/create-repair-request.request';
import { UpdateStatusRepairRequestRequestDto } from './dto/request/update-status-repair-request.request';
import { DetailRepairRequestResponse } from './dto/response/detail-repair-request.response';
import { ListRepairRequestResponse } from './dto/response/list-repair-request.response';
import { RepairRequestRepositoryInterface } from './interface/repair-request.repository.interface';
import { RepairRequestServiceInterface } from './interface/repair-request.service.interface';
import {
  REPAIR_REQUEST_ACTION_CONFIRMED,
  REPAIR_REQUEST_ACTION_REJECTED,
  REPAIR_REQUEST_CONST,
  REPAIR_REQUEST_EVENTS_ENUM,
  REPAIR_REQUEST_STATUS_ENUM,
} from './repair-request.constant';

@Injectable()
export class RepairRequestService implements RepairRequestServiceInterface {
  constructor(
    @Inject('RepairRequestRepositoryInterface')
    private readonly repairRequestRepository: RepairRequestRepositoryInterface,
    @Inject('ErrorTypeRepositoryInterface')
    private readonly errorTypeRepository: ErrorTypeRepositoryInterface,
    @Inject('JobRepositoryInterface')
    private readonly jobRepository: JobRepositoryInterface,
    @Inject('DeviceRepositoryInterface')
    private readonly deviceRepository: DeviceRepositoryInterface,
    @Inject('MaintenanceTeamRepositoryInterface')
    private readonly maintenanceTeamRepository: MaintenanceTeamRepositoryInterface,
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,
    private readonly eventEmitter: EventEmitter2,
    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(
    request: CreateRepairRequestRequestDto,
  ): Promise<ResponsePayload<any>> {
    const {
      user,
      errorTypeId,
      deviceId,
      accreditationJobId,
      permissionCondition,
    } = request;

    const device = await this.deviceRepository.findOneByCondition({
      _id: deviceId,
      areaId: { $ne: null },
      active: ACTIVE_ENUM.ACTIVE,
      ...permissionCondition,
    });

    const repairRequestExist =
      await this.repairRequestRepository.findOneByCondition({
        deviceId,
        status: {
          $in: [
            REPAIR_REQUEST_STATUS_ENUM.COMPLETED,
            REPAIR_REQUEST_STATUS_ENUM.CONFIRMED,
            REPAIR_REQUEST_STATUS_ENUM.IN_PROGRESS,
            REPAIR_REQUEST_STATUS_ENUM.WAIT_CONFIRM,
          ],
        },
      });
    if (repairRequestExist) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.REPAIR_REQUEST_UNFINISHED'),
        )
        .build();
    }
    if (!device) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.DEVICE_NOT_AREA'))
        .build();
    }
    if (errorTypeId) {
      const errorType = await this.errorTypeRepository.findOneById(errorTypeId);

      if (!errorType) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }
    }

    // validate job accreditation
    if (accreditationJobId) {
      const accreditationJob = await this.jobRepository.findOneByCondition({
        _id: accreditationJobId,
        deviceId,
        type: JOB_TYPE_ENUM.ACCREDITATION,
        status: {
          $in: [
            JOB_STATUS_ENUM.COMPLETED,
            JOB_STATUS_ENUM.IN_PROGRESS,
            JOB_STATUS_ENUM.RESOLVED,
          ],
        },
        'result.result': {
          $in: [RESULT_ENUM.FAILED, null],
        },
      });

      if (!accreditationJob) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.ACCREDITATION_JOB_NOT_SUITABLE'),
        ).toResponse();
      }
    }

    const histories = [
      {
        userId: request.userId,
        action: HISTORY_ACTION_ENUM.CREATE,
        content: await this.i18n
          .translate('text.createRepairRequestName')
          .replace('{username}', user.username),
        status: REPAIR_REQUEST_STATUS_ENUM.WAIT_CONFIRM,
      },
    ];

    request.code = await this.repairRequestRepository.generateNextCodeWithYear(
      REPAIR_REQUEST_CONST.CODE.PREFIX,
    );
    const unexpectedRepairRequestDocument =
      await this.repairRequestRepository.createEntity({
        ...request,
        histories,
        areaId: device.areaId,
        deviceId: deviceId,
        requestedBy: request.user.id,
      });

    const unexpectedRepairRequest = await this.repairRequestRepository.create(
      unexpectedRepairRequestDocument,
    );

    this.eventEmitter.emit(
      REPAIR_REQUEST_EVENTS_ENUM.CREATED,
      new EventRequestDto({
        id: unexpectedRepairRequest._id,
        code: device.code,
        name: '',
        fromUserId: request.user.id,
      }),
    );

    return new ResponseBuilder(unexpectedRepairRequest)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async changeStatus(
    request: UpdateStatusRepairRequestRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { user } = request;
    const repairRequest =
      await this.repairRequestRepository.findOneWithPopulate(
        { _id: request.id },
        { path: 'device' },
      );
    if (!repairRequest) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const device = repairRequest.device;
    const isAcceptable = this.checkPermission(user, device);
    if (!isAcceptable) {
      return new ApiError(
        ResponseCodeEnum.NOT_ACCEPTABLE,
        await this.i18n.translate('error.NOT_ACCEPTABLE'),
      ).toResponse();
    }

    let status = this.getUnexpectedRepairRequestStatusByAction(request.action);

    const isStatusValid = this.checkStatusValid(repairRequest.status, status);
    if (!isStatusValid) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.DEVICE_ASSIGNMENT_STATUS_INVALID'),
        )
        .build();
    }
    if (status === REPAIR_REQUEST_STATUS_ENUM.CONFIRMED) {
      this.eventEmitter.emit(
        REPAIR_REQUEST_EVENTS_ENUM.CONFIRMED,
        new EventRequestDto({
          id: repairRequest._id,
          code: repairRequest.code,
          name: '',
          fromUserId: request.user.id,
        }),
      );
      status = await this.createRepairJob(repairRequest, request.user);
    } else if (status === REPAIR_REQUEST_STATUS_ENUM.REJECT) {
      this.eventEmitter.emit(
        REPAIR_REQUEST_EVENTS_ENUM.REJECTED,
        new EventRequestDto({
          id: repairRequest._id,
          code: repairRequest.code,
          name: '',
          fromUserId: request.user.id,
        }),
      );
    }
    const text = new Map();
    text.set(
      REPAIR_REQUEST_STATUS_ENUM.CONFIRMED,
      await this.i18n.translate('text.REPAIR_REQUEST_STATUS_TEXT.CONFIRMED'),
    );
    text.set(
      REPAIR_REQUEST_STATUS_ENUM.REJECT,
      await this.i18n.translate('text.REPAIR_REQUEST_STATUS_TEXT.REJECT'),
    );
    text.set(
      REPAIR_REQUEST_STATUS_ENUM.IN_PROGRESS,
      await this.i18n.translate('text.REPAIR_REQUEST_STATUS_TEXT.IN_PROGRESS'),
    );
    text.set(
      REPAIR_REQUEST_STATUS_ENUM.COMPLETED,
      await this.i18n.translate('text.REPAIR_REQUEST_STATUS_TEXT.COMPLETED'),
    );
    text.set(
      REPAIR_REQUEST_STATUS_ENUM.RESOLVED,
      await this.i18n.translate('text.REPAIR_REQUEST_STATUS_TEXT.RESOLVED'),
    );

    const history = [
      {
        userId: request.userId,
        action:
          status === REPAIR_REQUEST_STATUS_ENUM.CONFIRMED
            ? HISTORY_ACTION_ENUM.CONFIRM
            : HISTORY_ACTION_ENUM.REJECT,
        content: await this.i18n
          .translate('text.statusRepairRequestName')
          .replace('{username}', request.user.username)
          .replace('{status}', text.get(status)),
        status,
        createdAt: new Date(),
      },
    ];

    await this.repairRequestRepository.findByIdAndUpdate(request.id, {
      status,
      $push: { histories: history },
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async list(request: ListRepairRequestQuery): Promise<ResponsePayload<any>> {
    const { user } = request;

    let conditions = [] as any;
    const myRequest = request.filter?.find(
      (e) => e.column === 'myRequest',
    )?.text;
    if (+myRequest !== IS_ACTION_ENUM.YES) {
      switch (user.role) {
        case ROLE.ADMIN:
          break;
        case ROLE.FACTORY_MANAGER:
          conditions = [
            {
              column: 'factoryIds',
              text: user?.factoryIds.toString(),
            },
          ];
          break;
        case ROLE.LEADER:
          conditions = [
            {
              column: 'deviceGroupIds',
              text: user.maintenanceTeam?.deviceGroupIds.toString(),
            },
            {
              column: 'deviceAreaIds',
              text: user.maintenanceTeam?.areaIds.toString(),
            },
          ];
          break;
        case ROLE.MEMBER:
          const userMe = user.maintenanceTeam?.members?.find(
            (e) => e.userId === user.id,
          );
          conditions = [
            {
              column: 'deviceGroupIds',
              text: userMe?.deviceGroupIds?.join(','),
            },
            {
              column: 'deviceAreaIds',
              text: userMe?.areaIds?.join(','),
            },
          ];
          break;
        default:
          conditions = [
            {
              column: 'myRequest',
              text: IS_ACTION_ENUM.YES,
            },
          ];
      }
    }
    request.filter = [...(request.filter ?? []), ...conditions];
    const { result, count } = await this.repairRequestRepository.list(request);

    const userIds = compact(result.map((e) => e.requestedBy));

    const users = await this.userService.getList([
      { column: 'userIds', text: userIds.join(',') },
    ]);

    const userMap = keyBy(users, 'id');

    result.forEach((e) => {
      e.requestedBy = userMap[e.requestedBy];
    });

    const dataReturn = plainToInstance(ListRepairRequestResponse, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PaginationResponse>({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private checkStatusValid(oldStatus: number, newStatus: number) {
    switch (newStatus) {
      case REPAIR_REQUEST_STATUS_ENUM.CONFIRMED:
        return oldStatus === REPAIR_REQUEST_STATUS_ENUM.WAIT_CONFIRM;
      case REPAIR_REQUEST_STATUS_ENUM.REJECT:
        return oldStatus !== REPAIR_REQUEST_STATUS_ENUM.CONFIRMED;
      default:
        return false;
    }
  }

  private getUnexpectedRepairRequestStatusByAction(action: string): number {
    switch (action) {
      case REPAIR_REQUEST_ACTION_CONFIRMED:
        return REPAIR_REQUEST_STATUS_ENUM.CONFIRMED;
      case REPAIR_REQUEST_ACTION_REJECTED:
        return REPAIR_REQUEST_STATUS_ENUM.REJECT;
      default:
        return REPAIR_REQUEST_STATUS_ENUM.WAIT_CONFIRM;
    }
  }

  private async createRepairJob(repairRequest: any, user: any): Promise<any> {
    const jobName = await this.i18n.translate('text.unexpectedRepairJobName');
    const systemName = await this.i18n.translate('text.SYSTEM_NAME');
    const messageCreatedJob = await this.i18n
      .translate('text.CREATED_JOB')
      .replace('{username}', systemName);

    const members =
      await this.maintenanceTeamRepository.getMemberByDeviceGroupAndArea(
        repairRequest.device?.deviceGroupId,
        repairRequest.device?.areaId,
      );
    const isMember = members?.find(
      (e) => e.userId === +user.id && e.role === MAINTENANCE_TEAM_ROLE.MEMBER,
    );
    let event: string;
    let status: number;
    let inprogressJobInfo: any = {};
    const histories: any[] = [
      {
        userId: user.id,
        action: HISTORY_ACTION_ENUM.CREATE,
        content: messageCreatedJob,
        status: JOB_STATUS_ENUM.NON_ASSIGN,
      },
    ];
    let repairRequestNewStatus = REPAIR_REQUEST_STATUS_ENUM.CONFIRMED;
    if (isMember) {
      event = REPAIR_REQUEST_EVENTS_ENUM.MEMBER_CREATE_JOB_REPAIR;
      status = JOB_STATUS_ENUM.IN_PROGRESS;
      const messageConfirmJob = await this.i18n
        .translate('text.userConfirmedJob')
        .replace('{username}', user.username);
      histories.push({
        userId: user.id,
        action: HISTORY_ACTION_ENUM.UPDATE,
        content: messageConfirmJob,
        status: JOB_STATUS_ENUM.IN_PROGRESS,
      });
      inprogressJobInfo = {
        assign: {
          teamId: user.maintenanceTeam._id,
          userId: user.id,
        },
        planFrom: new Date(),
        planTo: new Date(),
        isNeedAccept: false,
      };
      repairRequestNewStatus = REPAIR_REQUEST_STATUS_ENUM.IN_PROGRESS;
    } else {
      event = REPAIR_REQUEST_EVENTS_ENUM.LEADER_CREATE_JOB_REPAIR;
      status = JOB_STATUS_ENUM.NON_ASSIGN;
    }
    const jobDocuments = await this.jobRepository.createEntity({
      name: jobName.replace('{deviceName}', repairRequest.device?.name ?? ''),
      description: repairRequest?.description,
      status,
      type: JOB_TYPE_ENUM.UNEXPECTED_REPAIR,
      jobTypeId: repairRequest._id,
      ...inprogressJobInfo,
      histories,
      deviceId: repairRequest.device?._id,
      areaId: repairRequest.areaId,
    });

    const jobRepair = await this.jobRepository.create(jobDocuments);
    this.eventEmitter.emit(
      event,
      new EventRequestDto({
        id: jobRepair._id,
        code: repairRequest.code,
        name: '',
        entityType: JOB_TYPE_ENUM.UNEXPECTED_REPAIR,
        fromUserId: user.id,
      }),
    );
    return repairRequestNewStatus;
  }

  async detail(request: IdParamDto): Promise<ResponsePayload<any>> {
    const { user } = request;
    const repairRequest =
      await this.repairRequestRepository.findOneWithPopulate(
        {
          _id: request.id,
        },
        [
          { path: 'errorType accreditationJob supplies.supply' },
          {
            path: 'device',
            populate: 'area',
          },
        ],
      );

    if (!repairRequest) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const device = repairRequest.device;
    const isMyRequest = user.id === repairRequest.requestedBy;
    const isAcceptable = this.checkPermission(user, device) || isMyRequest;
    if (!isAcceptable) {
      return new ApiError(
        ResponseCodeEnum.NOT_ACCEPTABLE,
        await this.i18n.translate('error.NOT_ACCEPTABLE'),
      ).toResponse();
    }
    if (
      user?.role !== ROLE.ADMIN &&
      !user?.factoryIds?.includes(repairRequest.device?.factoryId)
    ) {
      return new ApiError(
        ResponseCodeEnum.NOT_ACCEPTABLE,
        await this.i18n.translate('error.NOT_ACCEPTABLE'),
      ).toResponse();
    }

    const requestedBy = await this.userService.getDetailUser(
      repairRequest.requestedBy,
    );

    repairRequest.requestedBy = requestedBy;

    if (repairRequest.executedBy) {
      const userExecute = await this.userService.getDetailUser(
        repairRequest.executedBy,
      );

      repairRequest.executedBy = userExecute;
    }

    const dataReturn = plainToInstance(
      DetailRepairRequestResponse,
      {
        ...repairRequest,
        stopTime: repairRequest.accreditationJob?.stopTime,
        executionTime: repairRequest.accreditationJob?.executionTime,
      },
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private checkPermission(user, device: Device) {
    let isAcceptable = false;
    switch (user.role) {
      case ROLE.ADMIN:
        isAcceptable = true;
        break;
      case ROLE.FACTORY_MANAGER:
        isAcceptable = user.factoryIds?.includes(device.factoryId);
        break;
      case ROLE.LEADER:
        // thiết bị có area and deviceGroup mà đội bảo trì quản lý
        isAcceptable =
          user.maintenanceTeam?.deviceGroupIds?.includes(
            device.deviceGroupId.toString(),
          ) &&
          user.maintenanceTeam?.areaIds?.includes(device.areaId.toString());
        break;
      case ROLE.MEMBER:
        // thiết bị có area and deviceGroup mà thành viên quản lý
        const userMe = user.maintenanceTeam?.members?.find(
          (e) => e.userId === user.id,
        );
        isAcceptable =
          userMe?.deviceGroupIds?.includes(device.deviceGroupId.toString()) &&
          userMe?.areaIds?.includes(device.areaId.toString());
        break;
      default:
        break;
    }
    return isAcceptable;
  }
}
