import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { CheckListTemplateDetailResponseDto } from '@components/checklist-template/dto/response/checklist-template-detail.response.dto';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { FileUrlResponseDto } from '@utils/dto/response/file-url.response.dto';

export class DetailCheckListTemplateResponseDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  active: number;

  @ApiProperty({
    type: FileUrlResponseDto,
    isArray: true,
  })
  @Expose()
  @Type(() => FileUrlResponseDto)
  fileUrls: FileUrlResponseDto[];

  @ApiProperty({
    type: CheckListTemplateDetailResponseDto,
    isArray: true,
  })
  @Expose()
  @Type(() => CheckListTemplateDetailResponseDto)
  details: CheckListTemplateDetailResponseDto[];
}
