import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString } from 'class-validator';
import { GET_ALL_ENUM } from '@constant/common';

export class GetListCheckListTemplateRequestDto extends PaginationQuery {
  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(GET_ALL_ENUM)
  isGetAll: number;

  @ApiPropertyOptional({
    example: '[{"id": "1"},{ "id": "2"}]',
  })
  @IsOptional()
  @IsString()
  queryIds?: string;
}
