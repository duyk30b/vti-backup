import { ApiProperty } from '@nestjs/swagger';
import {
  ArrayUnique,
  IsArray,
  IsEnum,
  IsMongoId,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import { plainToClass, Transform, Type } from 'class-transformer';
import { CHECKLIST_TEMPLATE_CONST } from '@components/checklist-template/checklist-template.constant';
import { BaseDto } from '@core/dto/base.dto';
import { OBLIGATORY_ENUM } from '@constant/common';
import { MIME_TYPES_FOR_TEMPLATE } from '@utils/constant';
import { IsNotBlank } from 'src/validator/is-not-blank.validator';

export class CheckListTemplateDetailRequestDto {
  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  id: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  @MaxLength(CHECKLIST_TEMPLATE_CONST.TITLE.MAX_LENGTH)
  title: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  @MaxLength(CHECKLIST_TEMPLATE_CONST.DESCRIPTION.MAX_LENGTH)
  description: string;

  @ApiProperty()
  @IsEnum(OBLIGATORY_ENUM)
  @IsOptional()
  obligatory: number;
}
export class DataBodyChecklistTemplate extends BaseDto {
  code: string;

  @ApiProperty({ description: 'Tên của mẫu phiếu báo cáo' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(CHECKLIST_TEMPLATE_CONST.NAME.MAX_LENGTH)
  @IsNotBlank()
  name: string;

  @ApiProperty({ description: 'Mô tả' })
  @IsOptional()
  @IsString()
  @MaxLength(CHECKLIST_TEMPLATE_CONST.DESCRIPTION.MAX_LENGTH)
  description: string;

  fileIds: string[];

  @ApiProperty({ description: 'Chi tiết' })
  @IsArray()
  @IsNotEmpty()
  @ValidateNested({ each: true })
  @ArrayUnique((e: CheckListTemplateDetailRequestDto) => e.title)
  @Type(() => CheckListTemplateDetailRequestDto)
  details: CheckListTemplateDetailRequestDto[];
}

export class File {
  filename: string;
  data: ArrayBuffer;
  encoding: string;
  @IsEnum(MIME_TYPES_FOR_TEMPLATE)
  mimetype: string;
  limit: boolean;
}
export class CreateCheckListTemplateRequestDto extends BaseDto {
  @ApiProperty({ type: DataBodyChecklistTemplate })
  @Type(() => DataBodyChecklistTemplate)
  @ValidateNested({ each: true })
  @Transform(({ value }) =>
    plainToClass(DataBodyChecklistTemplate, JSON.parse(value)),
  )
  @IsNotEmpty()
  data: DataBodyChecklistTemplate;

  @ApiProperty()
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => File)
  files: File[];
}
