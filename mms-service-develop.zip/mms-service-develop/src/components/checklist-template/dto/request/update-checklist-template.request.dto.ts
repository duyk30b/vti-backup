import { ApiProperty } from '@nestjs/swagger';
import { FileUrlParamDto } from '@utils/dto/request/file-url.request.dto';
import { Transform, Type } from 'class-transformer';
import {
  IsMongoId,
  IsNotEmpty,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';
import { CreateCheckListTemplateRequestDto } from './create-checklist-template.request.dto';

export class UpdateCheckListTemplateBody extends CreateCheckListTemplateRequestDto {
  @ApiProperty()
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => FileUrlParamDto)
  @Transform(({ value }) => JSON.parse(value))
  fileUrls: FileUrlParamDto[];
}

export class UpdateCheckListTemplateRequestDto extends UpdateCheckListTemplateBody {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @IsMongoId()
  id: string;
}
