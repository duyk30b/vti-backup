import { ACTIVE_ENUM } from '@constant/common';
import { ApiProperty } from '@nestjs/swagger';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { IsEnum, IsNotEmpty } from 'class-validator';

export class UpdateStatusChecklistTemplateRequest extends IdParamDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(ACTIVE_ENUM)
  active: number;
}
