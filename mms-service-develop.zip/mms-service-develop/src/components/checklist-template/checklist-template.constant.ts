import { CODE_REGEX } from '@constant/common';

export const CHECKLIST_TEMPLATE_CONST = {
  DESCRIPTION: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
  CODE: {
    MAX_LENGTH: 20,
    MIN_LENGTH: 6,
    COLUMN: 'code',
    REGEX: CODE_REGEX,
    PREFIX: 'KTDK',
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  TITLE: {
    MAX_LENGTH: 50,
    COLUMN: 'title',
  },
  DEVICE: {
    COLUMN: 'deviceId',
  },
  PERIOD_TIME: {
    MIN: 1,
  },
};
export enum CheckTypeEnum {
  PassFail,
}
export enum checklistResultEnum {
  Fail = 0,
  Pass = 1,
}
export const CHECK_LIST_TEMPLATE_NAME = 'check-list-template';
export const CHECK_LIST_TEMPLATE_HEADER = [
  {
    from: 'i',
  },
  {
    from: '_id',
  },
  {
    from: 'code',
  },
  {
    from: 'name',
  },
  {
    from: 'description',
  },
  {
    from: 'checkType',
  },
  {
    from: 'deviceName',
  },
  {
    from: 'details',
  },
  {
    from: 'createdAt',
  },
  {
    from: 'updatedAt',
  },
];
export const CHECK_LIST_TEMPLATE_DETAIL_HEADER = [
  {
    from: 'i',
  },
  {
    from: 'code',
  },
  {
    from: 'title',
  },
  {
    from: 'description',
  },
  {
    from: 'obligatory',
  },
];

export const CheckTypeImport = {
  'Pass-Fail': CheckTypeEnum.PassFail,
};
