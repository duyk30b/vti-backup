import { ResponsePayload } from '@utils/response-payload';
import { DetailCheckListTemplateResponseDto } from '@components/checklist-template/dto/response/detail-checklist-template.response.dto';
import { GetListCheckListTemplateRequestDto } from '@components/checklist-template/dto/request/get-list-checklist-template.request.dto';
import { UpdateCheckListTemplateRequestDto } from '@components/checklist-template/dto/request/update-checklist-template.request.dto';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateStatusChecklistTemplateRequest } from '../dto/request/update-status-checklist-template.request.dto';

export interface CheckListTemplateServiceInterface {
  detail(
    request: IdParamDto,
  ): Promise<ResponsePayload<DetailCheckListTemplateResponseDto | any>>;
  create(request: any): Promise<any>;
  getList(request: GetListCheckListTemplateRequestDto): Promise<any>;
  update(request: UpdateCheckListTemplateRequestDto): Promise<any>;
  updateStatus(
    request: UpdateStatusChecklistTemplateRequest,
  ): Promise<ResponsePayload<any>>;
  findOneByCode(code: string): Promise<any>;
  import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }>;
}
