import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { UserModule } from '@components/user/user.module';
import { CheckListTemplateController } from '@components/checklist-template/checklist-template.controller';
import { CheckListTemplateRepository } from 'src/repository/checklist-template/checklist-template.repository';
import { CheckListTemplateService } from '@components/checklist-template/checklist-template.service';
import { HistoryModule } from '@components/history/history.module';
import { ChecklistTemplateSchema } from 'src/models/checklist-template/checklist-template.schema';
import { FileModule } from '@components/file/file.module';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'CheckListTemplate', schema: ChecklistTemplateSchema },
    ]),
    UserModule,
    HistoryModule,
    FileModule,
  ],
  controllers: [CheckListTemplateController],
  providers: [
    {
      provide: 'CheckListTemplateRepositoryInterface',
      useClass: CheckListTemplateRepository,
    },
    {
      provide: 'CheckListTemplateServiceInterface',
      useClass: CheckListTemplateService,
    },
  ],
  exports: [MongooseModule],
})
export class CheckListTemplateModule {}
