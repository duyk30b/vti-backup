import { GetListCheckListTemplateResponseDto } from '@components/checklist-template/dto/response/get-all-checklist-template.response.dto';
import {
  Body,
  Param,
  Query,
  Controller,
  Inject,
  Injectable,
  Post,
  Put,
  Get,
} from '@nestjs/common';
import { CheckListTemplateServiceInterface } from '@components/checklist-template/interface/checklist-template.service.interface';
import { isEmpty } from 'lodash';
import { CreateCheckListTemplateRequestDto } from '@components/checklist-template/dto/request/create-checklist-template.request.dto';
import { GetListCheckListTemplateRequestDto } from '@components/checklist-template/dto/request/get-list-checklist-template.request.dto';

import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { ACTIVE_ENUM } from '@constant/common';
import { UpdateCheckListTemplateBody } from './dto/request/update-checklist-template.request.dto';
import { DetailCheckListTemplateResponseDto } from './dto/response/detail-checklist-template.response.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CREATE_CHECKLIST_TEMPLATE_PERMISSION,
  DETAIL_CHECKLIST_TEMPLATE_PERMISSION,
  LIST_CHECKLIST_TEMPLATE_PERMISSION,
  UPDATE_CHECKLIST_TEMPLATE_PERMISSION,
  UPDATE_STATUS_CHECKLIST_TEMPLATE_PERMISSION,
} from '@utils/permissions/checklist-template';
import {
  CREATE_MAINTENANCE_TEMPLATE_PERMISSION,
  UPDATE_MAINTENANCE_TEMPLATE_PERMISSION,
} from '@utils/permissions/maintenance-template';

@Injectable()
@Controller('checklist-templates')
export class CheckListTemplateController {
  constructor(
    @Inject('CheckListTemplateServiceInterface')
    private readonly checkListTemplateService: CheckListTemplateServiceInterface,
  ) {}

  @PermissionCode(CREATE_CHECKLIST_TEMPLATE_PERMISSION.code)
  @Post('')
  @ApiOperation({
    tags: ['Checklist Template'],
    summary: 'Create Check List Template',
    description: 'Create a new Check List Template',
  })
  @ApiResponse({
    status: 200,
    description: 'Created successfully',
    type: SuccessResponse,
  })
  async create(
    @Body() payload: CreateCheckListTemplateRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.checkListTemplateService.create(request);
  }

  @PermissionCode(
    LIST_CHECKLIST_TEMPLATE_PERMISSION.code,
    CREATE_MAINTENANCE_TEMPLATE_PERMISSION.code,
    UPDATE_MAINTENANCE_TEMPLATE_PERMISSION.code,
  )
  @Get('')
  @ApiOperation({
    tags: ['Checklist Template'],
    summary: 'Get Checklist Template',
    description: 'Danh sách mẫu phiếu kiểm tra',
  })
  @ApiResponse({
    status: 200,
    description: 'Created successfully',
    type: GetListCheckListTemplateResponseDto,
  })
  async getList(
    @Query() query: GetListCheckListTemplateRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.checkListTemplateService.getList(request);
  }

  @PermissionCode(DETAIL_CHECKLIST_TEMPLATE_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Checklist Template'],
    summary: 'Detail Check List Template',
    description: 'Detail Check List Template',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailCheckListTemplateResponseDto,
  })
  async detail(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.checkListTemplateService.detail(request);
  }

  @PermissionCode(UPDATE_CHECKLIST_TEMPLATE_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Checklist Template'],
    summary: 'Update Check List Template',
    description: 'Update an existing Check List Template',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  async update(
    @Body() payload: UpdateCheckListTemplateBody,
    @Param() param: IdParamDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    const {
      request: { id },
      responseError: paramError,
    } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    if (paramError && !isEmpty(paramError)) {
      return responseError;
    }

    return await this.checkListTemplateService.update({
      ...request,
      id,
    });
  }

  @PermissionCode(UPDATE_STATUS_CHECKLIST_TEMPLATE_PERMISSION.code)
  @Put('/:id/active')
  @ApiOperation({
    tags: ['Checklist Template'],
    summary: 'Active status Checklist',
    description: 'Active status Checklist',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async active(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.checkListTemplateService.updateStatus({
      active: ACTIVE_ENUM.ACTIVE,
      ...request,
    });
  }

  @PermissionCode(UPDATE_STATUS_CHECKLIST_TEMPLATE_PERMISSION.code)
  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Checklist Template'],
    summary: 'Inactive status Checklist',
    description: 'Inactive status Checklist',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async inactive(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.checkListTemplateService.updateStatus({
      active: ACTIVE_ENUM.INACTIVE,
      ...request,
    });
  }
}
