import { keyBy, map, isEmpty, difference } from 'lodash';
import { Inject, Injectable } from '@nestjs/common';
import { CheckListTemplateServiceInterface } from '@components/checklist-template/interface/checklist-template.service.interface';
import { CheckListTemplateRepositoryInterface } from '@components/checklist-template/interface/checklist-template.repository.interface';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { plainToInstance } from 'class-transformer';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { CreateCheckListTemplateRequestDto } from '@components/checklist-template/dto/request/create-checklist-template.request.dto';
import { GetListCheckListTemplateRequestDto } from '@components/checklist-template/dto/request/get-list-checklist-template.request.dto';
import { DetailCheckListTemplateResponseDto } from '@components/checklist-template/dto/response/detail-checklist-template.response.dto';
import { UpdateCheckListTemplateRequestDto } from '@components/checklist-template/dto/request/update-checklist-template.request.dto';
import { GetListCheckListTemplateResponseDto } from '@components/checklist-template/dto/response/get-all-checklist-template.response.dto';
import { GET_ALL_ENUM } from '@constant/common';
import { ResponsePayload } from '@utils/response-payload';
import { UpdateStatusChecklistTemplateRequest } from './dto/request/update-status-checklist-template.request.dto';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { CHECKLIST_TEMPLATE_CONST } from './checklist-template.constant';
import { getCurrentCodeByLastRecord } from 'src/helper/code.helper';
import {
  getDataInsert,
  getDataToUpdateError,
  getDataUpdate,
} from 'src/helper/import.helper';
import { FileServiceInterface } from '@components/file/interface/file.service.interface';
import { FileResource } from '@components/file/file.constant';
import { ConfigService } from '@config/config.service';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';

@Injectable()
export class CheckListTemplateService
  implements CheckListTemplateServiceInterface
{
  private readonly configService: ConfigService;
  private readonly fileUri: string;
  constructor(
    @Inject('CheckListTemplateRepositoryInterface')
    private readonly checklistTemplateRepository: CheckListTemplateRepositoryInterface,

    @Inject('FileServiceInterface')
    private readonly fileService: FileServiceInterface,

    private i18n: I18nRequestScopeService,
  ) {
    this.configService = new ConfigService();
    this.fileUri = this.configService.get('fileUri');
  }

  async updateStatus(
    request: UpdateStatusChecklistTemplateRequest,
  ): Promise<ResponsePayload<any>> {
    const { id, active } = request;

    try {
      const checklistTemplate =
        await this.checklistTemplateRepository.findOneById(id);
      if (!checklistTemplate) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.CHECK_LIST_TEMPLATE_NOT_FOUND'),
          )
          .build();
      }

      await this.checklistTemplateRepository.findByIdAndUpdate(id, {
        $set: { active },
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  async create(request: CreateCheckListTemplateRequestDto): Promise<any> {
    try {
      const { data, files } = request;

      if (!isEmpty(files)) {
        const fileIds = await this.fileService.uploadFiles(
          files ?? [],
          FileResource.CHECKLIST,
        );
        if (fileIds?.length !== files.length) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(await this.i18n.translate('error.UPLOAD_FILE_ERROR'))
            .build();
        }
        data.fileIds = fileIds;
      }
      data.code = await this.checklistTemplateRepository.generateNextCode(
        CHECKLIST_TEMPLATE_CONST.CODE.PREFIX,
      );
      const checklistTemplate =
        this.checklistTemplateRepository.createEntity(data);
      const dataSave = await this.checklistTemplateRepository.create(
        checklistTemplate,
      );

      const dataReturn = plainToInstance(BasicResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      console.error(err);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CREATE'))
        .build();
    }
  }

  async getList(request: GetListCheckListTemplateRequestDto): Promise<any> {
    if (request.isGetAll === GET_ALL_ENUM.YES) {
      const data = await this.checklistTemplateRepository.findAll();
      if (!data) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.CHECK_LIST_TEMPLATE_NOT_FOUND'),
          )
          .build();
      }
      const result = plainToInstance(
        GetListCheckListTemplateResponseDto,
        data,
        {
          excludeExtraneousValues: true,
        },
      );
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } else {
      const { result, count } = await this.checklistTemplateRepository.getList(
        request,
      );
      const response = plainToInstance(
        GetListCheckListTemplateResponseDto,
        result,
        { excludeExtraneousValues: true },
      );

      return new ResponseBuilder<PaginationResponse>({
        items: response,
        meta: { total: count, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
  }

  async findOneByCode(code: string): Promise<any> {
    const response = await this.checklistTemplateRepository.findOneByCode(code);
    if (!response) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const result = plainToInstance(
      DetailCheckListTemplateResponseDto,
      response,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async detail(request: IdParamDto): Promise<any> {
    const { id } = request;
    let fileUrls = [];
    const result = await this.checklistTemplateRepository.findOneById(id);
    if (!result) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!isEmpty(result?.fileIds)) {
      const fileInfos = await this.fileService.getFileInfoByIds(
        result?.fileIds,
      );

      fileUrls = fileInfos.map((file) => ({
        ...file,
        fileUrl: this.fileUri + file?.id,
      }));
    }
    const response = plainToInstance(
      DetailCheckListTemplateResponseDto,
      { ...result, fileUrls },
      { excludeExtraneousValues: true },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async update(request: UpdateCheckListTemplateRequestDto): Promise<any> {
    const { data, files, id, fileUrls } = request;

    try {
      let checkListTemplate =
        await this.checklistTemplateRepository.findOneById(id);
      if (!checkListTemplate) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }
      let fileIds = [];
      if (!isEmpty(files)) {
        fileIds = await this.fileService.uploadFiles(
          files ?? [],
          FileResource.CHECKLIST,
        );
        if (fileIds?.length !== files.length) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(await this.i18n.translate('error.UPLOAD_FILE_ERROR'))
            .build();
        }
      }
      const fileIdsBody = map(fileUrls, 'id') ?? [];
      const filesNotFound = difference(
        fileIdsBody,
        checkListTemplate.fileIds?.map((el) => el.toString()),
      );
      if (!isEmpty(filesNotFound)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.FILE_NOT_FOUND'))
          .build();
      }
      data.fileIds = fileIds.concat(fileIdsBody);
      checkListTemplate = this.checklistTemplateRepository.updateEntity(
        checkListTemplate,
        data,
      );
      await this.checklistTemplateRepository.findByIdAndUpdate(
        id,
        checkListTemplate,
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }
  }

  async import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const textAdd = await this.i18n.translate('import.common.add');
    const codePrefix = CHECKLIST_TEMPLATE_CONST.CODE.PREFIX;
    const lastRecord = await this.checklistTemplateRepository.lastRecord();
    const codeCurrent = getCurrentCodeByLastRecord(codePrefix, lastRecord);

    const dataInsert = getDataInsert(data, codePrefix, codeCurrent, textAdd);
    const { dataToUpdate, codesUpdate } = getDataUpdate(data, textAdd);

    const codeUpdateExists =
      await this.checklistTemplateRepository.findAllByCondition({
        code: { $in: codesUpdate },
      });
    const codeUpdateMap = keyBy(codeUpdateExists, 'code');

    const { dataError, dataUpdate } = getDataToUpdateError(
      dataToUpdate,
      codeUpdateMap,
    );
    // check duplicate

    const isTitleDuplicate = (doc) => {
      return (
        new Set(map(doc.details, (data) => data.title?.toLocaleLowerCase()))
          .size !== doc.details?.length
      );
    };
    const bulkOps = [];
    [...dataInsert, ...dataUpdate].forEach((doc) => {
      if (isTitleDuplicate(doc)) {
        dataError.push(doc);
      } else {
        bulkOps.push({
          updateOne: {
            filter: { code: doc.code },
            update: doc,
            upsert: true,
          },
        });
      }
    });
    const dataSuccess = await this.checklistTemplateRepository.bulkWrite(
      bulkOps,
    );

    return { dataError, dataSuccess };
  }
}
