import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { AccreditationTemplateModel } from 'src/models/accreditation-template/accreditation-template.model';
import { DataBodyAccreditationTemplate } from '../dto/request/create-accreditation-request.dto';
import { GetListAccreditationTemplateRequest } from '../dto/request/list-accreditation-request.dto';

export interface AccreditationTemplateRepositoryInterface
  extends BaseAbstractRepository<AccreditationTemplateModel> {
  createEntity(
    request: DataBodyAccreditationTemplate,
  ): AccreditationTemplateModel;
  updateEntity(
    document: AccreditationTemplateModel,
    request: DataBodyAccreditationTemplate,
  ): AccreditationTemplateModel;
  list(request: GetListAccreditationTemplateRequest): Promise<any>;
  getTemplateScheduleByTemplate(id: string): Promise<any>;
}
