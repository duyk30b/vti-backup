import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreateAccreditationTemplateRequestDto } from '../dto/request/create-accreditation-request.dto';
import { DetailAccreditationTemplateRequest } from '../dto/request/detail-accreditation-request.dto';
import { UpdateAccreditationTemplateRequest } from '../dto/request/update-accreditation-request.dto';
import { UpdateStatusAccreditationRequest } from '../dto/request/update-status-accreditation.request.dto';
import { GetListAccreditationResponse } from '../dto/response/list-accreditation-response.dto';

export interface AccreditationTemplateServiceInterface {
  create(
    request: CreateAccreditationTemplateRequestDto,
  ): Promise<ResponsePayload<any>>;
  update(
    request: IdParamDto & UpdateAccreditationTemplateRequest,
  ): Promise<ResponsePayload<any>>;
  updateStatus(
    request: UpdateStatusAccreditationRequest,
  ): Promise<ResponsePayload<any>>;

  getList(request: any): Promise<ResponsePayload<GetListAccreditationResponse>>;
  detail(
    request: DetailAccreditationTemplateRequest,
  ): Promise<ResponsePayload<any>>;

  import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }>;
}
