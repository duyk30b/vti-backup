import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose } from 'class-transformer';
import { DetailAccreditationTemplateResponseDto } from './detail-accreditation-response.dto';

export class GetListAccreditationResponse extends PaginationResponse {
  @ApiProperty({ type: DetailAccreditationTemplateResponseDto, isArray: true })
  @Expose()
  items: DetailAccreditationTemplateResponseDto[];
}
