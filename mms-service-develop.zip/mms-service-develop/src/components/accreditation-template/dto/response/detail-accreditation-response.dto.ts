import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { FileUrlResponseDto } from '@utils/dto/response/file-url.response.dto';
import { Expose, Type } from 'class-transformer';

class DetailAccreditationTemplate extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  title: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  obligatory: number;
}
export class DetailAccreditationTemplateResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  periodic: number;

  @ApiProperty()
  @Expose()
  activeTime: number;

  @ApiProperty()
  @Expose()
  active: number;

  @ApiProperty({
    type: FileUrlResponseDto,
    isArray: true,
  })
  @Expose()
  @Type(() => FileUrlResponseDto)
  fileUrls: FileUrlResponseDto[];

  @ApiProperty({ type: DetailAccreditationTemplate, isArray: true })
  @Expose()
  @Type(() => DetailAccreditationTemplate)
  details: DetailAccreditationTemplate[];
}
