import { IdParamDto } from '@utils/dto/request/param-id.request.dto';

export class DetailAccreditationTemplateRequest extends IdParamDto {}
