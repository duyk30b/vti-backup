import { ACTIVE_ENUM } from '@constant/common';
import { ApiProperty } from '@nestjs/swagger';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { IsEnum, IsNotEmpty } from 'class-validator';

export class UpdateStatusAccreditationRequest extends IdParamDto {
  @ApiProperty()
  @IsEnum(ACTIVE_ENUM)
  @IsNotEmpty()
  active: number;
}
