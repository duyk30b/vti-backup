import { ACCREDITATION_TEMPLATE_CONST } from '@components/accreditation-template/accreditation-template.constant';
import { DEVICE_STATUS_CONST } from '@components/device-status/device-status.constant';
import { OBLIGATORY_ENUM } from '@constant/common';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { MIME_TYPES_FOR_TEMPLATE } from '@utils/constant';
import { plainToClass, Transform, Type } from 'class-transformer';
import {
  IsArray,
  IsEnum,
  IsMongoId,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';
import { IsNotBlank } from 'src/validator/is-not-blank.validator';

export class DetailAccreditationTemplateRequestDto {
  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  id: string;

  @ApiProperty()
  @IsString()
  @MaxLength(ACCREDITATION_TEMPLATE_CONST.DETAIL_ACCREDITATION.TITLE.MAX_LENGTH)
  @IsNotEmpty()
  @IsNotBlank()
  title: string;

  @ApiProperty()
  @IsString()
  @MaxLength(
    ACCREDITATION_TEMPLATE_CONST.DETAIL_ACCREDITATION.DESCRIPTION.MAX_LENGTH,
  )
  @IsOptional()
  description: string;

  @ApiProperty()
  @IsEnum(OBLIGATORY_ENUM)
  @IsNotEmpty()
  obligatory: number;
}
export class DataBodyAccreditationTemplate {
  code: string;

  @ApiProperty()
  @MaxLength(ACCREDITATION_TEMPLATE_CONST.NAME.MAX_LENGTH)
  @IsNotBlank()
  @IsString()
  name: string;

  @ApiProperty()
  @MaxLength(ACCREDITATION_TEMPLATE_CONST.DESCRIPTION.MAX_LENGTH)
  @IsString()
  @IsOptional()
  description: string;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  @Min(1)
  periodic: number;

  @ApiProperty()
  @Min(DEVICE_STATUS_CONST.ACTIVE_TIME.MIN)
  @IsNumber()
  @IsNotEmpty()
  activeTime: number;

  fileIds: string[];

  @ApiProperty({ type: DetailAccreditationTemplateRequestDto })
  @ValidateNested({ each: true })
  @Type(() => DetailAccreditationTemplateRequestDto)
  @IsArray()
  @IsNotEmpty()
  details: DetailAccreditationTemplateRequestDto[];
}

export class File {
  filename: string;
  data: ArrayBuffer;
  encoding: string;
  @IsEnum(MIME_TYPES_FOR_TEMPLATE)
  mimetype: string;
  limit: boolean;
}
export class CreateAccreditationTemplateRequestDto extends BaseDto {
  @ApiProperty({ type: DataBodyAccreditationTemplate })
  @Type(() => DataBodyAccreditationTemplate)
  @ValidateNested({ each: true })
  @Transform(({ value }) =>
    plainToClass(DataBodyAccreditationTemplate, JSON.parse(value)),
  )
  @IsNotEmpty()
  data: DataBodyAccreditationTemplate;

  @ApiProperty()
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => File)
  files: File[];
}
