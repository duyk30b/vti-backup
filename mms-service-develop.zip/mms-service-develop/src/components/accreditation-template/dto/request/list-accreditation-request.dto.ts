import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { IsOptional, IsString } from 'class-validator';

export class GetListAccreditationTemplateRequest extends PaginationQuery {
  @ApiProperty()
  @IsOptional()
  @IsString()
  queryIds?: string;
}
