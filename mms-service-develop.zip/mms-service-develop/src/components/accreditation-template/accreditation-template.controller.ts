import { ACTIVE_ENUM } from '@constant/common';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  Body,
  Controller,
  Get,
  Inject,
  Injectable,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import {
  CREATE_ACCREDITATION_TEMPLATE_PERMISSION,
  DETAIL_ACCREDITATION_TEMPLATE_PERMISSION,
  LIST_ACCREDITATION_TEMPLATE_PERMISSION,
  UPDATE_ACCREDITATION_TEMPLATE_PERMISSION,
  UPDATE_STATUS_ACCREDITATION_TEMPLATE_PERMISSION,
} from '@utils/permissions/accreditation-template';
import {
  CREATE_DEVICE_GROUP_PERMISSION,
  UPDATE_DEVICE_GROUP_PERMISSION,
} from '@utils/permissions/device-group';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateAccreditationTemplateRequestDto } from './dto/request/create-accreditation-request.dto';
import { DetailAccreditationTemplateRequest } from './dto/request/detail-accreditation-request.dto';
import { GetListAccreditationTemplateRequest } from './dto/request/list-accreditation-request.dto';
import { UpdateAccreditationTemplateRequest } from './dto/request/update-accreditation-request.dto';
import { DetailAccreditationTemplateResponseDto } from './dto/response/detail-accreditation-response.dto';
import { GetListAccreditationResponse } from './dto/response/list-accreditation-response.dto';
import { AccreditationTemplateServiceInterface } from './interface/accreditotion-template.service.interface';

@Injectable()
@Controller('accreditation-templates')
export class AccreditationController {
  constructor(
    @Inject('AccreditationTemplateServiceInterface')
    private readonly accreditationTemplateService: AccreditationTemplateServiceInterface,
  ) {}

  @PermissionCode(CREATE_ACCREDITATION_TEMPLATE_PERMISSION.code)
  @Post('/')
  @ApiOperation({
    tags: ['Accreditation Templates'],
    summary: 'Create Accreditation',
    description: 'Create Accreditation',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async create(
    @Body() body: CreateAccreditationTemplateRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.accreditationTemplateService.create(request);
  }

  @PermissionCode(
    LIST_ACCREDITATION_TEMPLATE_PERMISSION.code,
    CREATE_DEVICE_GROUP_PERMISSION.code,
    UPDATE_DEVICE_GROUP_PERMISSION.code,
  )
  @Get('/')
  @ApiOperation({
    tags: ['Accreditation Templates'],
    summary: 'Get List Accreditation',
    description: 'Get List Accreditation',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetListAccreditationResponse,
  })
  async getList(
    @Query() query: GetListAccreditationTemplateRequest,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.accreditationTemplateService.getList(request);
  }

  @PermissionCode(DETAIL_ACCREDITATION_TEMPLATE_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Accreditation Templates'],
    summary: 'Get Detail Accreditation',
    description: 'Get Detail Accreditation',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailAccreditationTemplateResponseDto,
  })
  async getdetail(
    @Param() param: DetailAccreditationTemplateRequest,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.accreditationTemplateService.detail(request);
  }

  @PermissionCode(UPDATE_ACCREDITATION_TEMPLATE_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Accreditation Templates'],
    summary: 'Update Accreditation',
    description: 'Update Accreditation',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async update(
    @Param() param: IdParamDto,
    @Body() body: UpdateAccreditationTemplateRequest,
  ): Promise<any> {
    const { request: requestParam, responseError: responseErrorParam } = param;
    if (responseErrorParam && !isEmpty(responseErrorParam)) {
      return responseErrorParam;
    }

    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.accreditationTemplateService.update({
      ...request,
      id: requestParam.id,
    });
  }

  @PermissionCode(UPDATE_STATUS_ACCREDITATION_TEMPLATE_PERMISSION.code)
  @Put('/:id/active')
  @ApiOperation({
    tags: ['Accreditation Templates'],
    summary: 'Active status Accreditation',
    description: 'Active status Accreditation',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async active(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.accreditationTemplateService.updateStatus({
      active: ACTIVE_ENUM.ACTIVE,
      ...request,
    });
  }

  @PermissionCode(UPDATE_STATUS_ACCREDITATION_TEMPLATE_PERMISSION.code)
  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Accreditation Templates'],
    summary: 'Inactive status Accreditation',
    description: 'Inactive status Accreditation',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async inactive(@Param() param: IdParamDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.accreditationTemplateService.updateStatus({
      active: ACTIVE_ENUM.INACTIVE,
      ...request,
    });
  }
}
