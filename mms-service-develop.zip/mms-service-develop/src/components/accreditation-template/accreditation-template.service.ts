import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { keyBy, map, isEmpty, difference } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { getCurrentCodeByLastRecord } from 'src/helper/code.helper';
import { ACCREDITATION_TEMPLATE_CONST } from './accreditation-template.constant';
import { DetailAccreditationTemplateRequest } from './dto/request/detail-accreditation-request.dto';
import { GetListAccreditationTemplateRequest } from './dto/request/list-accreditation-request.dto';
import { UpdateAccreditationTemplateRequest } from './dto/request/update-accreditation-request.dto';
import { UpdateStatusAccreditationRequest } from './dto/request/update-status-accreditation.request.dto';
import { DetailAccreditationTemplateResponseDto } from './dto/response/detail-accreditation-response.dto';
import { AccreditationTemplateRepositoryInterface } from './interface/accreditation-template.repository.interface';
import { AccreditationTemplateServiceInterface } from './interface/accreditotion-template.service.interface';
import {
  getDataInsert,
  getDataToUpdateError,
  getDataUpdate,
} from 'src/helper/import.helper';
import { FileServiceInterface } from '@components/file/interface/file.service.interface';
import { FileResource } from '@components/file/file.constant';
import { ConfigService } from '@config/config.service';
import { DEVICE_TEMPLATE_SCHEDULE_EVENT_ENUM } from '@components/device/device.constant';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';

@Injectable()
export class AccreditationTemplateService
  implements AccreditationTemplateServiceInterface
{
  private readonly configService: ConfigService;
  private readonly fileUri: string;
  constructor(
    @Inject('AccreditationTemplateRepositoryInterface')
    private readonly accreditationTemplateRepository: AccreditationTemplateRepositoryInterface,

    @Inject('FileServiceInterface')
    private readonly fileService: FileServiceInterface,

    private readonly eventEmitter: EventEmitter2,

    private i18n: I18nRequestScopeService,
  ) {
    this.configService = new ConfigService();
    this.fileUri = this.configService.get('fileUri');
  }

  async updateStatus(
    request: UpdateStatusAccreditationRequest,
  ): Promise<ResponsePayload<any>> {
    const { id, active } = request;

    try {
      const accreditationTemplate =
        await this.accreditationTemplateRepository.findOneById(id);
      if (!accreditationTemplate) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.ACCREDITATION_TEMPLATE_NOT_FOUND'),
          )
          .build();
      }

      await this.accreditationTemplateRepository.findByIdAndUpdate(id, {
        $set: { active },
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  async create(request: any): Promise<ResponsePayload<any>> {
    const { data, files } = request;

    try {
      if (!isEmpty(files)) {
        const fileIds = await this.fileService.uploadFiles(
          files ?? [],
          FileResource.ACCREDITATION,
        );
        if (fileIds?.length !== files.length) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(await this.i18n.translate('error.UPLOAD_FILE_ERROR'))
            .build();
        }
        data.fileIds = fileIds;
      }
      data.code = await this.accreditationTemplateRepository.generateNextCode(
        ACCREDITATION_TEMPLATE_CONST.CODE.PREFIX,
      );
      // create new accreditation template document
      const accreditationTemplate =
        this.accreditationTemplateRepository.createEntity(data);

      // save accreditation template
      const dataSave = await this.accreditationTemplateRepository.create(
        accreditationTemplate,
      );
      const dataReturn = plainToInstance(BasicResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CREATE'))
        .build();
    }
  }

  async getList(
    request: GetListAccreditationTemplateRequest,
  ): Promise<ResponsePayload<any>> {
    try {
      const { data, count } = await this.accreditationTemplateRepository.list(
        request,
      );
      const dataReturn = plainToInstance(
        DetailAccreditationTemplateResponseDto,
        data,
        {
          excludeExtraneousValues: true,
        },
      );
      return new ResponseBuilder({
        items: dataReturn,
        meta: { total: count, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async detail(
    request: DetailAccreditationTemplateRequest,
  ): Promise<ResponsePayload<any>> {
    try {
      const data = await this.accreditationTemplateRepository.findOneById(
        request.id,
      );
      if (!data) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.ACCREDITATION_TEMPLATE_NOT_FOUND'),
          )
          .build();
      }
      if (!isEmpty(data?.fileIds)) {
        const fileInfos = await this.fileService.getFileInfoByIds(
          data?.fileIds,
        );
        data['fileUrls'] = fileInfos.map((file) => ({
          ...file,
          fileUrl: this.fileUri + file?.id,
        }));
      }
      const dataReturn = plainToInstance(
        DetailAccreditationTemplateResponseDto,
        data,
        {
          excludeExtraneousValues: true,
        },
      );
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async update(
    request: IdParamDto & UpdateAccreditationTemplateRequest,
  ): Promise<any> {
    try {
      const { data, files, id, fileUrls } = request;

      let fileIds = [];
      if (!isEmpty(files)) {
        fileIds = await this.fileService.uploadFiles(
          files ?? [],
          FileResource.ACCREDITATION,
        );
        if (fileIds?.length !== files.length) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(await this.i18n.translate('error.UPLOAD_FILE_ERROR'))
            .build();
        }
      }
      let accreditationTemplate =
        await this.accreditationTemplateRepository.findOneById(id);
      if (!accreditationTemplate) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.ACCREDITATION_TEMPLATE_NOT_FOUND'),
          )
          .build();
      }
      const fileIdsBody = map(fileUrls, 'id') ?? [];
      const filesNotFound = difference(
        fileIdsBody,
        accreditationTemplate.fileIds?.map((el) => el.toString()),
      );
      if (!isEmpty(filesNotFound)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.FILE_NOT_FOUND'))
          .build();
      }
      data.fileIds = fileIds.concat(fileIdsBody);
      data.details?.forEach((el) => {
        el['_id'] = el.id;
      });

      accreditationTemplate =
        await this.accreditationTemplateRepository.findByIdAndUpdate(id, data);
      const devices =
        await this.accreditationTemplateRepository.getTemplateScheduleByTemplate(
          id,
        );
      this.eventEmitter.emit(
        DEVICE_TEMPLATE_SCHEDULE_EVENT_ENUM.ACCREDITATION_UPDATE,
        { devices, accreditationTemplate },
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const textAdd = await this.i18n.translate('import.common.add');
    const codePrefix = ACCREDITATION_TEMPLATE_CONST.CODE.PREFIX;
    const lastRecord = await this.accreditationTemplateRepository.lastRecord();
    const codeCurrent = getCurrentCodeByLastRecord(codePrefix, lastRecord);

    const dataInsert = getDataInsert(data, codePrefix, codeCurrent, textAdd);
    const { dataToUpdate, codesUpdate } = getDataUpdate(data, textAdd);

    const codeUpdateExists =
      await this.accreditationTemplateRepository.findAllByCondition({
        code: { $in: codesUpdate },
      });
    const codeUpdateMap = keyBy(codeUpdateExists, 'code');

    const { dataError, dataUpdate } = getDataToUpdateError(
      dataToUpdate,
      codeUpdateMap,
    );
    // check duplicate
    const isTitleDuplicate = (doc) => {
      return (
        new Set(map(doc.details, (data) => data.title?.toLocaleLowerCase()))
          .size !== doc.details?.length
      );
    };
    const bulkOps = [];
    [...dataInsert, ...dataUpdate].forEach((doc) => {
      if (isTitleDuplicate(doc)) {
        dataError.push(doc);
      } else {
        bulkOps.push({
          updateOne: {
            filter: { code: doc.code },
            update: doc,
            upsert: true,
          },
        });
      }
    });
    const dataSuccess = await this.accreditationTemplateRepository.bulkWrite(
      bulkOps,
    );
    return { dataError, dataSuccess };
  }
}
