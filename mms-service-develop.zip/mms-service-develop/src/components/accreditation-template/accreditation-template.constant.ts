import { CODE_REGEX } from '@constant/common';

export const ACCREDITATION_TEMPLATE_CONST = {
  CODE: {
    MAX_LENGTH: 20,
    MIN_LENGTH: 6,
    COLUMN: 'code',
    PREFIX: 'PKD',
    REGEX: CODE_REGEX,
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
  PERIODIC: {
    MAX: 365,
    MIN: 1,
  },
  DETAIL_ACCREDITATION: {
    TITLE: {
      MAX_LENGTH: 255,
      COLUMN: 'title',
    },
    DESCRIPTION: {
      MAX_LENGTH: 255,
      COLUMN: 'description',
    },
    OBLIGATORY: {
      column: 'obligatory',
    },
  },
};
