import { FileModule } from '@components/file/file.module';
import { SettingModule } from '@components/setting/setting.module';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { AccreditationTemplateSchema } from 'src/models/accreditation-template/accreditation-template.schema';
import { DeviceTemplateScheduleSchema } from 'src/models/device-template-schedule/device-template-schedule.schema';
import { DeviceSchema } from 'src/models/device/device.schema';
import { AccreditationTemplateRepository } from 'src/repository/accreditation-template/accreditation-template.repository';
import { DeviceTemplateScheduleRepository } from 'src/repository/device-template-schedule/device-template-schedule.repository';
import { DeviceRepository } from 'src/repository/device/device.repository';
import { AccreditationController } from './accreditation-template.controller';
import { AccreditationTemplateService } from './accreditation-template.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: 'AccreditationTemplateModel',
        schema: AccreditationTemplateSchema,
      },
      { name: 'Device', schema: DeviceSchema },
      { name: 'DeviceTemplateSchedule', schema: DeviceTemplateScheduleSchema },
    ]),
    FileModule,
    SettingModule,
  ],
  controllers: [AccreditationController],
  providers: [
    {
      provide: 'AccreditationTemplateRepositoryInterface',
      useClass: AccreditationTemplateRepository,
    },
    {
      provide: 'AccreditationTemplateServiceInterface',
      useClass: AccreditationTemplateService,
    },
    {
      provide: 'DeviceRepositoryInterface',
      useClass: DeviceRepository,
    },
    {
      provide: 'DeviceTemplateScheduleRepositoryInterface',
      useClass: DeviceTemplateScheduleRepository,
    },
  ],
  exports: [
    MongooseModule,
    {
      provide: 'AccreditationTemplateRepositoryInterface',
      useClass: AccreditationTemplateRepository,
    },
    {
      provide: 'AccreditationTemplateServiceInterface',
      useClass: AccreditationTemplateService,
    },
  ],
})
export class AccreditationTemplateModule {}
