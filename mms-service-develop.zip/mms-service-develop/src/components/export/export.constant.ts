export const EXCEL_STYLE = {
  SHEET_FONT: {
    size: 13,
    color: { argb: '000000' },
    bold: false,
    name: 'Times New Roman',
  },
  TOTAL_FONT: {
    color: { argb: 'FF0000' },
    size: 13,
    bold: true,
  },
  HEADER_FONT: {
    size: 18,
    bold: true,
    name: 'Times New Roman',
  },
  TITLE_FONT: {
    size: 13,
    bold: true,
    name: 'Times New Roman',
  },
  DEFAULT_FONT: {
    size: 12,
    bold: false,
    name: 'Times New Roman',
  },
  HEADER_FILL: {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'c0c0c0' },
  },
  HIGHT_LIGHT: {
    color: { argb: 'FF0000' },
    name: 'Times New Roman',
    size: 13,
  },
  ALIGN_CENTER: {
    vertical: 'middle',
    horizontal: 'center',
    wrapText: true,
  },
  ALIGN_LEFT_MIDDLE: {
    vertical: 'middle',
    horizontal: 'left',
    wrapText: true,
  },
  ALIGN_RIGHT_MIDDLE: {
    vertical: 'middle',
    horizontal: 'right',
    wrapText: true,
  },
  ALIGN_BOTTOM: {
    vertical: 'bottom',
    horizontal: 'center',
    wrapText: true,
  },
  BORDER_ALL: {
    top: { style: 'thin' },
    left: { style: 'thin' },
    bottom: { style: 'thin' },
    right: { style: 'thin' },
  },
  DDMMYYYYHHMMSS: 'dd-mm-yyyy HH:MM:SS',
  TITLE_HEIGHT: 38,
};

export const ROW = {
  COUNT_START_ROW: 1,
  COUNT_END_ROW: 10001,
  LIMIT_EXPORT: 100000,
  LIMIT_EXPORT_ON_SHEET: 10000,
};

export const SHEET = {
  START_SHEET: 1,
  NAME: 'Sheet',
};

export enum ExportTypeEnum {
  ONE_SHEET = 1,
  MULTI_SHEET = 2,
}

export enum TypeEnum {
  DEVICE_GROUP,
  CHECKLIST_TEMPLATE,
  INSTALLATION_TEMPLATE,
  ATTRIBUTE_TYPE,
  MAINTENANCE_ATTRIBUTE,
  SUPPLY_GROUP,
  SUPPLY,
  DEVICE,
  UNIT,
  MAINTENANCE_TEAM,
  DEVICE_REQUEST,
  AREA,
  ERROR_TYPE,
  VENDOR,
  DEVICE_TYPE,
  DEVICE_ASSIGNMENT,
  ARTICLE_DEVICE_GROUP,
  MAINTENANCE_TEMPLATE,
  ACCREDITATION_TEMPLATE,
  JOB,
  WAREHOUSE,
  INVENTORY_DEVICE_GROUP,
  INVENTORY_SUPPLY,
  DEVICE_INVENTORY,
  DEVICE_NAME,
  REPORT_NEW_INVESTMENT_DEVICE,
  OPERATION_VALUE,
  REPORT_TRANSFER,
  REPORT_TRANSFER_DETAIL,
  REPORT_DEVICE_SYNTHESIS,
  REPORT_DEVICE_MAINTENANCE,
}

export const MAX_NUMBER_PAGE = 10;
