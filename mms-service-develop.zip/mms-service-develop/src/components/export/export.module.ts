import { DeviceNameSchema } from 'src/models/device-name/device-name.schema';
import { DeviceRequestRepository } from 'src/repository/device-request/device-request-ticket.repository';
import { AttributeTypeRepository } from 'src/repository/attribute-type/attribute-type.repository';
import { AttributeTypeSchema } from 'src/models/attribute-type/attribute-type.schema';
import { MaintenanceAttributeRepository } from 'src/repository/maintenance-attribute/maintenance-attribute.repository';
import { MaintenanceAttributeSchema } from 'src/models/maintenance-attribute/maintenance-attribute.schema';
import { SupplyGroupSchema } from 'src/models/supply-group/supply-group.schema';
import { SupplyGroupRepository } from 'src/repository/supply-group/supply-group.repository';
import { SupplySchema } from 'src/models/supply/supply.schema';
import { SupplyRepository } from 'src/repository/supply/supply.repository';
import { UserService } from '@components/user/user.service';
import { Global, Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ChecklistTemplateSchema } from 'src/models/checklist-template/checklist-template.schema';
import { DeviceGroupSchema } from 'src/models/device-group/device-group.schema';
import { InstallationTemplateSchema } from 'src/models/installation-template/installation-template.schema';
import { DeviceSchema } from 'src/models/device/device.schema';
import { MaintenanceTeamSchema } from 'src/models/maintenance-team/maintenance-team.schema';
import { CheckListTemplateRepository } from 'src/repository/checklist-template/checklist-template.repository';
import { DeviceGroupRepository } from 'src/repository/device-group/device-group.repository';
import { InstallationTemplateRepository } from 'src/repository/installation-template/installation-template.repository';
import { DeviceRepository } from 'src/repository/device/device.repository';
import { MaintenanceTeamRepository } from 'src/repository/maintenance-team/maintenance-team.repository';
import { ExportController } from './export.controller';
import { ExportService } from './export.service';
import { DeviceRequestSchema } from 'src/models/device-request/device-request-ticket.schema';
import { AreaSchema } from 'src/models/area/area.schema';
import { AreaRepository } from 'src/repository/area/area.repository';
import { ErrorTypeSchema } from 'src/models/error-type/error-type.schema';
import { ErrorTypeRepository } from 'src/repository/error-type/error-type.repository';
import { VendorRepository } from 'src/repository/vendor/vendor.repository';
import { VendorSchema } from 'src/models/vendor/vendor.schema';
import { DeviceTypeRepository } from 'src/repository/device-type/device-type.repository';
import { DeviceTypeSchema } from 'src/models/device-type/device-type.schema';
import { DeviceAssignmentSchema } from 'src/models/device-assignment/device-assignment.schema';
import { DeviceAssignmentRepository } from 'src/repository/device-assignment/device-assignment.repository';
import { ArticleDeviceGroupSchema } from 'src/models/article-device-group/article-device-group.schema';
import { ArticleDeviceGroupRepository } from 'src/repository/article-device-group/article-device-group.repository';
import { MaintenanceTemplateSchema } from 'src/models/maintenance-template/maintenance-template.schema';
import { MaintenanceTemplateRepository } from 'src/repository/maintenance-template/maintenance-template.repository';
import { AccreditationTemplateRepository } from 'src/repository/accreditation-template/accreditation-template.repository';
import { AccreditationTemplateSchema } from 'src/models/accreditation-template/accreditation-template.schema';
import { JobSchema } from 'src/models/job/job.schema';
import { JobRepository } from 'src/repository/job/job.repository';
import { InventoryRepository } from 'src/repository/warehouse-inventories/inventory.repository';
import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { DeviceNameRepository } from 'src/repository/device-name/device-name.repository';
import { InventorySchema } from 'src/models/warehouse-inventories/inventory.schema';
import {
  OperationValue,
  OperationValueSchema,
} from 'src/models/operation-value/operation-value.schema';
import { OperationValueRepository } from 'src/repository/operation-value/operation-value.repository';
import { OperationIndexRepository } from 'src/repository/operation-index/operation-index.repository';
import {
  OperationIndex,
  OperationIndexSchema,
} from 'src/models/operation-index/operation-index.schema';
import { TransferTicketRepository } from 'src/repository/transfer-ticket/transfer-ticket.repository';
import { TransferTicketSchema } from 'src/models/transfer-ticket/transfer-ticket.schema';
import { ReportModule } from '@components/report/report.module';
import { ItemModule } from '@components/item/item.module';

@Global()
@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'DeviceGroup', schema: DeviceGroupSchema },
      { name: 'MaintenanceTeam', schema: MaintenanceTeamSchema },
      { name: 'CheckListTemplate', schema: ChecklistTemplateSchema },
      { name: 'InstallationTemplate', schema: InstallationTemplateSchema },
      { name: 'AttributeType', schema: AttributeTypeSchema },
      { name: 'MaintenanceAttribute', schema: MaintenanceAttributeSchema },
      { name: 'SupplyGroup', schema: SupplyGroupSchema },
      { name: 'Supply', schema: SupplySchema },
      { name: 'Device', schema: DeviceSchema },
      { name: 'DeviceRequest', schema: DeviceRequestSchema },
      { name: 'Area', schema: AreaSchema },
      { name: 'ErrorTypeModel', schema: ErrorTypeSchema },
      { name: 'VendorModel', schema: VendorSchema },
      { name: 'DeviceType', schema: DeviceTypeSchema },
      { name: 'DeviceAssignment', schema: DeviceAssignmentSchema },
      { name: 'ArticleDeviceGroup', schema: ArticleDeviceGroupSchema },
      { name: 'MaintenanceTemplate', schema: MaintenanceTemplateSchema },
      { name: 'Job', schema: JobSchema },
      { name: 'Inventory', schema: InventorySchema },
      {
        name: 'AccreditationTemplateModel',
        schema: AccreditationTemplateSchema,
      },
      { name: 'DeviceName', schema: DeviceNameSchema },
      { name: 'TransferTicket', schema: TransferTicketSchema },
      { name: OperationValue.name, schema: OperationValueSchema },
      { name: OperationIndex.name, schema: OperationIndexSchema },
    ]),
    WarehouseModule,
    ReportModule,
    ItemModule,
  ],
  providers: [
    {
      provide: 'ExportServiceInterface',
      useClass: ExportService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'DeviceGroupRepositoryInterface',
      useClass: DeviceGroupRepository,
    },
    {
      provide: 'MaintenanceTeamRepositoryInterface',
      useClass: MaintenanceTeamRepository,
    },
    {
      provide: 'CheckListTemplateRepositoryInterface',
      useClass: CheckListTemplateRepository,
    },
    {
      provide: 'InstallationTemplateRepositoryInterface',
      useClass: InstallationTemplateRepository,
    },
    {
      provide: 'AttributeTypeRepositoryInterface',
      useClass: AttributeTypeRepository,
    },
    {
      provide: 'MaintenanceAttributeRepositoryInterface',
      useClass: MaintenanceAttributeRepository,
    },
    {
      provide: 'SupplyGroupRepositoryInterface',
      useClass: SupplyGroupRepository,
    },
    {
      provide: 'SupplyRepositoryInterface',
      useClass: SupplyRepository,
    },
    {
      provide: 'DeviceRepositoryInterface',
      useClass: DeviceRepository,
    },
    {
      provide: 'DeviceRequestRepositoryInterface',
      useClass: DeviceRequestRepository,
    },
    {
      provide: 'AreaRepositoryInterface',
      useClass: AreaRepository,
    },
    {
      provide: 'ErrorTypeRepositoryInterface',
      useClass: ErrorTypeRepository,
    },
    {
      provide: 'VendorRepositoryInterface',
      useClass: VendorRepository,
    },
    {
      provide: 'DeviceTypeRepositoryInterface',
      useClass: DeviceTypeRepository,
    },
    {
      provide: 'DeviceAssignmentRepositoryInterface',
      useClass: DeviceAssignmentRepository,
    },
    {
      provide: 'ArticleDeviceGroupRepositoryInterface',
      useClass: ArticleDeviceGroupRepository,
    },
    {
      provide: 'MaintenanceTemplateRepositoryInterface',
      useClass: MaintenanceTemplateRepository,
    },
    {
      provide: 'AccreditationTemplateRepositoryInterface',
      useClass: AccreditationTemplateRepository,
    },
    {
      provide: 'JobRepositoryInterface',
      useClass: JobRepository,
    },
    {
      provide: 'InventoryRepositoryInterface',
      useClass: InventoryRepository,
    },
    {
      provide: 'TransferTicketRepositoryInterface',
      useClass: TransferTicketRepository,
    },
    {
      provide: 'DeviceNameRepositoryInterface',
      useClass: DeviceNameRepository,
    },
    {
      provide: 'OperationValueRepositoryInterface',
      useClass: OperationValueRepository,
    },
    {
      provide: 'OperationIndexRepositoryInterface',
      useClass: OperationIndexRepository,
    },
  ],
  controllers: [ExportController],
  exports: [
    {
      provide: 'ExportServiceInterface',
      useClass: ExportService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
  ],
})
export class ExportModule {}
