import {
  Controller,
  Get,
  Inject,
  Query,
  UseInterceptors,
} from '@nestjs/common';
import { isEmpty } from 'lodash';
import { ExportRequestDto } from './dto/request/export.request.dto';
import { ExportServiceInterface } from './interface/export.service.interface';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { TypeEnum } from './export.constant';
import { EXPORT_ACCREDITATION_TEMPLATE_PERMISSION } from '@utils/permissions/accreditation-template';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { EXPORT_AREA_PERMISSION } from '@utils/permissions/area';
import { EXPORT_ARTICLE_DEVICE_GROUP_PERMISSION } from '@utils/permissions/article-device-group';
import { EXPORT_ATTRIBUTE_TYPE_PERMISSION } from '@utils/permissions/attribute-type';
import { EXPORT_CHECKLIST_TEMPLATE_PERMISSION } from '@utils/permissions/checklist-template';
import { EXPORT_DEVICE_PERMISSION } from '@utils/permissions/device';
import { EXPORT_DEVICE_GROUP_PERMISSION } from '@utils/permissions/device-group';
import { EXPORT_DEVICE_TYPE_PERMISSION } from '@utils/permissions/device-type';
import { EXPORT_ERROR_TYPE_PERMISSION } from '@utils/permissions/error-type';
import { EXPORT_INSTALLATION_TEMPLATE_PERMISSION } from '@utils/permissions/installation-template';
import { EXPORT_MAINTENANCE_ATTRIBUTE_PERMISSION } from '@utils/permissions/maintenance-attribute';
import { EXPORT_MAINTENANCE_TEAM_PERMISSION } from '@utils/permissions/maintenance-team';
import { EXPORT_MAINTENANCE_TEMPLATE_PERMISSION } from '@utils/permissions/maintenance-template';
import { EXPORT_SUPPLY_PERMISSION } from '@utils/permissions/supply';
import { EXPORT_SUPPLY_GROUP_PERMISSION } from '@utils/permissions/supply-group';
import { EXPORT_VENDOR_PERMISSION } from '@utils/permissions/vendor';
import {
  EXPORT_DEVICE_INVENTORY_PERMISSION,
  EXPORT_INVENTORY_DEVICE_GROUP_PERMISSION,
  EXPORT_INVENTORY_SUPPLY_PERMISSION,
} from '@utils/permissions/warehouse-inventory';
import { EXPORT_DEVICE_NAME_PERMISSION } from '@utils/permissions/device-name';
import { EXPORT_REPORT_NEW_INVESTMENT_DEVICE_PERMISSION } from '@utils/permissions/report-new-investment-device';
import { EXPORT_OPERATION_VALUE_PERMISSION } from '@utils/permissions/operation-value';
import {
  EXPORT_REPORT_DETAIL_DEVICE_TRANSFER_PERMISSION,
  EXPORT_REPORT_DEVICE_TRANSFER_PERMISSION,
} from '@utils/permissions/report-device-transfer';
import { EXPORT_REPORT_DEVICE_SYNTHESIS_PERMISSION } from '@utils/permissions/report-device';
import { EXPORT_REPORT_DEVICE_MAINTENANCE_PERMISSION } from '@utils/permissions/report-device-maintenance';
import { GetMaintenancePlanReportRequest } from '@components/report/dto/request/get-maintenance-plan-report.request';
import { PermissionInterceptor } from '@core/interceptors/permission.interceptor';

@Controller('export')
export class ExportController {
  constructor(
    @Inject('ExportServiceInterface')
    private readonly exportService: ExportServiceInterface,
  ) {}

  @PermissionCode(EXPORT_ACCREDITATION_TEMPLATE_PERMISSION.code)
  @Get(`/${TypeEnum.ACCREDITATION_TEMPLATE}`)
  @ApiOperation({
    tags: ['Export accreditation'],
    summary: 'Export accreditation',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportAccreditation(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.ACCREDITATION_TEMPLATE,
    });
  }

  @PermissionCode(EXPORT_AREA_PERMISSION.code)
  @Get(`/${TypeEnum.AREA}`)
  @ApiOperation({
    tags: ['Export Area'],
    summary: 'Export Area',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportArea(@Query() payload: ExportRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.AREA,
    });
  }

  @PermissionCode(EXPORT_ARTICLE_DEVICE_GROUP_PERMISSION.code)
  @Get(`/${TypeEnum.ARTICLE_DEVICE_GROUP}`)
  @ApiOperation({
    tags: ['Export ArticleDeviceGroup'],
    summary: 'Export ArticleDeviceGroup',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportArticleDeviceGroup(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.ARTICLE_DEVICE_GROUP,
    });
  }

  @PermissionCode(EXPORT_ATTRIBUTE_TYPE_PERMISSION.code)
  @Get(`/${TypeEnum.ATTRIBUTE_TYPE}`)
  @ApiOperation({
    tags: ['Export AttributeType'],
    summary: 'Export AttributeType',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportAttributeType(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.ATTRIBUTE_TYPE,
    });
  }

  @PermissionCode(EXPORT_CHECKLIST_TEMPLATE_PERMISSION.code)
  @Get(`/${TypeEnum.CHECKLIST_TEMPLATE}`)
  @ApiOperation({
    tags: ['Export ChecklistTemplate'],
    summary: 'Export ChecklistTemplate',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportChecklistTemplate(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.CHECKLIST_TEMPLATE,
    });
  }

  @PermissionCode(EXPORT_DEVICE_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get(`/${TypeEnum.DEVICE}`)
  @ApiOperation({
    tags: ['Export Device'],
    summary: 'Export Device',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportDevice(@Query() payload: ExportRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.DEVICE,
    });
  }

  @PermissionCode(EXPORT_DEVICE_GROUP_PERMISSION.code)
  @Get(`/${TypeEnum.DEVICE_GROUP}`)
  @ApiOperation({
    tags: ['Export DeviceGroup'],
    summary: 'Export DeviceGroup',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportDeviceGroup(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.DEVICE_GROUP,
    });
  }

  @PermissionCode(EXPORT_DEVICE_INVENTORY_PERMISSION.code)
  @Get(`/${TypeEnum.DEVICE_INVENTORY}`)
  @ApiOperation({
    tags: ['Export DeviceInventory'],
    summary: 'Export DeviceInventory',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportDeviceInventory(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.DEVICE_INVENTORY,
    });
  }

  @PermissionCode(EXPORT_DEVICE_TYPE_PERMISSION.code)
  @Get(`/${TypeEnum.DEVICE_TYPE}`)
  @ApiOperation({
    tags: ['Export DeviceType'],
    summary: 'Export DeviceType',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportDeviceType(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.DEVICE_TYPE,
    });
  }
  @PermissionCode(EXPORT_ERROR_TYPE_PERMISSION.code)
  @Get(`/${TypeEnum.ERROR_TYPE}`)
  @ApiOperation({
    tags: ['Export ErrorType'],
    summary: 'Export ErrorType',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportErrorType(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.ERROR_TYPE,
    });
  }

  @PermissionCode(EXPORT_INSTALLATION_TEMPLATE_PERMISSION.code)
  @Get(`/${TypeEnum.INSTALLATION_TEMPLATE}`)
  @ApiOperation({
    tags: ['Export Installation_template'],
    summary: 'Export Installation_template',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportInstallation_template(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.INSTALLATION_TEMPLATE,
    });
  }

  @PermissionCode(EXPORT_INVENTORY_DEVICE_GROUP_PERMISSION.code)
  @Get(`/${TypeEnum.INVENTORY_DEVICE_GROUP}`)
  @ApiOperation({
    tags: ['Export InventoryDeviceGroup'],
    summary: 'Export InventoryDeviceGroup',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportInventoryDeviceGroup(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.INVENTORY_DEVICE_GROUP,
    });
  }

  @PermissionCode(EXPORT_INVENTORY_SUPPLY_PERMISSION.code)
  @Get(`/${TypeEnum.INVENTORY_SUPPLY}`)
  @ApiOperation({
    tags: ['Export InventorySupply'],
    summary: 'Export InventorySupply',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportInventorySupply(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.INVENTORY_SUPPLY,
    });
  }

  @PermissionCode(EXPORT_MAINTENANCE_ATTRIBUTE_PERMISSION.code)
  @Get(`/${TypeEnum.MAINTENANCE_ATTRIBUTE}`)
  @ApiOperation({
    tags: ['Export MaintenanceAttribute'],
    summary: 'Export MaintenanceAttribute',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportMaintenanceAttribute(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.MAINTENANCE_ATTRIBUTE,
    });
  }

  @PermissionCode(EXPORT_MAINTENANCE_TEAM_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get(`/${TypeEnum.MAINTENANCE_TEAM}`)
  @ApiOperation({
    tags: ['Export MaintenanceTeam'],
    summary: 'Export MaintenanceTeam',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportMaintenanceTeam(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.MAINTENANCE_TEAM,
    });
  }

  @PermissionCode(EXPORT_MAINTENANCE_TEMPLATE_PERMISSION.code)
  @Get(`/${TypeEnum.MAINTENANCE_TEMPLATE}`)
  @ApiOperation({
    tags: ['Export MaintenanceTemplate'],
    summary: 'Export MaintenanceTemplate',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportMaintenanceTemplate(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.MAINTENANCE_TEMPLATE,
    });
  }

  @PermissionCode(EXPORT_SUPPLY_PERMISSION.code)
  @Get(`/${TypeEnum.SUPPLY}`)
  @ApiOperation({
    tags: ['Export Supply'],
    summary: 'Export Supply',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportSupply(@Query() payload: ExportRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.SUPPLY,
    });
  }

  @PermissionCode(EXPORT_SUPPLY_GROUP_PERMISSION.code)
  @Get(`/${TypeEnum.SUPPLY_GROUP}`)
  @ApiOperation({
    tags: ['Export SupplyGroup'],
    summary: 'Export SupplyGroup',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportSupplyGroup(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.SUPPLY_GROUP,
    });
  }

  @PermissionCode(EXPORT_VENDOR_PERMISSION.code)
  @Get(`/${TypeEnum.VENDOR}`)
  @ApiOperation({
    tags: ['Export Vendor'],
    summary: 'Export Vendor',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportVendor(@Query() payload: ExportRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.VENDOR,
    });
  }

  @Get(`/${TypeEnum.WAREHOUSE}`)
  @UseInterceptors(PermissionInterceptor)
  @ApiOperation({
    tags: ['Export Warehouse'],
    summary: 'Export Warehouse',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportWarehouse(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.WAREHOUSE,
    });
  }

  @PermissionCode(EXPORT_DEVICE_NAME_PERMISSION.code)
  @Get(`/${TypeEnum.DEVICE_NAME}`)
  @ApiOperation({
    tags: ['Export device name'],
    summary: 'Export device name',
    description: 'Xuất danh sách',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportDeviceName(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.DEVICE_NAME,
    });
  }

  @PermissionCode(EXPORT_REPORT_NEW_INVESTMENT_DEVICE_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get(`/${TypeEnum.REPORT_NEW_INVESTMENT_DEVICE}`)
  @ApiOperation({
    tags: ['Export report new investment device'],
    summary: 'Export report new investment device',
    description: 'Xuất danh sách',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportReportNewInvestmentDevice(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.REPORT_NEW_INVESTMENT_DEVICE,
    });
  }

  @PermissionCode(EXPORT_OPERATION_VALUE_PERMISSION.code)
  @Get(`/${TypeEnum.OPERATION_VALUE}`)
  @ApiOperation({
    tags: ['Export operation value'],
    summary: 'Export operation value',
    description: 'Xuất danh sách',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportOperationValue(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.OPERATION_VALUE,
    });
  }

  @PermissionCode(EXPORT_REPORT_DEVICE_TRANSFER_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get(`/${TypeEnum.REPORT_TRANSFER}`)
  @ApiOperation({
    tags: ['Export report transfer'],
    summary: 'Export report transfer',
    description: 'Xuất danh sách',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportReportTransfer(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.REPORT_TRANSFER,
    });
  }

  @PermissionCode(EXPORT_REPORT_DETAIL_DEVICE_TRANSFER_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get(`/${TypeEnum.REPORT_TRANSFER_DETAIL}`)
  @ApiOperation({
    tags: ['Export report transfer detail'],
    summary: 'Export report transfer detail',
    description: 'Xuất chi tiết',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportReportTransferDetail(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.REPORT_TRANSFER_DETAIL,
    });
  }

  @PermissionCode(EXPORT_REPORT_DEVICE_SYNTHESIS_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get(`/${TypeEnum.REPORT_DEVICE_SYNTHESIS}`)
  @ApiOperation({
    tags: ['Export device synthesis'],
    summary: 'Export device synthesis',
    description: 'Xuất danh sách',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportDeviceSynthesis(
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.REPORT_DEVICE_SYNTHESIS,
    });
  }

  @PermissionCode(EXPORT_REPORT_DEVICE_MAINTENANCE_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @Get(`/${TypeEnum.REPORT_DEVICE_MAINTENANCE}`)
  @ApiOperation({
    tags: ['Export device maintenance'],
    summary: 'Export device maintenance',
    description: 'Xuất danh sách',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportDeviceMaintenance(
    @Query() payload: GetMaintenancePlanReportRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.exportService.export({
      ...request,
      type: TypeEnum.REPORT_DEVICE_MAINTENANCE,
    });
  }
}
