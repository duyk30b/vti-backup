import { REPORT_TYPE_ENUM } from '@constant/common';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { Transform } from 'class-transformer';
import { IsEnum, IsNumber, IsOptional, IsString } from 'class-validator';

export class ExportRequestDto extends PaginationQuery {
  @ApiPropertyOptional({
    example: '[{"id": "1", "itemId": "2"}]',
  })
  @IsOptional()
  @IsString()
  queryIds?: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  columnSettings: string;

  @ApiProperty()
  @IsOptional()
  type: number;

  @ApiProperty()
  @IsEnum(REPORT_TYPE_ENUM)
  @Transform(({ value }) => +value)
  @IsOptional()
  timeUnit: number;

  @ApiProperty()
  @IsNumber()
  @Transform((data) => +data.value)
  @IsOptional()
  fromFactoryId: number;

  @ApiProperty()
  @IsNumber()
  @Transform((data) => +data.value)
  @IsOptional()
  toFactoryId: number;
}
