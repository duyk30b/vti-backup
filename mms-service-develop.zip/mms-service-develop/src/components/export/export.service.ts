import { DeviceNameRepositoryInterface } from '@components/device-name/interface/device-name.repository.interface';
import { GetListMaintenanceAttributeRequestDto } from './../maintenance-attribute/dto/request/get-list-maintenance-attribute.request.dto';
import { GetListAttributeTypeQuery } from '@components/attribute-type/dto/request/get-list-attribute-type.query';
import { GetListCheckListTemplateRequestDto } from '@components/checklist-template/dto/request/get-list-checklist-template.request.dto';
import { CheckListTemplateRepositoryInterface } from '@components/checklist-template/interface/checklist-template.repository.interface';
import { AttributeTypeRepositoryInterface } from './../attribute-type/interface/attribute-type.repository.interface';
import { MaintenanceAttributeRepositoryInterface } from '@components/maintenance-attribute/interface/maintenance-attribute.repository.interface';
import { SupplyGroupRepositoryInterface } from '@components/supply-group/interface/supply-group.repository.interface';
import { GetListSupplyGroupRequestDto } from '@components/supply-group/dto/request/get-list-supply-group.request.dto';
import { SupplyRepositoryInterface } from './../supply/interface/supply.repository.interface';
import { GetListSupplyRequestDto } from './../supply/dto/request/get-list-supply.request.dto';
import { GetListDeviceGroupRequestDto } from '@components/device-group/dto/request/get-list-device-group.request.dto';
import { DeviceGroupRepositoryInterface } from '@components/device-group/interface/device-group.repository.interface';
import { GetListInstallationTemplateQuery } from '@components/installation-template/dto/query/get-list-installation-template.query';
import { InstallationTemplateRepositoryInterface } from '@components/installation-template/interface/installation-template.repository';
import { MaintenanceTeamRepositoryInterface } from '@components/maintenance-team/interface/maintenance-team.repository.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { Workbook, Font, Alignment, Borders } from 'exceljs';
import {
  isEmpty,
  keyBy,
  map,
  uniq,
  compact,
  first,
  has,
  flatMap,
  round,
} from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ExportRequestDto } from './dto/request/export.request.dto';
import {
  EXCEL_STYLE,
  MAX_NUMBER_PAGE,
  ROW,
  SHEET,
  TypeEnum,
} from './export.constant';
import { ExportServiceInterface } from './interface/export.service.interface';
import { DeviceRepositoryInterface } from '@components/device/interface/device.repository.interface';
import {
  ASSET_TYPE_ENUM,
  DEVICE_STATUS_ENUM,
  IS_FIXED_ASSET,
} from '@components/device/device.constant';
import { GetListMaintenanceTeamRequestDto } from '@components/maintenance-team/dto/request/get-list-maintenace-team.request.dto';
import { DeviceRequestRepositoryInterface } from '@components/device-request/interface/device-request-ticket.repository.interface';
import { AreaRepositoryInterface } from '@components/area/interface/area.repository.interface';
import { GetListAreaQuery } from '@components/area/dto/request/get-list-area.query';
import { ErrorTypeRepositoryInterface } from '@components/error-type/interface/error-type.repository.interface';
import { GetListErrorTypeQuery } from '@components/error-type/dto/request/get-list-error-type.query';
import { VendorRepositoryInterface } from '@components/vendor/interface/vendor.repository.interface';
import { GetListVendorRequestDto } from '@components/vendor/dto/request/get-list-vendor.request.dto';
import { GetListDevicesRequestDto } from '@components/device/dto/request/list-devices.request.dto';
import { ListDeviceTypeRequestDto as ListDeviceNameRequestDto } from '@components/device-type/dto/request/list-device-type.dto';
import { DeviceTypeRepositoryInterface } from '@components/device-type/interface/device-type.repository.interface';
import { ListDeviceAssignmentQuery } from '@components/device-assignment/dto/query/list-device-assignment.query';
import { DeviceAssignmentRepositoryInterface } from '@components/device-assignment/interface/device-assignment.repository.interface';
import { DEVICE_ASSIGNMENTS_STATUS_ENUM } from '@components/device-assignment/device-assignment.constant';
import { ArticleDeviceGroupRepositoryInterface } from '@components/article-device-group/interface/article-device-group.repository.interface';
import { ListArticleDeviceGroupRequestDto } from '@components/article-device-group/dto/request/list-article-device-group.request.dto';
import { MaintenanceTemplateRepositoryInterface } from '@components/maintenance-template/interface/maintenance-template.repository.interface';
import { GetListMaintenanceTemplateRequestDto } from '@components/maintenance-template/dto/request/get-list-maintenance-template.request.dto';
import {
  ACTIVE_ENUM,
  DATE_FORMAT_EXPORT,
  OBLIGATORY_ENUM,
  REPORT_TYPE_ENUM,
} from '@constant/common';
import { MAINTENANCE_JOB_TYPE } from '@components/maintenance-template/maintenance-template.constant';
import { ERROR_TYPE_PRIORITY_ENUM } from '@components/error-type/error-type.constant';
import { GetListAccreditationTemplateRequest } from '@components/accreditation-template/dto/request/list-accreditation-request.dto';
import { AccreditationTemplateRepositoryInterface } from '@components/accreditation-template/interface/accreditation-template.repository.interface';
import { DEVICE_REQUEST_TYPE_ENUM } from '@components/device-request/device-request.constant';
import { CAN_UPDATE_STATUS } from '@components/device-group/device-group.constant';
import { MAINTENANCE_TEAM_ROLE } from '@components/maintenance-team/maintenance-team.constant';
import { ListDeviceRequestsRequestDto } from '@components/device-request/dto/request/list-device-requests.request.dto';
import { GetWarehouseInventoriesQueryDto } from '@components/warehouse/dto/request/get-warehouse-inventories.request';
import { ASSET_INVENTORY_ENUM } from '@components/warehouse/warehouse.constant';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { GetInventoryByWarehouseAndDeviceGroupRequestDto } from '@components/warehouse/dto/request/get-inventories-by-warehouse-and-device-group.request.dto';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import * as moment from 'moment';
import { OperationValueRepositoryInterface } from '@components/operation-value/interface/operation-value.repository.interface';
import { GetListOperationValueQuery } from '@components/operation-value/dto/request/get-list-operation-value.query';
import { OperationIndexRepositoryInterface } from '@components/operation-index/interface/operation-index.repository.interface';
import { TransferTicketRepositoryInterface } from '@components/transfer-ticket/interface/transfer-ticket.repository.interface';
import { div, plus } from '@utils/helper';
import { TRANSFER_REQUEST_TYPE_ENUM } from '@components/transfer-request/transfer-request.constant';
import { ReportDetailTransferTicketRequest } from '@components/report/dto/request/detail-report-transfer-ticket.request';
import { ReportServiceInterface } from '@components/report/interface/report.service.interface';
import { DEVICE_STATUS_STATE_ENUM } from '@components/device-status/device-status.constant';
import { GetDeviceMaintenanceReportRequest } from '@components/report/dto/request/get-device-maintenance-report.request';
import { REPORT_UNIT_TYPE_ENUM } from '@components/report/report.constant';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { Supply } from 'src/models/supply/supply.model';
import { convertWithCommas } from 'src/helper/export.helper';
@Injectable()
export class ExportService implements ExportServiceInterface {
  constructor(
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('SupplyRepositoryInterface')
    private readonly supplyRepository: SupplyRepositoryInterface,

    @Inject('DeviceGroupRepositoryInterface')
    private readonly deviceGroupRepository: DeviceGroupRepositoryInterface,

    @Inject('DeviceRepositoryInterface')
    private readonly deviceRepository: DeviceRepositoryInterface,

    @Inject('AttributeTypeRepositoryInterface')
    private readonly attributeTypeRepository: AttributeTypeRepositoryInterface,

    @Inject('MaintenanceAttributeRepositoryInterface')
    private readonly maintenanceAttributeRepository: MaintenanceAttributeRepositoryInterface,

    @Inject('SupplyGroupRepositoryInterface')
    private readonly supplyGroupRepository: SupplyGroupRepositoryInterface,

    @Inject('MaintenanceTeamRepositoryInterface')
    private readonly maintenanceTeamRepository: MaintenanceTeamRepositoryInterface,

    @Inject('CheckListTemplateRepositoryInterface')
    private readonly checkListTemplateRepository: CheckListTemplateRepositoryInterface,

    @Inject('InstallationTemplateRepositoryInterface')
    private readonly installationTemplateRepository: InstallationTemplateRepositoryInterface,

    @Inject('DeviceRequestRepositoryInterface')
    private readonly deviceRequestRepository: DeviceRequestRepositoryInterface,

    @Inject('AreaRepositoryInterface')
    private readonly areaRepository: AreaRepositoryInterface,

    @Inject('ErrorTypeRepositoryInterface')
    private readonly errorTypeRepository: ErrorTypeRepositoryInterface,
    @Inject('VendorRepositoryInterface')
    private readonly vendorRepository: VendorRepositoryInterface,

    @Inject('DeviceTypeRepositoryInterface')
    private readonly deviceTypeRepository: DeviceTypeRepositoryInterface,

    @Inject('DeviceAssignmentRepositoryInterface')
    private readonly deviceAssignmentRepository: DeviceAssignmentRepositoryInterface,

    @Inject('ArticleDeviceGroupRepositoryInterface')
    private readonly articleDeviceGroupRepository: ArticleDeviceGroupRepositoryInterface,

    @Inject('MaintenanceTemplateRepositoryInterface')
    private readonly maintenanceTemplateRepository: MaintenanceTemplateRepositoryInterface,

    @Inject('AccreditationTemplateRepositoryInterface')
    private readonly accreditationTemplateRepository: AccreditationTemplateRepositoryInterface,

    @Inject('DeviceNameRepositoryInterface')
    private readonly deviceNameRepository: DeviceNameRepositoryInterface,

    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,

    @Inject('OperationValueRepositoryInterface')
    private readonly operationValueRepository: OperationValueRepositoryInterface,

    @Inject('OperationIndexRepositoryInterface')
    private readonly operationIndexRepository: OperationIndexRepositoryInterface,

    @Inject('TransferTicketRepositoryInterface')
    private readonly transferTicketRepository: TransferTicketRepositoryInterface,

    @Inject('ReportServiceInterface')
    private readonly reportService: ReportServiceInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}
  async export(request: any): Promise<any> {
    const { queryIds, type } = request;

    if (!isEmpty(queryIds) && queryIds.length > ROW.LIMIT_EXPORT) {
      return new ResponseBuilder()
        .withMessage(
          await this.i18n.translate('error.LIMIT_EXPORT_ONE_SHEET_ERROR'),
        )
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }

    let workbook;
    switch (type) {
      case TypeEnum.DEVICE_GROUP:
        workbook = await this.exportDeviceGroup(request);
        break;
      case TypeEnum.CHECKLIST_TEMPLATE:
        workbook = await this.exportTemplateChecklist(request);
        break;
      case TypeEnum.INSTALLATION_TEMPLATE:
        workbook = await this.exportInstallationTemplate(request);
        break;
      case TypeEnum.ATTRIBUTE_TYPE:
        workbook = await this.exportAttributeType(request);
        break;
      case TypeEnum.MAINTENANCE_ATTRIBUTE:
        workbook = await this.exportMaintenanceAttributes(request);
        break;
      case TypeEnum.SUPPLY_GROUP:
        workbook = await this.exportSupplyGroup(request);
        break;
      case TypeEnum.SUPPLY:
        workbook = await this.exportSupply(request);
        break;
      case TypeEnum.DEVICE:
        workbook = await this.exportDevice(request);
        break;
      case TypeEnum.MAINTENANCE_TEAM:
        workbook = await this.exportMaintenanceTeam(request);
        break;
      case TypeEnum.DEVICE_REQUEST:
        workbook = await this.exportDeviceRequest(request);
        break;
      case TypeEnum.AREA:
        workbook = await this.exportArea(request);
        break;
      case TypeEnum.ERROR_TYPE:
        workbook = await this.exportErrorType(request);
        break;
      case TypeEnum.VENDOR:
        workbook = await this.exportVendor(request);
        break;
      case TypeEnum.DEVICE_TYPE:
        workbook = await this.exportDeviceType(request);
        break;
      case TypeEnum.ARTICLE_DEVICE_GROUP:
        workbook = await this.exportArticleDeviceGroup(request);
        break;
      case TypeEnum.DEVICE_ASSIGNMENT:
        workbook = await this.exportDeviceAssignment(request);
        break;
      case TypeEnum.MAINTENANCE_TEMPLATE:
        workbook = await this.exportMaintenanceTemplate(request);
        break;
      case TypeEnum.ACCREDITATION_TEMPLATE:
        workbook = await this.exportAccreditationTemplate(request);
        break;
      case TypeEnum.INVENTORY_DEVICE_GROUP:
        workbook = await this.exportInventoryDeviceGroup(request);
        break;
      case TypeEnum.INVENTORY_SUPPLY:
        workbook = await this.exportInventorySupply(request);
        break;
      case TypeEnum.DEVICE_INVENTORY:
        workbook = await this.exportDeviceInventory(request);
        break;
      case TypeEnum.DEVICE_NAME:
        workbook = await this.exportDeviceName(request);
        break;
      case TypeEnum.REPORT_NEW_INVESTMENT_DEVICE:
        workbook = await this.exportReportNewInvestmentDevice(request);
        break;
      case TypeEnum.OPERATION_VALUE:
        workbook = await this.exportOperationValue(request);
        break;
      case TypeEnum.REPORT_TRANSFER:
        workbook = await this.exportReportTransfer(request);
        break;
      case TypeEnum.REPORT_TRANSFER_DETAIL:
        workbook = await this.exportReportTransferDetail(request);
        break;
      case TypeEnum.REPORT_DEVICE_SYNTHESIS:
        workbook = await this.exportReportDeviceSynthesis(request);
        break;
      case TypeEnum.REPORT_DEVICE_MAINTENANCE:
        workbook = await this.exportMaintenancePlan(request);
        break;
      default:
        break;
    }
    if (workbook?.xlsx) {
      await workbook.xlsx.writeFile('excel.xlsx');
      const file = await workbook.xlsx.writeBuffer();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .withData(file)
        .build();
    } else {
      return workbook;
    }
  }

  async exportTemplateChecklist(payload: ExportRequestDto) {
    let checklistTemplates = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListCheckListTemplateRequestDto();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      const { result } = await this.checkListTemplateRepository.getList(
        request,
      );
      if (!isEmpty(result)) {
        checklistTemplates = checklistTemplates.concat(result);
      }
      if (result.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!checklistTemplates || isEmpty(checklistTemplates)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }
    const columnSettings = JSON.parse(payload.columnSettings);
    const checklistTemplateHeader = await this.i18n.translate(
      'export.checklistTemplate',
    );
    const headers = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: {
        alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
      },
      title: checklistTemplateHeader[el],
    }));
    const headerSub = [
      {
        key: 'code',
        width: 25,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.checklistTemplate.code'),
      },
      {
        key: 'title',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.checklistTemplate.details.title',
        ),
      },
      {
        key: 'description',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.checklistTemplate.details.description',
        ),
      },
      {
        key: 'obligatory',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.checklistTemplate.details.obligatory',
        ),
      },
    ];

    const commonText = await this.i18n.translate('export.common');

    const items = [];
    for (const checklistTemplate of checklistTemplates) {
      const item = {
        code: checklistTemplate.code ?? '',
        name: checklistTemplate.name ?? '',
        description: checklistTemplate.description ?? '',
        active:
          checklistTemplate.active === ACTIVE_ENUM.ACTIVE
            ? commonText.active
            : commonText.inactive,
        subItem: [],
        level: 1,
      };
      for (const detail of checklistTemplate.details) {
        item.subItem.push({
          code: checklistTemplate.code ?? '',
          title: detail.title ?? '',
          description: detail.description ?? '',
          obligatory:
            detail.obligatory === OBLIGATORY_ENUM.YES
              ? commonText.yes
              : commonText.no,
          level: 2,
        });
      }
      items.push(item);
    }

    const titleMap = new Map();
    const headerMap = new Map();
    titleMap.set(1, [checklistTemplateHeader.title]);
    titleMap.set(2, [
      await this.i18n.translate('export.checklistTemplate.details.headerTitle'),
    ]);

    headerMap.set(1, headers);
    headerMap.set(2, headerSub);
    const workbook = new Workbook();

    return await this.exportMultiSheetUtil(
      workbook,
      items,
      1,
      titleMap,
      headerMap,
    );
  }

  async exportInstallationTemplate(payload: ExportRequestDto) {
    let installationTemplates = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListInstallationTemplateQuery();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      const { data } = await this.installationTemplateRepository.list(request);
      if (!isEmpty(data)) {
        installationTemplates = installationTemplates.concat(data);
      }

      if (data.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!installationTemplates || isEmpty(installationTemplates)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }
    const columnSettings = JSON.parse(payload.columnSettings);
    const installationTemplateHeader = await this.i18n.translate(
      'export.installationTemplate',
    );
    const headers = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: {
        alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
      },
      title: installationTemplateHeader[el],
    }));

    const headerSub = [
      {
        key: 'code',
        width: 25,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.installationTemplate.code'),
      },
      {
        key: 'title',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.installationTemplate.details.title',
        ),
      },
    ];

    const active = await this.i18n.translate('export.common.active');
    const inactive = await this.i18n.translate('export.common.inactive');
    const textYes = await this.i18n.translate('export.common.yes');
    const textNo = await this.i18n.translate('export.common.no');

    const items = [];
    for (const installationTemplate of installationTemplates) {
      const item = {
        code: installationTemplate.code ?? '',
        name: installationTemplate.name ?? '',
        description: installationTemplate.description ?? '',
        active:
          installationTemplate.active === ACTIVE_ENUM.ACTIVE
            ? active
            : inactive,
        subItem: [],
        level: 1,
      };
      for (const detail of installationTemplate.details) {
        item.subItem.push({
          code: installationTemplate.code ?? '',
          title: detail.title ?? '',
          description: detail.description ?? '',
          obligatory:
            detail.obligatory === OBLIGATORY_ENUM.YES ? textYes : textNo,
          level: 2,
        });
      }
      items.push(item);
    }

    const titleMap = new Map();
    const headerMap = new Map();
    titleMap.set(1, [installationTemplateHeader.title]);
    titleMap.set(2, [
      await this.i18n.translate(
        'export.installationTemplate.details.headerTitle',
      ),
    ]);

    headerMap.set(1, headers);
    headerMap.set(2, headerSub);
    const workbook = new Workbook();

    return await this.exportMultiSheetUtil(
      workbook,
      items,
      1,
      titleMap,
      headerMap,
    );
  }

  async exportAttributeType(payload: ExportRequestDto) {
    let attributeTypes = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListAttributeTypeQuery();
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      const { data } = await this.attributeTypeRepository.list(request);
      if (!isEmpty(data)) {
        attributeTypes = attributeTypes.concat(data);
      }
      if (data.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!attributeTypes || isEmpty(attributeTypes)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }
    const unitIds = map(attributeTypes, 'unitId');
    const units = await this.itemService.getListUnit([
      {
        column: 'ids',
        text: uniq(unitIds).toString(),
      },
    ]);
    const unitMap = keyBy(units, 'id');
    const columnSettings = JSON.parse(payload.columnSettings);
    const attributeTypeHeader = await this.i18n.translate(
      'export.attributeType',
    );
    const headers = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: {
        alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
      },
      title: attributeTypeHeader[el],
    }));

    const active = await this.i18n.translate('export.common.active');
    const inactive = await this.i18n.translate('export.common.inactive');

    const items = attributeTypes?.map((attributeType) => {
      const item = {
        code: attributeType.code ?? '',
        name: attributeType.name ?? '',
        description: attributeType.description ?? '',
        unit: unitMap[attributeType.unitId]?.name ?? '',
        active: attributeType.active === ACTIVE_ENUM.ACTIVE ? active : inactive,
      };

      return item;
    });

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [attributeTypeHeader.title],
      headers,
    );
    return workbook;
  }

  async exportMaintenanceAttributes(payload: ExportRequestDto) {
    let maintenanceAttributes = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListMaintenanceAttributeRequestDto();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds)).join(',');
      }
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      const { result } = await this.maintenanceAttributeRepository.getList(
        request,
      );
      if (!isEmpty(result)) {
        maintenanceAttributes = maintenanceAttributes.concat(result);
      }
      if (result.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!maintenanceAttributes || isEmpty(maintenanceAttributes)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const columnSettings = JSON.parse(payload.columnSettings);
    const maintenanceAttributeHeader = await this.i18n.translate(
      'export.maintenanceAttribute',
    );
    const headers = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: {
        alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
      },
      title: maintenanceAttributeHeader[el],
    }));
    const commonText = await this.i18n.translate('export.common');

    const items = maintenanceAttributes?.map((maintenanceAttribute) => {
      const item = {
        code: maintenanceAttribute.code ?? '',
        name: maintenanceAttribute.name ?? '',
        description: maintenanceAttribute.description ?? '',
        active:
          maintenanceAttribute?.active === ACTIVE_ENUM.ACTIVE
            ? commonText.active
            : commonText.inactive,
      };

      return item;
    });

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [maintenanceAttributeHeader.title],
      headers,
    );
    return workbook;
  }

  async exportAccreditationTemplate(payload: ExportRequestDto) {
    let accreditationTemplates = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListAccreditationTemplateRequest();
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      const { data } = await this.accreditationTemplateRepository.list(request);
      if (!isEmpty(data)) {
        accreditationTemplates = accreditationTemplates.concat(data);
      }
      if (data.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!accreditationTemplates || isEmpty(accreditationTemplates)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const columnSettings = JSON.parse(payload.columnSettings);
    const accreditationTemplateHeader = await this.i18n.translate(
      'export.accreditationTemplate',
    );
    const headers = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: {
        alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
      },
      title: accreditationTemplateHeader[el],
    }));

    const headerSub = [
      {
        key: 'code',
        width: 25,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.accreditationTemplate.code'),
      },
      {
        key: 'title',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.accreditationTemplate.details.title',
        ),
      },
      {
        key: 'obligatory',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.accreditationTemplate.details.obligatory',
        ),
      },
      {
        key: 'description',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.accreditationTemplate.details.description',
        ),
      },
    ];
    const commonText = await this.i18n.translate('export.common');

    const items = [];
    for (const accreditationTemplate of accreditationTemplates) {
      const item = {
        code: accreditationTemplate.code ?? '',
        name: accreditationTemplate.name ?? '',
        description: accreditationTemplate.description ?? '',
        periodic: accreditationTemplate.periodic ?? '',
        active:
          accreditationTemplate.active === ACTIVE_ENUM.ACTIVE
            ? commonText.active
            : commonText.inactive,
        subItem: [],
        level: 1,
      };
      for (const detail of accreditationTemplate.details) {
        item.subItem.push({
          code: accreditationTemplate.code ?? '',
          title: detail.title ?? '',
          description: detail.description ?? '',
          obligatory:
            detail.obligatory === OBLIGATORY_ENUM.YES
              ? commonText.yes
              : commonText.no,
          level: 2,
        });
      }
      items.push(item);
    }

    const titleMap = new Map();
    const headerMap = new Map();
    titleMap.set(1, [accreditationTemplateHeader.title]);
    titleMap.set(2, [accreditationTemplateHeader.details.title]);

    headerMap.set(1, headers);
    headerMap.set(2, headerSub);
    const workbook = new Workbook();

    return await this.exportMultiSheetUtil(
      workbook,
      items,
      1,
      titleMap,
      headerMap,
    );
  }

  async exportSupplyGroup(payload: ExportRequestDto) {
    let supplyGroups = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListSupplyGroupRequestDto();
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      const { data } = await this.supplyGroupRepository.getList(request);
      if (!isEmpty(data)) {
        supplyGroups = supplyGroups.concat(data);
      }
      if (data.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!supplyGroups || isEmpty(supplyGroups)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const commonText = await this.i18n.translate('export.common');

    const columnSettings = JSON.parse(payload.columnSettings);
    const supplyGroupHeader = await this.i18n.translate('export.supplyGroup');
    const headers = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: {
        alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
      },
      title: supplyGroupHeader[el],
    }));

    const items = supplyGroups?.map((supplyGroup) => {
      const item = {
        code: supplyGroup.code ?? '',
        name: supplyGroup.name ?? '',
        active: supplyGroup.active ? commonText.active : commonText.inactive,
        description: supplyGroup.description ?? '',
      };
      return item;
    });

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [supplyGroupHeader.title],
      headers,
    );
    return workbook;
  }

  async exportSupply(payload: ExportRequestDto) {
    let supplies: Supply[] = [];
    const columnSettings = JSON.parse(payload.columnSettings);
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListSupplyRequestDto();
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      const { result } = await this.supplyRepository.getList(request);
      if (!isEmpty(result)) {
        supplies = supplies.concat(result);
      }
      if (result.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!supplies || isEmpty(supplies)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }
    const unitIds = map(supplies, 'unitId');
    const units = await this.itemService.getListUnit([
      {
        column: 'ids',
        text: uniq(unitIds).toString(),
      },
    ]);
    const unitMap = keyBy(units, 'id');
    const supplyHeader = await this.i18n.translate('export.supply');
    const headers = columnSettings.map((el: string) => ({
      key: el,
      width: 25,
      style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      title: supplyHeader[el],
    }));
    const active = await this.i18n.translate('export.common.active');
    const inactive = await this.i18n.translate('export.common.inactive');

    const items = supplies?.map((supply) => {
      const item = {
        code: supply.code ?? '',
        name: supply.name ?? '',
        nameOther: supply.nameOther ?? '',
        supplyGroupName: supply['supplyGroup']?.name ?? '',
        type: supply.supplyType?.name ?? '',
        unit: unitMap[supply.unitId]?.name ?? '',
        vendor: supply['vendor']?.name ?? '',
        price: convertWithCommas(supply.price ?? 0),
        description: supply.description ?? '',
        active: supply.active === ACTIVE_ENUM.ACTIVE ? active : inactive,
        updatedAt: supply?.updatedAt,
      };

      return item;
    });

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [await this.i18n.translate('export.supply.title')],
      headers,
    );
    return workbook;
  }

  async exportDevice(payload: ExportRequestDto) {
    let factories: any;
    let devices: any[] = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListDevicesRequestDto();
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      request.user = payload.user;
      request.keyword = payload.keyword;
      request.isMasterData = 1;
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      const { result } = await this.deviceRepository.list(request);
      if (!isEmpty(result)) {
        devices = devices.concat(result);
      }
      if (result?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }
    if (!devices || isEmpty(devices)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const factoryIds = compact(uniq(devices.map((device) => device.factoryId)));
    if (!isEmpty(factoryIds)) {
      factories = await this.userService.getFactoryList([
        {
          column: 'factoryIds',
          text: factoryIds,
        },
      ]);
    }
    const factoryMap = keyBy(factories, 'id');

    const columnSettings = JSON.parse(payload.columnSettings);
    const deviceText = await this.i18n.translate('export.device');
    const headers = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      title: deviceText[el],
    }));

    const status = new Map();
    const textCommon = await this.i18n.translate('export.common');
    const deviceUseStatus = textCommon.deviceUseStatus;
    status.set(
      DEVICE_STATUS_ENUM.AWAIT_CLEARANCE,
      deviceUseStatus.awaitClearance,
    );
    status.set(DEVICE_STATUS_ENUM.BROKEN, deviceUseStatus.broken);
    status.set(DEVICE_STATUS_ENUM.PREVENTIVE, deviceUseStatus.preventive);
    status.set(DEVICE_STATUS_ENUM.USELESS, deviceUseStatus.useless);
    status.set(DEVICE_STATUS_ENUM.USING, deviceUseStatus.using);
    const items = [];
    for (const device of devices) {
      const item = {
        code: device?.code ?? '',
        name: device?.name ?? '',
        serial: device?.serial ?? '',
        actualSerial: device?.actualSerial ?? '',
        factory: factoryMap[device?.factoryId]?.name ?? '',
        area: device?.area?.[0]?.name ?? '',
        model: device?.model ?? '',
        vendor: device?.vendor?.[0]?.name ?? '',
        manufacturer: device?.manufacturer ?? '',
        identificationNo: device?.identificationNo ?? '',
        deviceGroup: device?.deviceGroup?.[0]?.name ?? '',
        deviceGroupCode: device?.deviceGroup?.[0]?.code ?? '',
        articleDeviceGroupCode: device?.articleDeviceGroup?.[0]?.code ?? '',
        articleDeviceGroupName: device?.articleDeviceGroup?.[0]?.name ?? '',
        deviceType: device?.deviceType?.[0]?.name ?? '',
        warehouse: device?.warehouse?.[0]?.name ?? '',
        depreciation: device?.depreciation ?? '',
        type:
          device?.assetType === ASSET_TYPE_ENUM.RENT
            ? deviceText.rent
            : deviceText.buy,
        manufactureDate: device?.manufactureDate
          ? moment(device?.manufactureDate).format(DATE_FORMAT_EXPORT)
          : '',
        creationDate: device?.creationDate
          ? moment(device?.creationDate).format(DATE_FORMAT_EXPORT)
          : '',
        capitalizationDate: moment(
          device?.capitalizationDate ?? device?.createdAt,
        ).format(DATE_FORMAT_EXPORT),
        warrantyPeriod: device?.warrantyPeriod ?? '',
        status: status.get(device?.status) ?? '',
        active:
          device?.active === ACTIVE_ENUM.ACTIVE
            ? deviceText.activeStatus
            : deviceText.inactiveStatus,
      };

      items.push(item);
    }

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [await this.i18n.translate('export.device.title')],
      headers,
    );
    return workbook;
  }

  async exportMaintenanceTemplate(payload: ExportRequestDto) {
    let maintenanceTemplates: any = [];
    const titleMap: any = new Map();
    const headerMap: any = new Map();

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListMaintenanceTemplateRequestDto();
      request.page = i;
      request.filter = payload.filter;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      const list = await this.maintenanceTemplateRepository.list(request);
      if (!isEmpty(list.data)) {
        maintenanceTemplates = [...maintenanceTemplates, ...list.data];
      }
      if (list?.data?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }
    if (!maintenanceTemplates || isEmpty(maintenanceTemplates)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }
    const columnSettings = JSON.parse(payload.columnSettings);
    const maintenanceTemplateText = await this.i18n.translate(
      'export.maintenanceTemplate',
    );
    const header = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      title: maintenanceTemplateText[el],
    }));

    const headerDetail = [
      {
        key: 'code',
        width: 25,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.maintenanceTemplate.code'),
      },
      {
        key: 'title',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.maintenanceTemplate.details.title',
        ),
      },
      {
        key: 'type',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.maintenanceTemplate.details.type',
        ),
      },

      {
        key: 'description',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.maintenanceTemplate.details.description',
        ),
      },

      {
        key: 'checklistTemplate',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.maintenanceTemplate.details.checklistTemplate',
        ),
      },
      {
        key: 'periodTime',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.maintenanceTemplate.details.periodTime',
        ),
      },
      {
        key: 'obligatory',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.maintenanceTemplate.details.obligatory',
        ),
      },
    ];
    const commonText = await this.i18n.translate('export.common');

    const items = [];
    for (const maintenanceTemplate of maintenanceTemplates) {
      const item = {
        code: maintenanceTemplate.code ?? '',
        name: maintenanceTemplate.name ?? '',
        description: maintenanceTemplate.description ?? '',
        active:
          maintenanceTemplate.active === ACTIVE_ENUM.ACTIVE
            ? commonText.active
            : commonText.inactive,
        subItem: [],
        level: 1,
      };

      for (const detail of maintenanceTemplate.details) {
        item.subItem.push({
          code: maintenanceTemplate.code ?? '',
          title: detail.title ?? '',
          type:
            detail?.type === MAINTENANCE_JOB_TYPE.CHECK
              ? 'Kiểm tra'
              : 'Bảo dưỡng',
          description: detail?.description ?? '',
          checklistTemplate: detail?.checklistTemplate?.name ?? '',
          periodTime: detail?.periodTime ?? '',
          obligatory: detail?.obligatory === 0 ? commonText.no : commonText.yes,
          level: 2,
        });
      }
      items.push(item);
    }

    titleMap.set(1, [
      await this.i18n.translate('export.maintenanceTemplate.title'),
    ]);
    titleMap.set(2, [
      await this.i18n.translate('export.maintenanceTemplate.details.TITLE'),
    ]);

    headerMap.set(1, header);
    headerMap.set(2, headerDetail);

    let workbook = new Workbook();
    workbook = await this.exportMultiSheetUtil(
      workbook,
      items,
      1,
      titleMap,
      headerMap,
    );
    return workbook;
  }

  async exportDeviceGroup(payload: ExportRequestDto) {
    let deviceGroups: any = [];
    const titleMap: any = new Map();
    const headerMap: any = new Map();

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListDeviceGroupRequestDto();
      request.page = i;
      request.filter = payload.filter;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      const { result } = await this.deviceGroupRepository.listToExport(request);
      if (!isEmpty(result)) {
        deviceGroups = [...deviceGroups, ...result];
      }
      if (result?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }
    if (!deviceGroups || isEmpty(deviceGroups)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }
    const columnSettings = JSON.parse(payload.columnSettings);
    const deviceGroupText = await this.i18n.translate('export.deviceGroup');
    const header = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      title: deviceGroupText[el],
    }));
    const headerMaintenanceIndex = [
      {
        key: 'code',
        width: 25,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceGroup.code'),
      },
      {
        key: 'supply',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.deviceGroup.maintenanceIndex.supply',
        ),
      },
      {
        key: 'type',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.deviceGroup.maintenanceIndex.type',
        ),
      },

      {
        key: 'maintenanceFrequency',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.deviceGroup.maintenanceIndex.maintenanceFrequency',
        ),
      },

      {
        key: 'mtbf',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.deviceGroup.maintenanceIndex.mtbf',
        ),
      },
      {
        key: 'mttr',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.deviceGroup.maintenanceIndex.mttr',
        ),
      },
      {
        key: 'mtta',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.deviceGroup.maintenanceIndex.mtta',
        ),
      },
      {
        key: 'mttf',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.deviceGroup.maintenanceIndex.mttf',
        ),
      },
    ];
    const headerSupplies = [
      {
        key: 'code',
        width: 25,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceGroup.code'),
      },
      {
        key: 'supply',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceGroup.supplies.supply'),
      },
      {
        key: 'type',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceGroup.supplies.type'),
      },

      {
        key: 'quantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.deviceGroup.supplies.quantity',
        ),
      },

      {
        key: 'estimateUsedTime',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.deviceGroup.supplies.estimateUsedTime',
        ),
      },
      {
        key: 'canFixable',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.deviceGroup.supplies.canFixable',
        ),
      },
    ];
    const textCommon = await this.i18n.translate('export.common');
    const textTypeMaintenanceIndex = await this.i18n.translate(
      'export.deviceGroup.maintenanceIndex',
    );

    const items = [];

    for (const deviceGroup of deviceGroups) {
      const item = {
        code: deviceGroup.code ?? '',
        name: deviceGroup.name ?? '',
        installationTemplate: deviceGroup.installationTemplate?.name ?? '',
        accreditationTemplate: deviceGroup.accreditationTemplate?.name ?? '',
        errorTypes:
          deviceGroup.errorTypes?.map((el) => el.name).join(', ') ?? '',
        attributeTypes:
          deviceGroup.attributeTypes?.map((el) => el.name).join(', ') ?? '',
        deviceType: deviceGroup.deviceType?.name ?? '',
        articleDeviceGroup: deviceGroup.articleDeviceGroup?.name ?? '',
        frequency: deviceGroup.frequency ?? '',
        maintenanceAttribute: deviceGroup.maintenanceAttribute?.name ?? '',
        maintenanceTemplate: deviceGroup.maintenanceTemplate?.name ?? '',
        active:
          deviceGroup.active === ACTIVE_ENUM.ACTIVE
            ? textCommon.active
            : textCommon.inactive,
        canUpdateStatus:
          deviceGroup.canUpdateStatus === CAN_UPDATE_STATUS.YES
            ? textCommon.yes
            : textCommon.no,
        subItem: [],
        subItemClone: [],
        level: 1,
      };
      for (const data of deviceGroup.supplies) {
        item.subItem.push({
          code: deviceGroup.code ?? '',
          supply: data.supply?.name ?? '',
          type: data.supply.supplyType?.name ?? '',
          quantity: data?.quantity ?? '',
          estimateUsedTime: data?.estimateUsedTime ?? '',
          canFixable: data?.canFixable === 0 ? textCommon.no : textCommon.yes,
          level: 2,
        });
      }

      for (const maintenanceInfo of deviceGroup.maintenanceIndex) {
        item.subItemClone.push({
          code: deviceGroup.code ?? '',
          supply: maintenanceInfo.supplyId
            ? maintenanceInfo.supply?.name
            : deviceGroup.name,
          type: maintenanceInfo.supplyId
            ? textTypeMaintenanceIndex.accessory
            : textTypeMaintenanceIndex.device,
          maintenanceFrequency: maintenanceInfo?.maintenanceFrequency ?? '',
          mtbf: maintenanceInfo?.mtbf ?? '',
          mttr: maintenanceInfo?.mttr ?? '',
          mtta: maintenanceInfo?.mtta ?? '',
          mttf: maintenanceInfo?.mttf ?? '',
          level: 3,
        });
      }
      items.push(item);
    }

    titleMap.set(1, [await this.i18n.translate('export.deviceGroup.title')]);
    titleMap.set(2, [
      await this.i18n.translate('export.deviceGroup.supplies.title'),
    ]);
    titleMap.set(3, [
      await this.i18n.translate('export.deviceGroup.maintenanceIndex.title'),
    ]);

    headerMap.set(1, header);
    headerMap.set(2, headerSupplies);
    headerMap.set(3, headerMaintenanceIndex);

    let workbook = new Workbook();
    workbook = await this.exportMultiSheetUtil(
      workbook,
      items,
      1,
      titleMap,
      headerMap,
    );
    return workbook;
  }

  async exportMaintenanceTeam(payload: ExportRequestDto) {
    let maintenanceTeams = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListMaintenanceTeamRequestDto();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.user = payload.user;
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      const { result } = await this.maintenanceTeamRepository.getList(request);
      if (!isEmpty(result)) {
        maintenanceTeams = maintenanceTeams.concat(result);
      }
      if (result.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    let userIds = [];
    let factoryIds = [];
    maintenanceTeams.forEach((maintenanceTeam) => {
      const leader = maintenanceTeam.members.find(
        (member) => member.role === MAINTENANCE_TEAM_ROLE.LEADER,
      );

      maintenanceTeam.leaderId = leader.userId;
      userIds.push(leader.userId);
      factoryIds.push(maintenanceTeam.factoryId);
    });
    userIds = compact(uniq(userIds));
    factoryIds = compact(uniq(factoryIds));

    const users = await this.userService.getList([
      { column: 'userIds', text: userIds.join(',') },
    ]);
    const userMap = keyBy(users, 'id');

    const filterFactory = [
      {
        column: 'factoryIds',
        text: factoryIds,
      },
    ];
    const factories = await this.userService.getFactoryList(filterFactory);
    const factoryMap = keyBy(factories, 'id');

    const columnSettings = JSON.parse(payload.columnSettings);
    const maintenanceTeamText = await this.i18n.translate(
      'export.maintenanceTeam',
    );
    const headers = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      title: maintenanceTeamText[el],
    }));
    const textCommon = await this.i18n.translate('export.common');
    const items = maintenanceTeams.map((maintenanceTeam) => ({
      code: maintenanceTeam?.code,
      name: maintenanceTeam?.name,
      leaderName: userMap[maintenanceTeam.leaderId]?.username ?? '',
      factory: has(factoryMap, maintenanceTeam.factoryId)
        ? factoryMap[maintenanceTeam.factoryId].name
        : '',
      active:
        maintenanceTeam?.active === ACTIVE_ENUM.ACTIVE
          ? textCommon.active
          : textCommon.inactive,
    }));
    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [await this.i18n.translate('export.maintenanceTeam.title')],
      headers,
    );
    return workbook;
  }

  async exportOneSheetUtil(data: any[], title: any, headers: any) {
    const workbook = new Workbook();
    let countRowData = ROW.COUNT_START_ROW;
    let countSheet = SHEET.START_SHEET;
    const tableColNum = headers.length;
    data.forEach((element) => {
      let worksheet = workbook.getWorksheet(SHEET.NAME + countSheet);
      if (countRowData == ROW.COUNT_START_ROW) {
        worksheet = workbook.addWorksheet(SHEET.NAME + countSheet);

        const titleRow = worksheet.getRow(2);
        titleRow.values = title;
        titleRow.font = <Font>EXCEL_STYLE.HEADER_FONT;
        titleRow.height = EXCEL_STYLE.TITLE_HEIGHT;
        titleRow.getCell(1).alignment = <Partial<Alignment>>(
          EXCEL_STYLE.ALIGN_CENTER
        );
        worksheet.mergeCellsWithoutStyle(2, 1, 2, tableColNum);

        const headerRow = worksheet.getRow(4);
        headerRow.values = headers.map((header) => header.title);
        headerRow.eachCell(function (cell) {
          cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
          cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        });
      }
      worksheet.columns = headers;
      worksheet
        .addRow({
          ...element,
        })
        .eachCell(function (cell) {
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          cell.font = <Font>EXCEL_STYLE.DEFAULT_FONT;
        });

      countRowData++;
      if (countRowData == ROW.COUNT_END_ROW) {
        countSheet++;
        countRowData = ROW.COUNT_START_ROW;
      }
    });
    return workbook;
  }

  async exportMultiSheetUtil(
    workbook: Workbook,
    items: any[],
    level: any,
    titleMap: any,
    headersMap: any,
  ) {
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      let worksheet = workbook.getWorksheet(SHEET.NAME + level);
      if (!worksheet) {
        worksheet = workbook.addWorksheet(SHEET.NAME + level);

        const titleRow = worksheet.getRow(1);
        titleRow.values = titleMap.get(level);
        titleRow.font = <Font>EXCEL_STYLE.TITLE_FONT;

        const headerRow = worksheet.getRow(3);
        headerRow.values = headersMap.get(level).map((header) => header.title);
        headerRow.eachCell(function (cell) {
          cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
          cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        });
        worksheet.columns = headersMap.get(level);
      }

      worksheet
        .addRow({
          ...item,
        })
        .eachCell(function (cell) {
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          cell.font = <Font>EXCEL_STYLE.DEFAULT_FONT;
        });
      if (item.subItem?.length > 0) {
        const getLevel = first(item.subItem)['level'] ?? level + 1;
        workbook = await this.exportMultiSheetUtil(
          workbook,
          item.subItem,
          getLevel,
          titleMap,
          headersMap,
        );
      }

      if (item.subItemClone?.length > 0) {
        const getLevel = first(item.subItemClone)['level'] ?? level + 2;
        workbook = await this.exportMultiSheetUtil(
          workbook,
          item.subItemClone,
          getLevel,
          titleMap,
          headersMap,
        );
      }
    }

    return workbook;
  }

  // @TODO: luồng chưa ổn
  async exportDeviceRequest(payload: ExportRequestDto) {
    let deviceRequests = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new ListDeviceRequestsRequestDto();
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      const { data } = await this.deviceRequestRepository.getList(
        request as any,
      );
      if (data && !isEmpty(data)) {
        deviceRequests = [...deviceRequests, ...data];
      }
      if (data.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!deviceRequests || isEmpty(deviceRequests)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const headers = [
      {},
      {
        key: 'code',
        width: 25,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceRequest.code'),
      },
      {
        key: 'name',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceRequest.name'),
      },
      {
        key: 'type',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceRequest.type'),
      },
      {
        key: 'transferRequest',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.deviceRequest.transferRequest',
        ),
      },
      {
        key: 'type',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceRequest.type'),
      },
      {
        key: 'expectReturnDate',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.deviceRequest.expectReturnDate',
        ),
      },
      {
        key: 'description',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceRequest.description'),
      },
      {
        key: 'factory',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceRequest.factory'),
      },
      {
        key: 'deviceGroup',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceRequest.deviceGroup'),
      },
      {
        key: 'quantity',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceRequest.quantity'),
      },
      {
        key: 'status',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceRequest.status'),
      },
    ];

    const headerSubOne = [
      {
        key: 'deviceGroup',
        width: 15,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.deviceRequest.requestProvide.deviceGroup',
        ),
      },

      {
        key: 'warehouseQuantity',
        width: 15,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.deviceRequest.requestProvide.warehouseQuantity',
        ),
      },
      {
        key: 'requestQuantity',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.deviceRequest.requestProvide.requestQuantity',
        ),
      },
    ];

    const headerSubTwo = [
      {
        key: 'serial',
        width: 15,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.deviceRequest.requestReturn.serial',
        ),
      },

      {
        key: 'name',
        width: 15,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.deviceRequest.requestReturn.name',
        ),
      },
      {
        key: 'area',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.deviceRequest.requestReturn.area',
        ),
      },
      {
        key: 'warehouse',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.deviceRequest.requestReturn.warehouse',
        ),
      },
    ];

    const factoryIds = compact(uniq(map(deviceRequests, 'factoryId')));
    const factories = await this.userService.getFactoryList([
      {
        column: 'factoryIds',
        text: factoryIds,
      },
    ]);
    const factoryMap = keyBy(factories, 'id');
    const items = [];
    const status = new Map();
    status.set(DEVICE_ASSIGNMENTS_STATUS_ENUM.WAIT_CONFIRM, 'Đợi xác nhận');
    status.set(DEVICE_ASSIGNMENTS_STATUS_ENUM.CONFIRMED, 'Xác nhận');
    status.set(DEVICE_ASSIGNMENTS_STATUS_ENUM.REJECT, 'Từ chối');

    const active = await this.i18n.translate('export.common.active');
    const inactive = await this.i18n.translate('export.common.inactive');

    deviceRequests?.forEach((deviceRequest) => {
      if (deviceRequest.type === DEVICE_REQUEST_TYPE_ENUM.RETURN) {
        const deviceGroups = deviceRequest?.deviceGroups
          ?.map((el) => el.name)
          .join(', ');

        const item = {
          code: deviceRequest.code ?? '',
          name: deviceRequest?.deviceRequest?.name ?? '',
          toFactory: factoryMap[deviceRequest?.factoryId]?.name ?? '',
          deviceGroup: deviceGroups ?? '',
          expectReturnDate: deviceRequest.expectReturnDate ?? '',
          description: deviceRequest?.description ?? '',
          type: 'Yêu cầu cấp',
          status:
            deviceRequest.status === ACTIVE_ENUM.ACTIVE ? active : inactive,
          level: 1,
          subItem: [],
          subClone: [],
        };
        for (const deviceGroupRequest of deviceRequest.deviceGroupRequest ??
          []) {
          item.subItem.push({
            code: deviceRequest.code ?? '',
            name: deviceGroupRequest.deviceGroupId.name ?? '',
            // @TODO: caculate availableWarehouseQuantity
            warehouseQuantity: '',
            requestQuantity: deviceGroupRequest.quantity,
            level: 2,
          });
        }
        items.push(item);
      } else {
        const item = {
          code: deviceRequest.code ?? '',
          name: deviceRequest?.deviceRequest?.name ?? '',
          transferRequest: deviceRequest?.deviceRequest?.transferRequest ?? '',
          toFactory: factoryMap[deviceRequest?.factoryId]?.name ?? '',
          returnFactory: '',
          expectReturnDate: deviceRequest.expectReturnDate ?? '',
          realityReturnDate: deviceRequest.realityReturnDate ?? '',
          type: 'Yêu cầu trả',
          description: deviceRequest?.description ?? '',
          status:
            deviceRequest.status === ACTIVE_ENUM.ACTIVE ? active : inactive,
          level: 1,
          subItem: [],
          subClone: [],
        };
        for (const device of deviceRequest.devices ?? []) {
          item.subItem.push({
            code: deviceRequest.code ?? '',
            serial: device.deviceId?.serial ?? '',
            deviceGroup: device.deviceId?.deviceGroup?.name ?? '',
            area: device.areaId?.name ?? '',
            warehouse: device.warehouseId?.name ?? '',
            level: 3,
          });
        }
        items.push(item);
      }
    });

    const titleMap = new Map();
    const headerMap = new Map();
    titleMap.set(1, [await this.i18n.translate('export.deviceRequest.title')]);
    titleMap.set(2, [
      await this.i18n.translate('export.deviceRequest.requestProvide.title'),
    ]);
    titleMap.set(3, [
      await this.i18n.translate('export.deviceRequest.requestReturn.title'),
    ]);

    headerMap.set(1, headers);
    headerMap.set(2, headerSubOne);
    headerMap.set(3, headerSubTwo);
    const workbook = new Workbook();

    return await this.exportMultiSheetUtil(
      workbook,
      items,
      1,
      titleMap,
      headerMap,
    );
  }

  async exportArea(payload: ExportRequestDto) {
    let areas = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListAreaQuery();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      const { data } = await this.areaRepository.list(request);
      if (!isEmpty(data)) {
        areas = areas.concat(data);
      }
      if (data.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!areas || isEmpty(areas)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const columnSettings = JSON.parse(payload.columnSettings);
    const areaText = await this.i18n.translate('export.area');
    const headers = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      title: areaText[el],
    }));

    const factoryIds = compact(uniq(map(areas, 'factoryId')));
    const factories = await this.userService.getFactoryList([
      {
        column: 'factoryIds',
        text: factoryIds,
      },
    ]);
    const factoryMap = keyBy(factories, 'id');

    const active = await this.i18n.translate('export.common.active');
    const inactive = await this.i18n.translate('export.common.inactive');

    const items = areas?.map((area) => {
      const item = {
        code: area.code ?? '',
        name: area.name ?? '',
        description: area.description ?? '',
        factory: has(factoryMap, area.factoryId)
          ? factoryMap[area.factoryId].name
          : '',
        active: area.active === ACTIVE_ENUM.ACTIVE ? active : inactive,
      };

      return item;
    });

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(items, [areaText.title], headers);
    return workbook;
  }

  async exportErrorType(payload: ExportRequestDto) {
    let errorTypes = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListErrorTypeQuery();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      const { data } = await this.errorTypeRepository.list(request);
      if (!isEmpty(data)) {
        errorTypes = errorTypes.concat(data);
      }

      if (data.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!errorTypes || isEmpty(errorTypes)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }
    const columnSettings = JSON.parse(payload.columnSettings);
    const errorTypeText = await this.i18n.translate('export.errorType');
    const headers = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      title: errorTypeText[el],
    }));

    const active = await this.i18n.translate('export.common.active');
    const inactive = await this.i18n.translate('export.common.inactive');

    const priority = new Map();
    priority.set(ERROR_TYPE_PRIORITY_ENUM.LOW, 'Thấp');
    priority.set(ERROR_TYPE_PRIORITY_ENUM.MEDIUM, 'Trung bình');
    priority.set(ERROR_TYPE_PRIORITY_ENUM.HIGH, 'Cao');
    const items = errorTypes.map((item) => ({
      code: item?.code,
      name: item?.name,
      description: item?.description ?? '',
      priority: priority.get(item?.priority) ?? '',
      active: item?.active === ACTIVE_ENUM.ACTIVE ? active : inactive,
    }));
    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [errorTypeText.title],
      headers,
    );
    return workbook;
  }

  async exportVendor(payload: ExportRequestDto) {
    let vendors = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListVendorRequestDto();
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }

      const { data } = await this.vendorRepository.list(request);
      if (!isEmpty(data)) {
        vendors = vendors.concat(data);
      }
      if (data.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!vendors || isEmpty(vendors)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const columnSettings = JSON.parse(payload.columnSettings);
    const vendorText = await this.i18n.translate('export.vendor');
    const headers = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      title: vendorText[el],
    }));
    const active = await this.i18n.translate('export.common.active');
    const inactive = await this.i18n.translate('export.common.inactive');

    const items = vendors?.map((vendor) => {
      const item = {
        code: vendor.code ?? '',
        name: vendor.name ?? '',
        address: vendor.address ?? '',
        phone: vendor.phone ?? '',
        email: vendor.email ?? '',
        taxCode: vendor.taxCode ?? '',
        contactUser: vendor.contactUser ?? '',
        active: vendor.active === ACTIVE_ENUM.ACTIVE ? active : inactive,
      };

      return item;
    });

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [vendorText.title],
      headers,
    );
    return workbook;
  }

  async exportDeviceType(payload: ExportRequestDto) {
    let deviceTypes = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new ListDeviceNameRequestDto();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      const { data } = await this.deviceTypeRepository.list(request);
      if (!isEmpty(data)) {
        deviceTypes = deviceTypes.concat(data);
      }
      if (data.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!deviceTypes || isEmpty(deviceTypes)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const columnSettings = JSON.parse(payload.columnSettings);
    const deviceTypeText = await this.i18n.translate('export.deviceType');
    const headers = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      title: deviceTypeText[el],
    }));

    const textCommon = await this.i18n.translate('export.common');
    const items = deviceTypes?.map((deviceType) => {
      const item = {
        code: deviceType.code ?? '',
        name: deviceType.name ?? '',
        description: deviceType.description ?? '',
        deviceGroup: deviceType.deviceGroupId?.name ?? '',
        active:
          deviceType.active === ACTIVE_ENUM.ACTIVE
            ? textCommon.active
            : textCommon.inactive,
      };
      return item;
    });

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [deviceTypeText.title],
      headers,
    );
    return workbook;
  }

  async exportDeviceName(payload: ExportRequestDto) {
    let deviceName = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new ListDeviceNameRequestDto();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      const { data } = await this.deviceNameRepository.list(request);
      if (!isEmpty(data)) {
        deviceName = deviceName.concat(data);
      }
      if (data.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!deviceName || isEmpty(deviceName)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const columnSettings = JSON.parse(payload.columnSettings);
    const deviceNameHeader = await this.i18n.translate('export.deviceName');
    const headers = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: {
        alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
      },
      title: deviceNameHeader[el],
    }));
    const textCommon = await this.i18n.translate('export.common');

    const items = deviceName?.map((deviceName) => {
      const item = {
        code: deviceName.code ?? '',
        name: deviceName.name ?? '',
        description: deviceName.description ?? '',
        active:
          deviceName.active === ACTIVE_ENUM.ACTIVE
            ? textCommon.active
            : textCommon.inactive,
      };

      return item;
    });

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [deviceNameHeader.title],
      headers,
    );
    return workbook;
  }

  async exportDeviceAssignment(payload: ExportRequestDto) {
    let deviceAssignments = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new ListDeviceAssignmentQuery();
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      const { data } = await this.deviceAssignmentRepository.listToExport(
        request,
      );
      deviceAssignments = deviceAssignments.concat(data);
      if (data.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!deviceAssignments || isEmpty(deviceAssignments)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const headers = [
      {},
      {
        key: 'code',
        width: 25,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceAssignment.code'),
      },

      {
        key: 'assignDate',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceAssignment.assignDate'),
      },
      {
        key: 'requestName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceAssignment.requestName'),
      },
      {
        key: 'factoryName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceAssignment.factoryName'),
      },
      {
        key: 'deviceGroup',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceAssignment.deviceGroup'),
      },
      {
        key: 'status',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceAssignment.status'),
      },
      {
        key: 'quantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.deviceAssignment.quantity'),
      },
    ];

    const headerSub = [
      {
        key: 'serial',
        width: 15,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.deviceAssignment.details.serial',
        ),
      },

      {
        key: 'deviceGroup',
        width: 15,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.deviceAssignment.details.deviceGroup',
        ),
      },
      {
        key: 'area',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.deviceAssignment.details.area',
        ),
      },
    ];

    const factoryIds = compact(
      uniq(map(deviceAssignments, 'deviceRequest.factoryId')),
    );
    const factories = await this.userService.getFactoryList([
      {
        column: 'factoryIds',
        text: factoryIds,
      },
    ]);
    const factoryMap = keyBy(factories, 'id');

    const userIds = compact(uniq(map(deviceAssignments, 'assignUser')));
    const users = await this.userService.getList([
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ]);
    const userMap = keyBy(users, 'id');

    const items = [];
    const status = new Map();
    status.set(DEVICE_ASSIGNMENTS_STATUS_ENUM.WAIT_CONFIRM, 'Đợi xác nhận');
    status.set(DEVICE_ASSIGNMENTS_STATUS_ENUM.CONFIRMED, 'Xác nhận');
    status.set(DEVICE_ASSIGNMENTS_STATUS_ENUM.REJECT, 'Từ chối');
    deviceAssignments?.forEach((deviceAssignment) => {
      const deviceGroups = deviceAssignment['deviceRequest']?.deviceGroups
        ?.map((el) => el.name)
        .join(', ');

      const quantity = deviceAssignment[
        'deviceRequest'
      ]?.deviceGroupRequest?.reduce((total, el) => {
        if (parseInt(el.quantity)) return total + el.quantity;
      }, 0);
      const item = {
        code: deviceAssignment.code ?? '',
        request: deviceAssignment?.deviceRequest?.name ?? '',
        assignDate: deviceAssignment.assignDate ?? '',
        factory:
          factoryMap[deviceAssignment.deviceRequest?.factoryId]?.name ?? '',

        deviceGroup: deviceGroups ?? '',
        assignUser: userMap[deviceAssignment.assignUser]?.name ?? '',
        quantity: quantity,
        status: status.get(deviceAssignment.status) ?? '',
        level: 1,
        subItem: [],
      };
      for (const detail of deviceAssignment.details ?? []) {
        item.subItem.push({
          code: deviceAssignment.code ?? '',
          serial: detail.deviceId?.serial ?? '',
          deviceGroup: detail.deviceId?.deviceGroup?.name ?? '',
          area: detail.areaId?.name ?? '',
          level: 2,
        });
      }
      items.push(item);
    });

    const titleMap = new Map();
    const headerMap = new Map();
    titleMap.set(1, [
      await this.i18n.translate('export.deviceAssignment.title'),
    ]);
    titleMap.set(2, [
      await this.i18n.translate('export.deviceAssignment.details.title'),
    ]);

    headerMap.set(1, headers);
    headerMap.set(2, headerSub);
    const workbook = new Workbook();

    return await this.exportMultiSheetUtil(
      workbook,
      items,
      1,
      titleMap,
      headerMap,
    );
  }

  async exportArticleDeviceGroup(payload: ExportRequestDto) {
    let articleDeviceGroups = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new ListArticleDeviceGroupRequestDto();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      const { data } = await this.articleDeviceGroupRepository.list(request);
      if (!isEmpty(data)) {
        articleDeviceGroups = articleDeviceGroups.concat(data);
      }
      if (data.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!articleDeviceGroups || isEmpty(articleDeviceGroups)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const columnSettings = JSON.parse(payload.columnSettings);
    const articleDeviceGroupHeader = await this.i18n.translate(
      'export.articleDeviceGroup',
    );
    const headers = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: {
        alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
      },
      title: articleDeviceGroupHeader[el],
    }));
    const textCommon = await this.i18n.translate('export.common');

    const items = articleDeviceGroups?.map((articleDeviceGroup) => {
      const item = {
        code: articleDeviceGroup.code ?? '',
        name: articleDeviceGroup.name ?? '',
        description: articleDeviceGroup.description ?? '',
        active:
          articleDeviceGroup.active === ACTIVE_ENUM.ACTIVE
            ? textCommon.active
            : textCommon.inactive,
      };

      return item;
    });

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [articleDeviceGroupHeader.title],
      headers,
    );
    return workbook;
  }

  async exportInventoryDeviceGroup(payload: ExportRequestDto) {
    let inventoryDeviceGroups = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetWarehouseInventoriesQueryDto();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      request.user = payload.user;
      request.type = ASSET_INVENTORY_ENUM.DEVICE_GROUP;
      const {
        data: { items },
      } = await this.warehouseService.getInventories(request);
      if (!isEmpty(items)) {
        inventoryDeviceGroups = inventoryDeviceGroups.concat(items);
      }
      if (items.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!inventoryDeviceGroups || isEmpty(inventoryDeviceGroups)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const columnSettings = JSON.parse(payload.columnSettings);
    const inventoryDeviceGroupHeader = await this.i18n.translate(
      'export.inventoryDeviceGroup',
    );
    const headers = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: {
        alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
      },
      title: inventoryDeviceGroupHeader[el],
    }));
    const deviceUnit = await this.i18n.translate('text.DEVICE_UNIT');

    const items = inventoryDeviceGroups?.map((inventoryDeviceGroup) => {
      const item = {
        assetName: inventoryDeviceGroup?.assetName ?? '',
        factory: inventoryDeviceGroup.factory?.name ?? '',
        warehouse: inventoryDeviceGroup?.warehouse?.name ?? '',
        stockQuantity: inventoryDeviceGroup.stockQuantity ?? 0,
        unit: deviceUnit,
      };

      return item;
    });

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [inventoryDeviceGroupHeader.title],
      headers,
    );
    return workbook;
  }

  async exportInventorySupply(payload: ExportRequestDto) {
    const inventorySupplies = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetWarehouseInventoriesQueryDto();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      request.user = payload.user;
      request.type = ASSET_INVENTORY_ENUM.SUPPLY;
      const {
        data: { items },
      } = await this.warehouseService.getInventories(request);
      if (!isEmpty(items)) {
        inventorySupplies.push(...items);
      }
      if (items.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!inventorySupplies || isEmpty(inventorySupplies)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const columnSettings = JSON.parse(payload.columnSettings);
    const inventorySupplyHeader = await this.i18n.translate(
      'export.inventorySupply',
    );
    const headers = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: {
        alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
      },
      title: inventorySupplyHeader[el],
    }));

    const items = inventorySupplies?.map((inventorySupply) => {
      const item = {
        supplyGroup: inventorySupply.supplyGroup?.name ?? '',
        code: inventorySupply.assetCode ?? '',
        name: inventorySupply.assetName ?? '',
        type: inventorySupply.assetTypeDisplay?.name ?? '',
        factory: inventorySupply.factory?.name ?? '',
        warehouse: inventorySupply?.warehouse?.name ?? '',
        vendor: inventorySupply?.vendor?.name ?? '',
        quantity: inventorySupply.stockQuantity,
        unit: inventorySupply?.unit?.name ?? '',
      };

      return item;
    });

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [inventorySupplyHeader.title],
      headers,
    );
    return workbook;
  }

  async exportDeviceInventory(payload: ExportRequestDto) {
    let deviceInventories = [];
    const { filter } = payload;
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const query = new PaginationQuery();
      const request = new GetInventoryByWarehouseAndDeviceGroupRequestDto();
      query.page = i;
      query.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      query.filter = payload.filter;
      query.sort = payload.sort;
      filter?.forEach((el) => {
        const value = el.text;
        switch (el.column) {
          case 'warehouseId':
            request.warehouseId = value;
            break;
          case 'deviceGroupId':
            request.deviceGroupId = value;
            break;
          default:
            break;
        }
      });
      if (!request.warehouseId && !request.deviceGroupId) {
        return new ResponseBuilder()
          .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .build();
      }
      if (!isEmpty(JSON.parse(payload.queryIds))) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      const res =
        await this.warehouseService.getInventoriesByWarehouseAndDeviceGroup(
          { ...request, user: payload.user },
          query,
        );
      if (res.statusCode !== ResponseCodeEnum.SUCCESS) {
        return res;
      }
      const items = res.data?.items;
      deviceInventories = deviceInventories.concat(items);
      if (items?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }
    if (!deviceInventories || isEmpty(deviceInventories)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const columnSettings = JSON.parse(payload.columnSettings);
    const deviceInventoryHeader = await this.i18n.translate(
      'export.deviceInventory',
    );
    const headers = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: {
        alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
      },
      title: deviceInventoryHeader[el],
    }));

    const items = deviceInventories?.map((deviceInventory) => {
      const item = {
        serial: deviceInventory.serial ?? '',
        identificationNo: deviceInventory.identificationNo ?? '',
        name: deviceInventory.name ?? '',
        vendor: deviceInventory.vendor?.name ?? '',
        model: deviceInventory.model ?? '',
        manufacturer: deviceInventory.manufacturer ?? '',
      };

      return item;
    });

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [await this.i18n.translate('export.deviceInventory.title')],
      headers,
    );
    return workbook;
  }

  async exportReportNewInvestmentDevice(payload: ExportRequestDto) {
    const devices: any[] = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListDevicesRequestDto();
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      const { result } = await this.deviceRepository.reportNewInvestmentDevice(
        request,
      );
      if (!isEmpty(result)) {
        devices.push(...result);
      }
      if (result?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }
    if (!devices || isEmpty(devices)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const factoryIdReturns = map(devices, 'factoryId');

    const factories = await this.userService.getFactoryList([
      { column: 'factoryIds', text: uniq(factoryIdReturns) },
    ]);
    const factoryMap = keyBy(factories, 'id');

    const columnSettings = JSON.parse(payload.columnSettings);
    const reportNewInvestment = await this.i18n.translate(
      'export.reportNewInvestmentDevice',
    );
    const headers = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      title: reportNewInvestment[el],
    }));

    const items = [];
    for (const device of devices) {
      const item = {
        factory: factoryMap[device?.factoryId]?.name ?? '',
        manufacturer: device?.manufacturer ?? '',
        deviceName: device?.deviceName?.[0]?.name ?? '',
        serial: device?.serial ?? '',
        actualSerial: device?.actualSerial ?? '',
        capitalizationDate: moment(
          device?.capitalizationDate ?? device?.createdAt,
        ).format(DATE_FORMAT_EXPORT),
        model: device?.model ?? '',
        quantity: device?.quantity ?? '',
        company: device?.company ?? '',
        vendor: device?.vendor?.[0]?.name ?? '',
      };

      items.push(item);
    }

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [await this.i18n.translate('export.device.title')],
      headers,
    );
    return workbook;
  }

  async exportOperationValue(payload: ExportRequestDto) {
    const operationValues: any[] = [];
    const { filter, timeUnit, sort } = payload;
    const startDate = filter
      ?.find((e) => e.column === 'date')
      ?.text.split('|')[0];
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListOperationValueQuery();
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = filter;
      request.sort = sort;
      request.timeUnit = timeUnit;
      const result = await this.operationValueRepository.export(request);
      if (!isEmpty(result)) {
        operationValues.push(...result);
      }
      if (result?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }
    if (!operationValues || isEmpty(operationValues)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }
    const operationValueText = await this.i18n.translate(
      'export.operationValue',
    );
    const timeUnitText = await this.i18n.translate('export.timeUnit');
    const operationIndexIds = map(
      flatMap(operationValues, 'operationIndexes'),
      'operationIndexId',
    );
    const operationIndexes =
      await this.operationIndexRepository.findAllByCondition({
        _id: { $in: operationIndexIds },
      });
    const parameters = flatMap(operationIndexes, 'parameters');
    const workbook = new Workbook();
    const rowHeaderOne = 3;
    const rowHeaderTwo = 4;
    const rowStart = 2;
    const columnDate = 1;
    const columnFactory = 2;
    let headerColumnCurrent = 3;
    const tableColumnTotal = 2 + parameters.length;
    const title = operationValueText.title.toUpperCase();
    const worksheet = workbook.addWorksheet(SHEET.NAME + 1);
    const styleHeader = {
      font: <Font>EXCEL_STYLE.TITLE_FONT,
      border: <Partial<Borders>>EXCEL_STYLE.BORDER_ALL,
      alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER,
    };
    //  merge title
    const titleCell = worksheet.getRow(rowStart).getCell(1);
    titleCell.value = title;
    worksheet.mergeCells(rowStart, 1, rowStart, tableColumnTotal);
    titleCell.style = styleHeader;
    // set header for key
    const headers = [
      {
        key: 'date',
        width: 20,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: operationValueText.date,
      },
      {
        key: 'factory',
        width: 25,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: operationValueText.factory,
      },
      ...parameters?.map((el) => ({
        key: el._id,
        width: 15,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: el.name,
      })),
    ];
    worksheet.columns = headers;
    // merge cell for date and factory
    worksheet.mergeCells(rowHeaderOne, columnDate, rowHeaderTwo, columnDate);
    worksheet.mergeCells(
      rowHeaderOne,
      columnFactory,
      rowHeaderTwo,
      columnFactory,
    );
    const cellDate = worksheet.getRow(rowHeaderOne).getCell(columnDate);
    const cellFactory = worksheet.getRow(rowHeaderOne).getCell(columnFactory);
    cellDate.value = operationValueText.date;
    cellDate.style = styleHeader;
    cellFactory.value = operationValueText.factory;
    cellFactory.style = styleHeader;
    // set header
    operationIndexes.forEach((e) => {
      const headerColumnStart = headerColumnCurrent;
      e.parameters?.forEach((el) => {
        const cellChild = worksheet
          .getRow(rowHeaderTwo)
          .getCell(headerColumnCurrent++);
        cellChild.value = el.name;
        cellChild.style = styleHeader;
      });
      worksheet.mergeCells(
        rowHeaderOne,
        headerColumnStart,
        rowHeaderOne,
        headerColumnCurrent - 1,
      );
      const cellParent = worksheet
        .getRow(rowHeaderOne)
        .getCell(headerColumnStart);
      cellParent.value = `${e.name} (${e.unit})`;
      cellParent.style = styleHeader;
    });
    // add factory
    const factoryIds = map(operationValues, 'factoryId');
    const factories = await this.userService.getFactoryList([
      {
        column: 'factoryIds',
        text: factoryIds,
      },
    ]);
    const factoryMap = keyBy(factories, 'id');
    // add data body
    let datePre;
    switch (timeUnit) {
      case REPORT_TYPE_ENUM.DAY:
        datePre = timeUnitText.day;
        break;
      case REPORT_TYPE_ENUM.MONTH:
        datePre = timeUnitText.month;
        break;
      case REPORT_TYPE_ENUM.QUARTER:
        datePre = timeUnitText.quarter;
        break;

      default:
        break;
    }
    const items = operationValues?.map((operationValue) => {
      const item = {
        factory: factoryMap[operationValue.factoryId]?.name ?? '',
        date: `${datePre} ${
          timeUnit === REPORT_TYPE_ENUM.DAY
            ? moment(operationValue.date).format(DATE_FORMAT_EXPORT)
            : timeUnit === REPORT_TYPE_ENUM.MONTH
            ? moment(startDate).month() + 1
            : moment(startDate).quarter()
        }`,
      };
      operationValue.operationIndexes?.forEach((e) => {
        e.parameters?.forEach((el) => {
          item[el.parameterId] = el.value ?? '';
        });
      });
      return item;
    });
    const defaultRow = {};
    parameters.forEach((e) => (defaultRow[e['_id']] = ''));
    items?.forEach((el) => {
      worksheet
        .addRow({
          ...defaultRow,
          ...el,
        })
        .eachCell(function (cell) {
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          cell.font = <Font>EXCEL_STYLE.DEFAULT_FONT;
        });
    });
    return workbook;
  }

  async exportReportTransfer(payload: ExportRequestDto) {
    const results: any[] = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new PaginationQuery();
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const { data } = await this.transferTicketRepository.reportTransferTicket(
        request,
      );
      if (!isEmpty(data)) {
        results.push(...data);
      }
      if (data?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }
    if (!results || isEmpty(results)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const factoryIds = results
      .map((e) => [e.fromFactoryId, e.toFactoryId])
      .flat();

    const factories = await this.userService.getFactoryList([
      {
        column: 'factoryIds',
        text: factoryIds,
      },
    ]);
    const factoryMap = keyBy(factories, 'id');

    const reportTransfer = await this.i18n.translate('export.reportTransfer');
    const headers = [
      {
        key: 'stt',
        width: 10,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: reportTransfer.stt,
      },
      {
        key: 'toFactory',
        width: 25,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: reportTransfer.toFactory,
      },
      {
        key: 'fromFactory',
        width: 25,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: reportTransfer.fromFactory,
      },
      {
        key: 'totalBuy',
        width: 20,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: reportTransfer.totalBuy,
      },
      {
        key: 'totalRent',
        width: 20,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: reportTransfer.totalRent,
      },
    ];

    const items = [];
    let totalBuy = 0;
    let totalRent = 0;
    results.forEach((el, index) => {
      totalBuy += el.totalBuy ?? 0;
      totalRent += el.totalRent ?? 0;
      const item = {
        stt: plus(index, 1),
        fromFactory: factoryMap[el.fromFactoryId]?.name ?? '',
        toFactory: factoryMap[el.toFactoryId]?.name ?? '',
        totalBuy: el?.totalBuy ?? 0,
        totalRent: el?.totalRent ?? 0,
      };
      items.push(item);
    });
    items.push({
      stt: '',
      fromFactory: '',
      toFactory: reportTransfer.total,
      totalBuy,
      totalRent,
    });

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [reportTransfer.title],
      headers,
    );
    return workbook;
  }

  async exportReportTransferDetail(payload: ExportRequestDto) {
    const results: any[] = [];
    const { toFactoryId, fromFactoryId } = payload;
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new ReportDetailTransferTicketRequest();
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      request.fromFactoryId = fromFactoryId;
      request.toFactoryId = toFactoryId;
      const { data } =
        await this.transferTicketRepository.reportDetailTransferTicket(request);
      if (!isEmpty(data)) {
        results.push(...data);
      }
      if (data?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }
    const factoryIds = [toFactoryId, fromFactoryId];

    const factories = await this.userService.getFactoryList([
      {
        column: 'factoryIds',
        text: factoryIds,
      },
    ]);

    const factoryMap = keyBy(factories, 'id');
    if (!results || isEmpty(results)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }
    const reportTransferDetail = await this.i18n.translate(
      'export.reportTransferDetail',
    );
    const headers = [
      {
        key: 'stt',
        width: 5,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: reportTransferDetail.stt,
      },
      {
        key: 'name',
        width: 20,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: reportTransferDetail.name,
      },
      {
        key: 'manufacturer',
        width: 15,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: reportTransferDetail.manufacturer,
      },
      {
        key: 'model',
        width: 15,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: reportTransferDetail.model,
      },
      {
        key: 'serial',
        width: 15,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: reportTransferDetail.serial,
      },

      {
        key: 'quantity',
        width: 10,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: reportTransferDetail.quantity,
      },
      {
        key: 'toFactory',
        width: 25,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: reportTransferDetail.toFactory,
      },
      {
        key: 'transferDate',
        width: 10,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: reportTransferDetail.transferDate,
      },
      {
        key: 'fromFactory',
        width: 25,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: reportTransferDetail.fromFactory,
      },
      {
        key: 'buy',
        width: 10,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: reportTransferDetail.buy,
      },
      {
        key: 'rent',
        width: 10,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: reportTransferDetail.rent,
      },
    ];
    const defaultQuantity = 1;
    const items = [];
    results.forEach((el, index) => {
      const item = {
        stt: plus(index, 1),
        name: el?.device?.name ?? '',
        manufacturer: el?.device?.manufacturer ?? '',
        model: el?.device?.model ?? '',
        serial: el?.device?.serial ?? '',
        quantity: defaultQuantity,
        toFactory: factoryMap[toFactoryId]?.name ?? '',
        transferDate: moment(el?.transferDate).format(DATE_FORMAT_EXPORT) ?? '',
        fromFactory: factoryMap[fromFactoryId]?.name ?? '',
        buy:
          el?.transferRequest?.type === TRANSFER_REQUEST_TYPE_ENUM.BUY
            ? 'x'
            : '',
        rent:
          el?.transferRequest?.type === TRANSFER_REQUEST_TYPE_ENUM.RENT
            ? 'x'
            : '',
      };
      items.push(item);
    });
    items.push({
      stt: '',
      manufacturer: '',
      model: '',
      serial: '',
      toFactory: '',
      transferDate: '',
      fromFactory: '',
      buy: '',
      rent: '',
      name: reportTransferDetail.total,
      quantity: results?.length,
    });
    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [reportTransferDetail.title],
      headers,
    );
    return workbook;
  }

  async exportReportDeviceSynthesis(payload: ExportRequestDto) {
    const devices: any[] = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new ExportRequestDto();
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const {
        data: { items },
      } = await this.reportService.getDeviceSynthesis(request);
      if (!isEmpty(items)) {
        devices.push(...items);
      }
      if (items?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }
    if (!devices || isEmpty(devices)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const reportDeviceSynthesis = await this.i18n.translate(
      'export.reportDeviceSynthesis',
    );
    const headers = Object.entries(reportDeviceSynthesis.table)?.map(
      ([key, value]) => ({
        key,
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: value,
      }),
    );
    const commonText = await this.i18n.translate('export.common');
    const statusText = commonText.deviceUseStatus;
    const statusMap = new Map([
      [DEVICE_STATUS_ENUM.USING, statusText.using],
      [DEVICE_STATUS_ENUM.PREVENTIVE, statusText.preventive],
      [DEVICE_STATUS_ENUM.BROKEN, statusText.broken],
      [DEVICE_STATUS_ENUM.USELESS, statusText.useless],
      [DEVICE_STATUS_ENUM.AWAIT_CLEARANCE, statusText.awaitClearance],
    ]);
    const deviceStatusText = reportDeviceSynthesis.deviceStatus;
    const deviceStatusMap = new Map([
      [DEVICE_STATUS_STATE_ENUM.ACTIVE, deviceStatusText.active],
      [DEVICE_STATUS_STATE_ENUM.STOP, deviceStatusText.stop],
      [DEVICE_STATUS_STATE_ENUM.ERROR, deviceStatusText.error],
      [DEVICE_STATUS_STATE_ENUM.OFF, deviceStatusText.off],
    ]);

    const items = [];
    for (const device of devices) {
      const item = {
        factory: device?.factory?.name ?? '',
        manufacturer: device?.manufacturer ?? '',
        model: device?.model ?? '',
        code: device?.code ?? '',
        name: device?.name ?? '',
        deviceType: device?.deviceType?.name ?? '',
        deviceGroup: device?.deviceGroup?.name ?? '',
        warehouse: device?.warehouse?.name ?? '',
        vendor: device?.vendor?.name ?? '',
        serial: device?.serial ?? '',
        actualSerial: device?.actualSerial ?? '',
        identificationNo: device?.identificationNo ?? '',
        unit: device?.unit?.name ?? '',
        isFixedAsset:
          device?.isFixedAsset === IS_FIXED_ASSET.YES
            ? commonText.wfx
            : commonText.mmsx,
        creationDate:
          moment(device?.creationDate).format(DATE_FORMAT_EXPORT) ?? '',
        originFactory: device?.originFactory?.name ?? '',
        useFactory: device?.factory?.name ?? '',
        user: device?.user ?? '',
        status: statusMap.get(device?.status) ?? statusText.using,
        active:
          deviceStatusMap.get(device?.deviceStatus) ?? deviceStatusText.active,
      };

      items.push(item);
    }

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      items,
      [reportDeviceSynthesis.title],
      headers,
    );
    return workbook;
  }

  async exportMaintenancePlan(
    payload: GetDeviceMaintenanceReportRequest,
  ): Promise<any> {
    const results: any[] = [];
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetDeviceMaintenanceReportRequest();
      request.sort = payload.sort;
      request.startDate = payload.startDate;
      request.endDate = payload.endDate;
      request.reportUnitType = payload.reportUnitType;
      request.type = payload.type;
      request.filter = payload.filter;
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      const {
        data: { items: datas },
      } = await this.reportService.getDeviceMaintenance(request);
      if (!isEmpty(datas)) {
        results.push(...datas);
      }
      if (datas?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }
    if (!results || isEmpty(results)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const reportDeviceMaintenance = await this.i18n.translate(
      'export.reportDeviceMaintenance',
    );
    const unitLength =
      payload.reportUnitType === REPORT_UNIT_TYPE_ENUM.MONTH ? 12 : 4;
    const preFix =
      payload.reportUnitType === REPORT_UNIT_TYPE_ENUM.MONTH
        ? reportDeviceMaintenance.prefixMonth
        : reportDeviceMaintenance.prefixQuarter;

    const header = [
      {
        key: 'stt',
        width: 5,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.reportDeviceMaintenance.stt'),
      },
      {
        key: 'factory',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.reportDeviceMaintenance.factory',
        ),
      },
      ...new Array(unitLength).fill('').flatMap((_, index) => [
        {
          key: `${plus(index, 1)}-plan`,
          width: 10,
          style: {
            alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
          },
          title: `${preFix}${plus(index, 1)}-${reportDeviceMaintenance.plan}`,
        },
        {
          key: `${plus(index, 1)}-actual`,
          width: 10,
          style: {
            alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
          },
          title: `${preFix}${plus(index, 1)}-${reportDeviceMaintenance.actual}`,
        },
        {
          key: `${plus(index, 1)}-scale`,
          width: 10,
          style: {
            alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
          },
          title: `${preFix}${plus(index, 1)}-${reportDeviceMaintenance.scale}`,
        },
      ]),
      {
        key: `totalPlan`,
        width: 10,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: `${reportDeviceMaintenance.total} ${reportDeviceMaintenance.plan}`,
      },
      {
        key: `totalActual`,
        width: 10,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: `${reportDeviceMaintenance.total} ${reportDeviceMaintenance.actual}`,
      },
      {
        key: `totalScale`,
        width: 10,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: `${reportDeviceMaintenance.total} ${reportDeviceMaintenance.scale}`,
      },
    ];

    const title =
      reportDeviceMaintenance.title + moment(payload.startDate).year();
    const items = [];

    results.forEach((e, index) => {
      const total = { plan: 0, actual: 0 };
      const item = {
        stt: plus(index, 1),
        factory: e?.factory?.name ?? '',
        ...e.reportByUnits?.reduce((pre, cur) => {
          total.plan += cur.plan;
          total.actual += cur.actual;
          pre[`${plus(cur.tag, 1)}-plan`] = cur.plan ?? 0;
          pre[`${plus(cur.tag, 1)}-actual`] = cur.actual ?? 0;
          pre[`${plus(cur.tag, 1)}-scale`] = (round(cur.scale, 2) ?? 0) + '%';
          return pre;
        }, {}),
        totalPlan: total.plan,
        totalActual: total.actual,
        totalScale: (round(div(total.actual, total.plan) * 100, 2) ?? 0) + '%',
      };

      items.push(item);
    });

    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(items, [title], header);
    return workbook;
  }
}
