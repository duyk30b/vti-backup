import { returnStockQuantity } from 'src/helper/code.helper';
import { TransferTicketRepositoryInterface } from '@components/transfer-ticket/interface/transfer-ticket.repository.interface';
import { WarehouseRepositoryInterface } from '@components/warehouse/interface/warehouse.repository.interface';
import { DeviceRepositoryInterface } from '@components/device/interface/device.repository.interface';
import {
  DEVICE_REQUEST_ACTION_CONFIRMED,
  DEVICE_REQUEST_ACTION_REJECTED,
  DEVICE_REQUEST_EVENTS_ENUM,
  DEVICE_REQUEST_STATUS_CAN_DELETE,
  DEVICE_REQUEST_STATUS_CAN_UPDATE,
  DEVICE_REQUEST_STATUS_ENUM,
  DEVICE_REQUEST_TYPE_ENUM,
  TRANSFER_TICKET_CAN_CREATE_RETURN_REQUEST,
} from './device-request.constant';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { DeviceRequestRepositoryInterface } from '@components/device-request/interface/device-request-ticket.repository.interface';
import { DeviceRequestServiceInterface } from '@components/device-request/interface/device-request.service.interface';
import { CreateDeviceProvideRequestDto } from '@components/device-request/dto/request/request-ticket/create-device-request-ticket.request.dto';
import { DetailDeviceRequestResponseDto } from '@components/device-request/dto/response/detail-device-request-ticket.response.dto';
import { UpdateDeviceRequestRequestDto } from '@components/device-request/dto/request/request-ticket/update-device-request-ticket.request.dto';
import {
  flatMap,
  groupBy,
  keyBy,
  map,
  compact,
  uniq,
  isEmpty,
  intersection,
  difference,
} from 'lodash';
import { ListDeviceRequestsRequestDto } from '@components/device-request/dto/request/list-device-requests.request.dto';
import { DEVICE_REQUEST_CONST } from '@components/device-request/device-request.constant';
import { plainToInstance } from 'class-transformer';
import { DeviceGroupRepositoryInterface } from '@components/device-group/interface/device-group.repository.interface';
import { UpdateStatusDeviceRequestRequestDto } from './dto/request/request-ticket/update-status-device-request.request.dto';
import { InventoryRepositoryInterface } from '@components/warehouse/interface/inventory.repository.interface';
import { GetInventoryByWarehousesAndAssetsRequestDto } from '@components/warehouse/dto/request/get-inventories-by-warehouses-assets.request.dto';
import { minus } from '@utils/common';
import { ApiError } from '@utils/api.error';
import { ACTIVE_ENUM, PLANED_ASSET_ENUM } from '@constant/common';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { DetailDeviceRequestRequestDto } from './dto/request/request-ticket/detail-device-request.request.dto';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { EventRequestDto } from '@components/notification/dto/event.request.dto';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Types } from 'mongoose';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { ResponsePayload } from '@utils/response-payload';
import { DeviceRequest } from 'src/models/device-request/device-request-ticket.model';
import { TRANSFER_TICKET_STATUS_UPDATE_TYPE_ENUM } from '@components/transfer-ticket/transfer-ticket.constant';

@Injectable()
export class DeviceRequestService implements DeviceRequestServiceInterface {
  constructor(
    @Inject('DeviceRequestRepositoryInterface')
    private readonly deviceRequestRepository: DeviceRequestRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('DeviceGroupRepositoryInterface')
    private readonly deviceGroupRepository: DeviceGroupRepositoryInterface,

    @Inject('DeviceRepositoryInterface')
    private readonly deviceRepository: DeviceRepositoryInterface,

    @Inject('TransferTicketRepositoryInterface')
    private readonly transferTicketRepository: TransferTicketRepositoryInterface,

    @Inject('WarehouseRepositoryInterface')
    private readonly warehouseRepository: WarehouseRepositoryInterface,

    @Inject('InventoryRepositoryInterface')
    private readonly inventoryRepository: InventoryRepositoryInterface,

    private readonly eventEmitter: EventEmitter2,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async list(request: ListDeviceRequestsRequestDto): Promise<any> {
    const isListForImportRequest = request.filter?.some(
      (e) => e.column === 'listForImportRequest',
    );
    if (isListForImportRequest) {
      request.filter?.find(
        (el, index) =>
          el.column === 'factoryIds' && request.filter.splice(index, 1),
      );
    }
    const { items, count } = await this.deviceRequestRepository.getList(
      request,
    );
    const factoryIds = uniq(
      compact(flatMap(items, (e) => [e.factoryId, e.toFactoryId])),
    );
    let factories = await this.userService.getFactoryList([
      {
        column: 'factoryIds',
        text: factoryIds,
      },
    ]);
    factories = keyBy(factories, 'id');

    items.forEach((item) => {
      item.factory = factories[item.toFactoryId] ?? factories[item.factoryId];
      item.toFactory = factories[item.toFactoryId];
      item.fromFactory = item.factory;
    });
    const response = plainToInstance(DetailDeviceRequestResponseDto, items, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder({
      items: response,
      meta: { total: count, page: request?.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async create(payload: CreateDeviceProvideRequestDto): Promise<any> {
    const validate = await this.validateBeforeSave(payload);
    if (validate.statusCode !== ResponseCodeEnum.SUCCESS) {
      return validate;
    }
    const { request } = validate.data;
    // generate code cho yêu cầu mới
    const code = await this.deviceRequestRepository.generateNextCodeWithYear(
      DEVICE_REQUEST_CONST.CODE.PREFIX,
    );
    const deviceRequest = this.deviceRequestRepository.createDocument(
      request,
      code,
    );
    const dataSave = await deviceRequest.save();
    const dataReturn = plainToInstance(BasicResponseDto, dataSave, {
      excludeExtraneousValues: true,
    });
    this.eventEmitter.emit(
      DEVICE_REQUEST_EVENTS_ENUM.CREATED,
      new EventRequestDto({
        id: deviceRequest._id,
        code: deviceRequest.code,
        name: '',
        entityType: request.type,
        fromUserId: request.user.id,
      }),
    );
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
  async validateBeforeSave(
    request: CreateDeviceProvideRequestDto,
    id: string = null,
  ): Promise<
    ResponsePayload<{
      deviceRequest?: DeviceRequest;
      request?: CreateDeviceProvideRequestDto;
    }>
  > {
    const { deviceGroupRequest, deviceIds, transferTicketId, type } = request;
    let { factoryId } = request;

    // nếu loại yêu cầu là cấp thì cần kiểm tra nhóm thiết bị và nhà máy nhận có tồn tại hay không
    if (type === DEVICE_REQUEST_TYPE_ENUM.REQUEST) {
      // kiểm tra nhóm thiết bị tồn tại hay không
      const deviceGroupIds = map(deviceGroupRequest, 'deviceGroupId');
      const deviceGroups = await this.deviceGroupRepository.findAllByCondition({
        _id: {
          $in: deviceGroupIds,
        },
      });
      if (deviceGroups.length !== deviceGroupIds.length) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.DEVICE_GROUP_NOT_FOUND'),
          )
          .build();
      }

      // kiểm tra nhà máy nhận tồn tại hay không
      const factory = await this.userService.getFactoryById(factoryId);
      if (!factory) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.FACTORY_NOT_FOUND'))
          .build();
      }
    } else {
      // kiểm tra thiết bị tồn tại
      const devices = await this.deviceRepository.findAllByCondition({
        _id: { $in: deviceIds },
        active: ACTIVE_ENUM.ACTIVE,
      });
      if (devices.length !== deviceIds.length) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.DEVICE_INACTIVE'))
          .build();
      }
      const transferTicket =
        await this.transferTicketRepository.findOneWithPopulate(
          { _id: transferTicketId },
          { path: 'transferRequest', populate: 'request' },
        );
      if (!transferTicket) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.TRANSFER_TICKET_NOT_FOUND'),
          )
          .build();
      }
      request.devices = devices?.map((e) => ({
        deviceId: e._id,
        warehouseId: e.warehouseId,
      }));
      request.factoryId = transferTicket?.toFactoryId;
      request.toFactoryId = transferTicket?.fromFactoryId;
      factoryId = transferTicket?.toFactoryId;
    }

    let deviceRequest = {} as any;
    if (id) {
      deviceRequest = await this.deviceRequestRepository.findOneByCondition({
        _id: id,
      });
      if (!deviceRequest) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.REQUEST_NOT_FOUND'))
          .build();
      }
      if (!DEVICE_REQUEST_STATUS_CAN_UPDATE.includes(deviceRequest.status)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.DEVICE_REQUEST_STATUS_INVALID'),
          )
          .build();
      }
    }
    return new ResponseBuilder({ deviceRequest, request })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async detail(
    request: DetailDeviceRequestRequestDto & PaginationQuery,
  ): Promise<any> {
    const deviceRequest: any =
      await this.deviceRequestRepository.findOneWithPopulate(
        { ...request.permissionCondition, _id: new Types.ObjectId(request.id) },
        [
          {
            path: 'deviceGroupRequest.deviceGroup devices.warehouse',
          },
          {
            path: 'devices.device',
            populate: [{ path: 'deviceGroup warehouse area' }],
          },
          {
            path: 'transferTicket',
            populate: { path: 'transferRequest', populate: 'request' },
          },
        ],
      );
    if (!deviceRequest) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const toFactoryId = deviceRequest?.transferTicket?.fromFactoryId;
    const estimatedReturnDate =
      deviceRequest?.transferTicket?.transferRequest?.estimatedReturnDate;
    const fromFactoryId =
      deviceRequest?.transferTicket?.transferRequest?.request?.factoryId;
    const deviceGroupIds = map(
      deviceRequest.deviceGroupRequest,
      'deviceGroupId',
    );
    const factories = await this.userService.getFactoryList([
      {
        column: 'factoryIds',
        text: compact([fromFactoryId, toFactoryId]),
      },
    ]);
    const factoryMap = keyBy(factories, 'id');

    // lấy số lượng tồn kho theo nhà máy
    const warehouses = await this.warehouseRepository.findAllByCondition({
      factoryId: deviceRequest.factoryId,
    });
    const warehouseIds = map(warehouses, '_id');
    const inventoryByFactory =
      await this.inventoryRepository.getInventoryByWarehousesAndAssets({
        assetIds: deviceGroupIds,
        warehouseIds: warehouseIds,
      });

    // lấy số lượng tồn kho ở tất cả nhà máy
    const inventories =
      await this.inventoryRepository.getInventoryByWarehousesAndAssets({
        assetIds: deviceGroupIds,
      } as GetInventoryByWarehousesAndAssetsRequestDto);
    const inventoryByFactoryMap = keyBy(inventoryByFactory, '_id.assetId');
    const inventoryMap = keyBy(inventories, '_id.assetId');

    // lấy số lượng tồn kho kế hoạch
    const deviceRequestPlanned =
      await this.deviceRequestRepository.findAllByCondition({
        type: DEVICE_REQUEST_TYPE_ENUM.REQUEST,
        status: DEVICE_REQUEST_STATUS_ENUM.CONFIRMED,
        'deviceGroupRequest.deviceGroupId': { $in: deviceGroupIds },
        deletedAt: null,
      });
    const deviceGroupPlanned: any = groupBy(
      flatMap(deviceRequestPlanned, 'deviceGroupRequest'),
      'deviceGroupId',
    );
    const plannedQuantity = {};
    for (const deviceGroupId in deviceGroupPlanned) {
      const planQuantity = deviceGroupPlanned[deviceGroupId].reduce(
        (total, curr) => (total += curr.quantity || 0),
        0,
      );
      plannedQuantity[deviceGroupId] = { deviceGroupId, planQuantity };
    }

    const factory = await this.userService.getFactoryById(
      deviceRequest.factoryId,
    );
    const response = plainToInstance(
      DetailDeviceRequestResponseDto,
      {
        ...deviceRequest,
        factory,
        fromFactory: factoryMap[fromFactoryId],
        toFactory: factoryMap[toFactoryId],
        estimatedReturnDate,
        devices: deviceRequest.devices?.map((e) => ({
          ...e,
          ...e.device,
          warehouse: e.warehouse,
        })),
        deviceGroupRequest: deviceRequest?.deviceGroupRequest?.map(
          (deviceGroup) => {
            const planQuantity =
              plannedQuantity[deviceGroup.deviceGroupId.toString()]
                ?.planQuantity || 0;
            const availableStockQuantityInFactory = returnStockQuantity(
              minus(
                inventoryByFactoryMap[deviceGroup.deviceGroupId.toString()]
                  ?.availableQuantity || 0,
                planQuantity,
              ),
            );
            const availableStockQuantity = returnStockQuantity(
              minus(
                inventoryMap[deviceGroup.deviceGroupId.toString()]
                  ?.availableQuantity || 0,
                planQuantity,
              ),
            );
            const availableStockQuantityOtherFactory = returnStockQuantity(
              minus(availableStockQuantity, availableStockQuantityInFactory),
            );
            return {
              ...deviceGroup,
              availableStockQuantityInFactory,
              availableStockQuantity,
              availableStockQuantityOtherFactory,
            };
          },
        ),
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async update(payload: UpdateDeviceRequestRequestDto): Promise<any> {
    const validate = await this.validateBeforeSave(payload, payload.id);
    if (validate.statusCode !== ResponseCodeEnum.SUCCESS) {
      return validate;
    }
    const { deviceRequest, request } = validate.data;
    try {
      const deviceRequestUpdate = this.deviceRequestRepository.updateDocument(
        deviceRequest,
        request,
      );
      await this.deviceRequestRepository.findByIdAndUpdate(
        payload.id,
        deviceRequestUpdate,
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async delete(request: IdParamDto): Promise<any> {
    const { id } = request;

    const deviceRequest = await this.deviceRequestRepository.findOneByCondition(
      { ...request.permissionCondition, _id: id },
    );
    if (!deviceRequest) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!DEVICE_REQUEST_STATUS_CAN_DELETE.includes(deviceRequest.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.DEVICE_REQUEST_STATUS_INVALID'),
        )
        .build();
    }
    try {
      await this.deviceRequestRepository.softDelete(id);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async updateStatus(
    request: UpdateStatusDeviceRequestRequestDto,
  ): Promise<any> {
    const { id, action } = request;

    const status = this.getNextDeviceStatusByAction(action);
    const deviceRequest =
      await this.deviceRequestRepository.findOneWithPopulate(
        { ...request.permissionCondition, _id: id },
        'transferTicket',
      );
    if (!deviceRequest) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const isStatusValid = this.checkStatusValid(deviceRequest.status, status);
    if (!isStatusValid) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.DEVICE_REQUEST_STATUS_INVALID'),
        )
        .build();
    }
    if (
      deviceRequest.type === DEVICE_REQUEST_TYPE_ENUM.RETURN &&
      status === DEVICE_REQUEST_STATUS_ENUM.CONFIRMED
    ) {
      const validate = await this.handleConfirmRequest(deviceRequest);
      if (validate.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validate;
      }
    }

    try {
      const eventPayload = new EventRequestDto({
        id: deviceRequest._id,
        code: deviceRequest.code,
        name: '',
        entityType: deviceRequest.type,
        fromUserId: request.user.id,
      });
      switch (status) {
        case DEVICE_REQUEST_STATUS_ENUM.REJECTED:
          this.eventEmitter.emit(
            DEVICE_REQUEST_EVENTS_ENUM.REJECTED,
            eventPayload,
          );
          break;
        case DEVICE_REQUEST_STATUS_ENUM.CONFIRMED:
          this.eventEmitter.emit(
            DEVICE_REQUEST_EVENTS_ENUM.APPROVED,
            eventPayload,
          );
          break;
        case DEVICE_REQUEST_STATUS_ENUM.COMPLETED:
          this.eventEmitter.emit(
            DEVICE_REQUEST_EVENTS_ENUM.COMPLETED,
            eventPayload,
          );
          break;
        default:
          break;
      }
      await this.deviceRequestRepository.findByIdAndUpdate(id, {
        $set: {
          status,
        },
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async handleConfirmRequest(deviceRequest: DeviceRequest) {
    if (
      !TRANSFER_TICKET_CAN_CREATE_RETURN_REQUEST.includes(
        deviceRequest['transferTicket']?.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.TRANSFER_TICKET_STATUS_INVALID'),
        )
        .build();
    }
    const returnDeviceIdCurs = map(deviceRequest.devices, (e) =>
      e.deviceId.toString(),
    );
    const devices = await this.deviceRepository.findAllByCondition({
      active: ACTIVE_ENUM.ACTIVE,
      _id: { $in: returnDeviceIdCurs },
      factoryId: deviceRequest.factoryId,
    });
    if (devices.length !== returnDeviceIdCurs.length) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.DEVICE_YET_EXPORT'),
      ).toResponse();
    }
    // check tổng số lượng trả so với phiếu điều chuyển
    const deviceRequests =
      await this.deviceRequestRepository.findAllByCondition({
        transferTicketId: deviceRequest.transferTicketId,
        status: {
          $in: [
            DEVICE_REQUEST_STATUS_ENUM.CONFIRMED,
            DEVICE_REQUEST_STATUS_ENUM.COMPLETED,
          ],
        },
      });
    const returnedDeviceIds = map(flatMap(deviceRequests, 'devices'), (e) =>
      e.deviceId.toString(),
    );
    const requestDeviceIds = map(
      deviceRequest['transferTicket']?.devices,
      (e) => e.deviceId.toString(),
    );

    if (!isEmpty(intersection(returnDeviceIdCurs, returnedDeviceIds))) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.RETURN_PLANED_DEVICE'),
      ).toResponse();
    }

    if (!isEmpty(difference(returnDeviceIdCurs, requestDeviceIds))) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.DEVICE_DIFF_REQUEST'),
      ).toResponse();
    }
    // update status return in devices of transfer
    const updateDevicesInRequest = deviceRequest['transferTicket']?.devices.map(
      (e) => {
        if (returnDeviceIdCurs.includes(e.deviceId.toString())) {
          e.returnPlanned = PLANED_ASSET_ENUM.YES;
        }
        return e;
      },
    );

    await this.transferTicketRepository.findByIdAndUpdate(
      deviceRequest.transferTicketId,
      {
        $set: {
          devices: updateDevicesInRequest,
        },
      },
    );

    await this.transferTicketRepository.updateStatusByRequest(
      deviceRequest.transferTicketId,
      TRANSFER_TICKET_STATUS_UPDATE_TYPE_ENUM.CONFIRM_RETURN_REQUEST,
    );
    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  private getNextDeviceStatusByAction(action: string): number {
    switch (action) {
      case DEVICE_REQUEST_ACTION_CONFIRMED:
        return DEVICE_REQUEST_STATUS_ENUM.CONFIRMED;
      case DEVICE_REQUEST_ACTION_REJECTED:
        return DEVICE_REQUEST_STATUS_ENUM.REJECTED;
      default:
        return DEVICE_REQUEST_STATUS_ENUM.WAITING_APPROVE;
    }
  }

  private checkStatusValid(oldStatus, newStatus) {
    switch (newStatus) {
      case DEVICE_REQUEST_STATUS_ENUM.CONFIRMED:
        return oldStatus === DEVICE_REQUEST_STATUS_ENUM.WAITING_APPROVE;
      case DEVICE_REQUEST_STATUS_ENUM.REJECTED:
        return oldStatus === DEVICE_REQUEST_STATUS_ENUM.WAITING_APPROVE;
      default:
        return false;
    }
  }
}
