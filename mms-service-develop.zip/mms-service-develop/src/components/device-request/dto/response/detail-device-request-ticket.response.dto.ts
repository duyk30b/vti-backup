import { BasicSqlDocumentResponse } from '@utils/dto/response/basic-sql-document.response';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { Expose, Transform, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { DeviceBasicResponseDto } from '@components/device/dto/response/device-basic.response.dto';
export class DeviceDetailDto extends DeviceBasicResponseDto {
  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  deviceGroup: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  area: BasicResponseDto;

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  warehouse: BasicResponseDto;

  @ApiProperty()
  @Expose()
  exportPlanned: number;

  @ApiProperty()
  @Expose()
  importPlanned: number;
}

class DeviceGroupRequest {
  @ApiProperty()
  @Expose()
  @Transform((value) => value.obj.deviceGroupId?.toString())
  deviceGroupId: string;

  @ApiProperty()
  @Expose()
  @Transform((value) => value.obj.deviceGroup?.code)
  code: string;

  @ApiProperty()
  @Expose()
  @Transform((value) => value.obj.deviceGroup?.name)
  name: string;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  availableStockQuantity: number;

  @ApiProperty()
  @Expose()
  availableStockQuantityInFactory: number;

  @ApiProperty()
  @Expose()
  availableStockQuantityOtherFactory: number;
}

export class DetailDeviceRequestResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Expose()
  @Type(() => BasicSqlDocumentResponse)
  factory: BasicSqlDocumentResponse;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Expose()
  @Type(() => BasicSqlDocumentResponse)
  toFactory: BasicSqlDocumentResponse;

  @ApiProperty({ type: BasicSqlDocumentResponse })
  @Expose()
  @Type(() => BasicSqlDocumentResponse)
  fromFactory: BasicSqlDocumentResponse;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  expectReturnDate: Date;

  @ApiProperty()
  @Expose()
  estimatedReturnDate: Date;

  @ApiProperty({ type: DeviceGroupRequest, isArray: true })
  @Expose()
  @Type(() => DeviceGroupRequest)
  deviceGroupRequest: DeviceGroupRequest[];

  @ApiProperty({ type: DeviceDetailDto, isArray: true })
  @Expose()
  @Type(() => DeviceDetailDto)
  devices: DeviceDetailDto[];

  @ApiProperty({ type: BasicResponseDto, isArray: true })
  @Expose()
  @Type(() => BasicResponseDto)
  deviceGroups: BasicResponseDto[];

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  transferTicket: BasicResponseDto;
}
