import { Expose, Type } from 'class-transformer';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { ApiProperty } from '@nestjs/swagger';
import { DetailDeviceRequestResponseDto } from './detail-device-request-ticket.response.dto';

export class ListDeviceRequestsResponseDto extends PaginationResponse {
  @ApiProperty({ type: DetailDeviceRequestResponseDto, isArray: true })
  @Expose()
  @Type(() => DetailDeviceRequestResponseDto)
  items: DetailDeviceRequestResponseDto;
}
