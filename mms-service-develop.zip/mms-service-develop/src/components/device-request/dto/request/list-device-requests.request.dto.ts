import { IsOptional, IsString } from 'class-validator';
import { PaginationQuery } from '@utils/dto/request/pagination.query';

export class ListDeviceRequestsRequestDto extends PaginationQuery {
  @IsOptional()
  isGetAll: boolean;

  @IsOptional()
  @IsString()
  queryIds?: string;
}
