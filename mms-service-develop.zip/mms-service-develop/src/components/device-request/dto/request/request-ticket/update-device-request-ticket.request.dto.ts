import {
  CreateDeviceProvideRequestBody,
  CreateDeviceProvideRequestDto,
} from '@components/device-request/dto/request/request-ticket/create-device-request-ticket.request.dto';
import { IsMongoId, IsNotEmpty, IsString } from 'class-validator';

export class UpdateDeviceRequestBody extends CreateDeviceProvideRequestBody {}

export class UpdateDeviceRequestRequestDto extends CreateDeviceProvideRequestDto {
  @IsString()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
