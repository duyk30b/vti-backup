import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsDateString,
  IsEnum,
  IsInt,
  IsMongoId,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  Min,
  ValidateIf,
  ValidateNested,
} from 'class-validator';
import {
  DEVICE_REQUEST_CONST,
  DEVICE_REQUEST_TYPE_ENUM,
} from '@components/device-request/device-request.constant';
import { BaseDto } from '@core/dto/base.dto';
import { IsNotBlank } from 'src/validator/is-not-blank.validator';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class DeviceGroupDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  deviceGroupId: string;

  @ApiProperty()
  @IsInt()
  @Min(1)
  @IsNotEmpty()
  quantity: number;
}

export class CreateDeviceProvideRequestBody extends BaseDto {
  devices: any[];
  toFactoryId: number;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  @MaxLength(DEVICE_REQUEST_CONST.NAME.MAX_LENGTH)
  @IsNotBlank()
  name: string;

  @ValidateIf((data) => data.type === DEVICE_REQUEST_TYPE_ENUM.REQUEST)
  @ApiProperty({ description: 'Id nhà máy nhận' })
  @IsInt()
  @IsNotEmpty()
  factoryId: number;

  @ApiProperty()
  @IsEnum(DEVICE_REQUEST_TYPE_ENUM)
  @IsNotEmpty()
  type: number;

  @ApiProperty()
  @IsDateString()
  @IsOptional()
  expectReturnDate: Date;

  @ApiProperty()
  @IsString()
  @IsOptional()
  @MaxLength(DEVICE_REQUEST_CONST.DESCRIPTION.MAX_LENGTH)
  description: string;

  @ValidateIf((data) => data.type === DEVICE_REQUEST_TYPE_ENUM.RETURN)
  @ApiProperty({ type: String, isArray: true })
  @IsArray()
  @ArrayNotEmpty()
  @ArrayUnique((data) => data)
  deviceIds: string[];

  @ValidateIf((data) => data.type === DEVICE_REQUEST_TYPE_ENUM.RETURN)
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  transferTicketId: string;

  @ValidateIf((data) => data.type === DEVICE_REQUEST_TYPE_ENUM.REQUEST)
  @ApiProperty({ type: DeviceGroupDto, isArray: true })
  @ArrayNotEmpty()
  @IsArray()
  @ArrayUnique((data: DeviceGroupDto) => data.deviceGroupId)
  @Type(() => DeviceGroupDto)
  @ValidateNested({ each: true })
  deviceGroupRequest: DeviceGroupDto[];
}

export class CreateDeviceProvideRequestDto extends CreateDeviceProvideRequestBody {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  createdBy: number;
}
