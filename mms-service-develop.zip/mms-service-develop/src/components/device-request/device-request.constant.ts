import { TRANSFER_TICKET_STATUS_ENUM } from '@components/transfer-ticket/transfer-ticket.constant';
import { CODE_REGEX } from '@constant/common';

export enum DEVICE_REQUEST_STATUS_ENUM {
  WAITING_APPROVE,
  CONFIRMED,
  REJECTED,
  COMPLETED,
}

export const DEVICE_REQUEST_ACTION_APPROVE = 'approve';
export const DEVICE_REQUEST_ACTION_CONFIRMED = 'confirmed';
export const DEVICE_REQUEST_ACTION_REJECTED = 'rejected';

export const DEVICE_REQUEST_ACTION = [
  DEVICE_REQUEST_ACTION_APPROVE,
  DEVICE_REQUEST_ACTION_CONFIRMED,
  DEVICE_REQUEST_ACTION_REJECTED,
];

export const DEVICE_REQUEST_STATUS_CAN_DELETE = [
  DEVICE_REQUEST_STATUS_ENUM.WAITING_APPROVE,
];

export const DEVICE_REQUEST_STATUS_CAN_UPDATE = [
  DEVICE_REQUEST_STATUS_ENUM.WAITING_APPROVE,
];

export const DEVICE_REQUEST_CONST = {
  CODE: {
    LENGTH: 20,
    COLUMN: 'code',
    PAD_CHAR: '0',
    PREFIX: 'YCTB',
    DEFAULT_CODE: 0,
    GAP: 1,
    REGEX: CODE_REGEX,
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  STATUS: {
    COLUMN: 'status',
    ENUM: DEVICE_REQUEST_STATUS_ENUM,
  },
  TYPE: {
    COLUMN: 'type',
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
  DEVICE_GROUP: {
    COLUMN: 'deviceGroupIds',
  },
  DEVICE: {
    COLUMN: 'deviceIds',
  },
  REQUEST_TICKET: {
    COLL: 'deviceRequests',
  },
  QUANTITY: {
    COLUMN: 'quantity',
  },
};

export enum DEVICE_REQUEST_TYPE_ENUM {
  REQUEST,
  RETURN,
}

export enum DEVICE_REQUEST_EVENTS_ENUM {
  CREATED = 'device-request.created',
  APPROVED = 'device-request.approved',
  REJECTED = 'device-request.rejected',
  COMPLETED = 'device-request.completed',
}

export const TRANSFER_TICKET_CAN_CREATE_RETURN_REQUEST = [
  TRANSFER_TICKET_STATUS_ENUM.IMPORTED,
  TRANSFER_TICKET_STATUS_ENUM.IMPORTING,
  TRANSFER_TICKET_STATUS_ENUM.RETURNING,
];
