import { WarehouseRepository } from 'src/repository/warehouse/warehouse.repository';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { UserModule } from '@components/user/user.module';
import { DeviceRequestService } from '@components/device-request/device-request.service';
import { DeviceRequestRepository } from 'src/repository/device-request/device-request-ticket.repository';
import { DeviceRequestSchema } from 'src/models/device-request/device-request-ticket.schema';
import { DeviceRequestController } from '@components/device-request/device-request.controller';
import { DeviceRepository } from 'src/repository/device/device.repository';
import { DeviceAssignmentRepository } from 'src/repository/device-assignment/device-assignment.repository';
import { DeviceGroupRepository } from 'src/repository/device-group/device-group.repository';
import { AreaRepository } from 'src/repository/area/area.repository';
import { TransferRequestSchema } from 'src/models/transfer-request/transfer-request.schema';
import { DeviceAssignmentSchema } from 'src/models/device-assignment/device-assignment.schema';
import { DeviceSchema } from 'src/models/device/device.schema';
import { AreaSchema } from 'src/models/area/area.schema';
import { DeviceGroupSchema } from 'src/models/device-group/device-group.schema';
import { InventorySchema } from 'src/models/warehouse-inventories/inventory.schema';
import { InventoryRepository } from 'src/repository/warehouse-inventories/inventory.repository';
import { WarehouseSchema } from 'src/models/warehouse/warehouse.schema';
import { TransferTicketRepository } from 'src/repository/transfer-ticket/transfer-ticket.repository';
import { NotificationService } from '@components/notification/notification.service';
import { ConfigService } from '@config/config.service';
import { DeviceAssignmentNotificationListener } from './listeners/device-request.notification.listener';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'DeviceRequest', schema: DeviceRequestSchema },
      { name: 'TransferRequest', schema: TransferRequestSchema },
      { name: 'DeviceAssignment', schema: DeviceAssignmentSchema },
      { name: 'Device', schema: DeviceSchema },
      { name: 'DeviceGroup', schema: DeviceGroupSchema },
      { name: 'Area', schema: AreaSchema },
      { name: 'Inventory', schema: InventorySchema },
      { name: 'Warehouse', schema: WarehouseSchema },
    ]),
    UserModule,
  ],
  controllers: [DeviceRequestController],
  providers: [
    {
      provide: 'DeviceRequestRepositoryInterface',
      useClass: DeviceRequestRepository,
    },
    {
      provide: 'DeviceRequestServiceInterface',
      useClass: DeviceRequestService,
    },
    {
      provide: 'DeviceGroupRepositoryInterface',
      useClass: DeviceGroupRepository,
    },
    {
      provide: 'DeviceAssignmentRepositoryInterface',
      useClass: DeviceAssignmentRepository,
    },
    {
      provide: 'DeviceRepositoryInterface',
      useClass: DeviceRepository,
    },
    {
      provide: 'AreaRepositoryInterface',
      useClass: AreaRepository,
    },
    {
      provide: 'TransferTicketRepositoryInterface',
      useClass: TransferTicketRepository,
    },
    {
      provide: 'InventoryRepositoryInterface',
      useClass: InventoryRepository,
    },
    {
      provide: 'WarehouseRepositoryInterface',
      useClass: WarehouseRepository,
    },
    ConfigService,
    {
      provide: 'NotificationServiceInterface',
      useClass: NotificationService,
    },
    DeviceAssignmentNotificationListener,
  ],
  exports: [
    MongooseModule,
    {
      provide: 'DeviceRequestServiceInterface',
      useClass: DeviceRequestService,
    },
    {
      provide: 'DeviceRequestRepositoryInterface',
      useClass: DeviceRequestRepository,
    },
  ],
})
export class DeviceRequestModule {}
