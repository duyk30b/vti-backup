import { IdParamDto } from './../../utils/dto/request/param-id.request.dto';
import {
  Body,
  Controller,
  Inject,
  Injectable,
  Param,
  Query,
  Post,
  Put,
  Delete,
  Get,
  UseInterceptors,
} from '@nestjs/common';
import { isEmpty } from 'lodash';
import { DeviceRequestServiceInterface } from '@components/device-request/interface/device-request.service.interface';
import { CreateDeviceProvideRequestBody } from '@components/device-request/dto/request/request-ticket/create-device-request-ticket.request.dto';
import { DetailDeviceRequestRequestDto } from '@components/device-request/dto/request/request-ticket/detail-device-request.request.dto';
import { UpdateDeviceRequestBody } from '@components/device-request/dto/request/request-ticket/update-device-request-ticket.request.dto';
import { ListDeviceRequestsRequestDto } from '@components/device-request/dto/request/list-device-requests.request.dto';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { DetailDeviceRequestResponseDto } from './dto/response/detail-device-request-ticket.response.dto';
import { ListDeviceRequestsResponseDto } from './dto/response/list-device-requests.response.dto';
import {
  CONFIRM_DEVICE_REQUEST_PERMISSION,
  CREATE_GRANT_DEVICE_REQUEST_TICKET_PERMISSION,
  CREATE_RETURN_DEVICE_REQUEST_TICKET_PERMISSION,
  DELETE_DEVICE_REQUEST_TICKET_PERMISSION,
  DETAIL_DEVICE_REQUEST_TICKET_PERMISSION,
  LIST_DEVICE_REQUEST_PERMISSION,
  UPDATE_DEVICE_REQUEST_TICKET_PERMISSION,
} from '@utils/permissions/device-request';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { UpdateStatusDeviceRequestRequestDto } from './dto/request/request-ticket/update-status-device-request.request.dto';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { PermissionInterceptor } from '@core/interceptors/permission.interceptor';
import {
  CREATE_DEVICE_ASSIGNMENT_PERMISSION,
  UPDATE_DEVICE_ASSIGNMENT_PERMISSION,
} from '@utils/permissions/device-assignment';
import {
  CREATE_WAREHOUSE_IMPORT_REQUEST_PERMISSION,
  UPDATE_WAREHOUSE_IMPORT_REQUEST_PERMISSION,
} from '@utils/permissions/warehouse-import-request';
import {
  CREATE_WAREHOUSE_EXPORT_REQUEST_PERMISSION,
  UPDATE_WAREHOUSE_EXPORT_REQUEST_PERMISSION,
} from '@utils/permissions/warehouse-export-request';
import {
  CREATE_TRANSFER_REQUEST_PERMISSION,
  UPDATE_TRANSFER_REQUEST_PERMISSION,
} from '@utils/permissions/transfer-request';

@Injectable()
@Controller('device-requests')
export class DeviceRequestController {
  constructor(
    @Inject('DeviceRequestServiceInterface')
    private readonly deviceRequestService: DeviceRequestServiceInterface,
  ) {}

  @PermissionCode(
    LIST_DEVICE_REQUEST_PERMISSION.code,
    UPDATE_DEVICE_ASSIGNMENT_PERMISSION.code,
    CREATE_DEVICE_ASSIGNMENT_PERMISSION.code,
    CREATE_WAREHOUSE_IMPORT_REQUEST_PERMISSION.code,
    UPDATE_WAREHOUSE_IMPORT_REQUEST_PERMISSION.code,
    CREATE_WAREHOUSE_EXPORT_REQUEST_PERMISSION.code,
    UPDATE_WAREHOUSE_EXPORT_REQUEST_PERMISSION.code,
    UPDATE_TRANSFER_REQUEST_PERMISSION.code,
    CREATE_TRANSFER_REQUEST_PERMISSION.code,
  )
  @UseInterceptors(PermissionInterceptor)
  @ApiOperation({
    tags: ['Device Requests'],
    summary: 'Danh sách yêu cầu thiết bị',
    description: 'Danh sách yêu cầu thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListDeviceRequestsResponseDto,
  })
  @Get('/')
  async list(@Query() query: ListDeviceRequestsRequestDto): Promise<any> {
    const { request, responseError } = query;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceRequestService.list(request);
  }

  @PermissionCode(CREATE_GRANT_DEVICE_REQUEST_TICKET_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @ApiOperation({
    tags: ['Device Requests'],
    summary: 'Tạo yêu cầu cấp thiết bị',
    description: 'Tạo yêu cầu trả thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  @Post('/grant')
  async createBorrowRequest(
    @Body() payload: CreateDeviceProvideRequestBody,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceRequestService.create({
      ...request,
      createdBy: request.userId,
    });
  }

  @PermissionCode(CREATE_RETURN_DEVICE_REQUEST_TICKET_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @ApiOperation({
    tags: ['Device Requests'],
    summary: 'Tạo yêu cầu trả thiết bị',
    description: 'Tạo yêu cầu trả thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  @Post('/return')
  async createReturnRequest(
    @Body() payload: CreateDeviceProvideRequestBody,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceRequestService.create({
      ...request,
      createdBy: request.userId,
    });
  }

  @PermissionCode(DELETE_DEVICE_REQUEST_TICKET_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @ApiOperation({
    tags: ['Device Requests'],
    summary: 'Xóa yêu cầu thiết bị',
    description: 'Xóa yêu cầu thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  @Delete('/:id')
  async delete(@Param() payload: IdParamDto): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.deviceRequestService.delete(request);
  }

  @PermissionCode(
    DETAIL_DEVICE_REQUEST_TICKET_PERMISSION.code,
    UPDATE_DEVICE_ASSIGNMENT_PERMISSION.code,
    CREATE_DEVICE_ASSIGNMENT_PERMISSION.code,
    CREATE_WAREHOUSE_IMPORT_REQUEST_PERMISSION.code,
    UPDATE_WAREHOUSE_IMPORT_REQUEST_PERMISSION.code,
    CREATE_WAREHOUSE_EXPORT_REQUEST_PERMISSION.code,
    UPDATE_WAREHOUSE_EXPORT_REQUEST_PERMISSION.code,
    UPDATE_TRANSFER_REQUEST_PERMISSION.code,
    CREATE_TRANSFER_REQUEST_PERMISSION.code,
  )
  @UseInterceptors(PermissionInterceptor)
  @ApiOperation({
    tags: ['Device Requests'],
    summary: 'Chi tiết yêu cầu thiết bị',
    description: 'Chi tiết yêu cầu thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailDeviceRequestResponseDto,
  })
  @Get('/:id')
  async detail(
    @Param() payload: DetailDeviceRequestRequestDto,
    @Query() query: PaginationQuery,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceRequestService.detail({
      ...request,
      filter: query.filter,
    });
  }

  @PermissionCode(UPDATE_DEVICE_REQUEST_TICKET_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @ApiOperation({
    tags: ['Device Requests'],
    summary: 'Sửa yêu cầu thiết bị',
    description: 'Sửa yêu cầu thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  @Put('/:id')
  async update(
    @Param() param: DetailDeviceRequestRequestDto,
    @Body() payload: UpdateDeviceRequestBody,
  ): Promise<any> {
    const { request: requestParam, responseError: responseErrorParam } = param;
    if (responseErrorParam && !isEmpty(responseErrorParam)) {
      return responseErrorParam;
    }

    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceRequestService.update({
      ...request,
      id: requestParam.id,
    });
  }

  @PermissionCode(CONFIRM_DEVICE_REQUEST_PERMISSION.code)
  @UseInterceptors(PermissionInterceptor)
  @ApiOperation({
    tags: ['Device Requests'],
    summary: 'Approve/reject cầu thiết bị',
    description: 'Approve/reject yêu cầu thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  @Put('/:id/:action')
  async updateStatus(
    @Param() param: UpdateStatusDeviceRequestRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (request && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceRequestService.updateStatus(request);
  }
}
