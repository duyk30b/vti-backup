import { CreateDeviceProvideRequestDto } from '@components/device-request/dto/request/request-ticket/create-device-request-ticket.request.dto';
import { ListDeviceRequestsRequestDto } from '@components/device-request/dto/request/list-device-requests.request.dto';
import { UpdateStatusDeviceRequestRequestDto } from '../dto/request/request-ticket/update-status-device-request.request.dto';
import { UpdateDeviceRequestRequestDto } from '../dto/request/request-ticket/update-device-request-ticket.request.dto';
import { DetailDeviceRequestRequestDto } from '../dto/request/request-ticket/detail-device-request.request.dto';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';

export interface DeviceRequestServiceInterface {
  list(request: ListDeviceRequestsRequestDto): Promise<any>;
  create(request: CreateDeviceProvideRequestDto): Promise<any>;
  detail(
    request: DetailDeviceRequestRequestDto & PaginationQuery,
  ): Promise<any>;
  update(request: UpdateDeviceRequestRequestDto): Promise<any>;
  delete(request: IdParamDto): Promise<any>;
  updateStatus(request: UpdateStatusDeviceRequestRequestDto): Promise<any>;
}
