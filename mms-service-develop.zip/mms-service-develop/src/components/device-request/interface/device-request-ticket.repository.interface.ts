import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { DeviceRequest } from 'src/models/device-request/device-request-ticket.model';
import { CreateDeviceProvideRequestDto } from '@components/device-request/dto/request/request-ticket/create-device-request-ticket.request.dto';
import { ListDeviceRequestsRequestDto } from '@components/device-request/dto/request/list-device-requests.request.dto';

export interface DeviceRequestRepositoryInterface
  extends BaseInterfaceRepository<DeviceRequest> {
  getList(
    request: ListDeviceRequestsRequestDto,
    isGetAll?: boolean,
  ): Promise<any>;
  createDocument(
    request: CreateDeviceProvideRequestDto,
    code: string,
  ): DeviceRequest;
  updateDocument(entity: DeviceRequest, data: any): DeviceRequest;
}
