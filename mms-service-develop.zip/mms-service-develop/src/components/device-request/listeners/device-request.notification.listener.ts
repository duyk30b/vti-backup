import { EventRequestDto } from '@components/notification/dto/event.request.dto';
import { PushNotificationRequestDto } from '@components/notification/dto/notification.request.dto';
import { NotificationServiceInterface } from '@components/notification/interface/notification.service.interface';
import {
  NOTIFICATION_ENTITY_ENUM,
  TYPE_NOTIFICATION_RENDER_ACTION_ENUM,
} from '@components/notification/notification.const';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { NotificationListenerAbstract } from '@core/abstracts/notification.listener.abstract';
import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { map } from 'lodash';
import { I18nService } from 'nestjs-i18n';
import { DEVICE_REQUEST_EVENTS_ENUM } from '../device-request.constant';
import { DeviceRequestRepositoryInterface } from '../interface/device-request-ticket.repository.interface';

@Injectable()
export class DeviceAssignmentNotificationListener extends NotificationListenerAbstract {
  constructor(
    @Inject('NotificationServiceInterface')
    protected readonly notificationService: NotificationServiceInterface,

    @Inject('DeviceRequestRepositoryInterface')
    private readonly deviceRequestRepository: DeviceRequestRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    private readonly i18n: I18nService,
  ) {
    super(notificationService);
  }

  @OnEvent(DEVICE_REQUEST_EVENTS_ENUM.CREATED)
  public async handleCreateDeviceAssignment(event: EventRequestDto) {
    const notificationRequest = new PushNotificationRequestDto();
    const { id, code, fromUserId } = event;
    const user = await this.userService.getDetailUser(fromUserId);
    const { fullName, username } = user;
    notificationRequest.title = await this.i18n.translate(
      'message.defineDeviceRequest.notification.createTitle',
    );
    notificationRequest.content = await this.i18n.translate(
      'message.defineDeviceRequest.notification.createContent',
      { args: { username: fullName || username, deviceRequestCode: code } },
    );
    notificationRequest.action =
      // noti created thì action(điều hướng) sang confirm and reject
      TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_CONFIRM_AND_REJECT;
    notificationRequest.payload = this.generatePayload(
      event,
      NOTIFICATION_ENTITY_ENUM.DEVICE_REQUEST_DETAIL,
    );

    const deviceRequest = await this.deviceRequestRepository.findOneById(id);
    // báo cho quản lý nhà máy của phiếu y/c
    const factoryManagers = await this.userService.getListFactoryManager(
      deviceRequest.factoryId,
    );
    const userIds = map(factoryManagers, 'id');
    notificationRequest.userIds = userIds;
    notificationRequest.createdBy = event.fromUserId;
    return [await super.sendWebNotification(notificationRequest)];
  }

  @OnEvent(DEVICE_REQUEST_EVENTS_ENUM.APPROVED)
  public async handleApproveDeviceAssigment(event: EventRequestDto) {
    const notificationRequest = new PushNotificationRequestDto();
    const { id, code, fromUserId } = event;
    const user = await this.userService.getDetailUser(fromUserId);
    const { fullName, username } = user;
    notificationRequest.title = await this.i18n.translate(
      'message.defineDeviceRequest.notification.approveTitle',
    );
    notificationRequest.content = await this.i18n.translate(
      'message.defineDeviceRequest.notification.approveContent',
      {
        args: {
          username: fullName || username,
          deviceRequestCode: code,
        },
      },
    );
    notificationRequest.action =
      TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_VIEW;
    notificationRequest.payload = this.generatePayload(
      event,
      NOTIFICATION_ENTITY_ENUM.DEVICE_REQUEST_DETAIL,
    );

    const deviceRequest = await this.deviceRequestRepository.findOneById(id);
    // báo cho quản lý nhà máy của phiếu y/c
    const factoryManagers = await this.userService.getListFactoryManager(
      deviceRequest.factoryId,
    );
    const requestBy = await this.userService.getDetailUser(
      deviceRequest.createdBy,
    );
    const userIds = map([...(factoryManagers ?? []), requestBy], 'id');
    notificationRequest.userIds = userIds;
    notificationRequest.createdBy = event.fromUserId;
    return [await super.sendWebNotification(notificationRequest)];
  }

  @OnEvent(DEVICE_REQUEST_EVENTS_ENUM.REJECTED)
  public async handleRejectDeviceAssigment(event: EventRequestDto) {
    const notificationRequest = new PushNotificationRequestDto();
    const { id, code, fromUserId } = event;
    const user = await this.userService.getDetailUser(fromUserId);
    const { fullName, username } = user;
    notificationRequest.title = await this.i18n.translate(
      'message.defineDeviceRequest.notification.rejectTitle',
    );
    notificationRequest.content = await this.i18n.translate(
      'message.defineDeviceRequest.notification.rejectContent',
      {
        args: {
          username: fullName || username,
          deviceRequestCode: code,
        },
      },
    );
    notificationRequest.action =
      TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_VIEW;
    notificationRequest.payload = this.generatePayload(
      event,
      NOTIFICATION_ENTITY_ENUM.DEVICE_REQUEST_DETAIL,
    );

    const deviceRequest = await this.deviceRequestRepository.findOneById(id);
    // báo cho quản lý nhà máy của phiếu y/c
    const factoryManagers = await this.userService.getListFactoryManager(
      deviceRequest.factoryId,
    );
    const requestBy = await this.userService.getDetailUser(
      deviceRequest.createdBy,
    );
    const userIds = map([...(factoryManagers ?? []), requestBy], 'id');
    notificationRequest.userIds = userIds;
    notificationRequest.createdBy = event.fromUserId;
    return [await super.sendWebNotification(notificationRequest)];
  }

  @OnEvent(DEVICE_REQUEST_EVENTS_ENUM.COMPLETED)
  public async handleRejectDeviceAssigments(event: EventRequestDto) {
    const notificationRequest = new PushNotificationRequestDto();
    const { id, code } = event;
    notificationRequest.title = await this.i18n.translate(
      'message.defineDeviceRequest.notification.completeTitle',
    );
    notificationRequest.content = await this.i18n.translate(
      'message.defineDeviceRequest.notification.completeContent',
      {
        args: {
          deviceRequestCode: code,
        },
      },
    );
    notificationRequest.action =
      TYPE_NOTIFICATION_RENDER_ACTION_ENUM.ACTION_VIEW;
    notificationRequest.payload = this.generatePayload(
      event,
      NOTIFICATION_ENTITY_ENUM.DEVICE_REQUEST_DETAIL,
    );

    const deviceRequest = await this.deviceRequestRepository.findOneById(id);
    const requestBy = await this.userService.getDetailUser(
      deviceRequest.createdBy,
    );
    // báo cho quản lý nhà máy của phiếu y/c
    const factoryManagers = await this.userService.getListFactoryManager(
      deviceRequest.factoryId,
    );
    const userIds = map([...(factoryManagers ?? []), requestBy], 'id');
    notificationRequest.userIds = userIds;
    notificationRequest.createdBy = event.fromUserId;
    return [await super.sendWebNotification(notificationRequest)];
  }
}
