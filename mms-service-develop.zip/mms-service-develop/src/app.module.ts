import { AccreditationTemplateModule } from '@components/accreditation-template/accreditation-template.module';
import { AreaModule } from '@components/area/area.module';
import { ArticleDeviceGroupModule } from '@components/article-device-group/article-device-group.module';
import { AttributeTypeModule } from '@components/attribute-type/attribute-type.module';
import { AuthModule } from '@components/auth/auth.module';
import { CheckListTemplateModule } from '@components/checklist-template/checklist-template.module';
import { DashboardModule } from '@components/dashboard/dashboard.module';
import { DeviceAssignmentModule } from '@components/device-assignment/device-assignment.module';
import { DeviceGroupModule } from '@components/device-group/device-group.module';
import { DeviceNameModule } from '@components/device-name/device-name.module';
import { DeviceRequestModule } from '@components/device-request/device-request.module';
import { DeviceStatusModule } from '@components/device-status/device-status.module';
import { DeviceTypeModule } from '@components/device-type/device-type.module';
import { DeviceModule } from '@components/device/device.module';
import { ErrorTypeModule } from '@components/error-type/error-type.module';
import { ExportModule } from '@components/export/export.module';
import { FileModule } from '@components/file/file.module';
import { HistoryModule } from '@components/history/history.module';
import { ImportExcelModule } from '@components/import-excel/import-excel.module';
import { InstallationTemplateModule } from '@components/installation-template/installation-template.module';
import { JobModule } from '@components/job/job.module';
import { MaintenanceAttributeModule } from '@components/maintenance-attribute/maintenance-attribute.module';
import { MaintenanceIndexModule } from '@components/maintenance-index/maintenance-index.module';
import { MaintenancePlanModule } from '@components/maintenance-plan/maintenance-plan.module';
import { MaintenanceTeamModule } from '@components/maintenance-team/maintenance-team.module';
import { MaintenanceTemplateModule } from '@components/maintenance-template/maintenance-template.module';
import { OperationIndexModule } from '@components/operation-index/operation-index.module';
import { OperationValueModule } from '@components/operation-value/operation-value.module';
import { RepairRequestModule } from '@components/repair-request/repair-request.module';
import { ReportModule } from '@components/report/report.module';
import { SettingModule } from '@components/setting/setting.module';
import { SparePartPlanModule } from '@components/spare-part-plan/spare-part-plan.module';
import { SupplyGroupModule } from '@components/supply-group/supply-group.module';
import { SupplyRequestModule } from '@components/supply-request/supply-request.module';
import { SupplyTypeModule } from '@components/supply-type/supply-type.module';
import { SupplyModule } from '@components/supply/supply.module';
// import { SyncDataModule } from '@components/sync-data/sync-data.module';
import { TransferRequestModule } from '@components/transfer-request/transfer-request.module';
import { TransferTicketModule } from '@components/transfer-ticket/transfer-ticket.module';
import { UpdateInventoryTicketModule } from '@components/update-warehouse-inventory-ticket/update-inventory-ticket.module';
import { UserModule } from '@components/user/user.module';
import { VendorModule } from '@components/vendor/vendor.module';
import { WarehouseExportRequestModule } from '@components/warehouse-export-request/warehouse-export-request.module';
import { WarehouseExportModule } from '@components/warehouse-export/warehouse-export.module';
import { WarehouseImportRequestModule } from '@components/warehouse-import-request/warehouse-import-request.module';
import { WarehouseImportModule } from '@components/warehouse-import/warehouse-import.module';
import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { WarningModule } from '@components/warning/warning.module';
import DatabaseConfigService from '@config/database.config';
import { HttpClientModule } from '@core/components/http-client/http-client.module';
import { KongGatewayModule } from '@core/components/kong-gateway/kong-gateway.module';
import { CoreModule } from '@core/core.module';
import { AuthorizationGuard } from '@core/guards/authorization.guard';
import { NatsClientModule } from '@core/transporter/nats-transporter/nats-client.module';
import { ValidationPipe } from '@core/pipe/validator.pipe';
import { BootModule } from '@nestcloud/boot';
import { BOOT, CONSUL } from '@nestcloud/common';
import { ConsulModule } from '@nestcloud/consul';
import { ServiceModule } from '@nestcloud/service';
import { BullModule } from '@nestjs/bull';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { APP_GUARD, APP_PIPE } from '@nestjs/core';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { MongooseModule } from '@nestjs/mongoose';
import { ScheduleModule } from '@nestjs/schedule';
import { I18nJsonLoader, I18nModule } from 'nestjs-i18n';
import * as path from 'path';
import { resolve } from 'path';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { CronModule } from './components/cron/cron.module';
import { QueryResolver } from './i18n/query-resolver';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    I18nModule.forRoot({
      fallbackLanguage: 'vi',
      loader: I18nJsonLoader,
      loaderOptions: {
        path: path.join(__dirname, '/i18n/'),
        watch: true,
      },
      resolvers: [{ use: QueryResolver, options: ['lang', 'locale', 'l'] }],
    }),
    MongooseModule.forRootAsync({
      useClass: DatabaseConfigService,
    }),
    ScheduleModule.forRoot(),
    BootModule.forRoot({
      filePath: resolve(__dirname, '../config.yaml'),
    }),
    BullModule.forRoot({
      defaultJobOptions: {
        attempts: Number(process.env.QUEUE_ATTEMP) || 5,
        backoff: Number(process.env.QUEUE_BACKOFF) || 5000,
        removeOnComplete: true,
        delay: 5000,
      },
      redis: {
        host: process.env.REDIS_HOST || 'redis',
        port: Number(process.env.REDIS_PORT) || 6379,
        // password: process.env.REDIS_PASSWORD || '',
      },
    }),
    EventEmitterModule.forRoot(),
    ConsulModule.forRootAsync({ inject: [BOOT] }),
    ServiceModule.forRootAsync({ inject: [BOOT, CONSUL] }),
    HttpClientModule,
    KongGatewayModule.forRootAsync(),
    JobModule,
    DeviceAssignmentModule,
    UserModule,
    MaintenanceTeamModule,
    DeviceGroupModule,
    MaintenanceAttributeModule,
    SupplyGroupModule,
    SupplyModule,
    AuthModule,
    DeviceModule,
    CheckListTemplateModule,
    DeviceRequestModule,
    CronModule,
    AttributeTypeModule,
    InstallationTemplateModule,
    SupplyRequestModule,
    DeviceStatusModule,
    CoreModule,
    ExportModule,
    ImportExcelModule,
    WarningModule,
    AreaModule,
    ErrorTypeModule,
    WarehouseModule,
    VendorModule,
    AccreditationTemplateModule,
    DeviceTypeModule,
    ArticleDeviceGroupModule,
    RepairRequestModule,
    TransferRequestModule,
    MaintenanceTemplateModule,
    TransferTicketModule,
    // SyncDataModule,
    MaintenanceIndexModule,
    SparePartPlanModule,
    UpdateInventoryTicketModule,
    DashboardModule,
    ReportModule,
    MaintenancePlanModule,
    FileModule,
    HistoryModule,
    SettingModule,
    DeviceNameModule,
    SupplyTypeModule,
    OperationIndexModule,
    OperationValueModule,
    WarehouseExportModule,
    WarehouseExportRequestModule,
    WarehouseImportRequestModule,
    WarehouseImportModule,
    NatsClientModule,
  ],
  controllers: [AppController],
  providers: [
    {
      provide: APP_PIPE,
      useClass: ValidationPipe,
    },
    {
      provide: APP_GUARD,
      useClass: AuthorizationGuard,
    },
    AppService,
  ],
})
export class AppModule {}
