import { CreateCauseRequestDto } from '@components/cause/dto/request/create-cause.request.dto';
import { GetListCauseRequestDto } from '@components/cause/dto/request/get-list-cause.request.dto';
import { UpdateCauseBodyDto } from '@components/cause/dto/request/update-cause.request.dto';
import { CauseRepositoryInterface } from '@components/cause/interface/cause.repository.interface';
import { SortOrder } from '@constant/database.constant';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { getRegexByValue } from '@utils/common';
import { isEmpty } from 'lodash';
import * as moment from 'moment';
import { Model, Types } from 'mongoose';
import { CauseCollection } from 'src/models/cause/cause.schema';

@Injectable()
export class CauseRepository
  extends BaseAbstractRepository<CauseCollection>
  implements CauseRepositoryInterface
{
  constructor(
    @InjectModel(CauseCollection.name)
    private readonly causeCollection: Model<CauseCollection>,
  ) {
    super(causeCollection);
  }

  createModel(request: CreateCauseRequestDto): CauseCollection {
    const { code, name, description, isActive, userId } = request;
    const causeCollection = new this.causeCollection();
    causeCollection.code = code;
    causeCollection.name = name;
    causeCollection.description = description;
    causeCollection.isActive = isActive;
    causeCollection.createdBy = userId;
    return causeCollection;
  }

  updateModel(
    cause: CauseCollection,
    request: UpdateCauseBodyDto,
  ): CauseCollection {
    const { name, description, isActive, userId } = request;
    cause.name = name;
    cause.description = description;
    cause.isActive = isActive;
    cause.updatedBy = userId;
    return cause;
  }

  async getList(
    request: GetListCauseRequestDto,
  ): Promise<{ data: (CauseCollection & { _id: any })[]; count: number }> {
    const { keyword, sort, filter, take, skip, queryIds } = request;

    let filterObj = {};
    let sortObj = {};

    if (!isEmpty(queryIds)) {
      filterObj = {
        ...filterObj,
        _id: {
          $in: queryIds.map((id) => new Types.ObjectId(id)),
        },
      };
    }

    if (!isEmpty(keyword)) {
      filterObj = {
        $or: [
          { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          { name: { $regex: '.*' + keyword + '.*', $options: 'i' } },
        ],
      };
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: {
                $regex: '.*' + value + '.*',
                $options: 'i',
              },
            };
            break;
          case 'name':
            filterObj = {
              ...filterObj,
              name: getRegexByValue(value),
            };
            break;
          case 'description':
            filterObj = {
              ...filterObj,
              description: getRegexByValue(value),
            };
            break;
          case 'isActive':
            filterObj = {
              ...filterObj,
              isActive: parseInt(value),
            };
            break;
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'createdBy':
            filterObj = {
              ...filterObj,
              createdBy: parseInt(value),
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order;
        switch (item.column) {
          case 'code':
            sortObj = { code: order };
            break;
          case 'name':
            sortObj = { name: order };
            break;
          case 'createdAt':
            sortObj = { createdAt: order };
            break;
          case 'updatedAt':
            sortObj = { updatedAt: order };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = { isActive: 1, createdAt: -1 };
    }

    const result = await this.causeCollection
      .aggregate()
      .match(filterObj)
      .sort(sortObj)
      .limit(take)
      .skip(skip)
      .exec();
    const total: number = await this.causeCollection
      .find({ deletedAt: null })
      .find(filterObj)
      .countDocuments()
      .exec();
    return { data: result, count: total };
  }

  async getLastCause(): Promise<any> {
    return await this.causeCollection
      .findOne()
      .sort({ createdAt: SortOrder.Descending })
      .exec();
  }
}
