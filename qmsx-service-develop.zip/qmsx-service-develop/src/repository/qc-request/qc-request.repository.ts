import { GetQCRequestReportRequestDto } from '@components/qc-report/dto/request/get-qc-request-report.request.dto';
import { CreateQCRequestRequestDto } from '@components/qc-request/dto/request/create-qc-request.request.dto';
import { GetListQCRequestRequestDto } from '@components/qc-request/dto/request/get-list-qc-request.request.dto';
import { UpdateQCRequestBodyDto } from '@components/qc-request/dto/request/update-qc-request.request.dto';
import { QCRequestRepositoryInterface } from '@components/qc-request/interface/qc-request.repository.interface';
import { QC_REQUEST_STATUS } from '@components/qc-request/qc-request.constant';
import { SortOrder } from '@constant/database.constant';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { getRegexByValue } from '@utils/common';
import { isEmpty } from 'lodash';
import * as moment from 'moment';
import { Model, Types } from 'mongoose';
import { QCRequest } from 'src/models/qc-request/qc-request.schema';

export class QCRequestRepository
  extends BaseAbstractRepository<QCRequest>
  implements QCRequestRepositoryInterface
{
  constructor(
    @InjectModel(QCRequest.name)
    private readonly qcRequestModel: Model<QCRequest>,
  ) {
    super(qcRequestModel);
  }

  createModel(request: CreateQCRequestRequestDto): QCRequest {
    const {
      code,
      name,
      requestSource,
      requestType,
      requestBy,
      returnDate,
      ticket,
      proposeProcess,
      workOrder,
      description,
      items,
      status,
      userId,
    } = request;
    const qcRequestModel = new this.qcRequestModel();
    qcRequestModel.code = code;
    qcRequestModel.name = name;
    qcRequestModel.requestSource = requestSource;
    qcRequestModel.requestType = requestType;
    qcRequestModel.requestBy = requestBy;
    qcRequestModel.returnDate = returnDate;
    qcRequestModel.ticket = ticket;
    qcRequestModel.proposeProcess = proposeProcess;
    qcRequestModel.workOrder = workOrder;
    qcRequestModel.description = description;
    qcRequestModel.items = items;
    qcRequestModel.status = status;
    qcRequestModel.createdBy = userId;
    return qcRequestModel;
  }

  updateModel(
    qcRequest: QCRequest,
    request: UpdateQCRequestBodyDto,
  ): QCRequest {
    const {
      name,
      requestSource,
      requestType,
      requestBy,
      returnDate,
      ticket,
      proposeProcess,
      workOrder,
      description,
      items,
      status,
      userId,
    } = request;
    qcRequest.name = name;
    qcRequest.requestSource = requestSource;
    qcRequest.requestType = requestType;
    qcRequest.requestBy = requestBy;
    qcRequest.returnDate = returnDate;
    qcRequest.ticket = ticket;
    qcRequest.proposeProcess = proposeProcess;
    qcRequest.workOrder = workOrder;
    qcRequest.description = description;
    qcRequest.items = items;
    qcRequest.status = status;
    qcRequest.updatedBy = userId;
    return qcRequest;
  }

  async getQCRequestReport(
    request: GetQCRequestReportRequestDto,
  ): Promise<any> {
    const { take, skip } = request;
    const filterObj: any = {
      status: { $ne: QC_REQUEST_STATUS.DRAFT },
    };
    const sortObj = { createdAt: SortOrder.Descending };

    const aggregate = this.qcRequestModel.aggregate([
      {
        $match: filterObj,
      },
      {
        $addFields: {
          waiting: {
            $cond: [
              {
                $eq: ['$status', QC_REQUEST_STATUS.WAITING],
              },
              1,
              0,
            ],
          },
          confirmed: {
            $cond: [
              {
                $eq: ['$status', QC_REQUEST_STATUS.CONFIRMED],
              },
              1,
              0,
            ],
          },
          rejected: {
            $cond: [
              {
                $eq: ['$status', QC_REQUEST_STATUS.REJECTED],
              },
              1,
              0,
            ],
          },
          inProgress: {
            $cond: [
              {
                $eq: ['$status', QC_REQUEST_STATUS.IN_PROGRESS],
              },
              1,
              0,
            ],
          },
          completed: {
            $cond: [
              {
                $eq: ['$status', QC_REQUEST_STATUS.COMPLETED],
              },
              1,
              0,
            ],
          },
        },
      },
      {
        $group: {
          _id: '$requestSource',
          waiting: {
            $sum: '$waiting',
          },
          confirmed: {
            $sum: '$confirmed',
          },
          rejected: {
            $sum: '$rejected',
          },
          inProgress: {
            $sum: '$inProgress',
          },
          completed: {
            $sum: '$completed',
          },
          total: {
            $sum: 1,
          },
        },
      },
    ]);

    const result = await aggregate.sort(sortObj).skip(skip).limit(take).exec();

    const count = await aggregate.count('count').exec();

    return {
      data: result,
      count: count[0]?.['count'] || 0,
    };
  }

  async getList(request: GetListQCRequestRequestDto): Promise<any> {
    const { keyword, sort, filter, take, skip, queryIds } = request;
    let filterObj = {};
    let sortObj = {};

    if (!isEmpty(queryIds)) {
      filterObj = {
        ...filterObj,
        _id: {
          $in: queryIds.map((id) => new Types.ObjectId(id)),
        },
      };
    }

    if (!isEmpty(keyword)) {
      filterObj = {
        $or: [
          { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          { name: getRegexByValue(keyword) },
        ],
      };
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: {
                $regex: `.*${value}.*`,
                $options: 'i',
              },
            };
            break;
          case 'name':
            filterObj = {
              ...filterObj,
              name: getRegexByValue(value),
            };
            break;
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'returnDate':
            filterObj = {
              ...filterObj,
              returnDate: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'createdBy':
            filterObj = {
              ...filterObj,
              createdBy: {
                $in: value.split(',').map((i) => parseInt(i)),
              },
            };
            break;
          case 'requestBy':
            filterObj = {
              ...filterObj,
              requestBy: parseInt(value),
            };
            break;
          case 'requestSource':
            filterObj = {
              ...filterObj,
              requestSource: parseInt(value),
            };
            break;
          case 'requestType':
            filterObj = {
              ...filterObj,
              requestType: getRegexByValue(value),
            };
            break;
          case 'ticket':
            filterObj = {
              ...filterObj,
              ticket: getRegexByValue(value),
            };
            break;
          case 'status':
            filterObj = {
              ...filterObj,
              status: {
                $in: value.split(',').map((i) => parseInt(i)),
              },
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order;
        switch (item.column) {
          case 'code':
            sortObj = { code: order };
            break;
          case 'name':
            sortObj = { name: order };
            break;
          case 'returnDate':
            sortObj = { returnDate: order };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = {
        sortStatus: SortOrder.Ascending,
        createdAt: SortOrder.Descending,
      };
    }

    const result: any = await this.qcRequestModel
      .aggregate()
      .addFields({
        sortStatus: {
          $indexOfArray: [
            [
              QC_REQUEST_STATUS.DRAFT,
              QC_REQUEST_STATUS.WAITING,
              QC_REQUEST_STATUS.CONFIRMED,
              QC_REQUEST_STATUS.IN_PROGRESS,
              QC_REQUEST_STATUS.COMPLETED,
              QC_REQUEST_STATUS.REJECTED,
            ],
            '$status',
          ],
        },
      })
      .match(filterObj)
      .sort(sortObj)
      .skip(skip)
      .limit(take)
      .exec();

    const count = await this.qcRequestModel
      .find({
        ...filterObj,
      })
      .countDocuments()
      .exec();

    return {
      data: result,
      count,
    };
  }

  async getLastQCRequest(prefixWithYear: string): Promise<any> {
    return await this.qcRequestModel
      .findOne({
        code: {
          $regex: `${prefixWithYear}.*`,
          $options: 'i',
        },
      })
      .sort({ createdAt: SortOrder.Descending })
      .exec();
  }
}
