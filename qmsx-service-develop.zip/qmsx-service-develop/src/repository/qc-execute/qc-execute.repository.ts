import { GetListQCExecuteRequestDto } from '@components/qc-execute/dto/request/get-list-qc-execute.request.dto';
import { QCExecuteRepositoryInterface } from '@components/qc-execute/interface/qc-execute.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { getRegexByValue } from '@utils/common';
import { isEmpty } from 'lodash';
import * as moment from 'moment';
import { Model, Types } from 'mongoose';
import { QCExecute } from 'src/models/qc-execute/qc-execute.schema';

export class QCExecuteRepository
  extends BaseAbstractRepository<QCExecute>
  implements QCExecuteRepositoryInterface
{
  constructor(
    @InjectModel(QCExecute.name)
    private readonly qcExecuteModel: Model<QCExecute>,
  ) {
    super(qcExecuteModel);
  }

  async getListByQCCommandCode(qcCommandCode: string): Promise<any> {
    const filterObj = {
      qcCommandCode,
    };
    const sortObj = { createdAt: -1 };
    const result: any = await this.qcExecuteModel
      .aggregate([
        {
          $lookup: {
            from: 'qcExecuteResults',
            localField: '_id',
            foreignField: 'qcExecuteId',
            as: 'qcExecuteResults',
          },
        },
      ])
      .match(filterObj)
      .sort(sortObj)
      .exec();

    return result;
  }

  async getList(request: GetListQCExecuteRequestDto): Promise<any> {
    const { keyword, sort, filter, take, skip, queryIds } = request;
    let filterObj = {};
    let sortObj = {};

    if (!isEmpty(queryIds)) {
      filterObj = {
        ...filterObj,
        _id: {
          $in: queryIds.map((id) => new Types.ObjectId(id)),
        },
      };
    }

    if (!isEmpty(keyword)) {
      filterObj = {
        $or: [
          { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          { name: getRegexByValue(keyword) },
        ],
      };
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'itemCode':
            filterObj = {
              ...filterObj,
              itemCode: {
                $in: value.split(','),
              },
            };
            break;
          case 'itemName':
            filterObj = {
              ...filterObj,
              itemName: getRegexByValue(value),
            };
            break;
          case 'lot':
            filterObj = {
              ...filterObj,
              lot: getRegexByValue(value),
            };
            break;
          case 'rangeDate':
            filterObj = {
              ...filterObj,
              startDate: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'createdBy':
            filterObj = {
              ...filterObj,
              createdBy: parseInt(value),
            };
            break;
          case 'qcCommandCode':
            filterObj = {
              ...filterObj,
              qcCommandCode: getRegexByValue(value),
            };
            break;
          case 'qcBy':
            filterObj = {
              ...filterObj,
              qcBy: {
                $in: value.split(','),
              },
            };
            break;
          case 'status':
            filterObj = {
              ...filterObj,
              status: parseInt(value),
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order;
        switch (item.column) {
          case 'code':
            sortObj = { code: order };
            break;
          case 'name':
            sortObj = { name: order };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = { createdAt: -1, active: -1 };
    }

    const result: any = await this.qcExecuteModel
      .aggregate()
      .match(filterObj)
      .sort(sortObj)
      .skip(skip)
      .limit(take)
      .exec();
    const count = await this.qcExecuteModel
      .find({
        ...filterObj,
      })
      .countDocuments()
      .exec();

    return {
      data: result,
      count,
    };
  }
}
