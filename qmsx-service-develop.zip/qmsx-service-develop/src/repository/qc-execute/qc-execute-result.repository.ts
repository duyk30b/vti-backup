import { CreateQCExecuteResultRequestDto } from '@components/qc-execute/dto/request/create-qc-execute-result.request.dto';
import { GetListQCExecuteResultRequestDto } from '@components/qc-execute/dto/request/get-list-qc-result.request.dto';
import { GetQCReportByCauseRequestDto } from '@components/qc-execute/dto/request/get-qc-report-by-cause.request.dto';
import { QCExecuteResultRepositoryInterface } from '@components/qc-execute/interface/qc-execute-result.repository.interface';
import { QC_TYPE } from '@components/qc-execute/qc-execute.constant';
import { GetQCCommandReportByCauseRequestDto } from '@components/qc-report/dto/request/get-qc-command-report-by-cause.request.dto';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { getRegexByValue } from '@utils/common';
import { isEmpty } from 'lodash';
import * as moment from 'moment';
import { Model, Types } from 'mongoose';
import { QCExecuteResult } from 'src/models/qc-execute/qc-execute-result.schema';

export class QCExecuteResultRepository
  extends BaseAbstractRepository<QCExecuteResult>
  implements QCExecuteResultRepositoryInterface
{
  constructor(
    @InjectModel(QCExecuteResult.name)
    private readonly qcQcExecuteResultModel: Model<QCExecuteResult>,
  ) {
    super(qcQcExecuteResultModel);
  }

  createModel(
    request: CreateQCExecuteResultRequestDto,
    code: string,
  ): QCExecuteResult {
    const {
      quantity,
      failQuantity,
      qcEndDate,
      qcStartDate,
      duration,
      index,
      qcExecuteId,
      qcExecuteProgressId,
      resultInfo,
      userId,
    } = request;
    const qcExecuteResultModel = new this.qcQcExecuteResultModel();
    qcExecuteResultModel.index = index;
    qcExecuteResultModel.name = '';
    qcExecuteResultModel.description = '';
    qcExecuteResultModel.code = code;
    qcExecuteResultModel.quantity = quantity;
    qcExecuteResultModel.failQuantity = failQuantity;
    qcExecuteResultModel.duration = duration;
    qcExecuteResultModel.qcEndDate = qcEndDate;
    qcExecuteResultModel.qcStartDate = qcStartDate;
    qcExecuteResultModel.status = 0;
    qcExecuteResultModel.qcExecuteId = qcExecuteId;
    qcExecuteResultModel.qcExecuteProgressId = qcExecuteProgressId;
    qcExecuteResultModel.resultInfo = resultInfo;
    qcExecuteResultModel.createdBy = userId;

    return qcExecuteResultModel;
  }

  async getQCCommandReportByCause(
    request: GetQCCommandReportByCauseRequestDto,
  ): Promise<any> {
    const { causeId, itemCode, sort, filter, take, skip } = request;
    let filterObj: any = {
      causeId: new Types.ObjectId(causeId),
      itemCode: itemCode,
    };
    let sortObj = {};

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: {
                $regex: '.*' + value + '.*',
                $options: 'i',
              },
            };
            break;
          case 'name':
            filterObj = {
              ...filterObj,
              name: getRegexByValue(value),
            };
            break;
          case 'status':
            filterObj = {
              ...filterObj,
              status: parseInt(value),
            };
            break;
          case 'createdBy':
            filterObj = {
              ...filterObj,
              createdBy: parseInt(value),
            };
            break;
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order;
        switch (item.column) {
          case 'code':
            sortObj = { code: order };
            break;
          case 'name':
            sortObj = { name: order };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = { status: -1, createdAt: -1 };
    }

    const aggregate = this.qcQcExecuteResultModel
      .aggregate([
        {
          $addFields: {
            causeId: {
              $reduce: {
                input: '$resultInfo.causeCodes',
                initialValue: [],
                in: {
                  $concatArrays: ['$$value', '$$this'],
                },
              },
            },
          },
        },
        {
          $unwind: {
            path: '$causeId',
          },
        },
        {
          $lookup: {
            from: 'qcExecutes',
            localField: 'qcExecuteId',
            foreignField: '_id',
            as: 'qcExecute',
          },
        },
        {
          $unwind: {
            path: '$qcExecute',
          },
        },
        {
          $lookup: {
            from: 'qcCommands',
            localField: 'qcExecute.qcCommandCode',
            foreignField: 'code',
            as: 'qcCommand',
          },
        },
        {
          $unwind: {
            path: '$qcCommand',
          },
        },
        {
          $project: {
            _id: '$qcCommand._id',
            code: '$qcCommand.code',
            name: '$qcCommand.name',
            createdAt: '$qcCommand.createdAt',
            createdBy: '$qcCommand.createdBy',
            causeId: '$causeId',
            itemCode: '$qcExecute.itemCode',
            lot: '$qcExecute.lot',
            status: '$qcExecute.status',
          },
        },
      ])
      .match(filterObj);

    const result = await aggregate.sort(sortObj).skip(skip).limit(take).exec();

    const count = await aggregate.count('count').exec();

    return {
      data: result,
      count: count[0]?.['count'] || 0,
    };
  }

  async getQCReportByCause(
    request: GetQCReportByCauseRequestDto,
  ): Promise<any> {
    const { take, skip } = request;
    const sortObj = { createdAt: -1 };
    const aggregate = this.qcQcExecuteResultModel.aggregate([
      {
        $addFields: {
          causeId: {
            $reduce: {
              input: '$resultInfo.causeCodes',
              initialValue: [],
              in: {
                $concatArrays: ['$$value', '$$this'],
              },
            },
          },
        },
      },
      {
        $unwind: {
          path: '$causeId',
        },
      },
      {
        $lookup: {
          from: 'qcExecutes',
          localField: 'qcExecuteId',
          foreignField: '_id',
          as: 'qcExecute',
        },
      },
      {
        $unwind: {
          path: '$qcExecute',
        },
      },
      {
        $group: {
          _id: {
            itemCode: '$qcExecute.itemCode',
            causeId: '$causeId',
          },
          count: {
            $sum: 1,
          },
        },
      },
      {
        $replaceRoot: {
          newRoot: {
            $mergeObjects: [
              '$_id',
              {
                count: '$count',
              },
            ],
          },
        },
      },
      {
        $lookup: {
          from: 'causes',
          localField: 'causeId',
          foreignField: '_id',
          as: 'cause',
        },
      },
      {
        $unwind: {
          path: '$cause',
        },
      },
    ]);

    const result = await aggregate.sort(sortObj).skip(skip).limit(take).exec();

    const count = await aggregate.count('count').exec();

    return {
      data: result,
      count: count[0]?.['count'] || 0,
    };
  }

  async getList(request: GetListQCExecuteResultRequestDto): Promise<any> {
    const {
      keyword,
      sort,
      filter,
      take,
      skip,
      queryIds,
      type,
      idQcExecute,
      idQcProgress,
    } = request;
    let filterObj = {};

    switch (Number(type)) {
      case QC_TYPE.EXECUTE:
        filterObj = {
          qcExecuteId: idQcExecute,
        };
        break;
      case QC_TYPE.PROGRESS:
        filterObj = {
          qcExecuteProgressId: idQcProgress,
        };
        break;
      default:
        break;
    }

    let sortObj = {};

    if (!isEmpty(queryIds)) {
      filterObj = {
        ...filterObj,
        _id: {
          $in: queryIds.map((id) => new Types.ObjectId(id)),
        },
      };
    }

    if (!isEmpty(keyword)) {
      filterObj = {
        $or: [
          { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          { name: getRegexByValue(keyword) },
        ],
      };
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: {
                $regex: '.*' + value + '.*',
                $options: 'i',
              },
            };
            break;
          case 'name':
            filterObj = {
              ...filterObj,
              name: getRegexByValue(value),
            };
            break;
          case 'description':
            filterObj = {
              ...filterObj,
              description: getRegexByValue(value),
            };
            break;
          case 'status':
            filterObj = {
              ...filterObj,
              status: parseInt(value),
            };
            break;
          case 'createdBy':
            filterObj = {
              ...filterObj,
              createdBy: parseInt(value),
            };
            break;
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order;
        switch (item.column) {
          case 'code':
            sortObj = { code: order };
            break;
          case 'name':
            sortObj = { name: order };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = { status: -1, createdAt: -1 };
    }

    const result: any = await this.qcQcExecuteResultModel
      .aggregate()
      .match(filterObj)
      .sort(sortObj)
      .skip(skip)
      .limit(take)
      .exec();

    const count = await this.qcQcExecuteResultModel
      .find({
        ...filterObj,
      })
      .countDocuments()
      .exec();

    return {
      data: result,
      count,
    };
  }

  async getLastItem() {
    return await this.qcQcExecuteResultModel
      .aggregate()
      .sort({ code: -1 })
      .limit(10)
      .exec();
  }

  async getTotalResult(qcExecuteId: string) {
    return await this.qcQcExecuteResultModel
      .aggregate([
        { $match: { qcExecuteId: qcExecuteId, status: 1 } },
        {
          $group: {
            _id: {
              index: '$index',
              qcExecuteProgressId: '$qcExecuteProgressId',
            },
          },
        },
      ])
      .exec();
  }
}
