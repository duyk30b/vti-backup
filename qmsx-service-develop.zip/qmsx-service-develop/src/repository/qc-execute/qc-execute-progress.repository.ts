import { QCExecuteProgressRepositoryInterface } from '@components/qc-execute/interface/qc-execute-progress.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { QCExecuteProgress } from 'src/models/qc-execute/qc-execute-progress.schema';

export class QCExecuteProgressRepository
  extends BaseAbstractRepository<QCExecuteProgress>
  implements QCExecuteProgressRepositoryInterface
{
  constructor(
    @InjectModel(QCExecuteProgress.name)
    private readonly qcQcExecuteProgressModel: Model<QCExecuteProgress>,
  ) {
    super(qcQcExecuteProgressModel);
  }
}
