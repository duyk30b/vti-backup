import { CreateErrorRequestDto } from '@components/error/dto/request/create-error.request.dto';
import { GetListErrorRequestDto } from '@components/error/dto/request/get-list-error.request.dto';
import { UpdateErrorBodyDto } from '@components/error/dto/request/update-error.request.dto';
import { ErrorRepositoryInterface } from '@components/error/interface/error.repository.interface';
import { SortOrder } from '@constant/database.constant';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { getRegexByValue } from '@utils/common';
import { isEmpty } from 'lodash';
import * as moment from 'moment';
import { Model, Types } from 'mongoose';
import { Error } from 'src/models/error/error.schema';

export class ErrorRepository
  extends BaseAbstractRepository<Error>
  implements ErrorRepositoryInterface
{
  constructor(
    @InjectModel(Error.name)
    private readonly errorModel: Model<Error>,
  ) {
    super(errorModel);
  }

  createModel(request: CreateErrorRequestDto): Error {
    const { code, name, description, causeCodes, active, userId } = request;
    const errorModel = new this.errorModel();
    errorModel.code = code;
    errorModel.name = name;
    errorModel.description = description;
    errorModel.causeCodes = causeCodes;
    errorModel.active = active;
    errorModel.createdBy = userId;
    return errorModel;
  }

  updateModel(error: Error, request: UpdateErrorBodyDto): Error {
    const { name, description, causeCodes, active, userId } = request;
    error.name = name;
    error.description = description;
    error.causeCodes = causeCodes;
    error.active = active;
    error.updatedBy = userId;
    return error;
  }

  async getList(request: GetListErrorRequestDto): Promise<any> {
    const { keyword, sort, filter, take, skip, queryIds } = request;
    let filterObj = {};
    let sortObj = {};

    if (!isEmpty(queryIds)) {
      filterObj = {
        ...filterObj,
        _id: {
          $in: queryIds.map((id) => new Types.ObjectId(id)),
        },
      };
    }

    if (!isEmpty(keyword)) {
      filterObj = {
        $or: [
          { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          { name: getRegexByValue(keyword) },
        ],
      };
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: {
                $regex: `.*${value}.*`,
                $options: 'i',
              },
            };
            break;
          case 'name':
            filterObj = {
              ...filterObj,
              name: getRegexByValue(value),
            };
            break;
          case 'description':
            filterObj = {
              ...filterObj,
              description: getRegexByValue(value),
            };
            break;
          case 'active':
            filterObj = {
              ...filterObj,
              active: parseInt(value),
            };
            break;
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'createdBy':
            filterObj = {
              ...filterObj,
              createdBy: parseInt(value),
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order;
        switch (item.column) {
          case 'code':
            sortObj = { code: order };
            break;
          case 'name':
            sortObj = { name: order };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = { active: -1, createdAt: -1 };
    }

    const result: any = await this.errorModel
      .aggregate()
      .match(filterObj)
      .sort(sortObj)
      .skip(skip)
      .limit(take)
      .exec();

    const count = await this.errorModel
      .find({
        ...filterObj,
      })
      .countDocuments()
      .exec();

    return {
      data: result,
      count,
    };
  }

  async getLastError(): Promise<any> {
    return await this.errorModel
      .findOne()
      .sort({ createdAt: SortOrder.Descending })
      .exec();
  }
}
