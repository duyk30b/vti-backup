import { SettingRepositoryInterface } from '@components/setting/interface/setting.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { QCSetting } from 'src/models/setting/setting.schema';

export class SettingRepository
  extends BaseAbstractRepository<QCSetting>
  implements SettingRepositoryInterface
{
  constructor(
    @InjectModel(QCSetting.name)
    private readonly settingModel: Model<QCSetting>,
  ) {
    super(settingModel);
  }
}
