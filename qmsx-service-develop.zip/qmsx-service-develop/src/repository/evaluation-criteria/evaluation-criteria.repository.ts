import { CreateEvaluationCriteriaRequestDto } from '@components/evaluation-criteria/dto/request/evaluation-criteria.request.dto';
import { GetListEvaluationCriteriaRequestDto } from '@components/evaluation-criteria/dto/request/get-list-evaluation-criteria.request.dto';
import { UpdateEvaluationCriteriaBodyDto } from '@components/evaluation-criteria/dto/request/update-evaluation-criteria.request.dto';
import { EvaluationCriteriaRepositoryInterface } from '@components/evaluation-criteria/interface/evaluation-criteria.repository.interface';
import { SortOrder } from '@constant/database.constant';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { getRegexByValue } from '@utils/common';
import { isEmpty } from 'lodash';
import * as moment from 'moment';
import { Model, Types } from 'mongoose';
import { EvaluationCriteria } from 'src/models/evaluation-criteria/evaluation-criteria.schema';

export class EvaluationCriteriaRepository
  extends BaseAbstractRepository<EvaluationCriteria>
  implements EvaluationCriteriaRepositoryInterface
{
  constructor(
    @InjectModel(EvaluationCriteria.name)
    private readonly evaluationCriteriaModel: Model<EvaluationCriteria>,
  ) {
    super(evaluationCriteriaModel);
  }

  createModel(request: CreateEvaluationCriteriaRequestDto): EvaluationCriteria {
    const {
      code,
      name,
      checkType,
      upperBound,
      norm,
      lowerBound,
      description,
      details,
      active,
      userId,
    } = request;
    const evaluationCriteriaModel = new this.evaluationCriteriaModel();
    evaluationCriteriaModel.code = code;
    evaluationCriteriaModel.name = name;
    evaluationCriteriaModel.checkType = checkType;
    evaluationCriteriaModel.upperBound = upperBound;
    evaluationCriteriaModel.norm = norm;
    evaluationCriteriaModel.lowerBound = lowerBound;
    evaluationCriteriaModel.description = description;
    evaluationCriteriaModel.details = details;
    evaluationCriteriaModel.active = active;
    evaluationCriteriaModel.createdBy = userId;
    return evaluationCriteriaModel;
  }

  updateModel(
    evaluationCriteria: EvaluationCriteria,
    request: UpdateEvaluationCriteriaBodyDto,
  ): EvaluationCriteria {
    const {
      name,
      checkType,
      upperBound,
      norm,
      lowerBound,
      description,
      details,
      active,
      userId,
    } = request;
    evaluationCriteria.name = name;
    evaluationCriteria.checkType = checkType;
    evaluationCriteria.upperBound = upperBound;
    evaluationCriteria.norm = norm;
    evaluationCriteria.lowerBound = lowerBound;
    evaluationCriteria.description = description;
    evaluationCriteria.details = details;
    evaluationCriteria.active = active;
    evaluationCriteria.updatedBy = userId;
    return evaluationCriteria;
  }

  async getList(request: GetListEvaluationCriteriaRequestDto): Promise<any> {
    const { keyword, sort, filter, take, skip, queryIds } = request;
    let filterObj = {};
    let sortObj = {};

    if (!isEmpty(queryIds)) {
      filterObj = {
        ...filterObj,
        _id: {
          $in: queryIds.map((id) => new Types.ObjectId(id)),
        },
      };
    }

    if (!isEmpty(keyword)) {
      filterObj = {
        $or: [
          { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          { name: getRegexByValue(keyword) },
        ],
      };
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: {
                $regex: `.*${value}.*`,
                $options: 'i',
              },
            };
            break;
          case 'name':
            filterObj = {
              ...filterObj,
              name: getRegexByValue(value),
            };
            break;
          case 'active':
            filterObj = {
              ...filterObj,
              active: parseInt(value),
            };
            break;
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'createdBy':
            filterObj = {
              ...filterObj,
              createdBy: parseInt(value),
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order;
        switch (item.column) {
          case 'code':
            sortObj = { code: order };
            break;
          case 'name':
            sortObj = { name: order };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = { active: -1, createdAt: -1 };
    }

    const result: any = await this.evaluationCriteriaModel
      .aggregate()
      .match(filterObj)
      .sort(sortObj)
      .skip(skip)
      .limit(take)
      .exec();

    const count = await this.evaluationCriteriaModel
      .find({
        ...filterObj,
      })
      .countDocuments()
      .exec();

    return {
      data: result,
      count,
    };
  }

  async getLastEvaluationCriteria(): Promise<any> {
    return await this.evaluationCriteriaModel
      .findOne()
      .sort({ createdAt: SortOrder.Descending })
      .exec();
  }
}
