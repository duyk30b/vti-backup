import { CreateEvaluationFormRequestDto } from '@components/evaluation-form/dto/request/create-evaluation-form-template.request.dto';
import { GetListEvaluationFormRequestDto } from '@components/evaluation-form/dto/request/get-list-evaluation-form.request.dto';
import { UpdateEvaluationFormBodyDto } from '@components/evaluation-form/dto/request/update-evaluation-form.request.dto';
import { EvaluationFormRepositoryInterface } from '@components/evaluation-form/interface/evaluation-form.repository.interface';
import { SortOrder } from '@constant/database.constant';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { getRegexByValue } from '@utils/common';
import { isEmpty } from 'lodash';
import * as moment from 'moment';
import { Model, Types } from 'mongoose';
import { EvaluationFormCollection } from 'src/models/evaluation-form/evaluation-form.schema';

@Injectable()
export class EvaluationFormRepository
  extends BaseAbstractRepository<EvaluationFormCollection>
  implements EvaluationFormRepositoryInterface
{
  constructor(
    @InjectModel(EvaluationFormCollection.name)
    private readonly evaluationFormCollection: Model<EvaluationFormCollection>,
  ) {
    super(evaluationFormCollection);
  }

  createModel(
    request: CreateEvaluationFormRequestDto,
  ): EvaluationFormCollection {
    const {
      code,
      name,
      description,
      active,
      userId,
      itemId,
      qcNumber,
      qcQuantity,
      qcFormat,
      evaluations,
    } = request;
    const evaluationFormCollection = new this.evaluationFormCollection();
    evaluationFormCollection.code = code;
    evaluationFormCollection.name = name;
    evaluationFormCollection.description = description;
    evaluationFormCollection.qcNumber = qcNumber;
    evaluationFormCollection.qcQuantity = qcQuantity;
    evaluationFormCollection.qcFormat = qcFormat;
    evaluationFormCollection.itemId = itemId;
    evaluationFormCollection.active = active;
    evaluationFormCollection.createdBy = userId;
    evaluationFormCollection.evaluations = evaluations;
    return evaluationFormCollection;
  }

  updateModel(
    evaluationForm: EvaluationFormCollection,
    request: UpdateEvaluationFormBodyDto,
  ): EvaluationFormCollection {
    const {
      name,
      description,
      active,
      qcFormat,
      userId,
      evaluations,
      qcNumber,
      itemId,
      qcQuantity,
    } = request;
    evaluationForm.name = name;
    evaluationForm.description = description;
    evaluationForm.active = active;
    evaluationForm.updatedBy = userId;
    evaluationForm.qcNumber = qcNumber;
    evaluationForm.itemId = itemId;
    evaluationForm.qcFormat = qcFormat;
    evaluationForm.qcQuantity = qcQuantity;
    evaluationForm.evaluations = evaluations;
    return evaluationForm;
  }

  async getList(request: GetListEvaluationFormRequestDto): Promise<{
    data: (EvaluationFormCollection & { _id: any })[];
    count: number;
  }> {
    const { keyword, sort, filter, take, skip, queryIds } = request;

    let filterObj = {};
    let sortObj = {};

    if (!isEmpty(queryIds)) {
      filterObj = {
        ...filterObj,
        _id: {
          $in: queryIds.map((id) => new Types.ObjectId(id)),
        },
      };
    }

    if (!isEmpty(keyword)) {
      filterObj = {
        $or: [
          { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          { name: { $regex: '.*' + keyword + '.*', $options: 'i' } },
        ],
      };
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: {
                $regex: '.*' + value + '.*',
                $options: 'i',
              },
            };
            break;
          case 'name':
            filterObj = {
              ...filterObj,
              name: getRegexByValue(value),
            };
            break;
          case 'active':
            filterObj = {
              ...filterObj,
              active: parseInt(value),
            };
            break;
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'qcNumber':
            filterObj = {
              ...filterObj,
              qcNumber: parseInt(value),
            };
            break;
          case 'qcQuantity':
            filterObj = {
              ...filterObj,
              qcQuantity: Number(value),
            };
            break;
          case 'qcFormat':
            filterObj = {
              ...filterObj,
              qcFormat: value,
            };
            break;
          case 'createdBy':
            filterObj = {
              ...filterObj,
              createdBy: parseInt(value),
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order;
        switch (item.column) {
          case 'code':
            sortObj = { code: order };
            break;
          case 'name':
            sortObj = { name: order };
            break;
          case 'createdAt':
            sortObj = { createdAt: order };
            break;
          case 'updatedAt':
            sortObj = { updatedAt: order };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = { active: -1, createdAt: -1 };
    }

    const result = await this.evaluationFormCollection
      .aggregate()
      .match(filterObj)
      .sort(sortObj)
      .limit(take)
      .skip(skip)
      .exec();
    const total: number = await this.evaluationFormCollection
      .find({ deletedAt: null })
      .find(filterObj)
      .countDocuments()
      .exec();
    return { data: result, count: total };
  }

  async getLastEvaluationForm(): Promise<any> {
    return await this.evaluationFormCollection
      .findOne()
      .sort({ createdAt: SortOrder.Descending })
      .exec();
  }
}
