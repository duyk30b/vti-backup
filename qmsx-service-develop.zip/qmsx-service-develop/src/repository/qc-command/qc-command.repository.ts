import { CreateQCCommandRequestDto } from '@components/qc-command/dto/request/create-qc-command.request.dto';
import { GetListQCCommandRequestDto } from '@components/qc-command/dto/request/get-list-qc-command.request.dto';
import { UpdateQCCommandBodyDto } from '@components/qc-command/dto/request/update-qc-command.request.dto';
import { QCCommandRepositoryInterface } from '@components/qc-command/interface/qc-command.repository.interface';
import { QC_COMMAND_STATUS } from '@components/qc-command/qc-command.constant';
import { GetQCCommandProgressReportRequestDto } from '@components/qc-report/dto/request/get-qc-command-progress-report.request.dto';
import { GetQCCommandReportBySourceRequestDto } from '@components/qc-report/dto/request/get-qc-command-report-by-source.request.dto';
import { SortOrder } from '@constant/database.constant';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { getRegexByValue } from '@utils/common';
import { isEmpty } from 'lodash';
import * as moment from 'moment';
import { Model, Types } from 'mongoose';
import { QCCommand } from 'src/models/qc-command/qc-command.schema';

export class QCCommandRepository
  extends BaseAbstractRepository<QCCommand>
  implements QCCommandRepositoryInterface
{
  constructor(
    @InjectModel(QCCommand.name)
    private readonly qcCommandModel: Model<QCCommand>,
  ) {
    super(qcCommandModel);
  }

  createModel(request: CreateQCCommandRequestDto): QCCommand {
    const { code, name, qcRequestCode, description, items, status, userId } =
      request;
    const qcCommandModel = new this.qcCommandModel();
    qcCommandModel.code = code;
    qcCommandModel.name = name;
    qcCommandModel.qcRequestCode = qcRequestCode;
    qcCommandModel.description = description;
    qcCommandModel.items = items;
    qcCommandModel.status = status;
    qcCommandModel.createdBy = userId;
    return qcCommandModel;
  }

  updateModel(
    qcCommand: QCCommand,
    request: UpdateQCCommandBodyDto,
  ): QCCommand {
    const { name, qcRequestCode, description, items, status, userId } = request;
    qcCommand.name = name;
    qcCommand.name = name;
    qcCommand.qcRequestCode = qcRequestCode;
    qcCommand.description = description;
    qcCommand.items = items;
    qcCommand.status = status;
    qcCommand.updatedBy = userId;
    return qcCommand;
  }

  async getQCCommandReport(request: any): Promise<any> {
    const { sort, filter, take, skip } = request;
    let filterObj: any = {};
    let sortObj = {};

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: {
                $regex: '.*' + value + '.*',
                $options: 'i',
              },
            };
            break;
          case 'name':
            filterObj = {
              ...filterObj,
              name: getRegexByValue(value),
            };
            break;
          case 'status':
            filterObj = {
              ...filterObj,
              status: {
                $in: value.split(',').map((i) => parseInt(i)),
              },
            };
            break;
          case 'createdBy':
            filterObj = {
              ...filterObj,
              createdBy: parseInt(value),
            };
            break;
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order;
        switch (item.column) {
          case 'code':
            sortObj = { code: order };
            break;
          case 'name':
            sortObj = { name: order };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = { status: -1, createdAt: -1 };
    }

    const aggregate = this.qcCommandModel
      .aggregate([
        {
          $lookup: {
            from: 'qcRequests',
            localField: 'qcRequestCode',
            foreignField: 'code',
            as: 'qcRequest',
          },
        },
        {
          $unwind: {
            path: '$qcRequest',
          },
        },
        {
          $project: {
            code: '$code',
            name: '$name',
            startDate: {
              $min: '$items.startDate',
            },
            endDate: {
              $min: '$items.endDate',
            },
            deadline: '$qcRequest.returnDate',
            requestSource: '$qcRequest.requestSource',
            requestType: '$qcRequest.requestType',
            createdBy: '$createdBy',
            createdAt: '$createdAt',
            status: '$status',
            requestBy: '$qcRequest.requestBy',
            qcRequestCode: '$qcRequest.code',
            qcRequestName: '$qcRequest.name',
          },
        },
      ])
      .match(filterObj);

    const result = await aggregate.sort(sortObj).skip(skip).limit(take).exec();

    const count = await aggregate.count('count').exec();

    return {
      data: result,
      count: count[0]?.['count'] || 0,
    };
  }

  async getQCCommandReportBySource(
    request: GetQCCommandReportBySourceRequestDto,
  ): Promise<any> {
    const { requestSource, requestType, sort, filter, take, skip } = request;
    let filterObj: any = {};
    let sortObj = {};

    if (!isEmpty(requestSource)) {
      filterObj = {
        ...filterObj,
        requestSource: requestSource,
      };
    }

    if (!isEmpty(requestType)) {
      filterObj = {
        ...filterObj,
        requestType: requestType,
      };
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: {
                $regex: '.*' + value + '.*',
                $options: 'i',
              },
            };
            break;
          case 'name':
            filterObj = {
              ...filterObj,
              name: getRegexByValue(value),
            };
            break;
          case 'status':
            filterObj = {
              ...filterObj,
              status: parseInt(value),
            };
            break;
          case 'createdBy':
            filterObj = {
              ...filterObj,
              createdBy: parseInt(value),
            };
            break;
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order;
        switch (item.column) {
          case 'code':
            sortObj = { code: order };
            break;
          case 'name':
            sortObj = { name: order };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = { status: -1, createdAt: -1 };
    }

    const aggregate = this.qcCommandModel
      .aggregate([
        {
          $lookup: {
            from: 'qcRequests',
            localField: 'qcRequestCode',
            foreignField: 'code',
            as: 'qcRequest',
          },
        },
        {
          $unwind: {
            path: '$qcRequest',
          },
        },
        {
          $project: {
            code: '$code',
            name: '$name',
            startDate: {
              $min: '$items.startDate',
            },
            endDate: {
              $min: '$items.endDate',
            },
            deadline: '$qcRequest.returnDate',
            requestSource: '$qcRequest.requestSource',
            requestType: '$qcRequest.requestType',
            createdBy: '$createdBy',
            createdAt: '$createdAt',
            status: '$status',
          },
        },
      ])
      .match(filterObj);

    const result = await aggregate.sort(sortObj).skip(skip).limit(take).exec();

    const count = await aggregate.count('count').exec();

    return {
      data: result,
      count: count[0]?.['count'] || 0,
    };
  }

  async getQCCommandProgressReport(
    request: GetQCCommandProgressReportRequestDto,
  ): Promise<any> {
    const { take, skip } = request;
    const filterObj: any = {
      status: { $nin: [0, 3] },
    };
    const sortObj = { createdAt: -1 };

    const aggregate = this.qcCommandModel
      .aggregate([
        {
          $match: {
            status: {
              $nin: [0, 3],
            },
          },
        },
        {
          $lookup: {
            from: 'qcRequests',
            localField: 'qcRequestCode',
            foreignField: 'code',
            as: 'qcRequest',
          },
        },
        {
          $unwind: {
            path: '$qcRequest',
          },
        },
        {
          $addFields: {
            requestSource: '$qcRequest.requestSource',
            requestType: '$qcRequest.requestType',
            waiting: {
              $cond: [
                {
                  $eq: ['$status', QC_COMMAND_STATUS.WAITING],
                },
                1,
                0,
              ],
            },
            confirmed: {
              $cond: [
                {
                  $eq: ['$status', QC_COMMAND_STATUS.CONFIRMED],
                },
                1,
                0,
              ],
            },
            inProgress: {
              $cond: [
                {
                  $eq: ['$status', QC_COMMAND_STATUS.IN_PROGRESS],
                },
                1,
                0,
              ],
            },
            compeleted: {
              $cond: [
                {
                  $eq: ['$status', QC_COMMAND_STATUS.COMPLETED],
                },
                1,
                0,
              ],
            },
          },
        },
        {
          $group: {
            _id: {
              requestSource: '$requestSource',
              requestType: '$requestType',
            },
            waiting: {
              $sum: '$waiting',
            },
            confirmed: {
              $sum: '$confirmed',
            },
            inProgress: {
              $sum: '$inProgress',
            },
            compeleted: {
              $sum: '$compeleted',
            },
            total: {
              $sum: 1,
            },
          },
        },
      ])
      .match(filterObj);

    const result = await aggregate.sort(sortObj).skip(skip).limit(take).exec();

    const count = await aggregate.count('count').exec();

    return {
      data: result,
      count: count[0]?.['count'] || 0,
    };
  }

  async getList(request: GetListQCCommandRequestDto): Promise<any> {
    const { keyword, sort, filter, take, skip, queryIds } = request;
    let filterObj = {};
    let sortObj = {};

    if (!isEmpty(queryIds)) {
      filterObj = {
        ...filterObj,
        _id: {
          $in: queryIds.map((id) => new Types.ObjectId(id)),
        },
      };
    }

    if (!isEmpty(keyword)) {
      filterObj = {
        $or: [
          { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          { name: getRegexByValue(keyword) },
        ],
      };
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: {
                $regex: `.*${value}.*`,
                $options: 'i',
              },
            };
            break;
          case 'name':
            filterObj = {
              ...filterObj,
              name: getRegexByValue(value),
            };
            break;
          case 'qcRequestCode':
            filterObj = {
              ...filterObj,
              qcRequestCode: {
                $regex: `.*${value}.*`,
                $options: 'i',
              },
            };
            break;
          case 'requestSource':
            filterObj = {
              ...filterObj,
              requestSource: parseInt(value),
            };
            break;
          case 'requestType':
            filterObj = {
              ...filterObj,
              requestType: getRegexByValue(value),
            };
            break;
          case 'itemCode':
            filterObj = {
              ...filterObj,
              itemCode: getRegexByValue(value),
            };
            break;
          case 'startEndDate':
            filterObj = {
              ...filterObj,
              startDate: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'deadline':
            filterObj = {
              ...filterObj,
              deadline: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'createdBy':
            filterObj = {
              ...filterObj,
              createdBy: parseInt(value),
            };
            break;
          case 'status':
            filterObj = {
              ...filterObj,
              status: parseInt(value),
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order;
        switch (item.column) {
          case 'code':
            sortObj = { code: order };
            break;
          case 'name':
            sortObj = { name: order };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = {
        status: SortOrder.Ascending,
        createdAt: SortOrder.Descending,
      };
    }

    const result: any = await this.qcCommandModel
      .aggregate([
        {
          $lookup: {
            from: 'qcRequests',
            localField: 'qcRequestCode',
            foreignField: 'code',
            as: 'qcRequest',
          },
        },
      ])
      .addFields({
        sortStatus: {
          $indexOfArray: [
            [
              QC_COMMAND_STATUS.DRAFT,
              QC_COMMAND_STATUS.WAITING,
              QC_COMMAND_STATUS.CONFIRMED,
              QC_COMMAND_STATUS.IN_PROGRESS,
              QC_COMMAND_STATUS.COMPLETED,
              QC_COMMAND_STATUS.REJECTED,
            ],
            '$status',
          ],
        },
      })
      .match(filterObj)
      .sort(sortObj)
      .skip(skip)
      .limit(take)
      .exec();

    const count = await this.qcCommandModel
      .find({
        ...filterObj,
      })
      .countDocuments()
      .exec();

    return {
      data: result,
      count,
    };
  }

  async getLastQCCommand(prefixWithYear: string): Promise<any> {
    return await this.qcCommandModel
      .findOne({
        code: {
          $regex: `${prefixWithYear}.*`,
          $options: 'i',
        },
      })
      .sort({ createdAt: SortOrder.Descending })
      .exec();
  }

  async getTotalPlanExecuteQuantityItems(qcRequestCode: string): Promise<any> {
    const qcStatusFilter = [
      QC_COMMAND_STATUS.CONFIRMED,
      QC_COMMAND_STATUS.IN_PROGRESS,
      QC_COMMAND_STATUS.COMPLETED,
    ];
    return await this.qcCommandModel
      .aggregate([
        {
          $match: {
            qcRequestCode: qcRequestCode,
            status: {
              $in: qcStatusFilter,
            },
          },
        },
        {
          $unwind: {
            path: '$items',
          },
        },
        {
          $group: {
            _id: {
              itemCode: '$items.itemCode',
              lot: '$items.lot',
            },
            totalPlanExecuteQuantity: {
              $sum: '$items.planExecuteQuantity',
            },
          },
        },
      ])
      .exec();
  }
}
