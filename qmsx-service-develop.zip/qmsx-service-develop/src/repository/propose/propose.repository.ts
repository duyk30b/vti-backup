import { ProposeRepositoryInterface } from '@components/propose/interface/propose.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Propose } from 'src/models/propose/propose.schema';

export class ProposeRepository
  extends BaseAbstractRepository<Propose>
  implements ProposeRepositoryInterface
{
  constructor(
    @InjectModel(Propose.name)
    private readonly proposeModel: Model<Propose>,
  ) {
    super(proposeModel);
  }
}
