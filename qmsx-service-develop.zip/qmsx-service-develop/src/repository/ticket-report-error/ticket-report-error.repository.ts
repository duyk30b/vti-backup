import { GetListTicketReportErrorRequestDto } from '@components/ticket-report-error/dto/request/get-list-ticket-report-error.request.dto';
import { TicketReportErrorRepositoryInterface } from '@components/ticket-report-error/interface/ticket-report-error.repository.interface';
import { SortOrder } from '@constant/database.constant';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { getRegexByValue } from '@utils/common';
import { isEmpty } from 'lodash';
import * as moment from 'moment';
import { Model, Types } from 'mongoose';
import { TicketReportError } from 'src/models/ticket-report-error/ticket-report-error.schema';

export class TicketReportErrorRepository
  extends BaseAbstractRepository<TicketReportError>
  implements TicketReportErrorRepositoryInterface
{
  constructor(
    @InjectModel(TicketReportError.name)
    private readonly ticketReportErrorModel: Model<TicketReportError>,
  ) {
    super(ticketReportErrorModel);
  }

  async getList(request: GetListTicketReportErrorRequestDto): Promise<any> {
    const { keyword, sort, filter, take, skip, queryIds } = request;
    let filterObj = {};
    let sortObj = {};

    if (!isEmpty(queryIds)) {
      filterObj = {
        ...filterObj,
        _id: {
          $in: queryIds.map((id) => new Types.ObjectId(id)),
        },
      };
    }

    if (!isEmpty(keyword)) {
      filterObj = {
        $or: [
          { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          { name: getRegexByValue(keyword) },
        ],
      };
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: {
                $regex: `.*${value}.*`,
                $options: 'i',
              },
            };
            break;
          case 'qcCommandCode':
            filterObj = {
              ...filterObj,
              qcCommandCode: {
                $regex: `.*${value}.*`,
                $options: 'i',
              },
            };
            break;
          case 'qcCommandName':
            filterObj = {
              ...filterObj,
              'qcCommand.name': {
                $regex: `.*${value}.*`,
                $options: 'i',
              },
            };
            break;
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'createdBy':
            filterObj = {
              ...filterObj,
              createdBy: parseInt(value),
            };
            break;
          case 'status':
            filterObj = {
              ...filterObj,
              status: parseInt(value),
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order;
        switch (item.column) {
          case 'code':
            sortObj = { code: order };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = { status: -1, createdAt: -1 };
    }

    const result: any = await this.ticketReportErrorModel
      .aggregate([
        {
          $lookup: {
            from: 'qcCommands',
            localField: 'qcCommandCode',
            foreignField: 'code',
            as: 'qcCommand',
          },
        },
      ])
      .match(filterObj)
      .sort(sortObj)
      .skip(skip)
      .limit(take)
      .exec();

    const count = await this.ticketReportErrorModel
      .find({
        ...filterObj,
      })
      .countDocuments()
      .exec();

    return {
      data: result,
      count,
    };
  }

  async getLastTicketReportError(prefixWithYear: string): Promise<any> {
    return await this.ticketReportErrorModel
      .findOne({
        code: {
          $regex: `${prefixWithYear}.*`,
          $options: 'i',
        },
      })
      .sort({ createdAt: SortOrder.Descending })
      .exec();
  }
}
