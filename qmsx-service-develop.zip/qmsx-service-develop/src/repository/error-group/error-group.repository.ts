import { CreateErrorGroupRequestDto } from '@components/error-group/dto/request/create-error-group.request.dto';
import { GetListErrorGroupRequestDto } from '@components/error-group/dto/request/get-list-error-group.request.dto';
import { UpdateErrorGroupBodyDto } from '@components/error-group/dto/request/update-error-group.request.dto';
import { ErrorGroupRepositoryInterface } from '@components/error-group/interface/error-group.repository.interface';
import { SortOrder } from '@constant/database.constant';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { getRegexByValue } from '@utils/common';
import { isEmpty } from 'lodash';
import * as moment from 'moment';
import { Model, Types } from 'mongoose';
import { ErrorGroup } from 'src/models/error-group/error-group.schema';

export class ErrorGroupRepository
  extends BaseAbstractRepository<ErrorGroup>
  implements ErrorGroupRepositoryInterface
{
  constructor(
    @InjectModel(ErrorGroup.name)
    private readonly errorGroupModel: Model<ErrorGroup>,
  ) {
    super(errorGroupModel);
  }

  createModel(request: CreateErrorGroupRequestDto): ErrorGroup {
    const { code, name, description, errorCodes, active, userId } = request;
    const errorGroupModel = new this.errorGroupModel();
    errorGroupModel.code = code;
    errorGroupModel.name = name;
    errorGroupModel.description = description;
    errorGroupModel.errorCodes = errorCodes;
    errorGroupModel.active = active;
    errorGroupModel.createdBy = userId;
    return errorGroupModel;
  }

  updateModel(
    errorGroup: ErrorGroup,
    request: UpdateErrorGroupBodyDto,
  ): ErrorGroup {
    const { name, description, errorCodes, active, userId } = request;
    errorGroup.name = name;
    errorGroup.description = description;
    errorGroup.errorCodes = errorCodes;
    errorGroup.active = active;
    errorGroup.updatedBy = userId;
    return errorGroup;
  }

  async getList(request: GetListErrorGroupRequestDto): Promise<any> {
    const { keyword, sort, filter, take, skip, queryIds } = request;
    let filterObj = {};
    let sortObj = {};

    if (!isEmpty(queryIds)) {
      filterObj = {
        ...filterObj,
        _id: {
          $in: queryIds.map((id) => new Types.ObjectId(id)),
        },
      };
    }

    if (!isEmpty(keyword)) {
      filterObj = {
        $or: [
          { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          { name: getRegexByValue(keyword) },
        ],
      };
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: {
                $regex: `.*${value}.*`,
                $options: 'i',
              },
            };
            break;
          case 'name':
            filterObj = {
              ...filterObj,
              name: getRegexByValue(value),
            };
            break;
          case 'description':
            filterObj = {
              ...filterObj,
              description: getRegexByValue(value),
            };
            break;
          case 'active':
            filterObj = {
              ...filterObj,
              active: parseInt(value),
            };
            break;
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'createdBy':
            filterObj = {
              ...filterObj,
              createdBy: parseInt(value),
            };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order;
        switch (item.column) {
          case 'code':
            sortObj = { code: order };
            break;
          case 'name':
            sortObj = { name: order };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = { active: -1, createdAt: -1 };
    }

    const result: any = await this.errorGroupModel
      .aggregate()
      .match(filterObj)
      .sort(sortObj)
      .skip(skip)
      .limit(take)
      .exec();

    const count = await this.errorGroupModel
      .find({
        ...filterObj,
      })
      .countDocuments()
      .exec();

    return {
      data: result,
      count,
    };
  }

  async getLastErrorGroup(): Promise<any> {
    return await this.errorGroupModel
      .findOne()
      .sort({ createdAt: SortOrder.Descending })
      .exec();
  }
}
