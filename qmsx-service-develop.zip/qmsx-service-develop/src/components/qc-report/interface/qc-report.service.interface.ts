import { GetQCReportByCauseRequestDto } from '@components/qc-execute/dto/request/get-qc-report-by-cause.request.dto';
import { GetQCCommandProgressReportRequestDto } from '../dto/request/get-qc-command-progress-report.request.dto';
import { GetQCCommandReportByCauseRequestDto } from '../dto/request/get-qc-command-report-by-cause.request.dto';
import { GetQCCommandReportBySourceRequestDto } from '../dto/request/get-qc-command-report-by-source.request.dto';
import { GetQCRequestReportRequestDto } from '../dto/request/get-qc-request-report.request.dto';

export interface QCReportServiceInterface {
  getQCReportByCause(request: GetQCReportByCauseRequestDto): Promise<any>;
  getQCCommandReportByCause(
    request: GetQCCommandReportByCauseRequestDto,
  ): Promise<any>;
  getQCCommandProgressReport(
    request: GetQCCommandProgressReportRequestDto,
  ): Promise<any>;
  getQCCommandReportBySource(
    request: GetQCCommandReportBySourceRequestDto,
  ): Promise<any>;
  getQCCommandProgressReport(
    request: GetQCCommandProgressReportRequestDto,
  ): Promise<any>;
  getQCRequestReport(request: GetQCRequestReportRequestDto): Promise<any>;
}
