import { ItemService } from '@components/item/item.service';
import { QCCommandRepositoryInterface } from '@components/qc-command/interface/qc-command.repository.interface';
import { QCExecuteResultRepositoryInterface } from '@components/qc-execute/interface/qc-execute-result.repository.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { compact, concat, isEmpty, keyBy, map, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { GetQCCommandProgressReportRequestDto } from './dto/request/get-qc-command-progress-report.request.dto';
import { GetQCCommandReportByCauseRequestDto } from './dto/request/get-qc-command-report-by-cause.request.dto';
import { GetQCCommandReportBySourceRequestDto } from './dto/request/get-qc-command-report-by-source.request.dto';
import { GetListQCReportRequestDto } from './dto/request/get-qc-report-by-cause.request.dto';
import { QCCommandProgressReportResponseDto } from './dto/response/qc-command-progress-report.response.dto';
import { QCCommandReportByCauseResponseDto } from './dto/response/qc-command-report-by-cause.response.dto';
import { QCCommandReportBySourceResponseDto } from './dto/response/qc-command-report-by-source.response.dto';
import { QCReportByCauseResponseDto } from './dto/response/qc-report-by-cause.response.dto';
import { QCReportServiceInterface } from './interface/qc-report.service.interface';
import { GetQCRequestReportRequestDto } from './dto/request/get-qc-request-report.request.dto';
import { QCRequestRepositoryInterface } from '@components/qc-request/interface/qc-request.repository.interface';
import { QCRequestReportResponseDto } from './dto/response/qc-request-report.response.dto';

@Injectable()
export class QCReportService implements QCReportServiceInterface {
  constructor(
    @Inject('QCRequestRepositoryInterface')
    private readonly qcRequestRepository: QCRequestRepositoryInterface,

    @Inject('QCCommandRepositoryInterface')
    private readonly qcCommandRepository: QCCommandRepositoryInterface,

    @Inject('QCExecuteResultRepositoryInterface')
    private readonly qcExecuteResultRepository: QCExecuteResultRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ItemService')
    private readonly itemService: ItemService,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async getQCRequestReport(
    request: GetQCRequestReportRequestDto,
  ): Promise<any> {
    const { data, count } = await this.qcRequestRepository.getQCRequestReport(
      request,
    );

    const dataReturn = plainToInstance(QCRequestReportResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getQCCommandReportBySource(
    request: GetQCCommandReportBySourceRequestDto,
  ): Promise<any> {
    const { data, count } =
      await this.qcCommandRepository.getQCCommandReportBySource(request);

    const createdBy = uniq(compact(map(data, 'createdBy')));
    const requestBy = uniq(compact(map(data, 'requestBy')));
    const userIds = uniq(concat(createdBy, requestBy));

    // Filter by user id
    const userIdFilters = [
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ];

    if (!isEmpty(userIds)) {
      let users = await this.userService.getList(userIdFilters);
      users = keyBy(users, 'id');
      data.forEach((item) => {
        item.createdBy = users[item.createdBy];
        item.requestBy = users[item.requestBy];
      });
    }

    const dataReturn = plainToInstance(
      QCCommandReportBySourceResponseDto,
      data,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getQCCommandProgressReport(
    request: GetQCCommandProgressReportRequestDto,
  ): Promise<any> {
    const { data, count } =
      await this.qcCommandRepository.getQCCommandProgressReport(request);

    const dataReturn = plainToInstance(
      QCCommandProgressReportResponseDto,
      data,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getQCCommandReportByCause(
    request: GetQCCommandReportByCauseRequestDto,
  ): Promise<any> {
    const { data, count } =
      await this.qcExecuteResultRepository.getQCCommandReportByCause(request);

    const userIds = uniq(compact(map(data, 'createdBy')));

    // Filter by user id
    const userIdFilters = [
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ];

    if (!isEmpty(userIds)) {
      let users = await this.userService.getList(userIdFilters);
      users = keyBy(users, 'id');
      data.forEach((item) => {
        item.createdBy = users[item.createdBy];
      });
    }

    const dataReturn = plainToInstance(
      QCCommandReportByCauseResponseDto,
      data,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getQCReportByCause(request: GetListQCReportRequestDto) {
    const { data, count } =
      await this.qcExecuteResultRepository.getQCReportByCause(request);

    // Filter by item code
    const itemCodes = uniq(compact(map(data, 'itemCode')));
    if (!isEmpty(itemCodes)) {
      const request = {
        codes: itemCodes.join(','),
      };
      let itemList = await this.itemService.getItemList(request);
      itemList = keyBy(itemList, 'code');

      data?.forEach((it) => {
        it.item = itemList[it.itemCode];
      });
    }

    const dataReturn = plainToInstance(QCReportByCauseResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
