import { GetQCReportByCauseRequestDto } from '@components/qc-execute/dto/request/get-qc-report-by-cause.request.dto';
import { Controller, Get, Inject, Query } from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { isEmpty } from 'lodash';
import { GetQCCommandProgressReportRequestDto } from './dto/request/get-qc-command-progress-report.request.dto';
import { GetQCCommandReportByCauseRequestDto } from './dto/request/get-qc-command-report-by-cause.request.dto';
import { GetQCCommandReportBySourceRequestDto } from './dto/request/get-qc-command-report-by-source.request.dto';
import { GetQCRequestReportRequestDto } from './dto/request/get-qc-request-report.request.dto';
import { QCCommandReportBySourceResponseDto } from './dto/response/qc-command-report-by-source.response.dto';
import { QCReportByCauseResponseDto } from './dto/response/qc-report-by-cause.response.dto';
import { QCRequestReportResponseDto } from './dto/response/qc-request-report.response.dto';
import { QCReportServiceInterface } from './interface/qc-report.service.interface';

@Controller('qc-reports')
export class QCReportController {
  constructor(
    @Inject('QCReportServiceInterface')
    private readonly qualityReportService: QCReportServiceInterface,
  ) {}

  @Get()
  @ApiOperation({
    tags: ['QC Report - Báo cáo QC'],
    summary: 'Thống kê nguyên nhân lỗi',
    description: 'Thống kê nguyên nhân lỗi',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: QCReportByCauseResponseDto,
  })
  async getList(@Query() query: GetQCReportByCauseRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qualityReportService.getQCReportByCause(request);
  }

  @Get('qc-command-by-cause')
  @ApiOperation({
    tags: ['QC Report - Báo cáo QC'],
    summary: 'Thống kê lệnh QC theo nguyên nhân',
    description: 'Thống kê lệnh QC theo nguyên nhân',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: QCReportByCauseResponseDto,
  })
  async getQCCommandReportByCause(
    @Query() query: GetQCCommandReportByCauseRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qualityReportService.getQCCommandReportByCause(request);
  }

  @Get('qc-command-progress')
  @ApiOperation({
    tags: ['QC Report - Báo cáo QC'],
    summary: 'Thống kê tiến độ lênh QC',
    description: 'Thống kê tiến độ lênh QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: QCReportByCauseResponseDto,
  })
  async getQCCommandProgressReport(
    @Query() query: GetQCCommandProgressReportRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qualityReportService.getQCCommandProgressReport(request);
  }

  @Get('qc-command-by-source')
  @ApiOperation({
    tags: ['QC Report - Báo cáo QC'],
    summary: 'Thống kê lệnh QC theo nguồn yêu cầu',
    description: 'Thống kê lệnh QC theo nguồn yêu cầu',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: QCCommandReportBySourceResponseDto,
  })
  async getQCCommandReportBySource(
    @Query() query: GetQCCommandReportBySourceRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qualityReportService.getQCCommandReportBySource(request);
  }

  @Get('qc-request')
  @ApiOperation({
    tags: ['QC Report - Báo cáo QC'],
    summary: 'Thống kê yêu cầu QC',
    description: 'Thống kê yêu cầu QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: QCRequestReportResponseDto,
  })
  async getQCRequestReport(
    @Query() query: GetQCRequestReportRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qualityReportService.getQCRequestReport(request);
  }
}
