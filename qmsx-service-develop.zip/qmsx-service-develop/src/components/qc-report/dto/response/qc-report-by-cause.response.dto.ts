import { BaseResponseDto } from '@core/dto/base.response.dto';
import { Expose } from 'class-transformer';

export class QCReportByCauseResponseDto extends BaseResponseDto {
  @Expose()
  cause: any;

  @Expose()
  item: any;

  @Expose()
  count: number;
}
