import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform } from 'class-transformer';

export class QCCommandProgressReportResponseDto {
  @ApiProperty()
  @Expose({ name: '_id' })
  @Transform((value) => value.obj._id)
  uniqKey: any;

  @ApiProperty()
  @Expose()
  waiting: number;

  @ApiProperty()
  @Expose()
  confirmed: number;

  @ApiProperty()
  @Expose()
  inProgress: number;

  @ApiProperty()
  @Expose()
  compeleted: number;

  @ApiProperty()
  @Expose()
  total: number;
}
