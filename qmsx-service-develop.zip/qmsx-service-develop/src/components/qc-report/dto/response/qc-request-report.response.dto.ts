import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform } from 'class-transformer';

export class QCRequestReportResponseDto {
  @ApiProperty()
  @Expose({ name: '_id' })
  @Transform((value) => value.obj._id)
  requestSource: number;

  @ApiProperty()
  @Expose()
  total: number;

  @ApiProperty()
  @Expose()
  waiting: number;

  @ApiProperty()
  @Expose()
  confirmed: number;

  @ApiProperty()
  @Expose()
  rejected: number;

  @ApiProperty()
  @Expose()
  inProgress: number;

  @ApiProperty()
  @Expose()
  completed: number;
}
