import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { IsArray, IsOptional } from 'class-validator';

export class GetQCCommandReportRequestDto extends PaginationQuery {
  @ApiProperty()
  @IsOptional()
  @IsArray()
  queryIds: string[];
}
