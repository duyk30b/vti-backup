import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { IsMongoId, IsNotEmpty, IsString } from 'class-validator';

export class GetQCCommandReportByCauseRequestDto extends PaginationQuery {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  causeId: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  itemCode: string;
}
