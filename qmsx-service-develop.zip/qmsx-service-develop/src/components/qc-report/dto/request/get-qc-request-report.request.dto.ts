import { PaginationQuery } from '@utils/dto/request/pagination.query';

export class GetQCRequestReportRequestDto extends PaginationQuery {}
