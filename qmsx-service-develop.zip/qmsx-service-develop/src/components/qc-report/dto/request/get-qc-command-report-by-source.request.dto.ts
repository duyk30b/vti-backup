import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty, IsString } from 'class-validator';

export class GetQCCommandReportBySourceRequestDto extends PaginationQuery {
  @ApiProperty()
  @Transform((param) => Number(param.value))
  @IsNotEmpty()
  @IsInt()
  requestSource: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  requestType: string;
}
