import { PushNotificationRequestDto } from '../dto/notification.request.dto';

export interface NotificationServiceInterface {
  pushNotification(request: PushNotificationRequestDto): Promise<any>;
}
