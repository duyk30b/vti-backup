import { GetListErrorRequestDto } from '@components/error/dto/request/get-list-error.request.dto';
import { QCCommand } from 'src/models/qc-command/qc-command.schema';
import { CreateUpdateProposeRequestDto } from '../dto/request/create-update-propose.request.dto';
import { GetDetailTicketReportErrorRequestDto } from '../dto/request/get-detail-ticket-report-error.request.dto';

export interface TicketReportErrorServiceInterface {
  create(qcCommand: QCCommand, userId: number): Promise<any>;
  getDetail(request: GetDetailTicketReportErrorRequestDto): Promise<any>;
  getList(request: GetListErrorRequestDto): Promise<any>;
  createUpdatePropose(request: CreateUpdateProposeRequestDto): Promise<any>;
}
