import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { TicketReportError } from 'src/models/ticket-report-error/ticket-report-error.schema';
import { GetListTicketReportErrorRequestDto } from '../dto/request/get-list-ticket-report-error.request.dto';

export interface TicketReportErrorRepositoryInterface
  extends BaseInterfaceRepository<TicketReportError> {
  getList(request: GetListTicketReportErrorRequestDto): Promise<any>;
  getLastTicketReportError(prefixWithYear: string): Promise<any>;
}
