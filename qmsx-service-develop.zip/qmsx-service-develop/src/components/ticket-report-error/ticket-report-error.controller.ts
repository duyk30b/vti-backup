import {
  Body,
  Controller,
  Get,
  Inject,
  Param,
  Post,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateUpdateProposeRequestDto } from './dto/request/create-update-propose.request.dto';
import { GetDetailTicketReportErrorRequestDto } from './dto/request/get-detail-ticket-report-error.request.dto';
import { GetListTicketReportErrorRequestDto } from './dto/request/get-list-ticket-report-error.request.dto';
import { ListTicketReportErrorResponseDto } from './dto/response/list-ticket-report-error.response.dto';
import { TicketReportErrorResponseDto } from './dto/response/ticket-report-error.response.dto';
import { TicketReportErrorServiceInterface } from './interface/ticket-report-error.service.interface';

@Controller('ticket-report-errors')
export class TicketReportErrorController {
  constructor(
    @Inject('TicketReportErrorServiceInterface')
    private readonly ticketReportErrorService: TicketReportErrorServiceInterface,
  ) {}

  @Get('/:id')
  @ApiOperation({
    tags: ['Ticket Report Error - Phiếu báo cáo lỗi'],
    summary: 'Chi tiết phiếu báo cáo lỗi',
    description: 'Chi tiết phiếu báo cáo lỗi',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: TicketReportErrorResponseDto,
  })
  async getDetail(
    @Param() param: GetDetailTicketReportErrorRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.ticketReportErrorService.getDetail(request);
  }

  @Get()
  @ApiOperation({
    tags: ['Ticket Report Error - Phiếu báo cáo lỗi'],
    summary: 'Danh sách phiếu báo cáo lỗi',
    description: 'Danh sách phiếu báo cáo lỗi',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListTicketReportErrorResponseDto,
  })
  async getList(
    @Query() query: GetListTicketReportErrorRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.ticketReportErrorService.getList(request);
  }

  @Post('/proposes')
  @ApiOperation({
    tags: ['Ticket Report Error - Phiếu báo cáo lỗi'],
    summary: 'Thêm/Sửa đề xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Add Successfully',
    type: SuccessResponse,
  })
  async createUpdatePropose(
    @Body() payload: CreateUpdateProposeRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.ticketReportErrorService.createUpdatePropose(request);
  }
}
