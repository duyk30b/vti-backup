import { CODE_REGEX } from '@constant/common';

export enum TICKET_REPORT_ERROR_STATUS {
  TODO,
  IN_PROGRESS,
  DONE,
  FINISHED,
}

export const REGEX_PADDING_ZERO = /^0+/;
export const EMPTY_STRING = '';
export const PREFIX_TICKET_REPORT_ERROR_CODE = 'PBCL';
export const FORMAT_SHORT_YEAR = 'YY';
export const INDEX_TICKET_REPORT_ERROR_CODE_START = 1;
export const STEP_INDEX_TICKET_REPORT_ERROR_CODE = 1;
export const MAX_LENGTH_INDEX = 6;
export const PADDING_SYMBOL = '0';

export const ERROR_GROUP_CONST = {
  CODE: {
    MAX_LENGTH: 50,
    COLUMN: 'code',
    REGEX: CODE_REGEX,
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
};
