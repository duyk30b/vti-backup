import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateTicketReportErrorRequestDto } from './create-ticket-report-error.request.dto';

export class UpdateTicketReportErrorBodyDto extends CreateTicketReportErrorRequestDto {}

export class UpdateTicketReportErrorRequestDto extends UpdateTicketReportErrorBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
