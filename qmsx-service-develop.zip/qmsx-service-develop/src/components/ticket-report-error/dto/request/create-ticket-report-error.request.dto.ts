import { ERROR_GROUP_CONST } from '@components/ticket-report-error/ticket-report-error.constant';
import { ACTIVE_ENUM } from '@constant/common';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import {
  IsArray,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';
import { Types } from 'mongoose';

export class CreateTicketReportErrorRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @MaxLength(ERROR_GROUP_CONST.CODE.MAX_LENGTH)
  @IsString()
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @MaxLength(ERROR_GROUP_CONST.NAME.MAX_LENGTH)
  @IsString()
  name: string;

  @ApiProperty()
  @IsOptional()
  @MaxLength(ERROR_GROUP_CONST.DESCRIPTION.MAX_LENGTH)
  @IsString()
  description: string;

  @ApiProperty()
  @Transform((param) => param?.value?.map((item) => new Types.ObjectId(item)))
  @IsOptional()
  @IsArray()
  errorIds: Types.ObjectId[];

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(ACTIVE_ENUM)
  active: number;
}
