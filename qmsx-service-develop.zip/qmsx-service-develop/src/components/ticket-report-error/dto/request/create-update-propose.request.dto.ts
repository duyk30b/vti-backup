import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty, IsString } from 'class-validator';
import { Types } from 'mongoose';

export class CreateUpdateProposeRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  qcExecuteId: Types.ObjectId;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  errorCode: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  content: string;
}
