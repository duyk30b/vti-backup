import { QCCommandResponseDto } from '@components/qc-command/dto/response/qc-command.response.dto';
import { QCExecuteResponseDto } from '@components/qc-execute/dto/response/qc-execute.response.dto';
import { UserResponseDto } from '@components/user/dto/response/user.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { Expose, Type } from 'class-transformer';

export class TicketReportErrorResponseDto extends BaseResponseDto {
  @Expose()
  code: string;

  @Expose()
  qcCommandCode: string;

  @Expose()
  @Type(() => QCCommandResponseDto)
  qcCommand: QCCommandResponseDto;

  @Expose()
  @Type(() => UserResponseDto)
  qcBy: UserResponseDto[];

  @Expose()
  startDate: Date;

  @Expose()
  endDate: Date;

  @Expose()
  @Type(() => QCExecuteResponseDto)
  items: QCExecuteResponseDto[];

  @Expose()
  status: number;
}
