import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';
import { TicketReportErrorResponseDto } from './ticket-report-error.response.dto';

export class ListTicketReportErrorResponseDto extends PaginationResponse {
  @ApiProperty({ type: TicketReportErrorResponseDto, isArray: true })
  @Type(() => TicketReportErrorResponseDto)
  @Expose()
  items: TicketReportErrorResponseDto[];
}
