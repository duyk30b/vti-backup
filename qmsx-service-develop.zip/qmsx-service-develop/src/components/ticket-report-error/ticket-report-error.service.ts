import { ErrorRepositoryInterface } from '@components/error/interface/error.repository.interface';
import { EvaluationCriteriaRepositoryInterface } from '@components/evaluation-criteria/interface/evaluation-criteria.repository.interface';
import { ItemService } from '@components/item/item.service';
import { ProposeRepositoryInterface } from '@components/propose/interface/propose.repository.interface';
import { QCCommandRepositoryInterface } from '@components/qc-command/interface/qc-command.repository.interface';
import { QCExecuteRepositoryInterface } from '@components/qc-execute/interface/qc-execute.repository.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import {
  compact,
  concat,
  find,
  flatten,
  groupBy,
  head,
  isEmpty,
  keyBy,
  map,
  maxBy,
  minBy,
  sumBy,
  uniq,
} from 'lodash';
import * as moment from 'moment';
import { Types } from 'mongoose';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { QCCommand } from 'src/models/qc-command/qc-command.schema';
import { CreateUpdateProposeRequestDto } from './dto/request/create-update-propose.request.dto';
import { GetDetailTicketReportErrorRequestDto } from './dto/request/get-detail-ticket-report-error.request.dto';
import { GetListTicketReportErrorRequestDto } from './dto/request/get-list-ticket-report-error.request.dto';
import { TicketReportErrorResponseDto } from './dto/response/ticket-report-error.response.dto';
import { TicketReportErrorRepositoryInterface } from './interface/ticket-report-error.repository.interface';
import { TicketReportErrorServiceInterface } from './interface/ticket-report-error.service.interface';
import {
  EMPTY_STRING,
  FORMAT_SHORT_YEAR,
  INDEX_TICKET_REPORT_ERROR_CODE_START,
  MAX_LENGTH_INDEX,
  PADDING_SYMBOL,
  PREFIX_TICKET_REPORT_ERROR_CODE,
  REGEX_PADDING_ZERO,
  STEP_INDEX_TICKET_REPORT_ERROR_CODE,
  TICKET_REPORT_ERROR_STATUS,
} from './ticket-report-error.constant';

@Injectable()
export class TicketReportErrorService
  implements TicketReportErrorServiceInterface
{
  constructor(
    @Inject('ErrorRepositoryInterface')
    private readonly errorRepository: ErrorRepositoryInterface,

    @Inject('EvaluationCriteriaRepositoryInterface')
    private readonly evaluationCriteriaRepository: EvaluationCriteriaRepositoryInterface,

    @Inject('QCCommandRepositoryInterface')
    private readonly qcCommandRepository: QCCommandRepositoryInterface,

    @Inject('QCExecuteRepositoryInterface')
    private readonly qcExecuteRepository: QCExecuteRepositoryInterface,

    @Inject('TicketReportErrorRepositoryInterface')
    private readonly ticketReportErrorRepository: TicketReportErrorRepositoryInterface,

    @Inject('ProposeRepositoryInterface')
    private readonly proposeRepository: ProposeRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ItemService')
    private readonly itemService: ItemService,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(qcCommand: QCCommand, userId: number): Promise<any> {
    const ticketReportError = {
      code: await this.generateTicketReportErrorCode(),
      qcCommandCode: qcCommand.code,
      createdBy: userId,
      status: TICKET_REPORT_ERROR_STATUS.TODO,
    };

    await this.ticketReportErrorRepository.create(ticketReportError);
  }

  async getDetail(request: GetDetailTicketReportErrorRequestDto): Promise<any> {
    try {
      const { id } = request;
      const ticketReportError: any =
        await this.ticketReportErrorRepository.findOneById(id);

      if (!ticketReportError) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      // Get QC command
      const qcCommand = await this.qcCommandRepository.findOneByCode(
        ticketReportError.qcCommandCode,
      );

      ticketReportError.qcCommand = qcCommand;

      // Get list item QC
      const items = await this.qcExecuteRepository.getListByQCCommandCode(
        ticketReportError.qcCommandCode,
      );

      // Get user QC
      // TODO
      const qcBy = uniq(flatten(map(items, 'qcBy')));

      // Filter by user id
      const userIdFilters = [
        {
          column: 'userIds',
          text: qcBy.join(','),
        },
      ];

      if (!isEmpty(qcBy)) {
        ticketReportError.qcBy = await this.userService.getList(userIdFilters);
      }

      // Map all result
      const resultAll = flatten(map(items, 'qcExecuteResults'));

      // Get start date QC
      ticketReportError.startDate = minBy(
        resultAll,
        'qcStartDate',
      )?.qcStartDate;

      // Get end date QC
      ticketReportError.endDate = maxBy(resultAll, 'qcEndDate')?.qcEndDate;

      // Get end date QC
      const itemCodes = uniq(compact(map(items, 'itemCode')));
      let itemList: any = [];
      if (!isEmpty(itemCodes)) {
        const request = {
          codes: itemCodes.join(','),
        };
        itemList = await this.itemService.getItemList(request);
        itemList = keyBy(itemList, 'code');
      }

      // Get error list
      const errorCodes = uniq(
        compact(
          map(
            flatten(map(flatten(map(items, 'qcExecuteResults')), 'resultInfo')),
            'errorCode',
          ),
        ),
      );
      let errorList: any = [];
      if (!isEmpty(errorCodes)) {
        errorList = await this.errorRepository.findAllByCondition({
          code: { $in: errorCodes },
        });
        errorList = keyBy(errorList, 'code');
      }

      // Get evaluation list
      const evaluationCodes = uniq(
        compact(
          map(
            flatten(map(flatten(map(items, 'qcExecuteResults')), 'resultInfo')),
            'evaluationCode',
          ),
        ),
      );
      let evaluationList: any = [];
      if (!isEmpty(errorCodes)) {
        evaluationList =
          await this.evaluationCriteriaRepository.findAllByCondition({
            code: { $in: evaluationCodes },
          });
        evaluationList = keyBy(evaluationList, 'code');
      }

      //  Get qc execute list
      const qcExecuteIds = uniq(compact(map(items, '_id')));
      let proposes: any = [];
      if (!isEmpty(qcExecuteIds)) {
        proposes = await this.proposeRepository.findAllByCondition({
          qcExecuteId: { $in: qcExecuteIds },
        });
      }

      items.forEach((item) => {
        const errors = map(
          groupBy(
            flatten(concat(map(item?.qcExecuteResults, 'resultInfo'))),
            'errorCode',
          ),
          (itemError, errorCode) => {
            return {
              errorCode: errorCode,
              error: errorList[errorCode],
              evaluationCode: head(itemError)?.evaluationCode,
              evaluation: evaluationList[head(itemError)?.evaluationCode],
              errorNumber: sumBy(itemError, 'errorNumber'),
              causeCodes: flatten(map(itemError, 'causeCodes')),
              propose: find(proposes, {
                qcExecuteId: item._id,
                errorCode: errorCode,
              })?.content,
            };
          },
        );
        item.errors = errors;
        item.item = itemList[item.itemCode];
      });

      ticketReportError.items = items;

      const dataReturn = plainToInstance(
        TicketReportErrorResponseDto,
        ticketReportError,
        {
          excludeExtraneousValues: true,
        },
      );

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getList(request: GetListTicketReportErrorRequestDto): Promise<any> {
    const { data, count } = await this.ticketReportErrorRepository.getList(
      request,
    );
    const userIds = uniq(compact(map(data, 'createdBy')));

    // Filter by user id
    const userIdFilters = [
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ];

    if (!isEmpty(userIds)) {
      let users = await this.userService.getList(userIdFilters);
      users = keyBy(users, 'id');
      data.forEach((item) => {
        item.createdBy = {
          id: users[item.createdBy]?.id,
          username: users[item.createdBy]?.username,
          fullName: users[item.createdBy]?.fullName,
          code: users[item.createdBy]?.code,
        };
      });
    }

    const dataReturn = plainToInstance(TicketReportErrorResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async createUpdatePropose(
    request: CreateUpdateProposeRequestDto,
  ): Promise<any> {
    try {
      const { qcExecuteId, errorCode, content } = request;

      const bulkOps = [
        {
          updateOne: {
            filter: { qcExecuteId: new Types.ObjectId(qcExecuteId), errorCode },
            update: {
              qcExecuteId: new Types.ObjectId(qcExecuteId),
              errorCode,
              content,
            },
            upsert: true,
          },
        },
      ];

      await this.proposeRepository.bulkWrite(bulkOps);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  private async generateTicketReportErrorCode(): Promise<any> {
    const shortYear = moment().format(FORMAT_SHORT_YEAR);
    const prefixWithYear = `${PREFIX_TICKET_REPORT_ERROR_CODE}${shortYear}`;

    const lastTicketReportError =
      await this.ticketReportErrorRepository.getLastTicketReportError(
        prefixWithYear,
      );

    let index = INDEX_TICKET_REPORT_ERROR_CODE_START;
    if (!isEmpty(lastTicketReportError)) {
      const lastCode: string = lastTicketReportError.code;
      if (!isEmpty(lastCode) && lastCode.length > prefixWithYear.length) {
        let lastIndex: any = lastCode
          .substring(prefixWithYear.length)
          .replace(REGEX_PADDING_ZERO, EMPTY_STRING);
        lastIndex = Number(lastIndex);
        if (!isNaN(lastIndex)) {
          index = lastIndex + STEP_INDEX_TICKET_REPORT_ERROR_CODE;
        }
      }
    }

    const codeNew = `${prefixWithYear}${index
      ?.toString()
      .padStart(MAX_LENGTH_INDEX, PADDING_SYMBOL)}`;

    const existCode = await this.ticketReportErrorRepository.findOneByCode(
      codeNew,
    );

    if (!isEmpty(existCode)) {
      return this.generateTicketReportErrorCode();
    }

    return codeNew;
  }
}
