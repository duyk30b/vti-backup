import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ErrorSchema } from 'src/models/error/error.schema';
import { Propose, ProposeSchema } from 'src/models/propose/propose.schema';
import {
  QCExecute,
  QCExecuteSchema,
} from 'src/models/qc-execute/qc-execute.schema';
import {
  TicketReportError,
  TicketReportErrorSchema,
} from 'src/models/ticket-report-error/ticket-report-error.schema';
import { ErrorRepository } from 'src/repository/error/error.repository';
import { ProposeRepository } from 'src/repository/propose/propose.repository';
import { QCExecuteRepository } from 'src/repository/qc-execute/qc-execute.repository';
import { TicketReportErrorRepository } from 'src/repository/ticket-report-error/ticket-report-error.repository';
import { TicketReportErrorController } from './ticket-report-error.controller';
import { TicketReportErrorService } from './ticket-report-error.service';
import { ItemService } from '@components/item/item.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: TicketReportError.name,
        schema: TicketReportErrorSchema,
      },
      {
        name: Error.name,
        schema: ErrorSchema,
      },
      {
        name: QCExecute.name,
        schema: QCExecuteSchema,
      },
      {
        name: Propose.name,
        schema: ProposeSchema,
      },
    ]),
  ],
  controllers: [TicketReportErrorController],
  providers: [
    {
      provide: 'TicketReportErrorServiceInterface',
      useClass: TicketReportErrorService,
    },
    {
      provide: 'TicketReportErrorRepositoryInterface',
      useClass: TicketReportErrorRepository,
    },
    {
      provide: 'ErrorRepositoryInterface',
      useClass: ErrorRepository,
    },
    {
      provide: 'QCExecuteRepositoryInterface',
      useClass: QCExecuteRepository,
    },
    {
      provide: 'ProposeRepositoryInterface',
      useClass: ProposeRepository,
    },
    {
      provide: 'ItemService',
      useClass: ItemService,
    },
  ],
  exports: [
    {
      provide: 'TicketReportErrorServiceInterface',
      useClass: TicketReportErrorService,
    },
    {
      provide: 'TicketReportErrorRepositoryInterface',
      useClass: TicketReportErrorRepository,
    },
  ],
})
export class TicketReportErrorModule {}
