import { Module } from '@nestjs/common';
import { SettingService } from './setting.service';
import { SettingController } from './setting.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { QCSetting, QCSettingSchema } from 'src/models/setting/setting.schema';
import { SettingRepository } from 'src/repository/setting/setting.repository';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: QCSetting.name,
        schema: QCSettingSchema,
      },
    ]),
  ],
  controllers: [SettingController],
  providers: [
    {
      provide: 'SettingServiceInterface',
      useClass: SettingService,
    },
    {
      provide: 'SettingRepositoryInterface',
      useClass: SettingRepository,
    },
  ],
  exports: [
    {
      provide: 'SettingServiceInterface',
      useClass: SettingService,
    },
    {
      provide: 'SettingRepositoryInterface',
      useClass: SettingRepository,
    },
  ],
})
export class SettingModule {}
