import { Inject, Injectable } from '@nestjs/common';
import { SettingServiceInterface } from './interface/setting.service.interface';
import { SettingRepositoryInterface } from './interface/setting.repository.interface';
import { isEmpty } from 'lodash';
import { ApiError } from '@utils/api.error';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { plainToInstance } from 'class-transformer';
import { QCSettingResponseDto } from './dto/response/setting.response.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { UpdateQCSettingBodyDto } from './dto/request/update-qc-setting.request.dto';

@Injectable()
export class SettingService implements SettingServiceInterface {
  constructor(
    @Inject('SettingRepositoryInterface')
    private readonly settingRepository: SettingRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async onModuleInit() {
    // initialize the setting record
    const setting = await this.settingRepository.findAll();
    if (!isEmpty(setting)) return;
    await this.settingRepository.create({});
  }

  async find() {
    const setting = await this.settingRepository.findAll();
    if (isEmpty(setting)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const dataReturn = plainToInstance(QCSettingResponseDto, setting[0], {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateSetting(request: UpdateQCSettingBodyDto) {
    const doc = await this.settingRepository.findAllAndUpdate(
      {},
      { ...request, createdBy: request.userId },
      true,
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
