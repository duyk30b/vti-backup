import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { QCSetting } from 'src/models/setting/setting.schema';

export interface SettingRepositoryInterface
  extends BaseInterfaceRepository<QCSetting> {}
