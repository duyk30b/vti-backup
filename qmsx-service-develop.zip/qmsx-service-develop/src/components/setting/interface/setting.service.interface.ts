import { UpdateQCSettingBodyDto } from '../dto/request/update-qc-setting.request.dto';

export interface SettingServiceInterface {
  find(): Promise<any>;
  updateSetting(updateSetting: UpdateQCSettingBodyDto): Promise<any>;
}
