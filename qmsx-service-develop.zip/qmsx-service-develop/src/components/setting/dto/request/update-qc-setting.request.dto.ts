import {
  QC_SETTING_FORMAT,
  QC_SETTING_TODO_QUANTITY,
} from '@components/qc-execute/qc-execute.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional } from 'class-validator';

export class UpdateQCSettingBodyDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @IsEnum(QC_SETTING_FORMAT)
  settingFormat: number;

  @ApiProperty()
  @IsOptional()
  @IsEnum(QC_SETTING_TODO_QUANTITY)
  settingTodoQuantity: number;
}
