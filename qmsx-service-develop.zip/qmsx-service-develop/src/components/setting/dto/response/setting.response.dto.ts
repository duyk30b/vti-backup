import { BaseResponseDto } from '@core/dto/base.response.dto';
import { Expose } from 'class-transformer';

export class QCSettingResponseDto extends BaseResponseDto {
  @Expose()
  settingFormat: number;

  @Expose()
  settingTodoQuantity: number;
}
