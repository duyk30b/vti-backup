import { Body, Controller, Get, Inject, Put } from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { QCSettingResponseDto } from './dto/response/setting.response.dto';
import { SettingServiceInterface } from './interface/setting.service.interface';
import { UpdateQCSettingBodyDto } from './dto/request/update-qc-setting.request.dto';
import { isEmpty } from 'lodash';

@Controller('qc-settings')
export class SettingController {
  constructor(
    @Inject('SettingServiceInterface')
    private readonly settingService: SettingServiceInterface,
  ) {}

  @Get()
  @ApiOperation({
    tags: ['QC Setting - Cài đặt QC'],
    summary: 'Lấy thông tin cài đặt QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully',
    type: QCSettingResponseDto,
  })
  async findOne() {
    return await this.settingService.find();
  }

  @ApiOperation({
    tags: ['QC Setting - Cài đặt QC'],
    summary: 'Cập nhật QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully',
  })
  @Put()
  async update(@Body() updateSettingDto: UpdateQCSettingBodyDto) {
    const { request, responseError } = updateSettingDto;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.settingService.updateSetting(request);
  }
}
