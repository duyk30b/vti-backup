import { GetListCauseRequestDto } from '@components/cause/dto/request/get-list-cause.request.dto';
import { CauseRepositoryInterface } from '@components/cause/interface/cause.repository.interface';
import { GetListErrorGroupRequestDto } from '@components/error-group/dto/request/get-list-error-group.request.dto';
import { ErrorGroupRepositoryInterface } from '@components/error-group/interface/error-group.repository.interface';
import { GetListErrorRequestDto } from '@components/error/dto/request/get-list-error.request.dto';
import { ErrorRepositoryInterface } from '@components/error/interface/error.repository.interface';
import { GetListEvaluationCriteriaRequestDto } from '@components/evaluation-criteria/dto/request/get-list-evaluation-criteria.request.dto';
import { CHECK_TYPE } from '@components/evaluation-criteria/evaluation-criteria.constant';
import { EvaluationCriteriaRepositoryInterface } from '@components/evaluation-criteria/interface/evaluation-criteria.repository.interface';
import { GetListEvaluationFormRequestDto } from '@components/evaluation-form/dto/request/get-list-evaluation-form.request.dto';
import { IMPORTANT } from '@components/evaluation-form/evaluation-form.constant';
import { ItemService } from '@components/item/item.service';
import { GetListQCCommandRequestDto } from '@components/qc-command/dto/request/get-list-qc-command.request.dto';
import { QCCommandRepositoryInterface } from '@components/qc-command/interface/qc-command.repository.interface';
import {
  QC_COMMAND_STATUS,
  REVIEW_TYPE,
} from '@components/qc-command/qc-command.constant';
import { QCExecuteRepositoryInterface } from '@components/qc-execute/interface/qc-execute.repository.interface';
import { QC_STATUS } from '@components/qc-execute/qc-execute.constant';
import { GetQCCommandReportRequestDto } from '@components/qc-report/dto/request/get-qc-command-report.request.dto';
import { GetListQCRequestRequestDto } from '@components/qc-request/dto/request/get-list-qc-request.request.dto';
import { QCRequestRepositoryInterface } from '@components/qc-request/interface/qc-request.repository.interface';
import {
  PROPOSE_PROCESS,
  REQUEST_SOURCE,
  REQUEST_TYPE_MAP,
} from '@components/qc-request/qc-request.constant';
import { GetListTicketReportErrorRequestDto } from '@components/ticket-report-error/dto/request/get-list-ticket-report-error.request.dto';
import { TicketReportErrorRepositoryInterface } from '@components/ticket-report-error/interface/ticket-report-error.repository.interface';
import { TICKET_REPORT_ERROR_STATUS } from '@components/ticket-report-error/ticket-report-error.constant';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ACTIVE_ENUM, DATE_FORMAT_EXPORT } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { Alignment, Borders, Font, Workbook } from 'exceljs';
import {
  compact,
  concat,
  filter,
  first,
  flatten,
  forEach,
  isEmpty,
  keyBy,
  map,
  maxBy,
  minBy,
  uniq,
} from 'lodash';
import * as moment from 'moment';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { QCCommand } from 'src/models/qc-command/qc-command.schema';
import { ExportRequestDto } from './dto/request/export.request.dto';
import {
  EXCEL_STYLE,
  MAX_NUMBER_PAGE,
  REQUEST_TYPE_OPTIONS_MAP,
  ROW,
  SHEET,
  TypeEnum,
} from './export.constant';
import { ExportServiceInterface } from './interface/export.service.interface';
@Injectable()
export class ExportService implements ExportServiceInterface {
  constructor(
    @Inject('CauseRepositoryInterface')
    private readonly causeRepository: CauseRepositoryInterface,

    @Inject('ErrorRepositoryInterface')
    private readonly errorRepository: ErrorRepositoryInterface,

    @Inject('ErrorGroupRepositoryInterface')
    private readonly errorGroupRepository: ErrorGroupRepositoryInterface,

    @Inject('EvaluationFormRepositoryInterface')
    private readonly evaluationFormRepository: ErrorGroupRepositoryInterface,

    @Inject('ItemService')
    private readonly itemService: ItemService,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('EvaluationCriteriaRepositoryInterface')
    private readonly evaluationCriteriaRepository: EvaluationCriteriaRepositoryInterface,

    @Inject('QCRequestRepositoryInterface')
    private readonly qcRequestRepository: QCRequestRepositoryInterface,

    @Inject('QCCommandRepositoryInterface')
    private readonly qcCommandRepository: QCCommandRepositoryInterface,

    @Inject('QCExecuteRepositoryInterface')
    private readonly qcExecuteRepository: QCExecuteRepositoryInterface,

    @Inject('TicketReportErrorRepositoryInterface')
    private readonly ticketReportErrorRepository: TicketReportErrorRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async export(request: any): Promise<any> {
    const { queryIds, type } = request;

    if (!isEmpty(queryIds) && queryIds.length > ROW.LIMIT_EXPORT) {
      return new ResponseBuilder()
        .withMessage(
          await this.i18n.translate('error.LIMIT_EXPORT_ONE_SHEET_ERROR'),
        )
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }

    let workbook;
    switch (type) {
      case TypeEnum.ERROR:
        workbook = await this.exportError(request);
        break;
      case TypeEnum.ERROR_GROUP:
        workbook = await this.exportErrorGroup(request);
        break;
      case TypeEnum.CAUSE:
        workbook = await this.exportCauses(request);
        break;
      case TypeEnum.EVALUATION_FORM:
        workbook = await this.exportEvaluationForm(request);
        break;
      case TypeEnum.EVALUATION_CRITERIA:
        workbook = await this.exportEvaluationCriteria(request);
        break;
      case TypeEnum.QC_REQUEST:
        workbook = await this.exportQCRequest(request);
        break;
      case TypeEnum.QC_COMMAND:
        workbook = await this.exportQCCommand(request);
        break;
      case TypeEnum.QC_EXECUTE:
        workbook = await this.exportQcExecute(request);
        break;
      case TypeEnum.TICKET_REPORT_ERROR:
        workbook = await this.exportTicketReportError(request);
        break;
      case TypeEnum.QC_QUALITY_REPORT:
        workbook = await this.exportQCQualityReport(request);
        break;
      case TypeEnum.QC_COMAND_REPORT:
        workbook = await this.exportQCCommandReport(request);
        break;
      default:
        break;
    }

    if (workbook?.xlsx) {
      await workbook.xlsx.writeFile('excel.xlsx');
      const file = await workbook.xlsx.writeBuffer();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .withData(file)
        .build();
    } else {
      return workbook;
    }
  }

  async exportTemplate(request: any): Promise<any> {
    const { type } = request;

    const workbook = new Workbook();
    switch (type) {
      case TypeEnum.ERROR:
        await workbook.xlsx.readFile('src/assets/error-template-import.xlsx');
        break;
      case TypeEnum.ERROR_GROUP:
        await workbook.xlsx.readFile(
          'src/assets/error-group-template-import.xlsx',
        );
        break;
      case TypeEnum.CAUSE:
        await workbook.xlsx.readFile('src/assets/cause-template-import.xlsx');
        break;
      case TypeEnum.EVALUATION_FORM:
        await workbook.xlsx.readFile(
          'src/assets/evaluation-form-template-import.xlsx',
        );
        break;
      case TypeEnum.EVALUATION_CRITERIA:
        await workbook.xlsx.readFile(
          'src/assets/evaluation-criteria-template-import.xlsx',
        );
        break;
      case TypeEnum.QC_REQUEST:
        await workbook.xlsx.readFile(
          'src/assets/qc-request-template-import.xlsx',
        );
        break;
      default:
        break;
    }

    if (workbook?.xlsx) {
      await workbook.xlsx.writeFile('excel-template.xlsx');
      const file = await workbook.xlsx.writeBuffer();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .withData(file)
        .build();
    } else {
      return workbook;
    }
  }

  async exportError(payload: ExportRequestDto) {
    let errors = [];
    const titleMap: any = new Map();
    const headersMap: any = new Map();
    const sheetName: any = new Map();

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListErrorRequestDto();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id');
      }
      request.user = payload.user;
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      const { data } = await this.errorRepository.getList(request);
      if (!isEmpty(data)) {
        errors = errors.concat(data);
      }
      if (data?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    let userIds = [];
    userIds = compact(uniq(userIds));

    let itemsSheetTwo = [];

    for (let index = 0; index < errors.length; index++) {
      const error = errors[index];
      const data = await this.causeRepository.findAllByCondition({
        code: { $in: error?.causCodes },
      });

      const dataSub = data.map((item) => {
        return {
          code_error: error.code,
          code_cause: item.code,
          level: 2,
        };
      });

      itemsSheetTwo = itemsSheetTwo.concat(dataSub);
      error.subItem = [...dataSub];
    }

    // const users = await this.userService.getList([
    //   { column: 'userIds', text: userIds.join(',') },
    // ]);

    // const userMap = keyBy(users, 'id');

    const columnSettings = JSON.parse(payload.columnSettings);
    const errorText = await this.i18n.translate('export.error');

    const headerMainSheet = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      title: errorText[el],
    }));
    const headerSecondSheet = [
      {
        key: 'code_error',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: errorText['code'],
      },
      {
        key: 'code_cause',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: errorText['cause']['code_cause'],
      },
    ];

    const textCommon = await this.i18n.translate('export.common');

    const itemsSheetOne = errors.map((error) => ({
      code: error?.code,
      name: error?.name,
      description: error?.description,
      active:
        error?.active === ACTIVE_ENUM.ACTIVE
          ? textCommon.active
          : textCommon.inactive,
      subItem: [...error.subItem],
      level: 1,
    }));

    titleMap.set(1, [await this.i18n.translate('export.error.title')]);
    titleMap.set(2, [await this.i18n.translate('export.error.cause.title')]);
    headersMap.set(1, headerMainSheet);
    headersMap.set(2, headerSecondSheet);
    sheetName.set(1, await this.i18n.translate('export.error.sheetName'));
    sheetName.set(2, await this.i18n.translate('export.error.cause.sheetName'));

    let workbook = new Workbook();
    workbook = await this.exportMultiSheetUtil(
      workbook,
      itemsSheetOne,
      1,
      titleMap,
      headersMap,
      sheetName,
    );
    return workbook;
  }

  async exportErrorGroup(payload: ExportRequestDto) {
    let errorGroups = [];
    const titleMap: any = new Map();
    const headersMap: any = new Map();
    const sheetName: any = new Map();

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListErrorGroupRequestDto();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id');
      }
      request.user = payload.user;
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      const { data } = await this.errorGroupRepository.getList(request);
      if (!isEmpty(data)) {
        errorGroups = errorGroups.concat(data);
      }
      if (data?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    let itemsSheetTwo = [];

    for (let index = 0; index < errorGroups.length; index++) {
      const errorGroup = errorGroups[index];
      const data = await this.errorRepository.findAllByCondition({
        code: { $in: errorGroup?.errorCodes },
      });

      const dataSub = data.map((item) => {
        return {
          code_error_group: errorGroup.code,
          code_error: item.code,
          level: 2,
        };
      });

      itemsSheetTwo = itemsSheetTwo.concat(dataSub);
      errorGroup.subItem = [...dataSub];
    }

    // let userIds = [];
    // userIds = compact(uniq(userIds));

    // const users = await this.userService.getList([
    //   { column: 'userIds', text: userIds.join(',') },
    // ]);

    // const userMap = keyBy(users, 'id');

    const columnSettings = JSON.parse(payload.columnSettings);
    const errorGroupText = await this.i18n.translate('export.errorGroup');

    const headerMainSheet = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      title: errorGroupText[el],
    }));
    const headerSecondSheet = [
      {
        key: 'code_error_group',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: errorGroupText['code'],
      },
      {
        key: 'code_error',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: errorGroupText['error']['code_error'],
      },
    ];

    const textCommon = await this.i18n.translate('export.common');
    const itemsSheetOne = errorGroups.map((errorGroup) => ({
      code: errorGroup?.code,
      name: errorGroup?.name,
      description: errorGroup?.description,
      active:
        errorGroup?.active === ACTIVE_ENUM.ACTIVE
          ? textCommon.active
          : textCommon.inactive,
      subItem: [...errorGroup.subItem],
      level: 1,
    }));

    titleMap.set(1, [await this.i18n.translate('export.errorGroup.title')]);
    titleMap.set(2, [
      await this.i18n.translate('export.errorGroup.error.title'),
    ]);
    headersMap.set(1, headerMainSheet);
    headersMap.set(2, headerSecondSheet);
    sheetName.set(1, await this.i18n.translate('export.errorGroup.sheetName'));
    sheetName.set(
      2,
      await this.i18n.translate('export.errorGroup.error.sheetName'),
    );

    let workbook = new Workbook();
    workbook = await this.exportMultiSheetUtil(
      workbook,
      itemsSheetOne,
      1,
      titleMap,
      headersMap,
      sheetName,
    );
    return workbook;
  }

  async exportEvaluationForm(payload: ExportRequestDto) {
    const textCommon = await this.i18n.translate('export.common');
    let evaluationForms = [];
    const titleMap: any = new Map();
    const headersMap: any = new Map();
    const sheetName: any = new Map();

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListEvaluationFormRequestDto();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id');
      }
      request.user = payload.user;
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      const { data } = await this.evaluationFormRepository.getList(request);
      if (!isEmpty(data)) {
        evaluationForms = evaluationForms.concat(data);
      }
      if (data?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }
    let itemsSheetTwo = [];

    for (let index = 0; index < evaluationForms.length; index++) {
      const evaluationForm = evaluationForms[index];

      const dataSub = evaluationForm.evaluations.map((item) => {
        return {
          code_evaluation_form: evaluationForm.code,
          code_evaluation_criteria: item.code,
          important:
            item.important === IMPORTANT.YES ? textCommon.yes : textCommon.no,
          level: 2,
        };
      });

      itemsSheetTwo = itemsSheetTwo.concat(dataSub);
      evaluationForm.subItem = [...dataSub];
    }

    const itemTypeList = await this.itemService.getItemTypeList({});

    const columnSettings = JSON.parse(payload.columnSettings);
    const evaluationFormText = await this.i18n.translate(
      'export.evaluationForm',
    );

    const headerMainSheet = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      title: evaluationFormText[el],
    }));

    const headerSecondSheet = [
      {
        key: 'code_evaluation_form',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: evaluationFormText['code'],
      },
      {
        key: 'code_evaluation_criteria',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: evaluationFormText['evaluation_criteria']['code'],
      },
      {
        key: 'important',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: evaluationFormText['evaluation_criteria']['important'],
      },
    ];

    const itemsSheetOne = evaluationForms.map((evaluationForm) => {
      const item = itemTypeList?.items.filter(
        (itemType) => itemType.id === evaluationForm.itemId,
      );

      return {
        code: evaluationForm?.code,
        name: evaluationForm?.name,
        description: evaluationForm?.description,
        qcNumber: evaluationForm.qcNumber,
        qcQuantity: evaluationForm.qcQuantity,
        qcFormat: evaluationForm.qcFormat,
        itemTypeCode: item[0]?.code,
        active:
          evaluationForm?.active === ACTIVE_ENUM.ACTIVE
            ? textCommon.active
            : textCommon.inactive,
        subItem: [...evaluationForm.subItem],
        level: 1,
      };
    });

    titleMap.set(1, [await this.i18n.translate('export.evaluationForm.title')]);
    titleMap.set(2, [
      await this.i18n.translate(
        'export.evaluationForm.evaluation_criteria.title',
      ),
    ]);
    headersMap.set(1, headerMainSheet);
    headersMap.set(2, headerSecondSheet);
    sheetName.set(
      1,
      await this.i18n.translate('export.evaluationForm.sheetName'),
    );
    sheetName.set(
      2,
      await this.i18n.translate(
        'export.evaluationForm.evaluation_criteria.sheetName',
      ),
    );

    let workbook = new Workbook();
    workbook = await this.exportMultiSheetUtil(
      workbook,
      itemsSheetOne,
      1,
      titleMap,
      headersMap,
      sheetName,
    );
    return workbook;
  }

  async exportEvaluationCriteria(payload: ExportRequestDto) {
    let evaluationCriterias = [];
    const titleMap: any = new Map();
    const headersMap: any = new Map();
    const sheetName: any = new Map();

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListEvaluationCriteriaRequestDto();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id');
      }
      request.user = payload.user;
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      const { data } = await this.evaluationCriteriaRepository.getList(request);
      if (!isEmpty(data)) {
        evaluationCriterias = evaluationCriterias.concat(data);
      }
      if (data?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    let userIds = [];
    userIds = compact(uniq(userIds));

    let itemsSheetTwo = [];

    for (let index = 0; index < evaluationCriterias.length; index++) {
      const evaluationCriteria = evaluationCriterias[index];
      const details = evaluationCriteria.details;
      const dataSub = details?.map((item) => {
        return {
          evaluationCriteriaCode: evaluationCriteria.code,
          name: item.name,
          code: item.errorCodes.join(', '),
          description: item.description,
          level: 2,
        };
      });

      itemsSheetTwo = itemsSheetTwo.concat(dataSub);
      evaluationCriteria.subItem = [...dataSub];
    }

    const columnSettings = JSON.parse(payload.columnSettings);
    const evaluationCriteriaText = await this.i18n.translate(
      'export.evaluationCriteria',
    );

    const headerMainSheet = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      title: evaluationCriteriaText[el],
    }));
    const headerSecondSheet = [
      {
        key: 'evaluationCriteriaCode',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: evaluationCriteriaText['code'],
      },
      {
        key: 'name',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: evaluationCriteriaText['detail']['name'],
      },
      {
        key: 'code',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: evaluationCriteriaText['detail']['code'],
      },
      {
        key: 'description',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: evaluationCriteriaText['detail']['description'],
      },
    ];

    const textCommon = await this.i18n.translate('export.common');

    const itemsSheetOne = evaluationCriterias.map((evaluationCriteria) => ({
      code: evaluationCriteria?.code,
      name: evaluationCriteria?.name,
      checkType:
        evaluationCriteria?.checkType === CHECK_TYPE.MEASURE
          ? evaluationCriteriaText.measure
          : evaluationCriteriaText.status,
      norm:
        evaluationCriteria?.checkType === CHECK_TYPE.STATUS
          ? ''
          : evaluationCriteria?.norm || '',
      upperBound:
        evaluationCriteria?.checkType === CHECK_TYPE.STATUS
          ? ''
          : evaluationCriteria?.upperBound || '',
      lowerBound:
        evaluationCriteria?.checkType === CHECK_TYPE.STATUS
          ? ''
          : evaluationCriteria?.lowerBound || '',
      description: evaluationCriteria?.description,
      active:
        evaluationCriteria?.active === ACTIVE_ENUM.ACTIVE
          ? textCommon.active
          : textCommon.inactive,
      subItem: [...evaluationCriteria.subItem],
      level: 1,
    }));

    titleMap.set(1, [
      await this.i18n.translate('export.evaluationCriteria.title'),
    ]);
    titleMap.set(2, [
      await this.i18n.translate('export.evaluationCriteria.detail.title'),
    ]);
    headersMap.set(1, headerMainSheet);
    headersMap.set(2, headerSecondSheet);
    sheetName.set(
      1,
      await this.i18n.translate('export.evaluationCriteria.sheetName'),
    );
    sheetName.set(
      2,
      await this.i18n.translate('export.evaluationCriteria.detail.name'),
    );

    let workbook = new Workbook();
    workbook = await this.exportMultiSheetUtil(
      workbook,
      itemsSheetOne,
      1,
      titleMap,
      headersMap,
      sheetName,
    );
    return workbook;
  }

  async exportQCRequest(payload: ExportRequestDto) {
    let qcRequests = [];
    const titleMap: any = new Map();
    const headersMap: any = new Map();
    const sheetName: any = new Map();

    const columnSettings = JSON.parse(payload.columnSettings);
    const qcRequestText = await this.i18n.translate('export.qcRequest');

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListQCRequestRequestDto();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id');
      }
      request.user = payload.user;
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      const { data } = await this.qcRequestRepository.getList(request);
      if (!isEmpty(data)) {
        qcRequests = qcRequests.concat(data);
      }
      if (data?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    const userIds = uniq(compact(map(qcRequests, 'requestBy')));

    // Filter by user id
    const userIdFilters = [
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ];

    let users: any = [];
    if (!isEmpty(userIds)) {
      users = await this.userService.getList(userIdFilters);
      users = keyBy(users, 'id');
    }

    const itemCodes = uniq(
      compact(map(flatten(map(qcRequests, 'items')), 'code')),
    );
    let itemList: any = [];
    if (!isEmpty(itemCodes)) {
      const request = {
        codes: itemCodes.join(','),
      };
      itemList = await this.itemService.getItemList(request);
      itemList = keyBy(itemList, 'code');
    }

    for (let index = 0; index < qcRequests.length; index++) {
      const qcRequest = qcRequests[index];
      const details = qcRequest.items;

      const dataSub = details?.map((item) => {
        return {
          qcRequestCode: qcRequest?.code,
          itemType: itemList[item.code]?.itemType?.name,
          itemCode: item.code,
          itemName: itemList[item.code]?.name,
          checkType:
            item.checkType === CHECK_TYPE.MEASURE
              ? qcRequestText['items']['measure']
              : qcRequestText['items']['status'],
          lot: item.lot,
          planQuantity: Intl.NumberFormat('en-US').format(
            item?.planQuantity || 0,
          ),
          unitCode: itemList[item.code]?.itemUnit?.name,
          level: 2,
        };
      });

      qcRequest.subItem = [...dataSub];
      qcRequest.requestType = this.i18n.translate(
        `export.${REQUEST_TYPE_OPTIONS_MAP[qcRequest.requestType]}`,
      );
    }

    const headerMainSheet = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      title: qcRequestText[el],
    }));
    const headerSecondSheet = [
      {
        key: 'qcRequestCode',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: qcRequestText.code,
      },
      {
        key: 'itemType',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: qcRequestText['items']['itemType'],
      },
      {
        key: 'itemCode',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: qcRequestText['items']['itemCode'],
      },
      {
        key: 'itemName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: qcRequestText['items']['itemName'],
      },
      {
        key: 'checkType',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: qcRequestText['items']['checkType'],
      },
      {
        key: 'lot',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: qcRequestText['items']['lot'],
      },
      {
        key: 'planQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: qcRequestText['items']['planQuantity'],
      },
      {
        key: 'unitCode',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: qcRequestText['items']['unitCode'],
      },
    ];

    const itemsSheetOne = qcRequests.map((qcRequest) => ({
      code: qcRequest?.code,
      name: qcRequest?.name,
      requestSource:
        qcRequest?.requestSource === REQUEST_SOURCE.MESX
          ? qcRequestText.mesx
          : qcRequest?.requestSource === REQUEST_SOURCE.WMSX
          ? qcRequestText.wmsx
          : qcRequestText.qmsx,
      requestType: qcRequest?.requestType,
      ticketCode: qcRequest?.ticketCode || '',
      ticketName: '', // TBD
      requestBy: users[qcRequest?.requestBy]?.fullName,
      returnDate: qcRequest?.returnDate,
      workOrderCode: '', // TBD
      proposeProcess:
        qcRequest?.proposeProcess === PROPOSE_PROCESS.NO
          ? qcRequestText.no
          : qcRequestText.yes,
      createdAt: qcRequest?.createdAt,
      description: qcRequest?.description,
      subItem: [...qcRequest.subItem],
      level: 1,
    }));

    titleMap.set(1, [await this.i18n.translate('export.qcRequest.title')]);
    titleMap.set(2, [
      await this.i18n.translate('export.qcRequest.items.title'),
    ]);
    headersMap.set(1, headerMainSheet);
    headersMap.set(2, headerSecondSheet);
    sheetName.set(1, await this.i18n.translate('export.qcRequest.sheetName'));
    sheetName.set(
      2,
      await this.i18n.translate('export.qcRequest.items.sheetName'),
    );

    let workbook = new Workbook();
    workbook = await this.exportMultiSheetUtil(
      workbook,
      itemsSheetOne,
      1,
      titleMap,
      headersMap,
      sheetName,
    );
    return workbook;
  }

  async exportQCCommand(payload: ExportRequestDto) {
    let qcCommands = [];
    let qcCommandCodes = [];
    let qcRequestCodes = [];
    const titleMap: any = new Map();
    const headersMap: any = new Map();

    const columnSettings = JSON.parse(payload.columnSettings);
    const qcCommandText = await this.i18n.translate('export.qcCommand');

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListQCCommandRequestDto();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id');
      }
      request.user = payload.user;
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      const { data } = await this.qcCommandRepository.getList(request);
      if (!isEmpty(data)) {
        qcCommands = qcCommands.concat(data);
        qcCommandCodes = qcCommandCodes.concat(map(data, 'code'));
        qcRequestCodes = qcRequestCodes.concat(map(data, 'qcRequestCode'));
      }
      if (data?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }
    qcRequestCodes = uniq(qcRequestCodes);

    let qcRequests: any = await this.qcRequestRepository.findAllByCondition({
      code: { $in: qcRequestCodes },
    });
    qcRequests = keyBy(qcRequests, 'code');

    qcCommandCodes = uniq(qcCommandCodes);
    let qcExecutes: any = await this.qcExecuteRepository.findAllByCondition({
      qcCommandCode: { $in: qcCommandCodes },
    });

    const createdBy = uniq(compact(map(qcCommands, 'createdBy')));
    const qcBy = uniq(compact(flatten(map(qcExecutes, 'qcBy'))));
    const userIds = uniq(concat(createdBy, qcBy));

    // Filter by user id
    const userIdFilters = [
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ];

    let users = [];
    let userKeys: any = [];
    if (!isEmpty(userIds)) {
      users = await this.userService.getList(userIdFilters);
      userKeys = keyBy(users, 'id');
    }

    const itemCodes = uniq(compact(map(qcExecutes, 'itemCode')));
    let itemList: any = [];
    if (!isEmpty(itemCodes)) {
      const request = {
        codes: itemCodes.join(','),
      };
      itemList = await this.itemService.getItemList(request);
      itemList = keyBy(itemList, 'code');
    }

    const evaluationCriteriaCodes = uniq(
      compact(flatten(map(qcExecutes, 'evaluationCriterias'))),
    );

    const evaluationCriterias: any =
      await this.evaluationCriteriaRepository.findAllByCondition({
        code: { $in: evaluationCriteriaCodes },
      });

    qcExecutes = qcExecutes?.map((item) => {
      return {
        qcCommandCode: item.qcCommandCode,
        itemName: itemList[item.itemCode]?.name,
        lot: item.lot,
        reviewType:
          item.reviewType === REVIEW_TYPE.EVALUATION_FORM
            ? qcCommandText['items']['evaluationForm']
            : qcCommandText['items']['evaluationCriteria'],
        evaluationCriterias: map(
          filter(evaluationCriterias, (evaluationCriteria) => {
            return item.evaluationCriterias.indexOf(evaluationCriteria);
          }),
          'name',
        )?.join(', '),
        qcNumber: item.qcNumber,
        qcBy: map(
          filter(users, (user) => {
            return item.qcBy?.indexOf(user.id) > -1;
          }),
          'fullName',
        )?.join(', '),
        startDateEndDate: `${moment(item.startDate).format(
          DATE_FORMAT_EXPORT,
        )}${' - '}${moment(item.endDate).format(DATE_FORMAT_EXPORT)}`,
        planQuantity: item.planQuantity,
        todoQuantity: item.todoQuantity,
        testedQuantity: item.testedQuantity,
        passQuantity: item.passQuantity,
        failQuantity: item.failQuantity,
        level: 2,
      };
    });

    const headerMainSheet = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      title: qcCommandText[el],
    }));

    const headerSecondSheet = [
      {
        key: 'itemName',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: qcCommandText['items']['itemName'],
      },
      {
        key: 'lot',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: qcCommandText['items']['lot'],
      },
      {
        key: 'reviewType',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: qcCommandText['items']['reviewType'],
      },
      {
        key: 'evaluationCriterias',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: qcCommandText['items']['evaluationCriterias'],
      },
      {
        key: 'qcNumber',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: qcCommandText['items']['qcNumber'],
      },
      {
        key: 'qcBy',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: qcCommandText['items']['qcBy'],
      },
      {
        key: 'startDateEndDate',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: qcCommandText['items']['startDateEndDate'],
      },
      {
        key: 'planQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: qcCommandText['items']['planQuantity'],
      },
      {
        key: 'todoQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: qcCommandText['items']['todoQuantity'],
      },
      {
        key: 'testedQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: qcCommandText['items']['testedQuantity'],
      },
      {
        key: 'passQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: qcCommandText['items']['passQuantity'],
      },
      {
        key: 'failQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: qcCommandText['items']['failQuantity'],
      },
    ];

    const itemsSheetOne = qcCommands.map((qcCommand: QCCommand) => ({
      code: qcCommand?.code,
      name: qcCommand?.name,
      status:
        qcCommand?.status === QC_COMMAND_STATUS.DRAFT
          ? qcCommandText.draft
          : qcCommand?.status === QC_COMMAND_STATUS.WAITING
          ? qcCommandText.waiting
          : qcCommand?.status === QC_COMMAND_STATUS.CONFIRMED
          ? qcCommandText.confirmed
          : qcCommand?.status === QC_COMMAND_STATUS.REJECTED
          ? qcCommandText.rejected
          : qcCommand?.status === QC_COMMAND_STATUS.IN_PROGRESS
          ? qcCommandText.inProgress
          : qcCommandText.completed,
      startDateEndDate: `${moment(
        minBy(qcCommand?.items, 'startDate')?.startDate,
      ).format(DATE_FORMAT_EXPORT)}${' - '}${moment(
        maxBy(qcCommand?.items, 'endDate')?.endDate,
      ).format(DATE_FORMAT_EXPORT)}`,
      deadline: moment(qcRequests[qcCommand?.qcRequestCode]?.returnDate).format(
        DATE_FORMAT_EXPORT,
      ),
      createdBy: userKeys[qcCommand?.createdBy]?.fullName,
      qcRequest: qcRequests[qcCommand?.qcRequestCode]?.name,
      requestSource:
        qcRequests[qcCommand?.qcRequestCode]?.requestSource ===
        REQUEST_SOURCE.MESX
          ? qcCommandText.mesx
          : qcRequests[qcCommand?.qcRequestCode]?.requestSource ===
            REQUEST_SOURCE.WMSX
          ? qcCommandText.wmsx
          : qcCommandText.qmsx,
      requestType: qcRequests[qcCommand?.qcRequestCode]?.requestType,
      createdAt: qcCommand?.createdAt,
      subItem: filter(qcExecutes, { qcCommandCode: qcCommand?.code }),
      level: 1,
    }));

    titleMap.set(1, [await this.i18n.translate('export.qcCommand.title')]);
    titleMap.set(2, [
      await this.i18n.translate('export.qcCommand.items.title'),
    ]);
    headersMap.set(1, headerMainSheet);
    headersMap.set(2, headerSecondSheet);

    let workbook = new Workbook();
    workbook = await this.exportMultiSheetUtil(
      workbook,
      itemsSheetOne,
      1,
      titleMap,
      headersMap,
    );
    return workbook;
  }

  async exportTicketReportError(payload: ExportRequestDto) {
    let ticketReportErrors = [];
    const titleMap: any = new Map();
    const headersMap: any = new Map();

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListTicketReportErrorRequestDto();
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id');
      }
      request.user = payload.user;
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.sort = payload.sort;
      request.keyword = payload.keyword;
      const { data } = await this.ticketReportErrorRepository.getList(request);
      if (!isEmpty(data)) {
        ticketReportErrors = ticketReportErrors.concat(data);
      }
      if (data?.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    const userIds = uniq(map(ticketReportErrors, 'createdBy'));
    // Filter by user id
    const userIdFilters = [
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ];

    let users: any = [];
    if (!isEmpty(userIds)) {
      users = await this.userService.getList(userIdFilters);
      users = keyBy(users, 'id');
    }

    const qcCommandCodes = uniq(map(ticketReportErrors, 'qcCommandCode'));
    let qcCommands: any = [];
    if (!isEmpty(qcCommandCodes)) {
      qcCommands = await this.qcCommandRepository.findAllByCondition({
        code: { $in: qcCommandCodes },
      });
      qcCommands = keyBy(qcCommands, 'code');
    }

    let qcExecutes: any = [];
    if (!isEmpty(qcCommandCodes)) {
      qcExecutes = await this.qcExecuteRepository.findAllByCondition({
        qcCommandCode: { $in: qcCommandCodes },
      });
    }

    const itemCodes = uniq(map(qcExecutes, 'itemCode'));
    let itemList: any = [];
    if (!isEmpty(itemCodes)) {
      const request = {
        codes: itemCodes.join(','),
      };
      itemList = await this.itemService.getItemList(request);
      itemList = keyBy(itemList, 'code');
    }

    forEach(qcExecutes, (qcExecute) => {
      qcExecute.itemName = itemList[qcExecute.itemCode]?.name;
    });

    const columnSettings = JSON.parse(payload.columnSettings);
    const ticketReportErrorText = await this.i18n.translate(
      'export.ticketReportError',
    );

    const headerMainSheet = columnSettings?.map((el: string) => ({
      key: el,
      width: 25,
      style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      title: ticketReportErrorText[el],
    }));
    const headerSecondSheet = [
      {
        key: 'itemCode',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: ticketReportErrorText['items']['itemCode'],
      },
      {
        key: 'itemName',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: ticketReportErrorText['items']['itemName'],
      },
      {
        key: 'lot',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: ticketReportErrorText['items']['lot'],
      },
      {
        key: 'planQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: ticketReportErrorText['items']['planQuantity'],
      },
      {
        key: 'todoQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: ticketReportErrorText['items']['todoQuantity'],
      },
      {
        key: 'testedQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: ticketReportErrorText['items']['testedQuantity'],
      },
      {
        key: 'passQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: ticketReportErrorText['items']['passQuantity'],
      },
      {
        key: 'failQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: ticketReportErrorText['items']['failQuantity'],
      },
    ];

    const itemsSheetOne = ticketReportErrors.map((ticketReportError) => ({
      code: ticketReportError?.code,
      qcCommandCode: ticketReportError?.qcCommandCode,
      qcCommandName: qcCommands[ticketReportError?.qcCommandCode]?.name,
      createdBy: users[ticketReportError?.createdBy]?.fullName,
      createdAt: ticketReportError?.createdAt,
      subItem: [...qcExecutes],
      status:
        ticketReportError?.status === TICKET_REPORT_ERROR_STATUS.TODO
          ? ticketReportErrorText.todo
          : ticketReportError?.status === TICKET_REPORT_ERROR_STATUS.IN_PROGRESS
          ? ticketReportErrorText.inProgress
          : ticketReportError?.status === TICKET_REPORT_ERROR_STATUS.DONE
          ? ticketReportErrorText.done
          : ticketReportErrorText.finished,
      level: 1,
    }));

    titleMap.set(1, [
      await this.i18n.translate('export.ticketReportError.title'),
    ]);
    titleMap.set(2, [
      await this.i18n.translate('export.ticketReportError.items.title'),
    ]);
    headersMap.set(1, headerMainSheet);
    headersMap.set(2, headerSecondSheet);

    let workbook = new Workbook();
    workbook = await this.exportMultiSheetUtil(
      workbook,
      itemsSheetOne,
      1,
      titleMap,
      headersMap,
    );
    return workbook;
  }

  async exportQCQualityReport(payload: ExportRequestDto) {
    let qcQualityReports: any = [];
    const qcQualityReportText = await this.i18n.translate(
      'export.qcQualityReport',
    );

    const request = new GetListCauseRequestDto();
    request.page = payload.page;
    if (payload.queryIds) {
      request.queryIds = map(JSON.parse(payload.queryIds), 'id');
    }
    request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
    request.filter = payload.filter;
    request.sort = payload.sort;

    const { data } = await this.qcExecuteRepository.getList(request);

    // Filter by item code
    const itemCodes = uniq(compact(map(data, 'itemCode')));
    let itemList: any = [];
    if (!isEmpty(itemCodes)) {
      const request = {
        codes: itemCodes.join(','),
      };
      itemList = await this.itemService.getItemList(request);
      itemList = keyBy(itemList, 'code');
    }

    // Filter by qcCommand code
    const qcCommandCodes = uniq(compact(map(data, 'qcCommandCode')));
    let qcCommandList: any = [];
    if (!isEmpty(itemCodes)) {
      qcCommandList = await this.qcCommandRepository.findAllByCondition({
        code: {
          $in: qcCommandCodes,
        },
      });
      qcCommandList = keyBy(qcCommandList, 'code');
    }

    qcQualityReports = map(data, (item) => {
      return {
        itemCode: item.itemCode,
        itemName: itemList[item.itemCode]?.name,
        lot: item.lot || '',
        qcCommandCode: item.qcCommandCode,
        qcCommandName: qcCommandList[item.qcCommandCode]?.name,
        qcNumber: `${item.progress}/${item.qcNumber}`,
        planQuantityCommand: item.planQuantity,
        todoQuantity: item.todoQuantity,
        testedQuantity: item.testedQuantity,
        failQuantity: item.failQuantity,
        passQuantity: item.passQuantity,
        status:
          item.status === QC_STATUS.NOT
            ? qcQualityReportText.not
            : item.status === QC_STATUS.DOING
            ? qcQualityReportText.doing
            : qcQualityReportText.done,
      };
    });

    const headers = [
      {
        key: 'itemCode',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcQualityReport.itemCode'),
      },
      {
        key: 'itemName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcQualityReport.itemName'),
      },
      {
        key: 'lot',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcQualityReport.lot'),
      },
      {
        key: 'qcCommandCode',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.qcQualityReport.qcCommandCode',
        ),
      },
      {
        key: 'qcCommandName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.qcQualityReport.qcCommandName',
        ),
      },
      {
        key: 'qcNumber',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcQualityReport.qcNumber'),
      },
      {
        key: 'planQuantityCommand',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.qcQualityReport.planQuantityCommand',
        ),
      },
      {
        key: 'todoQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcQualityReport.todoQuantity'),
      },
      {
        key: 'testedQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.qcQualityReport.testedQuantity',
        ),
      },
      {
        key: 'failQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcQualityReport.failQuantity'),
      },
      {
        key: 'passQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcQualityReport.passQuantity'),
      },
      {
        key: 'status',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcQualityReport.status'),
      },
    ];

    const workbook = await this.exportOneSheetUtil(
      qcQualityReports,
      [await this.i18n.translate('export.qcQualityReport.title')],
      headers,
    );

    return workbook;
  }

  async exportQCCommandReport(payload: ExportRequestDto) {
    let qcCommandReports: any = [];
    const qcCommandReportText = await this.i18n.translate(
      'export.qcCommandReport',
    );

    const request = new GetQCCommandReportRequestDto();
    request.page = payload.page;
    if (payload.queryIds) {
      request.queryIds = map(JSON.parse(payload.queryIds), 'id');
    }
    request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
    request.filter = payload.filter;
    request.sort = payload.sort;

    const { data } = await this.qcCommandRepository.getQCCommandReport(request);

    const userIds = uniq(map(data, 'createdBy'));
    // Filter by user id
    const userIdFilters = [
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ];

    let users: any = [];
    if (!isEmpty(userIds)) {
      users = await this.userService.getList(userIdFilters);
      users = keyBy(users, 'id');
    }

    qcCommandReports = map(data, (item) => {
      return {
        requestSource:
          item.requestSource === REQUEST_SOURCE.MESX
            ? qcCommandReportText.mesx
            : item.requestSource === REQUEST_SOURCE.WMSX
            ? qcCommandReportText.wmsx
            : qcCommandReportText.qmsx,
        requestType: qcCommandReportText[REQUEST_TYPE_MAP[item.requestType]],
        qcCommandCode: item.code,
        qcCommandName: item.name,
        startDateEndDate: `${moment(item.startDate).format(
          DATE_FORMAT_EXPORT,
        )} - ${moment(item.endDate).format(DATE_FORMAT_EXPORT)}`,
        deadline: moment(item.deadline).format(DATE_FORMAT_EXPORT),
        createdBy: users[item.createdBy].fullName,
        createdAt: moment(item.createdAt).format(DATE_FORMAT_EXPORT),
      };
    });

    const headers = [
      {
        key: 'requestSource',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.qcCommandReport.requestSource',
        ),
      },
      {
        key: 'requestType',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcCommandReport.requestType'),
      },
      {
        key: 'qcCommandCode',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.qcCommandReport.qcCommandCode',
        ),
      },
      {
        key: 'qcCommandName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.qcCommandReport.qcCommandName',
        ),
      },
      {
        key: 'startDateEndDate',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.qcCommandReport.startDateEndDate',
        ),
      },
      {
        key: 'deadline',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcCommandReport.deadline'),
      },
      {
        key: 'createdBy',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcCommandReport.createdBy'),
      },
      {
        key: 'createdAt',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcCommandReport.createdAt'),
      },
    ];

    const workbook = await this.exportOneSheetUtil(
      qcCommandReports,
      [await this.i18n.translate('export.qcCommandReport.title')],
      headers,
    );

    return workbook;
  }

  async exportOneSheetUtil(data: any[], title: any, headers: any) {
    const workbook = new Workbook();
    let countRowData = ROW.COUNT_START_ROW;
    let countSheet = SHEET.START_SHEET;
    const tableColNum = headers.length;
    data.forEach((element) => {
      let worksheet = workbook.getWorksheet(SHEET.NAME + countSheet);
      if (countRowData == ROW.COUNT_START_ROW) {
        worksheet = workbook.addWorksheet(SHEET.NAME + countSheet);

        const titleRow = worksheet.getRow(2);
        titleRow.values = title;
        titleRow.font = <Font>EXCEL_STYLE.HEADER_FONT;
        titleRow.height = EXCEL_STYLE.TITLE_HEIGHT;
        titleRow.getCell(1).alignment = <Partial<Alignment>>(
          EXCEL_STYLE.ALIGN_CENTER
        );
        worksheet.mergeCellsWithoutStyle(2, 1, 2, tableColNum);

        const headerRow = worksheet.getRow(4);
        headerRow.values = headers.map((header) => header.title);
        headerRow.eachCell(function (cell) {
          cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
          cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        });
      }
      worksheet.columns = headers;
      worksheet
        .addRow({
          ...element,
        })
        .eachCell(function (cell) {
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          cell.font = <Font>EXCEL_STYLE.DEFAULT_FONT;
        });

      countRowData++;
      if (countRowData == ROW.COUNT_END_ROW) {
        countSheet++;
        countRowData = ROW.COUNT_START_ROW;
      }
    });
    return workbook;
  }

  async exportMultiSheetUtil(
    workbook: Workbook,
    items: any[],
    level: any,
    titleMap: any,
    headersMap: any,
    sheetName?: any,
  ) {
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      let worksheet = workbook.getWorksheet(
        sheetName ? sheetName.get(level) : SHEET.NAME + level,
      );
      if (!worksheet) {
        worksheet = workbook.addWorksheet(
          sheetName ? sheetName.get(level) : SHEET.NAME + level,
        );

        const titleRow = worksheet.getRow(1);
        titleRow.values = titleMap.get(level);
        titleRow.font = <Font>EXCEL_STYLE.TITLE_FONT;
        titleRow.height = EXCEL_STYLE.TITLE_HEIGHT;
        titleRow.getCell(1).alignment = <Partial<Alignment>>(
          EXCEL_STYLE.ALIGN_CENTER
        );

        const headerRow = worksheet.getRow(3);
        headerRow.values = headersMap.get(level).map((header) => header.title);
        headerRow.eachCell(function (cell) {
          cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
          cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        });
        worksheet.columns = headersMap.get(level);
        const tableColNum = headersMap.get(level).length;
        worksheet.mergeCellsWithoutStyle(1, 1, 1, tableColNum);
      }

      worksheet
        .addRow({
          ...item,
        })
        .eachCell(function (cell) {
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          cell.font = <Font>EXCEL_STYLE.DEFAULT_FONT;
        });
      if (item.subItem?.length > 0) {
        const getLevel = first(item.subItem)['level'] ?? level + 1;
        workbook = await this.exportMultiSheetUtil(
          workbook,
          item.subItem,
          getLevel,
          titleMap,
          headersMap,
          sheetName,
        );
      }

      if (item.subItemClone?.length > 0) {
        const getLevel = first(item.subItemClone)['level'] ?? level + 2;
        workbook = await this.exportMultiSheetUtil(
          workbook,
          item.subItemClone,
          getLevel,
          titleMap,
          headersMap,
        );
      }
    }

    return workbook;
  }

  async exportCauses(payload: ExportRequestDto) {
    let listCausesReport: any[] = [];
    const textCommon = await this.i18n.translate('export.common');

    const request = new GetListCauseRequestDto();
    request.page = payload.page;
    if (payload.queryIds) {
      request.queryIds = map(JSON.parse(payload.queryIds), 'id');
    }
    request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
    request.filter = payload.filter;
    request.sort = payload.sort;
    const { data } = await this.causeRepository.getList(request);

    if (!isEmpty(data)) {
      listCausesReport = listCausesReport.concat(data);
    }

    if (!listCausesReport || isEmpty(listCausesReport)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }
    const responseData = listCausesReport.map((i) => {
      return {
        code: i.code,
        name: i.name,
        description: i.description,
        isActive:
          i.isActive === ACTIVE_ENUM.ACTIVE
            ? textCommon.active
            : textCommon.inactive,
      };
    });

    const headers = [
      {
        key: 'code',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.cause.code'),
      },
      {
        key: 'name',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.cause.name'),
      },
      {
        key: 'description',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.cause.description'),
      },
      {
        key: 'isActive',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.cause.status'),
      },
    ];

    const workbook = await this.exportOneSheetUtil(
      responseData,
      [await this.i18n.translate('export.causeReport.title')],
      headers,
    );

    return workbook;
  }

  async exportQcExecute(payload: ExportRequestDto) {
    let listQcExecuteReport: any[] = [];
    const textCommon = await this.i18n.translate('export.common');

    const request = new GetListCauseRequestDto();
    request.page = payload.page;
    if (payload.queryIds) {
      request.queryIds = map(JSON.parse(payload.queryIds), 'id');
    }
    request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
    request.filter = payload.filter;
    request.sort = payload.sort;
    const { data } = await this.qcExecuteRepository.getList(request);

    if (!isEmpty(data)) {
      listQcExecuteReport = listQcExecuteReport.concat(data);
    }

    if (!listQcExecuteReport || isEmpty(listQcExecuteReport)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const userIds = uniq(compact(map(listQcExecuteReport, 'qcBy')));

    // Filter by user id
    const userIdFilters = [
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ];

    if (!isEmpty(userIds)) {
      let users = await this.userService.getList(userIdFilters);
      users = keyBy(users, 'id');
      listQcExecuteReport.forEach((item) => {
        item.qcBy = item.qcBy.map((i: number) => users[i]);
      });
    }

    const responseData = listQcExecuteReport.map((i) => {
      return {
        itemCode: i.itemCode,
        itemName: i.itemName,
        lot: i.lot,
        qcCommandCode: i.qcCommandCode,
        qcBy: i.qcBy.map((user) => user?.fullName).join(', '),
        qcFormat: i.qcFormat,
        planQuantity: i.planQuantity,
        todoQuantity: i.todoQuantity,
        testedQuantity: i.testedQuantity,
        remainQuantity: i.remainQuantity,
        passQuantity: i.passQuantity,
        failQuantity: i.failQuantity,
        status:
          i.status === QC_STATUS.NOT
            ? textCommon.unfulfilled
            : i.status === QC_STATUS.DONE
            ? textCommon.fulfilled
            : textCommon.processing,
      };
    });

    const headers = [
      {
        key: 'itemCode',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcExecute.itemCode'),
      },
      {
        key: 'itemName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcExecute.itemName'),
      },
      {
        key: 'lot',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcExecute.lot'),
      },
      {
        key: 'qcCommandCode',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcExecute.qcCommandCode'),
      },
      {
        key: 'qcBy',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcExecute.qcBy'),
      },
      {
        key: 'qcFormat',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcExecute.qcFormat'),
      },
      {
        key: 'planQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcExecute.planQuantity'),
      },
      {
        key: 'todoQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcExecute.todoQuantity'),
      },
      {
        key: 'testedQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcExecute.testedQuantity'),
      },
      {
        key: 'remainQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcExecute.remainQuantity'),
      },
      {
        key: 'passQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcExecute.passQuantity'),
      },
      {
        key: 'failQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcExecute.failQuantity'),
      },
      {
        key: 'status',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcExecute.status'),
      },
      {
        key: 'progress',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.qcExecute.progress'),
      },
    ];

    const workbook = await this.exportOneSheetUtil(
      responseData,
      [await this.i18n.translate('export.qcExecute.title')],
      headers,
    );

    return workbook;
  }
}
