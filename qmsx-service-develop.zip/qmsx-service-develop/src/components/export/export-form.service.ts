import { ErrorRepositoryInterface } from '@components/error/interface/error.repository.interface';
import { EvaluationCriteriaRepositoryInterface } from '@components/evaluation-criteria/interface/evaluation-criteria.repository.interface';
import { EvaluationFormRepositoryInterface } from '@components/evaluation-form/interface/evaluation-form.repository.interface';
import { ItemService } from '@components/item/item.service';
import { QCCommandRepositoryInterface } from '@components/qc-command/interface/qc-command.repository.interface';
import { QCExecuteRepositoryInterface } from '@components/qc-execute/interface/qc-execute.repository.interface';
import { QC_ITEM_STATUS } from '@components/qc-item/qc-item.constant';
import { QCRequestRepositoryInterface } from '@components/qc-request/interface/qc-request.repository.interface';
import { REQUEST_SOURCE } from '@components/qc-request/qc-request.constant';
import { TicketReportErrorRepositoryInterface } from '@components/ticket-report-error/interface/ticket-report-error.repository.interface';
import { TICKET_REPORT_ERROR_STATUS } from '@components/ticket-report-error/ticket-report-error.constant';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { DATE_FORMAT_EXPORT } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { Alignment, Borders, Font, Workbook } from 'exceljs';
import {
  compact,
  forEach,
  isEmpty,
  keyBy,
  map,
  maxBy,
  minBy,
  uniq,
} from 'lodash';
import * as moment from 'moment';
import { I18nRequestScopeService } from 'nestjs-i18n';
import {
  EXCEL_FORM_EVALUATION_STYLE,
  EXCEL_STYLE,
  EXCEL_TICKET_QC_COMMAND_STYLE,
  TypeEnum,
} from './export.constant';
import { ExportFormServiceInterface } from './interface/export-form.interface';
@Injectable()
export class ExportFormService implements ExportFormServiceInterface {
  constructor(
    @Inject('ErrorRepositoryInterface')
    private readonly errorRepository: ErrorRepositoryInterface,

    @Inject('EvaluationFormRepositoryInterface')
    private readonly evaluationFormRepository: EvaluationFormRepositoryInterface,

    @Inject('EvaluationCriteriaRepositoryInterface')
    private readonly evaluationCriteriaRepository: EvaluationCriteriaRepositoryInterface,

    @Inject('QCCommandRepositoryInterface')
    private readonly qcCommandRepository: QCCommandRepositoryInterface,

    @Inject('QCRequestRepositoryInterface')
    private readonly qcRequestRepository: QCRequestRepositoryInterface,

    @Inject('QCExecuteRepositoryInterface')
    private readonly qcExecuteRepository: QCExecuteRepositoryInterface,

    @Inject('TicketReportErrorRepositoryInterface')
    private readonly ticketReportErrorRepository: TicketReportErrorRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ItemService')
    private readonly itemService: ItemService,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async exportForm(request: any): Promise<any> {
    const { type, payload } = request;

    let workbook = new Workbook();
    switch (type) {
      case TypeEnum.ERROR:
        break;
      case TypeEnum.ERROR_GROUP:
        break;
      case TypeEnum.CAUSE:
        break;
      case TypeEnum.EVALUATION_FORM:
        workbook = await this.exportEvaluationFormTicket(
          workbook,
          payload?.evaluationFormId,
        );
        break;
      case TypeEnum.EVALUATION_CRITERIA:
        break;
      case TypeEnum.QC_COMMAND:
        workbook = await this.exportQCCommandTicket(
          workbook,
          payload?.qcCommandId,
        );
        break;
      case TypeEnum.TICKET_REPORT_ERROR:
        workbook = await this.exportTicketReportError(
          workbook,
          payload?.ticketReportErrorId,
        );
        break;
      default:
        break;
    }

    if (workbook?.xlsx) {
      await workbook.xlsx.writeFile('excel-form.xlsx');
      const file = await workbook.xlsx.writeBuffer();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .withData(file)
        .build();
    } else {
      return workbook;
    }
  }

  async exportEvaluationFormTicket(workbook: any, evaluationFormId: string) {
    const { dataEvaluationForm, dataEvaluationCriteria } =
      await this.getDataEvaluationForm(evaluationFormId);
    const START_SUB_TITLE_ROW = 5;
    const textEvaluationForm = await this.i18n.translate('export.exportForm');
    const subtitle = ['code', 'qcItemCode', 'qcItemName', 'person', 'date'];
    const headerMainTable = [
      {
        key: 'stt',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: textEvaluationForm.evaluationForm.stt,
      },
      {
        key: 'evaluation_criteria',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: textEvaluationForm.evaluationForm.evaluationCriteria,
      },
      {
        key: 'value',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: textEvaluationForm.evaluationForm.value,
      },
      {
        key: 'note',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: textEvaluationForm.evaluationForm.note,
      },
    ];
    let worksheet = workbook.getWorksheet('Sheet 1');
    if (!worksheet) {
      worksheet = workbook.addWorksheet('Sheet 1');
      // draw header
      let headerRow = worksheet.getRow(2);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_FORM_EVALUATION_STYLE.HEADER_FONT;

      headerRow.value = textEvaluationForm.evaluationForm.title;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      let nameRow = worksheet.getRow(3);
      nameRow = nameRow.getCell(2);
      nameRow.font = <Font>EXCEL_FORM_EVALUATION_STYLE.HEADER_FONT;
      nameRow.value = textEvaluationForm.name + ' ' + dataEvaluationForm.name; //need name value of EF
      nameRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;

      // generate subtitle
      for (
        let index = START_SUB_TITLE_ROW;
        index < START_SUB_TITLE_ROW + subtitle.length;
        index++
      ) {
        let nameRow = worksheet.getRow(index);
        nameRow = nameRow.getCell(3);
        nameRow.font = <Font>EXCEL_FORM_EVALUATION_STYLE.DEFAULT_FONT;
        const key = subtitle[index - START_SUB_TITLE_ROW];
        if (key === 'code') {
          nameRow.value =
            textEvaluationForm['evaluationForm'][key] +
            ' ' +
            dataEvaluationForm.code;
        } else {
          nameRow.value = textEvaluationForm['evaluationForm'][key];
        } //need value if key ==='code'
        worksheet.mergeCellsWithoutStyle(index, 3, index, 7);
      }

      worksheet.mergeCellsWithoutStyle(11, 3, 11, 6);
      for (let index = 2; index < 2 + headerMainTable.length; index++) {
        let headerTableRow = worksheet.getRow(11);
        headerTableRow = headerTableRow.getCell(index > 3 ? index + 3 : index);
        headerTableRow.value = headerMainTable[index - 2].title;
        headerTableRow.font = <Font>EXCEL_FORM_EVALUATION_STYLE.HEADER_FONT;
        headerTableRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
        headerTableRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      }

      // draw table
      let CONTINUE_ROW = 12;
      let NUMBER_TABLE = 1;

      for (let i = 0; i < dataEvaluationCriteria.length; i++) {
        let mainRow = worksheet.getRow(CONTINUE_ROW);
        mainRow = mainRow.getCell(2);
        mainRow.value = dataEvaluationCriteria[i].name;
        mainRow.font = <Font>EXCEL_FORM_EVALUATION_STYLE.DEFAULT_FONT;
        mainRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
        mainRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        worksheet.mergeCells(CONTINUE_ROW, 2, CONTINUE_ROW, 8);
        CONTINUE_ROW++;
        if (dataEvaluationCriteria[i].errors.length) {
          dataEvaluationCriteria[i].errors.forEach((ec) => {
            const subRow = worksheet.getRow(CONTINUE_ROW);
            subRow.values = ['', NUMBER_TABLE++, ec.name, '', '', '', '', ''];
            worksheet.mergeCellsWithoutStyle(CONTINUE_ROW, 3, CONTINUE_ROW, 6);
            CONTINUE_ROW++;
            subRow.eachCell(function (cell, i) {
              if (i !== 1) {
                cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
                cell.font = <Font>EXCEL_FORM_EVALUATION_STYLE.DEFAULT_FONT;
                cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
              }
            });
          });
        }
      }

      // result footer
      CONTINUE_ROW++;
      let resRow = worksheet.getRow(CONTINUE_ROW);
      resRow = resRow.getCell(2);
      resRow.value = textEvaluationForm.evaluationForm.result;
      resRow.font = <Font>EXCEL_FORM_EVALUATION_STYLE.HEADER_FONT;
      worksheet.mergeCellsWithoutStyle(CONTINUE_ROW, 2, CONTINUE_ROW, 4);

      // date footer
      CONTINUE_ROW += 2;
      let dateRow = worksheet.getRow(CONTINUE_ROW);
      dateRow = dateRow.getCell(6);
      dateRow.value = textEvaluationForm.evaluationForm.datePlacehoder;
      dateRow.font = <Font>EXCEL_FORM_EVALUATION_STYLE.DEFAULT_FONT;
      worksheet.mergeCells(CONTINUE_ROW, 6, CONTINUE_ROW, 7);

      // sign footer
      CONTINUE_ROW += 2;
      const signRow = worksheet.getRow(CONTINUE_ROW);
      const signCell1 = signRow.getCell(3);
      signCell1.value = textEvaluationForm.evaluationForm.manager;
      signCell1.font = <Font>EXCEL_FORM_EVALUATION_STYLE.HEADER_FONT;
      worksheet.mergeCells(CONTINUE_ROW, 3, CONTINUE_ROW, 5);
      const signCell2 = signRow.getCell(7);
      signCell2.value = textEvaluationForm.evaluationForm.evaluatePerson;
      signCell2.font = <Font>EXCEL_FORM_EVALUATION_STYLE.HEADER_FONT;
      worksheet.mergeCells(CONTINUE_ROW, 7, CONTINUE_ROW, 8);

      //merge cell
      worksheet.mergeCellsWithoutStyle(2, 2, 2, 8);
      worksheet.mergeCellsWithoutStyle(3, 2, 3, 8);
    }

    return workbook;
  }

  async getDataEvaluationForm(evaluationFormId: string) {
    const evaluationForm = await this.evaluationFormRepository.findOneById(
      evaluationFormId,
    );
    const evaluationCriteriaCode = evaluationForm.evaluations.map(
      (item) => item.code,
    );
    const evaluationCriterias =
      await this.evaluationCriteriaRepository.findAllByCondition({
        code: {
          $in: evaluationCriteriaCode,
        },
      });
    const evaluations = evaluationCriterias.map(async (item) => {
      const errorCodes = [];
      item?.details.forEach((detail) => {
        errorCodes.push(...detail.errorCodes);
      });
      const errors = await this.errorRepository.findAllByCondition({
        code: {
          $in: errorCodes,
        },
      });
      return { ...item, errors: errors };
    });
    const dataEvaluationCriteria = await Promise.all(evaluations);

    return { dataEvaluationForm: evaluationForm, dataEvaluationCriteria };
  }

  async exportQCCommandTicket(workbook: any, qcCommandId: string) {
    const { qcCommand, qcRequest, startDate, endDate, qcExecutes } =
      await this.getDataQCCommand(qcCommandId);
    const START_SUB_TITLE_ROW = 5;
    const ticketQCCommandText = await this.i18n.translate(
      'export.ticketQCCommand',
    );

    let worksheet = workbook.getWorksheet('Sheet 1');
    if (!worksheet) {
      worksheet = workbook.addWorksheet('Sheet 1');
      // draw left header
      let headerRow = worksheet.getRow(2);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.LEFT_HEADER_FONT;
      headerRow.value = ticketQCCommandText.company;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );

      headerRow = worksheet.getRow(3);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.LEFT_HEADER_FONT;
      headerRow.value = ticketQCCommandText.department;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );

      headerRow = worksheet.getRow(4);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.LEFT_HEADER_FONT;
      headerRow.value = ticketQCCommandText.date;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );

      // title
      headerRow = worksheet.getRow(6);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.TITLE_FONT;
      headerRow.value = ticketQCCommandText.title;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      // Merged cell title
      worksheet.mergeCellsWithoutStyle(6, 2, 6, 24);

      // sub header center
      headerRow = worksheet.getRow(8);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
      headerRow.value = `${ticketQCCommandText.qcCommandCode}${qcCommand.code}`;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );

      headerRow = worksheet.getRow(9);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
      headerRow.value = `${ticketQCCommandText.qcCommandName}${qcCommand.name}`;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );

      headerRow = worksheet.getRow(10);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
      headerRow.value = `${ticketQCCommandText.qcRequestCode}${qcCommand.qcRequestCode}`;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );

      headerRow = worksheet.getRow(11);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
      headerRow.value = `${ticketQCCommandText.requestSource}${
        qcRequest.requestSource === REQUEST_SOURCE.MESX
          ? ticketQCCommandText.mesx
          : qcRequest.requestSource === REQUEST_SOURCE.WMSX
          ? ticketQCCommandText.wmsx
          : ticketQCCommandText.qmsx
      }`;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );

      headerRow = worksheet.getRow(12);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
      headerRow.value = `${ticketQCCommandText.startDateEndDate}${moment(
        startDate,
      ).format(DATE_FORMAT_EXPORT)}${' - '}${moment(endDate).format(
        DATE_FORMAT_EXPORT,
      )}`;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );

      headerRow = worksheet.getRow(13);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
      headerRow.value = `${ticketQCCommandText.deadline}${moment(
        qcRequest.returnDate,
      ).format(DATE_FORMAT_EXPORT)}`;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );

      // draw header table
      headerRow = worksheet.getRow(15);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketQCCommandText.index;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      worksheet.mergeCells(15, 2, 16, 3);

      headerRow = worksheet.getRow(15);
      headerRow = headerRow.getCell(4);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketQCCommandText.itemCode;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      worksheet.mergeCells(15, 4, 16, 8);

      headerRow = worksheet.getRow(15);
      headerRow = headerRow.getCell(9);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketQCCommandText.itemName;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      worksheet.mergeCells(15, 9, 16, 12);

      headerRow = worksheet.getRow(15);
      headerRow = headerRow.getCell(13);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketQCCommandText.startDateEndDate;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      worksheet.mergeCells(15, 13, 16, 16);

      headerRow = worksheet.getRow(15);
      headerRow = headerRow.getCell(17);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketQCCommandText.status;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      worksheet.mergeCells(15, 17, 16, 19);

      // Progress Header
      headerRow = worksheet.getRow(15);
      headerRow = headerRow.getCell(20);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketQCCommandText.progress;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      worksheet.mergeCells(15, 20, 15, 24);

      headerRow = worksheet.getRow(16);
      headerRow = headerRow.getCell(20);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketQCCommandText.planQuantity;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;

      headerRow = worksheet.getRow(16);
      headerRow = headerRow.getCell(21);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketQCCommandText.todoQuantity;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;

      headerRow = worksheet.getRow(16);
      headerRow = headerRow.getCell(22);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketQCCommandText.testedQuantity;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;

      headerRow = worksheet.getRow(16);
      headerRow = headerRow.getCell(23);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketQCCommandText.passQuantity;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;

      headerRow = worksheet.getRow(16);
      headerRow = headerRow.getCell(24);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketQCCommandText.failQuantity;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;

      const rowStartTableData = 17;
      for (let i = 0; i < qcExecutes?.length; i++) {
        const qcExecute = qcExecutes[i];
        headerRow = worksheet.getRow(rowStartTableData + i);
        headerRow = headerRow.getCell(2);
        headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
        headerRow.value = i + 1;
        headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
        headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        worksheet.mergeCells(
          rowStartTableData + i,
          2,
          rowStartTableData + i,
          3,
        );

        headerRow = worksheet.getRow(rowStartTableData + i);
        headerRow = headerRow.getCell(4);
        headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
        headerRow.value = qcExecute.itemCode;
        headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE;
        headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        worksheet.mergeCells(
          rowStartTableData + i,
          4,
          rowStartTableData + i,
          8,
        );

        headerRow = worksheet.getRow(rowStartTableData + i);
        headerRow = headerRow.getCell(9);
        headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
        headerRow.value = qcExecute.itemName;
        headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE;
        headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        worksheet.mergeCells(
          rowStartTableData + i,
          9,
          rowStartTableData + i,
          12,
        );

        headerRow = worksheet.getRow(rowStartTableData + i);
        headerRow = headerRow.getCell(13);
        headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
        headerRow.value = `${moment(qcExecute.startDate).format(
          DATE_FORMAT_EXPORT,
        )}${' - '}${moment(qcExecute.endDate).format(DATE_FORMAT_EXPORT)}`;
        headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE;
        headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        worksheet.mergeCells(
          rowStartTableData + i,
          13,
          rowStartTableData + i,
          16,
        );

        headerRow = worksheet.getRow(rowStartTableData + i);
        headerRow = headerRow.getCell(17);
        headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
        headerRow.value =
          qcExecute.status === QC_ITEM_STATUS.TODO
            ? ticketQCCommandText.todo
            : qcExecute.status === QC_ITEM_STATUS.IN_PROGRESS
            ? ticketQCCommandText.inProgress
            : ticketQCCommandText.completed;
        headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE;
        headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        worksheet.mergeCells(
          rowStartTableData + i,
          17,
          rowStartTableData + i,
          19,
        );

        headerRow = worksheet.getRow(rowStartTableData + i);
        headerRow = headerRow.getCell(20);
        headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
        headerRow.value = qcExecute.planQuantity;
        headerRow.alignment = <Partial<Alignment>>(
          EXCEL_STYLE.ALIGN_RIGHT_MIDDLE
        );
        headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;

        headerRow = worksheet.getRow(rowStartTableData + i);
        headerRow = headerRow.getCell(21);
        headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
        headerRow.value = qcExecute.todoQuantity;
        headerRow.alignment = <Partial<Alignment>>(
          EXCEL_STYLE.ALIGN_RIGHT_MIDDLE
        );
        headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;

        headerRow = worksheet.getRow(rowStartTableData + i);
        headerRow = headerRow.getCell(22);
        headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
        headerRow.value = qcExecute.testedQuantity;
        headerRow.alignment = <Partial<Alignment>>(
          EXCEL_STYLE.ALIGN_RIGHT_MIDDLE
        );
        headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;

        headerRow = worksheet.getRow(rowStartTableData + i);
        headerRow = headerRow.getCell(23);
        headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
        headerRow.value = qcExecute.passQuantity;
        headerRow.alignment = <Partial<Alignment>>(
          EXCEL_STYLE.ALIGN_RIGHT_MIDDLE
        );
        headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;

        headerRow = worksheet.getRow(rowStartTableData + i);
        headerRow = headerRow.getCell(24);
        headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
        headerRow.value = qcExecute.failQuantity;
        headerRow.alignment = <Partial<Alignment>>(
          EXCEL_STYLE.ALIGN_RIGHT_MIDDLE
        );
        headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      }
      const rowStartSignature = rowStartTableData + qcExecutes?.length + 2;

      // Signature
      headerRow = worksheet.getRow(rowStartSignature);
      headerRow = headerRow.getCell(21);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
      headerRow.value = ticketQCCommandText.signatureDate;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );

      headerRow = worksheet.getRow(rowStartSignature + 1);
      headerRow = headerRow.getCell(22);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketQCCommandText.approver;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );
    }

    return workbook;
  }

  async getDataQCCommand(qcCommandId: string) {
    const qcCommand = await this.qcCommandRepository.findOneById(qcCommandId);

    const qcRequest = await this.qcRequestRepository.findOneByCode(
      qcCommand.qcRequestCode,
    );

    const startDate = minBy(qcCommand?.items, 'startDate')?.startDate;

    const endDate = maxBy(qcCommand?.items, 'endDate')?.endDate;

    const itemCodes = uniq(compact(map(qcCommand?.items, 'itemCode')));
    const qcExecutes: any = await this.qcExecuteRepository.findAllByCondition({
      qcCommandCode: qcCommand?.code,
    });
    let itemList: any = [];
    if (!isEmpty(itemCodes)) {
      const request = {
        codes: itemCodes.join(','),
      };
      itemList = await this.itemService.getItemList(request);
      itemList = keyBy(itemList, 'code');
    }
    forEach(qcExecutes, (qcExecute) => {
      qcExecute.itemName = itemList[qcExecute.itemCode]?.name;
    });

    return { qcCommand, qcRequest, startDate, endDate, qcExecutes };
  }

  async exportTicketReportError(workbook: any, ticketReportErrorId: string) {
    const { ticketReportError, qcExecutes } =
      await this.getDataTicketReportError(ticketReportErrorId);
    const ticketReportErrorText = await this.i18n.translate(
      'export.ticketReportErrorPrint',
    );

    let worksheet = workbook.getWorksheet('Sheet 1');
    if (!worksheet) {
      worksheet = workbook.addWorksheet('Sheet 1');
      // draw left header
      let headerRow = worksheet.getRow(2);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.LEFT_HEADER_FONT;
      headerRow.value = ticketReportErrorText.company;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );

      headerRow = worksheet.getRow(3);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.LEFT_HEADER_FONT;
      headerRow.value = ticketReportErrorText.department;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );

      headerRow = worksheet.getRow(4);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.LEFT_HEADER_FONT;
      headerRow.value = ticketReportErrorText.date;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );

      // title
      headerRow = worksheet.getRow(6);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.TITLE_FONT;
      headerRow.value = ticketReportErrorText.title;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      // Merged cell title
      worksheet.mergeCellsWithoutStyle(6, 2, 6, 27);

      // sub header center
      headerRow = worksheet.getRow(8);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
      headerRow.value = `${ticketReportErrorText.code}${ticketReportError.code}`;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );

      headerRow = worksheet.getRow(9);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
      headerRow.value = `${ticketReportErrorText.qcCommandName}${ticketReportError.qcCommand?.name}`;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );

      headerRow = worksheet.getRow(10);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
      headerRow.value = `${ticketReportErrorText.createdBy}${ticketReportError.createdBy?.fullName}`;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );

      headerRow = worksheet.getRow(11);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
      headerRow.value = `${ticketReportErrorText.createdAt}${moment(
        ticketReportError.createdAt,
      ).format(DATE_FORMAT_EXPORT)}`;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );

      headerRow = worksheet.getRow(12);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
      headerRow.value = `${ticketReportErrorText.status}${
        ticketReportError?.status === TICKET_REPORT_ERROR_STATUS.TODO
          ? ticketReportErrorText.todo
          : ticketReportError?.status === TICKET_REPORT_ERROR_STATUS.IN_PROGRESS
          ? ticketReportErrorText.inProgress
          : ticketReportError?.status === TICKET_REPORT_ERROR_STATUS.DONE
          ? ticketReportErrorText.done
          : ticketReportErrorText.finished
      }`;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );

      // draw header table
      headerRow = worksheet.getRow(14);
      headerRow = headerRow.getCell(2);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketReportErrorText.index;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      worksheet.mergeCells(14, 2, 15, 2);

      headerRow = worksheet.getRow(14);
      headerRow = headerRow.getCell(3);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketReportErrorText.itemCode;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      worksheet.mergeCells(14, 3, 15, 7);

      headerRow = worksheet.getRow(14);
      headerRow = headerRow.getCell(8);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketReportErrorText.itemName;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      worksheet.mergeCells(14, 8, 15, 11);

      headerRow = worksheet.getRow(14);
      headerRow = headerRow.getCell(12);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketReportErrorText.lot;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      worksheet.mergeCells(14, 12, 15, 15);

      headerRow = worksheet.getRow(14);
      headerRow = headerRow.getCell(16);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketReportErrorText.planQuantity;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      worksheet.mergeCells(14, 16, 15, 17);

      headerRow = worksheet.getRow(14);
      headerRow = headerRow.getCell(18);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketReportErrorText.todoQuantity;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      worksheet.mergeCells(14, 18, 15, 19);

      // Progress Header
      headerRow = worksheet.getRow(14);
      headerRow = headerRow.getCell(20);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketReportErrorText.progress;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      worksheet.mergeCells(14, 20, 14, 27);

      headerRow = worksheet.getRow(15);
      headerRow = headerRow.getCell(20);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketReportErrorText.testedQuantity;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      worksheet.mergeCells(15, 20, 15, 21);

      headerRow = worksheet.getRow(15);
      headerRow = headerRow.getCell(22);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketReportErrorText.remainQuantity;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      worksheet.mergeCells(15, 22, 15, 23);

      headerRow = worksheet.getRow(15);
      headerRow = headerRow.getCell(24);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketReportErrorText.passQuantity;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      worksheet.mergeCells(15, 24, 15, 25);

      headerRow = worksheet.getRow(15);
      headerRow = headerRow.getCell(26);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketReportErrorText.failQuantity;
      headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
      headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      worksheet.mergeCells(15, 26, 15, 27);

      // Fill data
      const rowStartTableData = 16;
      for (let index = 0; index <= qcExecutes?.length; index++) {
        const qcExecute = qcExecutes[0];
        headerRow = worksheet.getRow(rowStartTableData + index);
        headerRow = headerRow.getCell(2);
        headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
        headerRow.value = index + 1;
        headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
        headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;

        headerRow = worksheet.getRow(rowStartTableData + index);
        headerRow = headerRow.getCell(3);
        headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
        headerRow.value = qcExecute.itemCode;
        headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
        headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        worksheet.mergeCells(
          rowStartTableData + index,
          3,
          rowStartTableData + index,
          7,
        );

        headerRow = worksheet.getRow(rowStartTableData + index);
        headerRow = headerRow.getCell(8);
        headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
        headerRow.value = qcExecute.itemName;
        headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
        headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        worksheet.mergeCells(
          rowStartTableData + index,
          8,
          rowStartTableData + index,
          11,
        );

        headerRow = worksheet.getRow(rowStartTableData + index);
        headerRow = headerRow.getCell(12);
        headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
        headerRow.value = qcExecute.lot;
        headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
        headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        worksheet.mergeCells(
          rowStartTableData + index,
          12,
          rowStartTableData + index,
          15,
        );

        headerRow = worksheet.getRow(rowStartTableData + index);
        headerRow = headerRow.getCell(16);
        headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
        headerRow.value = qcExecute.planQuantity;
        headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
        headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        worksheet.mergeCells(
          rowStartTableData + index,
          16,
          rowStartTableData + index,
          17,
        );

        headerRow = worksheet.getRow(rowStartTableData + index);
        headerRow = headerRow.getCell(18);
        headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
        headerRow.value = qcExecute.todoQuantity;
        headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
        headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        worksheet.mergeCells(
          rowStartTableData + index,
          18,
          rowStartTableData + index,
          19,
        );

        headerRow = worksheet.getRow(rowStartTableData + index);
        headerRow = headerRow.getCell(20);
        headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
        headerRow.value = qcExecute.testedQuantity;
        headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
        headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        worksheet.mergeCells(
          rowStartTableData + index,
          20,
          rowStartTableData + index,
          21,
        );

        headerRow = worksheet.getRow(rowStartTableData + index);
        headerRow = headerRow.getCell(22);
        headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
        headerRow.value = qcExecute.remainQuantity;
        headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
        headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        worksheet.mergeCells(
          rowStartTableData + index,
          22,
          rowStartTableData + index,
          23,
        );

        headerRow = worksheet.getRow(rowStartTableData + index);
        headerRow = headerRow.getCell(24);
        headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
        headerRow.value = qcExecute.passQuantity;
        headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
        headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        worksheet.mergeCells(
          rowStartTableData + index,
          24,
          rowStartTableData + index,
          25,
        );

        headerRow = worksheet.getRow(rowStartTableData + index);
        headerRow = headerRow.getCell(26);
        headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
        headerRow.value = qcExecute.failQuantity;
        headerRow.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
        headerRow.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        worksheet.mergeCells(
          rowStartTableData + index,
          26,
          rowStartTableData + index,
          27,
        );
      }
      const rowStartSignature = rowStartTableData + qcExecutes?.length + 3;

      // Signature
      headerRow = worksheet.getRow(rowStartSignature);
      headerRow = headerRow.getCell(21);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.DEFAULT_FONT;
      headerRow.value = ticketReportErrorText.signatureDate;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );

      headerRow = worksheet.getRow(rowStartSignature + 1);
      headerRow = headerRow.getCell(22);
      headerRow.font = <Font>EXCEL_TICKET_QC_COMMAND_STYLE.BOLD_FONT;
      headerRow.value = ticketReportErrorText.approver;
      headerRow.alignment = <Partial<Alignment>>(
        EXCEL_STYLE.ALIGN_LEFT_MIDDLE_NOWRAP
      );
    }

    return workbook;
  }

  async getDataTicketReportError(ticketReportErrorId: string) {
    const ticketReportError: any =
      await this.ticketReportErrorRepository.findOneById(ticketReportErrorId);

    const user = await this.userService.getDetail(ticketReportError?.createdBy);
    ticketReportError.createdBy = user;

    const qcCommand = await this.qcCommandRepository.findOneByCode(
      ticketReportError?.qcCommandCode,
    );
    ticketReportError.qcCommand = qcCommand;

    const qcExecutes: any = await this.qcExecuteRepository.findAllByCondition({
      qcCommandCode: ticketReportError?.qcCommandCode,
    });

    const itemCodes = uniq(compact(map(qcExecutes, 'itemCode')));
    let itemList: any = [];
    if (!isEmpty(itemCodes)) {
      const request = {
        codes: itemCodes.join(','),
      };
      itemList = await this.itemService.getItemList(request);
      itemList = keyBy(itemList, 'code');
    }
    forEach(qcExecutes, (qcExecute) => {
      qcExecute.itemName = itemList[qcExecute.itemCode]?.name;
    });

    return { ticketReportError, qcExecutes };
  }
}
