import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { IsOptional, IsString } from 'class-validator';

export class ExportFormRequestDto extends PaginationQuery {
  @ApiProperty()
  @IsOptional()
  @IsString()
  evaluationFormId: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  qcCommandId: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  ticketReportErrorId: string;
}
