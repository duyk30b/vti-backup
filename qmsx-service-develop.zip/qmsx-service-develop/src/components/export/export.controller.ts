import { Controller, Get, Inject, Param, Query } from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { isEmpty } from 'lodash';
import { ExportRequestDto } from './dto/request/export.request.dto';
import { ExportServiceInterface } from './interface/export.service.interface';
import { ExportFormServiceInterface } from './interface/export-form.interface';
import { ExportFormRequestDto } from './dto/request/export-form.request.dto';

@Controller('export')
export class ExportController {
  constructor(
    @Inject('ExportServiceInterface')
    private readonly exportService: ExportServiceInterface,

    @Inject('ExportFormServiceInterface')
    private readonly exportFormService: ExportFormServiceInterface,
  ) {}

  @Get('/:type')
  @ApiOperation({
    tags: ['Export Data - Xuất dữ liệu'],
    summary: 'Export Data - Xuất dữ liệu',
    description: 'Export Data - Xuất dữ liệu',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async exportData(
    @Query() payload: ExportRequestDto,
    @Param('type') type: number,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.exportService.export({
      ...request,
      type: Number(type),
    });
  }

  @Get('/form/:type')
  @ApiOperation({
    tags: ['Export Ticket - In phiếu'],
    summary: 'Export Ticket - In phiếu',
    description: 'Export Ticket - In phiếu',
  })
  @ApiResponse({
    status: 200,
    description: 'Get template form successfully',
  })
  public async exportForm(
    @Query() payload: ExportFormRequestDto,
    @Param('type') type: number,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.exportFormService.exportForm({
      type: Number(type),
      payload: request,
    });
  }

  @Get('/template/:type')
  @ApiOperation({
    tags: ['Export Template - Tải mẫu nhập dữ liệu'],
    summary: 'Export Template - Tải mẫu nhập dữ liệu',
    description: 'Export Template - Tải mẫu nhập dữ liệu',
  })
  @ApiResponse({
    status: 200,
    description: 'Get template form successfully',
  })
  public async exportTemplate(@Param('type') type: number): Promise<any> {
    return await this.exportService.exportTemplate({
      type: Number(type),
    });
  }
}
