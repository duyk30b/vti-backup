import { CauseService } from '@components/cause/cause.service';
import { ErrorGroupService } from '@components/error-group/error-group.service';
import { ErrorService } from '@components/error/error.service';
import { EvaluationCriteriaService } from '@components/evaluation-criteria/evaluation-criteria.service';
import { ItemService } from '@components/item/item.service';
import { Global, Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { CauseCollection, CauseSchema } from 'src/models/cause/cause.schema';
import {
  ErrorGroup,
  ErrorGroupSchema,
} from 'src/models/error-group/error-group.schema';
import { Error, ErrorSchema } from 'src/models/error/error.schema';
import {
  EvaluationCriteria,
  EvaluationCriteriaSchema,
} from 'src/models/evaluation-criteria/evaluation-criteria.schema';
import {
  EvaluationFormCollection,
  EvaluationFormSchema,
} from 'src/models/evaluation-form/evaluation-form.schema';
import {
  QCCommand,
  QCCommandSchema,
} from 'src/models/qc-command/qc-command.schema';
import {
  QCExecute,
  QCExecuteSchema,
} from 'src/models/qc-execute/qc-execute.schema';
import {
  QCRequest,
  QCRequestSchema,
} from 'src/models/qc-request/qc-request.schema';
import {
  TicketReportError,
  TicketReportErrorSchema,
} from 'src/models/ticket-report-error/ticket-report-error.schema';
import { CauseRepository } from 'src/repository/cause/cause.repository';
import { ErrorGroupRepository } from 'src/repository/error-group/error-group.repository';
import { ErrorRepository } from 'src/repository/error/error.repository';
import { EvaluationCriteriaRepository } from 'src/repository/evaluation-criteria/evaluation-criteria.repository';
import { EvaluationFormRepository } from 'src/repository/evaluation-form/evaluation-form.repository';
import { QCCommandRepository } from 'src/repository/qc-command/qc-command.repository';
import { QCExecuteRepository } from 'src/repository/qc-execute/qc-execute.repository';
import { QCRequestRepository } from 'src/repository/qc-request/qc-request.repository';
import { TicketReportErrorRepository } from 'src/repository/ticket-report-error/ticket-report-error.repository';
import { ExportFormService } from './export-form.service';
import { ExportController } from './export.controller';
import { ExportService } from './export.service';

@Global()
@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: ErrorGroup.name,
        schema: ErrorGroupSchema,
      },
      {
        name: Error.name,
        schema: ErrorSchema,
      },
      {
        name: CauseCollection.name,
        schema: CauseSchema,
      },
      {
        name: EvaluationFormCollection.name,
        schema: EvaluationFormSchema,
      },
      {
        name: EvaluationCriteria.name,
        schema: EvaluationCriteriaSchema,
      },
      {
        name: QCRequest.name,
        schema: QCRequestSchema,
      },
      {
        name: QCCommand.name,
        schema: QCCommandSchema,
      },
      {
        name: QCExecute.name,
        schema: QCExecuteSchema,
      },
      {
        name: TicketReportError.name,
        schema: TicketReportErrorSchema,
      },
    ]),
  ],
  providers: [
    {
      provide: 'ExportServiceInterface',
      useClass: ExportService,
    },
    {
      provide: 'ErrorGroupServiceInterface',
      useClass: ErrorGroupService,
    },
    {
      provide: 'ErrorGroupRepositoryInterface',
      useClass: ErrorGroupRepository,
    },
    {
      provide: 'ErrorServiceInterface',
      useClass: ErrorService,
    },
    {
      provide: 'ErrorRepositoryInterface',
      useClass: ErrorRepository,
    },
    {
      provide: 'CauseServiceInterface',
      useClass: CauseService,
    },
    {
      provide: 'CauseRepositoryInterface',
      useClass: CauseRepository,
    },
    {
      provide: 'EvaluationFormRepositoryInterface',
      useClass: EvaluationFormRepository,
    },
    {
      provide: 'ItemService',
      useClass: ItemService,
    },
    {
      provide: 'EvaluationCriteriaServiceInterface',
      useClass: EvaluationCriteriaService,
    },
    {
      provide: 'EvaluationCriteriaRepositoryInterface',
      useClass: EvaluationCriteriaRepository,
    },
    {
      provide: 'ExportFormServiceInterface',
      useClass: ExportFormService,
    },
    {
      provide: 'QCRequestRepositoryInterface',
      useClass: QCRequestRepository,
    },
    {
      provide: 'QCCommandRepositoryInterface',
      useClass: QCCommandRepository,
    },
    {
      provide: 'QCExecuteRepositoryInterface',
      useClass: QCExecuteRepository,
    },
    {
      provide: 'TicketReportErrorRepositoryInterface',
      useClass: TicketReportErrorRepository,
    },
  ],
  controllers: [ExportController],
  exports: [
    {
      provide: 'ExportServiceInterface',
      useClass: ExportService,
    },
    {
      provide: 'ErrorGroupServiceInterface',
      useClass: ErrorGroupService,
    },
    {
      provide: 'ErrorGroupRepositoryInterface',
      useClass: ErrorGroupRepository,
    },
    {
      provide: 'ErrorServiceInterface',
      useClass: ErrorService,
    },
    {
      provide: 'ErrorRepositoryInterface',
      useClass: ErrorRepository,
    },
    {
      provide: 'CauseServiceInterface',
      useClass: CauseService,
    },
    {
      provide: 'CauseRepositoryInterface',
      useClass: CauseRepository,
    },
    {
      provide: 'EvaluationFormRepositoryInterface',
      useClass: EvaluationFormRepository,
    },
    {
      provide: 'EvaluationCriteriaServiceInterface',
      useClass: EvaluationCriteriaService,
    },
    {
      provide: 'EvaluationCriteriaRepositoryInterface',
      useClass: EvaluationCriteriaRepository,
    },
    {
      provide: 'QCRequestRepositoryInterface',
      useClass: QCRequestRepository,
    },
    {
      provide: 'QCCommandRepositoryInterface',
      useClass: QCCommandRepository,
    },
  ],
})
export class ExportModule {}
