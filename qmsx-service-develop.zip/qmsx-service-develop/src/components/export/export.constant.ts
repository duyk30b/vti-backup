export const EXCEL_STYLE = {
  SHEET_FONT: {
    size: 13,
    color: { argb: '000000' },
    bold: false,
    name: 'Times New Roman',
  },
  TOTAL_FONT: {
    color: { argb: 'FF0000' },
    size: 13,
    bold: true,
  },
  HEADER_FONT: {
    size: 18,
    bold: true,
    name: 'Times New Roman',
  },
  TITLE_FONT: {
    size: 13,
    bold: true,
    name: 'Times New Roman',
  },
  DEFAULT_FONT: {
    size: 12,
    bold: false,
    name: 'Times New Roman',
  },
  HEADER_FILL: {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'c0c0c0' },
  },
  HIGHT_LIGHT: {
    color: { argb: 'FF0000' },
    name: 'Times New Roman',
    size: 13,
  },
  ALIGN_CENTER: {
    vertical: 'middle',
    horizontal: 'center',
    wrapText: true,
  },
  ALIGN_LEFT_MIDDLE: {
    vertical: 'middle',
    horizontal: 'left',
    wrapText: true,
  },
  ALIGN_LEFT_MIDDLE_NOWRAP: {
    vertical: 'middle',
    horizontal: 'left',
    wrapText: false,
  },
  ALIGN_RIGHT_MIDDLE: {
    vertical: 'middle',
    horizontal: 'right',
    wrapText: true,
  },
  ALIGN_BOTTOM: {
    vertical: 'bottom',
    horizontal: 'center',
    wrapText: true,
  },
  BORDER_ALL: {
    top: { style: 'thin' },
    left: { style: 'thin' },
    bottom: { style: 'thin' },
    right: { style: 'thin' },
  },
  DDMMYYYYHHMMSS: 'dd-mm-yyyy HH:MM:SS',
  TITLE_HEIGHT: 38,
};

export const ROW = {
  COUNT_START_ROW: 1,
  COUNT_END_ROW: 10001,
  LIMIT_EXPORT: 100000,
  LIMIT_EXPORT_ON_SHEET: 10000,
};

export const SHEET = {
  START_SHEET: 1,
  NAME: 'Sheet',
};

export enum ExportTypeEnum {
  ONE_SHEET = 1,
  MULTI_SHEET = 2,
}

export enum TypeEnum {
  ERROR,
  ERROR_GROUP,
  CAUSE,
  EVALUATION_FORM,
  EVALUATION_CRITERIA,
  QC_REQUEST,
  QC_COMMAND,
  QC_EXECUTE,
  TICKET_REPORT_ERROR,
  QC_QUALITY_REPORT,
  QC_COMAND_REPORT,
}

export const MAX_NUMBER_PAGE = 10;

/*EXCEL EVALUATION FORM*/
export const EXCEL_FORM_EVALUATION_STYLE = {
  SHEET_FONT: {
    size: 13,
    color: { argb: '000000' },
    bold: false,
    name: 'Times New Roman',
  },
  HEADER_FONT: {
    size: 10,
    bold: true,
    name: 'Times New Roman',
  },
  DEFAULT_FONT: {
    size: 10,
    bold: false,
    name: 'Times New Roman',
  },
};

/* EXCEL TICKET QC COMMAND */
export const EXCEL_TICKET_QC_COMMAND_STYLE = {
  LEFT_HEADER_FONT: {
    size: 10,
    bold: true,
    name: 'Times New Roman',
  },
  TITLE_FONT: {
    size: 13,
    bold: true,
    name: 'Times New Roman',
  },
  SHEET_FONT: {
    size: 13,
    color: { argb: '000000' },
    bold: false,
    name: 'Times New Roman',
  },
  DEFAULT_FONT: {
    size: 10,
    bold: false,
    name: 'Times New Roman',
  },
  BOLD_FONT: {
    size: 10,
    bold: true,
    name: 'Times New Roman',
  },
};

/* EXCEL QC REQUEST */
export enum REQUEST_TYPE_VALUE {
  IMP_PO, //phiếu nhập kho
  IMP_PRO,
  IMP_IMO,
  EXP_SO, //phiếu xuất kho
  EXP_PRO,
  EXP_EXO,
  MANUFACTURE_IMP,
  MANUFACTURE_EXP,
  REQUEST_ARISES, //giấy đề nghị
  REQUEST_OUTSIDE, //đảo hàng
}

export const REQUEST_TYPE_OPTIONS_MAP = {
  [REQUEST_TYPE_VALUE.IMP_PO]: 'qcRequest.requestOptions.importPo',
  [REQUEST_TYPE_VALUE.IMP_PRO]: 'qcRequest.requestOptions.importPro',
  [REQUEST_TYPE_VALUE.IMP_IMO]: 'qcRequest.requestOptions.IMP_IMO',
  [REQUEST_TYPE_VALUE.EXP_SO]: 'qcRequest.requestOptions.EXP_SO',
  [REQUEST_TYPE_VALUE.EXP_PRO]: 'qcRequest.requestOptions.exportPro',
  [REQUEST_TYPE_VALUE.EXP_EXO]: 'qcRequest.requestOptions.exportExo',
  [REQUEST_TYPE_VALUE.MANUFACTURE_IMP]:
    'qcRequest.requestOptions.manufactureImp',
  [REQUEST_TYPE_VALUE.MANUFACTURE_EXP]:
    'qcRequest.requestOptions.manufactureExp',
  [REQUEST_TYPE_VALUE.REQUEST_ARISES]: 'qcRequest.requestOptions.requestArises',
  [REQUEST_TYPE_VALUE.REQUEST_OUTSIDE]:
    'qcRequest.requestOptions.requestOutside',
};
