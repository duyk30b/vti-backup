import { NATS_QMSX } from '@config/nats.config';
import { ACTIVE_ENUM } from '@constant/common';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern, Payload } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateCauseRequestDto } from './dto/request/create-cause.request.dto';
import { GetListCauseRequestDto } from './dto/request/get-list-cause.request.dto';
import { UpdateCauseBodyDto } from './dto/request/update-cause.request.dto';
import { CauseServiceInterface } from './interface/cause.service.interface';

@Controller('causes')
export class CauseController {
  constructor(
    @Inject('CauseServiceInterface')
    private causeService: CauseServiceInterface,
  ) {}

  @Post()
  @ApiOperation({
    tags: ['Cause - Nguyên nhân'],
    summary: 'Tạo nguyên nhân',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
  })
  @MessagePattern(`${NATS_QMSX}.createCause`)
  async create(@Payload() payload: CreateCauseRequestDto) {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.causeService.create(request);
  }

  @Get()
  @ApiOperation({
    tags: ['Cause - Nguyên nhân'],
    summary: 'Danh sách nguyên nhân',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
  })
  @MessagePattern(`${NATS_QMSX}.getListCause`)
  async getList(@Query() payload: GetListCauseRequestDto) {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.causeService.getList(request);
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['Cause - Nguyên nhân'],
    summary: 'Chi tiết nguyên nhân',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
  })
  @MessagePattern(`${NATS_QMSX}.getCauseDetail`)
  async getDetail(@Param() param: IdParamMongoDto) {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.causeService.getDetail(request);
  }

  @Put('/:id')
  @ApiOperation({
    tags: ['Cause - Nguyên nhân'],
    summary: 'Sửa nguyên nhân',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  @MessagePattern(`${NATS_QMSX}.updateCause`)
  async update(
    @Param() param: IdParamMongoDto,
    @Body() payload: UpdateCauseBodyDto,
  ): Promise<any> {
    const { request: requestParam, responseError: responseParamError } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.causeService.update({
      id: requestParam.id,
      ...request,
    });
  }

  @Delete('/:id')
  @ApiOperation({
    tags: ['Cause - Nguyên nhân'],
    summary: 'Xóa nguyên nhân',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
  })
  @MessagePattern(`${NATS_QMSX}.removeCause`)
  async remove(@Param() param: IdParamMongoDto) {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.causeService.remove(request);
  }

  @Put('/:id/active')
  @ApiOperation({
    tags: ['Cause - Nguyên nhân'],
    summary: 'Tạm dừng nguyên nhân',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async active(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.causeService.updateActiveStatus({
      ...request,
      status: ACTIVE_ENUM.ACTIVE,
    });
  }

  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Cause - Nguyên nhân'],
    summary: 'Hoạt động nguyên nhân',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async inactive(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.causeService.updateActiveStatus({
      ...request,
      status: ACTIVE_ENUM.INACTIVE,
    });
  }
}
