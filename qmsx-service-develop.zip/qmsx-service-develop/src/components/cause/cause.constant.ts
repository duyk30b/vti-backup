export const CAUSE_CONST = {
  CODE: {
    MAX_LENGTH: 50,
  },
  NAME: {
    MAX_LENGTH: 255,
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
};

export const REGEX_PADDING_ZERO = /^0+/;
export const EMPTY_STRING = '';
export const PREFIX_CAUSE_CODE = 'MNN';
export const FORMAT_SHORT_YEAR = 'YY';
export const INDEX_CAUSE_CODE_START = 1;
export const STEP_INDEX_CAUSE_CODE = 1;
export const MAX_LENGTH_INDEX = 6;
export const PADDING_SYMBOL = '0';
