import { CAUSE_CONST } from '@components/cause/cause.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsOptional, MaxLength } from 'class-validator';

export class CreateCauseRequestDto extends BaseDto {
  @ApiProperty({ example: 'MK01', required: true })
  @MaxLength(CAUSE_CONST.CODE.MAX_LENGTH)
  @IsOptional()
  code: string;

  @ApiProperty({ example: 'name', required: true })
  @MaxLength(CAUSE_CONST.NAME.MAX_LENGTH)
  @IsNotEmpty()
  name: string;

  @ApiProperty({ example: 'description', required: false })
  @MaxLength(CAUSE_CONST.DESCRIPTION.MAX_LENGTH)
  @IsOptional()
  description: string;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  isActive: number;
}
