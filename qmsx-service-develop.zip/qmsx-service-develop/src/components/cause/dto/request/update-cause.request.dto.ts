import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateCauseRequestDto } from './create-cause.request.dto';

export class UpdateCauseBodyDto extends CreateCauseRequestDto {}

export class UpdateCauseRequestDto extends UpdateCauseBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
