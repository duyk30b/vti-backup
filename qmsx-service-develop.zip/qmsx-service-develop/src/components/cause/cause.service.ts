import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ACTIVE_ENUM } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { compact, isEmpty, isNumber, keyBy, map, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import {
  getDataInsert,
  getDataToInsertError,
  getDataToUpdateError,
  getDataUpdate,
} from 'src/helper/import.helper';
import {
  EMPTY_STRING,
  INDEX_CAUSE_CODE_START,
  MAX_LENGTH_INDEX,
  PADDING_SYMBOL,
  PREFIX_CAUSE_CODE,
  REGEX_PADDING_ZERO,
  STEP_INDEX_CAUSE_CODE,
} from './cause.constant';
import { CreateCauseRequestDto } from './dto/request/create-cause.request.dto';
import { GetListCauseRequestDto } from './dto/request/get-list-cause.request.dto';
import { UpdateCauseRequestDto } from './dto/request/update-cause.request.dto';
import { CauseResponseDto } from './dto/response/cause.response.dto';
import { CauseRepositoryInterface } from './interface/cause.repository.interface';
import { CauseServiceInterface } from './interface/cause.service.interface';

@Injectable()
export class CauseService implements CauseServiceInterface {
  constructor(
    @Inject('CauseRepositoryInterface')
    private causeRepository: CauseRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateCauseRequestDto) {
    try {
      const { code } = request;
      const causeCheck = await this.causeRepository.findOneByCode(code);
      if (!isEmpty(causeCheck)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.CAUSE_CODE_EXIST'))
          .build();
      }

      const document = this.causeRepository.createModel(request);
      document.code = await this.generateCauseCode();
      const dataSave = await document.save();
      const dataReturn = plainToInstance(CauseResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getDetail(request: IdParamMongoDto) {
    try {
      const { id } = request;
      const causeDataDetail = await this.causeRepository.findOneById(id);
      if (!causeDataDetail) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }

      const dataReturn = plainToInstance(CauseResponseDto, causeDataDetail, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getList(request: GetListCauseRequestDto): Promise<any> {
    const { data, count } = await this.causeRepository.getList(request);
    const userIds = uniq(compact(map(data, 'createdBy')));

    // Filter by user id
    const userIdFilters = [
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ];

    if (!isEmpty(userIds)) {
      let users = await this.userService.getList(userIdFilters);
      users = keyBy(users, 'id');
      data.forEach((item) => {
        item.createdBy = {
          id: users[item.createdBy]?.id,
          username: users[item.createdBy]?.username,
          fullName: users[item.createdBy]?.fullName,
          code: users[item.createdBy]?.code,
        };
      });
    }

    const dataReturn = plainToInstance(CauseResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async update(request: UpdateCauseRequestDto) {
    try {
      const { id } = request;
      let causeDataDetail = await this.causeRepository.findOneById(id);
      if (!causeDataDetail) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }
      causeDataDetail = this.causeRepository.updateModel(
        causeDataDetail,
        request,
      );
      const dataSave = await this.causeRepository.findByIdAndUpdate(
        id,
        causeDataDetail,
      );
      const dataReturn = plainToInstance(CauseResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async remove(request: any): Promise<any> {
    try {
      const { id } = request;
      const causeDataDetail = await this.causeRepository.findOneById(id);
      if (!causeDataDetail) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      } else {
        await this.causeRepository.deleteById(id);
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
      }
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async updateActiveStatus(request: UpdateActiveStatusPayload): Promise<any> {
    const { id, status } = request;
    const error = await this.causeRepository.findOneById(id);
    if (!error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    await this.causeRepository.findByIdAndUpdate(id, {
      $set: { isActive: status },
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private getErrorValidateExcel(data: any[], i18n: I18nRequestScopeService) {
    const dataError = [];
    const dataRes = [];
    data.forEach((item) => {
      if (
        item.action !== i18n.translate('import.common.add') &&
        item.action !== i18n.translate('import.common.edit')
      ) {
        dataError.push({
          ...item,
          errorDesc: i18n.translate('import.error.action'),
        });
      } else if (new RegExp(/[^0-9a-zA-Z]/g).test(item?.code)) {
        dataError.push({
          ...item,
          errorDesc: i18n.translate('import.cause.codeInvalid'),
        });
      } else if (
        item?.isActive !== ACTIVE_ENUM.ACTIVE &&
        item?.isActive !== ACTIVE_ENUM.INACTIVE
      ) {
        dataError.push({
          ...item,
          errorDesc: i18n.translate('import.error.active'),
        });
      } else
        dataRes.push({
          ...item,
          description: item.description ? item.description : '',
        });
    });
    return { dataErrorValidate: dataError, dataPass: dataRes };
  }

  async import(
    data: any,
    userId: number,
  ): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const textAdd = await this.i18n.translate('import.common.add');

    const { dataErrorValidate, dataPass } = this.getErrorValidateExcel(
      data,
      this.i18n,
    );

    let { dataToInsert, codesInsert } = getDataInsert(dataPass, textAdd);
    dataToInsert = dataToInsert.map((item) => {
      return { ...item, createdBy: userId };
    });
    const { dataToUpdate, codesUpdate } = getDataUpdate(dataPass, textAdd);

    const codeInsertExists = await this.causeRepository.findAllByCondition({
      code: { $in: codesInsert },
    });
    const codeUpdateExists = await this.causeRepository.findAllByCondition({
      code: { $in: codesUpdate },
    });

    const codeInsertMap = keyBy(codeInsertExists, 'code');
    const codeUpdateMap = keyBy(codeUpdateExists, 'code');

    const { dataError: dataInsertError, dataInsert } = getDataToInsertError(
      dataToInsert,
      codeInsertMap,
    );
    const { dataError: dataUpdateError, dataUpdate } = getDataToUpdateError(
      dataToUpdate,
      codeUpdateMap,
    );

    const bulkOps = [...dataInsert, ...dataUpdate].map((doc) => ({
      updateOne: {
        filter: { code: doc.code },
        update: doc,
        upsert: true,
      },
    }));

    const dataSuccess = await this.causeRepository.bulkWrite(bulkOps);

    return {
      dataError: [...dataInsertError, ...dataUpdateError, ...dataErrorValidate],
      dataSuccess,
    };
  }

  private async generateCauseCode(): Promise<any> {
    const lastCause = await this.causeRepository.getLastCause();

    let index = INDEX_CAUSE_CODE_START;
    if (!isEmpty(lastCause)) {
      const lastCode: string = lastCause.code;
      if (!isEmpty(lastCode) && lastCode.length > PREFIX_CAUSE_CODE.length) {
        let lastIndex: any = lastCode
          .substring(PREFIX_CAUSE_CODE.length)
          .replace(REGEX_PADDING_ZERO, EMPTY_STRING);
        lastIndex = Number(lastIndex);
        if (!isNaN(lastIndex)) {
          index = lastIndex + STEP_INDEX_CAUSE_CODE;
        }
      }
    }

    const codeNew = `${PREFIX_CAUSE_CODE}${index
      ?.toString()
      .padStart(MAX_LENGTH_INDEX, PADDING_SYMBOL)}`;

    const existCode = await this.causeRepository.findOneByCode(codeNew);

    if (!isEmpty(existCode)) {
      return this.generateCauseCode();
    }

    return codeNew;
  }
}
