import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { CreateCauseRequestDto } from '../dto/request/create-cause.request.dto';
import { GetListCauseRequestDto } from '../dto/request/get-list-cause.request.dto';
import { UpdateCauseBodyDto } from '../dto/request/update-cause.request.dto';
import { CauseCollection } from 'src/models/cause/cause.schema';

export interface CauseRepositoryInterface
  extends BaseInterfaceRepository<CauseCollection> {
  createModel(request: CreateCauseRequestDto): CauseCollection;
  updateModel(
    cause: CauseCollection,
    request: UpdateCauseBodyDto,
  ): CauseCollection;
  getList(request: GetListCauseRequestDto): Promise<any>;
  getLastCause(): Promise<any>;
}
