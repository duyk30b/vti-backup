import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { CreateCauseRequestDto } from '../dto/request/create-cause.request.dto';
import { GetListCauseRequestDto } from '../dto/request/get-list-cause.request.dto';
import { UpdateCauseRequestDto } from '../dto/request/update-cause.request.dto';

export interface CauseServiceInterface {
  create(request: CreateCauseRequestDto): Promise<any>;
  getList(request: GetListCauseRequestDto): Promise<any>;
  getDetail(request: IdParamMongoDto): Promise<any>;
  update(request: UpdateCauseRequestDto): Promise<any>;
  remove(request: any): Promise<any>;
  updateActiveStatus(request: UpdateActiveStatusPayload): Promise<any>;
  import(
    data: any,
    userId: number,
  ): Promise<{ dataSuccess: any[]; dataError: any[] }>;
}
