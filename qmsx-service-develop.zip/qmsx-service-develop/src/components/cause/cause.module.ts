import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { CauseCollection, CauseSchema } from 'src/models/cause/cause.schema';
import { CauseRepository } from 'src/repository/cause/cause.repository';
import { CauseController } from './cause.controller';
import { CauseService } from './cause.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: CauseCollection.name,
        schema: CauseSchema,
      },
    ]),
  ],
  controllers: [CauseController],
  providers: [
    {
      provide: 'CauseServiceInterface',
      useClass: CauseService,
    },
    {
      provide: 'CauseRepositoryInterface',
      useClass: CauseRepository,
    },
  ],
  exports: [
    {
      provide: 'CauseRepositoryInterface',
      useClass: CauseRepository,
    },
  ],
})
export class CauseModule {}
