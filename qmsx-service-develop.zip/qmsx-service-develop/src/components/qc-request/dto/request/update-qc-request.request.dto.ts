import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateQCRequestRequestDto } from './create-qc-request.request.dto';

export class UpdateQCRequestBodyDto extends CreateQCRequestRequestDto {}

export class UpdateQCRequestRequestDto extends UpdateQCRequestBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
