import {
  CHECK_TYPE,
  PROPOSE_PROCESS,
  QC_REQUEST_CONST,
  QC_REQUEST_STATUS,
  REQUEST_SOURCE,
} from '@components/qc-request/qc-request.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsPositive,
  IsString,
  MaxLength,
  MinLength,
  ValidateNested,
} from 'class-validator';

class ItemRequest {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  itemType: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  code: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  name: string;

  @ApiProperty()
  @IsOptional()
  @IsEnum(CHECK_TYPE)
  checkType: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  lot: string;

  @ApiProperty()
  @IsNotEmpty()
  planQuantity: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  unit: string;
}

export class CreateQCRequestRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @MaxLength(QC_REQUEST_CONST.CODE.MAX_LENGTH)
  @MinLength(QC_REQUEST_CONST.CODE.MIN_LENGTH)
  @IsString()
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @MaxLength(QC_REQUEST_CONST.NAME.MAX_LENGTH)
  @MinLength(QC_REQUEST_CONST.NAME.MIN_LENGTH)
  @IsString()
  name: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(REQUEST_SOURCE)
  requestSource: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  requestType: string;

  @ApiProperty()
  @IsOptional()
  @IsPositive()
  requestBy: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  returnDate: Date;

  @ApiProperty()
  @IsOptional()
  @IsString()
  ticket: string;

  @ApiProperty()
  @IsOptional()
  @IsEnum(PROPOSE_PROCESS)
  proposeProcess: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  workOrder: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  description: string;

  @ApiProperty({ type: ItemRequest, isArray: true })
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => ItemRequest)
  items: ItemRequest[];

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(QC_REQUEST_STATUS)
  status: number;
}
