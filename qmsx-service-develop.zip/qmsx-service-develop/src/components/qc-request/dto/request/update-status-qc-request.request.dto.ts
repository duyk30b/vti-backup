import { QC_REQUEST_STATUS } from '@components/qc-request/qc-request.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsMongoId, IsNotEmpty } from 'class-validator';

export class UpdateStatusQCRequestRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(QC_REQUEST_STATUS)
  status: number;
}
