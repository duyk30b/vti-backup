import { UserResponseDto } from '@components/user/dto/response/user.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class ItemRequestResponseDto {
  @Expose()
  itemType: string;

  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  checkType: number;

  @Expose()
  lot: string;

  @Expose()
  planQuantity: number;

  @Expose()
  remainPlanCommandQuantity: number;

  @Expose()
  unit: string;
}

export class QCRequestResponseDto extends BaseResponseDto {
  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  requestSource: number;

  @Expose()
  requestType: string;

  @Expose({ name: 'requestBy' })
  @Type(() => UserResponseDto)
  requestBy: UserResponseDto;

  @Expose()
  returnDate: Date;

  @Expose()
  ticket: string;

  @Expose()
  proposeProcess: number;

  @Expose()
  workOrder: string;

  @Expose()
  description: string;

  @ApiProperty({ type: ItemRequestResponseDto, isArray: true })
  @Type(() => ItemRequestResponseDto)
  @Expose()
  items: ItemRequestResponseDto[];

  @Expose()
  status: number;
}
