import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';
import { QCRequestResponseDto } from './qc-request.response.dto';

export class ListQCRequestResponseDto extends PaginationResponse {
  @ApiProperty({ type: QCRequestResponseDto, isArray: true })
  @Type(() => QCRequestResponseDto)
  @Expose()
  items: QCRequestResponseDto[];
}
