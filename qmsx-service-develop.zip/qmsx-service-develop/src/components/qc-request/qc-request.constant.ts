import { CODE_REGEX } from '@constant/common';

export enum QC_REQUEST_STATUS {
  DRAFT,
  WAITING,
  CONFIRMED,
  REJECTED,
  IN_PROGRESS,
  COMPLETED,
}

export enum CHECK_TYPE {
  MEASURE,
  STATUS,
}

export enum REQUEST_SOURCE {
  MESX,
  WMSX,
  QMSX,
}

export enum PROPOSE_PROCESS {
  NO,
  YES,
}

export const QC_REQUEST_CONST = {
  CODE: {
    MIN_LENGTH: 6,
    MAX_LENGTH: 255,
    COLUMN: 'code',
    REGEX: CODE_REGEX,
  },
  NAME: {
    MIN_LENGTH: 3,
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  DESCRIPTION: {
    COLUMN: 'description',
  },
};

export enum REQUEST_TYPE_ENUM {
  IMP_PO, //phiếu nhập kho
  IMP_PRO,
  IMP_IMO,
  EXP_SO, //phiếu xuất kho
  EXP_PRO,
  EXP_EXO,
  MANUFACTURE_IMP,
  MANUFACTURE_EXP,
  REQUEST_ARISES, //giấy đề nghị
  REQUEST_OUTSIDE, //đảo hàng
}

export const REQUEST_TYPE_MAP = {
  0: 'impPO',
  1: 'impPRO',
  2: 'impIMO',
  3: 'expSO',
  4: 'expPRO',
  5: 'expEXO',
  6: 'manufactureImp',
  7: 'manufactureExp',
  8: 'requestArises',
  9: 'requestOutside',
};

export const REGEX_PADDING_ZERO = /^0+/;
export const EMPTY_STRING = '';
export const PREFIX_QC_REQUEST_CODE = 'YCQC';
export const FORMAT_SHORT_YEAR = 'YY';
export const INDEX_QC_REQUEST_CODE_START = 1;
export const STEP_INDEX_QC_REQUEST_CODE = 1;
export const MAX_LENGTH_INDEX = 6;
export const PADDING_SYMBOL = '0';
