import { CauseRepositoryInterface } from '@components/cause/interface/cause.repository.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { compact, concat, isEmpty, keyBy, map, uniq } from 'lodash';
import * as moment from 'moment';
import { I18nRequestScopeService } from 'nestjs-i18n';
import {
  getDataInsert,
  getDataToUpdateError,
  getDataUpdate,
} from 'src/helper/import.helper';
import { CreateQCRequestRequestDto } from './dto/request/create-qc-request.request.dto';
import { GetDetailQCRequestRequestDto } from './dto/request/get-detail-qc-request.request.dto';
import { GetListQCRequestRequestDto } from './dto/request/get-list-qc-request.request.dto';
import { UpdateQCRequestRequestDto } from './dto/request/update-qc-request.request.dto';
import { UpdateStatusQCRequestRequestDto } from './dto/request/update-status-qc-request.request.dto';
import { QCRequestResponseDto } from './dto/response/qc-request.response.dto';
import { QCRequestRepositoryInterface } from './interface/qc-request.repository.interface';
import { QCRequestServiceInterface } from './interface/qc-request.service.interface';
import {
  EMPTY_STRING,
  FORMAT_SHORT_YEAR,
  INDEX_QC_REQUEST_CODE_START,
  MAX_LENGTH_INDEX,
  PADDING_SYMBOL,
  PREFIX_QC_REQUEST_CODE,
  REGEX_PADDING_ZERO,
  STEP_INDEX_QC_REQUEST_CODE,
} from './qc-request.constant';
import { QCCommandRepositoryInterface } from '@components/qc-command/interface/qc-command.repository.interface';

@Injectable()
export class QCRequestService implements QCRequestServiceInterface {
  constructor(
    @Inject('CauseRepositoryInterface')
    private readonly causeRepository: CauseRepositoryInterface,

    @Inject('QCRequestRepositoryInterface')
    private readonly qcRequestRepository: QCRequestRepositoryInterface,

    @Inject('QCCommandRepositoryInterface')
    private readonly qcCommandRepository: QCCommandRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateQCRequestRequestDto): Promise<any> {
    try {
      const { code } = request;
      const qcRequest = await this.qcRequestRepository.findOneByCode(code);
      if (!isEmpty(qcRequest)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.QC_REQUEST_CODE_EXIST'))
          .build();
      }

      const document = this.qcRequestRepository.createModel(request);
      document.code = await this.generateQCRequestCode();
      const dataSave = await document.save();
      const dataReturn = plainToInstance(QCRequestResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getDetail(request: GetDetailQCRequestRequestDto): Promise<any> {
    try {
      const { id } = request;
      const qcRequest: any = await this.qcRequestRepository.findOneById(id);
      if (isEmpty(qcRequest)) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      const createdBy = await this.userService.getDetail(qcRequest.createdBy);
      const requestBy = await this.userService.getDetail(qcRequest.requestBy);

      if (!isEmpty(createdBy)) {
        qcRequest.createdBy = createdBy;
      }

      if (!isEmpty(requestBy)) {
        qcRequest.requestBy = requestBy;
      }

      const dataReturn = plainToInstance(QCRequestResponseDto, qcRequest, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getList(request: GetListQCRequestRequestDto): Promise<any> {
    let { data, count } = await this.qcRequestRepository.getList(request);
    const createdBy = compact(map(data, 'createdBy'));
    const requestBy = compact(map(data, 'requestBy'));
    const userIds = uniq(concat(createdBy, requestBy));

    data = await Promise.all(
      data.map(async (qcRequest) => {
        let qcCommandGroupBy = (
          await this.qcCommandRepository.getTotalPlanExecuteQuantityItems(
            qcRequest.code,
          )
        ).map((j) => {
          return { ...j, keyMap: `${j._id.itemCode}-${j._id.lot}` };
        });
        if (qcCommandGroupBy.length) {
          qcCommandGroupBy = keyBy(qcCommandGroupBy, 'keyMap');
        }
        qcRequest.items.map((item) => {
          const remainPlanCommandQuantity =
            item.planQuantity -
            qcCommandGroupBy[`${item.code}-${item.lot}`]
              ?.totalPlanExecuteQuantity;
          item.remainPlanCommandQuantity = remainPlanCommandQuantity || 0;
          return item;
        });
        return qcRequest;
      }),
    );

    // Filter by user id
    const userIdFilters = [
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ];

    if (!isEmpty(userIds)) {
      let users = await this.userService.getList(userIdFilters);
      users = keyBy(users, 'id');
      data.forEach((item) => {
        item.createdBy = {
          id: users[item.createdBy]?.id,
          username: users[item.createdBy]?.username,
          fullName: users[item.createdBy]?.fullName,
          code: users[item.createdBy]?.code,
        };
        item.requestBy = {
          id: users[item.requestBy]?.id,
          username: users[item.requestBy]?.username,
          fullName: users[item.requestBy]?.fullName,
          code: users[item.requestBy]?.code,
        };
      });
    }

    const dataReturn = plainToInstance(QCRequestResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async update(request: UpdateQCRequestRequestDto): Promise<any> {
    try {
      const { id } = request;
      let qcRequest = await this.qcRequestRepository.findOneById(id);
      if (!qcRequest) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }
      qcRequest = this.qcRequestRepository.updateModel(qcRequest, request);

      const dataSave = await this.qcRequestRepository.findByIdAndUpdate(
        id,
        qcRequest,
      );

      const dataReturn = plainToInstance(QCRequestResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async delete(request: IdParamMongoDto): Promise<any> {
    const { id } = request;
    const qcRequest = await this.qcRequestRepository.findOneByCondition(id);
    if (!qcRequest) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    await this.qcRequestRepository.deleteById(id);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateStatus(request: UpdateStatusQCRequestRequestDto): Promise<any> {
    const { id, status } = request;
    const qcRequest = await this.qcRequestRepository.findOneById(id);
    if (!qcRequest) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }

    await this.qcRequestRepository.findByIdAndUpdate(id, {
      $set: { status: status },
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const textAdd = await this.i18n.translate('import.common.add');

    const { dataToInsert } = getDataInsert(data, textAdd);
    const { dataToUpdate, codesUpdate } = getDataUpdate(data, textAdd);

    const codeUpdateExists = await this.qcRequestRepository.findAllByCondition({
      code: { $in: codesUpdate },
    });
    const codeUpdateMap = keyBy(codeUpdateExists, 'code');

    const { dataError, dataUpdate } = getDataToUpdateError(
      dataToUpdate,
      codeUpdateMap,
    );

    const bulkOps = [...dataToInsert, ...dataUpdate].map((doc) => ({
      updateOne: {
        filter: { code: doc.code },
        update: doc,
        upsert: true,
      },
    }));

    const dataSuccess = await this.qcRequestRepository.bulkWrite(bulkOps);

    return { dataError, dataSuccess };
  }

  private async generateQCRequestCode(): Promise<any> {
    const shortYear = moment().format(FORMAT_SHORT_YEAR);
    const prefixWithYear = `${PREFIX_QC_REQUEST_CODE}${shortYear}`;

    const lastQCRequest = await this.qcRequestRepository.getLastQCRequest(
      prefixWithYear,
    );

    let index = INDEX_QC_REQUEST_CODE_START;
    if (!isEmpty(lastQCRequest)) {
      const lastCode: string = lastQCRequest.code;
      if (!isEmpty(lastCode) && lastCode.length > prefixWithYear.length) {
        let lastIndex: any = lastCode
          .substring(prefixWithYear.length)
          .replace(REGEX_PADDING_ZERO, EMPTY_STRING);
        lastIndex = Number(lastIndex);
        if (!isNaN(lastIndex)) {
          index = lastIndex + STEP_INDEX_QC_REQUEST_CODE;
        }
      }
    }

    const codeNew = `${prefixWithYear}${index
      ?.toString()
      .padStart(MAX_LENGTH_INDEX, PADDING_SYMBOL)}`;

    const existCode = await this.qcRequestRepository.findOneByCode(codeNew);

    if (!isEmpty(existCode)) {
      return this.generateQCRequestCode();
    }

    return codeNew;
  }
}
