import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateQCRequestRequestDto } from './dto/request/create-qc-request.request.dto';
import { GetDetailQCRequestRequestDto } from './dto/request/get-detail-qc-request.request.dto';
import { GetListQCRequestRequestDto } from './dto/request/get-list-qc-request.request.dto';
import { UpdateQCRequestBodyDto } from './dto/request/update-qc-request.request.dto';
import { ListQCRequestResponseDto } from './dto/response/list-qc-request.response.dto';
import { QCRequestResponseDto } from './dto/response/qc-request.response.dto';
import { QCRequestServiceInterface } from './interface/qc-request.service.interface';
import { QC_REQUEST_STATUS } from './qc-request.constant';

@Controller('qc-requests')
export class QCRequestController {
  constructor(
    @Inject('QCRequestServiceInterface')
    private readonly qcRequestService: QCRequestServiceInterface,
  ) {}

  @Post()
  @ApiOperation({
    tags: ['QC Request - Yêu cầu QC'],
    summary: 'Thêm yêu cầu QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Add Successfully',
    type: QCRequestResponseDto,
  })
  async create(@Body() payload: CreateQCRequestRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.qcRequestService.create(request);
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['QC Request - Yêu cầu QC'],
    summary: 'Chi tiết yêu cầu QC',
    description: 'Chi tiết yêu cầu QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: QCRequestResponseDto,
  })
  async getDetail(@Param() param: GetDetailQCRequestRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qcRequestService.getDetail(request);
  }

  @Get()
  @ApiOperation({
    tags: ['QC Request - Yêu cầu QC'],
    summary: 'Danh sách yêu cầu QC',
    description: 'Danh sách yêu cầu QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListQCRequestResponseDto,
  })
  async getList(@Query() query: GetListQCRequestRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qcRequestService.getList(request);
  }

  @Put('/:id')
  @ApiOperation({
    tags: ['QC Request - Yêu cầu QC'],
    summary: 'Sửa yêu cầu QC',
    description: 'Sửa yêu cầu QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async update(
    @Param() param: IdParamMongoDto,
    @Body() payload: UpdateQCRequestBodyDto,
  ): Promise<any> {
    const { request: requestParam, responseError: responseParamQCRequest } =
      param;
    if (responseParamQCRequest && !isEmpty(responseParamQCRequest)) {
      return responseParamQCRequest;
    }
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.qcRequestService.update({
      id: requestParam.id,
      ...request,
    });
  }

  @Delete('/:id')
  @ApiOperation({
    tags: ['QC Request - Yêu cầu QC'],
    summary: 'Xóa yêu cầu QC',
    description: 'Xóa yêu cầu QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async delete(@Param() param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.qcRequestService.delete(request);
  }

  @Put('/:id/submit')
  @ApiOperation({
    tags: ['QC Request - Yêu cầu QC'],
    summary: 'Gửi yêu cầu QC',
    description: 'Gửi yêu cầu QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async submit(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qcRequestService.updateStatus({
      ...request,
      status: QC_REQUEST_STATUS.WAITING,
    });
  }

  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['QC Request - Yêu cầu QC'],
    summary: 'Xác nhận yêu cầu QC',
    description: 'Xác nhận yêu cầu QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async confirm(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qcRequestService.updateStatus({
      ...request,
      status: QC_REQUEST_STATUS.CONFIRMED,
    });
  }

  @Put('/:id/reject')
  @ApiOperation({
    tags: ['QC Request - Yêu cầu QC'],
    summary: 'Từ chối yêu cầu QC',
    description: 'Từ chối yêu cầu QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async reject(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qcRequestService.updateStatus({
      ...request,
      status: QC_REQUEST_STATUS.REJECTED,
    });
  }
}
