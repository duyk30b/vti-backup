import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { CreateQCRequestRequestDto } from '../dto/request/create-qc-request.request.dto';
import { GetDetailQCRequestRequestDto } from '../dto/request/get-detail-qc-request.request.dto';
import { GetListQCRequestRequestDto } from '../dto/request/get-list-qc-request.request.dto';
import { UpdateQCRequestRequestDto } from '../dto/request/update-qc-request.request.dto';
import { UpdateStatusQCRequestRequestDto } from '../dto/request/update-status-qc-request.request.dto';

export interface QCRequestServiceInterface {
  create(request: CreateQCRequestRequestDto): Promise<any>;
  update(request: UpdateQCRequestRequestDto): Promise<any>;
  getDetail(request: GetDetailQCRequestRequestDto): Promise<any>;
  getList(request: GetListQCRequestRequestDto): Promise<any>;
  delete(request: IdParamMongoDto): Promise<any>;
  updateStatus(request: UpdateStatusQCRequestRequestDto): Promise<any>;
  import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }>;
}
