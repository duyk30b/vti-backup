import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { QCRequest } from 'src/models/qc-request/qc-request.schema';
import { CreateQCRequestRequestDto } from '../dto/request/create-qc-request.request.dto';
import { GetListQCRequestRequestDto } from '../dto/request/get-list-qc-request.request.dto';
import { GetQCRequestReportRequestDto } from '../../qc-report/dto/request/get-qc-request-report.request.dto';
import { UpdateQCRequestBodyDto } from '../dto/request/update-qc-request.request.dto';

export interface QCRequestRepositoryInterface
  extends BaseInterfaceRepository<QCRequest> {
  createModel(request: CreateQCRequestRequestDto): QCRequest;
  updateModel(qcRequest: QCRequest, request: UpdateQCRequestBodyDto): QCRequest;
  getList(request: GetListQCRequestRequestDto): Promise<any>;
  getLastQCRequest(prefixWithYear: string): Promise<any>;
  getQCRequestReport(request: GetQCRequestReportRequestDto): Promise<any>;
}
