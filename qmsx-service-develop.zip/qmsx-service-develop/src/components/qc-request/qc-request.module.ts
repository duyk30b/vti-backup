import { CauseModule } from '@components/cause/cause.module';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { CauseCollection, CauseSchema } from 'src/models/cause/cause.schema';
import {
  QCRequest,
  QCRequestSchema,
} from 'src/models/qc-request/qc-request.schema';
import { QCRequestRepository } from 'src/repository/qc-request/qc-request.repository';
import { QCRequestController } from './qc-request.controller';
import { QCRequestService } from './qc-request.service';
import { QCCommandRepository } from 'src/repository/qc-command/qc-command.repository';
import { QcCommandModule } from '@components/qc-command/qc-command.module';
import {
  QCCommand,
  QCCommandSchema,
} from 'src/models/qc-command/qc-command.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: QCCommand.name,
        schema: QCCommandSchema,
      },
      {
        name: QCRequest.name,
        schema: QCRequestSchema,
      },
      {
        name: CauseCollection.name,
        schema: CauseSchema,
      },
    ]),
    CauseModule,
    QcCommandModule,
  ],
  controllers: [QCRequestController],
  providers: [
    {
      provide: 'QCRequestServiceInterface',
      useClass: QCRequestService,
    },
    {
      provide: 'QCRequestRepositoryInterface',
      useClass: QCRequestRepository,
    },
    {
      provide: 'QCCommandRepositoryInterface',
      useClass: QCCommandRepository,
    },
  ],
  exports: [
    {
      provide: 'QCRequestServiceInterface',
      useClass: QCRequestService,
    },
    {
      provide: 'QCRequestRepositoryInterface',
      useClass: QCRequestRepository,
    },
  ],
})
export class QCRequestModule {}
