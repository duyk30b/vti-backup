import { ErrorResponseDto } from '@components/error/dto/response/error.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { Expose, Type } from 'class-transformer';
import { Types } from 'mongoose';

export class EvaluationCriteriaDetail {
  @Expose()
  name: string;

  @Expose()
  description: string;

  @Expose()
  errorCodes: string[];

  @Expose()
  @Type(() => ErrorResponseDto)
  errors: ErrorResponseDto[];
}

export class EvaluationCriteriaResponseDto extends BaseResponseDto {
  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  checkType: number;

  @Expose()
  upperBound: number;

  @Expose()
  norm: number;

  @Expose()
  lowerBound: number;

  @Expose()
  description: string;

  @Expose()
  @Type(() => EvaluationCriteriaDetail)
  details: EvaluationCriteriaDetail[];

  @Expose()
  active: number;
}
