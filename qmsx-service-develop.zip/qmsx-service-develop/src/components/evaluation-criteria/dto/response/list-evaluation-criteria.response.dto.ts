import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';
import { EvaluationCriteriaResponseDto } from './evaluation-criteria.response.dto';

export class ListEvaluationCriteriaResponseDto extends PaginationResponse {
  @ApiProperty({ type: EvaluationCriteriaResponseDto, isArray: true })
  @Type(() => EvaluationCriteriaResponseDto)
  @Expose()
  items: EvaluationCriteriaResponseDto[];
}
