import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateEvaluationCriteriaRequestDto } from './evaluation-criteria.request.dto';

export class UpdateEvaluationCriteriaBodyDto extends CreateEvaluationCriteriaRequestDto {}

export class UpdateEvaluationCriteriaRequestDto extends UpdateEvaluationCriteriaBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
