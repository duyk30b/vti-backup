import {
  CHECK_TYPE,
  EVALUATION_CRITERIA_CONST,
} from '@components/evaluation-criteria/evaluation-criteria.constant';
import { ACTIVE_ENUM } from '@constant/common';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';
import { EvaluationCriteriaDetail } from 'src/models/evaluation-criteria/evaluation-criteria.schema';

export class CreateEvaluationCriteriaRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @MaxLength(EVALUATION_CRITERIA_CONST.CODE.MAX_LENGTH)
  @IsString()
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @MaxLength(EVALUATION_CRITERIA_CONST.NAME.MAX_LENGTH)
  @IsString()
  name: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(CHECK_TYPE)
  checkType: number;

  @ApiProperty()
  upperBound: number;

  @ApiProperty()
  norm: number;

  @ApiProperty()
  lowerBound: number;

  @ApiProperty()
  @IsOptional()
  @MaxLength(EVALUATION_CRITERIA_CONST.DESCRIPTION.MAX_LENGTH)
  @IsString()
  description: string;

  @ApiProperty()
  @IsOptional()
  @IsArray()
  details: EvaluationCriteriaDetail[];

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(ACTIVE_ENUM)
  active: number;
}
