import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import {
  EvaluationCriteria,
  EvaluationCriteriaSchema,
} from 'src/models/evaluation-criteria/evaluation-criteria.schema';
import { ErrorSchema } from 'src/models/error/error.schema';
import { EvaluationCriteriaRepository } from 'src/repository/evaluation-criteria/evaluation-criteria.repository';
import { ErrorRepository } from 'src/repository/error/error.repository';
import { EvaluationCriteriaController } from './evaluation-criteria.controller';
import { EvaluationCriteriaService } from './evaluation-criteria.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: EvaluationCriteria.name,
        schema: EvaluationCriteriaSchema,
      },
      {
        name: Error.name,
        schema: ErrorSchema,
      },
    ]),
  ],
  controllers: [EvaluationCriteriaController],
  providers: [
    {
      provide: 'EvaluationCriteriaServiceInterface',
      useClass: EvaluationCriteriaService,
    },
    {
      provide: 'EvaluationCriteriaRepositoryInterface',
      useClass: EvaluationCriteriaRepository,
    },
    {
      provide: 'ErrorRepositoryInterface',
      useClass: ErrorRepository,
    },
  ],
  exports: [
    {
      provide: 'EvaluationCriteriaServiceInterface',
      useClass: EvaluationCriteriaService,
    },
    {
      provide: 'EvaluationCriteriaRepositoryInterface',
      useClass: EvaluationCriteriaRepository,
    },
  ],
})
export class EvaluationCriteriaModule {}
