import { GetListErrorRequestDto } from '@components/error/dto/request/get-list-error.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { CreateEvaluationCriteriaRequestDto } from '../dto/request/evaluation-criteria.request.dto';
import { GetDetailEvaluationCriteriaRequestDto } from '../dto/request/get-detail-evaluation-criteria.request.dto';
import { UpdateEvaluationCriteriaRequestDto } from '../dto/request/update-evaluation-criteria.request.dto';

export interface EvaluationCriteriaServiceInterface {
  create(request: CreateEvaluationCriteriaRequestDto): Promise<any>;
  update(request: UpdateEvaluationCriteriaRequestDto): Promise<any>;
  getDetail(request: GetDetailEvaluationCriteriaRequestDto): Promise<any>;
  getList(request: GetListErrorRequestDto): Promise<any>;
  delete(request: IdParamMongoDto): Promise<any>;
  updateActiveStatus(request: UpdateActiveStatusPayload): Promise<any>;
  import(
    data: any,
    userId: number,
  ): Promise<{ dataSuccess: any[]; dataError: any[] }>;
}
