import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { EvaluationCriteria } from 'src/models/evaluation-criteria/evaluation-criteria.schema';
import { CreateEvaluationCriteriaRequestDto } from '../dto/request/evaluation-criteria.request.dto';
import { GetListEvaluationCriteriaRequestDto } from '../dto/request/get-list-evaluation-criteria.request.dto';
import { UpdateEvaluationCriteriaBodyDto } from '../dto/request/update-evaluation-criteria.request.dto';

export interface EvaluationCriteriaRepositoryInterface
  extends BaseInterfaceRepository<EvaluationCriteria> {
  createModel(request: CreateEvaluationCriteriaRequestDto): EvaluationCriteria;
  updateModel(
    error: EvaluationCriteria,
    request: UpdateEvaluationCriteriaBodyDto,
  ): EvaluationCriteria;
  getList(request: GetListEvaluationCriteriaRequestDto): Promise<any>;
  getLastEvaluationCriteria(): Promise<any>;
}
