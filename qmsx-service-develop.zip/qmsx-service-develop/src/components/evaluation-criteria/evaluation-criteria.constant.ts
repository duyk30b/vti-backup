import { CODE_REGEX } from '@constant/common';

export enum CHECK_TYPE {
  MEASURE,
  STATUS,
}

export const EVALUATION_CRITERIA_CONST = {
  CODE: {
    MAX_LENGTH: 50,
    COLUMN: 'code',
    REGEX: CODE_REGEX,
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  UPPER_BOUND: {
    MIN: 1,
    MAX: 99,
    COLUMN: 'upperBound',
  },
  NORM: {
    MIN: 1,
    MAX: 99,
    COLUMN: 'norm',
  },
  LOWER_BOUND: {
    MIN: 1,
    MAX: 99,
    COLUMN: 'lowerBound',
  },
  DESCRIPTION: {
    MAX_LENGTH: 1000,
    COLUMN: 'description',
  },
};

export const EVALUATION_CRITERIA_DETAIL_CONST = {
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
};

export const REGEX_PADDING_ZERO = /^0+/;
export const EMPTY_STRING = '';
export const PREFIX_EVALUATION_CRITERIA_CODE = 'TCDG';
export const FORMAT_SHORT_YEAR = 'YY';
export const INDEX_EVALUATION_CRITERIA_CODE_START = 1;
export const STEP_INDEX_EVALUATION_CRITERIA_CODE = 1;
export const MAX_LENGTH_INDEX = 6;
export const PADDING_SYMBOL = '0';
