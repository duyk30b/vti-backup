import { ACTIVE_ENUM } from '@constant/common';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateEvaluationCriteriaRequestDto } from './dto/request/evaluation-criteria.request.dto';
import { GetDetailEvaluationCriteriaRequestDto } from './dto/request/get-detail-evaluation-criteria.request.dto';
import { GetListEvaluationCriteriaRequestDto } from './dto/request/get-list-evaluation-criteria.request.dto';
import { UpdateEvaluationCriteriaBodyDto } from './dto/request/update-evaluation-criteria.request.dto';
import { EvaluationCriteriaResponseDto } from './dto/response/evaluation-criteria.response.dto';
import { ListEvaluationCriteriaResponseDto } from './dto/response/list-evaluation-criteria.response.dto';
import { EvaluationCriteriaServiceInterface } from './interface/evaluation-criteria.service.interface';

@Controller('evaluation-criterias')
export class EvaluationCriteriaController {
  constructor(
    @Inject('EvaluationCriteriaServiceInterface')
    private readonly evaluationCriteriaService: EvaluationCriteriaServiceInterface,
  ) {}

  @Post()
  @ApiOperation({
    tags: ['Evaluation Criteria - Tiêu chí đánh giá'],
    summary: 'Thêm tiêu chí đánh giá',
  })
  @ApiResponse({
    status: 200,
    description: 'Add Successfully',
    type: EvaluationCriteriaResponseDto,
  })
  async create(
    @Body() payload: CreateEvaluationCriteriaRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.evaluationCriteriaService.create(request);
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['Evaluation Criteria - Tiêu chí đánh giá'],
    summary: 'Chi tiết tiêu chí đánh giá',
    description: 'Chi tiết tiêu chí đánh giá',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: EvaluationCriteriaResponseDto,
  })
  async getDetail(
    @Param() param: GetDetailEvaluationCriteriaRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.evaluationCriteriaService.getDetail(request);
  }

  @Get()
  @ApiOperation({
    tags: ['Evaluation Criteria - Tiêu chí đánh giá'],
    summary: 'Danh sách tiêu chí đánh giá',
    description: 'Danh sách tiêu chí đánh giá',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListEvaluationCriteriaResponseDto,
  })
  async getList(
    @Query() query: GetListEvaluationCriteriaRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.evaluationCriteriaService.getList(request);
  }

  @Put('/:id')
  @ApiOperation({
    tags: ['Evaluation Criteria - Tiêu chí đánh giá'],
    summary: 'Sửa tiêu chí đánh giá',
    description: 'Sửa tiêu chí đánh giá',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async update(
    @Param() param: IdParamMongoDto,
    @Body() payload: UpdateEvaluationCriteriaBodyDto,
  ): Promise<any> {
    const { request: requestParam, responseError: responseParamError } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.evaluationCriteriaService.update({
      id: requestParam.id,
      ...request,
    });
  }

  @Delete('/:id')
  @ApiOperation({
    tags: ['Evaluation Criteria - Tiêu chí đánh giá'],
    summary: 'Xóa tiêu chí đánh giá',
    description: 'Xóa tiêu chí đánh giá',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async delete(@Param() param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.evaluationCriteriaService.delete(request);
  }

  @Put('/:id/active')
  @ApiOperation({
    tags: ['Evaluation Criteria - Tiêu chí đánh giá'],
    summary: 'Hoạt động tiêu chí đánh giá',
    description: 'Hoạt động tiêu chí đánh giá',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async active(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.evaluationCriteriaService.updateActiveStatus({
      ...request,
      status: ACTIVE_ENUM.ACTIVE,
    });
  }

  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Evaluation Criteria - Tiêu chí đánh giá'],
    summary: 'Tạm dừng tiêu chí đánh giá',
    description: 'Tạm dừng tiêu chí đánh giá',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async inactive(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.evaluationCriteriaService.updateActiveStatus({
      ...request,
      status: ACTIVE_ENUM.INACTIVE,
    });
  }
}
