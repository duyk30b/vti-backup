import { ErrorRepositoryInterface } from '@components/error/interface/error.repository.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ACTIVE_ENUM } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import {
  compact,
  difference,
  filter,
  flatten,
  isEmpty,
  isNumber,
  keyBy,
  map,
  uniq,
} from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import {
  getDataInsert,
  getDataToInsertError,
  getDataToUpdateError,
  getDataUpdate,
} from 'src/helper/import.helper';
import { CreateEvaluationCriteriaRequestDto } from './dto/request/evaluation-criteria.request.dto';
import { GetDetailEvaluationCriteriaRequestDto } from './dto/request/get-detail-evaluation-criteria.request.dto';
import { GetListEvaluationCriteriaRequestDto } from './dto/request/get-list-evaluation-criteria.request.dto';
import { UpdateEvaluationCriteriaRequestDto } from './dto/request/update-evaluation-criteria.request.dto';
import { EvaluationCriteriaResponseDto } from './dto/response/evaluation-criteria.response.dto';
import {
  EMPTY_STRING,
  INDEX_EVALUATION_CRITERIA_CODE_START,
  MAX_LENGTH_INDEX,
  PADDING_SYMBOL,
  PREFIX_EVALUATION_CRITERIA_CODE,
  REGEX_PADDING_ZERO,
  STEP_INDEX_EVALUATION_CRITERIA_CODE,
} from './evaluation-criteria.constant';
import { EvaluationCriteriaRepositoryInterface } from './interface/evaluation-criteria.repository.interface';
import { EvaluationCriteriaServiceInterface } from './interface/evaluation-criteria.service.interface';

@Injectable()
export class EvaluationCriteriaService
  implements EvaluationCriteriaServiceInterface
{
  constructor(
    @Inject('ErrorRepositoryInterface')
    private readonly errorRepository: ErrorRepositoryInterface,

    @Inject('EvaluationCriteriaRepositoryInterface')
    private readonly evaluationCriteriaRepository: EvaluationCriteriaRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateEvaluationCriteriaRequestDto): Promise<any> {
    try {
      const { code } = request;
      const evaluationCriteria =
        await this.evaluationCriteriaRepository.findOneByCode(code);
      if (!isEmpty(evaluationCriteria)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.EVALUATION_CRITERIA_CODE_EXIST'),
          )
          .build();
      }

      const validateResult = await this.validateError(request);
      if (validateResult.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validateResult;
      }

      const document = this.evaluationCriteriaRepository.createModel(request);
      document.code = await this.generateEvaluationCriteriaCode();
      const dataSave = await document.save();
      const dataReturn = plainToInstance(
        EvaluationCriteriaResponseDto,
        dataSave,
        {
          excludeExtraneousValues: true,
        },
      );
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  private async validateError(
    request: CreateEvaluationCriteriaRequestDto,
  ): Promise<any> {
    const errorCodes = uniq(flatten(request.details.map((i) => i.errorCodes)));

    const errorInactive = await this.errorRepository.findAllByCondition({
      code: {
        $in: errorCodes,
      },
      active: ACTIVE_ENUM.INACTIVE,
    });

    if (errorInactive.length > 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.LOCKED)
        .withMessage(
          `Lỗi ${errorInactive
            .map((i) => i.code)
            .join(', ')} đang ở trạng thái tạm dừng`,
        )
        .build();
    }

    const errorCodesFound = (
      await this.errorRepository.findAllByCondition({
        code: {
          $in: errorCodes,
        },
      })
    ).map((i) => i.code);
    const errorNotFound = difference(errorCodes, errorCodesFound);

    if (errorCodesFound.length !== errorCodes.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          `${await this.i18n.translate(
            'error.NOT_FOUND_ERROR',
          )} ${errorNotFound.join(', ')}`,
        )
        .build();
    }
    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async getDetail(
    request: GetDetailEvaluationCriteriaRequestDto,
  ): Promise<any> {
    try {
      const { id } = request;
      const evaluationCriteria =
        await this.evaluationCriteriaRepository.findOneById(id);
      if (!evaluationCriteria) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      const dataReturn = plainToInstance(
        EvaluationCriteriaResponseDto,
        evaluationCriteria,
        {
          excludeExtraneousValues: true,
        },
      );

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getList(request: GetListEvaluationCriteriaRequestDto): Promise<any> {
    const { data, count } = await this.evaluationCriteriaRepository.getList(
      request,
    );
    const userIds = uniq(compact(map(data, 'createdBy')));
    const errorCodes = uniq(
      flatten(map(flatten(map(data, 'details')), 'errorCodes')),
    );

    const errors = await this.errorRepository.findAllByCondition({
      code: {
        $in: errorCodes,
      },
    });

    // Filter by user id
    const userIdFilters = [
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ];

    if (!isEmpty(userIds)) {
      let users = await this.userService.getList(userIdFilters);
      users = keyBy(users, 'id');
      data.forEach((item) => {
        item.createdBy = {
          id: users[item.createdBy]?.id,
          username: users[item.createdBy]?.username,
          fullName: users[item.createdBy]?.fullName,
          code: users[item.createdBy]?.code,
        };
        item.details.forEach((detail) => {
          detail.errors = filter(errors, (error) => {
            return detail.errorCodes?.indexOf(error.code) > -1;
          });
        });
      });
    }

    const dataReturn = plainToInstance(EvaluationCriteriaResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async update(request: UpdateEvaluationCriteriaRequestDto): Promise<any> {
    try {
      const { id } = request;
      let evaluationCriteria =
        await this.evaluationCriteriaRepository.findOneById(id);
      if (!evaluationCriteria) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      const validateResult = await this.validateError(request);
      if (validateResult.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validateResult;
      }

      evaluationCriteria = this.evaluationCriteriaRepository.updateModel(
        evaluationCriteria,
        request,
      );

      const dataSave =
        await this.evaluationCriteriaRepository.findByIdAndUpdate(
          id,
          evaluationCriteria,
        );

      const dataReturn = plainToInstance(
        EvaluationCriteriaResponseDto,
        dataSave,
        {
          excludeExtraneousValues: true,
        },
      );

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async delete(request: IdParamMongoDto): Promise<any> {
    const { id } = request;
    const evaluationCriteria =
      await this.evaluationCriteriaRepository.findOneByCondition(id);
    if (!evaluationCriteria) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    await this.evaluationCriteriaRepository.deleteById(id);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateActiveStatus(request: UpdateActiveStatusPayload): Promise<any> {
    const { id, status } = request;
    const evaluationCriteria =
      await this.evaluationCriteriaRepository.findOneById(id);
    if (!evaluationCriteria) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    await this.evaluationCriteriaRepository.findByIdAndUpdate(id, {
      $set: { active: status },
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private getErrorValidateExcel(data: any[], i18n: I18nRequestScopeService) {
    const dataError = [];
    const dataRes = [];
    data.forEach((item) => {
      if (
        item.action !== i18n.translate('import.common.add') &&
        item.action !== i18n.translate('import.common.edit')
      ) {
        dataError.push({
          ...item,
          errorDesc: i18n.translate('import.error.action'),
        });
      } else if (new RegExp(/[^0-9a-zA-Z]/g).test(item?.code)) {
        dataError.push({
          ...item,
          errorDesc: i18n.translate(
            'import.evaluationCriteriaTemplate.codeInvalid',
          ),
        });
      } else if (
        item?.active !== ACTIVE_ENUM.ACTIVE &&
        item?.active !== ACTIVE_ENUM.INACTIVE
      ) {
        dataError.push({
          ...item,
          errorDesc: i18n.translate('import.error.active'),
        });
      } else if (item?.norm <= 0 || item?.norm >= 100) {
        dataError.push({
          ...item,
          errorDesc: i18n.translate('export.common.invalidField'),
        });
      } else if (item?.lowerBound <= 0 || item?.lowerBound >= 100) {
        dataError.push({
          ...item,
          errorDesc: i18n.translate('export.common.invalidField'),
        });
      } else if (item?.upperBound <= 0 || item?.upperBound >= 100) {
        dataError.push({
          ...item,
          errorDesc: i18n.translate('export.common.invalidField'),
        });
      } else
        dataRes.push({
          ...item,
          description: item.description ? item.description : '',
        });
    });
    return { dataErrorValidate: dataError, dataPass: dataRes };
  }

  async import(
    data: any,
    userId: number,
  ): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const textAdd = await this.i18n.translate('import.common.add');
    const { dataErrorValidate, dataPass } = this.getErrorValidateExcel(
      data,
      this.i18n,
    );

    let { dataToInsert, codesInsert } = getDataInsert(dataPass, textAdd);
    const { dataToUpdate, codesUpdate } = getDataUpdate(dataPass, textAdd);
    dataToInsert = dataToInsert.map((item) => {
      return { ...item, createdBy: userId };
    });

    const codeInsertExists =
      await this.evaluationCriteriaRepository.findAllByCondition({
        code: { $in: codesInsert },
      });
    const codeUpdateExists =
      await this.evaluationCriteriaRepository.findAllByCondition({
        code: { $in: codesUpdate },
      });
    const codeInsertMap = keyBy(codeInsertExists, 'code');
    const codeUpdateMap = keyBy(codeUpdateExists, 'code');

    const { dataError: dataInsertError, dataInsert } = getDataToInsertError(
      dataToInsert,
      codeInsertMap,
    );
    const { dataError: dataUpdateError, dataUpdate } = getDataToUpdateError(
      dataToUpdate,
      codeUpdateMap,
    );

    const bulkOps = [...dataInsert, ...dataUpdate].map((doc) => ({
      updateOne: {
        filter: { code: doc.code },
        update: doc,
        upsert: true,
      },
    }));

    const dataSuccess = await this.evaluationCriteriaRepository.bulkWrite(
      bulkOps,
    );

    return {
      dataError: [...dataInsertError, ...dataUpdateError, ...dataErrorValidate],
      dataSuccess,
    };
  }

  private async generateEvaluationCriteriaCode(): Promise<any> {
    const lastEvaluationCriteria =
      await this.evaluationCriteriaRepository.getLastEvaluationCriteria();

    let index = INDEX_EVALUATION_CRITERIA_CODE_START;
    if (!isEmpty(lastEvaluationCriteria)) {
      const lastCode: string = lastEvaluationCriteria.code;
      if (
        !isEmpty(lastCode) &&
        lastCode.length > PREFIX_EVALUATION_CRITERIA_CODE.length
      ) {
        let lastIndex: any = lastCode
          .substring(PREFIX_EVALUATION_CRITERIA_CODE.length)
          .replace(REGEX_PADDING_ZERO, EMPTY_STRING);
        lastIndex = Number(lastIndex);
        if (!isNaN(lastIndex)) {
          index = lastIndex + STEP_INDEX_EVALUATION_CRITERIA_CODE;
        }
      }
    }

    const codeNew = `${PREFIX_EVALUATION_CRITERIA_CODE}${index
      ?.toString()
      .padStart(MAX_LENGTH_INDEX, PADDING_SYMBOL)}`;

    const existCode = await this.evaluationCriteriaRepository.findOneByCode(
      codeNew,
    );

    if (!isEmpty(existCode)) {
      return this.generateEvaluationCriteriaCode();
    }

    return codeNew;
  }
}
