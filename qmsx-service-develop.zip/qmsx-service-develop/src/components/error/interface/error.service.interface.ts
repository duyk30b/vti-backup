import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { CreateErrorRequestDto } from '../dto/request/create-error.request.dto';
import { GetDetailErrorRequestDto } from '../dto/request/get-detail-error.request.dto';
import { UpdateErrorRequestDto } from '../dto/request/update-error.request.dto';
import { GetListErrorRequestDto } from '../dto/request/get-list-error.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';

export interface ErrorServiceInterface {
  create(request: CreateErrorRequestDto): Promise<any>;
  update(request: UpdateErrorRequestDto): Promise<any>;
  getDetail(request: GetDetailErrorRequestDto): Promise<any>;
  getList(request: GetListErrorRequestDto): Promise<any>;
  delete(request: IdParamMongoDto): Promise<any>;
  updateActiveStatus(request: UpdateActiveStatusPayload): Promise<any>;
  import(
    data: any,
    userId: number,
  ): Promise<{ dataSuccess: any[]; dataError: any[] }>;
}
