import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { Error } from 'src/models/error/error.schema';
import { CreateErrorRequestDto } from '../dto/request/create-error.request.dto';
import { GetListErrorRequestDto } from '../dto/request/get-list-error.request.dto';
import { UpdateErrorBodyDto } from '../dto/request/update-error.request.dto';

export interface ErrorRepositoryInterface
  extends BaseInterfaceRepository<Error> {
  createModel(request: CreateErrorRequestDto): Error;
  updateModel(error: Error, request: UpdateErrorBodyDto): Error;
  getList(request: GetListErrorRequestDto): Promise<any>;
  getLastError(): Promise<any>;
}
