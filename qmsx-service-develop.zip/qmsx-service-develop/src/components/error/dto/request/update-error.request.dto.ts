import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateErrorRequestDto } from './create-error.request.dto';

export class UpdateErrorBodyDto extends CreateErrorRequestDto {}

export class UpdateErrorRequestDto extends UpdateErrorBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
