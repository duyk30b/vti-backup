import { ERROR_CONST } from '@components/error/error.constant';
import { ACTIVE_ENUM } from '@constant/common';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';

export class CreateErrorRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @MaxLength(ERROR_CONST.CODE.MAX_LENGTH)
  @IsString()
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @MaxLength(ERROR_CONST.NAME.MAX_LENGTH)
  @IsString()
  name: string;

  @ApiProperty()
  @IsOptional()
  @MaxLength(ERROR_CONST.DESCRIPTION.MAX_LENGTH)
  @IsString()
  description: string;

  @ApiProperty()
  @IsOptional()
  @IsArray()
  causeCodes: string[];

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(ACTIVE_ENUM)
  active: number;
}
