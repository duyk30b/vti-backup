import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';
import { ErrorResponseDto } from './error.response.dto';

export class ListErrorResponseDto extends PaginationResponse {
  @ApiProperty({ type: ErrorResponseDto, isArray: true })
  @Type(() => ErrorResponseDto)
  @Expose()
  items: ErrorResponseDto[];
}
