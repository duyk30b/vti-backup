import { CauseResponseDto } from '@components/cause/dto/response/cause.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { Expose, Type } from 'class-transformer';

export class ErrorResponseDto extends BaseResponseDto {
  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  description: string;

  @Expose()
  active: number;

  @Expose()
  @Type(() => String)
  causeCodes: string[];

  @Expose()
  @Type(() => CauseResponseDto)
  causes: CauseResponseDto[];
}
