import { CauseResponseDto } from '@components/cause/dto/response/cause.response.dto';
import { CauseRepositoryInterface } from '@components/cause/interface/cause.repository.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ACTIVE_ENUM } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import {
  compact,
  difference,
  isEmpty,
  isNumber,
  keyBy,
  map,
  uniq,
} from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import {
  getDataInsert,
  getDataToInsertError,
  getDataToUpdateError,
  getDataUpdate,
} from 'src/helper/import.helper';
import { CreateErrorRequestDto } from './dto/request/create-error.request.dto';
import { GetDetailErrorRequestDto } from './dto/request/get-detail-error.request.dto';
import { GetListErrorRequestDto } from './dto/request/get-list-error.request.dto';
import { UpdateErrorRequestDto } from './dto/request/update-error.request.dto';
import { ErrorResponseDto } from './dto/response/error.response.dto';
import {
  EMPTY_STRING,
  INDEX_ERROR_CODE_START,
  MAX_LENGTH_INDEX,
  PADDING_SYMBOL,
  PREFIX_ERROR_CODE,
  REGEX_PADDING_ZERO,
  STEP_INDEX_ERROR_CODE,
} from './error.constant';
import { ErrorRepositoryInterface } from './interface/error.repository.interface';
import { ErrorServiceInterface } from './interface/error.service.interface';

@Injectable()
export class ErrorService implements ErrorServiceInterface {
  constructor(
    @Inject('CauseRepositoryInterface')
    private readonly causeRepository: CauseRepositoryInterface,

    @Inject('ErrorRepositoryInterface')
    private readonly errorRepository: ErrorRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateErrorRequestDto): Promise<any> {
    try {
      const { code } = request;
      const errorGroup = await this.errorRepository.findOneByCode(code);
      if (!isEmpty(errorGroup)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.ERROR_CODE_EXIST'))
          .build();
      }

      const validateResult = await this.validateCause(request);
      if (validateResult.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validateResult;
      }

      const document = this.errorRepository.createModel(request);
      document.code = await this.generateErrorCode();
      const dataSave = await document.save();
      const dataReturn = plainToInstance(ErrorResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  private async validateCause(request: CreateErrorRequestDto): Promise<any> {
    let { causeCodes } = request;
    causeCodes = uniq(compact(causeCodes));
    const causeExists = await this.causeRepository.findAllByCondition({
      code: { $in: causeCodes },
    });
    const causeCodeExists = causeExists.map((cause) => cause.code);
    const causeNotFound = difference(causeCodes, causeCodeExists);
    if (causeCodes.length != causeCodeExists.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          `${await this.i18n.translate(
            'error.NOT_FOUND_CAUSE',
          )} ${causeNotFound.join(', ')}`,
        )
        .build();
    }
    const causeInactive = await this.causeRepository.findAllByCondition({
      code: {
        $in: causeCodes,
      },
      isActive: ACTIVE_ENUM.INACTIVE,
    });

    if (causeInactive.length > 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.LOCKED)
        .withMessage(
          `Nguyên nhân ${causeInactive
            .map((i) => i.code)
            .join(', ')} đang ở trạng thái tạm dừng`,
        )
        .build();
    }
    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async getDetail(request: GetDetailErrorRequestDto): Promise<any> {
    try {
      const { id } = request;
      const error = await this.errorRepository.findOneById(id);
      if (!error) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      const causes = await this.causeRepository.findAllByCondition({
        code: { $in: error?.causeCodes },
      });

      const causeReturn = plainToInstance(CauseResponseDto, causes, {
        excludeExtraneousValues: true,
      });

      const dataReturn = plainToInstance(ErrorResponseDto, error, {
        excludeExtraneousValues: true,
      });

      dataReturn.causes = causeReturn;

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getList(request: GetListErrorRequestDto): Promise<any> {
    const { data, count } = await this.errorRepository.getList(request);
    const userIds = uniq(compact(map(data, 'createdBy')));

    // Filter by user id
    const userIdFilters = [
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ];

    if (!isEmpty(userIds)) {
      let users = await this.userService.getList(userIdFilters);
      users = keyBy(users, 'id');
      data.forEach((item) => {
        item.createdBy = {
          id: users[item.createdBy]?.id,
          username: users[item.createdBy]?.username,
          fullName: users[item.createdBy]?.fullName,
          code: users[item.createdBy]?.code,
        };
      });
    }

    const dataReturn = plainToInstance(ErrorResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async update(request: UpdateErrorRequestDto): Promise<any> {
    try {
      const { id } = request;
      let error = await this.errorRepository.findOneById(id);
      if (!error) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      const validateResult = await this.validateCause(request);
      if (validateResult.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validateResult;
      }

      error = this.errorRepository.updateModel(error, request);

      const dataSave = await this.errorRepository.findByIdAndUpdate(id, error);

      const dataReturn = plainToInstance(ErrorResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async delete(request: IdParamMongoDto): Promise<any> {
    const { id } = request;
    const error = await this.errorRepository.findOneByCondition(id);
    if (!error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    await this.errorRepository.deleteById(id);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateActiveStatus(request: UpdateActiveStatusPayload): Promise<any> {
    const { id, status } = request;
    const error = await this.errorRepository.findOneById(id);
    if (!error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    await this.errorRepository.findByIdAndUpdate(id, {
      $set: { active: status },
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private getErrorValidateExcel(data: any[], i18n: I18nRequestScopeService) {
    const dataError = [];
    const dataRes = [];
    data.forEach((item) => {
      if (
        item.action !== i18n.translate('import.common.add') &&
        item.action !== i18n.translate('import.common.edit')
      ) {
        dataError.push({
          ...item,
          errorDesc: i18n.translate('import.error.action'),
        });
      } else if (new RegExp(/[^0-9a-zA-Z]/g).test(item?.code)) {
        dataError.push({
          ...item,
          errorDesc: i18n.translate('import.errorTemplate.codeInvalid'),
        });
      } else if (
        item?.active !== ACTIVE_ENUM.ACTIVE &&
        item?.active !== ACTIVE_ENUM.INACTIVE
      ) {
        dataError.push({
          ...item,
          errorDesc: i18n.translate('import.error.active'),
        });
      } else
        dataRes.push({
          ...item,
          description: item.description ? item.description : '',
        });
    });
    return { dataErrorValidate: dataError, dataPass: dataRes };
  }

  async import(
    data: any,
    userId: number,
  ): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const textAdd = await this.i18n.translate('import.common.add');

    const { dataErrorValidate, dataPass } = this.getErrorValidateExcel(
      data,
      this.i18n,
    );

    let { dataToInsert, codesInsert } = getDataInsert(dataPass, textAdd);
    const { dataToUpdate, codesUpdate } = getDataUpdate(dataPass, textAdd);
    dataToInsert = dataToInsert.map((item) => {
      return { ...item, createdBy: userId };
    });

    const codeInsertExists = await this.errorRepository.findAllByCondition({
      code: { $in: codesInsert },
    });
    const codeUpdateExists = await this.errorRepository.findAllByCondition({
      code: { $in: codesUpdate },
    });

    const codeInsertMap = keyBy(codeInsertExists, 'code');
    const codeUpdateMap = keyBy(codeUpdateExists, 'code');

    const { dataError: dataInsertError, dataInsert } = getDataToInsertError(
      dataToInsert,
      codeInsertMap,
    );
    const { dataError: dataUpdateError, dataUpdate } = getDataToUpdateError(
      dataToUpdate,
      codeUpdateMap,
    );

    const bulkOps = [...dataInsert, ...dataUpdate].map((doc) => ({
      updateOne: {
        filter: { code: doc.code },
        update: doc,
        upsert: true,
      },
    }));

    const dataSuccess = await this.errorRepository.bulkWrite(bulkOps);

    return {
      dataError: [...dataInsertError, ...dataUpdateError, ...dataErrorValidate],
      dataSuccess,
    };
  }

  private async generateErrorCode(): Promise<any> {
    const lastError = await this.errorRepository.getLastError();

    let index = INDEX_ERROR_CODE_START;
    if (!isEmpty(lastError)) {
      const lastCode: string = lastError.code;
      if (!isEmpty(lastCode) && lastCode.length > PREFIX_ERROR_CODE.length) {
        let lastIndex: any = lastCode
          .substring(PREFIX_ERROR_CODE.length)
          .replace(REGEX_PADDING_ZERO, EMPTY_STRING);
        lastIndex = Number(lastIndex);
        if (!isNaN(lastIndex)) {
          index = lastIndex + STEP_INDEX_ERROR_CODE;
        }
      }
    }

    const codeNew = `${PREFIX_ERROR_CODE}${index
      ?.toString()
      .padStart(MAX_LENGTH_INDEX, PADDING_SYMBOL)}`;

    const existCode = await this.errorRepository.findOneByCode(codeNew);

    if (!isEmpty(existCode)) {
      return this.generateErrorCode();
    }

    return codeNew;
  }
}
