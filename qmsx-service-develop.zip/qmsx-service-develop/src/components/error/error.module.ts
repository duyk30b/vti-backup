import { CauseModule } from '@components/cause/cause.module';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { CauseCollection, CauseSchema } from 'src/models/cause/cause.schema';
import { ErrorSchema } from 'src/models/error/error.schema';
import { ErrorRepository } from 'src/repository/error/error.repository';
import { ErrorController } from './error.controller';
import { ErrorService } from './error.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: Error.name,
        schema: ErrorSchema,
      },
      {
        name: CauseCollection.name,
        schema: CauseSchema,
      },
    ]),
    CauseModule,
  ],
  controllers: [ErrorController],
  providers: [
    {
      provide: 'ErrorServiceInterface',
      useClass: ErrorService,
    },
    {
      provide: 'ErrorRepositoryInterface',
      useClass: ErrorRepository,
    },
  ],
  exports: [
    {
      provide: 'ErrorServiceInterface',
      useClass: ErrorService,
    },
    {
      provide: 'ErrorRepositoryInterface',
      useClass: ErrorRepository,
    },
  ],
})
export class ErrorModule {}
