import { ACTIVE_ENUM } from '@constant/common';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateErrorRequestDto } from './dto/request/create-error.request.dto';
import { GetDetailErrorRequestDto } from './dto/request/get-detail-error.request.dto';
import { GetListErrorRequestDto } from './dto/request/get-list-error.request.dto';
import { UpdateErrorBodyDto } from './dto/request/update-error.request.dto';
import { ErrorResponseDto } from './dto/response/error.response.dto';
import { ListErrorResponseDto } from './dto/response/list-error.response.dto';
import { ErrorServiceInterface } from './interface/error.service.interface';

@Controller('errors')
export class ErrorController {
  constructor(
    @Inject('ErrorServiceInterface')
    private readonly errorService: ErrorServiceInterface,
  ) {}

  @Post()
  @ApiOperation({
    tags: ['Error - Lỗi'],
    summary: 'Thêm lỗi',
  })
  @ApiResponse({
    status: 200,
    description: 'Add Successfully',
    type: ErrorResponseDto,
  })
  async create(@Body() payload: CreateErrorRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.errorService.create(request);
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['Error - Lỗi'],
    summary: 'Chi tiết lỗi',
    description: 'Chi tiết lỗi',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ErrorResponseDto,
  })
  async getDetail(@Param() param: GetDetailErrorRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.errorService.getDetail(request);
  }

  @Get()
  @ApiOperation({
    tags: ['Error - Lỗi'],
    summary: 'Danh sách lỗi',
    description: 'Danh sách lỗi',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListErrorResponseDto,
  })
  async getList(@Query() query: GetListErrorRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.errorService.getList(request);
  }

  @Put('/:id')
  @ApiOperation({
    tags: ['Error - Lỗi'],
    summary: 'Sửa lỗi',
    description: 'Sửa lỗi',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async update(
    @Param() param: IdParamMongoDto,
    @Body() payload: UpdateErrorBodyDto,
  ): Promise<any> {
    const { request: requestParam, responseError: responseParamError } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.errorService.update({
      id: requestParam.id,
      ...request,
    });
  }

  @Delete('/:id')
  @ApiOperation({
    tags: ['Error - Lỗi'],
    summary: 'Xóa error',
    description: 'Xóa error',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async delete(@Param() param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.errorService.delete(request);
  }

  @Put('/:id/active')
  @ApiOperation({
    tags: ['Error - Lỗi'],
    summary: 'Hoạt động lỗi',
    description: 'Hoạt động lỗi',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async active(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.errorService.updateActiveStatus({
      ...request,
      status: ACTIVE_ENUM.ACTIVE,
    });
  }

  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Error - Lỗi'],
    summary: 'Tạm dừng lỗi',
    description: 'Tạm dừng lỗi',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async inactive(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.errorService.updateActiveStatus({
      ...request,
      status: ACTIVE_ENUM.INACTIVE,
    });
  }
}
