import { Controller, Get, Inject, Query } from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { isEmpty } from 'lodash';
import { GetListQualityReportRequestDto } from './dto/request/get-list-quality-report.request.dto';
import { QualityReportResponseDto } from './dto/response/quality-report.response.dto';
import { QualityReportServiceInterface } from './interface/quality-report.service.interface';

@Controller('quality-reports')
export class QualityReportController {
  constructor(
    @Inject('QualityReportServiceInterface')
    private readonly qualityReportService: QualityReportServiceInterface,
  ) {}

  @Get()
  @ApiOperation({
    tags: ['Quality Report - Báo cáo chất lượng'],
    summary: 'Danh sách QC',
    description: 'Danh sách QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: QualityReportResponseDto,
  })
  async getList(@Query() query: GetListQualityReportRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qualityReportService.getList(request);
  }
}
