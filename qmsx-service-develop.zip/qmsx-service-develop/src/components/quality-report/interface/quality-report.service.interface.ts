import { GetListQualityReportRequestDto } from '../dto/request/get-list-quality-report.request.dto';

export interface QualityReportServiceInterface {
  getList(request: GetListQualityReportRequestDto): Promise<any>;
}
