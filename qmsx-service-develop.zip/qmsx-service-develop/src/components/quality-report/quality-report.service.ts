import { ItemService } from '@components/item/item.service';
import { QCCommandRepositoryInterface } from '@components/qc-command/interface/qc-command.repository.interface';
import { QCExecuteRepositoryInterface } from '@components/qc-execute/interface/qc-execute.repository.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { compact, isEmpty, keyBy, map, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { GetListQualityReportRequestDto } from './dto/request/get-list-quality-report.request.dto';
import { QualityReportResponseDto } from './dto/response/quality-report.response.dto';
import { QualityReportServiceInterface } from './interface/quality-report.service.interface';

@Injectable()
export class QualityReportService implements QualityReportServiceInterface {
  constructor(
    @Inject('QCExecuteRepositoryInterface')
    private readonly qcExecuteRepository: QCExecuteRepositoryInterface,

    @Inject('QCCommandRepositoryInterface')
    private readonly qcCommandRepository: QCCommandRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ItemService')
    private readonly itemService: ItemService,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async getList(request: GetListQualityReportRequestDto) {
    const { data, count } = await this.qcExecuteRepository.getList(request);
    const userIds = uniq(compact(map(data, 'qcBy')));

    // Filter by user id
    const userIdFilters = [
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ];

    if (!isEmpty(userIds)) {
      let users = await this.userService.getList(userIdFilters);
      users = keyBy(users, 'id');
      data.forEach((item) => {
        item.qcBy = item.qcBy.map((i: number) => users[i]);
      });
    }

    // Filter by item code
    const itemCodes = uniq(compact(map(data, 'itemCode')));
    if (!isEmpty(itemCodes)) {
      const request = {
        codes: itemCodes.join(','),
      };
      let itemList = await this.itemService.getItemList(request);
      itemList = keyBy(itemList, 'code');

      data?.forEach((it) => {
        it.item = itemList[it.itemCode];
      });
    }

    // Filter by qcCommand code
    const qcCommandCodes = uniq(compact(map(data, 'qcCommandCode')));
    if (!isEmpty(itemCodes)) {
      let qcCommandList: any =
        await this.qcCommandRepository.findAllByCondition({
          code: {
            $in: qcCommandCodes,
          },
        });
      qcCommandList = keyBy(qcCommandList, 'code');

      data?.forEach((it) => {
        it.qcCommand = qcCommandList[it.qcCommandCode];
      });
    }

    const dataReturn = plainToInstance(QualityReportResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
