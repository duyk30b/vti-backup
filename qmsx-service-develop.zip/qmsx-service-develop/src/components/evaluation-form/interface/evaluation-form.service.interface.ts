import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { CreateEvaluationFormRequestDto } from '../dto/request/create-evaluation-form-template.request.dto';
import { GetListEvaluationFormRequestDto } from '../dto/request/get-list-evaluation-form.request.dto';
import { UpdateEvaluationFormRequestDto } from '../dto/request/update-evaluation-form.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { GetDetailEvaluationFormRequestDto } from '../dto/request/get-detail-evaluation-form.request.dto';

export interface EvaluationFormServiceInterface {
  create(request: CreateEvaluationFormRequestDto): Promise<any>;
  update(request: UpdateEvaluationFormRequestDto): Promise<any>;
  getDetail(request: GetDetailEvaluationFormRequestDto): Promise<any>;
  getList(request: GetListEvaluationFormRequestDto): Promise<any>;
  delete(request: IdParamMongoDto): Promise<any>;
  updateActiveStatus(request: UpdateActiveStatusPayload): Promise<any>;
  import(
    data: any,
    userId: number,
  ): Promise<{ dataSuccess: any[]; dataError: any[] }>;
}
