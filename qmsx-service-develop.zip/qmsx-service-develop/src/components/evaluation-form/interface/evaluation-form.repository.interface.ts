import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { CreateEvaluationFormRequestDto } from '../dto/request/create-evaluation-form-template.request.dto';
import { EvaluationFormCollection } from 'src/models/evaluation-form/evaluation-form.schema';
import { GetListEvaluationFormRequestDto } from '../dto/request/get-list-evaluation-form.request.dto';
import { UpdateEvaluationFormBodyDto } from '../dto/request/update-evaluation-form.request.dto';

export interface EvaluationFormRepositoryInterface
  extends BaseInterfaceRepository<EvaluationFormCollection> {
  createModel(
    request: CreateEvaluationFormRequestDto,
  ): EvaluationFormCollection;
  updateModel(
    error: EvaluationFormCollection,
    request: UpdateEvaluationFormBodyDto,
  ): EvaluationFormCollection;
  getList(request: GetListEvaluationFormRequestDto): Promise<any>;
  getLastEvaluationForm(): Promise<any>;
}
