import { CODE_REGEX } from '@constant/common';

export const EVALUATION_FORM_CONST = {
  CODE: {
    MAX_LENGTH: 50,
    COLUMN: 'code',
    REGEX: CODE_REGEX,
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  DESCRIPTION: {
    MAX_LENGTH: 1000,
    COLUMN: 'description',
  },
  QC_NUMBER: {
    MAX: 100,
    COLUMN: 'qcNumber',
  },
  QC_QUANTITY: {
    MAX: 99,
    COLUMN: 'qcQuantity',
  },
  BOUND: {
    MAX: 99,
  },
};

export enum QC_FORMAT {
  ALL,
  RANDOM,
}

export enum IMPORTANT {
  NO,
  YES,
}

export const REGEX_PADDING_ZERO = /^0+/;
export const EMPTY_STRING = '';
export const PREFIX_EVALUATION_FORM_CODE = 'MPDG';
export const FORMAT_SHORT_YEAR = 'YY';
export const INDEX_EVALUATION_FORM_CODE_START = 1;
export const STEP_INDEX_EVALUATION_FORM_CODE = 1;
export const MAX_LENGTH_INDEX = 6;
export const PADDING_SYMBOL = '0';
