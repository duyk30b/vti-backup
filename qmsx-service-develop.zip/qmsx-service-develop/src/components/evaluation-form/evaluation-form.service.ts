import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import {
  compact,
  difference,
  flatten,
  isEmpty,
  keyBy,
  map,
  uniq,
} from 'lodash';
import { CreateEvaluationFormRequestDto } from './dto/request/create-evaluation-form-template.request.dto';
import { EvaluationFormResponseDto } from './dto/response/evaluation-form.response.dto';
import { EvaluationFormServiceInterface } from './interface/evaluation-form.service.interface';

import { EvaluationCriteriaRepositoryInterface } from '@components/evaluation-criteria/interface/evaluation-criteria.repository.interface';
import { ItemService } from '@components/item/item.service';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ACTIVE_ENUM } from '@constant/common';
import { ApiError } from '@utils/api.error';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { I18nRequestScopeService } from 'nestjs-i18n';
import {
  getDataInsert,
  getDataToInsertError,
  getDataToUpdateError,
  getDataUpdate,
} from 'src/helper/import.helper';
import { GetDetailEvaluationFormRequestDto } from './dto/request/get-detail-evaluation-form.request.dto';
import { GetListEvaluationFormRequestDto } from './dto/request/get-list-evaluation-form.request.dto';
import { UpdateEvaluationFormRequestDto } from './dto/request/update-evaluation-form.request.dto';
import {
  EMPTY_STRING,
  INDEX_EVALUATION_FORM_CODE_START,
  MAX_LENGTH_INDEX,
  PADDING_SYMBOL,
  PREFIX_EVALUATION_FORM_CODE,
  REGEX_PADDING_ZERO,
  STEP_INDEX_EVALUATION_FORM_CODE,
} from './evaluation-form.constant';
import { EvaluationFormRepositoryInterface } from './interface/evaluation-form.repository.interface';

@Injectable()
export class EvaluationFormService implements EvaluationFormServiceInterface {
  constructor(
    @Inject('EvaluationFormRepositoryInterface')
    private readonly evaluationFormRepository: EvaluationFormRepositoryInterface,

    @Inject('EvaluationCriteriaRepositoryInterface')
    private readonly evaluationCriteriaRepository: EvaluationCriteriaRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ItemService')
    private readonly itemService: ItemService,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateEvaluationFormRequestDto): Promise<any> {
    try {
      const { code } = request;
      const EvaluationForm = await this.evaluationFormRepository.findOneByCode(
        code,
      );
      if (!isEmpty(EvaluationForm)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.ERROR_GROUP_CODE_EXIST'),
          )
          .build();
      }

      const validateResult = await this.validateEvaluationCriteria(request);
      if (validateResult.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validateResult;
      }

      const evaluations = (
        await this.evaluationCriteriaRepository.findAllByCondition({
          code: {
            $in: request.evaluations.map((i) => i.code),
          },
        })
      ).filter((evaluate) => evaluate.active === ACTIVE_ENUM.INACTIVE);
      if (!isEmpty(evaluations)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.INVALID_ACTIVE_STATUS_EVALUATION'),
          )
          .build();
      }

      const document = this.evaluationFormRepository.createModel(request);
      document.code = await this.generateEvaluationFormCode();
      const dataSave = await document.save();
      const dataReturn = plainToInstance(EvaluationFormResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getDetail(request: GetDetailEvaluationFormRequestDto): Promise<any> {
    try {
      const { id } = request;
      const evaluationForm = await this.evaluationFormRepository.findOneById(
        id,
      );
      if (!evaluationForm) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      const res = await this.itemService.getItemTypeDetail({
        id: evaluationForm.itemId,
      });

      (evaluationForm as any).item = res;

      const dataReturn = plainToInstance(
        EvaluationFormResponseDto,
        evaluationForm,
        {
          excludeExtraneousValues: true,
        },
      );

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getList(request: GetListEvaluationFormRequestDto): Promise<any> {
    const { data, count } = await this.evaluationFormRepository.getList(
      request,
    );
    const userIds = uniq(compact(map(data, 'createdBy')));
    const itemIds = uniq(compact(map(data, 'itemId')));

    // Filter by user id
    const userIdFilters = [
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ];

    const itemIdFilters = [
      {
        column: 'itemIds',
        text: itemIds.join(','),
      },
    ];

    if (!isEmpty(userIds)) {
      let users = await this.userService.getList(userIdFilters);
      let itemList = (
        await this.itemService.getItemTypeList({
          ids: itemIds.join(','),
        })
      ).items;
      users = keyBy(users, 'id');
      itemList = keyBy(itemList, 'id');
      data.forEach((i) => {
        i.createdBy = {
          id: users[i?.createdBy]?.id,
          username: users[i?.createdBy]?.username,
          fullName: users[i?.createdBy]?.fullName,
          code: users[i?.createdBy]?.code,
        };
        i.item = { ...itemList[i.itemId] };
      });
    }

    const dataReturn = plainToInstance(EvaluationFormResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async update(request: UpdateEvaluationFormRequestDto): Promise<any> {
    try {
      const { id } = request;
      let errorGroup = await this.evaluationFormRepository.findOneById(id);
      if (!errorGroup) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      const validateResult = await this.validateEvaluationCriteria(request);
      if (validateResult.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validateResult;
      }

      errorGroup = this.evaluationFormRepository.updateModel(
        errorGroup,
        request,
      );

      const dataSave = await this.evaluationFormRepository.findByIdAndUpdate(
        id,
        errorGroup,
      );

      const dataReturn = plainToInstance(EvaluationFormResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async delete(request: IdParamMongoDto): Promise<any> {
    const { id } = request;
    const errorGroup = await this.evaluationFormRepository.findOneByCondition(
      id,
    );
    if (!errorGroup) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    await this.evaluationFormRepository.deleteById(id);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async validateEvaluationCriteria(
    request: CreateEvaluationFormRequestDto,
  ): Promise<any> {
    const evaluationCriteriaCodes = uniq(
      flatten(request.evaluations.map((i) => i.code)),
    );

    const evaluationCriteriaInactive =
      await this.evaluationCriteriaRepository.findAllByCondition({
        code: {
          $in: evaluationCriteriaCodes,
        },
        active: ACTIVE_ENUM.INACTIVE,
      });

    if (evaluationCriteriaInactive.length > 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.LOCKED)
        .withMessage(
          `Tiêu chí ${evaluationCriteriaInactive
            .map((i) => i.code)
            .join(', ')} đang ở trạng thái tạm dừng`,
        )
        .build();
    }

    const evaluationCriteriaCodesFound = (
      await this.evaluationCriteriaRepository.findAllByCondition({
        code: {
          $in: evaluationCriteriaCodes,
        },
      })
    ).map((i) => i.code);
    const evaluationCriteriaNotFound = difference(
      evaluationCriteriaCodes,
      evaluationCriteriaCodesFound,
    );

    if (
      evaluationCriteriaCodesFound.length !== evaluationCriteriaCodes.length
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          `${await this.i18n.translate(
            'error.NOT_FOUND_EVALUATION_CRITERIA',
          )} ${evaluationCriteriaNotFound.join(', ')}`,
        )
        .build();
    }
    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async updateActiveStatus(request: UpdateActiveStatusPayload): Promise<any> {
    const { id, status } = request;
    const errorGroup = await this.evaluationFormRepository.findOneById(id);
    if (!errorGroup) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    await this.evaluationFormRepository.findByIdAndUpdate(id, {
      $set: { active: status },
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private getErrorValidateExcel(data: any[], i18n: I18nRequestScopeService) {
    const dataError = [];
    const dataRes = [];
    data.forEach((item) => {
      if (
        item.action !== i18n.translate('import.common.add') &&
        item.action !== i18n.translate('import.common.edit')
      ) {
        dataError.push({
          ...item,
          errorDesc: i18n.translate('import.error.action'),
        });
      } else if (new RegExp(/[^0-9a-zA-Z]/g).test(item?.code)) {
        dataError.push({
          ...item,
          errorDesc: i18n.translate('import.evaluationForm.codeInvalid'),
        });
      } else if (
        item?.active !== ACTIVE_ENUM.ACTIVE &&
        item?.active !== ACTIVE_ENUM.INACTIVE
      ) {
        dataError.push({
          ...item,
          errorDesc: i18n.translate('import.error.active'),
        });
      } else if (item?.qcNumber <= 0 || item?.qcNumber > 100) {
        dataError.push({
          ...item,
          errorDesc: i18n.translate('export.common.invalidField'),
        });
      } else if (item?.qcQuantity <= 0 || item?.qcQuantity >= 100) {
        dataError.push({
          ...item,
          errorDesc: i18n.translate('export.common.invalidField'),
        });
      } else
        dataRes.push({
          ...item,
          description: item.description ? item.description : '',
        });
    });
    return { dataErrorValidate: dataError, dataPass: dataRes };
  }

  async import(
    data: any,
    userId: number,
  ): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const textAdd = await this.i18n.translate('import.common.add');
    const { dataErrorValidate, dataPass } = this.getErrorValidateExcel(
      data,
      this.i18n,
    );

    let { dataToInsert, codesInsert } = getDataInsert(dataPass, textAdd);
    let { dataToUpdate, codesUpdate } = getDataUpdate(dataPass, textAdd);
    dataToInsert = dataToInsert.map((item) => {
      return { ...item, createdBy: userId };
    });

    const codeInsertExists =
      await this.evaluationFormRepository.findAllByCondition({
        code: { $in: codesInsert },
      });
    const codeUpdateExists =
      await this.evaluationFormRepository.findAllByCondition({
        code: { $in: codesUpdate },
      });

    const codeInsertMap = keyBy(codeInsertExists, 'code');
    const codeUpdateMap = keyBy(codeUpdateExists, 'code');

    const { dataError: dataInsertError, dataInsert } = getDataToInsertError(
      dataToInsert,
      codeInsertMap,
    );

    const { dataError: dataUpdateError, dataUpdate } = getDataToUpdateError(
      dataToUpdate,
      codeUpdateMap,
    );

    const bulkOps = [...dataInsert, ...dataUpdate].map((doc) => ({
      updateOne: {
        filter: { code: doc.code },
        update: doc,
        upsert: true,
      },
    }));

    const dataSuccess = await this.evaluationFormRepository.bulkWrite(bulkOps);

    return {
      dataError: [...dataInsertError, ...dataUpdateError, ...dataErrorValidate],
      dataSuccess,
    };
  }

  private async generateEvaluationFormCode(): Promise<any> {
    const lastEvaluationForm =
      await this.evaluationFormRepository.getLastEvaluationForm();

    let index = INDEX_EVALUATION_FORM_CODE_START;
    if (!isEmpty(lastEvaluationForm)) {
      const lastCode: string = lastEvaluationForm.code;
      if (
        !isEmpty(lastCode) &&
        lastCode.length > PREFIX_EVALUATION_FORM_CODE.length
      ) {
        let lastIndex: any = lastCode
          .substring(PREFIX_EVALUATION_FORM_CODE.length)
          .replace(REGEX_PADDING_ZERO, EMPTY_STRING);
        lastIndex = Number(lastIndex);
        if (!isNaN(lastIndex)) {
          index = lastIndex + STEP_INDEX_EVALUATION_FORM_CODE;
        }
      }
    }

    const codeNew = `${PREFIX_EVALUATION_FORM_CODE}${index
      ?.toString()
      .padStart(MAX_LENGTH_INDEX, PADDING_SYMBOL)}`;

    const existCode = await this.evaluationFormRepository.findOneByCode(
      codeNew,
    );

    if (!isEmpty(existCode)) {
      return this.generateEvaluationFormCode();
    }

    return codeNew;
  }
}
