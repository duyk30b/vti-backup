import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';

export class GetDetailEvaluationFormRequestDto extends IdParamMongoDto {}
