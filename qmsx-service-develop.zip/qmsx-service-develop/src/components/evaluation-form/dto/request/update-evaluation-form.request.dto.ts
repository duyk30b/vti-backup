import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateEvaluationFormRequestDto } from './create-evaluation-form-template.request.dto';

export class UpdateEvaluationFormBodyDto extends CreateEvaluationFormRequestDto {}

export class UpdateEvaluationFormRequestDto extends UpdateEvaluationFormBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
