import { CHECK_TYPE } from '@components/evaluation-criteria/evaluation-criteria.constant';
import {
  EVALUATION_FORM_CONST,
  IMPORTANT,
  QC_FORMAT,
} from '@components/evaluation-form/evaluation-form.constant';
import { ACTIVE_ENUM } from '@constant/common';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsEnum,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  ValidateNested,
} from 'class-validator';

export class Evaluation {
  @ApiProperty()
  @IsNotEmpty()
  @MaxLength(EVALUATION_FORM_CONST.CODE.MAX_LENGTH)
  @IsString()
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @MaxLength(EVALUATION_FORM_CONST.NAME.MAX_LENGTH)
  @IsString()
  name: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(CHECK_TYPE)
  checkType: number;

  @ApiProperty()
  @IsOptional()
  @Max(EVALUATION_FORM_CONST.BOUND.MAX)
  upperBound: number;

  @ApiProperty()
  @IsOptional()
  @Max(EVALUATION_FORM_CONST.BOUND.MAX)
  lowerBound: number;

  @ApiProperty()
  @IsOptional()
  @Max(EVALUATION_FORM_CONST.BOUND.MAX)
  norm: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(IMPORTANT)
  important: number;
}

export class CreateEvaluationFormRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @MaxLength(EVALUATION_FORM_CONST.CODE.MAX_LENGTH)
  @IsString()
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @MaxLength(EVALUATION_FORM_CONST.NAME.MAX_LENGTH)
  @IsString()
  name: string;

  @ApiProperty()
  @IsOptional()
  @MaxLength(EVALUATION_FORM_CONST.DESCRIPTION.MAX_LENGTH)
  @IsString()
  description: string;

  @ApiProperty()
  @IsNotEmpty()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @Max(EVALUATION_FORM_CONST.QC_NUMBER.MAX)
  qcNumber: number;

  @ApiProperty()
  @IsNotEmpty()
  @Max(EVALUATION_FORM_CONST.QC_QUANTITY.MAX)
  qcQuantity: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(QC_FORMAT)
  qcFormat: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(ACTIVE_ENUM)
  active: number;

  @ValidateNested({ each: true })
  @Type(() => Evaluation)
  @IsArray()
  evaluations: Evaluation[];

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  weight: number;
}
