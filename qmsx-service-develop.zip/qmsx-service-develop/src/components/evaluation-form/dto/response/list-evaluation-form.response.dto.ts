import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';
import { EvaluationFormResponseDto } from './evaluation-form.response.dto';

export class ListEvaluationFormResponseDto extends PaginationResponse {
  @ApiProperty({ type: EvaluationFormResponseDto, isArray: true })
  @Type(() => EvaluationFormResponseDto)
  @Expose()
  items: EvaluationFormResponseDto[];
}
