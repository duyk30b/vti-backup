import { BaseResponseDto } from '@core/dto/base.response.dto';
import { Expose, Type } from 'class-transformer';
import { Evaluation } from '../request/create-evaluation-form-template.request.dto';

class ItemTypeSetting {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;
}

export class EvaluationFormResponseDto extends BaseResponseDto {
  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  description: string;

  @Expose()
  active: number;

  @Expose()
  qcNumber: number;

  @Expose()
  qcFormat: string;

  @Expose()
  qcQuantity: number;

  @Expose()
  @Type(() => ItemTypeSetting)
  item: ItemTypeSetting;

  @Expose()
  evaluations: Evaluation[];

  @Expose()
  weight: number;
}
