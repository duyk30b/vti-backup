import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { EvaluationFormController } from './evaluation-form.controller';
import { EvaluationFormService } from './evaluation-form.service';
import {
  EvaluationFormSchema,
  EvaluationFormCollection,
} from 'src/models/evaluation-form/evaluation-form.schema';
import { EvaluationFormRepository } from 'src/repository/evaluation-form/evaluation-form.repository';
import { ItemService } from '@components/item/item.service';
import { EvaluationCriteriaRepository } from 'src/repository/evaluation-criteria/evaluation-criteria.repository';
import {
  EvaluationCriteria,
  EvaluationCriteriaSchema,
} from 'src/models/evaluation-criteria/evaluation-criteria.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: EvaluationFormCollection.name,
        schema: EvaluationFormSchema,
      },
      {
        name: EvaluationCriteria.name,
        schema: EvaluationCriteriaSchema,
      },
    ]),
  ],
  controllers: [EvaluationFormController],
  providers: [
    {
      provide: 'EvaluationFormServiceInterface',
      useClass: EvaluationFormService,
    },
    {
      provide: 'EvaluationFormRepositoryInterface',
      useClass: EvaluationFormRepository,
    },
    {
      provide: 'ItemService',
      useClass: ItemService,
    },
    {
      provide: 'EvaluationCriteriaRepositoryInterface',
      useClass: EvaluationCriteriaRepository,
    },
  ],
  exports: [
    {
      provide: 'EvaluationFormServiceInterface',
      useClass: EvaluationFormService,
    },
    {
      provide: 'EvaluationFormRepositoryInterface',
      useClass: EvaluationFormRepository,
    },
  ],
})
export class EvaluationFormModule {}
