import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { isEmpty } from 'lodash';
import { EvaluationFormServiceInterface } from './interface/evaluation-form.service.interface';
import { CreateEvaluationFormRequestDto } from './dto/request/create-evaluation-form-template.request.dto';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { GetListEvaluationFormRequestDto } from './dto/request/get-list-evaluation-form.request.dto';
import { ListEvaluationFormResponseDto } from './dto/response/list-evaluation-form.response.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateEvaluationFormBodyDto } from './dto/request/update-evaluation-form.request.dto';
import { ACTIVE_ENUM } from '@constant/common';
import { GetDetailEvaluationFormRequestDto } from './dto/request/get-detail-evaluation-form.request.dto';
import { EvaluationFormResponseDto } from './dto/response/evaluation-form.response.dto';

@Controller('evaluation-forms')
export class EvaluationFormController {
  constructor(
    @Inject('EvaluationFormServiceInterface')
    private readonly evaluationFormService: EvaluationFormServiceInterface,
  ) {}

  @Post()
  @ApiOperation({
    tags: ['Evaluation Form - Mẫu phiếu đánh giá'],
    summary: 'Thêm mẫu phiếu đánh giá',
  })
  @ApiResponse({
    status: 200,
    description: 'Add Successfully',
    type: EvaluationFormResponseDto,
  })
  async create(@Body() payload: CreateEvaluationFormRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.evaluationFormService.create(request);
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['Evaluation Form - Mẫu phiếu đánh giá'],
    summary: 'Chi tiết mẫu phiếu đánh giá',
    description: 'Chi tiết mẫu phiếu đánh giá',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: EvaluationFormResponseDto,
  })
  async getDetail(
    @Param() param: GetDetailEvaluationFormRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.evaluationFormService.getDetail(request);
  }

  @Get()
  @ApiOperation({
    tags: ['Evaluation Form - Mẫu phiếu đánh giá'],
    summary: 'Danh sách mẫu phiếu đánh giá',
    description: 'Danh sách mẫu phiếu đánh giá',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListEvaluationFormResponseDto,
  })
  async getList(@Query() query: GetListEvaluationFormRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.evaluationFormService.getList(request);
  }

  @Put('/:id')
  @ApiOperation({
    tags: ['Evaluation Form - Mẫu phiếu đánh giá'],
    summary: 'Sửa mẫu phiếu đánh giá',
    description: 'Sửa mẫu phiếu đánh giá',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async update(
    @Param() param: IdParamMongoDto,
    @Body() payload: UpdateEvaluationFormBodyDto,
  ): Promise<any> {
    const { request: requestParam, responseError: responseParamError } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }

    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.evaluationFormService.update({
      id: requestParam.id,
      ...request,
    });
  }

  @Delete('/:id')
  @ApiOperation({
    tags: ['Evaluation Form - Mẫu phiếu đánh giá'],
    summary: 'Xóa mẫu phiếu đánh giá',
    description: 'Xóa mẫu phiếu đánh giá',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async delete(@Param() param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.evaluationFormService.delete(request);
  }

  @Put('/:id/active')
  @ApiOperation({
    tags: ['Evaluation Form - Mẫu phiếu đánh giá'],
    summary: 'Hoạt động mẫu phiếu đánh giá',
    description: 'Hoạt động mẫu phiếu đánh giá',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async active(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.evaluationFormService.updateActiveStatus({
      ...request,
      status: ACTIVE_ENUM.ACTIVE,
    });
  }

  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Evaluation Form - Mẫu phiếu đánh giá'],
    summary: 'Tạm dừng mẫu phiếu đánh giá',
    description: 'Tạm dừng mẫu phiếu đánh giá',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async inactive(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.evaluationFormService.updateActiveStatus({
      ...request,
      status: ACTIVE_ENUM.INACTIVE,
    });
  }
}
