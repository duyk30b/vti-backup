import { NATS_USER } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { UserServiceInterface } from './interface/user.service.interface';

@Injectable()
export class UserService implements UserServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async getList(filter: any): Promise<any> {
    try {
      const response = await this.natsClientService.send(`${NATS_USER}.list`, {
        filter,
      });
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
      return response?.data?.items;
    } catch (err) {
      return [];
    }
  }

  async getDetail(filter: any): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_USER}.detail`,
        {
          id: filter,
        },
      );
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) return {};
      return response?.data;
    } catch (err) {
      return {};
    }
  }
}
