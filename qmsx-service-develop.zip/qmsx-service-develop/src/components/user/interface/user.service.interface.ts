export interface UserServiceInterface {
  getList(filter: any): Promise<any>;
  getDetail(filter: any): Promise<any>;
}
