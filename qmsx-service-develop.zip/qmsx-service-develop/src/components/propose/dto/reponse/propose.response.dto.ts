import { BaseResponseDto } from '@core/dto/base.response.dto';
import { Expose } from 'class-transformer';
import { Types } from 'mongoose';

export class ProposeResponseDto extends BaseResponseDto {
  @Expose()
  qcExecuteId: Types.ObjectId;

  @Expose()
  errorCode: string;

  @Expose()
  content: string;
}
