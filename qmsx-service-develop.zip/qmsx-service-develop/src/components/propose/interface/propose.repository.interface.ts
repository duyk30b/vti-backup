import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { Propose } from 'src/models/propose/propose.schema';

export interface ProposeRepositoryInterface
  extends BaseInterfaceRepository<Propose> {}
