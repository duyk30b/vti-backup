export interface TicketReportErrorServiceInterface {}
