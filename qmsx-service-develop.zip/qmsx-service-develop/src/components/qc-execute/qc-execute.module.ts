import { ItemService } from '@components/item/item.service';
import { SettingModule } from '@components/setting/setting.module';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ErrorSchema } from 'src/models/error/error.schema';
import {
  EvaluationCriteria,
  EvaluationCriteriaSchema,
} from 'src/models/evaluation-criteria/evaluation-criteria.schema';
import {
  QCCommand,
  QCCommandSchema,
} from 'src/models/qc-command/qc-command.schema';
import {
  QCExecuteProgress,
  QCExecuteProgressSchema,
} from 'src/models/qc-execute/qc-execute-progress.schema';
import {
  QCExecuteResult,
  QCExecuteResultSchema,
} from 'src/models/qc-execute/qc-execute-result.schema';
import {
  QCExecute,
  QCExecuteSchema,
} from 'src/models/qc-execute/qc-execute.schema';
import { ErrorRepository } from 'src/repository/error/error.repository';
import { EvaluationCriteriaRepository } from 'src/repository/evaluation-criteria/evaluation-criteria.repository';
import { QCCommandRepository } from 'src/repository/qc-command/qc-command.repository';
import { QCExecuteProgressRepository } from 'src/repository/qc-execute/qc-execute-progress.repository';
import { QCExecuteResultRepository } from 'src/repository/qc-execute/qc-execute-result.repository';
import { QCExecuteRepository } from 'src/repository/qc-execute/qc-execute.repository';
import { QcExecuteController } from './qc-execute.controller';
import { QcExecuteService } from './qc-execute.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: Error.name,
        schema: ErrorSchema,
      },
      {
        name: QCExecute.name,
        schema: QCExecuteSchema,
      },
      {
        name: QCExecuteProgress.name,
        schema: QCExecuteProgressSchema,
      },
      {
        name: QCExecuteResult.name,
        schema: QCExecuteResultSchema,
      },
      {
        name: QCCommand.name,
        schema: QCCommandSchema,
      },
      {
        name: EvaluationCriteria.name,
        schema: EvaluationCriteriaSchema,
      },
    ]),
    SettingModule,
  ],
  controllers: [QcExecuteController],
  providers: [
    {
      provide: 'ErrorRepositoryInterface',
      useClass: ErrorRepository,
    },
    {
      provide: 'EvaluationCriteriaRepositoryInterface',
      useClass: EvaluationCriteriaRepository,
    },
    {
      provide: 'QCExecuteServiceInterface',
      useClass: QcExecuteService,
    },
    {
      provide: 'QCExecuteRepositoryInterface',
      useClass: QCExecuteRepository,
    },
    {
      provide: 'QCExecuteProgressRepositoryInterface',
      useClass: QCExecuteProgressRepository,
    },
    {
      provide: 'QCExecuteResultRepositoryInterface',
      useClass: QCExecuteResultRepository,
    },
    {
      provide: 'QCCommandRepositoryInterface',
      useClass: QCCommandRepository,
    },
    {
      provide: 'ItemService',
      useClass: ItemService,
    },
  ],
  exports: [
    {
      provide: 'QCExecuteServiceInterface',
      useClass: QcExecuteService,
    },
    {
      provide: 'QCExecuteRepositoryInterface',
      useClass: QCExecuteRepository,
    },
    {
      provide: 'QCExecuteProgressRepositoryInterface',
      useClass: QCExecuteProgressRepository,
    },
    {
      provide: 'QCExecuteResultRepositoryInterface',
      useClass: QCExecuteResultRepository,
    },
  ],
})
export class QcExecuteModule {}
