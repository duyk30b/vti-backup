import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { QCExecute } from 'src/models/qc-execute/qc-execute.schema';
import { GetListQCExecuteRequestDto } from '../dto/request/get-list-qc-execute.request.dto';

export interface QCExecuteRepositoryInterface
  extends BaseInterfaceRepository<QCExecute> {
  getList(request: GetListQCExecuteRequestDto): Promise<any>;
  getListByQCCommandCode(qcCommandCode: string): Promise<any>;
}
