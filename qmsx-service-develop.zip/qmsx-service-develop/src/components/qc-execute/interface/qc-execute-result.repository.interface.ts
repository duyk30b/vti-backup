import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { QCExecuteResult } from 'src/models/qc-execute/qc-execute-result.schema';
import { GetQCCommandReportByCauseRequestDto } from '../../qc-report/dto/request/get-qc-command-report-by-cause.request.dto';
import { CreateQCExecuteResultRequestDto } from '../dto/request/create-qc-execute-result.request.dto';
import { GetListQCExecuteResultRequestDto } from '../dto/request/get-list-qc-result.request.dto';
import { GetQCReportByCauseRequestDto } from '../dto/request/get-qc-report-by-cause.request.dto';

export interface QCExecuteResultRepositoryInterface
  extends BaseInterfaceRepository<QCExecuteResult> {
  createModel(
    request: CreateQCExecuteResultRequestDto,
    code: string,
  ): QCExecuteResult;
  getList(request: GetListQCExecuteResultRequestDto): Promise<any>;
  getLastItem(): Promise<any>;
  getTotalResult(qcExecuteId: string): Promise<any>;
  getQCReportByCause(request: GetQCReportByCauseRequestDto): Promise<any>;
  getQCCommandReportByCause(
    request: GetQCCommandReportByCauseRequestDto,
  ): Promise<any>;
}
