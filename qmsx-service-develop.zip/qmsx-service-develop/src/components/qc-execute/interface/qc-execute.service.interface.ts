import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { ConfirmQCExecuteResultRequestDto } from '../dto/request/confirm-qc-execute-result.request.dto';
import { CreateQCExecuteResultRequestDto } from '../dto/request/create-qc-execute-result.request.dto';
import { GetDetailPerformQCExecuteRequestDto } from '../dto/request/get-detail-qc-execute-progress.request.dto';
import { GetDetailQCExecuteRequestDto } from '../dto/request/get-detail-qc-execute.request.dto';
import { GetListQCExecuteRequestDto } from '../dto/request/get-list-qc-execute.request.dto';
import { GetListQCExecuteResultRequestDto } from '../dto/request/get-list-qc-result.request.dto';
import { GetQCReportByCauseRequestDto } from '../dto/request/get-qc-report-by-cause.request.dto';
import { GetDetailQCExecuteByUniqFieldRequestDto } from '../dto/request/get-detail-qc-execute-by-uniq-field.request.dto';
import { GetListQCExecuteResultByUniqFieldRequestDto } from '../dto/request/get-list-qc-result-by-uniq-field.request.dto';

export interface QCExecuteServiceInterface {
  getList(request: GetListQCExecuteRequestDto): Promise<any>;
  getDetailById(request: GetDetailQCExecuteRequestDto): Promise<any>;
  getDetailByUniqField(
    request: GetDetailQCExecuteByUniqFieldRequestDto,
  ): Promise<any>;
  getDetailPerform(request: GetDetailPerformQCExecuteRequestDto): Promise<any>;
  createQcResult(request: CreateQCExecuteResultRequestDto): Promise<any>;
  changeStatusQcResult(
    request: IdParamMongoDto & ConfirmQCExecuteResultRequestDto,
  ): Promise<any>;
  getListQcResultById(request: GetListQCExecuteResultRequestDto): Promise<any>;
  getListQcResultByUniqField(
    request: GetListQCExecuteResultByUniqFieldRequestDto,
  ): Promise<any>;
  getDetailQcResult(request: IdParamMongoDto): Promise<any>;
  createMulti(body: any): Promise<any>;
  getQCReportByCause(request: GetQCReportByCauseRequestDto): Promise<any>;
}
