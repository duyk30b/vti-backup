import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { QCExecuteProgress } from 'src/models/qc-execute/qc-execute-progress.schema';

export interface QCExecuteProgressRepositoryInterface
  extends BaseInterfaceRepository<QCExecuteProgress> {}
