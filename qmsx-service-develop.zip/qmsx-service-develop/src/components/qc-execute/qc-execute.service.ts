import { ErrorRepositoryInterface } from '@components/error/interface/error.repository.interface';
import { EvaluationCriteriaRepositoryInterface } from '@components/evaluation-criteria/interface/evaluation-criteria.repository.interface';
import { ItemService } from '@components/item/item.service';
import { QCCommandRepositoryInterface } from '@components/qc-command/interface/qc-command.repository.interface';
import { SettingServiceInterface } from '@components/setting/interface/setting.service.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/mongoose';
import { ApiError } from '@utils/api.error';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { compact, isEmpty, keyBy, map, uniq } from 'lodash';
import { Connection } from 'mongoose';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { QCExecuteProgress } from 'src/models/qc-execute/qc-execute-progress.schema';
import { ConfirmQCExecuteResultRequestDto } from './dto/request/confirm-qc-execute-result.request.dto';
import { CreateQCExecuteResultRequestDto } from './dto/request/create-qc-execute-result.request.dto';
import { GetDetailPerformQCExecuteRequestDto } from './dto/request/get-detail-qc-execute-progress.request.dto';
import { GetDetailQCExecuteRequestDto } from './dto/request/get-detail-qc-execute.request.dto';
import { GetListQCExecuteRequestDto } from './dto/request/get-list-qc-execute.request.dto';
import { GetListQCExecuteResultRequestDto } from './dto/request/get-list-qc-result.request.dto';
import { GetQCReportByCauseRequestDto } from './dto/request/get-qc-report-by-cause.request.dto';
import { QCExecuteProgressResponseDto } from './dto/response/qc-execute-progress.response.dto';
import { QCExecuteResultResponseDto } from './dto/response/qc-execute-result.response.dto';
import { QCExecuteResponseDto } from './dto/response/qc-execute.response.dto';
import { QCExecuteProgressRepositoryInterface } from './interface/qc-execute-progress.repository.interface';
import { QCExecuteResultRepositoryInterface } from './interface/qc-execute-result.repository.interface';
import { QCExecuteRepositoryInterface } from './interface/qc-execute.repository.interface';
import { QCExecuteServiceInterface } from './interface/qc-execute.service.interface';
import {
  QC_SETTING_TODO_QUANTITY,
  QC_STATUS,
  QC_TYPE,
} from './qc-execute.constant';
import { GetDetailQCExecuteByUniqFieldRequestDto } from './dto/request/get-detail-qc-execute-by-uniq-field.request.dto';
import { QCExecute } from 'src/models/qc-execute/qc-execute.schema';
import { GetListQCExecuteResultByUniqFieldRequestDto } from './dto/request/get-list-qc-result-by-uniq-field.request.dto';

@Injectable()
export class QcExecuteService implements QCExecuteServiceInterface {
  constructor(
    @Inject('QCExecuteRepositoryInterface')
    private readonly qcExecuteRepository: QCExecuteRepositoryInterface,

    @Inject('QCExecuteProgressRepositoryInterface')
    private readonly qcExecuteProgressRepository: QCExecuteProgressRepositoryInterface,

    @Inject('QCExecuteResultRepositoryInterface')
    private readonly qcExecuteResultRepository: QCExecuteResultRepositoryInterface,

    @Inject('QCCommandRepositoryInterface')
    private readonly qcCommandRepository: QCCommandRepositoryInterface,

    @Inject('EvaluationCriteriaRepositoryInterface')
    private readonly evaluationCriteriaRepository: EvaluationCriteriaRepositoryInterface,

    @Inject('ErrorRepositoryInterface')
    private readonly errorRepository: ErrorRepositoryInterface,

    @Inject('SettingServiceInterface')
    private readonly settingService: SettingServiceInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ItemService')
    private readonly itemService: ItemService,

    @InjectConnection() private readonly connection: Connection,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async getQCReportByCause(
    request: GetQCReportByCauseRequestDto,
  ): Promise<any> {
    const { data, count } = await this.qcExecuteRepository.getList(request);
    return new ResponseBuilder({
      items: data,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(request: GetListQCExecuteRequestDto) {
    const { data, count } = await this.qcExecuteRepository.getList(request);
    const userIds = uniq(compact(map(data, 'qcBy')));

    // Filter by user id
    const userIdFilters = [
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ];

    if (!isEmpty(userIds)) {
      let users = await this.userService.getList(userIdFilters);
      users = keyBy(users, 'id');
      data.forEach((item) => {
        item.qcBy = item.qcBy.map((i: number) => users[i]);
      });
    }

    // Filter by item code
    const itemCodes = uniq(compact(map(data, 'itemCode')));
    if (!isEmpty(itemCodes)) {
      const request = {
        codes: itemCodes.join(','),
      };
      let itemList = await this.itemService.getItemList(request);
      itemList = keyBy(itemList, 'code');

      data?.forEach((it) => {
        it.item = itemList[it.itemCode];
      });
    }

    // Filter by qcCommand code
    const qcCommandCodes = uniq(compact(map(data, 'qcCommandCode')));
    if (!isEmpty(itemCodes)) {
      let qcCommandList: any =
        await this.qcCommandRepository.findAllByCondition({
          code: {
            $in: qcCommandCodes,
          },
        });
      qcCommandList = keyBy(qcCommandList, 'code');

      data?.forEach((it) => {
        it.qcCommand = qcCommandList[it.qcCommandCode];
      });
    }

    const dataReturn = plainToInstance(QCExecuteResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async handleGetDetail(qcExecute: QCExecute) {
    if (!qcExecute) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const requestItem = {
      codes: qcExecute.itemCode,
    };
    let itemList = await this.itemService.getItemList(requestItem);
    itemList = keyBy(itemList, 'code');

    (qcExecute as any).item = itemList[qcExecute.itemCode];

    // handle get qc progress item
    const qcExecuteProgress =
      await this.qcExecuteProgressRepository.findAllByCondition({
        _id: {
          $in: qcExecute.qcProgressItemIds,
        },
      });

    (qcExecute as any).executeProgresses = qcExecuteProgress;

    const qcCommand = await this.qcCommandRepository.findOneByCode(
      qcExecute.qcCommandCode,
    );
    (qcExecute as any).qcCommand = qcCommand;

    const dataReturn = plainToInstance(QCExecuteResponseDto, qcExecute, {
      excludeExtraneousValues: true,
    });

    //need to handle get qc command object

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getDetailByUniqField(
    request: GetDetailQCExecuteByUniqFieldRequestDto,
  ): Promise<any> {
    try {
      const { itemCode, lot, qcCommandCode } = request;
      const qcExecute = await this.qcExecuteRepository.findOneByCondition({
        itemCode: itemCode,
        lot: lot,
        qcCommandCode: qcCommandCode,
      });

      return await this.handleGetDetail(qcExecute);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getDetailById(request: GetDetailQCExecuteRequestDto): Promise<any> {
    try {
      const { id } = request;
      const qcExecute = await this.qcExecuteRepository.findOneById(id);

      return await this.handleGetDetail(qcExecute);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getDetailPerform(
    request: GetDetailPerformQCExecuteRequestDto,
  ): Promise<any> {
    try {
      const { id, idProgress } = request;
      const qcExecute = await this.qcExecuteRepository.findOneById(id);

      if (!qcExecute) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      // need to handle get qc command object
      const qcCommand = await this.qcCommandRepository.findOneByCode(
        qcExecute.qcCommandCode,
      );

      (qcExecute as any).qcCommand = qcCommand;

      const evaluateCriteriaCodes = qcExecute.evaluationCriterias.map(
        (eva) => eva.code,
      );
      const evaluateCriteriaList =
        await this.evaluationCriteriaRepository.findAllByCondition({
          code: {
            $in: evaluateCriteriaCodes,
          },
        });
      if (evaluateCriteriaList.length) {
        for (let index = 0; index < evaluateCriteriaList.length; index++) {
          const errorCodes = [];
          const element = evaluateCriteriaList[index];
          const details = element.details;
          for (let index = 0; index < details.length; index++) {
            errorCodes.push(...details[index].errorCodes);
          }
          const errorList = await this.errorRepository.findAllByCondition({
            code: {
              $in: uniq(errorCodes),
            },
          });
          (element as any).errors = errorList;
        }
      }
      (qcExecute as any).evaluationCriterias = evaluateCriteriaList;

      const qcExecuteProgress =
        await this.qcExecuteProgressRepository.findOneById(idProgress);

      if (!qcExecuteProgress) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      const dataReturn = plainToInstance(
        QCExecuteProgressResponseDto,
        { ...qcExecute, ...qcExecuteProgress },
        {
          excludeExtraneousValues: true,
        },
      );

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async createQcResult(request: CreateQCExecuteResultRequestDto): Promise<any> {
    try {
      // generate code and pass to request
      const code = await this.generateUniqueCode();
      const document = this.qcExecuteResultRepository.createModel(
        request,
        code,
      );
      const dataSave = await document.save();
      const dataReturn = plainToInstance(QCExecuteResultResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async changeStatusQcResult(
    request: IdParamMongoDto & ConfirmQCExecuteResultRequestDto,
  ) {
    try {
      const { id, name, description, resultInfo } = request;
      const qcResult = await this.qcExecuteResultRepository.findOneById(id);
      if (qcResult.status) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
          .build();
      }
      await this.qcExecuteResultRepository.findByIdAndUpdate(id, {
        status: 1,
        name,
        description,
        resultInfo,
      });
      qcResult.name = name;
      qcResult.description = description;
      qcResult.resultInfo = resultInfo;

      // update execute progress
      const qcProgressMap = await this.qcExecuteProgressRepository.findOneById(
        qcResult.qcExecuteProgressId,
      );

      // check quantity of qcResult is smaller than remain quantity of qcProgress
      if (qcProgressMap.remainQuantity < qcResult.quantity) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.INVALID_QUANTITY_NUMBER'),
          )
          .build();
      }

      qcProgressMap.passQuantity =
        qcProgressMap.passQuantity +
        (qcResult.quantity - qcResult.failQuantity);
      qcProgressMap.failQuantity += qcResult.failQuantity;
      qcProgressMap.testedQuantity =
        qcProgressMap.passQuantity + qcProgressMap.failQuantity;
      qcProgressMap.remainQuantity =
        qcProgressMap.todoQuantity - qcProgressMap.testedQuantity;

      if (qcProgressMap.todoQuantity === qcProgressMap.testedQuantity) {
        qcProgressMap.status = QC_STATUS.DONE;
      } else {
        qcProgressMap.status = QC_STATUS.DOING;
      }

      await this.qcExecuteProgressRepository.findByIdAndUpdate(
        qcResult.qcExecuteProgressId,
        qcProgressMap,
      );

      // update execute
      const qcExecuteMap = await this.qcExecuteRepository.findOneById(
        qcResult.qcExecuteId,
      );

      const qcExecuteProgress =
        await this.qcExecuteResultRepository.getTotalResult(
          qcResult.qcExecuteId,
        );
      qcExecuteMap.progress = qcExecuteProgress.length;

      const qcProgressList =
        await this.qcExecuteProgressRepository.findAllByCondition({
          _id: {
            $in: qcExecuteMap.qcProgressItemIds,
          },
        });

      if (
        qcExecuteMap.settingTodoQuantity === QC_SETTING_TODO_QUANTITY.TESTED
      ) {
        // handle get the value of pass and fail quantity of qc-execute
        if (qcExecuteProgress.length === qcResult.index) {
          qcExecuteMap.passQuantity = qcProgressMap.passQuantity;
          qcExecuteMap.failQuantity = qcProgressMap.failQuantity;
        }
        for (let index = 0; index < qcProgressList.length; index++) {
          const element = qcProgressList[index];
          if (!index) continue;
          element.todoQuantity = qcProgressList[index - 1].testedQuantity;
          element.remainQuantity =
            element.todoQuantity - element.testedQuantity;
        }
      } else if (
        qcExecuteMap.settingTodoQuantity === QC_SETTING_TODO_QUANTITY.FAIL
      ) {
        qcExecuteMap.passQuantity += qcProgressMap.passQuantity;
        // handle get the value of fail quantity of qc-execute
        if (qcExecuteProgress.length === qcResult.index) {
          qcExecuteMap.failQuantity = qcProgressMap.failQuantity;
        }
        for (let index = 0; index < qcProgressList.length; index++) {
          const element = qcProgressList[index];
          if (!index) continue;
          element.todoQuantity = qcProgressList[index - 1].failQuantity;
          element.remainQuantity =
            element.todoQuantity - element.testedQuantity;
        }
      } else {
        // handle get the value of pass and fail quantity of qc-execute
        if (qcExecuteProgress.length === qcResult.index) {
          qcExecuteMap.passQuantity = qcProgressMap.passQuantity;
        }
        qcExecuteMap.failQuantity += qcProgressMap.failQuantity;
        for (let index = 0; index < qcProgressList.length; index++) {
          const element = qcProgressList[index];
          if (!index) continue;
          element.todoQuantity = qcProgressList[index - 1].passQuantity;
          element.remainQuantity =
            element.todoQuantity - element.testedQuantity;
        }
      }

      const bulkOps = [...qcProgressList].map((doc) => ({
        updateOne: {
          filter: { _id: doc._id },
          update: doc,
          upsert: true,
        },
      }));
      await this.qcExecuteProgressRepository.bulkWrite(bulkOps);

      qcExecuteMap.testedQuantity =
        qcExecuteMap.passQuantity + qcExecuteMap.failQuantity;
      qcExecuteMap.remainQuantity =
        qcExecuteMap.todoQuantity - qcExecuteMap.testedQuantity;

      if (
        qcExecuteMap.todoQuantity === qcExecuteMap.testedQuantity &&
        qcExecuteMap.progress === qcExecuteMap.qcNumber
      ) {
        qcExecuteMap.status = QC_STATUS.DONE;
      } else if (qcExecuteMap.testedQuantity === 0) {
        qcExecuteMap.status = QC_STATUS.NOT;
      } else {
        qcExecuteMap.status = QC_STATUS.DOING;
      }

      await this.qcExecuteRepository.findByIdAndUpdate(
        qcResult.qcExecuteId,
        qcExecuteMap,
      );

      const dataReturn = plainToInstance(QCExecuteResultResponseDto, qcResult, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  private async handleGetListQcResult(request: any) {
    const { idQcExecute } = request;
    const { data, count } = await this.qcExecuteResultRepository.getList(
      request,
    );

    const userIds = uniq(compact(map(data, 'createdBy')));

    // Filter by user id
    const userIdFilters = [
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ];

    if (!isEmpty(userIds)) {
      let users = await this.userService.getList(userIdFilters);
      users = keyBy(users, 'id');
      data.forEach((item) => {
        item.createdBy = {
          id: users[item.createdBy]?.id,
          username: users[item.createdBy]?.username,
          fullName: users[item.createdBy]?.fullName,
          code: users[item.createdBy]?.code,
        };
      });
    }

    const qcExecute = await this.qcExecuteRepository.findOneById(idQcExecute);

    const qcCommand = await this.qcCommandRepository.findOneByCode(
      qcExecute?.qcCommandCode,
    );

    if (isEmpty(qcExecute) || isEmpty(qcCommand)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    // get item mapping
    const itemList = await this.itemService.getItemList({
      codes: qcExecute.itemCode,
    });
    const item = itemList[0];

    const dataReturn = plainToInstance(QCExecuteResultResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder({
      itemCode: qcExecute.itemCode,
      itemName: item?.name,
      qcCommandCode: qcCommand.code,
      qcCommandName: qcCommand.name,
      lot: qcExecute.lot,
      qcNumber: qcExecute.qcNumber,
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getListQcResultByUniqField(
    request: GetListQCExecuteResultByUniqFieldRequestDto,
  ): Promise<any> {
    try {
      const { itemCode, lot, qcCommandCode } = request;
      const qcExecute = await this.qcExecuteRepository.findOneByCondition({
        itemCode: itemCode,
        lot: lot,
        qcCommandCode: qcCommandCode,
      });
      if (isEmpty(qcExecute)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
          .build();
      }
      (request as any).idQcExecute = qcExecute._id.toString();
      (request as any).type = QC_TYPE.EXECUTE;
      return await this.handleGetListQcResult(request);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getListQcResultById(
    request: GetListQCExecuteResultRequestDto,
  ): Promise<any> {
    try {
      return await this.handleGetListQcResult(request);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getDetailQcResult(request: IdParamMongoDto): Promise<any> {
    try {
      const { id } = request;
      const qcResult = await this.qcExecuteResultRepository.findOneById(id);
      if (!qcResult) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      //update result info properties
      const errorCodes = uniq(compact(map(qcResult.resultInfo, 'errorCode')));
      const evaluationCodes = uniq(
        compact(map(qcResult.resultInfo, 'evaluationCode')),
      );
      let errorList: any = await this.errorRepository.findAllByCondition({
        code: {
          $in: errorCodes,
        },
      });
      let evaluateList: any =
        await this.evaluationCriteriaRepository.findAllByCondition({
          code: {
            $in: evaluationCodes,
          },
        });

      errorList = keyBy(errorList, 'code');
      evaluateList = keyBy(evaluateList, 'code');
      (qcResult as any).resultInfo = qcResult.resultInfo.map((result) => {
        return {
          errorCode: errorList[result.errorCode]?.code,
          errorName: errorList[result.errorCode]?.name,
          errorDescription: errorList[result.errorCode]?.description,
          evaluationCode: evaluateList[result.evaluationCode]?.code,
          evaluationName: evaluateList[result.evaluationCode]?.name,
          errorNumber: result.errorNumber,
          causeCodes: result.causeCodes,
        };
      });

      const qcExecute = await this.qcExecuteRepository.findOneById(
        qcResult.qcExecuteId,
      );

      //user service call data
      const userInfo = await this.userService.getDetail(qcResult.createdBy);
      qcResult.createdBy = userInfo;

      // Filter by user id
      const userIdFilters = [
        {
          column: 'userIds',
          text: qcExecute.qcBy.join(','),
        },
      ];

      if (!isEmpty(qcExecute.qcBy)) {
        let users = await this.userService.getList(userIdFilters);
        users = keyBy(users, 'id');
        qcExecute.qcBy = qcExecute.qcBy.map((i: number) => users[i]);
      }

      const qcCommand = await this.qcCommandRepository.findOneByCode(
        qcExecute?.qcCommandCode,
      );

      if (isEmpty(qcExecute) || isEmpty(qcCommand)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
          .build();
      }

      const itemList = await this.itemService.getItemList({
        codes: qcExecute.itemCode,
      });
      const item = itemList[0];

      const dataReturn = plainToInstance(
        QCExecuteResultResponseDto,
        { ...qcResult, qcExecute, qcCommand, item },
        {
          excludeExtraneousValues: true,
        },
      );

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTsERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async createMulti(items: any) {
    try {
      // Get setting qc method
      const setting = await this.settingService.find();
      //need to check da ton tai qcExecute o trong db hay chua
      for (let i = 0; i < items?.length; i++) {
        let executeProgressTemp = {} as QCExecuteProgress;
        const qcExecute = items?.[i];
        const executeProgressIds = [];
        const qcExecuteExist =
          await this.qcExecuteRepository.findOneByCondition({
            itemCode: qcExecute.itemCode,
            lot: qcExecute.lot,
            qcCommandCode: qcExecute.qcCommandCode,
          });

        if (!isEmpty(qcExecuteExist)) {
          continue;
        }

        for (let j = 0; j < qcExecute.qcNumber; j++) {
          const executeProgress = {} as QCExecuteProgress;
          if (j === 0) {
            executeProgress.todoQuantity = qcExecute.todoQuantity;
            executeProgress.remainQuantity = qcExecute.todoQuantity;
          } else {
            executeProgress.remainQuantity = 0;
            if (qcExecute.settingTodoQuantity === 0) {
              executeProgress.todoQuantity = executeProgressTemp.testedQuantity;
            } else if (qcExecute.settingTodoQuantity === 2) {
              executeProgress.todoQuantity = executeProgressTemp.passQuantity;
            } else {
              executeProgress.todoQuantity = executeProgressTemp.failQuantity;
            }
          }
          executeProgress.index = j + 1;
          executeProgress.testedQuantity = 0;
          executeProgress.passQuantity = 0;
          executeProgress.failQuantity = 0;
          executeProgress.status = 0;
          const result = await this.qcExecuteProgressRepository.create(
            executeProgress,
          );
          executeProgressIds.push(result._id);
          executeProgressTemp = executeProgress;
        }
        await this.qcExecuteRepository.create({
          ...qcExecute,
          remainQuantity: qcExecute.todoQuantity,
          qcProgressItemIds: executeProgressIds,
          testedQuantity: 0,
          progress: 0,
          passQuantity: 0,
          failQuantity: 0,
          settingFormat: setting?.data.settingFormat,
          settingTodoQuantity: setting?.data.settingTodoQuantity,
          status: QC_STATUS.NOT,
        });
      }

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async generateUniqueCode() {
    const prefix = 'PKQ';
    const year = new Date().getFullYear().toString().slice(-2);

    const lastQcResult = await this.qcExecuteResultRepository.getLastItem();

    let sequenceNumber = 1;
    if (!isEmpty(lastQcResult)) {
      const lastCode = lastQcResult[0].code;
      const lastSequenceNumber = parseInt(lastCode.slice(-6), 10);
      sequenceNumber = lastSequenceNumber + 1;
    }

    const paddedSequenceNumber = sequenceNumber.toString().padStart(6, '0');

    const code = `${prefix}${year}${paddedSequenceNumber}`;

    // Kiểm tra xem mã code đã tồn tại trong collection hay chưa
    const existingQcResult =
      await this.qcExecuteResultRepository.findOneByCondition({
        code,
      });

    if (existingQcResult) {
      return this.generateUniqueCode();
    }

    return code;
  }
}
