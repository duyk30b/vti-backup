import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsNotEmpty, IsOptional } from 'class-validator';
export class Result {
  @ApiProperty()
  @IsNotEmpty()
  errorCode: string;

  @ApiProperty()
  @IsNotEmpty()
  evaluationCode: string;

  @ApiProperty()
  @IsNotEmpty()
  errorNumber: number;

  @ApiProperty()
  @IsOptional()
  causeCodes: string[];

  @ApiProperty()
  @IsOptional()
  propose: string;
}
export class CreateQCExecuteResultRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  qcExecuteId: string;

  @ApiProperty()
  @IsNotEmpty()
  qcExecuteProgressId: string;

  @ApiProperty()
  @IsNotEmpty()
  index: number;

  @ApiProperty()
  @IsOptional()
  name: string;

  @ApiProperty()
  @IsOptional()
  description: string;

  @ApiProperty()
  @IsNotEmpty()
  quantity: number;

  @ApiProperty()
  @IsNotEmpty()
  failQuantity: number;

  @ApiProperty()
  @IsNotEmpty()
  duration: number;

  @ApiProperty()
  @IsNotEmpty()
  qcStartDate: Date;

  @ApiProperty()
  @IsNotEmpty()
  qcEndDate: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  resultInfo: Result[];
}
