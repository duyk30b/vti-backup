import { QC_TYPE } from '@components/qc-execute/qc-execute.constant';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class GetListQCExecuteResultRequestDto extends PaginationQuery {
  @ApiPropertyOptional({
    example: ['1', '2'],
  })
  @IsOptional()
  @IsString()
  queryIds?: string[];

  @ApiProperty()
  @IsNotEmpty()
  type: QC_TYPE;

  @ApiProperty()
  @IsNotEmpty()
  idQcExecute: string;

  @ApiProperty()
  @IsOptional()
  idQcProgress: string;
}
