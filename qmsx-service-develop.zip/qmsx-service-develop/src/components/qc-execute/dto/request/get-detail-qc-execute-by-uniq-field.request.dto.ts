import { BaseDto } from '@core/dto/base.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class GetDetailQCExecuteByUniqFieldRequestDto extends BaseDto {
  @ApiPropertyOptional({
    example: 'IT0001',
  })
  @IsNotEmpty()
  @IsString()
  itemCode: string;

  @ApiPropertyOptional({
    example: 'IT-002',
  })
  @IsOptional()
  @IsString()
  lot: string;

  @ApiPropertyOptional({
    example: 'QC0001',
  })
  @IsNotEmpty()
  @IsString()
  qcCommandCode: string;
}
