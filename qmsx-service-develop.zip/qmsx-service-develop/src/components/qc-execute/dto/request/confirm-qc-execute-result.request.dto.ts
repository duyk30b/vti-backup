import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsOptional } from 'class-validator';
import { Result } from 'src/models/qc-execute/qc-execute-result.schema';

export class ConfirmQCExecuteResultRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  name: string;

  @ApiProperty()
  @IsOptional()
  description: string;

  @ApiProperty()
  @IsOptional()
  resultInfo: Result[];
}
