import { ApiProperty } from '@nestjs/swagger';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import { QC_STATUS } from '@components/qc-execute/qc-execute.constant';
import { Expose } from 'class-transformer';
import { BaseResponseDto } from '@core/dto/base.response.dto';

export class ExecuteProgress extends BaseResponseDto {
  @Expose()
  index: number;

  @Expose()
  todoQuantity: number;

  @Expose()
  testedQuantity: number;

  @Expose()
  remainQuantity: number;

  @Expose()
  passQuantity: number;

  @Expose()
  failQuantity: number;

  @Expose()
  status: QC_STATUS;
}

export class GetDetailPerformQCExecuteRequestDto extends IdParamMongoDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  idProgress: string;
}
