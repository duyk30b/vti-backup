import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class GetListQCExecuteResultByUniqFieldRequestDto extends PaginationQuery {
  @ApiPropertyOptional({
    example: ['1', '2'],
  })
  @IsOptional()
  @IsString()
  queryIds?: string[];

  @ApiPropertyOptional({
    example: 'IT0001',
  })
  @IsNotEmpty()
  @IsString()
  itemCode: string;

  @ApiPropertyOptional({
    example: 'IT-002',
  })
  @IsOptional()
  @IsString()
  lot: string;

  @ApiPropertyOptional({
    example: 'QC0001',
  })
  @IsNotEmpty()
  @IsString()
  qcCommandCode: string;
}
