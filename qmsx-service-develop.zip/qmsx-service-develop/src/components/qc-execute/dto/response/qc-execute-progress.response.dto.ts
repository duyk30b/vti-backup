import { ErrorResponseDto } from '@components/error/dto/response/error.response.dto';
import { QCCommandResponseDto } from '@components/qc-command/dto/response/qc-command.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { Expose, Type } from 'class-transformer';
export class EvaluationCriterias {
  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  checkType: number;

  @Expose()
  upperBound: number;

  @Expose()
  norm: number;

  @Expose()
  lowerBound: number;

  @Expose()
  description: string;

  @Expose()
  active: number;

  @Expose()
  @Type(() => ErrorResponseDto)
  errors: ErrorResponseDto[];
}

export class QCExecuteProgressResponseDto extends BaseResponseDto {
  @Expose()
  index: number;

  @Expose()
  qcNumber: number;

  @Expose()
  itemCode: string;

  @Expose()
  itemName: string;

  @Expose()
  @Type(() => QCCommandResponseDto)
  qcCommand: QCCommandResponseDto;

  @Expose()
  lot: string;

  @Expose()
  startDate: Date;

  @Expose()
  endDate: Date;

  @Expose()
  todoQuantity: number;

  @Expose()
  testedQuantity: number;

  @Expose()
  remainQuantity: number;

  @Expose()
  @Type(() => EvaluationCriterias)
  evaluationCriterias: EvaluationCriterias[];
}
