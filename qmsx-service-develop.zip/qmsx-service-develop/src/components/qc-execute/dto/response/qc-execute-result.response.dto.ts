import { QC_STATUS_RESULT } from '@components/qc-execute/qc-execute.constant';
import { UserResponseDto } from '@components/user/dto/response/user.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { Expose, Type } from 'class-transformer';
import { Types } from 'mongoose';

export class Item {
  @Expose()
  code: string;

  @Expose()
  name: string;
}
export class ResultDto {
  @Expose()
  errorCode: string;

  @Expose()
  errorName: string;

  @Expose()
  errorDescription: string;

  @Expose()
  evaluationName: string;

  @Expose()
  errorNumber: number;

  @Expose()
  causeCodes: string[];
}

class ExecuteDto {
  @Expose()
  @Type(() => UserResponseDto)
  qcBy: UserResponseDto[];

  @Expose()
  itemName: string;

  @Expose()
  itemCode: string;

  @Expose()
  lot: string;

  @Expose()
  qcNumber: number;

  @Expose()
  startDate: Date;

  @Expose()
  endDate: Date;
}

class CommandDto {
  @Expose()
  code: string;

  @Expose()
  name: string;
}

export class QCExecuteResultResponseDto extends BaseResponseDto {
  @Expose()
  qcExecuteId: Types.ObjectId;

  @Expose()
  qcExecuteProgressId: Types.ObjectId;

  @Expose()
  index: number;

  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  description: string;

  @Expose()
  quantity: number;

  @Expose()
  failQuantity: number;

  @Expose()
  duration: number;

  @Expose()
  qcStartDate: Date;

  @Expose()
  qcEndDate: Date;

  @Expose()
  status: QC_STATUS_RESULT;

  @Expose()
  @Type(() => Item)
  item: Item;

  @Expose()
  @Type(() => ExecuteDto)
  qcExecute: ExecuteDto;

  @Expose()
  @Type(() => CommandDto)
  qcCommand: CommandDto;

  @Expose()
  @Type(() => ResultDto)
  resultInfo: ResultDto[];
}
