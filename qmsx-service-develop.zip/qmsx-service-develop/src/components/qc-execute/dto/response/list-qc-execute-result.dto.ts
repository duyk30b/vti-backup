import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';
import { QCExecuteResultResponseDto } from './qc-execute-result.response.dto';

export class ListQCExecuteResultResponseDto extends PaginationResponse {
  @ApiProperty({ type: QCExecuteResultResponseDto, isArray: true })
  @Type(() => QCExecuteResultResponseDto)
  @Expose()
  items: QCExecuteResultResponseDto[];
}
