import { Evaluation } from '@components/evaluation-form/dto/request/create-evaluation-form-template.request.dto';
import {
  QC_SETTING_FORMAT,
  QC_SETTING_TODO_QUANTITY,
  QC_STATUS,
} from '@components/qc-execute/qc-execute.constant';
import { UserResponseDto } from '@components/user/dto/response/user.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { Expose, Type } from 'class-transformer';
import { ExecuteProgress } from '../request/get-detail-qc-execute-progress.request.dto';
import { QCCommandResponseDto } from '@components/qc-command/dto/response/qc-command.response.dto';

class ItemResponse {
  @Expose()
  code: string;

  @Expose()
  name: string;
}

export class QCExecuteResponseDto extends BaseResponseDto {
  @Expose()
  itemName: string;

  @Expose()
  itemCode: string;

  @Expose()
  @Type(() => ItemResponse)
  item: ItemResponse;

  @Expose()
  lot: string;

  @Expose()
  evaluationCriterias: Evaluation[];

  @Expose()
  qcNumber: number;

  @Expose()
  startDate: Date;

  @Expose()
  endDate: Date;

  @Expose()
  deadLine: Date;

  @Expose()
  qcCommandCode: string;

  @Expose()
  @Type(() => QCCommandResponseDto)
  qcCommand: QCCommandResponseDto;

  @Expose()
  @Type(() => UserResponseDto)
  qcBy: UserResponseDto[];

  @Expose()
  qcFormat: string;

  @Expose()
  planQuantity: number;

  @Expose()
  todoQuantity: number;

  @Expose()
  testedQuantity: number;

  @Expose()
  remainQuantity: number;

  @Expose()
  passQuantity: number;

  @Expose()
  failQuantity: number;

  @Expose()
  unit: string;

  @Expose()
  status: QC_STATUS;

  @Expose()
  progress: string;

  @Expose()
  settingFormat: QC_SETTING_FORMAT;

  @Expose()
  settingTodoQuantity: QC_SETTING_TODO_QUANTITY;

  @Expose()
  @Type(() => ExecuteProgress)
  executeProgresses: ExecuteProgress[];

  @Expose()
  errors: any[];
}
