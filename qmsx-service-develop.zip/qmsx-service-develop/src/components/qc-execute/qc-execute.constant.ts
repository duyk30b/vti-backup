export enum QC_STATUS {
  NOT,
  DOING,
  DONE,
}

export enum QC_STATUS_RESULT {
  DRAFT,
  DONE,
}

export enum QC_SETTING_FORMAT {
  MANDATORY,
  OPTIONAL,
}

export enum QC_SETTING_TODO_QUANTITY {
  TESTED,
  FAIL,
  PASS,
}

export enum QC_TYPE {
  EXECUTE,
  PROGRESS,
}
