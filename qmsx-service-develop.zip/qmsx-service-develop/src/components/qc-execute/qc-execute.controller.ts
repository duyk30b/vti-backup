import {
  Body,
  Controller,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { Payload } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { isEmpty } from 'lodash';
import { CreateQCExecuteResultRequestDto } from './dto/request/create-qc-execute-result.request.dto';
import { GetDetailPerformQCExecuteRequestDto } from './dto/request/get-detail-qc-execute-progress.request.dto';
import { GetDetailQCExecuteRequestDto } from './dto/request/get-detail-qc-execute.request.dto';
import { GetListQCExecuteRequestDto } from './dto/request/get-list-qc-execute.request.dto';
import { ListQCExecuteResponseDto } from './dto/response/list-qc-execute.response.dto';
import { QCExecuteServiceInterface } from './interface/qc-execute.service.interface';
import { GetListQCExecuteResultRequestDto } from './dto/request/get-list-qc-result.request.dto';
import { ListQCExecuteResultResponseDto } from './dto/response/list-qc-execute-result.dto';
import { ConfirmQCExecuteResultRequestDto } from './dto/request/confirm-qc-execute-result.request.dto';
import { GetDetailQCExecuteByUniqFieldRequestDto } from './dto/request/get-detail-qc-execute-by-uniq-field.request.dto';
import { GetListQCExecuteResultByUniqFieldRequestDto } from './dto/request/get-list-qc-result-by-uniq-field.request.dto';

@Controller('qc-executes')
export class QcExecuteController {
  constructor(
    @Inject('QCExecuteServiceInterface')
    private readonly qcExecuteService: QCExecuteServiceInterface,
  ) {}

  @Get()
  @ApiOperation({
    tags: ['QC Execute - Thực hiện QC'],
    summary: 'Danh sách thực hiện qc',
    description: 'Danh sách thực hiện qc',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListQCExecuteResponseDto,
  })
  async getList(@Query() query: GetListQCExecuteRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qcExecuteService.getList(request);
  }

  @Get('/detail/:id')
  @ApiOperation({
    tags: ['QC Execute - Thực hiện QC'],
    summary: 'Tiến trình qc sản phẩm',
    description: 'Tiến trình qc sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
  })
  async getDetailById(
    @Param() param: GetDetailQCExecuteRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qcExecuteService.getDetailById(request);
  }

  @Get('/detail')
  @ApiOperation({
    tags: ['QC Execute - Thực hiện QC'],
    summary: 'Tiến trình qc sản phẩm',
    description: 'Tiến trình qc sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
  })
  async getDetailByUniqField(
    @Query() query: GetDetailQCExecuteByUniqFieldRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qcExecuteService.getDetailByUniqField(request);
  }

  @Get('/:id/:idProgress')
  @ApiOperation({
    tags: ['QC Execute - Thực hiện QC'],
    summary: 'thực hiện qc sản phẩm',
    description: 'thực hiện qc sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
  })
  async getDetailPerform(
    @Param() param: GetDetailPerformQCExecuteRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qcExecuteService.getDetailPerform(request);
  }

  @Post('/result')
  @ApiOperation({
    tags: ['QC Execute - Thực hiện QC'],
    summary: 'thực hiện qc sản phẩm',
    description: 'thực hiện qc sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
  })
  async createQcResult(
    @Payload() payload: CreateQCExecuteResultRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qcExecuteService.createQcResult(request);
  }

  @Put('/:id/result')
  @ApiOperation({
    tags: ['QC Execute - Thực hiện QC'],
    summary: 'thay đổi trạng thái qc sản phẩm',
    description: 'thay đổi trạng thái qc sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
  })
  async changeStatusQCResult(
    @Param() param: IdParamMongoDto,
    @Payload() payload: ConfirmQCExecuteResultRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    const { request: requestPayload, responseError: responseErrorPayload } =
      payload;
    if (responseErrorPayload && !isEmpty(responseErrorPayload)) {
      return responseErrorPayload;
    }

    return await this.qcExecuteService.changeStatusQcResult({
      ...request,
      ...requestPayload,
    });
  }

  @Get('/result')
  @ApiOperation({
    tags: ['QC Execute - Thực hiện QC'],
    summary: 'danh sách kết quả qc',
    description: 'danh sách kết quả qc',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListQCExecuteResultResponseDto,
  })
  async getListQCResultById(@Query() query: GetListQCExecuteResultRequestDto) {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qcExecuteService.getListQcResultById(request);
  }

  @Get('/item/result')
  @ApiOperation({
    tags: ['QC Execute - Thực hiện QC'],
    summary: 'danh sách kết quả qc',
    description: 'danh sách kết quả qc',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListQCExecuteResultResponseDto,
  })
  async getListQCResultByUniqField(
    @Query() query: GetListQCExecuteResultByUniqFieldRequestDto,
  ) {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qcExecuteService.getListQcResultByUniqField(request);
  }

  @Get('/:id/result')
  @ApiOperation({
    tags: ['QC Execute - Thực hiện QC'],
    summary: 'chi tiết kết quả qc',
    description: 'chi tiết kết quả qc',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
  })
  async getDetailQCResult(@Param() param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qcExecuteService.getDetailQcResult(request);
  }

  @Post('/test')
  async test(@Body() body: any): Promise<any> {
    return await this.qcExecuteService.createMulti(body.data);
  }
}
