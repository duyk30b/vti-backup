import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import {
  ErrorGroup,
  ErrorGroupSchema,
} from 'src/models/error-group/error-group.schema';
import { ErrorSchema } from 'src/models/error/error.schema';
import { ErrorGroupRepository } from 'src/repository/error-group/error-group.repository';
import { ErrorRepository } from 'src/repository/error/error.repository';
import { ErrorGroupController } from './error-group.controller';
import { ErrorGroupService } from './error-group.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: ErrorGroup.name,
        schema: ErrorGroupSchema,
      },
      {
        name: Error.name,
        schema: ErrorSchema,
      },
    ]),
  ],
  controllers: [ErrorGroupController],
  providers: [
    {
      provide: 'ErrorGroupServiceInterface',
      useClass: ErrorGroupService,
    },
    {
      provide: 'ErrorGroupRepositoryInterface',
      useClass: ErrorGroupRepository,
    },
    {
      provide: 'ErrorRepositoryInterface',
      useClass: ErrorRepository,
    },
  ],
  exports: [
    {
      provide: 'ErrorGroupServiceInterface',
      useClass: ErrorGroupService,
    },
    {
      provide: 'ErrorGroupRepositoryInterface',
      useClass: ErrorGroupRepository,
    },
  ],
})
export class ErrorGroupModule {}
