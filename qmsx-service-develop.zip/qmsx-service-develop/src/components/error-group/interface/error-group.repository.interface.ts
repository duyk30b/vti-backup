import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ErrorGroup } from 'src/models/error-group/error-group.schema';
import { CreateErrorGroupRequestDto } from '../dto/request/create-error-group.request.dto';
import { GetListErrorGroupRequestDto } from '../dto/request/get-list-error-group.request.dto';
import { UpdateErrorGroupBodyDto } from '../dto/request/update-error-group.request.dto';

export interface ErrorGroupRepositoryInterface
  extends BaseInterfaceRepository<ErrorGroup> {
  createModel(request: CreateErrorGroupRequestDto): ErrorGroup;
  updateModel(error: ErrorGroup, request: UpdateErrorGroupBodyDto): ErrorGroup;
  getList(request: GetListErrorGroupRequestDto): Promise<any>;
  getLastErrorGroup(): Promise<any>;
}
