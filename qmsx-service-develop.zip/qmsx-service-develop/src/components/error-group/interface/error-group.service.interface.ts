import { GetListErrorRequestDto } from '@components/error/dto/request/get-list-error.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { CreateErrorGroupRequestDto } from '../dto/request/create-error-group.request.dto';
import { GetDetailErrorGroupRequestDto } from '../dto/request/get-detail-error-group.request.dto';
import { UpdateErrorGroupRequestDto } from '../dto/request/update-error-group.request.dto';

export interface ErrorGroupServiceInterface {
  create(request: CreateErrorGroupRequestDto): Promise<any>;
  update(request: UpdateErrorGroupRequestDto): Promise<any>;
  getDetail(request: GetDetailErrorGroupRequestDto): Promise<any>;
  getList(request: GetListErrorRequestDto): Promise<any>;
  delete(request: IdParamMongoDto): Promise<any>;
  updateActiveStatus(request: UpdateActiveStatusPayload): Promise<any>;
  import(
    data: any,
    userId: number,
  ): Promise<{ dataSuccess: any[]; dataError: any[] }>;
}
