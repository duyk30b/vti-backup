import { ErrorResponseDto } from '@components/error/dto/response/error.response.dto';
import { ErrorRepositoryInterface } from '@components/error/interface/error.repository.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ACTIVE_ENUM } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import {
  compact,
  difference,
  isEmpty,
  isNumber,
  keyBy,
  map,
  uniq,
} from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import {
  getDataInsert,
  getDataToInsertError,
  getDataToUpdateError,
  getDataUpdate,
} from 'src/helper/import.helper';
import { CreateErrorGroupRequestDto } from './dto/request/create-error-group.request.dto';
import { GetDetailErrorGroupRequestDto } from './dto/request/get-detail-error-group.request.dto';
import { GetListErrorGroupRequestDto } from './dto/request/get-list-error-group.request.dto';
import { UpdateErrorGroupRequestDto } from './dto/request/update-error-group.request.dto';
import { ErrorGroupResponseDto } from './dto/response/error-group.response.dto';
import {
  EMPTY_STRING,
  INDEX_ERROR_GROUP_CODE_START,
  MAX_LENGTH_INDEX,
  PADDING_SYMBOL,
  PREFIX_ERROR_GROUP_CODE,
  REGEX_PADDING_ZERO,
  STEP_INDEX_ERROR_GROUP_CODE,
} from './error-group.constant';
import { ErrorGroupRepositoryInterface } from './interface/error-group.repository.interface';
import { ErrorGroupServiceInterface } from './interface/error-group.service.interface';

@Injectable()
export class ErrorGroupService implements ErrorGroupServiceInterface {
  constructor(
    @Inject('ErrorRepositoryInterface')
    private readonly errorRepository: ErrorRepositoryInterface,

    @Inject('ErrorGroupRepositoryInterface')
    private readonly errorGroupRepository: ErrorGroupRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateErrorGroupRequestDto): Promise<any> {
    try {
      const { code } = request;
      const errorGroup = await this.errorGroupRepository.findOneByCode(code);
      if (!isEmpty(errorGroup)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.ERROR_GROUP_CODE_EXIST'),
          )
          .build();
      }

      const validateResult = await this.validateError(request);
      if (validateResult.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validateResult;
      }

      const document = this.errorGroupRepository.createModel(request);
      document.code = await this.generateErrorGroupCode();
      const dataSave = await document.save();
      const dataReturn = plainToInstance(ErrorGroupResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  private async validateError(
    request: CreateErrorGroupRequestDto,
  ): Promise<any> {
    let { errorCodes } = request;
    errorCodes = uniq(compact(errorCodes));
    const errorExists = await this.errorRepository.findAllByCondition({
      code: { $in: errorCodes },
    });
    const errorCodeExists = errorExists.map((error) => error.code);
    const errorNotFound = difference(errorCodes, errorCodeExists);
    if (errorCodes.length != errorCodeExists.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          `${await this.i18n.translate(
            'error.NOT_FOUND_ERROR',
          )} ${errorNotFound.join(', ')}`,
        )
        .build();
    }
    const errorInactive = await this.errorRepository.findAllByCondition({
      code: {
        $in: errorCodes,
      },
      active: ACTIVE_ENUM.INACTIVE,
    });

    if (errorInactive.length > 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.LOCKED)
        .withMessage(
          `Lỗi ${errorInactive
            .map((i) => i.code)
            .join(', ')} đang ở trạng thái tạm dừng`,
        )
        .build();
    }
    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async getDetail(request: GetDetailErrorGroupRequestDto): Promise<any> {
    try {
      const { id } = request;
      const errorGroup = await this.errorGroupRepository.findOneById(id);
      if (!errorGroup) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      const errors = await this.errorRepository.findAllByCondition({
        code: { $in: errorGroup?.errorCodes },
      });

      const errorReturn = plainToInstance(ErrorResponseDto, errors, {
        excludeExtraneousValues: true,
      });

      const dataReturn = plainToInstance(ErrorGroupResponseDto, errorGroup, {
        excludeExtraneousValues: true,
      });

      dataReturn.errors = errorReturn;

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getList(request: GetListErrorGroupRequestDto): Promise<any> {
    const { data, count } = await this.errorGroupRepository.getList(request);
    const userIds = uniq(compact(map(data, 'createdBy')));

    // Filter by user id
    const userIdFilters = [
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ];

    if (!isEmpty(userIds)) {
      let users = await this.userService.getList(userIdFilters);
      users = keyBy(users, 'id');
      data.forEach((item) => {
        item.createdBy = {
          id: users[item.createdBy]?.id,
          username: users[item.createdBy]?.username,
          fullName: users[item.createdBy]?.fullName,
          code: users[item.createdBy]?.code,
        };
      });
    }

    const dataReturn = plainToInstance(ErrorGroupResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async update(request: UpdateErrorGroupRequestDto): Promise<any> {
    try {
      const { id } = request;
      let errorGroup = await this.errorGroupRepository.findOneById(id);
      if (!errorGroup) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      const validateResult = await this.validateError(request);
      if (validateResult.statusCode !== ResponseCodeEnum.SUCCESS) {
        return validateResult;
      }

      errorGroup = this.errorGroupRepository.updateModel(errorGroup, request);

      const dataSave = await this.errorGroupRepository.findByIdAndUpdate(
        id,
        errorGroup,
      );

      const dataReturn = plainToInstance(ErrorGroupResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async delete(request: IdParamMongoDto): Promise<any> {
    const { id } = request;
    const errorGroup = await this.errorGroupRepository.findOneByCondition(id);
    if (!errorGroup) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    await this.errorGroupRepository.deleteById(id);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateActiveStatus(request: UpdateActiveStatusPayload): Promise<any> {
    const { id, status } = request;
    const errorGroup = await this.errorGroupRepository.findOneById(id);
    if (!errorGroup) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    await this.errorGroupRepository.findByIdAndUpdate(id, {
      $set: { active: status },
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private getErrorValidateExcel(data: any[], i18n: I18nRequestScopeService) {
    const dataError = [];
    const dataRes = [];
    data.forEach((item) => {
      if (
        item.action !== i18n.translate('import.common.add') &&
        item.action !== i18n.translate('import.common.edit')
      ) {
        dataError.push({
          ...item,
          errorDesc: i18n.translate('import.error.action'),
        });
      } else if (new RegExp(/[^0-9a-zA-Z]/g).test(item?.code)) {
        dataError.push({
          ...item,
          errorDesc: i18n.translate('import.errorGroupTemplate.codeInvalid'),
        });
      } else if (
        item?.active !== ACTIVE_ENUM.ACTIVE &&
        item?.active !== ACTIVE_ENUM.INACTIVE
      ) {
        dataError.push({
          ...item,
          errorDesc: i18n.translate('import.error.active'),
        });
      } else
        dataRes.push({
          ...item,
          description: item.description ? item.description : '',
        });
    });
    return { dataErrorValidate: dataError, dataPass: dataRes };
  }

  async import(
    data: any,
    userId: number,
  ): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const textAdd = await this.i18n.translate('import.common.add');
    const { dataErrorValidate, dataPass } = this.getErrorValidateExcel(
      data,
      this.i18n,
    );

    let { dataToInsert, codesInsert } = getDataInsert(dataPass, textAdd);
    const { dataToUpdate, codesUpdate } = getDataUpdate(dataPass, textAdd);
    dataToInsert = dataToInsert.map((item) => {
      return { ...item, createdBy: userId };
    });

    const codeInsertExists = await this.errorGroupRepository.findAllByCondition(
      {
        code: { $in: codesInsert },
      },
    );
    const codeUpdateExists = await this.errorGroupRepository.findAllByCondition(
      {
        code: { $in: codesUpdate },
      },
    );
    const codeInsertMap = keyBy(codeInsertExists, 'code');
    const codeUpdateMap = keyBy(codeUpdateExists, 'code');

    const { dataError: dataInsertError, dataInsert } = getDataToInsertError(
      dataToInsert,
      codeInsertMap,
    );
    const { dataError: dataUpdateError, dataUpdate } = getDataToUpdateError(
      dataToUpdate,
      codeUpdateMap,
    );

    const bulkOps = [...dataInsert, ...dataUpdate].map((doc) => ({
      updateOne: {
        filter: { code: doc.code },
        update: doc,
        upsert: true,
      },
    }));

    const dataSuccess = await this.errorGroupRepository.bulkWrite(bulkOps);

    return {
      dataError: [...dataInsertError, ...dataUpdateError, ...dataErrorValidate],
      dataSuccess,
    };
  }

  private async generateErrorGroupCode(): Promise<any> {
    const lastErrorGroup = await this.errorGroupRepository.getLastErrorGroup();

    let index = INDEX_ERROR_GROUP_CODE_START;
    if (!isEmpty(lastErrorGroup)) {
      const lastCode: string = lastErrorGroup.code;
      if (
        !isEmpty(lastCode) &&
        lastCode.length > PREFIX_ERROR_GROUP_CODE.length
      ) {
        let lastIndex: any = lastCode
          .substring(PREFIX_ERROR_GROUP_CODE.length)
          .replace(REGEX_PADDING_ZERO, EMPTY_STRING);
        lastIndex = Number(lastIndex);
        if (!isNaN(lastIndex)) {
          index = lastIndex + STEP_INDEX_ERROR_GROUP_CODE;
        }
      }
    }

    const codeNew = `${PREFIX_ERROR_GROUP_CODE}${index
      ?.toString()
      .padStart(MAX_LENGTH_INDEX, PADDING_SYMBOL)}`;

    const existCode = await this.errorGroupRepository.findOneByCode(codeNew);

    if (!isEmpty(existCode)) {
      return this.generateErrorGroupCode();
    }

    return codeNew;
  }
}
