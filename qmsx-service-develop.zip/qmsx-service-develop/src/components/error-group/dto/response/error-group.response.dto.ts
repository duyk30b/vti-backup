import { ErrorResponseDto } from '@components/error/dto/response/error.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { Expose } from 'class-transformer';
import { Types } from 'mongoose';

export class ErrorGroupResponseDto extends BaseResponseDto {
  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  description: string;

  @Expose()
  active: number;

  @Expose()
  errorCodes: string[];

  @Expose()
  errors: ErrorResponseDto[];
}
