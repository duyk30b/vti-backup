import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';
import { ErrorGroupResponseDto } from './error-group.response.dto';

export class ListErrorGroupResponseDto extends PaginationResponse {
  @ApiProperty({ type: ErrorGroupResponseDto, isArray: true })
  @Type(() => ErrorGroupResponseDto)
  @Expose()
  items: ErrorGroupResponseDto[];
}
