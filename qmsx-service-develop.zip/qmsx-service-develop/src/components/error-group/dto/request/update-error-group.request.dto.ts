import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateErrorGroupRequestDto } from './create-error-group.request.dto';

export class UpdateErrorGroupBodyDto extends CreateErrorGroupRequestDto {}

export class UpdateErrorGroupRequestDto extends UpdateErrorGroupBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
