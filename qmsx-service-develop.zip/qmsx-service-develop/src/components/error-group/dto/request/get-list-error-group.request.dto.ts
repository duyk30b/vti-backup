import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/dto/request/pagination.query';
import { IsOptional, IsString } from 'class-validator';

export class GetListErrorGroupRequestDto extends PaginationQuery {
  @ApiPropertyOptional({
    example: ['1', '2'],
  })
  @IsOptional()
  @IsString()
  queryIds?: string[];
}
