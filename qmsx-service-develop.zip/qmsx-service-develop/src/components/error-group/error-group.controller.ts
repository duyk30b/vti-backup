import { ACTIVE_ENUM } from '@constant/common';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateErrorGroupRequestDto } from './dto/request/create-error-group.request.dto';
import { GetDetailErrorGroupRequestDto } from './dto/request/get-detail-error-group.request.dto';
import { GetListErrorGroupRequestDto } from './dto/request/get-list-error-group.request.dto';
import { UpdateErrorGroupBodyDto } from './dto/request/update-error-group.request.dto';
import { ErrorGroupResponseDto } from './dto/response/error-group.response.dto';
import { ListErrorGroupResponseDto } from './dto/response/list-error-group.response.dto';
import { ErrorGroupServiceInterface } from './interface/error-group.service.interface';

@Controller('error-groups')
export class ErrorGroupController {
  constructor(
    @Inject('ErrorGroupServiceInterface')
    private readonly errorGroupService: ErrorGroupServiceInterface,
  ) {}

  @Post()
  @ApiOperation({
    tags: ['Error Group - Nhóm lỗi'],
    summary: 'Thêm nhóm lỗi',
  })
  @ApiResponse({
    status: 200,
    description: 'Add Successfully',
    type: ErrorGroupResponseDto,
  })
  async create(@Body() payload: CreateErrorGroupRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.errorGroupService.create(request);
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['Error Group - Nhóm lỗi'],
    summary: 'Chi tiết nhóm lỗi',
    description: 'Chi tiết nhóm lỗi',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ErrorGroupResponseDto,
  })
  async getDetail(@Param() param: GetDetailErrorGroupRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.errorGroupService.getDetail(request);
  }

  @Get()
  @ApiOperation({
    tags: ['Error Group - Nhóm lỗi'],
    summary: 'Danh sách nhóm lỗi',
    description: 'Danh sách nhóm lỗi',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListErrorGroupResponseDto,
  })
  async getList(@Query() query: GetListErrorGroupRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.errorGroupService.getList(request);
  }

  @Put('/:id')
  @ApiOperation({
    tags: ['Error Group - Nhóm lỗi'],
    summary: 'Sửa nhóm lỗi',
    description: 'Sửa nhóm lỗi',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async update(
    @Param() param: IdParamMongoDto,
    @Body() payload: UpdateErrorGroupBodyDto,
  ): Promise<any> {
    const { request: requestParam, responseError: responseParamError } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.errorGroupService.update({
      id: requestParam.id,
      ...request,
    });
  }

  @Delete('/:id')
  @ApiOperation({
    tags: ['Error Group - Nhóm lỗi'],
    summary: 'Xóa nhóm lỗi',
    description: 'Xóa nhóm nhóm lỗi',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async delete(@Param() param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.errorGroupService.delete(request);
  }

  @Put('/:id/active')
  @ApiOperation({
    tags: ['Error Group - Nhóm lỗi'],
    summary: 'Hoạt động nhóm lỗi',
    description: 'Hoạt động nhóm lỗi',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async active(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.errorGroupService.updateActiveStatus({
      ...request,
      status: ACTIVE_ENUM.ACTIVE,
    });
  }

  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Error Group - Nhóm lỗi'],
    summary: 'Tạm dừng nhóm lỗi',
    description: 'Tạm dừng nhóm lỗi',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async inactive(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.errorGroupService.updateActiveStatus({
      ...request,
      status: ACTIVE_ENUM.INACTIVE,
    });
  }
}
