import { CauseRepositoryInterface } from '@components/cause/interface/cause.repository.interface';
import { CauseServiceInterface } from '@components/cause/interface/cause.service.interface';
import { ErrorGroupServiceInterface } from '@components/error-group/interface/error-group.service.interface';
import { ErrorRepositoryInterface } from '@components/error/interface/error.repository.interface';
import { ErrorServiceInterface } from '@components/error/interface/error.service.interface';
import { CHECK_TYPE } from '@components/evaluation-criteria/evaluation-criteria.constant';
import { EvaluationCriteriaRepositoryInterface } from '@components/evaluation-criteria/interface/evaluation-criteria.repository.interface';
import { EvaluationCriteriaServiceInterface } from '@components/evaluation-criteria/interface/evaluation-criteria.service.interface';
import {
  IMPORTANT,
  QC_FORMAT,
} from '@components/evaluation-form/evaluation-form.constant';
import { EvaluationFormServiceInterface } from '@components/evaluation-form/interface/evaluation-form.service.interface';
import { EXCEL_STYLE, TypeEnum } from '@components/export/export.constant';
import { ExportService } from '@components/export/export.service';
import { ItemService } from '@components/item/item.service';
import { QCRequestServiceInterface } from '@components/qc-request/interface/qc-request.service.interface';
import { ACTIVE_ENUM, DATE_FORMAT_EXPORT } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { getDataDuplicate } from '@utils/common';
import { ResponseBuilder } from '@utils/response-builder';
import { Alignment, Workbook } from 'exceljs';
import { compact, isEmpty, isNull, keyBy, uniq, uniqBy } from 'lodash';
import * as moment from 'moment';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ImportExcelRequest } from './dto/import-excel.request';
import {
  ACTION_IMPORT_KEY,
  QC_PROPOSE_PROCESS,
  QC_REQUEST_SOURCE,
  TEMPLATE_CAUSE,
  TEMPLATE_ERROR,
  TEMPLATE_ERROR_GROUP,
  TEMPLATE_EVALUATION_CRITERIA,
  TEMPLATE_EVALUATION_CRITERIA_DETAIL,
  TEMPLATE_EVALUATION_FORM,
  TEMPLATE_QC_REQUEST,
  TEMPLATE_QC_REQUEST_ITEM,
  TEMPLATE_SUB_CAUSE,
  TEMPLATE_SUB_ERROR,
  TEMPLATE_SUB_EVALUATION_CRITERIA,
} from './import-excel.constant';
import { ImportExcelServiceInterface } from './interface/import-excel.service.interface';

@Injectable()
export class ImportExcelService implements ImportExcelServiceInterface {
  constructor(
    @Inject('ErrorServiceInterface')
    private readonly errorService: ErrorServiceInterface,

    @Inject('ErrorGroupServiceInterface')
    private readonly errorGroupService: ErrorGroupServiceInterface,

    @Inject('CauseServiceInterface')
    private readonly causeService: CauseServiceInterface,

    @Inject('EvaluationCriteriaServiceInterface')
    private readonly evaluationCriteriaService: EvaluationCriteriaServiceInterface,

    @Inject('CauseRepositoryInterface')
    private readonly causeRepository: CauseRepositoryInterface,

    @Inject('ErrorRepositoryInterface')
    private readonly errorRepository: ErrorRepositoryInterface,

    @Inject('EvaluationFormServiceInterface')
    private readonly evaluationFormService: EvaluationFormServiceInterface,

    @Inject('EvaluationCriteriaRepositoryInterface')
    private readonly evaluationCriteriaRepository: EvaluationCriteriaRepositoryInterface,

    @Inject('QCRequestServiceInterface')
    private readonly qcRequestService: QCRequestServiceInterface,

    @Inject('ExportServiceInterface')
    private readonly exportService: ExportService,

    @Inject('ItemService')
    private readonly itemService: ItemService,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async import(payload: ImportExcelRequest): Promise<any> {
    const { type, files, user } = payload;

    const workbook = new Workbook();
    await workbook.xlsx.load(Buffer.from(files[0].data));
    switch (type) {
      case TypeEnum.ERROR:
        return await this.importError(workbook, user.id);
      case TypeEnum.ERROR_GROUP:
        return await this.importErrorGroup(workbook, user.id);
      case TypeEnum.CAUSE:
        return await this.importCause(workbook, user.id);
      case TypeEnum.EVALUATION_FORM:
        return await this.importEvaluationForm(workbook, user.id);
      case TypeEnum.EVALUATION_CRITERIA:
        return await this.importEvaluationCriteria(workbook, user.id);
      case TypeEnum.QC_REQUEST:
        return await this.importQCRequest(workbook, user.id);
      default:
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
    }
  }

  private async importError(workbook: any, userId: number): Promise<any> {
    const textCommon = await this.i18n.translate('export.common');
    const headerFirstSheet = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.errorTemplate.code'),
      name: await this.i18n.translate('import.errorTemplate.name'),
      description: await this.i18n.translate(
        'import.errorTemplate.description',
      ),
      active: await this.i18n.translate('import.errorTemplate.active'),
    };

    const headerSecondSheet = {
      code_error: await this.i18n.translate('import.errorTemplate.code'),
      code_cause: await this.i18n.translate('import.cause.code'),
    };

    const [dataExcelError, resultExcelError] = await this.handleWorkbook(
      workbook,
      TEMPLATE_ERROR,
      headerFirstSheet,
      await this.i18n.translate('import.sheetName.errorTemplate.Sheet1'),
    );

    const [dataExcelCause, _] = await this.handleWorkbook(
      workbook,
      TEMPLATE_SUB_CAUSE,
      headerSecondSheet,
      await this.i18n.translate('import.sheetName.errorTemplate.Sheet2'),
    );

    const uniqDataExcelCause = uniqBy(
      dataExcelCause,
      (obj) => obj.code_error && obj.code_cause,
    );

    let causes = [];
    if (!isEmpty(uniqDataExcelCause)) {
      causes = await this.causeRepository.findAllByCondition({
        code: {
          $in: uniqDataExcelCause.map((item) => item.code_cause),
        },
        isActive: ACTIVE_ENUM.ACTIVE,
      });
    }

    const dataMapping = uniqDataExcelCause
      ?.map((item) => {
        const findCause = causes.find(
          (cause) => cause.code === item.code_cause,
        );
        if (findCause) {
          return {
            ...item,
            causeCode: findCause.code,
          };
        }
        return item;
      })
      .filter((item) => item.hasOwnProperty('causeCode'));

    if (dataExcelError[0]?.statusCode === ResponseCodeEnum.NOT_FOUND) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(dataExcelError[0]?.message)
        .build();
    }

    const dataCreatePassing = dataExcelError?.map((item) => {
      const causeCodes = dataMapping
        .filter((data) => data.code_error === item.code)
        .map((i) => i.causeId);
      return {
        ...item,
        active:
          item?.active === textCommon.active
            ? ACTIVE_ENUM.ACTIVE
            : ACTIVE_ENUM.INACTIVE,
        causeCodes: causeCodes,
      };
    });

    const { dataError, dataSuccess } = await this.errorService.import(
      dataCreatePassing,
      userId,
    );

    const file = await this.getDataReportErrorOne([
      ...resultExcelError,
      ...dataError,
    ]);

    return new ResponseBuilder({
      dataSuccess,
      dataError: [...resultExcelError, ...dataError],
      fileData: file,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async importErrorGroup(workbook: any, userId: number): Promise<any> {
    const textCommon = await this.i18n.translate('export.common');
    const headerFirstSheet = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.errorGroupTemplate.code'),
      name: await this.i18n.translate('import.errorGroupTemplate.name'),
      description: await this.i18n.translate(
        'import.errorGroupTemplate.description',
      ),
      active: await this.i18n.translate('import.errorGroupTemplate.active'),
    };

    const headerSecondSheet = {
      code_error_group: await this.i18n.translate(
        'import.errorGroupTemplate.code',
      ),
      code_error: await this.i18n.translate('import.errorTemplate.code'),
    };

    const [dataExcelErrorGroup, resultExcelErrorGroup] =
      await this.handleWorkbook(
        workbook,
        TEMPLATE_ERROR_GROUP,
        headerFirstSheet,
        await this.i18n.translate('import.sheetName.errorGroupTemplate.Sheet1'),
      );

    const [dataExcelError, _] = await this.handleWorkbook(
      workbook,
      TEMPLATE_SUB_ERROR,
      headerSecondSheet,
      await this.i18n.translate('import.sheetName.errorGroupTemplate.Sheet2'),
    );

    const uniqDataExcelError = uniqBy(
      dataExcelError,
      (obj) => obj.code_error_group && obj.code_error,
    );

    let errors = [];
    if (!isEmpty(uniqDataExcelError)) {
      errors = await this.errorRepository.findAllByCondition({
        code: {
          $in: uniqDataExcelError.map((item) => item.code_error),
        },
        active: ACTIVE_ENUM.ACTIVE,
      });
    }

    const dataMapping = uniqDataExcelError
      ?.map((item) => {
        const findError = errors.find(
          (error) => error.code === item.code_error,
        );
        if (findError) {
          return {
            ...item,
            errorCode: findError.code,
          };
        }
        return item;
      })
      .filter((item) => item.hasOwnProperty('errorCode'));

    if (dataExcelErrorGroup[0]?.statusCode === ResponseCodeEnum.NOT_FOUND) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(dataExcelErrorGroup[0]?.message)
        .build();
    }

    const dataCreatePassing = dataExcelErrorGroup?.map((item) => {
      const errorCodes = dataMapping
        .filter((data) => data.code_error_group === item.code)
        .map((i) => i.errorCode);
      return {
        ...item,
        active:
          item?.active === textCommon.active
            ? ACTIVE_ENUM.ACTIVE
            : ACTIVE_ENUM.INACTIVE,
        errorCodes: errorCodes,
      };
    });

    const { dataError, dataSuccess } = await this.errorGroupService.import(
      dataCreatePassing,
      userId,
    );

    const file = await this.getDataReportErrorOne([
      ...resultExcelErrorGroup,
      ...dataError,
    ]);

    return new ResponseBuilder({
      dataSuccess,
      dataError: [...resultExcelErrorGroup, ...dataError],
      fileData: file,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async importEvaluationCriteria(
    workbook: any,
    userId: number,
  ): Promise<any> {
    const textCommon = await this.i18n.translate('export.common');
    const evaluationCriteriaText = await this.i18n.translate(
      'import.evaluationCriteria',
    );
    const headerFirstSheet = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.evaluationCriteriaTemplate.code'),
      name: await this.i18n.translate('import.evaluationCriteriaTemplate.name'),
      checkType: await this.i18n.translate(
        'import.evaluationCriteriaTemplate.checkType',
      ),
      norm: await this.i18n.translate('import.evaluationCriteriaTemplate.norm'),
      upperBound: await this.i18n.translate(
        'import.evaluationCriteriaTemplate.upperBound',
      ),
      lowerBound: await this.i18n.translate(
        'import.evaluationCriteriaTemplate.lowerBound',
      ),
      description: await this.i18n.translate(
        'import.evaluationCriteriaTemplate.description',
      ),
      active: await this.i18n.translate(
        'import.evaluationCriteriaTemplate.active',
      ),
    };

    const headerSecondSheet = {
      evaluationCriteriaCode: await this.i18n.translate(
        'import.evaluationCriteriaTemplate.code',
      ),
      name: await this.i18n.translate(
        'import.evaluationCriteriaTemplate.detail.name',
      ),
      errorCodes: await this.i18n.translate(
        'import.evaluationCriteriaTemplate.detail.code',
      ),
      description: await this.i18n.translate(
        'import.evaluationCriteriaTemplate.detail.description',
      ),
    };

    const [dataExcelEvaluationCriteria, resultEvaluationCriteria] =
      await this.handleWorkbook(
        workbook,
        TEMPLATE_EVALUATION_CRITERIA,
        headerFirstSheet,
        await this.i18n.translate(
          'import.sheetName.evaluationCriteriaTemplate.Sheet1',
        ),
      );
    const [dataExcelEvaluationCriteriaDetail, _] = await this.handleWorkbook(
      workbook,
      TEMPLATE_EVALUATION_CRITERIA_DETAIL,
      headerSecondSheet,
      await this.i18n.translate(
        'import.sheetName.evaluationCriteriaTemplate.Sheet2',
      ),
    );

    if (
      dataExcelEvaluationCriteria[0]?.statusCode === ResponseCodeEnum.NOT_FOUND
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(dataExcelEvaluationCriteria[0]?.message)
        .build();
    }

    const dataCreatePassing = dataExcelEvaluationCriteria?.map((item) => {
      const evaluationCriteriaDetail = dataExcelEvaluationCriteriaDetail
        .filter((detail) => detail.evaluationCriteriaCode === item.code)
        .map((detail) => {
          return {
            name: detail.name,
            errorCodes: detail.errorCodes?.split(','),
            description: detail.description,
          };
        });
      return {
        ...item,
        checkType:
          item?.checkType === evaluationCriteriaText.measure
            ? CHECK_TYPE.MEASURE
            : CHECK_TYPE.STATUS,
        active:
          item?.active === textCommon.active
            ? ACTIVE_ENUM.ACTIVE
            : ACTIVE_ENUM.INACTIVE,
        details: evaluationCriteriaDetail,
        createdBy: userId,
      };
    });

    const { dataError, dataSuccess } =
      await this.evaluationCriteriaService.import(dataCreatePassing, userId);

    const file = await this.getDataReportErrorOne([
      ...resultEvaluationCriteria,
      ...dataError,
    ]);
    return new ResponseBuilder({
      dataSuccess,
      dataError: [...resultEvaluationCriteria, ...dataError],
      fileData: file,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async importQCRequest(workbook: any, userId: number): Promise<any> {
    const textCommon = await this.i18n.translate('export.common');
    const qcRequestText = await this.i18n.translate('import.qcRequestTemplate');
    const headerFirstSheet = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.qcRequestTemplate.code'),
      name: await this.i18n.translate('import.qcRequestTemplate.name'),
      requestSource: await this.i18n.translate(
        'import.qcRequestTemplate.requestSource',
      ),
      requestType: await this.i18n.translate(
        'import.qcRequestTemplate.requestType',
      ),
      ticketCode: await this.i18n.translate(
        'import.qcRequestTemplate.ticketCode',
      ),
      requestBy: await this.i18n.translate(
        'import.qcRequestTemplate.requestBy',
      ),
      returnDate: await this.i18n.translate(
        'import.qcRequestTemplate.returnDate',
      ),
      workOrderCode: await this.i18n.translate(
        'import.qcRequestTemplate.workOrderCode',
      ),
      proposeProcess: await this.i18n.translate(
        'import.qcRequestTemplate.proposeProcess',
      ),
      description: await this.i18n.translate(
        'import.qcRequestTemplate.description',
      ),
    };

    const headerSecondSheet = {
      qcRequestCode: await this.i18n.translate(
        'import.qcRequestTemplate.items.qcRequestCode',
      ),
      itemCode: await this.i18n.translate(
        'import.qcRequestTemplate.items.itemCode',
      ),
      checkType: await this.i18n.translate(
        'import.qcRequestTemplate.items.checkType',
      ),
      lot: await this.i18n.translate('import.qcRequestTemplate.items.lot'),
      planQuantity: await this.i18n.translate(
        'import.qcRequestTemplate.items.planQuantity',
      ),
      unitCode: await this.i18n.translate(
        'import.qcRequestTemplate.items.unitCode',
      ),
    };

    const [dataExcelQCRequest, resultQCRequest] = await this.handleWorkbook(
      workbook,
      TEMPLATE_QC_REQUEST,
      headerFirstSheet,
      await this.i18n.translate('import.sheetName.Sheet1'),
    );
    const [dataExcelQCRequestItems, _] = await this.handleWorkbook(
      workbook,
      TEMPLATE_QC_REQUEST_ITEM,
      headerSecondSheet,
      await this.i18n.translate('import.sheetName.Sheet2'),
    );

    if (dataExcelQCRequest[0]?.statusCode === ResponseCodeEnum.NOT_FOUND) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(dataExcelQCRequest[0]?.message)
        .build();
    }

    const dataCreatePassing = dataExcelQCRequest?.map((qcRequest) => {
      const items = dataExcelQCRequestItems
        .filter((itemQC) => itemQC.qcRequestCode === qcRequest.code)
        .map((item) => {
          return {
            itemType: item.itemType,
            itemCode: item.itemCode,
            itemName: item.itemName,
            checkType: item.checkType,
            lot: item.lot,
            planQuantity: item.planQuantity,
            unitCode: item.unitCode,
          };
        });
      return {
        ...qcRequest,
        requestSource:
          qcRequest?.requestSource === qcRequestText.mesx
            ? QC_REQUEST_SOURCE.MESX
            : qcRequest?.requestSource === qcRequestText.wmsx
            ? QC_REQUEST_SOURCE.WMSX
            : QC_REQUEST_SOURCE.QMSX,
        returnDate: moment(qcRequest?.returnDate, DATE_FORMAT_EXPORT),
        proposeProcess:
          qcRequest?.proposeProcess === qcRequestText.yes
            ? QC_PROPOSE_PROCESS.YES
            : QC_PROPOSE_PROCESS.NO,
        items: items,
        createdBy: userId,
      };
    });

    const { dataError, dataSuccess } = await this.qcRequestService.import(
      dataCreatePassing,
    );

    if (!isEmpty(dataError)) {
      return new ResponseBuilder({
        dataSuccess,
        dataError: [...resultQCRequest, ...dataError],
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    return new ResponseBuilder({
      dataSuccess,
      dataError: [...resultQCRequest, ...dataError],
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async importEvaluationForm(
    workbook: any,
    userId: number,
  ): Promise<any> {
    const textCommon = await this.i18n.translate('export.common');
    const evaluationText = await this.i18n.translate('import.evaluationForm');
    const headerFirstSheet = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.evaluationForm.code'),
      name: await this.i18n.translate('import.evaluationForm.name'),
      code_item: await this.i18n.translate('import.evaluationForm.code_item'),
      qcFormat: await this.i18n.translate('import.evaluationForm.qcFormat'),
      qcQuantity: await this.i18n.translate('import.evaluationForm.qcQuantity'),
      qcNumber: await this.i18n.translate('import.evaluationForm.qcNumber'),
      description: await this.i18n.translate(
        'import.evaluationForm.description',
      ),
      active: await this.i18n.translate('import.evaluationForm.active'),
    };

    const headerSecondSheet = {
      code_evaluation_form: await this.i18n.translate(
        'import.evaluationForm.code',
      ),
      code_evaluation_criteria: await this.i18n.translate(
        'import.evaluationForm.evaluationCriteria.code',
      ),
      important: await this.i18n.translate(
        'import.evaluationForm.evaluationCriteria.important',
      ),
    };

    const [dataExcelEvaluationForm, resultEvaluationForm] =
      await this.handleWorkbook(
        workbook,
        TEMPLATE_EVALUATION_FORM,
        headerFirstSheet,
        await this.i18n.translate('import.sheetName.errorTemplate.Sheet1'),
      );

    const [dataExcelEvaluationCriteria, _] = await this.handleWorkbook(
      workbook,
      TEMPLATE_SUB_EVALUATION_CRITERIA,
      headerSecondSheet,
      await this.i18n.translate('import.sheetName.errorTemplate.Sheet2'),
    );

    const uniqDataExcelEvaluationCriteria = uniqBy(
      dataExcelEvaluationCriteria,
      (obj) => obj.code_evaluation_form && obj.code_evaluation_criteria,
    );

    let evaluationCriterias = [];
    if (!isEmpty(uniqDataExcelEvaluationCriteria)) {
      evaluationCriterias =
        await this.evaluationCriteriaRepository.findAllByCondition({
          code: {
            $in: uniqDataExcelEvaluationCriteria.map(
              (item) => item.code_evaluation_criteria,
            ),
          },
        });
    }

    if (dataExcelEvaluationForm[0]?.statusCode === ResponseCodeEnum.NOT_FOUND) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(dataExcelEvaluationForm[0]?.message)
        .build();
    }

    let itemTypeList = (await this.itemService.getItemTypeList({})).items;
    itemTypeList = keyBy(itemTypeList, 'code');

    const dataCreatePassing = dataExcelEvaluationForm?.map((item) => {
      const dataMapping = dataExcelEvaluationCriteria.filter(
        (data) => data.code_evaluation_form === item.code,
      );
      const evaluations = evaluationCriterias
        .map((evaluationCriteria) => {
          const dataFinded = dataMapping.find(
            (item) => item.code_evaluation_criteria === evaluationCriteria.code,
          );

          if (dataFinded) {
            return {
              ...evaluationCriteria,
              important:
                dataFinded?.important === textCommon.yes
                  ? IMPORTANT.YES
                  : IMPORTANT.NO,
            };
          }
          return evaluationCriteria;
        })
        .filter(
          (item) =>
            item.hasOwnProperty('important') &&
            (item.important === textCommon.yes ||
              item.important === textCommon.no),
        );
      return {
        ...item,
        itemId: itemTypeList[item?.code_item].id,
        active:
          item?.active === textCommon.active
            ? ACTIVE_ENUM.ACTIVE
            : ACTIVE_ENUM.INACTIVE,
        createdBy: userId,
        qcFormat:
          item?.qcFormat.toLocaleLowerCase() ===
          evaluationText.qcAll.toLocaleLowerCase()
            ? QC_FORMAT.ALL
            : QC_FORMAT.RANDOM,
        evaluations: evaluations,
      };
    });

    const { dataError, dataSuccess } = await this.evaluationFormService.import(
      dataCreatePassing,
      userId,
    );

    const file = await this.getDataReportErrorOne([
      ...resultEvaluationForm,
      ...dataError,
    ]);

    return new ResponseBuilder({
      dataSuccess,
      dataError: [...resultEvaluationForm, ...dataError],
      fileData: file,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async importCause(workbook: any, userId: number): Promise<any> {
    const textCommon = await this.i18n.translate('export.common');
    const header = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.cause.code'),
      name: await this.i18n.translate('import.cause.name'),
      description: await this.i18n.translate('import.cause.description'),
      isActive: await this.i18n.translate('import.cause.status'),
    };

    const [data, resultError] = await this.handleWorkbook(
      workbook,
      TEMPLATE_CAUSE,
      header,
      await this.i18n.translate('import.sheetName.cause.Sheet1'),
    );

    if (data[0]?.statusCode === ResponseCodeEnum.NOT_FOUND) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(data[0]?.message)
        .build();
    }

    const dataImport = data.map((item) => {
      return {
        ...item,
        isActive:
          item.isActive.toLocaleLowerCase() ===
          textCommon.active.toLocaleLowerCase()
            ? 1
            : 0,
      };
    });

    const { dataError, dataSuccess } = await this.causeService.import(
      dataImport,
      userId,
    );
    const file = await this.getDataReportErrorOne([
      ...dataError,
      ...resultError,
    ]);

    return new ResponseBuilder({
      dataSuccess,
      dataError: [...resultError, ...dataError],
      fileData: file,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private async handleWorkbook(
    workbook: any,
    template: any,
    header: any,
    sheetName: any,
  ) {
    const sizeHeader = Object.keys(header).length;
    const templateMap = new Map(
      Object.keys(template).map((key) => [key, template[key]]),
    );
    const templateKeyMap = new Map(
      Object.keys(template).map((key, index) => [index, key]),
    );
    const worksheet = workbook.getWorksheet(sheetName);
    return await this.getDataWorksheet(
      worksheet,
      templateMap,
      templateKeyMap,
      sizeHeader,
      header,
    );
  }

  private async getDataWorksheet(
    worksheet,
    templateMap,
    templateKeyMap,
    sizeHeader,
    header,
  ) {
    const data: any[] = [];
    let dataError = [];
    let isData = false;
    for (let i = 1; i <= worksheet?.rowCount; i++) {
      const row = worksheet.getRow(i);
      if (isData) {
        const obj: any = {};
        let error = false;
        obj['line'] = i;
        if (!row.cellCount) {
          break;
        }
        for (let j = 0; j < row.cellCount; j++) {
          const cell = row.getCell(j + 1);
          const cellValue =
            templateMap.get(templateKeyMap.get(j))?.type === 'string'
              ? cell.value?.toString()?.trim()
              : cell.value;
          obj[templateKeyMap.get(j)] = cellValue;

          error = await this.validateDataCell(
            header,
            templateMap.get(templateKeyMap.get(j)),
            cellValue,
          );
          if (error) {
            if (templateKeyMap.get(j) === ACTION_IMPORT_KEY.action.key) {
              return await this.validateDataUniqueCode(
                data,
                dataError,
                templateMap.get('code'),
              );
            }
            break;
          }
        }
        if (error) {
          dataError = dataError.concat({
            ...obj,
            action: obj.action?.toLocaleLowerCase(),
          });
          error = false;
        } else {
          data.push({ ...obj, action: obj.action?.toLocaleLowerCase() });
        }
      }
      if (row.cellCount === sizeHeader && !isData) {
        isData = true;
        for (let j = 0; j < row.cellCount; j++) {
          const cell = row.getCell(j + 1);

          if (header[templateKeyMap.get(j)] !== cell.value) {
            return [
              [
                {
                  statusCode: ResponseCodeEnum.NOT_FOUND,
                  message: await this.i18n.translate(
                    'error.HEADER_TEMPLATE_ERROR',
                    {
                      args: {
                        currentCell: cell.value ?? '',
                        headerCell: header[templateKeyMap.get(j)],
                      },
                    },
                  ),
                },
              ],
              [],
            ];
          }
        }
      }
      if (row.cellCount !== sizeHeader && !isData && row.cellCount !== 0) {
        return [
          [
            {
              statusCode: ResponseCodeEnum.NOT_FOUND,
              message: await this.i18n.translate(
                'error.HEADER_LENGTH_TEMPLATE_ERROR',
              ),
            },
          ],
        ];
      }
    }
    if (isEmpty(data) && isEmpty(dataError)) {
      return [
        [
          {
            statusCode: ResponseCodeEnum.NOT_FOUND,
            message: await this.i18n.translate('error.NOT_FOUND'),
          },
        ],
      ];
    }
    return await this.validateDataUniqueCode(
      data,
      dataError,
      templateMap.get('code'),
    );
  }

  private async validateDataCell(header, template, value) {
    let error: any = '';
    // check not null
    if (template?.notNull) {
      if (
        (template?.type === 'string' && !value?.length) ||
        (isEmpty(value) && isNull(value))
      ) {
        error = true;
      }
    }

    // check string max length
    if (template?.maxLength && template.type === 'string') {
      error =
        value?.toString()?.trim()?.length > template.maxLength ? true : error;
    }
    return error;
  }

  private async validateDataUniqueCode(
    data: any[],
    dataError: any[],
    templateCode: any,
  ) {
    const listCode = compact(
      data.map((i) => {
        return i?.code;
      }),
    );
    if (isEmpty(listCode) || templateCode?.unique === false)
      return [data, dataError];
    let dataDuplicate = getDataDuplicate(listCode);
    dataDuplicate = uniq(dataDuplicate);
    if (dataDuplicate.length > 0) {
      const newData: any[] = [];
      let newDataError = [...dataError];
      for (let i = 0; i < data.length; i++) {
        const item = data[i];
        if (dataDuplicate.includes(item.code)) {
          newDataError = newDataError.concat({
            ...item,
            action: item.action?.toLocaleLowerCase(),
          });
        } else {
          newData.push(item);
        }
      }
      return [newData, newDataError];
    }

    return [data, dataError];
  }

  private async getDataReportErrorOne(dataError: any) {
    const textCommon = await this.i18n.translate('export.common');
    const headerSheetResult = [
      {
        key: 'line',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: textCommon.lineError,
      },
      {
        key: 'errorDesc',
        width: 60,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: textCommon.errorDescription,
      },
    ];

    const reportErrorData = dataError.map((error) => {
      return {
        line: error.line,
        errorDesc: error?.errorDesc || textCommon.invalidField,
      };
    });

    const workbookErrorReport = await this.exportService.exportOneSheetUtil(
      reportErrorData,
      [await this.i18n.translate('export.causeReport.resultImport')],
      headerSheetResult,
    );

    await workbookErrorReport.xlsx.writeFile('excelReport.xlsx');
    const file = await workbookErrorReport.xlsx.writeBuffer();
    return file;
  }

  private async getDataReportErrorMulti(
    dataError: any,
    dataSubError: any,
    titleMap: any,
    sheetName: any,
  ) {
    const textCommon = await this.i18n.translate('export.common');
    const headersMap: any = new Map();
    const headerSheet = [
      {
        key: 'line',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: textCommon.lineError,
      },
      {
        key: 'errorDesc',
        width: 60,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: textCommon.errorDescription,
      },
    ];

    const reportErrorData = dataError.map((error) => {
      return {
        line: error.line,
        errorDesc: error?.errorDesc || textCommon.invalidField,
        level: 1,
        subItem: dataSubError.map((errorSub) => {
          return {
            line: errorSub.line,
            errorDesc: errorSub?.errorDesc || textCommon.invalidField,
            level: 2,
          };
        }),
      };
    });

    headersMap.set(1, headerSheet);
    headersMap.set(2, headerSheet);

    let workbook = new Workbook();
    workbook = await this.exportService.exportMultiSheetUtil(
      workbook,
      reportErrorData,
      1,
      titleMap,
      headersMap,
      sheetName,
    );
    await workbook.xlsx.writeFile('excelReport.xlsx');
    const file = await workbook.xlsx.writeBuffer();
    return file;
  }
}
