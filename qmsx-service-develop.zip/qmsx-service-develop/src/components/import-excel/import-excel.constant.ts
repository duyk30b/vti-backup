import { CAUSE_CONST } from '@components/cause/cause.constant';
import { ERROR_GROUP_CONST } from '@components/error-group/error-group.constant';
import { ERROR_CONST } from '@components/error/error.constant';
import { EVALUATION_CRITERIA_CONST } from '@components/evaluation-criteria/evaluation-criteria.constant';
import { EVALUATION_FORM_CONST } from '@components/evaluation-form/evaluation-form.constant';
import { QC_REQUEST_CONST } from '@components/qc-request/qc-request.constant';

export enum QC_PROPOSE_PROCESS {
  NO,
  YES,
}

export enum QC_REQUEST_SOURCE {
  MESX,
  WMSX,
  QMSX,
}

export const ACTION_IMPORT_KEY = {
  action: {
    key: 'action',
    notNull: true,
  },
};

export const TEMPLATE_ERROR = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    maxLength: ERROR_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: ERROR_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: ERROR_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
  active: {
    key: 'active',
    type: 'number',
    notNull: true,
  },
};

export const TEMPLATE_ERROR_GROUP = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    maxLength: ERROR_GROUP_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: ERROR_GROUP_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: ERROR_GROUP_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
  active: {
    key: 'active',
    type: 'number',
    notNull: true,
  },
};

export const TEMPLATE_CAUSE = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    maxLength: CAUSE_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: CAUSE_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: CAUSE_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
  isActive: {
    key: 'isActive',
    type: 'number',
    notNull: true,
  },
};

export const TEMPLATE_SUB_CAUSE = {
  code_error: {
    key: 'code_error',
    type: 'string',
    maxLength: ERROR_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  code_cause: {
    key: 'code_cause',
    type: 'string',
    maxLength: CAUSE_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
};

export const TEMPLATE_SUB_ERROR = {
  code_error_group: {
    key: 'code_error_group',
    type: 'string',
    maxLength: ERROR_GROUP_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  code_error: {
    key: 'code_error',
    type: 'string',
    maxLength: ERROR_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
};

export const TEMPLATE_EVALUATION_FORM = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    maxLength: EVALUATION_FORM_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: EVALUATION_FORM_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  code_item: {
    key: 'code_item',
    type: 'string',
    notNull: true,
  },
  qcFormat: {
    key: 'qcFormat',
    type: 'string',
    notNull: true,
  },
  qcQuantity: {
    key: 'qcQuantity',
    type: 'number',
    notNull: true,
  },
  qcNumber: {
    key: 'qcNumber',
    type: 'number',
    maxLength: EVALUATION_FORM_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: EVALUATION_FORM_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
  active: {
    key: 'active',
    type: 'number',
    notNull: true,
  },
};

export const TEMPLATE_SUB_EVALUATION_CRITERIA = {
  code_evaluation_form: {
    key: 'code_evaluation_form',
    type: 'string',
    maxLength: ERROR_GROUP_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  code_evaluation_criteria: {
    key: 'code_evaluation_criteria',
    type: 'string',
    maxLength: ERROR_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  important: {
    key: 'important',
    type: 'string',
    notNull: true,
  },
};

export const TEMPLATE_EVALUATION_CRITERIA = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    maxLength: EVALUATION_CRITERIA_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: EVALUATION_CRITERIA_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  checkType: {
    key: 'checkType',
    type: 'string',
    notNull: true,
  },
  norm: {
    key: 'norm',
    type: 'number',
    notNull: true,
  },
  upperBound: {
    key: 'upperBound',
    type: 'number',
    notNull: true,
  },
  lowerBound: {
    key: 'lowerBound',
    type: 'number',
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: EVALUATION_CRITERIA_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
  active: {
    key: 'active',
    type: 'number',
    notNull: true,
  },
};

export const TEMPLATE_EVALUATION_CRITERIA_DETAIL = {
  evaluationCriteriaCode: {
    key: 'evaluationCriteriaCode',
    type: 'string',
    maxLength: EVALUATION_CRITERIA_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: EVALUATION_CRITERIA_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  errorCodes: {
    key: 'errorCodes',
    type: 'string',
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    maxLength: EVALUATION_CRITERIA_CONST.DESCRIPTION.MAX_LENGTH,
    notNull: false,
  },
};

export const TEMPLATE_QC_REQUEST = {
  action: {
    key: 'action',
    notNull: true,
  },
  code: {
    key: 'code',
    type: 'string',
    maxLength: QC_REQUEST_CONST.CODE.MAX_LENGTH,
    notNull: true,
  },
  name: {
    key: 'name',
    type: 'string',
    maxLength: QC_REQUEST_CONST.NAME.MAX_LENGTH,
    notNull: true,
  },
  requestSource: {
    key: 'requestSource',
    type: 'string',
    notNull: true,
  },
  requestType: {
    key: 'requestType',
    type: 'string',
    notNull: true,
  },
  ticketCode: {
    key: 'ticketCode',
    type: 'string',
    notNull: true,
  },
  requestBy: {
    key: 'requestBy',
    type: 'string',
    notNull: true,
  },
  returnDate: {
    key: 'returnDate',
    type: 'string',
    notNull: true,
  },
  workOrderCode: {
    key: 'workOrderCode',
    type: 'string',
    notNull: true,
  },
  proposeProcess: {
    key: 'proposeProcess',
    type: 'string',
    notNull: true,
  },
  description: {
    key: 'description',
    type: 'string',
    notNull: true,
  },
};

export const TEMPLATE_QC_REQUEST_ITEM = {
  qcRequestCode: {
    key: 'qcRequestCode',
    type: 'string',
    notNull: true,
  },
  itemCode: {
    key: 'itemCode',
    type: 'string',
    notNull: true,
  },
  checkType: {
    key: 'checkType',
    type: 'string',
    notNull: true,
  },
  lot: {
    key: 'lot',
    type: 'string',
    notNull: true,
  },
  planQuantity: {
    key: 'planQuantity',
    type: 'string',
    notNull: true,
  },
  unitCode: {
    key: 'unitCode',
    type: 'string',
    notNull: true,
  },
};
