import { CauseService } from '@components/cause/cause.service';
import { ErrorGroupService } from '@components/error-group/error-group.service';
import { ErrorService } from '@components/error/error.service';
import { UserService } from '@components/user/user.service';
import { ConfigService } from '@config/config.service';
import { Global, Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { CauseCollection, CauseSchema } from 'src/models/cause/cause.schema';
import {
  ErrorGroup,
  ErrorGroupSchema,
} from 'src/models/error-group/error-group.schema';
import { Error, ErrorSchema } from 'src/models/error/error.schema';
import { CauseRepository } from 'src/repository/cause/cause.repository';
import { ErrorGroupRepository } from 'src/repository/error-group/error-group.repository';
import { ErrorRepository } from 'src/repository/error/error.repository';
import { ImportExcelController } from './import-excel.controller';
import { ImportExcelService } from './import-excel.service';
import { EvaluationCriteriaRepository } from 'src/repository/evaluation-criteria/evaluation-criteria.repository';
import { EvaluationFormService } from '@components/evaluation-form/evaluation-form.service';
import {
  EvaluationCriteria,
  EvaluationCriteriaSchema,
} from 'src/models/evaluation-criteria/evaluation-criteria.schema';

import { ItemService } from '@components/item/item.service';
import { QCRequestService } from '@components/qc-request/qc-request.service';

@Global()
@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: ErrorGroup.name,
        schema: ErrorGroupSchema,
      },
      {
        name: Error.name,
        schema: ErrorSchema,
      },
      {
        name: CauseCollection.name,
        schema: CauseSchema,
      },
      {
        name: EvaluationCriteria.name,
        schema: EvaluationCriteriaSchema,
      },
    ]),
  ],
  exports: [
    {
      provide: 'ImportExcelServiceInterface',
      useClass: ImportExcelService,
    },
    {
      provide: 'ErrorGroupServiceInterface',
      useClass: ErrorGroupService,
    },
    {
      provide: 'ErrorGroupRepositoryInterface',
      useClass: ErrorGroupRepository,
    },
    {
      provide: 'ErrorServiceInterface',
      useClass: ErrorService,
    },
    {
      provide: 'ErrorRepositoryInterface',
      useClass: ErrorRepository,
    },
    {
      provide: 'CauseServiceInterface',
      useClass: CauseService,
    },
    {
      provide: 'CauseRepositoryInterface',
      useClass: CauseRepository,
    },
    {
      provide: 'EvaluationFormServiceInterface',
      useClass: EvaluationFormService,
    },
    {
      provide: 'EvaluationCriteriaRepositoryInterface',
      useClass: EvaluationCriteriaRepository,
    },
    {
      provide: 'QCRequestServiceInterface',
      useClass: QCRequestService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'ImportExcelServiceInterface',
      useClass: ImportExcelService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'ErrorGroupServiceInterface',
      useClass: ErrorGroupService,
    },
    {
      provide: 'ErrorGroupRepositoryInterface',
      useClass: ErrorGroupRepository,
    },
    {
      provide: 'ErrorServiceInterface',
      useClass: ErrorService,
    },
    {
      provide: 'ErrorRepositoryInterface',
      useClass: ErrorRepository,
    },
    {
      provide: 'CauseServiceInterface',
      useClass: CauseService,
    },
    {
      provide: 'CauseRepositoryInterface',
      useClass: CauseRepository,
    },
    {
      provide: 'EvaluationFormServiceInterface',
      useClass: EvaluationFormService,
    },
    {
      provide: 'EvaluationCriteriaRepositoryInterface',
      useClass: EvaluationCriteriaRepository,
    },
    {
      provide: 'ItemService',
      useClass: ItemService,
    },
    {
      provide: 'QCRequestServiceInterface',
      useClass: QCRequestService,
    },
  ],
  controllers: [ImportExcelController],
})
export class ImportExcelModule {}
