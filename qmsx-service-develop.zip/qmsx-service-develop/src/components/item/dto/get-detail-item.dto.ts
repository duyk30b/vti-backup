export class GetDetailItemDto {}
