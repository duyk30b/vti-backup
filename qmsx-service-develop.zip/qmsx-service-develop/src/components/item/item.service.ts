import { NATS_ITEM } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';

@Injectable()
export class ItemService {
  constructor(private readonly natsClientService: NatsClientService) {}

  async getItemTypeDetail(filter: { id: number }): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_ITEM}.get_item_type_setting_detail_internal`,
        filter,
      );
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) return {};
      return response?.data;
    } catch (err) {
      return {};
    }
  }

  async getItemTypeList(filter: {}): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_ITEM}.item_type_setting_list`,
        filter,
      );
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
      return response?.data;
    } catch (err) {
      return [];
    }
  }

  async getItemList(request: any): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_ITEM}.get_item_list`,
        request,
      );
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
      return response?.data?.items;
    } catch (err) {
      return [];
    }
  }
}
