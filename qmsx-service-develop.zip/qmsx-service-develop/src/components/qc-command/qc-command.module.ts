import { ItemService } from '@components/item/item.service';
import { QcExecuteService } from '@components/qc-execute/qc-execute.service';
import { TicketReportErrorService } from '@components/ticket-report-error/ticket-report-error.service';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ErrorSchema } from 'src/models/error/error.schema';
import { Propose, ProposeSchema } from 'src/models/propose/propose.schema';
import {
  QCCommand,
  QCCommandSchema,
} from 'src/models/qc-command/qc-command.schema';
import {
  QCExecuteProgress,
  QCExecuteProgressSchema,
} from 'src/models/qc-execute/qc-execute-progress.schema';
import {
  QCExecuteResult,
  QCExecuteResultSchema,
} from 'src/models/qc-execute/qc-execute-result.schema';
import {
  QCExecute,
  QCExecuteSchema,
} from 'src/models/qc-execute/qc-execute.schema';
import {
  TicketReportError,
  TicketReportErrorSchema,
} from 'src/models/ticket-report-error/ticket-report-error.schema';
import { ErrorRepository } from 'src/repository/error/error.repository';
import { ProposeRepository } from 'src/repository/propose/propose.repository';
import { QCCommandRepository } from 'src/repository/qc-command/qc-command.repository';
import { QCExecuteProgressRepository } from 'src/repository/qc-execute/qc-execute-progress.repository';
import { QCExecuteResultRepository } from 'src/repository/qc-execute/qc-execute-result.repository';
import { QCExecuteRepository } from 'src/repository/qc-execute/qc-execute.repository';
import { TicketReportErrorRepository } from 'src/repository/ticket-report-error/ticket-report-error.repository';
import { QCCommandController } from './qc-command.controller';
import { QCCommandService } from './qc-command.service';
import { SettingModule } from '@components/setting/setting.module';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: QCCommand.name,
        schema: QCCommandSchema,
      },
      {
        name: QCExecute.name,
        schema: QCExecuteSchema,
      },
      {
        name: QCExecuteProgress.name,
        schema: QCExecuteProgressSchema,
      },
      {
        name: QCExecuteResult.name,
        schema: QCExecuteResultSchema,
      },
      {
        name: Error.name,
        schema: ErrorSchema,
      },
      {
        name: TicketReportError.name,
        schema: TicketReportErrorSchema,
      },
      {
        name: Propose.name,
        schema: ProposeSchema,
      },
    ]),
    SettingModule,
  ],
  controllers: [QCCommandController],
  providers: [
    {
      provide: 'QCCommandServiceInterface',
      useClass: QCCommandService,
    },
    {
      provide: 'QCCommandRepositoryInterface',
      useClass: QCCommandRepository,
    },
    {
      provide: 'QCExecuteRepositoryInterface',
      useClass: QCExecuteRepository,
    },
    {
      provide: 'ErrorRepositoryInterface',
      useClass: ErrorRepository,
    },
    {
      provide: 'ItemService',
      useClass: ItemService,
    },
    {
      provide: 'QCExecuteProgressRepositoryInterface',
      useClass: QCExecuteProgressRepository,
    },
    {
      provide: 'QCExecuteResultRepositoryInterface',
      useClass: QCExecuteResultRepository,
    },
    {
      provide: 'QCExecuteServiceInterface',
      useClass: QcExecuteService,
    },
    {
      provide: 'TicketReportErrorRepositoryInterface',
      useClass: TicketReportErrorRepository,
    },
    {
      provide: 'TicketReportErrorServiceInterface',
      useClass: TicketReportErrorService,
    },
    {
      provide: 'ProposeRepositoryInterface',
      useClass: ProposeRepository,
    },
  ],
  exports: [
    {
      provide: 'QCCommandServiceInterface',
      useClass: QCCommandService,
    },
    {
      provide: 'QCCommandRepositoryInterface',
      useClass: QCCommandRepository,
    },
    {
      provide: 'QCExecuteRepositoryInterface',
      useClass: QCExecuteRepository,
    },
  ],
})
export class QcCommandModule {}
