import { GetQCCommandReportBySourceRequestDto } from '@components/qc-report/dto/request/get-qc-command-report-by-source.request.dto';
import { GetQCCommandReportRequestDto } from '@components/qc-report/dto/request/get-qc-command-report.request.dto';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { QCCommand } from 'src/models/qc-command/qc-command.schema';
import { GetQCCommandProgressReportRequestDto } from '../../qc-report/dto/request/get-qc-command-progress-report.request.dto';
import { CreateQCCommandRequestDto } from '../dto/request/create-qc-command.request.dto';
import { GetListQCCommandRequestDto } from '../dto/request/get-list-qc-command.request.dto';
import { UpdateQCCommandBodyDto } from '../dto/request/update-qc-command.request.dto';

export interface QCCommandRepositoryInterface
  extends BaseInterfaceRepository<QCCommand> {
  createModel(request: CreateQCCommandRequestDto): QCCommand;
  updateModel(error: QCCommand, request: UpdateQCCommandBodyDto): QCCommand;
  getList(request: GetListQCCommandRequestDto): Promise<any>;
  getQCCommandProgressReport(
    request: GetQCCommandProgressReportRequestDto,
  ): Promise<any>;
  getQCCommandReportBySource(
    request: GetQCCommandReportBySourceRequestDto,
  ): Promise<any>;
  getQCCommandReport(request: GetQCCommandReportRequestDto): Promise<any>;
  getLastQCCommand(prefixWithYear: string): Promise<any>;
  getTotalPlanExecuteQuantityItems(qcRequestCode: string): Promise<any>;
}
