import { GetListErrorRequestDto } from '@components/error/dto/request/get-list-error.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { CreateQCCommandRequestDto } from '../dto/request/create-qc-command.request.dto';
import { GetDetailQCCommandRequestDto } from '../dto/request/get-detail-qc-command.request.dto';
import { UpdateQCCommandRequestDto } from '../dto/request/update-qc-command.request.dto';
import { UpdateStatusQCCommandRequestDto } from '../dto/request/update-status-qc-command.request.dto';

export interface QCCommandServiceInterface {
  create(request: CreateQCCommandRequestDto): Promise<any>;
  update(request: UpdateQCCommandRequestDto): Promise<any>;
  getDetail(request: GetDetailQCCommandRequestDto): Promise<any>;
  getList(request: GetListErrorRequestDto): Promise<any>;
  delete(request: IdParamMongoDto): Promise<any>;
  updateStatus(request: UpdateStatusQCCommandRequestDto): Promise<any>;
  import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }>;
}
