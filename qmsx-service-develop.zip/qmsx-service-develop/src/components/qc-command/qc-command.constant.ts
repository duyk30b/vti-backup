export enum REVIEW_TYPE {
  EVALUATION_FORM,
  EVALUATION_CRITERIA,
}

export enum CHECK_TYPE {
  MEASURE,
  STATUS,
}

export enum QC_COMMAND_STATUS {
  DRAFT,
  WAITING,
  CONFIRMED,
  REJECTED,
  IN_PROGRESS,
  COMPLETED,
}

export const QC_COMMAND_CONST = {
  CODE: {
    MIN_LENGTH: 6,
    MAX_LENGTH: 100,
    COLUMN: 'code',
  },
  NAME: {
    MIN_LENGTH: 1,
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  DESCRIPTION: {
    MIN_LENGTH: 1,
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
  TODO_QUANTITY: {
    MIN: 1,
    MAX: 999999999,
    COLUMN: 'todoQuantity',
  },
};

export const REGEX_PADDING_ZERO = /^0+/;
export const EMPTY_STRING = '';
export const PREFIX_QC_COMMAND_CODE = 'LQC';
export const FORMAT_SHORT_YEAR = 'YY';
export const INDEX_QC_COMMAND_CODE_START = 1;
export const STEP_INDEX_QC_COMMAND_CODE = 1;
export const MAX_LENGTH_INDEX = 6;
export const PADDING_SYMBOL = '0';
