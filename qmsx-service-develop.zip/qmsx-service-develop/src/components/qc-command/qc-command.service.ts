import { ItemService } from '@components/item/item.service';
import { QCExecuteServiceInterface } from '@components/qc-execute/interface/qc-execute.service.interface';
import { QCRequestRepositoryInterface } from '@components/qc-request/interface/qc-request.repository.interface';
import { QC_REQUEST_STATUS } from '@components/qc-request/qc-request.constant';
import { TicketReportErrorServiceInterface } from '@components/ticket-report-error/interface/ticket-report-error.service.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import {
  compact,
  filter,
  flatten,
  isEmpty,
  isNumber,
  keyBy,
  map,
  uniq,
} from 'lodash';
import * as moment from 'moment';
import { I18nRequestScopeService } from 'nestjs-i18n';
import {
  getDataInsert,
  getDataToUpdateError,
  getDataUpdate,
} from 'src/helper/import.helper';
import { CreateQCCommandRequestDto } from './dto/request/create-qc-command.request.dto';
import { GetDetailQCCommandRequestDto } from './dto/request/get-detail-qc-command.request.dto';
import { GetListQCCommandRequestDto } from './dto/request/get-list-qc-command.request.dto';
import { UpdateQCCommandRequestDto } from './dto/request/update-qc-command.request.dto';
import { UpdateStatusQCCommandRequestDto } from './dto/request/update-status-qc-command.request.dto';
import { QCCommandResponseDto } from './dto/response/qc-command.response.dto';
import { QCCommandRepositoryInterface } from './interface/qc-command.repository.interface';
import { QCCommandServiceInterface } from './interface/qc-command.service.interface';
import {
  EMPTY_STRING,
  FORMAT_SHORT_YEAR,
  INDEX_QC_COMMAND_CODE_START,
  MAX_LENGTH_INDEX,
  PADDING_SYMBOL,
  PREFIX_QC_COMMAND_CODE,
  QC_COMMAND_STATUS,
  REGEX_PADDING_ZERO,
  STEP_INDEX_QC_COMMAND_CODE,
} from './qc-command.constant';

@Injectable()
export class QCCommandService implements QCCommandServiceInterface {
  constructor(
    @Inject('QCRequestRepositoryInterface')
    private readonly qcRequestRepository: QCRequestRepositoryInterface,

    @Inject('QCCommandRepositoryInterface')
    private readonly qcCommandRepository: QCCommandRepositoryInterface,

    @Inject('TicketReportErrorServiceInterface')
    private readonly ticketReportErrorService: TicketReportErrorServiceInterface,

    @Inject('QCExecuteServiceInterface')
    private readonly qcExecuteService: QCExecuteServiceInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ItemService')
    private readonly itemService: ItemService,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateQCCommandRequestDto): Promise<any> {
    try {
      const { code } = request;
      const qcCommand = await this.qcCommandRepository.findOneByCode(code);
      if (!isEmpty(qcCommand)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.QC_COMMAND_CODE_EXIST'))
          .build();
      }

      const document = this.qcCommandRepository.createModel(request);
      document.code = await this.generateQCCommandCode();
      const dataSave = await document.save();
      const dataReturn = plainToInstance(QCCommandResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getDetail(request: GetDetailQCCommandRequestDto): Promise<any> {
    try {
      const { id } = request;
      const qcCommand = await this.qcCommandRepository.findOneById(id);
      if (isEmpty(qcCommand)) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      const itemCodes = uniq(compact(map(qcCommand?.items, 'itemCode')));
      if (!isEmpty(itemCodes)) {
        const request = {
          codes: itemCodes.join(','),
        };
        let itemList = await this.itemService.getItemList(request);
        itemList = keyBy(itemList, 'code');

        qcCommand?.items.forEach((it) => {
          it.item = itemList[it.itemCode];
        });
      }

      const qcRequest = await this.qcRequestRepository.findOneByCode(
        qcCommand.qcRequestCode,
      );

      qcCommand.qcRequest = qcRequest;

      const qcBy = uniq(compact(flatten(map(qcCommand?.items, 'qcBy'))));

      // Filter by user id
      const userIdFilters = [
        {
          column: 'userIds',
          text: qcBy.join(','),
        },
      ];

      if (!isEmpty(qcBy)) {
        const users = await this.userService.getList(userIdFilters);
        qcCommand?.items?.forEach((item) => {
          item.qcBy = filter(users, (user) => {
            return qcBy.indexOf(user.id) > -1;
          });
        });
      }

      const createdBy = await this.userService.getDetail(qcCommand.createdBy);

      if (!isEmpty(createdBy)) {
        qcCommand.createdBy = createdBy;
      }

      const dataReturn = plainToInstance(QCCommandResponseDto, qcCommand, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getList(request: GetListQCCommandRequestDto): Promise<any> {
    const { data, count } = await this.qcCommandRepository.getList(request);
    const userIds = uniq(compact(map(data, 'createdBy')));

    // Filter by user id
    const userIdFilters = [
      {
        column: 'userIds',
        text: userIds.join(','),
      },
    ];

    if (!isEmpty(userIds)) {
      let users = await this.userService.getList(userIdFilters);
      users = keyBy(users, 'id');
      data.forEach((item) => {
        item.createdBy = {
          id: users[item.createdBy]?.id,
          username: users[item.createdBy]?.username,
          fullName: users[item.createdBy]?.fullName,
          code: users[item.createdBy]?.code,
        };
        item.qcRequest = item.qcRequest?.[0];
      });
    }

    const dataReturn = plainToInstance(QCCommandResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async update(request: UpdateQCCommandRequestDto): Promise<any> {
    try {
      const { id } = request;
      let qcCommand = await this.qcCommandRepository.findOneById(id);
      if (!qcCommand) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }
      qcCommand = this.qcCommandRepository.updateModel(qcCommand, request);

      const dataSave = await this.qcCommandRepository.findByIdAndUpdate(
        id,
        qcCommand,
      );

      const dataReturn = plainToInstance(QCCommandResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async delete(request: IdParamMongoDto): Promise<any> {
    const { id } = request;
    const qcCommand = await this.qcCommandRepository.findOneByCondition(id);
    if (!qcCommand) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    await this.qcCommandRepository.deleteById(id);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateStatus(request: UpdateStatusQCCommandRequestDto): Promise<any> {
    const { id, status, userId } = request;
    const qcCommand = await this.qcCommandRepository.findOneById(id);
    if (!qcCommand) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }

    if (status === QC_COMMAND_STATUS.CONFIRMED) {
      const items = qcCommand.items?.map((item) => ({
        ...item,
        qcCommandCode: qcCommand.code,
      }));

      await this.qcRequestRepository.findAllAndUpdate(
        {
          code: qcCommand.qcRequestCode,
        },
        { $set: { status: QC_REQUEST_STATUS.IN_PROGRESS } },
      );

      await this.qcExecuteService.createMulti(items);

      await this.ticketReportErrorService.create(qcCommand, userId);
    }

    await this.qcCommandRepository.findByIdAndUpdate(id, {
      $set: { status: status },
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async import(data: any): Promise<{ dataSuccess: any[]; dataError: any[] }> {
    const textAdd = await this.i18n.translate('import.common.add');

    const { dataToInsert } = getDataInsert(data, textAdd);
    const { dataToUpdate, codesUpdate } = getDataUpdate(data, textAdd);

    const codeUpdateExists = await this.qcCommandRepository.findAllByCondition({
      code: { $in: codesUpdate },
    });
    const codeUpdateMap = keyBy(codeUpdateExists, 'code');

    const { dataError, dataUpdate } = getDataToUpdateError(
      dataToUpdate,
      codeUpdateMap,
    );

    const bulkOps = [...dataToInsert, ...dataUpdate].map((doc) => ({
      updateOne: {
        filter: { code: doc.code },
        update: doc,
        upsert: true,
      },
    }));

    const dataSuccess = await this.qcCommandRepository.bulkWrite(bulkOps);

    return { dataError, dataSuccess };
  }

  private async generateQCCommandCode(): Promise<any> {
    const shortYear = moment().format(FORMAT_SHORT_YEAR);
    const prefixWithYear = `${PREFIX_QC_COMMAND_CODE}${shortYear}`;

    const lastQCCommand = await this.qcCommandRepository.getLastQCCommand(
      prefixWithYear,
    );

    let index = INDEX_QC_COMMAND_CODE_START;
    if (!isEmpty(lastQCCommand)) {
      const lastCode: string = lastQCCommand.code;
      if (!isEmpty(lastCode) && lastCode.length > prefixWithYear.length) {
        let lastIndex: any = lastCode
          .substring(prefixWithYear.length)
          .replace(REGEX_PADDING_ZERO, EMPTY_STRING);
        lastIndex = Number(lastIndex);
        if (!isNaN(lastIndex)) {
          index = lastIndex + STEP_INDEX_QC_COMMAND_CODE;
        }
      }
    }

    const codeNew = `${prefixWithYear}${index
      ?.toString()
      .padStart(MAX_LENGTH_INDEX, PADDING_SYMBOL)}`;

    const existCode = await this.qcCommandRepository.findOneByCode(codeNew);

    if (!isEmpty(existCode)) {
      return this.generateQCCommandCode();
    }

    return codeNew;
  }
}
