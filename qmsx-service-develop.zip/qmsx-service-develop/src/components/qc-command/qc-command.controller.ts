import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateQCCommandRequestDto } from './dto/request/create-qc-command.request.dto';
import { GetDetailQCCommandRequestDto } from './dto/request/get-detail-qc-command.request.dto';
import { GetListQCCommandRequestDto } from './dto/request/get-list-qc-command.request.dto';
import { UpdateQCCommandBodyDto } from './dto/request/update-qc-command.request.dto';
import { ListQCCommandResponseDto } from './dto/response/list-qc-command.response.dto';
import { QCCommandResponseDto } from './dto/response/qc-command.response.dto';
import { QCCommandServiceInterface } from './interface/qc-command.service.interface';
import { QC_COMMAND_STATUS } from './qc-command.constant';

@Controller('qc-commands')
export class QCCommandController {
  constructor(
    @Inject('QCCommandServiceInterface')
    private readonly qcCommandService: QCCommandServiceInterface,
  ) {}

  @Post()
  @ApiOperation({
    tags: ['QC Command - Lệnh QC'],
    summary: 'Thêm lệnh QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Add Successfully',
    type: QCCommandResponseDto,
  })
  async create(@Body() payload: CreateQCCommandRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.qcCommandService.create(request);
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['QC Command - Lệnh QC'],
    summary: 'Chi tiết lệnh QC',
    description: 'Chi tiết lệnh QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: QCCommandResponseDto,
  })
  async getDetail(@Param() param: GetDetailQCCommandRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qcCommandService.getDetail(request);
  }

  @Get()
  @ApiOperation({
    tags: ['QC Command - Lệnh QC'],
    summary: 'Danh sách lệnh QC',
    description: 'Danh sách lệnh QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListQCCommandResponseDto,
  })
  async getList(@Query() query: GetListQCCommandRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qcCommandService.getList(request);
  }

  @Put('/:id')
  @ApiOperation({
    tags: ['QC Command - Lệnh QC'],
    summary: 'Sửa lệnh QC',
    description: 'Sửa lệnh QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async update(
    @Param() param: IdParamMongoDto,
    @Body() payload: UpdateQCCommandBodyDto,
  ): Promise<any> {
    const { request: requestParam, responseError: responseParamError } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.qcCommandService.update({
      id: requestParam.id,
      ...request,
    });
  }

  @Delete('/:id')
  @ApiOperation({
    tags: ['QC Command - Lệnh QC'],
    summary: 'Xóa lệnh QC',
    description: 'Xóa lệnh QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async delete(@Param() param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.qcCommandService.delete(request);
  }

  @Put('/:id/submit')
  @ApiOperation({
    tags: ['QC Command - Lệnh QC'],
    summary: 'Gửi lệnh QC',
    description: 'Gửi lệnh QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async submit(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qcCommandService.updateStatus({
      ...request,
      status: QC_COMMAND_STATUS.WAITING,
    });
  }

  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['QC Command - Lệnh QC'],
    summary: 'Xác nhận lệnh QC',
    description: 'Xác nhận lệnh QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async confirm(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qcCommandService.updateStatus({
      ...request,
      status: QC_COMMAND_STATUS.CONFIRMED,
    });
  }

  @Put('/:id/reject')
  @ApiOperation({
    tags: ['QC Command - Lệnh QC'],
    summary: 'Từ chối lệnh QC',
    description: 'Từ chối lệnh QC',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async reject(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qcCommandService.updateStatus({
      ...request,
      status: QC_COMMAND_STATUS.REJECTED,
    });
  }
}
