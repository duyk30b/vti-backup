import { QCRequestResponseDto } from '@components/qc-request/dto/response/qc-request.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { Expose, Type } from 'class-transformer';

class EvaluationCriteria {
  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  checkType: number;

  @Expose()
  upperBound: number;

  @Expose()
  norm: number;

  @Expose()
  lowerBound: number;

  @Expose()
  important: number;

  @Expose()
  weight: number;
}

export class ItemExecuteQC {
  @Expose()
  itemCode: string;

  @Expose()
  item: any;

  @Expose()
  reviewType: number;

  @Expose()
  evaluationFormCode: string;

  @Expose()
  evaluationCriterias: EvaluationCriteria[];

  @Expose()
  qcNumber: number;

  @Expose()
  qcBy: number[];

  @Expose()
  startDate: Date;

  @Expose()
  endDate: Date;

  @Expose()
  lot: string;

  @Expose()
  qcFormat: number;

  @Expose()
  planQuantity: number;

  @Expose()
  planExecuteQuantity: number;

  @Expose()
  todoQuantity: number;

  @Expose()
  unit: string;
}

export class QCCommandResponseDto extends BaseResponseDto {
  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  qcRequestCode: string;

  @Expose()
  @Type(() => QCRequestResponseDto)
  qcRequest: QCRequestResponseDto;

  @Expose()
  description: string;

  @Expose()
  status: number;

  @Expose()
  items: ItemExecuteQC[];
}
