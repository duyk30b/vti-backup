import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';
import { QCCommandResponseDto } from './qc-command.response.dto';

export class ListQCCommandResponseDto extends PaginationResponse {
  @ApiProperty({ type: QCCommandResponseDto, isArray: true })
  @Type(() => QCCommandResponseDto)
  @Expose()
  items: QCCommandResponseDto[];
}
