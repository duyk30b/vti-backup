import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateQCCommandRequestDto } from './create-qc-command.request.dto';

export class UpdateQCCommandBodyDto extends CreateQCCommandRequestDto {}

export class UpdateQCCommandRequestDto extends UpdateQCCommandBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
