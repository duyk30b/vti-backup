import { QC_COMMAND_STATUS } from '@components/qc-command/qc-command.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsMongoId, IsNotEmpty } from 'class-validator';

export class UpdateStatusQCCommandRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(QC_COMMAND_STATUS)
  status: number;
}
