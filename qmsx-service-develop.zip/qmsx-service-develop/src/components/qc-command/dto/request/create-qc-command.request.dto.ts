import { QC_FORMAT } from '@components/evaluation-form/evaluation-form.constant';
import {
  QC_COMMAND_CONST,
  QC_COMMAND_STATUS,
  REVIEW_TYPE,
} from '@components/qc-command/qc-command.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsDate,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
  MinLength,
} from 'class-validator';

export class EvaluationCriteria {
  @ApiProperty()
  code: string;

  @ApiProperty()
  name: string;

  @ApiProperty()
  checkType: number;

  @ApiProperty()
  upperBound: number;

  @ApiProperty()
  norm: number;

  @ApiProperty()
  lowerBound: number;

  @ApiProperty()
  important: number;

  @ApiProperty()
  weight: number;
}

export class ItemExecuteQC {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  itemCode: string;

  @ApiProperty()
  @IsOptional()
  item: any;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(REVIEW_TYPE)
  reviewType: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  evaluationFormCode: string;

  @ApiProperty()
  @IsNotEmpty()
  evaluationCriterias: EvaluationCriteria[];

  @ApiProperty()
  @IsOptional()
  qcNumber: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  qcBy: number[];

  @ApiProperty()
  @IsNotEmpty()
  @IsDate()
  startDate: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsDate()
  endDate: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  lot: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(QC_FORMAT)
  qcFormat: number;

  @ApiProperty()
  @IsOptional()
  planQuantity: number;

  @ApiProperty()
  @IsNotEmpty()
  planExecuteQuantity: number;

  @ApiProperty()
  @IsNotEmpty()
  @Min(QC_COMMAND_CONST.TODO_QUANTITY.MIN)
  @Max(QC_COMMAND_CONST.TODO_QUANTITY.MAX)
  todoQuantity: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  unit: string;
}

export class CreateQCCommandRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @MinLength(QC_COMMAND_CONST.CODE.MIN_LENGTH)
  @MaxLength(QC_COMMAND_CONST.CODE.MAX_LENGTH)
  @IsString()
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @MinLength(QC_COMMAND_CONST.NAME.MIN_LENGTH)
  @MaxLength(QC_COMMAND_CONST.NAME.MAX_LENGTH)
  @IsString()
  name: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  qcRequestCode: string;

  @ApiProperty()
  @IsOptional()
  @MaxLength(QC_COMMAND_CONST.DESCRIPTION.MAX_LENGTH)
  @IsString()
  description: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(QC_COMMAND_STATUS)
  status: number;

  @ApiProperty()
  @IsOptional()
  @IsArray()
  items: ItemExecuteQC[];
}
