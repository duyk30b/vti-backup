import { has } from 'lodash';

export function getDataInsert(data: any[], textAdd = 'add') {
  const dataToInsert = [];
  const codesInsert = [];
  data.forEach((item) => {
    if (item.action === textAdd) {
      dataToInsert.push(item);
      codesInsert.push(item.code);
    }
  });
  return { dataToInsert, codesInsert };
}

export function getDataUpdate(data: any[], textAdd = 'add') {
  const dataToUpdate = [];
  const codesUpdate = [];
  data.forEach((item) => {
    if (item.action !== textAdd) {
      dataToUpdate.push(item);
      codesUpdate.push(item.code);
    }
  });
  return { dataToUpdate, codesUpdate };
}

export function getDataToUpdateError(data: any[], dataCodeMap = {}) {
  const dataError = [];
  const dataUpdate = [];
  data.forEach((item) => {
    if (!has(dataCodeMap, item.code)) {
      dataError.push(item);
    } else {
      dataUpdate.push(item);
    }
  });
  return { dataUpdate, dataError };
}

export function getDataToInsertError(data: any[], dataCodeMap = {}) {
  const dataError = [];
  const dataInsert = [];
  data.forEach((item) => {
    if (!has(dataCodeMap, item.code)) {
      dataInsert.push(item);
    } else {
      dataError.push(item);
    }
  });
  return { dataInsert, dataError };
}
