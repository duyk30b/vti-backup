import { Inject, Injectable } from '@nestjs/common';
import { ClientNats } from '@nestjs/microservices';
import { firstValueFrom } from 'rxjs';

@Injectable()
export class NatsClientService {
  constructor(
    @Inject('NATS_CLIENT_SERVICE')
    private client: ClientNats,
  ) {}

  async send(pattern: string, data: any): Promise<any> {
    const request = this.client.send(pattern, data);
    return await firstValueFrom(request);
  }
}
