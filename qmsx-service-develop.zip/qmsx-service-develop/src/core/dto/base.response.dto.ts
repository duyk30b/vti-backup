import { UserResponseDto } from '@components/user/dto/response/user.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';

export class BaseResponseDto {
  @ApiProperty()
  @Expose({ name: '_id' })
  @Transform((value) => value.obj._id?.toString())
  id: string;

  @ApiProperty()
  @Expose({ name: 'createdAt' })
  createdAt: Date;

  @ApiProperty()
  @Expose({ name: 'updatedAt' })
  updatedAt: Date;

  @ApiProperty()
  @Expose({ name: 'createdBy' })
  @Type(() => UserResponseDto)
  createdBy: UserResponseDto;
}
