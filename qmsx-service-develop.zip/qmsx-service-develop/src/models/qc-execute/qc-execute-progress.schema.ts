import { QC_STATUS } from '@components/qc-execute/qc-execute.constant';
import { DEFAULT_COLLATION } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Types } from 'mongoose';

@Schema({
  timestamps: true,
  collection: 'qcExecuteProgresses',
  collation: DEFAULT_COLLATION,
})
export class QCExecuteProgress extends BaseModel {
  @Prop({
    type: Number,
    required: true,
  })
  index: number;

  @Prop({
    type: Number,
    required: true,
  })
  todoQuantity: number;

  @Prop({
    type: Number,
    required: true,
  })
  testedQuantity: number;

  @Prop({
    type: Number,
    required: true,
  })
  remainQuantity: number;

  @Prop({
    type: Number,
    required: true,
  })
  passQuantity: number;

  @Prop({
    type: Number,
    required: true,
  })
  failQuantity: number;

  @Prop({
    type: Number,
    required: true,
  })
  status: QC_STATUS;

  @Prop({
    required: false,
  })
  resultIds: Types.ObjectId[];
}

export const QCExecuteProgressSchema =
  SchemaFactory.createForClass(QCExecuteProgress);
