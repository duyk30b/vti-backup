import { QC_STATUS_RESULT } from '@components/qc-execute/qc-execute.constant';
import { DEFAULT_COLLATION } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

export class Result {
  @Prop({
    type: String,
    required: true,
  })
  errorCode: string;

  @Prop({
    type: String,
    required: true,
  })
  evaluationCode: string;

  @Prop({
    type: Number,
    required: true,
  })
  errorNumber: number;

  @Prop({
    required: false,
  })
  causeCodes: string[];

  @Prop({
    type: String,
    required: false,
  })
  propose: string;
}

@Schema({
  timestamps: true,
  collection: 'qcExecuteResults',
  collation: DEFAULT_COLLATION,
})
export class QCExecuteResult extends BaseModel {
  @Prop({
    type: Number,
    required: true,
  })
  index: number;

  @Prop({
    type: String,
    required: true,
  })
  code: string;

  @Prop({
    type: String,
    required: false,
  })
  name: string;

  @Prop({
    type: String,
    required: false,
  })
  description: string;

  @Prop({
    type: Number,
    required: true,
  })
  quantity: number;

  @Prop({
    type: Number,
    required: false,
    default: 0,
  })
  failQuantity: number;

  @Prop({
    type: Number,
    required: true,
  })
  status: QC_STATUS_RESULT;

  @Prop({
    type: Number,
    required: true,
  })
  duration: number;

  @Prop({
    type: Date,
    required: true,
  })
  qcStartDate: Date;

  @Prop({
    type: Date,
    required: true,
  })
  qcEndDate: Date;

  @Prop({
    required: false,
    type: Result,
  })
  resultInfo?: Result[];

  @Prop({
    required: true,
  })
  qcExecuteId: string;

  @Prop({
    required: true,
  })
  qcExecuteProgressId: string;
}

export const QCExecuteResultSchema =
  SchemaFactory.createForClass(QCExecuteResult);
