import {
  QC_SETTING_FORMAT,
  QC_SETTING_TODO_QUANTITY,
  QC_STATUS,
} from '@components/qc-execute/qc-execute.constant';
import { DEFAULT_COLLATION } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Types } from 'mongoose';
import { EvaluationCriteria } from '../evaluation-criteria/evaluation-criteria.schema';

class Evaluation extends EvaluationCriteria {
  @Prop({
    type: Number,
    required: true,
  })
  important: number;
}

@Schema({
  timestamps: true,
  collection: 'qcExecutes',
  collation: DEFAULT_COLLATION,
})
export class QCExecute extends BaseModel {
  @Prop({
    type: String,
    required: true,
  })
  itemCode: string;

  @Prop({
    type: String,
    required: false,
  })
  lot: string;

  @Prop({
    type: Number,
    required: true,
  })
  qcNumber: number;

  @Prop({
    type: Date,
    required: true,
  })
  startDate: Date;

  @Prop({
    type: Date,
    required: true,
  })
  endDate: Date;

  @Prop({
    type: Date,
    required: false,
  })
  deadline: Date;

  @Prop({ type: String, required: true })
  qcCommandCode: string;

  @Prop({
    required: true,
  })
  qcBy: number[];

  @Prop({
    required: true,
  })
  qcFormat: string;

  @Prop({
    required: false,
  })
  settingFormat: QC_SETTING_FORMAT;

  @Prop({
    required: false,
  })
  settingTodoQuantity: QC_SETTING_TODO_QUANTITY;

  @Prop({
    type: Number,
    required: true,
  })
  planQuantity: number;

  @Prop({
    type: Number,
    required: true,
  })
  todoQuantity: number;

  @Prop({
    type: Number,
    required: false,
  })
  testedQuantity: number;

  @Prop({
    type: Number,
    required: false,
  })
  remainQuantity: number;

  @Prop({
    type: Number,
    required: false,
  })
  passQuantity: number;

  @Prop({
    type: Number,
    required: false,
  })
  failQuantity: number;

  @Prop({
    type: Number,
    required: true,
  })
  status: QC_STATUS;

  @Prop({
    type: Number,
    required: false,
  })
  progress: number;

  @Prop({
    required: false,
  })
  qcProgressItemIds: Types.ObjectId[];

  @Prop({
    required: false,
  })
  qcResultIds: Types.ObjectId[];

  @Prop({
    required: false,
  })
  evaluationCriterias: Evaluation[];
}

export const QCExecuteSchema = SchemaFactory.createForClass(QCExecute);
