import { QC_STATUS } from '@components/qc-execute/qc-execute.constant';
import { DEFAULT_COLLATION } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

export class ErrorItem {
  @Prop({
    type: String,
    required: true,
  })
  code: string;

  @Prop({
    type: String,
    required: true,
  })
  name: string;

  @Prop({
    type: String,
    required: true,
  })
  evaluationCriteriaCode: string;

  @Prop({
    type: Number,
    required: true,
  })
  errorNumber: number;

  @Prop({
    type: String,
    required: true,
  })
  causeCodes: string[];

  @Prop({
    type: String,
    required: false,
  })
  recommend: string;
}

export class ItemTicketReport {
  @Prop({
    type: String,
    required: true,
  })
  code: string;

  @Prop({
    type: String,
    required: true,
  })
  name: string;

  @Prop({
    type: String,
    required: true,
  })
  lot: string;

  @Prop({
    type: Number,
    required: false,
  })
  planQuantity: number;

  @Prop({
    type: Number,
    required: false,
  })
  todoQuantity: number;

  @Prop({
    type: Number,
    required: false,
  })
  testedQuantity: number;

  @Prop({
    type: Number,
    required: false,
  })
  remainQuantity: number;

  @Prop({
    type: Number,
    required: false,
  })
  passQuantity: number;

  @Prop({
    type: Number,
    required: false,
  })
  failQuantity: number;

  qcExecuteResults: any;
}

@Schema({
  timestamps: true,
  collection: 'ticketReportErrors',
  collation: DEFAULT_COLLATION,
})
export class TicketReportError extends BaseModel {
  @Prop({
    type: String,
    required: true,
  })
  code: string;

  @Prop({
    type: String,
    required: true,
  })
  qcCommandCode: string;

  qcCommand: any;

  qcBy: any;

  @Prop({
    type: Date,
    required: false,
  })
  startDate: Date;

  @Prop({
    type: Date,
    required: false,
  })
  endDate: Date;

  @Prop({
    type: ItemTicketReport,
    required: false,
  })
  items: ItemTicketReport[];

  @Prop({
    type: Number,
    required: true,
  })
  status: QC_STATUS;
}

export const TicketReportErrorSchema =
  SchemaFactory.createForClass(TicketReportError);
