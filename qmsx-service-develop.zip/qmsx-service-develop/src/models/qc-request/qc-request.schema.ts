import { CHECK_TYPE } from '@components/evaluation-criteria/evaluation-criteria.constant';
import {
  PROPOSE_PROCESS,
  QC_REQUEST_STATUS,
  REQUEST_SOURCE,
} from '@components/qc-request/qc-request.constant';
import { DEFAULT_COLLATION } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

export class ItemRequest {
  @Prop({
    type: String,
    required: true,
  })
  itemType: string;

  @Prop({
    type: String,
    required: true,
  })
  code: string;

  @Prop({
    type: String,
    required: false,
  })
  name: string;

  @Prop({
    type: Number,
    enum: CHECK_TYPE,
    required: false,
    default: CHECK_TYPE.MEASURE,
  })
  checkType: number;

  @Prop({
    type: String,
    required: true,
  })
  lot: string;

  @Prop({
    type: Number,
    required: true,
  })
  planQuantity: number;

  @Prop({
    type: String,
    required: false,
  })
  unit: string;
}

@Schema({
  timestamps: true,
  collection: 'qcRequests',
  collation: DEFAULT_COLLATION,
})
export class QCRequest extends BaseModel {
  @Prop({
    type: String,
    required: true,
  })
  code: string;

  @Prop({
    type: String,
    required: true,
  })
  name: string;

  @Prop({
    type: Number,
    enum: REQUEST_SOURCE,
    required: true,
    default: REQUEST_SOURCE.QMSX,
  })
  requestSource: number;

  @Prop({
    type: String,
    required: true,
  })
  requestType: string;

  @Prop({
    type: Number,
    required: false,
  })
  requestBy: number;

  @Prop({
    type: Date,
    required: true,
  })
  returnDate: Date;

  @Prop({
    type: String,
    required: false,
  })
  ticket: string;

  @Prop({
    type: Number,
    enum: PROPOSE_PROCESS,
    required: false,
  })
  proposeProcess: number;

  @Prop({
    type: String,
    required: false,
  })
  workOrder: string;

  @Prop({
    type: String,
    required: false,
  })
  description: string;

  @Prop({
    type: ItemRequest,
    required: false,
  })
  items: ItemRequest[];

  @Prop({
    type: Number,
    enum: QC_REQUEST_STATUS,
    required: true,
    default: QC_REQUEST_STATUS.DRAFT,
  })
  status: number;
}

export const QCRequestSchema = SchemaFactory.createForClass(QCRequest);
