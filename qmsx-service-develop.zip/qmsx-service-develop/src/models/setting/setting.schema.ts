import {
  QC_SETTING_FORMAT,
  QC_SETTING_TODO_QUANTITY,
} from '@components/qc-execute/qc-execute.constant';
import { DEFAULT_COLLATION } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

@Schema({
  timestamps: true,
  collection: 'qcSettings',
  collation: DEFAULT_COLLATION,
})
export class QCSetting extends BaseModel {
  @Prop({
    type: Number,
    required: true,
    enum: QC_SETTING_FORMAT,
    default: QC_SETTING_FORMAT.MANDATORY,
  })
  settingFormat: QC_SETTING_FORMAT;

  @Prop({
    type: Number,
    required: true,
    enum: QC_SETTING_TODO_QUANTITY,
    default: QC_SETTING_TODO_QUANTITY.TESTED,
  })
  settingTodoQuantity: QC_SETTING_TODO_QUANTITY;
}

export const QCSettingSchema = SchemaFactory.createForClass(QCSetting);
