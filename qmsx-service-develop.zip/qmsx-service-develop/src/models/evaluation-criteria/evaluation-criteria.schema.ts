import { ACTIVE_ENUM, DEFAULT_COLLATION } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

export class EvaluationCriteriaDetail extends BaseModel {
  @Prop({
    type: String,
    required: true,
  })
  name: string;

  @Prop({
    type: String,
    required: false,
  })
  description: string;

  @Prop({
    type: String,
    required: false,
  })
  errorCodes: string[];

  errors: any;
}

@Schema({
  timestamps: true,
  collection: 'evaluationCriterias',
  collation: DEFAULT_COLLATION,
})
export class EvaluationCriteria extends BaseModel {
  @Prop({
    type: String,
    required: true,
  })
  code: string;

  @Prop({
    type: String,
    required: true,
  })
  name: string;

  @Prop({
    type: Number,
    required: true,
  })
  checkType: number;

  @Prop({
    type: Number,
    required: false,
  })
  upperBound: number;

  @Prop({
    type: Number,
    required: false,
  })
  norm: number;

  @Prop({
    type: Number,
    required: false,
  })
  lowerBound: number;

  @Prop({
    type: Number,
    required: false,
  })
  weight: number;

  @Prop({
    type: String,
    required: false,
  })
  description: string;

  @Prop({
    required: false,
  })
  details: EvaluationCriteriaDetail[];

  @Prop({
    type: Number,
    enum: ACTIVE_ENUM,
    required: false,
    default: ACTIVE_ENUM.ACTIVE,
  })
  active: number;
}

export const EvaluationCriteriaSchema =
  SchemaFactory.createForClass(EvaluationCriteria);
