import { ACTIVE_ENUM, DEFAULT_COLLATION } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Types } from 'mongoose';

@Schema({
  timestamps: true,
  collection: 'errorGroups',
  collation: DEFAULT_COLLATION,
})
export class ErrorGroup extends BaseModel {
  @Prop({
    type: String,
    required: true,
  })
  code: string;

  @Prop({
    type: String,
    required: true,
  })
  name: string;

  @Prop({
    type: String,
    required: false,
  })
  description: string;

  @Prop({
    required: false,
  })
  errorCodes: string[];

  @Prop({
    type: Number,
    enum: ACTIVE_ENUM,
    required: false,
    default: ACTIVE_ENUM.ACTIVE,
  })
  active: number;
}

export const ErrorGroupSchema = SchemaFactory.createForClass(ErrorGroup);
