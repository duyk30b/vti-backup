import { QC_FORMAT } from '@components/evaluation-form/evaluation-form.constant';
import {
  QC_COMMAND_STATUS,
  REVIEW_TYPE,
} from '@components/qc-command/qc-command.constant';
import { DEFAULT_COLLATION } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

class EvaluationCriteria {
  @Prop()
  code: string;

  @Prop()
  name: string;

  @Prop()
  checkType: number;

  @Prop()
  upperBound: number;

  @Prop()
  norm: number;

  @Prop()
  lowerBound: number;

  @Prop()
  weight: number;

  @Prop()
  important: number;
}

export class ItemExecuteQC {
  @Prop({
    type: String,
    required: true,
  })
  itemCode: string;

  item: any;

  @Prop({
    type: Number,
    enum: REVIEW_TYPE,
    required: false,
    default: REVIEW_TYPE.EVALUATION_FORM,
  })
  reviewType: number;

  @Prop({
    type: String,
    required: false,
  })
  evaluationFormCode: string;

  @Prop({
    type: EvaluationCriteria,
    required: true,
  })
  evaluationCriterias: EvaluationCriteria[];

  @Prop({
    type: Number,
    required: true,
  })
  qcNumber: number;

  @Prop({
    type: Number,
    required: false,
  })
  qcBy: number[];

  @Prop({
    type: Date,
    required: true,
  })
  startDate: Date;

  @Prop({
    type: Date,
    required: true,
  })
  endDate: Date;

  @Prop({
    type: String,
    required: false,
  })
  lot: string;

  @Prop({
    type: Number,
    enum: QC_FORMAT,
    required: true,
  })
  qcFormat: number;

  @Prop({
    type: Number,
    required: false,
  })
  planQuantity: number;

  @Prop({
    type: Number,
    required: true,
  })
  planExecuteQuantity: number;

  @Prop({
    type: Number,
    required: true,
  })
  todoQuantity: number;

  @Prop({
    type: String,
    required: true,
  })
  unit: string;
}

@Schema({
  timestamps: true,
  collection: 'qcCommands',
  collation: DEFAULT_COLLATION,
})
export class QCCommand extends BaseModel {
  @Prop({
    type: String,
    required: true,
  })
  code: string;

  @Prop({
    type: String,
    required: true,
  })
  name: string;

  @Prop({
    type: String,
    required: true,
  })
  qcRequestCode: string;

  qcRequest: any;

  @Prop({
    type: String,
    required: false,
  })
  description: string;

  @Prop({
    type: Number,
    enum: QC_COMMAND_STATUS,
    required: true,
  })
  status: number;

  @Prop({
    type: ItemExecuteQC,
    required: false,
  })
  items: ItemExecuteQC[];
}
export const QCCommandSchema = SchemaFactory.createForClass(QCCommand);
