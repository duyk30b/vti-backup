import { Evaluation } from '@components/evaluation-form/dto/request/create-evaluation-form-template.request.dto';
import { DEFAULT_COLLATION } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

export class EvaluationCol {
  @Prop({ required: true })
  code: string;

  @Prop({ required: true })
  name: string;

  @Prop({ required: true })
  checkType: string;

  @Prop({ required: true })
  uppperBound: number;

  @Prop({ required: true })
  lowerBound: number;

  @Prop({ required: true })
  norm: number;
}

@Schema({
  timestamps: true,
  collection: 'evaluationForms',
  collation: DEFAULT_COLLATION,
})
export class EvaluationFormCollection extends BaseModel {
  @Prop({ required: true })
  code: string;

  @Prop({ required: true })
  name: string;

  @Prop({ required: false })
  description: string;

  @Prop({ required: true })
  active: number;

  @Prop({ required: true })
  itemId: number;

  @Prop({ required: true })
  qcNumber: number;

  @Prop({ required: true })
  qcQuantity: number;

  @Prop({ required: true })
  qcFormat: number;

  @Prop({ required: true, type: EvaluationCol })
  evaluations: Evaluation[];

  @Prop({
    type: Number,
    required: false,
  })
  weight: number;
}

export const EvaluationFormSchema = SchemaFactory.createForClass(
  EvaluationFormCollection,
);
