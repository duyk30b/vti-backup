import { DEFAULT_COLLATION } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

@Schema({
  timestamps: true,
  collection: 'causes',
  collation: DEFAULT_COLLATION,
})
export class CauseCollection extends BaseModel {
  @Prop({ required: true })
  code: string;

  @Prop({ required: true })
  name: string;

  @Prop({ required: false })
  description: string;

  @Prop({ required: true })
  isActive: number;
}

export const CauseSchema = SchemaFactory.createForClass(CauseCollection);
