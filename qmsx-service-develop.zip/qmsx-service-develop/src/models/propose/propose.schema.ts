import { DEFAULT_COLLATION } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Types } from 'mongoose';

@Schema({
  timestamps: true,
  collection: 'proposes',
  collation: DEFAULT_COLLATION,
})
export class Propose extends BaseModel {
  @Prop({
    type: Types.ObjectId,
    required: true,
  })
  qcExecuteId: Types.ObjectId;

  @Prop({
    type: String,
    required: true,
  })
  errorCode: string;

  @Prop({
    type: String,
    required: true,
  })
  content: string;
}

export const ProposeSchema = SchemaFactory.createForClass(Propose);
