import { ACTIVE_ENUM, DEFAULT_COLLATION } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

@Schema({
  timestamps: true,
  collection: 'errors',
  collation: DEFAULT_COLLATION,
})
export class Error extends BaseModel {
  @Prop({
    type: String,
    required: true,
  })
  code: string;

  @Prop({
    type: String,
    required: true,
  })
  name: string;

  @Prop({
    type: String,
    required: false,
  })
  description: string;

  @Prop({
    type: Array,
    required: false,
  })
  causeCodes: string[];

  @Prop({
    type: Number,
    enum: ACTIVE_ENUM,
    required: false,
    default: ACTIVE_ENUM.ACTIVE,
  })
  active: number;
}

export const ErrorSchema = SchemaFactory.createForClass(Error);
