import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';

export class IdParams extends BaseDto {
  @ApiProperty({ description: 'Id' })
  @IsMongoId()
  @IsNotEmpty()
  id: string;
}
