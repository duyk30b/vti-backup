import { Global, Module } from '@nestjs/common';
import { WarehouseClientService } from './warehouse-client.service';

@Global()
@Module({
  exports: [WarehouseClientService],
  providers: [WarehouseClientService],
})
export class WarehouseClientModule {}
