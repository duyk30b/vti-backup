import { Global, Module } from '@nestjs/common';
import { ItemClientService } from './item.client.service';

@Global()
@Module({
  exports: [ItemClientService],
  providers: [ItemClientService],
})
export class ItemClientModule {}
