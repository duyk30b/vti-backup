import { NATS_ITEM } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { GetItemStockWarehouseLocatorRequestDto } from './request/get-items-stock-warehouse-locator.request.dto';

@Injectable()
export class ItemClientService {
  constructor(private readonly natsClientService: NatsClientService) {}

  async checkExistItemInLocator(locatorIds: string[]): Promise<boolean> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.check_exist_item_stock_in_locator`,
      { locatorIds },
    );
    return response?.data;
  }

  async getPositionExistItems(params: any): Promise<any[]> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_position_items`,
      params,
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getItemStockWarehouseLocators(
    request: GetItemStockWarehouseLocatorRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_stock_warehouse_locator_by_locator_ids`,
      request,
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }
}
