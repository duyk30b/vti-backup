import { ArrayNotEmpty, IsInt, IsNotEmpty } from 'class-validator';

export class ItemWarehouseRequestDto {
  @IsNotEmpty()
  @IsInt()
  itemId: number;
}

export class ItemWarehouseByLocationRequestDto {
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ArrayNotEmpty()
  lots: string[];
}
