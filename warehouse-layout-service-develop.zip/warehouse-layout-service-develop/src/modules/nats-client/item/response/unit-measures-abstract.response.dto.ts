import { UnitMeasuresEnum, UnitWeightEnum } from '@constant/common';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class UnitMeaseuresAbstractResponse {
  @ApiProperty()
  @Expose()
  value: number;

  @ApiProperty()
  @Expose()
  unit: UnitMeasuresEnum;
}

export class UnitWeightAbstractResponse {
  @ApiProperty()
  @Expose()
  value: number;

  @ApiProperty()
  @Expose()
  unit: UnitWeightEnum;
}
