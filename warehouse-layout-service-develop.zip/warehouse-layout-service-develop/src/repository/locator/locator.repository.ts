import { CreateLocatorRequestDto } from '@components/locator/dto/request/create-locator.request.dto';
import { GetListLocatorRequestDto } from '@components/locator/dto/request/get-list-locator.request.dto';
import { GetLocatorByKeywordRequestDto } from '@components/locator/dto/request/get-locator-by-keyword.request.dto';
import {
  LocatorConditionDto,
  LocatorRepositoryInterface,
} from '@components/locator/interface/locator.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Locator } from '@models/locator/locator.schema';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { isEmpty } from 'lodash';
import { FilterQuery, Model, Types } from 'mongoose';
import {
  LocatorStatusEnum,
  LocatorTypeEnum,
} from './../../components/locator/locator.constant';

@Injectable()
export class LocatorRepository
  extends BaseAbstractRepository<Locator>
  implements LocatorRepositoryInterface
{
  constructor(
    @InjectModel('Locator')
    private readonly locator: Model<Locator>,
  ) {
    super(locator);
  }

  getFilterOptions(condition: LocatorConditionDto) {
    const filter: FilterQuery<Locator> = {};

    if (condition.id != null) filter._id = condition.id;
    if (condition.warehouseId != null) filter.rootId = condition.warehouseId;

    if (condition.ids != null) filter._id = { $in: condition.ids };

    return filter;
  }

  async findManyBy(condition: LocatorConditionDto) {
    const filter = this.getFilterOptions(condition);
    return await this.locator.find(filter).lean();
  }

  createDocument(request: CreateLocatorRequestDto): Locator {
    const { warehouseId, description, userId } = request;
    const document = new this.locator();
    document.description = description;
    document.type = LocatorTypeEnum.REAL_LOCATION;
    document.rootId = warehouseId;
    document.createdBy = userId;
    document.status = LocatorStatusEnum.ACTIVE;
    return document;
  }

  updateDocument(locator: Locator, request: any): Locator {
    if (request?.name) locator.name = request.name;
    if (request?.code) locator.name = request.code;
    if (request?.warehouseId) locator.rootId = request.warehouseId;
    if (request?.description) locator.description = request.description;
    if (request?.level) locator.level = request.level;
    locator.updatedBy = request.userId;
    return locator;
  }

  async getList(
    request: GetListLocatorRequestDto,
    isGetAll?: boolean,
  ): Promise<any> {
    const { keyword, sort, filter, take, skip, locatorIds } = request;
    let filterObj = {};
    let sortObj = {};

    if (keyword?.length) {
      filterObj = {
        $or: [{ code: { $regex: '.*' + keyword + '.*', $options: 'i' } }],
      };
    }
    if (!isEmpty(locatorIds)) {
      filterObj = {
        ...filterObj,
        _id: {
          $in: locatorIds.map((id) => new Types.ObjectId(id)),
        },
      };
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        switch (item.column) {
          case 'locatorIds':
            filterObj = {
              ...filterObj,
              _id: {
                $in: item.text.split(',').map((id) => new Types.ObjectId(id)),
              },
            };
            break;
          case 'type':
            filterObj = {
              ...filterObj,
              type: {
                $in: item.text.split(',').map((id) => +id),
              },
            };
            break;
          case 'warehouseId':
          case 'rootId':
            filterObj = {
              ...filterObj,
              rootId: +item.text,
            };
            break;
          case 'warehouseIds':
            filterObj = {
              ...filterObj,
              rootId: {
                $in: item.text.split(',').map((id) => +id),
              },
            };
            break;
          case 'code':
            filterObj = {
              ...filterObj,
              code: {
                $regex: '.*' + item.text + '.*',
                $options: 'i',
              },
            };
            break;
          case 'name':
            filterObj = {
              ...filterObj,
              name: {
                $regex: '.*' + item.text + '.*',
                $options: 'i',
              },
            };
            break;
          case 'level':
            filterObj = { ...filterObj, level: +item.text };
            break;
          case 'status':
            filterObj = { ...filterObj, status: item.text };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const sort = item.order == 'DESC' ? -1 : 1;
        switch (item.column) {
          case 'code':
            sortObj = { ...sortObj, code: sort };
            break;
          case 'name':
            sortObj = { ...sortObj, name: sort };
            break;
          case 'warehouseCode':
            isGetAll = true;
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = { createdAt: -1 };
    }

    const count = await this.locator.count(filterObj);
    const query = this.locator.find(filterObj).sort(sortObj).lean();

    const result = isGetAll
      ? await query.exec()
      : await query.skip(skip).limit(take).exec();
    return {
      result: result,
      count: count,
    };
  }

  async getListByLayoutId(layoutId: string): Promise<any> {
    const query = this.locator
      .aggregate()
      .lookup({
        from: 'locations',
        localField: 'refLocation',
        foreignField: '_id',
        pipeline: [
          {
            $match: {
              layoutId: new Types.ObjectId(layoutId),
            },
          },
        ],
        as: 'locations',
      })
      .match({
        locations: {
          $ne: [],
        },
      });

    const queryResult = await query.exec();

    return queryResult;
  }

  async getListByLayoutIds(layoutIds: string[]): Promise<any> {
    const query = this.locator
      .aggregate()
      .lookup({
        from: 'locations',
        localField: 'refLocation',
        foreignField: '_id',
        pipeline: [
          {
            $match: {
              layoutId: {
                $in: layoutIds.map((id) => new Types.ObjectId(id)),
              },
            },
          },
        ],
        as: 'locations',
      })
      .match({
        locations: {
          $ne: [],
        },
      });

    const queryResult = await query.exec();

    return queryResult;
  }

  async getLocatorsByRootId(rootId: number): Promise<any> {
    return await this.locator.find({ rootId: rootId });
  }

  async getLocatorByLocatorId(locatorId: number): Promise<any> {
    return await this.locator.findOne({ locatorId: locatorId });
  }

  async getLocatorByCode(code: string, warehouseId?: number): Promise<any> {
    return warehouseId
      ? await this.locator.findOne({ code: code, rootId: warehouseId })
      : await this.locator.findOne({ code: code });
  }

  async findLocatorByCodeKeyword(
    request: GetLocatorByKeywordRequestDto,
  ): Promise<any> {
    const { locatorCodeKeyword, rootId } = request;
    let keywordObj = {};
    keywordObj = {
      $and: [
        {
          code: { $regex: '.*' + locatorCodeKeyword + '.*', $options: 'i' },
          rootId: { $in: rootId },
        },
      ],
    };
    return await this.locator.find(keywordObj);
  }
}
