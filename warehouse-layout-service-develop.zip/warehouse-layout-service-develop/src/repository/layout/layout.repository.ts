import { CreateLayoutRequestDto } from '@components/layout/dto/request/create-layout.request.dto';
import { GetLayoutListRequestDto } from '@components/layout/dto/request/get-layout-list.request.dto';
import { LayoutRepositoryInterface } from '@components/layout/interface/layout.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import '@utils/extensions/mongoose.extension';
import { isEmpty } from 'lodash';
import * as moment from 'moment';
import { Model } from 'mongoose';
import { Layout, LayoutLevelModel } from 'src/models/layout/layout.schema';

@Injectable()
export class LayoutRepository
  extends BaseAbstractRepository<Layout>
  implements LayoutRepositoryInterface
{
  constructor(
    @InjectModel(Layout.name)
    private readonly layout: Model<Layout>,
  ) {
    super(layout);
  }

  public createDocument(request: CreateLayoutRequestDto): Layout {
    const {
      code,
      name,
      warehouseId,
      layoutTemplateId,
      lengthUnit,
      weightUnit,
      quantity,
      items,
      userId,
    } = request;
    const document = new this.layout();
    document.code = code;
    document.name = name;
    document.warehouseId = warehouseId;
    if (layoutTemplateId) document.layoutTemplate = layoutTemplateId;
    document.lengthUnit = lengthUnit;
    document.weightUnit = weightUnit;
    document.quantity = quantity;
    document.items = items;
    document.createdBy = userId;
    return document;
  }

  public createLayoutLevelModel(item: LayoutLevelModel): LayoutLevelModel {
    const layoutLevelModel = new LayoutLevelModel();
    layoutLevelModel.code = item?.code;
    layoutLevelModel.name = item?.name;
    layoutLevelModel.length = item?.length;
    layoutLevelModel.width = item?.width;
    layoutLevelModel.height = item?.height;
    layoutLevelModel.weight = item?.weight;
    layoutLevelModel.quantity = item?.quantity;
    layoutLevelModel.layoutType = item?.layoutType;
    layoutLevelModel.level = item?.level;
    return layoutLevelModel;
  }

  updateDocument(layout: Layout, request: any): Layout {
    if (request?.code) layout.code = request.code;
    if (request?.name) layout.name = request.name;
    if (request?.warehouseId) layout.warehouseId = request.warehouseId;
    if (request?.layoutTemplateId)
      layout.layoutTemplate = request.layoutTemplateId;
    if (request?.lengthUnit) layout.lengthUnit = request.lengthUnit;
    if (request?.weightUnit) layout.weightUnit = request.weightUnit;
    if (request?.quantity) layout.quantity = request.quantity;
    if (request?.items) layout.items = request.items;
    return layout;
  }

  async getList(request: GetLayoutListRequestDto): Promise<any> {
    const { keyword, sort, filter, take, skip } = request;
    let filterObj = {};
    let sortObj = {};

    if (keyword?.length) {
      filterObj = {
        $or: [
          { name: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          {
            items: {
              $elemMatch: {
                name: { $regex: '.*' + keyword + '.*', $options: 'i' },
              },
            },
          },
        ],
      };
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: {
                $regex: '.*' + item.text + '.*',
                $options: 'i',
              },
            };
            break;
          case 'name':
            filterObj = {
              ...filterObj,
              name: {
                $regex: '.*' + item.text + '.*',
                $options: 'i',
              },
            };
            break;
          case 'nameLevel1': // Filter by name of level 1
            filterObj = {
              ...filterObj,
              items: {
                $elemMatch: {
                  name: { $regex: '.*' + item.text + '.*', $options: 'i' },
                },
              },
            };
            break;
          case 'warehouseId': // Filter by multiple warehouse
            filterObj = {
              ...filterObj,
              warehouseId: {
                $in: item.text.split(',').map((id) => parseInt(id)),
              },
            };
            break;
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'status':
            filterObj = { ...filterObj, status: parseInt(item.text) };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const sort = item.order == 'DESC' ? -1 : 1;
        switch (item.column) {
          case 'code':
            sortObj = { ...sortObj, code: sort };
            break;
          case 'name':
            sortObj = { ...sortObj, name: sort };
            break;
          case 'nameLevel1':
            sortObj = { ...sortObj, nameL1: sort };
            break;
          case 'length':
            sortObj = { ...sortObj, length: sort };
            break;
          case 'weight':
            sortObj = { ...sortObj, weight: sort };
            break;
          case 'numLevel':
            sortObj = { ...sortObj, levelCnt: sort };
            break;
          default:
            break;
        }
      });
    } else {
      // Default sort by the created at and id
      sortObj = { createdAt: -1, _id: -1 };
    }

    const query = this.layout
      .aggregate()
      .addFields({
        nameL1: { $first: '$items.name' },
        length: {
          $multiply: [
            { $first: '$items.length' },
            { $first: '$items.width' },
            { $first: '$items.height' },
          ],
        },
        weight: { $first: '$items.weight' },
        levelCnt: { $size: `$items` },
      })
      .match(filterObj);

    const queryResult = (
      await query.buildPaginationQuery(skip, take, sortObj).exec()
    )[0];

    return {
      result: queryResult.data,
      count: queryResult.total,
    };
  }

  async deleteManyByCondition(condition: any): Promise<any> {
    return this.layout.deleteMany(condition).exec();
  }
}
