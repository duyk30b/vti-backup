import { CreateLayoutTemplateRequestDto } from '@components/layout-template/dto/request/create-template-layout.request.dto';
import { GetLayoutTemplateListRequestDto } from '@components/layout-template/dto/request/get-template-layout-list.request.dto';
import { LayoutTemplateRepositoryInterface } from '@components/layout-template/interface/layout-template.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import '@utils/extensions/mongoose.extension';
import { isEmpty } from 'lodash';
import * as moment from 'moment';
import { Model } from 'mongoose';
import { LayoutTemplate } from 'src/models/layout-template/layout-template.schema';

@Injectable()
export class LayoutTemplateRepository
  extends BaseAbstractRepository<LayoutTemplate>
  implements LayoutTemplateRepositoryInterface
{
  constructor(
    @InjectModel(LayoutTemplate.name)
    private readonly layoutTemplate: Model<LayoutTemplate>,
  ) {
    super(layoutTemplate);
  }

  public createDocument(
    request: CreateLayoutTemplateRequestDto,
  ): LayoutTemplate {
    const { name, lengthUnit, weightUnit, items, userId } = request;
    const document = new this.layoutTemplate();
    document.name = name;
    document.lengthUnit = lengthUnit;
    document.weightUnit = weightUnit;
    document.items = items;
    document.createdBy = userId;
    return document;
  }

  updateDocument(layoutTemplate: LayoutTemplate, request: any): LayoutTemplate {
    if (request?.name) layoutTemplate.name = request.name;
    if (request?.lengthUnit) layoutTemplate.lengthUnit = request.lengthUnit;
    if (request?.weightUnit) layoutTemplate.weightUnit = request.weightUnit;
    if (request?.items) layoutTemplate.items = request.items;
    return layoutTemplate;
  }

  async getList(request: GetLayoutTemplateListRequestDto): Promise<any> {
    const { keyword, sort, filter, take, skip } = request;
    let filterObj = {};
    let sortObj = {};

    if (keyword?.length) {
      filterObj = {
        $or: [
          { name: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          {
            items: {
              $elemMatch: {
                name: { $regex: '.*' + keyword + '.*', $options: 'i' },
              },
            },
          },
        ],
      };
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        switch (item.column) {
          case 'name':
            filterObj = {
              ...filterObj,
              name: {
                $regex: '.*' + item.text + '.*',
                $options: 'i',
              },
            };
            break;
          case 'level':
            filterObj = { ...filterObj, level: +item.text };
            break;
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'status':
            filterObj = { ...filterObj, status: parseInt(item.text) };
            break;
          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const sort = item.order == 'DESC' ? -1 : 1;
        switch (item.column) {
          case 'code':
            sortObj = { ...sortObj, code: sort };
            break;
          case 'name':
            sortObj = { ...sortObj, name: sort };
            break;
          case 'length':
            sortObj = { ...sortObj, length: sort };
            break;
          case 'weight':
            sortObj = { ...sortObj, weight: sort };
            break;
          case 'levelCnt':
            sortObj = { ...sortObj, levelCnt: sort };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = { createdAt: -1 };
    }

    const query = this.layoutTemplate
      .aggregate()
      .addFields({
        length: {
          $multiply: [
            { $first: '$items.length' },
            { $first: '$items.width' },
            { $first: '$items.height' },
          ],
        },
        weight: { $first: '$items.weight' },
        levelCnt: { $size: `$items` },
      })
      .match(filterObj);

    const queryResult = (
      await query.buildPaginationQuery(skip, take, sortObj).exec()
    )[0];

    return {
      result: queryResult.data,
      count: queryResult.total,
    };
  }

  async deleteManyByCondition(condition: any): Promise<any> {
    return this.layoutTemplate.deleteMany(condition).exec();
  }
}
