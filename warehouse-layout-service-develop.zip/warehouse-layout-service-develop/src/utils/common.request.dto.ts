import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { ArrayNotEmpty, IsMongoId, IsNotEmpty } from 'class-validator';
import { IsArrayMongoId } from 'src/validator/is-array-mongo-id.validator';

export class DetailRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}

export class DeleteMultipleDto extends BaseDto {
  @ApiProperty()
  @Transform((data) => data.value.split(','))
  @ArrayNotEmpty()
  @IsArrayMongoId()
  ids: string[];
}
