import { StatusPermission } from '@constant/common';

export const CREATE_LOCATOR_PERMISSION = {
  code: 'WAREHOUSE_CREATE_LOCATOR',
  name: 'Tạo vị trí lưu kho',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATOR_GROUP',
  status: StatusPermission.ACTIVE,
};

export const UPDATE_LOCATOR_PERMISSION = {
  code: 'WAREHOUSE_UPDATE_LOCATOR',
  name: 'Sửa vị trí lưu kho',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATOR_GROUP',
  status: StatusPermission.ACTIVE,
};

export const DELETE_LOCATOR_PERMISSION = {
  code: 'WAREHOUSE_DELETE_LOCATOR',
  name: 'Xóa vị trí lưu kho',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATOR_GROUP',
  status: StatusPermission.ACTIVE,
};

export const CONFIRM_LOCATOR_PERMISSION = {
  code: 'WAREHOUSE_CONFIRM_LOCATOR',
  name: 'Xác nhận vị trí',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATOR_GROUP',
  status: StatusPermission.ACTIVE,
};

export const REJECT_LOCATOR_PERMISSION = {
  code: 'WAREHOUSE_REJECT_LOCATOR',
  name: 'Từ chối vị trí',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATOR_GROUP',
  status: StatusPermission.ACTIVE,
};

export const DETAIL_LOCATOR_PERMISSION = {
  code: 'WAREHOUSE_DETAIL_LOCATOR',
  name: 'Chi tiết vị trí lưu kho',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATOR_GROUP',
  status: StatusPermission.ACTIVE,
};

export const LIST_LOCATOR_PERMISSION = {
  code: 'WAREHOUSE_LIST_LOCATOR',
  name: 'Danh sách vị trí lưu kho',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATOR_GROUP',
  status: StatusPermission.ACTIVE,
};

export const LOCATOR_GROUP_PERMISSION = {
  name: 'Định nghĩa vị trí lưu kho',
  code: 'WAREHOUSE_LOCATOR_GROUP',
  status: StatusPermission.ACTIVE,
};

export const LOCATOR_PERMISSION = [
  CREATE_LOCATOR_PERMISSION,
  UPDATE_LOCATOR_PERMISSION,
  DELETE_LOCATOR_PERMISSION,
  DETAIL_LOCATOR_PERMISSION,
  LIST_LOCATOR_PERMISSION,
  CONFIRM_LOCATOR_PERMISSION,
  REJECT_LOCATOR_PERMISSION,
];
