import { StatusPermission } from '@constant/common';

export const LOCATION_SEGMENT_GROUP_PERMISSION = {
  name: 'Quản lý các cấp vị trí',
  code: 'WAREHOUSE_LOCATION_SEGMENT_GROUP',
  status: StatusPermission.ACTIVE,
};

export const CREATE_LOCATION_SEGMENT_PERMISSION = {
  code: 'WAREHOUSE_CREATE_LOCATION_SEGMENT',
  name: 'Tạo cấp vị trí',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATION_SEGMENT_GROUP',
  status: StatusPermission.ACTIVE,
};

export const UPDATE_LOCATION_SEGMENT_PERMISSION = {
  code: 'WAREHOUSE_UPDATE_LOCATION_SEGMENT',
  name: 'Sửa cấp vị trí',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATION_SEGMENT_GROUP',
  status: StatusPermission.ACTIVE,
};

export const DELETE_LOCATION_SEGMENT_PERMISSION = {
  code: 'WAREHOUSE_DELETE_LOCATION_SEGMENT',
  name: 'Xóa cấp vị trí',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATION_SEGMENT_GROUP',
  status: StatusPermission.INACTIVE,
};

export const CONFIRM_LOCATION_SEGMENT_PERMISSION = {
  code: 'WAREHOUSE_CONFIRM_LOCATION_SEGMENT',
  name: 'Mở khoá cấp vị trí',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATION_SEGMENT_GROUP',
  status: StatusPermission.ACTIVE,
};

export const REJECT_LOCATION_SEGMENT_PERMISSION = {
  code: 'WAREHOUSE_REJECT_LOCATION_SEGMENT',
  name: 'Khóa cấp vị trí',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATION_SEGMENT_GROUP',
  status: StatusPermission.ACTIVE,
};

export const DETAIL_LOCATION_SEGMENT_PERMISSION = {
  code: 'WAREHOUSE_DETAIL_LOCATION_SEGMENT',
  name: 'Chi tiết cấp vị trí',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATION_SEGMENT_GROUP',
  status: StatusPermission.ACTIVE,
};

export const LIST_LOCATION_SEGMENT_PERMISSION = {
  code: 'WAREHOUSE_LIST_LOCATION_SEGMENT',
  name: 'Danh sách cấp vị trí',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATION_SEGMENT_GROUP',
  status: StatusPermission.ACTIVE,
};

export const IMPORT_LOCATION_SEGMENT_PERMISSION = {
  code: 'WAREHOUSE_IMPORT_LOCATION_SEGMENT',
  name: 'Nhập theo danh sách cấp vị trí',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATION_SEGMENT_GROUP',
  status: StatusPermission.ACTIVE,
};

export const EXPORT_LOCATION_SEGMENT_PERMISSION = {
  code: 'WAREHOUSE_EXPORT_LOCATION_SEGMENT',
  name: 'Xuất danh sách cấp vị trí',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATION_SEGMENT_GROUP',
  status: StatusPermission.ACTIVE,
};

export const LOCATION_SEGMENT_PERMISSION = [
  CREATE_LOCATION_SEGMENT_PERMISSION,
  UPDATE_LOCATION_SEGMENT_PERMISSION,
  DELETE_LOCATION_SEGMENT_PERMISSION,
  DETAIL_LOCATION_SEGMENT_PERMISSION,
  CONFIRM_LOCATION_SEGMENT_PERMISSION,
  REJECT_LOCATION_SEGMENT_PERMISSION,
  LIST_LOCATION_SEGMENT_PERMISSION,
];
