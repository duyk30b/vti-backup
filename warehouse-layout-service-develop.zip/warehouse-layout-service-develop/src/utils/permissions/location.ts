import { StatusPermission } from '@constant/common';

export const LOCATION_GROUP_PERMISSION = {
  name: 'Quản lý vị trí',
  code: 'WAREHOUSE_LOCATION_GROUP',
  status: StatusPermission.ACTIVE,
};

export const CREATE_LOCATION_PERMISSION = {
  code: 'WAREHOUSE_CREATE_LOCATION',
  name: 'Tạo vị trí',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATION_GROUP',
  status: StatusPermission.ACTIVE,
};

export const UPDATE_LOCATION_PERMISSION = {
  code: 'WAREHOUSE_UPDATE_LOCATION',
  name: 'Sửa vị trí',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATION_GROUP',
  status: StatusPermission.ACTIVE,
};

export const DELETE_LOCATION_PERMISSION = {
  code: 'WAREHOUSE_DELETE_LOCATION',
  name: 'Xóa vị trí',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATION_GROUP',
  status: StatusPermission.INACTIVE,
};

export const CONFIRM_LOCATION_PERMISSION = {
  code: 'WAREHOUSE_CONFIRM_LOCATION',
  name: 'Mở khoá vị trí',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATION_GROUP',
  status: StatusPermission.ACTIVE,
};

export const REJECT_LOCATION_PERMISSION = {
  code: 'WAREHOUSE_REJECT_LOCATION',
  name: 'Khoá vị trí',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATION_GROUP',
  status: StatusPermission.ACTIVE,
};

export const DETAIL_LOCATION_PERMISSION = {
  code: 'WAREHOUSE_DETAIL_LOCATION',
  name: 'Chi tiết vị trí',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATION_GROUP',
  status: StatusPermission.ACTIVE,
};

export const LIST_LOCATION_PERMISSION = {
  code: 'WAREHOUSE_LIST_LOCATION',
  name: 'Danh sách vị trí',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATION_GROUP',
  status: StatusPermission.ACTIVE,
};

export const IMPORT_LOCATION_PERMISSION = {
  code: 'WAREHOUSE_IMPORT_LOCATION',
  name: 'Nhập theo danh sách vị trí',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATION_GROUP',
  status: StatusPermission.ACTIVE,
};

export const EXPORT_LOCATION_PERMISSION = {
  code: 'WAREHOUSE_EXPORT_LOCATION',
  name: 'Xuất theo danh sách vị trí',
  groupPermissionSettingCode: 'WAREHOUSE_LOCATION_GROUP',
  status: StatusPermission.ACTIVE,
};

export const LOCATION_PERMISSION = [
  CREATE_LOCATION_PERMISSION,
  UPDATE_LOCATION_PERMISSION,
  DELETE_LOCATION_PERMISSION,
  DETAIL_LOCATION_PERMISSION,
  LIST_LOCATION_PERMISSION,
  CONFIRM_LOCATION_PERMISSION,
  REJECT_LOCATION_PERMISSION,
  IMPORT_LOCATION_PERMISSION,
  EXPORT_LOCATION_PERMISSION,
];
