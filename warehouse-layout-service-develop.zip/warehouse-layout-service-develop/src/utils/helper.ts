import { PREFIX_MPATH } from '@components/locator/locator.constant';

/**
 * @deprecated Using isEmpty from 'lodash'
 */
export default function isEmpty(obj) {
  return Object.keys(obj).length === 0;
}

/**
 * @deprecated Using `keyBy(data, 'id')`. Import keyBy from 'lodash'
 */
export function serilize(data) {
  if (data.length > 0) {
    const serilizeData = [];
    data.forEach((record) => {
      serilizeData[record.id] = record;
    });
    return serilizeData;
  }
  return data;
}

export function genMpath(data: number[] | string[]): string {
  return data.join(PREFIX_MPATH) + PREFIX_MPATH;
}

export const isDevMode = () => {
  return (
    process.env.NODE_ENV.startsWith('dev') ||
    process.env.NODE_ENV.startsWith('local')
  );
};
