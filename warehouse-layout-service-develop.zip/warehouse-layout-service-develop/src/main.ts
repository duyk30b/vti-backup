import { NATS_SERVERS, NATS_WAREHOUSE_LAYOUT } from '@config/nats.config';
import { ClusterService } from '@core/cluster/cluster.service';
import { ExceptionEnterceptor } from '@core/interceptors/exception.interceptor';
import { FilterQueryPipe } from '@core/pipe/filter-query.pipe';
import { SortQueryPipe } from '@core/pipe/sort-query.pipe';
import { NestFactory } from '@nestjs/core';
import { Transport } from '@nestjs/microservices';
import { FastifyAdapter, NestFastifyApplication } from '@nestjs/platform-fastify';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { isDevMode } from '@utils/helper';
import fastifyMultipart from 'fastify-multipart';
import { AppModule } from './app.module';
import { APIPrefix } from './common/common';
import { ConfigService } from './config/config.service';

async function bootstrap() {
  const fastifyAdapter = new FastifyAdapter();

  fastifyAdapter.register(fastifyMultipart, {
    attachFieldsToBody: true,
    addToBody: true,
  });

  const app = await NestFactory.create<NestFastifyApplication>(AppModule, fastifyAdapter, {
    logger: isDevMode() ? ['debug', 'error', 'log', 'verbose', 'warn'] : ['error'],
  });

  app.connectMicroservice(
    {
      transport: Transport.NATS,
      options: {
        servers: NATS_SERVERS,
        queue: NATS_WAREHOUSE_LAYOUT,
      },
    },
    { inheritAppConfig: true },
  );

  const options = new DocumentBuilder()
    .setTitle('API docs')
    .addTag('warehouse-layouts')
    .addBearerAuth({ type: 'http', description: 'Access token' }, 'access-token')
    .setVersion('1.0')
    .build();

  await app.startAllMicroservices();
  app.setGlobalPrefix(APIPrefix.Version);

  const document = SwaggerModule.createDocument(app, options);
  SwaggerModule.setup(`/api/v1/warehouse-layouts/swagger-docs`, app, document, {
    swaggerOptions: { persistAuthorization: true },
  });

  let corsOptions = {};
  const configService = new ConfigService();
  if (configService.get('corsOrigin')) {
    corsOptions = {
      origin: new ConfigService().get('corsOrigin'),
    };
  }

  // eslint-disable-next-line @typescript-eslint/no-var-requires
  app.register(require('@fastify/cors'), corsOptions);
  app.useGlobalPipes(new SortQueryPipe());
  app.useGlobalPipes(new FilterQueryPipe());
  app.useGlobalInterceptors(new ExceptionEnterceptor());

  await app.listen(new ConfigService().get('httpPort'), '0.0.0.0');
}

isDevMode() ? bootstrap() : ClusterService.clusterize(bootstrap);
