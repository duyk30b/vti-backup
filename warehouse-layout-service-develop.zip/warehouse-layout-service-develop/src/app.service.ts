import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable, Logger } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { INSERT_PERMISSION } from '@utils/permissions/permission';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';

@Injectable()
export class AppService {
  constructor(
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,
  ) {}
  async onModuleInit() {
    await this.updatePermissions();
  }

  getHello(): string {
    return 'Hello World!';
  }

  getHealth(): any {
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage('This is Warehouse-layout-service')
      .build();
  }

  private async updatePermissions() {
    const waitForMe = (ms: number) => {
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(ms);
        }, ms);
      });
    };
    let inserted = false,
      deleted = false,
      retryInsertCount = 0,
      retryDeleteCount = 0;
    do {
      try {
        if (!inserted && 6 > retryInsertCount) {
          retryInsertCount++;
          const responseInsert = await this.userService.insertPermission(
            INSERT_PERMISSION,
          );

          inserted = responseInsert?.statusCode === ResponseCodeEnum.SUCCESS;
        }

        if (!deleted && 6 > retryDeleteCount) {
          retryDeleteCount++;
          const responseDelete =
            await this.userService.deletePermissionNotActive();

          deleted = responseDelete?.statusCode === ResponseCodeEnum.SUCCESS;
        }

        if (
          (!inserted && 6 > retryInsertCount) ||
          (!deleted && 6 > retryDeleteCount)
        ) {
          await waitForMe(5000);
        }
      } catch (err) {
        Logger.error(err.message, 'Permission Sync Error');
        await waitForMe(5000);
      }
    } while (
      (!inserted && 6 > retryInsertCount) ||
      (!deleted && 6 > retryDeleteCount)
    );
  }
}
