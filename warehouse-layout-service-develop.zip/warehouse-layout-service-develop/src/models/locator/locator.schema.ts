import {
  LOCATOR_RULES,
  LocatorStatusEnum,
  LocatorTypeEnum,
} from '@components/locator/locator.constant';
import { DEFAULT_COLLATION } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Types } from 'mongoose';

@Schema({
  collection: 'locators',
  timestamps: true,
  collation: DEFAULT_COLLATION,
})
export class Locator extends BaseModel {
  @Prop({
    type: Types.ObjectId,
    require: true,
    ref: 'Layout',
  })
  layoutId: Types.ObjectId;

  @Prop({ required: true, maxlength: LOCATOR_RULES.CODE.MAX_LENGTH })
  code: string;

  @Prop({ required: false, maxlength: LOCATOR_RULES.NAME.MAX_LENGTH })
  name: string;

  @Prop({ required: false, maxlength: 255 })
  description: string;

  @Prop({ required: true })
  level: number;

  @Prop({ required: true })
  rootId: number;

  @Prop({ required: false })
  mpath: string;

  @Prop({ required: false })
  pathCode: string;

  @Prop({ required: false })
  pathName: string;

  @Prop({ default: LocatorStatusEnum.ACTIVE })
  status: LocatorStatusEnum;

  @Prop({ required: false })
  layoutType: number;

  @Prop({ required: false })
  lengthUnit: number;

  @Prop({ required: false })
  weightUnit: number;

  @Prop({ required: false })
  length: number;

  @Prop({ required: false })
  width: number;

  @Prop({ required: false })
  height: number;

  @Prop({ required: false })
  weight: number;

  @Prop({ default: LocatorTypeEnum.REAL_LOCATION }) // sau nay se bo type
  type: LocatorTypeEnum;
}

export const LocatorSchema = SchemaFactory.createForClass(Locator);
