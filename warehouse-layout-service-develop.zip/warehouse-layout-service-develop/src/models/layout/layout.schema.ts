import { LAYOUT_TYPE_ENUM } from '@components/layout-template/layout-template.constant';
import { LAYOUT_RULES } from '@components/layout/layout.constant';
import { DEFAULT_COLLATION } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Locator, LocatorSchema } from '@models/locator/locator.schema';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Types } from 'mongoose';

export class LayoutLevelModel {
  @Prop({
    required: true,
    unique: true,
    maxlength: LAYOUT_RULES.CODE.MAX_LENGTH,
  })
  code: string;

  @Prop({ maxlength: LAYOUT_RULES.NAME.MAX_LENGTH })
  name: string;

  @Prop({ type: Number })
  length: number;

  @Prop({ type: Number })
  width: number;

  @Prop({ type: Number })
  height: number;

  @Prop({ type: Number })
  weight: number;

  @Prop({ type: Number })
  quantity: number;

  @Prop({
    type: Number,
    enum: LAYOUT_TYPE_ENUM,
    default: LAYOUT_TYPE_ENUM.FLAT,
  })
  layoutType: number;

  @Prop({
    type: Number,
    required: true,
  })
  level: number;
}

@Schema({
  collection: 'layout',
  timestamps: true,
  collation: DEFAULT_COLLATION,
})
export class Layout extends BaseModel {
  @Prop({
    required: true,
    unique: true,
    maxlength: LAYOUT_RULES.CODE.MAX_LENGTH,
  })
  code: string;

  @Prop({ maxlength: LAYOUT_RULES.NAME.MAX_LENGTH })
  name: string;

  @Prop({ required: true })
  warehouseId: number;

  @Prop({ required: false, type: Types.ObjectId })
  layoutTemplate: string;

  @Prop({ required: true })
  lengthUnit: number;

  @Prop({ required: true })
  weightUnit: number;

  @Prop()
  items: LayoutLevelModel[];

  @Prop({ required: true })
  quantity: number;

  @Prop({
    type: [LocatorSchema],
    ref: 'Locator',
  })
  locators: Locator[];
}

export const LayoutSchema = SchemaFactory.createForClass(Layout);
