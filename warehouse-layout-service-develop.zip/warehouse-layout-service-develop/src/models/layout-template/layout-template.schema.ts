import { LAYOUT_TEMPLATE_RULES } from '@components/layout-template/layout-template.constant';
import { DEFAULT_COLLATION } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { LayoutLevelModel } from '@models/layout/layout.schema';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

@Schema({
  collection: 'layoutTemplate',
  timestamps: true,
  collation: DEFAULT_COLLATION,
})
export class LayoutTemplate extends BaseModel {
  @Prop({
    required: true,
    maxlength: LAYOUT_TEMPLATE_RULES.NAME.MAX_LENGTH,
  })
  name: string;

  @Prop({ required: true })
  lengthUnit: number;

  @Prop({ required: true })
  weightUnit: number;

  @Prop()
  items: LayoutLevelModel[];
}

export const LayoutTemplateSchema =
  SchemaFactory.createForClass(LayoutTemplate);
