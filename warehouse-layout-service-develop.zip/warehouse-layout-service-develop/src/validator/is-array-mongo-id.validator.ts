import { buildMessage, ValidateBy, ValidationOptions } from 'class-validator';
import { Types } from 'mongoose';

export const IS_ARRAY_MONGO_ID = 'isArrayMongoId';

export function isArrayMongoId(array: unknown): boolean {
  if (!Array.isArray(array)) return false;

  return array.every((value) => Types.ObjectId.isValid(value));
}

export function IsArrayMongoId(
  validationOptions?: ValidationOptions,
): PropertyDecorator {
  return ValidateBy(
    {
      name: IS_ARRAY_MONGO_ID,
      validator: {
        validate: (value): boolean => isArrayMongoId(value),
        defaultMessage: buildMessage(
          (eachPrefix) =>
            eachPrefix + '$property should not contain $constraint1 values',
          validationOptions,
        ),
      },
    },
    validationOptions,
  );
}
