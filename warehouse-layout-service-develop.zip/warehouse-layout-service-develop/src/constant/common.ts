import * as dotenv from 'dotenv';
import { CollationOptions } from 'mongodb';

dotenv.config();

export enum APIPrefix {
  Version = 'api/v1',
}
export const FORMAT_CODE_PERMISSION = 'WAREHOUSE_LAYOUT_';

export enum SortOrder {
  Ascending = 1,
  Descending = -1,
}

export const DEFAULT_COLLATION: CollationOptions = {
  locale: 'vi',
};

export const SORT_CONST = {
  ASCENDING: 'asc',
  DESCENDING: 'desc',
};

//permission
export enum StatusPermission {
  ACTIVE = 1,
  INACTIVE = 0,
}

export enum UnitMeasuresEnum {
  CM = 1,
  DM = 2,
  M = 3,
}

export const UNIT_MEASURES = [
  UnitMeasuresEnum.CM,
  UnitMeasuresEnum.DM,
  UnitMeasuresEnum.M,
];

export enum UnitWeightEnum {
  GAM = 1,
  KG = 2,
  TON = 3,
}

export const UNIT_WEIGHT = [
  UnitWeightEnum.GAM,
  UnitWeightEnum.KG,
  UnitWeightEnum.TON,
];

export const UNIT_MEASURE_DEFAULT = UnitMeasuresEnum.CM;

export const UNIT_WEIGHT_DEFAULT = UnitWeightEnum.GAM;

export const DATA_DEFAULT_MEASURES = {
  value: 0,
  unit: UnitMeasuresEnum.CM,
};

export enum QUEUES_NAME_ENUM {
  SYNC_DATA_QUEUE = 'SYNC_DATA_QUEUE',
}

export enum IsActionEnum {
  NO,
  YES,
}
