import { CreateLocatorByWarehouseRequestDto } from '../dto/request/create-locator-by-warehouse.request.dto';
import { DeleteLocatorRequestDto } from '../dto/request/delete-locator.request.dto';
import { GetListLocatorRequestDto } from '../dto/request/get-list-locator.request.dto';
import { GetLocatorByCodeRequestDto } from '../dto/request/get-locator-by-code.request.dto';
import { GetLocatorByKeywordRequestDto } from '../dto/request/get-locator-by-keyword.request.dto';
import { GetLocatorDetailRequestDto } from '../dto/request/get-locator.request.dto';
import { GetLocatorsRequestDto } from '../dto/request/get-locators.request.dto';
import { UpdateLocatorRequestDto } from '../dto/request/update-locator.request.dto';
import { ConfirmLocatorRequestDto } from './../dto/request/confirm-locator.request.dto';
import { GetLocatorVirtualByWarehouseIdRequestDto } from './../dto/request/get-locator-virtual-by-warehouse-id.request.dto';
import { RejectLocatorRequestDto } from './../dto/request/reject-locator.request.dto';

export interface LocatorServiceInterface {
  update(request: UpdateLocatorRequestDto): Promise<any>;
  getDetail(request: GetLocatorDetailRequestDto): Promise<any>;
  getList(request: GetListLocatorRequestDto): Promise<any>;
  getMany(request: GetLocatorsRequestDto): Promise<any>;
  delete(request: DeleteLocatorRequestDto): Promise<any>;
  getLocatorByLocatorId(locatorId: number): Promise<any>;
  getLocatorByRootIds(
    rootIds: number[],
    locatorIds: number[],
    type?: number,
  ): Promise<any>;
  createLocatorByWarehouse(request: CreateLocatorByWarehouseRequestDto);
  getLocatorByCode(payload: GetLocatorByCodeRequestDto): Promise<any>;
  getLocatorCodeKeyword(request: GetLocatorByKeywordRequestDto): Promise<any>;
  getLocatorVirtualByWarehouseId(
    request: GetLocatorVirtualByWarehouseIdRequestDto,
  ): Promise<any>;
  confirm(request: ConfirmLocatorRequestDto): Promise<any>;
  reject(request: RejectLocatorRequestDto): Promise<any>;
  getLocatorsByRootId(rootId: number): Promise<any>;
  getLocatorByCodes(request: any): Promise<any>;
}
