import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { Locator } from '@models/locator/locator.schema';
import { GetListLocatorRequestDto } from '../dto/request/get-list-locator.request.dto';
import { GetLocatorByKeywordRequestDto } from '../dto/request/get-locator-by-keyword.request.dto';

export interface LocatorConditionDto {
  id?: string;
  ids?: string[];
  warehouseId?: number;
}
export interface LocatorRepositoryInterface
  extends BaseInterfaceRepository<Locator> {
  findManyBy(condition: LocatorConditionDto): Promise<any>;
  getList(request: GetListLocatorRequestDto, isGetAll?: boolean): Promise<any>;
  createDocument(request: any): Locator;
  updateDocument(locator: Locator, request: any): Locator;
  getLocatorByLocatorId(locatorId: number): Promise<any>;
  getLocatorByCode(code: string, warehouseId?: number): Promise<any>;
  findLocatorByCodeKeyword(
    request: GetLocatorByKeywordRequestDto,
  ): Promise<any>;
  getLocatorsByRootId(rootId: number): Promise<any>;
  deleteManyByCondition(condition: any): Promise<any>;
  getListByLayoutId(layoutId: string): Promise<any>;
  getListByLayoutIds(layoutIds: string[]): Promise<any>;
}
