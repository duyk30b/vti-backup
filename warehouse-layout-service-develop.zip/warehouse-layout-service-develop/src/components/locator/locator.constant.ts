export const LOCATOR_RULES = {
  CODE: {
    MAX_LENGTH: 255,
  },
  NAME: {
    MAX_LENGTH: 255,
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
};
export const REGEX = {
  LOCATION_ID: /\d+/g,
  LOCATION_ID_PATH: /([\d]+.)/g,
};

export const CHARACTER_MAP_LOCATION_NAME = '->';
export const CHARACTER_MAP_LOCATION_CODE = '->';
export const CHARACTER_MAP_LOCATION_PATH = '.';

export enum LocatorStatusEnum {
  INACTIVE = 0,
  ACTIVE = 1,
}

export const CAN_STATUS_CONFIRM_LOCATOR = [LocatorStatusEnum.INACTIVE];

export const CAN_STATUS_REJECT_LOCATOR = [LocatorStatusEnum.ACTIVE];

export enum LocatorTypeEnum {
  REAL_LOCATION = 0,
  VIRTUAL_LOCATION = 1,
}

export const LEVEL_ROOT = 0;

export const PREFIX_MPATH = '.';
