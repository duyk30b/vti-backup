import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { isEmpty, keyBy, map, uniq } from 'lodash';
import { Types } from 'mongoose';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ItemClientService } from 'src/modules/nats-client/item/item.client.service';
import { WarehouseClientService } from 'src/modules/nats-client/warehouse/warehouse-client.service';
import { ConfirmLocatorRequestDto } from './dto/request/confirm-locator.request.dto';
import { CreateLocatorByWarehouseRequestDto } from './dto/request/create-locator-by-warehouse.request.dto';
import { CreateLocatorRequestDto } from './dto/request/create-locator.request.dto';
import { DeleteLocatorRequestDto } from './dto/request/delete-locator.request.dto';
import { GetListLocatorRequestDto } from './dto/request/get-list-locator.request.dto';
import { GetLocatorByCodeRequestDto } from './dto/request/get-locator-by-code.request.dto';
import { GetLocatorByKeywordRequestDto } from './dto/request/get-locator-by-keyword.request.dto';
import { GetLocatorVirtualByWarehouseIdRequestDto } from './dto/request/get-locator-virtual-by-warehouse-id.request.dto';
import { GetLocatorDetailRequestDto } from './dto/request/get-locator.request.dto';
import { GetLocatorsRequestDto } from './dto/request/get-locators.request.dto';
import { RejectLocatorRequestDto } from './dto/request/reject-locator.request.dto';
import { UpdateLocatorRequestDto } from './dto/request/update-locator.request.dto';
import { LocatorResponseDto } from './dto/response/locator.response.dto';
import { LocatorRepositoryInterface } from './interface/locator.repository.interface';
import { LocatorServiceInterface } from './interface/locator.service.interface';
import {
  CAN_STATUS_CONFIRM_LOCATOR,
  CAN_STATUS_REJECT_LOCATOR,
  CHARACTER_MAP_LOCATION_CODE,
  CHARACTER_MAP_LOCATION_NAME,
  CHARACTER_MAP_LOCATION_PATH,
  LEVEL_ROOT,
  LocatorStatusEnum,
  LocatorTypeEnum,
} from './locator.constant';

@Injectable()
export class LocatorService implements LocatorServiceInterface {
  constructor(
    @Inject('LocatorRepositoryInterface')
    private readonly locatorRepository: LocatorRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    private readonly warehouseClientService: WarehouseClientService,

    private readonly itemClientService: ItemClientService,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async update(request: UpdateLocatorRequestDto): Promise<any> {
    const { id } = request;
    const locator = await this.locatorRepository.findOneById(id);
    if (!locator) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const body = { ...request };
    const bulkWrite: any = [
      {
        updateOne: {
          filter: { _id: id },
          update: { $set: body },
        },
      },
    ];

    const childRoots = await this.locatorRepository.findAllByCondition({
      mpath: { $regex: id },
      level: body.level + 1,
    });

    const childIdsUpdate: string[] = [];
    body.items.forEach((i) => {
      if (i.id) childIdsUpdate.push(i.id);
    });

    const childIdsDelete = [];
    childRoots.forEach((i) => {
      const id = i._id.toString();
      if (!childIdsUpdate.includes(id)) childIdsDelete.push(id);
    });

    if (childIdsDelete.length) {
      const locatorsDelete = await this.locatorRepository.findAllByCondition({
        mpath: { $regex: new RegExp(childIdsDelete.join('|'), 'g') },
      });
      const locatorIdsDelete = locatorsDelete.map((i) => i._id.toString());

      const itemsExist = await this.itemClientService.checkExistItemInLocator(
        locatorIdsDelete,
      );

      if (!isEmpty(itemsExist)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(this.i18n.translate('error.ITEMS_EXISTED_IN_LOCATOR'))
          .build();
      }

      bulkWrite.push({
        deleteMany: { filter: { _id: { $in: locatorIdsDelete } } },
      });
    }

    body.items.forEach((item) => {
      const { name, code, level } = item;
      const pathCode = `${locator.pathCode}${CHARACTER_MAP_LOCATION_CODE}${code}`;
      const pathName = `${locator.pathName}${CHARACTER_MAP_LOCATION_NAME}${name}`;
      if (!item.id) {
        const _id = new Types.ObjectId();
        bulkWrite.push({
          insertOne: {
            document: {
              ...item,
              _id,
              level,
              parentId: id,
              mpath:
                locator.mpath + CHARACTER_MAP_LOCATION_PATH + _id.toString(),
              name,
              code,
              pathCode,
              pathName,
              layoutId: locator.layoutId,
              rootId: locator.rootId,
              lengthUnit: locator.lengthUnit,
              weightUnit: locator.weightUnit,
            },
          },
        });
      } else
        bulkWrite.push({
          updateOne: {
            filter: { _id: item.id },
            update: {
              $set: {
                ...item,
                name,
                code,
                level,
                pathCode,
                pathName,
                parentId: id,
                updateBy: request.userId,
              },
            },
          },
        });
    });
    console.log(bulkWrite);
    const result = await this.locatorRepository.bulkWrite(bulkWrite);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(this.i18n.translate('error.SUCCESS'))
      .withData(result)
      .build();
  }

  async getDetail(request: GetLocatorDetailRequestDto): Promise<any> {
    const locator = await this.locatorRepository.findOneById(request.id);
    if (!locator) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const users = await this.userService.getUserByIds(
      [locator.createdBy],
      true,
    );

    const seralizeWarehouse = await this.warehouseClientService.getListByIds(
      [locator.rootId],
      true,
    );

    if (!isEmpty(users)) {
      locator.createdBy = users[locator.createdBy];
    }

    const response = plainToInstance(
      LocatorResponseDto,
      {
        ...locator,
        warehouse: seralizeWarehouse[locator.rootId],
      },
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getLocatorByLocatorId(locatorId: number): Promise<any> {
    const locator = await this.locatorRepository.getLocatorByLocatorId(
      locatorId,
    );
    if (!locator) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const users = await this.userService.getUserByIds(
      [locator.createdBy],
      true,
    );

    if (!isEmpty(users)) {
      locator.createdBy = users[locator.createdBy];
    }

    const response = plainToInstance(LocatorResponseDto, locator, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getMany(request: GetLocatorsRequestDto): Promise<any> {
    const { ids, warehouseId } = request;
    const locators = await this.locatorRepository.findManyBy({
      ids,
      warehouseId,
    });
    locators.forEach((i) => (i.id = i._id.toString()));

    return new ResponseBuilder(locators)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(request: GetListLocatorRequestDto): Promise<any> {
    const { page, sort, take, skip, itemIds, warehouseId } = request;
    let itemQuantityMap = {};

    if (!isEmpty(itemIds)) {
      const param: any = {
        itemIds,
      };
      if (warehouseId) {
        param.warehouseId = warehouseId;
      }
      const positionExistItems =
        await this.itemClientService.getPositionExistItems(param);
      request.locatorIds = map(positionExistItems, 'ticketLocatorId');
      itemQuantityMap = keyBy(positionExistItems, 'ticketLocatorId');
    }
    // eslint-disable-next-line prefer-const
    let { result, count } = await this.locatorRepository.getList(request);
    const userIds = uniq(result.map((item) => item.createdBy));
    let serializeUser;
    if (!isEmpty(userIds)) {
      serializeUser = await this.userService.getUserByIds(userIds, true);
    }
    const warehouseIds = uniq(map(result, 'rootId'));
    let serializeWarehouse;
    if (!isEmpty(warehouseIds)) {
      serializeWarehouse = await this.warehouseClientService.getListByIds(
        warehouseIds,
        true,
      );
    }
    result.forEach((item) => {
      item.createdBy = serializeUser[item.createdBy];
      item.warehouse = serializeWarehouse[item.rootId];
      item.stockQuantity = +itemQuantityMap[item.locatorId]?.quantity || 0;
    });

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const sort = item.order === 'ASC' ? 1 : -1;
        switch (item.column) {
          case 'warehouseCode':
            if (!isEmpty(result)) {
              result.sort((a, b) => {
                const codeA = a.warehouse.code,
                  codeB = b.warehouse.code;
                if (codeA < codeB) return -sort;
                if (codeA > codeB) return sort;
                return 0;
              });
              result = result.slice(skip, skip + take);
            }
            break;
          default:
            break;
        }
      });
    }
    const dataReturn = plainToInstance(
      LocatorResponseDto,
      request.isPutAway === 1
        ? result.filter((e) => e?.location !== null)
        : result,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async delete(request: DeleteLocatorRequestDto): Promise<any> {
    const { id } = request;
    const locator = await this.locatorRepository.findOneById(id);
    if (!locator) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(this.i18n.translate('error.LOCATOR_NOT_FOUND'))
        .build();
    }

    const locators = await this.locatorRepository.findAllByCondition({
      mpath: { $regex: `${id}` },
      level: { $gte: locator.level },
    });
    if (!locators || !locators.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const locatorIds = map(locators, '_id');

    const itemsExist = await this.itemClientService.checkExistItemInLocator(
      locatorIds,
    );

    if (itemsExist && !isEmpty(itemsExist)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(this.i18n.translate('error.ITEMS_EXISTED_IN_LOCATOR'))
        .build();
    }

    const result = await this.locatorRepository.deleteManyByCondition({
      ids: locatorIds,
    });

    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getLocatorByRootIds(
    rootIds: number[],
    locatorIds: number[],
    type?: number,
  ): Promise<any> {
    let filter: any = {
      rootId: { $in: rootIds },
    };
    if (locatorIds && !isEmpty(locatorIds)) {
      filter = {
        ...filter,
        locatorId: { $in: locatorIds },
      };
    }
    if (type !== undefined) {
      filter = {
        ...filter,
        type: { $in: type },
      };
    }
    const locators = await this.locatorRepository.findAllByCondition(filter);

    if (isEmpty(locators)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const response = plainToInstance(LocatorResponseDto, locators, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async createLocatorByWarehouse(
    request: CreateLocatorByWarehouseRequestDto,
  ): Promise<any> {
    const { warehouseId, name, code } = request;

    const locatorDocument = this.locatorRepository.createDocument({
      description: null,
    } as CreateLocatorRequestDto);
    locatorDocument.rootId = warehouseId;
    locatorDocument.name = name;
    locatorDocument.code = code;
    locatorDocument.level = LEVEL_ROOT;
    locatorDocument.mpath = null;
    locatorDocument.type = LocatorTypeEnum.VIRTUAL_LOCATION;
    try {
      await this.locatorRepository.create(locatorDocument);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(
          error?.message ||
            (await this.i18n.translate('error.INTERNAL_SERVER_ERROR')),
        )
        .build();
    }
  }

  async getLocatorByCode(payload: GetLocatorByCodeRequestDto): Promise<any> {
    const { code, warehouseId } = payload;
    const locator = await this.locatorRepository.getLocatorByCode(
      code,
      warehouseId,
    );
    if (!locator) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const users = await this.userService.getUserByIds(
      [locator?.createdBy],
      true,
    );

    if (!isEmpty(users)) {
      locator.createdBy = users[locator?.createdBy];
    }

    const response = plainToInstance(LocatorResponseDto, locator, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getLocatorByCodes(payload: any): Promise<any> {
    const { codes } = payload;
    const locators = await this.locatorRepository.findAllByCondition({
      code: { $in: codes },
    });

    const response = plainToInstance(LocatorResponseDto, locators, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getLocatorCodeKeyword(
    request: GetLocatorByKeywordRequestDto,
  ): Promise<any> {
    const warehouses = await this.locatorRepository.findLocatorByCodeKeyword(
      request,
    );

    const response = plainToInstance(LocatorResponseDto, warehouses, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async getLocatorVirtualByWarehouseId(
    request: GetLocatorVirtualByWarehouseIdRequestDto,
  ): Promise<any> {
    const { warehouseId } = request;
    const locator = await this.locatorRepository.findOneByCondition({
      rootId: warehouseId,
      type: LocatorTypeEnum.REAL_LOCATION,
    });

    if (!locator) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const response = plainToInstance(LocatorResponseDto, locator, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async confirm(request: ConfirmLocatorRequestDto): Promise<any> {
    const { id } = request;
    const locator = await this.locatorRepository.findOneById(id);
    if (!locator) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CAN_STATUS_CONFIRM_LOCATOR.includes(locator.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(this.i18n.translate('error.CAN_NOT_CHANGE_STATUS'))
        .build();
    }
    locator.status = LocatorStatusEnum.ACTIVE;
    try {
      await this.locatorRepository.findByIdAndUpdate(locator._id, locator);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .build();
    }
  }

  async reject(request: RejectLocatorRequestDto): Promise<any> {
    const { id } = request;
    const locator = await this.locatorRepository.findOneById(id);
    if (!locator) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CAN_STATUS_REJECT_LOCATOR.includes(locator.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(this.i18n.translate('error.CAN_NOT_CHANGE_STATUS'))
        .build();
    }
    locator.status = LocatorStatusEnum.INACTIVE;
    try {
      await this.locatorRepository.findByIdAndUpdate(locator._id, locator);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .build();
    }
  }

  async getLocatorsByRootId(rootId: number): Promise<any> {
    const locators = await this.locatorRepository.getLocatorsByRootId(rootId);
    if (!locators) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const response = plainToInstance(LocatorResponseDto, locators, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
