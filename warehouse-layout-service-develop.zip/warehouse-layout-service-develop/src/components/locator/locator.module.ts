import { ConfigService } from '@config/config.service';
import { Global, Module } from '@nestjs/common';
import { LocatorController } from './locator.controller';
import { LocatorService } from './locator.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { MongooseModule } from '@nestjs/mongoose';
import { LocatorSchema } from 'src/models/locator/locator.schema';
import { LocatorRepository } from 'src/repository/locator/locator.repository';

@Global()
@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'Locator', schema: LocatorSchema }]),
    UserModule,
  ],
  exports: [
    {
      provide: 'LocatorRepositoryInterface',
      useClass: LocatorRepository,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'LocatorRepositoryInterface',
      useClass: LocatorRepository,
    },
    {
      provide: 'LocatorServiceInterface',
      useClass: LocatorService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
  ],
  controllers: [LocatorController],
})
export class LocatorModule {}
