import { NATS_WAREHOUSE_LAYOUT } from '@config/nats.config';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import {
  DELETE_LOCATOR_PERMISSION,
  DETAIL_LOCATOR_PERMISSION,
  LIST_LOCATOR_PERMISSION,
  UPDATE_LOCATOR_PERMISSION,
} from '@utils/permissions/locator';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { IdParams } from 'src/common/swagger';
import {
  CONFIRM_LOCATOR_PERMISSION,
  REJECT_LOCATOR_PERMISSION,
} from './../../utils/permissions/locator';
import { ConfirmLocatorRequestDto } from './dto/request/confirm-locator.request.dto';
import { CreateLocatorByWarehouseRequestDto } from './dto/request/create-locator-by-warehouse.request.dto';
import { DeleteLocatorRequestDto } from './dto/request/delete-locator.request.dto';
import { GetDetailLocatorByLocatorIdRequestDto } from './dto/request/get-detail-locator-by-locator-id.request.dto';
import { GetListLocatorRequestDto } from './dto/request/get-list-locator.request.dto';
import { GetLocatorByCodeRequestDto } from './dto/request/get-locator-by-code.request.dto';
import { GetLocatorByKeywordRequestDto } from './dto/request/get-locator-by-keyword.request.dto';
import { GetLocatorVirtualByWarehouseIdRequestDto } from './dto/request/get-locator-virtual-by-warehouse-id.request.dto';
import { GetLocatorDetailRequestDto } from './dto/request/get-locator.request.dto';
import { GetLocatorsByRootIdRequestDto } from './dto/request/get-locators-by-root-id.request.dto';
import { GetLocatorsByRootIds } from './dto/request/get-locators-by-root-ids.request.dto';
import { GetLocatorsRequestDto } from './dto/request/get-locators.request.dto';
import { LocatorUpsertBody } from './dto/request/locator-upsert.body';
import { RejectLocatorRequestDto } from './dto/request/reject-locator.request.dto';
import { LocatorServiceInterface } from './interface/locator.service.interface';

@Controller('locators')
export class LocatorController {
  constructor(
    @Inject('LocatorServiceInterface')
    private readonly locatorService: LocatorServiceInterface,
  ) {}

  @MessagePattern(`${NATS_WAREHOUSE_LAYOUT}.create_locator_by_warehouse`)
  public async createLocatorByWarehouse(
    @Body() body: CreateLocatorByWarehouseRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locatorService.createLocatorByWarehouse(request);
  }

  @PermissionCode(UPDATE_LOCATOR_PERMISSION.code)
  @Put(':id')
  async update(@Param() param: IdParams, @Body() body: LocatorUpsertBody) {
    const {
      request: { id },
      responseError: paramError,
    } = param;
    if (paramError && !isEmpty(paramError)) {
      return paramError;
    }
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locatorService.update({ id, ...request });
  }

  @PermissionCode(LIST_LOCATOR_PERMISSION.code)
  @Get('list')
  public async getList(@Query() query: GetListLocatorRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locatorService.getList(request);
  }

  @PermissionCode(DETAIL_LOCATOR_PERMISSION.code)
  @Get('/:id')
  public async get(@Param() param: GetLocatorDetailRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locatorService.getDetail(request);
  }

  @PermissionCode(DELETE_LOCATOR_PERMISSION.code)
  @Delete('/:id')
  public async delete(@Param() param: DeleteLocatorRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locatorService.delete(request);
  }

  @MessagePattern(`${NATS_WAREHOUSE_LAYOUT}.get_locators`)
  public async getMany(@Body() query: GetLocatorsRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locatorService.getMany(request);
  }

  @MessagePattern(`${NATS_WAREHOUSE_LAYOUT}.get_locators_by_ids`)
  public async getLocatorsByIds(
    @Body() query: GetLocatorsRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locatorService.getMany(request);
  }

  @Get('/:locatorId/detail')
  @ApiOperation({
    tags: ['Locator'],
    summary: 'locator detail',
    description: 'Detail vị trí',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: SuccessResponse,
  })
  public async getDetail(
    @Param() param: GetDetailLocatorByLocatorIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locatorService.getLocatorByLocatorId(request.locatorId);
  }

  @MessagePattern(`${NATS_WAREHOUSE_LAYOUT}.get_detail`)
  public async getDetailTcp(
    @Body() param: GetDetailLocatorByLocatorIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locatorService.getLocatorByLocatorId(request.locatorId);
  }

  @Get('/detail/by-code')
  public async getLocatorByCode(
    @Query()
    payload: GetLocatorByCodeRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locatorService.getLocatorByCode({
      code: request.code,
    } as GetLocatorByCodeRequestDto);
  }

  @MessagePattern(`${NATS_WAREHOUSE_LAYOUT}.get_locator_by_code`)
  public async getLocatorByCodeTcp(
    @Body() payload: GetLocatorByCodeRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.locatorService.getLocatorByCode(request);
  }

  @MessagePattern(`${NATS_WAREHOUSE_LAYOUT}.get_locator_by_codes`)
  public async getLocatorByCodes(@Body() payload: any): Promise<any> {
    return await this.locatorService.getLocatorByCodes(payload);
  }

  @MessagePattern(`${NATS_WAREHOUSE_LAYOUT}.get_locators_by_root_ids`)
  public async getLocatorByRootIds(
    @Body() body: GetLocatorsByRootIds,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locatorService.getLocatorByRootIds(
      request.rootIds,
      request.locatorIds,
      request.type,
    );
  }

  @MessagePattern(`${NATS_WAREHOUSE_LAYOUT}.get_locators_by_root_id`)
  public async getLocatorsByRootIdTcp(
    @Body() body: GetLocatorsByRootIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locatorService.getLocatorsByRootId(request.rootId);
  }

  @MessagePattern(`${NATS_WAREHOUSE_LAYOUT}.get_locator_by_keyword`)
  public async getItemByConditions(
    @Body() payload: GetLocatorByKeywordRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locatorService.getLocatorCodeKeyword(request);
  }

  @MessagePattern(
    `${NATS_WAREHOUSE_LAYOUT}.get_locator_virtual_by_warehouse_id`,
  )
  public async getLocatorVirtualByWarehouseId(
    @Body() payload: GetLocatorVirtualByWarehouseIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locatorService.getLocatorVirtualByWarehouseId(request);
  }

  @Get('/list/key')
  public async getItemByConditionsTcp(
    @Query() payload: GetLocatorByKeywordRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.locatorService.getLocatorCodeKeyword(request);
  }

  @PermissionCode(CONFIRM_LOCATOR_PERMISSION.code)
  @Put(':id/confirm')
  @ApiOperation({
    tags: ['Locator'],
    summary: 'locator Confirm',
    description: 'Active vị trí',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: SuccessResponse,
  })
  async confirm(@Param() param: ConfirmLocatorRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locatorService.confirm(request);
  }

  @PermissionCode(REJECT_LOCATOR_PERMISSION.code)
  @Put(':id/reject')
  @ApiOperation({
    tags: ['Locator'],
    summary: 'locator Reject',
    description: 'Reject vị trí',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: SuccessResponse,
  })
  async reject(@Param() param: RejectLocatorRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.locatorService.reject(request);
  }
}
