import { UserBasicResponseDto } from '@components/user/dto/response/user.basic.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { WarehouseResponseDto } from 'src/modules/nats-client/warehouse/dto/response/warehouse.response.dto';

export class LocatorResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  pathName: string;

  @ApiProperty()
  @Expose()
  pathCode: string;

  @ApiProperty()
  @Expose()
  level: number;

  @ApiProperty()
  @Expose()
  locatorId: number;

  @ApiProperty()
  @Expose()
  rootId: number;

  @ApiProperty()
  @Expose()
  locationId: number;

  @ApiProperty()
  @Expose()
  stockQuantity: number;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty({ type: UserBasicResponseDto })
  @Expose()
  @Type(() => UserBasicResponseDto)
  createdBy: UserBasicResponseDto;

  @ApiProperty({ type: UserBasicResponseDto })
  @Expose()
  @Type(() => UserBasicResponseDto)
  updatedBy: UserBasicResponseDto;

  @ApiProperty({ type: WarehouseResponseDto })
  @Expose()
  @Type(() => WarehouseResponseDto)
  warehouse: WarehouseResponseDto;

  @ApiProperty()
  @Expose()
  length: number;

  @ApiProperty()
  @Expose()
  width: number;

  @ApiProperty()
  @Expose()
  height: number;

  @ApiProperty()
  @Expose()
  weight: number;

  @ApiProperty()
  @Expose()
  lengthUnit: number;

  @ApiProperty()
  @Expose()
  weightUnit: number;
}
