import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId } from 'class-validator';

export class FindIdLocatorRequestDto extends BaseDto {
  @ApiProperty()
  @IsMongoId()
  id: string;
}
