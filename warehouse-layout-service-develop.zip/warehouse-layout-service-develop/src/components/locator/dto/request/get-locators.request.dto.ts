import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsArray, IsOptional } from 'class-validator';
import { BaseDto } from '../../../../core/dto/base.dto';

export class GetLocatorsRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  ids: string[];

  @ApiPropertyOptional()
  @IsOptional()
  warehouseId: number;
}
