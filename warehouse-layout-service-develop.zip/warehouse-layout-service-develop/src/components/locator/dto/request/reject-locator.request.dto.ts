import { FindIdLocatorRequestDto } from './find-id-locator.request.dto';
export class RejectLocatorRequestDto extends FindIdLocatorRequestDto {}
