import { LOCATOR_RULES } from '@components/locator/locator.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsPositive, IsString, MaxLength } from 'class-validator';

export class CreateLocatorByWarehouseRequestDto extends BaseDto {
  @ApiProperty()
  @IsPositive()
  @IsNotEmpty()
  warehouseId: number;

  @ApiProperty()
  @MaxLength(LOCATOR_RULES.NAME.MAX_LENGTH)
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty()
  @MaxLength(LOCATOR_RULES.CODE.MAX_LENGTH)
  @IsString()
  @IsNotEmpty()
  code: string;
}
