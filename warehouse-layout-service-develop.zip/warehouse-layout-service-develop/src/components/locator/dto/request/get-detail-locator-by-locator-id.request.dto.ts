import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';

export class GetDetailLocatorByLocatorIdRequestDto extends BaseDto {
  @ApiProperty()
  @Transform((obj) => Number(obj.value))
  locatorId: number;
}
