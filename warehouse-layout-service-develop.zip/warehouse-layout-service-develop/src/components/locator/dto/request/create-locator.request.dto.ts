import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsInt,
  IsMongoId,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  Min,
} from 'class-validator';
import { LocatorUpsertBody } from './locator-upsert.body';

export class CreateLocatorRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @IsMongoId()
  id: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  @MaxLength(20)
  code: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  name: string;

  @ApiProperty()
  @IsOptional()
  warehouseId: number;

  @ApiProperty()
  @IsString()
  @IsOptional()
  @MaxLength(255)
  description: string;

  @ApiProperty()
  @IsInt()
  @Min(0)
  level: number;

  @ApiProperty()
  @IsOptional()
  length: number;

  @ApiProperty()
  @IsOptional()
  width: number;

  @ApiProperty()
  @IsOptional()
  height: number;

  @ApiProperty()
  @IsOptional()
  weight: number;

  @ApiProperty()
  @IsOptional()
  layoutType: number;

  @ApiProperty()
  @IsOptional()
  items: LocatorUpsertBody[];
}
