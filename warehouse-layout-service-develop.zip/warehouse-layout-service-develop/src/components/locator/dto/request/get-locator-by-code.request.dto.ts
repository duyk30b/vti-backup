import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { BaseDto } from '@core/dto/base.dto';
import { IsInt, IsOptional, IsString } from 'class-validator';

export class GetLocatorByCodeRequestDto extends BaseDto {
  @ApiProperty()
  @IsString()
  code: string;

  @ApiPropertyOptional()
  @IsInt()
  @IsOptional()
  warehouseId: number;
}
