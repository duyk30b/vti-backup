import { BaseDto } from '../../../../core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { ArrayNotEmpty, IsInt } from 'class-validator';

export class CloneLocatorWarehouseRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  sourceWarehouseId: number;

  @ApiProperty()
  @IsInt()
  destinationWarehouseId: number;

  @ApiProperty()
  @ArrayNotEmpty()
  locatorIds: number[];
}
