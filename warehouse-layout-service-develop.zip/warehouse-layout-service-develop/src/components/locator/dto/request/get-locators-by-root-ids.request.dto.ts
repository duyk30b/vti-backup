import { LocatorTypeEnum } from './../../locator.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsArray, IsEnum, IsOptional } from 'class-validator';

export class GetLocatorsByRootIds extends BaseDto {
  @ApiProperty()
  @IsArray()
  rootIds: number[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  locatorIds: number[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(LocatorTypeEnum)
  type: number;
}
