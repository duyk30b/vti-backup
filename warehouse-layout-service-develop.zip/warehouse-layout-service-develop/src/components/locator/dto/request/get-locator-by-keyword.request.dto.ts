import { BaseDto } from '@core/dto/base.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional } from 'class-validator';

export class GetLocatorByKeywordRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsOptional()
  locatorCodeKeyword: string;

  @ApiPropertyOptional()
  @IsOptional()
  rootId: number[];

  @ApiPropertyOptional()
  @IsOptional()
  locatorIds: number[];
}
