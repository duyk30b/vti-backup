import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateLocatorRequestDto } from './create-locator.request.dto';

export class UpdateLocatorBodyDto extends CreateLocatorRequestDto {}

export class UpdateLocatorRequestDto extends UpdateLocatorBodyDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  id: string;
}
