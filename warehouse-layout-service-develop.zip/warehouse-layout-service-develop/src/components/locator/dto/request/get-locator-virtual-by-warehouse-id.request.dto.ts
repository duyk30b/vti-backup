import { ApiProperty } from '@nestjs/swagger';
import { IsInt } from 'class-validator';
import { BaseDto } from './../../../../core/dto/base.dto';
export class GetLocatorVirtualByWarehouseIdRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  warehouseId: number;
}
