import { FindIdLocatorRequestDto } from './find-id-locator.request.dto';
export class ConfirmLocatorRequestDto extends FindIdLocatorRequestDto {}
