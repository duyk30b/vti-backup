import { IsActionEnum } from '@constant/common';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { Transform } from 'class-transformer';
import { IsOptional, IsEnum, IsArray } from 'class-validator';
import { isJson } from 'src/helper/string.helper';

export class GetListLocatorRequestDto extends PaginationQuery {
  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll: string;

  @ApiPropertyOptional()
  @IsEnum(IsActionEnum)
  @Transform(({ value }) => +value)
  @IsOptional()
  isImport: IsActionEnum;

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => {
    if (typeof value !== 'string') return value;

    if (value) value = value.replace(/\\/g, '');

    if (isJson(value)) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    }
  })
  locatorIds: number[];

  @ApiPropertyOptional()
  @IsArray()
  @Transform((data) => {
    return data.value
      .split(',')
      .map((e) => Number(e))
      .filter((e) => Number.isInteger(e));
  })
  @IsOptional()
  itemIds: number[];

  @ApiPropertyOptional()
  @Transform(({ value }) => +value)
  @IsOptional()
  warehouseId: number;

  @ApiPropertyOptional()
  @Transform(({ value }) => +value)
  @IsOptional()
  isPutAway: number;
}
