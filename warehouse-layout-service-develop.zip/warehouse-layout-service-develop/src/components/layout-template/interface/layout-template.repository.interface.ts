import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { LayoutTemplate } from 'src/models/layout-template/layout-template.schema';
import { CreateLayoutTemplateRequestDto } from '../dto/request/create-template-layout.request.dto';
import { GetLayoutTemplateListRequestDto } from '../dto/request/get-template-layout-list.request.dto';
export interface LayoutTemplateRepositoryInterface
  extends BaseAbstractRepository<LayoutTemplate> {
  createDocument(request: CreateLayoutTemplateRequestDto): LayoutTemplate;
  updateDocument(layoutTemplate: LayoutTemplate, request: any): LayoutTemplate;
  getList(request: GetLayoutTemplateListRequestDto): Promise<any>;
  deleteManyByCondition(condition: any): Promise<any>;
}
