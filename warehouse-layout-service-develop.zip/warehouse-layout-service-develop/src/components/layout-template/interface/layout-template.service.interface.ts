import { CreateLayoutTemplateRequestDto } from '../dto/request/create-template-layout.request.dto';
import { DeleteLayoutTemplateRequestDto } from '../dto/request/delete-template-layout.request.dto';
import { GetLayoutTemplateListRequestDto } from '../dto/request/get-template-layout-list.request.dto';
import { UpdateLayoutTemplateRequestDto } from '../dto/request/update-template-layout.request.dto';
import { DeleteMultipleDto, DetailRequestDto } from '@utils/common.request.dto';

export interface LayoutTemplateServiceInterface {
  create(request: CreateLayoutTemplateRequestDto): Promise<any>;
  getList(request: GetLayoutTemplateListRequestDto): Promise<any>;
  getDetail(request: DetailRequestDto): Promise<any>;
  update(request: UpdateLayoutTemplateRequestDto): Promise<any>;
  delete(request: DeleteLayoutTemplateRequestDto): Promise<any>;
  deleteMultiple(request: DeleteMultipleDto): Promise<any>;
}
