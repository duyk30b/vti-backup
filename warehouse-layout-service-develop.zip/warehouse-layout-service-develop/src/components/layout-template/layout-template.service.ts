import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { isEmpty, map, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { LayoutTemplate } from 'src/models/layout-template/layout-template.schema';
import { CreateLayoutTemplateRequestDto } from './dto/request/create-template-layout.request.dto';
import { DeleteLayoutTemplateRequestDto } from './dto/request/delete-template-layout.request.dto';
import { GetLayoutTemplateListRequestDto } from './dto/request/get-template-layout-list.request.dto';
import { UpdateLayoutTemplateRequestDto } from './dto/request/update-template-layout.request.dto';
import { LayoutTemplateResponseDto } from './dto/response/template-layout.response.dto';
import { LayoutTemplateRepositoryInterface } from './interface/layout-template.repository.interface';
import { LayoutTemplateServiceInterface } from './interface/layout-template.service.interface';
import { DeleteMultipleDto, DetailRequestDto } from '@utils/common.request.dto';

@Injectable()
export class LayoutTemplateService implements LayoutTemplateServiceInterface {
  constructor(
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('LayoutTemplateRepositoryInterface')
    private readonly layoutTemplateRepository: LayoutTemplateRepositoryInterface,
    private readonly i18n: I18nRequestScopeService,
  ) {}

  async update(request: UpdateLayoutTemplateRequestDto): Promise<any> {
    const { id } = request;

    const layoutTemplate = await this.layoutTemplateRepository.findOneById(id);
    if (!layoutTemplate) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const result = await this.validateLayoutTemplate(request, id);
    if (result.statusCode !== ResponseCodeEnum.SUCCESS) {
      return result;
    }

    const updateTemplate = this.layoutTemplateRepository.updateDocument(
      layoutTemplate,
      request,
    );
    return await this.save(updateTemplate, true);
  }

  async delete(request: DeleteLayoutTemplateRequestDto): Promise<any> {
    const { id } = request;
    const layoutTemplate = await this.layoutTemplateRepository.findOneById(id);
    if (!layoutTemplate) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    try {
      await this.layoutTemplateRepository.deleteByCondition({ _id: id });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate('error.DELETE_LAYOUT_TEMPLATE_SUCCESS'),
        )
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    try {
      const { ids } = request;
      const layoutTemplates =
        await this.layoutTemplateRepository.findAllByCondition({
          _id: { $in: ids },
        });

      if (!layoutTemplates || layoutTemplates.length != uniq(ids).length) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }

      await this.layoutTemplateRepository.deleteManyByCondition({
        _id: { $in: ids },
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate('error.DELETE_LAYOUT_TEMPLATE_SUCCESS'),
        )
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getDetail(request: DetailRequestDto): Promise<any> {
    const layoutTemplate = await this.layoutTemplateRepository.findOneById(
      request.id,
    );

    if (!layoutTemplate) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (layoutTemplate.createdBy) {
      const user = await this.userService.getUserById(layoutTemplate.createdBy);
      layoutTemplate.createdBy = user;
    }
    const response = plainToInstance(
      LayoutTemplateResponseDto,
      layoutTemplate,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  async create(request: CreateLayoutTemplateRequestDto): Promise<any> {
    const result = await this.validateLayoutTemplate(request);

    if (result.statusCode !== ResponseCodeEnum.SUCCESS) {
      return result;
    }

    const layoutTemplate =
      this.layoutTemplateRepository.createDocument(request);
    return await this.save(layoutTemplate);
  }

  async save(layoutTemplate: LayoutTemplate, isUpdate = false): Promise<any> {
    try {
      let result;
      if (isUpdate) {
        result = await this.layoutTemplateRepository.findByIdAndUpdate(
          layoutTemplate._id,
          layoutTemplate,
        );
      } else {
        result = await this.layoutTemplateRepository.create(layoutTemplate);
      }
      const response = plainToInstance(LayoutTemplateResponseDto, result, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            isUpdate
              ? 'error.UPDATE_LAYOUT_TEMPLATE_SUCCESS'
              : 'error.CREATE_LAYOUT_TEMPLATE_SUCCESS',
          ),
        )
        .withData(response)
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async validateLayoutTemplate(
    layoutTemplate: CreateLayoutTemplateRequestDto,
    idLayoutTemplate?: string,
  ) {
    let condition = {};
    if (idLayoutTemplate) {
      condition = {
        name: layoutTemplate.name,
        _id: { $ne: idLayoutTemplate },
      };
    } else {
      condition = {
        name: layoutTemplate.name,
      };
    }
    const layoutTemplateExist =
      await this.layoutTemplateRepository.findOneByCondition(condition);

    // Tên đã tồn tại
    if (layoutTemplateExist) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.LAYOUT_TEMPLATE_NAME_ALREADY_EXIST'),
        )
        .build();
    }

    const quantityLevel1 = layoutTemplate?.items[0]?.['quantity'];
    // Chỉ có một cấp một
    if (quantityLevel1 > 1) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.QUANTITY_MUST_EQUAL_ONE'))
        .build();
    }

    const items = layoutTemplate.items;

    for (let i = 0; i < items.length; i++) {
      let areaBef = 0;
      let heightBef = 0;
      let weightBef = 0;

      if (i > 0) {
        for (let j = i - 1; j > -1; j--) {
          areaBef = items[j]['length'] * items[j]['width'];
          heightBef = items[j]['height'];
          weightBef = items[j]['weight'];
          // Nếu cấp trước đó có đủ dữ liệu kích thước, trọng tải thì dừng lại
          if (areaBef > 0 && heightBef > 0 && weightBef > 0) {
            break;
          }
        }
      }

      const areaI = items[i]['length'] * items[i]['width'];
      const heightI = items[i]['height'];
      const quantityI = items[i]['quantity'];
      const weightI = items[i]['weight'];
      const weightAll = weightI * quantityI;

      if (items[i]['layoutType'] === 1) {
        const areaAll = areaI * quantityI;
        if (areaBef > 0) {
          if (areaAll > areaBef) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(await this.i18n.translate('error.TOO_WIDE'))
              .build();
          }
        }
        if (heightBef > 0) {
          if (heightI > heightBef) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(await this.i18n.translate('error.TOO_HIGH'))
              .build();
          }
        }
      } else {
        const heightAll = heightI * quantityI;
        if (areaBef > 0) {
          if (areaI > areaBef) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(await this.i18n.translate('error.TOO_WIDE'))
              .build();
          }
        }
        if (heightBef > 0) {
          if (heightAll > heightBef) {
            return new ResponseBuilder()
              .withCode(ResponseCodeEnum.BAD_REQUEST)
              .withMessage(await this.i18n.translate('error.TOO_HIGH'))
              .build();
          }
        }
      }
      if (weightBef > 0) {
        if (weightAll > weightBef) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(await this.i18n.translate('error.TOO_HEAVY'))
            .build();
        }
      }
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(request: GetLayoutTemplateListRequestDto): Promise<any> {
    const { page } = request;
    const { result, count } = await this.layoutTemplateRepository.getList(
      request,
    );
    const userIds = uniq(map(result, 'createdBy'));

    if (!isEmpty(userIds)) {
      const users = await this.userService.getUserByIds(userIds, true);
      result.forEach((item) => {
        item.createdBy = users[item.createdBy];
      });
    }

    const dataReturn = plainToInstance(LayoutTemplateResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
