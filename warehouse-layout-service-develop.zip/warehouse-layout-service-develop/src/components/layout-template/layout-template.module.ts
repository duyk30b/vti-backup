import { UserService } from '@components/user/user.service';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { LayoutTemplateSchema } from 'src/models/layout-template/layout-template.schema';
import { LayoutTemplateRepository } from 'src/repository/layout-template/layout-template.repository';
import { LayoutTemplateController } from './layout-template.controller';
import { LayoutTemplateService } from './layout-template.service';
import { LayoutSchema } from '@models/layout/layout.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'LayoutTemplate', schema: LayoutTemplateSchema },
      { name: 'Layout', schema: LayoutSchema },
    ]),
  ],
  controllers: [LayoutTemplateController],
  providers: [
    {
      provide: 'LayoutTemplateRepositoryInterface',
      useClass: LayoutTemplateRepository,
    },
    {
      provide: 'LayoutTemplateServiceInterface',
      useClass: LayoutTemplateService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
  ],
  exports: [
    MongooseModule,
    {
      provide: 'LayoutTemplateRepositoryInterface',
      useClass: LayoutTemplateRepository,
    },
    {
      provide: 'LayoutTemplateServiceInterface',
      useClass: LayoutTemplateService,
    },
  ],
})
export class LayoutTemplateModule {}
