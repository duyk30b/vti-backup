export const LAYOUT_TEMPLATE_RULES = {
  CODE: {
    MAX_LENGTH: 50,
    COLUMN: 'code',
  },
  NAME: {
    MAX_LENGTH: 50,
    COLUMN: 'name',
    REGEX:
      /^[a-zA-ZÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀỀỂẾưăạảấầẩẫậắằẳẵặẹẻẽềềểếỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợụủứừỬỮỰỲỴÝỶỸửữựỳỵỷỹ 0-9]+$/,
  },
};

export enum LAYOUT_TYPE_ENUM {
  FLAT,
  STACK,
}
