import { UserBasicResponseDto } from '@components/user/dto/response/user.basic.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

export class LayoutTemplateLevelResponseDto {
  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  length: number;

  @ApiProperty()
  @Expose()
  width: number;

  @ApiProperty()
  @Expose()
  height: number;

  @ApiProperty()
  @Expose()
  weight: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  layoutType: number;

  @ApiProperty()
  @Expose()
  level: number;
}

export class LayoutTemplateResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  lengthUnit: number;

  @ApiProperty()
  @Expose()
  weightUnit: number;

  @ApiProperty({ type: LayoutTemplateLevelResponseDto, isArray: true })
  @Expose()
  @Type(() => LayoutTemplateLevelResponseDto)
  items: LayoutTemplateLevelResponseDto[];

  @ApiProperty({ type: UserBasicResponseDto })
  @Expose()
  @Type(() => UserBasicResponseDto)
  createdBy: UserBasicResponseDto;

  @ApiProperty({ type: UserBasicResponseDto })
  @Expose()
  @Type(() => UserBasicResponseDto)
  updatedBy: UserBasicResponseDto;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  weight: number;

  @ApiProperty()
  @Expose()
  levelCnt: number;
}
