import {
  LAYOUT_TEMPLATE_RULES,
  LAYOUT_TYPE_ENUM,
} from '@components/layout-template/layout-template.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  ArrayNotEmpty,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';

export class LevelDto {
  @ApiProperty()
  @IsString()
  @MaxLength(LAYOUT_TEMPLATE_RULES.CODE.MAX_LENGTH)
  code: string;

  @ApiProperty()
  @IsString()
  @MaxLength(LAYOUT_TEMPLATE_RULES.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  length: number;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  width: number;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  height: number;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  weight: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  quantity: number;

  @ApiProperty()
  @IsEnum(LAYOUT_TYPE_ENUM)
  @IsNotEmpty()
  layoutType: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  level: number;
}

export class CreateLayoutTemplateRequestDto extends BaseDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  @MaxLength(LAYOUT_TEMPLATE_RULES.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  lengthUnit: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  weightUnit: number;

  @ApiProperty({ type: LevelDto, isArray: true })
  @ArrayNotEmpty()
  @ValidateNested({ each: true })
  items: LevelDto[];
}
