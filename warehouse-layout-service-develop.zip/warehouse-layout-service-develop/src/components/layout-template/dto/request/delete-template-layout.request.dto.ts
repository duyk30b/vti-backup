import { DetailRequestDto } from '@utils/common.request.dto';
export class DeleteLayoutTemplateRequestDto extends DetailRequestDto {}
