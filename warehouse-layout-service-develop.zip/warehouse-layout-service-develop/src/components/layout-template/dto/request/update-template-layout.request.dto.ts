import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateLayoutTemplateRequestDto } from './create-template-layout.request.dto';

export class UpdateLayoutTemplateBodyDto extends CreateLayoutTemplateRequestDto {}

export class UpdateLayoutTemplateRequestDto extends UpdateLayoutTemplateBodyDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  id: string;
}
