import { BaseResponseDto } from '@core/dto/base.response.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateLayoutTemplateRequestDto } from './dto/request/create-template-layout.request.dto';
import { DeleteLayoutTemplateRequestDto } from './dto/request/delete-template-layout.request.dto';
import { GetLayoutTemplateListRequestDto } from './dto/request/get-template-layout-list.request.dto';
import { UpdateLayoutTemplateBodyDto } from './dto/request/update-template-layout.request.dto';
import { LayoutTemplateResponseDto } from './dto/response/template-layout.response.dto';
import { LayoutTemplateServiceInterface } from './interface/layout-template.service.interface';
import { DeleteMultipleDto, DetailRequestDto } from '@utils/common.request.dto';

@Controller('layout-template')
export class LayoutTemplateController {
  constructor(
    @Inject('LayoutTemplateServiceInterface')
    private readonly layoutTemplateService: LayoutTemplateServiceInterface,
  ) {}

  @Post()
  @ApiOperation({
    tags: ['Layout Template'],
    summary: 'Create Layout Template',
    description: 'Tạo layout mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: BaseResponseDto,
  })
  async create(@Body() body: CreateLayoutTemplateRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.layoutTemplateService.create(request);
  }

  @Put(':id')
  @ApiOperation({
    tags: ['Layout Template'],
    summary: 'Layout Template Update',
    description: 'Cập nhật layout mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: LayoutTemplateResponseDto,
  })
  async update(
    @Param() param: DetailRequestDto,
    @Body() body: UpdateLayoutTemplateBodyDto,
  ): Promise<any> {
    const {
      request: { id },
      responseError: paramError,
    } = param;
    const { request, responseError } = body;
    if (paramError && !isEmpty(paramError)) {
      return responseError;
    }
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.layoutTemplateService.update({ ...request, id });
  }

  @Get()
  @ApiOperation({
    tags: ['Layout Template'],
    summary: 'Layout Template List',
    description: 'Danh sách layout mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: LayoutTemplateResponseDto,
  })
  async getList(@Query() query: GetLayoutTemplateListRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.layoutTemplateService.getList(request);
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['Layout Template'],
    summary: 'Layout Template Details',
    description: 'Chi tiết layout mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: LayoutTemplateResponseDto,
  })
  async getDetail(@Param() param: DetailRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.layoutTemplateService.getDetail(request);
  }

  @Delete(':id')
  @ApiOperation({
    tags: ['Layout Template'],
    summary: 'Layout Template Delete',
    description: 'Xóa layout mẫu',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: SuccessResponse,
  })
  async delete(@Param() param: DeleteLayoutTemplateRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.layoutTemplateService.delete(request);
  }

  @Delete('/multiple')
  @ApiOperation({
    tags: ['Layout Template'],
    summary: 'Delete multiple layout template',
    description: 'Xóa nhiều layout template',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deleteMultiple(@Query() query: DeleteMultipleDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.layoutTemplateService.deleteMultiple(request);
  }
}
