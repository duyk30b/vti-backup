/* eslint-disable @typescript-eslint/no-unused-vars */
import { QUEUES_NAME_ENUM } from '@constant/common';
import { InjectQueue } from '@nestjs/bull';
import { NotFoundException } from '@nestjs/common';
import Queue from 'bull';
import { isEmpty, first, has, values } from 'lodash';
import { DeleteJobRequestDto } from './dto/request/delete-job.request.dto';
import { GetDetailJobRequestDto } from './dto/request/get-detail-job.request.dto';
import { GetListJobQueueMonitorRequestDto } from './dto/request/get-list-job-queue-monitor.request.dto';
import { UpdateJobRequestDto } from './dto/request/update-job.request.dto';

export class MonitorQueueService {
  serializeQueue: Queue = {};
  constructor(
    @InjectQueue(QUEUES_NAME_ENUM.SYNC_DATA_QUEUE)
    private syncDataQueue: Queue,
  ) {
    this.serializeQueue[QUEUES_NAME_ENUM.SYNC_DATA_QUEUE] = this.syncDataQueue;
  }

  public async getListJob(
    request: GetListJobQueueMonitorRequestDto,
  ): Promise<any> {
    const queue = this.getQueueCurrent();
  }

  public async getDetailJob(request: GetDetailJobRequestDto): Promise<any> {
    const queue = this.getQueueCurrent();
  }
  public async updateJob(request: UpdateJobRequestDto): Promise<any> {
    const queue = this.getQueueCurrent();
  }
  public async deleteJob(request: DeleteJobRequestDto): Promise<any> {
    const queue = this.getQueueCurrent() as Queue;
  }

  protected getQueueCurrent(queueName?: string): Queue | any {
    if (isEmpty(this.serializeQueue)) {
      throw new NotFoundException();
    }
    if (!queueName) {
      return first(values(this.serializeQueue));
    }
    if (!has(this.serializeQueue, queueName)) {
      throw new NotFoundException();
    }
    return this.serializeQueue[queueName];
  }
}
