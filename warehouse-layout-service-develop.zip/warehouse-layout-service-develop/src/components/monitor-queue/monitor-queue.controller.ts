import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Put,
  Query,
} from '@nestjs/common';
import { GetListJobQueueMonitorRequestDto } from './dto/request/get-list-job-queue-monitor.request.dto';
import { MonitorQueueServiceInterface } from './interface/monitor-queue.service.interface';
import { isEmpty } from 'lodash';
import { GetDetailJobRequestDto } from './dto/request/get-detail-job.request.dto';
import { DeleteJobRequestDto } from './dto/request/delete-job.request.dto';
import { UpdateJobRequestDto } from './dto/request/update-job.request.dto';

@Controller('monitor-queues')
export class MonitorQueueController {
  constructor(
    @Inject('MonitorQueueServiceInterface')
    private readonly monitorQueueService: MonitorQueueServiceInterface,
  ) {}

  @Get('list')
  public async getListJob(
    @Query() payload: GetListJobQueueMonitorRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return this.monitorQueueService.getListJob(request);
  }

  @Delete(':id')
  public async deleteJob(@Query() payload: DeleteJobRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return this.monitorQueueService.deleteJob(request);
  }

  @Get(':id')
  public async getDetailJob(
    @Param() payload: GetDetailJobRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return this.monitorQueueService.getDetailJob(request);
  }

  @Put(':id')
  public async updateJob(@Body() payload: UpdateJobRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return this.monitorQueueService.updateJob(request);
  }
}
