import { LayoutTemplateRepositoryInterface } from '@components/layout-template/interface/layout-template.repository.interface';
import { LocatorRepositoryInterface } from '@components/locator/interface/locator.repository.interface';
import {
  CHARACTER_MAP_LOCATION_CODE,
  CHARACTER_MAP_LOCATION_NAME,
  CHARACTER_MAP_LOCATION_PATH,
} from '@components/locator/locator.constant';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/mongoose';
import { DeleteMultipleDto } from '@utils/common.request.dto';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { isEmpty, map, padStart, uniq } from 'lodash';
import { Connection, Types } from 'mongoose';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { Layout } from 'src/models/layout/layout.schema';
import { ItemClientService } from 'src/modules/nats-client/item/item.client.service';
import { WarehouseClientService } from 'src/modules/nats-client/warehouse/warehouse-client.service';
import { CreateLayoutRequestDto } from './dto/request/create-layout.request.dto';
import { DeleteLayoutRequestDto } from './dto/request/delete-layout.request.dto';
import { GetLayoutDetailsRequestDto } from './dto/request/get-layout-details.request.dto';
import { GetLayoutListRequestDto } from './dto/request/get-layout-list.request.dto';
import { UpdateLayoutRequestDto } from './dto/request/update-layout.request.dto';
import { LayoutResponseDto } from './dto/response/layout.response.dto';
import { LayoutRepositoryInterface } from './interface/layout.repository.interface';
import { LayoutServiceInterface } from './interface/layout.service.interface';

@Injectable()
export class LayoutService implements LayoutServiceInterface {
  constructor(
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('LayoutTemplateRepositoryInterface')
    private readonly layoutTemplateRepository: LayoutTemplateRepositoryInterface,

    @Inject('LayoutRepositoryInterface')
    private readonly layoutRepository: LayoutRepositoryInterface,

    @Inject('LocatorRepositoryInterface')
    private readonly locatorRepository: LocatorRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,

    private readonly warehouseClientService: WarehouseClientService,

    private readonly itemClientService: ItemClientService,

    @InjectConnection()
    private readonly connection: Connection,
  ) {}

  async create(request: CreateLayoutRequestDto): Promise<any> {
    const { warehouseId, layoutTemplateId, items } = request;

    const warehouse = await this.warehouseClientService.getDetail(warehouseId);
    if (!warehouse) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
        .build();
    }

    // Check duplicate code in the same warehouse
    const layoutExist = await this.layoutRepository.findOneByCondition({
      code: request.code,
      warehouseId,
    });

    if (!isEmpty(layoutExist)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.LAYOUT_CODE_ALREADY_EXISTS'),
        )
        .build();
    }

    if (layoutTemplateId) {
      const layoutTemplate = await this.layoutTemplateRepository.findOneById(
        layoutTemplateId,
      );
      if (!layoutTemplate) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.TEMPLATE_LAYOUT_NOT_FOUND'),
          )
          .build();
      }
    }

    // === create all layout ===
    const arrLayoutDto: Partial<Layout>[] = [];
    for (let i = 0; i < request.quantity; i++) {
      let code = request.code;
      if (i !== 0) code += padStart(i.toString(), 2, '0');
      arrLayoutDto.push({
        ...request,
        code,
        createdBy: request.userId,
      });
    }
    const layouts = await this.layoutRepository.createMany(arrLayoutDto);
    layouts.forEach((i) => (i.id = i._id.toString()));

    // === create all locator ===
    const arrLocator = [];
    for (let l = 0; l < layouts.length; l++) {
      arrLocator[l] = [];
      const layoutId = layouts[l]._id.toString();

      for (let floor = 0; floor < items.length; floor++) {
        arrLocator[l][floor] = [];
        if (floor === 0) {
          // Tang 1: name va code la cua layout, quantity = 1
          const _id = new Types.ObjectId();
          const mpath = _id.toString();

          arrLocator[l][floor].push({
            _id,
            ...items[floor],
            layoutId,
            mpath,
            name: `${items[floor].name}${l + 1}`, // name = vị trí cấp 1 + số layout
            code: `${items[floor].code}${l + 1}`, // code = vị trí cấp 1 + số layout
            pathCode: `${items[floor].code}${l + 1}`,
            pathName: `${items[floor].name}${l + 1}`,
            rootId: request.warehouseId,
            lengthUnit: request.lengthUnit,
            weightUnit: request.weightUnit,
          });
        } else {
          // loop for each locator lv2,lv3,.. with code
          for (let i = 0; i < items[floor].quantity; i++) {
            for (let j = 0; j < arrLocator[l][floor - 1].length; j++) {
              const parentLocator = arrLocator[l][floor - 1][j];
              const append = padStart((i + 1).toString(), 2, '0');
              const { _id: parentId, mpath: parentMpath } = parentLocator;

              const _id = new Types.ObjectId();
              const mpath = `${parentMpath}${CHARACTER_MAP_LOCATION_PATH}${_id.toString()}`;

              const code = `${items[floor].code + append}`;
              const name = `${items[floor].name + append}`;
              const pathCode = `${parentLocator.pathCode}${CHARACTER_MAP_LOCATION_CODE}${code}`;
              const pathName = `${parentLocator.pathName}${CHARACTER_MAP_LOCATION_NAME}${name}`;

              arrLocator[l][floor].push({
                _id,
                parentId,
                layoutId,
                ...items[floor],
                name,
                code,
                mpath,
                pathCode,
                pathName,
                rootId: request.warehouseId,
                lengthUnit: request.lengthUnit,
                weightUnit: request.weightUnit,
              });
            }
          }
        }
      }
    }

    const arrLocatorFlat = arrLocator.flat(2);
    const locators = await this.locatorRepository.createMany(arrLocatorFlat);
    layouts.forEach((lay) => {
      lay.locators = locators.filter((loc) => lay.id === loc.layoutId);
      lay['warehouse'] = warehouse;
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(this.i18n.translate('error.SUCCESS'))
      .withData(layouts)
      .build();
  }

  async getList(request: GetLayoutListRequestDto): Promise<any> {
    const { page } = request;
    const { result, count } = await this.layoutRepository.getList(request);
    const userIds = uniq(map(result, 'createdBy'));
    const warehouseIds = uniq(map(result, 'warehouseId'));
    const warehouses = await this.warehouseClientService.getListByIds(
      warehouseIds,
      true,
    );

    let users = [];
    if (!isEmpty(userIds)) {
      users = await this.userService.getUserByIds(userIds, true);
    }

    result.forEach((item) => {
      item.createdBy = users[item.createdBy];
      item.warehouse = warehouses[item.warehouseId];
    });

    const dataReturn = plainToInstance(LayoutResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getDetail(request: GetLayoutDetailsRequestDto): Promise<any> {
    const { id } = request;
    const layout = await this.layoutRepository.findOneById(id);

    if (!layout) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const warehouse = await this.warehouseClientService.getDetail(
      layout.warehouseId,
    );
    if (!warehouse) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
        .build();
    }

    if (layout.createdBy) {
      const user = await this.userService.getUserById(layout.createdBy);
      layout.createdBy = user;
    }

    const locators = await this.locatorRepository.findAllByCondition({
      layoutId: id,
    });
    locators.forEach((item) => {
      item['parentId'] = item.mpath.split(CHARACTER_MAP_LOCATION_PATH).at(-2);
      item.id = item._id.toString();
    });

    layout.id = layout._id.toString();
    layout.locators = locators;
    layout['warehouse'] = warehouse;

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(this.i18n.translate('error.SUCCESS'))
      .withData(layout)
      .build();
  }

  async update(request: UpdateLayoutRequestDto): Promise<any> {
    const { id, warehouseId, layoutTemplateId } = request;
    const layout = await this.layoutRepository.findOneById(id);
    if (!layout) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const warehouse = await this.warehouseClientService.getWarehouseById(
      warehouseId,
    );
    if (!warehouse) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
        .build();
    }
    if (layoutTemplateId) {
      const layoutTemplate = await this.layoutTemplateRepository.findOneById(
        layoutTemplateId,
      );
      if (!layoutTemplate) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.TEMPLATE_LAYOUT_NOT_FOUND'),
          )
          .build();
      }
    }

    const updateLayout = this.layoutRepository.updateDocument(layout, request);

    return await this.save(updateLayout, true);
  }

  async delete(request: DeleteLayoutRequestDto): Promise<any> {
    const { id } = request;
    const layout = await this.layoutRepository.findOneById(id);
    if (!layout) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.LAYOUT_NOT_FOUND'))
        .build();
    }
    const locators = await this.locatorRepository.findAllByCondition({
      layoutId: id,
    });
    const locatorIds = map(locators, '_id');

    const itemsExist = await this.itemClientService.checkExistItemInLocator(
      locatorIds,
    );

    if (itemsExist && !isEmpty(itemsExist)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(this.i18n.translate('error.ITEMS_EXISTED_IN_LOCATOR'))
        .build();
    }

    const session = await this.connection.startSession();
    // start transaction
    session.startTransaction();
    try {
      // Delete locator
      await this.locatorRepository.deleteManyByCondition({
        layoutId: id,
      });

      // Delete layout
      await this.layoutRepository.deleteByCondition({ _id: id });

      session.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch {
      session.abortTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async deleteMultiple(request: DeleteMultipleDto): Promise<any> {
    try {
      const { ids } = request;

      const layouts = await this.layoutRepository.findAllByCondition({
        _id: {
          $in: ids,
        },
      });

      if (!layouts || layouts.length != uniq(ids).length) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }

      const locators = await this.locatorRepository.getListByLayoutIds(ids);
      if (!isEmpty(locators)) {
        const ids = uniq(map(locators, '_id'));

        this.locatorRepository.deleteManyByCondition({
          _id: { $in: ids },
        });
      }

      await this.layoutRepository.deleteManyByCondition({
        _id: { $in: ids },
      });

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async save(layout: Layout, isUpdate = false): Promise<any> {
    try {
      let result;
      if (isUpdate) {
        result = await this.layoutRepository.findByIdAndUpdate(
          layout._id,
          layout,
        );
      } else {
        result = await this.layoutRepository.create(layout);
      }
      const response = plainToInstance(LayoutResponseDto, result, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(this.i18n.translate('error.SUCCESS'))
        .withData(response)
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async saveMany(arrLayout: Layout[]) {
    try {
      const result = await this.layoutRepository.create(arrLayout);

      const response = plainToInstance(LayoutResponseDto, result, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(this.i18n.translate('error.SUCCESS'))
        .withData(response)
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }
}
