import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { LayoutSchema } from 'src/models/layout/layout.schema';
import { LayoutTemplateRepository } from 'src/repository/layout-template/layout-template.repository';
import { LayoutRepository } from 'src/repository/layout/layout.repository';
import { LayoutController } from './layout.controller';
import { LayoutService } from './layout.service';
import { LocatorRepository } from 'src/repository/locator/locator.repository';
import { LocatorSchema } from '@models/locator/locator.schema';
import { LayoutTemplateSchema } from '@models/layout-template/layout-template.schema';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'Layout', schema: LayoutSchema }]),
    MongooseModule.forFeature([{ name: 'Locator', schema: LocatorSchema }]),
    MongooseModule.forFeature([
      { name: 'LayoutTemplate', schema: LayoutTemplateSchema },
    ]),
    UserModule,
  ],
  providers: [
    {
      provide: 'LayoutRepositoryInterface',
      useClass: LayoutRepository,
    },
    {
      provide: 'LayoutServiceInterface',
      useClass: LayoutService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'LayoutTemplateRepositoryInterface',
      useClass: LayoutTemplateRepository,
    },
    {
      provide: 'LocatorRepositoryInterface',
      useClass: LocatorRepository,
    },
  ],
  exports: [
    MongooseModule,
    {
      provide: 'LayoutRepositoryInterface',
      useClass: LayoutRepository,
    },
  ],
  controllers: [LayoutController],
})
export class LayoutModule {}
