import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';

import { Layout } from '@models/layout/layout.schema';
import { CreateLayoutRequestDto } from '../dto/request/create-layout.request.dto';
import { GetLayoutListRequestDto } from '../dto/request/get-layout-list.request.dto';

export interface LayoutRepositoryInterface
  extends BaseAbstractRepository<Layout> {
  createDocument(request: CreateLayoutRequestDto): Layout;
  updateDocument(layoutTemplate: Layout, request: any): Layout;
  getList(request: GetLayoutListRequestDto): Promise<any>;
  deleteManyByCondition(condition: any): Promise<any>;
}
