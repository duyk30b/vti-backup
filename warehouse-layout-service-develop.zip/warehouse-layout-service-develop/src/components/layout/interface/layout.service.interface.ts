import { DeleteMultipleDto } from '@utils/common.request.dto';
import { CreateLayoutRequestDto } from '../dto/request/create-layout.request.dto';
import { DeleteLayoutRequestDto } from '../dto/request/delete-layout.request.dto';
import { GetLayoutDetailsRequestDto } from '../dto/request/get-layout-details.request.dto';
import { GetLayoutListRequestDto } from '../dto/request/get-layout-list.request.dto';
import { UpdateLayoutRequestDto } from '../dto/request/update-layout.request.dto';

export interface LayoutServiceInterface {
  create(request: CreateLayoutRequestDto): Promise<any>;
  getList(request: GetLayoutListRequestDto): Promise<any>;
  getDetail(request: GetLayoutDetailsRequestDto): Promise<any>;
  update(request: UpdateLayoutRequestDto): Promise<any>;
  delete(request: DeleteLayoutRequestDto): Promise<any>;
  deleteMultiple(request: DeleteMultipleDto): Promise<any>;
}
