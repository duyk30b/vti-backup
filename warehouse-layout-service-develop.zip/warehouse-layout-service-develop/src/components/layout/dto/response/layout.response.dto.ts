import { LayoutTemplateResponseDto } from '@components/layout-template/dto/response/template-layout.response.dto';
import { UserBasicResponseDto } from '@components/user/dto/response/user.basic.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { LayoutLevelResponseDto } from './layout-level.response.dto';
import { WarehouseResponseDto } from 'src/modules/nats-client/warehouse/dto/response/warehouse.response.dto';

export class LayoutResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  @Type(() => WarehouseResponseDto)
  warehouse: WarehouseResponseDto;

  @ApiProperty()
  @Expose()
  layoutTemplateId: string;

  @ApiProperty()
  @Expose()
  @Type(() => LayoutTemplateResponseDto)
  layoutTemplate: LayoutTemplateResponseDto;

  @ApiProperty()
  @Expose()
  lengthUnit: number;

  @ApiProperty()
  @Expose()
  weightUnit: number;

  @ApiProperty({ type: LayoutLevelResponseDto })
  @Expose()
  @Type(() => LayoutLevelResponseDto)
  items: LayoutLevelResponseDto[];

  @ApiProperty({ type: UserBasicResponseDto })
  @Expose()
  @Type(() => UserBasicResponseDto)
  createdBy: UserBasicResponseDto;

  @ApiProperty({ type: UserBasicResponseDto })
  @Expose()
  @Type(() => UserBasicResponseDto)
  updatedBy: UserBasicResponseDto;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  canEditCode: boolean;
}
