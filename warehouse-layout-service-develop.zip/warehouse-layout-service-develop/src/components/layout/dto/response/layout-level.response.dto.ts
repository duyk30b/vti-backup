import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class LayoutLevelResponseDto {
  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  length: number;

  @ApiProperty()
  @Expose()
  width: number;

  @ApiProperty()
  @Expose()
  height: number;

  @ApiProperty()
  @Expose()
  weight: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  layoutType: number;

  @ApiProperty()
  @Expose()
  level: number;
}
