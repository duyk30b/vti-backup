import { PaginationQuery } from '@utils/pagination.query';

export class GetLayoutListRequestDto extends PaginationQuery {}
