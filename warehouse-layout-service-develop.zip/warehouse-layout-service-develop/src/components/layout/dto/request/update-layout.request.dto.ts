import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateLayoutRequestDto } from './create-layout.request.dto';

export class UpdateLayoutParamDto extends BaseDto {
  @ApiProperty({ description: 'Id' })
  @IsMongoId()
  @IsNotEmpty()
  id: string;
}

export class UpdateLayoutBodyDto extends CreateLayoutRequestDto {}

export class UpdateLayoutRequestDto extends UpdateLayoutBodyDto {
  @ApiProperty({ description: 'Id' })
  @IsMongoId()
  @IsNotEmpty()
  id: string;
}
