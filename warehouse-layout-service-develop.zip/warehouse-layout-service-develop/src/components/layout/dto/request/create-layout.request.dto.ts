import { LAYOUT_TYPE_ENUM } from '@components/layout-template/layout-template.constant';
import { LAYOUT_RULES } from '@components/layout/layout.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';

export class LocatorLayoutCreate {
  @ApiProperty({ description: 'Code', example: 'LWK' })
  @IsString()
  @IsNotEmpty()
  code: string;

  @ApiProperty({ description: 'Name', example: 'LayoutDemo' })
  @IsString()
  @MaxLength(LAYOUT_RULES.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ description: 'Quantity', example: 2 })
  @IsInt()
  quantity: number;

  @ApiProperty()
  @IsPositive()
  length: number;

  @ApiProperty()
  @IsPositive()
  width: number;

  @ApiProperty()
  @IsPositive()
  height: number;

  @ApiProperty()
  @IsPositive()
  weight: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(LAYOUT_TYPE_ENUM)
  layoutType: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  level: number;
}

export class CreateLayoutRequestDto extends BaseDto {
  @ApiProperty({ description: 'Code', example: 'LWK' })
  @IsString()
  @IsNotEmpty()
  code: string;

  @ApiProperty({ description: 'Name', example: 'LayoutDemo' })
  @IsString()
  @MaxLength(LAYOUT_RULES.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ description: 'Warehouse Id', example: 43 })
  @IsNumber()
  @IsPositive()
  warehouseId: number;

  @ApiProperty({ description: 'LayoutTemplate Id' })
  @IsString()
  @IsOptional()
  layoutTemplateId: string;

  @ApiProperty({ description: 'Length Unit Id' })
  @IsPositive()
  lengthUnit: number;

  @ApiProperty()
  @IsPositive()
  weightUnit: number;

  @ApiProperty({ description: 'Quantity', example: 2 })
  @IsInt()
  quantity: number;

  @ApiProperty({ description: 'Items level' })
  @Type(() => LocatorLayoutCreate)
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  items: LocatorLayoutCreate[];
}
