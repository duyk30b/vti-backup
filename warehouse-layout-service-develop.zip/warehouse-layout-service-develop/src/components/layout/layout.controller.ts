import { BaseResponseDto } from '@core/dto/base.response.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { DeleteLayoutRequestDto } from './dto/request/delete-layout.request.dto';
import { GetLayoutListRequestDto } from './dto/request/get-layout-list.request.dto';
import {
  UpdateLayoutBodyDto,
  UpdateLayoutParamDto,
} from './dto/request/update-layout.request.dto';
import { LayoutResponseDto } from './dto/response/layout.response.dto';
import { LayoutServiceInterface } from './interface/layout.service.interface';
import { DeleteMultipleDto } from '@utils/common.request.dto';
import { CreateLayoutRequestDto } from './dto/request/create-layout.request.dto';
import { GetLayoutDetailsRequestDto } from './dto/request/get-layout-details.request.dto';

@Controller('layouts')
export class LayoutController {
  constructor(
    @Inject('LayoutServiceInterface')
    private readonly layoutService: LayoutServiceInterface,
  ) {}

  @Post()
  @ApiOperation({
    tags: ['Layout'],
    summary: 'Create layout',
    description: 'Tạo layout',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: BaseResponseDto,
  })
  async create(@Body() body: CreateLayoutRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.layoutService.create(request);
  }

  @Put(':id')
  @ApiOperation({
    tags: ['Layout'],
    summary: 'Update layout',
    description: 'Chỉnh sửa layout',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: BaseResponseDto,
  })
  async update(
    @Param() param: UpdateLayoutParamDto,
    @Body() body: UpdateLayoutBodyDto,
  ): Promise<any> {
    const {
      request: { id },
      responseError: paramError,
    } = param;
    const { request, responseError } = body;
    if (paramError && !isEmpty(paramError)) {
      return responseError;
    }
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.layoutService.update({ ...request, id });
  }

  @Delete(':id')
  @ApiOperation({
    tags: ['Layout'],
    summary: 'Delete layout',
    description: 'Xóa layout',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  async delete(@Param() param: DeleteLayoutRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.layoutService.delete(request);
  }

  @Get(':id')
  @ApiOperation({
    tags: ['Layout'],
    summary: 'Details layout',
    description: 'Chi tiết layout',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: LayoutResponseDto,
  })
  async getDetail(@Param() param: GetLayoutDetailsRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.layoutService.getDetail(request);
  }

  @Get()
  @ApiOperation({
    tags: ['Layout'],
    summary: 'List layout',
    description: 'Danh sach layout',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: LayoutResponseDto,
  })
  async getList(@Query() query: GetLayoutListRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.layoutService.getList(request);
  }

  @Delete('/multiple')
  @ApiOperation({
    tags: ['Layout'],
    summary: 'Delete multiple layout',
    description: 'Xóa nhiều layout',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteMultiple(@Query() query: DeleteMultipleDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.layoutService.deleteMultiple(request);
  }
}
