import { InitDataModule } from './components/init-data/init-data.module';
import { BootModule } from '@nestcloud/boot';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { I18nModule } from 'nestjs-i18n';
import * as path from 'path';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { HttpClientModule } from '@core/components/http-client/http-client.module';
import { CoreModule } from '@core/core.module';
import { ValidationPipe } from '@core/pipe/validation.pipe';
import { APP_PIPE } from '@nestjs/core';
@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      expandVariables: true,
    }),
    I18nModule.forRoot({
      fallbackLanguage: 'vi',
      loaderOptions: {
        path: path.join(__dirname, '/i18n/'),
        watch: true,
      },
    }),
    BootModule.forRoot({
      filePath: path.resolve(__dirname, '../config.yaml'),
    }),
    HttpClientModule,
    CoreModule,
    InitDataModule,
  ],
  controllers: [AppController],
  providers: [
    {
      provide: APP_PIPE,
      useClass: ValidationPipe,
    },
    AppService,
  ],
})
export class AppModule {}
