import { Transform } from 'class-transformer';
import { IsInt, IsOptional } from 'class-validator';

export class BaseDto {
  @IsOptional()
  @Transform(() => {
    return 1;
  })
  @IsInt()
  userId?: number;

  request: any;

  responseError: any;
}
