import {
  CallHandler,
  ExecutionContext,
  Inject,
  mixin,
  NestInterceptor,
  Optional,
  Type,
} from '@nestjs/common';
import { Options, Multer } from 'multer';
import FastifyMulter from 'fastify-multer';
import { Observable } from 'rxjs';

type MulterInstance = any;
export function FastifyFileInterceptor(
  fieldName: string,
  loccalOptions: Options,
): Type<NestInterceptor> {
  class MixinInterceptor implements NestInterceptor {
    protected mutler: MulterInstance;

    constructor(
      @Optional()
      @Inject('MULTER_MODULE_OPTIONS')
      options: Multer,
    ) {
      this.mutler = (FastifyMulter as any)({ ...options, ...loccalOptions });
    }

    async intercept(
      context: ExecutionContext,
      next: CallHandler<any>,
    ): Promise<Observable<any>> {
      const ctx = context.switchToHttp();

      await new Promise<void>((resolve, reject) =>
        this.mutler.single(fieldName)(
          ctx.getRequest(),
          ctx.getResponse(),
          (error: any) => {
            if (error) return reject(error);
            resolve();
          },
        ),
      );
      return next.handle();
    }
  }

  const Interceptor = mixin(MixinInterceptor);

  return Interceptor as Type<NestInterceptor>;
}
