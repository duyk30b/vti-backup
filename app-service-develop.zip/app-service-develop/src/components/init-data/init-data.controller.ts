import { Controller, Inject, Param, Post } from '@nestjs/common';
import { InitDataServiceInterface } from './interface/init-data.service.interface';

@Controller('init-data')
export class InitDataController {
  constructor(
    @Inject('InitDataServiceInterface')
    private readonly initDataService: InitDataServiceInterface,
  ) {}

  @Post('/:folder/:menu')
  async insertItemService(
    @Param('folder') folder,
    @Param('menu') menu,
  ): Promise<any> {
    const payload = {
      folder,
      menu,
    };
    return await this.initDataService.initData(payload);
  }
}
