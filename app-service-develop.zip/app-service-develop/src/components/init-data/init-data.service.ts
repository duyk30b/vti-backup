import { ResponseCodeEnum } from '@constant/response-code.enum';
import { HttpClientServiceInterface } from '@core/components/http-client/interface/http-client.service.interface';
import { Inject } from '@nestjs/common';
import { readFileJson } from '@utils/json.helper';
import { ResponseBuilder } from '@utils/response-builder';
import * as path from 'path';
import * as fs from 'fs';
import {
  INIT_DATA_ITEM_SERVICE,
  INIT_DATA_PLAN_SERVICE,
  INIT_DATA_PRODUCE_SERVICE,
  INIT_DATA_QMSX_SERVICE,
  INIT_DATA_SALE_SERVICE,
  INIT_DATA_USER_SERVICE,
  INIT_DATA_WAREHOUSE_SERVICE,
  INIT_DATA_WAREHOUSE_YARD_SERVICE,
} from './init-data.constant';
import { InitDataServiceInterface } from './interface/init-data.service.interface';

export class InitDataService implements InitDataServiceInterface {
  constructor(
    @Inject('HttpClientServiceInterface')
    private readonly httpClientService: HttpClientServiceInterface,
  ) {}

  async initData(payload: any): Promise<any> {
    const { folder, menu } = payload;
    const fileUrl = path.resolve(
      process.cwd(),
      `data/${folder}/${menu}/index.json`,
    );
    if (!fs.existsSync(fileUrl)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage('FILE_NOT_FOUND')
        .build();
    }
    const data = await readFileJson(fileUrl);
    const keyService = Object.keys(data);

    for (let i = 0; i < keyService.length; i++) {
      const key = keyService[i];
      const serviceData = data[key];
      const body = this.getBody(serviceData);
      let url = null;
      switch (key) {
        case 'itemService':
          url = INIT_DATA_ITEM_SERVICE;
          break;
        case 'saleService':
          url = INIT_DATA_SALE_SERVICE;
          break;
        case 'userService':
          url = INIT_DATA_USER_SERVICE;
          break;
        case 'produceService':
          url = INIT_DATA_PRODUCE_SERVICE;

          break;
        case 'planService':
          url = INIT_DATA_PLAN_SERVICE;
          break;
        case 'qmsxService':
          url = INIT_DATA_QMSX_SERVICE;
          break;
        case 'warehouseService':
          url = INIT_DATA_WAREHOUSE_SERVICE;
          break;
        case 'warehouseYardService':
          url = INIT_DATA_WAREHOUSE_YARD_SERVICE;
          break;
        default:
          break;
      }
      if (url && serviceData.length !== 0) {
        await this.httpClientService.post(url, body);
      }
    }
    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  getBody(data) {
    const body: any = [];
    for (let i = 0; i < data.length; i++) {
      const element = data[i];
      const keyTableItemService = Object.keys(element);
      const obj: any = {
        table: keyTableItemService[0],
        data: {},
      };
      obj.data.values = '';
      for (let j = 0; j < element[keyTableItemService[0]].length; j++) {
        const e = element[keyTableItemService[0]][j];
        if (!obj.data.key) {
          obj.data.key = Object.keys(e).join(',');
        }
        obj.data.values += Object.keys(e)
          .map((i) => e[i])
          .join('|');
      }
      body.push(obj);
    }
    return body;
  }
}
