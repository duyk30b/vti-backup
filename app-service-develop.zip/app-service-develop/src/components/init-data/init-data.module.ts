import { InitDataService } from './init-data.service';
import { InitDataController } from './init-data.controller';
import { Module } from '@nestjs/common';

@Module({
  imports: [],
  providers: [
    {
      provide: 'InitDataServiceInterface',
      useClass: InitDataService,
    },
  ],
  controllers: [InitDataController],
  exports: [],
})
export class InitDataModule {}
