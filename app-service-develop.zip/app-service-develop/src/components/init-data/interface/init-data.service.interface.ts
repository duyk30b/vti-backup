export interface InitDataServiceInterface {
  initData(payload: any): Promise<any>;
}
