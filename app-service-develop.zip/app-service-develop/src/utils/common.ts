import { isNaN } from 'lodash';

export const escapeCharForSearch = (str: string): string => {
  return str.toLowerCase().replace(/[?%\\_]/gi, function (x) {
    return '\\' + x;
  });
};

export const convertInputToInt = (str: any): number => {
  const number = Number(str);
  if (isNaN(number) || number - parseInt(str) !== 0) {
    return 0;
  }
  return number;
};

export enum EnumSort {
  ASC = 'ASC',
  DESC = 'DESC',
}

export const getToDay = (): string => {
  const today = new Date();
  const yyyy = today.getFullYear();
  let mm: string | number = today.getMonth() + 1;
  let dd: string | number = today.getDate();

  if (dd < 10) dd = '0' + dd;
  if (mm < 10) mm = '0' + mm;

  return `${dd}-${mm}-${yyyy}`;
};
