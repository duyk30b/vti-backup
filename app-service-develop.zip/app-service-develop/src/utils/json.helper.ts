import * as path from 'path';
import $RefParser from '@apidevtools/json-schema-ref-parser';

export const readFileJson = async (fileUrl): Promise<any> => {
  return await $RefParser.dereference(path.resolve(process.cwd(), fileUrl));
};
