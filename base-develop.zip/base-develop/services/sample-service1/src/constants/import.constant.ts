export const IMPORT_FILE = {
  VALIDATE_MSG: {
    FILE_UNDEFINED: 'Chưa chọn file dữ liệu',
    WRONG_FILE_TYPE: 'Vui lòng chọn đúng định dạng file',
  },
  ALLOWED_EXT: ['xlsx', 'csv'],
};

export const EXT_SEPARATOR = '.';
