export enum APIPrefix {
  Version = 'api/v1/sample-service',
}
