import {
  DEVICE_PROFILE_CONST,
  DeviceProfileStatus,
  DeviceProfileType,
} from '@components/device-profile/device-profile.constant';
import { DEFAULT_COLLATION } from '@constant/common';
import { Schema } from 'mongoose';

const attributesSchema = new Schema({
  name: {
    type: String,
    maxlength: 255,
    required: true,
  },
  code: {
    type: String,
    maxlength: 255,
    required: true,
  },
  description: {
    type: String,
    maxlength: 255,
    required: false,
  },
  producingStepId: {
    type: Number,
    required: false,
  },
  dataType: {
    type: String,
    maxlength: 255,
    required: true,
  },
  isDefault: {
    type: Boolean,
    required: false,
  },
});

export const DeviceProfileSchema = new Schema(
  {
    name: {
      type: String,
      maxlength: DEVICE_PROFILE_CONST.NAME.MAX_LENGTH,
      required: true,
    },
    code: {
      type: String,
      maxlength: DEVICE_PROFILE_CONST.NAME.MAX_LENGTH,
      required: true,
    },
    description: {
      type: String,
      maxlength: 255,
      required: false,
    },
    type: {
      type: Number,
      enum: DeviceProfileType,
      default: DeviceProfileType.NORMAL,
      required: true,
    },
    status: {
      type: Number,
      enum: DeviceProfileStatus,
      default: DeviceProfileStatus.ACTIVE,
      required: false,
    },
    routingId: {
      type: Number,
      required: false,
    },
    producingStepId: {
      type: Number,
      required: false,
    },
    attributes: {
      type: [attributesSchema],
      required: true,
    },
  },
  {
    collection: 'deviceProfiles',
    id: true,
    timestamps: true,
    collation: DEFAULT_COLLATION,
  },
);
