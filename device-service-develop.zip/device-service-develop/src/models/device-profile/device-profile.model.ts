import {
  DeviceProfileStatus,
  DeviceProfileType,
} from '@components/device-profile/device-profile.constant';
import { BaseModel } from '@core/model/base.model';

interface DeviceProfileAttribute {
  name: string;
  code: string;
  description: string;
  producingStepId?: number;
  dataType?: string;
  isDefault?: boolean;
}

export interface DeviceProfile extends BaseModel {
  name: string;
  code: string;
  description: string;
  attributes: DeviceProfileAttribute[];
  type: DeviceProfileType;
  status: DeviceProfileStatus;
  routingId?: number;
  producingStepId?: number;
}
