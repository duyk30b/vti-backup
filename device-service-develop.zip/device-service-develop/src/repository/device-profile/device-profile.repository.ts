import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { DeviceProfile } from 'src/models/device-profile/device-profile.model';
import { DeviceProfileRepositoryInterface } from '@components/device-profile/interface/device-profile.repository.interface';
import {
  CreateDeviceProfileRequestDto,
  UpdateDeviceProfileRequestDto,
} from '@components/device-profile/dto/request/create-device-profile.request.dto';
import { GetListDeviceProfileRequestDto } from '@components/device-profile/dto/request/get-list-device-profile.request.dto';
import { isEmpty, replace } from 'lodash';
import { REGEX_FOR_FILTER } from '@constant/common';
import * as moment from 'moment';
import { SortOrder } from '@constant/database.constant';

@Injectable()
export class DeviceProfileRepository
  extends BaseAbstractRepository<DeviceProfile>
  implements DeviceProfileRepositoryInterface
{
  constructor(
    @InjectModel('DeviceProfile')
    private readonly deviceProfile: Model<DeviceProfile>,
  ) {
    super(deviceProfile);
  }

  public async getList(
    request: GetListDeviceProfileRequestDto,
  ): Promise<{ result: any; count: any } | { result: any; count: any }> {
    const { keyword, sort, filter, take, skip } = request;
    let filterObj = {};
    let sortObj = {};
    if (!isEmpty(keyword)) {
      filterObj = {
        $or: [
          { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          {
            name: {
              $regex:
                '.*' +
                replace(keyword, REGEX_FOR_FILTER, (e) => `\\${e}`) +
                '.*',
              $options: 'i',
            },
          },
        ],
      };
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'name':
            filterObj = {
              ...filterObj,
              name: {
                $regex: `.*${value}.*`,
                $options: 'i',
              },
            };
            break;
          case 'code':
            filterObj = {
              ...filterObj,
              code: {
                $regex: `.*${value}.*`,
                $options: 'i',
              },
            };
            break;
          case 'type':
            filterObj = {
              ...filterObj,
              type: value,
            };
            break;
          case 'routingId':
            filterObj = {
              ...filterObj,
              routingId: value,
            };
            break;
          case 'producingStepId':
            filterObj = {
              ...filterObj,
              producingStepId: value,
            };
            break;
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'updatedAt':
            filterObj = {
              ...filterObj,
              updatedAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          default:
            break;
        }
      });
    }
    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        switch (item.column) {
          case 'name':
            sortObj = { name: item.order?.toSortOrder() };
            break;
          case 'code':
            sortObj = { code: item.order?.toSortOrder() };
            break;
          case 'createdAt':
            sortObj = { createdAt: item.order?.toSortOrder() };
            break;
          case 'updatedAt':
            sortObj = { updatedAt: item.order?.toSortOrder() };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = { createdAt: SortOrder.Descending };
    }
    const result = await this.deviceProfile
      .find(filterObj)
      .select({
        code: 1,
        status: 1,
        name: 1,
        _id: 1,
        type: 1,
        routingId: 1,
        producingStepId: 1,
      })
      .limit(take)
      .skip(skip)
      .sort(sortObj)
      .lean();

    const total: number = await this.deviceProfile
      .find(filterObj)
      .countDocuments()
      .exec();

    return { result: result, count: total };
  }

  updateEntity(
    deviceProfile: DeviceProfile,
    request: UpdateDeviceProfileRequestDto,
  ): DeviceProfile {
    const { name, type, attributes, routingId, producingStepId, code } =
      request;
    deviceProfile.name = name;
    deviceProfile.code = code;
    deviceProfile.attributes = attributes;
    deviceProfile.type = type;
    deviceProfile.routingId = routingId;
    deviceProfile.producingStepId = producingStepId;

    return deviceProfile;
  }

  createDocument(request: CreateDeviceProfileRequestDto): DeviceProfile {
    const document = new this.deviceProfile();
    document.code = request.code;
    document.name = request.name;
    document.description = request.description;
    document.attributes = request.attributes;
    document.type = request.type;
    document.routingId = request.routingId;
    document.producingStepId = request.producingStepId;

    return document;
  }
}
