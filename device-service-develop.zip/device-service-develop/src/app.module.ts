import DatabaseConfigService from '@config/database.config';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { I18nJsonLoader, I18nModule } from 'nestjs-i18n';
import * as path from 'path';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { APP_GUARD, APP_PIPE } from '@nestjs/core';
import { ValidationPipe } from '@core/pipe/validator.pipe';
import { QueryResolver } from './i18n/query-resolver';
import { BootModule } from '@nestcloud/boot';
import { resolve } from 'path';
import { BOOT, CONSUL } from '@nestcloud/common';
import { ConsulModule } from '@nestcloud/consul';
import { ServiceModule } from '@nestcloud/service';
import { HttpClientModule } from '@core/components/http-client/http-client.module';
import { KongGatewayModule } from '@core/components/kong-gateway/kong-gateway.module';
import { UserModule } from '@components/user/user.module';
import { AuthModule } from '@components/auth/auth.module';
import { CoreModule } from '@core/core.module';
import { AuthorizationGuard } from '@core/guards/authorization.guard';
import { DeviceProfileModule } from '@components/device-profile/device-profile.module';
import { DeviceModule } from '@components/device/device.module';
import { KafkaProducerModule } from '@core/components/kafka-producer/kafka-producer.module';
import { ProduceModule } from '@components/produce/produce.module';
import { EdgeXModule } from '@core/components/edgex/edgex.module';
import { NatsClientModule } from '@core/transporter/nats-transporter/nats-client.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    I18nModule.forRoot({
      fallbackLanguage: 'vi',
      loader: I18nJsonLoader,
      loaderOptions: {
        path: path.join(__dirname, '/i18n/'),
        watch: true,
      },
      resolvers: [{ use: QueryResolver, options: ['lang', 'locale', 'l'] }],
    }),
    MongooseModule.forRootAsync({
      useClass: DatabaseConfigService,
    }),
    BootModule.forRoot({
      filePath: resolve(__dirname, '../config.yaml'),
    }),
    ConsulModule.forRootAsync({ inject: [BOOT] }),
    ServiceModule.forRootAsync({ inject: [BOOT, CONSUL] }),
    HttpClientModule,
    KongGatewayModule.forRootAsync(),
    // KafkaProducerModule,
    EdgeXModule,
    UserModule,
    ProduceModule,
    AuthModule,
    CoreModule,
    DeviceProfileModule,
    DeviceModule,
    NatsClientModule,
  ],
  controllers: [AppController],
  providers: [
    {
      provide: APP_PIPE,
      useClass: ValidationPipe,
    },
    {
      provide: APP_GUARD,
      useClass: AuthorizationGuard,
    },
    AppService,
  ],
})
export class AppModule {}
