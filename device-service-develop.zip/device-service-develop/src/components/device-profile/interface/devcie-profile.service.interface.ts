import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import {
  CreateDeviceProfileRequestDto,
  UpdateDeviceProfileRequestDto,
} from '../dto/request/create-device-profile.request.dto';
import { GetListDeviceProfileRequestDto } from '../dto/request/get-list-device-profile.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';

export interface DeviceProfileServiceInterface {
  getListByIds(payload: any): any;
  detail(request: IdParamDto): Promise<any>;
  getList(request: GetListDeviceProfileRequestDto): Promise<any>;
  create(request: CreateDeviceProfileRequestDto): Promise<any>;
  update(request: UpdateDeviceProfileRequestDto): Promise<any>;
  updateStatusActive(request: UpdateActiveStatusPayload): Promise<any>;
}
