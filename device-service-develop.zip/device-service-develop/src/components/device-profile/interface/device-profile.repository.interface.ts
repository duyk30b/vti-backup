import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { DeviceProfile } from 'src/models/device-profile/device-profile.model';
import {
  CreateDeviceProfileRequestDto,
  UpdateDeviceProfileRequestDto,
} from '../dto/request/create-device-profile.request.dto';
import { GetListDeviceProfileRequestDto } from '../dto/request/get-list-device-profile.request.dto';

export interface DeviceProfileRepositoryInterface
  extends BaseInterfaceRepository<DeviceProfile> {
  getList(
    request: GetListDeviceProfileRequestDto,
  ): { result: any; count: any } | PromiseLike<{ result: any; count: any }>;
  updateEntity(
    deviceProfile: DeviceProfile,
    request: UpdateDeviceProfileRequestDto,
  ): DeviceProfile;
  createDocument(request: CreateDeviceProfileRequestDto): DeviceProfile;
}
