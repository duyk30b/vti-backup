export enum DeviceProfileType {
  NORMAL = 0,
  PLC = 1,
}

export enum DeviceProfileStatus {
  PEDING = 0,
  ACTIVE = 1,
}

export const DEVICE_PROFILE_CONST = {
  CODE: {
    MAX_LENGTH: 255,
  },
  NAME: {
    MAX_LENGTH: 255,
  },
};
