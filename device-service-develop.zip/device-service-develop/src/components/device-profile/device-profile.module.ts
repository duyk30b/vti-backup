import { MongooseModule } from '@nestjs/mongoose';
import { Module } from '@nestjs/common';
import { DeviceProfileSchema } from 'src/models/device-profile/device-profile.schema';
import { DeviceProfileRepository } from 'src/repository/device-profile/device-profile.repository';
import { DeviceProfileController } from './device-profile.controller';
import { DeviceProfileService } from './device-profile.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'DeviceProfile', schema: DeviceProfileSchema },
    ]),
  ],
  controllers: [DeviceProfileController],
  providers: [
    {
      provide: 'DeviceProfileServiceInterface',
      useClass: DeviceProfileService,
    },
    {
      provide: 'DeviceProfileRepositoryInterface',
      useClass: DeviceProfileRepository,
    },
  ],
  exports: [MongooseModule],
})
export class DeviceProfileModule {}
