import {
  Body,
  Controller,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { DeviceProfileServiceInterface } from './interface/devcie-profile.service.interface';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { isEmpty } from 'lodash';
import {
  CreateDeviceProfileRequestDto,
  UpdateDeviceProfileRequestDto,
} from './dto/request/create-device-profile.request.dto';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { GetListDeviceProfileRequestDto } from './dto/request/get-list-device-profile.request.dto';
import { GetDetailDeviceProfileResponseDto } from './dto/response/get-detail-device-profile.response.dto';
import { ListDeviceProfileResponseDto } from './dto/response/list-device-profile.response.dto';
import { MessagePattern } from '@nestjs/microservices';
import { ResponsePayload } from '@utils/response-payload';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { ACTIVE_ENUM } from '@constant/common';
import { NATS_DEVICE } from '@config/nats.config';

@Controller('device-profiles')
export class DeviceProfileController {
  constructor(
    @Inject('DeviceProfileServiceInterface')
    private readonly deviceProfileService: DeviceProfileServiceInterface,
  ) {}

  @Post('')
  @ApiOperation({
    tags: ['Device Profile'],
    summary: 'Create Device profile',
    description: 'Create a new Device profile',
  })
  @ApiResponse({
    status: 200,
    description: 'Created successfully',
  })
  async create(@Body() payload: CreateDeviceProfileRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceProfileService.create(request);
  }

  @Put('/:id')
  @ApiOperation({
    tags: ['Device Profile'],
    summary: 'Update Device profile',
    description: 'Update Device profile',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  async update(
    @Body() payload: UpdateDeviceProfileRequestDto,
    @Param() param: IdParamDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    const {
      request: { id },
      responseError: responseParamError,
    } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }

    return await this.deviceProfileService.update({ ...request, id: id });
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['Device Profile'],
    summary: 'Detail Device Profile',
    description: 'Detail Device Profile',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetDetailDeviceProfileResponseDto,
  })
  async detail(@Param() payload: IdParamDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceProfileService.detail(request);
  }

  @MessagePattern(`${NATS_DEVICE}.get_device_profile`)
  async detailTcp(@Body() payload: any): Promise<any> {
    return await this.deviceProfileService.detail(payload);
  }

  @Get('/list')
  @ApiOperation({
    tags: ['Device Profile'],
    summary: 'List Of Device Profile',
    description: 'List Of Device Profile',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: ListDeviceProfileResponseDto,
  })
  async getList(
    @Query() payload: GetListDeviceProfileRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceProfileService.getList(request);
  }

  @MessagePattern(`${NATS_DEVICE}.get_device_profile_by_ids`)
  async getListByIdsTcp(@Body() payload: any): Promise<any> {
    return await this.deviceProfileService.getListByIds(payload);
  }

  @Put(':id/active')
  @ApiOperation({
    tags: ['Device Profile Active'],
    summary: 'Active device profile ',
    description: 'Active device profile',
  })
  @ApiResponse({
    status: 200,
    description: 'Active successfully',
  })
  public async active(
    @Param() param: IdParamDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.deviceProfileService.updateStatusActive({
      ...request,
      status: ACTIVE_ENUM.ACTIVE,
    } as UpdateActiveStatusPayload);
  }

  @Put(':id/inactive')
  @ApiOperation({
    tags: ['Device Profile Inactive'],
    summary: 'Inactive device profile ',
    description: 'Inactive device profile',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
  })
  public async inactive(
    @Param() param: IdParamDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.deviceProfileService.updateStatusActive({
      ...request,
      status: ACTIVE_ENUM.INACTIVE,
    } as UpdateActiveStatusPayload);
  }
}
