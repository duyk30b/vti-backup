import { Inject, Injectable, Logger } from '@nestjs/common';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DeviceProfileRepositoryInterface } from './interface/device-profile.repository.interface';
import { DeviceProfileServiceInterface } from './interface/devcie-profile.service.interface';
import {
  CreateDeviceProfileRequestDto,
  UpdateDeviceProfileRequestDto,
} from './dto/request/create-device-profile.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Types } from 'mongoose';
import { IdParamDto } from '@utils/dto/request/param-id.request.dto';
import { GetListDeviceProfileRequestDto } from './dto/request/get-list-device-profile.request.dto';
import { plainToInstance } from 'class-transformer';
import { ListDeviceProfileResponse } from './dto/response/list-device-profile.response.dto';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { GetDetailDeviceProfileResponse } from './dto/response/get-detail-device-profile.response.dto';
import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { find, isEmpty, map } from 'lodash';
import { log } from 'console';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';

@Injectable()
export class DeviceProfileService implements DeviceProfileServiceInterface {
  private readonly logger = new Logger(DeviceProfileService.name);
  constructor(
    @Inject('DeviceProfileRepositoryInterface')
    private readonly deviceProfileRepository: DeviceProfileRepositoryInterface,

    @Inject('ProduceServiceInterface')
    private readonly produceService: ProduceServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async getListByIds(payload: any) {
    log({ payload });
    const result = await this.deviceProfileRepository.findAllByCondition({
      _id: {
        $in: payload?.ids,
      },
    });
    const response = plainToInstance(ListDeviceProfileResponse, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async detail(request: IdParamDto): Promise<any> {
    const { id } = request;
    const result = await this.deviceProfileRepository.findOneById(id);
    if (!result) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.DEVICE_PROFILE_NOT_FOUND'),
        )
        .build();
    }

    await this.getDeviceExtraInformation(result);

    const response = plainToInstance(GetDetailDeviceProfileResponse, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getList(request: GetListDeviceProfileRequestDto): Promise<any> {
    const { result, count } = await this.deviceProfileRepository.getList(
      request,
    );

    if (!isEmpty(result)) {
      const routings = await this.produceService.getListRoutingByIds(
        map(result, 'routingId'),
        true,
      );

      const producingSteps =
        await this.produceService.getListProducingStepByIds(
          map(result, 'producingStepId'),
          true,
        );
      result.forEach((r) => {
        if (r.routingId) {
          r.routing = routings[r.routingId];
        }
        if (r.producingStepId) {
          r.producingStep = find(
            producingSteps,
            (ps) => ps.id === r.producingStepId,
          );
        }
      });
    }

    const response = plainToInstance(ListDeviceProfileResponse, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PaginationResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async update(request: UpdateDeviceProfileRequestDto): Promise<any> {
    const { id, name, code } = request;

    const deviceProfile = await this.deviceProfileRepository.findOneById(id);
    if (!deviceProfile) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.DEVICE_PROFILE_NOT_FOUND'),
        )
        .build();
    }

    const existDeviceProfile =
      await this.deviceProfileRepository.findOneByCondition({
        id: {
          $ne: new Types.ObjectId(id),
        },
        code: code,
      });

    if (existDeviceProfile) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.DEVICE_DEVICE_CODE_EXISTED'),
        )
        .build();
    }

    try {
      const result = await this.deviceProfileRepository.updateEntity(
        deviceProfile,
        request,
      );
      await this.deviceProfileRepository.findByIdAndUpdate(id, result);
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  public async create(request: CreateDeviceProfileRequestDto): Promise<any> {
    try {
      const { name, code } = request;

      const existDeviceProfile =
        await this.deviceProfileRepository.findOneByCondition({
          code: code,
        });

      if (existDeviceProfile) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.DEVICE_DEVICE_CODE_EXISTED'),
          )
          .build();
      }
      const deviceProfileDocument =
        this.deviceProfileRepository.createDocument(request);
      await deviceProfileDocument.save();

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      console.error(err);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CREATE'))
        .build();
    }
  }

  /**
   *
   * @param deviceProfile
   */
  private async getDeviceExtraInformation(deviceProfile: any): Promise<any> {
    try {
      const { routingId, producingStepId, attributes } = deviceProfile;

      const producingSteps =
        await this.produceService.getListProducingStepByIds(
          [producingStepId, ...map(attributes, 'producingStepId')],
          true,
        );
      if (producingStepId) {
        deviceProfile.producingStep = producingSteps[producingStepId];
      }
      deviceProfile.attributes = deviceProfile.attributes.map((attr) => {
        if (attr.producingStepId) {
          attr.producingStep = producingSteps[attr.producingStepId];
        }
        return attr;
      });
      if (routingId) {
        const routing = await this.produceService.getRoutingDetail(routingId);
        deviceProfile.routing = routing;
      }
    } catch (error) {
      this.logger.error('getDeviceExtraInformation ERROR: ', error);
    }
  }

  public async updateStatusActive(
    request: UpdateActiveStatusPayload,
  ): Promise<any> {
    const { id, status } = request;

    const deviceProfile = await this.deviceProfileRepository.findOneById(id);
    if (!deviceProfile) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.DEVICE_PROFILE_NOT_FOUND'),
        )
        .build();
    }

    try {
      deviceProfile.status = status;
      await this.deviceProfileRepository.findByIdAndUpdate(id, deviceProfile);
      return new ResponseBuilder(deviceProfile)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }
}
