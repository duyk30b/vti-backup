import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { SuccessResponse } from '@utils/success.response.dto';

class AttributeProducingStep extends BasicResponseDto {}
class AttributeRouting extends BasicResponseDto {}
export class ListDeviceProfileResponse extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty({ type: AttributeProducingStep })
  @Expose()
  @Type(() => AttributeProducingStep)
  producingStep: AttributeProducingStep;

  @ApiProperty({ type: AttributeProducingStep })
  @Expose()
  @Type(() => AttributeProducingStep)
  routing: AttributeRouting;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;
}

export class ListDeviceProfileResponseDto extends SuccessResponse {
  @ApiProperty({ type: ListDeviceProfileResponse })
  @Expose()
  @Type(() => ListDeviceProfileResponse)
  data: ListDeviceProfileResponse;
}
