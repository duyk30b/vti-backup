import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { IsArray } from 'class-validator';
import { SuccessResponse } from '@utils/success.response.dto';

class AttributeProducingStep extends BasicResponseDto {}
class AttributeRouting extends BasicResponseDto {
  @ApiProperty({ type: AttributeProducingStep })
  @Expose()
  @Type(() => AttributeProducingStep)
  producingSteps: AttributeProducingStep[];
}
class Attribute {
  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  producingStepId: number;

  @ApiProperty()
  @Expose()
  dataType: string;

  @ApiProperty()
  @Expose()
  isDefault: boolean;

  @ApiProperty({ type: AttributeProducingStep })
  @Expose()
  @Type(() => AttributeProducingStep)
  producingStep: AttributeProducingStep;
}

export class GetDetailDeviceProfileResponse extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty({ type: AttributeProducingStep })
  @Expose()
  @Type(() => AttributeProducingStep)
  producingStep: AttributeProducingStep;

  @ApiProperty({ type: AttributeRouting })
  @Expose()
  @Type(() => AttributeRouting)
  routing: AttributeRouting;

  @ApiProperty({ type: Attribute, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => Attribute)
  attributes: Attribute[];
}

export class GetDetailDeviceProfileResponseDto extends SuccessResponse {
  @ApiProperty({ type: GetDetailDeviceProfileResponse })
  @Expose()
  @Type(() => GetDetailDeviceProfileResponse)
  data: GetDetailDeviceProfileResponse;
}
