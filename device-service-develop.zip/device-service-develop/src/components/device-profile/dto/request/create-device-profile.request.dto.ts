import { DeviceProfileType } from '@components/device-profile/device-profile.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsArray,
  IsBoolean,
  IsEnum,
  IsMongoId,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';

class DeviceProfileAttribute {
  @ApiProperty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiProperty()
  @IsString()
  @MaxLength(255)
  code: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  producingStepId: number;

  @ApiProperty()
  @IsString()
  @MaxLength(255)
  dataType: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  isDefault: boolean;
}

export class CreateDeviceProfileRequestDto extends BaseDto {
  @ApiProperty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiPropertyOptional()
  @IsString()
  @MaxLength(255)
  @IsOptional()
  description: string;

  @ApiProperty()
  @IsString()
  @MaxLength(255)
  code: string;

  @ApiProperty()
  @IsNumber()
  @IsEnum(DeviceProfileType)
  type: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  routingId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  producingStepId: number;

  @ApiProperty({
    isArray: true,
    type: DeviceProfileAttribute,
  })
  @IsArray()
  @Type(() => DeviceProfileAttribute)
  @ValidateNested({ each: true })
  attributes: DeviceProfileAttribute[];
}

export class UpdateDeviceProfileRequestDto extends CreateDeviceProfileRequestDto {
  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  id: string;
}
