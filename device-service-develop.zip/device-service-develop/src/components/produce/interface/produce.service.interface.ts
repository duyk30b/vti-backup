export interface ProduceServiceInterface {
  getRoutingDetail(id): Promise<any>;
  getListRoutingByIds(ids, isSerialize?: true): Promise<any>;
  getListProducingStepByIds(ids, isSerialize?: true): Promise<any>;
}
