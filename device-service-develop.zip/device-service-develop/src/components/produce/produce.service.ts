import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { NATS_PRODUCE } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { keyBy } from 'lodash';

@Injectable()
export class ProduceService implements ProduceServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async getListProducingStepByIds(ids: any, isSerialize?: true): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_list_producing_step_by_ids`,
      { ids },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS)
      return isSerialize ? {} : [];

    return isSerialize ? keyBy(response.data, 'id') : response.data;
  }

  async getListRoutingByIds(ids: any, isSerialize?: true): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.list_routing_by_ids`,
      {
        ids,
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS)
      return isSerialize ? {} : [];

    return isSerialize ? keyBy(response.data, 'id') : response.data;
  }

  async getRoutingDetail(id: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.routing_detail`,
      {
        id,
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return null;

    return response.data;
  }
}
