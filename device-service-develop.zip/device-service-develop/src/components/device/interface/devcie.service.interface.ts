export interface DeviceServiceInterface {
  registerDevice(request: any): unknown;
}
