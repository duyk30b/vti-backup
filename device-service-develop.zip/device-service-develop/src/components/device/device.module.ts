import { MongooseModule } from '@nestjs/mongoose';
import { Module } from '@nestjs/common';
import { DeviceProfileSchema } from 'src/models/device-profile/device-profile.schema';
import { DeviceProfileRepository } from 'src/repository/device-profile/device-profile.repository';
import { DeviceController } from './device.controller';
import { DeviceService } from './device.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'DeviceProfile', schema: DeviceProfileSchema },
    ]),
  ],
  controllers: [DeviceController],
  providers: [
    {
      provide: 'DeviceServiceInterface',
      useClass: DeviceService,
    },
    {
      provide: 'DeviceProfileRepositoryInterface',
      useClass: DeviceProfileRepository,
    },
  ],
  exports: [],
})
export class DeviceModule {}
