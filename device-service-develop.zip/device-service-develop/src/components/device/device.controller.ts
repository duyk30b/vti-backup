import { Controller, Inject } from '@nestjs/common';
import { DeviceServiceInterface } from './interface/devcie.service.interface';
import { MessagePattern, Payload } from '@nestjs/microservices';
import { RegisterDeviceRequestDto } from './dto/request/register-device.request.dto';
import { isEmpty } from 'lodash';
import { NATS_DEVICE } from '@config/nats.config';

@Controller('/')
export class DeviceController {
  constructor(
    @Inject('DeviceServiceInterface')
    private readonly deviceService: DeviceServiceInterface,
  ) {}

  @MessagePattern(`${NATS_DEVICE}.register_device`)
  public async registerDevice(@Payload() payload: RegisterDeviceRequestDto) {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.deviceService.registerDevice(request);
  }
}
