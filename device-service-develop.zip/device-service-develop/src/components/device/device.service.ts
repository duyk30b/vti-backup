import { Inject, Injectable , Logger} from '@nestjs/common';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DeviceServiceInterface } from './interface/devcie.service.interface';
import { RegisterDeviceRequestDto } from './dto/request/register-device.request.dto';
import { DeviceProfileRepositoryInterface } from '@components/device-profile/interface/device-profile.repository.interface';
import { isEmpty } from 'lodash';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { EdgeXServiceServiceInterface } from '@core/components/edgex/interface/edgex.service.interface';

@Injectable()
export class DeviceService implements DeviceServiceInterface {
  private readonly logger = new Logger(DeviceService.name);

  constructor(
    @Inject('DeviceProfileRepositoryInterface')
    private readonly deviceProfileRepository: DeviceProfileRepositoryInterface,

    @Inject('EdgeXServiceInterface')
    private edgeXService: EdgeXServiceServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  /**
   * 
   * @param request 
   * @returns 
   */
  public async registerDevice(request: RegisterDeviceRequestDto): Promise<any> {
    const { profileId } = request;
    const deviceProfile = await this.deviceProfileRepository.findOneById(
      profileId,
    );

    if (isEmpty(deviceProfile)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.DEVICE_PROFILE_NOT_FOUND'),
        )
        .build();
    }

    try {
      await this.edgeXService.registerIotDevice({
        ...request,
        deviceProfile: deviceProfile
       })
    } catch (error) {
      this.logger.error(`IOT DEVICE Register ERROR: `, error)
    }
    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();

  }
}
