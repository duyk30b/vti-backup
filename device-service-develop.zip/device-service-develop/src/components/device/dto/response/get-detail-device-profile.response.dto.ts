import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';
import { IsArray } from 'class-validator';

class Attribute {
  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  dataType: string;
}

export class GetDetailDeviceProfileResponseDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  routingId: number;

  @ApiProperty()
  @Expose()
  producingStepId: number;

  @ApiProperty({ type: Attribute, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => Attribute)
  attributes: Attribute[];
}
