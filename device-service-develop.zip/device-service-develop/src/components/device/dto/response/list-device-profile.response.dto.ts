import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { BasicResponseDto } from '@utils/dto/response/basic.response.dto';

export class ListDeviceProfileResponseDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  routingId: number;

  @ApiProperty()
  @Expose()
  producingStepId: number;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;
}
