import { CODE_DEFAULT } from '@utils/constant';

export function generateCode(
  latestObj: any,
  defaultCode: string,
  maxLength: number,
  padChar: string,
  gap = 1,
): string {
  let generatedCode;
  if (latestObj) generatedCode = (+latestObj.code + gap).toString();
  else generatedCode = defaultCode;

  return generatedCode.padStart(maxLength, padChar);
}

export function generatedCode(latestObj: any, constant: any, gap = 1): string {
  let generatedCode;

  if (latestObj)
    generatedCode = (Number.parseInt(latestObj.code) + gap).toString();
  else generatedCode = constant.DEFAULT_CODE;

  return generatedCode.padStart(constant.MAX_LENGTH - 1, constant.PAD_CHAR);
}

export function generateCodeByPreviousCode(
  prefix: string,
  currentCode: number,
  maxLength = CODE_DEFAULT.CODE_LENGTH,
  gap = CODE_DEFAULT.GAP,
  padChar = CODE_DEFAULT.PAD_CHAR,
): string {
  return prefix.concat(
    (currentCode + gap).toString().padStart(maxLength, padChar),
  );
}

export const returnStockQuantity = (number) =>
  number ? (number < 0 ? 0 : number) : 0;

export function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function getCurrentCodeByLastRecord(codePrefix = '', lastRecord) {
  return +lastRecord.code?.replace(codePrefix, '') || 0;
}
