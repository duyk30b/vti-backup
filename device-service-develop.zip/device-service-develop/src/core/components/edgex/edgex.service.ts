import { Injectable } from '@nestjs/common';
import { EdgeXServiceServiceInterface } from './interface/edgex.service.interface';
import { HttpService } from '@nestjs/axios';
import { catchError, firstValueFrom, map, of, retry } from 'rxjs';
import { ConfigService } from '@config/config.service';
import { genericRetryStrategy } from '@utils/rxjs-util';

@Injectable()
export class EdgeXService implements EdgeXServiceServiceInterface {
  private readonly host
  private readonly port

  protected apiVersion = "v2"
  protected adminState = "UNLOCKED"
  protected operatingState = "UP"
  protected autoEventDefault = {
      "interval": "30s",
      "onChange": false,
      "sourceName": "All"
  }
  protected defaultProtocol = {
    opcua: {
                            "Endpoint": "opc.tcp://192.168.200.15:49320"
                      }
  }

  constructor(
    private httpClientService: HttpService,
  ) {
    const configService = new ConfigService();
    const edgeXConfig = configService.get('edgeX')
    this.host = edgeXConfig?.options.host
    this.port =  edgeXConfig?.options.port
  }

  public async registerIotDevice(data: any) {
   return await firstValueFrom(
        this.httpClientService
          .post(`http://${this.host}:${this.port}/api/v2/device`, [
            {
              "apiVersion": this.apiVersion,
              "device": {
                  "name": data.code,
                  "description": data.description,
                  "adminState": this.adminState,
                  "operatingState": this.operatingState,
                  "labels": [
                      "test", "OPCUA"
                  ],
                  "profileName": data.deviceProfile?.code,
                  "serviceName": data.name,
                  "autoEvents": [
                      this.autoEventDefault
                  ],
                  "protocols": {
                      ...this.defaultProtocol
                  }
              }
            }
          ])
          .pipe(
            map((response) => response.data),
            retry(
              genericRetryStrategy({
                scalingDuration: 1000,
                excludedStatusCodes: [409],
              }),
            ),
            catchError((error) => of(error)),
          ),
      );
  }
}
