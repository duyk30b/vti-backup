export interface EdgeXServiceServiceInterface {
  registerIotDevice(data: any);
}
