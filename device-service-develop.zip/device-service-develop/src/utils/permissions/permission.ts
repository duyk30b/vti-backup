export const PERMISSION = [];

export const GROUP_PERMISSION = [];

export const INSERT_PERMISSION = {
  permission: PERMISSION,
  groupPermission: GROUP_PERMISSION,
};
