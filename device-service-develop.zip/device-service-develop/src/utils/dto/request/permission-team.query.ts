import { IsOptional } from 'class-validator';

export class PermissionTeamQuery {
  @IsOptional()
  assignIds: string[];

  @IsOptional()
  checkPermission: boolean;
}
