export class BaseDto {
  request: any;

  responseError: any;

  userId?: number;

  lang?: string;
}
