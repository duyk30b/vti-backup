import { NATS_USER } from '@config/nats.config';
import { Public } from '@core/decorator/set-public.decorator';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Body, Controller, Get } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiBearerAuth } from '@nestjs/swagger';
import { ResponseBuilder } from '@utils/response-builder';
import { AppService } from './app.service';

@Controller('/')
@ApiBearerAuth('access-token')
export class AppController {
  constructor(
    private readonly appService: AppService,
    private readonly natsClientService: NatsClientService,
  ) {}

  @MessagePattern(`${NATS_USER}.ping`)
  pingServer(@Body() body: any) {
    return new ResponseBuilder().withData({ msg: 'pong', data: body }).build();
  }

  @Public()
  @Get('health')
  getHealth(): string {
    return this.appService.getHealth();
  }

  @Get('ping-nats')
  async pingNats(): Promise<any> {
    return await this.natsClientService.send(`${NATS_USER}.ping`, {
      msg: 'ping',
      queue: NATS_USER,
    });
  }
}
