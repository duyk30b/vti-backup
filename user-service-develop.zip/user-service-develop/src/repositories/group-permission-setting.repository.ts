import { isEmpty } from 'lodash';
import { Injectable } from '@nestjs/common';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { GroupPermissionSettingEntity } from '@entities/group-permission-setting/group-permission-setting.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { GroupPermissionSettingRepositoryInterface } from '@components/settings/user-role-setting/interface/group-permission-setting.repository.interface';
import { StatusPermission } from '@utils/constant';
import { CategoryGroupPermissionEntity } from '@entities/category-group-permission/category-group-permission.entity';
import { GetListGroupPermissionByDepartmentIdRequestDto } from '@components/settings/category-group-permission/dto/request/get-list-group-permission-by-category-id.request.dto';
import { DepartmentGroupPermissionEntity } from '@entities/category-group-permission/department-group-permission.entity';
import { PermissionSettingEntity } from '@entities/permission-setting/permission-setting.entity';
import { UserRolePermissionSettingEntity } from '@entities/user-role-permission-setting/user-role-permission-setting.entity';
import { DepartmentGroupPermissionByDepartmentIdRequestDto } from '@components/settings/department-setting/dto/request/department-group-permission-by-department-id.request.dto';

@Injectable()
export class GroupPermissionSettingRepository
  extends BaseAbstractRepository<GroupPermissionSettingEntity>
  implements GroupPermissionSettingRepositoryInterface
{
  constructor(
    @InjectRepository(GroupPermissionSettingEntity)
    private readonly groupPermissionSettingRepository: Repository<GroupPermissionSettingEntity>,
  ) {
    super(groupPermissionSettingRepository);
  }

  async getByIdCategoryIds(condition: any[]): Promise<any> {
    const query = this.groupPermissionSettingRepository
      .createQueryBuilder('gp')
      .select([
        'gp.id AS "id"',
        'gp.categoryGroupPermissionId AS "categoryGroupPermissionId"',
      ])
      .innerJoin(
        CategoryGroupPermissionEntity,
        'cgp',
        'cgp.id = gp.categoryGroupPermissionId',
      );

    for (let i = 0; i < condition.length; i++) {
      query.orWhere(
        `(gp.id = ${condition[i].groupPermissionId} AND gp.categoryGroupPermissionId = ${condition[i].categoryId})`,
      );
    }
    return query.getRawMany();
  }

  async getListByDepartmentId(
    request: GetListGroupPermissionByDepartmentIdRequestDto,
  ): Promise<any> {
    const { departmentId, isGetAll } = request;
    const query = this.groupPermissionSettingRepository
      .createQueryBuilder('gp')
      .select([
        'gp.id AS "id"',
        'gp.code AS "code"',
        'gp.name AS "name"',
        `COALESCE(dgp.status, 0) AS "status"`,
      ])
      .leftJoin(
        DepartmentGroupPermissionEntity,
        'dgp',
        `dgp.groupPermissionId = gp.id AND dgp.departmentId = ${departmentId}`,
      )
      .andWhere('gp.status = :status', {
        status: StatusPermission.ACTIVE,
      });
    const data =
      isGetAll === 1
        ? await query.getRawMany()
        : await query.offset(request.skip).limit(request.take).getRawMany();
    const count = await query.getCount();
    return { data, count };
  }

  async groupPermissionByDepartmentId(
    request: DepartmentGroupPermissionByDepartmentIdRequestDto,
  ): Promise<any> {
    const { departmentId, roleId, filter, skip, take } = request;
    const query = this.groupPermissionSettingRepository
      .createQueryBuilder('gps')
      .select([
        'gps.id AS "id"',
        'gps.name AS "name"',
        'gps.code AS "code"',
        'gps.status AS "status"',
        `CASE WHEN COUNT(ps) = 0 THEN '[]' ELSE JSON_AGG(
          DISTINCT JSONB_BUILD_OBJECT('id', ps.id, 'code', ps.code, 'name', ps.name, 'status', COALESCE(urps.status, 0))) END AS "permissionSettings"`,
      ])
      .innerJoin(
        DepartmentGroupPermissionEntity,
        'dgp',
        'dgp.groupPermissionId = gps.id',
      )
      .innerJoin(
        PermissionSettingEntity,
        'ps',
        'ps.groupPermissionSettingCode = gps.code',
      )
      .leftJoin(
        UserRolePermissionSettingEntity,
        'urps',
        `urps.permission_setting_code = ps.code AND urps.department_id = ${departmentId} AND urps.user_role_id = ${roleId}`,
      )
      .andWhere('dgp.departmentId = :departmentId', {
        departmentId: departmentId,
      })
      .addGroupBy('gps.id')
      .addGroupBy('gps.name')
      .addGroupBy('gps.code')
      .addGroupBy('gps.status')
      .orderBy('gps.name', 'ASC');

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        switch (item.column) {
          case 'status':
            query.andWhere(`"dgp"."status" = :status`, {
              status: item.text,
            });
            break;
          default:
            break;
        }
      });
    }

    const data = await query.offset(skip).limit(take).getRawMany();
    const count = await query.getCount();

    return { data, count };
  }
}
