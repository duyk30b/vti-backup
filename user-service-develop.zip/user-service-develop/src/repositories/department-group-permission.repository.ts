import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { DepartmentGroupPermissionEntity } from '@entities/category-group-permission/department-group-permission.entity';
import { DepartmentGroupPermissionRepositoryInterface } from '@components/settings/category-group-permission/interface/department-group-permission.repository.interface';

@Injectable()
export class DepartmentGroupPermissionRepository
  extends BaseAbstractRepository<DepartmentGroupPermissionEntity>
  implements DepartmentGroupPermissionRepositoryInterface
{
  constructor(
    @InjectRepository(DepartmentGroupPermissionEntity)
    private readonly departmentGroupPermissionRepository: Repository<DepartmentGroupPermissionEntity>,
  ) {
    super(departmentGroupPermissionRepository);
  }

  createEntity(data: any): DepartmentGroupPermissionEntity {
    const entity = new DepartmentGroupPermissionEntity();
    entity.departmentId = data.departmentId;
    entity.groupPermissionId = data.groupPermissionId;
    entity.status = data.status;
    return entity;
  }
}
