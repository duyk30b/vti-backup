import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectRepository } from '@nestjs/typeorm';
import { escapeCharForSearch } from '@utils/common';
import { Brackets, Repository } from 'typeorm';
import { isEmpty } from 'lodash';
import { DepartmentReceiptRepositoryInterface } from '@components/department-receipt/interface/department-receipt.repository.interface';
import { CreateDepartmentReceiptRequestDto } from '@components/department-receipt/dto/request/create-department-receipt.request.dto';
import { GetDepartmentReceiptListRequestDto } from '@components/department-receipt/dto/request/get-department-receipt-list.request.dto';
import { UpdateDepartmentReceiptRequestDto } from '@components/department-receipt/dto/request/update-department-receipt.request.dto';
import { DepartmentReceiptEntity } from '@entities/department-receipt/department-receipt.entity';
import { DepartmentReceiptStatusEnum } from '@components/department-receipt/department-receipt.constants';

export class DepartmentReceiptRepository
  extends BaseAbstractRepository<DepartmentReceiptEntity>
  implements DepartmentReceiptRepositoryInterface
{
  constructor(
    @InjectRepository(DepartmentReceiptEntity)
    private readonly departmentReceiptRepository: Repository<DepartmentReceiptEntity>,
  ) {
    super(departmentReceiptRepository);
  }
  createEntity(
    request: CreateDepartmentReceiptRequestDto,
  ): DepartmentReceiptEntity {
    const departmentReceipt = new DepartmentReceiptEntity();
    departmentReceipt.name = request.name;
    departmentReceipt.code = request.code;
    departmentReceipt.description = request.description;
    departmentReceipt.departmentType = request.departmentType;
    departmentReceipt.createdBy = request.userId;
    departmentReceipt.updatedBy = request.userId;
    departmentReceipt.status = DepartmentReceiptStatusEnum.ACTIVE;
    return departmentReceipt;
  }

  updateEntity(
    departmentReceipt: DepartmentReceiptEntity,
    request: UpdateDepartmentReceiptRequestDto,
  ): DepartmentReceiptEntity {
    departmentReceipt.name = request.name;
    departmentReceipt.description = request.description;
    departmentReceipt.departmentType = request.departmentType;
    departmentReceipt.updatedBy = request.userId;
    return departmentReceipt;
  }

  async getList(request: GetDepartmentReceiptListRequestDto): Promise<any> {
    const { skip, take, keyword, sort, filter, ids } = request;
    let query = await this.departmentReceiptRepository
      .createQueryBuilder('s')
      .select([
        's.id AS "id"',
        's.name AS "name"',
        's.code AS "code"',
        's.description AS "description"',
        's.status AS "status"',
        's.department_type AS "departmentType"',
        's.created_by AS "createdBy"',
        's.created_at AS "createdAt"',
        's.updated_by AS "updatedBy"',
        's.updated_at AS "updatedAt"',
        's.created_from AS "createdFrom"',
        's.sync_status AS "syncStatus"',
      ]);

    if (keyword) {
      query.andWhere(
        new Brackets((qb) => {
          qb.where(
            `lower(unaccent("s"."name")) LIKE lower(unaccent(:pkeyWord)) escape '\\'`,
            {
              pkeyword: `%${escapeCharForSearch(keyword)}%`,
            },
          );
          qb.orWhere(
            `lower(unaccent("s"."code")) LIKE lower(unaccent(:pkeyWord)) escape '\\'`,
            {
              pkeyWord: `%${escapeCharForSearch(keyword)}%`,
            },
          );
        }),
      );
    }

    if (ids) {
      query.andWhere(`"s"."id" IN (:...ids)`, {
        ids: ids.split(','),
      });
    }

    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        switch (item.column) {
          case 'createdAt':
            const createdFrom = item.text.split('|')[0];
            const createdTo = item.text.split('|')[1];
            query.andWhere(
              `"s"."created_at" between :createdFrom AND :createdTo`,
              {
                createdFrom: createdFrom,
                createdTo: createdTo,
              },
            );
            break;
          case 'updatedAt':
            const updatedFrom = item.text.split('|')[0];
            const updatedTo = item.text.split('|')[1];
            query.andWhere(
              `"s"."updated_at" between :updatedFrom AND :updatedTo`,
              {
                updatedFrom: updatedFrom,
                updatedTo: updatedTo,
              },
            );
            break;
          case 'status':
            query.andWhere(`"s"."status" = :status`, {
              status: item.text,
            });
            break;
          case 'departmentType':
            query.andWhere(`"s"."department_type" = :departmentType`, {
              departmentType: item.text,
            });
            break;
          case 'code':
            query.andWhere(
              `lower(unaccent("s"."code")) LIKE lower(unaccent(:code)) escape '\\'`,
              {
                code: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'name':
            query.andWhere(
              `lower(unaccent("s"."name")) LIKE lower(unaccent(:name)) escape '\\'`,
              {
                name: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;
          case 'description':
            query.andWhere(
              `lower(unaccent("s"."description")) LIKE lower(unaccent(:description)) escape '\\'`,
              {
                description: `%${escapeCharForSearch(item.text)}%`,
              },
            );
            break;

          default:
            break;
        }
      });
    }

    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        switch (item.column) {
          case 'name':
            query = query.orderBy(
              '"s"."name"',
              item.order === 'ASC' ? 'ASC' : 'DESC',
            );
            break;
          case 'code':
            query = query.orderBy(
              '"s"."code"',
              item.order === 'ASC' ? 'ASC' : 'DESC',
            );
            break;
          case 'createdAt':
            query = query.orderBy(
              '"s"."created_at"',
              item.order === 'ASC' ? 'ASC' : 'DESC',
            );
            break;
          case 'updatedAt':
            query = query.orderBy(
              '"s"."updated_at"',
              item.order === 'ASC' ? 'ASC' : 'DESC',
            );
            break;
          case 'createdFrom':
            query = query.orderBy(
              '"s"."created_from"',
              item.order === 'ASC' ? 'ASC' : 'DESC',
            );
            break;
          case 'createdFrom':
            query = query.orderBy(
              '"s"."status"',
              item.order === 'ASC' ? 'ASC' : 'DESC',
            );
            break;
          default:
            break;
        }
      });
    } else {
      query = query.orderBy('s.id', 'DESC');
    }

    query.addGroupBy('s.id');

    const data = await query.offset(skip).limit(take).getRawMany();
    const count = await query.getCount();

    return [data, count];
  }
}
