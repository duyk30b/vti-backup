import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { CategoryGroupPermissionEntity } from '@entities/category-group-permission/category-group-permission.entity';
import { CategoryGroupPermissionRepositoryInterface } from '@components/settings/category-group-permission/interface/category-group-permission.repository.interface';
import { GetListCategoryGroupPermissionRequestDto } from '@components/settings/category-group-permission/dto/request/get-list-category-group-permission.request.dto';

@Injectable()
export class CategoryGroupPermissionRepository
  extends BaseAbstractRepository<CategoryGroupPermissionEntity>
  implements CategoryGroupPermissionRepositoryInterface
{
  constructor(
    @InjectRepository(CategoryGroupPermissionEntity)
    private readonly moduleRepository: Repository<CategoryGroupPermissionEntity>,
  ) {
    super(moduleRepository);
  }

  async getList(
    request: GetListCategoryGroupPermissionRequestDto,
  ): Promise<any> {
    const query = this.moduleRepository
      .createQueryBuilder('m')
      .select([
        'm.id AS "id"',
        'm.code AS "code"',
        'm.name AS "name"',
        'm.description AS "description"',
      ]);
    const data = await query
      .offset(request.skip)
      .limit(request.take)
      .getRawMany();
    const count = await query.getCount();

    return { data, count };
  }
}
