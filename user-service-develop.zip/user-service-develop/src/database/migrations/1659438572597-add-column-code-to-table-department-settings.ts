import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addColumnCodeToTableDepartmentSettings1659438572597
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumns('department_settings', [
      new TableColumn({
        name: 'code',
        type: 'varchar',
        isNullable: true,
      }),
      new TableColumn({
        name: 'description',
        type: 'varchar',
        isNullable: true,
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('department_settings', [
      new TableColumn({
        name: 'code',
        type: 'varchar',
        isNullable: true,
      }),
      new TableColumn({
        name: 'description',
        type: 'varchar',
        isNullable: true,
      }),
    ]);
  }
}
