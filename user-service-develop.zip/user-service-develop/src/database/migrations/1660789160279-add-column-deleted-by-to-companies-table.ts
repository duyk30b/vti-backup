import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addColumnDeletedByToCompaniesTable1660789160279
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumns('companies', [
      new TableColumn({
        name: 'deleted_by',
        type: 'int',
        isNullable: true,
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('companies', [
      new TableColumn({
        name: 'deleted_by',
        type: 'int',
        isNullable: true,
      }),
    ]);
  }
}
