import { EnumStatus } from '@utils/common';
import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addStatusToUserRoleSettingTable1691400700288
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumn(
      'user_role_settings',
      new TableColumn({
        name: 'status',
        type: 'int',
        default: EnumStatus.YES,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn(
      'user_role_settings',
      new TableColumn({
        name: 'status',
        type: 'int',
        default: EnumStatus.YES,
      }),
    );
  }
}
