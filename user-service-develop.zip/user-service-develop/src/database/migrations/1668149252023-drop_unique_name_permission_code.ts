import { MigrationInterface, QueryRunner, TableUnique } from 'typeorm';

export class dropUniqueNamePermissionCode1668149252023
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    const table = await queryRunner.getTable('permission_settings');

    for (const uniqueConstraint of table.uniques) {
      for (const columnName of ['name']) {
        if (uniqueConstraint.columnNames.includes(columnName)) {
          await queryRunner.dropUniqueConstraint(
            'permission_settings',
            uniqueConstraint.name,
          );
        }
      }
    }
  }

  public down(queryRunner: QueryRunner): Promise<void> {
    return;
  }
}
