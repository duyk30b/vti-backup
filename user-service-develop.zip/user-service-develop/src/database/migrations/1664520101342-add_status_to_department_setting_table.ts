import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addStatusToDepartmentSettingTable1664520101342
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumn(
      'department_settings',
      new TableColumn({
        name: 'status',
        type: 'int',
        default: 0,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumn(
      'department_settings',
      new TableColumn({
        name: 'status',
        type: 'int',
        default: 0,
      }),
    );
  }
}
