import { MigrationInterface, QueryRunner } from 'typeorm';

export class alterConstraintColumnCodeInUserRoleSetting1692082609829
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      'ALTER TABLE user_role_settings ALTER COLUMN code type varchar(20)',
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      'ALTER TABLE user_role_settings ALTER COLUMN code type varchar(2)',
    );
  }
}
