import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addColumnDeletedAtTableDepartmentSettingAndUserRoleSetting1663150263714
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumns('department_settings', [
      new TableColumn({
        name: 'deleted_at',
        type: 'timestamptz',
        isNullable: true,
      }),
    ]);
    await queryRunner.addColumns('user_role_settings', [
      new TableColumn({
        name: 'deleted_at',
        type: 'timestamptz',
        isNullable: true,
      }),
    ]);
    await queryRunner.query(
      `ALTER TABLE "public"."user_role_settings" DROP CONSTRAINT "UQ_c49ed354fd77297e1cc213e1e17";`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('department_settings', [
      new TableColumn({
        name: 'deleted_at',
        type: 'timestamptz',
        isNullable: true,
      }),
    ]);
    await queryRunner.dropColumns('user_role_settings', [
      new TableColumn({
        name: 'deleted_at',
        type: 'timestamptz',
        isNullable: true,
      }),
    ]);
    await queryRunner.query(
      `ALTER TABLE "public"."user_role_settings" ADD CONSTRAINT "UQ_c49ed354fd77297e1cc213e1e17" UNIQUE (code);`,
    );
  }
}
