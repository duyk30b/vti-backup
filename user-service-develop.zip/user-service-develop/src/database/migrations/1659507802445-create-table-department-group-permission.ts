import { MigrationInterface, QueryRunner, Table } from 'typeorm';

export class createTableDepartmentGroupPermission1659507802445
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'department_group_permissions',
        columns: [
          {
            name: 'department_id',
            type: 'int',
            isPrimary: true,
          },
          {
            name: 'group_permission_id',
            type: 'int',
            isPrimary: true,
          },
        ],
      }),
      true,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable('department_group_permissions');
  }
}
