import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addColumnStatusToTalbeDepartmentGroupPermission1661153552601
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumns('department_group_permissions', [
      new TableColumn({
        name: 'status',
        type: 'int',
        isNullable: true,
      }),
    ]);
    await queryRunner.addColumns('user_role_permission_settings', [
      new TableColumn({
        name: 'status',
        type: 'int',
        isNullable: true,
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('department_group_permissions', [
      new TableColumn({
        name: 'status',
        type: 'int',
        isNullable: true,
      }),
    ]);
    await queryRunner.dropColumns('user_role_permission_settings', [
      new TableColumn({
        name: 'status',
        type: 'int',
        isNullable: true,
      }),
    ]);
  }
}
