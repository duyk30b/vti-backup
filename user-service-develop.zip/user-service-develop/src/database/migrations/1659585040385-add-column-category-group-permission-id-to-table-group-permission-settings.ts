import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addColumnCategoryGroupPermissionIdToTableGroupPermissionSettings1659585040385
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumns('group_permission_settings', [
      new TableColumn({
        name: 'category_group_permission_id',
        type: 'int',
        isNullable: true,
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('group_permission_settings', [
      new TableColumn({
        name: 'category_group_permission_id',
        type: 'int',
        isNullable: true,
      }),
    ]);
  }
}
