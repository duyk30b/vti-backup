import { MigrationInterface, QueryRunner } from 'typeorm';

export class dropUniqueNameGroupPermission1668222578927
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    const table = await queryRunner.getTable('group_permission_settings');

    for (const uniqueConstraint of table.uniques) {
      for (const columnName of ['name']) {
        if (uniqueConstraint.columnNames.includes(columnName)) {
          await queryRunner.dropUniqueConstraint(
            'group_permission_settings',
            uniqueConstraint.name,
          );
        }
      }
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    return;
  }
}
