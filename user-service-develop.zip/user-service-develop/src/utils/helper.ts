import Big from 'big.js';

export default function isEmpty(obj) {
  if (obj === null || obj === undefined) return true;
  return Object.keys(obj).length === 0;
}

export const plus = (first: number, second: number): number => {
  return Number(new Big(first).plus(new Big(second)));
};

export function serilize(data) {
  if (data.length > 0) {
    const serilizeData = [];
    data.forEach((record) => {
      serilizeData[record.id] = record;
    });
    return serilizeData;
  }
  return data;
}

export const isDevMode = () => {
  return (
    process.env.NODE_ENV.startsWith('dev') ||
    process.env.NODE_ENV.startsWith('local')
  );
};
