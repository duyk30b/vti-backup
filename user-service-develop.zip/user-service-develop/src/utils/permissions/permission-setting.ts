import { FORMAT_CODE_PERMISSION } from '@constant/common';
import { StatusPermission } from '@utils/constant';

export const PERMISSION_USER_GROUP_PERMISSION = {
  name: 'Cài đặt',
  code: FORMAT_CODE_PERMISSION + 'PERMISSION_GROUP',
  status: StatusPermission.ACTIVE,
};

export const MANAGE_USER_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'MANAGE_USER_PERMISSION',
  name: 'Quản lý phân quyền người dùng',
  groupPermissionSettingCode: PERMISSION_USER_GROUP_PERMISSION.code,
  status: StatusPermission.ACTIVE,
};

export const SET_PERMISSION_USER_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'SET_PERMISSION_USER',
  name: 'Phân quyền',
  groupPermissionSettingCode: PERMISSION_USER_GROUP_PERMISSION.code,
  status: StatusPermission.ACTIVE,
};

export const CONFIG_SIGNATURE_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'CONFIG_SIGNATURE',
  name: 'Cấu hình chữ ký',
  groupPermissionSettingCode: PERMISSION_USER_GROUP_PERMISSION.code,
  status: StatusPermission.ACTIVE,
};

export const LIST_PERMISSION_USER_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'LIST_PERMISSION_USER',
  name: 'Danh sách quyền của người dùng',
  groupPermissionSettingCode: PERMISSION_USER_GROUP_PERMISSION.code,
  status: StatusPermission.INACTIVE,
};

export const PERMISSION_USER_PERMISSION = [
  SET_PERMISSION_USER_PERMISSION,
  LIST_PERMISSION_USER_PERMISSION,
  CONFIG_SIGNATURE_PERMISSION,
  MANAGE_USER_PERMISSION,
];
