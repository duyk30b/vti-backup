import { FORMAT_CODE_PERMISSION } from '@constant/common';
import { StatusPermission } from '@utils/constant';

export const DEPARTMENT_RECEIPT_GROUP_PERMISSION = {
  name: 'Quản lý phòng ban nhận',
  code: FORMAT_CODE_PERMISSION + 'DEPARTMENT_RECEIPT_GROUP',
  status: StatusPermission.ACTIVE,
};

export const CREATE_DEPARTMENT_RECEIPT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'CREATE_DEPARTMENT_RECEIPT',
  name: 'Tạo phòng ban nhận',
  groupPermissionSettingCode: DEPARTMENT_RECEIPT_GROUP_PERMISSION.code,
  status: StatusPermission.ACTIVE,
};

export const UPDATE_DEPARTMENT_RECEIPT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'UPDATE_DEPARTMENT_RECEIPT',
  name: 'Sửa phòng ban nhận',
  groupPermissionSettingCode: DEPARTMENT_RECEIPT_GROUP_PERMISSION.code,
  status: StatusPermission.ACTIVE,
};

export const DELETE_DEPARTMENT_RECEIPT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'DELETE_DEPARTMENT_RECEIPT',
  name: 'Xóa phòng ban nhận',
  groupPermissionSettingCode: DEPARTMENT_RECEIPT_GROUP_PERMISSION.code,
  status: StatusPermission.ACTIVE,
};

export const DETAIL_DEPARTMENT_RECEIPT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'DETAIL_DEPARTMENT_RECEIPT',
  name: 'Chi tiết phòng ban nhận',
  groupPermissionSettingCode: DEPARTMENT_RECEIPT_GROUP_PERMISSION.code,
  status: StatusPermission.ACTIVE,
};

export const CONFIRM_DEPARTMENT_RECEIPT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'CONFIRM_DEPARTMENT_RECEIPT',
  name: 'Mở khoá phòng ban nhận',
  groupPermissionSettingCode: DEPARTMENT_RECEIPT_GROUP_PERMISSION.code,
  status: StatusPermission.ACTIVE,
};

export const REJECT_DEPARTMENT_RECEIPT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'REJECT_DEPARTMENT_RECEIPT',
  name: 'Khoá phòng ban nhận',
  groupPermissionSettingCode: DEPARTMENT_RECEIPT_GROUP_PERMISSION.code,
  status: StatusPermission.ACTIVE,
};

export const LIST_DEPARTMENT_RECEIPT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'LIST_DEPARTMENT_RECEIPT',
  name: 'Danh sách phòng ban nhận',
  groupPermissionSettingCode: DEPARTMENT_RECEIPT_GROUP_PERMISSION.code,
  status: StatusPermission.ACTIVE,
};

export const IMPORT_DEPARTMENT_RECEIPT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'IMPORT_DEPARTMENT_RECEIPT',
  name: 'Nhập theo danh sách phòng ban nhận',
  groupPermissionSettingCode: DEPARTMENT_RECEIPT_GROUP_PERMISSION.code,
  status: StatusPermission.ACTIVE,
};

export const EXPORT_DEPARTMENT_RECEIPT_PERMISSION = {
  code: FORMAT_CODE_PERMISSION + 'EXPORT_DEPARTMENT_RECEIPT',
  name: 'Xuất theo danh sách phòng ban nhận',
  groupPermissionSettingCode: DEPARTMENT_RECEIPT_GROUP_PERMISSION.code,
  status: StatusPermission.ACTIVE,
};

export const DEPARTMENT_RECEIPT_PERMISSION = [
  CREATE_DEPARTMENT_RECEIPT_PERMISSION,
  UPDATE_DEPARTMENT_RECEIPT_PERMISSION,
  DELETE_DEPARTMENT_RECEIPT_PERMISSION,
  DETAIL_DEPARTMENT_RECEIPT_PERMISSION,
  CONFIRM_DEPARTMENT_RECEIPT_PERMISSION,
  REJECT_DEPARTMENT_RECEIPT_PERMISSION,
  LIST_DEPARTMENT_RECEIPT_PERMISSION,
  IMPORT_DEPARTMENT_RECEIPT_PERMISSION,
  EXPORT_DEPARTMENT_RECEIPT_PERMISSION,
];
