import { Controller } from '@nestjs/common';

@Controller('warehouse')
export class WarehouseController {}
