import { DeleteRequestDto } from '@components/user/dto/request/delete.request.dto';
import { CreatePermissionResponseDto } from '@components/user/dto/response/create-permission.response.dto';
import { CheckPermissionDepartmentRequestDto } from '@components/warehouse/dto/request/check-permission-department.request.dto';
import { NATS_WAREHOUSE } from '@config/nats.config';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { escapeCharForSearch } from '@utils/common';
import { ResponsePayload } from '@utils/response-payload';
import { flatMap, isEmpty, map, uniq } from 'lodash';
import { ResponseCodeEnum } from './../../constant/response-code.enum';
import { WarehouseServiceInterface } from './interface/warehouse.service.interface';

@Injectable()
export class WarehouseService implements WarehouseServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async getListByIDs(ids: number[], relation?: string[]): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_WAREHOUSE}.get_warehouses_by_ids`,
        { warehouseIds: ids, relation },
      );

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }
      return response.data;
    } catch (err) {
      console.log(err);
      return [];
    }
  }

  async getWarehouseListByConditions(
    request: any,
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_WAREHOUSE}.get_warehouses_by_conditions`,
      request,
    );

    if (serilize) {
      const serilizeWarehouses = {};
      if (!response) return [];
      response.forEach((warehouse) => {
        serilizeWarehouses[warehouse.id] = warehouse;
      });
      return serilizeWarehouses;
    }

    return response;
  }

  async getWarehouseListByCompanyIds(request: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_WAREHOUSE}.get_warehouses_by_company_ids`,
      request,
    );

    return response;
  }

  async getWarehousesByName(filterByWarehouseName, onlyId?): Promise<any> {
    if (isEmpty(filterByWarehouseName)) {
      return [];
    }

    const warehouses = await this.getWarehouseListByConditions(
      'LOWER(name)LIKE ' +
        `LOWER(unaccent('%${escapeCharForSearch(
          filterByWarehouseName.text,
        )}%')) escape '\\'`,
    );

    if (!isEmpty(warehouses) && onlyId === true) {
      return uniq(map(flatMap(warehouses), 'id'));
    }

    return warehouses;
  }

  // Permission Setting

  async getPermissionCodeByName(request): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_WAREHOUSE}.get_permission_code_by_name`,
      request,
    );
  }

  async createNewPermission(
    request,
  ): Promise<ResponsePayload<CreatePermissionResponseDto>> {
    return await this.natsClientService.send(
      `${NATS_WAREHOUSE}.create_new_permission`,
      request,
    );
  }

  async deletePermission(request: DeleteRequestDto): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_WAREHOUSE}.delete_permission`,
      request,
    );
  }

  // Group Permission Setting
  async createGroupPermission(request): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_WAREHOUSE}.create_group_permission`,
      request,
    );
  }

  async checkPermissionDepartment(
    request: CheckPermissionDepartmentRequestDto,
  ): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_WAREHOUSE}.check_permission_department`,
      request,
    );
  }

  async getPermissionIdByCode(request: string): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_WAREHOUSE}.get_permission_id_by_code`,
      request,
    );
  }

  async getDepartmentIdByPermission(request: number): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_WAREHOUSE}.get_department_id_by_permission`,
      request,
    );
  }

  async getAllGroupPermission(request: any): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_WAREHOUSE}.get_all_group_permission`,
      request,
    );
  }
}
