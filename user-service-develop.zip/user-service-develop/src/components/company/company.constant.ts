export enum CompanyStatusEnum {
  REJECT = 0,
  CONFIRMED = 1,
}

export const CAN_UPDATE_COMPANY_STATUS: number[] = [CompanyStatusEnum.REJECT];

export enum StatusCompanyEnum {
  INACTIVE = 0,
  ACTIVE = 1,
}
