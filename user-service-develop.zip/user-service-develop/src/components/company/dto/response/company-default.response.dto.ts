import { BasicResponseDto } from '@core/dto/basic-response.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';

export class CompanyDefaultResponseDto extends BasicResponseDto {
  @Expose()
  address: string;
}

export class CompanyDefaultResponseSwaggerDto extends SuccessResponse {
  @Expose()
  @Type(() => CompanyDefaultResponseDto)
  data: CompanyDefaultResponseDto;
}
