import { Global, Module } from '@nestjs/common';
import { MailerModule } from '@nestjs-modules/mailer';
import { EjsAdapter } from '@nestjs-modules/mailer/dist/adapters/ejs.adapter';
import { MailService } from '@components/mail/mail.service';
import { join } from 'path';
import { MailConfig } from '@config/mail.config';

@Global()
@Module({
  imports: [
    MailerModule.forRoot({
      transport: {
        host: new MailConfig().get('host'),
        port: new MailConfig().get('port'),
        secure: false,
        auth: {
          user: new MailConfig().get('username'),
          pass: new MailConfig().get('password'),
        },
        tls: { rejectUnauthorized: false },
      },
      defaults: {
        from: `"No Reply" <${new MailConfig().get('noReply')}>`,
      },
      template: {
        dir: join(__dirname, 'templates'),
        adapter: new EjsAdapter(),
        options: {
          strict: false,
        },
      },
    }),
  ],
  exports: [MailService],
  providers: [MailService],
  controllers: [],
})
export class MailModule {}
