import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt } from 'class-validator';

export class DeleteFactoryRequestDto extends BaseDto {
  @ApiProperty({ example: '1' })
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
