import { FactoryModule } from '@components/factory/factory.module';
import { FactoryService } from '@components/factory/factory.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ImportController } from './import.controller';
import { ImportService } from './import.service';

@Global()
@Module({
  imports: [TypeOrmModule.forFeature([]), UserModule, FactoryModule],
  exports: [
    {
      provide: 'ImportServiceInterface',
      useClass: ImportService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'FactoryServiceInterface',
      useClass: FactoryService,
    },
  ],
  providers: [
    {
      provide: 'ImportServiceInterface',
      useClass: ImportService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'FactoryServiceInterface',
      useClass: FactoryService,
    },
  ],
  controllers: [ImportController],
})
export class ImportModule {}
