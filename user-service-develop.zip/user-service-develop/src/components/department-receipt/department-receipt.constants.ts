export enum Warehouse {
  AVENUE = '0',
}

export const DEPARTMENT_RECEIPT_RULES = {
  NAME: {
    MAX_LENGTH: 255,
  },
  CODE: {
    MAX_LENGTH: 20,
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
};

export enum DepartmentReceiptStatusEnum {
  CREATED = 0,
  ACTIVE = 1,
}

export const CONFIRMABLE_DEPARTMENT_RECEIPT_STATUSES = [
  DepartmentReceiptStatusEnum.CREATED,
];

export const REJECTABLE_DEPARTMENT_RECEIPT_STATUSES = [
  DepartmentReceiptStatusEnum.ACTIVE,
];

export enum DepartmentTypeEnum {
  INTERNAL = 0,
  EXTERNAL = 1,
}
