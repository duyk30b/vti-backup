import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectDataSource } from '@nestjs/typeorm';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty, keyBy, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, In } from 'typeorm';
import { REGEX_MAIL, REGEX_PHONE } from '@constant/common';
import { ImportFileDataAbstract } from '@core/abstracts/import-file-data.abstract';
import { DepartmentReceiptRepositoryInterface } from '../interface/department-receipt.repository.interface';

@Injectable()
export class DepartmentReceiptImport extends ImportFileDataAbstract {
  private readonly FIELD_TEMPLATE_CONST = {
    CODE: {
      DB_COL_NAME: 'code',
      COL_NAME: 'Mã phòng ban nhận',
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
      REGEX: /^([a-zA-Z0-9]+)$/,
    },
    NAME: {
      DB_COL_NAME: 'name',
      COL_NAME: 'Tên phòng ban nhận',
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    TYPE: {
      DB_COL_NAME: 'departmentType',
      COL_NAME: 'Loại phòng ban',
      MAX_LENGTH: 32,
      ALLOW_NULL: false,
    },
    DESCRIPTION: {
      DB_COL_NAME: 'description',
      COL_NAME: 'Mô tả',
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    REQUIRED_COL_NUM: 4,
  };
  private readonly SHEET_NAME = this.i18n.translate(
    'file-header.SHEET_NAME_FILE_IMPORT_DEPARTMENT_RECEIPT',
  );

  private readonly ROW_NUMBER_START = 0;

  constructor(
    @Inject('DepartmentReceiptRepositoryInterface')
    private readonly departmentReceiptRepository: DepartmentReceiptRepositoryInterface,
    @InjectDataSource()
    private readonly connection: DataSource,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    const arrayField = [];
    for (const [key, value] of Object.entries(this.FIELD_TEMPLATE_CONST)) {
      arrayField.push(value);
    }

    this.fieldsMap.groupSet([1, 2, 3, 4], arrayField);
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
    error: number,
    total: number,
    userId?: number,
  ): Promise<ImportResponseDto> {
    const departmentReceiptCodes = dataDto.map((i) => i.code);
    const oldDepartmentReceipts =
      await this.departmentReceiptRepository.findByCondition({
        code: In(departmentReceiptCodes),
      });
    const entities = [];
    const logRows = [];
    const oldDepartmentReceiptKeyByCode = keyBy(oldDepartmentReceipts, 'code');
    const { successMsg, unsuccessMsg } = await this.getMessage();

    dataDto.forEach((data) => {
      const { i, code } = data;
      const logRow = { id: i, row: i } as ImportResultDto;
      let entity;
      if (data.departmentType && data.departmentType === 'Bên ngoài') {
        data.departmentType = 1;
      } else if (data.departmentType && data.departmentType === 'Nội bộ') {
        data.departmentType = 0;
      }
      if (oldDepartmentReceiptKeyByCode[code]) {
        entity = this.departmentReceiptRepository.updateEntity(
          oldDepartmentReceiptKeyByCode[code],
          { userId, ...data },
        );
      } else {
        entity = this.departmentReceiptRepository.createEntity({
          userId,
          ...data,
        });
      }
      entities.push(entity);
      logRow.log = [successMsg];
      logRows.push(logRow);
    });

    const response = new ImportResponseDto();
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(entities);
      await queryRunner.commitTransaction();
      response.successCount = entities.length;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      response.successCount = 0;
      logRows.forEach((l) => {
        l.log = [unsuccessMsg];
      });
    } finally {
      await queryRunner.release();
      logs.push(...logRows);
    }
    response.result = logs;
    response.totalCount = total;
    return response;
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<ImportResponseDto | any>> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_CONST.REQUIRED_COL_NUM,
      this.SHEET_NAME,
    );
  }
}
