import { PermissionCode } from '@core/decorator/get-code.decorator';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import {
  CONFIRM_DEPARTMENT_RECEIPT_PERMISSION,
  CREATE_DEPARTMENT_RECEIPT_PERMISSION,
  DELETE_DEPARTMENT_RECEIPT_PERMISSION,
  DETAIL_DEPARTMENT_RECEIPT_PERMISSION,
  LIST_DEPARTMENT_RECEIPT_PERMISSION,
  REJECT_DEPARTMENT_RECEIPT_PERMISSION,
  UPDATE_DEPARTMENT_RECEIPT_PERMISSION,
} from '@utils/permissions/department-receipt';
import { isEmpty } from 'lodash';
import { ConfirmDepartmentReceiptRequestDto } from './dto/request/confirm-department-receipt.request.dto';
import { CreateDepartmentReceiptRequestDto } from './dto/request/create-department-receipt.request.dto';
import { DeleteDepartmentReceiptRequestDto } from './dto/request/delete-department-receipt.request.dto';
import { GetDepartmentReceiptByCodeRequestDto } from './dto/request/get-department-receipt-by-code.request.dto';
import { GetDepartmentReceiptByIdsRequestDto } from './dto/request/get-department-receipt-by-ids.request.dto';
import { GetDepartmentReceiptByCodeOrNameRequestDto } from './dto/request/get-department-receipt-by-code-or-name.request.dto';
import { GetDepartmentReceiptRequestDto } from './dto/request/get-department-receipt-detail.request.dto';
import { GetDepartmentReceiptListRequestDto } from './dto/request/get-department-receipt-list.request.dto';
import { UpdateDepartmentReceiptBodyDto } from './dto/request/update-department-receipt.request.dto';
import { DepartmentReceiptResponseDto } from './dto/response/department-receipt.response.dto';
import { DepartmentReceiptServiceInterface } from './interface/department-receipt.service.interface';
import { NATS_USER } from '@config/nats.config';

@Controller('department-receipts')
export class DepartmentReceiptController {
  constructor(
    @Inject('DepartmentReceiptsServiceInterface')
    private readonly departmentReceiptService: DepartmentReceiptServiceInterface,
  ) {}

  @PermissionCode(CREATE_DEPARTMENT_RECEIPT_PERMISSION.code)
  @Post('create')
  @ApiOperation({
    tags: ['DepartmentReceipt'],
    summary: 'Create new department receipt',
    description: 'Tạo 1 phòng ban nhận mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async create(
    @Body() body: CreateDepartmentReceiptRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.departmentReceiptService.create(request);
  }

  //@PermissionCode(CREATE_DEPARTMENT_RECEIPT_PERMISSION.code)
  @Post('/import')
  @ApiOperation({
    tags: ['DepartmentReceipt'],
    summary: 'import department receipt',
    description: 'import  phòng ban nhận',
  })
  @ApiResponse({
    status: 200,
    description: 'import successfully',
    type: null,
  })
  public async import(@Body() body: FileUpdloadRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.departmentReceiptService.import(request);
  }

  @PermissionCode(UPDATE_DEPARTMENT_RECEIPT_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['DepartmentReceipt'],
    summary: 'Update department receipt',
    description: 'Sửa phòng ban nhận',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async update(
    @Body() body: UpdateDepartmentReceiptBodyDto,
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.departmentReceiptService.update({ ...request, id });
  }

  @PermissionCode(DELETE_DEPARTMENT_RECEIPT_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['DepartmentReceipt'],
    summary: 'Delete department receipt',
    description: 'Xóa phòng ban nhận',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async delete(
    @Param() param: DeleteDepartmentReceiptRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.departmentReceiptService.delete(request);
  }

  @PermissionCode(CONFIRM_DEPARTMENT_RECEIPT_PERMISSION.code)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['DepartmentReceipt'],
    summary: 'Confirm department receipt',
    description: 'Xác nhận phòng ban nhận',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: null,
  })
  public async confirm(
    @Param() param: ConfirmDepartmentReceiptRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.departmentReceiptService.confirm(request);
  }

  @PermissionCode(REJECT_DEPARTMENT_RECEIPT_PERMISSION.code)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['DepartmentReceipt'],
    summary: 'Rejcet department receipt',
    description: 'Từ chối phòng ban nhận',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: null,
  })
  public async reject(
    @Param() param: ConfirmDepartmentReceiptRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.departmentReceiptService.reject(request);
  }

  @PermissionCode(DETAIL_DEPARTMENT_RECEIPT_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['DepartmentReceipt'],
    summary: 'Detail department receipt',
    description: 'Chi tiết phòng ban nhận',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: DepartmentReceiptResponseDto,
  })
  public async getDetail(
    @Param() param: GetDepartmentReceiptRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.departmentReceiptService.getDetail(request);
  }

  // @PermissionCode(LIST_DEPARTMENT_RECEIPT_PERMISSION.code)
  @Get('list')
  @ApiOperation({
    tags: ['DepartmentReceipt'],
    summary: 'Get list department receipt',
    description: 'Lấy danh sách phòng ban nhận',
  })
  @ApiResponse({
    status: 200,
    description: 'Get list successfully',
    type: null,
  })
  public async getList(
    @Query() query: GetDepartmentReceiptListRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.departmentReceiptService.getList(request);
  }

  @MessagePattern(`${NATS_USER}.get_department_receipt_detail`)
  public async getDetailTcp(
    @Body() param: GetDepartmentReceiptRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.departmentReceiptService.getDetail(request);
  }

  @MessagePattern(`${NATS_USER}.get_department_receipt_by_ids`)
  public async getDepartmentReceiptByIds(
    @Body() param: GetDepartmentReceiptByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.departmentReceiptService.getDepartmentReceiptByIds(
      request.ids,
    );
  }

  @MessagePattern(`${NATS_USER}.get_department_receipt_by_code`)
  public async getDepartmentReceiptByCode(
    @Body() param: GetDepartmentReceiptByCodeRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.departmentReceiptService.getDetailByCode(request);
  }

  @MessagePattern(`${NATS_USER}.get_department_receipt_by_code_or_name`)
  public async getDepartmentReceiptByName(
    @Body() param: GetDepartmentReceiptByCodeOrNameRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.departmentReceiptService.getDetailByCodeOrName(request);
  }

  @MessagePattern(`${NATS_USER}.get_department_receipts_by_code_or_name`)
  public async getDepartmentReceiptsByCodeOrName(
    values: string[],
  ): Promise<any> {
    return await this.departmentReceiptService.getDepartmentReceiptsByCodeOrName(
      values,
    );
  }
}
