import {
  DepartmentTypeEnum,
  DEPARTMENT_RECEIPT_RULES,
} from '@components/department-receipt/department-receipt.constants';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString, MaxLength } from 'class-validator';

export class CreateDepartmentReceiptRequestDto extends BaseDto {
  @ApiProperty({ example: '', description: '' })
  @IsString()
  @MaxLength(DEPARTMENT_RECEIPT_RULES.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: '', description: '' })
  @IsString()
  @MaxLength(DEPARTMENT_RECEIPT_RULES.CODE.MAX_LENGTH)
  code: string;

  @ApiPropertyOptional({ example: '', description: '' })
  @IsOptional()
  @IsString()
  @MaxLength(DEPARTMENT_RECEIPT_RULES.DESCRIPTION.MAX_LENGTH)
  description: string;

  @ApiProperty({ example: 1, description: '' })
  @IsEnum(DepartmentTypeEnum)
  departmentType: DepartmentTypeEnum;
}
