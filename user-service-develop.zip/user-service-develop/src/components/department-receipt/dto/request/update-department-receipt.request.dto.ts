import {
  DEPARTMENT_RECEIPT_RULES,
  DepartmentTypeEnum,
} from '@components/department-receipt/department-receipt.constants';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import {
  IsEnum,
  IsInt,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';

export class UpdateDepartmentReceiptBodyDto extends BaseDto {
  @ApiProperty({ example: '', description: '' })
  @IsString()
  @MaxLength(DEPARTMENT_RECEIPT_RULES.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: '', description: '' })
  @IsOptional()
  @IsString()
  @MaxLength(DEPARTMENT_RECEIPT_RULES.DESCRIPTION.MAX_LENGTH)
  description: string;

  @ApiProperty({ example: '', description: '' })
  @IsEnum(DepartmentTypeEnum)
  departmentType: DepartmentTypeEnum;
}
export class UpdateDepartmentReceiptRequestDto extends UpdateDepartmentReceiptBodyDto {
  @ApiProperty({ example: '', description: '' })
  @Transform(({ value }) => Number(value))
  @IsInt()
  id: number;
}
