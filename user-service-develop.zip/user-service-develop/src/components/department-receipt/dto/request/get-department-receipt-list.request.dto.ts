import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsOptional, IsString } from 'class-validator';

export class GetDepartmentReceiptListRequestDto extends PaginationQuery {
  @ApiPropertyOptional({ example: '1,2,3' })
  @IsString()
  @IsOptional()
  ids?: string;
}
