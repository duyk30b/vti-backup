import { UserRepositoryInterface } from '@components/user/interface/user.repository.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { DepartmentReceiptEntity } from '@entities/department-receipt/department-receipt.entity';
import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToClass } from 'class-transformer';
import { isEmpty, keyBy, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, ILike, In } from 'typeorm';
import {
  CONFIRMABLE_DEPARTMENT_RECEIPT_STATUSES,
  DepartmentReceiptStatusEnum,
  REJECTABLE_DEPARTMENT_RECEIPT_STATUSES,
} from './department-receipt.constants';
import { ConfirmDepartmentReceiptRequestDto } from './dto/request/confirm-department-receipt.request.dto';
import { CreateDepartmentReceiptRequestDto } from './dto/request/create-department-receipt.request.dto';
import { DeleteDepartmentReceiptRequestDto } from './dto/request/delete-department-receipt.request.dto';
import { GetDepartmentReceiptByCodeRequestDto } from './dto/request/get-department-receipt-by-code.request.dto';
import { GetDepartmentReceiptByCodeOrNameRequestDto } from './dto/request/get-department-receipt-by-code-or-name.request.dto';
import { GetDepartmentReceiptRequestDto } from './dto/request/get-department-receipt-detail.request.dto';
import { GetDepartmentReceiptListRequestDto } from './dto/request/get-department-receipt-list.request.dto';
import { UpdateDepartmentReceiptRequestDto } from './dto/request/update-department-receipt.request.dto';
import { DepartmentReceiptResponseDto } from './dto/response/department-receipt.response.dto';
import { DepartmentReceiptImport } from './import/department-receipt.import.helper';
import { DepartmentReceiptRepositoryInterface } from './interface/department-receipt.repository.interface';
import { DepartmentReceiptServiceInterface } from './interface/department-receipt.service.interface';

@Injectable()
export class DepartmentReceiptService
  implements DepartmentReceiptServiceInterface
{
  constructor(
    @InjectDataSource()
    private readonly connection: DataSource,

    @Inject('UserRepositoryInterface')
    private readonly userRepository: UserRepositoryInterface,

    @Inject('DepartmentReceiptImport')
    private readonly departmentReceiptImport: DepartmentReceiptImport,

    @Inject('DepartmentReceiptRepositoryInterface')
    private readonly departmentReceiptRepository: DepartmentReceiptRepositoryInterface,
    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateDepartmentReceiptRequestDto): Promise<any> {
    const existingDepartmentReceiptEntity =
      await this.departmentReceiptRepository.findOneByCondition({
        code: ILike(request.code),
      });
    if (existingDepartmentReceiptEntity) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'message.defineDepartmentReceipt.alreadyCodeExisted',
          ),
        )
        .build();
    }
    const departmentReceipt =
      this.departmentReceiptRepository.createEntity(request);
    return await this.save(departmentReceipt);
  }

  import(request: FileUpdloadRequestDto): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
    } as ImportRequestDto;
    importRequestDto.userId = request.userId;
    return this.departmentReceiptImport.importUtil(importRequestDto);
  }

  async update(request: UpdateDepartmentReceiptRequestDto): Promise<any> {
    const existingDepartmentReceiptEntity =
      await this.departmentReceiptRepository.findOneById(request.id);

    if (!existingDepartmentReceiptEntity) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const departmentReceipt = this.departmentReceiptRepository.updateEntity(
      existingDepartmentReceiptEntity,
      request,
    );
    return await this.save(departmentReceipt);
  }

  async delete(request: DeleteDepartmentReceiptRequestDto): Promise<any> {
    const departmentReceipt =
      await this.departmentReceiptRepository.findOneById(request.id);
    if (!departmentReceipt) {
      return new ResponseBuilder(departmentReceipt)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    departmentReceipt.deletedAt = new Date();
    departmentReceipt.deletedBy = request.userId;
    await this.departmentReceiptRepository.create(departmentReceipt);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async confirm(request: ConfirmDepartmentReceiptRequestDto): Promise<any> {
    const departmentReceipt =
      await this.departmentReceiptRepository.findOneById(request.id);
    if (!departmentReceipt) {
      return new ResponseBuilder(departmentReceipt)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (
      !CONFIRMABLE_DEPARTMENT_RECEIPT_STATUSES.includes(
        departmentReceipt.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CONFIRM'))
        .build();
    }
    departmentReceipt.status = DepartmentReceiptStatusEnum.ACTIVE;
    await this.departmentReceiptRepository.create(departmentReceipt);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.changeStatusSuccess'))
      .build();
  }

  async reject(request: ConfirmDepartmentReceiptRequestDto): Promise<any> {
    const departmentReceipt =
      await this.departmentReceiptRepository.findOneById(request.id);
    if (!departmentReceipt) {
      return new ResponseBuilder(departmentReceipt)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (
      !REJECTABLE_DEPARTMENT_RECEIPT_STATUSES.includes(departmentReceipt.status)
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_REJECT'))
        .build();
    }
    departmentReceipt.status = DepartmentReceiptStatusEnum.CREATED;
    await this.departmentReceiptRepository.create(departmentReceipt);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.changeStatusSuccess'))
      .build();
  }

  async getDetail(request: GetDepartmentReceiptRequestDto): Promise<any> {
    const departmentReceipt =
      await this.departmentReceiptRepository.findOneById(request.id);

    if (!departmentReceipt) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const response = await this.generateRespone(departmentReceipt);
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getDepartmentReceiptByIds(ids: number[]): Promise<any> {
    const departmentReceipts =
      await this.departmentReceiptRepository.findByCondition({
        id: In(ids),
      });

    if (isEmpty(departmentReceipts)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const response = plainToClass(
      DepartmentReceiptResponseDto,
      departmentReceipts,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(request: GetDepartmentReceiptListRequestDto): Promise<any> {
    const { page } = request;
    const [data, count] = await this.departmentReceiptRepository.getList(
      request,
    );
    const creatorIds = uniq(data.map((item) => item.createdBy));
    const updaterIds = uniq(data.map((item) => item.updatedBy));
    const userIds = [...creatorIds, ...updaterIds];
    if (userIds.length > 0) {
      const users = await this.userRepository.findByCondition({
        id: In(uniq(userIds)),
      });
      const userMap = keyBy(users, 'id');
      data.forEach((item) => {
        item.createdBy = userMap[item.createdBy];
        item.updatedBy = userMap[item.updatedBy];
      });
    }

    const dataReturn = plainToClass(DepartmentReceiptResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async save(
    departmentReceiptEntity: DepartmentReceiptEntity,
  ): Promise<ResponsePayload<any> | any> {
    try {
      const isUpdate = departmentReceiptEntity.id !== undefined;
      const result = await this.departmentReceiptRepository.create(
        departmentReceiptEntity,
      );
      const response = await this.generateRespone(result);
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          isUpdate
            ? await this.i18n.translate(
                'message.defineDepartmentReceipt.updateSuccess',
              )
            : await this.i18n.translate(
                'message.defineDepartmentReceipt.createSuccess',
              ),
        )
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder(error)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .build();
    }
  }

  private async generateRespone(
    departmentReceiptEntity: DepartmentReceiptEntity,
  ): Promise<DepartmentReceiptResponseDto> {
    const userIds = [
      departmentReceiptEntity.createdBy,
      departmentReceiptEntity.updatedBy,
    ];
    if (userIds.length > 0) {
      const users = await this.userRepository.findByCondition({
        id: In(uniq(userIds)),
      });
      const userMap = keyBy(users, 'id');
      departmentReceiptEntity.createdBy =
        userMap[departmentReceiptEntity.createdBy];
      departmentReceiptEntity.updatedBy =
        userMap[departmentReceiptEntity.updatedBy];
    }

    const response = plainToClass(
      DepartmentReceiptResponseDto,
      departmentReceiptEntity,
      {
        excludeExtraneousValues: true,
      },
    );

    return response;
  }

  async getDetailByCode(
    request: GetDepartmentReceiptByCodeRequestDto,
  ): Promise<any> {
    const departmentReceipt =
      await this.departmentReceiptRepository.findOneByCondition({
        code: request.code,
      });

    if (!departmentReceipt) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const response = await this.generateRespone(departmentReceipt);
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getDetailByCodeOrName(
    request: GetDepartmentReceiptByCodeOrNameRequestDto,
  ): Promise<any> {
    const departmentReceipt =
      await this.departmentReceiptRepository.findOneWithRelations({
        where: [{ code: request.value }, { name: request.value }],
      });

    if (!departmentReceipt) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const response = await this.generateRespone(departmentReceipt);
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getDepartmentReceiptsByCodeOrName(values: string[]): Promise<any> {
    const departmentReceipts =
      await this.departmentReceiptRepository.findWithRelations({
        where: values.map((value) => [{ code: value }, { name: value }]).flat(),
      });

    return new ResponseBuilder({
      items: departmentReceipts,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
