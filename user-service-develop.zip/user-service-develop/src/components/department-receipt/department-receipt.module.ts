import { DepartmentReceiptEntity } from '@entities/department-receipt/department-receipt.entity';
import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DepartmentReceiptController } from './department-receipt.controller';
import { DepartmentReceiptRepository } from '@repositories/department-receipt.repository';
import { DepartmentReceiptService } from './department-receipt.service';
import { UserModule } from '@components/user/user.module';
import { UserRepository } from '@repositories/user.repository';
import { User } from '@entities/user/user.entity';
import { DepartmentReceiptImport } from './import/department-receipt.import.helper';

@Global()
@Module({
  imports: [
    TypeOrmModule.forFeature([DepartmentReceiptEntity, User]),
    UserModule,
  ],
  exports: [],
  providers: [
    {
      provide: 'DepartmentReceiptRepositoryInterface',
      useClass: DepartmentReceiptRepository,
    },
    {
      provide: 'DepartmentReceiptsServiceInterface',
      useClass: DepartmentReceiptService,
    },
    {
      provide: 'DepartmentReceiptImport',
      useClass: DepartmentReceiptImport,
    },
    {
      provide: 'UserRepositoryInterface',
      useClass: UserRepository,
    },
  ],
  controllers: [DepartmentReceiptController],
})
export class DepartmentReceiptModule {}
