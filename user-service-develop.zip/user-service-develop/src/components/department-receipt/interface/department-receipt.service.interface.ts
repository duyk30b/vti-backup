import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { ConfirmDepartmentReceiptRequestDto } from '../dto/request/confirm-department-receipt.request.dto';
import { CreateDepartmentReceiptRequestDto } from '../dto/request/create-department-receipt.request.dto';
import { DeleteDepartmentReceiptRequestDto } from '../dto/request/delete-department-receipt.request.dto';
import { GetDepartmentReceiptByCodeRequestDto } from '../dto/request/get-department-receipt-by-code.request.dto';
import { GetDepartmentReceiptByCodeOrNameRequestDto } from '../dto/request/get-department-receipt-by-code-or-name.request.dto';
import { GetDepartmentReceiptRequestDto } from '../dto/request/get-department-receipt-detail.request.dto';
import { GetDepartmentReceiptListRequestDto } from '../dto/request/get-department-receipt-list.request.dto';
import { UpdateDepartmentReceiptRequestDto } from '../dto/request/update-department-receipt.request.dto';

export interface DepartmentReceiptServiceInterface {
  getDetail(request: GetDepartmentReceiptRequestDto): Promise<any>;
  getList(request: GetDepartmentReceiptListRequestDto): Promise<any>;
  create(request: CreateDepartmentReceiptRequestDto): Promise<any>;
  update(request: UpdateDepartmentReceiptRequestDto): Promise<any>;
  delete(request: DeleteDepartmentReceiptRequestDto): Promise<any>;
  confirm(request: ConfirmDepartmentReceiptRequestDto): Promise<any>;
  reject(request: ConfirmDepartmentReceiptRequestDto): Promise<any>;
  import(request: FileUpdloadRequestDto): Promise<any>;
  getDepartmentReceiptByIds(ids: number[]): Promise<any>;
  getDetailByCode(request: GetDepartmentReceiptByCodeRequestDto): Promise<any>;
  getDetailByCodeOrName(
    request: GetDepartmentReceiptByCodeOrNameRequestDto,
  ): Promise<any>;
  getDepartmentReceiptsByCodeOrName(values: string[]): Promise<any>;
}
