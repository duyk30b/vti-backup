import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { DepartmentReceiptEntity } from '@entities/department-receipt/department-receipt.entity';
import { CreateDepartmentReceiptRequestDto } from '../dto/request/create-department-receipt.request.dto';
import { GetDepartmentReceiptListRequestDto } from '../dto/request/get-department-receipt-list.request.dto';
import { UpdateDepartmentReceiptRequestDto } from '../dto/request/update-department-receipt.request.dto';

export interface DepartmentReceiptRepositoryInterface
  extends BaseInterfaceRepository<DepartmentReceiptEntity> {
  createEntity(
    request: CreateDepartmentReceiptRequestDto,
  ): DepartmentReceiptEntity;
  updateEntity(
    reason: DepartmentReceiptEntity,
    request: UpdateDepartmentReceiptRequestDto,
  ): DepartmentReceiptEntity;
  getList(request: GetDepartmentReceiptListRequestDto): Promise<any>;
}
