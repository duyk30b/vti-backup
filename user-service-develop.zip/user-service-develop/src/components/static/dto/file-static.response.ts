import { SuccessResponse } from '@utils/success.response.dto';

export class FileStaticResponse {
  data: any;
}
