import { SuccessResponse } from '@utils/success.response.dto';

export class ChangePasswordResponseDto extends SuccessResponse {}
