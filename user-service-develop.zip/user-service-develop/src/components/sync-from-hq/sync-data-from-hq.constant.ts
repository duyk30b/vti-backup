export enum ActionTypeEnum {
  CREATE = 0,
  UPDATE = 1,
  DELETE = 2,
  CONFIRM = 3,
  REJECT = 4,
}

export enum MasterDataTypeEnum {
  COMPANY = 0,
  REASON = 1,
  ITEM_UNIT_SETTING = 2,
  COST_TYPE = 3,
  QR_SETTING = 4,
  ITEM_QUALITY = 5,
  OBJECT_CATEGORY = 6,
  MANUTFACTURING_COUNTRY = 7,
  BUSINESS_TYPE = 8,
  ITEM_TYPE_SETTING = 9,
}

export enum CompanyCreatedEnum {
  HOLDING_COMPANY = 0,
  PHU_MY = 1,
  VINH_TAN = 2,
  EPS = 3,
  MONG_DUONG = 4,
  BUON_KUOP = 5,
}
