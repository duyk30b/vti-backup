import { SyncDataFromHqRequest } from '../request/sync-from-hq.request.dto';

export interface SyncDataFromHqServiceInterface {
  syncCompanyDataFromHQ(request: SyncDataFromHqRequest): Promise<any>;
  syncCompanyDataFromHqInternal(request: SyncDataFromHqRequest): Promise<any>;
}
