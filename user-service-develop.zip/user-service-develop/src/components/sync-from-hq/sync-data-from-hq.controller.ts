import { Body, Controller, Inject, Post } from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { SyncDataFromHqServiceInterface } from './interface/sync-data-from-hq.service.interface';
import { SyncDataFromHqRequest } from './request/sync-from-hq.request.dto';
import { isEmpty, first } from 'lodash';
import { MessagePattern } from '@nestjs/microservices';
import { NATS_USER } from '@config/nats.config';
@Controller('sync')
export class SyncDataFromHqController {
  constructor(
    @Inject('SyncDataFromHqServiceInterface')
    private readonly syncDataFromHqService: SyncDataFromHqServiceInterface,
  ) {}

  @Post('company')
  @ApiOperation({
    tags: ['Sync'],
    summary: 'Sync company data from HQ',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: SuccessResponse,
  })
  async syncCompanyDataFromHQ(@Body() payload: SyncDataFromHqRequest) {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    console.log(request);

    return this.syncDataFromHqService.syncCompanyDataFromHQ(request);
  }

  @MessagePattern(`${NATS_USER}.sync_company`)
  async syncCompanyDataFromHqInternal(@Body() payload: SyncDataFromHqRequest) {
    const { request, responseError } = payload;
    console.log(JSON.stringify(request));
    console.log(request);
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.syncDataFromHqService.syncCompanyDataFromHqInternal(request);
  }
}
