import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsDateString,
  IsDefined,
  IsEmail,
  IsEnum,
  IsInt,
  IsNotEmptyObject,
  IsObject,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import {
  ActionTypeEnum,
  CompanyCreatedEnum,
  MasterDataTypeEnum,
} from '../sync-data-from-hq.constant';

export class SyncItem {
  @ApiProperty({ example: 1, description: '' })
  @IsEnum(ActionTypeEnum)
  actionType: ActionTypeEnum;

  @ApiProperty({ example: 0, description: '' })
  @IsEnum(MasterDataTypeEnum)
  masterDataType: MasterDataTypeEnum;

  @ApiProperty({ example: 1, description: '' })
  @IsEnum(CompanyCreatedEnum)
  createdFrom: CompanyCreatedEnum;

  @ApiProperty({ example: '', description: '' })
  @IsObject()
  data:
    | Company
    | Reason
    | ItemUnitSetting
    | CostType
    | QrSetting
    | ItemQuality
    | ObjectCategory
    | ManufacturingCountry
    | BusinessType
    | ItemTypeSetting;
}

enum StatusEnum {
  ACTIVE = 1,
  INACTIVE = 0,
}

class Company {
  @ApiProperty({ example: '', description: '' })
  @IsInt()
  id: number;

  @ApiProperty({ example: '', description: '' })
  @IsString()
  name: string;

  @ApiProperty({ example: '', description: '' })
  @IsString()
  code: string;

  @ApiProperty({ example: '', description: '' })
  @IsString()
  @IsOptional()
  description: string;

  @ApiProperty({ example: '', description: '' })
  @IsString()
  address: string;

  @ApiProperty({ example: '', description: '' })
  @IsString()
  phone: string;

  @ApiProperty({ example: '', description: '' })
  @IsString()
  @IsEmail()
  email: string;

  @ApiProperty({ example: '', description: '' })
  @IsEnum(StatusEnum)
  status: StatusEnum;

  @ApiProperty({ example: '', description: '' })
  @IsDateString()
  createdAt: Date;

  @ApiProperty({ example: '', description: '' })
  @IsDateString()
  updatedAt: Date;

  @ApiProperty({ example: '', description: '' })
  @IsDateString()
  deletedAt: Date;
}

class Reason {
  id: number;
  name: string;
  code: string;
  description: string;
  status: StatusEnum;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date;
}

class ItemUnitSetting {
  id: number;
  name: string;
  code: string;
  shortName: string;
  description: string;
  status: StatusEnum;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date;
}

class CostType {
  id: number;
  name: string;
  code: string;
  description: string;
  status: StatusEnum;
  organizationPayment: OrganizationPayment;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date;
}

class OrganizationPayment {
  id: number;
  name: string;
  code: string;
  description: string;
  status: StatusEnum;
  email: string;
  phone: string;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date;
}

class QrSetting {
  id: number;
  version: AttributeValue;
  initializationMethod: InitializationMethod;
  uniqueId: AttributeValue;
}

class AttributeValue {
  id: string;
  length: number;
  value: string;
}

class Attribute {
  id: string;
  length: number;
}

class InitializationMethod {
  id: Attribute;
  subId1: AttributeValue;
  subId2: AttributeValue;
  subId3: AttributeValue;
}

class ItemQuality {
  id: number;
  name: string;
  code: string;
  description: string;
  status: StatusEnum;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date;
}

class ObjectCategory {
  id: number;
  name: string;
  code: string;
  description: string;
  status: StatusEnum;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date;
}

class ManufacturingCountry {
  id: number;
  name: string;
  code: string;
  description: string;
  status: StatusEnum;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date;
}

class BusinessType {
  id: number;
  name: string;
  code: string;
  description: string;
  status: StatusEnum;
  prefixNumber: string;
  parentBusiness: number;
  businessTypeAttributes: BusinessTypeAttribute[];
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date;
}

class BusinessTypeAttribute {
  id: number;
  name: string;
  code: string;
  fieldName: string;
  ebsLabel: string;
  type: number;
  columnName: number;
  tableName: number;
  required: boolean;
  transactionBusinessTypes: TransactionBusinessType[];
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date;
}

class TransactionBusinessType {
  id: number;
  orderId: number;
  orderType: number;
  value: Date;
}

class ItemTypeSetting {
  id: number;
  name: string;
  code: string;
  description: string;
  status: StatusEnum;
  createdAt: Date;
  updatedAt: Date;
  deletedAt: Date;
  hasItemDetail: boolean;
  level: number;
  mpath: string;
  parent?: ItemTypeSetting;
}

export class MetaData {
  @ApiProperty({
    example: 10,
    type: Number,
  })
  @IsInt()
  total: number;

  @ApiProperty({
    example: new Date(),
    type: Date,
  })
  @IsDateString()
  syncTime: Date;
}

export class SyncDataFromHqRequest extends BaseDto {
  @ApiProperty({ description: '', type: SyncItem, isArray: true })
  @IsArray()
  @ValidateNested()
  @Type(() => SyncItem)
  items: SyncItem[];

  @ApiProperty({ example: '', description: '', type: MetaData })
  @IsDefined()
  @IsNotEmptyObject()
  @ValidateNested()
  @Type(() => MetaData)
  meta: MetaData;
}
