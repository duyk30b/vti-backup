import { CompanyRepositoryInterface } from '@components/company/interface/company.repository.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Company } from '@entities/company/company.entity';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { SyncDataFromHqServiceInterface } from './interface/sync-data-from-hq.service.interface';
import {
  SyncDataFromHqRequest,
  SyncItem,
} from './request/sync-from-hq.request.dto';
import { keyBy } from 'lodash';
import { In } from 'typeorm';

@Injectable()
export class SyncDataFromHqService implements SyncDataFromHqServiceInterface {
  constructor(
    @Inject('CompanyRepositoryInterface')
    private readonly companyRepository: CompanyRepositoryInterface,
  ) {}

  async syncCompanyDataFromHQ(request: SyncDataFromHqRequest): Promise<any> {
    const companyItems: Company[] = request.items.map((item: SyncItem) => {
      return item.data as Company;
    });
    const itemIdMap = keyBy(companyItems, 'id');
    const uniqItems = Object.values(itemIdMap) as Company[];
    const ItemCodes = uniqItems.map((item) => item.code);
    const existedItems = await this.companyRepository.findByCondition({
      code: In(ItemCodes),
    });
    const itemCodeMap = keyBy(uniqItems, 'code');
    const existedItemCodeMap = keyBy(existedItems, 'code');
    existedItems.forEach((item) => {
      Object.assign(item, itemCodeMap[item.code]);
    });
    const newItems = uniqItems.filter((item) => !existedItemCodeMap[item.code]);
    newItems.forEach((item) => {
      item.id = undefined;
    });
    console.log([...existedItems, ...newItems]);
    try {
      await this.companyRepository.update([...existedItems, ...newItems]);
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage('Sync company data from HQ failed')
        .build();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage('Sync company data from HQ successfully')
      .build();
  }

  async syncCompanyDataFromHqInternal(
    request: SyncDataFromHqRequest,
  ): Promise<any> {
    const companyItems: Company[] = request.items.map((item: SyncItem) => {
      return item.data as Company;
    });
    const itemIdMap = keyBy(companyItems, 'id');
    const uniqItems = Object.values(itemIdMap) as Company[];
    const ItemCodes = uniqItems.map((item) => item.code);
    const existedItems = await this.companyRepository.findByCondition({
      code: In(ItemCodes),
    });
    const itemCodeMap = keyBy(uniqItems, 'code');
    const existedItemCodeMap = keyBy(existedItems, 'code');
    existedItems.forEach((item) => {
      if (item.updatedAt < itemCodeMap[item.code].updatedAt) {
        item = { ...item, ...itemCodeMap[item.code] } as Company;
      }
    });
    const newItems = uniqItems.filter((item) => !existedItemCodeMap[item.code]);
    newItems.forEach((item) => {
      item.id = undefined;
    });
    console.log([...existedItems, ...newItems]);
    try {
      const result = await this.companyRepository.update([
        ...existedItems,
        ...newItems,
      ]);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage('Sync company data from HQ successfully')
        .withData(result)
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage('Sync company data from HQ failed')
        .build();
    }
  }
}
