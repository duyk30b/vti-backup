import { CompanyModule } from '@components/company/company.module';
import { Company } from '@entities/company/company.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CompanyRepository } from '@repositories/company.repository';
import { SyncDataFromHqController } from './sync-data-from-hq.controller';
import { SyncDataFromHqService } from './sync-data-from-hq.service';

@Module({
  imports: [TypeOrmModule.forFeature([Company]), CompanyModule],
  controllers: [SyncDataFromHqController],
  providers: [
    {
      provide: 'SyncDataFromHqServiceInterface',
      useClass: SyncDataFromHqService,
    },
    {
      provide: 'CompanyRepositoryInterface',
      useClass: CompanyRepository,
    },
  ],
  exports: [],
})
export class SyncDataFromHqModule {}
