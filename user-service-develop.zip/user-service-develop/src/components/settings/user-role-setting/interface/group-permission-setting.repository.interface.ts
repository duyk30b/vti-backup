import { GetListGroupPermissionByDepartmentIdRequestDto } from '@components/settings/category-group-permission/dto/request/get-list-group-permission-by-category-id.request.dto';
import { DepartmentGroupPermissionByDepartmentIdRequestDto } from '@components/settings/department-setting/dto/request/department-group-permission-by-department-id.request.dto';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { GroupPermissionSettingEntity } from '@entities/group-permission-setting/group-permission-setting.entity';

export interface GroupPermissionSettingRepositoryInterface
  extends BaseInterfaceRepository<GroupPermissionSettingEntity> {
  getListByDepartmentId(
    request: GetListGroupPermissionByDepartmentIdRequestDto,
  ): Promise<any>;
  groupPermissionByDepartmentId(
    request: DepartmentGroupPermissionByDepartmentIdRequestDto,
  ): Promise<any>;
}
