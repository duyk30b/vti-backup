import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { GroupPermissionSettingRepository } from '@repositories/group-permission-setting.repository';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { flatMap, uniq, isEmpty, keyBy } from 'lodash';
import { GetListCategoryGroupPermissionRequestDto } from './dto/request/get-list-category-group-permission.request.dto';
import { GetListGroupPermissionByDepartmentIdRequestDto } from './dto/request/get-list-group-permission-by-category-id.request.dto';
import { GetListGroupPermissionByDepartmentIdResponseDto } from './dto/response/get-list-group-permission-by-category-id.response';
import { GetListCategoryPermissionResponseDto } from './dto/response/get-list-category-group-permission.response.dto';
import { CategoryGroupPermissionRepositoryInterface } from './interface/category-group-permission.repository.interface';
import { CategoryGroupPermissionServiceInterface } from './interface/category-group-permission.service.interface';
import { DepartmentSettingRepository } from '@repositories/deparment.repository';
import { ApiError } from '@utils/api.error';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource } from 'typeorm';
import { InjectDataSource } from '@nestjs/typeorm';

@Injectable()
export class CategoryGroupPermissionService
  implements CategoryGroupPermissionServiceInterface
{
  constructor(
    @Inject('CategoryGroupPermissionRepositoryInterface')
    private readonly categoryGroupPermissionRepository: CategoryGroupPermissionRepositoryInterface,

    @Inject('GroupPermissionSettingRepositoryInterface')
    private readonly groupPermissionSettingRepository: GroupPermissionSettingRepository,

    @Inject('DepartmentSettingRepositoryInterface')
    private readonly departmentSettingRepository: DepartmentSettingRepository,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async getList(
    request: GetListCategoryGroupPermissionRequestDto,
  ): Promise<any> {
    const { data, count } =
      await this.categoryGroupPermissionRepository.getList(request);

    const response = plainToInstance(
      GetListCategoryPermissionResponseDto,
      data,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async getListGroupPermissionByDepartmentId(
    request: GetListGroupPermissionByDepartmentIdRequestDto,
  ): Promise<any> {
    const { departmentId, page } = request;

    const department = await this.departmentSettingRepository.findOneById(
      departmentId,
    );

    if (isEmpty(department)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.DEPARTMENT_NOT_FOUND'),
      );
    }

    const { data, count } =
      await this.groupPermissionSettingRepository.getListByDepartmentId(
        request,
      );

    const result = {
      ...department,
      groupPermissions: data,
      meta: { total: count, page: page },
    };

    const response = plainToInstance(
      GetListGroupPermissionByDepartmentIdResponseDto,
      result,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }
}
