import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { Transform } from 'class-transformer';
import { IsEnum, IsInt, IsNotEmpty, IsOptional } from 'class-validator';

export class GetListGroupPermissionByDepartmentIdRequestDto extends PaginationQuery {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  @Transform((v) => +v.value)
  departmentId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => +value)
  @IsEnum([0, 1])
  isGetAll: number;
}
