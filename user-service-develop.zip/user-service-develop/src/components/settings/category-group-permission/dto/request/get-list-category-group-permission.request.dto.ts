import { PaginationQuery } from '@utils/pagination.query';

export class GetListCategoryGroupPermissionRequestDto extends PaginationQuery {}
