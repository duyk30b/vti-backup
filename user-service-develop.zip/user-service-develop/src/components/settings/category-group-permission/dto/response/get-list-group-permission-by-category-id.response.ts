import { Expose, Type } from 'class-transformer';

class GroupPermission {
  @Expose()
  id: number;

  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  status: number;
}

class Meta {
  @Expose()
  total: number;

  @Expose()
  page: number;
}

export class GetListGroupPermissionByDepartmentIdResponseDto {
  @Expose()
  id: number;

  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  groupPermissions: GroupPermission[];

  @Expose()
  @Type(() => Meta)
  meta: Meta;
}
