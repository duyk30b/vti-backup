import { CategoryGroupPermissionEntity } from '@entities/category-group-permission/category-group-permission.entity';
import { DepartmentSetting } from '@entities/department-setting/department-setting.entity';
import { GroupPermissionSettingEntity } from '@entities/group-permission-setting/group-permission-setting.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CategoryGroupPermissionRepository } from '@repositories/category-group-permission.repository';
import { DepartmentSettingRepository } from '@repositories/deparment.repository';
import { GroupPermissionSettingRepository } from '@repositories/group-permission-setting.repository';
import { CategoryGroupPermissionController } from './category-group-permission.controller';
import { CategoryGroupPermissionService } from './category-group-permission.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      CategoryGroupPermissionEntity,
      GroupPermissionSettingEntity,
      DepartmentSetting,
    ]),
  ],
  exports: [
    {
      provide: 'CategoryGroupPermissionRepositoryInterface',
      useClass: CategoryGroupPermissionRepository,
    },
    {
      provide: 'CategoryGroupPermissionServiceInterface',
      useClass: CategoryGroupPermissionService,
    },
    {
      provide: 'GroupPermissionSettingRepositoryInterface',
      useClass: GroupPermissionSettingRepository,
    },
    {
      provide: 'DepartmentSettingRepositoryInterface',
      useClass: DepartmentSettingRepository,
    },
  ],
  providers: [
    {
      provide: 'CategoryGroupPermissionRepositoryInterface',
      useClass: CategoryGroupPermissionRepository,
    },
    {
      provide: 'CategoryGroupPermissionServiceInterface',
      useClass: CategoryGroupPermissionService,
    },
    {
      provide: 'GroupPermissionSettingRepositoryInterface',
      useClass: GroupPermissionSettingRepository,
    },
    {
      provide: 'DepartmentSettingRepositoryInterface',
      useClass: DepartmentSettingRepository,
    },
  ],
  controllers: [CategoryGroupPermissionController],
})
export class CategoryGroupPermissionModule {}
