import {
  Controller,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty } from 'lodash';
import { GetListCategoryGroupPermissionRequestDto } from './dto/request/get-list-category-group-permission.request.dto';
import { GetListGroupPermissionByDepartmentIdRequestDto } from './dto/request/get-list-group-permission-by-category-id.request.dto';
import { GetListGroupPermissionByDepartmentIdResponseDto } from './dto/response/get-list-group-permission-by-category-id.response';
import { GetListCategoryPermissionResponseDto } from './dto/response/get-list-category-group-permission.response.dto';
import { CategoryGroupPermissionServiceInterface } from './interface/category-group-permission.service.interface';

@Controller('category-group-permissions')
export class CategoryGroupPermissionController {
  constructor(
    @Inject('CategoryGroupPermissionServiceInterface')
    private readonly categoryGroupPermissionService: CategoryGroupPermissionServiceInterface,
  ) {}

  @Get('/list')
  @ApiOperation({
    tags: ['Category Group Permission'],
    summary: 'List Category Group Permission',
    description: 'Danh sách Category Group Permission',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Category Group Permission List successfully',
    type: GetListCategoryPermissionResponseDto,
  })
  public async getList(
    @Query() payload: GetListCategoryGroupPermissionRequestDto,
  ): Promise<ResponsePayload<GetListCategoryPermissionResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.categoryGroupPermissionService.getList(request);
  }

  @Get('/group-permissions')
  @ApiOperation({
    tags: ['Category Group Permission'],
    summary: 'List Group Permission By Category',
    description: 'List Group Permission By Category',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List Group Permission By Category successfully',
    type: GetListGroupPermissionByDepartmentIdResponseDto,
  })
  public async getListGroupPermissionByCategoryId(
    @Query() payload: GetListGroupPermissionByDepartmentIdRequestDto,
  ): Promise<ResponsePayload<GetListCategoryPermissionResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.categoryGroupPermissionService.getListGroupPermissionByDepartmentId(
      request,
    );
  }
}
