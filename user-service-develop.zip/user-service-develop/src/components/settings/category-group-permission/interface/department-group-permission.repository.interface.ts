import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { DepartmentGroupPermissionEntity } from '@entities/category-group-permission/department-group-permission.entity';

export interface DepartmentGroupPermissionRepositoryInterface
  extends BaseInterfaceRepository<DepartmentGroupPermissionEntity> {
  createEntity(request: any): DepartmentGroupPermissionEntity;
}
