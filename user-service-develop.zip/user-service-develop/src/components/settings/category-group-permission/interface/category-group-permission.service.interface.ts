import { GetListCategoryGroupPermissionRequestDto } from '../dto/request/get-list-category-group-permission.request.dto';
import { GetListGroupPermissionByDepartmentIdRequestDto } from '../dto/request/get-list-group-permission-by-category-id.request.dto';

export interface CategoryGroupPermissionServiceInterface {
  getList(request: GetListCategoryGroupPermissionRequestDto): Promise<any>;
  getListGroupPermissionByDepartmentId(
    request: GetListGroupPermissionByDepartmentIdRequestDto,
  ): Promise<any>;
}
