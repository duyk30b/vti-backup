import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { CategoryGroupPermissionEntity } from '@entities/category-group-permission/category-group-permission.entity';
import { GetListCategoryGroupPermissionRequestDto } from '../dto/request/get-list-category-group-permission.request.dto';

export interface CategoryGroupPermissionRepositoryInterface
  extends BaseInterfaceRepository<CategoryGroupPermissionEntity> {
  getList(request: GetListCategoryGroupPermissionRequestDto): Promise<any>;
}
