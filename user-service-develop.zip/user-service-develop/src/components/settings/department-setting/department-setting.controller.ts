import { DepartmentSettingResponseDto } from './dto/response/detail-department-setting.response.dto';
import { UpdateDepartmentSettingRequestDto } from './dto/request/update-department-setting.request.dto';
import { CreateDepartmentSettingRequestDto } from './dto/request/create-department-setting.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Req,
} from '@nestjs/common';
import { DepartmentSettingServiceInterface } from '@components/settings/department-setting/interface/department-setting.service.interface';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { GetListDepartmentSettingResponseDto } from './dto/response/get-list-department-setting.response.dto';
import { GetListDepartmentSettingRequestDto } from './dto/request/get-list-department-setting.request';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty } from 'lodash';
import { DepartmentPermissionRequestDto } from './dto/request/department-permission.request';
import { SetStatusRequestDto } from './dto/request/set-status.request.dto';
import { MessagePattern } from '@nestjs/microservices';
import { GetDepartmentIdsRequestDto } from '../user-role-setting/dto/request/get-department-ids.request.dto';
import { GetDepartmentSettingbyIdsRequestDto } from './dto/request/get-department-settings-by-ids.request.dto';
import { DepartmentGroupPermissionByDepartmentIdRequestDto } from './dto/request/department-group-permission-by-department-id.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CONFIRM_DEPARTMENT_SETTING_PERMISSION,
  CREATE_DEPARTMENT_SETTING_PERMISSION,
  DECENTRALIZATION_GROUP_DEPARTMENT_SETTING_PERMISSION,
  DELETE_DEPARTMENT_SETTING_PERMISSION,
  DETAIL_DEPARTMENT_SETTING_PERMISSION,
  LIST_DEPARTMENT_SETTING_PERMISSION,
  REJECT_DEPARTMENT_SETTING_PERMISSION,
  UPDATE_DEPARTMENT_SETTING_PERMISSION,
} from '@utils/permissions/department-setting';
import { GetDepartmentSettingByKeywordRequestDto } from './dto/request/get-department-setting-by-keyword.request.dto';
import { NATS_USER } from '@config/nats.config';
import {
  CREATE_USER_PERMISSION,
  UPDATE_USER_PERMISSION,
} from '@utils/permissions/user';
import { UPDATE_USER_ROLE_SETTING_PERMISSION } from '@utils/permissions/user-role-setting';

@Controller('department-settings')
export class DepartmentSettingController {
  constructor(
    @Inject('DepartmentSettingServiceInterface')
    private readonly departmentSettingService: DepartmentSettingServiceInterface,
  ) {}
  @MessagePattern(`${NATS_USER}.get_department_settings_by_keyword`)
  public async getDepartmentSettingByKeyword(
    @Body() payload: GetDepartmentSettingByKeywordRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.departmentSettingService.getDepartmentSettingByKeyword(
      request,
    );
  }
  @PermissionCode(
    LIST_DEPARTMENT_SETTING_PERMISSION.code,
    UPDATE_USER_ROLE_SETTING_PERMISSION.code,
  )
  @Get('/list')
  @ApiOperation({
    tags: ['Department Setting'],
    summary: 'List Department Setting',
    description: 'Danh sách bộ phận',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Department Setting List successfully',
    type: GetListDepartmentSettingResponseDto,
  })
  public async getList(
    @Query() payload: GetListDepartmentSettingRequestDto,
  ): Promise<ResponsePayload<GetListDepartmentSettingResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.departmentSettingService.getList(request);
  }

  @PermissionCode(DETAIL_DEPARTMENT_SETTING_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Department Setting'],
    summary: 'Detail Department Setting',
    description: 'Chi tiết bộ phận',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Department Setting detail successfully',
    type: DepartmentSettingResponseDto,
  })
  public async getDetail(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<DepartmentSettingResponseDto | any>> {
    return await this.departmentSettingService.getDetail(id);
  }

  @Post('/:id/group-permissions')
  @ApiOperation({
    tags: ['Department Setting'],
    summary: 'Post Department Setting',
    description: 'Phân quyền chức năng bộ phận',
  })
  @ApiResponse({
    status: 200,
    description: 'Post Department Setting successfully',
    type: GetListDepartmentSettingResponseDto,
  })
  public async updateDepartmentGroupPermission(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: DepartmentPermissionRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;
    return await this.departmentSettingService.updateDepartmentGroupPermission(
      request,
    );
  }

  @PermissionCode(
    DECENTRALIZATION_GROUP_DEPARTMENT_SETTING_PERMISSION.code,
    UPDATE_USER_ROLE_SETTING_PERMISSION.code,
    CREATE_USER_PERMISSION.code,
    UPDATE_USER_PERMISSION.code,
  )
  @Get('/:departmentId/group-permissions')
  @ApiOperation({
    tags: ['Department Setting'],
    summary: 'Get Department Setting',
    description: 'Phân quyền chức năng bộ phận',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Department Setting successfully',
    type: GetListDepartmentSettingResponseDto,
  })
  public async departmentGroupPermissionByDepartmentId(
    @Param('departmentId', new ParseIntPipe()) departmentId,
    @Query() payload: DepartmentGroupPermissionByDepartmentIdRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.departmentSettingService.departmentGroupPermissionByDepartmentId(
      {
        ...request,
        departmentId,
      },
    );
  }

  @PermissionCode(CREATE_DEPARTMENT_SETTING_PERMISSION.code)
  @Post('/')
  @ApiOperation({
    tags: ['Department Setting'],
    summary: 'Create Department Setting',
    description: 'Tạo mới một bộ phận',
  })
  @ApiResponse({
    status: 200,
    description: 'Tạo thành công Bộ phận',
    type: SuccessResponse,
  })
  public async create(
    @Body() payload: CreateDepartmentSettingRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.departmentSettingService.create(request);
  }

  @PermissionCode(UPDATE_DEPARTMENT_SETTING_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Department Setting'],
    summary: 'Update Department Setting',
    description: 'Cập nhật một bộ phận',
  })
  @ApiResponse({
    status: 200,
    description: 'Cập nhật thành công Bộ phận',
    type: SuccessResponse,
  })
  public async update(
    @Param('id', new ParseIntPipe()) departmentId: number,
    @Body() payload: UpdateDepartmentSettingRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.departmentSettingService.update(departmentId, request);
  }

  @PermissionCode(DELETE_DEPARTMENT_SETTING_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Department Setting'],
    summary: 'Delete Department Setting',
    description: 'Xóa một bộ phận',
  })
  @ApiResponse({
    status: 200,
    description: 'Xóa thành công Bộ phận',
    type: SuccessResponse,
  })
  public async delete(
    @Param('id', new ParseIntPipe()) departmentId: number,
  ): Promise<ResponsePayload<any>> {
    return this.departmentSettingService.delete(departmentId);
  }

  @PermissionCode(CONFIRM_DEPARTMENT_SETTING_PERMISSION.code)
  // @MessagePattern('confirm_factory')
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Department'],
    summary: 'Confirm Department',
    description: 'Xác nhận bộ phận',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: SuccessResponse,
  })
  public async confirm(
    @Param() payload: SetStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.departmentSettingService.confirm(request);
  }

  // @MessagePattern('reject_factory')
  @PermissionCode(REJECT_DEPARTMENT_SETTING_PERMISSION.code)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Department'],
    summary: 'Reject Department',
    description: 'Từ chối xác nhận bộ phận',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: SuccessResponse,
  })
  public async reject(
    @Param() payload: SetStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.departmentSettingService.reject(request);
  }

  @MessagePattern(`${NATS_USER}.get_department_setting_by_ids`)
  public async getDepartmentSettingByIds(
    @Body() payload: GetDepartmentSettingbyIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.departmentSettingService.getDepartmentSettingByIds(
      request,
    );
  }
}
