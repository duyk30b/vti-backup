export enum DepartmentSettingStatusEnum {
  INACTIVE = 0,
  ACTIVE = 1,
}
