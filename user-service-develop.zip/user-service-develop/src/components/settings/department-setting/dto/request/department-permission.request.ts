import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { EnumStatus } from '@utils/common';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsNotEmpty,
  IsEnum,
  IsInt,
  IsOptional,
} from 'class-validator';

class GroupPermission {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(() => EnumStatus)
  status: EnumStatus;
}
export class DepartmentPermissionRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsArray()
  @Type(() => GroupPermission)
  groupPermissions: GroupPermission[];
}
