import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { ArrayNotEmpty, IsArray } from 'class-validator';

export class GetDepartmentSettingbyIdsRequestDto extends BaseDto {
  @ApiProperty({ example: '' })
  @IsArray()
  @ArrayNotEmpty()
  departmentSettingIds: number[];
}
