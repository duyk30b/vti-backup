import { BaseDto } from '@core/dto/base.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsString } from 'class-validator';

export class GetDepartmentSettingByKeywordRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsString()
  departmentSettingKeyword: string;
}
