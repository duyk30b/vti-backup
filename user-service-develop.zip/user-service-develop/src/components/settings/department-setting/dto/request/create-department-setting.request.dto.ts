import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';

export class CreateDepartmentSettingRequestDto extends BaseDto {
  @ApiProperty({ example: 'DP000001', description: 'department setting code' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(20)
  code: string;

  @ApiProperty({ example: 'Kho', description: 'department setting name' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiPropertyOptional({
    example: 'Day la kho thoc',
    description: 'department setting description',
  })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;
}
