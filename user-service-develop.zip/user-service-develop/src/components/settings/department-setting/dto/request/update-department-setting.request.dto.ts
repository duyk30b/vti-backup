import { BaseDto } from '@core/dto/base.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsString, MaxLength } from 'class-validator';

export class UpdateDepartmentSettingRequestDto extends BaseDto {
  @ApiPropertyOptional({
    example: 'Kho',
    description: 'department setting name',
  })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiPropertyOptional({
    example: 'Day la kho thoc',
    description: 'department setting description',
  })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;
}
