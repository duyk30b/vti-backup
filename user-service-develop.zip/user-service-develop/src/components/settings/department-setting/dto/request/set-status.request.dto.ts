import { ApiProperty } from '@nestjs/swagger';
import { IsInt } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { Transform } from 'class-transformer';
export class SetStatusRequestDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'id' })
  @Transform(({ value }) => Number(value))
  @IsInt()
  id: number;
}
