import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty, IsOptional } from 'class-validator';

export class DepartmentGroupPermissionByDepartmentIdRequestDto extends PaginationQuery {
  @ApiProperty()
  @IsOptional()
  @IsInt()
  departmentId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  @Transform((v) => +v.value)
  roleId: number;
}
