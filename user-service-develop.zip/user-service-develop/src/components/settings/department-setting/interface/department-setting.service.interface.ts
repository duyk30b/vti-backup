import { ResponsePayload } from '@utils/response-payload';
import { UpdateDepartmentSettingRequestDto } from './../dto/request/update-department-setting.request.dto';
import { CreateDepartmentSettingRequestDto } from './../dto/request/create-department-setting.request.dto';
import { DepartmentPermissionRequestDto } from '../dto/request/department-permission.request';
import { GetListDepartmentSettingRequestDto } from '../dto/request/get-list-department-setting.request';
import { SetStatusRequestDto } from '../dto/request/set-status.request.dto';
import { GetDepartmentSettingbyIdsRequestDto } from '../dto/request/get-department-settings-by-ids.request.dto';
import { DepartmentGroupPermissionByDepartmentIdRequestDto } from '../dto/request/department-group-permission-by-department-id.request.dto';
import { GetDepartmentSettingByKeywordRequestDto } from '../dto/request/get-department-setting-by-keyword.request.dto';

export interface DepartmentSettingServiceInterface {
  getList(request: GetListDepartmentSettingRequestDto): Promise<any>;
  updateDepartmentGroupPermission(
    request: DepartmentPermissionRequestDto,
  ): Promise<any>;
  create(
    request: CreateDepartmentSettingRequestDto,
  ): Promise<ResponsePayload<any>>;
  update(
    departmentId: number,
    request: UpdateDepartmentSettingRequestDto,
  ): Promise<ResponsePayload<any>>;
  delete(departmentId: number): Promise<ResponsePayload<any>>;
  getDetail(departmentId: number): Promise<ResponsePayload<any>>;
  confirm(request: SetStatusRequestDto): Promise<ResponsePayload<any>>;
  reject(request: SetStatusRequestDto): Promise<ResponsePayload<any>>;
  getDepartmentSettingByIds(
    request: GetDepartmentSettingbyIdsRequestDto,
  ): Promise<any>;
  departmentGroupPermissionByDepartmentId(
    request: DepartmentGroupPermissionByDepartmentIdRequestDto,
  ): Promise<any>;
  getDepartmentSettingByKeyword(
    keyword: GetDepartmentSettingByKeywordRequestDto,
  ): Promise<any>;
}
