import { UpdateDepartmentSettingRequestDto } from './../dto/request/update-department-setting.request.dto';
import { CreateDepartmentSettingRequestDto } from './../dto/request/create-department-setting.request.dto';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { DepartmentSetting } from '@entities/department-setting/department-setting.entity';
import { GetListDepartmentSettingRequestDto } from '../dto/request/get-list-department-setting.request';
import { GetDepartmentSettingByKeywordRequestDto } from '../dto/request/get-department-setting-by-keyword.request.dto';

export interface DepartmentSettingRepositoryInterface
  extends BaseInterfaceRepository<DepartmentSetting> {
  getListRoleAndPermissionOfDepartment(): Promise<any>;
  getRoleAndDepartment(): Promise<any>;
  getList(request: GetListDepartmentSettingRequestDto): Promise<any>;
  createEntity(request: CreateDepartmentSettingRequestDto): DepartmentSetting;
  updateEntity(
    departmentEntity: DepartmentSetting,
    request: UpdateDepartmentSettingRequestDto,
  ): DepartmentSetting;
  findDepartmentSettingByKeyword(
    request: GetDepartmentSettingByKeywordRequestDto,
  ): Promise<any>;
}
