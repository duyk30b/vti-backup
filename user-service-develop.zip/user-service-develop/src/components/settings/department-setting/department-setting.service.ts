import { DepartmentSettingStatusEnum } from '@components/settings/department-setting/department-setting.constant';
import { DepartmentResponseDto } from './../user-role-setting/dto/response/get-list-role-permission-department.response.dto';
import { DepartmentSettingResponseDto } from './dto/response/detail-department-setting.response.dto';
import { CreateDepartmentSettingRequestDto } from './dto/request/create-department-setting.request.dto';
import { UpdateDepartmentSettingRequestDto } from './dto/request/update-department-setting.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { Inject, Injectable } from '@nestjs/common';
import { DepartmentSettingServiceInterface } from '@components/settings/department-setting/interface/department-setting.service.interface';
import { DepartmentSettingRepositoryInterface } from '@components/settings/department-setting/interface/department-setting.repository.interface';
import { GetListDepartmentSettingRequestDto } from './dto/request/get-list-department-setting.request';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { plainToInstance } from 'class-transformer';
import { PagingResponse } from '@utils/paging.response';
import { GetListDepartmentSettingResponseDto } from './dto/response/get-list-department-setting.response.dto';
import { DepartmentPermissionRequestDto } from './dto/request/department-permission.request';
import { DataSource, In } from 'typeorm';
import { ApiError } from '@utils/api.error';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { flatMap, uniq, isEmpty, keyBy } from 'lodash';
import { GroupPermissionSettingRepository } from '@repositories/group-permission-setting.repository';
import { InjectDataSource } from '@nestjs/typeorm';
import { CategoryGroupPermissionRepository } from '@repositories/category-group-permission.repository';
import { DepartmentGroupPermissionRepository } from '@repositories/department-group-permission.repository';
import { DepartmentGroupPermissionEntity } from '@entities/category-group-permission/department-group-permission.entity';
import { SetStatusRequestDto } from './dto/request/set-status.request.dto';
import { GetDepartmentSettingbyIdsRequestDto } from './dto/request/get-department-settings-by-ids.request.dto';
import { DepartmentPermissionResponseDto } from './dto/response/department-permission.response.dto';
import { DepartmentGroupPermissionByDepartmentIdRequestDto } from './dto/request/department-group-permission-by-department-id.request.dto';
import { UserRoleSettingRepository } from '@repositories/user-role-setting.repository';
import { GetDepartmentSettingByKeywordRequestDto } from './dto/request/get-department-setting-by-keyword.request.dto';

@Injectable()
export class DepartmentSettingService
  implements DepartmentSettingServiceInterface
{
  constructor(
    @Inject('DepartmentRepositoryInterface')
    private readonly departmentSettingRepository: DepartmentSettingRepositoryInterface,

    @Inject('CategoryGroupPermissionRepositoryInterface')
    private readonly categoryGroupPermissionRepository: CategoryGroupPermissionRepository,

    @Inject('GroupPermissionSettingRepositoryInterface')
    private readonly groupPermissionSettingRepository: GroupPermissionSettingRepository,

    @Inject('DepartmentGroupPermissionRepositoryInterface')
    private readonly departmentGroupPermissionRepository: DepartmentGroupPermissionRepository,

    @Inject('UserRoleSettingRepositoryInterface')
    private readonly userRoleSettingRepository: UserRoleSettingRepository,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async getList(request: GetListDepartmentSettingRequestDto): Promise<any> {
    const { data, count } = await this.departmentSettingRepository.getList(
      request,
    );

    const response = plainToInstance(
      GetListDepartmentSettingResponseDto,
      data,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async updateDepartmentGroupPermission(
    request: DepartmentPermissionRequestDto,
  ): Promise<any> {
    const { id, groupPermissions } = request;
    const department = await this.departmentSettingRepository.findOneById(id);
    if (isEmpty(department)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.DEPARTMENT_NOT_FOUND'),
      ).toResponse();
    }

    const groupPermissionIds = groupPermissions.map((i) => i.id);
    const groupPermissionExist =
      await this.groupPermissionSettingRepository.findByCondition({
        id: In(groupPermissionIds),
      });
    if (groupPermissionExist.length !== groupPermissionIds.length) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.GROUP_PERMISSION_NOT_FOUND'),
      ).toResponse();
    }
    const groupPermissionMap = keyBy(groupPermissions, 'id');
    const conditionDepartmentGroupPermission = [];
    for (let i = 0; i < groupPermissions.length; i++) {
      conditionDepartmentGroupPermission.push({
        departmentId: id,
        groupPermissionId: groupPermissions[i].id,
      });
    }

    let oldDepartmentGroupPermissions =
      await this.departmentGroupPermissionRepository.findByCondition(
        conditionDepartmentGroupPermission,
      );

    if (!isEmpty(oldDepartmentGroupPermissions)) {
      oldDepartmentGroupPermissions = oldDepartmentGroupPermissions.map((i) => {
        return {
          ...i,
          status: groupPermissionMap[`${i.groupPermissionId}`]?.status,
        };
      });
    }

    const newDepartmentGroupPermissions = groupPermissions.filter(
      ({ id: id }) =>
        !oldDepartmentGroupPermissions.some(
          ({ groupPermissionId: groupPermissionId }) =>
            groupPermissionId === id,
        ),
    );
    const newDepartmentGroupPermissionEntities =
      newDepartmentGroupPermissions?.map((i) => {
        return this.departmentGroupPermissionRepository.createEntity({
          ...i,
          groupPermissionId: i.id,
          departmentId: id,
        });
      });

    let result;
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (!isEmpty(oldDepartmentGroupPermissions))
        await queryRunner.manager.save(
          DepartmentGroupPermissionEntity,
          oldDepartmentGroupPermissions,
        );

      if (!isEmpty(newDepartmentGroupPermissionEntities))
        await queryRunner.manager.save(
          DepartmentGroupPermissionEntity,
          newDepartmentGroupPermissionEntities,
        );
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder(error)
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    } finally {
      await queryRunner.release();
    }

    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async departmentGroupPermissionByDepartmentId(
    request: DepartmentGroupPermissionByDepartmentIdRequestDto,
  ): Promise<any> {
    const { departmentId, roleId, page } = request;
    const department = await this.departmentSettingRepository.findOneById(
      departmentId,
    );

    if (isEmpty(department)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.DEPARTMENT_NOT_FOUND'),
      ).toResponse();
    }

    const role = await this.userRoleSettingRepository.findOneById(roleId);

    if (isEmpty(role)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.USER_ROLE_NOT_FOUND'),
      ).toResponse();
    }

    const { data, count } =
      await this.groupPermissionSettingRepository.groupPermissionByDepartmentId(
        request,
      );

    const result = {
      ...department,
      groupPermissions: data,
      meta: { total: count, page: page },
    };

    const response = plainToInstance(DepartmentPermissionResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
  public async create(
    request: CreateDepartmentSettingRequestDto,
  ): Promise<ResponsePayload<any>> {
    const departmentExist =
      await this.departmentSettingRepository.findOneByCondition({
        code: request.code,
      });

    if (!isEmpty(departmentExist)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.CODE_ALREADY_EXISTS'))
        .build();
    }

    const departmentEntity =
      this.departmentSettingRepository.createEntity(request);

    await this.departmentSettingRepository.create(departmentEntity);

    return new ResponseBuilder(departmentEntity)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async update(
    departmentId: number,
    request: UpdateDepartmentSettingRequestDto,
  ): Promise<ResponsePayload<any>> {
    const department = await this.departmentSettingRepository.findOneById(
      departmentId,
    );

    if (!department) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const departmentEntity = this.departmentSettingRepository.updateEntity(
      department,
      request,
    );
    await this.departmentSettingRepository.update(departmentEntity);

    return new ResponseBuilder(departmentEntity)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async delete(departmentId: number): Promise<ResponsePayload<any>> {
    const department = await this.departmentSettingRepository.findOneById(
      departmentId,
    );

    if (!department) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    await this.departmentSettingRepository.softDelete(departmentId);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getDetail(departmentId: number): Promise<ResponsePayload<any>> {
    const department = await this.departmentSettingRepository.findOneById(
      departmentId,
    );

    if (!department) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const response = plainToInstance(DepartmentSettingResponseDto, department, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id } = request;
    const department = await this.departmentSettingRepository.findOneById(id);

    if (!department) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (department.status === DepartmentSettingStatusEnum.ACTIVE) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.CAN_NOT_CONFIRM'),
      ).toResponse();
    }

    department.status = DepartmentSettingStatusEnum.ACTIVE;
    const result = await this.departmentSettingRepository.create(department);

    const response = plainToInstance(DepartmentResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async reject(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id } = request;
    const department = await this.departmentSettingRepository.findOneById(id);

    if (!department) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (department.status === DepartmentSettingStatusEnum.INACTIVE) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_REJECT'),
      ).toResponse();
    }

    department.status = DepartmentSettingStatusEnum.INACTIVE;
    const result = await this.departmentSettingRepository.create(department);

    const response = plainToInstance(DepartmentResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getDepartmentSettingByIds(
    request: GetDepartmentSettingbyIdsRequestDto,
  ): Promise<any> {
    const result = await this.departmentSettingRepository.findByCondition({
      id: In(request.departmentSettingIds),
    });
    const response = plainToInstance(DepartmentSettingResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }
  async getDepartmentSettingByKeyword(
    request: GetDepartmentSettingByKeywordRequestDto,
  ): Promise<any> {
    const departmentSettings =
      await this.departmentSettingRepository.findDepartmentSettingByKeyword(
        request,
      );

    return new ResponseBuilder(departmentSettings)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.success'))
      .build();
  }
}
