import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DepartmentSetting } from '@entities/department-setting/department-setting.entity';
import { DepartmentSettingRepository } from '@repositories/deparment.repository';
import { DepartmentSettingService } from '@components/settings/department-setting/department-setting.service';
import { DepartmentSettingController } from '@components/settings/department-setting/department-setting.controller';
import { GroupPermissionSettingRepository } from '@repositories/group-permission-setting.repository';
import { GroupPermissionSettingEntity } from '@entities/group-permission-setting/group-permission-setting.entity';
import { CategoryGroupPermissionEntity } from '@entities/category-group-permission/category-group-permission.entity';
import { DepartmentGroupPermissionEntity } from '@entities/category-group-permission/department-group-permission.entity';
import { CategoryGroupPermissionRepository } from '@repositories/category-group-permission.repository';
import { DepartmentGroupPermissionRepository } from '@repositories/department-group-permission.repository';
import { UserRoleSettingRepository } from '@repositories/user-role-setting.repository';
import { UserRoleSetting } from '@entities/user-role-setting/user-role-setting.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      DepartmentSetting,
      CategoryGroupPermissionEntity,
      GroupPermissionSettingEntity,
      DepartmentGroupPermissionEntity,
      UserRoleSetting,
    ]),
  ],
  providers: [
    {
      provide: 'DepartmentRepositoryInterface',
      useClass: DepartmentSettingRepository,
    },
    {
      provide: 'DepartmentSettingServiceInterface',
      useClass: DepartmentSettingService,
    },
    {
      provide: 'CategoryGroupPermissionRepositoryInterface',
      useClass: CategoryGroupPermissionRepository,
    },
    {
      provide: 'GroupPermissionSettingRepositoryInterface',
      useClass: GroupPermissionSettingRepository,
    },
    {
      provide: 'DepartmentGroupPermissionRepositoryInterface',
      useClass: DepartmentGroupPermissionRepository,
    },
    {
      provide: 'UserRoleSettingRepositoryInterface',
      useClass: UserRoleSettingRepository,
    },
  ],
  controllers: [DepartmentSettingController],
})
export class DepartmentSettingModule {}
