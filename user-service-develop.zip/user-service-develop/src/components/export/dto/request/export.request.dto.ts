import { PaginationQuery } from '@utils/pagination.query';
import { TypeEnum } from '@components/export/export.constant';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsEnum, IsOptional, IsString } from 'class-validator';
import { Transform } from 'class-transformer';

export class ExportRequestDto extends PaginationQuery {
  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => {
    if (value?.split(',').length > 0)
      return value.split(',').map((id) => Number(id));
    else return null;
  })
  ids: number[];

  @ApiProperty()
  @IsEnum(TypeEnum)
  @Transform(({ value }) => Number(value))
  @IsNotEmpty()
  type: number;
}
