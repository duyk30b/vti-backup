import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';

@Injectable()
export class ProduceService implements ProduceServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  public async getFactoryIdsBySaleOrderIds(
    saleOrderIds: number[],
  ): Promise<any> {
    const payload = {
      saleOrderIds,
    };
    const response = await this.natsClientService.send(
      'get_factory_ids_by_sale_order_ids',
      payload,
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    return response.data;
  }
}
