import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('category_group_permissions')
export class CategoryGroupPermissionEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
  })
  code: string;

  @Column({
    type: 'varchar',
  })
  name: string;

  @Column({
    type: 'varchar',
  })
  description: string;
}
