import { EnumStatus } from '@utils/common';
import { Column, Entity, PrimaryColumn } from 'typeorm';

@Entity('department_group_permissions')
export class DepartmentGroupPermissionEntity {
  @PrimaryColumn({
    type: 'int',
  })
  departmentId: number;

  @PrimaryColumn({
    type: 'int',
  })
  groupPermissionId: number;

  @Column()
  status: EnumStatus;
}
