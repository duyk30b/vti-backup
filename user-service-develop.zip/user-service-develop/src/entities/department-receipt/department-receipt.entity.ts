import {
  DepartmentReceiptStatusEnum,
  DEPARTMENT_RECEIPT_RULES,
  DepartmentTypeEnum,
  Warehouse,
} from '@components/department-receipt/department-receipt.constants';
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity({ name: 'department_receipts' })
export class DepartmentReceiptEntity {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
    length: DEPARTMENT_RECEIPT_RULES.NAME.MAX_LENGTH,
  })
  name: string;

  @Column({
    type: 'varchar',
    length: DEPARTMENT_RECEIPT_RULES.CODE.MAX_LENGTH,
  })
  code: string;

  @Column({
    type: 'int',
  })
  departmentType: DepartmentTypeEnum;

  @Column({
    type: 'varchar',
    length: DEPARTMENT_RECEIPT_RULES.DESCRIPTION.MAX_LENGTH,
  })
  description: string;

  @Column({
    type: 'varchar',
    default: DepartmentReceiptStatusEnum.CREATED,
  })
  status: DepartmentReceiptStatusEnum;

  @Column({
    type: 'int',
  })
  createdBy: number;

  @Column({
    type: 'int',
  })
  updatedBy: number;

  @Column({
    type: 'int',
  })
  deletedBy: number;

  @Column()
  @CreateDateColumn()
  createdAt: Date;

  @Column()
  @UpdateDateColumn()
  updatedAt: Date;

  @Column()
  @DeleteDateColumn()
  deletedAt: Date;

  @Column({
    type: 'varchar',
    nullable: true,
  })
  createdFrom: Warehouse;

  @Column({
    type: 'jsonb',
    nullable: true,
  })
  syncStatus: [];
}
