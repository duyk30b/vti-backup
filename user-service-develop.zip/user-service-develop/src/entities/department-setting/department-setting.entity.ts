import { DepartmentSettingStatusEnum } from '@components/settings/department-setting/department-setting.constant';
import {
  Column,
  Entity,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToMany,
  JoinTable,
  PrimaryGeneratedColumn,
  DeleteDateColumn,
} from 'typeorm';

import { User } from '../user/user.entity';

@Entity({ name: 'department_settings' })
export class DepartmentSetting {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
  })
  name: string;

  @Column({
    type: 'varchar',
  })
  code: string;

  @Column({
    type: 'int',
    default: DepartmentSettingStatusEnum.ACTIVE,
  })
  status: number;

  @Column({
    type: 'varchar',
    length: 255,
    nullable: true,
  })
  description: string;

  @Column()
  @CreateDateColumn()
  createdAt: Date;

  @Column()
  @UpdateDateColumn()
  updatedAt: Date;

  @ManyToMany(() => User)
  @JoinTable()
  user: User;

  @Column()
  @DeleteDateColumn()
  deletedAt: Date;
}
