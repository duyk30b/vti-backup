package main

import (
	app "iot-adapter/pkg"
)

func main() {
	server := app.App{}

	server.Init()
}
