package test

import (
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type TestModule struct {
	c *Controller
}

func (t *TestModule) Init(rE *gin.Engine, db *gorm.DB) *TestModule {

	t.c.Init(rE, db)

	return t
}
