package dto

type CreateTestRequestDto struct {
	Name string `json:"name" validate:"required,max=1"`
}

type GetTestRequestDto struct {
	Id int
}

type TestDto struct {
	Id int `json:"id"`
	// Name string `json:"name"`
}
