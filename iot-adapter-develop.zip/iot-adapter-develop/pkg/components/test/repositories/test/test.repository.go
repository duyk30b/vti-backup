package repositories

import (
	entities "iot-adapter/pkg/components/test/entities/test"

	"gorm.io/gorm"
)

type TestRepositoryInterface interface {
	FindAll() []entities.Test
	Save(test entities.Test) entities.Test
}

type testRepository struct {
	DB *gorm.DB
}

func NewTestRepository(DB *gorm.DB) TestRepositoryInterface {
	return &testRepository{
		DB: DB,
	}
}

func (t *testRepository) FindAll() []entities.Test {
	var results []entities.Test

	t.DB.Find(&results)

	return results
}

func (t *testRepository) Save(test entities.Test) entities.Test {
	t.DB.Save(&test)

	return test
}
