package test

import (
	"iot-adapter/pkg/components/test/dto"
	repositories "iot-adapter/pkg/components/test/repositories/test"
	"iot-adapter/pkg/components/test/services"

	mapperDto "github.com/dranikpg/dto-mapper"
	"github.com/gin-gonic/gin"
	"github.com/go-playground/validator/v10"
	"gorm.io/gorm"
)

type Controller struct {
	r  *gin.Engine
	db *gorm.DB
}

var validate *validator.Validate

func (c *Controller) Init(rE *gin.Engine, db *gorm.DB) *Controller {
	validate = validator.New()
	testRespository := repositories.NewTestRepository(db)
	testService := services.NewTestService(testRespository)

	rE.POST("/test", func(ctx *gin.Context) {
		testRequestBody := new(dto.CreateTestRequestDto)
		err := ctx.BindJSON(testRequestBody)
		err = validate.Struct(testRequestBody)

		if err != nil {
			ctx.JSON(403, err.(validator.ValidationErrors).Error())
			return
		}

		test, err := testService.Create(*testRequestBody)

		if err != nil {
			ctx.JSON(403, err.Error())
		}
		response := dto.TestDto{}
		mapperDto.Map(&response, test)
		ctx.JSON(200, response)
	})

	return c
}
