package services

import (
	"iot-adapter/pkg/components/test/dto"
	entities "iot-adapter/pkg/components/test/entities/test"
	repositories "iot-adapter/pkg/components/test/repositories/test"
)

type TestServiceInterface interface {
	Create(body dto.CreateTestRequestDto) (entities.Test, error)
}

type testService struct {
	TestRepository repositories.TestRepositoryInterface
}

func NewTestService(
	testRepository repositories.TestRepositoryInterface,
) TestServiceInterface {
	return &testService{
		TestRepository: testRepository,
	}
}

func (service *testService) Create(body dto.CreateTestRequestDto) (entities.Test, error) {
	testEntity := entities.Test{
		Name: body.Name,
	}

	test := service.TestRepository.Save(testEntity)
	return test, nil
}
