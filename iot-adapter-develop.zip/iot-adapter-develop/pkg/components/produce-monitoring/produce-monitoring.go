package producemonitoring

import (
	"github.com/Shopify/sarama"
	mqtt "github.com/eclipse/paho.mqtt.golang"
)

type ProduceMonitoringModule struct {
	SyncProducer sarama.SyncProducer
}

func (p *ProduceMonitoringModule) Init(syncProducer *sarama.SyncProducer) map[string]interface{} {
	p.SyncProducer = *syncProducer
	topicName := map[string]string{
		"PRODUCE_MONITORING": "produceMonitoring",
	}

	return map[string]interface{}{
		topicName["PRODUCE_MONITORING"]: p.produceMonitoringHandler,
	}
}

func (p *ProduceMonitoringModule) produceMonitoringHandler(msg mqtt.Message) {
	//@ TODO
	p.SyncProducer.SendMessage(&sarama.ProducerMessage{
		Topic: msg.Topic(),
		Value: sarama.StringEncoder(string(msg.Payload())),
	})
}
