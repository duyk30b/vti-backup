package dto

type ProduceMonitoringRequestDto struct {
	ApiVersion string `json:"apiVersion""`
	DeviceName string `json:"deviceName""`
}
