package events

import (
	"github.com/Shopify/sarama"
	mqtt "github.com/mochi-co/mqtt/server"
	"github.com/mochi-co/mqtt/server/events"
)

type Event struct {
	Server       *mqtt.Server
	SyncProducer sarama.SyncProducer
}

func (e *Event) OnConnect() {
	e.Server.Events.OnConnect = func(cl events.Client, pk events.Packet) {
		// fmt.Printf("<< OnConnect client connected %s: %+v\n", cl.ID)
	}
}

func (e *Event) pubEvent(message string) {
	// TODO implement middleware to get topic
	topic := "sync_item_master_data"

	e.SyncProducer.SendMessage(&sarama.ProducerMessage{
		Topic: topic,
		Value: sarama.StringEncoder(message),
	})
}

func (e *Event) OnMessage() {
	e.Server.Events.OnMessage = func(cl events.Client, pk events.Packet) (pkx events.Packet, err error) {
		pkx = pk
		e.pubEvent(string(pkx.Payload))
		return pkx, nil
	}
}
