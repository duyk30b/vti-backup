package mqtt

import (
	"fmt"
	"log"
	"os"
	"os/signal"
	"syscall"
	"time"

	Config "iot-adapter/config"

	mqtt "github.com/eclipse/paho.mqtt.golang"

	"github.com/google/uuid"
	logrus "github.com/sirupsen/logrus"
)

var f mqtt.MessageHandler = func(client mqtt.Client, msg mqtt.Message) {
	fmt.Printf("MSG: %s\n", msg.Payload())
}

func Connect(configService *Config.Config, topicHandlers map[string]interface{}) {
	c := make(chan os.Signal, 1)
	signal.Notify(c, os.Interrupt, syscall.SIGTERM)
	mqtt.ERROR = log.New(os.Stdout, "", 0)
	broker := fmt.Sprintf("tcp://%s:%s", configService.GetConfig("mqttTcpHost"), configService.GetConfig("mqttTcpPort"))
	logrus.Info(fmt.Sprintf("MQTT START CONNECT TO: %s", broker))

	var clientId = uuid.New()

	opts := mqtt.NewClientOptions().AddBroker(broker).SetClientID(fmt.Sprint("IOT_ADAPTER_%s", clientId))
	opts.SetKeepAlive(60 * time.Second)

	// Set the message callback handler'
	opts.SetDefaultPublishHandler(f)

	client := mqtt.NewClient(opts)
	if token := client.Connect(); token.Wait() && token.Error() != nil {
		panic(token.Error())
	}
	topics := make(map[string]byte, len(topicHandlers))
	for k := range topicHandlers {
		topics[k] = 1
	}

	token := client.SubscribeMultiple(topics, func(client mqtt.Client, msg mqtt.Message) {
		handler := topicHandlers[msg.Topic()]
		if handler != nil {
			go handler.(func(mqtt.Message))(msg)
		}
	})
	token.Wait()
	if token.Error() != nil {
		log.Fatalln(token.Error())
	}
	<-c
}
