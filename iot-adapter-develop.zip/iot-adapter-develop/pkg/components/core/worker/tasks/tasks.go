package tasks

import (
	"bytes"
	"encoding/json"
	"fmt"
	"iot-adapter/config"
	"net/http"
)

func SendDataToMainServices(payload string) error {
	config := config.Config{}
	config.Init()

	var payloadJson, configApiPath map[string]interface{}
	json.Unmarshal([]byte(payload), &payloadJson)
	service := payloadJson["service"].(string)
	requestBody, _ := json.Marshal(payloadJson["bodyData"])

	json.Unmarshal([]byte(config.GetConfig("apiPathReceiveData")), &configApiPath)
	servicePath := configApiPath[service].(string)
	host := config.GetConfig("apiGatewayHost") + servicePath

	res, err := http.Post(
		host,
		"application/json",
		bytes.NewBuffer(requestBody),
	)
	if err != nil {
		fmt.Println("Send data to services error: ", err.Error())
		return err
	} else {
		fmt.Println("Response: ", res)
	}
	return nil
}
