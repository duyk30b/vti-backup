package worker

import (
	"fmt"

	machinery "github.com/RichardKnop/machinery/v1"
	workerConfig "github.com/RichardKnop/machinery/v1/config"
	workerTasks "github.com/RichardKnop/machinery/v1/tasks"

	"iot-adapter/config"
	"iot-adapter/pkg/components/core/worker/tasks"
)

var server *machinery.Server

func Init() {
	config := config.Config{}
	config.Init()

	broker := "redis://" + config.GetConfig("redisPassword") + "@" + config.GetConfig("redisHost") + ":" + config.GetConfig("redisPort")
	cnf := workerConfig.Config{
		Broker:        broker,
		ResultBackend: broker,
	}
	var err error
	server, err = machinery.NewServer(&cnf)

	if err != nil {
		fmt.Println("Could not create server: ", err.Error())
	}

	// RegisterTasks()

	worker := server.NewWorker("worker", 0)
	err = worker.Launch()
	if err != nil {
		fmt.Println("Could not launch worker! ", err.Error())
	}
}

func RegisterTasks() {
	err := server.RegisterTasks(map[string]interface{}{
		"SendDataToMainServices": tasks.SendDataToMainServices,
	})
	if err != nil {
		fmt.Println("Register tasks error: ", err.Error())
	}
}

func Signature(payload *workerTasks.Signature) {
	signatureTask := payload

	_, err := server.SendTask(signatureTask)
	if err != nil {
		fmt.Println("Send task error: ", err.Error())
	}
}
