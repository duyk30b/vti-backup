package kafka

import (
	"crypto/tls"
	"crypto/x509"
	"flag"
	"fmt"
	Config "iot-adapter/config"
	"log"
	"os"
	"strings"

	"github.com/Shopify/sarama"
)

var (
	certFile      = flag.String("certificate", "pkg/cert/kafka.pem", "The optional certificate file for client authentication")
	keyFile       = flag.String("key", "pkg/cert/kafka.key", "The optional key file for client authentication")
	caFile        = flag.String("ca", "pkg/cert/kafka.crt", "The optional certificate authority file for TLS client authentication")
	tlsSkipVerify = flag.Bool("tls-skip-verify", true, "Whether to skip TLS server cert verification")
)

func createTLSConfiguration() (t *tls.Config) {
	t = &tls.Config{
		InsecureSkipVerify: true,
	}
	if *certFile != "" && *keyFile != "" && *caFile != "" {
		cert, err := tls.LoadX509KeyPair(*certFile, *keyFile)
		if err != nil {
			log.Fatal(err)
		}

		caCert, err := os.ReadFile(*caFile)
		if err != nil {
			log.Fatal(err)
		}

		caCertPool := x509.NewCertPool()
		caCertPool.AppendCertsFromPEM(caCert)

		t = &tls.Config{
			Certificates:       []tls.Certificate{cert},
			RootCAs:            caCertPool,
			InsecureSkipVerify: *tlsSkipVerify,
		}
	}
	return t
}

func createKafkaConf() *sarama.Config {
	config := Config.Config{}
	config.Init()

	var (
		userName = config.GetConfig("KAFKA_USERNAME")
		passwd   = config.GetConfig("KAFKA_PASSWD")
	)

	if userName == "" {
		log.Fatalln("SASL username is required")
	}

	if passwd == "" {
		log.Fatalln("SASL password is required")
	}

	conf := sarama.NewConfig()
	conf.Producer.Retry.Max = 5
	conf.Producer.RequiredAcks = sarama.WaitForAll
	conf.Producer.Return.Successes = true
	conf.Metadata.Full = true
	conf.Version = sarama.V0_10_0_0
	conf.ClientID = "IOT_ADAPTER"
	conf.Metadata.Full = true
	// conf.Net.SASL.Enable = true
	// conf.Net.SASL.User = userName
	// conf.Net.SASL.Password = passwd
	// conf.Net.SASL.Handshake = true

	// if *algorithm == "sha512" {
	// 	conf.Net.SASL.SCRAMClientGeneratorFunc = func() sarama.SCRAMClient { return &XDGSCRAMClient{HashGeneratorFcn: SHA512} }
	// 	conf.Net.SASL.Mechanism = sarama.SASLTypeSCRAMSHA512
	// } else if *algorithm == "sha256" {
	// 	conf.Net.SASL.SCRAMClientGeneratorFunc = func() sarama.SCRAMClient { return &XDGSCRAMClient{HashGeneratorFcn: SHA256} }
	// 	conf.Net.SASL.Mechanism = sarama.SASLTypeSCRAMSHA256

	// } else {
	// 	log.Fatalf("invalid SHA algorithm \"%s\": can be either \"sha256\" or \"sha512\"", *algorithm)
	// }

	conf.Net.TLS.Enable = true
	conf.Net.TLS.Config = createTLSConfiguration()

	return conf

}

func CreateSyncProducer() *sarama.SyncProducer {
	config := Config.Config{}
	config.Init()

	splitBrokers := strings.Split(config.GetConfig("KAFKA_PEERS"), ",")

	conf := createKafkaConf()

	syncProducer, err := sarama.NewSyncProducer(splitBrokers, conf)
	if err != nil {
		log.Fatalln("failed to create producer: ", err)
	}
	fmt.Printf("CONNECT KAFKA SUCCESSFULLY\n")

	return &syncProducer
}

func CreateAsyncProducer() *sarama.AsyncProducer {
	config := Config.Config{}
	config.Init()

	splitBrokers := strings.Split(config.GetConfig("KAFKA_PEERS"), ",")

	conf := createKafkaConf()

	asyncProducer, err := sarama.NewAsyncProducer(splitBrokers, conf)
	if err != nil {
		log.Fatalln("failed to create producer: ", err)
	}

	return &asyncProducer
}
