package kong

import (
	Config "iot-adapter/config"
	"iot-adapter/pkg/components/core/kong/services"
	"log"

	"github.com/kevholditch/gokong"
)

type KongApiGatewayModule struct {
}

func (k *KongApiGatewayModule) Init(configService *Config.Config) *KongApiGatewayModule {
	kongConfig := gokong.Config{
		HostAddress: configService.GetConfig("kongHostAddress"),
	}

	kongClient := gokong.NewClient(&kongConfig)
	status, err := kongClient.Status().Get()
	_ = status
	if err != nil {
		log.Fatal(err.Error())
	} else {
		kongService := services.NewKongService(*kongClient, *configService)
		kongService.Init()
	}

	return k
}
