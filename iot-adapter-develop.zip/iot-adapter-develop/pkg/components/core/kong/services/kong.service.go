package services

import (
	"fmt"
	Config "iot-adapter/config"
	"log"

	"github.com/kevholditch/gokong"
)

type kongService struct {
	kongClient    *gokong.KongAdminClient
	configService *Config.Config
}

func (k *kongService) createOrUpdateUpStream() (*gokong.Upstream, error) {
	upstreamName := fmt.Sprintf("%s-upstream", k.configService.GetConfig("kongUpStreamName"))
	upstreamRequest := &gokong.UpstreamRequest{
		Name:  upstreamName,
		Slots: 10,
		HealthChecks: &gokong.UpstreamHealthCheck{
			Active: &gokong.UpstreamHealthCheckActive{
				Healthy: &gokong.ActiveHealthy{
					Successes: 2,
					Interval:  2,
				},
				Unhealthy: &gokong.ActiveUnhealthy{
					Interval:     5,
					HttpFailures: 2,
				},
				Timeout:  5,
				HttpPath: fmt.Sprintf("%s/health", k.configService.GetConfig("API_PATH")),
			},
		},
	}

	upstream, err := k.kongClient.Upstreams().GetByName(upstreamName)
	_ = err
	if upstream == nil {
		upstream, err := k.kongClient.Upstreams().Create(upstreamRequest)
		_ = upstream
		fmt.Println(err)
		if err != nil {
			log.Fatal(err.Error())
		}
	}

	return upstream, err
}

func (k *kongService) createOrUpdateUpStreamTarget(upstreamId string) {
	target := fmt.Sprintf("%s:%s", k.configService.GetConfig("httpHost"), k.configService.GetConfig("httpPort"))
	targets, err := k.kongClient.Targets().GetTargetsFromUpstreamId(upstreamId)
	fmt.Println("dsf", targets)
	fmt.Println(err)
	if targets == nil {
		targetRequest := &gokong.TargetRequest{
			Target: target,
			Weight: 100,
		}
		updatedTarget, err := k.kongClient.Targets().CreateFromUpstreamId(upstreamId, targetRequest)
		fmt.Println('s', updatedTarget, err)
	}
}

func (k *kongService) createOrUpdateService() {
}

func (k *kongService) createOrUpdateRoute() {
}

func (k *kongService) Init() {
	upstream, err := k.createOrUpdateUpStream()
	k.createOrUpdateUpStreamTarget(upstream.Id)
	k.createOrUpdateService()
	k.createOrUpdateRoute()
	if err != nil {
		log.Fatal(err)
	}
}

func NewKongService(kongClient gokong.KongAdminClient, configService Config.Config) *kongService {
	return &kongService{kongClient: &kongClient, configService: &configService}
}
