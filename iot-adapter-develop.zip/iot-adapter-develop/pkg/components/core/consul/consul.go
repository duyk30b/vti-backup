package consul

import (
	"fmt"
	Config "iot-adapter/config"
	"log"
	"os"
	"strconv"

	"github.com/hashicorp/consul/api"
)

type Consul struct {
	Config *Config.Config
	Client *api.Client
}

func (c *Consul) ServiceRegistry() {
	address, _ := os.Hostname()
	port, _ := strconv.Atoi(c.Config.GetConfig("httpPort"))

	registration := &api.AgentServiceRegistration{
		Name:    c.Config.GetConfig("serviceID"),
		Port:    port,
		Address: address,
		Check: &api.AgentServiceCheck{
			HTTP:     fmt.Sprintf("http://%s:%v/health", address, port),
			Interval: "5s",
			Timeout:  "30s",
		},
	}

	regiErr := c.Client.Agent().ServiceRegister(registration)

	if regiErr != nil {
		log.Printf("Failed to register service: %s:%v ", address, port)
	} else {
		log.Printf("successfully register service: %s:%v", address, port)
	}
}

func (c *Consul) Init(configService *Config.Config) {
	c.Config = configService
	var err error
	conf := &api.Config{
		Address: fmt.Sprintf("%s:%v", c.Config.GetConfig("CONSUL_HOST"), c.Config.GetConfig("CONSUL_PORT")),
		Token:   c.Config.GetConfig("CONSUL_TOKEN"),
	}
	c.Client, err = api.NewClient(conf)

	if err != nil {
		log.Println(err)
	}

}
