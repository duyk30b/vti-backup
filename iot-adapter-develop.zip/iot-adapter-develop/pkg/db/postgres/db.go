package db

import (
	"fmt"
	config "iot-adapter/config"
	entities "iot-adapter/pkg/components/test/entities/test"
	"log"
	"time"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

var dbConn *gorm.DB

func GetDns() string {
	config := config.Config{}
	config.Init()

	user := config.GetConfig("dbUser")
	password := config.GetConfig("dbPassword")
	db := config.GetConfig("dbName")
	host := config.GetConfig("dbHost")
	port := config.GetConfig("dbPort")

	return fmt.Sprintf("host=%s user=%s password=%s dbname=%s port=%s", host, user, password, db, port)
}

func CreateDBConnection() error {
	db, err := gorm.Open(postgres.New(postgres.Config{
		DSN:                  GetDns(),
		PreferSimpleProtocol: true,
	}), &gorm.Config{})

	if err != nil {
		log.Fatal(err)
	}

	// Create connection pool
	sqlDB, err := db.DB()

	sqlDB.SetConnMaxIdleTime(time.Minute * 5)

	// SetMaxIdleConns sets the maximum number of connections in the idle connection pool.
	sqlDB.SetMaxIdleConns(10)

	// SetMaxOpenConns sets the maximum number of open connections to the database.
	sqlDB.SetMaxOpenConns(100)

	// SetConnMaxLifetime sets the maximum amount of time a connection may be reused.
	sqlDB.SetConnMaxLifetime(time.Hour)
	dbConn = db
	return err
}

func GetDatabaseConnection() (*gorm.DB, error) {
	sqlDB, err := dbConn.DB()
	if err != nil {
		return dbConn, err
	}

	if err := sqlDB.Ping(); err != nil {
		return dbConn, err
	}

	return dbConn, nil
}

func AutoMigrateDB() error {
	db, connErr := GetDatabaseConnection()

	if connErr != nil {
		return connErr
	}

	// Required models
	err := db.AutoMigrate(&entities.Test{})

	// err:= db.AutoMigrate(&models.User{}, &models.Admin{}, &models.Guest{})

	return err
}

func Init() *gorm.DB {
	CreateDBConnection()

	db, err := GetDatabaseConnection()

	if err != nil {
		log.Fatalln(err)
	}

	AutoMigrateDB()

	return db
}
