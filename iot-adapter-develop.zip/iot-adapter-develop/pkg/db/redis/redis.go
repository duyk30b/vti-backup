package redis

import (
	"fmt"

	"github.com/go-redis/redis"

	config "iot-adapter/config"
)

func NewDatabase() {
	config := config.Config{}
	config.Init()

	client := redis.NewClient(&redis.Options{
		Addr:     config.GetConfig("redisHost") + ":" + config.GetConfig("redisPort"),
		Password: config.GetConfig("redisPassword"),
		DB:       0,
	})

	pong, err := client.Ping().Result()
	if err != nil {
		fmt.Println("Connect redis error: ", err)
	} else {
		fmt.Println("Connect redis success: ", pong)
	}
}
