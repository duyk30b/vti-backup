package app

import (
	"fmt"
	Config "iot-adapter/config"
	Consul "iot-adapter/pkg/components/core/consul"
	"iot-adapter/pkg/components/core/kafka"
	"iot-adapter/pkg/components/core/mqtt"
	producemonitoring "iot-adapter/pkg/components/produce-monitoring"
	"net/http"

	"github.com/gin-gonic/gin"
)

type App struct {
	r *gin.Engine
}

func (a *App) Init() {
	config := Config.Config{}
	config.Init()
	// kongClient := kong.KongApiGatewayModule{}
	// kongClient.Init(&config)

	// gin.SetMode(config.GetConfig("mode"))
	a.r = gin.New()

	// a.r.Use(gin.Logger())
	a.initializeRoutes()
	a.r.Use(gin.Recovery())

	consul := Consul.Consul{}
	consul.Init(&config)
	consul.ServiceRegistry()
	mqtt.Connect(&config, a.initTopicHandlers())

	go func() {
		a.r.Run(fmt.Sprintf(":%s", config.GetConfig("httpPort")))
	}()

}

func (a *App) initializeRoutes() {
	a.r.GET("/health", func(ctx *gin.Context) {
		ctx.String(http.StatusOK, "OKE")
	})
}

func (a *App) initTopicHandlers() map[string]interface{} {
	syncProducer := kafka.CreateSyncProducer()
	produceMonitoring := producemonitoring.ProduceMonitoringModule{}
	produceMonitoringTopics := produceMonitoring.Init(syncProducer)

	topics := make(map[string]interface{})

	for k, v := range produceMonitoringTopics {
		topics[k] = v
	}

	return topics
}
