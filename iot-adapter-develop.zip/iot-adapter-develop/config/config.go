package config

import (
	"flag"
	"os"
	"reflect"

	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
)

type Config struct {
	mode               string
	serviceID          string
	httpPort           string
	httpHost           string
	dbType             string
	dbHost             string
	dbPort             string
	dbUser             string
	dbPassword         string
	dbName             string
	kongHostAddress    string
	kongUsername       string
	kongPassword       string
	kongApiKey         string
	kongUpStreamName   string
	mqttTcpHost        string
	mqttTcpPort        string
	mqttUser           string
	mqttPassword       string
	redisHost          string
	redisPort          string
	redisPassword      string
	serviceType        string
	apiGatewayHost     string
	apiPathReceiveData string
}

func (c *Config) Init() *Config {
	// load .env file
	_ = godotenv.Load(".env")

	// if err != nil {
	// 	log.Fatalf("Error loading .env file")
	// }
	flag.Parse()

	var (
		mode     = gin.ReleaseMode
		httpPort = "3000"
		dbType   = "POSTGRES"
	)

	if os.Getenv("HTTP_PORT") != "" {
		httpPort = os.Getenv("HTTP_PORT")
	}
	c.serviceID = "iot-adpater"
	if os.Getenv("SERVER_NAME") != "" {
		c.serviceID = os.Getenv("SERVER_NAME")
	}
	if os.Getenv("MODE") != "" {
		httpPort = os.Getenv("MODE")
	}
	if os.Getenv("DATABASE_TYPE") != "" {
		dbType = os.Getenv("DATABASE_TYPE")
	}

	apiPathReceiveDataConfig := `{
		"warehouses": "/api/v1/warehouses/receive-iot-data"
	}`

	c.mode = mode
	c.httpPort = httpPort
	c.httpHost = os.Getenv("HTTP_HOST")
	c.dbType = dbType
	c.dbName = os.Getenv("DATABASE_NAME")
	c.dbHost = os.Getenv("DATABASE_HOST")
	c.dbPort = os.Getenv("DATABASE_PORT")
	c.dbUser = os.Getenv("DATABASE_USER")
	c.dbPassword = os.Getenv("DATABASE_PASSWORD")
	c.kongHostAddress = os.Getenv("KONG_HOST_ADDRESS")
	c.kongUsername = os.Getenv("KONG_USERNAME")
	c.kongPassword = os.Getenv("KONG_PASSWORD")
	c.kongApiKey = os.Getenv("KONG_API_KEY")
	c.kongUpStreamName = os.Getenv("KONG_UP_STREAM_NAME")
	c.mqttTcpHost = os.Getenv("MQTT_TCP_HOST")
	c.mqttTcpPort = os.Getenv("MQTT_TCP_PORT")
	c.mqttUser = os.Getenv("MQTT_USER")
	c.mqttPassword = os.Getenv("MQTT_PASSWORD")
	c.redisHost = os.Getenv("REDIS_HOST")
	c.redisPort = os.Getenv(("REDIS_PORT"))
	c.redisPassword = os.Getenv("REDIS_PASSWORD")
	c.serviceType = os.Getenv("SERVICE_TYPE")
	c.apiGatewayHost = os.Getenv("API_GATEWAY_HOST")
	c.apiPathReceiveData = apiPathReceiveDataConfig

	return c
}

func (x Config) GetConfig(key string) string {
	r := reflect.ValueOf(x)
	f := reflect.Indirect(r).FieldByName(key)
	if !f.IsValid() {
		return os.Getenv(key)
	} else {
		return f.String()
	}
}
