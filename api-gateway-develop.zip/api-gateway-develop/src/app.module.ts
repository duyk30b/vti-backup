import { ItemGateway } from './components/item/item.gateway';
import { SocketModule } from './components/socket/socket.module';
import { AppController } from './components/app/app.controller';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ClientProxyFactory } from '@nestjs/microservices';
import { UserController } from '@components/user/user.controller';
import { WarehouseController } from '@components/warehouse/warehouse.controller';
import { ConfigService } from './config/config.service';
import { ItemController } from '@components/item/item.controller';
import { SaleController } from '@components/sale/sale.controller';
import { SettingController } from '@components/setting/setting.controller';
import { JwtGuard } from '@core/guards/jwt.guard';
import { APP_GUARD } from '@nestjs/core';
import { ReportController } from '@components/report/report.controller';
import { ProduceController } from '@components/produces/produce.controller';
import { AuthController } from '@components/auth/auth.controller';
import { QualityControlController } from '@components/quality-control/quality-control.controller';
import { MmsController } from '@components/mms/mms.controller';
import { PlanController } from '@components/plan/plan.controller';
import { WarehouseYardController } from '@components/warehouse-yard/warehouse-yard.controller';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    SocketModule,
  ],
  providers: [
    ConfigService,
    ItemGateway,
    {
      provide: APP_GUARD,
      useClass: JwtGuard,
    },
    {
      provide: 'USER_SERVICE',
      useFactory: (configService: ConfigService) => {
        const userServiceOptions = configService.get('userService');
        return ClientProxyFactory.create(userServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'WAREHOUSE_SERVICE',
      useFactory: (configService: ConfigService) => {
        const warehouseServiceOptions = configService.get('warehouseService');
        return ClientProxyFactory.create(warehouseServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'ITEM_SERVICE',
      useFactory: (configService: ConfigService) => {
        const itemServiceOptions = configService.get('itemService');
        return ClientProxyFactory.create(itemServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'SALE_SERVICE',
      useFactory: (configService: ConfigService) => {
        const saleServiceOptions = configService.get('saleService');
        return ClientProxyFactory.create(saleServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'SETTING_SERVICE',
      useFactory: (configService: ConfigService) => {
        const settingServiceOptions = configService.get('settingService');
        return ClientProxyFactory.create(settingServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'PRODUCE_SERVICE',
      useFactory: (configService: ConfigService) => {
        const produceServiceOptions = configService.get('produceService');
        return ClientProxyFactory.create(produceServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'QMSX_SERVICE',
      useFactory: (configService: ConfigService) => {
        const qmsxServiceOptions = configService.get('qmsxService');
        return ClientProxyFactory.create(qmsxServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'MMS_SERVICE',
      useFactory: (configService: ConfigService) => {
        const mmsServiceOptions = configService.get('mmsService');
        return ClientProxyFactory.create(mmsServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'PLAN_SERVICE',
      useFactory: (configService: ConfigService) => {
        const planServiceOptions = configService.get('planService');
        return ClientProxyFactory.create(planServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'WAREHOUSE_YARD_SERVICE',
      useFactory: (configService: ConfigService) => {
        const warehouseYardServiceOptions = configService.get(
          'warehouseYardService',
        );
        return ClientProxyFactory.create(warehouseYardServiceOptions);
      },
      inject: [ConfigService],
    },
  ],
  controllers: [
    AppController,
    AuthController,
    UserController,
    WarehouseController,
    ItemController,
    SaleController,
    SettingController,
    ReportController,
    ProduceController,
    QualityControlController,
    MmsController,
    PlanController,
    WarehouseYardController,
  ],
})
export class AppModule {}
