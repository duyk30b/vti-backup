import { ItemGateway } from './item.gateway';
import { ItemDetailSettingResponseDto } from './dto/response/item-detail-setting.response.dto';
import { BlockResponseDto } from './dto/response/block.response.dto';
import { GetListBlockResponseDto } from './dto/response/get-list-block.response.dto';
import { GetListBlockRequestDto } from './dto/request/get-list-block.request.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Req,
  Response,
} from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import {
  ApiConsumes,
  ApiOperation,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { CreateBlockDto } from './dto/request/create-block.dto';
import { CreateItemDetailSettingDto } from './dto/request/create-item-detail-setting.dto';
import { CreateItemDto } from './dto/request/create-item.dto';
import { CreatePackageDto } from './dto/request/create-package.dto';
import { GetListItemRequestDto } from './dto/request/get-list-item.request.dto';
import { GetListPackageRequestDto } from './dto/request/get-list-package.request.dto';
import { UpdateBlockDto } from './dto/request/update-block.dto';
import { UpdateItemDetailSettingDto } from './dto/request/update-item-detail-setting.dto';
import { UpdateItemDto } from './dto/request/update-item.dto';
import { UpdatePackageDto } from './dto/request/update-package.dto';
import { CreateItemGroupSettingRequestDto } from '@components/item/dto/request/create-item-group-setting-request.dto';
import { UpdateItemGroupSettingRequestDto } from '@components/item/dto/request/update-item-group-setting-request.dto';
import { CreateItemUnitSettingRequestDto } from '@components/item/dto/request/create-item-unit-setting-request.dto';
import { UpdateItemUnitSettingRequestDto } from '@components/item/dto/request/update-item-unit-setting-request.dto';
import { GetListItemUnitSettingRequest } from '@components/item/dto/request/get-item-unit-setting-request.dto';
import { GetListItemResponseDto } from './dto/response/get-list-item.response.dto';
import { GetListDetailRequestDto } from './dto/request/get-list-detail.request.dto';
import { CreateItemTypeSettingRequestDto } from '@components/item/dto/request/create-item-type-setting-request.dto';
import { GetListItemTypeSettingResponseDto } from '@components/item/dto/response/get-list-item-type-setting.response.dto';
import { GetListItemTypeSettingRequestDto } from '@components/item/dto/request/get-list-item-type-setting.request.dto';
import { GetListItemUnitSettingResponseDto } from '@components/item/dto/response/get-list-item-unit-setting.response.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { ItemUnitSettingResponseDto } from '@components/item/dto/response/item-unit-setting-response.dto';
import { ItemGroupSettingResponseDto } from '@components/item/dto/response/item-group-setting-response.dto';
import { GetListItemGroupSettingRequestDto } from '@components/item/dto/request/get-list-item-group-setting.request.dto';
import { GetListItemGroupSettingResponseDto } from '@components/item/dto/response/get-list-item-group-setting.response.dto';
import { ItemTypeSettingResponseDto } from '@components/item/dto/response/item-type-setting.response.dto';
import {
  GetItemStockDto,
  GetItemWarehouseStockDto,
} from './dto/request/get-item-stock.dto';
import { ItemResponseDto } from './dto/response/item.response.dto';
import { ItemStockResponse } from './dto/response/item-stock-response.dto';
import { PackageResponseDto } from './dto/response/package.response.dto';
import { GetListPackageResponseDto } from './dto/response/get-list-package.response.dto';
import { Server } from 'socket.io';
import { PrintQrcodeRequestDto } from './dto/request/print.request.dto';
import { CountItemResponse } from './dto/response/count-item-response.dto';
import { ItemStatisticsQueryDto } from './dto/request/item-statistics.query.dto';
import { ItemStatisticsResponseDto } from './dto/response/item-statistics.response.dto';
import { ItemReportResponse } from './dto/response/item-report.response.dto';
import { ImportRequestDto } from '@core/dto/request/import.request.dto';
import { ImportResponseDto } from '@core/dto/response/import.response.dto';
import { ReadStream } from 'fs';
import { CreateInventoryNormRequestDto } from './dto/request/inventory-norm/create-inventory-norm.request.dto';
import { UpdateInventoryNormRequestDto } from './dto/request/inventory-norm/update-work-center.request.dto';
import { InventoryNormResponseDto } from './dto/response/inventory-norm/inventory-norm.response.dto';
import { GetListInventoryNormResponseDto } from './dto/response/inventory-norm/get-list-inventory-norm.response.dto';
import { GetListInventoryNormRequestDto } from './dto/request/inventory-norm/get-list-inventory-norm.request.dto';
import { ItemStockLocationListResponseDto } from './dto/response/item-stock-location.response.dto';
import { GetReportItemStockRequestDto } from './dto/request/get-report-item-stock.request.dto';
import { ScanQrcodeRequestDto } from './dto/request/qr-code-scan.request.dto';
import { GetLotsByItemRequestDto } from './dto/request/get-lots-by-item.request.dto';
import { GetListLotNumberResponseDto } from '@components/sale/dto/response/import-order/list-lot-number.response.dto';
import { GetLotNumberByItemIdRequestDto } from '@components/sale/dto/request/import-order/list-lot-number.request.dto';
import { ItemShelfFloorStockResponse } from './dto/response/item-shelf-floor-stock.response.dto';
import { ExportRequestDto } from './dto/request/export/export.request.dto';
import { CreateSuspendItemRequestDto } from './dto/request/suspend-item/create-suspend-item.request.dto';
import { SuspendItemResponseDto } from './dto/response/suspend-item/suspend-item.response.dto';
import { GetListSuspendItemRequestDto } from './dto/request/suspend-item/get-list-suspend-item.request.dto';
import { GetListSuspendItemResponseDto } from './dto/response/suspend-item/get-list-suspend-item.response.dto';
import { DeleteMultipleDto } from './dto/request/delete-multiple.dto';
import { PalletResponseDto } from './dto/response/pallet/pallet.response.dto';
import { GetListPalletRequestDto } from './dto/request/pallet/get-list-pallet.request.dto';
import { GetListPalletResponseDto } from './dto/response/pallet/get-list-pallet.response.dto';
import { CreatePalletRequestDto } from './dto/request/pallet/create-pallet.request.dto';
import { FileStaticResponse } from '@components/item/dto/response/file-static.response';
import { PalletEvenResponseDto } from './dto/response/pallet/pallet-even.response';

@Controller('items')
@ApiTags('Items')
export class ItemController {
  private socket: Server;
  constructor(
    @Inject('ITEM_SERVICE')
    private readonly itemServiceClient: ClientProxy,
    private readonly gateway: ItemGateway,
  ) {}

  @Get('ping')
  public async get(): Promise<any> {
    return await this.itemServiceClient.send('ping', {});
  }

  @Put('/item-group-settings/:id/confirm')
  @ApiOperation({
    tags: ['Item Group'],
    summary: 'confirm item group setting',
    description: 'xác nhận nhóm sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ItemGroupSettingResponseDto,
  })
  public async confirmItemGroup(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('confirm_item_group', payload);
  }
  @Get('/export')
  @ApiOperation({
    tags: ['Export item'],
    summary: 'Export',
    description: 'Xuất danh sách ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get export successfully',
  })
  public async export(
    @Query() request: ExportRequestDto,
    @Req() req: any,
    @Response({ passthrough: true }) res,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient
      .send('export_xlsx', payload)
      .toPromise();
  }
  @Put('/item-group-settings/:id/reject')
  @ApiOperation({
    tags: ['Item Group'],
    summary: 'reject item group setting',
    description: 'từ chối nhóm sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ItemGroupSettingResponseDto,
  })
  public async rejectItemGroup(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('reject_item_group', payload);
  }

  @Put('/item-unit-settings/:id/confirm')
  @ApiOperation({
    tags: ['Item Unit'],
    summary: 'confirm item unit setting',
    description: 'xác nhận đơn vị sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ItemUnitSettingResponseDto,
  })
  public async confirmItemUnit(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('confirm_item_unit', payload);
  }

  @Put('/item-unit-settings/:id/reject')
  @ApiOperation({
    tags: ['Item Unit'],
    summary: 'reject item unit setting',
    description: 'từ chối đơn vị sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ItemUnitSettingResponseDto,
  })
  public async rejectItemUnit(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('reject_item_unit', payload);
  }

  @Put('/item-type-settings/:id/confirm')
  @ApiOperation({
    tags: ['Item Type'],
    summary: 'confirm item type setting',
    description: 'xác nhận kiểu sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ItemTypeSettingResponseDto,
  })
  public async confirmItemType(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('confirm_item_type', payload);
  }

  @Put('/item-type-settings/:id/reject')
  @ApiOperation({
    tags: ['Item Type'],
    summary: 'reject item type setting',
    description: 'từ chối kiểu sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ItemTypeSettingResponseDto,
  })
  public async rejectItemType(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('reject_item_type', payload);
  }

  @Get('template-import/:filename')
  @ApiOperation({
    tags: ['import', 'import'],
    summary: 'import ',
    description: 'lấy file mẫu import',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  public async getImportTemplate(
    @Param('filename') fileName,
    @Req() req: any,
  ): Promise<any> {
    const result = await this.itemServiceClient
      .send('item-download-file', {
        fileName: fileName,
        lang: req.headers['lang'],
        userId: req.user.id,
      })
      .toPromise();

    if (result.file) {
      const buffer = this.toBuffer(result);
      return ReadStream.from(buffer);
    }
    return result;
  }

  // Inventory Norm

  @Post('inventory-norms/create')
  @ApiOperation({
    tags: ['Inventory norm'],
    summary: 'Create new inventory norm',
    description: 'Tạo giới hạn tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: InventoryNormResponseDto,
  })
  public async createInventoryNorm(
    @Body() request: CreateInventoryNormRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('inventory_norm_create', payload);
  }

  @Put('inventory-norms/:id')
  @ApiOperation({
    tags: ['Inventory norm'],
    summary: 'Update inventory norm',
    description: 'Cập nhật thông tin giới hạn tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: InventoryNormResponseDto,
  })
  public async updateInventoryNorm(
    @Param('id', new ParseIntPipe()) id,
    @Body() request: UpdateInventoryNormRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      ...request,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('inventory_norm_update', payload);
  }

  @Delete('inventory-norms/:id')
  @ApiOperation({
    tags: ['Inventory norm'],
    summary: 'Delete inventory norm',
    description: 'Xóa giới hạn tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deleteInventoryNorm(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('inventory_norm_delete', payload);
  }

  @Delete('inventory-norms/multiple')
  @ApiOperation({
    tags: ['Inventory norm'],
    summary: 'Delete multiple inventory norm',
    description: 'Xóa nhiều giới hạn tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deleteMultipleInventoryNorm(
    @Query() query: DeleteMultipleDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ids: query.ids,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'inventory_norm_delete_multiple',
      payload,
    );
  }

  @Get('/inventory-norms/:id')
  @ApiOperation({
    tags: ['Inventory Norm'],
    summary: 'Detail Inventory Norm',
    description: 'Chi tiết giới hạn tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: InventoryNormResponseDto,
  })
  public async getDetailInventoryNorm(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('inventory_norm_detail', payload);
  }

  @Get('/inventory-norms/list')
  @ApiOperation({
    tags: ['Inventory Norm'],
    summary: 'List Inventory Norm',
    description: 'Danh sách giới hạn tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListInventoryNormResponseDto,
  })
  public async getListInventoryNorm(
    @Query() request: GetListInventoryNormRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('inventory_norm_list', payload);
  }

  // End Inventory Norm

  // Item
  @Post('/create')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Create new item',
    description: 'Tạo 1 item mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async Create(
    @Body() request: CreateItemDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      createdByUserId: req.user.id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('create_item', payload);
  }

  @Put('/:id')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Update item',
    description: 'Cập nhật thông tin item',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  public async updateItem(
    @Param('id', new ParseIntPipe()) id,
    @Body() request: UpdateItemDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('update_item', payload);
  }

  @Delete('/:id')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Delete item (soft delete)',
    description: 'Xóa item',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deleteItem(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('delete_item', payload);
  }

  @Delete('/multiple')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Delete multiple item',
    description: 'Xóa nhiều item',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deleteMultipleItem(
    @Query() query: DeleteMultipleDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ids: query.ids,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('delete_item_multiple', payload);
  }

  @Get('list')
  @ApiOperation({
    tags: ['Item', 'Items'],
    summary: 'List Item',
    description: 'Danh sách item',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: GetListItemResponseDto,
  })
  public async getList(
    @Query() request: GetListItemRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('get_item_list', payload);
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['Item', 'Items'],
    summary: 'Item Detail',
    description: 'Chi tiết item',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ItemResponseDto,
  })
  public async getDetail(
    @Param('id', new ParseIntPipe()) id: number,
    @Req() req: any,
  ): Promise<any> {
    return await this.itemServiceClient.send('get_item_detail', {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    });
  }

  @Get('/item-stock')
  @ApiOperation({
    tags: ['Items'],
    summary: 'Item Stock',
    description: 'Số lượng tồn kho của item',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ItemStockResponse,
  })
  public async getItemStock(
    @Query() request: GetItemStockDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('get_item_stock', payload);
  }

  @Get('/warehouse-stock')
  @ApiOperation({
    tags: ['Items'],
    summary: 'Item Stock',
    description: 'Số lượng tồn kho của item kèm theo chi tiết location',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ItemStockLocationListResponseDto,
  })
  public async getItemWarehouseStock(
    @Query() request: GetItemWarehouseStockDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'get_item_warehouse_stock',
      payload,
    );
  }
  // End Item

  // Block
  @Post('/blocks/create')
  @ApiOperation({
    tags: ['Item', 'Block'],
    summary: 'Create new block',
    description: 'Tạo 1 kiện mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async createBlock(
    @Body() request: CreateBlockDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('create_block', payload);
  }

  @Put('blocks/:id')
  @ApiOperation({
    tags: ['Block', 'Item'],
    summary: 'Update block',
    description: 'Cập nhật thông tin kiện',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  public async updateBlock(
    @Param('id', new ParseIntPipe()) id,
    @Body() request: UpdateBlockDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('update_block', payload);
  }

  @Delete('blocks/:id')
  @ApiOperation({
    tags: ['Block', 'Item'],
    summary: 'Delete block',
    description: 'Xóa kiện',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deleteBlock(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('delete_block', payload);
  }

  @Delete('blocks/multiple')
  @ApiOperation({
    tags: ['Block', 'Item'],
    summary: 'Delete multiple block',
    description: 'Xóa nhiều kiện',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deleteMultipleBlock(
    @Query() query: DeleteMultipleDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ids: query.ids,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('delete_block_multiple', payload);
  }

  @Get('blocks/list')
  @ApiOperation({
    tags: ['Item', 'Block'],
    summary: 'List Block',
    description: 'Danh sách kiện',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: GetListBlockResponseDto,
  })
  public async getBlockList(
    @Query() request: GetListBlockRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('get_block_list', payload);
  }

  @Get('/blocks/:id')
  @ApiOperation({
    tags: ['Item', 'Blocks'],
    summary: 'Block Detail',
    description: 'Chi tiết block',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: BlockResponseDto,
  })
  public async getBlockDetail(
    @Param('id', new ParseIntPipe()) id: number,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('get_block_detail', payload);
  }

  // End block

  // Package
  @Post('packages/create')
  @ApiOperation({
    tags: ['Item', 'Package'],
    summary: 'Create new package',
    description: 'Tạo 1 package mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async createPackage(
    @Body() request: CreatePackageDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('create_package', payload);
  }

  @Get('/packages/:id')
  @ApiOperation({
    tags: ['Item', 'Package'],
    summary: 'Package Detail',
    description: 'Chi tiết package',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: PackageResponseDto,
  })
  public async getPackageDetail(
    @Param('id', new ParseIntPipe()) id: number,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('get_package_detail', payload);
  }

  @Put('packages/:id')
  @ApiOperation({
    tags: ['Package', 'Item'],
    summary: 'Update package',
    description: 'Cập nhật thông tin package',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  public async updatePackage(
    @Param('id', new ParseIntPipe()) id,
    @Body() request: UpdatePackageDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('update_package', payload);
  }

  @Delete('packages/:id')
  @ApiOperation({
    tags: ['Package', 'Item'],
    summary: 'Delete package',
    description: 'Xóa package',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deletePackage(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('delete_package', payload);
  }

  @Delete('packages/multiple')
  @ApiOperation({
    tags: ['Package', 'Item'],
    summary: 'Delete multiple package',
    description: 'Xóa nhiều package',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deleteMultiplePackage(
    @Query() query: DeleteMultipleDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ids: query.ids,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'delete_package_multiple',
      payload,
    );
  }

  @Get('packages/list')
  @ApiOperation({
    tags: ['Item', 'Package'],
    summary: 'List Package',
    description: 'Danh sách package',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: GetListPackageResponseDto,
  })
  public async getPackageList(
    @Query() request: GetListPackageRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('get_package_list', payload);
  }

  @Put('packages/:id/confirm')
  @ApiOperation({
    tags: ['Package'],
    summary: 'confirm package',
    description: 'xác nhận package',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: PackageResponseDto,
  })
  public async confirmPackage(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = { id: id, userId: req.user.id, lang: req.headers['lang'] };
    return await this.itemServiceClient.send('confirm_package', payload);
  }

  @Put('packages/:id/reject')
  @ApiOperation({
    tags: ['Package'],
    summary: 'reject package',
    description: 'từ chối package',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: PackageResponseDto,
  })
  public async rejectPackage(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('reject_package', payload);
  }

  // End Package

  // Item
  @Post('items/import')
  @ApiOperation({
    tags: ['Items'],
    summary: 'Import Items',
    description: 'Nhap List item',
  })
  @ApiResponse({
    status: 200,
    description: 'Import list success',
    type: ImportResponseDto,
  })
  @ApiConsumes('multipart/form-data')
  public async importItems(
    @Body() request: ImportRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      userIdCreated: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('import_items', payload);
  }

  @Put(':id/confirm')
  @ApiOperation({
    tags: ['Item Confirm'],
    summary: 'Confirmed data ',
    description: 'Confirm data',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ItemDetailSettingResponseDto,
  })
  public async confirmItem(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('confirm_item', payload);
  }

  @Put(':id/reject')
  @ApiOperation({
    tags: ['Item Reject'],
    summary: 'Reject data ',
    description: 'Reject data',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ItemDetailSettingResponseDto,
  })
  public async rejectItem(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('reject_item', payload);
  }

  // Item Detail

  @Post('item-details/import')
  @ApiOperation({
    tags: ['Item details'],
    summary: 'Import item details setting',
    description: 'Nhập một loạt item details mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Import successfully',
    type: ImportResponseDto,
  })
  @ApiConsumes('multipart/form-data')
  public async importItemDetails(
    @Body() request: ImportRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      lang: req.headers['lang'],
      userId: req.user.id,
    };
    return await this.itemServiceClient.send(
      'import_item_detail_setting',
      payload,
    );
  }

  @Post('item-details/create')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Create new item detail',
    description: 'Tạo 1 chi tiết mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ItemDetailSettingResponseDto,
  })
  public async createItemDetailSetting(
    @Body() request: CreateItemDetailSettingDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'create_item_detail_setting',
      payload,
    );
  }

  @Put('item-details/:id')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Update item detail',
    description: 'Cập nhật thông tin chi tiết',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: ItemDetailSettingResponseDto,
  })
  public async updateItemDetailSetting(
    @Param('id', new ParseIntPipe()) id,
    @Body() request: UpdateItemDetailSettingDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'update_item_detail_setting',
      payload,
    );
  }

  @Get('item-details/:id')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Get item detail',
    description: 'Lấy thông tin chi tiết',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: ItemDetailSettingResponseDto,
  })
  public async getItemDetailSetting(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'get_item_detail_setting',
      payload,
    );
  }

  @Delete('item-details/:id')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Delete item detail (soft delete)',
    description: 'Xóa chi tiết',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deleteItemDetailSetting(
    @Param('id', new ParseIntPipe()) id,
    @Body() request: UpdateItemDetailSettingDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'delete_item_detail_setting',
      payload,
    );
  }

  @Delete('item-details/multiple')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Delete multiple item detail (soft delete)',
    description: 'Xóa nhiều chi tiết',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deleteMultipleItemDetailSetting(
    @Query() query: DeleteMultipleDto,
    @Body() request: UpdateItemDetailSettingDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ids: query.ids,
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'delete_item_detail_setting_multiple',
      payload,
    );
  }

  @Get('item-details/list')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Get list item detail',
    description: 'Danh sách chi tiết',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ItemDetailSettingResponseDto,
  })
  public async getItemDetailList(
    @Query() request: GetListDetailRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('get_item_detail_list', payload);
  }

  @Put('item-details/:id/confirm')
  @ApiOperation({
    tags: ['ItemDetails'],
    summary: 'Confirmed data details',
    description: 'Confirm data',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ItemDetailSettingResponseDto,
  })
  public async confirmItemDetailSetting(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'confirm_item_detail_setting',
      payload,
    );
  }

  @Put('item-details/:id/reject')
  @ApiOperation({
    tags: ['ItemDetails'],
    summary: 'Reject data details setting',
    description: 'Reject data',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: ItemDetailSettingResponseDto,
  })
  public async rejectItemDetailSetting(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'reject_item_detail_setting',
      payload,
    );
  }

  // End Item Detail

  // Item Group

  @Post('item-group-settings/import')
  @ApiOperation({
    tags: ['Item group'],
    summary: 'Import item group setting',
    description: 'Nhập một loạt item group setting mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Import successfully',
    type: ImportResponseDto,
  })
  @ApiConsumes('multipart/form-data')
  public async importItemGroupSetting(
    @Body() request: ImportRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      userIdCreated: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'import_item_group_setting',
      payload,
    );
  }

  @Post('item-group-settings/create')
  @ApiOperation({
    tags: ['Item Group'],
    summary: 'Create new item group setting',
    description: 'Cài đặt một item group setting mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ItemGroupSettingResponseDto,
  })
  public async createItemGroupSetting(
    @Body() request: CreateItemGroupSettingRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'create_item_group_setting',
      payload,
    );
  }

  @Put('item-group-settings/:id')
  @ApiOperation({
    tags: ['Item Group'],
    summary: 'Update new item group setting',
    description: 'Update một item group setting mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: ItemGroupSettingResponseDto,
  })
  public async updateItemGroupSetting(
    @Param('id', new ParseIntPipe()) id,
    @Body() request: UpdateItemGroupSettingRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'update_item_group_setting',
      payload,
    );
  }

  @Get('item-group-settings/list')
  @ApiOperation({
    tags: ['Item Group'],
    summary: 'Get item group setting list',
    description: 'Get list item group setting',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListItemGroupSettingResponseDto,
  })
  public async getListItemGroupSetting(
    @Query() request: GetListItemGroupSettingRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'get_list_item_group_setting',
      payload,
    );
  }

  @Delete('item-group-settings/:id')
  @ApiOperation({
    tags: ['Item Group'],
    summary: 'Delete item group setting',
    description: 'Delete item group setting',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteItemGroupSetting(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'delete_item_group_setting',
      payload,
    );
  }

  @Delete('item-group-settings/multiple')
  @ApiOperation({
    tags: ['Item Group'],
    summary: 'Delete multiple item group setting',
    description: 'Delete multiple item group setting',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteMultipleItemGroupSetting(
    @Query() query: DeleteMultipleDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ids: query.ids,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'delete_item_group_setting_multiple',
      payload,
    );
  }

  @Get('item-group-settings/:id')
  @ApiOperation({
    tags: ['Item Group'],
    summary: 'Get item group setting detail',
    description: 'Get information of an item group setting',
  })
  @ApiResponse({
    status: 200,
    description: 'Get information successfully',
    type: ItemGroupSettingResponseDto,
  })
  public async getItemGroupSettingDetail(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = { id: id, userId: req.user.id, lang: req.headers['lang'] };
    return await this.itemServiceClient.send(
      'get_item_group_setting_detail',
      payload,
    );
  }

  // End Item Group

  @Post('item-unit-settings/import')
  @ApiOperation({
    tags: ['Item Unit'],
    summary: 'Import item unit setting',
    description: 'Nhập một loạt item unit setting mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Import successfully',
    type: ImportResponseDto,
  })
  @ApiConsumes('multipart/form-data')
  public async importItemUnitSetting(
    @Body() request: ImportRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      userIdCreated: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'import_item_unit_setting',
      payload,
    );
  }

  @Post('item-unit-settings/create')
  @ApiOperation({
    tags: ['Item Unit'],
    summary: 'Create new item unit setting',
    description: 'Cài đặt một item unit setting mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ItemUnitSettingResponseDto,
  })
  public async createItemUnitSetting(
    @Body() request: CreateItemUnitSettingRequestDto,
    @Req() req,
  ): Promise<any> {
    const user = req.user;
    const payload = {
      ...request,
      userId: user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'create_item_unit_setting',
      payload,
    );
  }

  @Put('item-unit-settings/:id')
  @ApiOperation({
    tags: ['Item Unit'],
    summary: 'Create new item unit setting',
    description: 'Cài đặt một item unit setting mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ItemUnitSettingResponseDto,
  })
  public async updateItemUnitSetting(
    @Param('id', new ParseIntPipe()) id,
    @Body() request: UpdateItemUnitSettingRequestDto,
    @Req() req,
  ): Promise<any> {
    const payload = {
      id: id,
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'update_item_unit_setting',
      payload,
    );
  }

  @Get('item-unit-settings/list')
  @ApiOperation({
    tags: ['Item Unit'],
    summary: 'Get item unit setting list',
    description: 'Get list item unit setting',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListItemUnitSettingResponseDto,
  })
  public async getListItemUnitSetting(
    @Query() request: GetListItemUnitSettingRequest,
    @Req() req,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'get_list_item_unit_setting',
      payload,
    );
  }

  @Delete('item-unit-settings/:id')
  @ApiOperation({
    tags: ['Item Unit'],
    summary: 'Delete item unit setting',
    description: 'Delete item unit setting',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteItemUnitSetting(
    @Param('id', new ParseIntPipe()) id,
    @Req() req,
  ): Promise<any> {
    const payload = { id: id, userId: req.user.id, lang: req.headers['lang'] };
    return await this.itemServiceClient.send(
      'delete_item_unit_setting',
      payload,
    );
  }

  @Delete('item-unit-settings/multiple')
  @ApiOperation({
    tags: ['Item Unit'],
    summary: 'Delete multiple item unit setting',
    description: 'Delete multiple item unit setting',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteMultipleItemUnitSetting(
    @Query() query: DeleteMultipleDto,
    @Req() req,
  ): Promise<any> {
    const payload = {
      ids: query.ids,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'delete_item_unit_setting_multiple',
      payload,
    );
  }

  @Get('item-unit-settings/:id')
  @ApiOperation({
    tags: ['Item Unit'],
    summary: 'Get item unit setting detail',
    description: 'Get information of an item unit setting',
  })
  @ApiResponse({
    status: 200,
    description: 'Get information successfully',
    type: ItemUnitSettingResponseDto,
  })
  public async getItemUnitSettingDetail(
    @Param('id', new ParseIntPipe()) id,
    @Req() req,
  ): Promise<any> {
    const payload = { id: id, userId: req.user.id, lang: req.headers['lang'] };
    return await this.itemServiceClient.send(
      'get_item_unit_setting_detail',
      payload,
    );
  }

  // End Item Unit

  // Item Type

  @Post('item-type-settings/import')
  @ApiOperation({
    tags: ['Item Type'],
    summary: 'Import item type setting',
    description: 'Nhập một loạt item type setting mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Import successfully',
    type: ImportResponseDto,
  })
  @ApiConsumes('multipart/form-data')
  public async importItemTypeSetting(
    @Body() request: ImportRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      userIdCreated: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'import_item_type_setting',
      payload,
    );
  }

  @Post('item-type-settings/create')
  @ApiOperation({
    tags: ['Item Type'],
    summary: 'Create new item type setting',
    description: 'Cài đặt một item type setting mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ItemTypeSettingResponseDto,
  })
  public async createItemTypeSetting(
    @Body() request: CreateItemTypeSettingRequestDto,
    @Req() req,
  ): Promise<any> {
    const payload = {
      ...request,
      lang: req.headers['lang'],
      userId: req.user.id,
    };
    return await this.itemServiceClient.send(
      'create_item_type_setting',
      payload,
    );
  }

  @Put('item-type-settings/:id')
  @ApiOperation({
    tags: ['Item Type'],
    summary: 'Update an item type setting',
    description: 'Cập nhật một item type setting mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: ItemTypeSettingResponseDto,
  })
  public async updateItemTypeSetting(
    @Param('id', new ParseIntPipe()) id,
    @Body() request: CreateItemTypeSettingRequestDto,
    @Req() req,
  ): Promise<any> {
    const payload = {
      id: parseInt(id),
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'update_item_type_setting',
      payload,
    );
  }

  @Delete('item-type-settings/:id')
  @ApiOperation({
    tags: ['Item Type'],
    summary: 'Delete an item type setting',
    description: 'Xóa một item type setting mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteItemTypeSetting(
    @Param('id') id,
    @Req() req,
  ): Promise<any> {
    const payload = {
      id: parseInt(id),
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'delete_item_type_setting',
      payload,
    );
  }

  @Delete('item-type-settings/multiple')
  @ApiOperation({
    tags: ['Item Type'],
    summary: 'Delete multiple item type setting',
    description: 'Xóa multiple item type setting mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteMultipleItemTypeSetting(
    @Query() query: DeleteMultipleDto,
    @Req() req,
  ): Promise<any> {
    const payload = {
      ids: query.ids,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'delete_item_type_setting_multiple',
      payload,
    );
  }

  @Get('item-type-settings/list')
  @ApiOperation({
    tags: ['ItemType'],
    summary: 'List Item Type',
    description: 'Danh sách kiểu item',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListItemTypeSettingResponseDto,
  })
  public async getListItemTypeSetting(
    @Query() request: GetListItemTypeSettingRequestDto,
    @Req() req,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('item_type_setting_list', payload);
  }

  @Get('item-type-settings/:id')
  @ApiOperation({
    tags: ['Item Type'],
    summary: 'Get item type setting detail',
    description: 'Get information of an item type setting',
  })
  @ApiResponse({
    status: 200,
    description: 'Get information successfully',
    type: ItemTypeSettingResponseDto,
  })
  public async getItemTypeSettingDetail(
    @Param('id', new ParseIntPipe()) id,
    @Req() req,
  ): Promise<any> {
    const payload = { id: id, userId: req.user.id, lang: req.headers['lang'] };
    return await this.itemServiceClient.send(
      'get_item_type_setting_detail',
      payload,
    );
  }

  // End Item Type

  // Print QR code
  @Post('qr-code/print')
  @ApiOperation({
    tags: ['Item', 'QR Code', 'Mobile'],
    summary: 'Print Item, Block, Package qr code',
    description: 'In Qr code',
  })
  @ApiResponse({
    status: 200,
    description: 'Print successfully',
    type: null,
  })
  public async printQrCode(
    @Body() request: PrintQrcodeRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      lang: req.headers['lang'],
    };
    const response = await this.itemServiceClient
      .send('print_qr_code', payload)
      .toPromise();
    this.gateway.server.emit('print_item_qr_code', response);
    return response;
  }

  @Get('/:id/stock')
  @ApiResponse({
    status: 200,
    type: ItemResponseDto,
  })
  public async getAllItemStock(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient
      .send('get_all_item_stock', payload)
      .toPromise();
  }

  @Get('qr-code/scan')
  @ApiOperation({
    tags: ['Item', 'QR Code', 'Scan', 'Mobile'],
    summary: 'Scan Item, Block, Package qr code',
    description: 'Scan Qr code',
  })
  @ApiResponse({
    status: 200,
    description: 'Scan successfully',
    type: null,
  })
  public async scanQrCode(
    @Query() request: ScanQrcodeRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      user: req.user,
      lang: req.headers['lang'],
    };

    return await this.itemServiceClient.send('scan_qr_code', payload);
  }

  @Get('reports/item-types/summary')
  @ApiOperation({
    tags: ['Item', 'Count total item'],
    summary: 'Item, Count Item',
    description: 'Count Item',
  })
  @ApiResponse({
    status: 200,
    description: 'Count successfully',
    type: CountItemResponse,
  })
  public async countTotalItem(@Req() req: any): Promise<any> {
    return await this.itemServiceClient.send('count_total_item', {
      lang: req.headers['lang'],
    });
  }

  @Get('reports/item-types/others/summary')
  @ApiOperation({
    tags: ['Item', 'Count total item without TP, NVL'],
    summary: 'Item, Count Item without TP, NVL',
    description: 'Count total item without TP, NVL',
  })
  @ApiResponse({
    status: 200,
    description: 'Count successfully',
    type: CountItemResponse,
  })
  public async countTotalOtherItem(@Req() req: any): Promise<any> {
    return await this.itemServiceClient.send('count_total_other_item', {
      lang: req.headers['lang'],
    });
  }

  @Get('reports/item-group/stocks')
  @ApiOperation({
    tags: ['Item', 'item statistics', 'item-stock', 'item-group'],
    summary: 'Item, item statistics',
    description: 'Trả về stock theo item_type và group by theo item-group',
  })
  @ApiResponse({
    status: 200,
    description: 'Statistics successfully',
    type: ItemStatisticsResponseDto,
  })
  public async itemStatistics(
    @Query() query: ItemStatisticsQueryDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...query,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'item_stock_by_item_group_summary',
      payload,
    );
  }

  @Get('warehouses/shelf-floor-stocks/list')
  @ApiOperation({
    tags: ['Item', 'item warehouse shelf floor stock', 'item stock'],
    summary: 'Item, item warehouse shelf stock',
    description: 'Trả về item và số lượng tồn kho và số lô',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ItemShelfFloorStockResponse,
  })
  public async getItemShelfFLoorStock(
    @Query() query: GetReportItemStockRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...query,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send(
      'get_item_shelf_floor_stock',
      payload,
    );
  }

  @Get('warehouses/stocks/list')
  @ApiOperation({
    tags: ['Item', 'item warehouse stock', 'item stock'],
    summary: 'Item, item warehouse stock',
    description: 'Trả về item và số lượng tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ItemReportResponse,
  })
  public async itemsReport(
    @Query() query: GetReportItemStockRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...query,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('items_report', payload);
  }

  @Get('/:id/lots')
  @ApiOperation({
    tags: ['Item', 'Lot Number'],
    summary: 'Item, lot number',
    description: 'Trả về số lô của item',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ItemReportResponse,
  })
  public async getLotsByItem(
    @Param('id', new ParseIntPipe()) id,
    @Query() query: GetLotsByItemRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      itemId: id,
      ...query,
      lang: req.headers['lang'],
    };
    return await this.itemServiceClient.send('get_lots_by_item', payload);
  }

  private toBuffer(fileResponse: FileStaticResponse): Buffer {
    return Buffer.from(fileResponse.data);
  }

  @Get('/item-stocks/lots')
  @ApiOperation({
    tags: ['Items'],
    summary: 'List Lot Number',
    description: 'Danh sách số lô theo sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListLotNumberResponseDto,
  })
  public async getListLotNumberOfItemStock(
    @Req() req: any,
    @Query() query: GetLotNumberByItemIdRequestDto,
  ): Promise<any> {
    const payload = {
      itemIds: query.itemIds ? query.itemIds.split(',') : [],
      warehouseIds: query.warehouseIds ? query.warehouseIds.split(',') : [],
      userId: req.user.id,
      lang: req.headers['lang'],
    };

    return await this.itemServiceClient.send(
      'get_list_lot_number_of_item_stock',
      payload,
    );
  }

  // suspend item
  @Post('/suspends/create')
  @ApiOperation({
    tags: ['Items'],
    summary: 'create suspend item',
    description: 'Tạo khóa sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: SuspendItemResponseDto,
  })
  public async createSuspendItem(
    @Req() req: any,
    @Body() request: CreateSuspendItemRequestDto,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };

    return await this.itemServiceClient.send('create_suspend_item', payload);
  }

  @Get('/suspends/:id')
  @ApiOperation({
    tags: ['Items'],
    summary: 'suspend item detail',
    description: 'Chi tiết khóa sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Detail successfully',
    type: SuspendItemResponseDto,
  })
  public async getSuspendItem(
    @Req() req: any,
    @Param('id', new ParseIntPipe()) id,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };

    return await this.itemServiceClient.send('detail_suspend_item', payload);
  }

  @Get('/suspends/list')
  @ApiOperation({
    tags: ['Items'],
    summary: 'suspend item list',
    description: 'Danh sách khóa sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'List successfully',
    type: GetListSuspendItemResponseDto,
  })
  public async getSuspendItems(
    @Req() req: any,
    @Query() request: GetListSuspendItemRequestDto,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };

    return await this.itemServiceClient.send('list_suspend_item', payload);
  }

  @Delete('/suspends/:id')
  @ApiOperation({
    tags: ['Items'],
    summary: 'delete suspend item',
    description: 'xóa khóa sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteSuspendItem(
    @Req() req: any,
    @Param('id', new ParseIntPipe()) id,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };

    return await this.itemServiceClient.send('delete_suspend_item', payload);
  }

  @Put('/suspends/:id/open')
  @ApiOperation({
    tags: ['Items'],
    summary: 'open suspend item',
    description: 'mở khóa sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Open successfully',
    type: SuspendItemResponseDto,
  })
  public async openSuspendItem(
    @Req() req: any,
    @Param('id', new ParseIntPipe()) id,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };

    return await this.itemServiceClient.send('open_suspend_item', payload);
  }

  @Put('/suspends/:id/close')
  @ApiOperation({
    tags: ['Items'],
    summary: 'close suspend item',
    description: 'khóa sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Close successfully',
    type: SuspendItemResponseDto,
  })
  public async closeSuspendItem(
    @Req() req: any,
    @Param('id', new ParseIntPipe()) id,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };

    return await this.itemServiceClient.send('close_suspend_item', payload);
  }

  // pallet
  @Post('/pallets/create')
  @ApiOperation({
    tags: ['Items'],
    summary: 'create pallet',
    description: 'Tạo pallet',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: PalletResponseDto,
  })
  public async createPallet(
    @Req() req: any,
    @Body() request: CreatePalletRequestDto,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };

    return await this.itemServiceClient.send('create_pallet', payload);
  }

  @Put('/pallets/:id')
  @ApiOperation({
    tags: ['Items'],
    summary: 'update pallet',
    description: 'Sửa pallet',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: PalletResponseDto,
  })
  public async updatePallet(
    @Req() req: any,
    @Body() request: CreatePalletRequestDto,
    @Param('id', new ParseIntPipe()) id,
  ): Promise<any> {
    const payload = {
      ...request,
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };

    return await this.itemServiceClient.send('update_pallet', payload);
  }

  @Get('/pallets/:id')
  @ApiOperation({
    tags: ['Items'],
    summary: 'pallet detail',
    description: 'Chi tiết pallet',
  })
  @ApiResponse({
    status: 200,
    description: 'Detail successfully',
    type: PalletResponseDto,
  })
  public async getPallet(
    @Req() req: any,
    @Param('id', new ParseIntPipe()) id,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };

    return await this.itemServiceClient.send('detail_pallet', payload);
  }

  @Get('/pallets/list')
  @ApiOperation({
    tags: ['Items'],
    summary: 'pallet list',
    description: 'Danh sách pallet',
  })
  @ApiResponse({
    status: 200,
    description: 'List successfully',
    type: GetListPalletResponseDto,
  })
  public async getPallets(
    @Req() req: any,
    @Query() request: GetListPalletRequestDto,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };

    return await this.itemServiceClient.send('list_pallet', payload);
  }

  @Delete('/pallets/:id')
  @ApiOperation({
    tags: ['Items'],
    summary: 'delete pallet',
    description: 'xóa pallet',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deletePallet(
    @Req() req: any,
    @Param('id', new ParseIntPipe()) id,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };

    return await this.itemServiceClient.send('delete_pallet', payload);
  }

  @Put('/pallets/:id/confirm')
  @ApiOperation({
    tags: ['Items'],
    summary: 'confirm pallet',
    description: 'xác nhận pallet',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: PalletResponseDto,
  })
  public async confirmPallet(
    @Req() req: any,
    @Param('id', new ParseIntPipe()) id,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };

    return await this.itemServiceClient.send('confirm_pallet', payload);
  }

  @Put('/pallets/:id/reject')
  @ApiOperation({
    tags: ['Items'],
    summary: 'reject pallet',
    description: 'từ chối pallet',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: PalletResponseDto,
  })
  public async rejectPallet(
    @Req() req: any,
    @Param('id', new ParseIntPipe()) id,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };

    return await this.itemServiceClient.send('reject_pallet', payload);
  }

  @Get('packages/:id/evenly')
  @ApiOperation({
    tags: ['Items'],
    summary: 'list package evenly',
    description: 'danh sách package chẵn theo item',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: PalletResponseDto,
  })
  public async getPackageEvenlyByItem(
    @Req() req: any,
    @Param('id', new ParseIntPipe()) itemId,
  ): Promise<any> {
    const payload = {
      itemId,
      userId: req.user.id,
      lang: req.headers['lang'],
    };

    return await this.itemServiceClient.send('get_package_evenly', payload);
  }

  @Get('pallets/:id/evenly')
  @ApiOperation({
    tags: ['Items'],
    summary: 'list pallet evenly',
    description: 'danh sách pallet chẵn theo item',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: PalletEvenResponseDto,
  })
  public async getPalletEvenlyByItem(
    @Req() req: any,
    @Param('id', new ParseIntPipe()) itemId,
  ): Promise<any> {
    const payload = {
      itemId,
      userId: req.user.id,
      lang: req.headers['lang'],
    };

    return await this.itemServiceClient.send('get_pallet_evenly', payload);
  }
}
