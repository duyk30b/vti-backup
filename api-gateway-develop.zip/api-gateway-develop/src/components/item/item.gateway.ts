import { SubscribeMessage } from '@nestjs/websockets';
import { WebSocketGateway, WebSocketServer } from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';

@WebSocketGateway()
export class ItemGateway {
  @WebSocketServer()
  server: Server;

  @SubscribeMessage('test')
  handleMessage(client: Socket, payload: any): void {
    console.log('handling', payload);
  }
}
