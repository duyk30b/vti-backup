import {
  IsNotEmpty,
  IsString,
  IsArray,
  IsOptional,
  IsIn,
  IsEnum,
} from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';

class ArrSort {
  @IsString()
  @IsNotEmpty()
  column: string;

  @IsString()
  @IsNotEmpty()
  @IsIn(['ASC', 'DESC'])
  order: string;
}

class ArrFilter {
  @IsString()
  @IsNotEmpty()
  column: string;

  @IsString()
  @IsNotEmpty()
  text: string;
}

export class GetListPackageRequestDto extends PaginationQuery {
  @ApiPropertyOptional({ example: 'example', description: 'search' })
  @IsOptional()
  @IsString()
  keyword: string;

  @ApiPropertyOptional({
    example: '1',
  })
  @IsOptional()
  @IsEnum(['0', '1'])
  withItem: string;

  @ApiPropertyOptional({
    example: '1',
  })
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll: string;

  @ApiPropertyOptional({
    example: [
      {
        column: 'code',
        order: 'DESC',
      },
    ],
    description: 'sort',
  })
  @IsOptional()
  @IsArray()
  sort: ArrSort[];

  @ApiPropertyOptional({
    example: [
      {
        column: 'code',
        text: 'abc',
      },
      {
        column: 'name',
        text: 'a',
      },
    ],
    description: 'filter',
  })
  @IsOptional()
  @IsArray()
  filter: ArrFilter[];
}
