import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';
import { UnitMeasuresRequest } from './unit-measures.request.dto';
import { UnitWeightRequest } from './unit-weight.request.dto';

export class PackageItemDto {
  @ApiProperty({
    example: 1,
    description: 'Mã thành phẩm cấu thành lên package',
  })
  @IsInt()
  @IsNotEmpty()
  itemId: number;

  @ApiProperty({
    example: 1,
    description: 'Số lượng item trong package',
  })
  @Min(1)
  @IsInt()
  @IsNotEmpty()
  quantity: number;
}

export class CreatePackageDto {
  @ApiProperty({ example: 'Package A', description: 'Tên package' })
  @MaxLength(255)
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({ example: 'PK_GO_XXX', description: 'Mã code của package' })
  @MaxLength(12)
  @IsString()
  @IsNotEmpty()
  code: string;

  @ApiPropertyOptional({
    example: 'Đây là package của cái bàn',
    description: 'Mô tả thông tin package',
  })
  @MaxLength(255)
  @IsOptional()
  description: string;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: 'Chiều rộng package',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  width: UnitMeasuresRequest;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: 'Chiều dài package',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  height: UnitMeasuresRequest;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: 'Chiều cao package',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  long: UnitMeasuresRequest;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: 'Khối lượng package',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitWeightRequest)
  weight: UnitWeightRequest;

  @ApiProperty({
    type: PackageItemDto,
    example: [
      { itemId: 1, quantity: 2 },
      { itemId: 2, quantity: 4 },
    ],
    description: 'Các item nằm trong package',
  })
  @ValidateNested()
  @ArrayUnique((e: PackageItemDto) => e.itemId)
  @ArrayNotEmpty()
  @Type(() => PackageItemDto)
  packageItems: PackageItemDto[];
}
