import { ApiPropertyOptional} from '@nestjs/swagger';
import { IsNumber, IsOptional, IsString } from 'class-validator';

export class GetListItemGroupSettingRequest {
  @ApiPropertyOptional()
  @IsNumber()
  @IsOptional()
  id: number;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  name: string;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  code: string;
}
