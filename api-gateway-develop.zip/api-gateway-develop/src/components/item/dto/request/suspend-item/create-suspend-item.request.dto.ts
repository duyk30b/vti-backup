import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsDateString,
  IsDecimal,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  Length,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';

export class SuspendItemDetailDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsDecimal()
  @Min(1)
  quantity: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @Length(10)
  lotNumber: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  mfg: Date;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  packageId: number;
}

export class CreateSuspendItemRequestDto {
  @ApiPropertyOptional()
  @IsOptional()
  @MaxLength(255)
  description: string;

  @ApiProperty({
    type: SuspendItemDetailDto,
    isArray: true,
  })
  @ValidateNested()
  @ArrayUnique(
    (e: SuspendItemDetailDto) => `${e.itemId}_${e.warehouseId}_${e.lotNumber}`,
  )
  @ArrayNotEmpty()
  @Type(() => SuspendItemDetailDto)
  items: SuspendItemDetailDto[];
}
