import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';

export class CreateItemDetailSettingDto {
  @ApiProperty({ example: 'PK_GO_XXX', description: 'Mã code của chi tiết' })
  @MaxLength(12)
  @IsString()
  @IsNotEmpty()
  code: string;

  @ApiProperty({ example: 'Chi tiết cái bàn', description: 'Tên chi tiết' })
  @IsNotEmpty()
  @MaxLength(255)
  @IsString()
  name: string;

  @ApiPropertyOptional({
    example: 'Đây là chi tiết cái bàn',
    description: 'Mô tả thông tin chi tiết',
  })
  @MaxLength(255)
  @IsOptional()
  description: string;
}
