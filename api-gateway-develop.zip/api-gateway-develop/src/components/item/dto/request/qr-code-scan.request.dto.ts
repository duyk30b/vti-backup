import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsString } from 'class-validator';

export enum OrderTypeEnum {
  IMPORT = 0,
  EXPORT = 1,
}

export enum ItemBarcodeTypeEnum {
  PO = '1',
  PRO = '2',
  SO = '3',
  TRANSFER = '4',
  INVENTORY = '5',
  STOCK = '6',
}

export class ScanQrcodeRequestDto {
  @ApiProperty()
  @IsEnum(ItemBarcodeTypeEnum)
  type: number;

  @ApiProperty()
  @IsEnum(OrderTypeEnum)
  transferType: number;

  @ApiProperty()
  @IsString()
  qrCode: string;

  @ApiPropertyOptional()
  @IsString()
  transferId: number;

  @ApiPropertyOptional()
  @IsString()
  warehouseId: number;

  @ApiPropertyOptional()
  @IsString()
  poId: number;

  @ApiPropertyOptional()
  @IsString()
  proId: number;

  @ApiPropertyOptional()
  @IsString()
  soId: number;
}
