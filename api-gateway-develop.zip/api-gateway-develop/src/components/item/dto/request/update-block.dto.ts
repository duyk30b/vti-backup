import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  NotEquals,
  ValidateIf,
  ValidateNested,
} from 'class-validator';
import { BlockItemDetailDto } from './create-block.dto';
import { UnitMeasuresRequest } from './unit-measures.request.dto';
import { UnitWeightRequest } from './unit-weight.request.dto';

export class UpdateBlockDto {
  @ApiProperty({ example: 1, description: 'Mã id của kiện cần update' })
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty({ example: 'Cái bàn', description: 'Tên kiện' })
  @MaxLength(255)
  @IsString()
  @NotEquals(null)
  @ValidateIf((_object, value) => value !== undefined)
  name: string;

  @ApiProperty({ example: 'BAN_GO_XXX', description: 'Mã code của kiện' })
  @MaxLength(12)
  @IsString()
  @NotEquals(null)
  @ValidateIf((_object, value) => value !== undefined)
  code: string;

  @ApiPropertyOptional({
    example: 'Đây là cái bàn',
    description: 'Mô tả thông tin kiện',
  })
  @MaxLength(255)
  @IsOptional()
  description: string;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: 'Chiều rộng kiện',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  width: UnitMeasuresRequest;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: 'Chiều dài kiện',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  height: UnitMeasuresRequest;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: 'Chiều cao kiện',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  long: UnitMeasuresRequest;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: 'Khối lượng kiện',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitWeightRequest)
  weight: UnitWeightRequest;

  @ApiProperty({
    type: BlockItemDetailDto,
    example: [
      { itemDetailId: 1, itemId: 1, quantity: 2 },
      { itemDetailId: 2, itemId: 1, quantity: 4 },
    ],
    description: 'Chi tiết của kiện (nếu có)',
  })
  @ValidateNested()
  @ArrayUnique((e: BlockItemDetailDto) => `${e.itemId}_${e.itemDetailId}`)
  @ArrayNotEmpty()
  @Type(() => BlockItemDetailDto)
  itemDetails: BlockItemDetailDto[];
}
