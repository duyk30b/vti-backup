import { ApiProperty } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsString,
} from 'class-validator';

export class DeleteMultipleDto {
  @ApiProperty({ example: '1, 2, 3', description: '1, 2, 3' })
  @IsString()
  @IsNotEmpty()
  ids: string;
}
