import { UNIT_WEIGHT } from '@constant/common';
import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty, IsNumber, IsPositive } from 'class-validator';

export class UnitWeightRequest {
  @ApiProperty({ example: '10.00', description: 'Giá trị' })
  @IsNotEmpty()
  @IsPositive()
  @IsNumber()
  value: number;

  @ApiProperty({ example: 1, description: 'Đơn vị đo' })
  @IsNotEmpty()
  @IsPositive()
  @IsEnum(UNIT_WEIGHT)
  unit: number;
}
