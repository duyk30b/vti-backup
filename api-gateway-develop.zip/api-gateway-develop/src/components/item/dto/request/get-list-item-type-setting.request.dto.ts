import { ApiProperty } from '@nestjs/swagger';
import {
  IsOptional,
  IsString,
  IsEnum,
  IsNotEmpty,
  IsArray,
} from 'class-validator';
import { Type } from 'class-transformer';

export enum EnumSort {
  ASC = 'ASC',
  DESC = 'DESC',
}

class Sort {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  column: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  @IsEnum(EnumSort)
  order: any;
}

class Filter {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  column: string;

  @IsString()
  @ApiProperty()
  @IsNotEmpty()
  text: string;
}
export class GetListItemTypeSettingRequestDto {
  @ApiProperty({ example: 'item', description: 'Input text' })
  @IsOptional()
  @IsString()
  keyword?: string;

  @ApiProperty({ example: 'AB', description: 'Input text' })
  @IsOptional()
  @IsArray()
  @Type(() => Filter)
  filter?: Filter[];

  @ApiProperty({ example: 'DESC', description: 'ASC or DESC' })
  @Type(() => Sort)
  @IsArray()
  @IsOptional()
  sort?: Sort[];
}
