import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';

export class InitInsertDataRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  table: string;

  @ApiProperty()
  @IsNotEmpty()
  data: any;
}
