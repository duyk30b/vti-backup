import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';

export class CreateItemUnitSettingRequestDto {
  @ApiProperty({
    example: 'item unit name',
    description: 'Ten cua item unit',
  })
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiProperty({ example: '12', description: 'Ma code cua item unit' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(2)
  code: string;

  @ApiPropertyOptional({
    example: 'description item unit setting',
    description: 'Mo ta cho item unit setting',
  })
  @IsString()
  @IsOptional()
  @MaxLength(255)
  description: string;
}
