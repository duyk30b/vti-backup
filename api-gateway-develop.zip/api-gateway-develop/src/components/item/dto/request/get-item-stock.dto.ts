import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { ArrayNotEmpty, IsEnum, IsOptional, IsInt } from 'class-validator';

export class GetItemStockDto extends PaginationQuery {
  @ApiProperty({
    example: '1,2,3,4,5,6',
    description: 'Danh sách kho cần lấy số lượng tồn kho',
  })
  @ArrayNotEmpty()
  warehouseIds: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll: string;
}
export class GetItemWarehouseStockDto extends PaginationQuery {
  @ApiProperty({})
  @IsInt()
  warehouseId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll: string;
}
