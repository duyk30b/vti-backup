import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
    IsNotEmpty,
    IsString,
    MaxLength,
    IsInt,
    IsOptional,
    ValidateNested,
    ArrayUnique,
    IsArray,
    ArrayNotEmpty,
} from 'class-validator';

export class InventoryNormRequestAbstractDto {

    @ApiProperty({ example: 1, description: 'mã nhà máy' })
    @IsNotEmpty()
    @IsInt()
    itemId: number;


    @ApiProperty({
        example: 100,
        description: 'Giới hạn tồn kho',
    })
    @IsNotEmpty()
    inventoryLimit: number;

    @ApiProperty({
        example: 50,
        description: 'Giới hạn tồn kho(cận dưới)',
    })
    @IsNotEmpty()
    minInventoryLimit: number;
    
    @ApiProperty({
        example: 150,
        description: 'Giới hạn tồn kho(cận trên)',
    })
    @IsNotEmpty()
    maxInventoryLimit: number;

    @ApiProperty({
        example: 1,
        description: 'Thời hạn lưu kho',
    })
    @IsNotEmpty()
    @IsInt()
    expiryWarehouse: number;

    @ApiProperty({
        example: 1,
        description: 'Thời hạn cảnh báo lưu kho',
    })
    @IsNotEmpty()
    @IsInt()
    expiryWarningWarehouse: number;
}
