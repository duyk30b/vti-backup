import { InventoryNormRequestAbstractDto } from "./inventory-norm.request.abstract.dto";

export class UpdateInventoryNormRequestDto extends InventoryNormRequestAbstractDto {}