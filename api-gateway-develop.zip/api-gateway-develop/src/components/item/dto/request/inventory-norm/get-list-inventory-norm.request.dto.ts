import { PaginationQuery } from '@utils/pagination.query';

export class GetListInventoryNormRequestDto extends PaginationQuery {}
