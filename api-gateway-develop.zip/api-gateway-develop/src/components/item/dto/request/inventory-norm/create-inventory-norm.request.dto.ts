import { InventoryNormRequestAbstractDto } from "./inventory-norm.request.abstract.dto";

export class CreateInventoryNormRequestDto extends InventoryNormRequestAbstractDto {}