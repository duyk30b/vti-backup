import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';

export class CreateItemTypeSettingRequestDto {
  @ApiProperty({ example: 'item type name', description: 'Ten cua item type' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiPropertyOptional({
    example: 'description item type setting',
    description: 'Mo ta cho item type setting',
  })
  @IsString()
  @IsOptional()
  @MaxLength(255)
  description: string;

  @ApiProperty({
    example: '1432',
    description: 'Mã code của item type',
  })
  @IsNotEmpty()
  @IsString()
  @MaxLength(2)
  code: string;

  @ApiProperty({ example: '1432', description: 'Mã itemDetail của item type' })
  @IsNotEmpty()
  @IsString()
  hasItemDetail: string;

  @IsNumber()
  @IsNotEmpty()
  userId: number;
}
