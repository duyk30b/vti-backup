import { UNIT_MEASURES, UNIT_WEIGHT } from '@constant/common';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayUnique,
  IsArray,
  IsDateString,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  MaxLength,
  Min,
  NotEquals,
  ValidateIf,
  ValidateNested,
} from 'class-validator';
import { ItemDetailDto } from './create-item.dto';
import { UnitMeasuresRequest } from './unit-measures.request.dto';
import { UnitWeightRequest } from './unit-weight.request.dto';

export class UpdateItemDto {
  @ApiProperty({ example: 'Cái bàn', description: 'Tên item' })
  @MaxLength(255)
  @IsString()
  @NotEquals(null)
  @ValidateIf((_object, value) => value !== undefined)
  name: string;

  @ApiProperty({ example: 'BAN_GO_XXX', description: 'Mã code của item' })
  @MaxLength(12)
  @IsString()
  @NotEquals(null)
  @ValidateIf((_object, value) => value !== undefined)
  code: string;

  @ApiPropertyOptional({
    example: 'Đây là cái bàn',
    description: 'Mô tả thông tin item',
  })
  @MaxLength(255)
  @IsOptional()
  description: string;

  @ApiProperty({
    example: 20000,
    description: 'Giá item',
  })
  @IsNumber()
  @IsNotEmpty()
  @Min(0)
  price: number;

  @ApiProperty({
    example: 1,
    description: 'Mã Id đơn vị của item',
  })
  @IsOptional()
  @IsInt()
  itemUnitId: number;

  @ApiProperty({
    example: 1,
    description: 'Mã loại item',
  })
  @IsOptional()
  @IsInt()
  itemTypeId: number;

  @ApiProperty({
    example: 1,
    description: 'Mã nhóm item',
  })
  @IsOptional()
  @IsInt()
  itemGroupId: number;

  @ApiPropertyOptional({ example: '1', description: 'isProductionObject' })
  @IsOptional()
  @IsString()
  @IsEnum(['0', '1'])
  isProductionObject: string;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: 'Chiều rộng item',
  })
  @IsOptional()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  width: UnitMeasuresRequest;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: 'Chiều dài item',
  })
  @IsOptional()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  height: UnitMeasuresRequest;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: 'Chiều cao item',
  })
  @IsOptional()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  long: UnitMeasuresRequest;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: 'Khối lượng item',
  })
  @IsOptional()
  @ValidateNested()
  @Type(() => UnitWeightRequest)
  weight: UnitWeightRequest;

  @ApiPropertyOptional({ example: 1, description: 'Không gian lưu trữ?' })
  @IsNotEmpty()
  @IsInt()
  @IsEnum([0, 1])
  hasStorageSpace: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  @IsPositive()
  dayExpire: number;

  @ApiProperty({
    example: [
      { detailId: 1, quantity: 2 },
      { detailId: 2, quantity: 4 },
    ],
    description: 'Chi tiết của item (nếu có)',
  })
  @ValidateNested()
  @ArrayUnique((e: ItemDetailDto) => e.detailId)
  @IsArray()
  @Type(() => ItemDetailDto)
  itemDetails: ItemDetailDto[];
}
