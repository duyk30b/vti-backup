import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';

export class GetPackageEvenlyByItemDto {
  @ApiProperty({ example: '1,2,3', description: 'package ids' })
  @IsString()
  @IsNotEmpty()
  packageIds: string;
}
