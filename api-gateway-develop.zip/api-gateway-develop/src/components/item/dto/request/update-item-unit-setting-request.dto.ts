import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';

export class UpdateItemUnitSettingRequestDto {
  @ApiProperty({ example: '11', description: 'Id của item unit' })
  @IsNotEmpty()
  @IsNumber()
  id: number;

  @ApiProperty({
    example: 'item unit name',
    description: 'Ten cua item unit',
  })
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiPropertyOptional({
    example: 'description item unit setting',
    description: 'Mo ta cho item unit setting',
  })
  @IsString()
  @IsOptional()
  @MaxLength(255)
  description: string;
}
