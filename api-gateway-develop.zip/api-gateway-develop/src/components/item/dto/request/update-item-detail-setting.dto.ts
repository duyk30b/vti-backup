import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  NotEquals,
  ValidateIf,
} from 'class-validator';

export class UpdateItemDetailSettingDto {
  @ApiProperty({ example: 1, description: 'Mã id của chi tiết cần update' })
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty({ example: 'PK_GO_XXX', description: 'Mã code của chi tiết' })
  @MaxLength(12)
  @IsString()
  @IsNotEmpty()
  code: string;

  @ApiProperty({ example: 'Chi tiết cái bàn', description: 'Tên chi tiết' })
  @MaxLength(255)
  @IsString()
  @NotEquals(null)
  @ValidateIf((_object, value) => value !== undefined)
  name: string;

  @ApiPropertyOptional({
    example: 'Đây là chi tiết cái bàn',
    description: 'Mô tả thông tin chi tiết',
  })
  @MaxLength(255)
  @IsOptional()
  description: string;
}
