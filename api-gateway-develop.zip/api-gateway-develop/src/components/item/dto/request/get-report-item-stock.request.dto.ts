import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsEnum, IsOptional } from 'class-validator';

export class GetReportItemStockRequestDto extends PaginationQuery {
  @ApiPropertyOptional({ example: 1 })
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll?: string;

  @ApiPropertyOptional({ example: 1 })
  @IsOptional()
  @IsEnum(['0', '1'])
  isAllLots?: string;
}
