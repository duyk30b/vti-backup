import { PaginationQuery } from '@utils/pagination.query';

export class GetListPalletRequestDto extends PaginationQuery {}
