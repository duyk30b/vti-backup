import { UnitMeasuresRequest } from '@components/warehouse/dto/warehouse/request/unit-measures.request.dto';
import { UnitWeightsRequest } from '@components/warehouse/dto/warehouse/request/unit-weights.request.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Length,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';

class PalletDetailRequest {
  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  itemId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  packageId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  blockId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  quantity: number;
}

export class CreatePalletRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @Length(1, 50)
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum([0, 1])
  type: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;

  @ApiProperty()
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  width: UnitMeasuresRequest;

  @ApiProperty()
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  height: UnitMeasuresRequest;

  @ApiProperty()
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  long: UnitMeasuresRequest;

  @ApiProperty()
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitWeightsRequest)
  weightLoad: UnitWeightsRequest;

  @ApiProperty({ type: PalletDetailRequest, isArray: true })
  @ArrayNotEmpty()
  @ValidateNested()
  @ArrayUnique()
  @Type(() => PalletDetailRequest)
  palletDetails: PalletDetailRequest[];
}
