import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';

export class CreateItemGroupSettingRequestDto {
  @ApiProperty({ example: '1432', description: 'Mã code của item group' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(4)
  code: string;

  @ApiProperty({ example: 'item group name', description: 'Ten cua item group' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiPropertyOptional({ example: 'description item group setting', description: 'Mo ta cho item group setting' })
  @IsString()
  @IsOptional()
  @MaxLength(255)
  description: string;
}
