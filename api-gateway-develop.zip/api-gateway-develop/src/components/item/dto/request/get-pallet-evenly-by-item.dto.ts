import { ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';

export class GetPalletEvenlyByItemDto {
  @ApiProperty({ example: '1,2,3', description: 'pallet ids' })
  @IsString()
  @IsOptional()
  palletIds: string;
}
