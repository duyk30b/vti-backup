import { ApiProperty } from '@nestjs/swagger';
import { IsString } from 'class-validator';

export class ItemStatisticsQueryDto {
  @ApiProperty({
    example: '00',
    description: 'Mã kiểu item',
  })
  @IsString()
  itemTypeCode: string;
}
