import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { ItemGroupSettingDetailResponseDto } from '@components/item/dto/response/item-group-setting-detail-response.dto';
import { IsArray } from 'class-validator';
import { SuccessResponse } from '@utils/success.response.dto';

export class ItemGroupSettingResponseDto extends SuccessResponse {
  @ApiProperty({ type: ItemGroupSettingDetailResponseDto, isArray: true })
  @Expose()
  @Type(() => ItemGroupSettingDetailResponseDto)
  @IsArray()
  data: ItemGroupSettingDetailResponseDto[];
}
