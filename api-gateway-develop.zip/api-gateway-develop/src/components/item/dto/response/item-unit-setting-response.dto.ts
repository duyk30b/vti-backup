import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { ItemUnitSettingDetailResponseDto } from '@components/item/dto/response/item-unit-setting-detail-response.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { IsArray } from 'class-validator';

export class ItemUnitSettingResponseDto extends SuccessResponse {
  @ApiProperty({ type: ItemUnitSettingDetailResponseDto, isArray: true })
  @Expose()
  @Type(() => ItemUnitSettingDetailResponseDto)
  @IsArray()
  data: ItemUnitSettingDetailResponseDto[];
}
