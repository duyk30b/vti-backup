import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { ItemTypeSettingDetailResponseDto } from '@components/item/dto/response/item-type-setting-detail-response.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { IsArray } from 'class-validator';

export class ItemTypeSettingResponseDto extends SuccessResponse {
  @ApiProperty({ type: ItemTypeSettingDetailResponseDto, isArray: true })
  @Expose()
  @Type(() => ItemTypeSettingDetailResponseDto)
  @IsArray()
  data: ItemTypeSettingDetailResponseDto[];
}
