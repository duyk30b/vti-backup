import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class ItemDetail {
  @ApiProperty()
  @Expose({ name: 'item_id' })
  itemId: number;

  @ApiProperty()
  @Expose({ name: 'item_detail_id' })
  itemDetailId: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  quantity: number;
}
