import { ApiProperty } from '@nestjs/swagger';
import { PagingResponse } from '@utils/paging.response';
import { Expose, Type } from 'class-transformer';

class BaseClass {
  @ApiProperty({
    example: 1,
  })
  @Expose()
  id: number;

  @Expose()
  @ApiProperty({
    example: 'name',
  })
  name: string;

  @Expose()
  @ApiProperty({
    example: 'code',
  })
  code: string;
}

class BaseData extends BaseClass {
  @Expose()
  @ApiProperty({
    example: 1,
  })
  quantity: number;

  @Expose()
  @Type(() => BaseClass)
  @ApiProperty({
    type: BaseClass,
  })
  warehouse: BaseClass;
}

export class ItemReportResponse extends PagingResponse {
  @Expose()
  @Type(() => BaseData)
  @ApiProperty({
    isArray: true,
    type: () => BaseData,
  })
  items: BaseData;
}
