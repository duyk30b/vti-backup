import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class ListLotByItemResponseDto {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  mfg: string;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  quantity: number;
}
