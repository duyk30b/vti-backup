import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray } from 'class-validator';
import { ItemResponseDto } from './item.response.dto';
import { UnitMeaseuresAbstractResponse } from './unit-measures-abstract.response.dto';

class PackageItem {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  packageId: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose({ name: 'itemQuantity' })
  quantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;
}
class UserResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  username: string;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  fullName: string;
}
export class PackageResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  @Type(() => UnitMeaseuresAbstractResponse)
  width: UnitMeaseuresAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => UnitMeaseuresAbstractResponse)
  height: UnitMeaseuresAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => UnitMeaseuresAbstractResponse)
  long: UnitMeaseuresAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => UnitMeaseuresAbstractResponse)
  weight: UnitMeaseuresAbstractResponse;

  @ApiProperty()
  @Expose()
  updatedAt: string;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty({ type: PackageItem, isArray: true })
  @Expose()
  @Type(() => PackageItem)
  @IsArray()
  packageItems: PackageItem[];

  @ApiProperty({ type: UserResponse })
  @Expose()
  @Type(() => UserResponse)
  approver: UserResponse;
}
