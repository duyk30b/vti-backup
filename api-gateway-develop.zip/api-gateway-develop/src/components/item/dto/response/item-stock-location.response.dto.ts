import { ApiProperty } from '@nestjs/swagger';
import { PagingResponse } from '@utils/paging.response';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { SuccessResponse } from '../../../warehouse/dto/warehouse/response/success.response.dto';

class ItemWarehouseLocationLot {
  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  @Expose()
  mfg: string;
}

class WarehouseSector {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;
}

class WarehouseShelf {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;
}

class WarehouseShelfFloor {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;
}
class Warehouse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ItemStockLocation {
  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => Warehouse)
  warehouse: Warehouse;

  @ApiProperty()
  @Expose()
  @Type(() => WarehouseSector)
  warehouseSector: WarehouseSector;

  @ApiProperty()
  @Expose()
  @Type(() => WarehouseShelf)
  warehouseShelf: WarehouseShelf;

  @ApiProperty()
  @Expose()
  @Type(() => WarehouseShelfFloor)
  warehouseShelfFloor: WarehouseShelfFloor;

  @ApiProperty({ type: ItemWarehouseLocationLot, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => ItemWarehouseLocationLot)
  lots: ItemWarehouseLocationLot[];
}

export class ItemStockLocationResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty({ type: ItemStockLocation, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => ItemStockLocation)
  locations: ItemStockLocation[];
}

export class ItemStockLocationListDto extends PagingResponse {
  @ApiProperty({ type: ItemStockLocationResponseDto, isArray: true })
  @Type(() => ItemStockLocationResponseDto)
  @Expose()
  @IsArray()
  items: ItemStockLocationResponseDto[];
}
export class ItemStockLocationListResponseDto extends SuccessResponse {
  @ApiProperty({ type: ItemStockLocationListDto })
  @Type(() => ItemStockLocationListDto)
  @Expose()
  data: ItemStockLocationListDto[];
}
