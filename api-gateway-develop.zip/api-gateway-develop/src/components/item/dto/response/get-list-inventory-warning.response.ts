import { ApiProperty } from "@nestjs/swagger";
import { Meta } from "@utils/common.response";
import { SuccessResponse } from "@utils/success.response.dto";
import { Expose, Type } from "class-transformer";
import { IsArray } from "class-validator";
class InventoryWarningData {
  @ApiProperty({example: 20, description: 'itemId'})
  @Expose()
  itemId: number;

  @ApiProperty({example: 'itemName', description: 'itemName'})
  @Expose()
  itemName: string;

  @ApiProperty({example: 'itemCode', description: 'itemCode'})
  @Expose()
  itemCode: string;

  @ApiProperty({example: 20, description: 'dayExpire'})
  @Expose()
  dayExpire: number;

  @ApiProperty({example: 20, description: 'quantityExpire'})
  @Expose()
  quantityExpire: number;
  
  @ApiProperty({example: 20, description: 'itemTypeId'})
  @Expose()
  itemTypeId: number;

  @ApiProperty({example: 'itemTypeName', description: 'itemTypeName'})
  @Expose()
  itemTypeName: string;

  @ApiProperty({example: 20, description: 'itemGroupId'})
  @Expose()
  itemGroupId: number;

  @ApiProperty({example: 'itemGroupName', description: 'itemGroupName'})
  @Expose()
  itemGroupName: string;

  @ApiProperty({example: 20, description: 'itemUnitId'})
  @Expose()
  itemUnitId: number;

  @ApiProperty({example: 'itemUnitName', description: 'itemUnitName'})
  @Expose()
  itemUnitName: string;

  @ApiProperty({example: 20, description: 'warehouseId'})
  @Expose()
  warehouseId: number;

  @ApiProperty({example: '2021-12-14T15:27:26.630Z', description: 'createdAt'})
  @Expose()
  createdAt: string;

  @ApiProperty({example: 20, description: 'quantity'})
  @Expose()
  quantity: number;
}

export class InventoryWarningDataResponse {
  @ApiProperty({ type: InventoryWarningData, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => InventoryWarningData)
  items: InventoryWarningData[];

  @ApiProperty({ type: Meta })
  @Expose()
  @Type(() => Meta)
  meta: Meta;
}

export class GetListInventoryWarningResponseDto extends SuccessResponse{
  @ApiProperty({ type: InventoryWarningDataResponse })
  @Expose()
  @Type(() => InventoryWarningDataResponse)
  data: InventoryWarningDataResponse;
}
