import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class CreateItemGroupSettingResponseDto {
  @ApiProperty()
  @Expose({ name: 'id' })
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;
}
