import { ApiProperty } from '@nestjs/swagger';
import { PagingResponse } from '@utils/paging.response';
import { Expose, Type } from 'class-transformer';

export class ItemShelfFloorStockResponse extends PagingResponse {
  @Expose()
  @ApiProperty({
    example: 1,
  })
  itemId: number;

  @Expose()
  @ApiProperty({
    example: 'PO00000002',
  })
  lotNumber: string;

  @Expose()
  @ApiProperty({
    example: 1,
  })
  stock: number;
}
