import { IsArray } from 'class-validator';
import { ItemUnit } from './item-unit.response.dto';
import { ItemGroup } from './item-type.response.dto';
import { ItemType } from './item-group.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { ItemDetail } from './item-detail.response.dto';
import { UnitMeaseuresAbstractResponse } from './unit-measures-abstract.response.dto';

export class ItemResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty({ type: ItemType })
  @Expose()
  @Type(() => ItemType)
  itemType: ItemType;

  @ApiProperty({ type: ItemGroup })
  @Expose()
  @Type(() => ItemGroup)
  itemGroup: ItemGroup;

  @ApiProperty({ type: ItemDetail, isArray: true })
  @Expose({ name: 'item_details' })
  @Type(() => ItemDetail)
  @IsArray()
  itemDetails: ItemDetail[];

  @ApiProperty({ type: ItemUnit })
  @Expose()
  @Type(() => ItemUnit)
  itemUnit: ItemUnit;

  @ApiProperty()
  @Expose()
  isHasDetail: boolean;

  @ApiProperty()
  @Expose()
  isProductionObject: boolean;

  @ApiProperty()
  @Expose()
  isHasBom: boolean;

  @ApiProperty()
  @Expose()
  updatedAt: string;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty()
  @Expose()
  @Type(() => UnitMeaseuresAbstractResponse)
  width: UnitMeaseuresAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => UnitMeaseuresAbstractResponse)
  height: UnitMeaseuresAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => UnitMeaseuresAbstractResponse)
  long: UnitMeaseuresAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => UnitMeaseuresAbstractResponse)
  weight: UnitMeaseuresAbstractResponse;

  @ApiProperty()
  @Expose()
  dayExpire: number;

  @ApiProperty()
  @Expose()
  hasItemDetail: boolean;

  @ApiProperty()
  @Expose()
  hasStorageSpace: boolean;
}
