import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray } from 'class-validator';
import { ItemResponseDto } from '@components/item/dto/response/item.response.dto';
import { UnitMeaseuresAbstractResponse } from './unit-measures-abstract.response.dto';

class ItemDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;
}
class BlockDetail {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  packageId: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose({ name: 'itemDetailQuantity' })
  quantity: number;

  @ApiProperty()
  @Expose()
  itemDetailId: number;

  @ApiProperty()
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => ItemDetail)
  itemDetail: ItemDetail;
}

export class BlockResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  @Type(() => UnitMeaseuresAbstractResponse)
  width: UnitMeaseuresAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => UnitMeaseuresAbstractResponse)
  height: UnitMeaseuresAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => UnitMeaseuresAbstractResponse)
  long: UnitMeaseuresAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => UnitMeaseuresAbstractResponse)
  weight: UnitMeaseuresAbstractResponse;

  @ApiProperty()
  @Expose()
  updatedAt: string;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty({ type: BlockDetail, isArray: true })
  @Expose()
  @Type(() => BlockDetail)
  @IsArray()
  blockItemDetails: BlockDetail[];
}
