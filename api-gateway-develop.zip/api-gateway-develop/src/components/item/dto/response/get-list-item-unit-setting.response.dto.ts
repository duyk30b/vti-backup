import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { ItemTypeSettingResponseDto } from '@components/item/dto/response/item-type-setting.response.dto';

class Meta {
  @Expose()
  total: number;
}

class MetaData {
  @Expose()
  data: ItemTypeSettingResponseDto[];

  @Expose()
  meta: Meta;
}

export class GetListItemUnitSettingResponseDto extends SuccessResponse {
  @ApiProperty({
    example: {
      items: [
        {
          id: 105,
          code: '34',
          name: 'Tuan',
          description: 'Hello everyone!!!',
          createdAt: '2021-07-21T06:39:29.260Z',
          updatedAt: '2021-07-21T06:39:29.260Z',
        },
      ],
      meta: {
        total: 1,
      },
    },
  })
  @Expose()
  data: MetaData;
}
