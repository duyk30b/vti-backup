import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class Group {
  @Expose()
  name: string;

  @Expose()
  value: number;
}

class ItemStatistics {
  @Expose()
  total: number;

  @Expose()
  @IsArray()
  groups: Group[];
}

export class ItemStatisticsResponseDto extends SuccessResponse {
  @Expose()
  @ApiProperty({
    example: {
      total: 69,
      groups: [
        { name: 'Group A', value: 66 },
        { name: 'Group A', value: 33 },
      ],
    },
  })
  data: ItemStatistics;
}
