import { IsArray } from 'class-validator';
import { PagingResponse } from './../../../../utils/paging.response';
import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

class BlockDetail {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  packageId: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  itemDetailId: number;
}

class BlockResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  updatedAt: string;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty({ type: BlockDetail, isArray: true })
  @Expose({ name: 'item_details' })
  @Type(() => BlockDetail)
  @IsArray()
  itemDetails: BlockDetail[];
}

export class Blockist extends PagingResponse {
  @ApiProperty({ type: BlockResponseDto, isArray: true })
  @Type(() => BlockResponseDto)
  @Expose()
  @IsArray()
  items: BlockResponseDto[];
}

export class GetListBlockResponseDto {
  @ApiProperty({ example: 200, description: '' })
  @Expose()
  statusCode: number;

  @ApiProperty({ example: 'Success', description: '' })
  @Expose()
  message: string;

  @ApiProperty({
    type: Blockist,
  })
  @Expose()
  @Type(() => Blockist)
  data: Blockist;
}
