import { FactoryDataResponseDto } from '@components/user/dto/factory/response/factory-data.response.dto';
import { UserResponseDto } from '@components/user/dto/user/response/user.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { ItemResponseDto } from '../item.response.dto';


export class InventoryNormResponseAbstractDto {
  @ApiProperty({ example: 1, description: 'id của giới hạn tồn kho' })
  @Expose()
  id: number;

  @ApiProperty({ type: ItemResponseDto })
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty({ example: 90, description: 'giới hạn tồn kho' })
  @Expose()
  inventoryLimit: number;

  @ApiProperty({ example: 75, description: 'giới hạn tồn kho(cận dưới)' })
  @Expose()
  minInventoryLimit: number;

  @ApiProperty({ example: 115, description: 'giới hạn tồn kho(cận trên)' })
  @Expose()
  maxInventoryLimit: number;
}
