export class FileStaticResponse {
  data: ArrayBuffer;
}
