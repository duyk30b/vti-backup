import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

export class CountItemResponse extends SuccessResponse {
  @Expose()
  @ApiProperty({
    example: {
      count: 69,
    },
  })
  data: number;
}
