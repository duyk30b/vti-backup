import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { IsArray } from 'class-validator';
import { UnitWeightsAbstractResponse } from '@components/warehouse/dto/warehouse/response/unit-weights-abstract.response.dto';
import { UnitMeaseuresAbstractResponse } from '@components/warehouse/dto/warehouse/response/unit-measures-abstract.response.dto';

class PackageResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}
class BlockResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ItemResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class PalletDetailResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;

  @ApiProperty()
  @Type(() => PackageResponseDto)
  @Expose()
  package: PackageResponseDto;

  @ApiProperty()
  @Type(() => BlockResponseDto)
  @Expose()
  block: BlockResponseDto;
}

export class PalletResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty({ type: UnitMeaseuresAbstractResponse })
  @Expose()
  @Type(() => UnitMeaseuresAbstractResponse)
  width: UnitMeaseuresAbstractResponse;

  @ApiProperty({ type: UnitMeaseuresAbstractResponse })
  @Expose()
  @Type(() => UnitMeaseuresAbstractResponse)
  height: UnitMeaseuresAbstractResponse;

  @ApiProperty({ type: UnitMeaseuresAbstractResponse })
  @Expose()
  @Type(() => UnitMeaseuresAbstractResponse)
  long: UnitMeaseuresAbstractResponse;

  @ApiProperty({ type: UnitWeightsAbstractResponse })
  @Expose()
  @Type(() => UnitWeightsAbstractResponse)
  weightLoad: UnitWeightsAbstractResponse;

  @ApiProperty({ type: PalletDetailResponse, isArray: true })
  @Type(() => PalletDetailResponse)
  @IsArray()
  @Expose()
  palletDetails: PalletDetailResponse[];

  @ApiProperty()
  @Expose()
  updatedAt: string;

  @ApiProperty()
  @Expose()
  createdAt: string;
}

export class PalletResponseDto extends SuccessResponse {
  @ApiProperty()
  @Type(() => PalletResponse)
  @Expose()
  data: PalletResponse;
}
