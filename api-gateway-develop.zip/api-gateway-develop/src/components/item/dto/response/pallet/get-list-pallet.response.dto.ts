import { ApiProperty } from '@nestjs/swagger';
import { Meta } from '@utils/common.response';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { PalletResponse } from './pallet.response.dto';

export class PalletDataResponse {
  @ApiProperty({ type: PalletResponse, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => PalletResponse)
  items: PalletResponse[];

  @ApiProperty({ type: Meta })
  @Expose()
  @Type(() => Meta)
  meta: Meta;
}

export class GetListPalletResponseDto extends SuccessResponse {
  @ApiProperty({ type: PalletDataResponse })
  @Expose()
  @Type(() => PalletDataResponse)
  data: PalletDataResponse;
}
