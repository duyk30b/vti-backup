import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';

class BaseResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

export class PalletEvenResponse extends BaseResponse {
  @ApiProperty({
    type: BaseResponse,
    isArray: true,
  })
  @Type(() => BaseResponse)
  @Expose()
  packages: BaseResponse[];
}

export class PalletEvenResponseDto extends SuccessResponse {
  @ApiProperty()
  @Type(() => PalletEvenResponse)
  @Expose()
  data: PalletEvenResponse;
}
