import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class UserResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  username: string;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  fullName: string;
}
export class ItemTypeSettingDetailResponseDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'hành phẩm', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'IG1', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'thành phẩm', description: '' })
  @Expose()
  description: string;

  @ApiProperty({ example: '1', description: '' })
  @Expose()
  hasItemDetail: string;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  status: number;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  createdAt: Date;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: UserResponse })
  @Expose()
  @Type(() => UserResponse)
  approver: UserResponse;
}
