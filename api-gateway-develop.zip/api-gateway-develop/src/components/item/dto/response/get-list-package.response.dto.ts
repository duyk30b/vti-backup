import { PackageResponseDto } from './package.response.dto';
import { IsArray } from 'class-validator';
import { PagingResponse } from '../../../../utils/paging.response';
import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

export class DataList extends PagingResponse {
  @ApiProperty({ type: PackageResponseDto, isArray: true })
  @Type(() => PackageResponseDto)
  @Expose()
  @IsArray()
  items: PackageResponseDto[];
}

export class GetListPackageResponseDto {
  @ApiProperty({ example: 200, description: '' })
  @Expose()
  statusCode: number;

  @ApiProperty({ example: 'Success', description: '' })
  @Expose()
  message: string;

  @ApiProperty({
    type: DataList,
  })
  @Expose()
  @Type(() => DataList)
  data: DataList;
}
