import { ApiProperty } from '@nestjs/swagger';
import { Meta } from '@utils/common.response';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { SuccessResponse } from '../success.response.dto';
import { SuspendItemResponse } from './suspend-item.response.dto';

export class SuspendItemDataResponse {
  @ApiProperty({ type: SuspendItemResponse, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => SuspendItemResponse)
  items: SuspendItemResponse[];

  @ApiProperty({ type: Meta })
  @Expose()
  @Type(() => Meta)
  meta: Meta;
}

export class GetListSuspendItemResponseDto extends SuccessResponse {
  @ApiProperty({ type: SuspendItemDataResponse })
  @Expose()
  @Type(() => SuspendItemDataResponse)
  data: SuspendItemDataResponse;
}
