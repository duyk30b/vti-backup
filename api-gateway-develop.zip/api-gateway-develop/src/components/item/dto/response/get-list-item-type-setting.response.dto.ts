import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { ItemTypeSettingResponseDto } from '@components/item/dto/response/item-type-setting.response.dto';

class Meta {
  @Expose()
  total: number;
}

class MetaData {
  @Expose()
  data: ItemTypeSettingResponseDto[];

  @Expose()
  meta: Meta;
}

export class GetListItemTypeSettingResponseDto extends SuccessResponse {
  @ApiProperty({
    example: {
      items: [
        {
          id: 48,
          name: 'Tuan',
          description: 'Mo ta thu hai',
          code: '20',
          hasItemDetail: true,
          createdAt: '2021-07-21T06:39:37.194Z',
          updatedAt: '2021-07-21T06:39:37.194Z',
        },
        {
          id: 47,
          name: 'Tuan',
          description: 'Mo ta thu hai',
          code: '19',
          hasItemDetail: true,
          createdAt: '2021-07-21T06:39:34.431Z',
          updatedAt: '2021-07-21T06:39:34.431Z',
        },
        {
          id: 46,
          name: 'Tuan',
          description: 'Mo ta thu hai',
          code: '18',
          hasItemDetail: false,
          createdAt: '2021-07-21T06:39:29.260Z',
          updatedAt: '2021-07-21T06:39:29.260Z',
        },
        {
          id: 45,
          name: 'Tuan',
          description: 'Mo ta thu hai',
          code: '17',
          hasItemDetail: false,
          createdAt: '2021-07-21T06:39:25.161Z',
          updatedAt: '2021-07-21T06:39:25.161Z',
        },
      ],
      meta: {
        total: 4,
      },
    },
  })
  @Expose()
  data: MetaData;
}
