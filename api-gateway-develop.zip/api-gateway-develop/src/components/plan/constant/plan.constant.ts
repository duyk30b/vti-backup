export enum ModeType {
  DELAY = 1,
  EVENLY_CAPACITY = 2,
  INPUT_CAPACITY = 3,
}
