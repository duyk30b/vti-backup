import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Req,
} from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { CreateFactoryCalendarRequestDto } from './dto/request/create-factory-calendar.request';
import { CreateListFactoryCalendarRequestDto } from './dto/request/create-list-factory-calendar.request.dto';
import { CreateWorkCenterCalendarRequestDto } from './dto/request/create-work-center-calendar.request';
import { ModerationEvenlyRequestDto } from './dto/request/moderation-evenly.request.dto';
import { GetMasterPlanRequestDto } from './dto/request/get-master-plan.request';
import { ModerationInputRequestDto } from './dto/request/moderation-input.request';
import { SearchFactoryCalendarRequestDto } from './dto/request/search-factory-calendar.request';
import { SearchWorkCenterCalendarRequestDto } from './dto/request/search-work-center-calendar.request';
import { UpdateFactoryCalendarRequestDto } from './dto/request/update-factory-calendar.request';
import { UpdateWorkCenterCalendarRequestDto } from './dto/request/update-work-center-calendar.request';
import { CreateUpdateFactoryCalendarResponseDto } from './dto/response/create-update-factory-calendar.response';
import { CreateUpdateWorkCenterCalendarResponseDto } from './dto/response/create-update-work-center-calendar.response';
import {
  GetMasterPlanResponseDto,
  MasterPlanResponseDto,
} from './dto/response/get-master-plan.response';
import { ListFactoryCalendarResponseDto } from './dto/response/list-factory-calendar.response';
import { ListWorkCenterCalendarResponseDto } from './dto/response/list-work-center-calendar.response';
import { SuggestSpreardRequestDto } from './dto/request/suggest-spread.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { CreateMasterPlanRequestDto } from './dto/request/create-master-plan.dto';
import { GetMasterPlanDetailRequestDto } from './dto/request/get-master-plan-detail.request.dto';
import { ManufacturingOrderConfirmedEvent } from './dto/request/event/manufacturing-order-confirmed.event.request.dto';
import { UpdateMasterPlanRequestDto } from './dto/request/update-master-plan.dto';
import { InitInsertDataRequestDto } from '@components/item/dto/request/init/init-insert-data.request.dto';
import { Public } from '@core/decorators/set-public.decorator';
import { SaleOrderProgressReportRequestDto } from './dto/request/sale-order/sale-order-progress-report.request.dto';
import { SaleOrderProgressReportResponseDto } from './dto/response/sale-order-progress-report.response.dto';

@Controller('plans')
@ApiTags('Plans')
export class PlanController {
  constructor(
    @Inject('PLAN_SERVICE')
    private readonly planServiceClient: ClientProxy,
  ) {}

  @Get('ping')
  public async get(): Promise<any> {
    return await this.planServiceClient.send('ping', {});
  }

  // FactoryCalendar
  @Post('/factory-calendars')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Tạo calendar nhà máy',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: CreateUpdateFactoryCalendarResponseDto,
  })
  public async createFactoryCalendarRequest(
    @Body() request: CreateFactoryCalendarRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      user: req.user,
    };

    return await this.planServiceClient.send(
      'create_factory_calendar',
      payload,
    );
  }

  @Put('/factory-calendars')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Sửa calendar nhà máy',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: CreateUpdateFactoryCalendarResponseDto,
  })
  public async updateFactoryCalendarRequest(
    @Body() request: UpdateFactoryCalendarRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      user: req.user,
    };
    return await this.planServiceClient.send(
      'update_factory_calendar',
      payload,
    );
  }

  @Delete('/factory-calendars/:id')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Xóa calendar nhà máy',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deleteFactoryCalendarRequest(
    @Param('id', new ParseIntPipe()) id: number,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id,
      userId: req.user.id,
    };
    return await this.planServiceClient.send(
      'delete_factory_calendar',
      payload,
    );
  }

  @Get('/factory-calendars')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Danh sách calendar nhà máy trong tháng',
  })
  @ApiResponse({
    status: 200,
    description: 'Search successfully',
    type: ListFactoryCalendarResponseDto,
  })
  public async listFactoryCalendarRequest(
    @Query() request: SearchFactoryCalendarRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
    };

    return await this.planServiceClient.send('list_factory_calendar', payload);
  }

  @Get('/factory-calendars/events')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Danh sách calendar nhà máy trong tháng',
  })
  @ApiResponse({
    status: 200,
    description: 'Search successfully',
    type: ListFactoryCalendarResponseDto,
  })
  public async listEventRequest(
    @Query() request: SearchFactoryCalendarRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
    };

    return await this.planServiceClient.send('list_event', payload);
  }

  @Post('/factory-calendars/setup')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Điều độ nhập quantity',
  })
  @ApiResponse({
    status: 200,
    description: 'Moderation input successfully',
    type: CreateListFactoryCalendarRequestDto,
  })
  public async createListFactoryCalendar(
    @Body() request: CreateListFactoryCalendarRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      user: req.user,
    };

    return await this.planServiceClient.send('setup_factory_calendar', payload);
  }

  // WorkCenterCalendar
  @Post('/work-center-calendars')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Tạo calendar phân xưởng',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: CreateUpdateWorkCenterCalendarResponseDto,
  })
  public async createWorkCenterCalendarRequest(
    @Body() request: CreateWorkCenterCalendarRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
    };

    return await this.planServiceClient.send(
      'create_work_center_calendar',
      payload,
    );
  }

  @Put('/work-center-calendars')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Sửa calendar phân xưởng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: CreateUpdateWorkCenterCalendarResponseDto,
  })
  public async updateWorkCenterCalendarRequest(
    @Body() request: UpdateWorkCenterCalendarRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
    };
    return await this.planServiceClient.send(
      'update_work_center_calendar',
      payload,
    );
  }

  @Delete('/work-center-calendars/:id')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Xóa calendar phân xưởng',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deleteWorkCenterCalendarRequest(
    @Param('id', new ParseIntPipe()) id: number,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id,
      userId: req.user.id,
    };
    return await this.planServiceClient.send(
      'delete_work_center_calendar',
      payload,
    );
  }

  @Get('/work-center-calendars')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Danh sách calendar phân xưởng trong tháng',
  })
  @ApiResponse({
    status: 200,
    description: 'Search successfully',
    type: ListWorkCenterCalendarResponseDto,
  })
  public async listWorkCenterCalendarRequest(
    @Query() request: SearchWorkCenterCalendarRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
    };

    return await this.planServiceClient.send(
      'list_work_center_calendar',
      payload,
    );
  }

  // planing
  @Post('/moderations/evenly/preview')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Preview Điều độ lùi ngày',
  })
  @ApiResponse({
    status: 200,
    description: 'Moderation spread successfully',
  })
  public async previewModerationEvenly(
    @Body() request: ModerationEvenlyRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
    };

    return await this.planServiceClient.send(
      'preview_moderation_evenly',
      payload,
    );
  }

  @Post('/moderations/evenly')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Điều độ lùi ngày',
  })
  @ApiResponse({
    status: 200,
    description: 'Moderation spread successfully',
  })
  public async moderationEvenly(
    @Body() request: ModerationEvenlyRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
    };

    return await this.planServiceClient.send('moderation_evenly', payload);
  }

  @Get('/master-plans')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'get list master plan',
  })
  @ApiResponse({
    status: 200,
    description: 'Get master plan successfully',
    type: GetMasterPlanResponseDto,
  })
  public async getMasterPlans(
    @Query() request: GetMasterPlanRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
    };

    return await this.planServiceClient.send('get_master_plans', payload);
  }

  @Get('/master-plans/:masterPlanId')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'get master plan by id',
  })
  @ApiResponse({
    status: 200,
    description: 'Get master plan successfully',
    type: MasterPlanResponseDto,
  })
  public async getMasterPlan(
    @Param('masterPlanId', new ParseIntPipe()) masterPlanId: number,
    @Query() request: GetMasterPlanDetailRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      masterPlanId,
      ...request,
      userId: req.user.id,
    };

    return await this.planServiceClient.send('get_master_plan', payload);
  }

  @Get('/master-plans/:id/materials')
  @ApiOperation({
    tags: ['Material', 'PLAN'],
    summary: '',
    description: 'Get material plan by master plan id',
  })
  @ApiResponse({
    status: 200,
    description: 'Get material plan by master plan successfully',
    type: MasterPlanResponseDto,
  })
  public async getMaterialPlan(
    @Param('id', new ParseIntPipe()) masterPlanId: number,
    @Query() request: GetMasterPlanDetailRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      masterPlanId,
      ...request,
      userId: req.user.id,
    };

    return await this.planServiceClient.send('get_material_plan', payload);
  }

  @Get('/master-plans/:id/schedule')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'get master plan by id',
  })
  @ApiResponse({
    status: 200,
    description: 'Get master plan successfully',
    type: MasterPlanResponseDto,
  })
  public async getScheduleMasterPlan(
    @Param('id', new ParseIntPipe()) id: number,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      masterPlanId: id,
      userId: req.user.id,
    };

    return await this.planServiceClient.send(
      'get_schedule_master_plan',
      payload,
    );
  }

  @Delete('/master-plans/:id')
  @ApiOperation({
    tags: ['Delete', 'Master Plan'],
    summary: '',
    description: 'Delete master plan by id',
  })
  @ApiResponse({
    status: 200,
    description: 'Get master plan successfully',
    type: SuccessResponse,
  })
  public async deleteMasterPlan(
    @Param('id', new ParseIntPipe()) id: number,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
    };

    return await this.planServiceClient.send('delete_master_plan', payload);
  }

  @Post('/master-plans/:id/moderations/input')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Điều độ nhập quantity',
  })
  @ApiResponse({
    status: 200,
    description: 'Moderation input successfully',
    type: ModerationInputRequestDto,
  })
  public async moderationInput(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() request: ModerationInputRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      id: +id,
      userId: req.user.id,
    };

    return await this.planServiceClient.send('moderation_input', payload);
  }

  @Get('master-plans/:masterPlanId/moderations/suggest-spread')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Suggest Điều độ nhập quantity',
  })
  @ApiResponse({
    status: 200,
    description: 'Moderation input successfully',
    type: ModerationInputRequestDto,
  })
  public async suggestModerationInput(
    @Param('masterPlanId', new ParseIntPipe()) masterPlanId: number,
    @Query() request: SuggestSpreardRequestDto,
  ): Promise<any> {
    return await this.planServiceClient.send('suggest_moderation_input', {
      ...request,
      masterPlanId,
    });
  }

  @Get('master-plans/:masterPlanId/items-producing-step/detail')
  @ApiOperation({
    tags: ['Plan', 'PLAN'],
    summary: '',
    description: 'Get detail item producing step',
  })
  @ApiResponse({
    status: 200,
    description: 'Moderation input successfully',
    type: ModerationInputRequestDto,
  })
  public async getDetailItemsProducingStep(
    @Param('masterPlanId', new ParseIntPipe()) masterPlanId: number,
    @Query() request: SuggestSpreardRequestDto,
  ): Promise<any> {
    return await this.planServiceClient.send('get_detail_item_producing_step', {
      ...request,
      masterPlanId,
    });
  }

  @Get('/create-schedule/:id')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'Suggest Điều độ nhập quantity',
  })
  @ApiResponse({
    status: 200,
    description: 'Moderation input successfully',
    type: ModerationInputRequestDto,
  })
  public async createSchedule(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    return await this.planServiceClient.send('create_schedule', id);
  }

  @Put('master-plans/:id/approve')
  @ApiOperation({
    tags: ['Plans', 'Master Plan'],
    summary: 'Xác nhận kế hoạch',
    description: 'Xác nhận kế hoạch',
  })
  @ApiResponse({
    status: 200,
    description: 'Update status master plan success',
    type: SuccessResponse,
  })
  public async approveMasterPlan(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.planServiceClient.send('approve_master_plan', payload);
  }

  @Put('master-plans/:id/reject')
  @ApiOperation({
    tags: ['Plans', 'Master Plan'],
    summary: 'Reject kế hoạch',
    description: 'Reject kế hoạch',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject Master Plan Success',
    type: SuccessResponse,
  })
  public async rejectMasterPlan(
    @Param('id', new ParseIntPipe()) id,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req.headers['lang'],
    };
    return await this.planServiceClient.send('reject_master_plan', payload);
  }

  @Post('/master-plans/create')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'create master plan',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async createMasterPlan(
    @Body() request: CreateMasterPlanRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
    };

    return await this.planServiceClient.send('create_master_plan', payload);
  }

  @Put('/master-plans/:id')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'update master plan',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  public async updateMasterPlan(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() request: UpdateMasterPlanRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id,
      ...request,
      userId: req.user.id,
    };

    return await this.planServiceClient.send('update_master_plan', payload);
  }

  @Put('/master-plans/:id/events/manufacturing-orders/confirmed')
  @ApiOperation({
    tags: ['PLAN'],
    summary: '',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async manufacturingOrderConfirmedEvent(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() request: ManufacturingOrderConfirmedEvent,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      ...request,
      userId: req.user.id,
    };

    return await this.planServiceClient.send(
      'manufacturing_order_confirmed_event',
      payload,
    );
  }

  @Get('/master-plans/:masterPlanId/flat-items')
  @ApiOperation({
    tags: ['PlanRequest', 'PLAN'],
    summary: '',
    description: 'get master plan by id flat items',
  })
  @ApiResponse({
    status: 200,
    description: 'Get master plan successfully',
    type: MasterPlanResponseDto,
  })
  public async getMasterPlanFlat(
    @Param('masterPlanId', new ParseIntPipe()) masterPlanId: number,
    @Query() request: GetMasterPlanDetailRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      masterPlanId,
      userId: req.user.id,
      lang: req.headers['lang'],
    };

    return await this.planServiceClient.send(
      'get_master_plan_flat_items',
      payload,
    );
  }

  @Public()
  @Post('/init-insert-data')
  @ApiOperation({
    tags: ['Items'],
    summary: 'init insert data',
    description: 'init insert data',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: null,
  })
  public async initInsertData(
    @Body() request: InitInsertDataRequestDto[],
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      lang: req.headers['lang'],
    };

    return await this.planServiceClient.send(
      'plan_service_insert_data',
      payload,
    );
  }

  @Get('sale-order-schedules/sale-orders/:id/progress/report')
  @ApiOperation({
    tags: ['Sale Order'],
    summary: 'Report',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Report',
    type: SaleOrderProgressReportResponseDto,
  })
  public async saleOrderProgressReport(
    @Param('id', new ParseIntPipe()) id: number,
    @Query() query: SaleOrderProgressReportRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return await this.planServiceClient.send('sale_order_progress_report', {
      id: id,
      ...query,
      userId: req.user.id,
      lang: req.headers['lang'],
    });
  }
}
