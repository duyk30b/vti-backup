import { ApiProperty } from '@nestjs/swagger';
import { IsDate, IsNotEmpty } from 'class-validator';

export class SearchCalendarAbstractRequestDto {
  @ApiProperty({ example: '2021-01-26T00:00:00.000Z' })
  @IsDate()
  @IsNotEmpty()
  from: Date;

  @ApiProperty({ example: '2022-02-05T00:00:00.000Z' })
  @IsDate()
  @IsNotEmpty()
  to: Date;
}
