import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsDate, IsNotEmpty, IsNumber, IsString } from 'class-validator';

export class CalendarAbstractRequestDto {
  @ApiProperty({ example: 'Nghỉ tết dương' })
  @IsString()
  @IsNotEmpty()
  title: string;

  @ApiPropertyOptional({ example: 'Nghỉ 3 ngày' })
  @IsString()
  description: string;

  @ApiProperty({ example: '2022-01-01T00:00:00.000Z' })
  @IsDate()
  @IsNotEmpty()
  from: Date;

  @ApiProperty({ example: '2022-01-04T00:00:00.000Z' })
  @IsDate()
  @IsNotEmpty()
  to: Date;

  @ApiProperty({ example: 0 })
  @IsNumber()
  @IsNotEmpty()
  type: number;
}
