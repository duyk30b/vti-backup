import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class CalendarAbstractResponseDto {
  @Expose()
  @ApiProperty({ example: 1 })
  id: number;

  @Expose()
  @ApiProperty({ example: 'Nghỉ tết dương' })
  title: string;

  @Expose()
  @ApiProperty({ example: 'Nghỉ 3 ngày' })
  description: string;

  @Expose()
  @ApiProperty({ example: '2022-01-01T00:00:00.000Z' })
  from: Date;

  @Expose()
  @ApiProperty({ example: '2022-01-04T00:00:00.000Z' })
  to: Date;

  @Expose()
  @ApiProperty({ example: 0 })
  type: number;

  @Expose()
  @ApiProperty({ example: '2021-11-30T00:00:00.000Z' })
  created_at: Date;

  @Expose()
  @ApiProperty({ example: '2021-11-30T00:00:00.000Z' })
  updated_at: Date;
}
