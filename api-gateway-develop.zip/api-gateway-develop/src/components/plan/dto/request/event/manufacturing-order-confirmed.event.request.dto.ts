import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import {
  IsNotEmpty,
  ValidateNested,
  ArrayNotEmpty,
  IsDateString,
} from 'class-validator';

export class ManufacturingOrderConfirmedEvent {
  @ApiProperty()
  @Expose()
  @IsNotEmpty()
  saleOrderId: number;

  @ApiProperty({ isArray: true })
  @ArrayNotEmpty()
  @ValidateNested()
  itemIds: number[];

  @ApiProperty()
  @IsDateString()
  dateFrom: Date;

  @ApiProperty()
  @IsDateString()
  dateTo: Date;
}
