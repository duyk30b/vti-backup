import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsDateString, IsOptional, IsString } from 'class-validator';

export class SaleOrderProgressReportRequestDto {
  @ApiPropertyOptional()
  @IsOptional()
  moIds: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  itemIds: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  producingStepIds: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  workCenterIds: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  dateFrom: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  dateTo: string;
}
