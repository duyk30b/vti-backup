import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsInt, IsNotEmpty } from 'class-validator';

export class ModerationEvenlyRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemProducingStepId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  dateFrom: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  dateTo: Date;
}
