import { CreateMasterPlanRequestDto } from './create-master-plan.dto';

export class UpdateMasterPlanRequestDto extends CreateMasterPlanRequestDto {}
