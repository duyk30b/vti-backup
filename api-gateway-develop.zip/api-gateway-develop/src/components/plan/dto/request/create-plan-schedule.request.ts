import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsArray,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsString,
} from 'class-validator';

class ProducingStep {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  producingStepId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  workCenterId: number;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  productionTimePerItem: number;
}

class BomDetail {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  itemId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  quantity: number;

  @ApiProperty({
    type: ProducingStep,
    isArray: true,
  })
  @IsNotEmpty()
  producingSteps: ProducingStep[];
}

class WorkCenters {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  workCenterId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  workCenterShiftId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  workCenterShiftRelaxId: number;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  workCenterName: string;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  productivityIndex: number;
}

class Bom {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  bomId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  itemId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  quantity: number;

  @ApiProperty({
    type: BomDetail,
    isArray: true,
  })
  @IsNotEmpty()
  bomDetails: BomDetail[];

  @ApiProperty({
    type: WorkCenters,
    isArray: true,
  })
  @IsNotEmpty()
  workCenters: WorkCenters[];
}

export class CreatePlanScheduleRequestDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  soId: number;

  @ApiPropertyOptional()
  @IsString()
  name: number;

  @ApiPropertyOptional()
  @IsString()
  code: number;

  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  dateFrom: Date;

  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  dateTo: Date;

  @ApiProperty({
    type: Bom,
    isArray: true,
  })
  @IsNotEmpty()
  boms: Bom[];
}
