import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CalendarAbstractRequestDto } from '../abstract/calendar.abstract.request.dto';

export class CreateWorkCenterCalendarRequestDto extends CalendarAbstractRequestDto {
  @ApiProperty({ example: 1 })
  @IsInt()
  @IsNotEmpty()
  workCenterId: number;
}
