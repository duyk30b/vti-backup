import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsNotEmpty, IsString } from 'class-validator';
import { CalendarAbstractRequestDto } from '../abstract/calendar.abstract.request.dto';

export class CreateFactoryCalendarRequestDto extends CalendarAbstractRequestDto {
  @ApiProperty({ example: [1, 2] })
  @IsArray()
  @IsNotEmpty()
  factoryIds: number[];

  @ApiProperty({ example: 'Mã' })
  @IsString()
  @IsNotEmpty()
  code: string;
}
