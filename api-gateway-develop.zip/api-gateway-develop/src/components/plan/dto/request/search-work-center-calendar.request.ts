import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';
import { SearchCalendarAbstractRequestDto } from '../abstract/search-calendar.abstract.dto';

export class SearchWorkCenterCalendarRequestDto extends SearchCalendarAbstractRequestDto {
  @ApiProperty({ example: 1 })
  @IsString()
  @IsNotEmpty()
  workCenterId: number;
}
