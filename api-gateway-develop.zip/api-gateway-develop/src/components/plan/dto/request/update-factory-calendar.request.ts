import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsNotEmpty, IsNumber, IsString } from 'class-validator';
import { CalendarAbstractRequestDto } from '../abstract/calendar.abstract.request.dto';

export class UpdateFactoryCalendarRequestDto extends CalendarAbstractRequestDto {
  @ApiProperty({ example: 1 })
  @IsNumber()
  @IsNotEmpty()
  id: number;

  @ApiProperty({ example: [1, 2] })
  @IsArray()
  @IsNotEmpty()
  factoryIds: number[];
}
