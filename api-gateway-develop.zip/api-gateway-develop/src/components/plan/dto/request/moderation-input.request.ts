import { ModeType } from '@components/plan/constant/plan.constant';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsEnum,
  IsInt,
  IsNotEmpty,
  ValidateNested,
} from 'class-validator';

class WorkCenterDetailSchedule {
  @ApiProperty({ example: 1 })
  @IsInt()
  @IsNotEmpty()
  id: number;

  @ApiProperty({ example: 1 })
  @IsInt()
  @IsNotEmpty()
  quantity: number;
}

class Item {
  @ApiProperty({ example: 1 })
  @IsInt()
  @IsNotEmpty()
  itemId: number;

  @ValidateNested()
  @ApiProperty({ type: WorkCenterDetailSchedule, isArray: true })
  @IsArray()
  @Type(() => WorkCenterDetailSchedule)
  @IsNotEmpty()
  workCenterDetailSchedules: WorkCenterDetailSchedule[];
}

export class ModerationInputRequestDto {
  @ValidateNested()
  @ApiProperty({
    type: Item,
    isArray: true,
  })
  @IsArray()
  @Type(() => Item)
  @IsNotEmpty()
  items: Item[];

  @ApiProperty({ example: 1 })
  @IsEnum(ModeType)
  @IsNotEmpty()
  modeType: ModeType;
}
