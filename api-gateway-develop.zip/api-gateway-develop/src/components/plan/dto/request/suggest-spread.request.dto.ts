import { ApiProperty } from '@nestjs/swagger';
import { IsArray, isNotEmpty } from 'class-validator';

export class SuggestSpreardRequestDto {
  @ApiProperty()
  @IsArray()
  itemProducingStepIds: number[];
}
