import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';
import { SearchCalendarAbstractRequestDto } from '../abstract/search-calendar.abstract.dto';

export class SearchFactoryCalendarRequestDto extends SearchCalendarAbstractRequestDto {
  @ApiPropertyOptional({ example: 1 })
  @IsString()
  @IsOptional()
  factoryId: number;
}
