import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsString } from 'class-validator';
import { CalendarAbstractRequestDto } from '../abstract/calendar.abstract.request.dto';

export class UpdateWorkCenterCalendarRequestDto extends CalendarAbstractRequestDto {
  @ApiProperty({ example: 1 })
  @IsNumber()
  @IsNotEmpty()
  id: number;

  @ApiProperty({ example: 1 })
  @IsString()
  @IsNotEmpty()
  workCenterId: number;
}
