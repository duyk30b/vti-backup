import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsDateString,
  IsMilitaryTime,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';

class Relax {
  @ApiPropertyOptional({ example: 'Nghỉ giải lao K1' })
  @IsString()
  @IsOptional()
  title: string;

  @ApiPropertyOptional({ example: '01:00' })
  @IsMilitaryTime()
  @IsNotEmpty()
  from: string;

  @ApiPropertyOptional({ example: '01:15' })
  @IsMilitaryTime()
  @IsNotEmpty()
  to: string;
}

class Shift {
  @ApiPropertyOptional({ example: 'K1' })
  @IsString()
  @IsOptional({ message: '' })
  title: string;

  @ApiPropertyOptional({ example: '00:00' })
  @IsMilitaryTime()
  @IsNotEmpty()
  from: string;

  @ApiPropertyOptional({ example: '01:00' })
  @IsMilitaryTime()
  @IsNotEmpty()
  to: string;

  @ApiProperty({ type: Relax, isArray: true })
  @Type(() => Relax)
  @IsArray()
  @IsOptional()
  relaxs: Relax[];
}

export class CreateListFactoryCalendarRequestDto {
  @ApiPropertyOptional({ example: 'Mô tả' })
  @IsString()
  @IsOptional()
  @MaxLength(255)
  description: string;

  @ApiProperty({ example: '2022-01-01T00:00:00.000Z' })
  @IsDateString()
  @IsNotEmpty()
  from: string;

  @ApiProperty({ example: '2022-01-01T00:00:00.000Z' })
  @IsDateString()
  @IsNotEmpty()
  to: string;

  @ApiProperty({ example: [1, 2] })
  @IsArray()
  @IsNotEmpty()
  factoryIds: number[];

  @ApiProperty({
    example: [1, 2],
    description: '0 -> 6, tương ứng Chủ Nhật -> Thứ 7',
  })
  @IsArray()
  @IsOptional()
  workDays: number[];

  @ApiProperty({ type: Shift, isArray: true })
  @Type(() => Shift)
  @IsArray()
  @IsOptional()
  shifts: Shift[];
}
