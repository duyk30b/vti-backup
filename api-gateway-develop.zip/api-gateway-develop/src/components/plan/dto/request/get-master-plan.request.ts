import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { Transform } from 'class-transformer';
import { IsInt, IsOptional, IsString } from 'class-validator';

export class GetMasterPlanRequestDto extends PaginationQuery {
  @ApiPropertyOptional({
    type: Number,
    example: 1,
  })
  @Transform((data) => Number(data.value))
  @IsInt()
  @IsOptional()
  soId: number;

  @ApiPropertyOptional({
    type: Number,
    example: 1,
  })
  @Transform((data) => Number(data.value))
  @IsInt()
  @IsOptional()
  masterPlanId: number;

  @ApiPropertyOptional({ example: '1,2,3' })
  @IsString()
  @IsOptional()
  itemIds: string;
}
