import { ApiProperty } from '@nestjs/swagger';
import {
  IsDateString,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
} from 'class-validator';

export class GetMasterPlanDetailRequestDto {
  @ApiProperty()
  @IsOptional()
  @IsInt()
  saleOrderId: number;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  planFrom: Date;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  planTo: Date;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  @IsEnum([0, 1])
  isActive: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  itemIds: string;
}
