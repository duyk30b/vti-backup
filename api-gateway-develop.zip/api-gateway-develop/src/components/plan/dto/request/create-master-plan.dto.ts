import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsDateString,
  IsInt,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

class SaleOrder {
  @ApiProperty()
  @IsInt()
  id: number;
}
export class CreateMasterPlanRequestDto {
  @ApiProperty({ type: SaleOrder, isArray: true })
  @IsArray()
  @ValidateNested()
  @Type(() => SaleOrder)
  saleOrders: SaleOrder[];

  @ApiProperty()
  @IsInt()
  factoryId: number;

  @ApiProperty()
  @IsString()
  code: string;

  @ApiProperty()
  @IsString()
  name: string;

  @ApiPropertyOptional()
  @IsOptional()
  description?: string;

  @ApiProperty()
  @IsDateString()
  dateFrom: string;

  @ApiProperty()
  @IsDateString()
  dateTo: string;

  @ApiProperty()
  @IsDateString()
  dateFromSo: string;

  @ApiProperty()
  @IsInt()
  dateCompletion: number;
}
