import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';

class ItemProducingStepSchedule {
  @ApiProperty({ example: 1 })
  @Expose()
  id: number;

  @ApiProperty({ example: 1 })
  @Expose()
  itemScheduleId: number;

  @ApiProperty({ example: 1 })
  @Expose()
  producingStepId: number;

  @ApiProperty({ example: 'name' })
  @Expose()
  producingStepName: string;

  @ApiProperty({ example: 1 })
  @Expose()
  quantity: number;

  @ApiProperty({ example: 1 })
  @Expose()
  actualQuantity: number;

  @ApiProperty({ example: 1 })
  @Expose()
  errorQuantity: number;

  @ApiProperty({ example: '2022-02-23T00:00:00.000Z' })
  @Expose()
  dateFrom: string;

  @ApiProperty({ example: '2022-02-23T00:00:00.000Z' })
  @Expose()
  dateTo: string;

  @ApiProperty({ example: '2022-02-23T10:13:54.306Z' })
  @Expose()
  createdAt: string;

  @ApiProperty({ example: '2022-02-23T10:13:54.306Z' })
  @Expose()
  updatedAt: string;
}

class ItemSchedule {
  @ApiProperty({ example: 1 })
  @Expose()
  id: number;

  @ApiProperty({ example: 1 })
  @Expose()
  saleOrderScheduleId: number;

  @ApiProperty({ example: 1 })
  @Expose()
  itemId: number;

  @ApiProperty({ example: 'name' })
  @Expose()
  itemName: string;

  @ApiProperty({ example: 'cái' })
  @Expose()
  itemUnitName: string;

  @ApiProperty({ example: 1 })
  @Expose()
  bomId: number;

  @ApiProperty({ example: 1 })
  @Expose()
  parentBomId: number;

  @ApiProperty({ example: 1 })
  @Expose()
  quantity: number;

  @ApiProperty({ example: 1 })
  @Expose()
  actualQuantity: number;

  @ApiProperty({ example: 1 })
  @Expose()
  errorQuantity: number;

  @ApiProperty({ example: '2022-02-23T00:00:00.000Z' })
  @Expose()
  dateFrom: string;

  @ApiProperty({ example: '2022-02-23T00:00:00.000Z' })
  @Expose()
  dateTo: string;

  @ApiProperty({ example: '2022-02-23T10:13:54.306Z' })
  @Expose()
  createdAt: string;

  @ApiProperty({ example: '2022-02-23T10:13:54.306Z' })
  @Expose()
  updatedAt: string;

  @ApiProperty({
    type: ItemSchedule,
    isArray: true,
  })
  @Expose()
  itemChildrens: ItemSchedule[];

  @ApiProperty({
    type: ItemProducingStepSchedule,
    isArray: true,
  })
  @Expose()
  itemProducingStepSchedules: ItemProducingStepSchedule[];
}

class SaleOrderSchedule {
  @ApiProperty({ example: 1 })
  @Expose()
  id: number;

  @ApiProperty({ example: 1 })
  @Expose()
  saleOrderId: number;

  @ApiProperty({ example: 1 })
  @Expose()
  saleOrderName: string;

  @ApiProperty({ example: '2022-02-23T00:00:00.000Z' })
  @Expose()
  dateFrom: string;

  @ApiProperty({ example: '2022-02-23T00:00:00.000Z' })
  @Expose()
  dateTo: string;

  @ApiProperty({ example: '2022-02-23T10:13:54.306Z' })
  @Expose()
  createdAt: string;

  @ApiProperty({ example: '2022-02-23T10:13:54.306Z' })
  @Expose()
  updatedAt: string;

  @ApiProperty({
    type: ItemSchedule,
    isArray: true,
  })
  @Expose()
  itemSchedules: ItemSchedule[];
}

export class MasterPlanResponseDto {
  @ApiProperty({ example: 1 })
  @Expose()
  id: number;

  @ApiProperty({ example: 'abc' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'abc' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'abc' })
  @Expose()
  description: string;

  @ApiProperty({ example: '2022-02-23T00:00:00.000Z' })
  @Expose()
  dateFrom: Date;

  @ApiProperty({ example: '2022-02-23T00:00:00.000Z' })
  @Expose()
  dateTo: Date;

  @ApiProperty({ example: '2022-02-23T00:00:00.000Z' })
  @Expose()
  createdAt: Date;

  @ApiProperty({ example: '2022-02-23T00:00:00.000Z' })
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: SaleOrderSchedule })
  @Type(() => SaleOrderSchedule)
  @Expose()
  saleOrderSchedules: SaleOrderSchedule[];
}
export class GetMasterPlanResponseDto extends SuccessResponse {
  @ApiProperty({
    type: MasterPlanResponseDto,
    isArray: true,
  })
  @Expose()
  data: MasterPlanResponseDto[];
}
