import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';
import { CalendarAbstractResponseDto } from '../abstract/calendar.abstract.response.dto';

class WorkCenterCalendarRequestItem extends CalendarAbstractResponseDto {
  @Expose()
  @ApiProperty({ example: 1 })
  workCenterId: number;
}
export class CreateUpdateWorkCenterCalendarResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: WorkCenterCalendarRequestItem;
}
