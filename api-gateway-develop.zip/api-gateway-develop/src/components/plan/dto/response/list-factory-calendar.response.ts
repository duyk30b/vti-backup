import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';
import { CalendarAbstractResponseDto } from '../abstract/calendar.abstract.response.dto';

class FactoryCalendarRequest extends CalendarAbstractResponseDto {
  @Expose()
  @ApiProperty({ example: 1 })
  factoryId: number;
}
export class ListFactoryCalendarResponseDto extends SuccessResponse {
  @ApiProperty({
    type: FactoryCalendarRequest,
    isArray: true,
  })
  @Expose()
  data: FactoryCalendarRequest[];
}
