import { BasicResponseDto } from '@core/dto/response/basic.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class Item extends BasicResponseDto {}
class Calendar {
  @Expose()
  @ApiProperty()
  executionDate: string;

  @Expose()
  @ApiProperty()
  planQuantity: number;

  @Expose()
  @ApiProperty()
  actualQuantity: number;

  @Expose()
  @ApiProperty()
  lateQuantity: number;

  @Expose()
  @ApiProperty()
  totalPlanQuantity: number;

  @Expose()
  @ApiProperty()
  totalActualQuantity: number;

  @Expose()
  @ApiProperty()
  totalLateQuantity: number;
}

export class SaleOrderProgressReportDto {
  @Expose()
  @ApiProperty({ type: Item })
  @Type(() => Item)
  item: Item;

  @Expose()
  @ApiProperty({ isArray: true, type: Calendar })
  @IsArray()
  @Type(() => Calendar)
  calendar: Calendar;
}

export class SaleOrderProgressReportResponseDto extends SuccessResponse {
  @ApiProperty({ type: SaleOrderProgressReportDto })
  @Expose()
  data: SaleOrderProgressReportDto;
}
