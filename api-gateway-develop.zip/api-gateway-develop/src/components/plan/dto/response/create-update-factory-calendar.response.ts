import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';
import { CalendarAbstractResponseDto } from '../abstract/calendar.abstract.response.dto';

class FactoryCalendarRequestItem extends CalendarAbstractResponseDto {
  @Expose()
  @ApiProperty({ example: 1 })
  factoryId: number;
}
export class CreateUpdateFactoryCalendarResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: FactoryCalendarRequestItem;
}
