import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';
import { CalendarAbstractResponseDto } from '../abstract/calendar.abstract.response.dto';

class WorkCenterCalendarRequest extends CalendarAbstractResponseDto {
  @Expose()
  @ApiProperty({ example: 1 })
  workCenterId: number;
}
export class ListWorkCenterCalendarResponseDto extends SuccessResponse {
  @ApiProperty({
    type: WorkCenterCalendarRequest,
    isArray: true,
  })
  @Expose()
  data: WorkCenterCalendarRequest[];
}
