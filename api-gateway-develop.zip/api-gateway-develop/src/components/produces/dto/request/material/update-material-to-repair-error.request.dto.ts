import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsInt, IsString, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';

class MaterialToRepairError {
  @ApiProperty({ example: 1 })
  @IsInt()
  workOrderId: number;

  @ApiProperty({ example: 1 })
  @IsInt()
  errorRepairQuantity: number;

  @ApiProperty({ example: 1 })
  @IsInt()
  itemId: number;

  @ApiProperty({ example: 'cái' })
  @IsString()
  itemUnit: string;

  @ApiProperty({ example: 'bàn' })
  @IsString()
  itemName: string;
}

export class UpdateMaterialToRepairErrorRequestDto {
  @ApiProperty({ type: MaterialToRepairError, isArray: true })
  @IsArray()
  @ValidateNested()
  @Type(() => MaterialToRepairError)
  materials: MaterialToRepairError[];
}
