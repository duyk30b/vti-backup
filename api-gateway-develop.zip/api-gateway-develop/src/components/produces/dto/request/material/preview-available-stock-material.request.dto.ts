import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsInt, IsNotEmpty, IsNumber } from 'class-validator';
import { Type } from 'class-transformer';

class MaterialItem {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  quantity: number;
}

export class PreviewAvailableStockMaterialRequestDto {
  @ApiProperty({
    isArray: true,
    type: MaterialItem,
  })
  @IsNotEmpty()
  @IsArray()
  @Type(() => MaterialItem)
  items: MaterialItem[];
}
