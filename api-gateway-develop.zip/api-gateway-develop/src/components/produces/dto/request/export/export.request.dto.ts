import { TypeEnum } from '@components/user/user.constant';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsEnum, IsOptional } from 'class-validator';

export class ExportRequestDto {
  @ApiPropertyOptional()
  @IsOptional()
  ids: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(TypeEnum)
  type: number;
}
