import {
  IsInt,
  IsNumber,
  IsDateString,
  IsString,
  IsOptional,
  Max,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsPositive } from 'class-validator';

export class ExportWorkOrderRequestDto {
  @ApiProperty({
    description: 'Số lượng xuất',
  })
  @IsNotEmpty()
  @IsNumber()
  @IsPositive()
  quantity: number;

  @ApiProperty({})
  @IsNotEmpty()
  @IsInt()
  workCenterId: number;

  @ApiProperty({})
  @IsNotEmpty()
  @IsInt()
  lotId: number;

  @ApiProperty({
    description: 'Ngày xuất',
  })
  @IsNotEmpty()
  @IsDateString()
  exportDate: Date;

  @ApiProperty({
    description: 'Ghi chú',
  })
  @IsOptional()
  @IsString()
  @Max(255)
  note: string;

  @ApiProperty({
    description: 'Công đoạn nhập',
  })
  @IsNotEmpty()
  @IsInt()
  toProducingStepId: number;
}
