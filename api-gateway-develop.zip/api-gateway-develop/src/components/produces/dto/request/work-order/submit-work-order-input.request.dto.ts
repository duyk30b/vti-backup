import {
  ValidateNested,
  ArrayUnique,
  IsArray,
  IsNumber,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { Type } from 'class-transformer';

class MaterialItemDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  quantity: number;
}

export class SubmitWorkOrderInputRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  workCenterId: number;

  @ApiProperty({
    description: 'Đầu vào',
    isArray: true,
    type: MaterialItemDto,
  })
  @ValidateNested()
  @ArrayUnique((e: MaterialItemDto) => e.itemId)
  @IsArray()
  @Type(() => MaterialItemDto)
  materialItems: MaterialItemDto[];
}
