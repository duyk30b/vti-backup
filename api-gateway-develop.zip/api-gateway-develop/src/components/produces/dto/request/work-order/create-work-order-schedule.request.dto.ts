import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsDate,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class WorkOrderScheduleDetail {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  workCenterId: number;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  @IsPositive()
  quantity: number;
}

export class CreateWorkOrderScheduleRequestDto {
  @ApiProperty({
    example: '2021-07-13 09:13:15.562609+00',
    description: 'plan from',
  })
  @IsDateString()
  @IsNotEmpty()
  planFrom: Date;

  @ApiProperty({
    example: '2021-07-14 09:13:15.562609+00',
    description: 'plan to',
  })
  @IsDateString()
  @IsNotEmpty()
  planTo: Date;

  @ApiProperty({ example: 400.2, description: 'quantity' })
  @IsNotEmpty()
  @IsNumber()
  quantity: number;

  @ApiProperty({
    description: 'Chi tiết lịch làm việc',
    isArray: true,
    type: WorkOrderScheduleDetail,
  })
  @IsNotEmpty()
  @IsArray()
  @ValidateNested()
  @ArrayUnique((e: WorkOrderScheduleDetail) => e.workCenterId)
  @ArrayNotEmpty()
  scheduleDetails: WorkOrderScheduleDetail[];

  @ApiProperty()
  @IsString()
  @IsOptional()
  @MaxLength(255)
  description: string;
}
