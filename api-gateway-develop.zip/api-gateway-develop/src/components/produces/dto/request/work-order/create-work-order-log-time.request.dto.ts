import { IsDateString, IsDecimal, IsInt, IsNotEmpty } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class WorkOrderLogTimeRequestDto {
  @ApiPropertyOptional({ description: 'Bắt đầu' })
  @IsDateString()
  start: string;

  @ApiPropertyOptional()
  @IsDateString()
  play: string;

  @ApiPropertyOptional()
  @IsDateString()
  pause: string;

  @ApiPropertyOptional()
  @IsDateString()
  end: string;

  @ApiPropertyOptional({ description: 'Thời gian thực hiện' })
  @IsDecimal()
  duration: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNotEmpty()
  @IsInt()
  workCenterId: number;
}
