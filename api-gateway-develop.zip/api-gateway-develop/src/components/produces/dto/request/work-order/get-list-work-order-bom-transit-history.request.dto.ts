import { PaginationQuery } from '@utils/pagination.query';

export class GetListWorkOrderBomTransitHistoryRequestDto extends PaginationQuery {}
