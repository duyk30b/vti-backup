import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsNotEmpty,
  IsString,
  MaxLength,
  IsInt,
  IsOptional,
  IsArray,
  IsNumber,
  IsDate,
} from 'class-validator';

export class WorkOrderRequestAbstractDto {
  @IsNotEmpty()
  @IsString()
  @MaxLength(20)
  @ApiProperty({ example: 'R001', description: 'code' })
  code: string;

  @ApiProperty({ example: 'work order 1', description: 'name' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiProperty({ example: 1, description: 'boq id' })
  @IsNotEmpty()
  @IsInt()
  boqId: number;

  @ApiProperty({ example: 1, description: 'routing id' })
  @IsNotEmpty()
  @IsInt()
  routingId: number;

  @ApiProperty({ example: 1, description: 'routing version id' })
  @IsNotEmpty()
  @IsInt()
  routingVersionId: number;

  @ApiProperty({ example: 1, description: 'work center id' })
  @IsNotEmpty()
  @IsInt()
  workCenterId: number;

  @ApiProperty({ example: 1, description: 'boq plan id' })
  @IsNotEmpty()
  @IsInt()
  boqPlanId: number;

  @ApiProperty({ example: 1, description: 'producing step id' })
  @IsNotEmpty()
  @IsInt()
  producingStepId: number;

  @ApiProperty({ example: 1, description: 'bom id' })
  @IsNotEmpty()
  @IsInt()
  bomId: number;

  @ApiProperty({
    example: '2021-07-13 09:13:15.562609+00',
    description: 'plan from',
  })
  @IsDate()
  @IsNotEmpty()
  planFrom: Date;

  @ApiProperty({
    example: '2021-07-13 09:13:15.562609+00',
    description: 'plan to',
  })
  @IsDate()
  @IsNotEmpty()
  planTo: Date;

  @ApiProperty({ example: 400.2, description: 'quantity' })
  @IsNotEmpty()
  @IsNumber()
  quantity: number;

  @ApiProperty({ example: 'description', description: 'description' })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;
}
