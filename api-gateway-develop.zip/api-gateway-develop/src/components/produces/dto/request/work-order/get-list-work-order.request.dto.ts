import { PaginationQuery } from '@utils/pagination.query';

export class GetListWorkOrderRequestDto extends PaginationQuery {}
