import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsPositive,
} from 'class-validator';

class ScrapMaterial {
  @ApiProperty({
    description: 'ID',
  })
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty({
    description: 'Số lượng',
  })
  @IsNotEmpty()
  @IsNumber()
  @IsPositive()
  quantity: number;
}

export class SubmitWorkOrderScrapRequestDto {
  @ApiProperty({
    description: 'Khối lượng phế liệu',
  })
  @IsOptional()
  @IsNumber()
  @IsPositive()
  quantity: number;

  @ApiProperty({
    description: 'Nguyên vật liệu',
    isArray: true,
    type: ScrapMaterial,
  })
  @IsNotEmpty()
  @IsArray()
  scrapMaterials: ScrapMaterial[];
}
