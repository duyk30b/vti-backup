import {
  IsDateString,
  IsNotEmpty,
  IsNumber,
  IsPositive,
  IsString,
  MaxLength,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class SubmitWorkOrderProgressRequestDto {
  @ApiProperty({
    description: 'SL sản xuất',
  })
  @IsNotEmpty()
  @IsNumber()
  @IsPositive()
  quantity: number;

  @ApiProperty({
    description: 'SL sản xuất',
  })
  @IsNotEmpty()
  @IsString()
  @MaxLength(50)
  lotNumber: string;

  @ApiProperty({
    description: 'SL sửa lại',
  })
  @IsNotEmpty()
  @IsNumber()
  @IsPositive()
  repairQuantity: number;

  @ApiProperty({
    description: 'work center id',
  })
  @IsNotEmpty()
  @IsDateString()
  executionDay: Date;
}
