import { ApiProperty } from '@nestjs/swagger';
import {
  IsInt,
  IsNotEmpty,
  IsPositive,
  IsString,
  MaxLength,
  IsNumber,
  IsDateString,
} from 'class-validator';

export class ImportInTransitRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  workOrderId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  workCenterId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  note: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @IsPositive()
  quantity: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  importDate: Date;
}
