import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsDecimal, IsOptional } from 'class-validator';

export class UpdateQualityControlWorkOrderRequestDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsDecimal()
  passQuantity: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDecimal()
  rejectQuantity: number;
}
