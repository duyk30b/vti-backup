import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';

export class GetAlertWorkOrderQualityControlRequestDto {
  @Expose()
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  producingStepId: number;

  @Expose()
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  manufacturingOrderId: number;

  @Expose()
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  manufacturingOrderPlanId: number;
}
