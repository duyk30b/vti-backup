import { WorkOrderRequestAbstractDto } from '@components/produces/dto/request/work-order/work-order.request.abstract.dto';

export class UpdateWorkOrderRequestDto extends WorkOrderRequestAbstractDto {}
