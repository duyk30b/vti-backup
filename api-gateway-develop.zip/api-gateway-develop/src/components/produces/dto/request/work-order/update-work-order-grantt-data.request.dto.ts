import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsDateString } from 'class-validator';

export class UpdateWorkOrderGranttDataRequestDto {
  @IsNotEmpty()
  @IsNumber()
  @ApiProperty({ example: '25', description: 'id' })
  rId: number;

  @ApiProperty({ example: '2021-11-19 06:20', description: 'start date' })
  @IsNotEmpty()
  @IsDateString()
  startDate: Date;

  @ApiProperty({ example: '2021-11-19 06:20', description: 'end date' })
  @IsNotEmpty()
  @IsDateString()
  endDate: Date;
}
