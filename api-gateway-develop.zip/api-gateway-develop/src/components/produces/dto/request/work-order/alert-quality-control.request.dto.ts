import { ALERT_WORK_ORDER_QUALITY_CONTROL_ENUM } from '@constant/common';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import {
  IsEnum,
  IsInt,
  IsString,
  MaxLength,
  IsOptional,
  IsNotEmpty,
  IsDateString,
} from 'class-validator';

export class AlertWorkOrderQualityControlRequestDto {
  @Expose()
  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(ALERT_WORK_ORDER_QUALITY_CONTROL_ENUM)
  type: number;

  @Expose()
  @ApiProperty()
  @IsString()
  @MaxLength(255)
  @IsNotEmpty()
  message: string;

  @Expose()
  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  alertedAt: Date;

  @Expose()
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  producingStepId: number;

  @Expose()
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  manufacturingOrderId: number;

  @Expose()
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  manufacturingOrderPlanId: number;

  @Expose()
  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  itemId: number;

  @Expose()
  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  previousBomId: number;

  @Expose()
  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  previousProducingStepId: number;
}
