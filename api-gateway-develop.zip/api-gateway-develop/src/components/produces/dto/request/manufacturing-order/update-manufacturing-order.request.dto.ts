import { CreateManufacturingOrderByPlanRequestDto } from './create-manufacturing-order-by-plan.request.dto';
import { ManufacturingOrderRequestAbstractDto } from './manufacturing-order.request.abstract.dto';

export class UpdateManufacturingOrderRequestDto extends ManufacturingOrderRequestAbstractDto {}
export class UpdateManufacturingOrderByPlanRequestDto extends CreateManufacturingOrderByPlanRequestDto {}
