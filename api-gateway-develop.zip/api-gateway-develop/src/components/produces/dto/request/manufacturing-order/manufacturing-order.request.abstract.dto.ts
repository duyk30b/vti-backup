import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayUnique,
  IsArray,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';

export class ManufacturingOrderRequestAbstractDto {
  @ApiProperty({
    example: 'Lệnh SX bàn',
    description: 'Tên lệnh sản xuất',
  })
  @IsNotEmpty()
  @MaxLength(255)
  @IsString()
  name: string;

  @ApiProperty({ example: 'MO01', description: 'Mã code của lệnh sản xuất' })
  @MaxLength(12)
  @IsNotEmpty()
  @IsString()
  code: string;

  @ApiProperty({
    example: 1,
    description: 'Mã Id của nhà máy',
  })
  @IsNotEmpty()
  @IsInt()
  factoryId: number;

  @ApiProperty({
    example: 1,
    description: 'Mã Id của Đơn hàng',
  })
  @IsOptional()
  @IsInt()
  saleOrderId: number;

  @ApiProperty({
    example: '2021-08-19T17:48:15.314Z',
    description: 'ngày bắt đầu thực hiện lệnh sản xuất',
  })
  @IsNotEmpty()
  @IsDateString()
  planFrom: Date;

  @ApiProperty({
    example: '2021-09-21T17:48:15.314Z',
    description: 'ngày hoàn tất công trình',
  })
  @IsNotEmpty()
  @IsDateString()
  planTo: Date;

  @ApiPropertyOptional({
    example: 'Lệnh sản xuất bàn',
    description: 'Mô tả thông tin Lệnh sản xuất',
  })
  @MaxLength(255)
  @IsOptional()
  description: string;

  @ApiProperty({
    example: [
      { id: 1, quantity: 2 },
      { id: 2, quantity: 4 },
    ],
    description: 'Các item của lệnh sản xuất',
  })
  @ValidateNested()
  @ArrayUnique((e: ManufacturingOrderItemDto) => e.id)
  @IsArray()
  @Type(() => ManufacturingOrderItemDto)
  moItems: ManufacturingOrderItemDto[];
}

export class ManufacturingOrderItemDto {
  @ApiProperty({
    example: 1,
    description: 'Mã sản phẩm',
  })
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty({
    example: 1,
    description: 'Số lượng sản phẩm',
  })
  @IsNotEmpty()
  @IsInt()
  quantity: number;
}
