import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { Expose } from 'class-transformer';
import { IsEnum } from 'class-validator';

export class GetMoItemListRequestDto extends PaginationQuery {
  @ApiPropertyOptional({ description: '0 hoặc 1' })
  @Expose()
  @IsEnum(['0', '1'])
  onlyInProgressItem: string;
}
