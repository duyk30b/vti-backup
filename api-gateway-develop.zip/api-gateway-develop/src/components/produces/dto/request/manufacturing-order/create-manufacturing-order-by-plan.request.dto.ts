import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';

export class CreateManufacturingOrderByPlanRequestDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  masterPlanId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  saleOrderId: number;

  @ApiProperty()
  @IsString()
  @MaxLength(255)
  @IsNotEmpty()
  name: string;

  @ApiProperty({ example: 'MO01', description: 'Mã code của lệnh sản xuất' })
  @MaxLength(12)
  @IsNotEmpty()
  @IsString()
  code: string;

  @ApiPropertyOptional({
    example: 'Lệnh sản xuất bàn',
    description: 'Mô tả thông tin Lệnh sản xuất',
  })
  @MaxLength(255)
  @IsOptional()
  description: string;

  @ApiProperty({
    example: '2021-08-19T17:48:15.314Z',
    description: 'ngày bắt đầu thực hiện lệnh sản xuất',
  })
  @IsNotEmpty()
  @IsDateString()
  planFrom: Date;

  @ApiProperty({
    example: '2021-09-21T17:48:15.314Z',
    description: 'ngày hoàn tất công trình',
  })
  @IsNotEmpty()
  @IsDateString()
  planTo: Date;
}
