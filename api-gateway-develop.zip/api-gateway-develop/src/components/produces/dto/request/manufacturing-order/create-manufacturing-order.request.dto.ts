import { ApiProperty } from '@nestjs/swagger';
import { ManufacturingOrderRequestAbstractDto } from './manufacturing-order.request.abstract.dto';
import { IsInt, IsNotEmpty } from 'class-validator';

export class CreateManufacturingOrderRequestDto extends ManufacturingOrderRequestAbstractDto {}
export class CreateManufacturingOrderRequestDto2 extends ManufacturingOrderRequestAbstractDto {
  @ApiProperty({
    example: 1,
    description: 'Mã Id của Đơn hàng',
  })
  @IsNotEmpty()
  @IsInt()
  saleOrderId: number;
}
