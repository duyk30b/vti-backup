import { PaginationQuery } from '@utils/pagination.query';

export class GetListManufacturingOrderRequestDto extends PaginationQuery {}
