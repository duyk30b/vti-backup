import { Expose } from 'class-transformer';
import { IsNumber, IsOptional } from 'class-validator';

export class GetItemMoDetailRequestDto {
  @IsOptional()
  @IsNumber()
  planId: number;
}
