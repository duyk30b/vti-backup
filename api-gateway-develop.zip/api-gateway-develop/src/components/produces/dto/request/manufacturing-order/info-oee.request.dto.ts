import { ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class InfoOeeRequestDto {
  @ApiPropertyOptional({ example: '1,2,3' })
  @Expose()
  ids: string;
}
