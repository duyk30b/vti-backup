import { ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { IsEnum, IsOptional } from 'class-validator';

export class GetBoqItemListRequestDto {
  @ApiPropertyOptional({ description: '0 hoặc 1' })
  @Expose()
  @IsEnum(['0', '1'])
  onlyInProgressItem: string;
}
