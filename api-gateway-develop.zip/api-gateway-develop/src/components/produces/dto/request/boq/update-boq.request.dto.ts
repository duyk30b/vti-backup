import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
    ArrayUnique,
    IsArray,
    IsDateString,
    IsInt,
    IsNotEmpty,
    IsNumber,
    IsOptional,
    IsString,
    MaxLength,
    Min,
    ValidateNested,
} from 'class-validator';
import { BoqItemDto } from './create-boq.request.dto';

export class UpdateBoqRequestDto {
    @ApiProperty({ example: 'Công trình sản xuất bàn', description: 'Tên công trình' })
    @IsNotEmpty()
    @MaxLength(255)
    @IsString()
    name: string;

    @ApiProperty({
        example: 1,
        description: 'Mã Id của quản lý',
    })
    @IsNotEmpty()
    @IsInt()
    pmId: number;

    @ApiProperty({
        example: 1,
        description: 'Mã Id của APM',
    })
    @IsOptional()
    @IsInt()
    apmId: number;


    @ApiProperty({
        example: '2021-08-19T17:48:15.314Z',
        description: 'ngày bắt đầu thực hiện công trình'
    })
    @IsNotEmpty()
    @IsDateString()
    planFrom: Date;

    @ApiProperty({
        example: '2021-09-21T17:48:15.314Z',
        description: 'ngày hoàn tất công trình'
    })
    @IsNotEmpty()
    @IsDateString()
    planTo: Date;

    @ApiPropertyOptional({
        example: 'Dự án xuất bàn',
        description: 'Mô tả thông công trình',
    })
    @MaxLength(255)
    @IsOptional()
    description: string;

    @ApiProperty({
        example: [
            { itemId: 1, quantity: 2 },
            { itemId: 2, quantity: 4 },
        ],
        description: 'Các thành phẩm của công trình',
    })
    @ValidateNested()
    @ArrayUnique((e: BoqItemDto) => e.id)
    @IsArray()
    @Type(() => BoqItemDto)
    boqItems: BoqItemDto[];
}