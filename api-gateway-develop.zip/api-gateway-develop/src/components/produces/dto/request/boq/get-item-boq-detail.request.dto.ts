import { Expose } from 'class-transformer';
import { IsNumber, IsOptional } from 'class-validator';

export class GetItemBoqDetailRequestDto {
  @IsOptional()
  @IsNumber()
  planId: number;
}
