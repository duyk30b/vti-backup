import { ApiProperty } from "@nestjs/swagger";
import { IsInt, IsNotEmpty, IsString, MaxLength } from "class-validator";

export class CreateProducingStepDetailRequestDto {
  @ApiProperty({ example: 'Tên producing step detail', description: 'Tên producing step detail' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiProperty({ example: 'Mã Công Đoạn', description: 'Mã Công Đoạn' })
  @IsNotEmpty()
  @IsInt()
  producingStepId: number;

  @ApiProperty({ example: 1, description: 'Thứ tự' })
  @IsNotEmpty()
  @IsInt()
  number: number;

  @ApiProperty({ example: 1.22, description: 'Thời gian thực hiện' })
  @IsNotEmpty()
  @IsInt()
  duration: number;
}