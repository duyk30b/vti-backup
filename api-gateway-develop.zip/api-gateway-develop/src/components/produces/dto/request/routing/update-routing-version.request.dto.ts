import { CreateRoutingVersionRequestDto } from '@components/produces/dto/request/routing/create-routing-version.request.dto';

export class UpdateRoutingVersionRequestDto extends CreateRoutingVersionRequestDto {}
