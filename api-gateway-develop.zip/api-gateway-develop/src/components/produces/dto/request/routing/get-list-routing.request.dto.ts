import { PaginationQuery } from '@utils/pagination.query';
import { IsEnum, IsOptional } from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';

export class GetListRoutingRequestDto extends PaginationQuery {
  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll: string;
}
