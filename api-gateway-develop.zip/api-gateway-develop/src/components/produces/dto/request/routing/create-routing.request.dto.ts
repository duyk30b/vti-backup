import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString, MaxLength, IsOptional } from 'class-validator';

export class CreateRoutingRequestDto {
  @IsNotEmpty()
  @IsString()
  @MaxLength(4)
  @ApiProperty({ example: 'R001', description: 'code' })
  code: string;

  @ApiProperty({ example: 'routing 1', description: 'name' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiProperty({ example: 'description', description: 'description' })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;
}
