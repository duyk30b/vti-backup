import { CreateRoutingRequestDto } from '@components/produces/dto/request/routing/create-routing.request.dto';

export class UpdateRoutingRequestDto extends CreateRoutingRequestDto {}
