import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayUnique,
  IsArray,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';

export class ProducingStepWoDto {
  @ApiProperty()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsInt()
  @IsOptional()
  workOrderId: number;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  quantity: number;

  @ApiProperty()
  @IsDateString()
  planFrom: Date;

  @ApiProperty()
  @IsDateString()
  planTo: Date;
}
export class PlanBomDto {
  @ApiProperty()
  @IsInt()
  bomId: number;

  @IsInt()
  @ApiProperty()
  boqDetailId: number;

  @ApiProperty()
  @IsInt()
  routingVersionId: number;

  @ApiProperty()
  @IsNumber()
  quantity: number;

  @ApiProperty()
  @IsDateString()
  planFrom: Date;

  @ApiProperty()
  @IsDateString()
  planTo: Date;

  @ApiProperty({
    type: [ProducingStepWoDto],
  })
  @IsArray()
  producingSteps: ProducingStepWoDto[];
}

export class CreatePlanRequest {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @MaxLength(4)
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @IsNotEmpty()
  @ApiProperty()
  @IsInt()
  boqId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  planFrom: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  planTo: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  pmId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  apmId: number;

  @ApiProperty()
  @MaxLength(255)
  @IsString()
  description: string;

  @ApiProperty({
    type: [PlanBomDto],
  })
  @IsArray()
  @Type(() => PlanBomDto)
  @ArrayUnique((e: PlanBomDto) => `${e.bomId}_${e.routingVersionId}`)
  planBoms: PlanBomDto[];
}
