import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class ProductivityAssessmentReportRequestDto {
  @ApiProperty({
    example: 1,
    description: '',
  })
  @IsNotEmpty()
  @IsInt()
  manufacturingOrderId: number;

  @ApiProperty({
    example: 1,
    description: '',
  })
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty({
    example: 1,
    description: '',
  })
  @IsNotEmpty()
  @IsInt()
  producingStepId: number;
}
