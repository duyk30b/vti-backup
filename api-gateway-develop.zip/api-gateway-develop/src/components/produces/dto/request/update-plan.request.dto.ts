import { ApiProperty } from "@nestjs/swagger";
import { CreatePlanRequest } from "./create-plan.request.dto";

export class UpdatePlanRequest extends CreatePlanRequest {
  
  @ApiProperty({
    type: Number,
  })  
  id: number;

}