import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayUnique,
  IsArray,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  IsPositive,
  ValidateNested,
} from 'class-validator';

export class GetBomProducingStepRequestDto {

  @ApiProperty()
  @IsInt()
  @IsOptional()
  bomId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  @IsOptional()
  itemId: number;

}

