import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsArray, IsNotEmpty, IsNumber, IsOptional, ValidateNested } from 'class-validator';

export class BomItemDto {
    
    @ApiProperty()
    @IsNotEmpty()
    itemId: number;

    @ApiProperty()
    @IsNotEmpty()
    quantity: number;
}

export class GetBomStructRequestDto {

    @ApiProperty()
    @IsNumber()
    @IsOptional()
    id: number;

    @ApiProperty()
    @IsArray()
    @IsOptional()
    @ValidateNested()
    @Type(() => BomItemDto)
    items: BomItemDto[];
}
  