import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayUnique,
  IsArray,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  IsPositive,
  ValidateNested,
} from 'class-validator';

export class BomProducingStepDetailsDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  bomDetailId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  producingStepId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  quantity: number;
}

export class CreateBomProducingStepRequestDto {
  @ApiProperty()
  @IsInt()
  @IsOptional()
  bomId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty({ type: BomProducingStepDetailsDto })
  @IsNotEmpty()
  @Type(() => BomProducingStepDetailsDto)
  @IsArray()
  detail: BomProducingStepDetailsDto[];
}
