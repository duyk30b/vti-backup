import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { Type } from "class-transformer";
import { ArrayUnique, IsArray, IsInt, IsNotEmpty, IsNumber, IsOptional, IsString, MaxLength, Min, ValidateNested } from "class-validator";
import { BomItemDto } from "./create-bom.request.dto";

export class UpdateBomRequestDto {
    @ApiProperty({ example: 'Định mức A', description: 'Tên BOM' })
    @IsNotEmpty()
    @MaxLength(255)
    @IsString()
    name: string;

    @ApiPropertyOptional({
        example: 'Định mức nguyên vật liệu',
        description: 'Mô tả BOM',
    })
    @MaxLength(255)
    @IsOptional()
    description: string;

    @ApiProperty({
        example: 1,
        description: 'Mã Id của quản lý',
    })
    @IsInt()
    @IsOptional()
    parentId: number;

    @ApiProperty({
        example: 1,
        description: 'Mã Id của routing',
    })
    @IsNotEmpty()
    @IsInt()
    routingId: number;

    @ApiProperty({
        example: 1,
        description: 'Mã Id của item',
    })
    @IsNotEmpty()
    @IsInt()
    itemId: number;
    
    @ApiProperty({
        example: [
            { itemId: 1, quantity: 2 },
            { itemId: 2, quantity: 4 },
        ],
        description: 'các thành phần của BOM',
    })
    @ValidateNested()
    @ArrayUnique((e: BomItemDto) => e.id)
    @IsArray()
    @Type(() => BomItemDto)
    bomItems: BomItemDto[];
}