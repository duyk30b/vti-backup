import { PaginationQuery } from '@utils/pagination.query';

export class GetListMaterialRequestWarningRequestDto extends PaginationQuery {}
