import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';

export class MaterialRequestWarningRequestDto {
  @ApiProperty({
    example: 'Cảnh bảo yêu cầu nguyên vật liệu',
  })
  @IsNotEmpty()
  @MaxLength(255)
  @IsString()
  name: string;

  @ApiProperty({ example: 'MO01IMP' })
  @MaxLength(50)
  @IsNotEmpty()
  @IsString()
  code: string;

  @ApiProperty({
    example: 1,
    description: 'Mã Id của MO',
  })
  @IsNotEmpty()
  @IsInt()
  manufacturingOrderId: number;

  @ApiProperty({
    example: '2021-08-19T17:48:15.314Z',
  })
  @IsNotEmpty()
  @IsDateString()
  planFrom: Date;

  @ApiProperty({
    example: '2021-09-21T17:48:15.314Z',
  })
  @IsNotEmpty()
  @IsDateString()
  planTo: Date;

  @ApiPropertyOptional({
    example: 'Cảnh bảo yêu cầu nguyên vật liệu',
  })
  @MaxLength(255)
  @IsOptional()
  description: string;
}
