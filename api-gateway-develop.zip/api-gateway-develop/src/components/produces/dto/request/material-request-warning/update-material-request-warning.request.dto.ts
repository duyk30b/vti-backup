import { MaterialRequestWarningRequestDto } from './material-request-warning.request.dto';

export class UpdateMaterialRequestWarningRequestDto extends MaterialRequestWarningRequestDto {}
