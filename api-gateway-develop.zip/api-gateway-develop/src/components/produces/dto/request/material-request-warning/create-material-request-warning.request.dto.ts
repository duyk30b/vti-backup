import { MaterialRequestWarningRequestDto } from './material-request-warning.request.dto';

export class CreateMaterialRequestWarningRequestDto extends MaterialRequestWarningRequestDto {}
