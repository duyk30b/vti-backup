import { PaginationQuery } from '@utils/pagination.query';

export class GetListPlanRequest extends PaginationQuery {}
