import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsInt, IsNotEmpty, IsOptional } from 'class-validator';

export class ProductivityReportRequestDto {
  @ApiProperty({
    example: 1,
    description: '',
  })
  @IsNotEmpty()
  @IsInt()
  manufacturingOrderId: number;

  @ApiProperty({
    example: 1,
    description: '',
  })
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty({
    example: 1,
    description: '',
  })
  @IsNotEmpty()
  @IsInt()
  producingStepId: number;

  @ApiProperty({
    example: 1,
    description: '',
  })
  @IsNotEmpty()
  @IsInt()
  workCenterId: number;
}
