import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsNotEmpty } from 'class-validator';

export class GetDashboardMoStatusRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  createdFrom: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  createdTo: Date;
}
