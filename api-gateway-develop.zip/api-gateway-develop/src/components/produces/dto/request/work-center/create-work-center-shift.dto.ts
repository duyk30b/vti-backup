import { ApiProperty } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsString,
  MaxLength,
  IsInt,
  IsOptional,
  ArrayNotEmpty,
  IsArray,
  IsMilitaryTime,
  IsNumber,
} from 'class-validator';

export class WorkCenterShift {
  @ApiProperty({ example: 'ca 1', description: 'tên ca' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiProperty({ example: '06:00', description: 'thời gian bắt đầu ca' })
  @IsNotEmpty()
  @IsMilitaryTime()
  startAt: string;

  @ApiProperty({ example: '18:00', description: 'thời gian kết thúc ca' })
  @IsNotEmpty()
  @IsMilitaryTime()
  endAt: string;

  @ApiProperty({
    example: 200,
    description: 'đơn giá/giờ',
  })
  @IsOptional()
  @IsNumber()
  pricePerHour: number;

  @ApiProperty({
    example: 'VND',
    description: 'đơn vị',
  })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  priceUnit: string;

  @ApiProperty({
    example: [
      {
        name: 'nghỉ đầu ca',
        startAt: '06:00',
        endAt: '06:30',
      },
    ],
    description: 'thời gian nghỉ trong ca',
  })
  @IsOptional()
  @IsArray()
  relaxTimes: WorkCenterShiftRelaxTime[];
}

export class WorkCenterShiftRelaxTime {
  @ApiProperty({ example: 'ca 1', description: 'tên ca' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiProperty({
    example: '06:00',
    description: 'thời gian bắt đầu nghỉ đầu ca',
  })
  @IsNotEmpty()
  @IsMilitaryTime()
  startAt: string;

  @ApiProperty({
    example: '06:300',
    description: 'thời gian kết thúc nghỉ đầu ca',
  })
  @IsNotEmpty()
  @IsMilitaryTime()
  endAt: string;
}

export class CreateWorkCenterShiftRequestDto {
  @IsNotEmpty()
  @IsInt()
  @ApiProperty({ example: '1', description: 'work center id' })
  workCenterId: number;

  @ArrayNotEmpty()
  @ApiProperty({
    example: [
      {
        name: 'ca 1',
        startAt: '06:00',
        endAt: '18:00',
        pricePerHour: 200,
        priceUnit: 'VND',
      },
      {
        name: 'ca 2',
        startAt: '18:00',
        endAt: '01:00',
        pricePerHour: 400,
        priceUnit: 'VND',
      },
    ],
    description: 'các ca làm việc của xưởng',
  })
  workCenterShifts: WorkCenterShift[];
}
