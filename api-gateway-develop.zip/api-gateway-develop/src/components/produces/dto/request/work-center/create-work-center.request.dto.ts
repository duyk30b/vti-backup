import { WorkCenterRequestAbstractDto } from "./work-center.request.abstract.dto";

export class CreateWorkCenterRequestDto extends WorkCenterRequestAbstractDto {}