import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class WorkCenterScheduleShiftDetailDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  workCenterShiftId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @IsPositive()
  quantity: number;
}

export class WorkCenterScheduleDetailDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  executionDay: Date;

  @ApiProperty({
    description: 'Chi tiết ca làm việc',
    isArray: true,
    type: WorkCenterScheduleShiftDetailDto,
  })
  @Type(() => WorkCenterScheduleShiftDetailDto)
  @IsArray()
  @ArrayNotEmpty()
  @ValidateNested({ each: true })
  @ArrayUnique((e: WorkCenterScheduleShiftDetailDto) => e.workCenterShiftId)
  scheduleShiftDetails: WorkCenterScheduleShiftDetailDto[];
}

export class CreateWorkCenterScheduleRequestDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  workOrderId: number;

  @ApiProperty({
    description: 'Chi tiết lịch làm việc',
    isArray: true,
    type: WorkCenterScheduleDetailDto,
  })
  @Type(() => WorkCenterScheduleDetailDto)
  @IsArray()
  @ArrayNotEmpty()
  @ValidateNested({ each: true })
  @ArrayUnique((e: WorkCenterScheduleDetailDto) => e.executionDay)
  scheduleDetails: WorkCenterScheduleDetailDto[];

  @ApiProperty()
  @IsString()
  @IsOptional()
  @MaxLength(255)
  description: string;
}
