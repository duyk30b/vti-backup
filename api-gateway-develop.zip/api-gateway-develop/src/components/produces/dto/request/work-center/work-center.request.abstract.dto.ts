import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsNotEmpty,
  IsString,
  MaxLength,
  IsInt,
  IsOptional,
  ValidateNested,
  ArrayUnique,
  IsArray,
  ArrayNotEmpty,
} from 'class-validator';
import { WorkCenterShift } from './create-work-center-shift.dto';

export class Member {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;
}
export class WorkCenterRequestAbstractDto {
  @IsNotEmpty()
  @IsString()
  @MaxLength(20)
  @ApiProperty({ example: 'WC001', description: 'code' })
  code: string;

  @ApiProperty({ example: 'Xưởng lắp ráp', description: 'name' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiProperty({ example: 1, description: 'mã nhà máy' })
  @IsNotEmpty()
  @IsInt()
  factoryId: number;

  @ApiProperty({ example: 1, description: 'mã tổ trưởng' })
  @IsNotEmpty()
  @IsInt()
  leaderId: number;

  @ApiProperty({
    example: 'Xưởng lắp ráp sản phẩm',
    description: 'mô tả xưởng',
  })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;

  @ApiProperty({
    example: 100,
    description: 'Hiệu suất làm việc(%)',
  })
  @IsNotEmpty()
  performance: number;

  @ApiProperty({
    example: 100,
    description: 'Công suất làm việc',
  })
  @IsNotEmpty()
  @IsInt()
  workingCapacity: number;

  @ApiProperty({
    example: 90,
    description: 'Mục tiêu OEE(%)',
  })
  @IsNotEmpty()
  oeeTarget: number;

  @ApiProperty({
    example: 2000,
    description: 'Chi phí trên giờ',
  })
  @IsNotEmpty()
  @IsInt()
  cost: number;

  @ApiProperty({ example: 30, description: 'Thời gian trước sản xuất(phút)' })
  @IsNotEmpty()
  preProductionTime: number;

  @ApiProperty({ example: 30, description: 'Thời gian sau sản xuất(phút)' })
  @IsNotEmpty()
  postProductionTime: number;

  @ApiPropertyOptional({
    example: 'Chuẩn (40 giờ/tuần)',
    description: 'Giờ làm việc',
  })
  @IsOptional()
  @IsNotEmpty()
  workingHours: string;

  @ApiProperty({
    example: [{ id: 1 }, { id: 2 }],
    description: 'Các thành viên của xưởng',
  })
  @ValidateNested()
  @ArrayUnique((e: Member) => e.id)
  @IsArray()
  @ArrayNotEmpty()
  @Type(() => Member)
  members: Member[];

  @ApiProperty({
    example: 1,
    description: 'công đoạn sản xuất của xưởng',
  })
  @IsNotEmpty()
  @IsInt()
  producingStepId: number;

  @ArrayNotEmpty()
  @ValidateNested({ each: true })
  @Type(() => WorkCenterShift)
  @ApiProperty({
    example: [
      {
        name: 'ca 1',
        startAt: '06:00',
        endAt: '18:00',
        pricePerHour: 200,
        priceUnit: 'VND',
      },
      {
        name: 'ca 2',
        startAt: '18:00',
        endAt: '01:00',
        pricePerHour: 400,
        priceUnit: 'VND',
      },
    ],
    description: 'các ca làm việc của xưởng',
  })
  workCenterShifts: WorkCenterShift[];
}
