import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsBoolean,
  IsEnum,
  IsInt,
  IsJSON,
  IsNotEmpty,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  ValidateNested,
} from 'class-validator';

export class QcObject {
  @ApiProperty({ example: true, description: 'trạng thái' })
  @IsOptional()
  @IsBoolean()
  enable: boolean;

  @ApiProperty({ example: 1, description: 'qc id' })
  @IsOptional()
  @IsInt()
  qcCriteriaId: number;

  @ApiProperty({ example: 1, description: 'item_per_member_time' })
  @IsOptional()
  @IsInt()
  itemPerMemberTime: number;
}

export class CreateProducingStepRequestDto {
  @ApiProperty({ example: 'ABC', description: 'Ten cua producing-step' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiProperty({ example: '1234', description: 'Code' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(4)
  code: string;

  @ApiPropertyOptional({
    example: 'Mo ta ve producing step',
    description: 'Description',
  })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;

  @ApiProperty({ example: '1', description: '0: In-active, 1: active' })
  @IsNotEmpty()
  @IsEnum(['0', '1'])
  status: string;

  @ApiPropertyOptional({
    example: '0',
    description:
      '0: Tất cả sp phải hoàn thành mới đc chuyển, 1; được phép chuyển',
  })
  @IsOptional()
  @IsEnum(['0', '1'])
  switchMode: string;

  @ApiPropertyOptional({
    example: '0',
    description: '% sản phẩm QC check : default 0%',
  })
  @IsOptional()
  @IsInt()
  @Max(100)
  qcQuantityRule: number;

  @ApiProperty({ example: '0', description: 'Trạng thái QC' })
  @IsString()
  @IsEnum(['0', '1'])
  qcCheck: string;

  @ApiPropertyOptional({ example: 1, description: 'workCenterid' })
  @IsOptional()
  @IsInt()
  workCenterId: number;

  @ApiPropertyOptional({ example: 1, description: 'qcCriteriaId' })
  @IsInt()
  @IsOptional()
  qcCriteriaId: number;

  @ApiPropertyOptional({ example: 1, description: 'productionTimePerItem' })
  @IsOptional()
  @IsInt()
  productionTimePerItem: number;

  @ApiPropertyOptional({ example: { enable: true, qcCriteriaId: 1, itemPerMemberTime: '1,22' }, description: 'Input QC' })
  @IsOptional()
  @ValidateNested()
  @Type(() => QcObject)
  inputQc: QcObject

  @ApiPropertyOptional({ example: { enable: true, qcCriteriaId: 1, itemPerMemberTime: '1,22' }, description: 'outputQc' })
  @IsOptional()
  @ValidateNested()
  @Type(() => QcObject)
  outputQc: QcObject
}
