import { CreateProducingStepRequestDto } from '@components/produces/dto/request/produce-step/create-producing-step.request.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber } from 'class-validator';

export class UpdateProducingStepRequestDto extends CreateProducingStepRequestDto {
  @ApiProperty({ example: '5', description: 'ID' })
  @IsNotEmpty()
  @IsNumber()
  id: number;
}
