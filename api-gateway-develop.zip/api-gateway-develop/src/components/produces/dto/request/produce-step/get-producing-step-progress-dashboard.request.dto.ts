import { IsOptional } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class GetProducingStepProgressDashboardRequestDto {
  @ApiProperty()
  @IsOptional()
  manufacturingOrderId: string;

  @ApiPropertyOptional()
  @IsOptional()
  itemId: string;

  @ApiPropertyOptional()
  @IsOptional()
  producingStepId: string;

  @ApiPropertyOptional()
  @IsOptional()
  workCenterId: string;
}
