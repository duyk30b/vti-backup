import { ApiProperty } from '@nestjs/swagger';
import {
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  MaxLength,
} from 'class-validator';

export class CreateQcRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  workOrderId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  lotNumberId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @IsPositive()
  passQuantity: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @IsPositive()
  rejectQuantity: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @MaxLength(255)
  note: string;
}
export class CreateQcAlertRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  workOrderId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  message: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  alertAt: Date;
}

export class CreateMaterialInputQcRequestDto extends CreateQcRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @MaxLength(255)
  note: string;
}
export class CreatePreviousBomQcRequestDto extends CreateQcRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @MaxLength(255)
  note: string;
}
