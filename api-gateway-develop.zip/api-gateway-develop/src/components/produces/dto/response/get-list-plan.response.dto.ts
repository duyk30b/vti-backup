import { ResponseCodeEnum } from "@constant/response-code.enum";
import { ApiProperty } from "@nestjs/swagger";
import { PagingResponse } from "@utils/paging.response";
import { ResponsePayload } from "@utils/response-payload";

export class ListPlanResponse extends PagingResponse{
  items: PlanDto[]
}

export class PlanDto {

  @ApiProperty()
  id: number;
  
  @ApiProperty()
  code: string;
  
  @ApiProperty()
  name: string;
  
  @ApiProperty()
  planFrom: Date;
  
  @ApiProperty()
  planTo: Date;
  
  @ApiProperty()
  version: string;
  
  @ApiProperty()
  description: string;
  
  @ApiProperty()
  boqId: number;
  
  @ApiProperty()
  boqName: string;
  
  @ApiProperty()
  pmId: number;
  
  @ApiProperty()
  pmName: string;
  
  @ApiProperty()
  apmName: string;
}

export class GetListPlanResponse implements ResponsePayload<ListPlanResponse> {
  
  statusCode: ResponseCodeEnum;
  
  @ApiProperty({
    type: String
  })
  message?: string;

  @ApiProperty({
    type: ListPlanResponse
  })
  data?: ListPlanResponse;
}