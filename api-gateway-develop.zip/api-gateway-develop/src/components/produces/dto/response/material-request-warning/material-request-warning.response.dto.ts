import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class SaleOrder {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'Đơn hàng 300 cái bàn', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'SO001', description: '' })
  @Expose()
  code: string;
}

class ManufacturingOrder {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'Lệnh sản xuất 300 cái bàn', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'MO001', description: '' })
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  planFrom: Date;

  @ApiProperty()
  @Expose()
  planTo: Date;
}

class Factory {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'nhà máy A', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'F001', description: '' })
  @Expose()
  code: string;
}

class ItemDetailMaterialRequestWarning {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'gỗ', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'MO001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 100, description: '' })
  @Expose()
  quantity: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  itemTypeId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  itemUnitId: number;
}

export class MaterialRequestWarningResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  planFrom: Date;

  @ApiProperty()
  @Expose()
  planTo: Date;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: ManufacturingOrder })
  @Expose()
  @Type(() => ManufacturingOrder)
  manufacturingOrder: ManufacturingOrder;

  @ApiProperty({ type: SaleOrder })
  @Expose()
  @Type(() => SaleOrder)
  saleOrder: SaleOrder;

  @ApiProperty({ type: Factory })
  @Expose()
  @Type(() => Factory)
  factory: Factory;

  @ApiProperty({ type: ItemDetailMaterialRequestWarning, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => ItemDetailMaterialRequestWarning)
  itemDetails: ItemDetailMaterialRequestWarning[];
}

export class MaterialRequestWarningResponseDto extends SuccessResponse {
  @ApiProperty({ type: MaterialRequestWarningResponse })
  @Expose()
  @Type(() => MaterialRequestWarningResponse)
  data: MaterialRequestWarningResponse;
}
