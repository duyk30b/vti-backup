import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { MaterialRequestWarningResponse } from './material-request-warning.response.dto';

class MetaMaterialRequestWarning {
  @ApiProperty({ example: 1 })
  @Expose()
  total: number;

  @ApiProperty({ example: 1 })
  @Expose()
  page: number;
}
export class MaterialRequestWarning {
  @ApiProperty({ type: MaterialRequestWarningResponse, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => MaterialRequestWarningResponse)
  items: MaterialRequestWarningResponse[];

  @ApiProperty({ type: MetaMaterialRequestWarning })
  @Expose()
  @Type(() => MetaMaterialRequestWarning)
  meta: MetaMaterialRequestWarning;
}

export class GetListMaterialRequestWarningResponseDto extends SuccessResponse {
  @ApiProperty({ type: MaterialRequestWarning })
  @Expose()
  @Type(() => MaterialRequestWarning)
  data: MaterialRequestWarning;
}
