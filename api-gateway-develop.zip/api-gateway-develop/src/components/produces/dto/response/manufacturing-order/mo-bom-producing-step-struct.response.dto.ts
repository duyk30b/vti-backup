import { ItemResponseDto } from "@components/item/dto/response/item.response.dto";
import { ApiProperty } from "@nestjs/swagger";
import { SuccessResponse } from "@utils/success.response.dto";
import { Expose, Type } from "class-transformer";
import { BomResponseDto } from "../bom/bom.response.dto";
import { ProducingStepDto } from "../detail-plan.response";

export class ProducingStep { 
  
  @ApiProperty()
  @Expose()
  producingStep: ProducingStepDto;

  @ApiProperty()
  @Expose()
  multiler: number;
  
  @ApiProperty()
  @Expose()
  remainningQuantity: number;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  planningQuantity: number;

  @ApiProperty()
  @Expose()
  producedQuantity: number;

  @ApiProperty()
  @Expose()
  scapQuantity: number;

  @ApiProperty()
  @Expose()
  inputQuantity: number;

}

export class BomItem {

  @ApiProperty()
  @Expose()
  item: ItemResponseDto;

  @ApiProperty()
  @Expose()
  bom: BomResponseDto;
  
  @ApiProperty()
  @Expose()
  multiler: number;

  @ApiProperty()
  @Expose()
  remainningQuantity: number;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  planningQuantity: number;

  @ApiProperty()
  @Expose()
  producedQuantity: number;
  
  @ApiProperty()
  @Expose()
  scapQuantity: number;

  @ApiProperty()
  @Expose()
  inputQuantity: number;

  @ApiProperty()
  @Expose()
  producingSteps: ProducingStep[];

  @ApiProperty()
  @Expose()
  childs: BomItem[]

}

export class MoBomProducingStepStructResponse extends SuccessResponse {
     
  data: BomItem[]

}