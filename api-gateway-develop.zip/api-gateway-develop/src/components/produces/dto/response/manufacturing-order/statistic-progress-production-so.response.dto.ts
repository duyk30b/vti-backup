import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class SaleOrderEntity {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  orderedAt: string;

  @ApiProperty()
  @Expose()
  deadline: string;

  @ApiProperty()
  @Expose()
  isHasPlan: string;
}

class MasterPlan {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  dateFrom: string;

  @ApiProperty()
  @Expose()
  dateTo: string;

  @ApiProperty()
  @Expose()
  status: number;
}

export class StatisticProgressProductionSoResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  planFrom: string;

  @ApiProperty()
  @Expose()
  planTo: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Type(() => SaleOrderEntity)
  @Expose()
  saleOrder: SaleOrderEntity;

  @ApiProperty()
  @Type(() => MasterPlan)
  @Expose()
  masterPlan: MasterPlan;
}
