import { ApiProperty } from "@nestjs/swagger";
import { PagingResponse } from "@utils/paging.response";
import { SuccessResponse } from "@utils/success.response.dto";
import { Expose, Type } from "class-transformer";
import { IsArray } from "class-validator";
import { PriceReportAbstractDto } from "./price-report.abstract.dto";

export class PriceReportData extends PagingResponse {
  @ApiProperty({ type: PriceReportAbstractDto, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => PriceReportAbstractDto)
  items: PriceReportAbstractDto[];
}

export class GetListPriceReportResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: PriceReportData;
}
