import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class MoItem {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}

class WorkOrderResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;
}

class ProducingStepResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty({ type: WorkOrderResponseDto, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => WorkOrderResponseDto)
  workOrders: WorkOrderResponseDto[];
}

export class MoItemResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty({ type: MoItem })
  @Type(() => MoItem)
  @Expose()
  item: MoItem;

  @ApiProperty({ type: ProducingStepResponseDto, isArray: true })
  @Type(() => ProducingStepResponseDto)
  @Expose()
  producingSteps: ProducingStepResponseDto;
}

export class MoPlanItemResponseDto {
  @ApiProperty()
  @Expose()
  planId: number;

  @ApiProperty()
  @Expose()
  planCode: number;

  @ApiProperty({ type: MoItemResponseDto, isArray: true })
  @Type(() => MoItemResponseDto)
  @Expose()
  moPlanBoms: MoItemResponseDto;
}

export class GetMoPlanItemListResponseDto extends SuccessResponse {
  @ApiProperty({ type: MoPlanItemResponseDto, isArray: true })
  @Type(() => MoPlanItemResponseDto)
  @Expose()
  data: MoPlanItemResponseDto;
}
