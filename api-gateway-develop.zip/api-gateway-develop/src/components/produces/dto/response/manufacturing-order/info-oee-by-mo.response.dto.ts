import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

class InfoOeeByMo {
  @ApiProperty()
  @Expose()
  totalPlanExecutionTime: number;

  @ApiProperty()
  @Expose()
  totalActualExecutionTime: number;

  @ApiProperty()
  @Expose()
  totalActualQuantity: number;

  @ApiProperty()
  @Expose()
  totalQcPassQuantity: number;

  @ApiProperty()
  @Expose()
  productivityRatio: number;
}

export class InfoOeeByMoResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: InfoOeeByMo;
}
