import { SuccessResponse } from '../../../../warehouse/dto/inventory/response/success.response';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class MoItem {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}
class WorkOrderResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;
}

class ProducingStepResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty({ type: WorkOrderResponseDto, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => WorkOrderResponseDto)
  workOrders: WorkOrderResponseDto[];
}

export class MoItemDetailResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  bomId: number;

  @ApiProperty()
  @Expose()
  isParent: boolean;

  @ApiProperty({ type: MoItem })
  @Type(() => MoItem)
  @Expose()
  item: MoItem;

  @ApiProperty({ type: ProducingStepResponseDto, isArray: true })
  @Type(() => ProducingStepResponseDto)
  @Expose()
  producingSteps: ProducingStepResponseDto;
}

export class GetMoItemDetailResponseDto extends SuccessResponse {
  @ApiProperty({ type: MoItemDetailResponseDto, isArray: true })
  @Type(() => MoItemDetailResponseDto)
  @Expose()
  data: MoItemDetailResponseDto;
}
