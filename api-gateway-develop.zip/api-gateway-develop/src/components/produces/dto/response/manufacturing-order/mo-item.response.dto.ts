import { SuccessResponse } from '../../../../warehouse/dto/inventory/response/success.response';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { MoItemResponseDto } from './mo-plan-item.response.dto';

class MoItem {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}

class WorkOrderResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;
}

class ProducingStepResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty({ type: WorkOrderResponseDto, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => WorkOrderResponseDto)
  workOrders: WorkOrderResponseDto[];
}

export class BoqItemResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty({ type: MoItem })
  @Type(() => MoItem)
  @Expose()
  item: MoItem;

  @ApiProperty({ type: ProducingStepResponseDto, isArray: true })
  @Type(() => ProducingStepResponseDto)
  @Expose()
  producingSteps: ProducingStepResponseDto;
}

export class GetMoItemListResponseDto extends SuccessResponse {
  @ApiProperty({ type: MoItemResponseDto, isArray: true })
  @Type(() => MoItemResponseDto)
  @Expose()
  data: MoItemResponseDto;
}
