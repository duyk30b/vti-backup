import { ApiProperty } from '@nestjs/swagger';
import { PagingResponse } from '@utils/paging.response';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { ManufacturingOrderResponseAbstractDto } from './manufacturing-order.response.abstract.dto';

export class ManufacturingOrderListData extends PagingResponse {
  @ApiProperty({ type: ManufacturingOrderResponseAbstractDto, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => ManufacturingOrderResponseAbstractDto)
  items: ManufacturingOrderResponseAbstractDto[];
}

export class GetListManufacturingOrderResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: ManufacturingOrderListData;
}
