import { ManufacturingOrderStatus } from '@components/produces/constant/manufacturing-order.constant';
import { FactoryResponseDto } from '@components/user/dto/factory/response/factory.response.dto';
import { UserResponseDto } from '@components/user/dto/user/response/user.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';
import { IsArray, IsEnum, IsNotEmpty } from 'class-validator';
import { ManufacturingOrderItemDto } from '../../request/manufacturing-order/manufacturing-order.request.abstract.dto';

class SaleOrderResponseDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'Đơn hàng gỗ', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'SO001', description: '' })
  @Expose()
  code: string;
}
class MasterPlanResponseDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'Đơn hàng gỗ', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'SO001', description: '' })
  @Expose()
  code: string;
}

export class ManufacturingOrderResponseAbstractDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  factoryId: number;

  @ApiProperty()
  @Expose()
  saleOrderId: number;

  @ApiProperty()
  @Expose()
  planFrom: Date;

  @ApiProperty()
  @Expose()
  planTo: Date;

  @IsEnum(ManufacturingOrderStatus)
  @Transform((data) => Number(data.value))
  @IsNotEmpty()
  @ApiProperty({
    description:
      '0 là chờ xác nhận, 1 là đã xác nhận, 2 là từ chối,3 là đang thực hiện,4 là đã hoàn thành',
  })
  status: ManufacturingOrderStatus;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty()
  @Expose()
  approvedAt: Date;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  createdByUser: UserResponseDto;

  @ApiProperty({ type: FactoryResponseDto })
  @Expose()
  @Type(() => FactoryResponseDto)
  factory: FactoryResponseDto;

  @ApiProperty({ type: MasterPlanResponseDto })
  @Expose()
  @Type(() => MasterPlanResponseDto)
  masterPlan: MasterPlanResponseDto;

  @ApiProperty({ type: SaleOrderResponseDto })
  @Expose()
  @Type(() => SaleOrderResponseDto)
  saleOrder: SaleOrderResponseDto;

  @ApiProperty({ type: ManufacturingOrderItemDto, isArray: true })
  @Expose()
  @Type(() => ManufacturingOrderItemDto)
  @IsArray()
  moItems: ManufacturingOrderItemDto[];
}
