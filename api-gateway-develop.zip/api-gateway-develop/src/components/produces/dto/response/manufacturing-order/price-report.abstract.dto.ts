import { ApiProperty } from "@nestjs/swagger";
import { Expose, Type } from "class-transformer";

class MoItem {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}

export class PriceReportAbstractDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty({ type: MoItem })
  @Type(() => MoItem)
  @Expose()
  item: MoItem;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  productionQuantity: number;

  @ApiProperty()
  @Expose()
  itemUnitId: number;

  @ApiProperty()
  @Expose()
  priceExpectProduction: number;

  @ApiProperty()
  @Expose()
  priceActualProduction: number;

  @ApiProperty()
  @Expose()
  priceExpectMaterial: number;

  @ApiProperty()
  @Expose()
  priceActualMaterial: number;
}