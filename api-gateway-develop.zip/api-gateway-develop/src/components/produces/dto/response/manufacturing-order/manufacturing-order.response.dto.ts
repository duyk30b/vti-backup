import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';
import { ManufacturingOrderResponseAbstractDto } from './manufacturing-order.response.abstract.dto';

export class ManufacturingOrderResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: ManufacturingOrderResponseAbstractDto;
}
