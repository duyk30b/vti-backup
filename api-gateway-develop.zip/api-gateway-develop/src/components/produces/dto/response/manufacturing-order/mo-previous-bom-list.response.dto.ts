import { BasicResponseDto } from '@core/dto/response/basic.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { PagingResponse } from '@utils/paging.response';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

export class MoPreviousBomListDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  inputQuantity: number;

  @ApiProperty()
  @Expose()
  qcPassQuantity: number;

  @ApiProperty()
  @Expose()
  qcRejectQuantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  manufacturingOrder: BasicResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  producingStep: BasicResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  routing: BasicResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  item: BasicResponseDto;
}

export class MoPreviousBomListResponseData extends PagingResponse {
  @ApiProperty({ type: MoPreviousBomListDto, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => MoPreviousBomListDto)
  items: MoPreviousBomListDto[];
}

export class MoPreviousBomListResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: MoPreviousBomListResponseData;
}
