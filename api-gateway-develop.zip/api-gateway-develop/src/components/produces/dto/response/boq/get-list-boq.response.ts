import { IsArray, IsEnum, IsNotEmpty } from 'class-validator';
import { PagingResponse } from '../../../../../utils/paging.response';
import { Expose, Transform, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { UserResponseDto } from '@components/user/dto/user/response/user.response.dto';
import { BoqStatus } from '@components/produces/constant/boq.constant';

class Boq {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  pmId: number;

  @ApiProperty()
  @Expose()
  apmId: number;

  @ApiProperty()
  @Expose()
  planFrom: Date;

  @ApiProperty()
  @Expose()
  planTo: Date;

  @IsEnum(BoqStatus)
  @Transform((data) => Number(data.value))
  @IsNotEmpty()
  @ApiProperty({
    description:
      '0 là chờ xác nhận, 1 là đã xác nhận, 2 là từ chối,3 là đang thực hiện,4 là đã hoàn thành',
  })
  status: BoqStatus;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty()
  @Expose()
  approvedAt: Date;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  createdByUser: UserResponseDto;
}

export class DataList extends PagingResponse {
  @ApiProperty({ type: Boq, isArray: true })
  @Type(() => Boq)
  @Expose()
  @IsArray()
  items: Boq[];
}

export class GetListBoqResponseDto {
  @ApiProperty({ example: 200, description: '' })
  @Expose()
  statusCode: number;

  @ApiProperty({ example: 'Success', description: '' })
  @Expose()
  message: string;

  @ApiProperty({
    type: DataList,
  })
  @Expose()
  @Type(() => DataList)
  data: DataList;
}
