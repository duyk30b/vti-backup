import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Transform, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { UserResponseDto } from '@components/user/dto/user/response/user.response.dto';
import { BoqItemDto } from '../../request/boq/create-boq.request.dto';
import { IsArray, IsEnum, IsNotEmpty } from 'class-validator';
import { BoqStatus } from '@components/produces/constant/boq.constant';

export class BoqResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  pmId: number;

  @ApiProperty()
  @Expose()
  apmId: number;

  @ApiProperty()
  @Expose()
  planFrom: Date;

  @ApiProperty()
  @Expose()
  planTo: Date;

  @IsEnum(BoqStatus)
  @Transform((data) => Number(data.value))
  @IsNotEmpty()
  @ApiProperty({
    description:
      '0 là chờ xác nhận, 1 là đã xác nhận, 2 là từ chối,3 là đang thực hiện,4 là đã hoàn thành',
  })
  status: BoqStatus;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty()
  @Expose()
  approvedAt: Date;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  createdByUser: UserResponseDto;

  @ApiProperty({ type: BoqItemDto, isArray: true })
  @Expose()
  @Type(() => BoqItemDto)
  @IsArray()
  boqItems: BoqItemDto[];
}

export class BoqResponseDto extends SuccessResponse {
  @ApiProperty({ type: BoqResponse })
  @Expose()
  data: BoqResponse;
}
