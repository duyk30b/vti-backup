import { ResponseCodeEnum } from "@constant/response-code.enum";
import { ApiProperty } from "@nestjs/swagger";
import { ResponsePayload } from "@utils/response-payload";
import { BomDto, ItemDto, PlansBom } from "./detail-plan.response";


export class ProducingStepDataDto {
  
  @ApiProperty()
  id: number;
  
  @ApiProperty()
  code: string;
  
  @ApiProperty()
  name: string;

  @ApiProperty()
  stepNumber: number;
}

export class RoutingVersionDataDto {
  
  @ApiProperty()
  id: number;

  @ApiProperty()
  name: string;
  
  @ApiProperty({
    type: [ProducingStepDataDto] 
  })
  producingSteps: ProducingStepDataDto[];
}
export class RoutingDataDto {
  
  @ApiProperty()
  id: number;
  
  @ApiProperty()
  code: string;
 
  @ApiProperty()
  name: string;
  
  @ApiProperty({
    type: [RoutingVersionDataDto] 
  })
  routingVersions: RoutingVersionDataDto[];
}

export class BomDetailDto {

  @ApiProperty()
  boqDetailId: number;

  @ApiProperty({
    type: ()=>ItemDto
  })
  item: ItemDto;
  
  @ApiProperty({
    type: ()=>BomDto
  })
  bom: BomDto;

  @ApiProperty()
  quantity: number;

  @ApiProperty()
  planingQuantity: number;
  
  @ApiProperty({
    type: ()=>PlansBom
  })
  planBom: PlansBom;

  @ApiProperty({
    type: RoutingDataDto
  })
  routing: RoutingDataDto;

  @ApiProperty({
    type: ()=>BomDetailDto
  })
  subBom: BomDetailDto[];
}

export class DetailBomPlanResponse implements ResponsePayload<BomDetailDto[]> {

  @ApiProperty({
    enum: ResponseCodeEnum,
  })
  statusCode: ResponseCodeEnum;

  @ApiProperty({
    type: String,
  })
  message?: string;

  @ApiProperty({
    type: [BomDetailDto],
  })
  data?: BomDetailDto[];
}