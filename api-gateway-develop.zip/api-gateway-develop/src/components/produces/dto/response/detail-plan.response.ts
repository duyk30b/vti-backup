import { WorkOrderStatus } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ApiProperty } from '@nestjs/swagger';
import { ResponsePayload } from '@utils/response-payload';
import { BomDetailDto } from './detail-bom-plan.response';

export class BoqDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  code: string;

  @ApiProperty()
  name: string;
}

export class BomDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  code: string;

  @ApiProperty()
  name: string;
}

export class WorkCenterDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  code: string;

  @ApiProperty()
  name: string;
}

export class ItemDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  code: string;

  @ApiProperty()
  name: string;

  @ApiProperty()
  unit: string;
}

export class RoutingVersionDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  name: string;
}

export class RoutingDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  code: string;

  @ApiProperty()
  name: string;

  @ApiProperty({
    type: RoutingVersionDto,
  })
  version: RoutingVersionDto;
}
export class ProducingStepDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  code: string;

  @ApiProperty()
  name: string;

  @ApiProperty()
  stepNumber: number;
}

export class PlanProducingStep {

  @ApiProperty({
    type: ProducingStepDto
  })
  producingStep: ProducingStepDto;

  @ApiProperty()
  planQuantity: number;

  @ApiProperty()
  actualQuantity: number;

  @ApiProperty()
  planDate: Date;

  @ApiProperty()
  executeDate: Date;

  @ApiProperty()
  endDate: Date;

  @ApiProperty()
  numberPlan: number;

  @ApiProperty()
  status: WorkOrderStatus;

  @ApiProperty()
  workOrderId: number;
}

export class PlansBom {
  
  @ApiProperty()
  boqPlanId: number;

  @ApiProperty()
  boqDetailId: number;
  
  bomId: number;

  itemId: number;

  routingVersionId: number;

  @ApiProperty({
    type: RoutingDto,
  })
  routing: RoutingDto;

  @ApiProperty()
  quantity: number;

  @ApiProperty()
  confirmedQuantity: number;

  @ApiProperty()
  actualQuantity: number;

  @ApiProperty()
  planDate: Date;

  @ApiProperty()
  executeDate: Date;

  @ApiProperty()
  endDate: Date;

  @ApiProperty({
    enum: WorkOrderStatus
  })
  status: WorkOrderStatus;

  @ApiProperty({
    type: [PlanProducingStep],
  })
  producingStep: PlanProducingStep[];

}

export class DetailPlanDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  code: string;

  @ApiProperty()
  name: string;

  @ApiProperty({
    type: BoqDto,
  })
  boq: BoqDto;

  @ApiProperty()
  planFrom: Date;

  @ApiProperty()
  planTo: Date;

  @ApiProperty()
  pmId: number;

  @ApiProperty()
  apmId: number;

  @ApiProperty()
  pmName: string;

  @ApiProperty()
  apmName: string;

  @ApiProperty()
  description: string;

  @ApiProperty({
    type: [BomDetailDto],
  })
  planBoms: BomDetailDto[];
}

export class DetailPlanResponse implements ResponsePayload<DetailPlanDto> {
  statusCode: ResponseCodeEnum;

  @ApiProperty({
    type: String,
  })
  message?: string;

  @ApiProperty({
    type: DetailPlanDto,
  })
  data?: DetailPlanDto;
}
