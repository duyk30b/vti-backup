import { IsArray, IsEnum, IsNotEmpty } from 'class-validator';
import { PagingResponse } from '../../../../../utils/paging.response';
import { Expose, Transform, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { ItemResponseDto } from '@components/item/dto/response/item.response.dto';
import { RoutingResponseDto } from '../routing/routing.response.dto';
import { BomStatus } from '@components/produces/constant/bom.constant';


class Bom {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  parentId: number;

  @IsEnum(BomStatus)
  @Transform((data) => Number(data.value))
  @IsNotEmpty()
  @ApiProperty({ description: '0 là chờ xác nhận, 1 là đã xác nhận, 2 là từ chối,3 là đang thực hiện,4 là đã hoàn thành' })
  status: BomStatus;

  @ApiProperty()
  @Expose()
  description: string;

  //update when have defined routing API
  @ApiProperty({type: RoutingResponseDto})
  @Expose()
  @Type(() => RoutingResponseDto)
  routing: RoutingResponseDto;  

  @ApiProperty({type: ItemResponseDto})
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;  
}

export class BomDataList extends PagingResponse {
  @ApiProperty({ type: Bom, isArray: true })
  @Type(() => Bom)
  @Expose()
  @IsArray()
  items: Bom[];
}

export class GetListBomResponseDto {
  @ApiProperty({ example: 200, description: '' })
  @Expose()
  statusCode: number;

  @ApiProperty({ example: 'Success', description: '' })
  @Expose()
  message: string;

  @ApiProperty({
    type: BomDataList,
  })
  @Expose()
  @Type(() => BomDataList)
  data: BomDataList;
}