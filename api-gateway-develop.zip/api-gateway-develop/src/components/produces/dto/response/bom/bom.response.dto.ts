import { ItemResponseDto } from '@components/item/dto/response/item.response.dto';
import { BomStatus } from '@components/produces/constant/bom.constant';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';
import { IsArray, IsEnum, IsNotEmpty } from 'class-validator';
import { BomItemDto } from '../../request/bom/create-bom.request.dto';
import { RoutingResponseDto } from '../routing/routing.response.dto';

export class BomResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  parentId: number;

  @IsEnum(BomStatus)
  @Transform((data) => Number(data.value))
  @IsNotEmpty()
  @ApiProperty({
    description:
      '0 là chờ xác nhận, 1 là đã xác nhận, 2 là từ chối,3 là đang thực hiện,4 là đã hoàn thành',
  })
  status: BomStatus;

  @ApiProperty()
  @Expose()
  description: string;

  //update when have defined routing API
  @ApiProperty({ type: RoutingResponseDto })
  @Expose()
  @Type(() => RoutingResponseDto)
  routing: RoutingResponseDto;

  @ApiProperty({ type: ItemResponseDto })
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty({ type: BomItemDto, isArray: true })
  @Expose()
  @Type(() => BomItemDto)
  @IsArray()
  bomItems: BomItemDto[];
}
