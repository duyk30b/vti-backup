import { ItemResponseDto } from '@components/item/dto/response/item.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { ProducingStepsSuccessResponseDto } from '../produce-step/producing-step-success.response.dto';

export class BomDetailDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  itemName: number;

  @ApiProperty()
  @Expose()
  itemCode: string;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  quantity: number;

  @ApiProperty({ type: ItemResponseDto })
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;
}

export class ProducingStepData { 
  producingStep: ProducingStepsSuccessResponseDto;
  quantity: number;
  status: number;
}

export class BomMaterialDetail {

  @ApiProperty({ type: BomDetailDto })
  @Type(() => BomDetailDto)
  @Expose()
  bomDetail: BomDetailDto;

  @ApiProperty({ type: ProducingStepData })
  @Type(() => ProducingStepData)
  @Expose()
  producingStepData: ProducingStepData[];
}

export class BomProducingStepStructResponseDto {
  @ApiProperty({ type: BomMaterialDetail })
  @Type(() => BomMaterialDetail)
  @Expose()
  materialDetails: BomMaterialDetail[];
}
