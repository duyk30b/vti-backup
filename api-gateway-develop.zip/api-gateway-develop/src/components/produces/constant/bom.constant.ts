export enum BomStatus {
    PENDING = 0,
    CONFIRMED = 1,
    REJECTED = 2,
    IN_PROGRESS = 3,
    COMPLETED = 4,
}
