export enum ReportType {
    WEEK = 0,
    MONTH = 1,
    QUARTER = 2,
}