import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class GenerateSerialRequest {
  @ApiProperty({
    description: 'Mã thiết bị',
    type: String,
  })
  @IsNotEmpty()
  deviceCode: string;
}
