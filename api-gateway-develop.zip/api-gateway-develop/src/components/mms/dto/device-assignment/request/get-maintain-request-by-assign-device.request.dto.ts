import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { Allow } from 'class-validator';

export class GetMaintainRequestByAssignDeviceRequest {
  @Allow()
  @Transform((value) => {
    return Number(value.value) || 1;
  })
  @ApiProperty({
    type: Number,
  })
  page?: number;

  @Allow()
  @ApiProperty({
    type: Number,
  })
  limit?: number;

  get take(): number {
    const limit = Number(this.limit) || 10;

    return limit > 0 && limit <= 200 ? limit : 10;
  }

  get skip(): number {
    const page = (Number(this.page) || 1) - 1;

    return (page < 0 ? 0 : page) * this.take;
  }
}
