import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsMongoId, IsOptional } from 'class-validator';
import { GetMaintainRequestByAssignDeviceRequest } from './get-maintain-request-by-assign-device.request.dto';

export class GetMaintainInfoByDeviceRequest extends GetMaintainRequestByAssignDeviceRequest {
  @ApiPropertyOptional({
    description: 'Id của device assignment',
  })
  @IsOptional()
  @IsMongoId()
  deviceAssignId: string;
}
