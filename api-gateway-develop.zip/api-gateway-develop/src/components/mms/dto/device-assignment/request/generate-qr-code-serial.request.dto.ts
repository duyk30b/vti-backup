import { ApiProperty } from '@nestjs/swagger';
import { ArrayNotEmpty, IsInt, IsNotEmpty, IsString } from 'class-validator';

class SerialPrint {
  @ApiProperty({
    description: 'Số serial',
  })
  @IsNotEmpty()
  @IsString()
  serial: string;

  @ApiProperty({
    description: 'Số lượng',
  })
  @IsNotEmpty()
  @IsInt()
  quantity: number;
}

export class GenerateQrCodeSerialRequest {
  @ApiProperty({
    description: 'Danh sách serial',
    type: SerialPrint,
    isArray: true,
  })
  @ArrayNotEmpty()
  serials: SerialPrint[];
}
