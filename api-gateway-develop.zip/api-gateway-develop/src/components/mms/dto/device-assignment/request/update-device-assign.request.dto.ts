import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsOptional } from 'class-validator';
import { DeviceAssignRequestDto } from './device-assign.request.dto';

export class UpdateDeviceAssignRequestDto extends DeviceAssignRequestDto {
  @ApiProperty({
    description: 'Mục tiêu oee của thiết bị',
  })
  @IsOptional()
  @IsNumber()
  oee: number;
}
