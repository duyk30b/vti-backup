import { PaginationQuery } from '@utils/pagination.query';
import { IsArray, IsNotEmpty } from 'class-validator';

export class ListSerialByDeviceIds extends PaginationQuery {
  @IsArray()
  @IsNotEmpty()
  deviceIds: string;
}
