import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsDateString,
  IsMongoId,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator';

export class DeviceAssignmentDto {
  @ApiPropertyOptional({
    description: 'Id yêu cầu',
  })
  @IsMongoId()
  @IsNotEmpty()
  deviceRequestId: string;

  @ApiProperty({
    description: 'Số serial',
  })
  @IsString()
  @IsNotEmpty()
  serial: string;

  @ApiProperty({
    description: 'Ngày phân công',
  })
  @IsNotEmpty()
  @IsDateString()
  assignedAt: Date;

  @ApiProperty({
    description: 'Id OEE',
  })
  @IsNotEmpty()
  @IsNumber()
  oee: number;

  @ApiProperty({
    description: 'Ngày sử dụng',
  })
  @IsNotEmpty()
  @IsDateString()
  usedAt: Date;

  @ApiProperty({
    description: 'Id người chịu trách nhiệm',
  })
  @IsNumber()
  @IsNotEmpty()
  responsibleUserId: number;
}

export class ImportDeviceAssignmentRequestDto {
  @ApiProperty({ type: DeviceAssignmentDto })
  @IsArray()
  @Type(() => DeviceAssignmentDto)
  items: DeviceAssignmentDto[];
}
