import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class ValidateSerialRequest {
  @ApiProperty({
    description: 'Mã serial',
    type: String,
  })
  @IsNotEmpty()
  serial: string;
}
