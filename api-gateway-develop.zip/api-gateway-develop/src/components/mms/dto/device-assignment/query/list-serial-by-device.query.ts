import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsEnum, IsMongoId, IsNotEmpty, IsOptional } from 'class-validator';

export class ListSerialByDeviceQuery extends PaginationQuery {
  @ApiProperty({
    description: 'Mã thiết bị',
    type: String,
  })
  @IsMongoId()
  @IsNotEmpty()
  deviceId: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll: string;
}
