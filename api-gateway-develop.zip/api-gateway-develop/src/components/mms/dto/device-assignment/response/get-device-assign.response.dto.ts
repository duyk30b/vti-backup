import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

class User {
  @Expose()
  @ApiProperty({ example: 'Admin' })
  fullName: string;

  @Expose()
  @ApiProperty({ example: 1 })
  userId: string;

  @Expose()
  @ApiProperty({ example: 'Admin' })
  username: string;
}

class History extends User {
  @Expose()
  @ApiProperty({ example: 1 })
  action: number;

  @Expose()
  @ApiProperty({ example: '2022-01-05T09:02:49.811Z' })
  createdAt: Date;
}

class Factory {
  @Expose()
  id: number;

  @Expose()
  code: string;

  @Expose()
  name: string;
}

export class GetDeviceAssignResponseDto extends SuccessResponse {
  @Expose()
  @ApiProperty({ example: '61d4fe551f1d37f3a4a1c7c5' })
  id: string;

  @Expose()
  @ApiProperty({ example: '61d4fe551f1d37f3a4a1c7c5' })
  requestId: string;

  @Expose()
  @ApiProperty({ example: '61d4fe551f1d37f3a4a1c7c5' })
  requestCode: string;

  @Expose()
  @ApiProperty({ example: '001' })
  deviceCode: string;

  @Expose()
  @ApiProperty({ example: '61b9ff3364d501430457f6bb' })
  deviceId: string;

  @Expose()
  @ApiProperty({ example: 'device1' })
  deviceName: string;

  @Expose()
  @ApiProperty({ example: 'hahahaha' })
  serial: string;

  @Expose()
  @ApiProperty({ example: '001' })
  model: string;

  @Expose()
  @ApiProperty({
    type: Date,
  })
  assignedAt: Date;

  @Expose()
  @ApiProperty({
    type: Date,
  })
  usedAt: Date;

  @Expose()
  @ApiProperty({ example: 1 })
  status: number;

  @Expose()
  @ApiPropertyOptional({ type: Factory })
  factory: Factory;

  @Expose()
  @ApiPropertyOptional({ type: Factory })
  workCenter: Factory;

  @Expose()
  @ApiPropertyOptional({ example: 1 })
  oee: number;

  @Expose()
  @ApiProperty({
    example: {
      fullName: 'Admin',
      userId: 7,
      username: 'admin',
    },
    type: User,
  })
  assignUser: User;

  @Expose()
  @ApiProperty({
    example: {
      fullName: 'Admin',
      userId: 7,
      username: 'admin',
    },
    type: User,
  })
  responsibleUser: User;

  @Expose()
  @ApiProperty({
    example: [
      {
        userId: 1,
        fullName: 'Admin',
        username: 'admin',
        action: 1,
        createdAt: '2022-01-05T09:02:49.811Z',
      },
    ],
    type: History,
  })
  histories: History[];
}
