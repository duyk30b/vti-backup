import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

export class GetMaintainRequestByAssignDeviceResponse extends SuccessResponse {
  @Expose()
  @ApiProperty({ example: '61ba01408e92b01449e96453' })
  id: string;

  @Expose()
  @ApiProperty({ example: '2022-01-04T03:34:22.585Z' })
  executionDate: string;

  @Expose()
  @ApiProperty({ example: 1 })
  type: number;
}
