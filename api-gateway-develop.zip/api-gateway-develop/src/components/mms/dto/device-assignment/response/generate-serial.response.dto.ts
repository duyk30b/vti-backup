import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

class Serial {
  @ApiProperty({ example: 'something string' })
  @Expose()
  serial: string;

  @ApiProperty()
  @Expose()
  suggestResponsibleUserId: number;
}

export class GenerateSerialResponse extends SuccessResponse {
  @ApiProperty({ type: Serial })
  @Expose()
  data: Serial;
}
