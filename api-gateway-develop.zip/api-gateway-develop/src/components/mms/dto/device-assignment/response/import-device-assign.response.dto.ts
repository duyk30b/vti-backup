import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';
import { IsArray } from 'class-validator';

export class ImportDeviceAssignResponseDto extends SuccessResponse {
  @ApiProperty({
    example: 1,
    description: 'Số dòng import thành công.',
  })
  @Expose()
  SUCCESS: number;

  @ApiProperty({
    example: 1,
    description: 'Số dòng import thất bại.',
  })
  @Expose()
  FAIL: number;

  @ApiProperty({
    example: 1,
    description: 'Trạng thái import.',
  })
  @IsArray()
  @Expose()
  statusImport: Boolean[];

  @ApiProperty({
    example: 1,
    description: 'Validation message.',
  })
  @IsArray()
  @Expose()
  messageValidate: string[];
}
