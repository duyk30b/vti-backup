import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

class ValidateSerial {
  @ApiProperty({
    type: Boolean,
  })
  @Expose()
  status: boolean;
}

export class ValidateSerialResponse extends SuccessResponse {
  @ApiProperty({ type: ValidateSerial })
  @Expose()
  data: ValidateSerial;
}
