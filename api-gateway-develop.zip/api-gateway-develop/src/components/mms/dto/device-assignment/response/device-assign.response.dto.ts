import { SuccessResponse } from '@utils/success.response.dto';

export class DeviceAssignResponseDto extends SuccessResponse {}
