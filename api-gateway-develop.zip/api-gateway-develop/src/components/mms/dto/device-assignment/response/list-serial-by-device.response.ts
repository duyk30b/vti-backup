import { ApiProperty } from '@nestjs/swagger';
import { Meta } from '@utils/common.response';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

class ListSerialByDevice {
  @ApiProperty({
    type: String,
    description: 'Mã phân công thiết bị',
  })
  @Expose()
  deviceAssignmentId: string;

  @ApiProperty({
    type: String,
    description: 'Mã Serial',
  })
  @Expose()
  serial: string;

  @ApiProperty({
    type: String,
    description: 'Tên thiết bị',
  })
  @Expose()
  deviceName: string;
}

class MetaDataSerialByDeviceResponse {
  @ApiProperty({ type: ListSerialByDevice, isArray: true })
  @Expose()
  items: ListSerialByDevice[];

  @ApiProperty({ type: Meta })
  @Expose()
  meta: Meta;
}

export class ListSerialByDeviceResponse extends SuccessResponse {
  @ApiProperty({ type: MetaDataSerialByDeviceResponse })
  @Expose()
  data: MetaDataSerialByDeviceResponse;
}
