import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

class DataAttributeType {
  @ApiProperty({ type: String })
  @Expose()
  id: string;

  @ApiProperty({ type: String })
  @Expose()
  name: string;

  @ApiProperty({ type: String })
  @Expose()
  code: string;

  @ApiProperty({ type: String })
  @Expose()
  unit: string;
}

class MasterDataAttributeType {
  @ApiProperty({ type: Number })
  @Expose()
  workCenterId: number;

  @ApiProperty({ type: String })
  @Expose()
  serial: string;

  @ApiProperty({ type: String })
  @Expose()
  deviceName: string;

  @ApiProperty({ type: DataAttributeType, isArray: true })
  @Expose()
  items: DataAttributeType;
}

export class AttributeTypeByDeviceAssignResponseDto extends SuccessResponse {
  @ApiProperty({ type: MasterDataAttributeType })
  @Expose()
  data: MasterDataAttributeType;
}
