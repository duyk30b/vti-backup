import { ApiProperty } from '@nestjs/swagger';
import { Meta } from '@utils/common.response';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';
import { DetailInstallationTemplateResponse } from './detail-installation-template.response';

class MetaDataInstallationTemplate {
  @ApiProperty({ type: DetailInstallationTemplateResponse, isArray: true })
  @Expose()
  items: DetailInstallationTemplateResponse[];

  @ApiProperty({ type: Meta })
  @Expose()
  meta: Meta;
}

export class ListInstallationTemplate extends SuccessResponse {
  @ApiProperty({ type: MetaDataInstallationTemplate })
  @Expose()
  data: MetaDataInstallationTemplate;
}
