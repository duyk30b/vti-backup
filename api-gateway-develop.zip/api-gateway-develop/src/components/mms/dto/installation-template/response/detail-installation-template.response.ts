import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class DetailInstallationTemplateDetail {
  @ApiProperty({ type: String })
  @Expose()
  title: string;

  @ApiProperty({ type: String })
  @Expose()
  description: string;

  @ApiProperty({ type: Boolean })
  @Expose()
  isRequire: boolean;
}

export class DetailInstallationTemplateResponse {
  @ApiProperty({ type: String })
  @Expose()
  id: string;

  @ApiProperty({ type: String })
  @Expose()
  code: string;

  @ApiProperty({ type: String })
  @Expose()
  name: string;

  @ApiProperty({ type: String })
  @Expose()
  description: string;

  @ApiProperty({ type: DetailInstallationTemplateDetail, isArray: true })
  @Type(() => DetailInstallationTemplateDetail)
  @Expose()
  details: DetailInstallationTemplateDetail[];
}
