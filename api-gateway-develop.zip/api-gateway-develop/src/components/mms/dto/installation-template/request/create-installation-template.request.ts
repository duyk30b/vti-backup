import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';

class CreateInstallationTemplateDetail {
  @ApiProperty({
    description: 'Tiêu đề',
    type: String,
  })
  @MaxLength(50)
  @IsString()
  @IsNotEmpty()
  title: string;

  @ApiProperty({
    description: 'Mô tả',
    type: String,
  })
  @MaxLength(255)
  @IsString()
  @IsNotEmpty()
  description: string;

  @ApiProperty({
    description: 'Có bắt buộc hay không',
    type: Boolean,
  })
  @IsBoolean()
  @IsOptional()
  isRequire: boolean;
}

export class CreateInstallationTemplateRequest {
  @ApiProperty({
    description: 'Mã phiếu',
    type: String,
  })
  @MaxLength(8)
  @IsString()
  @IsNotEmpty()
  code: string;

  @ApiProperty({
    description: 'Tên phiếu',
    type: String,
  })
  @MaxLength(50)
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({
    description: 'Mô tả',
    type: String,
  })
  @MaxLength(255)
  @IsString()
  @IsOptional()
  description: string;

  @ApiProperty({
    description: 'Chi tiết phiếu',
    type: CreateInstallationTemplateDetail,
    isArray: true,
  })
  @Type(() => CreateInstallationTemplateDetail)
  @ValidateNested({ each: true })
  @ArrayNotEmpty()
  details: CreateInstallationTemplateDetail[];
}
