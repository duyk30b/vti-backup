import { CreateInstallationTemplateRequest } from './create-installation-template.request';

export class UpdateInstallationTemplateRequest extends CreateInstallationTemplateRequest {}
