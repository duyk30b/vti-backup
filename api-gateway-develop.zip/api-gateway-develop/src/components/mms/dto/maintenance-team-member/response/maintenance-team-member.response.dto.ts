import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class MaintenanceTeamMemberResponseDto {
  @ApiProperty()
  @Expose()
  _id: string;

  @ApiProperty()
  @Expose()
  userId: number;

  @ApiProperty()
  @Expose()
  role: number;
}
