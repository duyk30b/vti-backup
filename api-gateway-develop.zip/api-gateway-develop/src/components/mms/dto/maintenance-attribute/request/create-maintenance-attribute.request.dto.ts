import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';
import { MAINTENANCE_ATTRIBUTE_CONST } from '@components/mms/constant/maintenance-attribute.constant';

export class CreateMaintenanceAttributeRequestDto {
  @ApiProperty({
    example: 'ABC123',
    description: 'Code của thuộc tính bảo trì',
  })
  @Expose()
  @IsNotEmpty()
  @IsString()
  @MaxLength(MAINTENANCE_ATTRIBUTE_CONST.CODE.MAX_LENGTH)
  code: string;

  @ApiProperty({ example: 'ABC123', description: 'Tên của thuộc tính bảo trì' })
  @Expose()
  @IsNotEmpty()
  @IsString()
  @MaxLength(MAINTENANCE_ATTRIBUTE_CONST.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: 'Mô tả', description: 'Mô tả' })
  @Expose()
  @IsOptional()
  @IsString()
  @MaxLength(MAINTENANCE_ATTRIBUTE_CONST.DESCRIPTION.MAX_LENGTH)
  description: string;
}
