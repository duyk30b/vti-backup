import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class CreateMaintenanceAttributeResponseDto {
  @ApiProperty({
    example: 'Mã thuộc tính',
    description: 'mã thuộc tính bảo trì',
  })
  @Expose()
  code: string;

  @ApiProperty({
    example: 'Tên thuộc tính',
    description: 'tên thuộc tính bảo trì',
  })
  @Expose()
  name: string;

  @ApiProperty({ example: 'Mô tả', description: 'Mô tả' })
  @Expose()
  description: string;

  @ApiProperty({ example: 'Ngày cập nhật', description: 'Ngày cập nhật' })
  @Expose()
  updatedAt: Date;

  @ApiProperty({ example: 'Ngày tạo', description: 'Ngày tạo' })
  @Expose()
  createdAt: Date;
}
