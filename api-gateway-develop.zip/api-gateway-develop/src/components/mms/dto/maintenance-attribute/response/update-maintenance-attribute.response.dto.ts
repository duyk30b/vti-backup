import { MaintenanceAttributeResponseDto } from '@components/mms/dto/maintenance-attribute/response/maintenance-attribute.response.dto';

export class UpdateMaintenanceAttributeResponseDto extends MaintenanceAttributeResponseDto {}
