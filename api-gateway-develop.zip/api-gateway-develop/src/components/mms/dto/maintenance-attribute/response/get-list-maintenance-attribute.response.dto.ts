import { SuccessResponseDto } from '@components/sale/dto/response/suscess.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { MaintenanceAttributeResponseDto } from '@components/mms/dto/maintenance-attribute/response/maintenance-attribute.response.dto';
class Meta {
  @Expose()
  total: number;

  @Expose()
  page: number;
}

class MetaData {
  @Expose()
  data: MaintenanceAttributeResponseDto[];

  @Expose()
  meta: Meta;
}

export class GetListMaintenanceAttributeResponseDto extends SuccessResponseDto {
  @ApiProperty()
  @Expose()
  data: MetaData;
}