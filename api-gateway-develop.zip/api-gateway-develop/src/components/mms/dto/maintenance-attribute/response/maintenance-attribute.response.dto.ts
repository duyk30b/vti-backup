import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class MaintenanceAttributeResponseDto {
  @ApiProperty({
    example: 1,
    description: 'Id của thuộc tính bảo trì',
  })
  @Expose()
  id: number;

  @ApiProperty({
    example: 'ABC',
    description: 'Mã của của thuộc tính bảo trì',
  })
  @Expose()
  name: string;

  @ApiProperty({
    example: 'ABC',
    description: 'Mã của thuộc tính bảo trì',
  })
  @Expose()
  code: string;

  @ApiProperty({
    example: 'ABC',
    description: 'Mô tả của thuộc tính bảo trì',
  })
  @Expose()
  description: string;

  @ApiProperty({
    example: 'ABC',
    description: 'Trạng thái của thuộc tính bảo trì',
  })
  @Expose()
  createAt: Date;

  @ApiProperty({
    example: 'ABC',
    description: 'Trạng thái của thuộc tính bảo trì',
  })
  @Expose()
  updateAt: Date;
}
