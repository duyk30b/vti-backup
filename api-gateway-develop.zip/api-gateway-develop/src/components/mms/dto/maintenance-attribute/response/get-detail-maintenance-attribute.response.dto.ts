import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { GetHistoryDetailResponseDto } from '@components/mms/dto/history/dto/response/get-history-detail.response.dto';

export class GetDetailMaintenanceAttributeResponseDto {
  @ApiProperty({ example: '61a840a42de73432d39703e5', description: 'Id' })
  @Expose()
  _id: string;

  @ApiProperty({ example: 'ABC123', description: 'Code' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'ABC123', description: 'Tên' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'Mô tả', description: 'Mô tả' })
  @Expose()
  description: string;

  @ApiProperty({ example: '2021-12-01T10:20:04.583Z', description: 'Ngày tạo' })
  @Expose()
  createdAt: Date;

  @ApiProperty({
    example: '2021-12-01T10:20:04.583Z',
    description: 'Ngày update',
  })
  @Expose()
  updatedAt: Date;

  @ApiProperty({
    example: [
      {
        _id: '61a840a42de73432d39703e6',
        userId: 1,
        username: 'admin',
        action: 0,
        createdAt: '2021-12-01T10:20:04.571Z',
      },
    ],
    description: 'Lịch sử hành động',
  })
  @Expose()
  @Type(() => GetHistoryDetailResponseDto)
  histories: GetHistoryDetailResponseDto[];
}
