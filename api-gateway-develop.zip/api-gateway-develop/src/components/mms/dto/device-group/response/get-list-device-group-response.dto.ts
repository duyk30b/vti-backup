import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { DeviceCategoryResponseDto } from '@components/mms/dto/device-group/response/device-category.response.dto';
class Meta {
  @Expose()
  total: number;

  @Expose()
  page: number;
}

class MetaData {
  @Expose()
  data: DeviceCategoryResponseDto[];

  @Expose()
  meta: Meta;
}
export class GetListDeviceGroupResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: MetaData;
}