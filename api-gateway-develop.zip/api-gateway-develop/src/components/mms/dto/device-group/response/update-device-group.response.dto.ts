import { GetDetailDeviceGroupResponseDto } from '@components/mms/dto/device-group/response/get-detail-device-group.response.dto';

export class UpdateDeviceGroupResponseDto extends GetDetailDeviceGroupResponseDto {}
