import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

export class CreateDeviceGroupResponseDto {
  @ApiProperty({
    example: '61a6f6498e1f824efce559a4',
    description: 'id của nhóm thiết bị',
  })
  @Expose()
  _id: string;

  @ApiProperty({ example: 'ABC123', description: 'Code của nhóm thiết bị' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'ABC123', description: 'tên của nhóm thiết bị' })
  @Expose()
  name: string;

  @ApiProperty({ example: [1, 2, 3], description: 'Ds người chịu trách nhiệm' })
  @Expose()
  @IsArray()
  responsibleUserIds: number[];

  @ApiProperty({ example: 'Mô tả', description: 'Mô tả' })
  @Expose()
  description: string;

  @ApiProperty({ example: 0, description: 'Status' })
  @Expose()
  status: number;
}
