import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class DeviceCategoryResponseDto extends SuccessResponse {
  @ApiProperty({
    example: 1,
    description: 'Id nhóm thiết bị' })
  @Expose()
  id: number;

  @ApiProperty({
    example: 'ABC',
    description: 'Mã nhóm thiết bị',
  })
  @Expose()
  code: string;

  @ApiProperty({
    example: 'ABC',
    description: 'Tên nhóm thiết bị',
  })
  @Expose()
  name: string;

  @ApiProperty({
    example: 'ABC',
    description: 'Mô tả nhóm thiết bị',
  })
  @Expose()
  description: string;

  @ApiProperty({
    example: 'ABC',
    description: 'Trạng thái nhóm thiết bị',
  })
  @Expose()
  status: number;

  @ApiProperty({
    example: '2021-11-25 09:13:15.562609+00',
    description: 'Ngày tạo nhóm thiết bị',
  })
  @Expose()
  createAt: Date;

  @ApiProperty({
    example: '2021-11-25 09:13:15.562609+00',
    description: 'Ngày tạo nhóm thiết bị',
  })
  @Expose()
  updateAt: Date;
}