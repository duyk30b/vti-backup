import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsEnum, IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';
import { Expose } from 'class-transformer';
import { DEVICE_GROUP_CONST, DeviceGroupStatusEnum } from '@components/mms/constant/device-group.constant';

export class CreateDeviceGroupRequestDto {
  @ApiProperty({ example: 'ABC123', description: 'Code của nhóm thiết bị' })
  @Expose()
  @IsNotEmpty()
  @MaxLength(DEVICE_GROUP_CONST.CODE.MAX_LENGTH)
  code: string;

  @ApiProperty({ example: 'ABC123', description: 'Tên của nhóm thiết bị' })
  @Expose()
  @IsNotEmpty()
  @MaxLength(DEVICE_GROUP_CONST.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: [1], description: 'Người chịu trách nhiệm' })
  @Expose()
  @IsNotEmpty()
  @IsArray()
  responsibleUserIds: number[];

  @ApiProperty({ example: '61bc885d04d70b7945e2073e', description: 'Người chịu trách nhiệm là đội bảo trì' })
  @Expose()
  @IsString()
  @IsOptional()
  responsibleMaintenanceTeam: string;

  @ApiProperty({ example: 'Mô tả', description: 'Mô tả' })
  @Expose()
  @MaxLength(DEVICE_GROUP_CONST.DESCRIPTION.MAX_LENGTH)
  description: string;

  @ApiProperty({ example: 0, description: 'Status' })
  @Expose()
  @IsEnum(DeviceGroupStatusEnum)
  @IsOptional()
  status: number;
}