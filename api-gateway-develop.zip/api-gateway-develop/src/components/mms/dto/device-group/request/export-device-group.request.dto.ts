import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { IsArray, IsNotEmpty, IsString } from 'class-validator';

export class ExportDeviceGroupRequestDto {
  @ApiProperty()
  @Expose()
  @IsString({ each: true })
  @IsArray()
  @IsNotEmpty()
  _ids: string[];
}
