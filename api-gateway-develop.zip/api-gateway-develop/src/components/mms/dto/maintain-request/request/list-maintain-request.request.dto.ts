import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsOptional, IsInt, IsString } from 'class-validator';

export class ListMaintainRequestDto extends PaginationQuery {
  @ApiProperty({ example: 1 })
  @IsInt()
  @IsOptional()
  page: number;

  @ApiProperty({ example: 1 })
  @IsInt()
  @IsOptional()
  limit: number;

  @ApiProperty({ example: 'test' })
  @IsString()
  @IsOptional()
  keyword: string;
}
