import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsOptional,
} from 'class-validator';

class AssignUser {
  @IsInt()
  @IsNotEmpty()
  userId: number;
}
export class EditJobRequestDto {
  @ApiProperty({ example: '2021-11-30' })
  @IsOptional()
  @IsDateString()
  planDate: Date;

  @ApiProperty({ example: [{ userId: 1 }] })
  @IsArray()
  @IsOptional()
  assignUsers: AssignUser[];
}
