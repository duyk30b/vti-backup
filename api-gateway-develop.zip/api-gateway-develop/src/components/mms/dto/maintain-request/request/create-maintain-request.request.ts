import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';

class SupplyItemCreate {
  @ApiProperty({})
  @IsString()
  @IsNotEmpty()
  supplyId: string;

  @ApiProperty({})
  @IsInt()
  @IsNotEmpty()
  @Min(1)
  @Max(99)
  quantity: number;
}

export class CreateMaintainRequestDto {
  @ApiProperty({})
  @IsString()
  @IsNotEmpty()
  @MaxLength(50)
  name: string;

  @ApiProperty({})
  @IsString()
  @IsNotEmpty()
  deviceAssignmentId: string;

  @ApiProperty({})
  @IsString()
  @IsOptional()
  @MaxLength(255)
  description: string;

  @ApiProperty({})
  @IsNotEmpty()
  @IsDateString()
  completeExpectedDate: Date;

  @ApiProperty({})
  @IsInt()
  priority: number;

  @ApiProperty({ type: SupplyItemCreate, isArray: true })
  @IsArray()
  @IsOptional()
  @Type(() => SupplyItemCreate)
  @ValidateNested()
  supplies: SupplyItemCreate[];

  @ApiProperty()
  @IsNumber()
  expectedMaintainTime: number;
}
