import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsDate,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';

class SupplyItemUpdate {
  @ApiProperty({})
  @IsString()
  @IsNotEmpty()
  supplyId: string;

  @ApiProperty({})
  @IsInt()
  @Max(99)
  @Min(1)
  @IsNotEmpty()
  quantity: number;
}

export class UpdateMaintainRequestDto {
  @ApiProperty({})
  @IsString()
  @IsOptional()
  deviceAssignmentId: string;

  @ApiProperty({})
  @IsString()
  @IsOptional()
  @MaxLength(255)
  description: string;

  @ApiProperty({})
  @IsString()
  @IsOptional()
  @MaxLength(50)
  name: string;

  @ApiProperty({})
  @IsDate()
  @IsOptional()
  completeExpectedDate: Date;

  @ApiProperty({})
  @IsDate()
  @IsOptional()
  executionDate: Date;

  @ApiProperty({ example: 2 })
  @IsInt()
  @IsOptional()
  priority: number;

  @ApiProperty({})
  @IsInt()
  @IsOptional()
  status: number;

  @ApiProperty({ type: SupplyItemUpdate, isArray: true })
  @IsArray()
  @IsOptional()
  @Type(() => SupplyItemUpdate)
  @ValidateNested()
  supplies: SupplyItemUpdate[];
}
