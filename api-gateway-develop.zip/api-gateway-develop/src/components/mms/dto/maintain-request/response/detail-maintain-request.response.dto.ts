import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { SuccessResponse } from './success.response';

class User {
  @Expose()
  @ApiProperty({ example: 1 })
  id: string;

  @Expose()
  @ApiProperty({ example: 'User 01' })
  name: string;

  @Expose()
  @ApiProperty({ example: 'Factory 01' })
  factory: string;

  @Expose()
  @ApiProperty({ example: 'Factory 01' })
  company: string;

  @Expose()
  @ApiProperty({ example: '0123456789' })
  phone: string;

  @Expose()
  @ApiProperty({ example: 'HN' })
  address: string;
}
class Device {
  @Expose()
  id: number;

  @Expose()
  @ApiProperty({ example: '01' })
  code: string;

  @Expose()
  @ApiProperty({ example: 'Keyboard' })
  name: string;

  @Expose()
  description: string;

  @Expose()
  @ApiProperty({ example: 1 })
  status: number;

  @Expose()
  @ApiProperty({ type: User })
  responsibleUser: User;
}

class DeviceAssignment {
  @Expose()
  id: number;

  @Expose()
  @ApiProperty({ example: '01' })
  serial: string;

  @Expose()
  @ApiProperty({ example: 1 })
  status: number;

  @Expose()
  @ApiProperty({ type: Device })
  @Type(() => Device)
  device: Device;
}

class Supply {
  @Expose()
  @ApiProperty({ example: '01' })
  id: string;

  @Expose()
  @ApiProperty({ example: '01' })
  name: string;

  @Expose()
  @ApiProperty({ example: 1 })
  quantity: number;
}

class MaintainRequestDetail {
  @Expose()
  id: number;

  @Expose()
  @ApiProperty({ example: '01' })
  code: string;

  @Expose()
  @ApiProperty({ example: 'Maintain Request' })
  name: string;

  @Expose()
  @ApiProperty({ example: 1 })
  userId: number;

  @Expose()
  @ApiProperty({ example: '01' })
  deviceAssignmentId: string;

  @Expose()
  @ApiProperty({ example: '01' })
  deviceId: string;

  @Expose()
  @ApiProperty({ example: 'no description' })
  description: string;

  @Expose()
  @ApiProperty({ example: 1 })
  status: number;

  @Expose()
  @ApiProperty({ example: '2021-11-30T00:00:00.000Z' })
  completeExpectedDate: Date;

  @Expose()
  @ApiProperty({ example: '2021-11-30T00:00:00.000Z' })
  executionDate: Date;

  @Expose()
  @ApiProperty({ example: 1 })
  priority: number;

  @Expose()
  @ApiProperty({ example: 1 })
  type: number;

  @Expose()
  @ApiProperty({ type: DeviceAssignment })
  @Type(() => DeviceAssignment)
  deviceAssignment: DeviceAssignment;

  @Expose()
  @ApiProperty({ type: User })
  user: User;

  @Expose()
  @ApiProperty({ type: Supply, isArray: true })
  supplies: Supply[];

  @Expose()
  @ApiProperty({ example: '2021-11-30T00:00:00.000Z' })
  planFrom: Date;

  @Expose()
  @ApiProperty({ example: '2021-11-30T00:00:00.000Z' })
  planDate: Date;
}

export class DetailMaintainRequestResponse extends SuccessResponse {
  @Expose()
  @ApiProperty()
  data: MaintainRequestDetail;
}
