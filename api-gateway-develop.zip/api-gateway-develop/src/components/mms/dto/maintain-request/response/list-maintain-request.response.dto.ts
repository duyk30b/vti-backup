import { ApiProperty } from '@nestjs/swagger';
import { PagingResponse } from '@utils/paging.response';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { SuccessResponse } from '@utils/success.response.dto';
import { DetailDeviceAssignmentResponse } from '../../job/response/list-job-by-device.response.dto';

class User {
  @Expose()
  @ApiProperty({ example: 1 })
  id: string;

  @Expose()
  @ApiProperty({ example: 'User 01' })
  name: string;
}

class Supply {
  @Expose()
  @ApiProperty({ example: '01' })
  id: string;

  @Expose()
  @ApiProperty({ example: '01' })
  name: string;

  @Expose()
  @ApiProperty({ example: 1 })
  quantity: number;
}

class MaintainRequestList {
  @Expose()
  id: number;

  @Expose()
  @ApiProperty({ example: '01' })
  code: string;

  @Expose()
  @ApiProperty({ example: 'Maintain Request' })
  name: string;

  @Expose()
  @ApiProperty({ example: 1 })
  userId: number;

  @Expose()
  @ApiProperty({ example: '01' })
  deviceAssignmentId: string;

  @Expose()
  @ApiProperty({ example: '01' })
  deviceId: string;

  @Expose()
  @ApiProperty({ example: 'no description' })
  description: string;

  @Expose()
  @ApiProperty({ example: 1 })
  status: number;

  @Expose()
  @ApiProperty({ example: '2021-11-30T00:00:00.000Z' })
  completeExpectedDate: Date;

  @Expose()
  @ApiProperty({ example: '2021-11-30T00:00:00.000Z' })
  executionDate: Date;

  @Expose()
  @ApiProperty({ example: 1 })
  priority: number;

  @Expose()
  @ApiProperty({ example: 1 })
  type: number;

  @Expose()
  @ApiProperty({ type: DetailDeviceAssignmentResponse })
  @Type(() => DetailDeviceAssignmentResponse)
  deviceAssignment: DetailDeviceAssignmentResponse;

  @Expose()
  @ApiProperty({ type: User })
  user: User;
}

export class ListMaintainRequest extends PagingResponse {
  @Expose()
  @ApiProperty({ type: MaintainRequestList, isArray: true })
  @Type(() => MaintainRequestList)
  @IsArray()
  items: MaintainRequestList[];
}
export class ListMaintainRequestResponse extends SuccessResponse {
  @Expose()
  @ApiProperty({ type: ListMaintainRequest })
  @Type(() => MaintainRequestList)
  data: ListMaintainRequest;
}
