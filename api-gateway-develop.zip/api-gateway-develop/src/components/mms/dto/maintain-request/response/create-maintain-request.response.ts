import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { SuccessResponse } from './success.response';

class MaintainRequestItem {
  @Expose()
  @ApiProperty({ example: '01' })
  id: number;

  @Expose()
  @ApiProperty({ example: 'Maintain Request' })
  name: string;

  @Expose()
  @ApiProperty({ example: 1 })
  userId: number;

  @Expose()
  @ApiProperty({ example: '01' })
  deviceAssignmentId: string;

  @Expose()
  @ApiProperty({ example: '' })
  description: string;

  @Expose()
  @ApiProperty({ example: 1 })
  status: number;

  @Expose()
  @ApiProperty({ example: '2021-11-30T00:00:00.000Z' })
  completeExpectedDate: Date;

  @Expose()
  @ApiProperty({ example: 1 })
  priority: number;
}

export class MaintainRequestResponse extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: MaintainRequestItem;
}
