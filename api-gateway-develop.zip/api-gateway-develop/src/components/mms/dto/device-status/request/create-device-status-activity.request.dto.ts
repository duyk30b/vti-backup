import { IsNotEmpty, IsArray, ValidateNested } from 'class-validator';
import { Type, Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

export class CreateDeviceStatusActivityRequestDto {
  @ApiProperty({
    description: 'deviceAssignmentId',
  })
  deviceAssignmentId: string;

  @ApiProperty({
    example: [
      {
        id: null,
        startDate: '2022/03/17 11:29:00',
        endDate: '2022/03/20 11:29:00',
        status: 1,
        productionOrderId: 1,
        attributes: [
          {
            key: '6229b936c75b9abc96aff9c8',
            value: 1,
          },
        ],
        actualQuantity: 1,
        passQuantity: 1,
      },
    ],
    description: 'Hoạt động',
  })
  @Expose()
  @IsArray()
  @IsNotEmpty()
  @ValidateNested({ each: true })
  @Type(() => DeviceStatusActivityDetailRequestDto)
  actives: DeviceStatusActivityDetailRequestDto[];
}

export class DeviceStatusActivityDetailRequestDto {
  @ApiProperty({
    description: 'Thời gian bắt đầu',
  })
  startDate: string;

  @ApiProperty({
    description: 'Thời gian kết thúc',
  })
  endDate: string;

  @ApiProperty({
    description: 'Trạng thái',
  })
  status: number;

  @ApiProperty({
    description: 'Lệnh sản xuất',
  })
  moId: number;

  @ApiProperty({
    description: 'số lượng sp pass',
  })
  passQuantity: number;

  @ApiProperty({
    description: 'số lượng sp thực tế',
  })
  actualQuantity: number;

  @ApiProperty({
    example: [
      {
        id: null,
        startDate: '2022/03/17 11:29:00',
        endDate: '2022/03/20 11:29:00',
        status: 1,
        moId: 1,
        attributes: [
          {
            key: '6229b936c75b9abc96aff9c8',
            rpm: '6229b936c75b9abc96aff9c8',
            temperature: '6229b936c75b9abc96aff9c8',
          },
        ],
      },
    ],
    description: 'Hoạt động',
  })
  @Expose()
  @IsArray()
  @IsNotEmpty()
  @ValidateNested({ each: true })
  @Type(() => Attributes)
  attributes: Attributes[];
}

export class Attributes {
  @ApiProperty({
    description: 'key',
  })
  key: string;

  @ApiProperty({
    description: 'value',
  })
  value: string;
}
