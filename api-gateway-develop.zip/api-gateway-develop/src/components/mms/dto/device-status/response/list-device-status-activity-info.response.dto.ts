import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { SuccessResponse } from '@utils/success.response.dto';
export class DeviceStatusActivityInfoResponseDto extends SuccessResponse {
  @ApiProperty({ type: () => ListDeviceStatusActivityInfo, isArray: true })
  @Expose()
  data: ListDeviceStatusActivityInfo[];

  @ApiProperty({ type: Number, example: 1 })
  @Expose()
  status: number;

  @ApiProperty({ type: Number, example: 1 })
  @Expose()
  totalOee: number;

  @ApiProperty({ type: Number, example: 1 })
  @Expose()
  type: number;

  @ApiProperty({ type: String, example: '02tbi05001' })
  @Expose()
  serial: string;

  @ApiProperty({ type: String, example: 'Thiết bị 1' })
  @Expose()
  deviceName: string;
}

export class ListDeviceStatusActivityInfo {
  @ApiProperty({ type: Date, example: '2022-04-05T02:30:00' })
  @Expose({ name: 'startDate' })
  date: Date;

  @ApiProperty({ type: Number, example: 10 })
  @Expose()
  activeTime: number;

  @ApiProperty({ type: Number, example: 10 })
  @Expose()
  actualQuantity: number;

  @ApiProperty({ type: Number, example: 10 })
  @Expose()
  passQuantity: number;

  @ApiProperty({ type: Number, example: 10 })
  @Expose()
  rest: number;

  @ApiProperty({ type: Number, example: 10 })
  @Expose()
  status: number;

  @ApiProperty({ type: Number, example: 10 })
  @Expose()
  oee: number;

  @ApiProperty({ type: Number, example: 10 })
  @Expose()
  stop: number;

  @ApiProperty({ type: () => Attributes, isArray: true })
  @Expose()
  attributes: Attributes[];
}

class Attributes {
  @ApiProperty({ type: String, example: 'Vòng quay' })
  @Expose()
  key: string;

  @ApiProperty({ type: String, example: '1000' })
  @Expose()
  value: string;
}

export class History {
  @ApiProperty({ type: String, example: '622958b349509b833b8d6e36' })
  @Expose()
  _id: string;

  @ApiProperty({ type: String, example: '2' })
  @Expose()
  status: string;

  @ApiProperty({ type: String, example: 'ABC' })
  @Expose()
  action: string;

  @ApiProperty({ type: String, example: '2022-04-05T02:30:00' })
  @Expose()
  actionBy: string;

  @ApiProperty({ type: String, example: '2022-04-05T02:30:00' })
  @Expose()
  actionAt: string;

  @ApiProperty({ type: String, example: 'ABC' })
  @Expose()
  user: string;
}
