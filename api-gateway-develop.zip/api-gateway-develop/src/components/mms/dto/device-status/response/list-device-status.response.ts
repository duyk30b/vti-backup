import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

export class DetailDeviceStatus {
  @ApiProperty({ type: String })
  @Expose()
  deviceAssignmentId: string;

  @ApiProperty({ type: String })
  @Expose()
  serial: string;

  @ApiProperty({ type: String })
  @Expose()
  deviceName: string;

  @ApiProperty({ type: Number })
  @Expose()
  status: number;

  @ApiProperty({ type: Number })
  @Expose()
  oee: number;

  @ApiProperty({ type: Date })
  @Expose()
  date: Date;

  @ApiProperty({ type: Number })
  @Expose()
  timeRest: number;

  @ApiProperty({ type: Number })
  @Expose()
  timeAction: number;

  @ApiProperty({ type: Number })
  @Expose()
  numOfStop: number;
}

class MetaDeviceStatus {
  @ApiProperty({ type: Number })
  @Expose()
  page: number;

  @ApiProperty({ type: Number })
  @Expose()
  total: number;
}

class MetaDataDeviceStatus {
  @ApiProperty({ type: Date })
  @Expose()
  dateExport: Date;

  @ApiProperty({ type: DetailDeviceStatus, isArray: true })
  @Expose()
  items: DetailDeviceStatus[];

  @ApiProperty({ type: MetaDeviceStatus })
  @Expose()
  meta: MetaDeviceStatus;
}

export class ListDeviceStatusResponse extends SuccessResponse {
  @ApiProperty({ type: MetaDataDeviceStatus })
  @Expose()
  data: MetaDataDeviceStatus;
}
