import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { SuccessResponse } from '@utils/success.response.dto';
import { ListDeviceStatusActivityInfo } from './list-device-status-activity-info.response.dto';

class Meta {
  @ApiProperty()
  @Expose()
  total: number;

  @ApiProperty()
  @Expose()
  page: number;

  @ApiProperty()
  @Expose()
  size: number;

  @ApiProperty()
  @Expose()
  serial: string;

  @ApiProperty()
  @Expose()
  totalOee: number;

  @ApiProperty()
  @Expose()
  deviceName: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  type: number;
}

export class DeviceStatusBySerialResponseDto extends SuccessResponse {
  @ApiProperty({ type: () => ListDeviceStatusActivityInfo, isArray: true })
  @Expose()
  items: ListDeviceStatusActivityInfo[];

  @ApiProperty({ type: () => Meta, example: Meta })
  @Expose()
  meta: Meta;
}
