import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsMongoId, IsOptional } from 'class-validator';

export class ListReportDeviceStatusQuery extends PaginationQuery {
  @ApiPropertyOptional({
    description: 'Id nhóm thiết bị',
  })
  @IsMongoId()
  @IsOptional()
  deviceGroupId: string;

  @ApiPropertyOptional({
    description: 'Id nhà máy',
  })
  @IsOptional()
  factoryId: number;

  @ApiPropertyOptional({
    description: 'Id xưởng',
  })
  @IsOptional()
  workCenterId: number;
}
