import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsMongoId, IsNumber, IsOptional } from 'class-validator';

export class ListReportDeviceAssignStatusQuery extends PaginationQuery {
  @ApiPropertyOptional({
    description: 'Id nhóm thiết bị',
  })
  @IsMongoId()
  @IsOptional()
  deviceGroupId: string;

  @ApiPropertyOptional({
    description: 'Id nhà máy',
  })
  @IsNumber()
  @IsOptional()
  factoryId: number;

  @ApiPropertyOptional({
    description: 'Id xưởng',
  })
  @IsNumber()
  @IsOptional()
  workCenterId: number;

  @ApiPropertyOptional({
    description: 'Id thiết bị',
  })
  @IsMongoId()
  @IsOptional()
  deviceId: number;

  @ApiPropertyOptional({
    description: 'Id người sử dụng',
  })
  @IsNumber()
  @IsOptional()
  assignUserId: number;
}
