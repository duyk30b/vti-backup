import { ApiProperty } from '@nestjs/swagger';
import { Meta } from '@utils/common.response';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

class ListReportDeviceStatus {
  @Expose()
  @ApiProperty({
    type: String,
  })
  deviceId: string;

  @Expose()
  @ApiProperty({
    type: String,
  })
  devideCode: string;

  @Expose()
  @ApiProperty({
    type: Number,
  })
  totalQuantity: number;

  @Expose()
  @ApiProperty({
    type: Number,
  })
  unUseQuantity: number;

  @Expose()
  @ApiProperty({
    type: Number,
  })
  usingQuantity: number;

  @Expose()
  @ApiProperty({
    type: Number,
  })
  returnedQuantity: number;

  @Expose()
  @ApiProperty({
    type: Number,
  })
  maintainQuantity: number;

  @Expose()
  @ApiProperty({
    type: Number,
  })
  scrapQuantity: number;
}

class DataListReportDeviceStatus {
  @Expose()
  @ApiProperty({
    type: ListReportDeviceStatus,
  })
  items: ListReportDeviceStatus;

  @Expose()
  @ApiProperty({
    type: Meta,
  })
  meta: Meta;
}

export class ListReportDeviceStatusResponse extends SuccessResponse {
  @Expose()
  @ApiProperty({
    type: DataListReportDeviceStatus,
  })
  data: DataListReportDeviceStatus;
}
