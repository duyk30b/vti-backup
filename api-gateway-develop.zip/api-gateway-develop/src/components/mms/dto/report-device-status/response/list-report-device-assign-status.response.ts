import { ApiProperty } from '@nestjs/swagger';
import { Meta } from '@utils/common.response';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

class ListReportDeviceAssignStatus {
  @Expose()
  @ApiProperty({
    type: String,
  })
  deviceAssignId: string;

  @Expose()
  @ApiProperty({
    type: String,
  })
  deviceName: string;

  @Expose()
  @ApiProperty({
    type: String,
  })
  serial: string;

  @Expose()
  @ApiProperty({
    type: String,
  })
  fullName: string;

  @Expose()
  @ApiProperty({
    type: Date,
  })
  usedAt: Date;

  @Expose()
  @ApiProperty({
    type: Number,
  })
  status: number;

  @Expose()
  @ApiProperty({
    type: Number,
  })
  numOfMaintain: number;

  @Expose()
  @ApiProperty({
    type: Number,
  })
  numOfError: number;
}

class DataListReportDeviceAssignStatus {
  @Expose()
  @ApiProperty({
    type: ListReportDeviceAssignStatus,
  })
  items: ListReportDeviceAssignStatus;

  @Expose()
  @ApiProperty({
    type: Meta,
  })
  meta: Meta;
}

export class ListReportDeviceAssignStatusResponse extends SuccessResponse {
  @Expose()
  @ApiProperty({
    type: DataListReportDeviceAssignStatus,
  })
  data: DataListReportDeviceAssignStatus;
}
