import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsEnum } from 'class-validator';
import { SupplyTypeConstant } from '@components/mms/constant/supply.constant';
import { GetHistoryDetailResponseDto } from '@components/mms/dto/history/dto/response/get-history-detail.response.dto';
import { DeviceType } from "@components/mms/constant/device.constant";

class DeviceGroup {
  @ApiProperty({
    example: 1,
    description: 'Id của nhóm thiết bị',
  })
  @Expose()
  id: number;

  @ApiProperty({
    example: 'ABC',
    description: 'Mã của nhóm thiết bị',
  })
  @Expose()
  code: string;

  @ApiProperty({
    example: 'ABC',
    description: 'Mã của nhóm thiết bị',
  })
  @Expose()
  name: string;
}
class factory {
  @ApiProperty({
    example: 1,
    description: 'Id của nhà máy',
  })
  @Expose()
  id: number;

  @ApiProperty({
    example: 'ABC',
    description: 'Mã của nhà máy',
  })
  @Expose()
  code: string;

  @ApiProperty({
    example: 'ABC',
    description: 'Mã của nhà máy',
  })
  @Expose()
  name: string;
}

class Supply {
  @ApiProperty({
    example: 1,
    description: 'Id của vật tư',
  })
  @Expose()
  id: number;

  @ApiProperty({
    example: 'ABC',
    description: 'Mã của vật tư thiết bị',
  })
  @Expose()
  code: string;

  @ApiProperty({
    example: 'ABC',
    description: 'Tên của vật tư thiết bị',
  })
  @Expose()
  name: string;

  @ApiProperty({ description: 'Sản phẩm', type: [factory], isArray: true })
  @Expose()
  @Type(() => factory)
  factory: factory[];

  @ApiProperty({
    example: 'ABC',
    description: 'Tên của vật tư thiết bị',
  })
  @Expose()
  @IsEnum(SupplyTypeConstant)
  type: SupplyTypeConstant;
}

export class DeviceResponseDto extends SuccessResponse {
  @ApiProperty({
    example: 1,
    description: 'Id của thiết bị',
  })
  @Expose()
  id: number;

  @ApiProperty({
    example: 'ABC',
    description: 'Mã của thiết bị',
  })
  @Expose()
  code: string;

  @ApiProperty({
    example: 'ABC',
    description: 'Tên của thiết bị',
  })
  @Expose()
  name: string;

  @ApiProperty({
    example: 'ABC',
    description: 'Mô tả của thiết bị',
  })
  @Expose()
  description: string;

  @ApiProperty({
    example: 'ABC',
    description: 'model of device',
  })
  @Expose()
  model: string;

  @ApiProperty({
    example: 20,
    description: 'Số lượng của thiết bị',
  })
  @Expose()
  quantity: number;

  @ApiProperty({
    example: '2021-11-25 16:00:00',
    description: 'Ngày tạo thiết bị',
  })
  @Expose()
  createAt: Date;

  @ApiProperty({
    example: '2021-11-25 16:00:00',
    description: 'Ngày sửa thiết bị',
  })
  @Expose()
  updateAt: Date;

  @ApiProperty({
    example: '100000',
    description: 'Giá của thiết bị',
  })
  @Expose()
  price: number;

  @ApiProperty({
    example: '',
    description: 'Type of Device',
  })
  @Expose()
  @IsEnum(DeviceType)
  type: DeviceType;

  @ApiProperty({
    example: '1',
    description: 'Id của người chịu trách nhiệm',
  })
  @Expose()
  responsibleUserId: string;
  @ApiProperty({
    example: '5',
    description: 'Thời gian kiểm tra định kỳ của sản phẩm',
  })
  @Expose()
  periodicInspectionTime: number;

  @ApiProperty({
    example: [
      {
        _id: '61a840a42de73432d39703e6',
        userId: 1,
        username: 'admin',
        action: 0,
        createdAt: '2021-12-01T10:20:04.571Z',
      },
    ],
    description: 'Lịch sử hành động',
  })
  @Expose()
  @Type(() => GetHistoryDetailResponseDto)
  histories: GetHistoryDetailResponseDto[];
}
