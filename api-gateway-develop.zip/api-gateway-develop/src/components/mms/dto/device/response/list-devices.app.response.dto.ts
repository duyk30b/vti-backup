import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class User {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  username: string;

  @ApiProperty()
  @Expose()
  fullname: string;
}

export class ListDevicesAppResponseDto {
  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  serial: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  @Type(() => User)
  assignmentUser: User;
}
