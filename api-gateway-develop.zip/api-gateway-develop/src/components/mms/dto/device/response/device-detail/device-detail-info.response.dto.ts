export class SupplyDto {
  id: string;
  code: string;
  name: string;
  unit: string;
}

export class DeviceSupplyDto {
  supply: SupplyDto;
  quantity: number;
  useDate: number;
}

export class MaintenanceAccessoryDto {
  supply: SupplyDto;
  quantity: number;
}

export class DeviceDetailInfoResponseDto {
  id: string;
  vendor: string;
  brand: string;
  deviceGroup: any;
  model: string;
  manufacturingDate: string;
  importDate: string;
  warrantyPeriod: number;
  supplies: DeviceSupplyDto[];
  accessories: MaintenanceAccessoryDto[];
}
