import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { BaseUserResponseDto } from '@components/user/dto/user/response/base.user.response.dto';
import { IsEnum } from 'class-validator';
import {
  DeviceStatus,
  DeviceType,
} from '@components/mms/constant/device.constant';

export class DeviceUsageDto {
  @ApiProperty()
  @Expose()
  @Type(() => BaseUserResponseDto)
  user: BaseUserResponseDto;
  @ApiProperty()
  @Expose()
  date: Date;
}

export class DeviceAssignmentDto {
  @ApiProperty()
  @Expose()
  serial: string;
  @ApiProperty()
  @Expose()
  date: Date;
}

class FactoryResponseDto {
  @ApiProperty()
  @Expose()
  id: number;
  @ApiProperty()
  @Expose()
  name: string;
  @ApiProperty()
  @Expose()
  code: string;
}

export class DeviceCommonInfoResponseDto {
  @ApiProperty({ example: '123', description: 'Id của device' })
  @Expose()
  id: string;
  @ApiProperty({ example: '123', description: 'Mã của device' })
  @Expose()
  code: string;
  @ApiProperty({ example: '123', description: 'Tên của device' })
  @Expose()
  name: string;
  @ApiProperty({ example: '123', description: 'Mô tả của device' })
  @Expose()
  description: string;
  @ApiProperty({ example: 1, description: 'Loại device' })
  @Expose()
  @IsEnum(DeviceType)
  type: number;
  @ApiProperty({
    example: {
      user: {
        id: 1,
        username: 'admin',
        fullName: 'Admin',
      },
      date: '2021-12-21T07:59:21.272Z',
    },
  })
  @Expose()
  @Type(() => DeviceUsageDto)
  deviceUsage: DeviceUsageDto;
  @ApiProperty({
    example: {
      serial: '61c17e563edf369ea06ab801',
      date: '2021-12-21T07:59:21.272Z',
    },
  })
  @Expose()
  @Type(() => DeviceAssignmentDto)
  deviceAssignment: DeviceAssignmentDto;

  @ApiProperty({
    example: {
      id: 19,
      name: 'Nhà máy dệt',
      code: 'A002',
    },
  })
  @Expose()
  @Type(() => FactoryResponseDto)
  factory: FactoryResponseDto;

  @ApiProperty({
    example: {
      id: 1,
      username: 'admin',
      fullName: 'Admin',
    },
  })
  @Expose()
  @Type(() => BaseUserResponseDto)
  responsibleUser: BaseUserResponseDto;

  @ApiProperty({ example: 1, description: 'trạng thái' })
  @Expose()
  @IsEnum(DeviceStatus)
  status: number;

  @ApiProperty({ example: 1, description: 'oee mục tiêu' })
  @Expose()
  oee: number;

  @ApiProperty({ example: 1, description: 'năng suất mục tiêu' })
  @Expose()
  productivityTarget: number;

  @ApiProperty({
    example: {
      id: 1,
      name: 'xưởng dệt',
      code: 'X001',
    },
  })
  @Expose()
  workCenter: FactoryResponseDto;
}
