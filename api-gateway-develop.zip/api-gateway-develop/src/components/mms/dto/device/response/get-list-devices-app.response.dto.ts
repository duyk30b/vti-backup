import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { ListDevicesAppResponseDto } from '@components/mms/dto/device/response/list-devices.app.response.dto';

class Meta {
  @Expose()
  total: number;

  @Expose()
  page: number;
}

class MetaData {
  @Expose()
  data: ListDevicesAppResponseDto[];

  @Expose()
  meta: Meta;
}

export class GetListDevicesAppResponseDto extends SuccessResponse {
  @ApiProperty({
    example: {
      items: [
        {
          id: '61b9c492af6a5878696dd0d5',
          code: 'C003',
          serial: '123456789',
          name: 'Máy PC Dell Vostro 4',
          estimatedMaintenance: 16,
          assignmentUser: {
            id: 1,
            username: 'admin',
            fullName: 'Admin',
            factory: 'Nhà máy',
            phone: '03910391',
            workCenter: 'Xưởng',
          },
          type: 1,
        },
      ],
      meta: {
        total: 1,
      },
    },
  })
  @Expose()
  data: MetaData;
}
