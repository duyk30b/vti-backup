import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
class GetMaintainInfo {
  @Expose()
  name: string;

  @Expose()
  estMaintenanceDate: Date;

  @Expose()
  estReplaceDate: Date;

  @Expose()
  mttrIndex: number;

  @Expose()
  mttaIndex: number;

  @Expose()
  mttfIndex: number;

  @Expose()
  mtbfIndex: number;
}

export class DeviceMaintenanceInfoAppDto {
  @ApiProperty()
  @Expose()
  name: string;

  @Expose()
  estMaintenanceDate: Date;

  @Expose()
  estReplaceDate: Date;

  @Expose()
  mttrIndex: number;

  @Expose()
  mttaIndex: number;

  @Expose()
  mttfIndex: number;

  @Expose()
  mtbfIndex: number;

  @Expose()
  @Type(() => GetMaintainInfo)
  supplies: GetMaintainInfo[];
}
export class DeviceMaintenanceInfoAppResponseDto extends SuccessResponse {
  @ApiPropertyOptional({
    example: {
      code: 'VNA43',
      name: 'Chải',
      mtbfIndex: 5,
      mttaIndex: 5,
      mttfIndex: 5,
      mttrIndex: 5,
      supplies: [
        {
          code: 'VNA43',
          name: 'Phụ tùng 01',
          estMaintenanceDate: '2022-01-15T01:40:32.130Z',
          estReplaceDate: '2022-01-15T01:40:32.130Z',
          mtbfIndex: '6',
          mttaIndex: '6',
          mttfIndex: '6',
          mttrIndex: '6',
        },
        {
          code: 'VNA43',
          name: 'Vật tư 01',
          estMaintenanceDate: '2022-01-15T01:40:32.130Z',
          estReplaceDate: '2022-01-15T01:40:32.130Z',
          mtbfIndex: '6',
          mttaIndex: '6',
          mttfIndex: '6',
          mttrIndex: '6',
        },
      ],
    },
  })
  @Expose()
  data: DeviceMaintenanceInfoAppDto;
}
