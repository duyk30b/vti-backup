import { WorkCenterDto } from '@components/produces/dto/response/detail-plan.response';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class ShiftDetailDto {
  @ApiProperty({ description: 'Thời gian làm việc' })
  @Expose()
  workTime: number;

  @ApiProperty({ description: 'Thời gian nghỉ nghỉ' })
  @Expose()
  relaxTime: number;
}

export class ShiftDto {
  @ApiProperty({ description: 'Id ca' })
  id: number;

  @ApiProperty({ description: 'Tên ca' })
  name: string;

  @ApiProperty({ description: 'Ngày' })
  date: string;

  @ApiProperty({
    description: 'Danh sách thời gian các ca gồm ca làm việc và ca nghỉ',
  })
  shiftDetail: ShiftDetailDto;
}

export class WorkOrderDto {
  @ApiProperty({ description: 'Id lệnh làm việc' })
  id: number;

  @ApiProperty({ description: 'Mã lệnh làm việc' })
  code: string;

  @ApiProperty({ description: 'Tên lệnh làm việc' })
  name: string;

  @ApiProperty({ description: 'Thời gian làm việc từ ngày' })
  dateFrom: string;

  @ApiProperty({ description: 'Thời gina làm việc đến ngày' })
  dateTo: string;

  @ApiProperty({ description: 'Danh sách ca' })
  shifts: ShiftDto[];
}

export class ManufacturingOrderDto {
  @ApiProperty({ description: 'Id lệnh sản xuất' })
  id: number;

  @ApiProperty({ description: 'Mã lệnh sản xuất' })
  code: string;

  @ApiProperty({ description: 'Tên lệnh sản xuất' })
  name: string;

  @ApiProperty({ description: 'Danh sách lệnh làm việc' })
  workOrders: WorkOrderDto[];
}

export class DeviceManufacturingInfoResponseDto {
  @ApiProperty({ description: 'Xưởng' })
  workCenter: WorkCenterDto;

  @ApiProperty({ description: 'Chỉ số OEE' })
  oeeIndex: string;

  @ApiProperty({ description: 'Lệnh làm việc' })
  manufacturingOrder: ManufacturingOrderDto;
}
