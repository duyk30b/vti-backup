import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { DeviceResponseDto } from '@components/mms/dto/device/response/device.response.dto';
import { DeviceStatus } from '@components/mms/constant/device.constant';

class Meta {
  @Expose()
  total: number;

  @Expose()
  page: number;
}

export class GetListDeviceDeviceGroupDto {
  @ApiProperty({ description: 'Id nhóm thiết bị' })
  _id: string;

  @ApiProperty({ description: 'Tên nhóm thiết bị' })
  name: string;
}

export class GetListDeviceDataDto {
  @ApiProperty({ description: 'Id thiết bị' })
  _id: string;

  @ApiProperty({ description: 'Mã thiết bị' })
  code: string;

  @ApiProperty({ description: 'Tên thiết bị' })
  name: string;

  @ApiProperty({ description: 'Mô tả thiết bị' })
  description: string;

  @ApiProperty({ description: 'Trạng thái thiết bị', enum: DeviceStatus })
  status: DeviceStatus;

  @ApiProperty({ description: 'Nhóm thiết bị' })
  deviceGroupId: GetListDeviceDeviceGroupDto;

  @ApiProperty({ description: 'Ngày tạo' })
  createdAt: Date;

  @ApiProperty({ description: 'Ngày chỉnh sửa' })
  updatedAt: Date;
}

class MetaData {
  @Expose()
  data: [];

  @Expose()
  meta: Meta;
}

export class GetListDeviceResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  MetaData: MetaData;
}
