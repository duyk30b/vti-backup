import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class DeviceMaintenanceHistoryAppDto {
  @ApiProperty()
  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  executionDateTo: Date;

  @Expose()
  maintenanceType: number;
}
export class DeviceMaintenanceHistoryAppResponseDto extends SuccessResponse {
  @ApiPropertyOptional({
    example: [
      {
        id: '61b9fbb25179fda57498c435',
        code: 'VNA43',
        name: 'Bảo trì chân đạp',
        executionDateTo: '2022-02-20T13:22:14.280Z',
        maintenanceType: 0,
      },
      {
        id: '61b9fbb25179fda57498c435',
        code: 'VNA434',
        name: 'Bảo trì chân đạp 2',
        executionDateTo: '2022-02-20T13:22:14.280Z',
        maintenanceType: 0,
      },
    ],
    description: 'Lịch sử bảo trì',
  })
  @Expose()
  data: DeviceMaintenanceHistoryAppDto;
}
