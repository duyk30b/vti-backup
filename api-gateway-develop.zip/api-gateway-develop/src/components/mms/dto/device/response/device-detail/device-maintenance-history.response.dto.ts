export class DeviceMaintenanceHistoryResponseDto {
  id: string;
  code: string;
  name: string;
  executionAt: string;
  type: string;
}
