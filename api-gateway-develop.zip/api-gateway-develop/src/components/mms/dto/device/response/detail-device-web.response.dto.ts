import {
  DeviceStatus,
  DeviceType,
  ResponsibleSubjectType,
} from '@components/mms/constant/device.constant';
import { ApiProperty } from '@nestjs/swagger';
import { SupplyTypeConstant } from '@components/mms/constant/supply.constant';

export class MaintenanceAttributeDto {
  @ApiProperty({
    description: 'Id thuộc tính bảo trì',
  })
  id: string;

  @ApiProperty({
    description: 'Tên thuộc tính bảo trì',
  })
  name: string;
}

export class FactoryDto {
  @ApiProperty({
    description: 'Id nhà máy',
  })
  id: number;

  @ApiProperty({
    description: 'Tên nhà máy',
  })
  name: string;
}

export class DeviceGroupDto {
  @ApiProperty({
    description: 'Id nhóm thiết bị',
  })
  id: string;

  @ApiProperty({
    description: 'Tên nhóm thiết bị',
  })
  name: string;
}

export class MaintenanceInfoDto {
  @ApiProperty({
    description: 'Tần suất bảo trì',
  })
  maintenancePeriod: number;

  @ApiProperty({
    description: 'Chỉ số MTTR',
  })
  mttrIndex: number;

  @ApiProperty({
    description: 'Chỉ số MTTA',
  })
  mttaIndex: number;

  @ApiProperty({
    description: 'Chỉ số MTTF',
  })
  mttfIndex: number;

  @ApiProperty({
    description: 'Chỉ số MTBF',
  })
  mtbfIndex: number;
}

export class SupplyDto {
  @ApiProperty({
    description: 'Id vật tư || phụ tùng',
  })
  id: string;

  @ApiProperty({
    description: 'Tên vật tư || phụ tùng',
  })
  name: string;

  @ApiProperty({
    enum: SupplyTypeConstant,
  })
  type: SupplyTypeConstant;
}

export class DeviceSupplyDto {
  @ApiProperty({
    description: 'Vật tư || phụ tùng',
  })
  supply: SupplyDto;

  @ApiProperty({
    description: 'Số lượng',
  })
  quantity: number;

  @ApiProperty({
    description: 'Thời lượng sử dụng',
  })
  useDate: number;
}

export class AccessoriesMaintenanceInformationDto extends MaintenanceInfoDto {
  @ApiProperty({
    description: 'Vật tư',
  })
  supply: SupplyDto;
}

export class ResponsibleSubjectDto {
  @ApiProperty({
    description: 'Id người chịu trách nhiệm / đội bảo trì',
  })
  id: string | number;

  @ApiProperty({
    description: 'Tên người chịu trách nhiệm / đội bảo trì',
  })
  name: string;

  @ApiProperty({
    enum: ResponsibleSubjectType,
  })
  type: ResponsibleSubjectType;
}

export class DetailDeviceWebResponseDto extends MaintenanceInfoDto {
  @ApiProperty({
    description: 'Id thiết bị',
  })
  id: string;

  @ApiProperty({
    description: 'Mã thiết bị',
  })
  code: string;

  @ApiProperty({
    description: 'Tên thiết bị',
  })
  name: string;

  @ApiProperty({
    description: 'Mô tả thiết bị',
  })
  description: string;

  @ApiProperty({
    description: 'Model thiết bị',
  })
  model: string;

  @ApiProperty({
    description: 'Giá',
  })
  price: number;

  @ApiProperty({
    description: 'Trạng thái thiết bị',
    enum: DeviceStatus,
  })
  status: DeviceStatus;

  @ApiProperty({
    description: 'Nhóm thiết bị',
    type: DeviceGroupDto,
  })
  deviceGroup: DeviceGroupDto;

  @ApiProperty({
    description: 'Loại thiết bị',
    enum: DeviceType,
  })
  type: DeviceType;

  @ApiProperty({
    description: 'Nhà máy',
  })
  factory: FactoryDto;

  @ApiProperty({
    description: 'Thuộc tính bảo trì',
  })
  maintenanceAttribute: MaintenanceAttributeDto;

  @ApiProperty({
    description: 'Kiểm tra định kì sau',
  })
  periodicInspectionTime: number;

  @ApiProperty({
    description: 'Nhà cung cấp',
  })
  vendor: string;

  @ApiProperty({
    description: 'Hãng sản xuất',
  })
  brand: string;

  @ApiProperty({
    description: 'Ngày sản xuất',
  })
  productionDate: Date;

  @ApiProperty({
    description: 'Ngày nhập',
  })
  importDate: Date;

  @ApiProperty({
    description: 'Thời hạn bảo hành',
  })
  warrantyPeriod: number;

  @ApiProperty({
    description: 'Thông tin bảo hành phụ tùng',
    type: [AccessoriesMaintenanceInformationDto],
  })
  accessoriesMaintenanceInformation: AccessoriesMaintenanceInformationDto[];

  @ApiProperty({
    description: 'Danh sách vật tư && phụ tùng',
    type: [DeviceSupplyDto],
  })
  suppliesAndAccessories: DeviceSupplyDto[];

  @ApiProperty({
    description: 'Người chịu trách nhiệm || đội bảo trì',
    type: [ResponsibleSubjectDto],
  })
  responsibleSubject: ResponsibleSubjectDto;

  @ApiProperty({
    description: 'Lịch sử',
  })
  histories: History[];
}
