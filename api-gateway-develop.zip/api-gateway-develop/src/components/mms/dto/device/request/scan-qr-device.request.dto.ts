import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';
import { Expose } from 'class-transformer';

export class ScanQrDeviceRequestDto {
  @ApiProperty({
    description: 'QR Code',
  })
  @Expose()
  @IsNotEmpty()
  @IsString()
  qrCode: string;
}
