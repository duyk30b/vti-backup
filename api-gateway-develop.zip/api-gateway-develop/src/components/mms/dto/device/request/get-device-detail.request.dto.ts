import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class GetDeviceDetailRequestDto {
  @ApiProperty({
    example: '1',
    description: 'id của thiết bị',
  })
  @Expose()
  id: number;
}