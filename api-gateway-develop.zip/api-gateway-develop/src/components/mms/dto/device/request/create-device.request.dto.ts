import { ApiProperty } from '@nestjs/swagger';
import {
  DeviceType,
  ResponsibleSubjectType,
} from '@components/mms/constant/device.constant';
import { MIN_POSITIVE_VALUE } from '@constant/common';

export class CreateMaintenanceInfoDto {
  @ApiProperty({ description: 'Tần suất bảo trì', minimum: MIN_POSITIVE_VALUE })
  maintenancePeriod: number;

  @ApiProperty({ description: 'Chỉ số MTTR', minimum: MIN_POSITIVE_VALUE })
  mttrIndex: number;

  @ApiProperty({ description: 'Chỉ số MTTA', minimum: MIN_POSITIVE_VALUE })
  mttaIndex: number;

  @ApiProperty({ description: 'Chỉ số MTTF', minimum: MIN_POSITIVE_VALUE })
  mttfIndex: number;

  @ApiProperty({ description: 'Chỉ số MTBF', minimum: MIN_POSITIVE_VALUE })
  mtbfIndex: number;
}

export class CreateSupplyDto {
  @ApiProperty({ description: 'Id vật tư, phụ tùng' })
  supplyId: string;

  @ApiProperty({ description: 'Số lượng', minimum: MIN_POSITIVE_VALUE })
  quantity: number;

  @ApiProperty({
    description: 'Thời lượng sử dụng',
    minimum: MIN_POSITIVE_VALUE,
  })
  useDate: number;

  @ApiProperty({ description: 'Có thể sửa chữa khi hỏng' })
  canRepair: boolean;
}

export class CreateAccessoriesMaintenanceInformationDto extends CreateMaintenanceInfoDto {
  @ApiProperty({ description: 'Id phụ tùng' })
  supplyId: string;
}

export class ResponsibleSubjectDto {
  @ApiProperty({
    description: 'Id người / team bảo trì chịu trách nhiệm',
    type: String || Number,
  })
  id: string | number;

  @ApiProperty({
    type: ResponsibleSubjectType,
    enum: ResponsibleSubjectType,
  })
  type: ResponsibleSubjectType;
}

export class CreateDeviceRequestDto extends CreateMaintenanceInfoDto {
  @ApiProperty({ description: 'Mã' })
  code: string;

  @ApiProperty({ description: 'Tên' })
  name: string;

  @ApiProperty({ description: 'Mô tả' })
  description: string;

  @ApiProperty({ description: 'Model' })
  model: string;

  @ApiProperty({ description: 'Giá', minimum: MIN_POSITIVE_VALUE })
  price: number;

  @ApiProperty({ description: 'Id nhóm thiết bị' })
  deviceGroupId: string;

  @ApiProperty({
    description: 'Loại thiết bị',
    type: DeviceType,
    enum: DeviceType,
  })
  type: DeviceType;

  @ApiProperty({ description: 'Id nhà máy', minimum: MIN_POSITIVE_VALUE })
  factoryId: number;

  @ApiProperty({ description: 'Id thuộc tính bảo trì' })
  maintenanceAttributeId: string;

  @ApiProperty({
    description: 'Kiểm tra định kì sau',
    minimum: MIN_POSITIVE_VALUE,
  })
  periodicInspectionTime: number;

  @ApiProperty({ description: 'Nhà cung cấp' })
  vendor: string;

  @ApiProperty({ description: 'Hãng sản xuất' })
  brand: string;

  @ApiProperty({ description: 'Ngày sản xuất' })
  productionDate: Date;

  @ApiProperty({ description: 'Ngày nhập' })
  importDate: Date;

  @ApiProperty({
    description: 'Thời hạn bảo hành',
    minimum: MIN_POSITIVE_VALUE,
  })
  warrantyPeriod: number;

  @ApiProperty({
    description: 'Danh sách thông tin bảo trì của phụ tùng',
    type: [CreateAccessoriesMaintenanceInformationDto],
  })
  accessoriesMaintenanceInformation: CreateAccessoriesMaintenanceInformationDto[];

  @ApiProperty({
    description: 'Danh sách vật tư, phụ tùng',
    type: [CreateSupplyDto],
  })
  suppliesAndAccessories: CreateSupplyDto[];

  @ApiProperty({
    description: 'Chịu trách nhiệm bởi',
    type: ResponsibleSubjectDto,
  })
  responsibleSubject: ResponsibleSubjectDto;

  @ApiProperty({
    description: 'Loại giá trị',
  })
  attributeType: string[];

  @ApiProperty({
    description: 'Mẫu phiếu lắp đặt',
  })
  installTemplate: string;

  @ApiProperty({ description: 'Có thể sửa chữa khi hỏng' })
  canRepair: boolean;
}
