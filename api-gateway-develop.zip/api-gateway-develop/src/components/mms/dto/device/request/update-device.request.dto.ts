import { CreateDeviceRequestDto } from '@components/mms/dto/device/request/create-device.request.dto';
import { ApiProperty } from '@nestjs/swagger';

export class UpdateDeviceRequestDto extends CreateDeviceRequestDto {
  @ApiProperty({
    description: 'Id thiết bị',
  })
  id: string;
}
