import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray, IsEnum, IsInt, IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';
import { CheckListTemplateDetailResponseDto } from '@components/mms/dto/check-list-template-detail/dto/response/check-list-template-detail.response.dto';
import { CHECK_LIST_TEMPLATE_CONST } from '@components/mms/constant/check-list-template.constant';

export class CreateCheckListTemplateRequestDto {
  @ApiProperty({ example: 'ABC123', description: 'Code của mẫu phiếu báo cáo' })
  @Expose()
  @IsNotEmpty()
  @IsString()
  @MaxLength(CHECK_LIST_TEMPLATE_CONST.CODE.MAX_LENGTH)
  code: string;

  @ApiProperty({ example: 'ABC123', description: 'Tên của mẫu phiếu báo cáo' })
  @Expose()
  @IsNotEmpty()
  @IsString()
  @MaxLength(CHECK_LIST_TEMPLATE_CONST.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: 'Mô tả', description: 'Mô tả' })
  @Expose()
  @IsOptional()
  @IsString()
  @MaxLength(CHECK_LIST_TEMPLATE_CONST.DESCRIPTION.MAX_LENGTH)
  description: string;

  @ApiProperty({ example: 'Mô tả', description: 'Id Thiết Bị' })
  @Expose()
  @IsOptional()
  @IsNotEmpty()
  @IsString()
  deviceId: string;

  @ApiProperty({ example: 'Mô tả', description: 'Loại kiểm tra' })
  @Expose()
  @IsOptional()
  @IsNotEmpty()
  @IsInt()
  checkType: number;

  @ApiProperty({ example: 0, description: 'Chi tiết' })
  @Expose()
  @IsArray()
  @IsNotEmpty()
  @Type(() => CheckListTemplateDetailResponseDto)
  details: CheckListTemplateDetailResponseDto[];
}