import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';
import { CheckListTemplateResponseDto } from '@components/mms/dto/check-list-template/response/check-list-template.response.dto';
import { ApiProperty } from '@nestjs/swagger';
class Meta {
  @Expose()
  total: number;

  @Expose()
  page: number;
}

class MetaData {
  @Expose()
  data: CheckListTemplateResponseDto[];

  @Expose()
  meta: Meta;
}
export class GetListCheckListTemplateResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: MetaData;
}