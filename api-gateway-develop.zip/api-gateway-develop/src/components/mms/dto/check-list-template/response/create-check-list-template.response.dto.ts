import { CheckListTemplateResponseDto } from '@components/mms/dto/check-list-template/response/check-list-template.response.dto';

export class CreateCheckListTemplateResponseDto extends CheckListTemplateResponseDto {}