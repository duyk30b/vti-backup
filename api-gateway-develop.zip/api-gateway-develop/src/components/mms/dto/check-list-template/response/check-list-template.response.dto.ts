import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { CheckListTemplateDetailResponseDto } from '@components/mms/dto/check-list-template-detail/dto/response/check-list-template-detail.response.dto';

export class CheckListTemplateResponseDto {
  @ApiProperty({ example: '61a8974b4711d21f394d57ff', description: 'Code của mẫu phiếu báo cáo' })
  @Expose()
  _id: string;

  @ApiProperty({ example: 'ABC123', description: 'Code của mẫu phiếu báo cáo' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'ABC123', description: 'Tên của mẫu phiếu báo cáo' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'Mô tả', description: 'Mô tả' })
  @Expose()
  description: string;

  @ApiProperty({ example: 'Mô tả', description: 'Id Thiết Bị' })
  @Expose()
  deviceId: string;

  @ApiProperty({ example: 'Mô tả', description: 'Loại kiểm tra' })
  @Expose()
  checkType: number;

  @ApiProperty({ example: 0, description: 'Chi tiết' })
  @Expose()
  @Type(() => CheckListTemplateDetailResponseDto)
  details: CheckListTemplateDetailResponseDto[];
}