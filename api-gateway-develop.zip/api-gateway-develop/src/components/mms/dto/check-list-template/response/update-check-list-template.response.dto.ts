import { CheckListResponseDto } from '@components/quality-control/dto/check-list/response/check-list.response.dto';

export class UpdateCheckListTemplateResponseDto extends CheckListResponseDto {}