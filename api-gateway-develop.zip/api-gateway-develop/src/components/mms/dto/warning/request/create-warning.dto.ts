import { ApiProperty } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsString,
  IsDateString,
  IsOptional,
  MaxLength,
  IsNumber,
} from 'class-validator';
export class SuppliesDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  supplyId: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  quantity: number;
}
export class CreateWarningDto {
  @ApiProperty({
    example: 1,
    description: 'Id lỗi',
  })
  @IsNotEmpty()
  @IsString()
  defectId: string;

  @ApiProperty({
    description: 'Ngày kì vọng hoàn thành',
  })
  @IsNotEmpty()
  @IsDateString()
  completeExpectedDate: Date;

  @ApiProperty({
    description: 'Mô tả',
    required: false,
  })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;

  @ApiProperty({
    description: '',
  })
  @IsNotEmpty()
  @IsString()
  deviceAssignmentId: string;

  @ApiProperty({ type: [SuppliesDto], required: false })
  @IsOptional()
  supplies: SuppliesDto;

  @ApiProperty({
    description: 'Ngày đến lịch bảo trì',
    required: false,
  })
  @IsOptional()
  @IsDateString()
  maintenanceArrivalDate: Date;
}
