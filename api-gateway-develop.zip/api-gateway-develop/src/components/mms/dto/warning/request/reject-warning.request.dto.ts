import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString, MaxLength } from 'class-validator';
export class RejectWarningRequestDto {
  @ApiProperty({ example: 'reason' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(500)
  reason: string;
}
