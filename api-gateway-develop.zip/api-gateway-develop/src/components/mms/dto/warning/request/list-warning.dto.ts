import { PaginationQuery } from '@utils/pagination.query';

export class GetListWarningRequestDto extends PaginationQuery {}
