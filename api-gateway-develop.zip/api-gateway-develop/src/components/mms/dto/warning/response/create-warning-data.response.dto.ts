import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { CreateWaringResponseDto } from '@components/mms/dto/warning/response/create-warning.response.dto';

export class CreateWarningDataResponseDto extends SuccessResponse {
  @ApiProperty({
    example: {
      id: 'string',
      defectId: 'string',
      completeExpectedDate: '2021-11-30T11:32:36.041Z',
      description: 'string',
      status: 0,
      executionDate: '2021-11-30T11:32:36.041Z',
      type: 0,
      deviceAssignmentId: 'string',
      supplies: [
        {
          "supplyId": "string",
          "quantity": 0
        }
      ],
      maintenanceArrivalDate: "2021-12-03T12:18:34.389Z",
      createdAt: '2021-11-30T11:32:36.041Z',
      updatedAt: '2021-11-30T11:32:36.041Z',
    },
  })
  @Expose()
  data: CreateWaringResponseDto;
}
