import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
export class SuppliesDto {
  @ApiProperty()
  @Expose()
  supplyId: string;

  @ApiProperty()
  @Expose()
  quantity: number;
}
export class CreateWaringResponseDto {
  @ApiProperty()
  @Expose({ name: 'id' })
  id: string;

  @ApiProperty()
  @Expose()
  defectId: string;

  @ApiProperty()
  @Expose()
  completeExpectedDate: Date;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  deviceAssignmentId: string;

  @ApiProperty({ type: [SuppliesDto] })
  @Expose()
  supplies: SuppliesDto;

  @ApiProperty({
    description: 'Ngày đến lịch bảo trì',
  })
  @Expose()
  maintenanceArrivalDate: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;
}
