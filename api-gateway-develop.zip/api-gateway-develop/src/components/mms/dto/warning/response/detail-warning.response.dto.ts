import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { DetailDeviceAssignmentResponse } from '../../job/response/list-job-by-device.response.dto';

export class DetailUser {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  email: string;

  @ApiProperty()
  @Expose()
  username: string;

  @ApiProperty()
  @Expose()
  fullName: string;

  @ApiProperty()
  @Expose()
  companyId: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  phone: string;
}

export class SuppliesDto {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  quantity: number;
}

export class DetailFactory {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  location: string;

  @ApiProperty()
  @Expose()
  companyId: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  phone: string;

  @ApiProperty()
  @Expose()
  status: number;
}

export class DetailCompany {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  address: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  email: string;

  @ApiProperty()
  @Expose()
  taxNo: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  phone: string;

  @ApiProperty()
  @Expose()
  status: number;
}

class DefectItem {
  @ApiProperty({ example: '01' })
  @Expose()
  id: string;

  @ApiProperty({ example: 'A01' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'Test' })
  @Expose()
  name: string;
}
export class DetailWarningResponse {
  @ApiProperty({ example: '61cd33d9be1e9a1ae9479661' })
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  @Type(() => DefectItem)
  defect: DefectItem;

  @ApiProperty({ example: '2021-11-30T00:00:00.000Z' })
  @Expose()
  completeExpectedDate: Date;

  @ApiProperty({ example: 'no desc' })
  @Expose()
  description: string;

  @ApiProperty({ example: 1 })
  @Expose()
  status: number;

  @ApiProperty({ example: 1 })
  @Expose()
  priority: number;

  @ApiProperty({ example: 'WO-61cd33d9be1e9a1ae9479661' })
  @Expose()
  code: string;

  @ApiProperty({ example: '2021-11-30T00:00:00.000Z' })
  @Expose()
  executionDate: Date;

  @ApiProperty({ example: 1 })
  @Expose()
  type: number;

  @ApiProperty({ type: DetailDeviceAssignmentResponse })
  @Expose()
  @Type(() => DetailDeviceAssignmentResponse)
  deviceAssignment: DetailDeviceAssignmentResponse;

  @ApiProperty({ type: SuppliesDto, isArray: true })
  @Expose()
  supplies: SuppliesDto[];

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;
}
