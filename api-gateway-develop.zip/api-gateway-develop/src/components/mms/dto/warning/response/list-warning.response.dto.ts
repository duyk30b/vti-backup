import { ApiProperty } from '@nestjs/swagger';
import { PagingResponse } from '@utils/paging.response';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { SuccessResponse } from '@utils/success.response.dto';
import { DetailDeviceAssignmentResponse } from '../../job/response/list-job-by-device.response.dto';

class WarningItem {
  @Expose()
  id: number;

  @Expose()
  @ApiProperty({})
  code: string;

  @Expose()
  @ApiProperty({})
  name: string;

  @Expose()
  @ApiProperty({})
  description: string;

  @Expose()
  @ApiProperty({})
  status: number;

  @Expose()
  @ApiProperty({})
  priority: number;

  @Expose()
  @ApiProperty({})
  type: number;

  @Expose()
  @ApiProperty({ type: DetailDeviceAssignmentResponse })
  @Type(() => DetailDeviceAssignmentResponse)
  deviceAssignment: DetailDeviceAssignmentResponse;

  @Expose()
  @ApiProperty({})
  createdAt: Date;
}

export class ListWarning extends PagingResponse {
  @Expose()
  @ApiProperty({ type: WarningItem, isArray: true })
  @Type(() => WarningItem)
  @IsArray()
  items: WarningItem[];
}
export class ListWarningResponse extends SuccessResponse {
  @Expose()
  @ApiProperty({ type: ListWarning })
  @Type(() => ListWarning)
  data: ListWarning;
}
