import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import {
  IsArray,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import { SUPPLY_GROUP_CONST, SupplyGroupStatusConstant } from '@components/mms/constant/supply-group.constant';


export class UpdateSupplyGroupRequestDto {
  @ApiProperty({ example: 'ABC123', description: 'Tên của nhóm vật tư' })
  @Expose()
  @IsNotEmpty()
  @IsString()
  @MaxLength(SUPPLY_GROUP_CONST.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: [1], description: 'Người chịu trách nhiệm' })
  @Expose()
  @IsNotEmpty()
  @ValidateNested()
  @IsArray()
  responsibleUserIds: number[];

  @ApiProperty({ example: 1, description: 'Người chịu trách nhiệm là đội bảo trì' })
  @Expose()
  @IsString()
  @IsOptional()
  responsibleMaintenanceTeam: string;

  @ApiProperty({ example: 'Mô tả', description: 'Mô tả' })
  @Expose()
  @IsOptional()
  @IsString()
  @MaxLength(SUPPLY_GROUP_CONST.DESCRIPTION.MAX_LENGTH)
  description: string;
}