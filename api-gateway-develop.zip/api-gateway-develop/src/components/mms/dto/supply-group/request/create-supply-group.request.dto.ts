import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';
import { Expose } from 'class-transformer';
import {
  SUPPLY_GROUP_CONST,
  SupplyGroupStatusConstant,
} from '@components/mms/constant/supply-group.constant';

export class CreateSupplyGroupRequestDto {
  @ApiProperty({ example: 'ABC123', description: 'Code của nhóm vật tư' })
  @Expose()
  @IsNotEmpty()
  @IsString()
  @MaxLength(SUPPLY_GROUP_CONST.CODE.MAX_LENGTH)
  code: string;

  @ApiProperty({ example: 'ABC123', description: 'Tên của nhóm vật tư' })
  @Expose()
  @IsNotEmpty()
  @IsString()
  @MaxLength(SUPPLY_GROUP_CONST.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: [1], description: 'Người chịu trách nhiệm' })
  @Expose()
  @IsNotEmpty()
  @IsArray()
  responsibleUserIds: number[];

  @ApiProperty()
  @Expose()
  @IsString()
  @IsOptional()
  responsibleMaintenanceTeam: string;

  @ApiProperty({ example: 'Mô tả', description: 'Mô tả' })
  @Expose()
  @IsString()
  @IsOptional()
  @MaxLength(SUPPLY_GROUP_CONST.DESCRIPTION.MAX_LENGTH)
  description: string;
}