import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class SupplyGroupResponseDto extends SuccessResponse {
  @ApiProperty({
    example: 1,
    description: 'Id nhóm vật tư' })
  @Expose()
  id: number;

  @ApiProperty({
    example: 'ABC',
    description: 'Mã nhóm vật tư',
  })
  @Expose()
  code: string;

  @ApiProperty({
    example: 'ABC',
    description: 'Tên nhóm vật tư',
  })
  @Expose()
  name: string;

  @ApiProperty({
    example: 'ABC',
    description: 'Mô tả nhóm vật tư',
  })
  @Expose()
  description: string;

  @ApiProperty({
    example: 'ABC',
    description: 'Danh sách người chịu trách nhiệm',
  })
  @Expose()
  responsibleUserIds: number[];

  @ApiProperty({
    example: 'ABC',
    description: 'Trạng thái nhóm vật tư',
  })
  @Expose()
  status: number;

  @ApiProperty({
    example: '2021-11-25 09:13:15.562609+00',
    description: 'Ngày tạo nhóm vật tư',
  })
  @Expose()
  createAt: Date;

  @ApiProperty({
    example: '2021-11-25 09:13:15.562609+00',
    description: 'Ngày cập nhật nhóm vật tư',
  })
  @Expose()
  updateAt: Date;
}