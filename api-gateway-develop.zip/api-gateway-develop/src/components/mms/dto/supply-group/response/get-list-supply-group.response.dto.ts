import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { SupplyGroupResponseDto } from '@components/mms/dto/supply-group/response/supply-group.response.dto';
class Meta {
  @Expose()
  total: number;

  @Expose()
  page: number;
}

class MetaData {
  @Expose()
  data: SupplyGroupResponseDto[];

  @Expose()
  meta: Meta;
}
export class GetListSupplyGroupResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  MetaData: MetaData;
}