import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class GetListSupplyGroupConfirmResponseDto {
  @ApiProperty()
  @Expose()
  _id: string;

  @ApiProperty()
  @Expose()
  name: string;
}