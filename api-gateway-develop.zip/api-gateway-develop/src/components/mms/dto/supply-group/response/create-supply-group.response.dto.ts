import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { IsArray } from 'class-validator';

export class CreateSupplyGroupResponseDto extends SuccessResponse {
  @ApiProperty({
    example: '61a6f6498e1f824efce559a4',
    description: 'id của nhóm vật tư',
  })
  @Expose()
  _id: string;

  @ApiProperty({ example: 'ABC123', description: 'Code của nhóm vật tư' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'ABC123', description: 'tên của nhóm vật tư' })
  @Expose()
  name: string;

  @ApiProperty({ example: [1, 2, 3], description: 'Ds người chịu trách nhiệm' })
  @Expose()
  @IsArray()
  responsibleUserIds: number[];

  @ApiProperty({ example: 'Mô tả', description: 'Mô tả' })
  @Expose()
  description: string;

  @ApiProperty({ example: 0, description: 'Status' })
  @Expose()
  status: number;
}