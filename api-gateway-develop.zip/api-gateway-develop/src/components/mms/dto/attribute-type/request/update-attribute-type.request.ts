import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';

export class UpdateAttributeTypeRequest {
  @ApiProperty({ description: 'Tên của loại giá trị', type: String })
  @MaxLength(50)
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiPropertyOptional({ description: 'Mô tả', type: String })
  @MaxLength(255)
  @IsString()
  @IsOptional()
  description: string;

  @ApiProperty({ description: 'Id đơn vị', type: Number })
  @IsNumber()
  @IsNotEmpty()
  unit: number;
}
