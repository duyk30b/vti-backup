import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class ValidateCodeRequest {
  @ApiProperty({
    description: 'Mã code',
    type: String,
  })
  @IsNotEmpty()
  code: string;
}
