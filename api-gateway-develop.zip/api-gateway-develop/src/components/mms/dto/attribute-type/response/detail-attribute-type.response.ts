import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

export class DetailAttributeType {
  @ApiProperty({ type: String })
  @Expose()
  id: string;

  @ApiProperty({ type: String })
  @Expose()
  code: string;

  @ApiProperty({ type: String })
  @Expose()
  name: string;

  @ApiProperty({ type: String })
  @Expose()
  description: string;

  @ApiProperty({ type: Number })
  @Expose()
  unit: number;
}

export class DetailAttributeTypeResponse extends SuccessResponse {
  @ApiProperty({ type: DetailAttributeType })
  @Expose()
  data: DetailAttributeType;
}
