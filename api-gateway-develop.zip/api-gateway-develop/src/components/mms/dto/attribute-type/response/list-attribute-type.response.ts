import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

export class DetailAttributeType {
  @ApiProperty({ type: String })
  @Expose()
  id: string;

  @ApiProperty({ type: String })
  @Expose()
  code: string;

  @ApiProperty({ type: String })
  @Expose()
  name: string;

  @ApiProperty({ type: String })
  @Expose()
  description: string;

  @ApiProperty({ type: Number })
  @Expose()
  unit: number;
}

class MetaAttributeType {
  @ApiProperty({ type: Number })
  @Expose()
  page: number;

  @ApiProperty({ type: Number })
  @Expose()
  total: number;
}

class MetaDataAttributeType {
  @ApiProperty({ type: DetailAttributeType, isArray: true })
  @Expose()
  items: DetailAttributeType[];

  @ApiProperty({ type: MetaAttributeType })
  @Expose()
  meta: MetaAttributeType;
}

export class ListAttributeTypeResponse extends SuccessResponse {
  @ApiProperty({ type: MetaDataAttributeType })
  @Expose()
  data: MetaDataAttributeType;
}
