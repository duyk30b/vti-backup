import { PaginationQuery } from '@utils/pagination.query';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class GetListUserResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  username: string;
}