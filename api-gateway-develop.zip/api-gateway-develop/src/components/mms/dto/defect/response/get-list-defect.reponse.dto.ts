import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';
import { DefectResponse } from '@components/mms/dto/defect/response/defect.response';
import { ApiProperty } from '@nestjs/swagger';
class Meta {
  @Expose()
  total: number;

  @Expose()
  page: number;
}

class MetaData {
  @Expose()
  data: DefectResponse[];

  @Expose()
  meta: Meta;
}
export class GetListDefectReponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: MetaData;
}