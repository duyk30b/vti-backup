import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class CreateDefectResponseDto {
  @ApiProperty({
    example: '61a6f6498e1f824efce559a4',
    description: 'id của lỗi',
  })
  @Expose()
  _id: string;

  @ApiProperty({ example: 'ABC123', description: 'Code của lỗi' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'ABC123', description: 'Tên của lỗi' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'ABC123', description: 'Mã thiết bị' })
  @Expose()
  deviceId: string;

  @ApiProperty({ example: 1, description: 'Mức ưu tiên' })
  @Expose()
  priority: number;

  @ApiProperty({ example: 'Mô tả', description: 'Mô tả' })
  @Expose()
  description: string;
}