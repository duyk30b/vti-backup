import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
class Device {
  @ApiProperty()
  @Expose()
  _id: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}

export class GetDetailDefectResponseDto {
  @ApiProperty({
    example: '61a6f6498e1f824efce559a4',
    description: 'id của lỗi',
  })
  @Expose()
  _id: string;

  @ApiProperty({ example: 'ABC123', description: 'Code của lỗi' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'ABC123', description: 'Tên của lỗi' })
  @Expose()
  name: string;

  @ApiProperty({ example: '', description: 'thiết bị' })
  @Expose()
  device: Device[];

  @ApiProperty({ example: 1, description: 'Loại vật tư' })
  @Expose()
  priority: number;

  @ApiProperty({ example: 'Mô tả', description: 'Mô tả' })
  @Expose()
  description: string;
}