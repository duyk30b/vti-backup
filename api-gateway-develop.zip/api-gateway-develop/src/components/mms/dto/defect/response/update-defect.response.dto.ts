import { GetDetailDefectResponseDto } from '@components/mms/dto/defect/response/get-detail-defect.response.dto';

export class UpdateDefectResponseDto extends GetDetailDefectResponseDto {}