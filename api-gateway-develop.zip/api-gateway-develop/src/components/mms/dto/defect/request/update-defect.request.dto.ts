import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import {
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';
import { DEFECT_CONST, DefectPriorityConstant } from '@components/mms/constant/defect.constant';

export class UpdateDefectRequestDto {
  @ApiProperty()
  @Expose()
  @IsNotEmpty()
  @IsString()
  @MaxLength(DEFECT_CONST.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty()
  @Expose()
  @IsString()
  @MaxLength(DEFECT_CONST.DESCRIPTION.MAX_LENGTH)
  @IsOptional()
  description: string;

  @ApiProperty()
  @Expose()
  @IsNotEmpty()
  @IsString()
  @IsEnum(DefectPriorityConstant)
  priority: number;

  @ApiProperty()
  @Expose()
  @IsNotEmpty()
  @IsString()
  deviceId: string;

  @ApiProperty()
  @Expose()
  @IsNotEmpty()
  @IsInt()
  userId: number;
}