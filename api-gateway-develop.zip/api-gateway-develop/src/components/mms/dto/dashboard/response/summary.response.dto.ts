import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';

export class DashboardSummaryDto {
  @ApiProperty({ example: 1 })
  @Expose()
  totalAllItem: number;

  @ApiProperty({ example: 5 })
  @Expose()
  totalFinishItem: number;

  @ApiProperty({ example: 20 })
  @Expose()
  totalSemiFinishItem: number;

  @ApiProperty({ example: 40 })
  @Expose()
  totalOutOfDateItem: number;
}

export class DashboardSummaryResponseDto extends SuccessResponse {
  @ApiProperty()
  data: DashboardSummaryDto;
}
