import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';

export class DashboardWarningPriorityResponseDto {
  @ApiProperty({ example: 1 })
  @Expose()
  totalMiniorItem: number;

  @ApiProperty({ example: 5 })
  @Expose()
  totalCriticalItem: number;

  @ApiProperty({ example: 20 })
  @Expose()
  totalBlockerItem: number;

  @ApiProperty({ example: 40 })
  @Expose()
  totalTrivialItem  : number;

  @ApiProperty({ example: 40 })
  @Expose()
  totalMajorItem  : number;

  @ApiProperty()
  @Expose()
  date: Date;

}

export class DashboardWarningPriorityDataResponseDto extends SuccessResponse {
  @ApiProperty({ type: [DashboardWarningPriorityResponseDto] })
  @Expose()
  data: DashboardWarningPriorityResponseDto
}
