import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';

export class DashboardJobStatusResponseDto {
  @ApiProperty({ example: 1 })
  @Expose()
  totalCompletedItem: number;

  @ApiProperty({ example: 5 })
  @Expose()
  totalOutOfDateItem: number;

  @ApiProperty({ example: 5 })
  @Expose()
  totalInProgressItem: number;

  //Kế hoạch
  @ApiProperty({ example: 5 })
  @Expose()
  totalCreatedItem: number;

  @ApiProperty()
  @Expose()
  date: Date;
}

export class DashboardJobStatusDataResponseDto extends SuccessResponse {
  @ApiProperty({ type: [DashboardJobStatusResponseDto] })
  @Expose()
  data: DashboardJobStatusResponseDto
}