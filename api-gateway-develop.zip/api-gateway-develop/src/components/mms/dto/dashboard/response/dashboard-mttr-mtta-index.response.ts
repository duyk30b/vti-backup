import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

enum IndexEnum {
  MTTR,
  MTTA,
}

class CountReportMttrMtta {
  @Expose()
  @ApiProperty({
    description: 'Số lượng',
  })
  count: number;

  @Expose()
  @ApiProperty({
    enum: IndexEnum,
    description: `
    MTTR = 0,
    MTTA = 1
    `,
  })
  status: IndexEnum;
}

class DataReportMttrMtta {
  @Expose()
  @ApiProperty()
  reportType: number;

  @Expose()
  @ApiProperty({
    description:
      'Tùy theo report type mà hiển thị ngày trong tuần, số tuần, số tháng',
  })
  tag: string;

  @Expose()
  @ApiProperty()
  rangeDate: string;

  @Expose()
  @ApiProperty({
    type: CountReportMttrMtta,
    isArray: true,
  })
  countReport: CountReportMttrMtta;
}

export class DashboardMttrMttaResponse extends SuccessResponse {
  @Expose()
  @ApiProperty({
    type: DataReportMttrMtta,
    isArray: true,
  })
  data: DataReportMttrMtta[];
}
