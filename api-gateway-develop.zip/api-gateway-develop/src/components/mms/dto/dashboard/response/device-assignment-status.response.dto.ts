import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
export class DashboardDeviceAssignmentStatusResponseDto {
  @ApiProperty({ example: 1 })
  @Expose()
  totalUnUseItem: number;

  @ApiProperty({ example: 5 })
  @Expose()
  totalInUseItem: number;

  @ApiProperty({ example: 5 })
  @Expose()
  totalMaintiningItem: number;

  @ApiProperty({ example: 5 })
  @Expose()
  totalReturnItem: number;

  @ApiProperty({ example: 5 })
  @Expose()
  totalScrappingItem: number;
}

export class DashboardDeviceAssignmentStatusDataResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: DashboardDeviceAssignmentStatusResponseDto
}