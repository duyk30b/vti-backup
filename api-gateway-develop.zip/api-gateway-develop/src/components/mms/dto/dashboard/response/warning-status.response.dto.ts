import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';

export class DashboardWarningStatusResponseDto {
  @ApiProperty({ example: 1 })
  @Expose()
  totalCompletedItem: number;

  @ApiProperty({ example: 5 })
  @Expose()
  totalInProgressItem: number;

  //Chờ xác nhận
  @ApiProperty({ example: 5 })
  @Expose()
  totalCreatedItem: number;

  @ApiProperty()
  @Expose()
  date: Date;
}

export class DashboardWarningStatusDataResponseDto extends SuccessResponse {
  @ApiProperty({ type: [DashboardWarningStatusResponseDto] })
  @Expose()
  data: DashboardWarningStatusResponseDto
}