import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { IsEnum, IsString } from 'class-validator';

export enum DEVICE_STATUS_ENUM {
  ACTIVE = 1, // Đang hoạt động
  STOP = 2, // Dừng
  ERROR = 3, // Lỗi
  OFF = 4, // Tắt
  MAINTENANCE = 5, // Tắt bảo trì
}

export class MoItem {
  @ApiProperty({
    description: 'Id lệnh sản xuất',
  })
  @IsString()
  id: string;

  @ApiProperty({
    description: 'Lệnh sản xuất',
  })
  @IsString()
  name: string;
}

export class DashboardDeviceStatusTotal {
  @ApiProperty({
    example: '2',
    description: 'Đang hoạt động',
  })
  @Expose()
  totalInActive: number;

  @ApiProperty({
    example: '2',
    description: 'Dừng',
  })
  @Expose()
  totalInStop: number;

  @ApiProperty({
    example: '2',
    description: 'Lỗi',
  })
  @Expose()
  totalInError: number;

  @ApiProperty({
    example: '2',
    description: 'Off(bảo trì)',
  })
  @Expose()
  totalInMaintain: number;

  @ApiProperty({
    example: '2',
    description: 'Off(tắt nguồn)',
  })
  @Expose()
  totalInShutDown: number;

  @ApiProperty({
    example: '2',
    description: 'Đang sử dụng',
  })
  @Expose()
  totalInUse: number;
}

export class DashboardDeviceData {
  @ApiProperty({
    example: 'Z-1000',
    description: 'Serial',
  })
  @Expose()
  serial: String;

  @ApiProperty({
    example: '1',
    description: 'Trạng thái',
  })
  @IsEnum(DEVICE_STATUS_ENUM)
  @Expose()
  status: number;

  @ApiProperty({
    example: '09:02',
    description: 'Thời gian hoạt động',
  })
  @Expose()
  activeTime: Date;
}

export class DashboardDeviceStatusResponseDto {
  @ApiProperty({
    example: '2022-01-05T09:02:49.811Z',
    description: 'Ngày xuất dữ liệu',
  })
  @Expose()
  exportedAt: Date;

  @ApiProperty({
    example: 75,
    description: 'Chỉ số oee trung bình',
  })
  @Expose()
  oee: number;

  @ApiProperty({
    example: 75,
    description: 'Số lượng thiết bị',
  })
  @Expose()
  deviceTotal: number;

  @ApiProperty({
    description: 'Tổng số thiết bị nhóm trạng thái',
    type: DashboardDeviceStatusTotal,
  })
  @Expose()
  totalDeviceStatus: DashboardDeviceStatusTotal;

  @ApiProperty({
    description: 'Sơ đồ thiết bị',
    type: [DashboardDeviceData],
  })
  @Expose()
  deviceStatusData: DashboardDeviceData[];

  @ApiProperty({
    description: 'Danh sách lệnh sản xuất',
    type: [MoItem],
  })
  @Expose()
  moList: MoItem[];
}
