import { ReportType } from '@components/report/constant/warehouse-report.constant';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsDateString,
  IsMongoId,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator';

export class DashboardMttrMttaQuery {
  @ApiProperty({
    description: 'Tuần: 0/Tháng: 1/Quý: 2',
    enum: ReportType,
  })
  @IsNotEmpty()
  reportType: ReportType;

  @ApiPropertyOptional({
    description: 'Ngày bắt đầu',
  })
  @IsDateString()
  @IsOptional()
  startDate: Date;

  @ApiPropertyOptional({
    description: 'Ngày kết thúc',
  })
  @IsDateString()
  @IsOptional()
  endDate: Date;

  @ApiPropertyOptional({
    description: 'Mã nhà máy',
  })
  @IsNumber()
  @IsOptional()
  factory: number;

  @ApiPropertyOptional({
    description: 'Mã đội bảo trì',
  })
  @IsMongoId()
  @IsOptional()
  maintainTeam: string;

  @ApiPropertyOptional({
    description: 'Mã serial',
  })
  @IsString()
  @IsOptional()
  serial: string;
}
