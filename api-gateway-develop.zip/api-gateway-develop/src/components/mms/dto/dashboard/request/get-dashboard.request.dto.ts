import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsNotEmpty, IsEnum } from 'class-validator';

export enum EnumGroupBy {
  DAY = '1',
  MONTH = '2',
  QUATER = '3',
}
export class GetDashboardRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  createdFrom: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  createdTo: Date;

  @ApiProperty({
    enum: EnumGroupBy,
    description: '1: DAY, 2: MONTH, 3: QUATER',
  })
  @IsNotEmpty()
  @IsEnum(EnumGroupBy)
  groupBy: EnumGroupBy;
}
