import { ReportType } from '@components/report/constant/warehouse-report.constant';
import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsNotEmpty, IsOptional } from 'class-validator';

export class GetDashboardWarningRequestDto {
  @ApiProperty({
    description: 'Tuần: 0/Tháng: 1/Quý: 2',
    enum: ReportType,
  })
  @IsNotEmpty()
  reportType: ReportType;
  @ApiProperty({
    description: 'Ngày bắt đầu',
  })
  @IsOptional()
  @IsDateString()
  startDate: Date;

  @ApiProperty({
    description: 'Ngày kết thúc',
  })
  @IsOptional()
  @IsDateString()
  endDate: Date;
}
