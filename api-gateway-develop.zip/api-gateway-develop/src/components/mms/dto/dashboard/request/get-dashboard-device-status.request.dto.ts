import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsOptional } from 'class-validator';

export class GetDashboardDeviceStatusRequestDto {
  @ApiProperty({ description: 'Id nhà máy' })
  @IsOptional()
  @IsString()
  factoryId: Number;

  @ApiProperty({ description: 'Id lệnh sản xuất' })
  @IsOptional()
  @IsString()
  moId: Number;
}
