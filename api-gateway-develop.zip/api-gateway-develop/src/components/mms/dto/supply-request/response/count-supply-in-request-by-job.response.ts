import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

class CountSupplyInRequestByJobResponse {
  @ApiProperty({
    type: String,
  })
  @Expose()
  supplyId: string;

  @ApiProperty({
    type: Number,
  })
  @Expose()
  actualImportQuantity: number;
}

class MetaDataCountSupplyInRequestByJob {
  @ApiProperty({ type: CountSupplyInRequestByJobResponse, isArray: true })
  @Expose()
  items: CountSupplyInRequestByJobResponse[];
}

export class CountSupplyInRequestByJobResponseDto extends SuccessResponse {
  @ApiProperty({ type: MetaDataCountSupplyInRequestByJob })
  @Expose()
  data: MetaDataCountSupplyInRequestByJob;
}
