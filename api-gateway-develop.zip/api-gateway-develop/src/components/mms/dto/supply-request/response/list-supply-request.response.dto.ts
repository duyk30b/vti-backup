import { ApiProperty } from '@nestjs/swagger';
import { Meta } from '@utils/common.response';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

class ListSupplyRequestResponse {
  @ApiProperty({
    type: String,
  })
  @Expose()
  id: string;

  @ApiProperty({
    type: String,
  })
  @Expose()
  code: string;

  @ApiProperty({
    type: String,
  })
  @Expose()
  name: string;

  @ApiProperty({
    type: String,
  })
  @Expose()
  deviceName: string;

  @ApiProperty({
    type: String,
  })
  @Expose()
  teamName: string;

  @ApiProperty({
    type: String,
  })
  @Expose()
  fullName: string;

  @ApiProperty({
    type: String,
  })
  @Expose()
  supplyName: string;

  @ApiProperty({
    type: Number,
  })
  @Expose()
  type: number;

  @ApiProperty({
    type: Number,
  })
  @Expose()
  status: number;
}

class MetaDataSupllyRequest {
  @ApiProperty({ type: ListSupplyRequestResponse, isArray: true })
  @Expose()
  items: ListSupplyRequestResponse[];

  @ApiProperty({ type: Meta })
  @Expose()
  meta: Meta;
}

export class ListSupplyRequestResponseDto extends SuccessResponse {
  @ApiProperty({ type: MetaDataSupllyRequest })
  @Expose()
  data: MetaDataSupllyRequest;
}
