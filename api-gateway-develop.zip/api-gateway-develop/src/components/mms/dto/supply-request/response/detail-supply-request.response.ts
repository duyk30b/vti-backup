import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class DetailSupplyRequest {
  @ApiProperty({ type: String })
  @Expose()
  id: string;

  @ApiProperty({ type: String })
  @Expose()
  code: string;

  @ApiProperty({ type: String })
  @Expose()
  name: string;

  @ApiProperty({ type: Number })
  @Expose()
  type: number;

  @ApiProperty({ type: String })
  @Expose()
  unit: string;

  @ApiProperty({ type: Number })
  @Expose()
  price: number;

  @ApiProperty({ type: Boolean })
  @Expose()
  isManufacture: boolean;

  @ApiProperty({ type: Number })
  @Expose()
  useQuantity: number;

  @ApiProperty({ type: Number })
  @Expose()
  stockQuantity: number;

  @ApiProperty({ type: Number })
  @Expose()
  planQuantity: number;

  @ApiProperty({ type: Number })
  @Expose()
  buyQuantity: number;
}

export class DetailSuppyRequestResponse {
  @ApiProperty({ type: String })
  @Expose()
  id: string;

  @ApiProperty({ type: String })
  @Expose()
  code: string;

  @ApiProperty({ type: String })
  @Expose()
  name: string;

  @ApiProperty({ type: String })
  @Expose()
  jobCode: string;

  @ApiProperty({ type: String })
  @Expose()
  jobName: string;

  @ApiProperty({ type: String })
  @Expose()
  requestedBy: string;

  @ApiProperty({ type: String })
  @Expose()
  serial: string;

  @ApiProperty({ type: String })
  @Expose()
  team: string;

  @ApiProperty({ type: String })
  @Expose()
  deviceName: string;

  @ApiProperty({ type: String })
  @Expose()
  receiveExpectedDate: string;

  @ApiProperty({ type: String })
  @Expose()
  factory: string;

  @ApiProperty({ type: String })
  @Expose()
  workCenter: string;

  @ApiProperty({ type: Number })
  @Expose()
  status: number;

  @ApiProperty({ type: DetailSupplyRequest, isArray: true })
  @Type(() => DetailSupplyRequest)
  @Expose()
  supplies: DetailSupplyRequest[];
}
