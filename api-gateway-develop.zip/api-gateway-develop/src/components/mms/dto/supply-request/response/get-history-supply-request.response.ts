import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class User {
  @Expose()
  id: string;

  @Expose()
  fullName: string;
}

export class GetHistorySupplyResponse {
  @ApiProperty({
    example: '2021-07-21T06:39:37.194Z',
  })
  @Expose()
  createdAt: string;

  @ApiProperty({
    example: { id: 1, fullName: 'admin' },
  })
  @Type(() => User)
  @Expose()
  user: User;

  @ApiProperty({
    example: Number,
  })
  @Expose()
  status: number;

  @ApiProperty({
    example: Number,
  })
  @Expose()
  action: number;

  @ApiProperty({
    example: String,
  })
  @Expose()
  content: string;
}
