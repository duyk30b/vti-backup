import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateSupplyRequest } from './create-supply-request.request.dto';

export class UpdateSupplyRequest extends CreateSupplyRequest {
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
