import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsDateString,
  IsMongoId,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Min,
} from 'class-validator';

class CreateSupplyRequestDetail {
  @ApiProperty({
    type: String,
    description: 'Id vật tư phụ tùng',
  })
  @IsMongoId()
  @IsNotEmpty()
  supplyId: string;

  @ApiProperty({
    type: Number,
    description: 'Số lượng cần yêu cầu',
  })
  @Min(1)
  @IsNumber()
  @IsNotEmpty()
  quantity: number;
}

export class CreateSupplyRequest {
  @ApiProperty({
    type: String,
    description: 'Id công việc',
  })
  @IsMongoId()
  @IsNotEmpty()
  jobId: string;

  @ApiPropertyOptional({
    type: String,
    description: 'Tên yêu cầu',
  })
  @IsString()
  @IsOptional()
  name: string;

  @ApiPropertyOptional({
    type: String,
    description: 'Mô tả yêu cầu',
  })
  @IsString()
  @IsOptional()
  description: string;

  @ApiProperty({
    type: Date,
    description: 'Ngày nhận mong muốn',
  })
  @IsDateString()
  @IsNotEmpty()
  receiveExpectedDate: Date;

  @ApiProperty({
    type: CreateSupplyRequestDetail,
    isArray: true,
    description: 'Danh sách phụ tùng',
  })
  @ArrayUnique<CreateSupplyRequestDetail>(
    (e: CreateSupplyRequestDetail) => e.supplyId,
  )
  @Type(() => CreateSupplyRequestDetail)
  @ArrayNotEmpty()
  supplies: CreateSupplyRequestDetail[];
}
