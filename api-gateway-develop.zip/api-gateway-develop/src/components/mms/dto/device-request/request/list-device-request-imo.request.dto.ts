import { PaginationQuery } from '@utils/pagination.query';

export class ListDeviceRequestImoQuery extends PaginationQuery {}
