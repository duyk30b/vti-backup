import { ApiProperty } from '@nestjs/swagger';

export class CreateDeviceRequestTicketRequestDto {
  @ApiProperty({
    description: 'Tên yêu cầu',
  })
  name: string;

  @ApiProperty({
    description: 'Mô tả yêu cầu',
  })
  description: string;

  @ApiProperty({
    description: 'Người sử dụng',
  })
  userId: number;

  @ApiProperty({
    description: 'Số lượng thiết bị',
  })
  quantity: number;

  @ApiProperty({
    description: 'Xưởng sử dụng',
  })
  workCenterId: number;

  @ApiProperty({
    description: 'Id thiết bị',
  })
  deviceId: string;
}
