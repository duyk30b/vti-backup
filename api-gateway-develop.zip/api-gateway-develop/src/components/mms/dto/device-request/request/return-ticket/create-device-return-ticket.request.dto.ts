import { ApiProperty } from '@nestjs/swagger';

export class CreateDeviceReturnTicketRequestDto {
  @ApiProperty({
    description: 'Tên yêu cầu trả thiết bị',
  })
  name: string;

  @ApiProperty({
    description: 'Mô tả yêu cầu trả thiết bị',
  })
  description: string;

  @ApiProperty({
    description: 'Danh sách Id phân công thiết bị',
    isArray: true,
    type: [String],
  })
  deviceAssignmentIds: string[];
}
