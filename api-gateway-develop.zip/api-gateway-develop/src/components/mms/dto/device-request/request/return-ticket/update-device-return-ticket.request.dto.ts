import { ApiProperty } from '@nestjs/swagger';
import { CreateDeviceReturnTicketRequestDto } from '@components/mms/dto/device-request/request/return-ticket/create-device-return-ticket.request.dto';

export class UpdateDeviceReturnTicketRequestDto extends CreateDeviceReturnTicketRequestDto {
  @ApiProperty({
    description: 'Id yêu cầu trả thiết bị',
  })
  id: string;
}
