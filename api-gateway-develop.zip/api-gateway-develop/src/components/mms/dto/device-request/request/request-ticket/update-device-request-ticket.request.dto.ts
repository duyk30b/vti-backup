import { ApiProperty } from '@nestjs/swagger';
import { CreateDeviceRequestTicketRequestDto } from '@components/mms/dto/device-request/request/request-ticket/create-device-request-ticket.request.dto';

export class UpdateDeviceRequestTicketRequestDto extends CreateDeviceRequestTicketRequestDto {
  @ApiProperty({
    description: 'Id yêu cầu cấp thiết bị',
  })
  id: string;
}
