import { ApiProperty } from '@nestjs/swagger';
import { DeviceReturnTicketStatus } from '@components/mms/constant/device-request.constant';

export class ChangeStatusDeviceReturnTicketRequestDto {
  @ApiProperty({
    description: 'Id yêu cầu trả thiết bị',
  })
  id: string;

  @ApiProperty({
    description: 'Trạng thái yêu cầu trả thiết bị',
    enum: DeviceReturnTicketStatus,
    example: 0,
  })
  status: DeviceReturnTicketStatus;
}
