import { ApiProperty } from '@nestjs/swagger';
import { DeviceRequestTicketStatus } from '@components/mms/constant/device-request.constant';

export class ChangeStatusDeviceRequestTicketRequestDto {
  @ApiProperty({
    description: 'Id yêu cầu cấp thiết bị',
  })
  id: string;

  @ApiProperty({
    description: 'Trạng thái yêu cầu cấp thiết bị',
    enum: DeviceRequestTicketStatus,
    example: 0,
  })
  status: DeviceRequestTicketStatus;
}
