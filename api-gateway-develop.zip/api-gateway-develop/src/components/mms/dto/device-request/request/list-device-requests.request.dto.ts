import { ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { PaginationQuery, Sort, Filter } from '@utils/pagination.query';
import { DeviceRequestType } from '@components/mms/constant/device-request.constant';

export class ListDeviceRequestsRequestDto extends PaginationQuery {
  @ApiPropertyOptional({
    example: 'YC1234',
    description: 'Từ khóa tìm kiếm',
  })
  keyword?: string;

  @ApiPropertyOptional({
    example: [{ column: 'name', text: 'abc' }],
    description: 'Filter theo tên cột',
  })
  @Type(() => Filter)
  filter?: Filter[];

  @ApiPropertyOptional({
    example: [{ column: 'name', order: 'DESC' }],
    description: 'Sắp xếp theo tên cột',
  })
  @Type(() => Sort)
  sort?: Sort[];

  @ApiPropertyOptional({
    description:
      'Loại yêu cầu.\n0 = Request (yêu cầu cấp)\n1 = Return (yêu cầu trả)',
    enum: DeviceRequestType,
  })
  type: number;
}
