import { ApiProperty } from '@nestjs/swagger';
import { DeviceType } from '@components/mms/constant/device.constant';
import { BaseUserResponseDto } from '@components/user/dto/user/response/base.user.response.dto';
import { DeviceRequestTicketStatus } from '@components/mms/constant/device-request.constant';

export class DeviceDto {
  @ApiProperty({
    description: 'Id thiết bị',
  })
  id: string;

  @ApiProperty({
    description: 'Mã thiết bị',
  })
  code: string;

  @ApiProperty({
    description: 'Tên thiết bị',
  })
  name: string;

  @ApiProperty({
    description: 'Loại thiết bị',
    enum: DeviceType,
  })
  type: DeviceType;
}

export class WorkCenterDto {
  @ApiProperty({
    description: 'Id xưởng sử dụng',
  })
  id: number;

  @ApiProperty({
    description: 'Tên xưởng sử dụng',
  })
  name: number;
}

export class DetailDeviceRequestTicketResponseDto {
  @ApiProperty({
    description: 'Id yêu cầu cấp thiết bị',
  })
  id: string;

  @ApiProperty({
    description: 'Mã yêu cầu cấp thiết bị',
  })
  code: string;

  @ApiProperty({
    description: 'Tên yêu cầu cấp thiết bị',
  })
  name: string;

  @ApiProperty({
    description: 'Mô tả yêu cầu cấp thiết bị',
  })
  description: string;

  @ApiProperty({
    description: 'Người yêu cầu cấp thiết bị',
  })
  user: BaseUserResponseDto;

  @ApiProperty({
    description: 'Số lượng thiết bị',
  })
  quantity: number;

  @ApiProperty({
    description: 'Thông tin xưởng sử dụng',
  })
  workCenter: WorkCenterDto;

  @ApiProperty({
    description: 'Id thiết bị',
  })
  device: DeviceDto;

  @ApiProperty({
    description: 'Trạng thái yêu cầu cấp thiết bị',
    enum: DeviceRequestTicketStatus,
  })
  status: DeviceRequestTicketStatus;

  @ApiProperty({
    description: 'Lịch sử',
  })
  histories: [];
}
