import { ApiProperty } from '@nestjs/swagger';
import { DeviceRequestTicketStatus } from '@components/mms/constant/device-request.constant';
import { SuccessResponse } from "@utils/success.response.dto";

class UserDto {
  @ApiProperty({
    description: 'Id người sử dụng',
  })
  id: number;

  @ApiProperty({
    description: 'Tên tài khoản',
  })
  username: string;

  @ApiProperty({
    description: 'Tên người sử dụng',
  })
  fullName: string;
}

class DeviceDto {
  @ApiProperty({
    description: 'Id thiết bị',
  })
  id: string;

  @ApiProperty({
    description: 'Mã thiết bị',
  })
  code: string;

  @ApiProperty({
    description: 'Tên thiết bị',
  })
  name: string;

  @ApiProperty({
    description: 'Serial thiết bị được phân công',
  })
  serial: string;

  @ApiProperty({
    description: 'Thông tin người sử dụng',
    type: UserDto,
  })
  user: UserDto;
}

export class ListDeviceRequestsResponseDto {
  @ApiProperty({
    description: 'Id yêu cầu',
  })
  id: string;

  @ApiProperty({
    description: 'Mã yêu cầu',
  })
  code: string;

  @ApiProperty({
    description: 'Trạng thái yêu cầu',
    enum: DeviceRequestTicketStatus,
    example: 0,
  })
  status: number;

  @ApiProperty({
    description: 'Loại yêu cầu',
  })
  type: number;

  @ApiProperty({
    description: 'Danh sách thiết bị của yêu cầu',
    type: [DeviceDto],
  })
  devices: DeviceDto[];

  @ApiProperty({
    description: 'Số lượng thiết bị của yêu cầu',
  })
  quantity: number;

  @ApiProperty({
    description: 'Ngày tạo yêu cầu',
  })
  createdAt: Date;

  @ApiProperty({
    description: 'Ngày chỉnh sửa yêu cầu',
  })
  updatedAt: Date;
}

// export class ListDeviceRequestsResponseDto extends SuccessResponse {
//   data:
// }
