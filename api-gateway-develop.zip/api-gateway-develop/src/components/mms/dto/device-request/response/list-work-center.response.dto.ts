import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

export class LeaderResponse {
  @Expose()
  id: number;

  @Expose()
  username: string;

  @Expose()
  fullName: string;
}

export class WorkCenterResponse {
  @Expose()
  id: number;

  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  leader: LeaderResponse;
}

export class ListWorkCenterResponse extends SuccessResponse {
  @ApiProperty({
    type: WorkCenterResponse,
    isArray: true,
    example: [
      {
        id: 396,
        code: 'XG04',
        name: 'xưởng ruột bút 2',
        leader: {
          id: 80,
          username: 'trung.nguyenvan',
          fullName: 'Nguyễn Văn Trung',
        },
      },
    ],
  })
  data: WorkCenterResponse[];
}
