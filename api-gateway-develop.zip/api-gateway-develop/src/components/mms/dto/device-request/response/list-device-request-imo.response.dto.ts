import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';

class ItemRequest {
  @ApiProperty({
    description: 'id sản phẩm',
  })
  id: string;

  @ApiProperty({
    description: 'Mã sản phẩm',
  })
  code: string;

  @ApiProperty({
    description: 'Loại sản phẩm',
  })
  type: number;

  @ApiProperty({
    description: 'số lượng sản phẩm',
  })
  planQuantity: number;

  @ApiProperty({
    description: 'Đơn vị',
  })
  unit: any;
}

class DeviceRequestImo {
  @ApiProperty({
    description: 'id yêu cầu',
  })
  id: string;

  @ApiProperty({
    description: 'Mã yêu cầu',
  })
  code: string;

  @ApiProperty({
    description: 'Tên yêu cầu',
  })
  name: string;

  @ApiProperty({
    description: 'Loại yêu cầu',
  })
  type: number;

  @ApiProperty({
    description: 'Ngày bắt đầu kế hoạch',
  })
  planFrom: Date;

  @ApiProperty({
    description: 'Ngày kết thúc kế hoạch',
  })
  planTo: Date;

  @ApiProperty({
    description: 'Mô tả yêu cầu',
  })
  description: string;

  @ApiProperty({ type: ItemRequest, isArray: true })
  items: ItemRequest[];
}

export class ListDeviceRequestImoResponseDto extends SuccessResponse {
  @ApiProperty({
    type: DeviceRequestImo,
    isArray: true,
    example: [
      {
        id: '6221c04ca5f5c4177ece46a5',
        code: '000000000003',
        name: 'yêu cầu mượn hàng',
        type: '1 -> yêu cầu trả, 2 là yêu cầu cấp',
        planFrom: '2022-02-16T09:17:18Z',
        planTo: '2022-02-17T09:17:18Z',
        description: 'Mô tả yêu cầu',
        itemList: [
          {
            id: '6221c04ca5f5c4177ece46a5',
            code: '000000000003',
            type: '0 -> phụ tùng, 1 -> vật tư, 2 -> thiết bị',
            planQuantity: 1,
            unit: {
              id: 1,
              name: 'cái',
            },
          },
        ],
      },
    ],
  })
  data: DeviceRequestImo[];
}
