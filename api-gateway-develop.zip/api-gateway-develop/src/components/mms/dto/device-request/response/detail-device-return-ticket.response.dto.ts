import { Expose } from 'class-transformer';
import { DeviceRequestTicketStatus } from "@components/mms/constant/device-request.constant";

export class UserDto {
  @Expose()
  id: number;

  @Expose()
  username: string;

  @Expose()
  fullName: string;
}

export class DeviceDto {
  @Expose()
  id: string;

  @Expose()
  code: string;

  @Expose()
  name: string;
}

export class DeviceAssignmentDto {
  @Expose()
  id: string;

  @Expose()
  serial: string;

  @Expose()
  device: DeviceDto;

  @Expose()
  user: UserDto;
}

export class DetailDeviceReturnTicketResponseDto {
  @Expose()
  id: string;

  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  description: string;

  @Expose()
  status: DeviceRequestTicketStatus;

  @Expose()
  deviceAssignments: DeviceAssignmentDto[];

  @Expose()
  histories: History[];
}
