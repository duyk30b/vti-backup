import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { IsArray, IsEnum, IsInt, IsNotEmpty, IsNumber, IsOptional, IsString, MaxLength } from "class-validator";
import { SUPPLY_CONST, SupplyTypeConstant } from "@components/mms/constant/supply.constant";

export class UpdateSupplyRequestDto {
  @ApiProperty({ example: 'ABC123', description: 'Code của vật tư' })
  @Expose()
  @IsNotEmpty()
  @IsString()
  @MaxLength(SUPPLY_CONST.CODE.MAX_LENGTH)
  code: string;

  @ApiProperty({ example: 'ABC123', description: 'Tên của vật tư' })
  @Expose()
  @IsNotEmpty()
  @IsString()
  @MaxLength(SUPPLY_CONST.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: 'ABC123', description: 'Mã nhóm của vật tư' })
  @Expose()
  @IsNotEmpty()
  @IsString()
  groupSupplyId: string;

  @ApiProperty({ example: 1, description: 'Loại vật tư' })
  @Expose()
  @IsNotEmpty()
  @IsEnum(SupplyTypeConstant)
  type: number;

  @ApiProperty({ example: 'Mô tả', description: 'Mô tả' })
  @Expose()
  @IsString()
  @IsOptional()
  @MaxLength(SUPPLY_CONST.DESCRIPTION.MAX_LENGTH)
  description: string;

  @ApiProperty({ example: [1], description: 'Người chịu trách nhiệm' })
  @Expose()
  @IsOptional()
  @IsArray()
  responsibleUserIds: number[];

  @ApiProperty({ example: 1, description: 'Người chịu trách nhiệm là nhóm bảo trì' })
  @Expose()
  @IsOptional()
  @IsArray()
  responsibleMaintenanceTeam: number;

  @ApiProperty({ example: '10000000', description: 'Giá' })
  @Expose()
  @IsInt()
  @IsOptional()
  price: number;

  @ApiProperty({ example: 1, description: 'Mã của nhà máy' })
  @Expose()
  @IsNotEmpty()
  @IsInt()
  factoryId: number;

  @ApiProperty({ example: 1, description: 'Mã của đơn vị' })
  @Expose()
  @IsNotEmpty()
  @IsInt()
  itemUnitId: number;
}