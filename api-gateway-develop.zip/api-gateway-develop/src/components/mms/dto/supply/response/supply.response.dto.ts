import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class SupplyResponseDto {
  @ApiProperty({
    example: '61a6f6498e1f824efce559a4',
    description: 'id của vật tư',
  })
  @Expose()
  _id: string;

  @ApiProperty({ example: 'ABC123', description: 'Code của vật tư' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'ABC123', description: 'Tên của vật tư' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'ABC123', description: 'Mã nhóm của vật tư' })
  @Expose()
  groupSupplyId: string;

  @ApiProperty({ example: 1, description: 'Loại vật tư' })
  @Expose()
  type: number;

  @ApiProperty({ example: 'Mô tả', description: 'Mô tả' })
  @Expose()
  description: string;

  @ApiProperty({ example: [1, 2, 3], description: 'Ds người chịu trách nhiệm' })
  @Expose()
  responsibleUserIds: number[];

  @ApiProperty({ example: '10000000', description: 'Giá' })
  @Expose()
  price: number;

  @ApiProperty()
  @Expose()
  factoryId: string;

  @ApiProperty()
  @Expose()
  itemUnitId: string;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updateAt: Date;
}