import { GetDetailSupplyGroupResponseDto } from '@components/mms/dto/supply-group/response/get-detail-supply-group.response.dto';

export class UpdateSupplyResponseDto extends GetDetailSupplyGroupResponseDto {}
