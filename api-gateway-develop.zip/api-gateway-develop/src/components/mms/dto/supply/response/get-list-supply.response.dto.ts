import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { SupplyResponseDto } from '@components/mms/dto/supply/response/supply.response.dto';

class Meta {
  @Expose()
  total: number;

  @Expose()
  page: number;
}

class MetaData {
  @Expose()
  data: SupplyResponseDto[];

  @Expose()
  meta: Meta;
}
export class GetListSupplyResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: MetaData;
}
