import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import {
  IsArray,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';
import { MaintenanceTeamMemberRoleConstant } from '@components/mms/constant/maintenance_team_member.constant';
import {
  MAINTENANCE_TEAM_CONST,
  MaintenanceTeamStatusConstant,
} from '@components/mms/constant/maintenance-team.constant';

class Member {
  @ApiProperty({ example: 0, description: 'UserId' })
  @Expose()
  @IsNotEmpty()
  @IsInt()
  userId: number;

  @ApiProperty({ example: 0, description: 'Role' })
  @Expose()
  @IsNotEmpty()
  @IsEnum(MaintenanceTeamMemberRoleConstant)
  role: number;
}

export class CreateMaintenanceTeamRequestDto {
  @ApiProperty({ example: 'ABC123', description: 'Code của đội bảo trì' })
  @Expose()
  @IsNotEmpty()
  @IsString()
  @MaxLength(MAINTENANCE_TEAM_CONST.CODE.MAX_LENGTH)
  code: string;

  @ApiProperty({ example: 'ABC123', description: 'Tên của đội bảo trì' })
  @Expose()
  @IsNotEmpty()
  @IsString()
  @MaxLength(MAINTENANCE_TEAM_CONST.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: 'Mô tả', description: 'Mô tả' })
  @Expose()
  @IsOptional()
  @IsString()
  @MaxLength(MAINTENANCE_TEAM_CONST.DESCRIPTION.MAX_LENGTH)
  description: string;

  @ApiProperty({ example: 0, description: 'thành viên của đội' })
  @Expose()
  @IsArray()
  @IsOptional()
  member: Member[];
}