import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import {
  IsArray,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';
import { MaintenanceTeamMemberRoleConstant } from '@components/mms/constant/maintenance_team_member.constant';
import { MAINTENANCE_TEAM_CONST } from '@components/mms/constant/maintenance-team.constant';

class Member {
  @ApiProperty({ example: 'User1', description: 'ID của thành viên đội' })
  @Expose()
  @IsNotEmpty()
  @IsInt()
  userId: number;

  @ApiProperty({ example: '1', description: 'Vai trò của thành viên đội' })
  @Expose()
  @IsNotEmpty()
  @IsEnum(MaintenanceTeamMemberRoleConstant)
  role: number;
}

export class UpdateMaintenanceTeamRequestDto {
  @ApiProperty({ example: 'ABC123', description: 'Tên của đội bảo trì' })
  @Expose()
  @IsNotEmpty()
  @IsString()
  @MaxLength(MAINTENANCE_TEAM_CONST.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty()
  @Expose()
  @IsNotEmpty()
  @IsArray()
  members: Member[];

  @ApiProperty({ example: 'Mô tả', description: 'Mô tả' })
  @Expose()
  @IsOptional()
  @IsString()
  @MaxLength(MAINTENANCE_TEAM_CONST.DESCRIPTION.MAX_LENGTH)
  description: string;
}