import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
class Member {
  @ApiProperty({ example: 'UserID', description: 'Mã của người dùng' })
  @Expose()
  userId: string;

  @ApiProperty({ example: 'Vai trò', description: 'Vai trò' })
  @Expose()
  role: string;
}

export class CreateMaintenanceTeamResponseDto {
  @ApiProperty({ example: 'Mã đội', description: 'mã đội' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'Tên đội', description: 'tên đội' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'Mô tả', description: 'Mô tả' })
  @Expose()
  description: string;

  @ApiProperty({ example: 'Ngày cập nhật', description: 'Ngày cập nhật' })
  @Expose()
  updatedAt: Date;

  @ApiProperty({ example: 'Ngày tạo', description: 'Ngày tạo' })
  @Expose()
  createdAt: Date;

  @ApiProperty({ example: 'Trạng thái', description: 'Trạng thái' })
  @Expose()
  status: number;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  members: Member[];
}
