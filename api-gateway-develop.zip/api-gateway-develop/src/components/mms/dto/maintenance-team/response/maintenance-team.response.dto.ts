import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class MaintenanceTeamResponseDto {
  @ApiProperty({
    example: 1,
    description: 'Id của đội bảo trì',
  })
  @Expose()
  id: number;

  @ApiProperty({
    example: 'ABC',
    description: 'Mã của của đội bảo trì',
  })
  @Expose()
  name: string;

  @ApiProperty({
    example: 'ABC',
    description: 'Mã của đội bảo trì',
  })
  @Expose()
  code: string;

  @ApiProperty({
    example: 'ABC',
    description: 'Mô tả của đội bảo trì',
  })
  @Expose()
  description: string;

  @ApiProperty({
    example: 'ABC',
    description: 'Trạng thái của đội bảo trì',
  })
  @Expose()
  status: string;

  @ApiProperty({
    example: 'ABC',
    description: 'Trạng thái của đội bảo trì',
  })
  @Expose()
  createAt: Date;

  @ApiProperty({
    example: 'ABC',
    description: 'Trạng thái của đội bảo trì',
  })
  @Expose()
  updateAt: Date;
}