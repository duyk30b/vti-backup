import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { MaintenanceTeamResponseDto } from '@components/mms/dto/maintenance-team/response/maintenance-team.response.dto';
class Meta {
  @Expose()
  total: number;

  @Expose()
  page: number;
}

class MetaData {
  @Expose()
  data: MaintenanceTeamResponseDto[];

  @Expose()
  meta: Meta;
}
export class GetListMaintenanceTeamResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: MetaData;
}
