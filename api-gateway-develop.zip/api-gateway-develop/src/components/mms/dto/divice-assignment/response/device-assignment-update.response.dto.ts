import { SuccessResponse } from '@utils/success.response.dto';
export class DeviceAssignmentUpdateResponseDto extends SuccessResponse {}
