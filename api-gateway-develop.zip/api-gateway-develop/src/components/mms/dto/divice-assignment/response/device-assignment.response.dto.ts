import { BaseUserResponseDto } from '@components/user/dto/user/response/base.user.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { IsNotEmpty } from 'class-validator';

class Device {
  @ApiProperty({
    example: '1',
    description: 'Id của thiết bị',
  })
  @Expose()
  id: number;

  @ApiProperty({
    example: '1',
    description: 'Mã của thiết bị',
  })
  @Expose()
  code: string;

  @ApiProperty({
    example: '1',
    description: 'Tên của thiết bị',
  })
  @Expose()
  name: string;

  @ApiProperty({
    example: '1',
    description: 'Model của thiết bị',
  })
  @Expose()
  model: string;
}

export class DeviceAssignmentResponseDto {
  @ApiProperty({
    example: 1,
    description: 'Id của phần công thiết bị',
  })
  @Expose()
  id: number;

  @ApiProperty({
    example: '2021-11-25 16:00:00',
    description: 'Ngày tạo phân công thiết bị',
  })
  @Expose()
  createdAt: Date;

  @ApiProperty({
    example: '2021-11-25 16:00:00',
    description: 'Ngày cập nhật phân công thiết bị gần nhất',
  })
  @Expose()
  updatedAt: Date;

  @ApiProperty({
    example: 'ABC',
    description: 'Trạng thái của thiết bị',
  })
  @Expose()
  status: string;

  @ApiProperty({
    example: 'ABC',
    description: 'Số serial của thiết bị',
  })
  @Expose()
  serial: string;

  @ApiProperty({
    example: '2021-11-25 16:00:00',
    description: 'Ngày phân công thiết bị',
  })
  @Expose()
  assignedAt: Date;

  @ApiProperty({
    example: '2021-11-25 16:00:00',
    description: 'Ngày sử dụng thiết bị',
  })
  @Expose()
  usedAt: Date;

  @ApiProperty({
    example: '',
    type: [Device],
    description: 'Ngày sửa thiết bị',
  })
  @Expose()
  device: Device;

  @IsNotEmpty()
  @Expose()
  user: BaseUserResponseDto;
}
