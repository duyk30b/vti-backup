import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

class MoInformation {
  @Expose()
  id: number;

  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  planFrom: string;

  @Expose()
  planTo: string;
}

export class GetMoInformationResponse extends SuccessResponse {
  @ApiProperty({
    type: MoInformation,
    example: [
      {
        code: 'moD61',
        id: 580,
        name: 'Lệnh D6',
        planFrom: '2022-03-14T17:00:00.000Z',
        planTo: '2022-03-19T16:59:59.000Z',
      },
    ],
    isArray: true,
  })
  @Expose()
  data: MoInformation[];
}
