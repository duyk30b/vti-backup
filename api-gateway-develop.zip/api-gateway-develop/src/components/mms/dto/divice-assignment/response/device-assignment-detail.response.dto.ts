import { DeviceAssignmentResponseDto } from '@components/mms/dto/divice-assignment/response/device-assignment.response.dto';

export class DeviceAssignmentDetailResponseDto extends DeviceAssignmentResponseDto {}
