import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { DeviceResponseDto } from '@components/mms/dto/device/response/device.response.dto';
class Meta {
  @Expose()
  total: number;

  @Expose()
  page: number;
}

class MetaData {
  @Expose()
  data: DeviceResponseDto[];

  @Expose()
  meta: Meta;
}
export class GetListDeviceAssignmentResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  MetaData: MetaData;
}