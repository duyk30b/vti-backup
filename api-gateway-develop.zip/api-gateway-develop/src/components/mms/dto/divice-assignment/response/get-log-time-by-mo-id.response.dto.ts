import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

class GetLogTimeByMoId {
  @Expose()
  moId: number;

  @Expose()
  day: string;

  @Expose()
  workTime: string;

  @Expose()
  stopTime: string;
}

export class GetLogTimeByMoIdResponse extends SuccessResponse {
  @ApiProperty({
    type: GetLogTimeByMoId,
    example: [
      {
        moId: 583,
        day: '2022-03-15',
        workTime: 0.77,
        stopTime: 959.23,
      },
    ],
    isArray: true,
  })
  @Expose()
  data: GetLogTimeByMoId[];
}
