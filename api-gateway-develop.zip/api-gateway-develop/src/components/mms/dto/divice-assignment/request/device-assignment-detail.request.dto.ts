import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class DeviceAssignmentDetailRequestDto{
  @ApiProperty({
    example: '1',
    description: 'Id của phân công thiết bị',
  })
  @Expose()
  id: number;
}