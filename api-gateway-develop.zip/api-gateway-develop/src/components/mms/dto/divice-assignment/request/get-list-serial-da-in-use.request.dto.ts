import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';

export class ListSerailInUseREquestDto {
  @ApiPropertyOptional({ example: 'Thietke-003', description: '' })
  @IsOptional()
  @IsString()
  serial?: string;
}
