import { PaginationQuery } from '@utils/pagination.query';

export class getMoInformation extends PaginationQuery {}
