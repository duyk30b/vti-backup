import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsString, IsInt } from 'class-validator';

export class getManufacturingInformation {
  @ApiPropertyOptional({ example: '284', description: 'id xưởng' })
  @IsNotEmpty()
  @IsInt()
  wcId: number;

  @ApiPropertyOptional({ example: '583,584', description: 'mo ids' })
  @IsNotEmpty()
  @IsString()
  moIds: string;
}
