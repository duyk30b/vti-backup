import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

class ReportTotalJob {
  @ApiProperty({
    description: `
    ALL = 1, // Tất cả công việc
    COMPLETED = 2, // Hoàn thành
    NOT_COMPLETED = 3, // Chưa hoàn thành
    LATE = 4, // Quá hạn
    `,
  })
  @Expose()
  status: number;

  @ApiProperty({
    description: 'Số lượng',
  })
  @Expose()
  count: number;
}

export class ReportTotalJobResponse extends SuccessResponse {
  @ApiProperty({
    description: 'Thống kê',
    isArray: true,
    type: ReportTotalJob,
  })
  @Expose()
  data: ReportTotalJob[];
}
