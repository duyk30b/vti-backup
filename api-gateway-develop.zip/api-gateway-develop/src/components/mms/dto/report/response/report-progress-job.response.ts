import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

enum StatusReportJobEnum {
  COMPLETED,
  LATE,
  WAITING_CONFIRM,
  IN_PROGRESS,
}

class CountReport {
  @Expose()
  @ApiProperty({
    description: 'Số lượng',
  })
  count: number;

  @Expose()
  @ApiProperty({
    enum: StatusReportJobEnum,
    description: `
    COMPLETED = 0,
    LATE = 1,
    WAITING_CONFIRM = 2,
    IN_PROGRESS = 3,
    `,
  })
  status: StatusReportJobEnum;
}

class DataReport {
  @Expose()
  @ApiProperty()
  reportType: number;

  @Expose()
  @ApiProperty({
    description:
      'Tùy theo report type mà hiển thị ngày trong tuần, số tuần, số tháng',
  })
  tag: string;

  @Expose()
  @ApiProperty()
  rangeDate: string;

  @Expose()
  @ApiProperty({
    type: CountReport,
    isArray: true,
  })
  countReport: CountReport;
}

export class ReportProgressJobResponse extends SuccessResponse {
  @Expose()
  @ApiProperty({
    type: DataReport,
    isArray: true,
  })
  data: DataReport[];
}
