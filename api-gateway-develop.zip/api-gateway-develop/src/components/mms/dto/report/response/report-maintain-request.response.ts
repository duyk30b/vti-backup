import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

enum StatusReportMaintainRequestEnum {
  WAITING_CONFIRM,
  IN_PROGRESS,
  COMPLETED,
}

class CountReport {
  @Expose()
  @ApiProperty({
    description: 'Số lượng',
  })
  count: number;

  @Expose()
  @ApiProperty({
    enum: StatusReportMaintainRequestEnum,
    description: `
    WAITING_CONFIRM = 0,
    IN_PROGRESS = 1,
    COMPLETED = 2,
    `,
  })
  status: StatusReportMaintainRequestEnum;
}

class DataReport {
  @Expose()
  @ApiProperty()
  reportType: number;

  @Expose()
  @ApiProperty({
    description:
      'Tùy theo report type mà hiển thị ngày trong tuần, số tuần, số tháng',
  })
  tag: string;

  @Expose()
  @ApiProperty()
  rangeDate: string;

  @Expose()
  @ApiProperty({
    type: CountReport,
    isArray: true,
  })
  countReport: CountReport;
}

export class ReportMaintainRequestResponse extends SuccessResponse {
  @Expose()
  @ApiProperty({
    type: DataReport,
    isArray: true,
  })
  data: DataReport[];
}
