import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsDateString, IsNotEmpty, IsOptional } from 'class-validator';

export enum ReportType {
  WEEK = 0,
  MONTH = 1,
  QUARTER = 2,
}

export class ReportProgressJobQuery {
  @ApiProperty({
    description: 'Tuần: 0/Tháng: 1/Quý: 2',
    enum: ReportType,
  })
  @IsNotEmpty()
  reportType: ReportType;

  @ApiPropertyOptional({
    description: 'Ngày bắt đầu',
  })
  @IsDateString()
  @IsOptional()
  startDate: Date;

  @ApiPropertyOptional({
    description: 'Ngày kết thúc',
  })
  @IsDateString()
  @IsOptional()
  endDate: Date;
}
