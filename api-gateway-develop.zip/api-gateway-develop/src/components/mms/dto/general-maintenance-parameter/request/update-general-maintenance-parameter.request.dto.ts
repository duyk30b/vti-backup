import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';

export class UpdateGeneralMaintenanceParameterRequestDto {
  @ApiProperty()
  @Expose()
  @IsNotEmpty()
  @IsInt()
  time: number;
}
