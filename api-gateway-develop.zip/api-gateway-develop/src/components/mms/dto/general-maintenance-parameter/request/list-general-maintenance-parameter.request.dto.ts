export class ListGeneralMaintenanceParameterRequestDto {}
