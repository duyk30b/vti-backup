import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { DetailWarningResponse } from '../../warning/response/detail-warning.response.dto';
import { DetailDeviceAssignmentResponse } from './list-job-by-device.response.dto';
export class MaintainRequest {
  @ApiProperty({ example: '61cd1b1bcff2a6dc3c75b6ca' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'MT-61cd1b1bcff2a6dc3c75b6ca' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'Maintain Request' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'No Description' })
  @Expose()
  description: string;

  @ApiProperty({ example: '2021-11-30T00:00:00.000Z' })
  @Expose()
  completeExpectedDate: Date;

  @ApiProperty({ example: 1 })
  @Expose()
  type: number;

  @ApiProperty({ example: 1 })
  @Expose()
  priority: number;

  @ApiProperty({ example: 1 })
  @Expose()
  userId: number;

  @ApiProperty({ type: DetailDeviceAssignmentResponse })
  @Expose()
  @Type(() => DetailDeviceAssignmentResponse)
  deviceAssignment: DetailDeviceAssignmentResponse;

  @ApiProperty()
  @Expose()
  executionDate: Date;
}

export class DeatailChecklistTemplate {
  @ApiProperty()
  id: string;

  @ApiProperty()
  @Expose()
  title: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  status: Date;
}

export class ChecklistTemplate {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  checkType: string;

  @ApiProperty()
  @Expose()
  priority: number;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty({ type: DeatailChecklistTemplate, isArray: true })
  @Expose()
  @Type(() => DeatailChecklistTemplate)
  details: DeatailChecklistTemplate[];

  @ApiProperty({})
  @Expose()
  @Type(() => DetailDeviceAssignmentResponse)
  deviceAssignment: DetailDeviceAssignmentResponse;
}

class MaintenancePeriodWarningItem {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  priority: number;

  @ApiProperty()
  @Expose()
  completeExpectedDate: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty()
  @Expose()
  @Type(() => DetailDeviceAssignmentResponse)
  deviceAssignment: DetailDeviceAssignmentResponse;
}

export class ListJobResponse {
  @ApiProperty({ example: '61cd33d9be1e9a1ae9479661' })
  @Expose()
  id: string;

  @ApiProperty({ example: 'WO-61cd33d9be1e9a1ae9479661' })
  @Expose()
  code: string;

  @ApiProperty({ type: MaintainRequest })
  @Expose()
  @Type(() => MaintainRequest)
  maitainRequest: MaintainRequest;

  @ApiProperty({ example: '2021-11-30T00:00:00.000Z' })
  @Expose()
  planDate: Date;

  @ApiProperty({ example: 1 })
  @Expose()
  type: string;

  @ApiProperty({ example: 1 })
  @Expose()
  status: string;

  @ApiProperty({ type: ChecklistTemplate })
  @Expose()
  @Type(() => ChecklistTemplate)
  checklistTemplate: ChecklistTemplate;

  @ApiProperty({ type: DetailWarningResponse })
  @Expose()
  @Type(() => DetailWarningResponse)
  warning: DetailWarningResponse;

  @ApiProperty({ type: MaintenancePeriodWarningItem })
  @Expose()
  @Type(() => MaintenancePeriodWarningItem)
  maintenancePeriodWarning: MaintenancePeriodWarningItem;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;
}
