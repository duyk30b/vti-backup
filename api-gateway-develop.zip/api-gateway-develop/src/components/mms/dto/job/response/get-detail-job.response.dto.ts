import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { DetailWarningResponse } from '../../warning/response/detail-warning.response.dto';
import { DetailDeviceAssignmentResponse } from './list-job-by-device.response.dto';
import { ChecklistTemplate } from './list-job.response.dto';

class Request {
  @Expose()
  @ApiProperty({ example: '01' })
  id: string;

  @Expose()
  @ApiProperty({ example: '01' })
  code: string;

  @Expose()
  @ApiProperty({ example: 'Maintain Request' })
  name: string;

  @Expose()
  @ApiProperty({ example: 1 })
  prioriry: number;

  @Expose()
  @ApiProperty({ example: '' })
  description: string;

  @Expose()
  @ApiProperty({ example: '2021-11-30T00:00:00.000Z' })
  completeExpectedDate: Date;

  @Expose()
  @ApiProperty({ type: DetailDeviceAssignmentResponse })
  @Type(() => DetailDeviceAssignmentResponse)
  deviceAssignment: DetailDeviceAssignmentResponse;
}

class AssignUser {
  @Expose()
  @ApiProperty({ example: 1 })
  userId: number;

  @Expose()
  @ApiProperty({ example: 'User Name' })
  name: string;

  @Expose()
  @ApiProperty({ example: 'User Full Name' })
  fullName: string;
}

class History {
  @Expose()
  @ApiProperty({ example: '01' })
  id: string;

  @Expose()
  @ApiProperty({ example: 1 })
  userId: number;

  @Expose()
  @ApiProperty({ example: 'created' })
  action: string;

  @ApiProperty()
  content: string;

  @Expose()
  @ApiProperty({ example: '2021-11-30T00:00:00.000Z' })
  createdAt: Date;
}
class SupplyMaintenancePeriodWarning {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  price: number;
}
class MaintenancePeriodWarningItem {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  priority: number;

  @ApiProperty()
  @Expose()
  completeExpectedDate: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty()
  @Expose()
  @Type(() => DetailDeviceAssignmentResponse)
  deviceAssignment: DetailDeviceAssignmentResponse;

  @ApiProperty()
  @Expose()
  @Type(() => SupplyMaintenancePeriodWarning)
  supply: SupplyMaintenancePeriodWarning;
}

class DetailPlan {
  @ApiProperty({ example: '62184abdd9668510e50844a1' })
  @Expose()
  id: string;

  @ApiProperty({ example: 'plan name' })
  @Expose()
  name: string;
}

export class DetailInstallationTemplate {
  @ApiProperty()
  id: string;

  @ApiProperty()
  @Expose()
  title: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  subtitle: string;

  @ApiProperty()
  @Expose()
  obligatory: boolean;
}
export class InstallationTemplate {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  checkType: string;

  @ApiProperty()
  @Expose()
  priority: number;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty({ type: DetailInstallationTemplate, isArray: true })
  @Expose()
  @Type(() => DetailInstallationTemplate)
  details: DetailInstallationTemplate[];

  @ApiProperty({})
  @Expose()
  @Type(() => DetailDeviceAssignmentResponse)
  deviceAssignment: DetailDeviceAssignmentResponse;
}
class JobItem {
  @Expose()
  @ApiProperty({ example: '01' })
  id: number;

  @Expose()
  @ApiProperty({ example: '01' })
  code: string;

  @Expose()
  @ApiProperty({ example: 'Sua ban phim' })
  name: string;

  @Expose()
  @ApiProperty({ example: 1 })
  status: number;

  @Expose()
  @ApiProperty({ example: '2021-11-30T00:00:00.000Z' })
  planDate: Date;

  @Expose()
  @ApiProperty({ example: 1 })
  type: number;

  @Expose()
  @ApiProperty({ type: Request })
  @Type(() => Request)
  maintainRequest: Request;

  @ApiProperty({ type: ChecklistTemplate })
  @Expose()
  checklistTemplate: ChecklistTemplate;

  @ApiProperty({ type: InstallationTemplate })
  @Expose()
  installationTemplate: InstallationTemplate;

  @ApiProperty({ type: DetailWarningResponse })
  @Expose()
  warning: DetailWarningResponse;

  @ApiProperty({ type: MaintenancePeriodWarningItem })
  @Expose()
  @Type(() => MaintenancePeriodWarningItem)
  maintenancePeriodWarning: MaintenancePeriodWarningItem;

  @ApiProperty({ type: History, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => History)
  histories: History[];

  @Expose()
  @ApiProperty({ example: 1 })
  maintenanceType: number;

  @ApiProperty({ type: AssignUser, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => AssignUser)
  assignUsers: AssignUser[];

  @ApiProperty()
  @Expose()
  planFrom: Date;

  @ApiProperty()
  @Expose()
  planTo: Date;

  @ApiProperty()
  @Expose()
  executionDateFrom: Date;

  @ApiProperty()
  @Expose()
  executionDateTo: Date;

  @ApiProperty({ description: 'Ngày bảo trì dự kiến' })
  estMaintenceDate: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty({ type: DetailPlan })
  @Expose()
  @Type(() => DetailPlan)
  plan: DetailPlan;

  @ApiProperty()
  @Expose()
  updatedAt: Date;
}

export class DetailJobResponse extends SuccessResponse {
  @Expose()
  @ApiProperty()
  data: JobItem;
}
