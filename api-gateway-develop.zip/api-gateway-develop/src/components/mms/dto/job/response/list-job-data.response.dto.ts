import { ApiProperty } from '@nestjs/swagger';
import { Meta } from '@utils/common.response';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

class ListJobData {
  @ApiProperty({
    type: String,
  })
  @Expose()
  id: string;

  @ApiProperty({
    type: String,
  })
  @Expose()
  serial: string;

  @ApiProperty({
    type: String,
  })
  @Expose()
  deviceName: string;

  @ApiProperty({
    type: String,
  })
  @Expose()
  description: string;

  @ApiProperty({
    type: String,
  })
  @Expose()
  status: string;

  @ApiProperty({
    type: Date,
  })
  @Expose()
  planFrom: Date;

  @ApiProperty({
    type: Date,
  })
  @Expose()
  planTo: Date;

  @ApiProperty({
    type: Date,
  })
  @Expose()
  executionDateFrom: Date;

  @ApiProperty({
    type: Date,
  })
  @Expose()
  executionDateTo: Date;
}

class ListJobDataResponse {
  @ApiProperty({ type: ListJobData, isArray: true })
  @Expose()
  items: ListJobData[];

  @ApiProperty({ type: Meta })
  @Expose()
  meta: Meta;
}

export class ListJobDataResponseDto extends SuccessResponse {
  @ApiProperty({ type: ListJobDataResponse })
  @Expose()
  data: ListJobDataResponse;
}
