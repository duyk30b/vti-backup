import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

class SparePart {
  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  type: number;

  @Expose()
  unit: string;

  @Expose()
  price: number;

  @Expose()
  quantity: number;
}

class DeviceAssignment {
  @Expose()
  id: '624a9cb7b193e0cc2e0bdd7e';

  @Expose()
  name: 'máy bay';

  @Expose()
  serial: 'mb22001';

  @Expose()
  sparePartDetails: SparePart[];
}

class WorkCenter {
  @Expose()
  id: number;

  @Expose()
  name: string;
}

class Factory {
  @Expose()
  id: number;

  @Expose()
  name: string;
}

class JobCreateSuppyRequestResponseDto {
  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  deviceAssignment: DeviceAssignment;

  @Expose()
  workCenter: WorkCenter;

  @Expose()
  factory: Factory;
}

export class ListJobCreateSuppyRequestResponseDto extends SuccessResponse {
  @Expose()
  @ApiProperty({
    example: [
      {
        code: 'P000000001',
        name: 'công việc 1',
        deviceAssignment: {
          id: '624a9cb7b193e0cc2e0bdd7e',
          name: 'máy bay',
          serial: 'mb22001',
          sparePartDetails: [
            {
              code: 'VT001',
              name: 'Vật tư 001',
              type: 1,
              unit: 'lít',
              price: 20000,
              quantity: 1,
            },
            {
              code: 'PT001',
              name: 'Phụ tùng 001',
              type: 0,
              unit: 'cái',
              price: 11000,
              quantity: 10,
            },
          ],
        },
        workCenter: {
          id: 1,
          name: 'xưởng 1',
        },
        factory: {
          id: 1,
          name: 'nhà máy 1',
        },
      },
    ],
    isArray: true,
  })
  data: JobCreateSuppyRequestResponseDto[];
}
