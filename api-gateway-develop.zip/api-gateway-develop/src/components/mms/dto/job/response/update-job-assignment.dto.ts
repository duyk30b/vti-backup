import { DetailJobResponse } from './get-detail-job.response.dto';
export class UpdateJobAssignmentResponseDto extends DetailJobResponse {}
