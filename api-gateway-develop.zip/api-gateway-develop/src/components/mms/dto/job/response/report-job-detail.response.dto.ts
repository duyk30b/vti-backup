import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';

export class ReportJobDetailResponse {
  @ApiProperty({ type: Number })
  @Expose()
  userId: number;

  @ApiProperty({ type: String })
  @Expose()
  userCode: string;

  @ApiProperty({ type: String })
  @Expose()
  userRole: string;

  @ApiProperty({ type: String })
  @Expose()
  fullName: string;

  @ApiProperty({ type: Date })
  @Expose()
  startWork: Date;

  @ApiProperty({ type: Number })
  @Expose()
  totalQuantity: number;

  @ApiProperty({ type: Number })
  @Expose()
  successQuantity: number;

  @ApiProperty({ type: Number })
  @Expose()
  executeQuantity: number;

  @ApiProperty({ type: Number })
  @Expose()
  lateQuantity: number;

  @ApiProperty({ type: Number })
  @Expose()
  waitQuantity: number;

  @ApiProperty({ type: Number })
  @Expose()
  planQuantity: number;

  @ApiProperty({ type: Number })
  @Expose()
  incurredQuantity: number;
}

export class ReportJobDetailResponseDto extends SuccessResponse {
  @ApiProperty({ type: ReportJobDetailResponse })
  @Type(() => ReportJobDetailResponse)
  @Expose()
  data: ReportJobDetailResponse;
}
