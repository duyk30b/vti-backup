import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { Type } from 'class-transformer';
import { IsArray, IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class Filter {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  column: string;

  @IsString()
  @ApiProperty()
  @IsNotEmpty()
  text: string;
}

export class ListJobProgressRequestDto extends PaginationQuery {
  @ApiPropertyOptional({
    example: [{ columm: 'name', text: 'abc' }],
    description:
      'Mã công việc: jobCode <br /> ' +
      'Mã yêu cầu/cảnh báo: warningCode <br /> ' +
      'Loại công việc: type <br /> ' +
      'Tên yêu cầu/cảnh báo: warningName <br /> ' +
      'Người thực hiện: user <br /> ' +
      'Serial: serial <br /> ' +
      'Tên thiết bị: deviceName <br /> ' +
      'Mô tả: warningDescription <br /> ' +
      'Độ ưu tiên: warningPriority <br /> ' +
      'Ngày thực hiện dự kiến (bắt đầu): planFrom <br /> ' +
      'Ngày thực hiện dự kiến (kết thúc): planTo <br /> ' +
      'Ngày thực hiện thực tế (bắt đầu): executionDateFrom <br /> ' +
      'Ngày thực hiện thực tế (kết thúc): executionDateTo',
  })
  @IsOptional()
  @IsArray()
  @Type(() => Filter)
  filter?: Filter[];
}
