import { PaginationQuery } from '@utils/pagination.query';
import {
  IsOptional,
  IsNotEmpty,
  IsString,
  IsArray,
  IsIn,
} from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';

class Filter {
  @IsString()
  @IsNotEmpty()
  column: string;

  @IsString()
  @IsNotEmpty()
  text: string;
}
export class JobItemQuery extends PaginationQuery {
  @ApiPropertyOptional()
  @IsOptional()
  user: number;
}
