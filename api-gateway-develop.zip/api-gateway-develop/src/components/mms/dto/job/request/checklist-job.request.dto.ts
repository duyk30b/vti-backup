import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsDateString,
  IsNotEmpty,
  IsOptional,
  IsString,
  ValidateNested,
  IsEnum,
  MaxLength,
} from 'class-validator';

class Detail {
  @IsString()
  @IsNotEmpty()
  id: string;

  @IsNotEmpty()
  @IsEnum(['0', '1'])
  status: string;
}

export class ChecklistJobRequestDto {
  @ApiProperty({ example: 'description' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  description: string;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  executionDateFrom: Date;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  executionDateTo: Date;

  @ApiProperty({ example: '1', description: 'Kết quả kiểm tra' })
  @IsNotEmpty()
  @IsEnum(['0', '1'])
  checkType: string;

  @ApiProperty({
    example: [
      {
        id: 'string',
        status: 1,
      },
    ],
  })
  @IsArray()
  @IsNotEmpty()
  @ValidateNested()
  details: Detail[];

  @ApiProperty({ example: 1 })
  @IsEnum(['0', '1'])
  @IsNotEmpty()
  checklistConclude: number;
}
