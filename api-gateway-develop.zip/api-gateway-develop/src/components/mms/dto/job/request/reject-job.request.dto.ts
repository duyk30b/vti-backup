import { IsOptional, IsString, MaxLength } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class JobRejectRequestDto {
  @ApiProperty()
  @IsOptional()
  @IsString()
  @MaxLength(255)
  reason: string;
}
