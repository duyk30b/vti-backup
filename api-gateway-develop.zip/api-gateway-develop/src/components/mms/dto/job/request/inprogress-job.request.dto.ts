import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsDateString } from 'class-validator';

export class InprogressJobRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  executionDateFrom: string;
}
