import {
  IsNotEmpty,
  IsDateString,
  IsInt,
  IsMongoId,
  IsOptional,
  IsArray,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class JobAssignmentRequestDto {
  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  planFrom: Date;

  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  planTo: Date;

  @ApiProperty()
  @IsArray()
  @IsNotEmpty()
  assignUser: string[];

  @ApiProperty()
  @IsMongoId()
  @IsOptional()
  planId: string;
}
