import { IsEnum, IsOptional } from 'class-validator';

export class DetailJobQuery {
  @IsEnum(['0', '1'])
  @IsOptional()
  isDraft: string;
}
