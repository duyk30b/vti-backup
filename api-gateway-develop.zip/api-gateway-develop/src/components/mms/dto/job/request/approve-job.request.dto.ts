import { ApiProperty } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsEnum,
  IsInt
} from 'class-validator';

export class ApproveJobRequestDto {
}
