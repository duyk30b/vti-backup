import { JOB_TYPE_MAINTENANCE_ENUM } from '@components/mms/constant/maintain-type.constant';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  IsEnum,
  MaxLength,
  IsNumber,
  ValidateNested,
} from 'class-validator';

class Supply {
  @IsString()
  @IsNotEmpty()
  supplyId: string;

  @IsInt()
  @IsNotEmpty()
  quantity: number;

  @IsString()
  @IsOptional()
  @MaxLength(500)
  description: string;

  @ApiProperty({ example: 1 })
  @IsEnum(JOB_TYPE_MAINTENANCE_ENUM)
  @IsNotEmpty()
  maintenanceType: number;
}

export class Detail {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  title: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;

  @ApiProperty()
  @IsEnum([1, 0])
  @IsNotEmpty()
  obligatory: number;

  @IsString()
  @IsOptional()
  subtitle: string;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  @IsEnum([1, 0])
  status: number;
}

export class ExecuteJobRequestDto {
  @ApiProperty({ example: 'description' })
  @IsString()
  @IsNotEmpty()
  description: string;

  @ApiProperty({ example: 1 })
  @IsEnum(JOB_TYPE_MAINTENANCE_ENUM)
  @IsNotEmpty()
  maintenanceType: number;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  executionDateFrom: Date;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  executionDateTo: Date;

  @ApiProperty({
    example: [
      {
        supplyId: '1',
        quantity: 1,
        description: 'description',
        maintainType: 1,
      },
    ],
  })
  @IsArray()
  @IsOptional()
  supplies: Supply[];

  // job type = 5 || công việc lắp đặt
  @ApiProperty()
  @IsOptional()
  @IsNumber()
  executionTime: number;

  @ApiProperty({ type: Detail, isArray: true })
  @IsArray()
  @IsNotEmpty()
  @ValidateNested()
  @IsOptional()
  details: Detail[];

  @ApiProperty({ example: 0 })
  @IsEnum([1, 0])
  @IsOptional()
  result: number;
}
