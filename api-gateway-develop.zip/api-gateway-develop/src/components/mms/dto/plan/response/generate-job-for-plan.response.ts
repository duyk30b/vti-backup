import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class GenerateJobForPlanResponse {
  @ApiProperty({ type: String })
  @Expose()
  code: string;

  @ApiProperty({ type: String })
  @Expose()
  deviceName: string;

  @ApiProperty({ type: String })
  @Expose()
  serial: string;

  @ApiProperty({ type: String })
  @Expose()
  assignUser: string;

  @ApiProperty({ type: Date })
  @Expose()
  planFrom: Date;

  @ApiProperty({ type: Date })
  @Expose()
  planTo: Date;

  @ApiProperty({ type: Date })
  @Expose()
  executedFrom: Date;

  @ApiProperty({ type: Date })
  @Expose()
  executedTo: Date;

  @ApiProperty({
    type: Number,
    description: `NON_ASSIGN = 1, // Chưa đc phân công
  WAITING_TO_CONFIRMED = 2, // Chờ xác nhận
  REJECTED = 3, // Từ chối
  TO_DO = 4, // Chưa thực hiện
  IN_PROGRESS = 5, // Đang thực hiện
  COMPLETED = 6, // Đã thực hiện
  OUT_OF_DATE = 7, // Quá hạn chưa thực hiện
  LATE = 8, // Quá hạn đang thực hiện
  RESOLVED = 9, // hoàn thành`,
  })
  @Expose()
  status: number;

  @ApiProperty({
    type: Number,
    description: `Loại công việc`,
  })
  @Expose()
  type: number;
}
