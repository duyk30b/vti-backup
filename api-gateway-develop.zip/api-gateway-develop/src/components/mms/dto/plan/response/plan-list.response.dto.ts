import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

class ListPlanItem {
  @ApiProperty({ type: String })
  @Expose()
  id: string;

  @Expose()
  @ApiProperty({
    type: String,
  })
  name: string;

  @Expose()
  @ApiProperty({
    type: String,
  })
  code: string;

  @Expose()
  @ApiProperty({
    type: Date,
  })
  planFrom: Date;

  @Expose()
  @ApiProperty({
    type: Date,
  })
  planTo: Date;

  @Expose()
  @ApiProperty({
    type: Number,
  })
  status: number;

  @Expose()
  @ApiProperty({
    type: Number,
  })
  jobPlanTotal: number;

  @Expose()
  @ApiProperty({
    type: Number,
  })
  jobExecutionTotal: number;
}

export class ListPlanItemResponse extends SuccessResponse {
  @Expose()
  @ApiProperty({
    type: [ListPlanItem],
  })
  data: [ListPlanItem];
}
