import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import {
  IsArray,
  IsDateString,
  IsEnum,
  IsMongoId,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  Min,
} from 'class-validator';

export enum ASSIGN_TYPE {
  USER,
  TEAM,
}
class JobTypeTotal {
  @ApiPropertyOptional({ description: 'Số lượng cảnh báo', type: Number })
  @IsNumber()
  @IsOptional()
  warningTotal: number;

  @ApiPropertyOptional({
    description: 'Số lượng yêu cầu người dùng',
    type: Number,
  })
  @IsNumber()
  @IsOptional()
  maintainRequestTotal: number;

  @ApiPropertyOptional({
    description: 'Số lượng kiểm tra định kỳ',
    type: Number,
  })
  @IsNumber()
  @IsOptional()
  maintainPeriodWarningTotal: number;

  @ApiPropertyOptional({ description: 'Số lượng bảo dưỡng', type: Number })
  @IsNumber()
  @IsOptional()
  checklistTemplateTotal: number;

  @ApiPropertyOptional({ description: 'Số lượng lắp đặt', type: Number })
  @IsNumber()
  @IsOptional()
  installingTotal: number;
}

export enum JOB_STATUS_ENUM {
  NON_ASSIGN = 1, // Chưa đc phân công
  WAITING_TO_CONFIRMED = 2, // Chờ xác nhận
  REJECTED = 3, // Từ chối
  TO_DO = 4, // Chưa thực hiện
  IN_PROGRESS = 5, // Đang thực hiện
  COMPLETED = 6, // Đã thực hiện
  OUT_OF_DATE = 7, // Quá hạn chưa thực hiện
  LATE = 8, // Quá hạn đang thực hiện
  RESOLVED = 9, // hoàn thành
}

export enum JOB_TYPE_ENUM {
  WARNING = 1,
  SCHEDULE_MAINTAIN = 2,
  REQUEST = 3,
  PERIOD_CHECK = 4,
  PLAN_MAINTENANCE = 5,
  PLAN_PERIOD_CHECK = 6,
  PLAN_INSTALLATION = 7,
}

class Device {
  @ApiPropertyOptional({ description: 'Tên thiết bị', type: String })
  @IsString()
  @IsNotEmpty()
  name: string;
}

class DeviceAssignment {
  @ApiPropertyOptional({ description: 'Thiết bị', type: Device })
  @Type(() => Device)
  @IsOptional()
  device: Device;

  @ApiPropertyOptional({ description: 'Mã serial', type: String })
  @IsString()
  @IsNotEmpty()
  serial: string;
}

class UserInfo {
  @ApiPropertyOptional({ description: 'Id member', type: Number })
  @IsNumber()
  userId: number;

  @ApiPropertyOptional({ description: 'Id team', type: Number })
  @Expose()
  @IsNumber()
  teamId: number;

  @ApiPropertyOptional({ description: 'Tên đầy đủ', type: String })
  @IsString()
  @IsNotEmpty()
  fullName: string;

  @ApiPropertyOptional({ description: 'Tên', type: String })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiPropertyOptional({ description: 'Mã team', type: ASSIGN_TYPE })
  @IsString()
  @IsNotEmpty()
  @IsEnum(ASSIGN_TYPE)
  type: any;
}

class DetailPlan {
  @ApiPropertyOptional({ description: 'Loại công việc', type: JOB_TYPE_ENUM })
  @IsNumber()
  @IsNotEmpty()
  type: number;

  @ApiPropertyOptional({ description: 'Phân công', type: DeviceAssignment })
  @Type(() => DeviceAssignment)
  @IsNotEmpty()
  deviceAssignment: DeviceAssignment;

  @ApiPropertyOptional({ description: 'Tên công việc', type: DeviceAssignment })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiPropertyOptional({ description: 'Mô tả công việc', type: String })
  @IsString()
  @IsNotEmpty()
  description: string;

  @ApiPropertyOptional({ description: 'Ngày dự tính bắt đầu', type: Date })
  @IsDateString()
  @IsNotEmpty()
  planFrom: Date;

  @ApiPropertyOptional({ description: 'Ngày dự tính kết thúc', type: Date })
  @IsDateString()
  @IsNotEmpty()
  planTo: Date;

  @ApiPropertyOptional({ description: 'Ngày thực tế bắt đầu', type: Date })
  @IsDateString()
  @IsNotEmpty()
  executionDateFrom: Date;

  @ApiPropertyOptional({ description: 'Ngày thực tế kết thúc', type: Date })
  @IsDateString()
  @IsNotEmpty()
  executionDateTo: Date;

  @ApiPropertyOptional({ description: 'Người thực hiện', type: UserInfo })
  @IsString()
  @IsNotEmpty()
  assignUsers: UserInfo[];
}

export class PlanDetailResponseDto {
  @ApiPropertyOptional({ description: 'Mã kế hoạch', type: String })
  @MaxLength(8)
  @IsString()
  @IsNotEmpty()
  code: string;

  @ApiPropertyOptional({ description: 'Tên kế hoạch', type: String })
  @MaxLength(50)
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiPropertyOptional({ description: 'Ngày dự tính bắt đầu', type: Date })
  @IsDateString()
  @IsNotEmpty()
  planFrom: Date;

  @ApiPropertyOptional({ description: 'Ngày dự tính kết thúc', type: Date })
  @IsDateString()
  @IsNotEmpty()
  planTo: Date;

  @Expose()
  @Type(() => JobTypeTotal)
  @IsOptional()
  jobTypeTotal: JobTypeTotal;

  @Expose()
  @Type(() => JobTypeTotal)
  @IsOptional()
  jobTypeExecutionTotal: JobTypeTotal;

  @Expose()
  @Type(() => DetailPlan)
  @IsArray()
  @IsOptional()
  jobs: DetailPlan[];
}
