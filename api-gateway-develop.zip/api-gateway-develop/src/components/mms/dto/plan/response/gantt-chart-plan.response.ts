import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

class DetailGanChartPlanJobDevice {
  @ApiProperty({ type: String })
  @Expose()
  id: string;

  @ApiProperty({ type: String })
  @Expose()
  code: string;

  @ApiProperty({ type: String })
  @Expose()
  name: string;

  @ApiProperty({ type: String })
  @Expose()
  serial: string;
}

class DetailGanChartPlanJobAssign {
  @ApiProperty({ type: String })
  @Expose()
  id: string;

  @ApiProperty({ type: String })
  @Expose()
  name: string;
}

export class DetailGanChartPlanJob {
  @ApiProperty({ type: String })
  @Expose()
  id: string;

  @ApiProperty({ type: String })
  @Expose()
  code: string;

  @ApiPropertyOptional({ type: String })
  @Expose()
  name: string;

  @ApiPropertyOptional({ type: String })
  @Expose()
  description: string;

  @ApiProperty({ type: Number })
  @Expose()
  type: number;

  @ApiProperty({ type: Number })
  @Expose()
  status: number;

  @ApiProperty({ type: Date })
  @Expose()
  planFrom: Date;

  @ApiProperty({ type: Date })
  @Expose()
  planTo: Date;

  @ApiPropertyOptional({ type: Date })
  @Expose()
  endDate: Date;

  @ApiPropertyOptional({ type: Date })
  @Expose()
  executionDateFrom: Date;

  @ApiPropertyOptional({ type: Date })
  @Expose()
  executionDateTo: Date;

  @ApiProperty({ type: DetailGanChartPlanJobDevice })
  @Expose()
  device: DetailGanChartPlanJobDevice;

  @ApiProperty({ type: DetailGanChartPlanJobAssign })
  @Expose()
  assign: DetailGanChartPlanJobAssign;
}

export class DetailGanttChartPlan {
  @ApiProperty({ type: String })
  @Expose()
  id: string;

  @ApiProperty({ type: String })
  @Expose()
  code: string;

  @ApiProperty({ type: String })
  @Expose()
  name: string;

  @ApiProperty({ type: Number })
  @Expose()
  status: number;

  @ApiProperty({ type: Date })
  @Expose()
  planFrom: Date;

  @ApiProperty({ type: Date })
  @Expose()
  planTo: Date;

  @ApiPropertyOptional({ type: Date })
  @Expose()
  endDate: Date;

  @ApiProperty({ type: DetailGanChartPlanJob, isArray: true })
  @Expose()
  jobs: DetailGanChartPlanJob[];
}

class MetaGanttChartPlan {
  @ApiProperty({ type: Number })
  @Expose()
  page: number;

  @ApiProperty({ type: Number })
  @Expose()
  total: number;
}

class MetaDataGanttChartPlan {
  @ApiProperty({ type: DetailGanttChartPlan, isArray: true })
  @Expose()
  items: DetailGanttChartPlan[];

  @ApiProperty({ type: MetaGanttChartPlan })
  @Expose()
  meta: MetaGanttChartPlan;
}

export class GanttChartPlanResponse extends SuccessResponse {
  @ApiProperty({ type: MetaDataGanttChartPlan })
  @Expose()
  data: MetaDataGanttChartPlan;
}
