import { ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsOptional } from 'class-validator';
export class GanttChartPlanQuery {
  @ApiPropertyOptional({
    description: 'Truyền lên id khi chọn công việc của tôi',
    type: Number,
  })
  @Transform((data) => Number(data.value))
  @IsOptional()
  user: number;
}
