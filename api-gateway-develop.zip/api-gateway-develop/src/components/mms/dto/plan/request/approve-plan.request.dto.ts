import { ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsString, MaxLength } from 'class-validator';
export class ApprovePlanRequestDto {
  @ApiProperty({ example: 'reason' })
  @IsString()
  @IsOptional()
  @MaxLength(225)
  reason: string;
}
