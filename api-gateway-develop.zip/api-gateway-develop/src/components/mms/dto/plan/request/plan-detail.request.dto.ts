import { Filter, PaginationQuery, Sort } from '@utils/pagination.query';
import { IsOptional, IsArray, Allow } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';

export class PlanDetailRequestDto {
  @ApiPropertyOptional({
    example: 'AB',
    description: `
    Lọc chi tiết kế hoạch: <br/>
    Mã công việc = code <br/>
    Tên công việc = name <br/>
    Serial = serial <br/>
    Tên thiết bị = nameDevice <br/>
    Mô tả = description <br/>
    Trạng thái = status <br/>
    Loại công việc = type <br/>
    Thời gian dự kiến bắt đầu  = planFrom <br/>
    Thời gian dự kiến kết thúc  = planTo <br/>
    Thời gian thực tế bắt đầu  = executionDateFrom <br/>
    Thời gian thực tế kết thúc  = executionDateTo <br/>
  `,
  })
  @IsOptional()
  @IsArray()
  @Type(() => Filter)
  filter?: Filter[];

  @Allow()
  @Transform((value) => {
    return Number(value.value) || 1;
  })
  @ApiProperty({
    type: Number,
  })
  page?: number;

  @Allow()
  @ApiProperty({
    type: Number,
  })
  limit?: number;
}
