import { Filter, PaginationQuery, Sort } from '@utils/pagination.query';
import { IsOptional, IsNotEmpty, IsString, IsArray } from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class PlanItemQuery extends PaginationQuery {
  @ApiPropertyOptional({
    example: 'Kế hoạch bảo trì',
    description: 'Tên kế hoạch & Mã kế hoạch',
  })
  @IsOptional()
  @IsString()
  keyword?: string;
}
