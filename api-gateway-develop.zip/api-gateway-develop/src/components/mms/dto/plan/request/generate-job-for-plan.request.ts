import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsDateString,
  IsNotEmpty,
  IsNumber,
  IsOptional,
} from 'class-validator';

export class GenerateJobForPlanRequest {
  @ApiProperty({ description: 'ID nhà máy', type: Number })
  @IsNumber()
  @IsNotEmpty()
  factoryId: number;

  @ApiPropertyOptional({ description: 'ID xưởng', type: Number })
  @IsNumber()
  @IsOptional()
  workCenterId: number;

  @ApiPropertyOptional({ description: 'Thời gian bắt đầu', type: Date })
  @IsDateString()
  @IsNotEmpty()
  planFrom: Date;

  @ApiPropertyOptional({ description: 'Thời gian kết thúc', type: Date })
  @IsDateString()
  @IsNotEmpty()
  planTo: Date;
}
