import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsDateString,
  IsMongoId,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';

class JobTypeTotal {
  @ApiPropertyOptional({ description: 'Số lượng', type: Number })
  @IsNumber()
  @IsOptional()
  warningTotal: number;

  @ApiPropertyOptional({ description: 'Số lượng', type: Number })
  @IsNumber()
  @IsOptional()
  maintainRequestTotal: number;

  @ApiPropertyOptional({ description: 'Số lượng', type: Number })
  @IsNumber()
  @IsOptional()
  maintainPeriodWarningTotal: number;

  @ApiPropertyOptional({ description: 'Số lượng', type: Number })
  @IsNumber()
  @IsOptional()
  checklistTemplateTotal: number;

  @ApiPropertyOptional({ description: 'Số lượng', type: Number })
  @IsNumber()
  @IsOptional()
  installingTotal: number;
}

class DetailPlan {
  @ApiProperty({ description: 'Loại công việc', type: Number })
  @IsNumber()
  @IsNotEmpty()
  type: number;

  @ApiProperty({ description: 'Id device assign', type: String })
  @IsMongoId()
  @IsNotEmpty()
  deviceAssignmentId: string;

  @ApiProperty({ description: 'Tên của công việc', type: String })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({ description: 'Mô tả của công việc', type: String })
  @IsString()
  @IsNotEmpty()
  description: string;

  @ApiProperty({ description: 'Ngày dự kiến bắt đầu', type: Date })
  @IsDateString()
  @IsNotEmpty()
  planFrom: Date;

  @ApiProperty({ description: 'Ngày dự kiến kết thúc', type: Date })
  @IsDateString()
  @IsNotEmpty()
  planTo: Date;

  @ApiProperty({ description: 'Người/Đội được phân công', type: String })
  @IsString()
  @IsNotEmpty()
  assign: string;
}

export class CreatePlanRequestDto {
  @ApiProperty({ description: 'Code của kế hoạch', type: String })
  @MaxLength(8)
  @IsString()
  @IsNotEmpty()
  code: string;

  @ApiProperty({ description: 'Tên của kế hoạch', type: String })
  @MaxLength(50)
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({ description: 'Ngày dự kiến bắt đầu', type: Date })
  @IsDateString()
  @IsNotEmpty()
  planFrom: Date;

  @ApiProperty({ description: 'Ngày dự kiến kết thúc', type: Date })
  @IsDateString()
  @IsNotEmpty()
  planTo: Date;

  @ApiProperty({ description: 'ID nhà máy', type: Number })
  @IsNumber()
  @IsNotEmpty()
  factoryId: number;

  @ApiPropertyOptional({ description: 'ID xưởng', type: Number })
  @IsNumber()
  @IsOptional()
  workCenterId: number;

  @ApiPropertyOptional({ description: 'Kế hoạch tổng thể', type: JobTypeTotal })
  @IsOptional()
  jobTypeTotal: JobTypeTotal;

  @ApiPropertyOptional({
    description: 'Kế hoạch chi tiết',
    type: DetailPlan,
    isArray: true,
  })
  @IsOptional()
  jobs: DetailPlan[];
}
