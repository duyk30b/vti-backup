export enum SupplyStatusConstant {
  Awaiting,
  Confirmed,
  Completed,
}
export const SUPPLY_CONST = {
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
  CODE: {
    MAX_LENGTH: 7,
  },
  NAME: {
    MAX_LENGTH: 255,
  },
};

export enum SupplyTypeConstant {
  SUPPLY,
  ACCESSORY,
}
