export const DEFECT_CONST = {
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
  CODE: {
    MAX_LENGTH: 9,
  },
  NAME: {
    MAX_LENGTH: 255,
  },
};
export enum DefectPriorityConstant {
  BLOCKER = 5,
  CRITICAL = 4,
  MAJOR = 3,
  MINOR = 2,
  TRIVIAL = 1,
}