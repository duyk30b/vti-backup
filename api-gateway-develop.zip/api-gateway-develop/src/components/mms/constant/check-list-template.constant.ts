export const CHECK_LIST_TEMPLATE_CONST = {
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
  CODE: {
    MAX_LENGTH: 50,
  },
  NAME: {
    MAX_LENGTH: 255,
  },
};
export enum CheckTypeConstant {
  PASSFAIL,
}
