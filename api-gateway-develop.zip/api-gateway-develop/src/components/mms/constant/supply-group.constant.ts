export enum SupplyGroupStatusConstant {
  Awaiting,
  Confirmed,
  Rejected,
  Completed,
}
export const SUPPLY_GROUP_CONST = {
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
  CODE: {
    MAX_LENGTH: 7,
  },
  NAME: {
    MAX_LENGTH: 255,
  },
};
