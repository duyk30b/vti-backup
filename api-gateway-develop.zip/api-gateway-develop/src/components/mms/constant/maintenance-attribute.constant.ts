export const MAINTENANCE_ATTRIBUTE_CONST = {
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
  CODE: {
    MAX_LENGTH: 7,
  },
  NAME: {
    MAX_LENGTH: 255,
  },
};
