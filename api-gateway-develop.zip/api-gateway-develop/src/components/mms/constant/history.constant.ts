export enum HistoryActionEnum {
  CREATE,
  UPDATE,
  DELETE
}