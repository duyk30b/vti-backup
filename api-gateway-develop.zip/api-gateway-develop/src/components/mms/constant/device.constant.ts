export enum DeviceType {
  Normal,
  ForManufacture,
}

export enum DeviceStatus {
  AwaitingConfirmation,
  Confirmed,
}

export enum ResponsibleSubjectType {
  User,
  MaintenanceTeam,
}
