export enum MaintenanceTeamMemberRoleConstant {
  LEADER,
  MEMBER,
}