export const DEVICE_GROUP_CONST = {
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
  CODE: {
    MAX_LENGTH: 7,
  },
  NAME: {
    MAX_LENGTH: 255,
  },
};

export enum DeviceGroupStatusEnum {
  AWAITING,
  CONFIRMED,
  COMPLETED
}
