export enum DeviceRequestTicketStatus {
  AwaitingConfirmation, // Waiting confirm
  AwaitingITConfirmation, // Waiting IT confirm
  AwaitingAssignment, // Waiting assign
  Assigned, // Assigned
  Confirmed, // Confirmed
  Rejected, // Rejected
}

export enum DeviceReturnTicketStatus {
  AwaitingConfirmation,
  AwaitingITConfirmation,
  AwaitingReturn,
  Returned,
  Rejected,
}

export enum DeviceRequestType {
  Request,
  Return,
}
