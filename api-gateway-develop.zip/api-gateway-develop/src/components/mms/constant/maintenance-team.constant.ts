export enum MaintenanceTeamStatusConstant {
  AWAITING,
  CONFIRMED,
  COMPLETED
}
export const MAINTENANCE_TEAM_CONST = {
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
  CODE: {
    MAX_LENGTH: 7,
  },
  NAME: {
    MAX_LENGTH: 255,
  },
};