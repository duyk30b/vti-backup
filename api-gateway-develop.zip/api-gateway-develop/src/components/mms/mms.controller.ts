import { ListSerialByDeviceIds } from './dto/device-assignment/request/list-serial-by-device-ids.request.dto';
import { UpdateStatusJobToReworkRequestDto } from './dto/job/request/update-status-job-to-rework.request.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Req,
  Query,
  Patch,
} from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { CreateMaintainRequestDto } from './dto/maintain-request/request/create-maintain-request.request';
import { ExecuteJobRequestDto } from './dto/job/request/execute-job.request.dto';
import { UpdateMaintainRequestDto } from './dto/maintain-request/request/update-maintain-request.request';
import { CreateWarningDto } from './dto/warning/request/create-warning.dto';
import { CreateWaringResponseDto } from './dto/warning/response/create-warning.response.dto';
import { DetailWarningDataResponseDto } from './dto/warning/response/detail-warning-data.response.dto';
import { ListJobDataResponseDto } from './dto/job/response/list-job-data.response.dto';
import { JobItemQuery } from './dto/job/request/job-item.query';
import { SuccessResponse } from '@utils/success.response.dto';
import { MaintainRequestResponse } from './dto/maintain-request/response/create-maintain-request.response';
import { EditJobRequestDto } from './dto/maintain-request/request/edit-job-request.request';
import { DashboardSummaryResponseDto } from './dto/dashboard/response/summary.response.dto';
import { GetDashboardRequestDto } from './dto/dashboard/request/get-dashboard.request.dto';
import { DashboardWarningPriorityDataResponseDto } from './dto/dashboard/response/warning-priority.response.dto';
import { DashboardWarningStatusDataResponseDto } from './dto/dashboard/response/warning-status.response.dto';
import { DashboardJobStatusDataResponseDto } from './dto/dashboard/response/job-status.response.dto';
import { DashboardDeviceAssignmentStatusDataResponseDto } from './dto/dashboard/response/device-assignment-status.response.dto';
import { ListMaintainRequestResponse } from './dto/maintain-request/response/list-maintain-request.response.dto';
import { DetailMaintainRequestResponse } from './dto/maintain-request/response/detail-maintain-request.response.dto';
import { ListJobByDeviceResponse } from './dto/job/response/list-job-by-device.response.dto';
import { CreateSupplyGroupResponseDto } from '@components/mms/dto/supply-group/response/create-supply-group.response.dto';
import { GetListSupplyGroupResponseDto } from '@components/mms/dto/supply-group/response/get-list-supply-group.response.dto';
import { UpdateSupplyGroupResponseDto } from '@components/mms/dto/supply-group/response/update-supply-group.response.dto';
import { UpdateDeviceGroupRequestDto } from '@components/mms/dto/device-group/request/update-device-group.request.dto';
import { GetListDeviceGroupRequestDto } from '@components/mms/dto/device-group/request/get-list-device-group.request.dto';
import { GetDetailSupplyGroupResponseDto } from '@components/mms/dto/supply-group/response/get-detail-supply-group.response.dto';
import { CreateDeviceGroupRequestDto } from '@components/mms/dto/device-group/request/create-device-group.request.dto';
import { UpdateSupplyGroupRequestDto } from '@components/mms/dto/supply-group/request/update-supply-group.request.dto';
import { GetListDevicesRequestDto } from '@components/mms/dto/device/request/get-list-device.request.dto';
import { ScanQrDeviceRequestDto } from '@components/mms/dto/device/request/scan-qr-device.request.dto';
import { DeviceCommonInfoResponseDto } from '@components/mms/dto/device/response/device-detail/device-common-info.response.dto';
import { DeviceMaintenanceInfoAppResponseDto } from '@components/mms/dto/device/response/device-detail/device-maintenance-info-app.response.dto';
import { ListMaintainRequestDto } from './dto/maintain-request/request/list-maintain-request.request.dto';
import { GetListMaintenanceTeamRequestDto } from '@components/mms/dto/maintenance-team/request/get-list-maintenance-team.request.dto';
import { GetListMaintenanceTeamResponseDto } from '@components/mms/dto/maintenance-team/response/get-list-maintenance-team.response.dto';
import { GetDetailMaintenanceTeamResponseDto } from '@components/mms/dto/maintenance-team/response/get-detail-maintenance-team.response.dto';
import { CreateMaintenanceTeamRequestDto } from '@components/mms/dto/maintenance-team/request/create-maintenance-team.request.dto';
import { UpdateMaintenanceTeamResponseDto } from '@components/mms/dto/maintenance-team/response/update-maintenance-team.response.dto';
import { UpdateMaintenanceTeamRequestDto } from '@components/mms/dto/maintenance-team/request/update-maintenance-team.request.dto';
import { GetListMaintenanceAttributeResponseDto } from '@components/mms/dto/maintenance-attribute/response/get-list-maintenance-attribute.response.dto';
import { GetListMaintenanceAttributeRequestDto } from '@components/mms/dto/maintenance-attribute/request/get-list-maintenance-attribute.request.dto';
import { GetDetailMaintenanceAttributeResponseDto } from '@components/mms/dto/maintenance-attribute/response/get-detail-maintenance-attribute.response.dto';
import { CreateMaintenanceAttributeResponseDto } from '@components/mms/dto/maintenance-attribute/response/create-maintenance-attribute.response.dto';
import { CreateMaintenanceAttributeRequestDto } from '@components/mms/dto/maintenance-attribute/request/create-maintenance-attribute.request.dto';
import { GetDetailDeviceGroupResponseDto } from '@components/mms/dto/device-group/response/get-detail-device-group.response.dto';
import { UpdateMaintenanceAttributeRequestDto } from '@components/mms/dto/maintenance-attribute/request/update-maintenance-attribute.request.dto';
import { GetListDeviceGroupResponseDto } from '@components/mms/dto/device-group/response/get-list-device-group-response.dto';
import { UpdateDeviceGroupResponseDto } from '@components/mms/dto/device-group/response/update-device-group.response.dto';
import { CreateSupplyGroupRequestDto } from '@components/mms/dto/supply-group/request/create-supply-group.request.dto';
import { GetListSupplyGroupRequestDto } from '@components/mms/dto/supply-group/request/get-list-supply-group.request.dto';
import { UpdateMaintenanceAttributeResponseDto } from '@components/mms/dto/maintenance-attribute/response/update-maintenance-attribute.response.dto';
import { GetListSupplyRequestDto } from '@components/mms/dto/supply/request/get-list-supply.request.dto';
import { CreateSupplyResponseDto } from '@components/mms/dto/supply/response/create-supply.response.dto';
import { CreateSupplyRequestDto } from '@components/mms/dto/supply/request/create-supply.request.dto';
import { GetDetailSupplyResponseDto } from '@components/mms/dto/supply/response/get-detail-supply.response.dto';
import { GetListSupplyResponseDto } from '@components/mms/dto/supply/response/get-list-supply.response.dto';
import { UpdateSupplyResponseDto } from '@components/mms/dto/supply/response/update-supply.response.dto';
import { UpdateSupplyRequestDto } from '@components/mms/dto/supply/request/update-supply.request.dto';
import { GetListFactoryResponseDto } from '@components/mms/dto/factory/response/get-list-factory.response.dto';
import { GetListFactoryRequestDto } from '@components/mms/dto/factory/request/get-list-factory.request.dto';
import { GetListUserResponseDto } from '@components/mms/dto/user/response/get-list-user.response.dto';
import { GetListUserRequestDto } from '@components/mms/dto/user/request/get-list-user.request.dto';
import { JobAssignmentRequestDto } from '@components/mms/dto/job/request/job-assignment.query';
import { ChecklistJobRequestDto } from '@components/mms/dto/job/request/checklist-job.request.dto';
import { GetListSupplyGroupConfirmResponseDto } from '@components/mms/dto/supply-group/response/get-list-supply-group-confirm.response.dto';
import { GetListSupplyGroupConfirmedRequestDto } from '@components/mms/dto/supply-group/request/get-list-supply-group-confirmed.request.dto';
import { GetListDefectReponseDto } from '@components/mms/dto/defect/response/get-list-defect.reponse.dto';
import { GetListDefectRequestDto } from '@components/mms/dto/defect/request/get-list-defect.request.dto';
import { CreateDefectRequestDto } from '@components/mms/dto/defect/request/create-defect.request.dto';
import { CreateDefectResponseDto } from '@components/mms/dto/defect/response/create-defect.response.dto';
import { UpdateDefectResponseDto } from '@components/mms/dto/defect/response/update-defect.response.dto';
import { GetListDevicesAppResponseDto } from '@components/mms/dto/device/response/get-list-devices-app.response.dto';
import { JobRejectRequestDto } from '@components/mms/dto/job/request/reject-job.request.dto';
import { GetDashboardDeviceAssignmentRequestDto } from '@components/mms/dto/dashboard/request/get-dashboard-device-assignment.request.dto';
import { CreateDeviceRequestDto } from '@components/mms/dto/device/request/create-device.request.dto';
import { GetDetailCheckListTemplateResponseDto } from '@components/mms/dto/check-list-template/response/get-detail-check-list-template.response.dto';
import { UpdateCheckListTemplateRequestDto } from '@components/mms/dto/check-list-template/request/update-check-list-template.request.dto';
import { UpdateCheckListTemplateResponseDto } from '@components/mms/dto/check-list-template/response/update-check-list-template.response.dto';
import { CreateCheckListTemplateRequestDto } from '@components/mms/dto/check-list-template/request/create-check-list-template.request.dto';
import { CreateCheckListTemplateResponseDto } from '@components/mms/dto/check-list-template/response/create-check-list-template.response.dto';
import { GetListCheckListTemplateRequestDto } from '@components/mms/dto/check-list-template/request/get-list-check-list-template.request.dto';
import { GetListCheckListTemplateResponseDto } from '@components/mms/dto/check-list-template/response/get-list-check-list-template.response.dto';
import { GetDetailDefectResponseDto } from '@components/mms/dto/defect/response/get-detail-defect.response.dto';
import { GetListDeviceDataDto } from '@components/mms/dto/device/response/get-list-device.response.dto';
import { DeviceDetailInfoAppResponseDto } from '@components/mms/dto/device/response/device-detail/device-detail-info-app.response.dto';
import { UpdateDeviceRequestDto } from '@components/mms/dto/device/request/update-device.request.dto';
import { CreateDeviceRequestTicketRequestDto } from './dto/device-request/request/request-ticket/create-device-request-ticket.request.dto';
import { ListJobByDeviceRequestDto } from './dto/job/request/list-job-by-device.request.dto';
import { DetailJobResponse } from './dto/job/response/get-detail-job.response.dto';
import { DetailDeviceRequestTicketResponseDto } from '@components/mms/dto/device-request/response/detail-device-request-ticket.response.dto';
import { ListGeneralMaintenanceParameterResponseDto } from '@components/mms/dto/general-maintenance-parameter/response/list-general-maintenance-parameter.response.dto';
import { ListGeneralMaintenanceParameterRequestDto } from '@components/mms/dto/general-maintenance-parameter/request/list-general-maintenance-parameter.request.dto';
import { CreateGeneralMaintenanceParameterResquestDto } from '@components/mms/dto/general-maintenance-parameter/request/create-general-maintenance-parameter.resquest.dto';
import { UpdateGeneralMaintenanceParameterRequestDto } from '@components/mms/dto/general-maintenance-parameter/request/update-general-maintenance-parameter.request.dto';
import { UpdateGeneralMaintenanceParameterResponseDto } from '@components/mms/dto/general-maintenance-parameter/response/update-general-maintenance-parameter.response.dto';
import { GetListDeviceAssignmentRequestDto } from './dto/divice-assignment/request/get-list-device-assignment.request.dto';
import { DeviceAssignmentResponseDto } from './dto/divice-assignment/response/device-assignment.response.dto';
import { GetListMaintenanceTeamAndUserRequestDto } from '@components/mms/dto/maintenance-team/request/get-list-maintenance-team-and-user.request.dto';
import { DeviceAssignResponseDto } from './dto/device-assignment/response/device-assign.response.dto';
import { DeviceAssignRequestDto } from './dto/device-assignment/request/device-assign.request.dto';
import { ImportDeviceAssignmentRequestDto } from './dto/device-assignment/request/import-device-assign.request.dto';
import { CreateDeviceReturnTicketRequestDto } from '@components/mms/dto/device-request/request/return-ticket/create-device-return-ticket.request.dto';
import { UpdateDeviceReturnTicketRequestDto } from '@components/mms/dto/device-request/request/return-ticket/update-device-return-ticket.request.dto';
import { UpdateDeviceAssignRequestDto } from './dto/device-assignment/request/update-device-assign.request.dto';
import { GetDeviceAssignResponseDto } from './dto/device-assignment/response/get-device-assign.response.dto';
import { UpdateDeviceRequestTicketRequestDto } from '@components/mms/dto/device-request/request/request-ticket/update-device-request-ticket.request.dto';
import { ListDeviceRequestsRequestDto } from '@components/mms/dto/device-request/request/list-device-requests.request.dto';
import { DetailDeviceWebResponseDto } from '@components/mms/dto/device/response/detail-device-web.response.dto';
import { GetMaintainRequestByAssignDeviceResponse } from './dto/device-assignment/response/get-maintain-request-by-assign-device.response.dto';
import { GetMaintainRequestByAssignDeviceRequest } from './dto/device-assignment/request/get-maintain-request-by-assign-device.request.dto';
import { GenerateQrCodeSerialResponse } from './dto/device-assignment/response/generate-qr-code-serial.response.dto';
import { GenerateQrCodeSerialRequest } from './dto/device-assignment/request/generate-qr-code-serial.request.dto';
import { GetMaintainInfoByDeviceRequest } from './dto/device-assignment/request/get-maintain-info-by-assign-device.request.dto';
import { GetMaintainInfoByDeviceResponse } from './dto/device-assignment/response/get-maintain-info-by-device.response.dto';
import { ExportDeviceAssignmentRequestDto } from './dto/device-assignment/request/export-device-assignment.request.dto';
import { ReportTotalJobResponse } from './dto/report/response/report-total-job.response.dto';
import { ImportDeviceAssignResponseDto } from './dto/device-assignment/response/import-device-assign.response.dto';
import { DashboardWarningResponseDto } from './dto/dashboard/response/dashboard-warning.response.dto';
import { GetDashboardWarningRequestDto } from './dto/dashboard/request/get-dashboard-warning.request.dto';
import { ReWorkMaintainRequestDto } from './dto/maintain-request/request/rework-maintain-request.request';
import { DeviceMaintenanceHistoryAppResponseDto } from '@components/mms/dto/device/response/device-detail/device-maintenance-history-app.response.dto';
import { ReportProgressJobResponse } from './dto/report/response/report-progress-job.response';
import { ReportProgressJobQuery } from './dto/report/query/report-progress-job.query';
import { RejectMaintainRequestDto } from './dto/maintain-request/request/reject-maintain-request.request';
import { RejectWarningRequestDto } from './dto/warning/request/reject-warning.request.dto';
import { ReportMaintainRequestResponse } from './dto/report/response/report-maintain-request.response';
import { GenerateSerialRequest } from './dto/device-assignment/request/generate-serial.request';
import { GenerateSerialResponse } from './dto/device-assignment/response/generate-serial.response.dto';
import { ValidateSerialRequest } from './dto/device-assignment/request/validate-serial.request';
import { ValidateSerialResponse } from './dto/device-assignment/response/validate-serial.response.dto';
import { GetListWarningRequestDto } from './dto/warning/request/list-warning.dto';
import { ListWarningResponse } from './dto/warning/response/list-warning.response.dto';
import { ListDeviceRequestsResponseDto } from '@components/mms/dto/device-request/response/list-device-requests.response.dto';
import { MaintainRequestHistoriesResponseDto } from './dto/maintain-request/response/maintain-request-histories.response.dto';
import { ChangeStatusDeviceReturnTicketRequestDto } from '@components/mms/dto/device-request/request/return-ticket/change-status-device-return-ticket.request.dto';
import { ChangeStatusDeviceRequestTicketRequestDto } from '@components/mms/dto/device-request/request/request-ticket/change-status-device-request-ticket.request.dto';
import { ListReportDeviceStatusQuery } from './dto/report-device-status/query/list-report-device-status.query';
import { ListReportDeviceStatusResponse } from './dto/report-device-status/response/list-report-device-status.response';
import { ListSerailInUseREquestDto } from './dto/divice-assignment/request/get-list-serial-da-in-use.request.dto';
import { SerialList } from './dto/divice-assignment/response/serial-list.response.dto';
import { ListReportDeviceAssignStatusQuery } from './dto/report-device-status/query/list-report-device-assign-status.query';
import { ListReportDeviceAssignStatusResponse } from './dto/report-device-status/response/list-report-device-assign-status.response';
import { ExportSupplyGroupRequestDto } from '@components/mms/dto/supply-group/request/export-supply-group.request.dto';
import { ExportDeviceGroupRequestDto } from '@components/mms/dto/device-group/request/export-device-group.request.dto';
import { ExportDefectRequestDto } from '@components/mms/dto/defect/request/export-defect.request.dto';
import { ExportSupplyRequestDto } from '@components/mms/dto/supply/request/export-supply.request.dto';
import { DashboardMttrMttaResponse } from './dto/dashboard/response/dashboard-mttr-mtta-index.response';
import { DashboardMttrMttaQuery } from './dto/dashboard/query/dashboard-mttr-mtta-index.query';
import { PlanItemQuery } from './dto/plan/request/get-plan-list.request.dto';
import { CreateAttributeTypeRequest } from './dto/attribute-type/request/create-attribute-type.request';
import { UpdateAttributeTypeRequest } from './dto/attribute-type/request/update-attribute-type.request';
import { DetailAttributeTypeResponse } from './dto/attribute-type/response/detail-attribute-type.response';
import { ListAttributeTypeResponse } from './dto/attribute-type/response/list-attribute-type.response';
import { ListAttributeTypeQuery } from './dto/attribute-type/query/list-attribute-type.query';
import { ListPlanItemResponse } from './dto/plan/response/plan-list.response.dto';
import { RejectPlanRequestDto } from './dto/plan/request/reject-plan.request.dto';
import { ApprovePlanRequestDto } from './dto/plan/request/approve-plan.request.dto';
import { UpdateOperationTimeBySerial } from './dto/device-assignment/request/update-operation-time-by-serial';
import { CreatePlanRequestDto } from './dto/plan/request/create-plan.request.dto';
import { PlanDetailRequestDto } from './dto/plan/request/plan-detail.request.dto';
import { PlanDetailResponseDto } from './dto/plan/response/plan-detail.response.dto';
import { CreateInstallationTemplateRequest } from './dto/installation-template/request/create-installation-template.request';
import { UpdateInstallationTemplateRequest } from './dto/installation-template/request/update-installation-template.request';
import { DetailInstallationTemplateResponse } from './dto/installation-template/response/detail-installation-template.response';
import { ListInstallationTemplate } from './dto/installation-template/response/list-installation-template.response';
import { ListInstallationTemplateQuery } from './dto/installation-template/query/list-installation-template.query';
import { ListSerialByDeviceQuery } from './dto/device-assignment/query/list-serial-by-device.query';
import { ListSerialByDeviceResponse } from './dto/device-assignment/response/list-serial-by-device.response';
import { UpdatePlanRequestDto } from './dto/plan/request/update-plan.request.dto';
import { ListDeviceRequestImoResponseDto } from './dto/device-request/response/list-device-request-imo.response.dto';
import { ListDeviceRequestImoQuery } from './dto/device-request/request/list-device-request-imo.request.dto';
import { CreateSupplyRequest } from './dto/supply-request/request/create-supply-request.request.dto';
import { ListSupplyRequestResponseDto } from './dto/supply-request/response/list-supply-request.response.dto';
import { ListSupplyRequestQuery } from './dto/supply-request/query/list-supply-request.query';
import { DetailSuppyRequestResponse } from './dto/supply-request/response/detail-supply-request.response';
import { UpdateSupplyRequest } from './dto/supply-request/request/update-supply-request.request.dto';
import { ListDeviceStatusResponse } from './dto/device-status/response/list-device-status.response';
import { PaginationQuery } from '@utils/pagination.query';
import { CountSupplyInRequestByJobResponseDto } from './dto/supply-request/response/count-supply-in-request-by-job.response';
import { GetDashboardDeviceStatusRequestDto } from './dto/dashboard/request/get-dashboard-device-status.request.dto';
import { DashboardDeviceStatusResponseDto } from './dto/dashboard/response/dashboard-device-status.response.dto';
import { CreateDeviceStatusActivityRequestDto } from './dto/device-status/request/create-device-status-activity.request.dto';
import { getMoInformation } from './dto/divice-assignment/request/get-mo-information.dto';
import { getManufacturingInformation } from './dto/divice-assignment/request/get-manufacturing-information.dto';
import { GetLogTimeByMoIdResponse } from './dto/divice-assignment/response/get-log-time-by-mo-id.response.dto';
import { ValidateCodeRequest } from './dto/attribute-type/request/validate-code.request';
import { DeviceStatusActivityInfoResponseDto } from './dto/device-status/response/list-device-status-activity-info.response.dto';
import { AttributeTypeByDeviceAssignResponseDto } from './dto/device-assignment/response/attribute-type-by-device-asign.response';
import { GetMoInformationResponse } from './dto/divice-assignment/response/get-mo-information.response.dto';
import { ListWorkCenterResponse } from './dto/device-request/response/list-work-center.response.dto';
import { ListJobCreateSuppyRequestResponseDto } from './dto/job/response/list-job-create-supply-request.response.dto';
import { DEFAULT_LANG } from 'src/common/common';
import { GanttChartPlanQuery } from './dto/plan/query/gantt-chart-plan.query';
import { GanttChartPlanResponse } from './dto/plan/response/gantt-chart-plan.response';
import { DeviceStatusBySerialResponseDto } from './dto/device-status/response/list-device-status-by-serial.response.dto';
import { GetHistorySupplyResponse } from './dto/supply-request/response/get-history-supply-request.response';
import { GenerateJobForPlanRequest } from './dto/plan/request/generate-job-for-plan.request';
import { GenerateJobForPlanResponse } from './dto/plan/response/generate-job-for-plan.response';
import { DetailJobQuery } from './dto/job/request/detail-job.query';
import { ReportJobResponseDto } from './dto/job/response/report-job.response.dto';
import { ReportJobDetailResponseDto } from './dto/job/response/report-job-detail.response.dto';

@ApiBearerAuth()
@Controller('mms')
@ApiTags('Mms')
export class MmsController {
  constructor(
    @Inject('MMS_SERVICE')
    private readonly mmsServiceClient: ClientProxy,
  ) {}

  @Get('ping')
  public async get(): Promise<any> {
    return await this.mmsServiceClient.send('ping', {});
  }

  @Post('/maintain-requests')
  @ApiOperation({
    tags: ['MaintainRequest', 'MMS'],
    summary: '',
    description: 'Tạo yêu cầu bảo trì',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: MaintainRequestResponse,
  })
  public async createMaintainRequest(
    @Body() request: CreateMaintainRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    };
    return await this.mmsServiceClient.send('create_maintain_request', {
      ...payload,
    });
  }

  @Put('/maintain-requests/:id')
  @ApiOperation({
    tags: ['MaintainRequest', 'MMS'],
    summary: '',
    description: 'Cập nhật yêu cầu bảo trì',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  public async updateMaintainRequest(
    @Body() request: UpdateMaintainRequestDto,
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return await this.mmsServiceClient.send('update_maintain_request', {
      id: id,
      ...request,
      userId: req.user.id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Delete('/maintain-requests/:id')
  @ApiOperation({
    tags: ['MaintainRequest', 'MMS'],
    summary: '',
    description: 'Xóa yêu cầu bảo trì',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteMaintainRequest(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    };
    return await this.mmsServiceClient.send(
      'destroy_maintain_request',
      payload,
    );
  }

  @Put('/maintain-requests/:id/approve')
  @ApiOperation({
    tags: ['MaintainRequest', 'MMS'],
    summary: '',
    description: 'Phê duyệt yêu cầu bảo trì',
  })
  @ApiResponse({
    status: 200,
    description: 'Approve successfully',
    type: SuccessResponse,
  })
  public async approveMaintainRequest(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    };
    return await this.mmsServiceClient.send(
      'approve_maintain_request',
      payload,
    );
  }

  @Put('/maintain-requests/:id/reject')
  @ApiOperation({
    tags: ['MaintainRequest', 'MMS'],
    summary: '',
    description: 'Từ chối yêu cầu bảo trì',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: SuccessResponse,
  })
  public async rejectMaintainRequest(
    @Param('id') id: string,
    @Req() req: any,
    @Body() request: RejectMaintainRequestDto,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    };
    return await this.mmsServiceClient.send('reject_maintain_request', payload);
  }

  @Get('/maintain-requests/:id/histories')
  @ApiOperation({
    tags: ['MaintainRequest', 'MMS'],
    summary: '',
    description: 'lịch sử hoạt động bảo trì',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: MaintainRequestHistoriesResponseDto,
  })
  public async getMaintainRequestHistories(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    };
    return await this.mmsServiceClient.send(
      'get_maintain_request_histories',
      payload,
    );
  }

  @Post('warnings')
  @ApiOperation({
    tags: ['Warning'],
    summary: 'Create new item',
    description: 'Tạo 1 item mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: CreateWaringResponseDto,
  })
  public async create(
    @Body() request: CreateWarningDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userId: req.user.id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    };
    return await this.mmsServiceClient.send('create_warning', payload);
  }

  @Get('warnings/:id')
  @ApiOperation({
    tags: ['Warning'],
    summary: 'Detail item',
    description: 'Chi tiết item',
  })
  @ApiResponse({
    status: 200,
    description: 'Detail Item',
    type: DetailWarningDataResponseDto,
  })
  public async detail(@Param('id') id: string, @Req() req: any): Promise<any> {
    return await this.mmsServiceClient.send('detail_warning', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  // api job

  @Get('jobs/list')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'List item',
    description: 'Danh sách công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'List Item',
    type: ListJobDataResponseDto,
  })
  public async jobs(
    @Query() request: JobItemQuery,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      userInfo: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    };
    return await this.mmsServiceClient.send('list_jobs', payload);
  }

  @Put('jobs/:id/assignments')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'Update item',
    description: 'Phân công công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Update Item',
    type: SuccessResponse,
  })
  public async jobsAssignment(
    @Body() request: JobAssignmentRequestDto,
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...request,
    };
    return await this.mmsServiceClient.send('update_job_assignment', payload);
  }

  @Put('jobs/:id/reject')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'Update item',
    description: 'Tù chối phân công công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Update Item',
    type: SuccessResponse,
  })
  public async jobsReject(
    @Param('id') id: string,
    @Req() req: any,
    @Body() request: JobRejectRequestDto,
  ): Promise<any> {
    const payload = {
      id: id,
      user: req.user,
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    };
    return await this.mmsServiceClient.send('update_job_reject', payload);
  }

  @Put('jobs/:id/implement')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'Update item',
    description: 'Thực hiện công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Update Item',
    type: SuccessResponse,
  })
  public async jobsImplement(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      id: id,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    };
    return await this.mmsServiceClient.send('update_job_implement', payload);
  }

  @Get('/jobs/:id')
  @ApiOperation({
    tags: ['Job', 'MMS'],
    summary: '',
    description: 'Chi tiết công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail Job successfully',
    type: DetailJobResponse,
  })
  public async detailJob(
    @Param('id') id: string,
    @Req() req: any,
    @Query() request: DetailJobQuery,
  ): Promise<any> {
    const payload = {
      id: id,
      isDraft: request.isDraft,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    };
    return await this.mmsServiceClient.send('detail_job', payload);
  }

  @Put('/jobs/:id')
  @ApiOperation({
    tags: ['Job', 'MMS'],
    summary: '',
    description: 'Sửa công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Edit Job successfully',
    type: SuccessResponse,
  })
  public async editJob(
    @Param('id') id: string,
    @Req() req: any,
    @Body() request: EditJobRequestDto,
  ): Promise<any> {
    const payload = {
      id: id,
      userId: req.user.id,
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    };
    return await this.mmsServiceClient.send('edit_job', payload);
  }

  @Put('/jobs/:id/execute')
  @ApiOperation({
    tags: ['Job', 'MMS'],
    summary: '',
    description: 'Thực thi công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Execute Job successfully',
    type: SuccessResponse,
  })
  public async executeJob(
    @Param('id') id: string,
    @Req() req: any,
    @Body() request: ExecuteJobRequestDto,
  ): Promise<any> {
    const payload = {
      id: id,
      user: req.user,
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    };
    return await this.mmsServiceClient.send('execute_job', payload);
  }

  @Put('/jobs/checklist/:id/execute')
  @ApiOperation({
    tags: ['Job', 'MMS'],
    summary: '',
    description: 'Thực hiện công việc kiểm tra định kỳ thôi',
  })
  @ApiResponse({
    status: 200,
    description: 'Job update successfully',
    type: SuccessResponse,
  })
  public async checkListJobExecute(
    @Param('id') id: string,
    @Req() req: any,
    @Body() request: ChecklistJobRequestDto,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      id: id,
      user: req.user,
      ...request,
    };
    return await this.mmsServiceClient.send('checklist_job', payload);
  }

  @Put('/jobs/checklist/:id/redo')
  @ApiOperation({
    tags: ['Job', 'MMS'],
    summary: '',
    description: 'Làm lại công việc kiểm tra định kì',
  })
  @ApiResponse({
    status: 200,
    description: 'Job update successfully',
    type: SuccessResponse,
  })
  public async checkListJobRedo(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      id: id,
      user: req.user,
    };
    return await this.mmsServiceClient.send('checklist_job_redo', payload);
  }

  @Put('/jobs/:id/in-progress')
  @ApiOperation({
    tags: ['Job', 'MMS'],
    summary: '',
    description: 'Làm lại công việc kiểm tra định kì',
  })
  @ApiResponse({
    status: 200,
    description: 'Job update successfully',
    type: SuccessResponse,
  })
  public async checkListJobInprogress(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      id: id,
      user: req.user,
    };
    return await this.mmsServiceClient.send('job_inprogress', payload);
  }

  @Put('/jobs/:id/approve')
  @ApiOperation({
    tags: ['Job', 'MMS'],
    summary: '',
    description: 'Hoàn thành công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Job Update successfully',
    type: SuccessResponse,
  })
  public async approveJob(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      id: id,
      user: req.user,
    };
    return await this.mmsServiceClient.send('approve_job', payload);
  }

  @Get('/jobs/create-supply-request')
  @ApiOperation({
    tags: ['Jobs'],
    summary: 'List Job',
    description: 'Danh sách công việc cần tạo yêu cầu cấp vtpt',
  })
  @ApiResponse({
    status: 200,
    description: 'List Job',
    type: ListJobCreateSuppyRequestResponseDto,
  })
  public async listJobCreate(
    @Query() request: PaginationQuery,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...request,
      userInfo: req.user,
    };
    return await this.mmsServiceClient.send(
      'list_jobs_create_supply_request',
      payload,
    );
  }

  // end job

  @Put('/warning/:id/approve')
  @ApiOperation({
    tags: ['Job', 'MMS'],
    summary: '',
    description: 'Xác nhận cảnh báo',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully',
    type: SuccessResponse,
  })
  public async approveWarning(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      id: id,
      userId: req.user.id,
    };
    return await this.mmsServiceClient.send('approve_warning', payload);
  }

  @Put('/warning/:id/reject')
  @ApiOperation({
    tags: ['Job', 'MMS'],
    summary: '',
    description: 'Từ chối cảnh báo',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully',
    type: SuccessResponse,
  })
  public async rejectWarning(
    @Param('id') id: string,
    @Req() req: any,
    @Body() request: RejectWarningRequestDto,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      id: id,
      userId: req.user.id,
      ...request,
    };
    return await this.mmsServiceClient.send('reject_warning', payload);
  }

  @Get('/dashboards/summary')
  @ApiOperation({
    tags: ['Dashboard'],
    summary: 'Dashboard summary',
    description: 'thông tin thống kê tổng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: DashboardSummaryResponseDto,
  })
  public async getDashboardSummary(): Promise<any> {
    return await this.mmsServiceClient.send('dashboard_summary', {});
  }

  @Get('/dashboards/warnings/priorities')
  @ApiOperation({
    tags: ['Dashboard'],
    summary: 'Dashboard warnings priority',
    description: 'Lỗi thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: DashboardWarningPriorityDataResponseDto,
  })
  public async getDashboardWarningPriority(
    @Query() query: GetDashboardRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return await this.mmsServiceClient.send('dashboard_warning_priority', {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...query,
    });
  }

  @Get('/dashboards/warnings/status')
  @ApiOperation({
    tags: ['Dashboard'],
    summary: 'Dashboard warnings status',
    description: 'Trạng thái yêu cầu',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: DashboardWarningStatusDataResponseDto,
  })
  public async getDashboardWarningStatus(
    @Query() query: GetDashboardRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return await this.mmsServiceClient.send('dashboard_warning_status', {
      ...query,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/dashboards/jobs/status')
  @ApiOperation({
    tags: ['Dashboard'],
    summary: 'Dashboard jobs status',
    description: 'Tiến độ công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: DashboardJobStatusDataResponseDto,
  })
  public async getDashboardJobsStatus(
    @Query() query: GetDashboardRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return await this.mmsServiceClient.send('dashboard_jod_status', {
      ...query,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  // start device assignment
  @Get('device-assignment/list')
  @ApiOperation({
    tags: ['Device Assignment'],
    summary: 'List item',
    description: 'Danh sách phân công thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'List Item',
    type: [DeviceAssignmentResponseDto],
  })
  public async deviceAssignment(
    @Query() request: GetListDeviceAssignmentRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return await this.mmsServiceClient.send('list_device_assignment', {
      ...request,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('device-assignment/serials-in-use')
  @ApiOperation({
    tags: ['Device Assignment'],
    summary: 'List item',
    description: 'Danh sách serial phân công thiết bị được sử dụng',
  })
  @ApiResponse({
    status: 200,
    description: 'List Item',
    type: [SerialList],
  })
  public async serialsList(
    @Query() request: ListSerailInUseREquestDto,
    @Req() req: any,
  ): Promise<any> {
    return await this.mmsServiceClient.send('list_serial_in_use', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Put('/device-assignments/operation-time')
  @ApiOperation({
    tags: ['Device Assignment'],
    summary: 'cập nhật thời gian hoạt động của thiết bị theo serial',
    description: 'Danh sách serial phân công thiết bị được sử dụng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update operation time',
  })
  public async updateOperationTimeBySerial(
    @Body() request: UpdateOperationTimeBySerial,
    @Req() req,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...request,
      user: req.user,
    };
    return await this.mmsServiceClient.send(
      'update_operation_time_by_serial',
      payload,
    );
  }

  // end device assignment

  @Get('/dashboards/device-assignments/status')
  @ApiOperation({
    tags: ['Dashboard'],
    summary: 'Dashboard device-assignments status',
    description: 'Trạng thái thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: DashboardDeviceAssignmentStatusDataResponseDto,
  })
  public async getDashboardDeviceAssignmentsStatus(
    @Query() query: GetDashboardDeviceAssignmentRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return await this.mmsServiceClient.send(
      'dashboard_device_assignment_status',
      {
        lang: req?.headers['lang'] || DEFAULT_LANG,
        ...query,
      },
    );
  }

  @Get('/maintain-requests')
  @ApiOperation({
    tags: ['Maintain Request', 'MMS'],
    summary: '',
    description: 'Danh sách yêu cầu bảo trì',
  })
  @ApiResponse({
    status: 200,
    description: 'List Maintain Request successfully',
    type: ListMaintainRequestResponse,
  })
  public async listMaintainRequest(
    @Query() query: ListMaintainRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...query,
      ...{ userId: req.user.id },
    };
    return await this.mmsServiceClient.send('list_maintain_request', payload);
  }

  @Get('/maintain-requests/:id')
  @ApiOperation({
    tags: ['Maintain Request', 'MMS'],
    summary: '',
    description: 'Chi tiết yêu cầu bảo trì',
  })
  @ApiResponse({
    status: 200,
    description: 'Detail Maintain Request successfully',
    type: DetailMaintainRequestResponse,
  })
  public async detailMaintainRequest(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      userId: req.user.id,
      id,
    };
    return await this.mmsServiceClient.send('detail_maintain_request', payload);
  }

  @Get('/devices/:serial/jobs')
  @ApiOperation({
    tags: ['Scan Job', 'MMS'],
    summary: '',
    description: 'Danh Sách công việc của thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'List Job By device successfully',
    type: ListJobByDeviceResponse,
  })
  public async listJobByDevice(
    @Param('serial') serial: string,
    @Req() req: any,
    @Query() query: ListJobByDeviceRequestDto,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...query,
      userId: req.user.id,
      serial,
    };
    return await this.mmsServiceClient.send('list_job_by_device', payload);
  }

  // Maintenance Team
  @Get('/maintenance-teams/list')
  @ApiOperation({
    tags: ['Maintenance Team'],
    summary: 'List Of MaintenanceTeam',
    description: 'List Of Maintenance Team',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListMaintenanceTeamResponseDto,
  })
  public async getListMaintenanceTeam(
    @Query() request: GetListMaintenanceTeamRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('list_maintenance_team', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/maintenance-teams/:id')
  @ApiOperation({
    tags: ['Maintenance Team'],
    summary: 'Detail Maintenance Team',
    description: 'Detail Maintenance Team',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetDetailMaintenanceTeamResponseDto,
  })
  public async detailMaintenanceTeam(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('detail_maintenance_team', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Post('/maintenance-teams')
  @ApiOperation({
    tags: ['Maintenance Team'],
    summary: 'Create Maintenance Team',
    description: 'Create Maintenance Team',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
  })
  public async createMaintenanceTeam(
    @Body() request: CreateMaintenanceTeamRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('create_maintenance_team', {
      ...request,
      userId: req.user.id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  //Update
  @Put('/maintenance-teams/:id')
  @ApiOperation({
    tags: ['Maintenance Team'],
    summary: 'Update MaintenanceTeam',
    description: 'Update an existing Maintenance Team',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: UpdateMaintenanceTeamResponseDto,
  })
  public async updateMaintenanceTeam(
    @Param('id') id: string,
    @Body() request: UpdateMaintenanceTeamRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('update_maintenance_team', {
      ...request,
      userId: req.user.id,
      _id: id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  //Delete
  @Delete('/maintenance-teams/:id')
  @ApiOperation({
    tags: ['Maintenance Team'],
    summary: 'Delete MaintenanceTeam',
    description: 'Delete an existing Maintenance Team',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteMaintenanceTeam(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('delete_maintenance_team', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/maintenance-teams-and-users/list')
  @ApiOperation({
    tags: ['Maintenance Team And User'],
    summary: 'List Of MaintenanceTeam and User',
    description: 'List Of Maintenance Team and User',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListMaintenanceTeamResponseDto,
  })
  public async getListMaintenanceTeamsAndUsers(
    @Query() request: GetListMaintenanceTeamAndUserRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('list_maintenance_team_and_user', {
      ...request,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  //Maintenance Attribute
  @Get('/maintenance-attributes/list')
  @ApiOperation({
    tags: ['Maintenance Attribute'],
    summary: 'List Of Maintenance Attribute',
    description: 'List Of Maintenance Attribute',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListMaintenanceAttributeResponseDto,
  })
  public async getListMaintenanceAttribute(
    @Query() request: GetListMaintenanceAttributeRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('list_maintenance_attribute', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  //Update
  @Put('/maintenance-attributes/:id')
  @ApiOperation({
    tags: ['Maintenance Attribute'],
    summary: 'Update Maintenance Attribute',
    description: 'Update an existing Maintenance Attribute',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: UpdateMaintenanceAttributeResponseDto,
  })
  public async updateMaintenanceAttribute(
    @Param('id') id: string,
    @Body() request: UpdateMaintenanceAttributeRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('update_maintenance_attribute', {
      ...request,
      userId: req.user.id,
      _id: id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  //Detail
  @Get('/maintenance-attributes/:id')
  @ApiOperation({
    tags: ['Maintenance Attribute'],
    summary: 'Detail Maintenance Attribute',
    description: 'Detail Maintenance Attribute',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetDetailMaintenanceAttributeResponseDto,
  })
  public async detailMaintenanceAttribute(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('detail_maintenance_attribute', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  //Delete
  @Delete('/maintenance-attributes/:id')
  @ApiOperation({
    tags: ['Maintenance Attribute'],
    summary: 'Delete Maintenance Attribute',
    description: 'Delete an existing Maintenance Attribute',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteMaintenanceAttribute(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('delete_maintenance_attribute', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  //Create
  @Post('/maintenance-attributes')
  @ApiOperation({
    tags: ['Maintenance Attribute'],
    summary: 'Create Maintenance Attribute',
    description: 'Create a new Maintenance Attribute',
  })
  @ApiResponse({
    status: 200,
    description: 'Created successfully',
    type: CreateMaintenanceAttributeResponseDto,
  })
  public async createMaintenanceAttribute(
    @Body() request: CreateMaintenanceAttributeRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('create_maintenance_attribute', {
      ...request,
      userId: req.user.id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  // Device Group
  @Get('/device-groups/list')
  @ApiOperation({
    tags: ['Device Group List'],
    summary: 'List Of Device Group',
    description: 'List Of Device Group',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListDeviceGroupResponseDto,
  })
  public async getListDeviceGroup(
    @Query() request: GetListDeviceGroupRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('list_device_group', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  //Update
  @Put('/device-groups/:id')
  @ApiOperation({
    tags: ['Device Group'],
    summary: 'Update Device Group',
    description: 'Update an existing Device Group',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: UpdateDeviceGroupResponseDto,
  })
  public async updateDeviceGroup(
    @Param('id') id: string,
    @Body() request: UpdateDeviceGroupRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('update_device_group', {
      ...request,
      userId: req.user.id,
      _id: id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  //Approve
  @Put('/device-groups/:id/confirmed')
  @ApiOperation({
    tags: ['Device Group'],
    summary: 'Confirm Device Group',
    description: 'Confirm an existing Device Group',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: UpdateDeviceGroupResponseDto,
  })
  public async confirmDeviceGroup(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('confirm_device_group', {
      userId: req.user.id,
      _id: id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  //Delete
  @Delete('/device-groups/:id')
  @ApiOperation({
    tags: ['Device Category'],
    summary: 'Delete Device Category',
    description: 'Delete an existing Device Category',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteDeviceGroup(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('delete_device_group', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  //Create
  @Post('/device-groups')
  @ApiOperation({
    tags: ['Device group'],
    summary: 'Create Device group',
    description: 'Create a new Device group',
  })
  @ApiResponse({
    status: 200,
    description: 'Created successfully',
  })
  public async createDeviceGroup(
    @Body() request: CreateDeviceGroupRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('create_device_group', {
      ...request,
      userId: req.user.id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/device-groups/:id')
  @ApiOperation({
    tags: ['Device Group'],
    summary: 'Detail Device Group',
    description: 'Detail Device Group',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetDetailDeviceGroupResponseDto,
  })
  public async detailDeviceGroup(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('detail_device_group', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  // Supplies Category
  @Get('/supply-groups/list')
  @ApiOperation({
    tags: ['Supply Group'],
    summary: 'List Of Supply Group',
    description: 'List Of Supply Group',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListSupplyGroupResponseDto,
  })
  public async getListSupplyGroup(
    @Query() request: GetListSupplyGroupRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('list_supply_group', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  //Update
  @Put('/supply-groups/:id')
  @ApiOperation({
    tags: ['Supply Group'],
    summary: 'Update Supply Group',
    description: 'Update an existing Supply Group',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: UpdateSupplyGroupResponseDto,
  })
  public async updateSupplyGroup(
    @Param('id') id: string,
    @Body() request: UpdateSupplyGroupRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('update_supply_group', {
      ...request,
      userId: req.user.id,
      _id: id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  //Delete
  @Delete('/supply-groups/:id')
  @ApiOperation({
    tags: ['Supply Group'],
    summary: 'Delete Supply Group',
    description: 'Delete an existing Supply Group',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteSupplyGroup(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('delete_supply_group', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  //Approve
  @Put('/supply-groups/:id/confirmed')
  @ApiOperation({
    tags: ['Supply Group'],
    summary: 'Confirm Supply Group',
    description: 'Confirm an existing Supply Group',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: UpdateDeviceGroupResponseDto,
  })
  public async confirmSupplyGroup(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('confirm_supply_group', {
      userId: req.user.id,
      _id: id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  //Create
  @Post('/supply-groups')
  @ApiOperation({
    tags: ['Supply Group'],
    summary: 'Create Supply Group',
    description: 'Create a new Supply Group',
  })
  @ApiResponse({
    status: 200,
    description: 'Created successfully',
    type: CreateSupplyGroupResponseDto,
  })
  public async createSupplyGroup(
    @Body() request: CreateSupplyGroupRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('create_supply_group', {
      ...request,
      userId: req.user.id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/supply-groups/:id')
  @ApiOperation({
    tags: ['Supply Group'],
    summary: 'Detail Supply Group',
    description: 'Detail Supply Group',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetDetailSupplyGroupResponseDto,
  })
  public async detailSupplyGroup(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('detail_supply_group', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/supply-groups/list/confirmed')
  @ApiOperation({
    tags: ['List Supply Group Confirmed '],
    summary: 'List Supply Group Confirmed',
    description: 'List Supply Group Confirmed',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetListSupplyGroupConfirmResponseDto,
  })
  public async getListSupplyGroupConfirmed(
    @Query() request: GetListSupplyGroupConfirmedRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('list_supply_group_confirmed', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  // Export
  @Post('supply-groups/export')
  @ApiOperation({
    tags: ['Export Supply Group'],
    summary: 'Export Supply Group',
    description: 'Export Supply Group',
  })
  @ApiResponse({
    status: 200,
    description: 'Export successfully',
  })
  public async exportSupplyGroup(
    @Body() request: ExportSupplyGroupRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('export_supply_group', {
      ...request,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  /* Begin Devices section */
  /** Begin app APIs **/
  @ApiOperation({
    tags: ['Devices'],
    summary: 'Danh sách thiết bị',
    description: 'Danh sách thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetListDevicesAppResponseDto,
  })
  @Get('/app/devices')
  public async getDevicesListForApp(
    @Query() request: GetListDevicesRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('device_list_app', {
      ...request,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @ApiOperation({
    tags: ['Devices'],
    summary: 'Quét mã QR thiết bị',
    description: 'Quét mã QR thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DeviceCommonInfoResponseDto,
  })
  @Get('/devices/qr-codes/scan')
  public async scanQrCode(
    @Query() request: ScanQrDeviceRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const userId = req.user.id;
    return this.mmsServiceClient.send('device_scan_qr', {
      ...request,
      userId: userId,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @ApiOperation({
    tags: ['Devices'],
    summary: 'Thông tin chi tiết thiết bị',
    description: 'Thông tin chi tiết thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DeviceDetailInfoAppResponseDto,
  })
  @Get('/app/devices/:id')
  public async getDeviceDetailInfoApp(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('device_detail_app_info', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @ApiOperation({
    tags: ['Devices'],
    summary: 'Thông số bảo trì thiết bị',
    description: 'Thông số bảo trì thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DeviceMaintenanceInfoAppResponseDto,
  })
  @Get('/app/devices/:serial/maintenance-info')
  public async getDeviceMaintenanceInfo(
    @Param('serial') serial: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('device_maintenance_info_app', {
      serial,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  // @ApiOperation({
  //   tags: ['Devices'],
  //   summary: 'Lịch sử bảo trì thiết bị',
  //   description: 'Lịch sử bảo trì thiết bị',
  // })
  // @ApiResponse({
  //   status: 200,
  //   description: 'Success',
  //   type: DeviceMaintenanceHistoryResponseDto,
  // })
  // @Get('/devices/:id/maintenance-histories')
  // public async getDeviceMaintenanceHistory(
  //   @Param('id') id: string,
  // ): Promise<any> {
  //   return new ResponseBuilder<DeviceMaintenanceHistoryResponseDto[]>([
  //     {
  //       id: '61a98e228d036b9d952eb197',
  //       code: 'WO1918191',
  //       name: 'Bảo trì máy dập',
  //       type: 'Bảo dưỡng',
  //       executionAt: '22/09/2021',
  //     },
  //     {
  //       id: '61a98e228d036b9d952eb198',
  //       code: 'WO1918192',
  //       name: 'Kẹt chân máy dập',
  //       type: 'Cảnh báo lỗi',
  //       executionAt: '22/09/2021',
  //     },
  //     {
  //       id: '61a98e228d036b9d952eb199',
  //       code: 'WO1918193',
  //       name: 'Kẹt chân máy dập',
  //       type: 'Cảnh báo lỗi',
  //       executionAt: '22/09/2021',
  //     },
  //   ]).build();
  // }

  // @ApiOperation({
  //   tags: ['Devices'],
  //   summary: 'Thông tin sản xuất thiết bị',
  //   description: 'Thông tin sản xuất thiết bị',
  // })
  // @ApiResponse({
  //   status: 200,
  //   description: 'Success',
  //   type: DeviceManufacturingInfoResponseDto,
  // })
  // @Get('/app/devices/:id/manufacturing-info')
  // public async getDeviceManufacturingInfo(
  //   @Param('id') id: string,
  // ): Promise<any> {
  //   return new ResponseBuilder<DeviceManufacturingInfoResponseDto>({
  //     workCenter: {
  //       id: 1,
  //       name: 'Xưởng 1',
  //       code: '02918918291',
  //     },
  //     oeeIndex: 'Máy dập',
  //     manufacturingOrder: {
  //       id: 1,
  //       code: 'MO123',
  //       name: 'Lệnh sản xuất A',
  //       workOrders: [
  //         {
  //           id: 2,
  //           code: 'WO123',
  //           name: 'Lệnh làm việc A',
  //           dateFrom: '02/08/2021',
  //           dateTo: '03/09/2021',
  //           shifts: [
  //             {
  //               id: 3,
  //               name: 'Ca 2',
  //               date: '03/09/2021',
  //               shiftDetail: {
  //                 workTime: 420,
  //                 relaxTime: 60,
  //               },
  //             },
  //             {
  //               id: 2,
  //               name: 'Ca 1',
  //               date: '03/09/2021',
  //               shiftDetail: {
  //                 workTime: 420,
  //                 relaxTime: 60,
  //               },
  //             },
  //             {
  //               id: 1,
  //               name: 'Ca 1',
  //               date: '02/09/2021',
  //               shiftDetail: {
  //                 workTime: 420,
  //                 relaxTime: 60,
  //               },
  //             },
  //           ],
  //         },
  //         {
  //           id: 1,
  //           code: 'WO123',
  //           name: 'Lệnh làm việc B',
  //           dateFrom: '02/08/2021',
  //           dateTo: '03/09/2021',
  //           shifts: [
  //             {
  //               id: 1,
  //               name: 'Ca 2',
  //               date: '03/09/2021',
  //               shiftDetail: {
  //                 workTime: 420,
  //                 relaxTime: 60,
  //               },
  //             },
  //             {
  //               id: 2,
  //               name: 'Ca 1',
  //               date: '03/09/2021',
  //               shiftDetail: {
  //                 workTime: 420,
  //                 relaxTime: 60,
  //               },
  //             },
  //             {
  //               id: 1,
  //               name: 'Ca 1',
  //               date: '02/09/2021',
  //               shiftDetail: {
  //                 workTime: 420,
  //                 relaxTime: 60,
  //               },
  //             },
  //           ],
  //         },
  //       ],
  //     },
  //   }).build();
  // }
  /** End of app APIs **/

  /** Begin of web APIs **/
  @ApiOperation({
    tags: ['Devices'],
    summary: 'Tạo thiết bị',
    description: 'Tạo thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: Number,
  })
  @Post('/web/devices')
  public async createDevice(
    @Body() request: CreateDeviceRequestDto,
    @Req() req,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...request,
      userId: req.user.id,
    };

    return this.mmsServiceClient.send('device_create', payload);
  }

  @ApiOperation({
    tags: ['Devices'],
    summary: 'Danh sách thiết bị',
    description: 'Danh sách thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: [GetListDeviceDataDto],
  })
  @Get('/web/devices')
  public async getDevicesListWeb(
    @Query() request: GetListDevicesRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('device_list_web', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @ApiOperation({
    tags: ['Devices'],
    summary: 'Xác nhận thiết bị',
    description: 'Xác nhận thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: String,
  })
  @Patch('/web/devices/:id')
  public async confirmDevice(
    @Param('id') id: string,
    @Req() req,
  ): Promise<any> {
    return this.mmsServiceClient.send('device_confirm', {
      id: id,
      userId: req.user.id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @ApiOperation({
    tags: ['Devices'],
    summary: 'Xóa thiết bị',
    description: 'Xóa thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
  })
  @Delete('/web/devices/:id')
  public async deleteDevice(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('device_delete', {
      id: id,
      userId: req.user.id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @ApiOperation({
    tags: ['Devices'],
    summary: 'Chi tiết thiết bị',
    description: 'Chi tiết thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailDeviceWebResponseDto,
  })
  @Get('/web/devices/:id')
  public async detailDeviceWeb(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('device_detail_web', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @ApiOperation({
    tags: ['Devices'],
    summary: 'Sửa thiết bị',
    description: 'Sửa thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: String,
  })
  @Put('/web/devices')
  public async updateDevice(
    @Body() request: UpdateDeviceRequestDto,
    @Req() req,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...request,
      userId: req.user.id,
    };

    return this.mmsServiceClient.send('device_update', payload);
  }

  @ApiOperation({
    tags: ['Devices'],
    summary: 'Danh sách tất cả thiết bị',
    description: 'Danh sách tất cả thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
  })
  @Get('/devices/all-devices')
  public async getAllDevice(@Req() req: any): Promise<any> {
    return this.mmsServiceClient.send('device_list_all', {
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Post('/devices/assign-device')
  @ApiOperation({
    tags: ['assign device', 'create assign device'],
    summary: 'Create assign device',
    description: 'Tạo phân công thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Created successfully',
    type: DeviceAssignResponseDto,
  })
  public async createAssignDevice(
    @Body() request: DeviceAssignRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('create_assign_device', {
      ...request,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Put('/devices/assign-device/:id')
  @ApiOperation({
    tags: ['assign device', 'update assign device'],
    summary: 'Update assign device',
    description: 'Sửa phân công thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: DeviceAssignResponseDto,
  })
  public async updateAssignDevice(
    @Param('id') id: string,
    @Body() request: UpdateDeviceAssignRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('update_assign_device', {
      ...request,
      id,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/devices/assign-device/:id')
  @ApiOperation({
    tags: ['assign device', 'get assign device'],
    summary: 'Get assign device',
    description: 'Lấy chi tiết phân công thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: GetDeviceAssignResponseDto,
  })
  public async getAssignDevice(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('get_assign_device', {
      id,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/devices/assign-device/:id/maintain-request')
  @ApiOperation({
    tags: ['get maintain request by assign device'],
    summary: 'Get maintain request by assign device',
    description: 'Lấy danh sách lịch sử bảo trì theo mã phân công thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: GetMaintainRequestByAssignDeviceResponse,
  })
  public async getMaintainRequestByAssignDevice(
    @Query() request: GetMaintainRequestByAssignDeviceRequest,
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('get_maintain_request_by_assign_device', {
      ...request,
      id,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/devices/assign-device/:id/maintain-info')
  @ApiOperation({
    tags: ['get maintain info by assign device'],
    summary: 'Get maintain info by assign device',
    description: 'Lấy danh sách thông tin bảo trì theo mã phân công thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: GetMaintainInfoByDeviceResponse,
  })
  public async getMaintainInfoByDevice(
    @Query() request: GetMaintainInfoByDeviceRequest,
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('get_maintain_info_by_device', {
      ...request,
      id,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/devices/assign-device/:id/attribute-type')
  @ApiOperation({
    tags: ['assign device', 'get attribute type of assign device'],
    summary: 'Get attribute type of assign device',
    description: 'Lấy danh sách thuộc tính của phân công thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: AttributeTypeByDeviceAssignResponseDto,
  })
  public async getAttributeTypeByDeviceAssign(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send(
      'get_attribute_type_by_device_assignment',
      {
        id,
        user: req.user,
        lang: req?.headers['lang'] || DEFAULT_LANG,
      },
    );
  }

  @Delete('/devices/assign-device/:id')
  @ApiOperation({
    tags: ['assign device', 'delete assign device'],
    summary: 'Delete assign device',
    description: 'Xóa phân công thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: GetDeviceAssignResponseDto,
  })
  public async deleteAssignDevice(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('delete_assign_device', {
      id,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Post('/device-assignments/import')
  @ApiOperation({
    tags: ['Supply'],
    summary: 'Import assign device',
    description: 'Import assign device',
  })
  @ApiResponse({
    status: 200,
    description: 'Created successfully',
    type: ImportDeviceAssignResponseDto,
  })
  public async importAssignDevice(
    @Body() request: ImportDeviceAssignmentRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('import_assign_device', {
      ...request,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/device-assignments/export')
  @ApiOperation({
    tags: ['Supply'],
    summary: 'Export assign device',
    description: 'Export assign device',
  })
  @ApiResponse({
    status: 200,
    description: 'Created successfully',
    type: DeviceAssignResponseDto,
  })
  public async exportAssignDevice(
    @Query() request: ExportDeviceAssignmentRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('export_assign_device', {
      ...request,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Post('/devices/assign-device/generate-qr-code')
  @ApiOperation({
    tags: ['qr code', 'generate qr code serial'],
    summary: 'Generate qr code serial',
    description: 'Tạo mã qr code serial',
  })
  @ApiResponse({
    status: 200,
    description: 'Generate successfully',
    type: GenerateQrCodeSerialResponse,
  })
  public async generateQrCodeSerial(
    @Body() request: GenerateQrCodeSerialRequest,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('generate_qr_code_serial', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Post('/generate-serial')
  @ApiOperation({
    tags: ['suggest serial'],
    summary: 'Gợi ý mã serial',
    description: 'Gợi ý mã serial',
  })
  @ApiResponse({
    status: 200,
    description: 'Generate successfully',
    type: GenerateSerialResponse,
  })
  public async generateSerial(
    @Body() request: GenerateSerialRequest,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('generate_serial', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Post('/validate-serial')
  @ApiOperation({
    tags: ['validate serial'],
    summary: 'Kiểm tra mã serial',
    description: 'Kiểm tra mã serial',
  })
  @ApiResponse({
    status: 200,
    description: 'Validate successfully',
    type: ValidateSerialResponse,
  })
  public async validateSerial(
    @Body() request: ValidateSerialRequest,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('validate_serial', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  /** End of web APIs **/
  /* End Devices section */

  @Get('/supplies')
  @ApiOperation({
    tags: ['List Supply'],
    summary: 'List Supply',
    description: 'List Supply',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetListSupplyResponseDto,
  })
  public async listSupply(
    @Query() request: GetListSupplyRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('list_supply', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  //Create
  @Post('/supplies')
  @ApiOperation({
    tags: ['Supply'],
    summary: 'Create Supply',
    description: 'Create a new Supply',
  })
  @ApiResponse({
    status: 200,
    description: 'Created successfully',
    type: CreateSupplyResponseDto,
  })
  public async createSupply(
    @Body() request: CreateSupplyRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('create_supply', {
      ...request,
      userId: req.user.id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Put('/supplies/:id')
  @ApiOperation({
    tags: ['Supply'],
    summary: 'Update Supply',
    description: 'Update an existing Supply',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: UpdateSupplyResponseDto,
  })
  public async updateSupply(
    @Param('id') id: string,
    @Body() request: UpdateSupplyRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('update_supply', {
      ...request,
      userId: req.user.id,
      _id: id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  //Delete
  @Delete('/supplies/:id')
  @ApiOperation({
    tags: ['Supply'],
    summary: 'Delete Supply',
    description: 'Delete an existing Supply',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteSupply(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('delete_supply', {
      id,
      userId: req.user.id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  //Approve
  @Put('/supplies/:id/confirmed')
  @ApiOperation({
    tags: ['Supply Group'],
    summary: 'Confirm Supply Group',
    description: 'Confirm an existing Supply Group',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: UpdateSupplyResponseDto,
  })
  public async confirmSupply(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('confirm_supply', {
      userId: req.user.id,
      _id: id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/supplies/:id')
  @ApiOperation({
    tags: ['Supply'],
    summary: 'Detail Supply',
    description: 'Detail Supply',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetDetailSupplyResponseDto,
  })
  public async detailSupply(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('detail_supply', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/item-unit/supplies/list')
  @ApiOperation({
    tags: ['Item Unit Setting'],
    summary: 'Get item unit setting list',
    description: 'Get item unit setting',
  })
  @ApiResponse({
    status: 200,
    description: 'Get item unit setting list successfully',
    type: GetListFactoryResponseDto,
  })
  public async getItemUnitSettingList(
    @Query() request: GetListFactoryRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('get_item_unit_list_for_supply', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/factory/supplies/list')
  @ApiOperation({
    tags: ['Factories'],
    summary: 'Get factory list',
    description: 'Get factory',
  })
  @ApiResponse({
    status: 200,
    description: 'Get item list successfully',
    type: GetListFactoryResponseDto,
  })
  public async getFactoryList(
    @Query() request: GetListFactoryRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('get_factory_list_for_supply', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/user/list')
  @ApiOperation({
    tags: ['Users'],
    summary: 'Get users list',
    description: 'Get user',
  })
  @ApiResponse({
    status: 200,
    description: 'Get user list successfully',
    type: GetListUserResponseDto,
  })
  public async getUserList(
    @Query() request: GetListUserRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('get_user_list', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  //Defect
  @Get('/defects')
  @ApiOperation({
    tags: ['List Defect'],
    summary: 'List Defect',
    description: 'List Defect',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetListDefectReponseDto,
  })
  public async listDefect(
    @Req() req: any,
    @Query() request: GetListDefectRequestDto,
  ): Promise<any> {
    return this.mmsServiceClient.send('list_defect', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Post('/defects')
  @ApiOperation({
    tags: ['Defect'],
    summary: 'Create Defect',
    description: 'Create a new Defect',
  })
  @ApiResponse({
    status: 200,
    description: 'Created successfully',
    type: CreateDefectResponseDto,
  })
  public async createDefect(
    @Body() request: CreateDefectRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('create_defect', {
      ...request,
      userId: req.user.id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Put('/defects/:id')
  @ApiOperation({
    tags: ['Defect'],
    summary: 'Update Defect',
    description: 'Update an existing Defect',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: UpdateDefectResponseDto,
  })
  public async updateDefect(
    @Param('id') id: string,
    @Body() request: UpdateSupplyRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('update_defect', {
      ...request,
      userId: req.user.id,
      _id: id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Delete('/defects/:id')
  @ApiOperation({
    tags: ['Defect'],
    summary: 'Delete Defect',
    description: 'Delete an existing Defect',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteDefect(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('delete_defect', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/defects/:id')
  @ApiOperation({
    tags: ['Defect'],
    summary: 'Detail Defect',
    description: 'Detail Defect',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetDetailDefectResponseDto,
  })
  public async detailDefect(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('detail_defect', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  // end of defect

  // Checklist-Template
  @Get('/check-list-templates')
  @ApiOperation({
    tags: ['List Check List Template'],
    summary: 'List Check List Template',
    description: 'List Check List Template',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetListCheckListTemplateResponseDto,
  })
  public async listCheckListTemplate(
    @Query() request: GetListCheckListTemplateRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('list_check_list_template', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Post('/check-list-templates')
  @ApiOperation({
    tags: ['Check List Template'],
    summary: 'Create Check List Template',
    description: 'Create a new Check List Template',
  })
  @ApiResponse({
    status: 200,
    description: 'Created successfully',
    type: CreateCheckListTemplateResponseDto,
  })
  public async createCheckListTemplate(
    @Body() request: CreateCheckListTemplateRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('create_check_list_template', {
      ...request,
      userId: req.user.id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Put('/check-list-templates/:id')
  @ApiOperation({
    tags: ['Check List Template'],
    summary: 'Update Check List Template',
    description: 'Update an existing Check List Template',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: UpdateCheckListTemplateResponseDto,
  })
  public async updateCheckListTemplate(
    @Param('id') id: string,
    @Body() request: UpdateCheckListTemplateRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('update_check_list_template', {
      ...request,
      userId: req.user.id,
      lang: req?.headers['lang'] || DEFAULT_LANG,

      _id: id,
    });
  }

  @Delete('/check-list-templates/:id')
  @ApiOperation({
    tags: ['Check List Template'],
    summary: 'Delete Check List Template',
    description: 'Delete an existing Check List Template',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteCheckListTemplate(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('delete_check_list_template', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/check-list-templates/:id')
  @ApiOperation({
    tags: ['Check List Template'],
    summary: 'Detail Check List Template',
    description: 'Detail Check List Template',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetDetailCheckListTemplateResponseDto,
  })
  public async detailCheckListTemplate(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('detail_check_list_template', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  // end of checklist template

  /* Begin of device request section */

  @ApiOperation({
    tags: ['DeviceRequests'],
    summary: 'Danh sách yêu cầu thiết bị',
    description: 'Danh sách yêu cầu thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListDeviceRequestsResponseDto,
  })
  @Get('/device-requests')
  public async getListDeviceRequests(
    @Query() request: ListDeviceRequestsRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('device_requests_list', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @ApiOperation({
    tags: ['DeviceRequests'],
    summary: 'Danh sách xưởng',
    description: 'Danh sách xưởng',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListWorkCenterResponse,
  })
  @Get('/device-requests/work-centers')
  public async getListWorkCenters(
    @Query() request: any,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('get_work_center_list', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  /** Begin of request ticket section **/

  @ApiOperation({
    tags: ['DeviceRequests_RequestTickets'],
    summary: 'Danh sách yêu cầu cấp thiết bị chờ phân công',
    description: 'Danh sách yêu cầu cấp thiết bị chờ phân công',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
  })
  @Get('/device-requests/awaiting-assignment-request-tickets')
  public async getListAwaitingAssignmentRequestTickets(
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send(
      'device_requests_awaiting_assignment_list',
      {
        lang: req?.headers['lang'] || DEFAULT_LANG,
      },
    );
  }

  @ApiOperation({
    tags: ['DeviceRequests_RequestTickets'],
    summary: 'Tạo yêu cầu cấp thiết bị',
    description: 'Tạo yêu cầu cấp thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: String,
  })
  @Post('/device-requests/request-tickets')
  public async createDeviceRequestTicket(
    @Body() request: CreateDeviceRequestTicketRequestDto,
    @Req() req,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...request,
      userCreatorId: req.user.id,
    };

    return this.mmsServiceClient.send('device_request_ticket_create', payload);
  }

  @ApiOperation({
    tags: ['DeviceRequests_RequestTickets'],
    summary: 'Chi tiết yêu cầu cấp thiết bị',
    description: 'Chi tiết yêu cầu cấp thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailDeviceRequestTicketResponseDto,
  })
  @Get('/device-requests/request-tickets/:id')
  public async getDetailDeviceRequestTicket(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('device_request_ticket_detail', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @ApiOperation({
    tags: ['DeviceRequests_RequestTickets'],
    summary: 'Xóa yêu cầu cấp thiết bị',
    description: 'Xóa yêu cầu cấp thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailDeviceRequestTicketResponseDto,
  })
  @Delete('/device-requests/request-tickets/:id')
  public async deleteDeviceRequestTicket(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('device_request_ticket_delete', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @ApiOperation({
    tags: ['DeviceRequests_RequestTickets'],
    summary: 'Sửa yêu cầu cấp thiết bị',
    description: 'Sửa yêu cầu cấp thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: String,
  })
  @Put('/device-requests/request-tickets')
  public async updateDeviceRequestTicket(
    @Body() request: UpdateDeviceRequestTicketRequestDto,
    @Req() req,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...request,
      userCreatorId: req.user.id,
    };

    return this.mmsServiceClient.send('device_request_ticket_update', payload);
  }

  @ApiOperation({
    tags: ['DeviceRequests_RequestTickets'],
    summary: 'Đổi trạng thái yêu cầu cấp thiết bị',
    description: 'Đổi trạng thái yêu cầu cấp thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: String,
  })
  @Patch('/device-requests/request-tickets')
  public async changeStatusDeviceRequestTicket(
    @Body() request: ChangeStatusDeviceRequestTicketRequestDto,
    @Req() req,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...request,
      userId: req.user.id,
      user: req.user,
    };

    return this.mmsServiceClient.send(
      'device_request_ticket_change_status',
      payload,
    );
  }

  /** End of request ticket section **/

  /** Begin of device status section **/

  @Post('/device-status/info-active-create')
  @ApiOperation({
    tags: ['DeviceStatus'],
    summary: 'Thêm mới thông tin hoạt động',
    description: 'Thêm mới thông tin hoạt động',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  public async infoActiveCreate(
    @Body() request: CreateDeviceStatusActivityRequestDto,
    @Req() req,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...request,
      userId: req.user.id,
    };
    return this.mmsServiceClient.send(
      'create_device_status_activity_info',
      payload,
    );
  }

  @Get('/device-status/:id/list-info-active')
  @ApiOperation({
    tags: ['DeviceStatus'],
    summary: 'Thông tin hoạt động của trạng thái thiết bị',
    description: 'Thông tin hoạt động của trạng thái thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DeviceStatusActivityInfoResponseDto,
  })
  public async listInfoActive(
    @Query() request: PaginationQuery,
    @Param('id') deviceAssignmentId: string,
    @Req() req,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      deviceAssignmentId,
      ...request,
    };
    return this.mmsServiceClient.send(
      'list_device_status_activity_info',
      payload,
    );
  }

  @Get('/device-status/:serial')
  @ApiOperation({
    tags: ['DeviceStatus'],
    summary: 'Thông tin hoạt động theo serial thiết bị',
    description: 'Thông tin hoạt động theo serial thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DeviceStatusBySerialResponseDto,
  })
  public async listInfoActiveBySerial(
    @Query() request: PaginationQuery,
    @Param('serial') serial: string,
    @Req() req,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      serial,
      ...request,
    };
    return this.mmsServiceClient.send('list_device_status_by_serial', payload);
  }

  @Get('/device-status')
  @ApiOperation({
    tags: ['List device status'],
    summary: 'Danh sách trạng thái thiết bị',
    description: 'Danh sách trạng thái thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListDeviceStatusResponse,
  })
  public async listDeviceStatus(
    @Query() request: PaginationQuery,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('list_device_status', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  /** End of device status section **/

  /** Begin of return ticket section **/

  @ApiOperation({
    tags: ['DeviceRequests_ReturnTickets'],
    summary: 'Tạo yêu cầu trả thiết bị',
    description: 'Tạo yêu cầu trả thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: String,
  })
  @Post('/device-requests/return-tickets')
  public async createDeviceReturnTicket(
    @Body() request: CreateDeviceReturnTicketRequestDto,
    @Req() req,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...request,
      userId: req.user.id,
    };

    return this.mmsServiceClient.send('device_return_ticket_create', payload);
  }

  @ApiOperation({
    tags: ['DeviceReturns_ReturnTickets'],
    summary: 'Chi tiết yêu cầu trả thiết bị',
    description: 'Chi tiết yêu cầu trả thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    //type: DetailDeviceReturnTicketResponseDto,
  })
  @Get('/device-requests/return-tickets/:id')
  public async getDetailDeviceReturnTicket(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('device_return_ticket_detail', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @ApiOperation({
    tags: ['DeviceReturns_ReturnTickets'],
    summary: 'Sửa yêu cầu trả thiết bị',
    description: 'Sửa yêu cầu trả thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: String,
  })
  @Put('/device-requests/return-tickets')
  public async updateDeviceReturnTicket(
    @Body() request: UpdateDeviceReturnTicketRequestDto,
    @Req() req,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...request,
      userId: req.user.id,
    };

    return this.mmsServiceClient.send('device_return_ticket_update', payload);
  }

  @ApiOperation({
    tags: ['DeviceReturns_ReturnTickets'],
    summary: 'Đổi trạng thái yêu cầu trả thiết bị',
    description: 'Đổi trạng thái yêu cầu trả thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: String,
  })
  @Patch('/device-requests/return-tickets')
  public async changeStatusReturnTicket(
    @Body() request: ChangeStatusDeviceReturnTicketRequestDto,
    @Req() req,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...request,
      userId: req.user.id,
    };

    return this.mmsServiceClient.send(
      'device_return_ticket_change_status',
      payload,
    );
  }

  @ApiOperation({
    tags: ['DeviceRequests_ReturnTickets'],
    summary: 'Xóa yêu cầu trả thiết bị',
    description: 'Xóa yêu cầu trả thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailDeviceRequestTicketResponseDto,
  })
  @Delete('/device-requests/return-tickets/:id')
  public async deleteDeviceReturnTicket(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('device_return_ticket_delete', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  /** End of return ticket section **/

  /* End of device request section */

  /* Start of general maintenance parameter section */
  @Get('/general-maintenance-parameters')
  @ApiOperation({
    tags: ['List General Maintenance Parameter'],
    summary: 'List General Maintenance Parameter',
    description: 'List General Maintenance Parameter',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListGeneralMaintenanceParameterResponseDto,
  })
  public async listGeneralMaintenanceParameter(
    @Query() request: ListGeneralMaintenanceParameterRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('list_general_maintenance_parameter', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  //Create
  @Post('/general-maintenance-parameters')
  @ApiOperation({
    tags: ['General Maintenance Parameter'],
    summary: 'Create General Maintenance Parameter',
    description: 'Create a new General Maintenance Parameter',
  })
  @ApiResponse({
    status: 200,
    description: 'Created successfully',
    type: SuccessResponse,
  })
  public async createGeneralMaintenanceParameter(
    @Body() request: CreateGeneralMaintenanceParameterResquestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('create_general_maintenance_parameter', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Put('/general-maintenance-parameters/:id')
  @ApiOperation({
    tags: ['General Maintenance Parameter'],
    summary: 'Update General Maintenance Parameter',
    description: 'Update an existing General Maintenance Parameter',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: UpdateGeneralMaintenanceParameterResponseDto,
  })
  public async updateGeneralMaintenanceParameter(
    @Param('id') id: string,
    @Body() request: UpdateGeneralMaintenanceParameterRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('update_general_maintenance_parameter', {
      ...request,
      _id: id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  /* End of general maintenance parameter section */

  @Put('/maintain-requests/:id/complete')
  @ApiOperation({
    tags: ['MaintainRequest', 'MMS'],
    summary: '',
    description: 'Hoàn thành yêu cầu bảo trì',
  })
  @ApiResponse({
    status: 200,
    description: 'Completed successfully',
    type: SuccessResponse,
  })
  public async completedMaintainRequest(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      id: id,
      userId: req.user.id,
    };
    return await this.mmsServiceClient.send(
      'completed_maintain_request',
      payload,
    );
  }

  @Put('/maintain-requests/:id/re-do')
  @ApiOperation({
    tags: ['MaintainRequest', 'MMS'],
    summary: '',
    description: 'Làm lại yêu cầu bảo trì',
  })
  @ApiResponse({
    status: 200,
    description: 'Redo successfully',
    type: SuccessResponse,
  })
  public async reDoMaintainRequest(
    @Param('id') id: string,
    @Body() request: ReWorkMaintainRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      id: id,
      userId: req.user.id,
      ...request,
    };
    return await this.mmsServiceClient.send('re_do_maintain_request', payload);
  }
  /* Start section API dashboard */
  @Get('/report-total-job')
  @ApiOperation({
    tags: ['Report total job'],
    summary: 'Report total job',
    description: 'Report total job',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ReportTotalJobResponse,
  })
  public async reportTotalJob(@Req() req: any): Promise<any> {
    return this.mmsServiceClient.send('report_total_job', {
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('dashboard/warning')
  @ApiOperation({
    tags: ['Dashboard warning'],
    summary: 'Dashboard warning',
    description: 'Dashboard warning',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: [DashboardWarningResponseDto],
  })
  public async dashboardWarning(
    @Query() request: GetDashboardWarningRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...request,
      user: req.user,
    };
    return this.mmsServiceClient.send('dashboard_warning', payload);
  }

  @Get('/report-progress-job')
  @ApiOperation({
    tags: ['Report progress job'],
    summary: 'Report progress job',
    description: 'Tiến độ công việc bảo trì',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ReportProgressJobResponse,
  })
  public async reportProgressJob(
    @Query() payload: ReportProgressJobQuery,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('report_progress_job', {
      ...payload,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/report-maintain-request')
  @ApiOperation({
    tags: ['Report maintain request'],
    summary: 'Report maintain request',
    description: 'Trạng thái yêu cầu',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ReportMaintainRequestResponse,
  })
  public async reportMaintainRequest(
    @Query() payload: ReportProgressJobQuery,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('report_maintain_request', {
      ...payload,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('dashboard/mttr-mtta-index')
  @ApiOperation({
    tags: ['Dashboard mttr mtta index'],
    summary: 'Dashboard mttr mtta index',
    description: 'Thông số mttr mtta',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DashboardMttrMttaResponse,
  })
  public async dashboardMttrMttaIndex(
    @Query() payload: DashboardMttrMttaQuery,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('dashboard_mttr_mtta_index', {
      ...payload,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('dashboard/device-status')
  @ApiOperation({
    tags: ['Dashboard device status'],
    summary: 'Dashboard trạng thái vận hành thiết bị',
    description: 'Trạng thái vận hành thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DashboardDeviceStatusResponseDto,
  })
  public async dashboardDeviceStatus(
    @Req() req: any,
    @Query() payload: GetDashboardDeviceStatusRequestDto,
  ): Promise<any> {
    return this.mmsServiceClient.send('dashboard_device_status', {
      ...payload,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  /* End section API dashboard */

  @ApiOperation({
    tags: ['Devices'],
    summary: 'Lịch sử bảo trì thiết bị',
    description: 'Lịch sử bảo trì thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DeviceMaintenanceHistoryAppResponseDto,
  })
  @Get('/app/devices/:serial/maintenance-histories')
  public async getDeviceMaintenanceHistoryApp(
    @Param('serial') serial: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('device_maintenance_history_app', {
      serial,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Put('/jobs/:id/rework')
  @ApiOperation({
    tags: ['Job', 'MMS'],
    summary: '',
    description: 'Làm lại công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Rework successfully',
    type: SuccessResponse,
  })
  public async reworkJob(
    @Param('id') id: string,
    @Body() request: UpdateStatusJobToReworkRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      id: id,
      user: req.user,
      ...request,
    };
    return await this.mmsServiceClient.send('rework_job', payload);
  }

  @Put('/jobs/:id/resolve')
  @ApiOperation({
    tags: ['Job', 'MMS'],
    summary: '',
    description: 'Hoàn thành công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Rework successfully',
    type: SuccessResponse,
  })
  public async resolveJob(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      id: id,
      user: req.user,
    };
    return await this.mmsServiceClient.send('resolved_job', payload);
  }

  @Get('/warnings')
  @ApiOperation({
    tags: ['Warning', 'MMS'],
    summary: '',
    description: 'Danh sách cảnh báo lỗi',
  })
  @ApiResponse({
    status: 200,
    description: 'List Warning successfully',
    type: ListWarningResponse,
  })
  public async listWarning(
    @Query() query: GetListWarningRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...query,
      userId: req.user.id,
    };
    return await this.mmsServiceClient.send('list_warning', payload);
  }

  @Get('/jobs/report-progress/list')
  @ApiOperation({
    tags: ['Jobs', 'MMS'],
    summary: '',
    description: 'Báo cáo tiến độ công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Report job progress successfully',
    type: ListJobDataResponseDto,
  })
  public async reportJobProgress(
    @Query() query: PaginationQuery,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...query,
      ...{ user: req.user },
    };
    return await this.mmsServiceClient.send(
      'report_job_progress_list',
      payload,
    );
  }

  @Get('/jobs/report')
  @ApiOperation({
    tags: ['Jobs', 'MMS'],
    summary: '',
    description: 'Báo cáo công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Report job successfully',
    type: ReportJobResponseDto,
  })
  public async reportJob(
    @Query() query: PaginationQuery,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...query,
      user: req.user,
    };
    return await this.mmsServiceClient.send('report_job', payload);
  }

  @Get('/jobs/report/:id')
  @ApiOperation({
    tags: ['Jobs', 'MMS'],
    summary: '',
    description: 'Báo cáo công việc chi tiết',
  })
  @ApiResponse({
    status: 200,
    description: 'Report job detail successfully',
    type: ReportJobDetailResponseDto,
  })
  public async reportJobDetail(
    @Req() req: any,
    @Param('id') id: string,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      user: req.user,
      id,
    };
    return await this.mmsServiceClient.send('report_job_detail', payload);
  }

  @Get('/maintenance-team/users/list')
  @ApiOperation({
    tags: ['Users'],
    summary: 'Get users list',
    description: 'Get user',
  })
  @ApiResponse({
    status: 200,
    description: 'Get user list successfully',
    type: GetListUserResponseDto,
  })
  public async getUserListByDepartment(
    @Query() request: GetListUserRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('get_user_list_by_department', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/report-device-status')
  @ApiOperation({
    tags: ['Report device status'],
    summary: 'Báo cáo trạng thái thiết bị',
    description: 'Trạng thái thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListReportDeviceStatusResponse,
  })
  public async getListReportDeviceStatus(
    @Query() payload: ListReportDeviceStatusQuery,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('list_report_device_status', {
      ...payload,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/report-device-assign-status')
  @ApiOperation({
    tags: ['Report device assign status'],
    summary: 'Báo cáo trạng thái phân công thiết bị ',
    description: 'Trạng thái phân công thiết bị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListReportDeviceAssignStatusResponse,
  })
  public async getListReportDeviceAssignStatus(
    @Query() payload: ListReportDeviceAssignStatusQuery,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('list_report_device_assign_status', {
      ...payload,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  // cron job

  @Get('/cron/warning-checklist')
  public async runCronJobCreateWarningChecklist(@Req() req: any): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      userId: req.user.id,
    };
    return this.mmsServiceClient.send('run_cron_warning_checklist', payload);
  }

  @Get('/cron/warning-checklist-every-day')
  public async runCronWarningChecklistEveryday(@Req() req: any): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      userId: req.user.id,
    };
    return this.mmsServiceClient.send(
      'run_cron_warning_checklist_every_day',
      payload,
    );
  }

  @Get('/cron/warning-maintain-peroid-device-error')
  public async runCronWarningMaintancePeroidDeviceError(
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      userId: req.user.id,
    };
    return this.mmsServiceClient.send(
      'run_cron_warning_maintance_peroid_device_error',
      payload,
    );
  }

  @Get('/cron/warning-maintain-peroid-device')
  public async runCronWarningMaintancePeroidDevice(
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      userId: req.user.id,
    };
    return this.mmsServiceClient.send(
      'run_cron_warning_maintance_peroid_device',
      payload,
    );
  }

  @Get('/cron/warning-maintain-peroid-supply-error')
  public async runCronWarningMaintancePeroidSupplyError(
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      userId: req.user.id,
    };
    return this.mmsServiceClient.send(
      'run_cron_warning_maintance_peroid_supply_error',
      payload,
    );
  }

  @Get('/cron/warning-maintain-peroid-supply')
  public async runCronWarningMaintancePeroidSupply(
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      userId: req.user.id,
    };
    return this.mmsServiceClient.send(
      'run_cron_warning_maintance_peroid_supply',
      payload,
    );
  }

  @Get('/cron/warning-maintain-peroid-replace-accessory')
  public async runCronWarningMaintancePeroidReplaceAsscessory(
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      userId: req.user.id,
    };
    return this.mmsServiceClient.send(
      'run_cron_warning_maintance_peroid_replace_accessory',
      payload,
    );
  }

  @Get('/cron/update-job-completed-to-resolve')
  public async runCronUpdateJobFromCompletedToResolve(
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      userId: req.user.id,
    };
    return this.mmsServiceClient.send(
      'run_cron_update_job_from_completed_to_resolve',
      payload,
    );
  }

  @Get('/cron/update-job-to-out-of-date')
  public async runCronUpdateJobToOutOfDate(@Req() req: any): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      userId: req.user.id,
    };
    return this.mmsServiceClient.send(
      'run_cron_update_job_to_out_of_date',
      payload,
    );
  }

  // end cron job
  // Export
  @Post('device-groups/export')
  @ApiOperation({
    tags: ['Export Device Group'],
    summary: 'Export Device Group',
    description: 'Export Device Group',
  })
  @ApiResponse({
    status: 200,
    description: 'Export successfully',
  })
  public async exportDeviceGroup(
    @Body() request: ExportDeviceGroupRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('export_device_group', {
      ...request,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Post('defects/export')
  @ApiOperation({
    tags: ['Export Defect'],
    summary: 'Export Defect',
    description: 'Export Defect',
  })
  @ApiResponse({
    status: 200,
    description: 'Export successfully',
  })
  public async exportDefect(
    @Body() request: ExportDefectRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('export_defect', {
      ...request,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Post('supplies/export')
  @ApiOperation({
    tags: ['Export Supply'],
    summary: 'Export Supply',
    description: 'Export Supply',
  })
  @ApiResponse({
    status: 200,
    description: 'Export successfully',
  })
  public async exportSupply(
    @Body() request: ExportSupplyRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('export_supply', {
      ...request,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Post('check-list-templates/export')
  @ApiOperation({
    tags: ['Export Check List Template'],
    summary: 'Export Check List Template',
    description: 'Export Check List Template',
  })
  @ApiResponse({
    status: 200,
    description: 'Export successfully',
  })
  public async exportCheckListTemplate(
    @Body() request: ExportSupplyRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('export_check_list_template', {
      ...request,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Post('devices/export')
  @ApiOperation({
    tags: ['Export Device'],
    summary: 'Export Device',
    description: 'Export Device',
  })
  @ApiResponse({
    status: 200,
    description: 'Export successfully',
  })
  public async exportDevice(
    @Body() request: ExportSupplyRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('export_device', {
      ...request,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  //plan
  @Get('plan/list')
  @ApiOperation({
    tags: ['List Plan'],
    summary: 'Danh sách kế hoạch tổng thể',
    description: 'Danh sách kế hoạch tổng thể',
  })
  @ApiResponse({
    status: 200,
    description: 'List successfully',
    type: ListPlanItemResponse,
  })
  public async listPlan(
    @Query() request: PlanItemQuery,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...request,
      user: req.user,
    };
    return await this.mmsServiceClient.send('list_plans', payload);
  }

  @Get('plan/gantt-chart')
  @ApiOperation({
    tags: ['Gantt chart plan'],
    summary: 'Biểu đồ kế hoạch',
    description: 'Biểu đồ kế hoạch',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: GanttChartPlanResponse,
  })
  public async ganttChart(
    @Query() request: GanttChartPlanQuery,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    };
    return await this.mmsServiceClient.send('gantt_chart_plan', payload);
  }

  @Put('plan/:id/reject')
  @ApiOperation({
    tags: ['Plans'],
    summary: 'Từ chối kế hoạch',
    description: 'Từ chối kế hoạch',
  })
  @ApiResponse({
    status: 200,
    description: 'Update Item',
    type: SuccessResponse,
  })
  public async plansReject(
    @Param('id') id: string,
    @Req() req: any,
    @Body() request: RejectPlanRequestDto,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      id: id,
      user: req.user,
      ...request,
    };
    return await this.mmsServiceClient.send('update_plan_reject', payload);
  }

  @Put('plan/:id/approve')
  @ApiOperation({
    tags: ['Plans'],
    summary: 'Xác nhận kế hoạch',
    description: 'Xác nhận kế hoạch',
  })
  @ApiResponse({
    status: 200,
    description: 'Update Item',
    type: SuccessResponse,
  })
  public async plansApprove(
    @Param('id') id: string,
    @Req() req: any,
    @Body() request: ApprovePlanRequestDto,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      id: id,
      user: req.user,
      ...request,
    };
    return await this.mmsServiceClient.send('update_plan_approve', payload);
  }

  @Get('plan/:id')
  @ApiOperation({
    tags: ['Plans'],
    summary: 'Chi tiết kế hoạch',
    description: 'Chi tiết kế hoạch',
  })
  @ApiResponse({
    status: 200,
    description: 'Update Item',
    type: PlanDetailResponseDto,
  })
  public async planDetail(
    @Param('id') id: string,
    @Req() req: any,
    @Query() request: PlanDetailRequestDto,
  ): Promise<any> {
    const payload = {
      lang: req?.headers['lang'] || DEFAULT_LANG,
      ...request,
      id: id,
      user: req.user,
    };
    return await this.mmsServiceClient.send('plan_detail', payload);
  }

  @Delete('plan/:id')
  @ApiOperation({
    tags: ['Plans'],
    summary: 'Xóa kế hoạch',
    description: 'Xóa kế hoạch',
  })
  @ApiResponse({
    status: 200,
    type: SuccessResponse,
  })
  public async deletePlan(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return await this.mmsServiceClient.send('delete_plan', {
      id,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Put('/plan/:id/update')
  @ApiOperation({
    tags: ['Update plan'],
    summary: 'Cập nhật kế hoạch',
    description: 'Cập nhật kế hoạch',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  public async updatePlan(
    @Body() request: UpdatePlanRequestDto,
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('update_plan', {
      ...request,
      id,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Post('/plan/generate-job')
  @ApiOperation({
    tags: ['Generate job for plan'],
    summary: 'Gen công việc từ nhà máy hoặc xưởng',
    description: 'Gen công việc từ nhà máy hoặc xưởng',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GenerateJobForPlanResponse,
  })
  public async generateJobForPlan(
    @Body() request: GenerateJobForPlanRequest,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('generate_job_for_plan', {
      ...request,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  //end plan
  // List API attribute type
  @Post('/attribute-type')
  @ApiOperation({
    tags: ['Create attribute type'],
    summary: 'Định nghĩa loại giá trị',
    description: 'Định nghĩa loại giá trị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  public async createAttributeType(
    @Body() request: CreateAttributeTypeRequest,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('create_attribute_type', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Put('/attribute-type/:id')
  @ApiOperation({
    tags: ['Update attribute type'],
    summary: 'Cập nhật loại giá trị',
    description: 'Cập nhật loại giá trị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  public async updateAttributeType(
    @Body() request: UpdateAttributeTypeRequest,
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('update_attribute_type', {
      ...request,
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/attribute-type/:id')
  @ApiOperation({
    tags: ['Detail attribute type'],
    summary: 'Chi tiết loại giá trị',
    description: 'Chi tiết loại giá trị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailAttributeTypeResponse,
  })
  public async detailAttributeType(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('detail_attribute_type', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Delete('/attribute-type/:id')
  @ApiOperation({
    tags: ['Detail attribute type'],
    summary: 'Chi tiết loại giá trị',
    description: 'Chi tiết loại giá trị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  public async deleteAttributeType(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('delete_attribute_type', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/attribute-type')
  @ApiOperation({
    tags: ['List attribute type'],
    summary: 'Danh sách loại giá trị',
    description: 'Danh sách loại giá trị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListAttributeTypeResponse,
  })
  public async listAttributeType(
    @Query() query: ListAttributeTypeQuery,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('list_attribute_type', {
      ...query,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Post('/validate-attribute-type')
  @ApiOperation({
    tags: ['validate attribute type'],
    summary: 'Kiểm tra loại giá trị',
    description: 'Kiểm tra loại giá trị',
  })
  @ApiResponse({
    status: 200,
    description: 'Validate successfully',
    type: ValidateSerialResponse,
  })
  public async validateAttributeType(
    @Body() request: ValidateCodeRequest,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('validate_attribute_type', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Post('/plan')
  @ApiOperation({
    tags: ['Create plan'],
    summary: 'Tạo kế hoạch',
    description: 'Tạo kế hoạch',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  public async createPlan(
    @Body() request: CreatePlanRequestDto,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('create_plan', {
      ...request,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  // Start Installation template
  @Post('/installation-template')
  @ApiOperation({
    tags: ['Create Installation template'],
    summary: 'Tạo phiếu lắp đặt',
    description: 'Tạo phiếu lắp đặt',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  public async createInstallationTemplate(
    @Body() request: CreateInstallationTemplateRequest,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('create_installation_template', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/installation-template')
  @ApiOperation({
    tags: ['List installation'],
    summary: 'Danh sách phiếu lắp đặt',
    description: 'Danh sách phiếu lắp đặt',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListInstallationTemplate,
  })
  public async listInstallationTemplate(
    @Query() request: ListInstallationTemplateQuery,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('list_installation_template', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Put('/installation-template/:id')
  @ApiOperation({
    tags: ['UpdateInstallation template'],
    summary: 'Cập nhật phiếu lắp đặt',
    description: 'Cập nhật phiếu lắp đặt',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  public async updateInstallationTemplate(
    @Body() request: UpdateInstallationTemplateRequest,
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('update_installation_template', {
      ...request,
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/installation-template/:id')
  @ApiOperation({
    tags: ['Detail installation template'],
    summary: 'Chi tiết phiếu lắp đặt',
    description: 'Chi tiết phiếu lắp đặt',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailInstallationTemplateResponse,
  })
  public async detailInstallationTemplate(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('detail_installation_template', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Delete('/installation-template/:id')
  @ApiOperation({
    tags: ['Delete installation template'],
    summary: 'Xóa phiếu lắp đặt',
    description: 'Xóa phiếu lắp đặt',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  public async deleteInstallationTemplate(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('delete_installation_template', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
  // End Installation template

  @Get('device-assignment/serial-by-device')
  @ApiOperation({
    tags: ['List serial'],
    summary: 'Danh sách mã serial theo thiết bị và trạng thái',
    description: 'Danh sách mã serial theo thiết bị và trạng thái',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListSerialByDeviceResponse,
  })
  public async listSerialByDeviceIds(
    @Query() request: ListSerialByDeviceIds,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('list_serial_by_device_ids', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/device-assignments/mo-information')
  @ApiOperation({
    tags: ['Device Assignment'],
    summary: 'danh sách mo theo xưởng & plan',
    description: 'danh sách mo theo xưởng & plan',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: GetMoInformationResponse,
  })
  public async getMoinformation(
    @Query() request: getMoInformation,
    @Req() req: any,
  ): Promise<any> {
    return await this.mmsServiceClient.send('get_mo_information', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('device-assignments/manufacturing-information')
  @ApiOperation({
    tags: ['Device Assignment'],
    summary: 'get log time theo mo',
    description: 'get log time theo mo',
  })
  @ApiResponse({
    status: 200,
    description: 'success',
    type: GetLogTimeByMoIdResponse,
  })
  public async getLogTimeByWoId(
    @Query() query: getManufacturingInformation,
    @Req() req: any,
  ): Promise<any> {
    return await this.mmsServiceClient.send('get_log_time_by_mo_ids', {
      ...query,
      wcId: +query.wcId,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/serial-by-device')
  @ApiOperation({
    tags: ['List serial'],
    summary: 'Danh sách mã serial theo thiết bị và trạng thái',
    description: 'Danh sách mã serial theo thiết bị và trạng thái',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListSerialByDeviceResponse,
  })
  public async listSerialByDevice(
    @Query() request: ListSerialByDeviceQuery,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('list_serial_by_device', {
      ...request,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/device-requests/list-imo')
  @ApiOperation({
    tags: ['Device request'],
    summary: 'Danh sách yêu cầu vật tư phụ tùng',
    description: 'Danh sách yêu cầu vật tư phụ tùng',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListDeviceRequestImoResponseDto,
  })
  async listDeviceRequestImo(
    @Query() query: ListDeviceRequestImoQuery,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      query,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    };
    return this.mmsServiceClient.send('list_device_request_imo', payload);
  }

  @Post('/supply-request')
  @ApiOperation({
    tags: ['Create supply request'],
    summary: 'Yêu cầu vật tư phụ tùng',
    description: 'Yêu cầu vật tư phụ tùng',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  public async createSupplyRequest(
    @Body() request: CreateSupplyRequest,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('create_supply_request', {
      ...request,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/supply-request')
  @ApiOperation({
    tags: ['List supply request'],
    summary: 'Danh sách yêu cầu vật tư phụ tùng',
    description: 'Danh sách yêu cầu vật tư phụ tùng',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListSupplyRequestResponseDto,
  })
  public async listSupplyRequest(
    @Query() request: ListSupplyRequestQuery,
  ): Promise<any> {
    return this.mmsServiceClient.send('list_supply_request', request);
  }

  @Delete('/supply-request/:id')
  @ApiOperation({
    tags: ['Delete supply request'],
    summary: 'Xóa yêu cầu vật tư phụ tùng',
    description: 'Xóa yêu cầu vật tư phụ tùng',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  public async deleteSupplyRequest(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('delete_supply_request', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/supply-request/:id/histories')
  @ApiOperation({
    tags: ['Supply request'],
    summary: 'lịch sử cầu vật tư phụ tùng',
    description: 'lịch sử yêu cầu vật tư phụ tùng',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: GetHistorySupplyResponse,
  })
  public async getHistorySupplyRequest(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('get_history_supply_request', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/device-requests/list-imo/:id')
  @ApiOperation({
    tags: ['Detail request'],
    summary: 'Chi tiết yêu cầu',
    description: 'Chi tiết yêu cầu',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  public async detailDeviceRequestImo(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('detail_device_request_imo', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Get('/supply-request/:id')
  @ApiOperation({
    tags: ['Detail supply request'],
    summary: 'Chi tiết yêu cầu vật tư phụ tùng',
    description: 'Chi tiết yêu cầu vật tư phụ tùng',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailSuppyRequestResponse,
  })
  public async detailSupplyRequest(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('detail_supply_request', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Put('/supply-request/:id')
  @ApiOperation({
    tags: ['Update supply request'],
    summary: 'Cập nhật yêu cầu vtpt',
    description: 'Cập nhật yêu cầu vtpt',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  public async updateSupplyRequest(
    @Body() request: UpdateSupplyRequest,
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('update_supply_request', {
      ...request,
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
      user: req.user,
    });
  }

  @Put('/supply-request/:id/confirm')
  @ApiOperation({
    tags: ['Confirm supply request'],
    summary: 'Xác nhận yêu cầu vật tư phụ tùng',
    description: 'Xác nhận yêu cầu vật tư phụ tùng',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  public async confirmSupplyRequest(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('confirm_supply_request', {
      id,
      user: req.user,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }

  @Put('/supply-request/:id/reject')
  @ApiOperation({
    tags: ['Reject supply request'],
    summary: 'Từ chối yêu cầu vật tư phụ tùng',
    description: 'Từ chối yêu cầu vật tư phụ tùng',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  public async rejectSupplyRequest(
    @Param('id') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('reject_supply_request', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
      user: req.user,
    });
  }

  @Get('/count-supply-in-request/:jobId')
  @ApiOperation({
    tags: ['Count supply in request by job'],
    summary: 'Đếm số lượng vật tư trong yêu cầu đã được nhận theo công việc',
    description:
      'Đếm số lượng vật tư trong yêu cầu đã được nhận theo công việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: CountSupplyInRequestByJobResponseDto,
  })
  public async countSupplyInRequestByJob(
    @Param('jobId') id: string,
    @Req() req: any,
  ): Promise<any> {
    return this.mmsServiceClient.send('count_supply_in_request_by_job', {
      id,
      lang: req?.headers['lang'] || DEFAULT_LANG,
    });
  }
}
