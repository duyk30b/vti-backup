import {
  ApiExcludeEndpoint,
  ApiOperation,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { Controller, Get, Inject, Req } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { EnvResponseDto } from './dto/response/env-response.dto';
import { plainToClass } from 'class-transformer';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Public } from '@core/decorators/set-public.decorator';
import { flatMap, map, uniq } from 'lodash';

@Controller('app')
@ApiTags('App')
export class AppController {
  constructor(
    @Inject('USER_SERVICE')
    private readonly userServiceClient: ClientProxy,

    @Inject('ITEM_SERVICE')
    private readonly itemServiceClient: ClientProxy,

    @Inject('WAREHOUSE_SERVICE')
    private readonly warehouseServiceClient: ClientProxy,

    @Inject('QMSX_SERVICE')
    private readonly qmsxServiceClient: ClientProxy,
  ) {}

  @Get('ping')
  public async get(): Promise<any> {
    return await this.userServiceClient.send('ping', {});
  }

  @Public()
  @Get('/seeders/nagf8gCudw=2313ndnkfjy24091u30932gsjknkjn2i3y1293820k,cn,')
  @ApiExcludeEndpoint()
  public async initSeeder(): Promise<any> {
    return await Promise.all([
      this.userServiceClient.send('run_seeders', {}).toPromise(),
      this.itemServiceClient.send('run_seeders', {}).toPromise(),
      this.warehouseServiceClient.send('run_seeders', {}).toPromise(),
    ]);
  }

  @Get('/env')
  @ApiOperation({
    tags: ['App', 'Enviroment'],
    summary: 'Env',
    description: 'Lấy dữ liệu khởi tạo',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: EnvResponseDto,
  })
  public async getEnv(@Req() req: any): Promise<any> {
    const userRoleIds = uniq(map(req.user.userRoleSettings, 'id'));
    const userDepartmentIds = uniq(map(req.user.departmentSettings, 'id'));

    const res = await Promise.all([
      this.userServiceClient
        .send('get_env', {
          userCode: req.user.code,
          userId: req.user.id,
          userRoleIds: userRoleIds,
          userDepartmentIds: userDepartmentIds,
        })
        .toPromise(),
      this.itemServiceClient.send('get_env', {}).toPromise(),
      this.warehouseServiceClient.send('get_env', {}).toPromise(),
    ]);
    let data = {};
    res.forEach((r) => {
      if (r.statusCode) {
        data = {
          ...data,
          ...r.data,
        };
      }
    });

    const response = plainToClass(EnvResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }
}
