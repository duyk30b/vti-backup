import { LoginRequestDto } from './dto/request/login-request.dto';
import {
  Body,
  Controller,
  Get,
  Inject,
  Query,
  Post,
  Req,
} from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Public } from '@core/decorators/set-public.decorator';
import { LoginSucessfullyResponseDto } from './dto/response/login-sucessfully-response.dto';

@Controller('auth')
@ApiTags('Auth')
export class AuthController {
  constructor(
    @Inject('USER_SERVICE')
    private readonly userServiceClient: ClientProxy,
  ) {}

  @Get('ping')
  public async get(): Promise<any> {
    return await this.userServiceClient.send('ping', {});
  }

  @Public()
  @Post('/login')
  @ApiOperation({
    tags: ['Auth', 'Login'],
    summary: 'Login',
    description: 'Đăng nhập',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: LoginSucessfullyResponseDto,
  })
  public async login(
    @Body() request: LoginRequestDto,
    @Req() req: any,
  ): Promise<any> {
    const payload = {
      ...request,
      lang: req.headers['lang'],
    };
    return await this.userServiceClient.send('login', payload);
  }

  @Get('/token/refresh')
  @ApiOperation({
    tags: ['Auth', 'Refresh Token'],
    summary: 'Login',
    description: 'Tạo mới access token',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: LoginSucessfullyResponseDto,
  })
  public async refreshToken(
    @Req() request: any,
    @Query('rememberPassword') rememberPassword: number,
  ): Promise<any> {
    const payload = {
      ...request.user,
      rememberPassword,
      lang: request.headers['lang'],
    };

    return await this.userServiceClient.send('refresh_token', payload);
  }
}
