import {IsEnum, IsNotEmpty, IsNumber, IsString, MaxLength} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { RememberPassword } from '@utils/common';

export class LoginRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  username: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  password: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  rememberPassword: number;
}
