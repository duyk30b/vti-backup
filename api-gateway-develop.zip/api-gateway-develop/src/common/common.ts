export enum APIPrefix {
  Version = 'api/v1',
}

export const DEFAULT_LANG = 'vi';
