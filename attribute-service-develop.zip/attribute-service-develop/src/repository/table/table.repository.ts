import { CreateTableRequestDto } from '@components/tables/dto/request/create-table.request.dto';
import { GetListTableRequestDto } from '@components/tables/dto/request/get-list-table.request.dto';
import { TableRepositoryInterface } from '@components/tables/interfaces/table.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { getRegexByValue } from '@utils/common';
import { isEmpty } from 'lodash';
import { Model, Types } from 'mongoose';
import { Table } from 'src/models/tables/table.shcema';

export class TableRepository
  extends BaseAbstractRepository<Table>
  implements TableRepositoryInterface
{
  constructor(
    @InjectModel('Table')
    private readonly tableModel: Model<Table>,
  ) {
    super(tableModel);
  }

  createEntity(request: CreateTableRequestDto): Table {
    const tableDoc = new this.tableModel();
    tableDoc.code = request.code;
    tableDoc.name = request.name;
    tableDoc.prefixService = request.prefixService;
    tableDoc.description = request.description;
    return tableDoc;
  }

  async getList(request: GetListTableRequestDto): Promise<any> {
    const { keyword, sort, filter, take, skip } = request;
    let filterObj = {};
    let sortObj = {};

    if (!isEmpty(keyword)) {
      filterObj = {
        $or: [
          { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          { name: getRegexByValue(keyword) },
        ],
      };
    }
    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: {
                $regex: `.*${value}.*`,
                $options: 'i',
              },
            };
            break;
          case 'name':
            filterObj = {
              ...filterObj,
              name: getRegexByValue(value),
            };
            break;
          case 'active':
            filterObj = {
              ...filterObj,
              active: parseInt(value),
            };
            break;
          case 'ids':
            filterObj = {
              ...filterObj,
              _id: {
                $in: value.split(',').map((e) => new Types.ObjectId(e)),
              },
            };
            break;
          default:
            break;
        }
      });
    }
    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order?.toSortOrder();
        switch (item.column) {
          case 'code':
            sortObj = { code: order };
            break;
          case 'name':
            sortObj = { name: order };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = { code: -1 };
    }

    const result: any = await this.tableModel
      .aggregate()
      .match(filterObj)
      .sort(sortObj)
      .skip(skip)
      .limit(take)
      .exec();
    const count = await this.tableModel
      .find({
        ...filterObj,
      })
      .countDocuments()
      .exec();
    return {
      data: result,
      count,
    };
  }
}
