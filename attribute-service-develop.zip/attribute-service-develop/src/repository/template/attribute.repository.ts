import { GetListAttributeRequestDto } from '@components/attribute/dto/request/get-list-attribute.request.dto';
import { UpdateAttributeBodyDto } from '@components/attribute/dto/request/update-attribute.request.dto';
import { CreateAttributeRequestDto } from '@components/template/dto/request/attribues/create-attribute-general.request.dto';
import { ACTIVE_ENUM } from '@constant/common';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { getRegexByValue } from '@utils/common';
import { isEmpty } from 'lodash';
import { Model, Types } from 'mongoose';
import { Attribute } from 'src/models/attributes/attribute.schema';
import { AttributeRepositoryInterface } from '@components/attribute/interfaces/attribute.repository.interface';

export class AttributeRepository
  extends BaseAbstractRepository<Attribute>
  implements AttributeRepositoryInterface
{
  constructor(
    @InjectModel('Attribute')
    private readonly attributeModel: Model<Attribute>,
  ) {
    super(attributeModel);
  }

  createEntity(request: CreateAttributeRequestDto): Attribute {
    const attributeDocument = new this.attributeModel();
    attributeDocument.code = request.code;
    attributeDocument.name = request.name;
    attributeDocument.dataType = request.dataType;
    attributeDocument.active = ACTIVE_ENUM.ACTIVE;
    return attributeDocument;
  }

  updateEntity(entity: Attribute, request: UpdateAttributeBodyDto): Attribute {
    entity.code = request.code;
    entity.name = request.name;
    entity.dataType = request.dataType;
    return entity;
  }

  async list(request: GetListAttributeRequestDto): Promise<any> {
    const { keyword, sort, filter, take, skip } = request;
    let filterObj = {};
    let sortObj = {};

    if (!isEmpty(keyword)) {
      filterObj = {
        $or: [
          { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          { name: getRegexByValue(keyword) },
        ],
      };
    }
    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: {
                $regex: `.*${value}.*`,
                $options: 'i',
              },
            };
            break;
          case 'name':
            filterObj = {
              ...filterObj,
              name: getRegexByValue(value),
            };
            break;
          case 'active':
            filterObj = {
              ...filterObj,
              active: parseInt(value),
            };
            break;
          case 'dataType':
            filterObj = {
              ...filterObj,
              dataType: parseInt(value),
            };
          case 'isFixedParent':
            filterObj = {
              ...filterObj,
              isFixedParent: parseInt(value),
            };
            break;
          case 'module':
            filterObj = {
              ...filterObj,
              module: parseInt(value),
            };
            break;
          case 'ids':
            filterObj = {
              ...filterObj,
              _id: {
                $in: value.split(',').map((e) => new Types.ObjectId(e)),
              },
            };
            break;
          case 'codes':
            filterObj = {
              ...filterObj,
              code: {
                $in: value.split(','),
              },
            };
            break;
          default:
            break;
        }
      });
    }
    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order?.toSortOrder();
        switch (item.column) {
          case 'code':
            sortObj = { code: order };
            break;
          case 'name':
            sortObj = { name: order };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = { createdAt: -1 };
    }

    const result: any = await this.attributeModel
      .aggregate()
      .match(filterObj)
      .sort(sortObj)
      .skip(skip)
      .limit(take)
      .exec();
    const count = await this.attributeModel
      .find({
        ...filterObj,
      })
      .countDocuments()
      .exec();
    return {
      data: result,
      count,
    };
  }
}
