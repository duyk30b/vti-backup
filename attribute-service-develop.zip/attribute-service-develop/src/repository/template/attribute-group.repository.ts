import { GetListAttributeGroupRequestDto } from '@components/attribute-group/dto/request/get-list-attribute-group.request.dto';
import { UpdateAttributeGroupBodyDto } from '@components/attribute-group/dto/request/update-attribute-group.request.dto';
import { AttributeGroupRepositoryInterface } from '@components/attribute-group/interfaces/attribute-group.repository.interface';
import { CreateAttributeGroupRequestDto } from '@components/template/dto/request/attribues/create-attribute-general.request.dto';
import { ACTIVE_ENUM } from '@constant/common';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { getRegexByValue } from '@utils/common';
import { isEmpty } from 'lodash';
import { Model } from 'mongoose';
import { AttributeGroup } from 'src/models/attribute-groups/attribute-group.schema';

export class AttributeGroupRepository
  extends BaseAbstractRepository<AttributeGroup>
  implements AttributeGroupRepositoryInterface
{
  constructor(
    @InjectModel('AttributeGroup')
    private readonly attributeGroupModel: Model<AttributeGroup>,
  ) {
    super(attributeGroupModel);
  }

  createEntity(request: CreateAttributeGroupRequestDto): AttributeGroup {
    const templateDocument = new this.attributeGroupModel();
    templateDocument.code = request.code;
    templateDocument.name = request.name;
    templateDocument.description = request.description;
    templateDocument.order = request.order;
    templateDocument.active = ACTIVE_ENUM.ACTIVE;
    return templateDocument;
  }

  updateEntity(
    entity: AttributeGroup,
    request: UpdateAttributeGroupBodyDto,
  ): AttributeGroup {
    entity.code = request.code;
    entity.code = request.code;
    entity.name = request.name;
    entity.order = request.order;
    entity.description = request.description;
    return entity;
  }

  async list(request: GetListAttributeGroupRequestDto): Promise<any> {
    const { keyword, sort, filter, take, skip } = request;
    let filterObj = {};
    let sortObj = {};

    if (!isEmpty(keyword)) {
      filterObj = {
        $or: [
          { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          { name: getRegexByValue(keyword) },
        ],
      };
    }
    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: {
                $regex: `.*${value}.*`,
                $options: 'i',
              },
            };
            break;
          case 'name':
            filterObj = {
              ...filterObj,
              name: getRegexByValue(value),
            };
            break;
          case 'active':
            filterObj = {
              ...filterObj,
              active: parseInt(value),
            };
            break;
          default:
            break;
        }
      });
    }
    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order?.toSortOrder();
        switch (item.column) {
          case 'code':
            sortObj = { code: order };
            break;
          case 'name':
            sortObj = { name: order };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = { createdAt: -1 };
    }

    const result: any = await this.attributeGroupModel
      .aggregate()
      .match(filterObj)
      .sort(sortObj)
      .skip(skip)
      .limit(take)
      .exec();
    const count = await this.attributeGroupModel
      .find({
        ...filterObj,
      })
      .countDocuments()
      .exec();
    return {
      data: result,
      count,
    };
  }
}
