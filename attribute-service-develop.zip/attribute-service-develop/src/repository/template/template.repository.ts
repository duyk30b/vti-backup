import { CreateTemplateRequestDto } from '@components/template/dto/request/template/create-template.request.dto';
import { GetListTemPlateRequestDto } from '@components/template/dto/request/template/get-list-template.request.dto';
import { TemplateRepositoryInterface } from '@components/template/interfaces/template.repository.interface';
import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { InjectModel } from '@nestjs/mongoose';
import { getRegexByValue } from '@utils/common';
import { isEmpty } from 'lodash';
import { Model } from 'mongoose';
import { Template } from 'src/models/templates/template.schema';
import * as moment from 'moment';

export class TemplateRepository
  extends BaseAbstractRepository<Template>
  implements TemplateRepositoryInterface
{
  constructor(
    @InjectModel('Template')
    private readonly templateModel: Model<Template>,
  ) {
    super(templateModel);
  }

  createEntity(request: CreateTemplateRequestDto): Template {
    const templateDocument = new this.templateModel();
    templateDocument.code = request.code;
    templateDocument.name = request.name;
    templateDocument.description = request.description;
    templateDocument.parentTemplateAttribute = request.parentTemplateAttribute;
    templateDocument.attributes = request.attributes;
    return templateDocument;
  }

  updateEntity(entity: Template, request: any): Template {
    entity.code = request.code;
    entity.name = request.name;
    entity.parentTemplateAttribute = request.parentTemplateAttribute;
    entity.description = request.description;
    entity.attributes = request.attributes;
    return entity;
  }

  async list(request: GetListTemPlateRequestDto): Promise<any> {
    const { keyword, sort, filter, take, skip } = request;
    let filterObj = {};
    let sortObj = {};

    if (!isEmpty(keyword)) {
      filterObj = {
        $or: [
          { code: { $regex: '.*' + keyword + '.*', $options: 'i' } },
          { name: getRegexByValue(keyword) },
        ],
      };
    }
    if (!isEmpty(filter)) {
      filter.forEach((item) => {
        const value = item ? item.text : null;
        switch (item.column) {
          case 'code':
            filterObj = {
              ...filterObj,
              code: {
                $regex: `.*${value}.*`,
                $options: 'i',
              },
            };
            break;
          case 'name':
            filterObj = {
              ...filterObj,
              name: getRegexByValue(value),
            };
            break;
          case 'parentTemplateAttribute':
            filterObj = {
              ...filterObj,
              parentTemplateAttribute: parseInt(value),
            };
            break;
          case 'active':
            filterObj = {
              ...filterObj,
              active: {
                $in: value?.split(',')?.map((e) => +e) || [],
              },
            };
          case 'status':
            filterObj = {
              ...filterObj,
              status: {
                $in: value?.split(',')?.map((e) => +e) || [],
              },
            };
            break;
          case 'createdAt':
            filterObj = {
              ...filterObj,
              createdAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'updatedAt':
            filterObj = {
              ...filterObj,
              updatedAt: {
                $gte: moment(item.text.split('|')[0]).startOf('day').toDate(),
                $lte: moment(item.text.split('|')[1]).endOf('day').toDate(),
              },
            };
            break;
          case 'type':
            filterObj = {
              ...filterObj,
              type: parseInt(value),
            };
            break;
          default:
            break;
        }
      });
    }
    if (!isEmpty(sort)) {
      sort.forEach((item) => {
        const order = item.order == 'DESC' ? -1 : 1;
        switch (item.column) {
          case 'code':
            sortObj = { code: order };
            break;
          case 'name':
            sortObj = { name: order };
            break;
          case 'parentTemplateAttribute':
            sortObj = { parentTemplateAttribute: order };
            break;
          case 'status':
            sortObj = { status: order };
            break;
          case 'active':
            sortObj = { active: order };
            break;
          default:
            break;
        }
      });
    } else {
      sortObj = { createdAt: -1 };
    }

    const result: any = await this.templateModel
      .aggregate()
      .match(filterObj)
      .sort(sortObj)
      .skip(skip)
      .limit(take)
      .exec();
    const count = await this.templateModel
      .find({
        ...filterObj,
      })
      .countDocuments()
      .exec();
    return {
      data: result,
      count,
    };
  }
}
