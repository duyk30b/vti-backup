import { ACTIVE_ENUM, DEFAULT_COLLATION, STATUS_ENUM } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

@Schema({
  timestamps: true,
  collection: 'tables',
  collation: DEFAULT_COLLATION,
})
export class Table extends BaseModel {
  @Prop({
    type: String,
    required: false,
  })
  code: string;

  @Prop({
    type: String,
    required: false,
  })
  name: string;

  @Prop({
    type: String,
    required: false,
  })
  prefixService: string;

  @Prop({
    type: String,
    required: false,
  })
  prefixEndPointService: string;

  @Prop({
    type: String,
    required: false,
  })
  prefixController: string;

  @Prop({
    type: String,
    required: false,
  })
  uri: string;

  @Prop({
    type: String,
    required: false,
  })
  description: string;

  @Prop({
    type: Number,
    enum: ACTIVE_ENUM,
    required: false,
    default: ACTIVE_ENUM.ACTIVE,
  })
  active: number;

  @Prop({
    type: Number,
    enum: STATUS_ENUM,
    required: false,
    default: STATUS_ENUM.WAITING_CONFIRM,
  })
  status: number;
}
export const TableSchema = SchemaFactory.createForClass(Table);
