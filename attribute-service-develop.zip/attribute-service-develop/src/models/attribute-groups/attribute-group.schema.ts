import { ACTIVE_ENUM, DEFAULT_COLLATION, STATUS_ENUM } from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
@Schema({
  timestamps: true,
  collection: 'attributeGroups',
  collation: DEFAULT_COLLATION,
})
export class AttributeGroup extends BaseModel {
  @Prop({
    type: String,
    required: false,
  })
  code: string;

  @Prop({
    type: String,
    required: false,
  })
  name: string;

  @Prop({
    type: String,
    required: false,
  })
  description: string;

  @Prop({
    type: Number,
    required: false,
  })
  order: number;

  @Prop({
    type: Number,
    enum: ACTIVE_ENUM,
    required: false,
    default: ACTIVE_ENUM.ACTIVE,
  })
  active: number;

  @Prop({
    type: Number,
    enum: STATUS_ENUM,
    required: false,
    default: STATUS_ENUM.WAITING_CONFIRM,
  })
  status: number;
}

export const AttributeGroupSchema =
  SchemaFactory.createForClass(AttributeGroup);
