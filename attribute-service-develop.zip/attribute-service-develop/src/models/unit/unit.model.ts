import { BaseModel } from '@core/model/base.model';

export interface Unit extends BaseModel {
  code: string;
  name: string;
  description: string;
  active: number;
}
