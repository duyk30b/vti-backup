import { Attribute } from './../attributes/attribute.schema';
import {
  AREA_ENUM_TEMPLATE,
  ACTIVE_ENUM,
  DEFAULT_COLLATION,
  TEMPLATE_PARENT_ENUM,
  STATUS_ENUM,
  REQUIRED_ENUM,
  DISABLE_ENUM,
} from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import * as mongoose from 'mongoose';
import { AttributeGroup } from '../attribute-groups/attribute-group.schema';
import { Table } from '../tables/table.shcema';
import { TemplateTypeEnum } from '@utils/template/general-template';
@Schema()
class AttributeRule {
  @Prop({
    type: mongoose.SchemaTypes.Mixed,
    required: false,
  })
  min: any;

  @Prop({
    type: mongoose.SchemaTypes.Mixed,
    required: false,
  })
  max: any;

  @Prop({
    type: mongoose.SchemaTypes.Mixed,
    required: false,
  })
  defaultValue: any;

  @Prop({
    type: mongoose.SchemaTypes.Mixed,
    required: false,
  })
  label: any;

  @Prop({
    type: mongoose.SchemaTypes.Mixed,
    required: false,
  })
  subLabel: any;

  @Prop({
    type: Number,
    enum: REQUIRED_ENUM,
    required: false,
  })
  isRequired: number;

  @Prop({
    type: Number,
    required: false,
  })
  canUpdate: number;

  @Prop({
    type: Number,
    required: false,
  })
  display: number;

  @Prop({
    type: mongoose.SchemaTypes.Mixed,
    required: false,
  })
  dataSource: any;

  @Prop({
    type: mongoose.SchemaTypes.Mixed,
    required: false,
  })
  fieldDataSource: any;

  @Prop({
    type: String,
    required: false,
  })
  dataRefEndpoint: string;

  @Prop({
    type: String,
    required: false,
  })
  autoGenCode: string;

  @Prop({
    type: String,
    required: false,
  })
  regex: string;

  @Prop({
    type: String,
    required: false,
  })
  description: string;

  @Prop({
    type: Number,
    enum: ACTIVE_ENUM,
    required: false,
    default: ACTIVE_ENUM.ACTIVE,
  })
  active: number;
  @Prop({
    type: Number,
    enum: STATUS_ENUM,
    required: false,
    default: STATUS_ENUM.WAITING_CONFIRM,
  })
  status: number;

  table?: Table;

  @Prop({
    type: Number,
    enum: DISABLE_ENUM,
    required: false,
    default: DISABLE_ENUM.EDITABLE,
  })
  disabled: number;
}
@Schema()
class AttributeTemplate {
  @Prop({
    type: SchemaFactory.createForClass(AttributeRule),
    require: false,
  })
  attributeRule: AttributeRule;

  @Prop({
    type: Number,
    enum: AREA_ENUM_TEMPLATE,
    required: true,
  })
  area: number;

  @Prop({
    type: mongoose.Schema.Types.ObjectId,
    required: false,
    ref: 'AttributeGroup',
  })
  groupId: string;

  @Prop({
    type: Number,
    required: false,
  })
  order: number;

  @Prop({
    type: mongoose.Schema.Types.ObjectId,
    required: false,
    ref: 'Attribute',
  })
  attributeId: string;

  @Prop({
    type: String,
    required: false,
  })
  attributeCode?: string;
}
@Schema({
  timestamps: true,
  collection: 'templates',
  collation: DEFAULT_COLLATION,
})
export class Template extends BaseModel {
  @Prop({
    type: String,
    required: true,
  })
  code: string;

  @Prop({
    type: String,
    required: true,
  })
  name: string;

  @Prop({
    type: Number,
    enum: TemplateTypeEnum,
    required: false,
  })
  type: number;

  @Prop({
    type: String,
    required: false,
  })
  description: string;

  @Prop({
    type: Number,
    enum: TEMPLATE_PARENT_ENUM,
    required: false,
  })
  parentTemplateAttribute: number;

  @Prop({
    type: Number,
    enum: ACTIVE_ENUM,
    required: false,
    default: ACTIVE_ENUM.ACTIVE,
  })
  active: number;

  @Prop({
    type: Number,
    enum: STATUS_ENUM,
    required: false,
    default: STATUS_ENUM.WAITING_CONFIRM,
  })
  status: number;

  @Prop({
    type: [SchemaFactory.createForClass(AttributeTemplate)],
    require: true,
  })
  attributes: AttributeTemplate[];
}

export const TemplateSchema = SchemaFactory.createForClass(Template);
TemplateSchema.virtual('attributes.attributeGroup', {
  ref: AttributeGroup.name,
  localField: 'attributes.groupId',
  foreignField: '_id',
  justOne: true,
});

TemplateSchema.virtual('attributes.attribute', {
  ref: Attribute.name,
  localField: 'attributes.attributeId',
  foreignField: '_id',
  justOne: true,
});
