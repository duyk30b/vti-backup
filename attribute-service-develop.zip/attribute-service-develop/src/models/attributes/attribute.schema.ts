import {
  ACTIVE_ENUM,
  DATA_TYPE_ENUM,
  DEFAULT_COLLATION,
  FIXED_ENUM_WITH_PARENT,
  MODULE_ENUM,
  STATUS_ENUM,
} from '@constant/common';
import { BaseModel } from '@core/model/base.model';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

@Schema({
  timestamps: true,
  collection: 'attributes',
  collation: DEFAULT_COLLATION,
})
export class Attribute extends BaseModel {
  @Prop({
    type: String,
    required: false,
  })
  code: string;

  @Prop({
    type: String,
    required: false,
  })
  name: string;

  @Prop({
    type: Number,
    enum: ACTIVE_ENUM,
    required: false,
    default: ACTIVE_ENUM.ACTIVE,
  })
  active: number;

  @Prop({
    type: Number,
    enum: DATA_TYPE_ENUM,
    required: false,
  })
  dataType: number;

  @Prop({
    type: Number,
    enum: MODULE_ENUM,
    required: false,
  })
  module: number;

  @Prop({
    type: Number,
    enum: STATUS_ENUM,
    required: false,
    default: STATUS_ENUM.WAITING_CONFIRM,
  })
  status: number;
}

export const AttributeSchema = SchemaFactory.createForClass(Attribute);
