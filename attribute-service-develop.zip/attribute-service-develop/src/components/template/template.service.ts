import {
  CAN_UPDATE_TEMPLATE,
  VALID_DEFAULT_TYPE_FOR_PARENT_IMPORT,
  CAN_NOT_DELETE_TEMPLATE,
} from './template.constants';
import { AttributeGroupRepositoryInterface } from '@components/attribute-group/interfaces/attribute-group.repository.interface';
import { AttributeRepositoryInterface } from '@components/attribute/interfaces/attribute.repository.interface';
import { STATUS_ENUM } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import {
  groupBy,
  isEmpty,
  map,
  orderBy,
  first,
  compact,
  flatMap,
  keyBy,
} from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { CreateTemplateRequestDto } from './dto/request/template/create-template.request.dto';
import { TemplateRepositoryInterface } from './interfaces/template.repository.interface';
import { TemplateServiceInterface } from './interfaces/template.service.interface';
import { plainToInstance } from 'class-transformer';
import { TemplateResponseDto } from './dto/response/template.response.dto';
import { UpdateTemplateRequestDto } from './dto/request/template/update-template.request.dto';
import { ApiError } from '@utils/api.error';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { GetDetailTemplateRequestDto } from './dto/request/template/get-detail-template.request.dto';
import { GetListTemPlateRequestDto } from './dto/request/template/get-list-template.request.dto';
import { TableRepositoryInterface } from '@components/tables/interfaces/table.repository.interface';
import * as mongoose from 'mongoose';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { GetTemplateByCodeRequestDto } from './dto/request/template/get-template-by-code.request.dto';
import { GetTemplateByIdRequestDto } from './dto/request/template/get-template-by-id.request.dto';
import { GetTemplatesByIdsRequestDto } from './dto/request/template/get-templates-by-ids.request.dto';
const ObjectId = mongoose.Types.ObjectId;

@Injectable()
export class TemplateService implements TemplateServiceInterface {
  constructor(
    @Inject('TemplateRepositoryInterface')
    private readonly templateRepository: TemplateRepositoryInterface,

    @Inject('AttributeRepositoryInterface')
    private readonly attributeRepository: AttributeRepositoryInterface,

    @Inject('AttributeGroupRepositoryInterface')
    private readonly attributeGroupRepository: AttributeGroupRepositoryInterface,

    @Inject('TableRepositoryInterface')
    private readonly tableRepository: TableRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateTemplateRequestDto): Promise<any> {
    const { code, attributes } = request;
    const checkExistedCode = await this.templateRepository.findOneByCondition({
      code: code,
    });
    if (checkExistedCode) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('message.defineTemplate.codeAlreadyExists'),
        )
        .build();
    }
    //validate attributeId and groupId
    const groupIds = compact(map(attributes, 'groupId'));
    const attributeIds = compact(map(attributes, 'attributeId'));
    if (!isEmpty(attributeIds)) {
      const attributeRes = await this.attributeRepository.findAllByCondition({
        _id: { $in: attributeIds },
      });
      if (isEmpty(attributeRes)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }
    }
    if (!isEmpty(groupIds)) {
      const attributeGroups =
        await this.attributeGroupRepository.findAllByCondition({
          _id: { $in: groupIds },
        });
      if (isEmpty(attributeGroups)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }
    }
    const attributeDataSourceRequest = flatMap(
      map(attributes, 'attributeRule'),
      'dataSource',
    );
    const attributeDataSoureceIds = attributeDataSourceRequest.filter((e) =>
      ObjectId.isValid(e),
    );
    if (!isEmpty(attributeDataSoureceIds)) {
      const tableResponse = await this.tableRepository.findAllByCondition({
        _id: { $in: attributeDataSoureceIds },
      });
      if (isEmpty(tableResponse)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();
      }
    }
    const templateDocument = await this.templateRepository.createEntity(
      request,
    );
    const dataSave = await templateDocument.save();
    const dataReturn = plainToInstance(TemplateResponseDto, dataSave, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async update(request: UpdateTemplateRequestDto): Promise<any> {
    try {
      const { id } = request;
      let template = await this.templateRepository.findOneById(id);
      if (!template) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      template = this.templateRepository.updateEntity(template, request);
      if (template.status === STATUS_ENUM.REJECT) {
        template.status = STATUS_ENUM.WAITING_CONFIRM;
      }
      const dataSave = await this.templateRepository.findByIdAndUpdate(
        id,
        template,
      );
      const dataReturn = plainToInstance(TemplateResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async updateActiveStatus(request: UpdateActiveStatusPayload): Promise<any> {
    const { id, status } = request;
    const template = await this.templateRepository.findOneById(id);
    if (!template) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    await this.templateRepository.findByIdAndUpdate(id, {
      $set: { active: status },
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
  async updateStatus(request: UpdateActiveStatusPayload): Promise<any> {
    const { id, status } = request;
    const template = await this.templateRepository.findOneById(id);
    if (!template) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    const dataSave = await this.templateRepository.findByIdAndUpdate(id, {
      $set: { status: status },
    });
    return new ResponseBuilder(dataSave)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
  async detail(request: GetDetailTemplateRequestDto): Promise<any> {
    const { id } = request;
    const template = await this.templateRepository.findOneWithPopulate(
      { _id: id },
      'attributes.attributeGroup attributes.attribute',
    );
    if (!template) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const attributeGroups = [];
    let attributeHeaders = [];
    const attributeGroupBy = groupBy(
      template.attributes,
      (e) => e.groupId ?? '',
    );
    Object.entries(attributeGroupBy).forEach(([key, value]) => {
      const attributeOrders = orderBy(value, ['order'], ['asc']);
      if (!key) {
        attributeHeaders = attributeOrders;
      } else {
        attributeGroups.push({
          ...first(attributeOrders)?.['attributeGroup'],
          attributes: attributeOrders,
        });
      }
    });
    const attributeDataSourceRequest = flatMap(
      map(template.attributes, 'attributeRule'),
      'dataSource',
    );
    const attributeRule = map(template.attributes, 'attributeRule');
    const attributeDataSoureceIds = attributeDataSourceRequest.filter((e) =>
      ObjectId.isValid(e),
    );
    if (!isEmpty(attributeDataSoureceIds)) {
      const tableResponse = await this.tableRepository.findAllByCondition({
        _id: { $in: attributeDataSoureceIds },
      });
      const tableResKeyBy = keyBy(tableResponse, '_id');
      attributeRule.map((itemRule) => {
        itemRule.dataSource
          .filter((e) => ObjectId.isValid(e))
          .forEach((itemSource) => {
            const key = itemSource;
            itemRule.table = tableResKeyBy[key];
          });
      });
    }

    const dataReturn = {
      ...template,
      attributeGroups: orderBy(attributeGroups, ['order'], ['asc']),
      attributeHeaders: orderBy(attributeHeaders, ['order'], ['asc']),
    };
    const result = plainToInstance(TemplateResponseDto, dataReturn, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async list(request: GetListTemPlateRequestDto): Promise<any> {
    const { data, count } = await this.templateRepository.list(request);
    const dataReturn = plainToInstance(TemplateResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
  private async validateTypeTemplateWithImport(type?: number): Promise<any> {
    const validType = !VALID_DEFAULT_TYPE_FOR_PARENT_IMPORT.includes(type);
    if (validType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.INVALID_TYPE_WITH_IMPORT_PARENT'),
        );
    }
  }
  private async validateTypeTemplateWithExport(type?: number): Promise<any> {
    const validType = !VALID_DEFAULT_TYPE_FOR_PARENT_IMPORT.includes(type);
    if (validType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.INVALID_TYPE_WITH_EXPORT_PARENT'),
        );
    }
  }
  private async validateTypeTemplateWithTransfer(type?: number): Promise<any> {
    const validType = !VALID_DEFAULT_TYPE_FOR_PARENT_IMPORT.includes(type);
    if (validType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.INVALID_TYPE_WITH_TRANSFER_PARENT'),
        );
    }
  }

  async delete(request: IdParamMongoDto): Promise<any> {
    const { id } = request;
    const template = await this.templateRepository.findOneById(id);
    if (!template) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }
    if (!CAN_UPDATE_TEMPLATE.includes(template.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('message.defineTemplate.statusInValid'),
        )
        .build();
    }
    if (CAN_NOT_DELETE_TEMPLATE.includes(template.code)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE_TEMPLATE'))
        .build();
    }
    await this.templateRepository.deleteById(id);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getTemplateByCode(request: GetTemplateByCodeRequestDto): Promise<any> {
    const { code } = request;
    const template = await this.templateRepository.findOneWithPopulate(
      { code: code },
      'attributes.attributeGroup attributes.attribute',
    );
    if (!template) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const attributeGroups = [];
    let attributeHeaders = [];
    const attributeGroupBy = groupBy(
      template.attributes,
      (e) => e.groupId ?? '',
    );
    Object.entries(attributeGroupBy).forEach(([key, value]) => {
      const attributeOrders = orderBy(value, ['order'], ['asc']);
      if (!key) {
        attributeHeaders = attributeOrders;
      } else {
        attributeGroups.push({
          ...first(attributeOrders)?.['attributeGroup'],
          attributes: attributeOrders,
        });
      }
    });
    const attributeDataSourceRequest = flatMap(
      map(template.attributes, 'attributeRule'),
      'dataSource',
    );
    const attributeRule = map(template.attributes, 'attributeRule');
    const attributeDataSoureceIds = attributeDataSourceRequest.filter((e) =>
      ObjectId.isValid(e),
    );
    if (!isEmpty(attributeDataSoureceIds)) {
      const tableResponse = await this.tableRepository.findAllByCondition({
        _id: { $in: attributeDataSoureceIds },
      });
      const tableResKeyBy = keyBy(tableResponse, '_id');
      attributeRule.map((itemRule) => {
        itemRule.dataSource
          .filter((e) => ObjectId.isValid(e))
          .forEach((itemSource) => {
            const key = itemSource;
            itemRule.table = tableResKeyBy[key];
          });
      });
    }

    const dataReturn = {
      ...template,
      attributeGroups: orderBy(attributeGroups, ['order'], ['asc']),
      attributeHeaders: orderBy(attributeHeaders, ['order'], ['asc']),
    };
    const result = plainToInstance(TemplateResponseDto, dataReturn, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getTemplateById(request: GetTemplateByIdRequestDto): Promise<any> {
    const { id } = request;
    const template = await this.templateRepository.findOneWithPopulate(
      { _id: id },
      'attributes.attributeGroup attributes.attribute',
    );
    if (!template) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    return new ResponseBuilder(template)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getTemplatesByIds(request: GetTemplatesByIdsRequestDto): Promise<any> {
    const { ids } = request;
    const templates = await this.templateRepository.findAllByCondition({
      _id: { $in: ids },
    });

    return new ResponseBuilder(templates)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
