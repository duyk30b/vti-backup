import { NATS_ATTRIBUTE } from './../../config/nats.config';
import { ACTIVE_ENUM, STATUS_ENUM } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import {
  CREATE_TEMPLATE_PERMISSION,
  UPDATE_TEMPLATE_PERMISSION,
  DETAIL_TEMPLATE_PERMISSION,
  LIST_TEMPLATE_PERMISSION,
  DELETE_TEMPLATE_PERMISSION,
  CONFIRM_TEMPLATE_PERMISSION,
  REJECT_TEMPLATE_PERMISSION,
  ACTIVE_TEMPLATE_PERMISSION,
  INACTIVE_TEMPLATE_PERMISSION,
} from '@utils/permissions/template.permission';
import { ResponseBuilder } from '@utils/response-builder';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateTemplateRequestDto } from './dto/request/template/create-template.request.dto';
import { GetDetailTemplateRequestDto } from './dto/request/template/get-detail-template.request.dto';
import { GetListTemPlateRequestDto } from './dto/request/template/get-list-template.request.dto';
import { GetTemplateByCodeRequestDto } from './dto/request/template/get-template-by-code.request.dto';
import { GetTemplateByIdRequestDto } from './dto/request/template/get-template-by-id.request.dto';
import { UpdateTemplateBodyDto } from './dto/request/template/update-template.request.dto';
import { ListTemplateResponseDto } from './dto/response/list-template.response.dto';
import { TemplateResponseDto } from './dto/response/template.response.dto';
import { TemplateServiceInterface } from './interfaces/template.service.interface';
import { GetTemplatesByIdsRequestDto } from './dto/request/template/get-templates-by-ids.request.dto';

@Controller('templates')
export class TemplateConstroller {
  constructor(
    @Inject('TemplateServiceInterface')
    private readonly templateService: TemplateServiceInterface,
  ) {}

  @PermissionCode(CREATE_TEMPLATE_PERMISSION.code)
  @Post('/')
  async create(@Body() payload: CreateTemplateRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.templateService.create(request);
  }

  @PermissionCode(UPDATE_TEMPLATE_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Template'],
    summary: 'Cập nhật template',
    description: 'Cập nhật template',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async update(
    @Param() param: IdParamMongoDto,
    @Body() payload: UpdateTemplateBodyDto,
  ): Promise<any> {
    const { request: requestParam, responseError: responseParamError } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.templateService.update({
      id: requestParam.id,
      ...request,
    });
  }

  // @PermissionCode(DETAIL_TEMPLATE_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Attribute Group'],
    summary: 'Chi tiết nhóm thuộc tính',
    description: 'Chi tiết nhóm thuộc tính',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: TemplateResponseDto,
  })
  async detail(@Param() param: GetDetailTemplateRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.templateService.detail(request);
  }

  // @PermissionCode(LIST_TEMPLATE_PERMISSION.code)
  @Get('')
  @ApiOperation({
    tags: ['Template'],
    summary: 'Danh sách template',
    description: 'Danh sách template',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListTemplateResponseDto,
  })
  async list(@Query() query: GetListTemPlateRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.templateService.list(request);
  }

  @PermissionCode(ACTIVE_TEMPLATE_PERMISSION.code)
  @Put('/:id/active')
  @ApiOperation({
    tags: ['Template'],
    summary: 'Active Template',
    description: 'Active Template',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async active(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.templateService.updateActiveStatus({
      ...request,
      status: ACTIVE_ENUM.ACTIVE,
    });
  }

  @PermissionCode(INACTIVE_TEMPLATE_PERMISSION.code)
  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Template'],
    summary: 'Inactive Template',
    description: 'Inactive Template',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async inactive(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.templateService.updateActiveStatus({
      ...request,
      status: ACTIVE_ENUM.INACTIVE,
    });
  }

  @PermissionCode(CONFIRM_TEMPLATE_PERMISSION.code)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Template'],
    summary: 'Active Template',
    description: 'Active Template',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async confirm(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.templateService.updateStatus({
      ...request,
      status: STATUS_ENUM.CONFIRM,
    });
  }
  @PermissionCode(REJECT_TEMPLATE_PERMISSION.code)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Template'],
    summary: 'Inactive Template',
    description: 'Inactive Template',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async reject(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.templateService.updateStatus({
      ...request,
      status: STATUS_ENUM.REJECT,
    });
  }

  @PermissionCode(DELETE_TEMPLATE_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['template'],
    summary: 'Delete template',
    description: 'Delete template',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async delete(@Param() Param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = Param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.templateService.delete(request);
  }

  @Get('/code/:code')
  public async getTemplateByCode(
    @Param() param: GetTemplateByCodeRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.templateService.getTemplateByCode(request);
  }
  @MessagePattern(`${NATS_ATTRIBUTE}.get_templates_by_code`)
  public async getTemplateByCodeTcp(
    @Body() body: GetTemplateByCodeRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.templateService.getTemplateByCode(request);
  }

  @MessagePattern(`${NATS_ATTRIBUTE}.get_template_by_id`)
  public async getTemplateByIdTcp(
    @Body() body: GetTemplateByIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.templateService.getTemplateById(request);
  }

  @MessagePattern(`${NATS_ATTRIBUTE}.get_templates_by_ids`)
  public async getTemplatesByIds(
    @Body() body: GetTemplatesByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.templateService.getTemplatesByIds(request);
  }
}
