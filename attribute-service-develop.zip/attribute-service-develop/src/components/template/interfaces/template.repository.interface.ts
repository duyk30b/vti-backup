import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { Template } from 'src/models/templates/template.schema';
import { CreateTemplateRequestDto } from '../dto/request/template/create-template.request.dto';
import { GetListTemPlateRequestDto } from '../dto/request/template/get-list-template.request.dto';
import { UpdateTemplateBodyDto } from '../dto/request/template/update-template.request.dto';

export interface TemplateRepositoryInterface
  extends BaseInterfaceRepository<Template> {
  createEntity(request: CreateTemplateRequestDto): Template;
  updateEntity(entity: Template, request: any): Template;
  list(request: GetListTemPlateRequestDto): Promise<any>;
}
