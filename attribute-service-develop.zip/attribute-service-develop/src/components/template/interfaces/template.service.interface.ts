import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { CreateTemplateRequestDto } from '../dto/request/template/create-template.request.dto';
import { GetDetailTemplateRequestDto } from '../dto/request/template/get-detail-template.request.dto';
import { GetListTemPlateRequestDto } from '../dto/request/template/get-list-template.request.dto';
import { GetTemplateByCodeRequestDto } from '../dto/request/template/get-template-by-code.request.dto';
import { GetTemplateByIdRequestDto } from '../dto/request/template/get-template-by-id.request.dto';
import { UpdateTemplateRequestDto } from '../dto/request/template/update-template.request.dto';
import { GetTemplatesByIdsRequestDto } from '../dto/request/template/get-templates-by-ids.request.dto';

export interface TemplateServiceInterface {
  create(request: CreateTemplateRequestDto): Promise<any>;
  update(request: UpdateTemplateRequestDto): Promise<any>;
  updateStatus(request: UpdateActiveStatusPayload): Promise<any>;
  updateActiveStatus(request: UpdateActiveStatusPayload): Promise<any>;
  detail(request: GetDetailTemplateRequestDto): Promise<any>;
  list(request: GetListTemPlateRequestDto): Promise<any>;
  delete(request: IdParamMongoDto): Promise<any>;
  getTemplateByCode(request: GetTemplateByCodeRequestDto): Promise<any>;
  getTemplateById(request: GetTemplateByIdRequestDto): Promise<any>;
  getTemplatesByIds(request: GetTemplatesByIdsRequestDto): Promise<any>;
}
