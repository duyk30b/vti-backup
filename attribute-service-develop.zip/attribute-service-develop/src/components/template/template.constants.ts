import { CODE_REGEX, STATUS_ENUM } from '@constant/common';
export enum TYPE_TEMPLATE_ENUM {
  IMPORT = 0,
  EXPORT = 1,
  TRANSFER_INTERNAL = 2,
}

export const TEMPLATE_CONST = {
  DESCRIPTION: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
  CODE: {
    MAX_LENGTH: 10,
    COLUMN: 'code',
    REGEX: CODE_REGEX,
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
};

export const VALID_DEFAULT_TYPE_FOR_PARENT_IMPORT = [TYPE_TEMPLATE_ENUM.IMPORT];
export const VALID_DEFAULT_TYPE_FOR_PARENT_EXPORT = [TYPE_TEMPLATE_ENUM.EXPORT];
export const VALID_DEFAULT_TYPE_FOR_PARENT_TRANSFER = [
  TYPE_TEMPLATE_ENUM.TRANSFER_INTERNAL,
];
export enum DataSourceEnum {
  VENDOR = 'vendors',
  ORGANIZATION_PAYMENT = 'organization_payments',
  SALE_ORDER_EXPORT = 'sale_order_exports',
  PURCHASED_ORDER_IMPORT = 'purchased_order_imports',
  WAREHOUSE_EXPORT_PROPOSAL = 'warehouse_export_proposals',
  CONSTRUCTION = 'constructions',
  CATEGORY_CONSTRUCTION = 'category_constructions',
  RECEIP = 'receipts',
  COST_TYPE = 'cost_types',
  ITEM = 'items',
  ITEM_DETAIL = 'item_details',
}
export const DATA_SOURCE_SELECT = [
  DataSourceEnum.VENDOR,
  DataSourceEnum.COST_TYPE,
  DataSourceEnum.CATEGORY_CONSTRUCTION,
  DataSourceEnum.ORGANIZATION_PAYMENT,
  DataSourceEnum.RECEIP,
  DataSourceEnum.SALE_ORDER_EXPORT,
  DataSourceEnum.PURCHASED_ORDER_IMPORT,
  DataSourceEnum.ITEM,
  DataSourceEnum.ITEM_DETAIL,
];
export const TEMPLATE_ATTRIBUTE_API_PATH = {
  [DataSourceEnum.VENDOR]: '/api/v1/sales/vendors/list',
  [DataSourceEnum.COST_TYPE]: '/api/v1/sales/cost-types/list',
  [DataSourceEnum.ORGANIZATION_PAYMENT]:
    '/api/v1/sales/organization-payments/list',
  [DataSourceEnum.SALE_ORDER_EXPORT]: '/api/v1/sales/sale-order-exports/list',
  [DataSourceEnum.PURCHASED_ORDER_IMPORT]:
    '/api/v1/sales/purchased-order-imports/list',
  [DataSourceEnum.WAREHOUSE_EXPORT_PROPOSAL]:
    '/api/v1/warehouses/warehouse-export-proposals/list',
  [DataSourceEnum.CONSTRUCTION]: '/api/v1/sales/constructions/list',
  [DataSourceEnum.CATEGORY_CONSTRUCTION]:
    '/api/v1/sales/construction-categories/list',
  [DataSourceEnum.RECEIP]: '/api/v1/sales/receipts/list',
};
export const REGEX_CHECK_MONGO_ID = /^[0-9a-fA-F]{24}$/;
export enum CodeMapRequestAttribute {
  ITEM_ID = 'itemId',
  REQUEST_USER_ID = 'requestUserId',
  BOM_VERSION = 'bomVersion',
}
export const CODE_MAP_ATTRIBUTE_REQUEST = [
  CodeMapRequestAttribute.BOM_VERSION,
  CodeMapRequestAttribute.ITEM_ID,
  CodeMapRequestAttribute.REQUEST_USER_ID,
];
export const CAN_UPDATE_TEMPLATE = [
  STATUS_ENUM.REJECT,
  STATUS_ENUM.WAITING_CONFIRM,
];
export const TemplateWmsx = {
  WMSX_YCN: 'WMSX_YCN',
  WMSX_YCX: 'WMSX_YCX',
  WMSX_YCC: 'WMSX_YCC',
};
export const TemplateMesx = {
  MESX_YCSX: 'MANUFACTURING_REQUEST_ORDER',
};
export const CAN_NOT_DELETE_TEMPLATE = [
  TemplateWmsx.WMSX_YCC,
  TemplateWmsx.WMSX_YCN,
  TemplateWmsx.WMSX_YCX,
  TemplateMesx.MESX_YCSX,
];
