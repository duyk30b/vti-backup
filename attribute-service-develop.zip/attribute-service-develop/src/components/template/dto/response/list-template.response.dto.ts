import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';
import { TemplateResponseDto } from './template.response.dto';

export class ListTemplateResponseDto extends PaginationResponse {
  @ApiProperty({ type: TemplateResponseDto, isArray: true })
  @Type(() => TemplateResponseDto)
  @Expose()
  items: TemplateResponseDto[];
}
