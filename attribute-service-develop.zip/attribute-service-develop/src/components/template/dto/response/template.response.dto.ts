import { AttributeGroupResponseDto } from '@components/attribute-group/dto/response/attribute-group.response.dto';
import { AttributeResponseDto } from '@components/attribute/dto/response/attribute.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { AttributeRuleResponseDto } from './attribute-rule.response.dto';

export class AttributeResponse extends BaseResponseDto {
  @Expose()
  order: number;

  @Expose()
  @ApiProperty({ type: AttributeRuleResponseDto, isArray: false })
  @Type(() => AttributeRuleResponseDto)
  attributeRule: AttributeRuleResponseDto;

  @Expose()
  @ApiProperty({ type: AttributeResponseDto, isArray: false })
  @Type(() => AttributeResponseDto)
  attribute: AttributeResponseDto;

  @Expose()
  @ApiProperty({ type: AttributeGroupResponseDto, isArray: false })
  @Type(() => AttributeGroupResponseDto)
  attributeGroup: AttributeGroupResponseDto;
}
export class FormGroup extends BaseResponseDto {
  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  order: number;

  @Expose()
  description: string;

  @Expose()
  active: number;

  @Expose()
  status: number;

  @ApiProperty({ type: AttributeResponse, isArray: true })
  @Type(() => AttributeResponse)
  @Expose()
  attributes: AttributeResponse[];
}
export class TemplateResponseDto extends BaseResponseDto {
  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  type: number;

  @Expose()
  description: string;

  @Expose()
  parentTemplateAttribute: number;

  @Expose()
  order: number;

  @Expose()
  status: number;

  @Expose()
  active: number;

  @ApiProperty({ type: AttributeResponse, isArray: true })
  @Type(() => AttributeResponse)
  @Expose()
  attributes: AttributeResponse[];

  @ApiProperty({ type: FormGroup, isArray: true })
  @Type(() => FormGroup)
  @Expose()
  attributeGroups: FormGroup[];

  @ApiProperty({ type: AttributeResponse, isArray: true })
  @Type(() => AttributeResponse)
  @Expose()
  attributeHeaders: AttributeResponse[];
}
