import { TableResponseDto } from '@components/tables/dto/response/table.response.dto';
import { BaseResponseDto } from '@core/dto/base.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

export class AttributeRuleResponseDto extends BaseResponseDto {
  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  dataSource: any;

  @Expose()
  fieldDataSource: any;

  @Expose()
  @ApiProperty({ type: TableResponseDto, isArray: false })
  @Type(() => TableResponseDto)
  table: TableResponseDto;

  @Expose()
  min: any;

  @Expose()
  max: any;

  @Expose()
  label: any;

  @Expose()
  subLabel: any;

  @Expose()
  defaultValue: any;

  @Expose()
  isRequired: number;

  @Expose()
  canUpdate: number;

  @Expose()
  display: number;

  @Expose()
  dataRefEndpoint: string;

  @Expose()
  autoGenCode: string;

  @Expose()
  description: string;

  @Expose()
  regex: string;

  @Expose()
  active: number;

  @Expose()
  status: number;

  @Expose()
  attributeId: number;

  @Expose()
  disabled: number;
}
