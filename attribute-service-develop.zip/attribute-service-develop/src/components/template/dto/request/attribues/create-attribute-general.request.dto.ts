import { IsString, IsEnum, IsOptional, IsInt } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  DATA_TYPE_ENUM,
  DISPLAY_ENUM,
  REQUIRED_ENUM,
  UPDATE_ENUM,
} from '@constant/common';
export class CreateAttributeRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  code: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  name: string;

  @ApiProperty()
  @IsEnum(DATA_TYPE_ENUM)
  dataType: DATA_TYPE_ENUM;
}

export class CreateAttributeRuleRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsOptional()
  max: any;

  @ApiPropertyOptional()
  @IsOptional()
  min: any;

  @ApiPropertyOptional()
  @IsOptional()
  defaultValue: any;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(REQUIRED_ENUM)
  isRequired: REQUIRED_ENUM;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(UPDATE_ENUM)
  canUpdate: UPDATE_ENUM;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(DISPLAY_ENUM)
  display: DISPLAY_ENUM;

  @ApiPropertyOptional()
  @IsOptional()
  dataSource: any;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  dataRefEndpoint: string;

  @ApiPropertyOptional()
  @IsOptional()
  label: any;

  @ApiPropertyOptional()
  @IsOptional()
  subLabel: any;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  autoGenCode: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  regex: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description: string;

  @ApiProperty()
  @IsOptional()
  @IsEnum(DATA_TYPE_ENUM)
  dataType: DATA_TYPE_ENUM;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  attributeId: string;
}

export class CreateAttributeGroupRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  code: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  name: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description: string;

  @ApiPropertyOptional()
  @IsOptional()
  order: number;
}
