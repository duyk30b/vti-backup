import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';

export class GetTemplatesByIdsRequestDto extends BaseDto {
  @ApiProperty()
  ids: any[];
}
