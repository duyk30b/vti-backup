import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';

export class GetTemplateByIdRequestDto extends IdParamMongoDto {}
