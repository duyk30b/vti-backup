import {
  IsInt,
  IsOptional,
  IsEnum,
  IsString,
  ValidateNested,
  ArrayNotEmpty,
  MaxLength,
} from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  AREA_ENUM_TEMPLATE,
  DATA_TYPE_ENUM,
  DISPLAY_ENUM,
  REQUIRED_ENUM,
  TEMPLATE_PARENT_ENUM,
  UPDATE_ENUM,
} from '@constant/common';
import { Type } from 'class-transformer';
import { TEMPLATE_CONST } from '@components/template/template.constants';

class AttributeRuleRequestDto {
  @ApiPropertyOptional()
  @IsOptional()
  max: any;

  @ApiPropertyOptional()
  @IsOptional()
  min: any;

  @ApiPropertyOptional()
  @IsOptional()
  defaultValue: any;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(REQUIRED_ENUM)
  isRequired: REQUIRED_ENUM;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(UPDATE_ENUM)
  canUpdate: UPDATE_ENUM;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(DISPLAY_ENUM)
  display: DISPLAY_ENUM;

  @ApiPropertyOptional()
  @IsOptional()
  dataSource: any;

  @ApiPropertyOptional()
  @IsOptional()
  fieldDataSource: any;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  dataRefEndpoint: string;

  @ApiPropertyOptional()
  @IsOptional()
  label: any;

  @ApiPropertyOptional()
  @IsOptional()
  subLabel: any;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  autoGenCode: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  regex: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description: string;

  @ApiProperty()
  @IsEnum(DATA_TYPE_ENUM)
  dataType: DATA_TYPE_ENUM;

  @ApiPropertyOptional()
  @IsOptional()
  status: number;

  @ApiPropertyOptional()
  @IsOptional()
  active: number;

  @ApiPropertyOptional()
  @IsOptional()
  disabled: number;
}

class AttributeTemplate {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  groupId: string;

  @ApiProperty({ type: AttributeRuleRequestDto, isArray: false })
  @ValidateNested({ each: true })
  @Type(() => AttributeRuleRequestDto)
  attributeRule: AttributeRuleRequestDto;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  order: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(AREA_ENUM_TEMPLATE)
  area: AREA_ENUM_TEMPLATE;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  attributeId: string;
}
export class CreateTemplateRequestDto extends BaseDto {
  @ApiProperty()
  @MaxLength(TEMPLATE_CONST.CODE.MAX_LENGTH)
  @IsString()
  code: string;

  @ApiProperty()
  @MaxLength(TEMPLATE_CONST.NAME.MAX_LENGTH)
  @IsString()
  name: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(TEMPLATE_PARENT_ENUM)
  parentTemplateAttribute: TEMPLATE_PARENT_ENUM;

  @ApiPropertyOptional()
  @IsOptional()
  @MaxLength(TEMPLATE_CONST.DESCRIPTION.MAX_LENGTH)
  @IsString()
  description: string;

  @ApiPropertyOptional({ type: AttributeTemplate, isArray: true })
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => AttributeTemplate)
  attributes: AttributeTemplate[];
}
