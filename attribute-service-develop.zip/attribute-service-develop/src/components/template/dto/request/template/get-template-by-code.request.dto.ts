import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsString } from 'class-validator';

export class GetTemplateByCodeRequestDto extends BaseDto {
  @ApiProperty()
  @IsString()
  code: string;
}
