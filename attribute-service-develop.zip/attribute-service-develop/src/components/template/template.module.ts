import { Global, Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { AttributeGroupSchema } from 'src/models/attribute-groups/attribute-group.schema';
import { AttributeSchema } from 'src/models/attributes/attribute.schema';
import { TableSchema } from 'src/models/tables/table.shcema';
import { TemplateSchema } from 'src/models/templates/template.schema';
import { TableRepository } from 'src/repository/table/table.repository';
import { AttributeGroupRepository } from 'src/repository/template/attribute-group.repository';
import { AttributeRepository } from 'src/repository/template/attribute.repository';
import { TemplateRepository } from 'src/repository/template/template.repository';
import { TemplateConstroller } from './template.controller';
import { TemplateService } from './template.service';
import { TemplateCronService } from './template.service.cron';

@Global()
@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: 'Template',
        schema: TemplateSchema,
      },
      {
        name: 'Attribute',
        schema: AttributeSchema,
      },
      {
        name: 'AttributeGroup',
        schema: AttributeGroupSchema,
      },
      {
        name: 'Table',
        schema: TableSchema,
      },
    ]),
  ],
  providers: [
    {
      provide: 'TemplateServiceInterface',
      useClass: TemplateService,
    },
    {
      provide: 'TemplateRepositoryInterface',
      useClass: TemplateRepository,
    },
    {
      provide: 'AttributeRepositoryInterface',
      useClass: AttributeRepository,
    },

    {
      provide: 'AttributeGroupRepositoryInterface',
      useClass: AttributeGroupRepository,
    },
    {
      provide: 'TableRepositoryInterface',
      useClass: TableRepository,
    },
    TemplateCronService,
  ],
  controllers: [TemplateConstroller],
  exports: [
    {
      provide: 'TemplateServiceInterface',
      useClass: TemplateService,
    },
    {
      provide: 'TemplateRepositoryInterface',
      useClass: TemplateRepository,
    },
    {
      provide: 'AttributeRepositoryInterface',
      useClass: AttributeRepository,
    },
    {
      provide: 'AttributeGroupRepositoryInterface',
      useClass: AttributeGroupRepository,
    },
    {
      provide: 'TableRepositoryInterface',
      useClass: TableRepository,
    },
    TemplateCronService,
  ],
})
export class TemplateModule {}
