import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import {
  CodeEnumFixedMesx,
  CodeEnumFixedWmsx,
  TEMPLATE_CONFIG_MAP,
} from '@utils/template/general-template';
import { I18nService } from 'nestjs-i18n';
import { TemplateRepositoryInterface } from './interfaces/template.repository.interface';

@Injectable()
export class TemplateCronService {
  constructor(
    @Inject('TemplateRepositoryInterface')
    private readonly templateRepository: TemplateRepositoryInterface,
    private readonly i18n: I18nService,
  ) {}

  public async runSeeder(): Promise<any> {
    const templateCodes = [...CodeEnumFixedWmsx, ...CodeEnumFixedMesx];

    const bulkOps = templateCodes.map((templateCode) => ({
      updateOne: {
        filter: { code: templateCode },
        update: {
          ...TEMPLATE_CONFIG_MAP[templateCode],
        },
        upsert: true,
      },
    }));

    const documents = await this.templateRepository.bulkWrite(bulkOps);

    return new ResponseBuilder(documents)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
