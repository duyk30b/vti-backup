import { GetListAttributeGroupRequestDto } from '@components/attribute-group/dto/request/get-list-attribute-group.request.dto';
import { UpdateAttributeGroupBodyDto } from '@components/attribute-group/dto/request/update-attribute-group.request.dto';
import { CreateAttributeGroupRequestDto } from '@components/template/dto/request/attribues/create-attribute-general.request.dto';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { AttributeGroup } from 'src/models/attribute-groups/attribute-group.schema';

export interface AttributeGroupRepositoryInterface
  extends BaseInterfaceRepository<AttributeGroup> {
  createEntity(request: CreateAttributeGroupRequestDto): AttributeGroup;
  updateEntity(
    entity: AttributeGroup,
    request: UpdateAttributeGroupBodyDto,
  ): AttributeGroup;
  list(request: GetListAttributeGroupRequestDto): Promise<any>;
}
