import { CreateAttributeGroupRequestDto } from '@components/template/dto/request/attribues/create-attribute-general.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { GetDetailAttributeGroupRequestDto } from '../dto/request/get-detail-attribute-group.request.dto';
import { GetListAttributeGroupRequestDto } from '../dto/request/get-list-attribute-group.request.dto';
import { UpdateAttributeGroupRequestDto } from '../dto/request/update-attribute-group.request.dto';
import { GetAttributeGroupsByCodesRequestDto } from '../dto/request/get-attribute-groups-by-codes.request.dto';

export interface AttributeGroupServiceInterface {
  create(request: CreateAttributeGroupRequestDto): Promise<any>;
  update(request: UpdateAttributeGroupRequestDto): Promise<any>;
  getDetail(request: GetDetailAttributeGroupRequestDto): Promise<any>;
  list(request: GetListAttributeGroupRequestDto): Promise<any>;
  updateActiveStatus(request: UpdateActiveStatusPayload): Promise<any>;
  updateStatus(request: UpdateActiveStatusPayload): Promise<any>;
  getAttributeGroupsByCodes(
    request: GetAttributeGroupsByCodesRequestDto,
  ): Promise<any>;
}
