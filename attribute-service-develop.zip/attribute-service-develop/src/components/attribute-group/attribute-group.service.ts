import { CreateAttributeGroupRequestDto } from '@components/template/dto/request/attribues/create-attribute-general.request.dto';
import { STATUS_ENUM } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { generateCodeByPreviousCode } from 'src/helper/code.helper';
import { ATTRIBUTE_GROUP_CONST } from './attribute-group.constants';
import { GetDetailAttributeGroupRequestDto } from './dto/request/get-detail-attribute-group.request.dto';
import { GetListAttributeGroupRequestDto } from './dto/request/get-list-attribute-group.request.dto';
import { UpdateAttributeGroupRequestDto } from './dto/request/update-attribute-group.request.dto';
import { AttributeGroupResponseDto } from './dto/response/attribute-group.response.dto';
import { AttributeGroupRepositoryInterface } from './interfaces/attribute-group.repository.interface';
import { AttributeGroupServiceInterface } from './interfaces/attribute-group.service.interface';
import { GetAttributeGroupsByCodesRequestDto } from './dto/request/get-attribute-groups-by-codes.request.dto';
@Injectable()
export class AttributeGroupService implements AttributeGroupServiceInterface {
  constructor(
    @Inject('AttributeGroupRepositoryInterface')
    private readonly attributeGroupRepository: AttributeGroupRepositoryInterface,
    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateAttributeGroupRequestDto): Promise<any> {
    try {
      const document = await this.attributeGroupRepository.createEntity(
        request,
      );
      const lastRecord = await this.attributeGroupRepository.lastRecord();
      const currentCode =
        Number(
          lastRecord.code?.replace(ATTRIBUTE_GROUP_CONST.CODE.PREFIX, ''),
        ) || 0;
      document.code = generateCodeByPreviousCode(
        ATTRIBUTE_GROUP_CONST.CODE.PREFIX,
        currentCode,
      );
      const dataSave = await document.save();
      const dataReturn = plainToInstance(AttributeGroupResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }
  async update(request: UpdateAttributeGroupRequestDto): Promise<any> {
    try {
      const { id } = request;
      let attributeGroup = await this.attributeGroupRepository.findOneById(id);
      if (!attributeGroup) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }
      attributeGroup = this.attributeGroupRepository.updateEntity(
        attributeGroup,
        request,
      );
      if (attributeGroup.status === STATUS_ENUM.REJECT) {
        attributeGroup.status = STATUS_ENUM.WAITING_CONFIRM;
      }
      const dataSave = await this.attributeGroupRepository.findByIdAndUpdate(
        id,
        attributeGroup,
      );

      const dataReturn = plainToInstance(AttributeGroupResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getDetail(request: GetDetailAttributeGroupRequestDto): Promise<any> {
    try {
      const { id } = request;
      const attribute = await this.attributeGroupRepository.findOneById(id);
      if (!attribute) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }
      const dataReturn = plainToInstance(AttributeGroupResponseDto, attribute, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }
  async list(request: GetListAttributeGroupRequestDto): Promise<any> {
    const { data, count } = await this.attributeGroupRepository.list(request);
    const dataReturn = plainToInstance(AttributeGroupResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateActiveStatus(request: UpdateActiveStatusPayload): Promise<any> {
    const { id, status } = request;
    const attribute = await this.attributeGroupRepository.findOneById(id);
    if (!attribute) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    await this.attributeGroupRepository.findByIdAndUpdate(id, {
      $set: { active: status },
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateStatus(request: UpdateActiveStatusPayload): Promise<any> {
    const { id, status } = request;
    const attribute = await this.attributeGroupRepository.findOneById(id);
    if (!attribute) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    const dataSave = await this.attributeGroupRepository.findByIdAndUpdate(id, {
      $set: { status: status },
    });
    return new ResponseBuilder(dataSave)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getAttributeGroupsByCodes(
    request: GetAttributeGroupsByCodesRequestDto,
  ): Promise<any> {
    const { codes } = request;
    const attributeGroups =
      await this.attributeGroupRepository.findAllByCondition({
        code: { $in: codes },
      });

    return new ResponseBuilder(attributeGroups)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
