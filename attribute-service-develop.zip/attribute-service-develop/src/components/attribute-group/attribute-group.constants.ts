export const ATTRIBUTE_GROUP_CONST = {
  CODE: {
    PREFIX: 'GRP',
  },
};
