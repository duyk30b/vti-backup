import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';
import { AttributeGroupResponseDto } from './attribute-group.response.dto';

export class ListAttributeGroupResponse extends PaginationResponse {
  @ApiProperty({ type: AttributeGroupResponseDto, isArray: true })
  @Type(() => AttributeGroupResponseDto)
  @Expose()
  items: AttributeGroupResponseDto[];
}
