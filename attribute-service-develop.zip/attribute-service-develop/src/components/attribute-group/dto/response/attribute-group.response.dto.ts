import { BaseResponseDto } from '@core/dto/base.response.dto';
import { Expose } from 'class-transformer';

export class AttributeGroupResponseDto extends BaseResponseDto {
  @Expose()
  id: string;

  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  dataSource: any;

  @Expose()
  dataRefEndpoint: string;

  @Expose()
  autoGenCode: string;

  @Expose()
  description: string;

  @Expose()
  dataType: string;

  @Expose()
  active: number;

  @Expose()
  order: number;

  @Expose()
  status: number;
}
