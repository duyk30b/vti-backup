import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateAttributeGroupRequestDto } from '@components/template/dto/request/attribues/create-attribute-general.request.dto';
import { ApiProperty } from '@nestjs/swagger';

export class UpdateAttributeGroupBodyDto extends CreateAttributeGroupRequestDto {}

export class UpdateAttributeGroupRequestDto extends UpdateAttributeGroupBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
