import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';

export class GetAttributeGroupsByCodesRequestDto extends BaseDto {
  @ApiProperty()
  codes: any[];
}
