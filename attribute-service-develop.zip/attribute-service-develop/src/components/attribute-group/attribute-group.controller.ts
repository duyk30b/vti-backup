import { CreateAttributeGroupRequestDto } from '@components/template/dto/request/attribues/create-attribute-general.request.dto';
import { ACTIVE_ENUM, STATUS_ENUM } from '@constant/common';
import {
  Body,
  Controller,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { GetDetailAttributeGroupRequestDto } from './dto/request/get-detail-attribute-group.request.dto';
import { GetListAttributeGroupRequestDto } from './dto/request/get-list-attribute-group.request.dto';
import { UpdateAttributeGroupBodyDto } from './dto/request/update-attribute-group.request.dto';
import { AttributeGroupResponseDto } from './dto/response/attribute-group.response.dto';
import { ListAttributeGroupResponse } from './dto/response/list-attribute-group.response.dto';
import { AttributeGroupServiceInterface } from './interfaces/attribute-group.service.interface';
import { MessagePattern } from '@nestjs/microservices';
import { GetAttributeGroupsByCodesRequestDto } from './dto/request/get-attribute-groups-by-codes.request.dto';
import { NATS_ATTRIBUTE } from '@config/nats.config';

@Controller('attribute-groups')
export class AttributeGroupController {
  constructor(
    @Inject('AttributeGroupServiceInterface')
    private readonly attributeGroupService: AttributeGroupServiceInterface,
  ) {}

  @Post('')
  async create(@Body() payload: CreateAttributeGroupRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.attributeGroupService.create(request);
  }

  @Put('/:id')
  @ApiOperation({
    tags: ['Attribute Group'],
    summary: 'Cập nhật nhóm thuộc tính',
    description: 'Cập nhật nhóm thuộc tính',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async update(
    @Param() param: IdParamMongoDto,
    @Body() payload: UpdateAttributeGroupBodyDto,
  ): Promise<any> {
    const { request: requestParam, responseError: responseParamError } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.attributeGroupService.update({
      id: requestParam.id,
      ...request,
    });
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['Attribute Group'],
    summary: 'Chi tiết nhóm thuộc tính',
    description: 'Chi tiết nhóm thuộc tính',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: AttributeGroupResponseDto,
  })
  async detail(
    @Param() param: GetDetailAttributeGroupRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.attributeGroupService.getDetail(request);
  }

  @Get('')
  @ApiOperation({
    tags: ['Attribute Group'],
    summary: 'Danh sách nhóm thuộc tính',
    description: 'Danh sách nhóm thuộc tính',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListAttributeGroupResponse,
  })
  async list(@Query() query: GetListAttributeGroupRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.attributeGroupService.list(request);
  }

  @Put('/:id/active')
  @ApiOperation({
    tags: ['Attribute Group'],
    summary: 'Active Attribute Group',
    description: 'Active Attribute Group',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async active(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.attributeGroupService.updateActiveStatus({
      ...request,
      status: ACTIVE_ENUM.ACTIVE,
    });
  }
  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Attribute Group'],
    summary: 'Inactive Attribute Group',
    description: 'Inactive Attribute Group',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async inactive(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.attributeGroupService.updateActiveStatus({
      ...request,
      status: ACTIVE_ENUM.INACTIVE,
    });
  }
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Attribute Group'],
    summary: 'Active Attribute Group',
    description: 'Active Attribute Group',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async confirm(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.attributeGroupService.updateStatus({
      ...request,
      status: STATUS_ENUM.CONFIRM,
    });
  }
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Attribute Group'],
    summary: 'Inactive Attribute Group',
    description: 'Inactive Attribute Group',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async reject(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.attributeGroupService.updateStatus({
      ...request,
      status: STATUS_ENUM.REJECT,
    });
  }

  @MessagePattern(`${NATS_ATTRIBUTE}.get_attribute_groups_by_codes`)
  @ApiOperation({
    tags: ['Attribute Group'],
    summary: 'Get List Attribute Group By Codes',
    description: 'Get List Attribute Group By Codes',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: AttributeGroupResponseDto,
  })
  async getAttributeGroupsByCodes(
    @Body() payload: GetAttributeGroupsByCodesRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.attributeGroupService.getAttributeGroupsByCodes(request);
  }
}
