import { Global, Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { AttributeGroupSchema } from 'src/models/attribute-groups/attribute-group.schema';
import { AttributeGroupRepository } from 'src/repository/template/attribute-group.repository';
import { AttributeGroupController } from './attribute-group.controller';
import { AttributeGroupService } from './attribute-group.service';
import { AttributeGroupCronService } from './attribute-group.service.cron';

@Global()
@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: 'AttributeGroup',
        schema: AttributeGroupSchema,
      },
    ]),
  ],
  controllers: [AttributeGroupController],
  providers: [
    {
      provide: 'AttributeGroupServiceInterface',
      useClass: AttributeGroupService,
    },
    {
      provide: 'AttributeGroupRepositoryInterface',
      useClass: AttributeGroupRepository,
    },
    AttributeGroupCronService,
  ],
  exports: [
    {
      provide: 'AttributeGroupServiceInterface',
      useClass: AttributeGroupService,
    },
    {
      provide: 'AttributeGroupRepositoryInterface',
      useClass: AttributeGroupRepository,
    },
    AttributeGroupCronService,
  ],
})
export class AttributeGroupModule {}
