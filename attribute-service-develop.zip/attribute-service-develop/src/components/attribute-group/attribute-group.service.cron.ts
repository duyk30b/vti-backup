import { GroupFixed, GROUP_CONFIG_MAP } from './../../constant/common';
import { Inject, Injectable } from '@nestjs/common';
import { AttributeGroupRepositoryInterface } from './interfaces/attribute-group.repository.interface';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { I18nService } from 'nestjs-i18n';

@Injectable()
export class AttributeGroupCronService {
  constructor(
    @Inject('AttributeGroupRepositoryInterface')
    private readonly attributeGroupRepository: AttributeGroupRepositoryInterface,
    private readonly i18n: I18nService,
  ) {}

  public async runSeeder(): Promise<any> {
    const attributeGroupCodes = [...Object.values(GroupFixed)];
    const bulkOps = attributeGroupCodes.map((attributeGroupCode) => ({
      updateOne: {
        filter: { code: attributeGroupCode },
        update: {
          ...GROUP_CONFIG_MAP[attributeGroupCode],
        },
        upsert: true,
      },
    }));

    const documents = await this.attributeGroupRepository.bulkWrite(bulkOps);

    return new ResponseBuilder(documents)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
