import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Injectable } from '@nestjs/common';
import { UserServiceInterface } from './interface/user.service.interface';
import {
  DEPARTMENT_SETTING_CONSTANT,
  USER_ROLE_SETTING_CONSTANT,
} from './user.constant';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { NATS_USER } from '@config/nats.config';

@Injectable()
export class UserService implements UserServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async insertPermission(permissions): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_USER}.insert_permission`,
      permissions,
    );
  }

  async deletePermissionNotActive(): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_USER}.delete_permission_not_active`,
      {},
    );
  }

  async getFactoryList(filter?: any, keyword?: string): Promise<any> {
    const params = {
      isGetAll: '1',
      filter: filter,
      isMasterData: '1',
      keyword: keyword,
    };
    try {
      const response = await this.natsClientService.send(
        `${NATS_USER}.list_factories`,
        params,
      );

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }
      return response.data.items;
    } catch (err) {
      return [];
    }
  }

  async getFactoryListWithPagination(
    filter?: any,
    page?: number,
    limit?: number,
  ): Promise<any> {
    const params = {
      page: page || 1,
      limit: limit || 10,
      filter: filter,
    };
    try {
      const response = await this.natsClientService.send(
        `${NATS_USER}.list_factories`,
        params,
      );

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }

      return response.data;
    } catch (err) {
      return [];
    }
  }

  async getFactoryById(id: number): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_USER}.detail_factory`,
        {
          id,
        },
      );

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return null;
      }
      return response.data;
    } catch (err) {
      return null;
    }
  }

  async updateStatusFactories(
    regionIds: string[],
    status: number,
  ): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_USER}.update_many_status`,
        {
          regionIds,
          status,
        },
      );

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return null;
      }
      return response.data;
    } catch (err) {
      return null;
    }
  }

  async detailCompany(id: number): Promise<any> {
    return await this.natsClientService.send(`${NATS_USER}.company_detail`, {
      id: id,
    });
  }

  async getDetailUser(id: number): Promise<any> {
    try {
      const response: any = this.natsClientService.send(`${NATS_USER}.detail`, {
        id: +id,
      });

      return response?.data;
    } catch (err) {
      return null;
    }
  }

  async getList(filter: any): Promise<any> {
    try {
      const response: any = this.natsClientService.send(`${NATS_USER}.list`, {
        filter,
      });

      return response?.data?.items || [];
    } catch (err) {
      return [];
    }
  }

  async getListFactoryManager(factoryId: any): Promise<any> {
    try {
      const response: any = this.natsClientService.send(`${NATS_USER}.list`, {
        filter: [
          { column: 'factoryId', text: factoryId },
          { column: 'roleCode', text: USER_ROLE_SETTING_CONSTANT.ADMIN },
          { column: 'departmentCode', text: DEPARTMENT_SETTING_CONSTANT.ME },
        ],
      });

      return response?.data?.items || [];
    } catch (err) {
      return [];
    }
  }

  async syncFactories(data: any): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_USER}.sync_factories`,
        {
          factorySyncs: data,
        },
      );

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return null;
      }
      return response.data;
    } catch (err) {
      return null;
    }
  }
}
