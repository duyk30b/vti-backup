import { NATS_USER } from '@config/nats.config';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';

@Injectable()
export class UserCronService {
  constructor(private readonly natsClientService: NatsClientService) {}

  async insertPermission(permissions): Promise<any> {
    return await this.natsClientService.send(`${NATS_USER}`, permissions);
  }

  async deletePermissionNotActive(): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_USER}.delete_permission_not_active`,
      {},
    );
  }
}
