import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { generateCodeByPreviousCode } from 'src/helper/code.helper';
import { CreateTableRequestDto } from './dto/request/create-table.request.dto';
import { GetListTableRequestDto } from './dto/request/get-list-table.request.dto';
import { TableResponseDto } from './dto/response/table.response.dto';
import { TableRepositoryInterface } from './interfaces/table.repository.interface';
import { TableServiceInterface } from './interfaces/table.service.interface';
import { TABLE_CONST } from './table.constants';
@Injectable()
export class TableService implements TableServiceInterface {
  constructor(
    @Inject('TableRepositoryInterface')
    private readonly tableRepository: TableRepositoryInterface,
    private readonly i18n: I18nRequestScopeService,
  ) {}

  async create(request: CreateTableRequestDto): Promise<any> {
    try {
      const tableDocument = await this.tableRepository.createEntity(request);
      const lastRecord = await this.tableRepository.lastRecord();
      const currentCode =
        Number(lastRecord.code?.replace(TABLE_CONST.CODE.PREFIX, '')) || 0;
      tableDocument.code = generateCodeByPreviousCode(
        TABLE_CONST.CODE.PREFIX,
        currentCode,
      );
      tableDocument.prefixEndPointService = `${TABLE_CONST.PREFIX_END_POINT_SERVIVE.PREFIX}/${request.prefixService}`;
      const dataSave = await tableDocument.save();
      const dataReturn = plainToInstance(TableResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async list(request: GetListTableRequestDto): Promise<any> {
    const { data, count } = await this.tableRepository.getList(request);
    const dataReturn = plainToInstance(TableResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
