import { CreateTableRequestDto } from '../dto/request/create-table.request.dto';
import { GetListTableRequestDto } from '../dto/request/get-list-table.request.dto';

export interface TableServiceInterface {
  create(request: CreateTableRequestDto): Promise<any>;
  list(request: GetListTableRequestDto): Promise<any>;
}
