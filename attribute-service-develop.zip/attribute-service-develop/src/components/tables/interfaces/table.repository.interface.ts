import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Table } from 'src/models/tables/table.shcema';
import { CreateTableRequestDto } from '../dto/request/create-table.request.dto';
import { GetListTableRequestDto } from '../dto/request/get-list-table.request.dto';

export interface TableRepositoryInterface
  extends BaseAbstractRepository<Table> {
  createEntity(request: CreateTableRequestDto): Table;
  getList(request: GetListTableRequestDto): Promise<any>;
}
