import { Body, Controller, Get, Inject, Post, Query } from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { isEmpty } from 'lodash';
import { CreateTableRequestDto } from './dto/request/create-table.request.dto';
import { GetListTableRequestDto } from './dto/request/get-list-table.request.dto';
import { TableServiceInterface } from './interfaces/table.service.interface';

@Controller('tables')
export class TableController {
  constructor(
    @Inject('TableServiceInterface')
    private readonly tableService: TableServiceInterface,
  ) {}

  @Post('')
  async create(@Body() payload: CreateTableRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.tableService.create(request);
  }

  @Get('')
  @ApiOperation({
    tags: ['Attribute Group'],
    summary: 'Danh sách nhóm thuộc tính',
    description: 'Danh sách nhóm thuộc tính',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: '',
  })
  async list(@Query() query: GetListTableRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.tableService.list(request);
  }
}
