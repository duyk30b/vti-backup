import { MongooseModule } from '@nestjs/mongoose';
import { Module } from '@nestjs/common';
import { TableSchema } from 'src/models/tables/table.shcema';
import { TableController } from './table.controller';
import { TableService } from './table.service';
import { TableRepository } from 'src/repository/table/table.repository';
import { TableCronService } from './table.service.cron';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: 'Table',
        schema: TableSchema,
      },
    ]),
  ],
  providers: [
    {
      provide: 'TableServiceInterface',
      useClass: TableService,
    },
    {
      provide: 'TableRepositoryInterface',
      useClass: TableRepository,
    },
    TableCronService,
  ],
  controllers: [TableController],
  exports: [
    {
      provide: 'TableServiceInterface',
      useClass: TableService,
    },
    {
      provide: 'TableRepositoryInterface',
      useClass: TableRepository,
    },
    TableCronService,
  ],
})
export class TableModule {}
