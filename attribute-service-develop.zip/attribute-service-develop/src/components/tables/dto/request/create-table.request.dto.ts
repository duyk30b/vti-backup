import { BaseDto } from '@core/dto/base.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';

export class CreateTableRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  code: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  name: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  prefixService: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  prefixEndPointService: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  prefixController: string;
}
