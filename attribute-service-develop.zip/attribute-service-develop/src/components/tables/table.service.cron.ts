import { TableFixed, TABLE_CONFIG_MAP } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nService } from 'nestjs-i18n';
import { TableRepositoryInterface } from './interfaces/table.repository.interface';
@Injectable()
export class TableCronService {
  constructor(
    @Inject('TableRepositoryInterface')
    private readonly tableRepository: TableRepositoryInterface,
    private readonly i18n: I18nService,
  ) {}

  public async runSeeder(): Promise<any> {
    const tableCodes = [
      TableFixed.ITEMS,
      TableFixed.REQUESTS,
      TableFixed.WAREHOUSES,
      TableFixed.DEPARTMENT_SETTINGS,
      TableFixed.USERS,
      TableFixed.TEMPLATES,
      TableFixed.REASONS,
      TableFixed.LOCATORS,
      TableFixed.WAREHOUSE_REQUEST_ORDERS,
      TableFixed.REASONS,
      TableFixed.ITEM_WAREHOUSE_STOCK,
    ];
    const bulkOps = tableCodes.map((tableCode) => ({
      updateOne: {
        filter: { code: tableCode },
        update: {
          ...TABLE_CONFIG_MAP[tableCode],
        },
        upsert: true,
      },
    }));

    const documents = await this.tableRepository.bulkWrite(bulkOps);

    return new ResponseBuilder(documents)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
