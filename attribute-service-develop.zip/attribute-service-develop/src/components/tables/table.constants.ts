export const TABLE_CONST = {
  CODE: {
    PREFIX: 'TBL',
  },
  PREFIX_END_POINT_SERVIVE: {
    PREFIX: 'v1',
  },
};
