import { NotificationEventInterface } from '@components/notification/interface/notification.event.interface';

export class EventRequestDto implements NotificationEventInterface {
  constructor({ id, name, code, entityType = null, fromUserId = null }) {
    this.id = id;
    this.name = name;
    this.entityType = entityType;
    this.code = code;
    this.fromUserId = fromUserId;
  }
  entityType?: number;
  id: string;
  name: string;
  code: string;
  fromUserId?: number;
}
