export interface NotificationEventInterface {
  id: string;
  name: string;
  code: string;
  entityType?: number;
  fromUserId?: number;
}
