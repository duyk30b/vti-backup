export const ATTRIBUTE_CONST = {
  CODE: {
    PREFIX: 'ATT',
  },
};
