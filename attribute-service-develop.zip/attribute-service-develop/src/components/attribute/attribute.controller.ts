import {
  Body,
  Controller,
  Get,
  Inject,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { AttributeServiceInterface } from './interfaces/attribute.service.interface';
import { CreateAttributeRequestDto } from '@components/template/dto/request/attribues/create-attribute-general.request.dto';
import { isEmpty } from 'lodash';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { UpdateAttributeBodyDto } from './dto/request/update-attribute.request.dto';
import { AttributeResponseDto } from './dto/response/attribute.response.dto';
import { GetDetailAttributeRequestDto } from './dto/request/get-detail-attribute.request.dto';
import { ListAttributeResponse } from './dto/response/list-attribute.response.dto';
import { GetListAttributeRequestDto } from './dto/request/get-list-attribute.request.dto';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { ACTIVE_ENUM, STATUS_ENUM } from '@constant/common';
import { MessagePattern } from '@nestjs/microservices';
import { NATS_ATTRIBUTE } from '@config/nats.config';

@Controller('')
export class AttributeController {
  constructor(
    @Inject('AttributeServiceInterface')
    private readonly attributeService: AttributeServiceInterface,
  ) {}

  @Post('')
  async create(@Body() payload: CreateAttributeRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.attributeService.create(request);
  }

  @Put('/:id')
  @ApiOperation({
    tags: ['Attribute'],
    summary: 'Cập nhật  thuộc tính',
    description: 'Cập nhật  thuộc tính',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async update(
    @Param() param: IdParamMongoDto,
    @Body() payload: UpdateAttributeBodyDto,
  ): Promise<any> {
    const { request: requestParam, responseError: responseParamError } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      console.log(responseError);
      return responseError;
    }
    return await this.attributeService.update({
      id: requestParam.id,
      ...request,
    });
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['Attribute'],
    summary: 'Chi tiết  thuộc tính',
    description: 'Chi tiết  thuộc tính',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: AttributeResponseDto,
  })
  async detail(@Param() param: GetDetailAttributeRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.attributeService.getDetail(request);
  }

  @Get('')
  @ApiOperation({
    tags: ['Attribute'],
    summary: 'Danh sách  thuộc tính',
    description: 'Danh sách  thuộc tính',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListAttributeResponse,
  })
  async list(@Query() query: GetListAttributeRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.attributeService.list(request);
  }

  @Put('/:id/active')
  @ApiOperation({
    tags: ['Attribute'],
    summary: 'Active Attribute',
    description: 'Active Attribute',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async active(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.attributeService.updateActiveStatus({
      ...request,
      status: ACTIVE_ENUM.ACTIVE,
    });
  }
  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Attribute'],
    summary: 'Inactive Attribute',
    description: 'Inactive Attribute',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async inactive(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.attributeService.updateActiveStatus({
      ...request,
      status: ACTIVE_ENUM.INACTIVE,
    });
  }
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Attribute'],
    summary: 'Confirm Attribute',
    description: 'Confirm Attribute',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async confirm(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.attributeService.updateStatus({
      ...request,
      status: STATUS_ENUM.CONFIRM,
    });
  }
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Attribute'],
    summary: 'Reject Attribute',
    description: 'Reject Attribute',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async reject(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.attributeService.updateStatus({
      ...request,
      status: STATUS_ENUM.REJECT,
    });
  }
  @MessagePattern(`${NATS_ATTRIBUTE}.get_attribute_by_codes`)
  @ApiOperation({
    tags: ['Attribute'],
    summary: 'Danh sách  thuộc tính',
    description: 'Danh sách  thuộc tính',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListAttributeResponse,
  })
  async getAttributeByCodes(
    @Body() body: GetListAttributeRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.attributeService.list(request);
  }
}
