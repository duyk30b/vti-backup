import {
  ATTRIBUTE_FIXED_PARENT_WMSX,
  ATTRIBUTE_FIXED_PARENT_MESX,
  ATTRIBUTE_CONFIG_MAP,
} from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nService } from 'nestjs-i18n';
import { AttributeRepositoryInterface } from './interfaces/attribute.repository.interface';

@Injectable()
export class AttributeCronService {
  constructor(
    @Inject('AttributeRepositoryInterface')
    private readonly attributeRepository: AttributeRepositoryInterface,
    private readonly i18n: I18nService,
  ) {}

  public async runSeeder(): Promise<any> {
    const attributeCodes = [
      ...ATTRIBUTE_FIXED_PARENT_WMSX,
      ...ATTRIBUTE_FIXED_PARENT_MESX,
    ];

    const bulkOps = attributeCodes.map((attributeCode) => ({
      updateOne: {
        filter: { code: attributeCode },
        update: {
          ...ATTRIBUTE_CONFIG_MAP[attributeCode],
        },
        upsert: true,
      },
    }));

    const documents = await this.attributeRepository.bulkWrite(bulkOps);

    return new ResponseBuilder(documents)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
