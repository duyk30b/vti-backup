import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateAttributeRequestDto } from '@components/template/dto/request/attribues/create-attribute-general.request.dto';
import { ApiProperty } from '@nestjs/swagger';

export class UpdateAttributeBodyDto extends CreateAttributeRequestDto {}

export class UpdateAttributeRequestDto extends UpdateAttributeBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  id: string;
}
