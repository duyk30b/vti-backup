import { ApiProperty } from '@nestjs/swagger';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Expose, Type } from 'class-transformer';
import { AttributeResponseDto } from './attribute.response.dto';

export class ListAttributeResponse extends PaginationResponse {
  @ApiProperty({ type: AttributeResponseDto, isArray: true })
  @Type(() => AttributeResponseDto)
  @Expose()
  items: AttributeResponseDto[];
}
