import { BaseResponseDto } from '@core/dto/base.response.dto';
import { Expose } from 'class-transformer';

export class AttributeResponseDto extends BaseResponseDto {
  @Expose()
  id: string;

  @Expose()
  code: string;

  @Expose()
  name: string;

  @Expose()
  dataSource: any;

  @Expose()
  min: any;

  @Expose()
  max: any;

  @Expose()
  label: any;

  @Expose()
  isFixedParent: number;

  @Expose()
  subLabel: any;

  @Expose()
  defaultValue: any;

  @Expose()
  isRequired: number;

  @Expose()
  canUpdate: number;

  @Expose()
  display: number;

  @Expose()
  dataRefEndpoint: string;

  @Expose()
  autoGenCode: string;

  @Expose()
  description: string;

  @Expose()
  dataType: string;

  @Expose()
  regex: string;

  @Expose()
  active: number;

  @Expose()
  status: number;
}
