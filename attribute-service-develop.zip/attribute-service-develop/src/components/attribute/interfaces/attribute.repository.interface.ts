import { GetListAttributeRequestDto } from '@components/attribute/dto/request/get-list-attribute.request.dto';
import { UpdateAttributeBodyDto } from '@components/attribute/dto/request/update-attribute.request.dto';
import { CreateAttributeRequestDto } from '@components/template/dto/request/attribues/create-attribute-general.request.dto';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { Attribute } from 'src/models/attributes/attribute.schema';

export interface AttributeRepositoryInterface
  extends BaseInterfaceRepository<Attribute> {
  createEntity(request: CreateAttributeRequestDto): Attribute;
  updateEntity(entity: Attribute, request: UpdateAttributeBodyDto): Attribute;
  list(request: GetListAttributeRequestDto): Promise<any>;
}
