import { CreateAttributeRequestDto } from '@components/template/dto/request/attribues/create-attribute-general.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { GetDetailAttributeRequestDto } from '../dto/request/get-detail-attribute.request.dto';
import { GetListAttributeRequestDto } from '../dto/request/get-list-attribute.request.dto';
import { UpdateAttributeRequestDto } from '../dto/request/update-attribute.request.dto';

export interface AttributeServiceInterface {
  create(request: CreateAttributeRequestDto): Promise<any>;
  update(request: UpdateAttributeRequestDto): Promise<any>;
  getDetail(request: GetDetailAttributeRequestDto): Promise<any>;
  list(request: GetListAttributeRequestDto): Promise<any>;
  updateActiveStatus(request: UpdateActiveStatusPayload): Promise<any>;
  updateStatus(request: UpdateActiveStatusPayload): Promise<any>;
}
