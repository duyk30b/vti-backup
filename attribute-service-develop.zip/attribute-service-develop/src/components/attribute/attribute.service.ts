import { CreateAttributeRequestDto } from '@components/template/dto/request/attribues/create-attribute-general.request.dto';
import { STATUS_ENUM } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { GetDetailAttributeRequestDto } from './dto/request/get-detail-attribute.request.dto';
import { GetListAttributeRequestDto } from './dto/request/get-list-attribute.request.dto';
import { UpdateAttributeRequestDto } from './dto/request/update-attribute.request.dto';
import { AttributeResponseDto } from './dto/response/attribute.response.dto';
import { AttributeRepositoryInterface } from './interfaces/attribute.repository.interface';
import { AttributeServiceInterface } from './interfaces/attribute.service.interface';
@Injectable()
export class AttributeService implements AttributeServiceInterface {
  constructor(
    @Inject('AttributeRepositoryInterface')
    private readonly attributeRepository: AttributeRepositoryInterface,
    private readonly i18n: I18nRequestScopeService,
  ) {}
  async create(request: CreateAttributeRequestDto): Promise<any> {
    try {
      const document = await this.attributeRepository.createEntity(request);
      const dataSave = await document.save();
      const dataReturn = plainToInstance(AttributeResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }
  async update(request: UpdateAttributeRequestDto): Promise<any> {
    try {
      const { id } = request;
      let attribute = await this.attributeRepository.findOneById(id);
      if (!attribute) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }
      attribute = this.attributeRepository.updateEntity(attribute, request);
      if (attribute?.status === STATUS_ENUM.REJECT) {
        attribute.status = STATUS_ENUM.WAITING_CONFIRM;
      }
      const dataSave = await this.attributeRepository.findByIdAndUpdate(
        id,
        attribute,
      );

      const dataReturn = plainToInstance(AttributeResponseDto, dataSave, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log('error', error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getDetail(request: GetDetailAttributeRequestDto): Promise<any> {
    try {
      const { id } = request;
      const attribute = await this.attributeRepository.findOneById(id);
      if (!attribute) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }
      const dataReturn = plainToInstance(AttributeResponseDto, attribute, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(dataReturn)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }
  async list(request: GetListAttributeRequestDto): Promise<any> {
    const { data, count } = await this.attributeRepository.list(request);
    const dataReturn = plainToInstance(AttributeResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateActiveStatus(request: UpdateActiveStatusPayload): Promise<any> {
    const { id, status } = request;
    const attribute = await this.attributeRepository.findOneById(id);
    if (!attribute) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    await this.attributeRepository.findByIdAndUpdate(id, {
      $set: { active: status },
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
  async updateStatus(request: UpdateActiveStatusPayload): Promise<any> {
    const { id, status } = request;
    const attribute = await this.attributeRepository.findOneById(id);
    if (!attribute) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'));
    }
    await this.attributeRepository.findByIdAndUpdate(id, {
      $set: { status: status },
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
