import { Global, Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { AttributeSchema } from 'src/models/attributes/attribute.schema';
import { AttributeRepository } from 'src/repository/template/attribute.repository';
import { AttributeController } from './attribute.controller';
import { AttributeService } from './attribute.service';
import { AttributeCronService } from './attribute.service.cron';

@Global()
@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: 'Attribute',
        schema: AttributeSchema,
      },
    ]),
  ],
  controllers: [AttributeController],
  providers: [
    {
      provide: 'AttributeServiceInterface',
      useClass: AttributeService,
    },
    {
      provide: 'AttributeRepositoryInterface',
      useClass: AttributeRepository,
    },
    AttributeCronService,
  ],
  exports: [
    {
      provide: 'AttributeServiceInterface',
      useClass: AttributeService,
    },
    {
      provide: 'AttributeRepositoryInterface',
      useClass: AttributeRepository,
    },
    AttributeCronService,
  ],
})
export class AttributeModule {}
