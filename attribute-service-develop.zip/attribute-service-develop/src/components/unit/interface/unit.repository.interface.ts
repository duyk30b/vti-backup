import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { Unit } from 'src/models/unit/unit.model';
import { GetListUnitQuery } from '../dto/request/get-list-unit.query';
import { CreateUnitRequest } from '../dto/request/create-unit.request';
import { UpdateUnitRequest } from '../dto/request/update-unit.request';

export interface UnitRepositoryInterface extends BaseAbstractRepository<Unit> {
  createEntity(request: CreateUnitRequest): Unit;
  updateEntity(entity: Unit, request: UpdateUnitRequest): Unit; 
  list(request: GetListUnitQuery): Promise<any>;
}
