import { ResponsePayload } from '@utils/response-payload';
import { GetListUnitQuery } from '../dto/request/get-list-unit.query';
import { CreateUnitRequest } from '../dto/request/create-unit.request';
import { UpdateUnitRequest } from '../dto/request/update-unit.request';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { UpdateActiveStatusPayload } from '@utils/dto/request/update-active-status.request.dto';

export interface UnitServiceInterface {
  create(request: CreateUnitRequest): Promise<ResponsePayload<any>>;
  update(request: UpdateUnitRequest): Promise<ResponsePayload<any>>;
  detail(request: IdParamMongoDto): Promise<ResponsePayload<any>>;
  list(request: GetListUnitQuery): Promise<ResponsePayload<any>>;
  updateStatus(request: UpdateActiveStatusPayload): Promise<any>;
}
