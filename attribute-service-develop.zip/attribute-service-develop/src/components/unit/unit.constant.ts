import { CODE_REGEX, ACTIVE_ENUM } from '@constant/common';

export const UNIT_CONST = {
  DESCRIPTION: {
    MAX_LENGTH: 255,
    COLUMN: 'description',
  },
  CODE: {
    MAX_LENGTH: 20,
    MIN_LENGTH: 6,
    COLUMN: 'code',
    REGEX: CODE_REGEX,
    PREFIX: 'DVT',
  },
  NAME: {
    MAX_LENGTH: 255,
    COLUMN: 'name',
  },
  ACTIVE: {
    COLUMN: 'active',
    ENUM: ACTIVE_ENUM,
  },
};
