import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { DetailUnitResponse } from './detail-unit.response';
import { PaginationResponse } from '@utils/dto/response/pagination.response';
import { Type } from 'class-transformer';

export class ListUnitResponse extends PaginationResponse {
  @ApiProperty({type: DetailUnitResponse,  isArray: true })
  @Type(() => DetailUnitResponse)
  @Expose() 
  items: DetailUnitResponse[];
}
