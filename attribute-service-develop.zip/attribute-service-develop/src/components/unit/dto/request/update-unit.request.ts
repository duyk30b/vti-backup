import { ApiProperty } from '@nestjs/swagger';
import { IsMongoId, IsNotEmpty } from 'class-validator';
import { CreateUnitRequest } from './create-unit.request';

export class UpdateUnitBodyDto extends CreateUnitRequest {}

export class UpdateUnitRequest extends UpdateUnitBodyDto {
  @ApiProperty()
  @IsMongoId()
  @IsNotEmpty()
  id: string;
}
