import { UNIT_CONST } from '@components/unit/unit.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';
import { IsNotBlank } from 'src/validator/is-not-blank.validator';

export class CreateUnitRequest extends BaseDto {
  code: string;

  @ApiProperty({ description: 'Tên của đơn vị' })
  @MaxLength(UNIT_CONST.NAME.MAX_LENGTH)
  @IsString()
  @IsNotEmpty()
  @IsNotBlank()
  name: string;

  @ApiProperty({ description: 'Mô tả của đơn vị' })
  @IsString()
  @MaxLength(UNIT_CONST.DESCRIPTION.MAX_LENGTH)
  @IsOptional()
  description: string;
}
