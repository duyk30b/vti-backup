import {
  Body,
  Controller,
  Get,
  Inject,
  Injectable,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { GetListUnitQuery } from './dto/request/get-list-unit.query';
import { CreateUnitRequest } from './dto/request/create-unit.request';
import { UpdateUnitBodyDto } from './dto/request/update-unit.request';
import { DetailUnitResponse } from './dto/response/detail-unit.response';
import { ListUnitResponse } from './dto/response/list-unit.response';
import { UnitServiceInterface } from './interface/unit.service.interface';
import { ACTIVE_ENUM } from '@constant/common';
import { IdParamMongoDto } from '@utils/dto/request/param-id.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CREATE_UNIT_PERMISSION,
  DETAIL_UNIT_PERMISSION,
  LIST_UNIT_PERMISSION,
  UPDATE_STATUS_UNIT_PERMISSION,
  UPDATE_UNIT_PERMISSION,
} from '@utils/permissions/unit';

@Injectable()
@Controller('units')
export class UnitController {
  constructor(
    @Inject('UnitServiceInterface')
    private readonly unitService: UnitServiceInterface,
  ) {}

  @PermissionCode(CREATE_UNIT_PERMISSION.code)
  @Post('/')
  @ApiOperation({
    tags: ['Unit'],
    summary: 'Định nghĩa đơn vị',
    description: 'Định nghĩa đơn vị',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async create(@Body() payload: CreateUnitRequest): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.unitService.create(request);
  }

  //@MessagePattern('update_unit')
  @PermissionCode(UPDATE_UNIT_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Unit'],
    summary: 'Update Unit',
    description: 'Update an existing unit',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  async update(
    @Param() param: IdParamMongoDto,
    @Body() payload: UpdateUnitBodyDto,
  ): Promise<any> {
    const { request: requestParam, responseError: responseParamError } = param;
    if (responseParamError && !isEmpty(responseParamError)) {
      return responseParamError;
    }
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.unitService.update({
      id: requestParam.id,
      ...request,
    });
  }

  //@MessagePattern('detail_unit')
  @PermissionCode(DETAIL_UNIT_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Unit'],
    summary: 'Detail unit',
    description: 'Detail unit',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: DetailUnitResponse,
  })
  async detail(@Param() param: IdParamMongoDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.unitService.detail(request);
  }

  @PermissionCode(LIST_UNIT_PERMISSION.code)
  @Get('/')
  @ApiOperation({
    tags: ['Unit'],
    summary: 'List Unit',
    description: 'List Unit',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: ListUnitResponse,
  })
  async list(@Query() query: GetListUnitQuery): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.unitService.list(request);
  }

  @PermissionCode(UPDATE_STATUS_UNIT_PERMISSION.code)
  @Put('/:id/active')
  @ApiOperation({
    tags: ['Unit'],
    summary: 'Cập nhật trạng thái đơn vị tính',
    description: 'Cập nhật trạng thái đơn vị tính',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async active(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.unitService.updateStatus({
      ...request,
      status: ACTIVE_ENUM.ACTIVE,
    });
  }

  @PermissionCode(UPDATE_STATUS_UNIT_PERMISSION.code)
  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Unit'],
    summary: 'Cập nhật trạng thái đơn vị tính',
    description: 'Cập nhật trạng thái đơn vị tính',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
    type: SuccessResponse,
  })
  async inactive(@Param() payload: IdParamMongoDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.unitService.updateStatus({
      ...request,
      status: ACTIVE_ENUM.INACTIVE,
    });
  }
}
