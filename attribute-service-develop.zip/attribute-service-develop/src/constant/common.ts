import { keyBy } from 'lodash';
import { CollationOptions } from 'mongodb';

export enum APIPrefix {
  Version = 'api/v1',
}

export const REGEX_FOR_FILTER =
  /[^a-zA-ZÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀỀỂẾưăạảấầẩẫậắằẳẵặẹẻẽềềểếỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợụủứừỬỮỰỲỴÝỶỸửữựỳỵýỷỹ 0-9]/gi;

export const startCommandChars = '^XA';

export const endCommandChars = '^XZ';

export enum REPORT_TYPE_ENUM {
  DAY,
  WEEK,
  MONTH,
  QUARTER,
  YEAR,
}

export const DEFAULT_COLLATION: CollationOptions = {
  locale: 'vi',
};

export const SEPARATOR = ',';

export const MILLISECOND_TO_MINUTE = 1000 * 60;

export const DATE_FORMAT = 'YYYY/MM/DD HH:mm:ss';

export const DATE_FORMAT_NOTIFICATION = 'DD/MM/YYYY';

export const DATE_FORMAT_WITHOUT_HOUR = 'YYYY/MM/DD';

export const DATE_FORMAT_IMPORT = 'DD-MM-YYYY';

export const DATE_FORMAT_EXPORT = 'DD/MM/YYYY';

export const DATE_FORMAT_REGEX =
  /^\d{4}\/(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])$/;

export const DEFAULT_WARNING_SAFE_TIME = 2; // days

export const IT_DEPARTMENT_ID = 4;

export const FORMAT_CODE_PERMISSION = 'MMS_';

export const SUNDAY_DAY = 0;

export enum ACTIVE_ENUM {
  INACTIVE,
  ACTIVE,
}

export enum DISABLE_ENUM {
  EDITABLE,
  DISABLED,
}

export enum GET_ALL_ENUM {
  NO,
  YES,
}

export enum MIME_TYPE_IMAGE_ENUM {
  APNG = 'image/apng',
  AVIF = 'image/avif',
  GIF = 'image/gif',
  JPEG = 'image/jpeg',
  PNG = 'image/png',
  SVG = 'image/svg+xml',
  Web = 'image/webp',
  BMP = '	image/bmp',
}

export enum MIME_TYPE_OFFICE_ENUM {
  PDF = 'application/pdf',
  DOC = 'application/msword',
  DOCX = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  XLSX = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  PPT = 'application/vnd.ms-powerpoint',
  PPTX = 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
}

export enum MIME_TYPE_TEXT_ENUM {
  TXT = 'text/plain',
  CSV = 'text/csv',
}

export const CODE_REGEX = /^[a-zA-Z0-9]+$/;

export enum STATUS_ENUM {
  WAITING_CONFIRM,
  CONFIRM,
  REJECT,
}

export enum REQUIRED_ENUM {
  OPTIONAL,
  REQUIRE,
}

export enum FIXED_ENUM_WITH_PARENT {
  UNFIXED,
  FIXED,
}

export enum DISPLAY_ENUM {
  SHOW,
  HIDDEN,
}
export enum DISPLAY_EXPORT {
  UN_DISPLAY = 0,
  DISPLAY = 1,
}

export enum UPDATE_ENUM {
  NOT_UPDATE,
  CAN_UPDATE,
}

export enum DATA_TYPE_ENUM {
  TEXT,
  CHECKBOX,
  DATE,
  SELECT_BOX_SINGLE,
  SELECT_BOX_MULTIPLE,
  NUMBER,
  RADIO,
  FILE,
}

export enum TEMPLATE_PARENT_ENUM {
  IMPORT = 0,
  EXPORT = 1,
  TRANSFER = 2,
  REQUEST_IMPORT = 3,
  REQUEST_EXPORT = 4,
  REQUEST_TRANSFER = 5,
  INVENTORY = 6, //Llệnh kiểm kê
  TICKET_INVENTORY = 7, //Phiếu kiểm kê
}

export enum AREA_ENUM_TEMPLATE {
  GENERAL = 0,
  DETAIL = 1,
}

//Khai báo code attribute cần theo module
export enum AttributeFixedWithModuleWmsx {
  WMSX_TEMPLATE_CODE = 'wmsxTemplateCode',
  WMSX_REQUEST_CODE = 'requestCode',
  WMSX_WAREHOUSE_IMPORT_CODE = 'warehouseImportCode',
  WMSX_WAREHOUSE_EXPORT_CODE = 'warehouseExportCode',
  WMSX_ITEM_CODE = 'wmsxItemCode',
  WMSX_DEPARTMENT_CODE = 'departmentCode',
  WMSX_ITEM_NAME = 'wmsxItemName',
  WMSX_DESCRIPTION = 'wmsxDescription',
  WMSX_ITEM_UNIT_NAME = 'wmsxItemUnitName',
  WMSX_USER_NOTE = 'wmsxUserNote',
  WMSX_REQUEST_QUANTITY = 'wmsxQuantityRequest',
  WMSX_PRICE = 'wmsxPrice',
  WMSX_AMOUNT = 'wmsxAmount',
  WMSX_QUANTITY_AVAILABLE = 'wmsxQuantityAvailable',
  WMSX_QUANTITY_ACTUAL = 'wmsxQuantityActual',
  WMSX_CREATED_BY = 'wmsxCreatedBy',
  WMSX_CREATED_AT = 'wmsxCreatedAt',
  WMSX_STATUS = 'wmsxStatus',
  WMSX_CREATED_RECEIPT_DATE = 'wmsxCreateReceiptDate',
  WMSX_REMAINNING_QUANTITY_REQUEST = 'wmsxRemainningQuantityRequest',
  //WMSX_PO
  WMSX_LOT_NUMBER = 'wmsxLotNumber',
  WMSX_USER_DELIVERY = 'wmsxUserDelivery', // Nguời giao hàng
  WMSX_REASON = 'wmsxReason',
  WMSX_MFG = 'wmsxManufactureDate',
  WMSX_FILE = 'wmsxFile',
  WMSX_CUSTOMER_IMPORT = 'wmsxCustomerImport', //Số lượng kế hoạch nhập,
  WMSX_CUSTOMER_TRANSFER = 'wmsxCustomerTransfer',
  WMSX_DATE_RECEIPT = 'wmsxReceiptDate', //Ngày chứng từ
  WMSX_ENTRY_QUANTITY = 'wmsxEntryQuantity', //Số lượng thực nhập
  WMSX_REMAINING_QUANTITY = 'wmsxRemainingQuantity', // Số lượng còn lại (số lượng cần cất)
  WMSX_STORED_QUANTITY = 'wmsxStoredQuantity', //Số lượng cất
  WMSX_LOCATOR = 'wmsxLocator', //Ví trí
  WMSX_LOCATOR_EXPORT = 'wmsxLocatorExport',
  WMSX_LOCATOR_IMPORT = 'wmsxLocatorImport',
  WMSX_PO_CODE = 'wmsxPoCode', //Mã phiếu nhập,
  //END PO
  //Attribute chung cho hệ thống
  WMSX_SO_CODE = 'wmsxSoCode',
  WMSX_TRANSFER_CODE = 'wmsxTransferCode',
  WMSX_GENERAL_PRICE = 'wmsxGeneralPrice', //Đơn giá dùng chung cho các phiếu nhâp,xuất,chuyển
  WMSX_GENERAL_AMOUNT = 'wmsxGeneralAmount', //Thành tiền dùng chung cho các phiếu nhập,xuất ,chuyển
  WMSX_GENERAL_DESC = 'wmsxGeneralDescription',
  WMSX_GENERAL_DEPARTMENT = 'wmsxGeneralDepartment',

  //export receipt
  WMSX_PLAN_DELIVERY_DATE = 'wmsxPlanDeliveryDate', // ngay giao du kien
  WMSX_PICK_ITEM_METHOD = 'wmsxPickItemMethod', // chien thuat lay hang
  WMSX_PLAN_EXPORT_QUANTITY = 'wmsxPlanExportQuantity', // so luong ke hoach xuat
  WMSX_TRANSFER_UNIT = 'wmsxTransferUnit', // don vi van chuyen
  WMSX_REQUEST_DEPARTMENT = 'wmsxRequestDepartment', // bo phan yeu cau
  WMSX_REQUEST_DESCRIPTION = 'wmsxRequestDescription', // mo ta yeu cau
  WMSX_IMPORT_DATE = 'wmsxImportDate',
  WMSX_ORDER_TYPE = 'wmsxOrderType',
  WMSX_EXPECTED_RELEASE_DATE = 'wmsxExpectedReleaseDate',

  //Transfer
  WMSX_TYPE_TRAMSFER = 'wmsxTypeTransfer',

  //Kiểm kê (Inventory)
  WMSX_INVENTORY_CODE = 'wmsxInvenCode', //Mã lệnh kiểm kê
  WMSX_INVENTORY_NAME = 'wmsxInvenName', //Tên lệnh kiểm kê
  WMSX_INVENTORY_TYPE = 'wmsxInvenType', //Loại lệnh kỉêm kê
  WMSX_INVENTORY_WAREHOUSE = 'wmsxInvenWarehouse', //kho
  WMSX_INVENTORY_USER = 'wmsxInvenUser', //Người thực hiện
  WMSX_INVENTORY_DATE = 'wmsxInvenDate', //Ngày chốt kì
  WMSX_INVENTORY_DATE_EXPECT = 'wmsxInvenDateExpected', //Ngày kiếm kê dự kiến
  WMSX_INVENTORY_DATE_EXPECT_TO = 'wmsxInvenDateExpectedTo', //Ngày kiếm kê dự kiến
  WMSX_INVENTORY_BLOCK_TICKET = 'wmsxInvenBlockTIcket', //Chặn nhập ,xuất
  WMSX_INVENTORY_FORM = 'wmsxInvenForm', //Hình thức kiểm kê
  WMSX_APPROVER = 'wmsxApprover', //Người xác nhận lệnh,
  WMSX_APPROVED_AT = 'wmsxApprovedAt', //Ngày xác nhận lệnh
  WMSX_COMPLETER = 'wmsxCompleter', //Nguoi hoan thanh lenh
  WMSX_COMPLETED_AT = 'wmsxCompletedAt', //Ngay hoan thanh lenh

  //Phiếu kiểm kê
  WMSX_TICK_INVENTORY_USER = 'wmsxTicketInvenUser', //Người kiểm kê,
  WMSX_TICK_INVENTORY_SHARE_USER = 'wmsxTickInvenShareUser', //Chia người theo từng phiếu,
  WMSX_TICK_INVENTORY_SHARE = 'wmsxTickInvenShare', //Chia theo phiếu
  WMSX_TICKET_INVENTORY_CODE = 'wmsxTickInvenCode', //Mã phiếu kiểm kê
  WMSX_TICKET_INVENTORY_LOCATOR = 'wmsxTickInvenLocator', //Vùng kiểm kê,
  WMSX_TICKET_INVENTORY_QUANTITY_PERIOD = 'wmsxTickInvenQuantityPeriod', //Số lượng chốt kì
  WMSX_TICKET_INVENTORY_QUANTITY = 'wmsxTickInvenQuantity', //Số lượng kiểm kê
  WMSX_TICKET_INVENTORY_RE_QUANTITY = 'wmsxTickInventoryReQuantity', //Sl kiểm kê lại
  WMSX_TICKET_INVENTORY_LOCATOR_HEADER = 'wmsxHeaderTicketInventoryLocator', // Vị trí kiểm kê khong dung
  WMSX_TICKET_INVENTORY_WAREHOUSE = 'wmsxTicketInventoryWarehouse', //KLho kiểm kê, Khong dung
  WMSX_TICKET_INVENTORY_IS_CREATE = 'wmsxIsCreateTicketInventory',
}

export enum AttributeFixedWithModuleMesx {
  MESX_CODE = 'mesxCode',
  MESX_STATUS = 'mesxStatus',
  MESX_ITEM_ID = 'mesxItemId',
  MESX_REQUEST_USER_ID = 'mesxRequestUserId',
  MESX_BOM_VERSION_ID = 'mesxBomVersionId',
  MESX_APPROVER_ID = 'mesxApprovedId',
  MESX_ITEM_UNIT_ID = 'mesxItemUnitId',

  MESX_NOTE = 'mesxNote',
  MESX_REQUEST_DATE = 'mesxRequestDate',
  MESX_REQUEST_USER_NAME = 'mesxRequestUserName',
  MESX_ITEM_CODE = 'mesxItemCode',
  MESX_ITEM_NAME = 'mesxItemName',
  MESX_ITEM_UNIT_NAME = 'mesxItemUnitName',
  MESX_BOM_VERSION_CODE = 'mesxBomVersionCode',
  MESX_QUANTITY = 'mesxQuantity',
  MESX_REQUEST_QUANTITY = 'mesxRequestQuantity',
  MESX_ACTUAL_QUANTITY = 'mesxActualQuantity',
  MESX_DEADLINE = 'mesxDeadline',
  MESX_APPROVED_AT = 'mesxApprovedAt',
  MESX_IS_HAS_PLAN = 'mesxIsHasPlan',
  MESX_FILES = 'mesxFiles',

  MESX_ORDER_AT = 'mesxOrderAt',
  MESX_ORDER_CODE = 'mesxOrderCode',
  MESX_ORDER_NAME = 'mesxOrderName',
  MESX_CURRENCY_UNIT_ID = 'mesxCurrencyUnitId',
  MESX_EXCHANGE_RATE = 'mesxExchangeRate',
  MESX_ORDER_TYPE = 'mesxOrderType',
  MESX_PURCHASE_STAFF_ID = 'mesxPurchaseStaffId',
  MESX_VENDOR_ID = 'mesxVendorId',
  MESX_PHONE_NUMBER = 'mesxPhoneNumber',
  MESX_TAX_NUMBER = 'mesxTaxNumber',
  MESX_PURCHASE_PRICE = 'mesxPurchasePrice',
  MESX_PO_QUANTITY = 'mesxPOQuantity',
  MESX_RECEIVER_PHONE_NUMBER = 'mesxReceiverPhoneNumber',
  MESX_PLAN_DELIVERY_AT = 'mesxPlanDeliveryAt',
  MESX_DISCOUNT = 'mesxDiscount',
  MESX_TOTAL_AMOUNT = 'mesxTotalAmount',
  MESX_ONE_TIME_DELIVERY = 'mesxOneTimeDelivery',
  MESX_RECEIVER = 'mesxReceiver',
  MESX_SHIPPING_METHOD_ID = 'mesxShippingMethodId',
  MESX_ADDRESS = 'mesxAddress',
  MESX_DELIVER_AT = 'mesxDeliverAt',
  MESX_PAY_AT = 'mesxPayAt',
  MESX_PAYMENT_METHOD_ID = 'mesxPaymentMethodId',
  MESX_PAYMENT_RATE = 'mesxPaymentRate',
  MESX_TOTAL_PAYMENT_AMOUNT = 'mesxTotalPaymentAmount',
  MESX_USER_ACCOUNT = 'mesxUserAccount',
  MESX_DESCRIPTION = 'mesxDescription',
  //invoice
  MESX_CREATED_AT = 'mesxCreatedAt',
  MESX_UPDATE_BY_USER_ID = 'mesxUpdateByUserId',
  MESX_INVOICE_CODE = 'mesxInvoiceCode',
  MESX_INVOICE_VALUE = 'mesxInvoiceValue',
  //manufacturing import export request order
  MESX_MANUFACTURING_ORDER_ID = 'mesxManufacturingOrderId',
  MESX_MANUFACTURING_ORDER_CODE = 'mesxManufacturingOrderCode',
  MESX_ITEM_TYPE_ID = 'mesxItemTypeId',
  MESX_ITEM_TYPE_NAME = 'mesxItemTypeName',
  MESX_DEPARTMENT_NAME = 'mesxDepartmentName',
  MESX_APPROVER_NAME = 'mesxApproverName',
  MESX_WAREHOUSE_ID = 'mesxWarehouseImportId',
  MESX_WAREHOUSE_NAME = 'mesxWarehouseImportName',
  MESX_PRODUCTION_ORDER_EXPORT_ID = 'mesxProductionOrderExportId',
  MESX_PRODUCTION_ORDER_IMPORT_ID = 'mesxProductionOrderImportId',
}

export enum TableFixed {
  WAREHOUSES = 'warehouses',
  ITEMS = 'items',
  REQUESTS = 'requests',
  DEPARTMENT_SETTINGS = 'department_settings',
  USERS = 'users',
  TEMPLATES = 'templates',
  LOCATORS = 'locators',
  WAREHOUSE_REQUEST_ORDERS = 'warehouse_request_orders',
  REASONS = 'reasons',
  ITEM_WAREHOUSE_STOCK = 'items-warehouse-stocks',
}

export enum GroupFixed {
  WMSX_GROUP = 'GR0001',
  MEEX_GROUP = 'GR0002',
  PO_DETAIL_ITEM_GROUP = 'GR0003',
  PO_DETAIL_DELIVERY_GROUP = 'GR0004',
  PO_DETAIL_PAYMENT_GROUP = 'GR0005',
  PO_DETAIL_INVOICE_GROUP = 'GR0006',
}

//Attribute được fixed theo template
export const ATTRIBUTE_FIXED_PARENT_WMSX = [
  ...Object.values(AttributeFixedWithModuleWmsx),
];

export const ATTRIBUTE_FIXED_PARENT_MESX = [
  ...Object.values(AttributeFixedWithModuleMesx),
];

export enum MODULE_ENUM {
  WMSX = 0,
  MESX = 1,
  MMS = 2,
  QMS = 3,
}

//Chỗ define thông tin attribute
export const ATTRIBUTE_CONFIG = [
  {
    _id: '6490029ef9c5580ec7309590',
    name: 'Loại nghiệp vụ',
    code: AttributeFixedWithModuleWmsx.WMSX_TEMPLATE_CODE,
    dataType: 3,
    module: 0,
  },
  {
    _id: '507f191e810c19729de860ea',
    name: 'Mã sản phẩm',
    code: AttributeFixedWithModuleWmsx.WMSX_ITEM_CODE,
    dataType: 3,
    module: 0,
  },
  {
    _id: '648ffea9fb4a1865850e4474',
    name: 'Tên sản phẩm',
    code: AttributeFixedWithModuleWmsx.WMSX_ITEM_NAME,
    dataType: 0,
    module: 0,
  },
  {
    _id: '648ffea9fb4a1865850e4476',
    name: 'ĐVT',
    code: AttributeFixedWithModuleWmsx.WMSX_ITEM_UNIT_NAME,
    dataType: 0,
    module: 0,
  },
  {
    _id: '648ffea9fb4a1865850e4477',
    name: 'SL yêu cầu',
    code: AttributeFixedWithModuleWmsx.WMSX_REQUEST_QUANTITY,
    dataType: 5,
    module: 0,
  },
  {
    _id: '64ae1ce168c26da945826d96',
    name: 'Tệp đính kèm',
    code: AttributeFixedWithModuleWmsx.WMSX_FILE,
    dataType: DATA_TYPE_ENUM.FILE,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64ad1379db387e98e75db94d',
    name: 'Ngày chứng từ',
    code: AttributeFixedWithModuleWmsx.WMSX_DATE_RECEIPT,
    dataType: DATA_TYPE_ENUM.DATE,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64ad1814b64b77d43dcef3df',
    name: 'Mã phiếu nhập',
    code: AttributeFixedWithModuleWmsx.WMSX_PO_CODE,
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.WMSX,
  },

  {
    _id: '64abb4605d3eaf652808ab1b',
    name: 'Mã phiếu xuất',
    code: AttributeFixedWithModuleWmsx.WMSX_SO_CODE,
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64ae4c0d2542b8bc92fc43c5',
    name: 'Mã phiếu chuyển',
    code: AttributeFixedWithModuleWmsx.WMSX_TRANSFER_CODE,
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '648ffea9fb4a1865850e4480',
    name: 'SL khả dụng',
    code: AttributeFixedWithModuleWmsx.WMSX_QUANTITY_AVAILABLE,
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '6499633a4da9bc38261e6c21',
    name: 'SL yêu cầu',
    code: AttributeFixedWithModuleWmsx.WMSX_REMAINNING_QUANTITY_REQUEST,
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64a66e000f5092414890eb62',
    name: 'SL cần cất',
    code: AttributeFixedWithModuleWmsx.WMSX_REMAINING_QUANTITY,
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64a66e000f5092414890eb64',
    name: 'SL cất',
    code: AttributeFixedWithModuleWmsx.WMSX_STORED_QUANTITY,
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64a66e000f5092414890eb65',
    name: 'SL thực nhập',
    code: AttributeFixedWithModuleWmsx.WMSX_ENTRY_QUANTITY,
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64a66e000f5092414890eb66',
    name: 'Vị trí',
    code: AttributeFixedWithModuleWmsx.WMSX_LOCATOR,
    dataType: DATA_TYPE_ENUM.SELECT_BOX_SINGLE,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64a66e000f5092414890eb67',
    name: 'Vị trí xuất',
    code: AttributeFixedWithModuleWmsx.WMSX_LOCATOR_EXPORT,
    dataType: DATA_TYPE_ENUM.SELECT_BOX_SINGLE,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64a66e000f5092414890eb68',
    name: 'Vị trí nhập',
    code: AttributeFixedWithModuleWmsx.WMSX_LOCATOR_IMPORT,
    dataType: DATA_TYPE_ENUM.SELECT_BOX_SINGLE,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '648ffea9fb4a1865850e4478',
    name: 'Đơn giá yêu cầu',
    code: AttributeFixedWithModuleWmsx.WMSX_PRICE,
    dataType: 5,
    module: 0,
  },
  {
    _id: '648ffea9fb4a1865850e4479',
    name: 'Thành tiền yêu cầu',
    code: AttributeFixedWithModuleWmsx.WMSX_AMOUNT,
    dataType: 5,
    module: 0,
  },

  {
    _id: '64b4f0cafa42bcabff67d1e3',
    name: 'Thành tiền',
    code: AttributeFixedWithModuleWmsx.WMSX_GENERAL_AMOUNT,
    dataType: 5,
    module: 0,
  },

  {
    _id: '649007b6fb4a1865850e506f',
    name: 'SL thực tế',
    code: AttributeFixedWithModuleWmsx.WMSX_QUANTITY_ACTUAL,
    dataType: 5,
    module: 0,
  },
  {
    name: 'Người yêu cầu ghi chú',
    code: AttributeFixedWithModuleWmsx.WMSX_USER_NOTE,
    dataType: 0,
    module: 0,
  },
  {
    _id: '649026d9fb4a1865850e703f',
    name: 'Người tạo',
    code: AttributeFixedWithModuleWmsx.WMSX_CREATED_BY,
    dataType: 0,
    module: 0,
  },
  {
    _id: '649026d9fb4a1865850e703e',
    name: 'Ngày tạo',
    code: AttributeFixedWithModuleWmsx.WMSX_CREATED_AT,
    dataType: 0,
    module: 0,
  },
  {
    _id: '6493ac08e0a01bffe529a317',
    name: 'Trạng thái',
    code: AttributeFixedWithModuleWmsx.WMSX_STATUS,
    dataType: 5,
    module: 0,
  },
  {
    _id: '507f1f77bcf86cd799439011',
    name: 'Mã yêu cầu',
    code: AttributeFixedWithModuleWmsx.WMSX_REQUEST_CODE,
    dataType: 3,
    module: 0,
  },
  {
    _id: '00000020f51bb4362eee2a4d',
    name: 'Kho nhập',
    code: AttributeFixedWithModuleWmsx.WMSX_WAREHOUSE_IMPORT_CODE,
    dataType: 3,
    module: 0,
  },
  {
    _id: '507f191e810c19729de860eb',
    name: 'Kho xuất',
    code: AttributeFixedWithModuleWmsx.WMSX_WAREHOUSE_EXPORT_CODE,
    dataType: 3,
    module: 0,
  },
  {
    _id: '646d5a885c5fadaa7a454964',
    name: 'Mô tả yêu cầu',
    code: AttributeFixedWithModuleWmsx.WMSX_DESCRIPTION,
    dataType: 0,
    module: 0,
  },
  {
    _id: '64ad11dc0ffe77784fa2de09',
    name: 'Người giao hàng',
    code: AttributeFixedWithModuleWmsx.WMSX_USER_DELIVERY,
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '646d5a885c5fadaa7a454965',
    name: 'Đơn vị (Bộ phận) yêu cầu',
    code: AttributeFixedWithModuleWmsx.WMSX_DEPARTMENT_CODE,
    dataType: 3,
    module: 0,
  },
  {
    _id: '64a645e59dec34b077ed1860',
    name: 'Số lô',
    code: AttributeFixedWithModuleWmsx.WMSX_LOT_NUMBER,
    dataType: 0,
    module: 0,
  },
  {
    _id: '64a65b125ab286ddad0aa582',
    name: 'Lý do',
    code: AttributeFixedWithModuleWmsx.WMSX_REASON,
    dataType: 3,
    module: 0,
  },
  {
    _id: '64a65b1b5ab286ddad0aa584',
    name: 'Ngày chứng từ',
    code: AttributeFixedWithModuleWmsx.WMSX_CREATED_RECEIPT_DATE,
    dataType: 2,
    module: 0,
  },
  {
    _id: '64a65b1b5ab286ddad0aa585',
    name: 'Ngày sản xuất',
    code: AttributeFixedWithModuleWmsx.WMSX_MFG,
    dataType: 2,
    module: 0,
  },
  {
    _id: '64a65b1b5ab286ddad0aa586',
    name: 'SLKH nhập',
    code: AttributeFixedWithModuleWmsx.WMSX_CUSTOMER_IMPORT,
    dataType: DATA_TYPE_ENUM.TEXT,
    module: 0,
  },
  {
    _id: '64a65b1b5ab286ddad0aa587',
    name: 'SLKH chyển',
    code: AttributeFixedWithModuleWmsx.WMSX_CUSTOMER_TRANSFER,
    dataType: DATA_TYPE_ENUM.TEXT,
    module: 0,
  },
  {
    _id: '64ae576536470eb7d34a6b14',
    name: 'Đơn vị (Bộ phận)',
    code: AttributeFixedWithModuleWmsx.WMSX_GENERAL_DEPARTMENT,
    dataType: 3,
    module: 0,
  },
  {
    _id: '64ae55d63cb2ec3244dfe3cf',
    name: 'Mô tả',
    code: AttributeFixedWithModuleWmsx.WMSX_GENERAL_DESC,
    dataType: 0,
    module: 0,
  },
  {
    _id: '64ae4c582542b8bc92fc43e4',
    name: 'Đơn giá',
    code: AttributeFixedWithModuleWmsx.WMSX_GENERAL_PRICE,
    dataType: 5,
    module: 0,
  },
  {
    _id: '64a7d1f3181e49b24b4a56e5',
    code: AttributeFixedWithModuleWmsx.WMSX_PLAN_DELIVERY_DATE,
    name: 'Ngày giao dự kiến',
    dataType: DATA_TYPE_ENUM.DATE,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56e6',
    code: AttributeFixedWithModuleWmsx.WMSX_PICK_ITEM_METHOD,
    name: 'Chiến thuật lấy hàng',
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56e7',
    code: AttributeFixedWithModuleWmsx.WMSX_PLAN_EXPORT_QUANTITY,
    name: 'SLKH xuất',
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56e8',
    code: AttributeFixedWithModuleWmsx.WMSX_TRANSFER_UNIT,
    name: 'Hãng vận chuyển',
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56e9',
    code: AttributeFixedWithModuleWmsx.WMSX_REQUEST_DEPARTMENT,
    name: 'Đơn vị(bộ phận) yêu cầu',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '5effaa5662679b5af2c58829',
    code: AttributeFixedWithModuleWmsx.WMSX_REQUEST_DESCRIPTION,
    name: 'Mô tả yêu cầu',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '5effaa5662679b5af2c58830',
    code: AttributeFixedWithModuleWmsx.WMSX_IMPORT_DATE,
    name: 'Ngày nhập kho',
    dataType: DATA_TYPE_ENUM.DATE,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '5effaa5662679b5af2c58840',
    code: AttributeFixedWithModuleWmsx.WMSX_ORDER_TYPE,
    name: 'Loại lệnh',
    dataType: DATA_TYPE_ENUM.SELECT_BOX_SINGLE,
    module: MODULE_ENUM.WMSX,
  },

  {
    _id: '5effaa5662679b5af2c58831',
    code: AttributeFixedWithModuleWmsx.WMSX_EXPECTED_RELEASE_DATE,
    name: 'Ngày xuất dự kiến',
    dataType: DATA_TYPE_ENUM.DATE,
    module: MODULE_ENUM.WMSX,
  },
  //Kiểm kê
  {
    _id: '64e2cdd5bf4bfb1f9804d872',
    code: AttributeFixedWithModuleWmsx.WMSX_INVENTORY_CODE,
    name: 'Mã lệnh kiểm kê',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e2cdd5bf4bfb1f9804d873',
    code: AttributeFixedWithModuleWmsx.WMSX_INVENTORY_NAME,
    name: 'Tên lệnh kiểm kê',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e2cdd5bf4bfb1f9804d874',
    code: AttributeFixedWithModuleWmsx.WMSX_INVENTORY_TYPE,
    name: 'Loại kiểm kê',
    dataType: DATA_TYPE_ENUM.SELECT_BOX_SINGLE,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e2cdd5bf4bfb1f9804d875',
    code: AttributeFixedWithModuleWmsx.WMSX_INVENTORY_WAREHOUSE,
    name: 'Kho',
    dataType: DATA_TYPE_ENUM.SELECT_BOX_MULTIPLE,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e2cdd5bf4bfb1f9804d876',
    code: AttributeFixedWithModuleWmsx.WMSX_INVENTORY_USER,
    name: 'Người thực hiện',
    dataType: DATA_TYPE_ENUM.SELECT_BOX_MULTIPLE,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e2cdd5bf4bfb1f9804d877',
    code: AttributeFixedWithModuleWmsx.WMSX_INVENTORY_DATE,
    name: 'Ngày chốt kỳ',
    dataType: DATA_TYPE_ENUM.DATE,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e2cdd5bf4bfb1f9804d878',
    code: AttributeFixedWithModuleWmsx.WMSX_INVENTORY_DATE_EXPECT,
    name: 'Ngày kiểm kê dự kiến',
    dataType: DATA_TYPE_ENUM.DATE,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e2cdd5bf4bfb1f9804d879',
    code: AttributeFixedWithModuleWmsx.WMSX_INVENTORY_BLOCK_TICKET,
    name: 'Chặn nhập xuất',
    dataType: DATA_TYPE_ENUM.RADIO,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e2cdd5bf4bfb1f9804d87a',
    code: AttributeFixedWithModuleWmsx.WMSX_INVENTORY_FORM,
    name: 'Hình thức kiểm kê',
    dataType: DATA_TYPE_ENUM.SELECT_BOX_SINGLE,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e2cdd5bf4bfb1f9804d87b',
    code: AttributeFixedWithModuleWmsx.WMSX_TICK_INVENTORY_USER,
    name: 'Người kiểm kê',
    dataType: DATA_TYPE_ENUM.SELECT_BOX_SINGLE,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e2cdd5bf4bfb1f9804d87c',
    code: AttributeFixedWithModuleWmsx.WMSX_TICK_INVENTORY_SHARE_USER,
    name: 'Chia người theo từng phiếu',
    dataType: DATA_TYPE_ENUM.CHECKBOX,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e2cdd5bf4bfb1f9804d87d',
    code: AttributeFixedWithModuleWmsx.WMSX_TICK_INVENTORY_SHARE,
    name: 'Chi theo phiếu',
    dataType: DATA_TYPE_ENUM.SELECT_BOX_SINGLE,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e2dcb2bf4bfb1f9804d87e',
    code: AttributeFixedWithModuleWmsx.WMSX_TICKET_INVENTORY_CODE,
    name: 'Mã phiếu kiểm kê',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e2dcb2bf4bfb1f9804d87f',
    code: AttributeFixedWithModuleWmsx.WMSX_TICKET_INVENTORY_LOCATOR,
    name: 'Vùng kiểm kê',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e2dcb2bf4bfb1f9804d880',
    code: AttributeFixedWithModuleWmsx.WMSX_TICKET_INVENTORY_QUANTITY_PERIOD,
    name: 'SL chốt kì',
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.WMSX,
  },

  {
    _id: '64e2dcb2bf4bfb1f9804d881',
    code: AttributeFixedWithModuleWmsx.WMSX_TICKET_INVENTORY_QUANTITY,
    name: 'SL kiểm kê',
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e2dcb2bf4bfb1f9804d882',
    code: AttributeFixedWithModuleWmsx.WMSX_TICKET_INVENTORY_RE_QUANTITY,
    name: 'SL kiểm kê lại',
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e2dcb2bf4bfb1f9804d883',
    code: AttributeFixedWithModuleWmsx.WMSX_INVENTORY_DATE_EXPECT_TO,
    name: 'Ngày kiểm kê dự kiến',
    dataType: DATA_TYPE_ENUM.DATE,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e2dcb2bf4bfb1f9804d884',
    code: AttributeFixedWithModuleWmsx.WMSX_APPROVER,
    name: 'Người xác nhận lệnh',
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e2dcb2bf4bfb1f9804d885',
    code: AttributeFixedWithModuleWmsx.WMSX_APPROVED_AT,
    name: 'Ngày xác nhận lệnh',
    dataType: DATA_TYPE_ENUM.DATE,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e2dcb2bf4bfb1f9804d886',
    code: AttributeFixedWithModuleWmsx.WMSX_COMPLETER,
    name: 'Người hoàn thành lệnh',
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e2dcb2bf4bfb1f9804d887',
    code: AttributeFixedWithModuleWmsx.WMSX_COMPLETED_AT,
    name: 'Ngày hoàn thành lệnh',
    dataType: DATA_TYPE_ENUM.DATE,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e5a7f02ac87a110609ae88',
    code: AttributeFixedWithModuleWmsx.WMSX_TICKET_INVENTORY_LOCATOR_HEADER,
    name: 'Vị trí kiểm kê',
    dataType: DATA_TYPE_ENUM.SELECT_BOX_SINGLE,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e5a7f02ac87a110609ae89',
    code: AttributeFixedWithModuleWmsx.WMSX_TICKET_INVENTORY_WAREHOUSE,
    name: 'Kho kiểm kê',
    dataType: DATA_TYPE_ENUM.SELECT_BOX_SINGLE,
    module: MODULE_ENUM.WMSX,
  },
  {
    _id: '64e5a7f02ac87a110609ae8a',
    code: AttributeFixedWithModuleWmsx.WMSX_TICKET_INVENTORY_IS_CREATE,
    name: 'Check box tạo phiếu kiểm kê',
    dataType: DATA_TYPE_ENUM.CHECKBOX,
    module: MODULE_ENUM.WMSX,
  },
  //mesx-manufacturing-request-order
  {
    _id: '648930ff963697d7a203eec8',
    name: 'Id SP',
    code: AttributeFixedWithModuleMesx.MESX_ITEM_ID,
    dataType: 3,
    module: 1,
  },
  {
    _id: '6489310b963697d7a203eec9',
    name: 'Người yêu cầu',
    code: AttributeFixedWithModuleMesx.MESX_REQUEST_USER_ID,
    dataType: 3,
    module: 1,
  },
  {
    _id: '64893112963697d7a203eeca',
    name: 'Phiên bản BOM',
    code: AttributeFixedWithModuleMesx.MESX_BOM_VERSION_ID,
    dataType: 3,
    module: 1,
  },
  {
    _id: '648930ff963697d7a203eedb',
    name: 'Id người phê duyệt',
    code: AttributeFixedWithModuleMesx.MESX_APPROVER_ID,
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: 1,
  },
  {
    _id: '64c8d7601c61e7e2d10819e1',
    name: 'Người phê duyệt',
    code: AttributeFixedWithModuleMesx.MESX_APPROVER_NAME,
    dataType: DATA_TYPE_ENUM.TEXT,
    module: 1,
  },
  {
    _id: '648930ff963697d7a203eece',
    name: 'Ngày phê duyệt',
    code: AttributeFixedWithModuleMesx.MESX_APPROVED_AT,
    dataType: 2,
    module: 1,
  },
  {
    _id: '648930ff963697d7a203eecf',
    name: 'Người yêu cầu',
    code: AttributeFixedWithModuleMesx.MESX_REQUEST_USER_ID,
    dataType: 3,
    module: 1,
  },
  {
    _id: '6493ec9824ad29706be0ce5e',
    name: 'Người yêu cầu',
    code: AttributeFixedWithModuleMesx.MESX_REQUEST_USER_NAME,
    dataType: DATA_TYPE_ENUM.TEXT,
    module: 1,
  },
  {
    _id: '6493ec9824ad29706be0ce4e',
    name: 'ĐVT',
    code: AttributeFixedWithModuleMesx.MESX_ITEM_UNIT_ID,
    dataType: 3,
    module: 1,
  },
  {
    _id: '6493ec9824ad29706be0ce4f',
    name: 'Ghi chú',
    code: AttributeFixedWithModuleMesx.MESX_NOTE,
    dataType: 0,
    module: 1,
  },

  {
    _id: '6493ec9824ad29706be0ce4c',
    name: 'Mã yêu cầu',
    code: AttributeFixedWithModuleMesx.MESX_CODE,
    dataType: 0,
    module: 1,
  },
  {
    _id: '6493ec9824ad29706be0ce50',
    name: 'Ngày yêu cầu',
    code: AttributeFixedWithModuleMesx.MESX_REQUEST_DATE,
    dataType: 2,
    module: 1,
  },
  {
    _id: '648930ff963697d7a203eed1',
    name: 'Mã SP',
    code: AttributeFixedWithModuleMesx.MESX_ITEM_CODE,
    dataType: DATA_TYPE_ENUM.TEXT,
    module: 1,
  },
  {
    _id: '648930ff963697d7a203eed2',
    name: 'Tên SP',
    code: AttributeFixedWithModuleMesx.MESX_ITEM_NAME,
    dataType: 0,
    module: 1,
  },
  {
    _id: '648930ff963697d7a203eed3',
    name: 'Tên ĐVT',
    code: AttributeFixedWithModuleMesx.MESX_ITEM_UNIT_NAME,
    dataType: DATA_TYPE_ENUM.TEXT,
    module: 1,
  },
  {
    _id: '648930ff963697d7a203eed4',
    name: 'Phiên bản bom',
    code: AttributeFixedWithModuleMesx.MESX_BOM_VERSION_CODE,
    dataType: DATA_TYPE_ENUM.TEXT,
    module: 1,
  },
  {
    _id: '648930ff963697d7a203eed5',
    name: 'SL yêu cầu SX',
    code: AttributeFixedWithModuleMesx.MESX_QUANTITY,
    dataType: 5,
    module: 1,
  },
  {
    _id: '648930ff963697d7a203eed5',
    name: 'SL yêu cầu SX',
    code: AttributeFixedWithModuleMesx.MESX_QUANTITY,
    dataType: 5,
    module: 1,
  },
  {
    _id: '64c789e53293d2be4a026e43',
    name: 'SL yêu cầu',
    code: AttributeFixedWithModuleMesx.MESX_REQUEST_QUANTITY,
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: 1,
  },
  {
    _id: '648930ff963f97d7a203eed5',
    name: 'SL đã sản xuất',
    code: AttributeFixedWithModuleMesx.MESX_ACTUAL_QUANTITY,
    dataType: 5,
    module: 1,
  },
  {
    _id: '648930ff963697d7a203eed7',
    name: 'Ngày cần',
    code: AttributeFixedWithModuleMesx.MESX_DEADLINE,
    dataType: 2,
    module: 1,
  },
  {
    _id: '648930ff963697d7a203eed8',
    name: 'Ngày phê duyệt',
    code: AttributeFixedWithModuleMesx.MESX_APPROVED_AT,
    dataType: 2,
    module: 1,
  },
  {
    _id: '6493ec9824ad29706be0ce4d',
    name: 'Trạng thái',
    code: AttributeFixedWithModuleMesx.MESX_STATUS,
    dataType: 0,
    module: 1,
  },
  {
    _id: '6493ec9824ad29706be0ce5e',
    name: 'Người yêu cầu',
    code: AttributeFixedWithModuleMesx.MESX_REQUEST_USER_NAME,
    dataType: DATA_TYPE_ENUM.TEXT,
    module: 1,
  },
  {
    name: 'Đã kế hoạch',
    code: AttributeFixedWithModuleMesx.MESX_IS_HAS_PLAN,
    dataType: 3,
    module: 1,
  },
  {
    _id: '64a52a15aae407b0aa015411',
    name: 'File đính kèm',
    code: AttributeFixedWithModuleMesx.MESX_FILES,
    dataType: 7,
    module: 1,
  },
  {
    _id: '64a7d1f3181e49b24b4a56c0',
    code: AttributeFixedWithModuleMesx.MESX_ORDER_AT,
    name: 'Ngày đặt hàng',
    dataType: DATA_TYPE_ENUM.DATE,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56c0',
    code: AttributeFixedWithModuleMesx.MESX_ORDER_AT,
    name: 'Ngày đặt hàng',
    dataType: DATA_TYPE_ENUM.DATE,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56d5',
    code: AttributeFixedWithModuleMesx.MESX_ORDER_CODE,
    name: 'Mã đơn hàng',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56d6',
    code: AttributeFixedWithModuleMesx.MESX_ORDER_NAME,
    name: 'Tên đơn hàng',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56c1',
    code: AttributeFixedWithModuleMesx.MESX_CURRENCY_UNIT_ID,
    name: 'Loại tiền',
    dataType: DATA_TYPE_ENUM.SELECT_BOX_SINGLE,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56c2',
    code: AttributeFixedWithModuleMesx.MESX_EXCHANGE_RATE,
    name: 'Tỷ giá',
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56c3',
    code: AttributeFixedWithModuleMesx.MESX_ORDER_TYPE,
    name: 'Loại đơn hàng',
    dataType: DATA_TYPE_ENUM.SELECT_BOX_SINGLE,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56c4',
    code: AttributeFixedWithModuleMesx.MESX_PURCHASE_STAFF_ID,
    name: 'Nhân viên mua hàng',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56c5',
    code: AttributeFixedWithModuleMesx.MESX_VENDOR_ID,
    name: 'Nhà cung cấp',
    dataType: DATA_TYPE_ENUM.SELECT_BOX_SINGLE,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56c6',
    code: AttributeFixedWithModuleMesx.MESX_PHONE_NUMBER,
    name: 'Số điện thoại',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56c7',
    code: AttributeFixedWithModuleMesx.MESX_TAX_NUMBER,
    name: 'Mã số thuế',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56c8',
    code: AttributeFixedWithModuleMesx.MESX_PURCHASE_PRICE,
    name: 'Giá mua',
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56c9',
    code: AttributeFixedWithModuleMesx.MESX_DISCOUNT,
    name: 'Chiết khấu',
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56ca',
    code: AttributeFixedWithModuleMesx.MESX_TOTAL_AMOUNT,
    name: 'Tổng tiền',
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56cb',
    code: AttributeFixedWithModuleMesx.MESX_ONE_TIME_DELIVERY,
    name: 'Giao hàng 1 lần',
    dataType: DATA_TYPE_ENUM.CHECKBOX,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56cc',
    code: AttributeFixedWithModuleMesx.MESX_RECEIVER,
    name: 'Người nhận',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56cd',
    code: AttributeFixedWithModuleMesx.MESX_SHIPPING_METHOD_ID,
    name: 'Phương thức vận chuyển',
    dataType: DATA_TYPE_ENUM.SELECT_BOX_SINGLE,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56ce',
    code: AttributeFixedWithModuleMesx.MESX_ADDRESS,
    name: 'Địa chỉ',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56cf',
    code: AttributeFixedWithModuleMesx.MESX_DELIVER_AT,
    name: 'Ngày nhận hàng',
    dataType: DATA_TYPE_ENUM.DATE,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56d0',
    code: AttributeFixedWithModuleMesx.MESX_PAY_AT,
    name: 'Ngày dự kiến thanh toán',
    dataType: DATA_TYPE_ENUM.DATE,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56d1',
    code: AttributeFixedWithModuleMesx.MESX_PAYMENT_METHOD_ID,
    name: 'Phương thức thanh toán',
    dataType: DATA_TYPE_ENUM.SELECT_BOX_SINGLE,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56d2',
    code: AttributeFixedWithModuleMesx.MESX_PAYMENT_RATE,
    name: '% Thanh toán',
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56d3',
    code: AttributeFixedWithModuleMesx.MESX_TOTAL_PAYMENT_AMOUNT,
    name: 'Thành tiền',
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56d4',
    code: AttributeFixedWithModuleMesx.MESX_USER_ACCOUNT,
    name: 'Tài khoản',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56d7',
    code: AttributeFixedWithModuleMesx.MESX_PO_QUANTITY,
    name: 'Số lượng',
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56d8',
    code: AttributeFixedWithModuleMesx.MESX_RECEIVER_PHONE_NUMBER,
    name: 'Số điện thoại',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56d9',
    code: AttributeFixedWithModuleMesx.MESX_PLAN_DELIVERY_AT,
    name: 'Kế hoạch giao hàng',
    dataType: DATA_TYPE_ENUM.DATE,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56e0',
    code: AttributeFixedWithModuleMesx.MESX_DESCRIPTION,
    name: 'Mô tả',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56e1',
    code: AttributeFixedWithModuleMesx.MESX_CREATED_AT,
    name: 'Ngày tạo',
    dataType: DATA_TYPE_ENUM.DATE,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56e2',
    code: AttributeFixedWithModuleMesx.MESX_UPDATE_BY_USER_ID,
    name: 'Người cập nhật',
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56e3',
    code: AttributeFixedWithModuleMesx.MESX_INVOICE_CODE,
    name: 'Mã hóa đơn',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64a7d1f3181e49b24b4a56e4',
    code: AttributeFixedWithModuleMesx.MESX_INVOICE_VALUE,
    name: 'Giá trị hóa đơn',
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64c7890e3293d2be4a026e41',
    name: 'Id Lệnh sản xuất',
    code: AttributeFixedWithModuleMesx.MESX_MANUFACTURING_ORDER_ID,
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: 1,
  },
  {
    _id: '64c8ced9de188952b00d7061',
    code: AttributeFixedWithModuleMesx.MESX_MANUFACTURING_ORDER_CODE,
    name: 'Lệnh sản xuất',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64c7890e3293d2be4a026e42',
    code: AttributeFixedWithModuleMesx.MESX_DEPARTMENT_NAME,
    name: 'Bộ phận',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64c7890e3293d2be4a026e43',
    code: AttributeFixedWithModuleMesx.MESX_ITEM_TYPE_ID,
    name: 'Id kiểu SP',
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64c8cefede188952b00d7062',
    code: AttributeFixedWithModuleMesx.MESX_ITEM_TYPE_NAME,
    name: 'Kiểu SP',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64c9fb6fbc6af221d3011521',
    code: AttributeFixedWithModuleMesx.MESX_WAREHOUSE_ID,
    name: 'Id kho nhập',
    dataType: DATA_TYPE_ENUM.NUMBER,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64c9fb9bbc6af221d3011522',
    code: AttributeFixedWithModuleMesx.MESX_WAREHOUSE_NAME,
    name: 'Kho nhập',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64dc7ea01f09b8065005b0b1',
    code: AttributeFixedWithModuleMesx.MESX_PRODUCTION_ORDER_EXPORT_ID,
    name: 'Id yêu cầu xuất nguyên vật liệu',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.MESX,
  },
  {
    _id: '64dc7ea01f09b8065005b0b2',
    code: AttributeFixedWithModuleMesx.MESX_PRODUCTION_ORDER_IMPORT_ID,
    name: 'Id yêu cầu nhập kho thành phẩm',
    dataType: DATA_TYPE_ENUM.TEXT,
    module: MODULE_ENUM.MESX,
  },
];

export const ATTRIBUTE_CONFIG_MAP = keyBy(ATTRIBUTE_CONFIG, 'code');

export enum MethodEnumApi {
  LIST = 'list',
  DETAIL = '/:id',
}

export enum PrefixServiceSystem {
  USER = 'users',
  WAREHOUSE = 'warehouses',
  PLAN = 'plans',
  PRODUCE_SERVICE = 'produces',
  ITEM = 'items',
  REQUETS = 'requests',
  ATTRIBUTE = 'attributes',
  REASONS = 'reasons',
  LOCATORS = 'locators',
}

export enum PrefixEndPointService {
  ITEM = '/v1/items',
  USER = '/v1/users',
  WAREHOUSE = '/v1/warehouses',
  SALE = '/v1/sales',
  PRODUCE = '/v1/produces',
  PLAN = '/v1/plans',
  REQUEST = '/v1/requests',
  ATTRIBUTE = '/v1/attributes',
  WAREHOUSE_LAYOUTS = '/v1/warehouse-layouts',
}

export enum PrefixController {
  BOM_VERSION = 'bom-versions',
  DEPARTMENT_SETTING = 'department-settings',
  TEMPLATE = 'templates',
  WAREHOUSE_REQUEST_ORDERS = 'warehouse-request-orders',
}

//Chỗ define thông tin bảng
export const TABLE_CONFIG = [
  {
    _id: '6482c1a9f392f20f996acb9a',
    name: MethodEnumApi.LIST,
    code: 'items',
    description: 'Api danh sách vật tư',
    prefixService: PrefixServiceSystem.ITEM,
    prefixController: '',
    prefixEndPointService: PrefixEndPointService.ITEM,
    uri: `${PrefixEndPointService.ITEM}/${MethodEnumApi.LIST}`,
  },
  {
    _id: '648936e58d977a3e30ebd943',
    name: MethodEnumApi.LIST,
    code: 'warehouses',
    description: 'Api danh sách kho',
    prefixService: PrefixServiceSystem.WAREHOUSE,
    prefixController: '',
    prefixEndPointService: PrefixEndPointService.WAREHOUSE,
    uri: `${PrefixEndPointService.WAREHOUSE}/${MethodEnumApi.LIST}`,
  },
  {
    _id: '648938c8963697d7a203eecb',
    name: '',
    code: 'requests',
    description: 'Api danh sách yêu cầu',
    prefixService: PrefixServiceSystem.REQUETS,
    prefixController: '',
    prefixEndPointService: PrefixEndPointService.REQUEST,
    uri: `${PrefixEndPointService.REQUEST}`,
  },
  {
    _id: '646d5a885c5fadaa7a45496c',
    name: MethodEnumApi.LIST,
    code: 'department_settings',
    description: 'Api danh sách đơn vị - Bộ Phận',
    prefixService: PrefixServiceSystem.USER,
    prefixController: PrefixController.DEPARTMENT_SETTING,
    prefixEndPointService: PrefixEndPointService.USER,
    uri: `${PrefixEndPointService.USER}/${PrefixController.DEPARTMENT_SETTING}/${MethodEnumApi.LIST}`,
  },
  {
    _id: '649169ac92ea555232cde3eb',
    name: '',
    code: 'warehouse_request_orders',
    description: 'Api danh sách yêu cầu (Nhập xuất chuyển)',
    prefixService: PrefixServiceSystem.REQUETS,
    prefixController: PrefixController.WAREHOUSE_REQUEST_ORDERS,
    prefixEndPointService: PrefixEndPointService.REQUEST,
    uri: `${PrefixEndPointService.REQUEST}/${PrefixController.WAREHOUSE_REQUEST_ORDERS}`,
  },
  {
    _id: '649270a9b11341d7be0e5ef6',
    name: MethodEnumApi.LIST,
    code: 'users',
    description: 'Api danh sách người dùng',
    prefixService: PrefixServiceSystem.USER,
    prefixController: '',
    prefixEndPointService: PrefixEndPointService.USER,
    uri: `${PrefixEndPointService.USER}/${MethodEnumApi.LIST}`,
  },
  {
    _id: '64902876f1eb42d57cca4545',
    name: '',
    code: 'templates',
    description: 'Api danh sách template',
    prefixService: PrefixServiceSystem.ATTRIBUTE,
    prefixController: PrefixController.TEMPLATE,
    prefixEndPointService: PrefixEndPointService.ATTRIBUTE,
    uri: `${PrefixEndPointService.ATTRIBUTE}/${PrefixController.TEMPLATE}`,
  },
  {
    _id: '64ab623b8751ba22ab016131',
    name: '',
    code: 'reasons',
    description: 'Api danh sách reason',
    prefixService: PrefixServiceSystem.REASONS,
    prefixController: '',
    prefixEndPointService: PrefixEndPointService.SALE,
    uri: `${PrefixEndPointService.SALE}/${PrefixServiceSystem.REASONS}/${MethodEnumApi.LIST}`,
  },
  {
    _id: '64ae78593f6803b21e092184',
    name: '',
    code: 'locators',
    description: 'Api danh sách locators',
    prefixService: PrefixServiceSystem.LOCATORS,
    prefixController: '',
    prefixEndPointService: PrefixEndPointService.WAREHOUSE_LAYOUTS,
    uri: `${PrefixEndPointService.WAREHOUSE_LAYOUTS}/${PrefixServiceSystem.LOCATORS}/${MethodEnumApi.LIST}`,
  },
  {
    _id: '64ae78593f6803b21e092185',
    name: MethodEnumApi.LIST,
    code: 'items-warehouse-stocks',
    description: 'Api danh sách tồn kho tồn kho vật tư',
    prefixService: PrefixServiceSystem.ITEM,
    prefixController: '',
    prefixEndPointService: PrefixEndPointService.ITEM,
    uri: `${PrefixEndPointService.ITEM}/item-stocks/storage-dates`,
  },
];

export const TABLE_CONFIG_MAP = keyBy(TABLE_CONFIG, 'code');

export const GROUP_CONFIG = [
  {
    _id: '6482a053a0b43d6233f4386f',
    code: GroupFixed.WMSX_GROUP,
    name: 'GR01',
    description: 'Group wmsx',
    order: 1,
  },
  {
    _id: '6482dfc94749b35dfe10904f',
    code: GroupFixed.MEEX_GROUP,
    name: 'Nhóm 1',
    description: 'Group mesx',
    order: 1,
  },
  {
    _id: '6482dfc94749b35dfe10904a',
    code: GroupFixed.PO_DETAIL_ITEM_GROUP,
    name: 'Danh sách sản phẩm',
    description: 'Item list PO detail',
    order: 1,
  },
  {
    _id: '6482dfc94749b35dfe10904b',
    code: GroupFixed.PO_DETAIL_DELIVERY_GROUP,
    name: 'Giao hàng',
    description: 'Delivery PO detail',
    order: 2,
  },
  {
    _id: '6482dfc94749b35dfe10904c',
    code: GroupFixed.PO_DETAIL_PAYMENT_GROUP,
    name: 'Kế hoạch thanh toán',
    description: 'Payment PO detail',
    order: 3,
  },
  {
    _id: '6482dfc94749b35dfe10904d',
    code: GroupFixed.PO_DETAIL_INVOICE_GROUP,
    name: 'Thông tin hoá đơn',
    description: 'Invoice PO detail',
    order: 4,
  },
];
export const GROUP_CONFIG_MAP = keyBy(GROUP_CONFIG, 'code');
