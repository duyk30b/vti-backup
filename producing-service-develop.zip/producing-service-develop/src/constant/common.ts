import { div, minus, mul } from '@utils/common';

export enum APIPrefix {
  Version = 'api/v1',
}

export const DATA_NOT_CHANGE = {};

export const enum MoPlanStatus {
  REJECTED = 0,
  CREATED = 1,
  CONFIRMED = 2,
  IN_PROGRESS = 3,
  COMPLETED = 4,
}

export const CAN_DELETE_MO_PLAN_STATUS: number[] = [
  MoPlanStatus.CREATED,
  MoPlanStatus.REJECTED,
];

export enum Progress {
  LATE = 1,
  NORMAL = 2,
  DONE = 3,
  NOTHING = 4,
}

export enum OrderStatusEnum {
  Pending = 0,
  Confirmed = 1,
  InProgress = 2,
  Approved = 3,
  Completed = 4,
  Reject = 5,
}

export const REPORT_QUALITY_HEADER = [
  {
    from: 'i',
  },
  {
    from: 'boqName',
  },
  {
    from: 'itemName',
  },
  {
    from: 'routingName',
  },
  {
    from: 'versionName',
  },
  {
    from: 'producingStep',
  },
  {
    from: 'planQuantity',
  },
  {
    from: 'quantity',
  },
  {
    from: 'needQcQuantity',
  },
  {
    from: 'qcQuantity',
  },
  {
    from: 'failQuantity',
  },
  {
    from: 'failedQuantity',
  },
];

export const REPORT_PROCCESS_HEADER = [
  {
    from: 'i',
  },
  {
    from: 'boqCode',
  },
  {
    from: 'boqName',
  },
  {
    from: 'planCode',
  },
  {
    from: 'planName',
  },
  {
    from: 'bomCode',
  },
  {
    from: 'itemCode',
  },
  {
    from: 'itemName',
  },
  {
    from: 'versionName',
  },
  {
    from: 'producingStep',
  },
  {
    from: 'process',
  },
];

export const getProccess = function (
  actualQuantity,
  quantity,
  executeDate,
  endDate,
): Progress {
  const now = new Date();
  const actual = actualQuantity ? actualQuantity : 0;
  const plan = quantity ? quantity : 0;
  const start = new Date(executeDate);
  const end = new Date(endDate);
  if (actual == 0) return Progress.NOTHING;
  if (plan == actual) return Progress.DONE;
  if (plan > actual && now > end) return Progress.LATE;
  const forcastQuantity = mul(
    plan,
    div(
      minus(now.getTime(), start.getTime()),
      minus(end.getTime(), start.getTime()),
    ),
  );
  if (forcastQuantity > actual && now > end) return Progress.LATE;
  return Progress.NORMAL;
};

export const startCommandChars = '^XA';
export const endCommandChars = '^XZ';

export enum ErrorReportStatus {
  Awaiting,
  Confirmed,
  Rejected,
  Completed,
}

//permission
export enum StatusPermission {
  ACTIVE = 1,
  INACTIVE = 0,
}

export const FORMAT_CODE_PERMISSION = 'PRODUCE_';

export const MINUTES_OF_ONE_DAY = 1440;

export const DEFAULT_TIME_FORMAT = 'HH:mm:ss';
