export interface WarehouseServiceInterface {
  getListByIDs(ids: number[], relation?: string[]): Promise<any>;
  getWarehouseListByConditions(request: any, serilize?: boolean): Promise<any>;
  getItemWarehouseListByConditions(
    request: any,
    serilize?: boolean,
  ): Promise<any>;
}
