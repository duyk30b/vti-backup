import { ItemManufacturingOrderResponseDto } from '../dto/response/item-manufacturing-order.response.dto';

export interface MasterPlanServiceInterface {
  getMasterPlanByDate(request: any): Promise<any>;
  getMasterPlanById(request: any): Promise<any>;
  getMasterPlanWithFlatItems(request: any): Promise<any>;
  manufacturingOrderConfirmedEvent(request: any): Promise<any>;
  getMasterPlans(request: any, serialize?: boolean): Promise<any>;
  updateItemProducingStepScheudleActualQuantity(
    masterPlanId: number,
    producingStepItemId: number,
    masterPlanWorkCenterDailyScheduleId: number,
    masterPlanWorkCenterDailyScheduleShiftId: number,
    quantity: number,
  ): Promise<any>;
  updateItemScheudleActualQuantity(
    masterPlanItemScheduleId: number,
    quantity: number,
  ): Promise<any>;
  getMOByMasterPlan(
    masterPlanId: number,
  ): Promise<ItemManufacturingOrderResponseDto[] | any>;
}
