import { Inject, Injectable } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { MasterPlanServiceInterface } from './interface/master-plan.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { keyBy } from 'lodash';
import { ItemManufacturingOrderResponseDto } from './dto/response/item-manufacturing-order.response.dto';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { NATS_PLAN } from '@config/nats.config';

@Injectable()
export class MasterPlanService implements MasterPlanServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  public async updateItemScheudleActualQuantity(
    masterPlanItemScheduleId: number,
    quantity: number,
  ): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_PLAN}.update_item_schedule_actual_quantity`,
      {
        masterPlanItemScheduleId,
        quantity: quantity,
      },
    );
  }

  /**
   *
   * @param masterPlanId
   * @param producingStepItemId
   * @param masterPlanWorkCenterDailyScheduleId
   * @param masterPlanWorkCenterDailyScheduleShiftId
   * @param quantity
   * @returns
   */
  public async updateItemProducingStepScheudleActualQuantity(
    masterPlanId: number,
    producingStepItemId: number,
    masterPlanWorkCenterDailyScheduleId: number,
    masterPlanWorkCenterDailyScheduleShiftId: number,
    quantity: number,
  ): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_PLAN}.update_item_producing_step_schedule_actual_quantity`,
      {
        masterPlanId,
        itemProducingStepScheduleId: producingStepItemId,
        masterPlanWorkCenterDailyScheduleId,
        masterPlanWorkCenterDailyScheduleShiftId,
        quantity: quantity,
      },
    );
  }

  async getMasterPlanById(request: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PLAN}.get_master_plan_by_id`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return response.data;
  }

  async getMasterPlanByDate(request: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PLAN}.get_detail_master_plan`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return response.data;
  }

  async getMasterPlanWithFlatItems(request: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PLAN}.get_master_plan_flat_items`,
      {
        ...request,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return response.data;
  }

  async manufacturingOrderConfirmedEvent(request: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PLAN}.manufacturing_order_confirmed_event`,
      {
        ...request,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return response.data;
  }

  async getMasterPlans(request: any, serialize?: false): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PLAN}.get_master_plans`,
      {
        ...request,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return {};
    }

    if (serialize) {
      return keyBy(response.data.masterPlans, 'id');
    }
    return response.data.masterPlans;
  }

  async getMOByMasterPlan(
    masterPlanId: number,
  ): Promise<ItemManufacturingOrderResponseDto[] | any> {
    const response = await this.natsClientService.send(
      `${NATS_PLAN}.get_mo_by_master_plan`,
      {
        masterPlanId,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }
}
