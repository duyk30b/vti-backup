import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

export class ItemManufacturingOrderResponseDto extends SuccessResponse {
  @Expose()
  id: number;

  @Expose()
  masterPlanId: number;

  @Expose()
  saleOrderScheduleId: number;

  @Expose()
  itemScheduleId: number;

  @Expose()
  moId: number;

  @Expose()
  quantity: number;

  @Expose()
  dateFrom: number;

  @Expose()
  dateTo: number;
}
