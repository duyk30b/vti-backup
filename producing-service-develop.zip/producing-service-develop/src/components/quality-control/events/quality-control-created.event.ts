export class QualityControlCreatedEvent {
  constructor({ moId }) {
    this.moId = moId;
  }
  moId: number;
}
