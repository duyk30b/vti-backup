import { BoqStatusEnum } from '@components/boq/boq.constant';
import { BoqRepositoryInterface } from '@components/boq/interface/boq.repository.interface';
import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';

@Injectable()
export class QualityControlCreatedListener {
  constructor(
    @Inject('BoqRepositoryInterface')
    private readonly boqRepository: BoqRepositoryInterface,
  ) {}

  @OnEvent('quality-control.created')
  public async checkAndUpdateBoqStatus({ boqId }) {
    if (!boqId) return;
    const boq = await this.boqRepository.getStatusSummary(boqId);
    if (
      boq &&
      boq.status !== BoqStatusEnum.COMPLETED &&
      parseFloat(boq.totalActualQuantity || 0) >=
        parseFloat(boq.totalPlanQuantity || 0)
    ) {
      await this.boqRepository.update({
        id: boqId,
        status: BoqStatusEnum.COMPLETED,
      });
    }

    return;
  }
}
