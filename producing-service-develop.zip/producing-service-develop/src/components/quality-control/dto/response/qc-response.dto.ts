import { Expose, Transform, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

class ITWorkOrder {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  planFrom: string;

  @ApiProperty()
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  planTo: string;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  quantity: number;
}
class ITRoutingVersion {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;
}
class ITUser {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  fullName: string;

  @ApiProperty()
  @Expose()
  username: string;
}

class ITWBoq {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ITProducingStep {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ITWBomItem {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  itemUnit: string;
}

class ITWBom {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty({ type: ITWBomItem })
  @Expose()
  @Type(() => ITWBomItem)
  item: ITWBomItem;
}

export class QcResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  quantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  totalQcPassQuantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  totalUnQcQuantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  totalQcQuantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  totalQcRejectQuantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  qcRejectQuantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  qcPassQuantity: number;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty()
  @Expose()
  note: string;

  @ApiProperty({ type: ITWorkOrder })
  @Expose()
  @Type(() => ITWorkOrder)
  workOrder: ITWorkOrder;

  @ApiProperty({ type: ITWBoq })
  @Expose()
  @Type(() => ITWBoq)
  manufacturingOrder: ITWBoq;

  @ApiProperty({ type: ITWBom })
  @Expose()
  @Type(() => ITWBom)
  bom: ITWBom;

  @ApiProperty({ type: ITWBom })
  @Expose()
  @Type(() => ITWBom)
  parentBom: ITWBom;

  @ApiProperty({ type: ITProducingStep })
  @Expose()
  @Type(() => ITProducingStep)
  producingStep: ITProducingStep;

  @ApiProperty({ type: ITProducingStep })
  @Expose()
  @Type(() => ITProducingStep)
  exportProducingStep: ITProducingStep;

  @ApiProperty({ type: ITRoutingVersion })
  @Expose()
  @Type(() => ITRoutingVersion)
  routingVersion: ITRoutingVersion;

  @ApiProperty({ type: ITUser })
  @Expose()
  @Type(() => ITUser)
  createdByUser: ITUser;
}
