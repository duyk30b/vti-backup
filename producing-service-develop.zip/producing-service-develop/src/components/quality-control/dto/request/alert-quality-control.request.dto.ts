import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { BaseDto } from '@core/dto/base.dto';
import {
  IsEnum,
  IsInt,
  IsString,
  MaxLength,
  IsOptional,
  IsDateString,
  IsNotEmpty,
} from 'class-validator';
import { ALERT_WORK_ORDER_QUALITY_CONTROL_ENUM } from '@components/quality-control/quality-control.constant';

export class AlertQualityControlRequestDto extends BaseDto {
  @Expose()
  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(ALERT_WORK_ORDER_QUALITY_CONTROL_ENUM)
  type: number;

  @Expose()
  @ApiProperty()
  @IsString()
  @MaxLength(255)
  @IsNotEmpty()
  message: string;

  @Expose()
  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  alertedAt: Date;

  @Expose()
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  producingStepId: number;

  @Expose()
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  manufacturingOrderId: number;

  @Expose()
  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  itemId: number;

  @Expose()
  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  previousBomId: number;

  @Expose()
  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  previousProducingStepId: number;
}
