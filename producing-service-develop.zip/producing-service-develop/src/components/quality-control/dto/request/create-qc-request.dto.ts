import { IsDateString, IsString, MaxLength } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty, IsNumber, IsOptional, Min } from 'class-validator';

export class CreateQcRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  workOrderId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  workCenterId: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  createdByUserId: number;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  @Min(0)
  passQuantity: number;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  @Min(0)
  rejectQuantity: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @MaxLength(255)
  note: string;

  @ApiProperty({
    description: 'execution day',
  })
  @IsNotEmpty()
  @IsDateString()
  executionDay: Date;
}

export class CreateMaterialInputQcRequestDto extends CreateQcRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @MaxLength(255)
  note: string;
}
export class CreatePreviousBomQcRequestDto extends CreateQcRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @MaxLength(255)
  note: string;
}
