import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';

export class GetAlerQualityControlRequestDto extends BaseDto {
  @Expose()
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  @Transform((data) => +data.value)
  producingStepId: number;

  @Expose()
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  @Transform((data) => +data.value)
  manufacturingOrderId: number;

  @Expose()
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  @Transform((data) => +data.value)
  manufacturingOrderPlanId: number;
}
