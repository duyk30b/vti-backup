import { MoPlanBomRepositoryInteface } from '@components/plan/inteface/mo-plan-bom.repository.inteface';
import { QualityControlRepositoryInterface } from './interface/quality-control.repository.interface';
import { WorkOrderEntity } from '@entities/work-order/work-order.entity';
import {
  CAN_QC_WORK_ORDER,
  WorkOrderRunningStatusEnum,
  WorkOrderStatusEnum,
} from './../work-order/work-order.constant';
import { QualityControlServiceInterface } from '@components/quality-control/interface/quality-controler.service.interface';
import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, Raw } from 'typeorm';
import { WorkOrderRepositoryInterface } from '@components/work-order/interface/work-order.repository.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponsePayload } from '@utils/response-payload';
import {
  CreateMaterialInputQcRequestDto,
  CreatePreviousBomQcRequestDto,
  CreateQcRequestDto,
} from './dto/request/create-qc-request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ApiError } from '@utils/api.error';
import { minus, plus } from '@utils/common';
import { QualityControlEntity } from '@entities/quality-control/quality-control.entity';
import { plainToInstance } from 'class-transformer';
import { GetListQcRequestDto } from './dto/request/get-list-qc.request.dto';
import { first, flatMap, isEmpty, last, map, uniq, has } from 'lodash';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { PagingResponse } from '@utils/paging.response';
import { QcResponseDto } from './dto/response/qc-response.dto';
import { GetDetailQcRequestDto } from './dto/request/get-detail-qc.request.dto';
import { MoPlanBomTransactionEntity } from '@entities/manufacturing-order/mo-plan-bom-transactions.entity';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { QualityControlCreatedEvent } from './events/quality-control-created.event';
import { ManufacturingOrderDetailEntity } from '@entities/manufacturing-order/manufacturing-order-details.entity';
import { ManufacturingOrderDetailRepositoryInterface } from '@components/manufacturing-order/interface/manufacturing-order-detail.repository.interface';
import { MoPlanBomEntity } from '@entities/manufacturing-order/mo-plan-boms.entity';
import { RoutingRepositoryInterface } from '@components/routing/interface/routing.repository.interface';
import { QualityControlTypeEnum } from './quality-control.constant';
import { WorkOrderMaterialInputEntity } from '@entities/work-order/material-input/work-order-material_input.entity';
import { WorkOrderMaterialInputRepository } from '@repositories/work-order/work-order-material-input.repository';
import { WorkOrderBomTransitRepositoryInterface } from '@components/work-order/interface/work-order-bom-transit.repository.interface';
import { WorkOrderBomTransitEntity } from '@entities/work-order/work-order-bom-transit.entity';
import { WorkOrderWorkCenterLotRepositoryInterface } from '@components/work-order/interface/work-order-work-center-lot.repository.interface';
import { WorkCenterRepositoryInterface } from '@components/work-center/interface/work-center.repository.interface';
import { WorkOrderScheduleDetailRepositoryInterface } from '@components/work-order/interface/work-order-schedule-detail.repository.interface';
import { WorkCenterDailyScheduleShiftEntity } from '@entities/work-center/work-center-daily-schedule-shift.entity';
import { WorkOrderScheduleDetailEntity } from '@entities/work-order/work-order-schedule-detail.entity';
import { WorkCenterDailyScheduleShiftRepositoryInterface } from '@components/work-center/interface/work-center-daily-schedule-shift.repository.interface';
import { getFullDateString, getShiftTime } from '@utils/helper';
import { WorkCenterShiftRepositoryInterface } from '@components/work-center/interface/work-center-shift.repository.interface';
import * as Moment from 'moment';
import { extendMoment } from 'moment-range';
import { WorkCenterDailyScheduleRepositoryInterface } from '@components/work-center/interface/work-center-daily-schedule.repository.interface';
import { ConfigService } from '@config/config.service';
import { InTransitRepositoryInterface } from '@components/work-order/interface/in-transit.repository.interface';
import { WorkOrderScheduleRepositoryInterface } from '@components/work-order/interface/work-order-schedule.repsository.interface';
import { AlertQualityControlRequestDto } from './dto/request/alert-quality-control.request.dto';
import { QualityControlAlertRepositoryInterface } from './interface/quality-control-alert.repository.interface';
import { GetAlerQualityControlRequestDto } from './dto/request/get-alert-quality-control.request.dto';
import { AlertQualityControlResponseDto } from './dto/response/alert-quality-control-response.dto';
import {
  MoPlanBomProgressUpdateEvent,
  WorkOrderProgressUpdateEvent,
} from '@components/manufacturing-order/events/manufacturing-order-progress.event';
import { ManufacturingOrderRepositoryInterface } from '@components/manufacturing-order/interface/manufacturing-order.repository.interface';
import { WorkCenterEntity } from '@entities/work-center/work-center.entity';
const moment = extendMoment(Moment);

@Injectable()
export class QualityControlService implements QualityControlServiceInterface {
  private readonly configService: ConfigService;

  constructor(
    @Inject('WorkOrderRepositoryInterface')
    private readonly workOrderRepository: WorkOrderRepositoryInterface,

    @Inject('WorkCenterRepositoryInterface')
    private readonly workCenterRepository: WorkCenterRepositoryInterface,

    @Inject('QualityControlRepositoryInterface')
    private readonly qualityControlRepository: QualityControlRepositoryInterface,

    @Inject('QualityControlAlertRepositoryInterface')
    private readonly qualityControlAlertRepository: QualityControlAlertRepositoryInterface,

    @Inject('WorkOrderWorkCenterLotRepositoryInterface')
    private readonly workOrderWorkCenterLotRepository: WorkOrderWorkCenterLotRepositoryInterface,

    @Inject('WorkOrderMaterialInputRepositoryInterface')
    private readonly workOrderMaterialInputRepository: WorkOrderMaterialInputRepository,

    @Inject('MoDetailRepositoryInterface')
    private readonly moDetailRepository: ManufacturingOrderDetailRepositoryInterface,

    @Inject('WorkOrderBomTransitRepositoryInterface')
    private readonly workOrderBomTransitRepository: WorkOrderBomTransitRepositoryInterface,

    @Inject('RoutingRepositoryInterface')
    private readonly routingRepository: RoutingRepositoryInterface,

    @Inject('MoPlanBomRepositoryInterface')
    private readonly moPlanBomRepository: MoPlanBomRepositoryInteface,

    @Inject('ManufacturingOrderRepositoryInterface')
    private readonly manufacturingOrderRepository: ManufacturingOrderRepositoryInterface,

    @Inject('WorkOrderScheduleDetailRepositoryInterface')
    private readonly workOrderScheduleDetailRepository: WorkOrderScheduleDetailRepositoryInterface,

    @Inject('WorkOrderScheduleRepositoryInterface')
    private readonly workOrderScheduleRepository: WorkOrderScheduleRepositoryInterface,

    @Inject('WorkCenterDailyScheduleShiftRepositoryInterface')
    private readonly workCenterDailyScheduleShiftRepository: WorkCenterDailyScheduleShiftRepositoryInterface,

    @Inject('WorkCenterShiftRepositoryInterface')
    private readonly workCenterShiftRepository: WorkCenterShiftRepositoryInterface,

    @Inject('WorkCenterDailyScheduleRepositoryInterface')
    private readonly workCenterDailyScheduleRepository: WorkCenterDailyScheduleRepositoryInterface,

    @Inject('InTransitRepositoryInterface')
    private readonly inTransitRepository: InTransitRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly eventEmitter: EventEmitter2,

    private readonly i18n: I18nRequestScopeService,
  ) {
    this.configService = new ConfigService();
  }

  /**
   *
   * @param producingStepId
   * @param moId
   * @param moPlanId
   * @returns
   */
  public async getHightPrioriryAlert(
    producingStepId: number,
    moId: number,
    moPlanId: number,
  ): Promise<any> {
    return await this.qualityControlAlertRepository.findOneWithRelations({
      where: {
        manufacturingOrderId: moId,
        manufacturingOrderPlanId: moPlanId,
        producingStepId: producingStepId,
      },
      orderBy: {
        type: 'ASC',
      },
      limit: 1,
    });
  }

  /**
   *
   * @param request
   */
  public async alert(
    request: AlertQualityControlRequestDto,
  ): Promise<ResponsePayload<any>> {
    const {
      type,
      message,
      alertedAt,
      producingStepId,
      manufacturingOrderId,
      previousBomId,
      previousProducingStepId,
      itemId,
    } = request;

    const manufacturingOrder =
      await this.workOrderRepository.findOneByCondition({
        moId: manufacturingOrderId,
        producingStepId: producingStepId,
      });

    if (isEmpty(manufacturingOrder)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    try {
      await this.qualityControlAlertRepository.create({
        message,
        alertedAt,
        producingStepId,
        manufacturingOrderId,
        manufacturingOrderPlanId: manufacturingOrder.moPlanId,
        itemId,
        previousBomId,
        previousProducingStepId,
        type,
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    }
  }

  /**
   *
   * @param request
   */
  public async getAlerts(
    request: GetAlerQualityControlRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { producingStepId, manufacturingOrderId, manufacturingOrderPlanId } =
      request;

    try {
      const alerts = await this.qualityControlAlertRepository.findWithRelations(
        {
          where: {
            producingStepId,
            manufacturingOrderId,
            manufacturingOrderPlanId,
          },
        },
      );

      const response = plainToInstance(AlertQualityControlResponseDto, alerts, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
  }

  public async create(
    request: CreateQcRequestDto,
  ): Promise<ResponsePayload<any>> {
    const {
      workOrderId,
      passQuantity,
      rejectQuantity,
      createdByUserId,
      note,
      workCenterId,
      executionDay,
    } = request;

    let shouldDispatchUpdateMoStatusEvent = false;
    const workOrder = await this.workOrderRepository.findOneWithRelations({
      where: { id: workOrderId },
      relations: ['workOrderSchedule'],
    });

    if (!workOrder || isEmpty(workOrder.workOrderSchedule)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }
    if (!CAN_QC_WORK_ORDER.includes(workOrder.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    }

    const workCenter = await this.workCenterRepository.findOneById(
      workCenterId,
    );

    if (!workCenter) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_CENTER_NOT_FOUND'))
        .build();
    }

    if (!passQuantity && !rejectQuantity) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.INVALID_QUANTITY'),
      ).toResponse();
    }

    const workOrderScheduleDetail =
      await this.workOrderScheduleDetailRepository.findOneWithRelations({
        where: {
          workOrderScheduleId: first(workOrder.workOrderSchedule).id,
          workCenterId: workCenterId,
        },
      });

    if (!workOrderScheduleDetail) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_CENTER_NOT_FOUND'))
        .build();
    }

    const workCenterLot =
      await this.workOrderWorkCenterLotRepository.findOneWithRelations({
        where: {
          workOrderId: workOrderId,
          workCenterId: workCenterId,
        },
      });

    if (!workCenterLot) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_CENTER_NOT_FOUND'))
        .build();
    }

    const unQcQuantity = minus(
      plus(
        workOrderScheduleDetail.actualQuantity,
        workOrderScheduleDetail.repairedQuantity || 0,
      ),
      plus(
        workOrderScheduleDetail.qcPassQuantity,
        workOrderScheduleDetail.qcRejectQuantity,
      ),
    );

    if (plus(passQuantity || 0, rejectQuantity || 0) > unQcQuantity) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INVALID_QUANTITY'))
        .build();
    }

    if (!workOrderScheduleDetail) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.WORK_ORDER_SCHEDULE_DETAIL_NOT_FOUND',
          ),
        )
        .build();
    }

    const workCenterShifts =
      await this.workCenterShiftRepository.findByCondition({
        workCenterId,
      });
    if (isEmpty(workCenterShifts)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WORK_CENTER_SHIFT_N_NOT_FOUND'),
        )
        .build();
    }

    let shift = workCenterShifts.find((workCenterShift) => {
      const { start, end } = getShiftTime(
        workCenterShift.startAt,
        workCenterShift.endAt,
      );
      const range = moment.range(start, end);
      return range.contains(moment(executionDay));
    });
    if (isEmpty(shift)) {
      shift = last(workCenterShifts);
    }

    const defaultTimeZone = this.configService.get('defaultTimeZone');
    const executionDate = getFullDateString(executionDay);
    let workCenterDailySchedule, workCenterDailyScheduleShift;
    workCenterDailySchedule =
      await this.workCenterDailyScheduleRepository.findOneWithRelations({
        where: {
          workOrderScheduleDetailId: workOrderScheduleDetail.id,
          workCenterId: workCenterId,
          executionDay: Raw(
            () =>
              `to_char(execution_day AT TIME ZONE '${defaultTimeZone}' , 'yyyy-mm-dd' ) = '${executionDate}'`,
          ),
        },
      });

    if (workCenterDailySchedule) {
      workCenterDailyScheduleShift =
        await this.workCenterDailyScheduleShiftRepository.findOneByCondition({
          workCenterDailyScheduleId: workCenterDailySchedule.id,
          workCenterShiftId: shift.id,
          executionDay: Raw(
            () =>
              `to_char(execution_day AT TIME ZONE '${defaultTimeZone}', 'yyyy-mm-dd' ) = '${executionDate}'`,
          ),
        });
    } else {
      workCenterDailySchedule =
        await this.workCenterDailyScheduleRepository.findOneWithRelations({
          where: {
            workOrderScheduleDetailId: workOrderScheduleDetail.id,
            workCenterId: workCenterId,
          },
          orderBy: {
            id: 'DESC',
          },
        });
      workCenterDailyScheduleShift =
        await this.workCenterDailyScheduleShiftRepository.findOneWithRelations({
          where: {
            workCenterDailyScheduleId: workCenterDailySchedule.id,
            workCenterShiftId: shift.id,
          },
          orderBy: {
            id: 'DESC',
          },
        });
    }

    if (!workCenterDailySchedule) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WORK_CENTER_SHIFT_N_NOT_FOUND'),
        )
        .build();
    }

    if (!workCenterDailyScheduleShift) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WORK_CENTER_SHIFT_N_NOT_FOUND'),
        )
        .build();
    }

    const isLatestStepOfBom =
      await this.routingRepository.isLatestStepInRouting(
        workOrder.routingId,
        workOrder.producingStepId,
      );

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const workOrderEntityUpdated = this.calcQcQuantity(
        workOrder,
        passQuantity,
        rejectQuantity,
      );
      if (
        minus(
          workOrderEntityUpdated.qcPassQuantity,
          workOrderEntityUpdated.quantity,
        ) >= 0
      ) {
        workOrderEntityUpdated.status = WorkOrderStatusEnum.COMPLETED;
        workOrderEntityUpdated.runningStatus = WorkOrderRunningStatusEnum.END;

        const currentWorkCenters =
          await this.workCenterRepository.findByCondition({
            currentRunningWorkOrderId: workOrderEntityUpdated.id,
          });

        if (!isEmpty(currentWorkCenters)) {
          for (let i = 0; i < currentWorkCenters.length; i++) {
            const wc = currentWorkCenters[i];
            wc.currentRunningWorkOrderId = null;
          }

          await queryRunner.manager.save(WorkCenterEntity, currentWorkCenters);
        }
      }

      const workCenterDailyScheduleShiftEntityUpdated = this.calcQcQuantity(
        workCenterDailyScheduleShift,
        passQuantity,
        rejectQuantity,
      );
      const workCenterLotEntityUpdated = this.calcQcQuantity(
        workCenterLot,
        passQuantity,
        rejectQuantity,
      );
      const workOrderScheduleDetailEntityUpdated = this.calcQcQuantity(
        workOrderScheduleDetail,
        passQuantity,
        rejectQuantity,
      );
      const qualityControlEntity = this.qualityControlRepository.createEntity({
        workOrderId: workOrderId,
        createdByUserId: createdByUserId,
        totalQcQuantity: unQcQuantity,
        totalQcPassQuantity: workOrderEntityUpdated.qcPassQuantity,
        totalQcRejectQuantity: workOrderEntityUpdated.qcRejectQuantity,
        qcPassQuantity: passQuantity,
        qcRejectQuantity: rejectQuantity,
        note: note,
        type: QualityControlTypeEnum.OUTPUT,
      });
      await queryRunner.manager.save(
        QualityControlEntity,
        qualityControlEntity,
      );
      await queryRunner.manager.save(workCenterLotEntityUpdated);

      let currentMoPlanBomId = null;
      if (isLatestStepOfBom) {
        // Update actual quantity of current bom
        const currentMoPlanBom = await this.moPlanBomRepository.findOneById(
          workOrder.moPlanBomId,
        );
        const moDetail = await this.moDetailRepository.findOneByCondition({
          id: currentMoPlanBom.moDetailId,
          manufacturingOrderId: currentMoPlanBom.moId,
          bomId: currentMoPlanBom.bomId,
        });

        // BOM is finished product!!
        if (moDetail) {
          moDetail.actualQuantity = plus(
            moDetail.actualQuantity || 0,
            passQuantity,
          );
          await queryRunner.manager.save(
            ManufacturingOrderDetailEntity,
            moDetail,
          );
          shouldDispatchUpdateMoStatusEvent = true;
        }
        currentMoPlanBom.actualQuantity = plus(
          currentMoPlanBom.actualQuantity,
          passQuantity,
        );
        const moPlanBomTransaction = new MoPlanBomTransactionEntity();
        moPlanBomTransaction.moId = workOrder.moId;
        moPlanBomTransaction.moPlanId = currentMoPlanBom.moPlanId;
        moPlanBomTransaction.moPlanBomId = workOrder.moPlanBomId;
        moPlanBomTransaction.quantity = passQuantity;

        await queryRunner.manager.save(MoPlanBomEntity, currentMoPlanBom);
        await queryRunner.manager.save(
          MoPlanBomTransactionEntity,
          moPlanBomTransaction,
        );
        currentMoPlanBomId = currentMoPlanBom.id;

        this.eventEmitter.emit(
          'manufacturing-order.mo-plan-bom-actual-quantity-updated',
          new MoPlanBomProgressUpdateEvent({
            moPlanBom: currentMoPlanBom,
            quantity: passQuantity,
          }),
        );
      }
      await queryRunner.manager.save(
        WorkCenterDailyScheduleShiftEntity,
        workCenterDailyScheduleShiftEntityUpdated,
      );
      await queryRunner.manager.save(
        WorkOrderScheduleDetailEntity,
        workOrderScheduleDetailEntityUpdated,
      );
      await queryRunner.manager.save(WorkOrderEntity, workOrderEntityUpdated);
      await queryRunner.commitTransaction();
      if (currentMoPlanBomId) {
        await this.moPlanBomRepository.updateEndAt(currentMoPlanBomId);
        await this.moPlanBomRepository.updateStartAt(currentMoPlanBomId);
      }
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
      if (shouldDispatchUpdateMoStatusEvent) {
        this.eventEmitter.emit(
          'quality-control.created',
          new QualityControlCreatedEvent({
            moId: workOrder.moId,
          }),
        );
      }
      const mo = await this.manufacturingOrderRepository.findOneById(
        workOrder.moId,
      );
      this.eventEmitter.emit(
        'manufacturing-order.work-order-actual-quantity-updated',
        new WorkOrderProgressUpdateEvent({
          mo: mo,
          workOrder: workOrder,
          workCenterDailySchedule: workCenterDailySchedule,
          workCenterDailyScheduleShift: workCenterDailyScheduleShift,
          quantity: passQuantity,
        }),
      );
    }
  }

  public async createMaterialInputQC(
    request: CreateMaterialInputQcRequestDto,
  ): Promise<ResponsePayload<any>> {
    const {
      workOrderId,
      itemId,
      passQuantity,
      rejectQuantity,
      createdByUserId,
      note,
    } = request;

    const workOrder = await this.workOrderRepository.scan(workOrderId);

    if (!workOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }
    if (!passQuantity && !rejectQuantity) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.INVALID_QUANTITY'),
      ).toResponse();
    }

    const material = workOrder.inputs?.find(
      (input) => isEmpty(input.bom) && input.itemId === itemId,
    );

    if (!material) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.MATERIAL_NOT_FOUND'))
        .build();
    }

    const unQcQuantity = minus(
      material.planQuantity,
      plus(
        material.totalQcPassQuantity || 0,
        material.totalQcRejectQuantity || 0,
      ),
    );
    if (plus(passQuantity || 0, rejectQuantity || 0) > unQcQuantity) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INVALID_QUANTITY'))
        .build();
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const qualityControlEntity = this.qualityControlRepository.createEntity({
        workOrderId: workOrderId,
        itemId: itemId,
        createdByUserId: createdByUserId,
        totalQcQuantity: unQcQuantity,
        totalQcPassQuantity: material.qcPassQuantity,
        totalQcRejectQuantity: material.qcRejectQuantity,
        qcPassQuantity: passQuantity,
        qcRejectQuantity: rejectQuantity,
        note: note,
        type: QualityControlTypeEnum.MATERIAL_INPUT,
      });
      await queryRunner.manager.save(
        QualityControlEntity,
        qualityControlEntity,
      );
      let materialInput =
        await this.workOrderMaterialInputRepository.findOneWithRelations({
          where: {
            workOrderId: workOrderId,
            itemId: itemId,
          },
        });
      if (!materialInput) {
        materialInput = new WorkOrderMaterialInputEntity();
        materialInput.workOrderId = workOrderId;
        materialInput.itemId = itemId;
        materialInput.quantity = material.planQuantity;
      }

      materialInput.qcPassQuantity = plus(
        materialInput.qcPassQuantity || 0,
        passQuantity,
      );
      materialInput.qcRejectQuantity = plus(
        materialInput.qcRejectQuantity || 0,
        rejectQuantity || 0,
      );

      await queryRunner.manager.save(
        WorkOrderMaterialInputEntity,
        materialInput,
      );
      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }
  }

  /**
   * QC sản phẩm từ công đoạn trước
   * @param request
   * @returns
   */
  public async createPreviousBomQC(
    request: CreatePreviousBomQcRequestDto,
  ): Promise<ResponsePayload<any>> {
    const {
      workOrderId,
      id,
      itemId,
      passQuantity,
      rejectQuantity,
      createdByUserId,
      note,
    } = request;
    console.log('dsfsdfdsfdsfsdfsdfdsfd');

    const workOrder = await this.workOrderRepository.findOneById(workOrderId);

    if (!workOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }
    if (!passQuantity && !rejectQuantity) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.INVALID_QUANTITY'),
      ).toResponse();
    }

    const previousBom =
      await this.workOrderBomTransitRepository.findOneByCondition({
        workOrderId: workOrderId,
        bomDetailItemId: itemId,
        bomDetailBomId: id,
      });

    if (!previousBom) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PREVIOUS_BOM_NOT_FOUND'))
        .build();
    }
    const unQcQuantity = minus(
      previousBom.inputQuantity,
      plus(previousBom.qcPassQuantity, previousBom.qcRejectQuantity),
    );
    if (plus(passQuantity || 0, rejectQuantity || 0) > unQcQuantity) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INVALID_QUANTITY'))
        .build();
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const qualityControlEntity = this.qualityControlRepository.createEntity({
        workOrderId: workOrderId,
        itemId: itemId,
        createdByUserId: createdByUserId,
        totalQcQuantity: unQcQuantity,
        totalQcPassQuantity: previousBom.qcPassQuantity,
        totalQcRejectQuantity: previousBom.qcRejectQuantity,
        qcPassQuantity: passQuantity,
        qcRejectQuantity: rejectQuantity,
        note: note,
        type: QualityControlTypeEnum.PREVIOUS_BOM,
        parentBomId: id,
      });
      await queryRunner.manager.save(
        QualityControlEntity,
        qualityControlEntity,
      );
      previousBom.qcPassQuantity = plus(
        previousBom.qcPassQuantity || 0,
        passQuantity,
      );
      previousBom.qcRejectQuantity = plus(
        previousBom.qcRejectQuantity,
        rejectQuantity || 0,
      );

      if (rejectQuantity) {
        const previousWorkOrder =
          await this.inTransitRepository.getDetailByImportWorkOrder(
            workOrderId,
          );

        const pWo = await this.workOrderRepository.findOneById(
          previousWorkOrder.workOrderId,
        );

        const { workOrderScheduleDetail, workCenterDailySchedule } =
          await this.getScheduleForPreviousBom(
            previousWorkOrder.workOrderId,
            previousWorkOrder.workCenterId,
          );
        if (workOrderScheduleDetail && workCenterDailySchedule) {
          workOrderScheduleDetail.qcRejectQuantity = plus(
            workOrderScheduleDetail.qcRejectQuantity || 0,
            +rejectQuantity,
          );
          pWo.qcRejectQuantity = plus(
            pWo.qcRejectQuantity || 0,
            +rejectQuantity,
          );

          // if (pWo.status != WorkOrderStatusEnum.COMPLETED)
          //   pWo.status = WorkOrderStatusEnum.IN_PROGRESS;

          const workCenterScheduleShift = last(
            workCenterDailySchedule.workCenterDailyScheduleShifts,
          );
          workCenterScheduleShift.qcRejectQuantity = plus(
            workCenterScheduleShift.qcRejectQuantity || 0,
            +rejectQuantity,
          );

          await queryRunner.manager.save(workOrderScheduleDetail);
          await queryRunner.manager.save(workCenterScheduleShift);
          await queryRunner.manager.save(pWo);
        }
      }

      await queryRunner.manager.save(WorkOrderBomTransitEntity, previousBom);
      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }
  }

  public async getList(
    request: GetListQcRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { keyword } = request;

    let filterItemIds = [];

    if (!isEmpty(keyword)) {
      filterItemIds = await this.itemService.getItemsByName(keyword, true);
    }

    const { result, count } = await this.qualityControlRepository.getList(
      request,
      filterItemIds,
    );

    const bomItemIds = uniq(map(flatMap(result, 'bom'), 'itemId'));
    const parentBomItemIds = uniq(map(flatMap(result, 'parentBom'), 'itemId'));

    const items = await this.itemService.getItemsByIds(
      uniq(bomItemIds.concat(parentBomItemIds)),
      true,
    );

    const data = result.map((inTransit) => ({
      ...inTransit,
      bom: {
        ...inTransit.bom,
        item: items[inTransit.bom.itemId],
      },
      parentBom: {
        ...inTransit.parentBom,
        item: items[inTransit.parentBom?.itemId],
      },
    }));

    const response = plainToInstance(QcResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async getDetail(
    payload: GetDetailQcRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id } = payload;
    const qc = await this.qualityControlRepository.getDetail(id);
    if (isEmpty(qc)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const users = await this.userService.getUserByIds(
      [qc.createdByUserId],
      true,
    );

    const itemIds = uniq([qc.bom?.itemId, qc.parentBom?.itemId]);
    const items = await this.itemService.getItemsByIds(itemIds, true);
    qc.bom = {
      ...qc.bom,
      item: items[qc.bom.itemId],
    };
    qc.createdByUser = users[qc.createdByUserId];
    qc.parentBom = {
      ...qc.parentBom,
      item: items[qc?.parentBom?.itemId],
    };
    const response = plainToInstance(QcResponseDto, qc, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  private calcQcQuantity(entity, passQuantity, rejectQuantity) {
    entity.qcPassQuantity = plus(entity.qcPassQuantity || 0, passQuantity);
    entity.qcRejectQuantity = plus(
      entity.qcRejectQuantity,
      rejectQuantity || 0,
    );
    if (has(entity, 'errorQuantity')) {
      entity.errorQuantity = plus(entity.errorQuantity, rejectQuantity || 0);
    }

    return entity;
  }

  private async getScheduleForPreviousBom(workOrderId, workCenterId) {
    //TODO implement in-transit with work order lot
    const workOrderSchedule =
      await this.workOrderScheduleRepository.findOneWithRelations({
        where: {
          workOrderId: workOrderId,
        },
        orderBy: {
          id: 'DESC',
        },
      });

    const workOrderScheduleDetail =
      await this.workOrderScheduleDetailRepository.findOneWithRelations({
        where: {
          workOrderScheduleId: workOrderSchedule.id,
        },
        orderBy: {
          id: 'DESC',
        },
      });
    const workCenterDailySchedule =
      await this.workCenterDailyScheduleRepository.findOneWithRelations({
        where: {
          workOrderScheduleDetailId: workOrderScheduleDetail.id,
          workCenterId: workCenterId,
        },
        relations: ['workCenterDailyScheduleShifts'],
        orderBy: {
          id: 'DESC',
        },
      });

    return {
      workOrderScheduleDetail,
      workCenterDailySchedule,
    };
  }
}
