import {
  Body,
  Controller,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { isEmpty } from 'lodash';
import { MessagePattern, Transport } from '@nestjs/microservices';
import { ResponsePayload } from '@utils/response-payload';
import { QualityControlServiceInterface } from '@components/quality-control/interface/quality-controler.service.interface';
import {
  CreateMaterialInputQcRequestDto,
  CreatePreviousBomQcRequestDto,
  CreateQcRequestDto,
} from './dto/request/create-qc-request.dto';
import { GetListQcRequestDto } from './dto/request/get-list-qc.request.dto';
import { GetDetailQcRequestDto } from './dto/request/get-detail-qc.request.dto';
import { AlertQualityControlRequestDto } from './dto/request/alert-quality-control.request.dto';
import { GetAlerQualityControlRequestDto } from './dto/request/get-alert-quality-control.request.dto';
import { ApiOperation } from '@nestjs/swagger';
import { DEFAULT_TRANSPORT } from '@utils/constant';
import { NATS_PRODUCE } from '@config/nats.config';

@Controller('quality-controls')
export class QualityControlController {
  constructor(
    @Inject('QualityControlServiceInterface')
    private readonly qualityControlService: QualityControlServiceInterface,
  ) {}

  @Post('')
  @ApiOperation({
    tags: ['Work Order', 'QC', 'Execution'],
    summary: 'Qc Work Order',
    description: 'Thực hiện QC lệnh làm việc',
  })
  public async create(
    @Body() payload: CreateQcRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.createdByUserId = request.userId;

    return await this.qualityControlService.create(request);
  }

  @Post('material-inputs')
  @ApiOperation({
    tags: ['Work Order', 'QC', 'Execution', 'Material Input'],
    summary: 'Qc Work Order Material Input',
    description: 'Thực hiện QC nguyên vật liệu lệnh làm việc',
  })
  @MessagePattern(`${NATS_PRODUCE}.qc_material_input_create`, DEFAULT_TRANSPORT)
  public async createMaterialInputQC(
    @Body() payload: CreateMaterialInputQcRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.createdByUserId = request.userId;
    return await this.qualityControlService.createMaterialInputQC(request);
  }

  @Post('previous-boms')
  @ApiOperation({
    tags: ['Work Order', 'QC', 'Execution', 'Previous Bom'],
    summary: 'Qc Work Order Previous Bom',
    description: 'Thực hiện QC nguyên vật liệu lệnh làm việc',
  })
  @MessagePattern(
    `${NATS_PRODUCE}.qc_previous_bom_input_create`,
    DEFAULT_TRANSPORT,
  )
  public async createPreviousBomQC(
    @Body() payload: CreatePreviousBomQcRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.createdByUserId = request.userId;
    return await this.qualityControlService.createPreviousBomQC(request);
  }

  @Get('list')
  @ApiOperation({
    tags: ['Work Order', 'QC', 'List'],
    summary: 'Qc Work Order',
    description: 'Danh sách QC lệnh làm việc',
  })
  @MessagePattern(`${NATS_PRODUCE}.qc_list`, DEFAULT_TRANSPORT)
  public async list(
    @Query() payload: GetListQcRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qualityControlService.getList(request);
  }

  @Get(':id')
  @ApiOperation({
    tags: ['Work Order', 'QC', 'Detail'],
    summary: 'Qc Work Order',
    description: 'Chi tiết QC lệnh làm việc',
  })
  public async detail(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<ResponsePayload<any>> {
    return await this.qualityControlService.getDetail({
      id,
    } as GetDetailQcRequestDto);
  }

  @Put('alerts')
  @ApiOperation({
    tags: ['Work Order'],
    summary: 'Alert Work Order Quality Control',
  })
  @MessagePattern(`${NATS_PRODUCE}.quality_control_alert`, DEFAULT_TRANSPORT)
  public async alert(
    @Body() payload: AlertQualityControlRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qualityControlService.alert(request);
  }

  @Get('alerts')
  @ApiOperation({
    tags: ['Work Order'],
    summary: 'Get Alert Work Order Quality Control',
  })
  @MessagePattern(
    `${NATS_PRODUCE}.get_quality_control_alerts`,
    DEFAULT_TRANSPORT,
  )
  public async getAlerts(
    @Query() payload: GetAlerQualityControlRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qualityControlService.getAlerts(request);
  }

  // TO DO: remove when refactor done
  @MessagePattern(`${NATS_PRODUCE}.qc_list`, DEFAULT_TRANSPORT)
  public async listTcp(
    @Body() payload: GetListQcRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qualityControlService.getList(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.qc_detail`, DEFAULT_TRANSPORT)
  public async detailTcp(
    @Body() payload: GetDetailQcRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request } = payload;
    return await this.qualityControlService.getDetail(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.qc_create`, DEFAULT_TRANSPORT)
  public async createTcp(
    @Body() payload: CreateQcRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.createdByUserId = request.userId;

    return await this.qualityControlService.create(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.qc_material_input_create`, DEFAULT_TRANSPORT)
  public async createMaterialInputQCTcp(
    @Body() payload: CreateMaterialInputQcRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.createdByUserId = request.userId;
    return await this.qualityControlService.createMaterialInputQC(request);
  }

  @MessagePattern(
    `${NATS_PRODUCE}.qc_previous_bom_input_create`,
    DEFAULT_TRANSPORT,
  )
  public async createPreviousBomQCTcp(
    @Body() payload: CreatePreviousBomQcRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.createdByUserId = request.userId;
    return await this.qualityControlService.createPreviousBomQC(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.quality_control_alert`, DEFAULT_TRANSPORT)
  public async alertTcp(
    @Body() payload: AlertQualityControlRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.qualityControlService.alert(request);
  }
}
