import { ResponsePayload } from '@utils/response-payload';
import {
  CreateMaterialInputQcRequestDto,
  CreatePreviousBomQcRequestDto,
  CreateQcRequestDto,
} from '../dto/request/create-qc-request.dto';
import { GetDetailQcRequestDto } from '../dto/request/get-detail-qc.request.dto';
import { GetListQcRequestDto } from '../dto/request/get-list-qc.request.dto';
import { AlertQualityControlRequestDto } from '../dto/request/alert-quality-control.request.dto';
import { GetAlerQualityControlRequestDto } from '../dto/request/get-alert-quality-control.request.dto';

export interface QualityControlServiceInterface {
  create(request: CreateQcRequestDto): Promise<ResponsePayload<any>>;
  getList(request: GetListQcRequestDto): Promise<ResponsePayload<any>>;
  getAlerts(
    request: GetAlerQualityControlRequestDto,
  ): Promise<ResponsePayload<any>>;
  getDetail(request: GetDetailQcRequestDto): Promise<ResponsePayload<any>>;
  alert(request: AlertQualityControlRequestDto): Promise<ResponsePayload<any>>;
  getHightPrioriryAlert(
    producingStepId: number,
    moId: number,
    moPlanId: number,
  ): Promise<ResponsePayload<any>>;
  createMaterialInputQC(
    request: CreateMaterialInputQcRequestDto,
  ): Promise<ResponsePayload<any>>;
  createPreviousBomQC(
    request: CreatePreviousBomQcRequestDto,
  ): Promise<ResponsePayload<any>>;
}
