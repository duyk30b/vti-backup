import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { QualityControlEntity } from '@entities/quality-control/quality-control.entity';
import { GetListQcRequestDto } from '../dto/request/get-list-qc.request.dto';

export interface QualityControlRepositoryInterface
  extends BaseInterfaceRepository<QualityControlEntity> {
  createEntity(request: any): QualityControlEntity;
  getList(request: GetListQcRequestDto, filterItemIds?: number[]): Promise<any>;
  getDetail(id: number): Promise<any>;
  getSumamry(
    moIds: number[],
    itemId?: number,
    routingId?: number,
    producingStepId?: number,
  ): Promise<any>;
}
