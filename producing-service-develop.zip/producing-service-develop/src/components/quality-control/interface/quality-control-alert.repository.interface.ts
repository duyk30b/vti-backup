import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { QualityControlAlertEntity } from '@entities/quality-control/quality-control-alert.entity';

export interface QualityControlAlertRepositoryInterface
  extends BaseInterfaceRepository<QualityControlAlertEntity> {
  createEntity(request: any): QualityControlAlertEntity;
}
