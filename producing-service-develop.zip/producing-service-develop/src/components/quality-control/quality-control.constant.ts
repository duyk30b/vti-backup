export enum QualityControlStatusEnum {
  CREATED = 0,
  CONFIRMED = 1,
  REJECTED = 2,
}

export enum QualityControlTypeEnum {
  OUTPUT = 1,
  MATERIAL_INPUT = 2,
  PREVIOUS_BOM = 3,
}

export enum ALERT_WORK_ORDER_QUALITY_CONTROL_ENUM {
  PROGRESS_ALERT = 1,
  MATERIAL_INPUT_ALERT = 2,
  PREVIOUS_BOM_ALERT = 3,
}
