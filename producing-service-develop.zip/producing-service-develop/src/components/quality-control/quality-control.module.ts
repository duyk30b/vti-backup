import { RoutingEntity } from '@entities/routing/routing.entity';
import { BoqDetailRepository } from '@repositories/boq/boq-detail.repository';
import { ProducingStepRepository } from '@repositories/produce/producing-step.repository';
import { ProducingStepEntity } from '@entities/producing-step/producing-step.entity';
import { QualityControlController } from './quality-control.controller';
import { WorkOrderModule } from '@components/work-order/work-order.module';
import { Module, Global } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WorkOrderEntity } from '@entities/work-order/work-order.entity';
import { WorkOrderRepository } from '@repositories/work-order/work-order.repository';
import { UserModule } from '@components/user/user.module';
import { QualityControlService } from './quality-control.service';
import { QualityControlRepository } from '@repositories/quality-control/quality-control.repository';
import { QualityControlEntity } from '@entities/quality-control/quality-control.entity';
import { ItemModule } from '@components/item/item.module';
import { ItemService } from '@components/item/item.service';
import { BoqDetail } from '@entities/boq/boq-details.entity';
import { QualityControlCreatedListener } from './listeners/quality-control-created.listener';
import { BoqRepository } from '@repositories/boq/boq.repository';
import { Boq } from '@entities/boq/boqs.entity';
import { MoPlanBomEntity } from '@entities/manufacturing-order/mo-plan-boms.entity';
import { MoPlanBomRepository } from '@repositories/plan/mo-plan-bom.repository';
import { ManufacturingOrderDetailEntity } from '@entities/manufacturing-order/manufacturing-order-details.entity';
import { ManufacturingOrderDetailRepository } from '@repositories/manufacturing-order/manufacturing-order-detail.repository';
import { ManufacturingOrderEntity } from '@entities/manufacturing-order/manufacturing-orders.entity';
import { RoutingRepository } from '@repositories/routing.repository';
import { WorkOrderMaterialInputEntity } from '@entities/work-order/material-input/work-order-material_input.entity';
import { WorkOrderMaterialInputRepository } from '@repositories/work-order/work-order-material-input.repository';
import { WorkOrderBomTransitEntity } from '@entities/work-order/work-order-bom-transit.entity';
import { WorkOrderBomTransitRepository } from '@repositories/work-order/work-order-bom-transit.repository';
import { WorkOrderLotRepository } from '@repositories/work-order/work-order-lot.repository';
import { WorkOrderLotEntity } from '@entities/work-order/lot/work-order-lot.entity';
import { WorkOrderWorkCenterLotEntity } from '@entities/work-order/lot/work-order-work-center-lot.entity';
import { WorkOrderWorkCenterLotRepository } from '@repositories/work-order/work-order-work-center-lot.repository';
import { WorkCenterEntity } from '@entities/work-center/work-center.entity';
import { WorkCenterRepository } from '../../repositories/work-center/work-center.repository';
import { WorkCenterDailyScheduleRepository } from '@repositories/work-center/work-center-daily-schedule.repository';
import { WorkCenterShiftRepository } from '@repositories/work-center/work-center-shift.repository';
import { WorkCenterDailyScheduleShiftRepository } from '@repositories/work-center/work-center-daily-schedule-shift.repository';
import { WorkOrderScheduleDetailRepository } from '@repositories/work-order/work-order-schedule-detail.repository';
import { WorkCenterDailyScheduleShiftEntity } from '@entities/work-center/work-center-daily-schedule-shift.entity';
import { WorkOrderScheduleDetailEntity } from '@entities/work-order/work-order-schedule-detail.entity';
import { WorkCenterShiftEntity } from '@entities/work-center/work-center-shift.entity';
import { WorkCenterDailyScheduleEntity } from '@entities/work-center/work-center-daily-schedule.entity';
import { InTransitEntity } from '@entities/work-order/in-transit.entity';
import { InTransitRepository } from '@repositories/work-order/in-transit.repository';
import { WorkOrderScheduleEntity } from '@entities/work-order/work-order-schedule.entity';
import { WorkOrderScheduleRepository } from '@repositories/work-order/work-order-schedule.repository';
import { QualityControlAlertRepository } from '@repositories/quality-control/quality-control-alert.repository';
import { QualityControlAlertEntity } from '@entities/quality-control/quality-control-alert.entity';
import { ManufacturingOrderRepository } from '@repositories/manufacturing-order/manufacturing-order.repository';
import { ConfigService } from '@nestjs/config';

@Global()
@Module({
  imports: [
    TypeOrmModule.forFeature([
      WorkOrderEntity,
      QualityControlEntity,
      ProducingStepEntity,
      RoutingEntity,
      MoPlanBomEntity,
      BoqDetail,
      Boq,
      ManufacturingOrderDetailEntity,
      ManufacturingOrderEntity,
      WorkOrderMaterialInputEntity,
      WorkOrderBomTransitEntity,
      WorkOrderLotEntity,
      WorkOrderWorkCenterLotEntity,
      WorkCenterEntity,
      WorkOrderScheduleDetailEntity,
      WorkOrderScheduleEntity,
      WorkCenterDailyScheduleShiftEntity,
      WorkCenterShiftEntity,
      WorkCenterDailyScheduleEntity,
      InTransitEntity,
      QualityControlAlertEntity,
    ]),
    WorkOrderModule,
    UserModule,
    ItemModule,
  ],
  providers: [
    {
      provide: 'MoDetailRepositoryInterface',
      useClass: ManufacturingOrderDetailRepository,
    },
    {
      provide: 'ManufacturingOrderRepositoryInterface',
      useClass: ManufacturingOrderRepository,
    },
    {
      provide: 'WorkOrderMaterialInputRepositoryInterface',
      useClass: WorkOrderMaterialInputRepository,
    },
    {
      provide: 'WorkOrderLotRepositoryInterface',
      useClass: WorkOrderLotRepository,
    },
    {
      provide: 'WorkCenterRepositoryInterface',
      useClass: WorkCenterRepository,
    },
    {
      provide: 'WorkOrderWorkCenterLotRepositoryInterface',
      useClass: WorkOrderWorkCenterLotRepository,
    },
    {
      provide: 'WorkOrderBomTransitRepositoryInterface',
      useClass: WorkOrderBomTransitRepository,
    },
    {
      provide: 'InTransitRepositoryInterface',
      useClass: InTransitRepository,
    },
    {
      provide: 'WorkOrderRepositoryInterface',
      useClass: WorkOrderRepository,
    },
    {
      provide: 'RoutingRepositoryInterface',
      useClass: RoutingRepository,
    },
    {
      provide: 'MoPlanBomRepositoryInterface',
      useClass: MoPlanBomRepository,
    },
    {
      provide: 'ProducingStepRepositoryInterface',
      useClass: ProducingStepRepository,
    },
    {
      provide: 'QualityControlRepositoryInterface',
      useClass: QualityControlRepository,
    },
    {
      provide: 'QualityControlAlertRepositoryInterface',
      useClass: QualityControlAlertRepository,
    },
    {
      provide: 'BoqDetailRepositoryInterface',
      useClass: BoqDetailRepository,
    },
    {
      provide: 'BoqRepositoryInterface',
      useClass: BoqRepository,
    },
    {
      provide: 'QualityControlServiceInterface',
      useClass: QualityControlService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'WorkOrderScheduleDetailRepositoryInterface',
      useClass: WorkOrderScheduleDetailRepository,
    },
    {
      provide: 'WorkOrderScheduleRepositoryInterface',
      useClass: WorkOrderScheduleRepository,
    },
    {
      provide: 'WorkCenterDailyScheduleShiftRepositoryInterface',
      useClass: WorkCenterDailyScheduleShiftRepository,
    },
    {
      provide: 'WorkCenterShiftRepositoryInterface',
      useClass: WorkCenterShiftRepository,
    },
    {
      provide: 'WorkCenterDailyScheduleRepositoryInterface',
      useClass: WorkCenterDailyScheduleRepository,
    },
    ConfigService,
    QualityControlCreatedListener,
  ],
  controllers: [QualityControlController],
  exports: [
    {
      provide: 'QualityControlServiceInterface',
      useClass: QualityControlService,
    },
  ],
})
export class QualityControlModule {}
