import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

export class ItemTypeResponse {
  @Expose()
  id: number;

  @Expose()
  code: string;

  @Expose()
  name: string;
}

class ItemUnitResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}
export class ItemResponseDto {
  id: number;

  @Expose({ name: 'id' })
  itemId: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  description: string;

  @Expose()
  isProductionObject: boolean;

  @Expose()
  isHasBom: boolean;

  @Expose()
  itemDetails: any;

  @Expose()
  remainingQuantity: any;

  @Expose()
  minInventoryLimit: any;

  @Expose()
  manufactureQuantity: any;

  @Expose()
  planQuantity: any;

  @Expose()
  planningQuantity: any;

  @ApiProperty({ type: ItemTypeResponse })
  @Type(() => ItemTypeResponse)
  @Expose()
  itemType: ItemTypeResponse;

  @ApiProperty({ type: ItemUnitResponse })
  @Expose()
  @Type(() => ItemUnitResponse)
  itemUnit: ItemUnitResponse;
}
