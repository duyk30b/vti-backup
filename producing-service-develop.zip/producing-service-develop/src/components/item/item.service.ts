import { NATS_ITEM } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { escapeCharForSearch } from '@utils/common';
import { isEmpty } from 'class-validator';
import { map } from 'lodash';
import { ItemServiceInterface } from './interface/item.service.interface';

@Injectable()
export class ItemService implements ItemServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async getItemsByIds(
    itemIds: number[],
    serilize?: boolean,
    factoryId?: number,
    filter?: any,
    forceFilterByFactoryId?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_items_by_ids`,
      {
        itemIds,
        factoryId,
        filter,
        basicInfor: true,
        forceFilterByFactoryId,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    const serilizeItems = {};
    if (serilize) {
      response.data.forEach((item) => {
        serilizeItems[item.id] = item;
      });

      return serilizeItems;
    }
    return response.data;
  }

  async getItemDetail(id: number): Promise<any> {
    console.log('🚀 ~ file: item.service.ts:43  ~ getItemDetail ~ id:', id);
  }

  async getItemsByConditions(condition: any, sort?: any): Promise<any> {
    return await this.natsClientService.send(
      `${NATS_ITEM}.get_items_by_conditions`,
      {
        condition: condition,
        sort: sort,
      },
    );
  }

  async getItemsByRelations(relation: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_items_by_relations`,
      {
        relation: relation,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }

  async getItemsByName(filterByName, onlyId?: boolean): Promise<any> {
    if (isEmpty(filterByName)) {
      return [];
    }

    const response = await this.getItemsByConditions(
      'LOWER(unaccent(name)) LIKE ' +
        `LOWER(unaccent('%${escapeCharForSearch(
          filterByName.text,
        )}%')) escape '\\'`,
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    if (!isEmpty(response.data) && onlyId === true) {
      return map(response.data, 'id');
    }

    return response.data;
  }

  async updateIsHasBomItem(request: any): Promise<any> {
    return this.natsClientService.send(
      `${NATS_ITEM}.update_is_has_bom_items`,
      request,
    );
  }

  async getItemWarehouseListByItemIdsAndWarehouseIds(
    request: any,
    serilize?: boolean,
    setDataMissing?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_item_warehouses_by_itemIds_warehouseIds`,
      request,
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    if (!response.data) return [];
    if (setDataMissing) {
      const itemIdMissings = request.itemIds.filter(
        (x) => !response.data.includes(x),
      );
      itemIdMissings.forEach((itemId) => {
        response.data.push({
          itemId: itemId,
          itemQuantity: 0,
        });
      });
    }

    if (serilize) {
      if (isEmpty(response.data)) return [];
      const serilizeItemWarehouses = [];
      response.data.forEach((itemWarehouse) => {
        serilizeItemWarehouses[itemWarehouse.itemId] = itemWarehouse;
      });
      return serilizeItemWarehouses;
    }

    return response.data;
  }

  async getItemsByCode(filterByCode, onlyId?: boolean): Promise<any> {
    if (isEmpty(filterByCode)) {
      return [];
    }

    const response = await this.getItemsByConditions(
      'LOWER(code) LIKE ' +
        `LOWER('%${escapeCharForSearch(filterByCode.text)}%') escape '\\'`,
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    if (!isEmpty(response.data) && onlyId === true) {
      return map(response.data, 'id');
    }

    return response.data;
  }

  async getItemByItemUnitNameKeyWord(
    filterItemUnitName: any,
    onlyId?: boolean,
  ): Promise<any> {
    if (isEmpty(filterItemUnitName)) {
      return [];
    }

    const response = await this.natsClientService.send(
      `${NATS_ITEM}.get_items_by_item_unit_name`,
      {
        itemUnitName: filterItemUnitName.text,
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    if (!isEmpty(response.data) && onlyId === true) {
      return map(response.data, 'id');
    }

    return response.data;
  }

  async getItemInventoryNormByItemIds(itemIds: number[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_ITEM}.inventory_norm_list_by_item_ids`,
      {
        itemIds,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getItemUnitByIds(ids: number[], serilize?: boolean): Promise<any> {
    try {
      const payload = {
        filter: [{ column: 'ids', text: ids.join(',') }],
        isGetAll: '1',
      };
      const response = await this.natsClientService.send(
        `${NATS_ITEM}.get_list_item_unit_setting`,
        payload,
      );
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return [];
      }

      if (serilize) {
        if (isEmpty(response.data.items)) return {};
        const serilizeItemUnits = {};
        response.data.items.forEach((item) => {
          serilizeItemUnits[item.id] = item;
        });
        return serilizeItemUnits;
      }

      return response.data.items;
    } catch (err) {
      return;
    }
  }

  async getItemVersionByIds(ids?: number[], serialize?: boolean): Promise<any> {
    return;
  }
}
