export interface ItemServiceInterface {
  getItemsByIds(
    itemIds: number[],
    serilize?: boolean,
    factoryId?: number,
    filter?: any,
    forceFilterByFactoryId?: boolean,
  ): Promise<any>;
  getItemsByConditions(condition: any, sort?: any): Promise<any>;
  getItemsByRelations(relation: any): Promise<any>;
  getItemsByName(filterByName, onlyId?: boolean): Promise<any>;
  getItemsByCode(filterByCode, onlyId?: boolean): Promise<any>;
  updateIsHasBomItem(request: any): Promise<any>;
  getItemWarehouseListByItemIdsAndWarehouseIds(
    request: any,
    serilize?: boolean,
    setDataMissing?: boolean,
  ): Promise<any>;
  getItemByItemUnitNameKeyWord(
    filterItemUnitName: any,
    onlyId?: boolean,
  ): Promise<any>;
  getItemInventoryNormByItemIds(itemIds: number[]): Promise<any>;
  getItemUnitByIds(ids: number[], serilize?: boolean): Promise<any>;
  getItemVersionByIds(ids?: number[], serialize?: boolean): Promise<any>;
}
