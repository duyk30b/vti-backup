import { QmxModule } from '@components/qmx/qmx.module';
import { WorkCenterUserEntity } from '@entities/work-center/work-center-user.entity';
import { WorkCenterDailyScheduleShiftEntity } from '@entities/work-center/work-center-daily-schedule-shift.entity';
import { WorkCenterDailyScheduleShiftRepository } from '@repositories/work-center/work-center-daily-schedule-shift.repository';
import { WorkOrderLogTimeRepository } from '@repositories/work-order/work-order-log-time.repository';
import { WorkOrderLogTimeEntity } from '@entities/work-order/work-order-log-time.entity';
import { WorkOrderInputHistoryRepository } from '@repositories/work-order/work-order-input-history.repository';
import { WorkOrderInputHistoryEntity } from '@entities/work-order/material-input/work-order-input-history.entity';
import { WorkOrderInputDetailRepository } from '@repositories/work-order/work-order-input-detail.repository';
import { WorkOrderInputDetailEntity } from '@entities/work-order/work-order-bom-transit-history.entity';
import { InTransitHistoryRepository } from '@repositories/work-order/in-transit-history.repository';
import { InTransitRepository } from '@repositories/work-order/in-transit.repository';
import { InTransitEntity } from '@entities/work-order/in-transit.entity';
import { WorkOrderScrapTransactionEntity } from '@entities/work-order/work-order-scrap-transaction.entity';
import { WorkOrderTransactionEntity } from '@entities/work-order/work-order-transaction.entity';
import { WorkOrderTransactionRepository } from '@repositories/work-order/work-order-transaction.repository';
import { BomDetailRepository } from '@repositories/bom/bom-detail.repository';
import { BomDetailEntity } from '@entities/bom/bom-details.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WorkOrderEntity } from '@entities/work-order/work-order.entity';
import { WorkOrderRepository } from '@repositories/work-order/work-order.repository';
import { WorkOrderService } from '@components/work-order/work-order.service';
import { WorkOrderController } from '@components/work-order/work-order.controller';
import { RoutingEntity } from '@entities/routing/routing.entity';
import { RoutingRepository } from '@repositories/routing.repository';
import { RoutingProducingStepEntity } from '@entities/producing-step/routing-producing-step.entity';
import { RoutingProducingStepRepository } from '@repositories/produce/routing-producing-step.repository';
import { ProducingStepEntity } from '@entities/producing-step/producing-step.entity';
import { ProducingStepRepository } from '@repositories/produce/producing-step.repository';
import { BoqDetail } from '@entities/boq/boq-details.entity';
import { Boq } from '@entities/boq/boqs.entity';
import { BomRepository } from '@repositories/bom/bom.repository';
import { BomEntity } from '@entities/bom/boms.entity';
import { BoqRepository } from '@repositories/boq/boq.repository';
import { UserService } from '@components/user/user.service';
import { UserModule } from '@components/user/user.module';
import { ItemService } from '@components/item/item.service';
import { ItemModule } from '@components/item/item.module';
import { WorkOrderScrapTransactionRepository } from '@repositories/work-order/work-order-scrap-transaction.repository';
import { InTransitHistoryEntity } from '@entities/work-order/in-transit-history.entity';
import { QualityControlCreatedListener } from '@components/quality-control/listeners/quality-control-created.listener';
import { MoPlanBomRepository } from '@repositories/plan/mo-plan-bom.repository';
import { ManufacturingOrderRepository } from '@repositories/manufacturing-order/manufacturing-order.repository';
import { ManufacturingOrderDetailRepository } from '@repositories/manufacturing-order/manufacturing-order-detail.repository';
import { MoPlanRepository } from '@repositories/plan/mo-plan.repository';
import { MoPlanEntity } from '@entities/manufacturing-order/mo-plans.entity';
import { MoPlanBomEntity } from '@entities/manufacturing-order/mo-plan-boms.entity';
import { ManufacturingOrderEntity } from '@entities/manufacturing-order/manufacturing-orders.entity';
import { ManufacturingOrderDetailEntity } from '@entities/manufacturing-order/manufacturing-order-details.entity';
import { WorkOrderScheduleEntity } from '@entities/work-order/work-order-schedule.entity';
import { WorkOrderScheduleRepository } from '@repositories/work-order/work-order-schedule.repository';
import { WorkOrderScheduleDetailRepository } from '@repositories/work-order/work-order-schedule-detail.repository';
import { WorkOrderScheduleDetailEntity } from '@entities/work-order/work-order-schedule-detail.entity';
import { WorkCenterEntity } from '@entities/work-center/work-center.entity';
import { WorkCenterRepository } from '@repositories/work-center/work-center.repository';
import { QualityControlRepository } from '@repositories/quality-control/quality-control.repository';
import { QualityControlEntity } from '@entities/quality-control/quality-control.entity';
import { WorkCenterUserRepository } from '@repositories/work-center/work-center-user.repository';
import { WorkCenterDailyScheduleRepository } from '@repositories/work-center/work-center-daily-schedule.repository';
import { WorkCenterShiftRepository } from '@repositories/work-center/work-center-shift.repository';
import { WorkCenterShiftEntity } from '@entities/work-center/work-center-shift.entity';
import { WorkCenterDailyScheduleEntity } from '@entities/work-center/work-center-daily-schedule.entity';
import { WorkCenterService } from '@components/work-center/work-center.service';
import { WorkCenterModule } from '@components/work-center/work-center.module';
import { WorkCenterShiftRelaxTimeEntity } from '@entities/work-center/work-center-shift-relax-time.entity';
import { WorkOrderLogTimeDetailEntity } from '@entities/work-order/work-order-log-time-detail.entity';
import { WorkOrderLogTimeDetailRepository } from '@repositories/work-order/work-order-log-time-detail.repository';
import { QualityControlService } from '@components/qmx/quality-control.service';
import { ManufacturingOrderProgressListener } from '@components/manufacturing-order/listeners/manufacturing-order-progress.listener';
import { WorkOrderMaterialInputEntity } from '@entities/work-order/material-input/work-order-material_input.entity';
import { WorkOrderMaterialInputRepository } from '@repositories/work-order/work-order-material-input.repository';
import { WorkOrderLotEntity } from '@entities/work-order/lot/work-order-lot.entity';
import { WorkOrderLotRepository } from '@repositories/work-order/work-order-lot.repository';
import { MaterialPlanScheduleEntity } from '@entities/material/material-plan-schedules.entity';
import { MaterialPlanScheduleRepository } from '@repositories/material/material-plan-schedule.repository';
import { WorkOrderWorkCenterLotEntity } from '@entities/work-order/lot/work-order-work-center-lot.entity';
import { WorkOrderWorkCenterLotRepository } from '@repositories/work-order/work-order-work-center-lot.repository';
import { BomProducingStepDetailsRepository } from '@repositories/bom/bom-producing-step-details.repository';
import { BomProducingStepDetailEntity } from '@entities/bom/bom-producing-steps.entity';
import { SaleCronService } from '@components/sale-order/sale-order-cron.service';
import { QualityControlAlertRepository } from '@repositories/quality-control/quality-control-alert.repository';
import { QualityControlAlertEntity } from '@entities/quality-control/quality-control-alert.entity';
import { WorkOrderBomTransitEntity } from '@entities/work-order/work-order-bom-transit.entity';
import { WorkOrderBomTransitRepository } from '@repositories/work-order/work-order-bom-transit.repository';
import { ConfigService } from '@config/config.service';
import { WorkOrderRunningLogsEntity } from '@entities/work-order/work-order-running-logs.entity';
import { WorkOrderRunningLogsRepository } from '@repositories/work-order/work-order-running-logs.repository';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      WorkOrderEntity,
      RoutingEntity,
      RoutingProducingStepEntity,
      ProducingStepEntity,
      Boq,
      BoqDetail,
      BomDetailEntity,
      BomEntity,
      ManufacturingOrderEntity,
      ManufacturingOrderDetailEntity,
      MoPlanBomEntity,
      MoPlanEntity,
      WorkOrderTransactionEntity,
      WorkOrderScrapTransactionEntity,
      InTransitEntity,
      InTransitHistoryEntity,
      WorkOrderInputDetailEntity,
      WorkOrderInputHistoryEntity,
      WorkOrderLogTimeEntity,
      WorkOrderBomTransitEntity,
      WorkOrderScheduleEntity,
      WorkOrderScheduleDetailEntity,
      WorkCenterEntity,
      QualityControlEntity,
      WorkCenterShiftEntity,
      QualityControlEntity,
      WorkCenterDailyScheduleShiftEntity,
      WorkCenterDailyScheduleEntity,
      WorkCenterUserEntity,
      WorkCenterShiftRelaxTimeEntity,
      WorkOrderLogTimeDetailEntity,
      WorkOrderMaterialInputEntity,
      WorkOrderLotEntity,
      WorkOrderWorkCenterLotEntity,
      MaterialPlanScheduleEntity,
      BomProducingStepDetailEntity,
      WorkOrderRunningLogsEntity,
      QualityControlAlertEntity,
    ]),
    UserModule,
    ItemModule,
    WorkCenterModule,
    QmxModule,
  ],
  providers: [
    {
      provide: 'WorkOrderRepositoryInterface',
      useClass: WorkOrderRepository,
    },
    {
      provide: 'InTransitRepositoryInterface',
      useClass: InTransitRepository,
    },
    {
      provide: 'WorkOrderTransactionRepositoryInterface',
      useClass: WorkOrderTransactionRepository,
    },
    {
      provide: 'WorkOrderBomTransitRepositoryInterface',
      useClass: WorkOrderBomTransitRepository,
    },
    {
      provide: 'WorkOrderScrapTransactionRepositoryInterface',
      useClass: WorkOrderScrapTransactionRepository,
    },
    {
      provide: 'WorkOrderInputHistoryRepositoryInterface',
      useClass: WorkOrderInputHistoryRepository,
    },
    {
      provide: 'ProducingStepRepositoryInterface',
      useClass: ProducingStepRepository,
    },
    {
      provide: 'WorkOrderLotRepositoryInterface',
      useClass: WorkOrderLotRepository,
    },
    {
      provide: 'WorkOrderWorkCenterLotRepositoryInterface',
      useClass: WorkOrderWorkCenterLotRepository,
    },
    {
      provide: 'RoutingProducingStepRepositoryInterface',
      useClass: RoutingProducingStepRepository,
    },
    {
      provide: 'RoutingRepositoryInterface',
      useClass: RoutingRepository,
    },
    {
      provide: 'QualityControlRepositoryInterface',
      useClass: QualityControlRepository,
    },
    {
      provide: 'QualityControlAlertRepositoryInterface',
      useClass: QualityControlAlertRepository,
    },
    { provide: 'BoqRepositoryInterface', useClass: BoqRepository },
    {
      provide: 'MoRepositoryInterface',
      useClass: ManufacturingOrderRepository,
    },
    {
      provide: 'MoDetailRepositoryInterface',
      useClass: ManufacturingOrderDetailRepository,
    },
    {
      provide: 'WorkOrderRunningLogsRepositoryInterface',
      useClass: WorkOrderRunningLogsRepository,
    },
    {
      provide: 'MoPlanBomRepositoryInterface',
      useClass: MoPlanBomRepository,
    },
    {
      provide: 'MoPlanRepositoryInterface',
      useClass: MoPlanRepository,
    },
    {
      provide: 'BomRepositoryInterface',
      useClass: BomRepository,
    },
    {
      provide: 'BomDetailRepositoryInterface',
      useClass: BomDetailRepository,
    },
    {
      provide: 'WorkOrderMaterialInputRepositoryInterface',
      useClass: WorkOrderMaterialInputRepository,
    },
    {
      provide: 'InTransitHistoryRepositoryInterface',
      useClass: InTransitHistoryRepository,
    },
    {
      provide: 'WorkOrderInputDetailRepositoryInterface',
      useClass: WorkOrderInputDetailRepository,
    },
    {
      provide: 'WorkOrderServiceInterface',
      useClass: WorkOrderService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'WorkOrderLogTimeRepositoryInterface',
      useClass: WorkOrderLogTimeRepository,
    },
    {
      provide: 'WorkOrderLogTimeDetailRepositoryInterface',
      useClass: WorkOrderLogTimeDetailRepository,
    },
    {
      provide: 'WorkOrderScheduleRepositoryInterface',
      useClass: WorkOrderScheduleRepository,
    },
    {
      provide: 'WorkOrderScheduleDetailRepositoryInterface',
      useClass: WorkOrderScheduleDetailRepository,
    },
    {
      provide: 'WorkCenterRepositoryInterface',
      useClass: WorkCenterRepository,
    },
    {
      provide: 'WorkCenterShiftRepositoryInterface',
      useClass: WorkCenterShiftRepository,
    },
    {
      provide: 'WorkCenterDailyScheduleShiftRepositoryInterface',
      useClass: WorkCenterDailyScheduleShiftRepository,
    },
    {
      provide: 'WorkCenterDailyScheduleRepositoryInterface',
      useClass: WorkCenterDailyScheduleRepository,
    },
    {
      provide: 'WorkCenterUserRepositoryInterface',
      useClass: WorkCenterUserRepository,
    },
    {
      provide: 'WorkCenterServiceInterface',
      useClass: WorkCenterService,
    },
    {
      provide: 'QmsxServiceInterface',
      useClass: QualityControlService,
    },
    {
      provide: 'MaterialPlanScheduleRepositoryInterface',
      useClass: MaterialPlanScheduleRepository,
    },
    {
      provide: 'BomProducingStepDetailsRepositoryInterface',
      useClass: BomProducingStepDetailsRepository,
    },
    {
      provide: 'ManufacturingOrderRepositoryInterface',
      useClass: ManufacturingOrderRepository,
    },
    ConfigService,
    SaleCronService,
    QualityControlCreatedListener,
    ManufacturingOrderProgressListener,
  ],
  exports: [
    {
      provide: 'WorkOrderRepositoryInterface',
      useClass: WorkOrderRepository,
    },
    {
      provide: 'InTransitRepositoryInterface',
      useClass: InTransitRepository,
    },
    {
      provide: 'WorkOrderTransactionRepositoryInterface',
      useClass: WorkOrderTransactionRepository,
    },
    {
      provide: 'WorkOrderBomTransitRepositoryInterface',
      useClass: WorkOrderBomTransitRepository,
    },
    {
      provide: 'WorkOrderScrapTransactionRepositoryInterface',
      useClass: WorkOrderScrapTransactionRepository,
    },
    {
      provide: 'WorkOrderInputHistoryRepositoryInterface',
      useClass: WorkOrderInputHistoryRepository,
    },
    {
      provide: 'ProducingStepRepositoryInterface',
      useClass: ProducingStepRepository,
    },
    {
      provide: 'WorkOrderLotRepositoryInterface',
      useClass: WorkOrderLotRepository,
    },
    {
      provide: 'WorkOrderWorkCenterLotRepositoryInterface',
      useClass: WorkOrderWorkCenterLotRepository,
    },
    {
      provide: 'RoutingProducingStepRepositoryInterface',
      useClass: RoutingProducingStepRepository,
    },
    {
      provide: 'RoutingRepositoryInterface',
      useClass: RoutingRepository,
    },
    {
      provide: 'QualityControlRepositoryInterface',
      useClass: QualityControlRepository,
    },
    {
      provide: 'QualityControlAlertRepositoryInterface',
      useClass: QualityControlAlertRepository,
    },
    { provide: 'BoqRepositoryInterface', useClass: BoqRepository },
    {
      provide: 'MoRepositoryInterface',
      useClass: ManufacturingOrderRepository,
    },
    {
      provide: 'MoDetailRepositoryInterface',
      useClass: ManufacturingOrderDetailRepository,
    },
    {
      provide: 'WorkOrderRunningLogsRepositoryInterface',
      useClass: WorkOrderRunningLogsRepository,
    },
    {
      provide: 'MoPlanBomRepositoryInterface',
      useClass: MoPlanBomRepository,
    },
    {
      provide: 'MoPlanRepositoryInterface',
      useClass: MoPlanRepository,
    },
    {
      provide: 'BomRepositoryInterface',
      useClass: BomRepository,
    },
    {
      provide: 'BomDetailRepositoryInterface',
      useClass: BomDetailRepository,
    },
    {
      provide: 'WorkOrderMaterialInputRepositoryInterface',
      useClass: WorkOrderMaterialInputRepository,
    },
    {
      provide: 'InTransitHistoryRepositoryInterface',
      useClass: InTransitHistoryRepository,
    },
    {
      provide: 'WorkOrderInputDetailRepositoryInterface',
      useClass: WorkOrderInputDetailRepository,
    },
    {
      provide: 'WorkOrderServiceInterface',
      useClass: WorkOrderService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'WorkOrderLogTimeRepositoryInterface',
      useClass: WorkOrderLogTimeRepository,
    },
    {
      provide: 'WorkOrderLogTimeDetailRepositoryInterface',
      useClass: WorkOrderLogTimeDetailRepository,
    },
    {
      provide: 'WorkOrderScheduleRepositoryInterface',
      useClass: WorkOrderScheduleRepository,
    },
    {
      provide: 'WorkOrderScheduleDetailRepositoryInterface',
      useClass: WorkOrderScheduleDetailRepository,
    },
    {
      provide: 'WorkCenterRepositoryInterface',
      useClass: WorkCenterRepository,
    },
    {
      provide: 'WorkCenterShiftRepositoryInterface',
      useClass: WorkCenterShiftRepository,
    },
    {
      provide: 'WorkCenterDailyScheduleShiftRepositoryInterface',
      useClass: WorkCenterDailyScheduleShiftRepository,
    },
    {
      provide: 'WorkCenterDailyScheduleRepositoryInterface',
      useClass: WorkCenterDailyScheduleRepository,
    },
    {
      provide: 'WorkCenterUserRepositoryInterface',
      useClass: WorkCenterUserRepository,
    },
    {
      provide: 'WorkCenterServiceInterface',
      useClass: WorkCenterService,
    },
    {
      provide: 'QmsxServiceInterface',
      useClass: QualityControlService,
    },
    {
      provide: 'MaterialPlanScheduleRepositoryInterface',
      useClass: MaterialPlanScheduleRepository,
    },
    {
      provide: 'BomProducingStepDetailsRepositoryInterface',
      useClass: BomProducingStepDetailsRepository,
    },
    ConfigService,
    SaleCronService,
    QualityControlCreatedListener,
    ManufacturingOrderProgressListener,
  ],
  controllers: [WorkOrderController],
})
export class WorkOrderModule {}
