import { MoPlanStatus } from '@constant/common';

export enum WorkOrderRunningStatusEnum {
  STOP = 0,
  RUNNING = 1,
  PAUSE = 2,
  END = 3,
}
export enum WorkOrderStatusEnum {
  CREATED = 0,
  CONFIRMED = 1,
  REJECTED = 2,
  IN_PROGRESS = 3,
  COMPLETED = 4,
}

export enum WorkOrderScheduleStatusEnum {
  CREATED = 0,
  CONFIRMED = 1,
  REJECTED = 2,
  IN_PROGRESS = 3,
  COMPLETED = 4,
}

export enum WorkOrderScheduleDetailStatusEnum {
  CREATED = 0,
  CONFIRMED = 1,
  REJECTED = 2,
  IN_PROGRESS = 3,
  COMPLETED = 4,
}

export enum TransitStatusEnum {
  CREATED = 0,
  REJECTED = 1,
  CONFIRMED = 2,
  IN_PROGRESS = 3,
  COMPLETED = 4,
}

export const CAN_CONFIRM_IN_TRANSIT_STATUS: number[] = [
  TransitStatusEnum.CREATED,
  TransitStatusEnum.REJECTED,
];

export const CAN_REJECT_IN_TRANSIT_STATUS: number[] = [
  TransitStatusEnum.CREATED,
];

export const CAN_IMPORT_IN_TRANSIT_STATUS: number[] = [
  TransitStatusEnum.CONFIRMED,
  TransitStatusEnum.IN_PROGRESS,
];

export const CAN_UPDATE_WORK_ORDER_STATUS: number[] = [
  WorkOrderStatusEnum.CREATED,
  WorkOrderStatusEnum.REJECTED,
  WorkOrderStatusEnum.CONFIRMED,
];

export const CAN_DELETE_WORK_ORDER_STATUS: number[] = [
  WorkOrderStatusEnum.CREATED,
  WorkOrderStatusEnum.REJECTED,
];

export const CAN_SUBMIT_WORK_ORDER_INPUT: number[] = [
  WorkOrderStatusEnum.IN_PROGRESS,
  WorkOrderStatusEnum.CONFIRMED,
];

export const CAN_SUBMIT_WORK_ORDER_SCRAP: number[] = [
  WorkOrderStatusEnum.IN_PROGRESS,
  WorkOrderStatusEnum.CONFIRMED,
  WorkOrderStatusEnum.COMPLETED,
];

export const CAN_SET_RUNNING_STATUS_WORK_ORDER: number[] = [
  WorkOrderStatusEnum.IN_PROGRESS,
  WorkOrderStatusEnum.CONFIRMED,
  WorkOrderStatusEnum.COMPLETED,
];

export const CAN_EXPORT_WORK_ORDER_STATUS: number[] = [
  WorkOrderStatusEnum.IN_PROGRESS,
  WorkOrderStatusEnum.COMPLETED,
];

export const CAN_SCAN_WORK_ORDER_STATUS: number[] = [
  WorkOrderStatusEnum.IN_PROGRESS,
  WorkOrderStatusEnum.CONFIRMED,
  WorkOrderStatusEnum.COMPLETED,
];

export const CAN_QC_WORK_ORDER: number[] = [WorkOrderStatusEnum.IN_PROGRESS];
export const CAN_LOG_TIME_WORK_ORDER: number[] = [
  WorkOrderStatusEnum.IN_PROGRESS,
  WorkOrderStatusEnum.CONFIRMED,
];

export const WORK_ORDER_CODE_PREFIX = 'WO';
export const WORK_ORDER_SCHEDULE_CODE_PREFIX = 'WOS';

export const FormatCodeWorkOrder = `${WORK_ORDER_CODE_PREFIX}`;
export const FormatCodeWorkOrderSchedule = `${WORK_ORDER_SCHEDULE_CODE_PREFIX}`;

export const PLAN_STATUS_ALLOW_CONFIRM = [
  MoPlanStatus.CONFIRMED,
  MoPlanStatus.IN_PROGRESS,
];

export const CAN_APPROVE_WORK_ORDER_SCHEDULE_STATUS: number[] = [
  WorkOrderScheduleStatusEnum.CREATED,
  WorkOrderScheduleStatusEnum.REJECTED,
];

export const CAN_REJECT_WORK_ORDER_SCHEDULE_STATUS: number[] = [
  WorkOrderScheduleStatusEnum.CREATED,
];

export const CAN_APPROVE_WORK_ORDER_SCHEDULE_DETAIL_STATUS: number[] = [
  WorkOrderScheduleDetailStatusEnum.CREATED,
  WorkOrderScheduleDetailStatusEnum.REJECTED,
];

export const CAN_REJECT_WORK_ORDER_SCHEDULE_DETAIL_STATUS: number[] = [
  WorkOrderScheduleDetailStatusEnum.CREATED,
];

export const CAN_APPROVE_WORK_ORDER_SCHEDULE_DETAIL_BY_WOS_STATUS: number[] = [
  WorkOrderScheduleStatusEnum.COMPLETED,
  WorkOrderScheduleStatusEnum.CONFIRMED,
];

export const CAN_DELETE_WORK_ORDER_SCHEDULE_DETAIL_STATUS: number[] = [
  WorkOrderScheduleDetailStatusEnum.CREATED,
  WorkOrderScheduleDetailStatusEnum.REJECTED,
];

export const STAGE_OPTIONS = {
  PO_IMPORT: 0,
  PRO_IMPORT: 2,
  PRO_EXPORT: 3,
  SO_EXPORT: 5,
  OUTPUT_PRODUCTION: 8,
  INPUT_PRODUCTION: 9,
};
