import { UpdateQualityControlWorkOrderRequestDto } from './dto/request/update-quality-control-work-order.request.dto';
import {
  Body,
  Controller,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { isEmpty } from 'lodash';
import { MessagePattern, Payload } from '@nestjs/microservices';
import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { WorkOrderServiceInterface } from '@components/work-order/interface/work-order.service.interface';
import { CreateWorkOrderRequestDto } from '@components/work-order/dto/request/create-work-order.request.dto';
import { UpdateWorkOrderRequestDto } from '@components/work-order/dto/request/update-work-order.request.dto';
import { SetStatusRequestDto } from '@components/work-order/dto/request/set-status.request.dto';
import { GetListWorkOrderRequestDto } from '@components/work-order/dto/request/get-list-work-order.request.dto';
import { WorkOrderResponseDto } from '@components/work-order/dto/response/work-order.response.dto';
import { GetListWorkOrderResponseDto } from '@components/work-order/dto/response/get-list-work-order.response.dto';
import { ScanWorkOrderRequestDto } from './dto/request/scan-work-order.request.dto';
import { SubmitWorkOrderInputRequestDto } from './dto/request/submit-work-order-input.request.dto';
import { SubmitWorkOrderScrapRequestDto } from './dto/request/submit-work-order-scrap.request.dto';
import { SubmitWorkOrderProgressRequestDto } from './dto/request/submit-work-order-progress.request.dto';
import { GetListWorkOrderTransactionRequestDto } from './dto/request/get-list-work-order-transaction.request.dto';
import { GetDetailWorkOrderTransactionRequestDto } from './dto/request/get-detail-work-order-transaction.request.dto';
import { SubmitWorkOrderExportRequestDto } from './dto/request/submit-export-work-order.request.dto';
import { GetListWorkOrderBomTransitHistoryRequestDto } from '@components/work-order/dto/request/get-list-work-order-bom-transit-history.request.dto';
import { GetListWorkOrderScrapTransactionRequestDto } from '@components/work-order/dto/request/get-list-work-order-scrap-transaction.request.dto';
import { GetDetailWorkOrderBomTransitHistoryRequestDto } from '@components/work-order/dto/request/get-detail-work-order-bom-transit-history.request.dto';
import { GetDetailWorkOrderScrapTransactionRequestDto } from '@components/work-order/dto/request/get-detail-work-order-scrap-transaction.request.dto';
import { GetListWorkOrderBomTransitHistoryResponseDto } from '@components/work-order/dto/response/get-list-work-order-bom-transit-history.response.dto';
import { GetListWorkOrderScrapTransactionResponseDto } from '@components/work-order/dto/response/get-list-work-order-scrap-transaction.response.dto';
import { WorkOrderBomTransitHistoryResponseDto } from '@components/work-order/dto/response/work-order-bom-transit-history.response.dto';
import { WorkOrderScrapTransactionResponseDto } from '@components/work-order/dto/response/work-order-scrap-transaction.response.dto';
import { GetListInTransitRequestDto } from './dto/request/get-list-in-transit.request.dto';
import { DetailWorkOrderExportRequestDto } from './dto/request/detail-work-order-export.request.dto';
import { GetDetailInTransitRequestDto } from './dto/request/get-detail-in-transit.request.dto';
import { ChangeStatusInTransitRequestDto } from './dto/request/change-status-in-transit.request.dto';
import { InTransitResponseDto } from './dto/response/in-transit.response.dto';
import { ImportInTransitRequestDto } from './dto/request/import-in-transit.request.dto';
import { PrintQrcodeRequestDto } from './dto/request/print.request.dto';
import { CreateWorkOrderLogTimeRequestDto } from './dto/request/create-work-order-log-time.request.dto';
import { GetDetailWorkOrderByBomAndProducingStepRequestDto } from './dto/request/get-detail-work-order-by-bom-and-producing-step.request.dto';
import { CreateWorkOrderScheduleRequestDto } from './dto/request/create-work-order-schedule.request.dto';
import { WorkOrderScheduleResponseDto } from './dto/response/work-order-schedule.response.dto';
import { GetWorkOrderScheduleRequestDto } from './dto/request/get-work-order-schedule.request.dto';
import { ChangeStatusWorkOrderScheduleRequestDto } from './dto/request/change-status-work-order-schedule.request.dto';
import { GetWorkOrderScheduleDetailResponseDto } from './dto/response/work-order-schedule-detail.response.dto';
import { GetListWorkOrderScheduleRequestDto } from './dto/request/get-list-work-order-schedule.request.dto';
import { DeleteWorkOrderScheduleDetailRequestDto } from './dto/request/delete-work-order-schedule-detail.request.dto';
import { ApiOperation, ApiParam, ApiResponse } from '@nestjs/swagger';
import { SubmitWorkOrderInputResponseDto } from './dto/response/submit-work-order-input.response.dto';
import { ImportWorkOrderMaterialInputRequestDto } from './dto/request/import-work-order-material-input.request.dto';
import { UpdateWorkOrderGranttDataRequestDto } from './dto/response/update-work-order-grantt-data.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  UPDATE_WORK_ORDER_PERMISSION,
  DELETE_WORK_ORDER_PERMISSION,
  DETAIL_WORK_ORDER_PERMISSION,
  LIST_WORK_ORDER_PERMISSION,
  CONFIRM_WORK_ORDER_PERMISSION,
  REJECT_WORK_ORDER_PERMISSION,
} from '@utils/permissions/work-order';
import {
  DeleteRequestDto,
  DetailRequestDto,
  GetDataByIdRequestDto,
} from '@utils/common.request.dto';
import {
  CONFIRM_WORK_ORDER_SCHEDULE_PERMISSION,
  DETAIL_WORK_ORDER_SCHEDULE_PERMISSION,
  LIST_WORK_ORDER_SCHEDULE_PERMISSION,
  REJECT_WORK_ORDER_SCHEDULE_PERMISSION,
  UPDATE_WORK_ORDER_SCHEDULE_PERMISSION,
} from '@utils/permissions/work-order-schedule';
import {
  CONFIRM_WORK_CENTER_DAILY_SCHEDULE_PERMISSION,
  DELETE_WORK_CENTER_DAILY_SCHEDULE_PERMISSION,
  LIST_WORK_CENTER_DAILY_SCHEDULE_PERMISSION,
  REJECT_WORK_CENTER_DAILY_SCHEDULE_PERMISSION,
} from '@utils/permissions/work-center-plan';
import { GetWorkOrderLogTimeRequestDto } from './dto/request/get-work-order-log-time.request.dto';
import { LogTimeByWoIdsRequestDto } from './dto/request/log-time-by-wo-ids.request.dto';
import { AutocompleteRequestDto } from './dto/request/autocomplete.request.dto';
import { WorkOrderScanResponseDto } from './dto/response/work-order-scan.response.dto';
import { ProduceMonitoringRequestDto } from './dto/request/produce-monitoring.request.dto';
import { DEFAULT_TRANSPORT } from '@utils/constant';
import { SuccessResponseDto } from '@components/producing-step/dto/response/success.response.dto';
import { ChangeRunningStatusRequestDto } from './dto/request/change-running-status.request.dto';
import { NATS_PRODUCE } from '@config/nats.config';

@Controller('work-orders')
export class WorkOrderController {
  constructor(
    @Inject('WorkOrderServiceInterface')
    private readonly workOrderService: WorkOrderServiceInterface,
  ) {}

  @Post('create')
  @ApiOperation({
    tags: ['Work Order'],
    summary: 'Create Work Order',
    description: 'Tạo mới lệnh làm việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: WorkOrderResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.work_order_create`, DEFAULT_TRANSPORT)
  public async create(
    @Body() payload: CreateWorkOrderRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.workOrderService.create(request);
  }

  @PermissionCode(UPDATE_WORK_ORDER_PERMISSION.code)
  @Put(':id')
  @ApiOperation({
    tags: ['Work Order'],
    summary: 'Update Work Order',
    description: 'Sửa thông lệnh làm việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: WorkOrderResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.work_order_update`, DEFAULT_TRANSPORT)
  public async update(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateWorkOrderRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;

    return await this.workOrderService.update(request);
  }

  @PermissionCode(DETAIL_WORK_ORDER_PERMISSION.code)
  @Get(':id')
  @ApiOperation({
    tags: ['Work Order'],
    summary: 'Detail Work Order',
    description: 'Chi tiết lệnh làm việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: WorkOrderResponseDto,
  })
  public async detail(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    return await this.workOrderService.detail(id);
  }

  @Get('/bom-id/:bomId/producing-step-id/:producingStepId')
  @ApiOperation({
    tags: ['Work Order'],
    summary: 'Detail Work Order By Bom And Producing step',
    description: 'Chi tiết lệnh làm việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: WorkOrderResponseDto,
  })
  @ApiParam({
    name: 'bomId',
    type: Number,
    example: 208,
    required: true,
    description: 'Boq Bom Plan ID',
  })
  @ApiParam({
    name: 'producingStepId',
    type: Number,
    example: 49,
    required: true,
    description: 'Producing Step ID',
  })
  @MessagePattern(
    `${NATS_PRODUCE}.work_order_detail_by_bom_and_producing_step`,
    DEFAULT_TRANSPORT,
  )
  public async detailWorkOrderByBomAndProducingStep(
    @Param('bomId', new ParseIntPipe()) bomId,
    @Param('producingStepId', new ParseIntPipe()) producingStepId,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    return await this.workOrderService.detailByBomAndProducingStep({
      bomId,
      producingStepId,
    } as GetDetailWorkOrderByBomAndProducingStepRequestDto);
  }

  @PermissionCode(DELETE_WORK_ORDER_PERMISSION.code)
  @MessagePattern(`${NATS_PRODUCE}.work_order_delete`, DEFAULT_TRANSPORT)
  public async delete(
    @Body() payload: DeleteRequestDto,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.workOrderService.delete(request.id);
  }

  // @PermissionCode(LIST_WORK_ORDER_PERMISSION.code)
  @Get('/list')
  @ApiOperation({
    tags: ['Work Order'],
    summary: 'List Work Order',
    description: 'Danh sách lệnh làm việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListWorkOrderResponseDto,
  })
  public async getList(
    @Query() payload: GetListWorkOrderRequestDto,
  ): Promise<ResponsePayload<GetListWorkOrderResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workOrderService.getList(request);
  }

  @PermissionCode(CONFIRM_WORK_ORDER_PERMISSION.code)
  @MessagePattern(`${NATS_PRODUCE}.confirm_work_order`, DEFAULT_TRANSPORT)
  public async confirm(
    @Body() payload: SetStatusRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workOrderService.confirm(request);
  }

  @PermissionCode(REJECT_WORK_ORDER_PERMISSION.code)
  @MessagePattern(`${NATS_PRODUCE}.reject_work_order`, DEFAULT_TRANSPORT)
  public async reject(
    @Body() payload: SetStatusRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workOrderService.reject(request);
  }

  @Get('/qr-code/scan')
  @ApiOperation({
    tags: ['Work Order', 'QR Code', 'Scan', 'Mobile'],
    summary: 'Detail Work Order By Qr Code',
    description: 'Scan chi tiết lệnh làm việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Scan Detail successfully',
    type: WorkOrderScanResponseDto,
  })
  public async scan(
    @Query() payload: ScanWorkOrderRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workOrderService.scan(request);
  }

  @Get('exports/scan')
  @ApiOperation({
    tags: ['Work Order Export', 'QR Code', 'Scan', 'Mobile'],
    summary: 'Export Work Order By Qr Code',
    description: 'Scan xuất công đoạn',
  })
  @ApiResponse({
    status: 200,
    description: 'Scan Detail successfully',
    type: WorkOrderScanResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.work_order_export_scan`, DEFAULT_TRANSPORT)
  public async exportScan(
    @Query() payload: ScanWorkOrderRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workOrderService.exportScan(request);
  }

  @Get(':id/exports/detail')
  @ApiOperation({
    tags: ['Work Order Export', 'Export', 'Mobile'],
    summary: 'Export Work Order By Work Order Id',
    description: 'Scan xuất công đoạn',
  })
  @ApiResponse({
    status: 200,
    description: 'Scan Detail successfully',
    type: WorkOrderScanResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.work_order_export_detail`, DEFAULT_TRANSPORT)
  public async exportDetail(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    return await this.workOrderService.exportDetail({
      id,
    } as DetailWorkOrderExportRequestDto);
  }

  @Post(':id/exports/submit')
  @ApiOperation({
    tags: ['Work Order', 'Export', 'Submit', 'Mobile'],
    summary: 'Export Work Order',
    description: 'Xuất công đoạn',
  })
  @ApiResponse({
    status: 200,
    description: 'Work Order Export successfully',
    type: SuccessResponse,
  })
  @MessagePattern(`${NATS_PRODUCE}.work_order_export_submit`, DEFAULT_TRANSPORT)
  public async exportSubmit(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() payload: SubmitWorkOrderExportRequestDto,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;
    request.createdByUserId = request.user?.id;

    return await this.workOrderService.exportSubmit(request);
  }

  @Put(':id/inputs/')
  @ApiOperation({
    tags: ['Work Order', 'Inputs', 'Submit', 'Mobile'],
    summary: 'Submit Work Order Material Input',
    description: 'Submit nguyên vật liệu đầu vào lệnh làm việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Submit successfully',
    type: SubmitWorkOrderInputResponseDto,
  })
  @MessagePattern(
    `${NATS_PRODUCE}.work_order_material_input_submit`,
    DEFAULT_TRANSPORT,
  )
  public async inputSubmit(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() payload: SubmitWorkOrderInputRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    request.createdByUserId = request.user?.id;

    return await this.workOrderService.materialInputSubmit(request);
  }

  @Put('/work-orders/:id/material-inputs/')
  @ApiOperation({
    tags: ['Work Order', 'Material', 'Submit'],
    summary: 'Submit Work Order Material Input',
    description: 'Nhập nguyên vật liệu đầu vào lệnh làm việc(kho)',
  })
  @ApiResponse({
    status: 200,
    description: 'Submit successfully',
    type: SubmitWorkOrderInputResponseDto,
  })
  @MessagePattern(
    `${NATS_PRODUCE}.work_order_material_input_import`,
    DEFAULT_TRANSPORT,
  )
  public async materialInputImport(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() payload: ImportWorkOrderMaterialInputRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;
    request.createdByUserId = request.user?.id;

    return await this.workOrderService.materialInputImport(request);
  }

  @Put(':id/scraps/')
  @ApiOperation({
    tags: ['Work Order', 'Scap', 'Submit', 'Mobile'],
    summary: 'Submit Work Order Scaps',
    description: 'Submit phế liệu',
  })
  @ApiResponse({
    status: 200,
    description: 'Submit successfully',
    type: SubmitWorkOrderInputResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.work_order_scrap_submit`, DEFAULT_TRANSPORT)
  public async scrapSubmit(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() payload: SubmitWorkOrderScrapRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    request.createdByUserId = request.user?.id;

    return await this.workOrderService.scrapSubmit(request);
  }

  @Put(':id/progress/')
  @ApiOperation({
    tags: ['Work Order', 'Progress', 'Submit', 'Mobile'],
    summary: 'Submit Work Order Progress',
    description: 'Submit tiến độ lệnh làm việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Submit successfully',
    type: SubmitWorkOrderInputResponseDto,
  })
  @MessagePattern(
    `${NATS_PRODUCE}.work_order_progress_submit`,
    DEFAULT_TRANSPORT,
  )
  public async progressSubmit(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() payload: SubmitWorkOrderProgressRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    request.createdByUserId = request.user?.id;
    return await this.workOrderService.progressSubmit(request);
  }

  @Get('transactions/list')
  @ApiOperation({
    tags: ['Work Order', 'Transaction', 'List'],
    summary: 'List Work Order Transaction',
    description: 'Danh sách lịch sử sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListWorkOrderTransactionRequestDto,
  })
  @MessagePattern(
    `${NATS_PRODUCE}.work_order_transaction_list`,
    DEFAULT_TRANSPORT,
  )
  public async getTransactionList(
    @Query() payload: GetListWorkOrderTransactionRequestDto,
  ): Promise<ResponsePayload<GetListWorkOrderResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workOrderService.getTransactionList(request);
  }

  @Get('transactions/:id')
  @ApiOperation({
    tags: ['Work Order', 'Transaction', 'Detail'],
    summary: 'Detail Work Order Transaction',
    description: 'Chi tiết lịch sử sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get detail successfully',
  })
  @MessagePattern(
    `${NATS_PRODUCE}.work_order_transaction_detail`,
    DEFAULT_TRANSPORT,
  )
  public async getTransactionDetail(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<ResponsePayload<GetListWorkOrderResponseDto | any>> {
    return await this.workOrderService.getTransactionDetail({
      id,
    } as GetDetailWorkOrderTransactionRequestDto);
  }

  @Get('scrap-transactions/list')
  @ApiOperation({
    tags: ['Work Order', 'Scrap Transaction', 'List'],
    summary: 'List Work Order Scrap Transaction',
    description: 'Danh sách lịch sử sản xuất (phế liệu)',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListWorkOrderScrapTransactionResponseDto,
  })
  @MessagePattern(
    `${NATS_PRODUCE}.work_order_scrap_transaction_list`,
    DEFAULT_TRANSPORT,
  )
  public async getListWorkOrderScrapTransaction(
    @Query() payload: GetListWorkOrderScrapTransactionRequestDto,
  ): Promise<
    ResponsePayload<GetListWorkOrderScrapTransactionResponseDto | any>
  > {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workOrderService.getListWorkOrderScrapTransaction(
      request,
    );
  }

  @Get('scrap-transactions/:id')
  @ApiOperation({
    tags: ['Work Order', 'Scrap Transaction', 'Detail'],
    summary: 'Detail Work Order Scrap Transaction',
    description: 'Chi tiết lịch sử sản xuất (phế liệu)',
  })
  @ApiResponse({
    status: 200,
    description: 'Get detail successfully',
    type: WorkOrderScrapTransactionResponseDto,
  })
  @MessagePattern(
    `${NATS_PRODUCE}.work_order_scrap_transaction_detail`,
    DEFAULT_TRANSPORT,
  )
  public async getDetailWorkOrderScrapTransaction(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<ResponsePayload<WorkOrderScrapTransactionResponseDto | any>> {
    return await this.workOrderService.getDetailWorkOrderScrapTransaction({
      id,
    } as GetDetailWorkOrderScrapTransactionRequestDto);
  }

  @Get('inputs/list')
  @ApiOperation({
    tags: ['Work Order', 'Bom Transit History', 'List'],
    summary: 'List Work Order Bom Transit',
    description: 'Danh sách lịch sử sản xuất (đầu vào)',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListWorkOrderBomTransitHistoryResponseDto,
  })
  @MessagePattern(
    `${NATS_PRODUCE}.work_order_bom_transit_history_list`,
    DEFAULT_TRANSPORT,
  )
  public async getListWorkOrderBomTransitHistory(
    @Query() payload: GetListWorkOrderBomTransitHistoryRequestDto,
  ): Promise<
    ResponsePayload<GetListWorkOrderBomTransitHistoryResponseDto | any>
  > {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workOrderService.getListWorkOrderBomTransitHistory(
      request,
    );
  }

  @Get('inputs/:id')
  @ApiOperation({
    tags: ['Work Order', 'Bom Transit History', 'Detail'],
    summary: 'Detail Work Order Bom Transit History',
    description: 'Chi tiết lịch sử sản xuất (đầu vào)',
  })
  @ApiResponse({
    status: 200,
    description: 'Get detail successfully',
    type: WorkOrderBomTransitHistoryResponseDto,
  })
  @MessagePattern(
    `${NATS_PRODUCE}.work_order_bom_transit_history_detail`,
    DEFAULT_TRANSPORT,
  )
  public async getDetailWorkOrderBomTransitHistory(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<ResponsePayload<WorkOrderBomTransitHistoryResponseDto | any>> {
    return await this.workOrderService.getDetailWorkOrderBomTransitHistory({
      id,
    } as GetDetailWorkOrderBomTransitHistoryRequestDto);
  }

  @Get('in-transits/list')
  @ApiOperation({
    tags: ['Work Order', 'In Transit', 'List', 'Mobile'],
    summary: 'List Work Order export',
    description: 'Danh sách lệnh xuât',
  })
  @ApiResponse({
    status: 200,
    description: 'Work Order Export successfully',
    type: GetListInTransitRequestDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.in_transit_list`, DEFAULT_TRANSPORT)
  public async getInTransitList(
    @Query() payload: GetListInTransitRequestDto,
  ): Promise<ResponsePayload<InTransitResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workOrderService.getInTransitList(request);
  }

  @Get('in-transits/histories/list')
  @ApiOperation({
    tags: ['Work Order', 'In Transit', 'Histories', 'List', 'Mobile'],
    summary: 'List In transit import',
    description: 'Danh sách lệnh nhập',
  })
  @ApiResponse({
    status: 200,
    description: 'Work Order Export successfully',
  })
  @MessagePattern(
    `${NATS_PRODUCE}.in_transit_import_history_list`,
    DEFAULT_TRANSPORT,
  )
  public async getInTransitImportHistoryList(
    @Query() payload: GetListInTransitRequestDto,
  ): Promise<ResponsePayload<InTransitResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workOrderService.getInTransitImportHistoryList(request);
  }

  @Get('in-transits/:id')
  @ApiOperation({
    tags: ['Work Order', 'In Transit', 'Detail', 'Mobile'],
    summary: 'Detail Work Order In Transit',
    description: 'Danh sách lệnh xuât',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail In transit successfully',
  })
  @MessagePattern(`${NATS_PRODUCE}.in_transit_detail`, DEFAULT_TRANSPORT)
  public async getInTransitDetail(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<ResponsePayload<InTransitResponseDto | any>> {
    return await this.workOrderService.getInTransitDetail({
      id,
    } as GetDetailInTransitRequestDto);
  }

  @Get('in-transits/histories/:id')
  @ApiOperation({
    tags: ['Work Order', 'In Transit', 'History', 'Detail', 'Mobile'],
    summary: 'Detail Work Order In Transit',
    description: 'Danh sách lệnh xuât',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail In transit successfully',
  })
  @MessagePattern(
    `${NATS_PRODUCE}.in_transit_import_history_detail`,
    DEFAULT_TRANSPORT,
  )
  public async getInTransitImportHistoryDetail(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<ResponsePayload<InTransitResponseDto | any>> {
    return await this.workOrderService.getInTransitImportHistoryDetail({
      id,
    } as GetDetailInTransitRequestDto);
  }

  @Put('in-transits/:id/confirm')
  @ApiOperation({
    tags: ['Work Order', 'In Transit', 'Confirm', 'Mobile'],
    summary: 'Confirm Work Order In Transit',
    description: 'Confirm lệnh xuât',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm In transit successfully',
    type: SuccessResponse,
  })
  @MessagePattern(`${NATS_PRODUCE}.in_transit_confirm`, DEFAULT_TRANSPORT)
  public async inTransitConfirm(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<ResponsePayload<InTransitResponseDto | any>> {
    return await this.workOrderService.confirmInTransit({
      id,
    } as ChangeStatusInTransitRequestDto);
  }

  @Put('in-transits/:id/reject')
  @ApiOperation({
    tags: ['Work Order', 'In Transit', 'reject', 'Mobile'],
    summary: 'Reject Work Order In Transit',
    description: 'Reject lệnh xuât',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject In transit successfully',
    type: SuccessResponse,
  })
  @MessagePattern(`${NATS_PRODUCE}.in_transit_reject`, DEFAULT_TRANSPORT)
  public async inTransitReject(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<ResponsePayload<InTransitResponseDto | any>> {
    return await this.workOrderService.rejectInTransit({
      id,
    } as ChangeStatusInTransitRequestDto);
  }

  @Put('in-transits/:id/import')
  @ApiOperation({
    tags: ['Work Order', 'In Transit', 'Import', 'Mobile'],
    summary: 'Import In Transit',
    description: 'Nhập lệnh xuât',
  })
  @ApiResponse({
    status: 200,
    description: 'Import In transit successfully',
  })
  @MessagePattern(`${NATS_PRODUCE}.in_transit_import`, DEFAULT_TRANSPORT)
  public async inTransitImport(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() payload: ImportInTransitRequestDto,
  ): Promise<ResponsePayload<InTransitResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;
    request.createdByUserId = request.userId;
    return await this.workOrderService.importInTransit(request);
  }

  @Post('qr-code/print')
  @ApiOperation({
    tags: ['Work Order', 'QR Code'],
    summary: 'Print Work Order, Block, Package qr code',
    description: 'In Qr code',
  })
  @ApiResponse({
    status: 200,
    description: 'Print successfully',
    type: null,
  })
  public async printQrCode(
    @Body() payload: PrintQrcodeRequestDto,
  ): Promise<ResponsePayload<InTransitResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workOrderService.printQrCode(request);
  }

  @Put(':id/quality-controls/quantity')
  @ApiOperation({
    tags: ['Work Order'],
    summary: 'Update Work Order quality control',
    description: 'Cập nhật thông tin qc lệnh làm việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: WorkOrderResponseDto,
  })
  @MessagePattern(
    `${NATS_PRODUCE}.work_order_quality_control_update`,
    DEFAULT_TRANSPORT,
  )
  public async updateQualityControlWorkOrder(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() payload: UpdateQualityControlWorkOrderRequestDto,
  ): Promise<ResponsePayload<InTransitResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;
    return await this.workOrderService.updateQualityControlWorkOrder(request);
  }

  @Post(':id/log-times')
  @ApiOperation({
    tags: ['Work Order', 'Log time'],
    summary: 'Create Work Order Log Time',
    description: 'Log time lệnh làm việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: SuccessResponse,
  })
  @MessagePattern(`${NATS_PRODUCE}.log_time_work_order`, DEFAULT_TRANSPORT)
  public async logTimeWorkOrder(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() payload: CreateWorkOrderLogTimeRequestDto,
  ): Promise<ResponsePayload<InTransitResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.workOrderService.logTimeWorkOrder(request);
  }

  @Put('log-times/:id')
  @ApiOperation({
    tags: ['Work Order', 'Log time'],
    summary: 'Update Work Order Log Time',
    description: 'Update Log time lệnh làm việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: SuccessResponse,
  })
  @MessagePattern(
    `${NATS_PRODUCE}.update_log_time_work_order`,
    DEFAULT_TRANSPORT,
  )
  public async updateLogTimeWorkOrder(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() payload: CreateWorkOrderLogTimeRequestDto,
  ): Promise<ResponsePayload<InTransitResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.workOrderService.updateLogTimeWorkOrder(request);
  }

  @Get(':id/log-times')
  @ApiOperation({
    tags: ['Work Order', 'Log time'],
    summary: 'Get Work Order Log Time',
    description: 'Lấy Log time lệnh làm việc',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  @MessagePattern(`${NATS_PRODUCE}.get_log_time_work_order`, DEFAULT_TRANSPORT)
  public async getLogTimeWorkOrder(
    @Param('id', new ParseIntPipe()) id: number,
    @Query() payload: GetWorkOrderLogTimeRequestDto,
  ): Promise<ResponsePayload<InTransitResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.workOrderService.getLogTimeWorkOrder(request);
  }

  @PermissionCode(UPDATE_WORK_ORDER_SCHEDULE_PERMISSION.code)
  @Post(':id/schedules')
  @ApiOperation({
    tags: ['Work Order', 'Schedule'],
    summary: 'Create Schedule Detail Work Order',
    description: 'Tạo lịch làm việc theo ngày',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
  })
  @ApiParam({
    name: 'workOrderId',
    type: Number,
    example: 601,
    required: true,
    description: 'Work Order ID',
  })
  @MessagePattern(
    `${NATS_PRODUCE}.create_work_order_schedule`,
    DEFAULT_TRANSPORT,
  )
  public async createWorkOrderSchedule(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() payload: CreateWorkOrderScheduleRequestDto,
  ): Promise<ResponsePayload<WorkOrderScheduleResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.workOrderId = id;

    return await this.workOrderService.createWorkOrderSchedule(request);
  }

  @PermissionCode(DETAIL_WORK_ORDER_SCHEDULE_PERMISSION.code)
  @Get(':id/schedules')
  @ApiOperation({
    tags: ['Work Order', 'Schedule'],
    summary: 'Get Schedule Detail Work Order',
    description: 'Lấy lịch làm việc theo ngày',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  @ApiParam({
    name: 'id',
    type: Number,
    example: 601,
    required: true,
    description: 'Work Order ID',
  })
  @MessagePattern(`${NATS_PRODUCE}.get_work_order_schedule`, DEFAULT_TRANSPORT)
  public async getWorkOrderSchedule(
    @Param('id', new ParseIntPipe()) id: number,
    @Query() payload: GetWorkOrderScheduleRequestDto,
  ): Promise<ResponsePayload<WorkOrderScheduleResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.workOrderService.getWorkOrderSchedule(request);
  }

  @PermissionCode(REJECT_WORK_ORDER_SCHEDULE_PERMISSION.code)
  @MessagePattern(
    `${NATS_PRODUCE}.reject_work_order_schedule`,
    DEFAULT_TRANSPORT,
  )
  public async rejectWorkOrderSchedule(
    @Body() payload: ChangeStatusWorkOrderScheduleRequestDto,
  ): Promise<ResponsePayload<WorkOrderScheduleResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workOrderService.rejectWorkOrderSchedule(request);
  }

  @PermissionCode(CONFIRM_WORK_ORDER_SCHEDULE_PERMISSION.code)
  @MessagePattern(
    `${NATS_PRODUCE}.approve_work_order_schedule`,
    DEFAULT_TRANSPORT,
  )
  public async approveWorkOrderSchedule(
    @Body() payload: ChangeStatusWorkOrderScheduleRequestDto,
  ): Promise<ResponsePayload<WorkOrderScheduleResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workOrderService.approveWorkOrderSchedule(request);
  }

  @PermissionCode(REJECT_WORK_CENTER_DAILY_SCHEDULE_PERMISSION.code)
  @MessagePattern(
    `${NATS_PRODUCE}.reject_work_order_schedule_detail`,
    DEFAULT_TRANSPORT,
  )
  public async rejectWorkOrderScheduleDetail(
    @Body() payload: ChangeStatusWorkOrderScheduleRequestDto,
  ): Promise<ResponsePayload<GetWorkOrderScheduleDetailResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workOrderService.rejectWorkOrderScheduleDetail(request);
  }

  @PermissionCode(CONFIRM_WORK_CENTER_DAILY_SCHEDULE_PERMISSION.code)
  @MessagePattern(
    `${NATS_PRODUCE}.approve_work_order_schedule_detail`,
    DEFAULT_TRANSPORT,
  )
  public async approveWorkOrderScheduleDetail(
    @Body() payload: ChangeStatusWorkOrderScheduleRequestDto,
  ): Promise<ResponsePayload<GetWorkOrderScheduleDetailResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workOrderService.approveWorkOrderScheduleDetail(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.gen_work_order_schedule`, DEFAULT_TRANSPORT)
  public async genWorkOrderSchedule(
    @Body() payload: GetDataByIdRequestDto,
  ): Promise<ResponsePayload<WorkOrderScheduleResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.workOrderService.genWorkOrderSchedule(request.id);
  }

  @PermissionCode(LIST_WORK_ORDER_SCHEDULE_PERMISSION.code)
  @Get('schedules/list')
  @ApiOperation({
    tags: ['Work Order', 'Schedule'],
    summary: 'Get Schedule Detail Work Order',
    description: 'danh sách detail schedules',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  @MessagePattern(
    `${NATS_PRODUCE}.get_list_work_order_schedule`,
    DEFAULT_TRANSPORT,
  )
  public async getListWorkOrderSchedules(
    @Query() payload: GetListWorkOrderScheduleRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.workOrderService.getListWorkOrderSchedules(request);
  }

  @PermissionCode(LIST_WORK_CENTER_DAILY_SCHEDULE_PERMISSION.code)
  @Get('schedule-details/list')
  @ApiOperation({
    tags: ['Work Order', 'Schedule'],
    summary: 'Get Schedule Detail Work Order',
    description: 'danh sách detail schedules',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  @MessagePattern(
    `${NATS_PRODUCE}.get_list_work_order_schedule_details`,
    DEFAULT_TRANSPORT,
  )
  public async getListWorkOrderScheduleDetails(
    @Query() payload: GetListWorkOrderScheduleRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.workOrderService.getListWorkOrderScheduleDetails(request);
  }

  @Get('/schedules/grantt')
  @ApiOperation({
    tags: ['Work Order', 'Schedule', 'Grantt chart'],
    summary: 'Get Schedule Grannt Work Order',
    description: 'danh sách hiển thị grantt schedules',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  @MessagePattern(
    `${NATS_PRODUCE}.get_grantt_work_order_schedule`,
    DEFAULT_TRANSPORT,
  )
  public async getGranttWorkOrderSchedules(
    @Query() payload: GetListWorkOrderScheduleRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.workOrderService.getGranttWorkOrderSchedules(request);
  }

  @PermissionCode(DELETE_WORK_CENTER_DAILY_SCHEDULE_PERMISSION.code)
  @MessagePattern(
    `${NATS_PRODUCE}.delete_work_order_schedule_detail`,
    DEFAULT_TRANSPORT,
  )
  public async deleteWorkOrderScheduleDetail(
    @Body() payload: DeleteWorkOrderScheduleDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.workOrderService.deleteWorkOrderScheduleDetail(request);
  }

  @MessagePattern(
    `${NATS_PRODUCE}.update_grantt_work_order_schedule`,
    DEFAULT_TRANSPORT,
  )
  public async updateGranttWorkOrderSchedules(
    @Body() payload: UpdateWorkOrderGranttDataRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.workOrderService.updateGranttWorkOrderSchedule(request);
  }

  public async getLogTimeByMoIds(
    @Body() payload: LogTimeByWoIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.workOrderService.getLogTimeByMoIds(request);
  }

  @Put(':id/autocomplete')
  @ApiOperation({
    tags: ['Work Order'],
    summary: 'Submit Work Order Auto',
  })
  @ApiResponse({
    status: 200,
    description: 'Submit successfully',
    type: SubmitWorkOrderInputResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.work_order_autocomplete`, DEFAULT_TRANSPORT)
  public async autocomplete(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    return await this.workOrderService.autocomplete({
      id,
    } as AutocompleteRequestDto);
  }

  @Put(':id/running-status')
  @ApiOperation({
    tags: ['Work Order'],
    summary: 'Submit Work Order Running Status',
  })
  @ApiResponse({
    status: 200,
    description: 'Submit successfully',
    type: SuccessResponseDto,
  })
  public async setRunningStatus(
    @Param('id', new ParseIntPipe()) id: number,
    @Body() payload: ChangeRunningStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.workOrderService.setRunningStatus(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.produceMonitoring`)
  public async produceMonitoring(
    @Payload() payload: ProduceMonitoringRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.workOrderService.produceMonitoring(request.value);
  }

  @MessagePattern(`${NATS_PRODUCE}.PRODUCE_REGISTER_DEVICE`)
  public async test(@Payload() payload: any): Promise<any> {
    console.log('fdsf', payload);
  }

  // TODO: remove when refactor done
  @PermissionCode(DETAIL_WORK_ORDER_PERMISSION.code)
  @MessagePattern(`${NATS_PRODUCE}.work_order_detail`, DEFAULT_TRANSPORT)
  public async detailTcp(
    @Body() payload: DetailRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.workOrderService.detail(request.id);
  }

  // TODO: remove when refactor done
  @MessagePattern(`${NATS_PRODUCE}.get_log_time_by_mo_ids`, DEFAULT_TRANSPORT)
  public async getLogTimeByMoIdsTcp(
    @Body() payload: LogTimeByWoIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.workOrderService.getLogTimeByMoIds(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.work_order_scan`, DEFAULT_TRANSPORT)
  public async scanTcp(
    @Body() payload: ScanWorkOrderRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workOrderService.scan(request);
  }

  @PermissionCode(LIST_WORK_ORDER_PERMISSION.code)
  @MessagePattern(`${NATS_PRODUCE}.work_order_list`, DEFAULT_TRANSPORT)
  public async getListTcp(
    @Body() payload: GetListWorkOrderRequestDto,
  ): Promise<ResponsePayload<GetListWorkOrderResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workOrderService.getList(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.print_work_order_qr_code`, DEFAULT_TRANSPORT)
  public async printQrCodeTcp(
    @Body() payload: PrintQrcodeRequestDto,
  ): Promise<ResponsePayload<InTransitResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workOrderService.printQrCode(request);
  }
}
