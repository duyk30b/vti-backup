import { GetStatisticProgressProductionRequestDto } from '@components/manufacturing-order/dto/request/get-statistic-progress-production.request.dto';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WorkOrderScheduleDetailEntity } from '@entities/work-order/work-order-schedule-detail.entity';
import { GetListWorkOrderDetailSchedulesRequestDto } from '../dto/request/get-list-work-order-detail-schedules.request.dto';

export interface WorkOrderScheduleDetailRepositoryInterface
  extends BaseInterfaceRepository<WorkOrderScheduleDetailEntity> {
  createEntity(data): WorkOrderScheduleDetailEntity;
  getByWorkCenterAndWorkOrderId(workCenterId, workOrderId): Promise<any>;
  getList(request: GetListWorkOrderDetailSchedulesRequestDto): Promise<any>;
  getWorkCenterScheduleListByPlanId(planId: number): Promise<any>;
  syncToMaterialPlanSchedules(id: number): Promise<any>;
  getListDetail(request: any, itemList?: any): Promise<any>;
  getStatisticProgressProductionWc(
    request: GetStatisticProgressProductionRequestDto,
  ): Promise<any>;
}
