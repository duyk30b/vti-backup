import { WorkOrderLogTimeEntity } from '@entities/work-order/work-order-log-time.entity';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';

export interface WorkOrderLogTimeRepositoryInterface
  extends BaseInterfaceRepository<WorkOrderLogTimeEntity> {
  createEntity(data): WorkOrderLogTimeEntity;
  getLogTimeByWorkOrderId(
    workOrderId: number,
    workCenterId?: number,
  ): Promise<any>;
}
