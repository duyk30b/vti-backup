import { WorkOrderInputDetailEntity } from '../../../entities/work-order/work-order-bom-transit-history.entity';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { GetListWorkOrderBomTransitHistoryRequestDto } from '@components/work-order/dto/request/get-list-work-order-bom-transit-history.request.dto';

export interface WorkOrderInputDetailRepositoryInterface
  extends BaseInterfaceRepository<WorkOrderInputDetailEntity> {
  getDetail(id: number): Promise<any>;
  createEntity(payload: any): WorkOrderInputDetailEntity;
  getList(
    request: GetListWorkOrderBomTransitHistoryRequestDto,
    filterItemIds?: number[],
  ): Promise<any>;
}
