import { DeleteWorkOrderScheduleDetailRequestDto } from './../dto/request/delete-work-order-schedule-detail.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { CreateWorkOrderRequestDto } from '@components/work-order/dto/request/create-work-order.request.dto';
import { UpdateWorkOrderRequestDto } from '@components/work-order/dto/request/update-work-order.request.dto';
import { SetStatusRequestDto } from '@components/work-order/dto/request/set-status.request.dto';
import { GetListWorkOrderRequestDto } from '@components/work-order/dto/request/get-list-work-order.request.dto';
import { WorkOrderResponseDto } from '@components/work-order/dto/response/work-order.response.dto';
import { GetListWorkOrderResponseDto } from '@components/work-order/dto/response/get-list-work-order.response.dto';
import { ScanWorkOrderRequestDto } from '../dto/request/scan-work-order.request.dto';
import { SubmitWorkOrderInputRequestDto } from '../dto/request/submit-work-order-input.request.dto';
import { SubmitWorkOrderScrapRequestDto } from '../dto/request/submit-work-order-scrap.request.dto';
import { GetListWorkOrderTransactionRequestDto } from '../dto/request/get-list-work-order-transaction.request.dto';
import { SubmitWorkOrderProgressRequestDto } from '../dto/request/submit-work-order-progress.request.dto';
import { GetDetailWorkOrderTransactionRequestDto } from '../dto/request/get-detail-work-order-transaction.request.dto';
import { SubmitWorkOrderExportRequestDto } from '../dto/request/submit-export-work-order.request.dto';
import { GetListWorkOrderBomTransitHistoryRequestDto } from '@components/work-order/dto/request/get-list-work-order-bom-transit-history.request.dto';
import { GetListWorkOrderScrapTransactionRequestDto } from '@components/work-order/dto/request/get-list-work-order-scrap-transaction.request.dto';
import { GetDetailWorkOrderBomTransitHistoryRequestDto } from '@components/work-order/dto/request/get-detail-work-order-bom-transit-history.request.dto';
import { GetDetailWorkOrderScrapTransactionRequestDto } from '@components/work-order/dto/request/get-detail-work-order-scrap-transaction.request.dto';
import { GetListWorkOrderBomTransitHistoryResponseDto } from '@components/work-order/dto/response/get-list-work-order-bom-transit-history.response.dto';
import { GetListWorkOrderScrapTransactionResponseDto } from '@components/work-order/dto/response/get-list-work-order-scrap-transaction.response.dto';
import { WorkOrderBomTransitHistoryResponseDto } from '@components/work-order/dto/response/work-order-bom-transit-history.response.dto';
import { WorkOrderScrapTransactionResponseDto } from '@components/work-order/dto/response/work-order-scrap-transaction.response.dto';
import { GetListInTransitRequestDto } from '../dto/request/get-list-in-transit.request.dto';
import { DetailWorkOrderExportRequestDto } from '../dto/request/detail-work-order-export.request.dto';
import { GetDetailInTransitRequestDto } from '../dto/request/get-detail-in-transit.request.dto';
import { InTransitResponseDto } from '../dto/response/in-transit.response.dto';
import { ChangeStatusInTransitRequestDto } from '../dto/request/change-status-in-transit.request.dto';
import { ImportInTransitRequestDto } from '../dto/request/import-in-transit.request.dto';
import { PrintQrcodeRequestDto } from '../dto/request/print.request.dto';
import { UpdateQualityControlWorkOrderRequestDto } from '../dto/request/update-quality-control-work-order.request.dto';
import { CreateWorkOrderLogTimeRequestDto } from '../dto/request/create-work-order-log-time.request.dto';
import { GetDetailWorkOrderByBomAndProducingStepRequestDto } from '../dto/request/get-detail-work-order-by-bom-and-producing-step.request.dto';
import { CreateWorkOrderScheduleRequestDto } from '../dto/request/create-work-order-schedule.request.dto';
import { GetWorkOrderScheduleRequestDto } from '../dto/request/get-work-order-schedule.request.dto';
import { ChangeStatusWorkOrderScheduleRequestDto } from '../dto/request/change-status-work-order-schedule.request.dto';
import { GetListWorkOrderDetailSchedulesRequestDto } from '../dto/request/get-list-work-order-detail-schedules.request.dto';
import { ImportWorkOrderMaterialInputRequestDto } from '../dto/request/import-work-order-material-input.request.dto';
import { UpdateWorkOrderGranttDataRequestDto } from '../dto/response/update-work-order-grantt-data.request.dto';
import { GetListWorkOrderScheduleRequestDto } from '../dto/request/get-list-work-order-schedule.request.dto';
import { GetWorkOrderLogTimeRequestDto } from '../dto/request/get-work-order-log-time.request.dto';
import { LogTimeByWoIdsRequestDto } from '../dto/request/log-time-by-wo-ids.request.dto';
import { AutocompleteRequestDto } from '../dto/request/autocomplete.request.dto';
import { ChangeRunningStatusRequestDto } from '../dto/request/change-running-status.request.dto';

export interface WorkOrderServiceInterface {
  create(
    request: CreateWorkOrderRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>>;
  update(
    request: UpdateWorkOrderRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>>;
  detail(id: number): Promise<ResponsePayload<WorkOrderResponseDto | any>>;
  detailByBomAndProducingStep(
    payload: GetDetailWorkOrderByBomAndProducingStepRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>>;
  getTransactionDetail(
    payload: GetDetailWorkOrderTransactionRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>>;
  scan(
    payload: ScanWorkOrderRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>>;
  exportScan(
    payload: ScanWorkOrderRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>>;
  exportDetail(
    payload: DetailWorkOrderExportRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>>;
  getInTransitDetail(
    payload: GetDetailInTransitRequestDto,
  ): Promise<ResponsePayload<InTransitResponseDto | any>>;
  getInTransitImportHistoryDetail(
    payload: GetDetailInTransitRequestDto,
  ): Promise<ResponsePayload<InTransitResponseDto | any>>;
  confirmInTransit(
    payload: ChangeStatusInTransitRequestDto,
  ): Promise<ResponsePayload<InTransitResponseDto | any>>;
  rejectInTransit(
    payload: ChangeStatusInTransitRequestDto,
  ): Promise<ResponsePayload<InTransitResponseDto | any>>;
  importInTransit(
    payload: ImportInTransitRequestDto,
  ): Promise<ResponsePayload<InTransitResponseDto | any>>;
  exportSubmit(
    payload: SubmitWorkOrderExportRequestDto,
  ): Promise<ResponsePayload<SuccessResponse | any>>;
  materialInputSubmit(
    payload: SubmitWorkOrderInputRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>>;
  materialInputImport(
    payload: ImportWorkOrderMaterialInputRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>>;
  scrapSubmit(
    payload: SubmitWorkOrderScrapRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>>;
  progressSubmit(
    payload: SubmitWorkOrderProgressRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>>;
  delete(id: number): Promise<ResponsePayload<SuccessResponse | any>>;
  getList(
    request: GetListWorkOrderRequestDto,
  ): Promise<ResponsePayload<GetListWorkOrderResponseDto | any>>;
  getInTransitList(
    request: GetListInTransitRequestDto,
  ): Promise<ResponsePayload<GetListWorkOrderResponseDto | any>>;
  getInTransitImportHistoryList(
    request: GetListInTransitRequestDto,
  ): Promise<ResponsePayload<GetListWorkOrderResponseDto | any>>;
  getTransactionList(
    request: GetListWorkOrderTransactionRequestDto,
  ): Promise<ResponsePayload<GetListWorkOrderResponseDto | any>>;
  confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>>;
  reject(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>>;
  getListWorkOrderScrapTransaction(
    payload: GetListWorkOrderScrapTransactionRequestDto,
  ): Promise<
    ResponsePayload<GetListWorkOrderScrapTransactionResponseDto | any>
  >;
  getDetailWorkOrderScrapTransaction(
    payload: GetDetailWorkOrderScrapTransactionRequestDto,
  ): Promise<ResponsePayload<WorkOrderScrapTransactionResponseDto | any>>;
  getListWorkOrderBomTransitHistory(
    payload: GetListWorkOrderBomTransitHistoryRequestDto,
  ): Promise<
    ResponsePayload<GetListWorkOrderBomTransitHistoryResponseDto | any>
  >;
  getDetailWorkOrderBomTransitHistory(
    payload: GetDetailWorkOrderBomTransitHistoryRequestDto,
  ): Promise<ResponsePayload<WorkOrderBomTransitHistoryResponseDto | any>>;
  printQrCode(payload: PrintQrcodeRequestDto): Promise<any>;
  updateQualityControlWorkOrder(
    payload: UpdateQualityControlWorkOrderRequestDto,
  ): Promise<any>;
  logTimeWorkOrder(payload: CreateWorkOrderLogTimeRequestDto): Promise<any>;
  getLogTimeWorkOrder(payload: GetWorkOrderLogTimeRequestDto): Promise<any>;
  updateLogTimeWorkOrder(
    payload: CreateWorkOrderLogTimeRequestDto,
  ): Promise<any>;
  createWorkOrderSchedule(
    payload: CreateWorkOrderScheduleRequestDto,
  ): Promise<any>;
  getWorkOrderSchedule(payload: GetWorkOrderScheduleRequestDto): Promise<any>;
  rejectWorkOrderSchedule(
    payload: ChangeStatusWorkOrderScheduleRequestDto,
  ): Promise<any>;
  approveWorkOrderSchedule(
    payload: ChangeStatusWorkOrderScheduleRequestDto,
  ): Promise<any>;
  genWorkOrderSchedule(workOrder): Promise<any>;
  getListWorkOrderSchedules(
    payload: GetListWorkOrderDetailSchedulesRequestDto,
  ): Promise<ResponsePayload<any>>;
  getGranttWorkOrderSchedules(
    payload: GetListWorkOrderDetailSchedulesRequestDto,
  ): Promise<ResponsePayload<any>>;
  approveWorkOrderScheduleDetail(
    request: ChangeStatusWorkOrderScheduleRequestDto,
  ): Promise<any>;
  rejectWorkOrderScheduleDetail(
    request: ChangeStatusWorkOrderScheduleRequestDto,
  ): Promise<any>;
  deleteWorkOrderScheduleDetail(
    payload: DeleteWorkOrderScheduleDetailRequestDto,
  ): Promise<any>;
  updateGranttWorkOrderSchedule(
    data: UpdateWorkOrderGranttDataRequestDto,
  ): Promise<any>;
  getListWorkOrderScheduleDetails(
    request: GetListWorkOrderScheduleRequestDto,
  ): Promise<any>;
  getLogTimeByMoIds(request: LogTimeByWoIdsRequestDto): Promise<any>;
  autocomplete(request: AutocompleteRequestDto): Promise<any>;
  produceMonitoring(request: any): Promise<any>;
  setRunningStatus(request: ChangeRunningStatusRequestDto): Promise<any>;
}
