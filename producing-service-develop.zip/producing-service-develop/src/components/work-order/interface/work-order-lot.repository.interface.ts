import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WorkOrderLotEntity } from '@entities/work-order/lot/work-order-lot.entity';

export type WorkOrderLotRepositoryInterface =
  BaseInterfaceRepository<WorkOrderLotEntity>;
