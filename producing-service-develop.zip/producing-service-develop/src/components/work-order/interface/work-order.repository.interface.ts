import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { GetListWorkOrderRequestDto } from '@components/work-order/dto/request/get-list-work-order.request.dto';
import { WorkOrderTransactionEntity } from '@entities/work-order/work-order-transaction.entity';
import { WorkOrderEntity } from '@entities/work-order/work-order.entity';
import { MaterialReportRequestDto } from '@components/report/dto/request/material-report.request.dto';
import { GetListPlcBomItemRequestDto } from '@components/work-center/dto/request/get-list-plc-bom-item.request.dto';

export interface WorkOrderRepositoryInterface
  extends BaseInterfaceRepository<WorkOrderEntity> {
  getByVirtualDevices(arg0: any, moBomId: number): unknown;
  getDetail(id: number): Promise<any>;
  getCurrentWorkOrdersByDevice(
    deviceIds: number[],
    producingStepIds: number[],
  ): Promise<any>;
  getDetailByBomAndProducingStep(
    bomId: number,
    producingStepId: number,
  ): Promise<any>;
  getImportWorkOrderByInTransitId(id: number): Promise<any>;
  scan(id: number): Promise<any>;
  getBomTransitByItemId(
    workOrderId: number,
    itemId: number,
    workCenterId: number,
  ): Promise<any>;
  getBomInputById(workOrderId: number, workCenterId: number): Promise<any>;
  getMaterialInputByItemId(id: number, itemId): Promise<any>;
  exportScan(id: number): Promise<any>;
  getList(
    request: GetListWorkOrderRequestDto,
    moDetailItemIds?: number[],
    bomItemIds?: number[],
    filterItemNameIds?: number[],
    filterItemCodeIds?: number[],
    searchBomItemIds?: number[],
  ): Promise<any>;
  createEntity(request: any, workOrder?: WorkOrderEntity): WorkOrderEntity;
  createTransactionEntity(payload: any): WorkOrderTransactionEntity;
  getTotalInProgressProducingStep(moIds?: number[]): Promise<any>;
  aggreateActualQuantityByBomId(moId: number): Promise<any>;

  updateStartAt(id: number);
  updateEndAt(id: number);
  getWorkOrderAndMO(id: number, workCenterIds: number[]);
  getWorkOrderAndFactoryId(id: number): Promise<any>;
  getWorkOrderAndWorkCenter(id: number): Promise<any>;
  getManufacturingOrderPlanReportList(
    request: MaterialReportRequestDto,
  ): Promise<any>;
  getWorkOrderDistinctBomId(): Promise<any>;
  getDetailByWorkOrderScheduleDetail(
    workOrderDetailScheduleId: number,
  ): Promise<any>;
  getMaterialInputs(workOrderId: number, workCenterId?: number): Promise<any>;
  getMaterialInputsByWorkOrderIds(workOrderIds: number[]): Promise<any>;
  getMaterialScrapByWorkOrderIds(workOrderIds: number[]): Promise<any>;
  getLogTimeByMoIds(request: any): Promise<any>;
  getMaterials(id: number): Promise<any>;
  getPrevousBoms(request: any, itemIds?: number[]): Promise<any>;
  getPlcBomItem(
    virtualDeviceId: number,
    request: GetListPlcBomItemRequestDto,
  ): Promise<any>;
  producingStepReport(
    id: number,
    itemId: number,
    productionLineId?: number,
  ): Promise<any>;
}
