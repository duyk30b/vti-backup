import { InTransitHistoryEntity } from './../../../entities/work-order/in-transit-history.entity';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { GetListInTransitRequestDto } from '../dto/request/get-list-in-transit.request.dto';

export interface InTransitHistoryRepositoryInterface
  extends BaseInterfaceRepository<InTransitHistoryEntity> {
  createEntity(data): InTransitHistoryEntity;
  getDetail(id: number): Promise<any>;
  getList(
    request: GetListInTransitRequestDto,
    filterItemIds?: number[],
  ): Promise<any>;
}
