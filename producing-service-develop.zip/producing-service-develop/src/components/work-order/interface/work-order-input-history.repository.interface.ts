import { WorkOrderInputHistoryEntity } from '../../../entities/work-order/material-input/work-order-input-history.entity';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { GetListWorkOrderBomTransitHistoryRequestDto } from '@components/work-order/dto/request/get-list-work-order-bom-transit-history.request.dto';

export interface WorkOrderInputHistoryRepositoryInterface
  extends BaseInterfaceRepository<WorkOrderInputHistoryEntity> {
  getDetail(id: number): Promise<any>;
  createEntity(payload: any): WorkOrderInputHistoryEntity;
  getList(
    request: GetListWorkOrderBomTransitHistoryRequestDto,
    filterItemIds?: number[],
  ): Promise<any>;
}
