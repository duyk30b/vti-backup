import { WorkOrderScrapTransactionEntity } from './../../../entities/work-order/work-order-scrap-transaction.entity';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { GetListWorkOrderTransactionRequestDto } from '../dto/request/get-list-work-order-transaction.request.dto';

export interface WorkOrderScrapTransactionRepositoryInterface
  extends BaseInterfaceRepository<WorkOrderScrapTransactionEntity> {
  getDetail(id: number): Promise<any>;
  createEntity(payload: any): WorkOrderScrapTransactionEntity;
  getList(
    request: GetListWorkOrderTransactionRequestDto,
    filterItemIds?: number[],
  ): Promise<any>;
}
