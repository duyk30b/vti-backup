import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WorkOrderScheduleEntity } from '@entities/work-order/work-order-schedule.entity';
import { GetListWorkOrderScheduleRequestDto } from '../dto/request/get-list-work-order-schedule.request.dto';

export interface WorkOrderScheduleRepositoryInterface
  extends BaseInterfaceRepository<WorkOrderScheduleEntity> {
  createEntity(data): WorkOrderScheduleEntity;
  getList(
    payload: GetListWorkOrderScheduleRequestDto,
    items?: any,
  ): Promise<any>;
  getDetailByWorkOrderId(id: number): Promise<any>;
}
