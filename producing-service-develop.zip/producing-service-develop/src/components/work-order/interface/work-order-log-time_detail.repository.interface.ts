import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WorkOrderLogTimeDetailEntity } from '@entities/work-order/work-order-log-time-detail.entity';

export interface WorkOrderLogTimeDetailRepositoryInterface
  extends BaseInterfaceRepository<WorkOrderLogTimeDetailEntity> {
  createEntity(data): WorkOrderLogTimeDetailEntity;
  queryRawGetWorkOrderLogTimeDetails(workOrderLogTimeId?: number): Promise<any>;
}
