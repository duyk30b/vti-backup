import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WorkOrderBomTransitEntity } from '@entities/work-order/work-order-bom-transit.entity';

export interface WorkOrderBomTransitRepositoryInterface
  extends BaseInterfaceRepository<WorkOrderBomTransitEntity> {
  materialReport(id: number, itemId: number, productionLineId?: number): any;
}
