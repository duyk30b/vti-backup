import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WorkOrderRunningLogsEntity } from '@entities/work-order/work-order-running-logs.entity';

export interface WorkOrderRunningLogsRepositoryInterface
  extends BaseInterfaceRepository<WorkOrderRunningLogsEntity> {
  createEntity(data): WorkOrderRunningLogsEntity;
  getDetail(id: number): Promise<any>;
}
