import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WorkOrderTransactionEntity } from '@entities/work-order/work-order-transaction.entity';
import { GetListWorkOrderTransactionRequestDto } from '../dto/request/get-list-work-order-transaction.request.dto';

export interface WorkOrderTransactionRepositoryInterface
  extends BaseInterfaceRepository<WorkOrderTransactionEntity> {
  getDetail(id: number): Promise<any>;
  getList(
    request: GetListWorkOrderTransactionRequestDto,
    filterItemIds?: number[],
  ): Promise<any>;
  getProducedItemSummary(
    moIds: number[],
    itemId?: number,
    routingId?: number,
    producingStepId?: number,
  ): Promise<any>;
}
