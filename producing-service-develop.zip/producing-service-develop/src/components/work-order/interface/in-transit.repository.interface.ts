import { InTransitEntity } from '@entities/work-order/in-transit.entity';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { GetListInTransitRequestDto } from '../dto/request/get-list-in-transit.request.dto';

export interface InTransitRepositoryInterface
  extends BaseInterfaceRepository<InTransitEntity> {
  createEntity(data): InTransitEntity;
  getDetail(id: number): Promise<any>;
  getDetailByImportWorkOrder(id: number): Promise<any>;
  getList(
    request: GetListInTransitRequestDto,
    filterItemIds?: number[],
  ): Promise<any>;
}
