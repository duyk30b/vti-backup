import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WorkOrderWorkCenterLotEntity } from '@entities/work-order/lot/work-order-work-center-lot.entity';

export type WorkOrderWorkCenterLotRepositoryInterface =
  BaseInterfaceRepository<WorkOrderWorkCenterLotEntity>;
