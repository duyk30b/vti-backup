import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WorkOrderMaterialInputEntity } from '@entities/work-order/material-input/work-order-material_input.entity';

export interface WorkOrderMaterialInputRepositoryInterface
  extends BaseInterfaceRepository<WorkOrderMaterialInputEntity> {
  createEntity(payload: any): WorkOrderMaterialInputEntity;
}
