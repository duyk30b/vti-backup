import { GetListWorkOrderScheduleDetailResponseDto } from './dto/response/get-list-work-order-schedule-detail.response.dto';
import { DeleteWorkOrderScheduleDetailRequestDto } from './dto/request/delete-work-order-schedule-detail.request.dto';
import { WorkCenterDailyScheduleEntity } from '@entities/work-center/work-center-daily-schedule.entity';
import { GetWorkOrderScheduleRequestDto } from './dto/request/get-work-order-schedule.request.dto';
import { WorkOrderScheduleDetailEntity } from '@entities/work-order/work-order-schedule-detail.entity';
import { convertSecondsToMinutes, div } from '@utils/common';
import { WorkOrderInputHistoryRepositoryInterface } from './interface/work-order-input-history.repository.interface';
import { WorkOrderInputHistoryEntity } from '@entities/work-order/material-input/work-order-input-history.entity';
import { WorkOrderInputDetailEntity } from '@entities/work-order/work-order-bom-transit-history.entity';
import { InTransitHistoryEntity } from '@entities/work-order/in-transit-history.entity';
import { InTransitHistoryRepositoryInterface } from './interface/in-transit-history.repository.interface';
import { InTransitRepositoryInterface } from '@components/work-order/interface/in-transit.repository.interface';
import { WorkOrderScrapTransactionEntity } from '@entities/work-order/work-order-scrap-transaction.entity';
import { GetDetailWorkOrderTransactionRequestDto } from './dto/request/get-detail-work-order-transaction.request.dto';
import { WorkOrderTransactionRepositoryInterface } from './interface/work-order-transaction.repository.interface';
import { GetListWorkOrderTransactionRequestDto } from './dto/request/get-list-work-order-transaction.request.dto';
import { WorkOrderBomTransitEntity } from '@entities/work-order/work-order-bom-transit.entity';
import { BomDetailRepositoryInterface } from '@components/bom/interface/bom-detail.repository.interface';
import {
  CAN_APPROVE_WORK_ORDER_SCHEDULE_DETAIL_BY_WOS_STATUS,
  CAN_APPROVE_WORK_ORDER_SCHEDULE_DETAIL_STATUS,
  CAN_APPROVE_WORK_ORDER_SCHEDULE_STATUS,
  CAN_CONFIRM_IN_TRANSIT_STATUS,
  CAN_DELETE_WORK_ORDER_SCHEDULE_DETAIL_STATUS,
  CAN_EXPORT_WORK_ORDER_STATUS,
  CAN_IMPORT_IN_TRANSIT_STATUS,
  CAN_LOG_TIME_WORK_ORDER,
  CAN_QC_WORK_ORDER,
  CAN_REJECT_IN_TRANSIT_STATUS,
  CAN_REJECT_WORK_ORDER_SCHEDULE_DETAIL_STATUS,
  CAN_REJECT_WORK_ORDER_SCHEDULE_STATUS,
  CAN_SCAN_WORK_ORDER_STATUS,
  CAN_SUBMIT_WORK_ORDER_INPUT,
  CAN_SUBMIT_WORK_ORDER_SCRAP,
  PLAN_STATUS_ALLOW_CONFIRM,
  STAGE_OPTIONS,
  TransitStatusEnum,
  WorkOrderScheduleDetailStatusEnum,
  WorkOrderScheduleStatusEnum,
  WORK_ORDER_CODE_PREFIX,
  CAN_SET_RUNNING_STATUS_WORK_ORDER,
  WorkOrderRunningStatusEnum,
} from './work-order.constant';
import { Inject, Injectable, Logger } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ApiError } from '@utils/api.error';
import { ResponsePayload } from '@utils/response-payload';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { plainToInstance } from 'class-transformer';
import { ResponseBuilder } from '@utils/response-builder';
import { DataSource, In, Not, QueryRunner, Raw } from 'typeorm';
import {
  find,
  flatMap,
  isEmpty,
  map,
  uniq,
  filter,
  first,
  min,
  sumBy,
  values,
  last,
  flattenDeep,
  findIndex,
  maxBy,
  keyBy,
} from 'lodash';
import { PagingResponse } from '@utils/paging.response';
import { SuccessResponse } from '@utils/success.response.dto';
import {
  WorkOrderStatusEnum,
  CAN_DELETE_WORK_ORDER_STATUS,
  CAN_UPDATE_WORK_ORDER_STATUS,
  FormatCodeWorkOrder,
} from '@components/work-order/work-order.constant';
import { minus, plus } from '@utils/common';
import { WorkOrderServiceInterface } from '@components/work-order/interface/work-order.service.interface';
import { WorkOrderRepositoryInterface } from '@components/work-order/interface/work-order.repository.interface';
import { RoutingRepositoryInterface } from '@components/routing/interface/routing.repository.interface';
import { BomRepositoryInterface } from '@components/bom/interface/bom.repository.interface';
import { ProducingStepRepositoryInterface } from '@components/producing-step/interface/producing-step.repository.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { CreateWorkOrderRequestDto } from '@components/work-order/dto/request/create-work-order.request.dto';
import { UpdateWorkOrderRequestDto } from '@components/work-order/dto/request/update-work-order.request.dto';
import { SetStatusRequestDto } from '@components/work-order/dto/request/set-status.request.dto';
import { GetListWorkOrderRequestDto } from '@components/work-order/dto/request/get-list-work-order.request.dto';
import { WorkOrderResponseDto } from '@components/work-order/dto/response/work-order.response.dto';
import { GetListWorkOrderResponseDto } from '@components/work-order/dto/response/get-list-work-order.response.dto';
import { WorkOrderResponseAbstractDto } from '@components/work-order/dto/response/work-order.response.abstract.dto';
import { ScanWorkOrderRequestDto } from './dto/request/scan-work-order.request.dto';
import {
  extractWorkOrderIdFromQrCode,
  getFullDateString,
  getShiftTime,
  mul,
} from '@utils/helper';
import { WorkOrderScanResponseDto } from './dto/response/work-order-scan.response.dto';
import { SubmitWorkOrderInputRequestDto } from './dto/request/submit-work-order-input.request.dto';
import { SubmitWorkOrderInputResponseDto } from './dto/response/submit-work-order-input.response.dto';
import { SubmitWorkOrderScrapRequestDto } from './dto/request/submit-work-order-scrap.request.dto';
import { WorkOrderEntity } from '@entities/work-order/work-order.entity';
import { SubmitWorkOrderProgressRequestDto } from './dto/request/submit-work-order-progress.request.dto';
import { WorkOrderTransactionEntity } from '@entities/work-order/work-order-transaction.entity';
import { WorkOrderTransactionResponseDto } from './dto/response/work-order-transaction.response.dto';
import { WorkOrderTransactionDetailResponseDto } from './dto/response/detail-work-order-transaction.response.dto';
import { WorkOrderScrapTransactionRepositoryInterface } from './interface/work-order-scrap-transaction.repository.interface';
import { SubmitWorkOrderExportRequestDto } from './dto/request/submit-export-work-order.request.dto';
import { InTransitEntity } from '@entities/work-order/in-transit.entity';
import { GetListWorkOrderBomTransitHistoryRequestDto } from '@components/work-order/dto/request/get-list-work-order-bom-transit-history.request.dto';
import { GetListWorkOrderScrapTransactionRequestDto } from '@components/work-order/dto/request/get-list-work-order-scrap-transaction.request.dto';
import { GetDetailWorkOrderBomTransitHistoryRequestDto } from '@components/work-order/dto/request/get-detail-work-order-bom-transit-history.request.dto';
import { GetDetailWorkOrderScrapTransactionRequestDto } from '@components/work-order/dto/request/get-detail-work-order-scrap-transaction.request.dto';
import { GetListWorkOrderBomTransitHistoryResponseDto } from '@components/work-order/dto/response/get-list-work-order-bom-transit-history.response.dto';
import { GetListWorkOrderScrapTransactionResponseDto } from '@components/work-order/dto/response/get-list-work-order-scrap-transaction.response.dto';
import { WorkOrderBomTransitHistoryResponseDto } from '@components/work-order/dto/response/work-order-bom-transit-history.response.dto';
import { WorkOrderScrapTransactionResponseDto } from '@components/work-order/dto/response/work-order-scrap-transaction.response.dto';
import { WorkOrderScrapTransactionResponseAbstractDto } from '@components/work-order/dto/response/work-order-scrap-transaction.response.abstract.dto';
import { WorkOrderBomTransitHistoryResponseAbstractDto } from '@components/work-order/dto/response/work-order-bom-transit-history.response.abstract.dto';
import { GetListInTransitRequestDto } from './dto/request/get-list-in-transit.request.dto';
import { InTransitResponseDto } from './dto/response/in-transit.response.dto';
import { DetailWorkOrderExportRequestDto } from './dto/request/detail-work-order-export.request.dto';
import { GetDetailInTransitRequestDto } from './dto/request/get-detail-in-transit.request.dto';
import { ChangeStatusInTransitRequestDto } from './dto/request/change-status-in-transit.request.dto';
import { ImportInTransitRequestDto } from './dto/request/import-in-transit.request.dto';
import { WorkOrderInputDetailRepositoryInterface } from './interface/work-order-input-detail.repository.interface';
import { PrintQrcodeRequestDto } from './dto/request/print.request.dto';
import {
  endCommandChars,
  MINUTES_OF_ONE_DAY,
  startCommandChars,
} from '@constant/common';
import { UpdateQualityControlWorkOrderRequestDto } from './dto/request/update-quality-control-work-order.request.dto';
import { QualityControlCreatedEvent } from '@components/quality-control/events/quality-control-created.event';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { ManufacturingOrderRepositoryInterface } from '@components/manufacturing-order/interface/manufacturing-order.repository.interface';
import { ManufacturingOrderDetailRepositoryInterface } from '@components/manufacturing-order/interface/manufacturing-order-detail.repository.interface';
import { MoPlanRepositoryInteface } from '@components/plan/inteface/mo-plan.repository.inteface';
import { ManufacturingOrderEntity } from '@entities/manufacturing-order/manufacturing-orders.entity';
import { ManufacturingOrderDetailEntity } from '@entities/manufacturing-order/manufacturing-order-details.entity';
import { MoPlanBomEntity } from '@entities/manufacturing-order/mo-plan-boms.entity';
import { MoPlanBomTransactionEntity } from '@entities/manufacturing-order/mo-plan-bom-transactions.entity';
import { MoPlanBomRepositoryInteface } from '@components/plan/inteface/mo-plan-bom.repository.inteface';
import { ProducingStepSwitchModeEnum } from '@components/producing-step/producing-step.constant';
import { CreateWorkOrderLogTimeRequestDto } from './dto/request/create-work-order-log-time.request.dto';
import * as Moment from 'moment';
import { WorkOrderLogTimeEntity } from '@entities/work-order/work-order-log-time.entity';
import { WorkOrderLogTimeRepositoryInterface } from './interface/work-order-log-time.repository.interface';
import { ManufacturingOrderStatusEnum } from '@components/manufacturing-order/manufacturing-order.constant';
import { SaleServiceInterface } from '@components/sale-order/interface/sale.service.interface';
import { GetDetailWorkOrderByBomAndProducingStepRequestDto } from './dto/request/get-detail-work-order-by-bom-and-producing-step.request.dto';
import { WorkOrderScheduleResponseDto } from './dto/response/work-order-schedule.response.dto';
import { CreateWorkOrderScheduleRequestDto } from './dto/request/create-work-order-schedule.request.dto';
import { WorkOrderScheduleRepositoryInterface } from './interface/work-order-schedule.repsository.interface';
import { WorkOrderScheduleEntity } from '@entities/work-order/work-order-schedule.entity';
import { WorkOrderScheduleDetailRepositoryInterface } from './interface/work-order-schedule-detail.repository.interface';
import { WorkCenterRepositoryInterface } from '@components/work-center/interface/work-center.repository.interface';
import { QualityControlEntity } from '@entities/quality-control/quality-control.entity';
import { QualityControlRepositoryInterface } from '@components/quality-control/interface/quality-control.repository.interface';
import { WorkCenterShiftRepositoryInterface } from '@components/work-center/interface/work-center-shift.repository.interface';
import { WorkCenterResponseAbstractDto } from '@components/work-center/dto/response/work-center.response.abstract.dto';
import {
  GetWorkOrderScheduleDetailResponseDto,
  WOScheduleDetailDto,
} from './dto/response/work-order-schedule-detail.response.dto';
import { ChangeStatusWorkOrderScheduleRequestDto } from './dto/request/change-status-work-order-schedule.request.dto';
import { genDailySchedule } from '@utils/generate-schedule';
import { extendMoment } from 'moment-range';
import { WorkCenterDailyScheduleShiftRepositoryInterface } from '@components/work-center/interface/work-center-daily-schedule-shift.repository.interface';
import { WorkCenterDailyScheduleRepositoryInterface } from '@components/work-center/interface/work-center-daily-schedule.repository.interface';
import { WorkCenterDailyScheduleShiftEntity } from '@entities/work-center/work-center-daily-schedule-shift.entity';
import { WorkCenterUserRepositoryInterface } from '@components/work-center/interface/work-center-user.repository.interface';
import { WorkCenterServiceInterface } from '@components/work-center/interface/work-center.service.interface';
import { WorkOrderLogTimeDetailRepositoryInterface } from './interface/work-order-log-time_detail.repository.interface';
import { GetListWorkOrderScheduleRequestDto } from './dto/request/get-list-work-order-schedule.request.dto';
import { QualityControlService } from '@components/qmx/quality-control.service';
import {
  ManufacturingOrderProgressSetEvent,
  MoPlanBomProgressUpdateEvent,
  WorkOrderProgressUpdateEvent,
} from '@components/manufacturing-order/events/manufacturing-order-progress.event';
import { ImportWorkOrderMaterialInputRequestDto } from './dto/request/import-work-order-material-input.request.dto';
import { WorkOrderMaterialInputRepositoryInterface } from './interface/work-order-material-input.repository.interface';
import { WorkOrderMaterialInputEntity } from '@entities/work-order/material-input/work-order-material_input.entity';
import { UpdateWorkOrderGranttDataRequestDto } from './dto/response/update-work-order-grantt-data.request.dto';
import { WorkOrderLotRepositoryInterface } from './interface/work-order-lot.repository.interface';
import { WorkOrderLotEntity } from '@entities/work-order/lot/work-order-lot.entity';
import { MaterialPlanScheduleRepositoryInterface } from '@components/material/interface/material-plan-schedule.repository.interface';
import { MaterialPlanScheduleEntity } from '@entities/material/material-plan-schedules.entity';
import { WorkOrderWorkCenterLotEntity } from '@entities/work-order/lot/work-order-work-center-lot.entity';
import { WorkOrderWorkCenterLotRepositoryInterface } from './interface/work-order-work-center-lot.repository.interface';
import { WorkOrderLogTimeDetailEntity } from '@entities/work-order/work-order-log-time-detail.entity';
import { GetWorkOrderLogTimeRequestDto } from './dto/request/get-work-order-log-time.request.dto';
import { WorkOrderLogTimeResponseDto } from './dto/response/work-order-log-time.response.dto';
import { BomProducingStepDetailsRepositoryInterface } from '@components/bom/interface/bom-producing-step-details.repository.interface';
import { ConfigService } from '@config/config.service';
import { QualityControlAlertRepositoryInterface } from '@components/quality-control/interface/quality-control-alert.repository.interface';
import { WorkOrderBomTransitRepositoryInterface } from './interface/work-order-bom-transit.repository.interface';
import { LogTimeByWoIdsResponseDto } from './dto/response/log-time-by-wo-ids.response.dto';
import { LogTimeByWoIdsRequestDto } from './dto/request/log-time-by-wo-ids.request.dto';
import { AutocompleteRequestDto } from './dto/request/autocomplete.request.dto';
import { IotValue } from '@core/dto/request/iot.request.dto';
import { WorkCenterTypeEnum } from '@components/work-center/work-center.constant';
import { ChangeRunningStatusRequestDto } from './dto/request/change-running-status.request.dto';
import { WorkOrderRunningLogsRepositoryInterface } from './interface/work-order-running-logs.repository.interface';
import { WorkCenterEntity } from '@entities/work-center/work-center.entity';
import { RequestServiceInterface } from '@components/request/interface/request.service.interface';
import { ManufacturingRequestOrderIdParamRequestDto } from '@components/request/dto/request/manufacturing-request-order-id-param.request.dto';
import { error } from 'console';
import { UpdateProducedQuantityRequestDto } from '@components/request/dto/request/update-produced-quantity.request.dto';
const moment = extendMoment(Moment);

@Injectable()
export class WorkOrderService implements WorkOrderServiceInterface {
  private readonly logger = new Logger(WorkOrderService.name);

  constructor(
    @Inject('RoutingRepositoryInterface')
    private readonly routingRepository: RoutingRepositoryInterface,

    @Inject('BomRepositoryInterface')
    private readonly bomRepository: BomRepositoryInterface,

    @Inject('BomProducingStepDetailsRepositoryInterface')
    private readonly bomProducingStepDetailsRepository: BomProducingStepDetailsRepositoryInterface,

    @Inject('MoRepositoryInterface')
    private readonly moRepository: ManufacturingOrderRepositoryInterface,

    @Inject('InTransitRepositoryInterface')
    private readonly inTransitRepository: InTransitRepositoryInterface,

    @Inject('WorkOrderInputHistoryRepositoryInterface')
    private readonly workOrderInputHistoryRepository: WorkOrderInputHistoryRepositoryInterface,

    @Inject('InTransitHistoryRepositoryInterface')
    private readonly inTransitHistoryRepository: InTransitHistoryRepositoryInterface,

    @Inject('MoPlanBomRepositoryInterface')
    private readonly moPlanBomRepository: MoPlanBomRepositoryInteface,

    @Inject('MoPlanRepositoryInterface')
    private readonly moPlanRepository: MoPlanRepositoryInteface,

    @Inject('MoDetailRepositoryInterface')
    private readonly moDetailRepository: ManufacturingOrderDetailRepositoryInterface,

    @Inject('BomDetailRepositoryInterface')
    private readonly bomDetailRepository: BomDetailRepositoryInterface,

    @Inject('WorkOrderMaterialInputRepositoryInterface')
    private readonly workOrderMaterialInputRepository: WorkOrderMaterialInputRepositoryInterface,

    @Inject('WorkOrderRunningLogsRepositoryInterface')
    private readonly workOrderRunningLogsRepository: WorkOrderRunningLogsRepositoryInterface,

    @Inject('ProducingStepRepositoryInterface')
    private readonly producingStepRepository: ProducingStepRepositoryInterface,

    @Inject('WorkOrderRepositoryInterface')
    private readonly workOrderRepository: WorkOrderRepositoryInterface,

    @Inject('WorkOrderTransactionRepositoryInterface')
    private readonly workOrderTransactionRepository: WorkOrderTransactionRepositoryInterface,

    @Inject('WorkOrderScrapTransactionRepositoryInterface')
    private readonly workOrderScrapTransactionRepository: WorkOrderScrapTransactionRepositoryInterface,

    @Inject('WorkOrderInputDetailRepositoryInterface')
    private readonly workOrderInputDetailRepository: WorkOrderInputDetailRepositoryInterface,

    @Inject('WorkOrderLogTimeRepositoryInterface')
    private readonly workOrderLogTimeRepository: WorkOrderLogTimeRepositoryInterface,

    @Inject('WorkOrderLogTimeDetailRepositoryInterface')
    private readonly workOrderLogTimeDetailRepository: WorkOrderLogTimeDetailRepositoryInterface,

    @Inject('WorkOrderBomTransitRepositoryInterface')
    private readonly workOrderBomTransitRepository: WorkOrderBomTransitRepositoryInterface,

    @Inject('WorkOrderScheduleRepositoryInterface')
    private readonly workOrderScheduleRepository: WorkOrderScheduleRepositoryInterface,

    @Inject('WorkOrderScheduleDetailRepositoryInterface')
    private readonly workOrderScheduleDetailRepository: WorkOrderScheduleDetailRepositoryInterface,

    @Inject('WorkCenterRepositoryInterface')
    private readonly workCenterRepository: WorkCenterRepositoryInterface,

    @Inject('WorkCenterShiftRepositoryInterface')
    private readonly workCenterShiftRepository: WorkCenterShiftRepositoryInterface,

    @Inject('QualityControlRepositoryInterface')
    private readonly qualityControlRepository: QualityControlRepositoryInterface,

    @Inject('QualityControlAlertRepositoryInterface')
    private readonly qualityControlAlertRepository: QualityControlAlertRepositoryInterface,

    @Inject('WorkCenterDailyScheduleShiftRepositoryInterface')
    private readonly workCenterDailyScheduleShiftRepository: WorkCenterDailyScheduleShiftRepositoryInterface,

    @Inject('WorkCenterDailyScheduleRepositoryInterface')
    private readonly workCenterDailyScheduleRepository: WorkCenterDailyScheduleRepositoryInterface,

    @Inject('WorkCenterUserRepositoryInterface')
    private readonly workCenterUserRepository: WorkCenterUserRepositoryInterface,

    @Inject('WorkOrderLotRepositoryInterface')
    private readonly workOrderLotRepository: WorkOrderLotRepositoryInterface,

    @Inject('WorkOrderWorkCenterLotRepositoryInterface')
    private readonly workOrderWorkCenterLotRepository: WorkOrderWorkCenterLotRepositoryInterface,

    @Inject('MaterialPlanScheduleRepositoryInterface')
    private readonly materialPlanScheduleRepository: MaterialPlanScheduleRepositoryInterface,

    @Inject('WorkCenterServiceInterface')
    protected readonly workCenterService: WorkCenterServiceInterface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('SaleServiceInterface')
    protected readonly saleService: SaleServiceInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('QmsxServiceInterface')
    private readonly qmsxService: QualityControlService,

    @Inject('RequestServiceInterface')
    private readonly requestService: RequestServiceInterface,

    @Inject('ManufacturingOrderRepositoryInterface')
    private readonly manufacturingOrderRepository: ManufacturingOrderRepositoryInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly eventEmitter: EventEmitter2,

    private readonly i18n: I18nRequestScopeService,

    private readonly configService: ConfigService,
  ) {
    this.configService = new ConfigService();
  }

  public async setRunningStatus(
    request: ChangeRunningStatusRequestDto,
  ): Promise<any> {
    const { id, status, workCenterId, userId } = request;
    const workOrder = await this.workOrderRepository.findOneById(id);

    if (!workOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }

    if (!CAN_SET_RUNNING_STATUS_WORK_ORDER.includes(workOrder.status)) {
      return new ApiError(
        ResponseCodeEnum.FORBIDDEN,
        await this.i18n.translate('error.INVALID_STATUS'),
      ).toResponse();
    }

    const workCenter = await this.workCenterRepository.findOneByCondition({
      id: workCenterId,
    });
    if (isEmpty(workCenter)) {
      return new ApiError(
        ResponseCodeEnum.FORBIDDEN,
        await this.i18n.translate('error.WOKR_CENTER_NOT_FOUND'),
      ).toResponse();
    }
    if (
      workCenter.currentRunningWorkOrderId &&
      workCenter.currentRunningWorkOrderId != id
    ) {
      return new ApiError(
        ResponseCodeEnum.FORBIDDEN,
        await this.i18n.translate('error.CAN_NOT_START_WORK_ORDER_REASON_1'),
      ).toResponse();
    }

    const runningLogEntity = this.workOrderRunningLogsRepository.createEntity({
      ...request,
      workOrderId: workOrder.id,
    });
    if (status == WorkOrderRunningStatusEnum.RUNNING) {
      workOrder.startAt = new Date();
    }

    workOrder.runningStatus = status;
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      workCenter.currentRunningWorkOrderId = status == 1 ? id : 0;

      if (workCenter.type === WorkCenterTypeEnum.PLC) {
        const virtualWorkCenters =
          await this.workCenterRepository.findWithRelations({
            parentId: workCenter.id,
            isVirtual: 1,
          });
        virtualWorkCenters.forEach((virtualWorkCenter) => {
          virtualWorkCenter.currentRunningWorkOrderId = status == 1 ? id : 0;
        });
        await queryRunner.manager.save(virtualWorkCenters);
      }

      await queryRunner.manager.save(workOrder);
      await queryRunner.manager.save(workCenter);
      await queryRunner.manager.save(runningLogEntity);
      let logTimeRequest;
      if (status == 1) {
        logTimeRequest = {
          id: id,
          userId: userId,
          start: new Date(),
          workCenterId: workCenterId,
        } as CreateWorkOrderLogTimeRequestDto;
      } else if (status == 2) {
        logTimeRequest = {
          id: id,
          userId: userId,
          end: new Date(),
          workCenterId: workCenterId,
        } as CreateWorkOrderLogTimeRequestDto;
      }
      await this.logTimeWorkOrder(logTimeRequest);

      await queryRunner.commitTransaction();

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (e) {
      this.logger.error(`WORK_ORDER Create running error: `, e);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  async updateLogTimeWorkOrder(
    payload: CreateWorkOrderLogTimeRequestDto,
  ): Promise<any> {
    const { id, duration, end, play, pause, workCenterId } = payload;
    const logTime: any =
      await this.workOrderLogTimeRepository.findOneWithRelations({
        where: {
          id: id,
        },
        relations: ['details'],
      });

    if (!logTime || (logTime && logTime.isStopped)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const lastLogTime: any = maxBy(logTime.details, 'id');
    const workOrderId = logTime.workOrderId;
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (duration) {
        const durationInMinutes = div(Number(duration), 60);
        logTime.duration = plus(logTime.duration || 0, durationInMinutes);
        logTime.isStopped = 1;

        await queryRunner.manager.save(WorkOrderLogTimeEntity, logTime);
        const workCenterDailyScheduleEntity =
          await this.generateDataUpdateLogTimeDurationWorkCenterDailySchedule(
            workOrderId,
            workCenterId,
            durationInMinutes,
          );
        if (workCenterDailyScheduleEntity.statusCode) {
          return workCenterDailyScheduleEntity;
        }
        await queryRunner.manager.save(
          WorkCenterDailyScheduleEntity,
          workCenterDailyScheduleEntity,
        );
      } else if (!isEmpty(end)) {
        const startTime = moment(logTime.startTime);
        const endTime = moment(end);

        if (endTime.isSameOrBefore(startTime)) {
          return new ApiError(
            ResponseCodeEnum.BAD_REQUEST,
            await this.i18n.translate('error.START_END_TIME_IS_INVALID'),
          ).toResponse();
        }
        logTime.endTime = endTime;
        logTime.isStopped = 1;
        logTime.workCenterId = workCenterId;

        if (lastLogTime && !lastLogTime.endTime) {
          const detailStartTime = moment(lastLogTime.startTime);
          if (endTime.isSameOrBefore(detailStartTime)) {
            return new ApiError(
              ResponseCodeEnum.BAD_REQUEST,
              await this.i18n.translate('error.START_END_TIME_IS_INVALID'),
            ).toResponse();
          }
          const detailEndTime = moment(end);
          lastLogTime.endTime = detailEndTime.format();
          lastLogTime.duration = convertSecondsToMinutes(
            moment.duration(detailEndTime.diff(detailStartTime)).asSeconds(),
          );
          lastLogTime.isStopped = 1;
          lastLogTime.workCenterId = workCenterId;
          logTime.duration = plus(
            Number(logTime.duration),
            Number(lastLogTime.duration),
          );

          await queryRunner.manager.save(
            WorkOrderLogTimeDetailEntity,
            lastLogTime,
          );
        }

        await queryRunner.manager.save(WorkOrderLogTimeEntity, logTime);
      }
      if (!isEmpty(play)) {
        if (lastLogTime && !lastLogTime.endTime) {
          return new ApiError(
            ResponseCodeEnum.BAD_REQUEST,
            await this.i18n.translate('error.START_END_TIME_IS_INVALID'),
          ).toResponse();
        }
        const newLastLogTime = new WorkOrderLogTimeDetailEntity();
        newLastLogTime.workOrderLogTimeId = logTime.id;
        newLastLogTime.startTime = moment(play).format();
        newLastLogTime.workCenterId = workCenterId;
        await queryRunner.manager.save(
          WorkOrderLogTimeDetailEntity,
          newLastLogTime,
        );
      } else if (!isEmpty(pause)) {
        if (lastLogTime && lastLogTime.endTime) {
          return new ApiError(
            ResponseCodeEnum.BAD_REQUEST,
            await this.i18n.translate('error.START_END_TIME_IS_INVALID'),
          ).toResponse();
        }
        const detailStartTime = moment(lastLogTime.startTime);
        const detailEndTime = moment(pause);
        lastLogTime.endTime = detailEndTime.format();
        lastLogTime.duration = convertSecondsToMinutes(
          moment.duration(detailEndTime.diff(detailStartTime)).asSeconds(),
        );
        lastLogTime.isStopped = 1;
        lastLogTime.workCenterId = workCenterId;

        logTime.duration = plus(logTime.duration || 0, lastLogTime.duration);
        logTime.workCenterId = workCenterId;

        await queryRunner.manager.save(
          WorkOrderLogTimeDetailEntity,
          lastLogTime,
        );
        await queryRunner.manager.save(WorkOrderLogTimeEntity, logTime);
      }

      // update logtime schedule
      if (!isEmpty(end)) {
        const querylogTimeDetails =
          await this.workOrderLogTimeDetailRepository.queryRawGetWorkOrderLogTimeDetails(
            id,
          );
        const logTimeDetails = await queryRunner.manager.query(
          querylogTimeDetails,
          [id],
        );

        let workCenterDailySchedules =
          await this.workCenterDailyScheduleRepository.getWorkCenterDailyScheduleByCondition(
            {
              workCenterId: workCenterId,
              workOrderId: workOrderId,
              executionDays: [],
            },
          );

        for (let a = 0; a < logTimeDetails.length; a++) {
          const start = logTimeDetails[a].startTime;
          const end = logTimeDetails[a].endTime;

          if (
            moment(start)
              .set({ hour: 0, minute: 0, second: 0 })
              .isSame(moment(end).set({ hour: 0, minute: 0, second: 0 }))
          ) {
            const executionDay = new Date(start);
            const duration = convertSecondsToMinutes(
              Math.round(
                moment.duration(moment(end).diff(moment(start))).asSeconds(),
              ),
            );

            const workCenterDailyScheduleEntity =
              await this.generateDataUpdateLogTimeDurationWorkCenterDailySchedule(
                workOrderId,
                workCenterId,
                duration,
                executionDay,
              );
            if (workCenterDailyScheduleEntity.statusCode) {
              return workCenterDailyScheduleEntity;
            }

            const logTimeDurationUpdate = [];
            logTimeDurationUpdate[workCenterDailyScheduleEntity.id] = duration;
            workCenterDailySchedules = workCenterDailySchedules.map(
              (record) => ({
                id: record.id,
                logTimeDuration: plus(
                  Number(record.logTimeDuration),
                  Number(logTimeDurationUpdate[record.id]) || 0,
                ),
              }),
            );
          } else {
            const executionDays = [];
            let executionDay = moment(start, 'YYYY-MM-DD').clone();

            while (executionDay.isSameOrBefore(moment(end, 'YYYY-MM-DD'))) {
              executionDays.push(executionDay.format('YYYY-MM-DD'));
              executionDay = executionDay.add(1, 'days');
            }

            const logTimeForStart = convertSecondsToMinutes(
              Math.round(
                moment
                  .duration(
                    moment(start)
                      .add(1, 'days')
                      .set({ hour: 0, minute: 0, second: 0 })
                      .diff(moment(start)),
                  )
                  .asSeconds(),
              ),
            );
            const logTimeForEnd = convertSecondsToMinutes(
              Math.round(
                moment
                  .duration(
                    moment(end).diff(
                      moment(end).set({ hour: 0, minute: 0, second: 0 }),
                    ),
                  )
                  .asSeconds(),
              ),
            );

            const lengthExecutionDays = executionDays.length;

            for (let i = 0; i < lengthExecutionDays; i++) {
              let logTimeDuration = 0;
              if (i === 0) {
                logTimeDuration = logTimeForStart;
              } else if (plus(i, 1) === lengthExecutionDays) {
                logTimeDuration = logTimeForEnd;
              } else {
                logTimeDuration = MINUTES_OF_ONE_DAY;
              }

              const workCenterDailyScheduleEntity =
                await this.generateDataUpdateLogTimeDurationWorkCenterDailySchedule(
                  workOrderId,
                  workCenterId,
                  logTimeDuration,
                  executionDays[i],
                );
              if (workCenterDailyScheduleEntity.statusCode) {
                return workCenterDailyScheduleEntity;
              }
              const logTimeDurationUpdate = [];
              logTimeDurationUpdate[workCenterDailyScheduleEntity.id] =
                logTimeDuration;
              workCenterDailySchedules = workCenterDailySchedules.map(
                (record) => ({
                  id: record.id,
                  logTimeDuration: plus(
                    Number(record.logTimeDuration),
                    Number(logTimeDurationUpdate[record.id]) || 0,
                  ),
                }),
              );
            }
          }
        }

        await queryRunner.manager.save(
          WorkCenterDailyScheduleEntity,
          workCenterDailySchedules,
        );
      }
      // end
      await queryRunner.commitTransaction();
      const requestToGetLogTimeDetail = new GetWorkOrderLogTimeRequestDto();
      requestToGetLogTimeDetail.id = logTime.workOrderId;
      return await this.getLogTimeWorkOrder(requestToGetLogTimeDetail);
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.INTERNAL_SERVER_ERROR'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }
  }

  async getLogTimeWorkOrder(
    payload: GetWorkOrderLogTimeRequestDto,
  ): Promise<any> {
    const { id, workCenterId } = payload;

    const logTime: any =
      await this.workOrderLogTimeRepository.getLogTimeByWorkOrderId(
        id,
        workCenterId,
      );

    if (logTime) {
      const lastLogTime: any = maxBy(logTime.details, 'id');
      logTime.lastPlay = lastLogTime.play;
      logTime.isOpenning = lastLogTime.end ? false : true;
    }

    const response = plainToInstance(WorkOrderLogTimeResponseDto, logTime, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async logTimeWorkOrder(
    payload: CreateWorkOrderLogTimeRequestDto,
  ): Promise<any> {
    const { id, start, end, duration, pause, play, workCenterId } = payload;
    let logTime;
    const workOrder = await this.workOrderRepository.findOneById(id);

    if (!workOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }

    if (!CAN_LOG_TIME_WORK_ORDER.includes(workOrder.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    }

    if (isEmpty(start) && !duration && isEmpty(end)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.START_END_TIME_IS_INVALID'),
      ).toResponse();
    }
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (duration) {
        const durationInMinutes = div(Number(duration), 60);
        logTime = await queryRunner.manager.save(WorkOrderLogTimeEntity, {
          workOrderId: id,
          duration: durationInMinutes,
          isStopped: 1,
          workCenterId: workCenterId,
        });
        const workCenterDailyScheduleEntity =
          await this.generateDataUpdateLogTimeDurationWorkCenterDailySchedule(
            id,
            workCenterId,
            durationInMinutes,
          );
        if (workCenterDailyScheduleEntity.statusCode) {
          return workCenterDailyScheduleEntity;
        }
        await queryRunner.manager.save(
          WorkCenterDailyScheduleEntity,
          workCenterDailyScheduleEntity,
        );
      } else {
        logTime = new WorkOrderLogTimeEntity();
        logTime.workOrderId = id;
        const startTime = start ? moment(start) : null;
        const endTime = end ? moment(end) : null;
        if (start && end && moment(start).isAfter(moment(end))) {
          return new ApiError(
            ResponseCodeEnum.BAD_REQUEST,
            await this.i18n.translate('error.START_END_TIME_IS_INVALID'),
          ).toResponse();
        }
        logTime.startTime = startTime;
        logTime.endTime = endTime;
        logTime.isStopped = startTime && endTime ? 1 : 0;
        logTime.workCenterId = workCenterId;

        logTime.duration = logTime.isStopped
          ? moment.duration(endTime.diff(startTime)).asMinutes()
          : null;
        logTime = await queryRunner.manager.save(
          WorkOrderLogTimeEntity,
          logTime,
        );
        let logTimeDetail =
          await this.workOrderLogTimeDetailRepository.findOneByCondition({
            workOrderLogTimeId: logTime.id,
            isStopped: 0,
          });
        if (!logTimeDetail) {
          logTimeDetail = new WorkOrderLogTimeDetailEntity();
          logTimeDetail.workOrderLogTimeId = logTime.id;
        }
        if (start) {
          logTimeDetail.startTime = startTime?.format();
        }
        if (pause) {
          logTimeDetail.endTime = moment(pause)?.format();
        }
        if (end) {
          logTimeDetail.endTime = moment(end)?.format();
        }
        if (play) {
          logTimeDetail.startTime = moment(play)?.format();
        }

        logTimeDetail.isStopped =
          logTimeDetail.startTime && logTimeDetail.endTime ? 1 : 0;

        logTimeDetail.duration = Math.round(
          logTimeDetail.isStopped
            ? convertSecondsToMinutes(
                moment
                  .duration(
                    moment(logTimeDetail.endTime).diff(
                      moment(logTimeDetail.startTime),
                    ),
                  )
                  .asSeconds(),
              )
            : 0,
        );
        logTimeDetail.workCenterId = workCenterId;
        await queryRunner.manager.save(
          WorkOrderLogTimeDetailEntity,
          logTimeDetail,
        );
      }
      await queryRunner.commitTransaction();
      const requestToGetLogTimeDetail = new GetWorkOrderLogTimeRequestDto();
      requestToGetLogTimeDetail.id = id;
      return await this.getLogTimeWorkOrder(requestToGetLogTimeDetail);
    } catch (error) {
      console.log(error);

      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.INTERNAL_SERVER_ERROR'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }
  }

  private async generateDataUpdateLogTimeDurationWorkCenterDailySchedule(
    workOrderId: number,
    workCenterId: number,
    duration: number,
    day?: Date,
  ): Promise<any> {
    let executionDay;
    if (!day) {
      executionDay = moment().set({ hour: 0, minute: 0, second: 0 });
    } else {
      executionDay = moment(day).set({ hour: 0, minute: 0, second: 0 });
    }

    const workCenterDailySchedules =
      await this.workCenterDailyScheduleRepository.getWorkCenterDailyScheduleByCondition(
        {
          workCenterId: workCenterId,
          workOrderId: workOrderId,
          executionDays: [],
        },
      );

    if (isEmpty(workCenterDailySchedules)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.WORK_CENTER_DAILY_SCHEDULE_NOT_FOUND'),
      ).toResponse();
    }
    let workCenterDailySchedule;
    workCenterDailySchedule = workCenterDailySchedules.filter((record) =>
      moment(record.executionDay, 'YYYY-MM-DD').isSame(executionDay, 'day'),
    );

    if (!isEmpty(workCenterDailySchedule)) {
      workCenterDailySchedule = first(workCenterDailySchedule);
    } else {
      const workCenterDailyScheduleStart = first(workCenterDailySchedules);
      const workCenterDailyScheduleEnd = last(workCenterDailySchedules);
      if (
        executionDay.isSameOrBefore(
          moment(workCenterDailyScheduleStart['executionDay']),
        )
      ) {
        workCenterDailySchedule = workCenterDailyScheduleStart;
      } else if (
        executionDay.isSameOrAfter(
          moment(workCenterDailyScheduleEnd['executionDay']),
        )
      ) {
        workCenterDailySchedule = workCenterDailyScheduleEnd;
      }
    }

    const logTimeDuration = plus(
      workCenterDailySchedule['logTimeDuration'] || 0,
      Number(duration) || 0,
    );

    const workCenterDailyScheduleEntity = new WorkCenterDailyScheduleEntity();
    workCenterDailyScheduleEntity.id = workCenterDailySchedule['id'];
    workCenterDailyScheduleEntity.logTimeDuration = logTimeDuration;
    workCenterDailyScheduleEntity.workCenterId = workCenterId;
    return workCenterDailyScheduleEntity;
  }

  async updateQualityControlWorkOrder(
    request: UpdateQualityControlWorkOrderRequestDto,
    workOrder?: WorkOrderEntity,
    queryRunner?: QueryRunner,
  ): Promise<any> {
    this.logger.debug('START updateQualityControlWorkOrder');

    const withoutQueryRunenr = isEmpty(queryRunner);
    const {
      id,
      passQuantity,
      rejectQuantity,
      note,
      userId,
      workCenterId,
      executionDay,
    } = request;
    let shouldDispatchUpdateMoStatusEvent = false;
    if (isEmpty(workOrder)) {
      workOrder = await this.workOrderRepository.findOneWithRelations({
        where: { id },
        relations: ['workOrderSchedule'],
      });
    }

    if (!workOrder || isEmpty(workOrder.workOrderSchedule)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }
    if (!CAN_QC_WORK_ORDER.includes(workOrder.status)) {
      this.logger.debug('updateQualityControlWorkOrder STATUS_IS_INVALID');
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_IS_INVALID'),
      ).toResponse();
    }

    if (!passQuantity && !rejectQuantity) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.INVALID_QUANTITY'),
      ).toResponse();
    }

    const workOrderScheduleDetail =
      await this.workOrderScheduleDetailRepository.findOneByCondition({
        workCenterId,
        workOrderScheduleId: first(workOrder.workOrderSchedule).id,
      });

    if (!workOrderScheduleDetail) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.WORK_ORDER_SCHEDULE_DETAIL_NOT_FOUND',
          ),
        )
        .build();
    }

    const workCenterShifts =
      await this.workCenterShiftRepository.findByCondition({
        workCenterId,
      });
    if (isEmpty(workCenterShifts)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WORK_CENTER_SHIFT_N_NOT_FOUND'),
        )
        .build();
    }
    let shift = workCenterShifts.find((workCenterShift) => {
      const { start, end } = getShiftTime(
        workCenterShift.startAt,
        workCenterShift.endAt,
      );
      const range = moment.range(start, end);
      return range.contains(moment(executionDay));
    });
    if (isEmpty(shift)) {
      shift = last(workCenterShifts);
    }
    const defaultTimeZone = this.configService.get('defaultTimeZone');
    const executionDate = getFullDateString(executionDay);
    const workCenterDailySchedule =
      await this.workCenterDailyScheduleRepository.findOneWithRelations({
        where: {
          workOrderScheduleDetailId: workOrderScheduleDetail.id,
          workCenterId: workCenterId,
          executionDay: Raw(
            () =>
              `to_char(execution_day AT TIME ZONE '${defaultTimeZone}', 'yyyy-mm-dd' ) = '${executionDate}'`,
          ),
        },
      });
    if (!workCenterDailySchedule) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WORK_CENTER_SHIFT_N_NOT_FOUND'),
        )
        .build();
    }

    const workCenterDailyScheduleShift =
      await this.workCenterDailyScheduleShiftRepository.findOneByCondition({
        workCenterDailyScheduleId: workCenterDailySchedule.id,
        workCenterShiftId: shift.id,
        executionDay: Raw(
          () =>
            `to_char(execution_day AT TIME ZONE '${defaultTimeZone}', 'yyyy-mm-dd' ) = '${executionDate}'`,
        ),
      });
    if (!workCenterDailyScheduleShift) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WORK_CENTER_SHIFT_N_NOT_FOUND'),
        )
        .build();
    }
    workCenterDailyScheduleShift.qcPassQuantity = plus(
      workCenterDailyScheduleShift.qcPassQuantity || 0,
      passQuantity || 0,
    );
    workCenterDailyScheduleShift.qcRejectQuantity = plus(
      workCenterDailyScheduleShift.qcRejectQuantity,
      rejectQuantity,
    );

    const unQcQuantity = minus(
      workOrder.actualQuantity,
      plus(workOrder.qcPassQuantity, workOrder.qcRejectQuantity),
    );
    // if (plus(passQuantity || 0, rejectQuantity || 0) > unQcQuantity) {
    //   this.logger.debug("updateQualityControlWorkOrderL  lus(passQuantity || 0, rejectQuantity || 0) > unQcQuantity", plus(passQuantity || 0, rejectQuantity || 0) > unQcQuantity )
    //   return new ResponseBuilder()
    //     .withCode(ResponseCodeEnum.BAD_REQUEST)
    //     .withMessage(await this.i18n.translate('error.INVALID_QUANTITY'))
    //     .build();
    // }
    const isLatestStepOfBom =
      await this.routingRepository.isLatestStepInRouting(
        workOrder.routingId,
        workOrder.producingStepId,
      );
    if (withoutQueryRunenr) {
      queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
    }

    try {
      const qualityControlEntity = this.qualityControlRepository.createEntity({
        workOrderId: workOrder.id,
        createdByUserId: userId,
        totalQcQuantity: unQcQuantity,
        totalQcPassQuantity: workOrder.qcPassQuantity,
        totalQcRejectQuantity: workOrder.qcRejectQuantity,
        qcPassQuantity: passQuantity,
        qcRejectQuantity: rejectQuantity,
        note: note,
      });
      await queryRunner.manager.save(
        QualityControlEntity,
        qualityControlEntity,
      );
      workOrder.qcPassQuantity = plus(
        workOrder.qcPassQuantity || 0,
        passQuantity || 0,
      );
      workOrder.qcRejectQuantity = plus(
        workOrder.qcRejectQuantity,
        rejectQuantity || 0,
      );
      if (
        minus(+workOrder.qcPassQuantity || 0, +workOrder.quantity || 0) >= 0
      ) {
        workOrder.status = WorkOrderStatusEnum.COMPLETED;
        workOrder.runningStatus = WorkOrderRunningStatusEnum.STOP;
        const currentWCs = await this.workCenterRepository.findWithRelations({
          where: {
            currentRunningWorkOrderId: workOrder.id,
          },
        });
        if (!isEmpty(currentWCs)) {
          for (let index = 0; index < currentWCs.length; index++) {
            const currentWC = currentWCs[index];
            currentWC.currentRunningWorkOrderId = null;
          }
          await queryRunner.manager.save(WorkCenterEntity, currentWCs);
        }
      }
      workOrderScheduleDetail.qcPassQuantity = plus(
        workOrderScheduleDetail.qcPassQuantity || 0,
        passQuantity || 0,
      );
      workOrderScheduleDetail.qcRejectQuantity = plus(
        workOrderScheduleDetail.qcRejectQuantity,
        rejectQuantity || 0,
      );

      let currentMoPlanBomId = null;

      if (isLatestStepOfBom) {
        // Update actual quantity of current bom
        const currentMoPlanBom = await this.moPlanBomRepository.findOneById(
          workOrder.moPlanBomId,
        );
        const moDetail = await this.moDetailRepository.findOneByCondition({
          id: currentMoPlanBom.moDetailId,
          manufacturingOrderId: currentMoPlanBom.moId,
          bomId: currentMoPlanBom.bomId,
        });
        // BOM is finished product!!

        if (moDetail) {
          moDetail.actualQuantity = plus(
            moDetail.actualQuantity || 0,
            passQuantity || 0,
          );
          await queryRunner.manager.save(
            ManufacturingOrderDetailEntity,
            moDetail,
          );
          shouldDispatchUpdateMoStatusEvent = true;
        }
        currentMoPlanBom.actualQuantity = plus(
          currentMoPlanBom.actualQuantity,
          passQuantity || 0,
        );
        const moPlanBomTransaction = new MoPlanBomTransactionEntity();
        moPlanBomTransaction.moId = workOrder.moId;
        moPlanBomTransaction.moPlanId = currentMoPlanBom.moPlanId;
        moPlanBomTransaction.moPlanBomId = workOrder.moPlanBomId;
        moPlanBomTransaction.quantity = passQuantity;
        if (
          minus(currentMoPlanBom.actualQuantity, currentMoPlanBom.quantity) >= 0
        ) {
          currentMoPlanBom.status = WorkOrderStatusEnum.COMPLETED;
          const plc = await this.workCenterRepository.findOneWithRelations({
            where: {
              currentRunningWorkOrderId: currentMoPlanBom.id,
            },
          });

          if (!isEmpty(plc)) {
            plc.currentRunningWorkOrderId = null;
            const virtualDevices =
              await this.workCenterRepository.findWithRelations({
                where: {
                  parentId: plc.id,
                  isVirtual: 1,
                },
              });
            if (!isEmpty(virtualDevices)) {
              for (let index = 0; index < virtualDevices.length; index++) {
                const currentWC = virtualDevices[index];
                currentWC.currentRunningWorkOrderId = null;
              }
              await queryRunner.manager.save(WorkCenterEntity, virtualDevices);
            }
            await queryRunner.manager.save(WorkCenterEntity, plc);
          }
        }
        await queryRunner.manager.save(MoPlanBomEntity, currentMoPlanBom);
        await queryRunner.manager.save(
          MoPlanBomTransactionEntity,
          moPlanBomTransaction,
        );
        currentMoPlanBomId = currentMoPlanBom.id;
      }
      await queryRunner.manager.save(
        WorkCenterDailyScheduleShiftEntity,
        workCenterDailyScheduleShift,
      );

      await queryRunner.manager.save(
        WorkOrderScheduleDetailEntity,
        workOrderScheduleDetail,
      );

      await queryRunner.manager.save(WorkOrderEntity, workOrder);

      if (withoutQueryRunenr) {
        await queryRunner.commitTransaction();
      }
      if (currentMoPlanBomId) {
        await this.moPlanBomRepository.updateEndAt(currentMoPlanBomId);
        await this.moPlanBomRepository.updateStartAt(currentMoPlanBomId);
      }
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      this.logger.error(error);
      if (!withoutQueryRunenr) {
        queryRunner.rollbackTransaction();
        queryRunner.release();
        throw error;
      }
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    } finally {
      if (withoutQueryRunenr) {
        await queryRunner.release();
      }
      if (shouldDispatchUpdateMoStatusEvent) {
        console.log('00000000');
        this.eventEmitter.emit(
          'quality-control.created',
          new QualityControlCreatedEvent({
            moId: workOrder.moId,
          }),
        );
      }
    }
  }

  public async create(
    request: CreateWorkOrderRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const validateWorkOrder = await this.validateWorkOrder(request);

    if (validateWorkOrder.statusCode === ResponseCodeEnum.BAD_REQUEST) {
      return validateWorkOrder;
    }

    const { moPlanBom } = validateWorkOrder.data;

    const workOrderSameProducingSteps =
      await this.workOrderRepository.findByCondition({
        moPlanBomId: moPlanBom.id,
        producingStepId: request.producingStepId,
      });

    let totalQuantity = request.quantity;

    if (workOrderSameProducingSteps.length > 0) {
      workOrderSameProducingSteps.forEach((workOrder) => {
        totalQuantity = plus(totalQuantity, workOrder.quantity);
      });
    }

    if (totalQuantity > moPlanBom.quantity) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.QUANTITY_IS_BIGGER_THAN_PLAN'),
      ).toResponse();
    }

    request.moPlanBomId = moPlanBom.id;
    const workOrderEntity = await this.workOrderRepository.createEntity(
      request,
    );

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const result = await queryRunner.manager.save(
        WorkOrderEntity,
        workOrderEntity,
      );

      const response = plainToInstance(WorkOrderResponseAbstractDto, result, {
        excludeExtraneousValues: true,
      });

      response.code = FormatCodeWorkOrder + result.id;
      await queryRunner.commitTransaction();
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }
  }

  public async update(
    request: UpdateWorkOrderRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { id } = request;
    const workOrder = await this.workOrderRepository.findOneById(id);

    if (!workOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }

    if (!CAN_UPDATE_WORK_ORDER_STATUS.includes(workOrder.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_IS_INVALID'),
      ).toResponse();
    }

    const validateWorkOrder = await this.validateWorkOrder(request);

    if (validateWorkOrder.statusCode === ResponseCodeEnum.BAD_REQUEST) {
      return validateWorkOrder;
    }

    const { moPlanBom } = validateWorkOrder.data;

    const workOrderSameProducingSteps =
      await this.workOrderRepository.findByCondition({
        moPlanBomId: moPlanBom.id,
        producingStepId: request.producingStepId,
        id: Not(id),
      });

    let totalQuantity = request.quantity;

    if (workOrderSameProducingSteps?.length > 0) {
      workOrderSameProducingSteps.forEach((workOrder) => {
        totalQuantity = plus(totalQuantity, workOrder.quantity);
      });
    }

    if (totalQuantity > moPlanBom.quantity) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.QUANTITY_IS_BIGGER_THAN_PLAN'),
      ).toResponse();
    }

    request.moPlanBomId = moPlanBom.id;
    const workOrderEntity = await this.workOrderRepository.createEntity(
      request,
      workOrder,
    );

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const result = await queryRunner.manager.save(
        WorkOrderEntity,
        workOrderEntity,
      );

      const response = plainToInstance(WorkOrderResponseAbstractDto, result, {
        excludeExtraneousValues: true,
      });

      response.code = FormatCodeWorkOrder + result.id;
      await queryRunner.commitTransaction();
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }
  }

  public async detail(
    id: number,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const workOrder = await this.workOrderRepository.getDetail(id);

    if (!workOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }

    workOrder.approver = {};

    if (workOrder.approverId !== null) {
      const users = await this.userService.getUserByIds(
        [workOrder.approverId],
        false,
      );
      workOrder.approver = !isEmpty(users[0]) ? users[0] : {};
    }
    const itemIds = uniq([workOrder.moDetail.itemId, workOrder.bom.itemId]);
    const mo = await this.moRepository.getDetail(workOrder.mo.id);
    const factory = await this.userService.getFactoriesByIds(
      [mo.factoryId],
      true,
    );
    workOrder.factory = factory[mo.factoryId] || {};
    const items = await this.itemService.getItemsByIds(itemIds, true);
    const manufacturingRequestOrderMap =
      await this.requestService.getManufacturingRequestOrderByIds(
        [workOrder.mo.manufacturingRequestOrderId],
        true,
      );
    workOrder.moDetail = {
      ...workOrder.moDetail,
      itemName: !isEmpty(items[workOrder.moDetail.itemId])
        ? items[workOrder.moDetail.itemId].name
        : null,
      itemUnitId: !isEmpty(items[workOrder.moDetail.itemId])
        ? items[workOrder.moDetail.itemId].itemunitid
        : null,
    };

    workOrder.bom = {
      ...workOrder.bom,
      itemName: !isEmpty(items[workOrder.bom.itemId])
        ? items[workOrder.bom.itemId].name
        : null,
      itemUnitId: !isEmpty(items[workOrder.bom.itemId])
        ? items[workOrder.bom.itemId].itemunitid
        : null,
    };
    workOrder.manufacturingRequestOrder =
      manufacturingRequestOrderMap[workOrder.mo.manufacturingRequestOrderId];

    const response = plainToInstance(WorkOrderResponseAbstractDto, workOrder, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async detailByBomAndProducingStep(
    request: GetDetailWorkOrderByBomAndProducingStepRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const workOrder =
      await this.workOrderRepository.getDetailByBomAndProducingStep(
        request.bomId,
        request.producingStepId,
      );

    if (!workOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }

    workOrder.approver = {};

    if (workOrder.approverId !== null) {
      const users = await this.userService.getUserByIds(
        [workOrder.approverId],
        false,
      );
      workOrder.approver = !isEmpty(users[0]) ? users[0] : {};
    }
    const itemIds = uniq([workOrder.moDetail.itemId, workOrder.bom.itemId]);

    const items = await this.itemService.getItemsByIds(itemIds, true);

    workOrder.moDetail = {
      ...workOrder.moDetail,
      itemName: !isEmpty(items[workOrder.moDetail.itemId])
        ? items[workOrder.moDetail.itemId].name
        : null,
      itemUnitId: !isEmpty(items[workOrder.moDetail.itemId])
        ? items[workOrder.moDetail.itemId].itemunitid
        : null,
    };

    workOrder.bom = {
      ...workOrder.bom,
      itemName: !isEmpty(items[workOrder.bom.itemId])
        ? items[workOrder.bom.itemId].name
        : null,
      itemUnitId: !isEmpty(items[workOrder.bom.itemId])
        ? items[workOrder.bom.itemId].itemUnitId
        : null,
    };

    const response = plainToInstance(WorkOrderResponseAbstractDto, workOrder, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async delete(
    id: number,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const workOrder = await this.workOrderRepository.findOneById(id);

      if (!workOrder) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
          .build();
      }

      if (!CAN_DELETE_WORK_ORDER_STATUS.includes(workOrder.status)) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.STATUS_IS_INVALID'),
        ).toResponse();
      }

      await queryRunner.manager.delete(WorkOrderEntity, id);

      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_DELETE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }
  }

  public async getList(
    request: GetListWorkOrderRequestDto,
  ): Promise<ResponsePayload<GetListWorkOrderResponseDto | any>> {
    const filterMoDetailItemName = request.filter?.find(
      (item) => item.column === 'moDetailItemName',
    );
    const itemNameFilter = request.filter?.find(
      (item) => item.column === 'itemName',
    );

    let filterItemNameIds = [];

    if (!isEmpty(itemNameFilter)) {
      filterItemNameIds = await this.itemService.getItemsByName(
        itemNameFilter,
        true,
      );

      if (isEmpty(filterItemNameIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: 0 },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    let filterItemCodeIds = [];

    const itemCodeFilter = request.filter?.find(
      (item) => item.column === 'itemCode',
    );
    if (!isEmpty(itemCodeFilter)) {
      filterItemCodeIds = await this.itemService.getItemsByCode(
        itemCodeFilter,
        true,
      );

      if (isEmpty(filterItemCodeIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: 0 },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    let filterMoDetailItemIds = [];

    if (!isEmpty(filterMoDetailItemName)) {
      filterMoDetailItemIds = await this.itemService.getItemsByName(
        filterMoDetailItemName,
        true,
      );

      if (isEmpty(filterMoDetailItemIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    const filterBomItemName = request.filter?.find(
      (item) => item.column === 'bomItemName',
    );

    let FilterBomItemIds = [];

    if (!isEmpty(filterBomItemName)) {
      FilterBomItemIds = await this.itemService.getItemsByName(
        filterBomItemName,
        true,
      );

      if (isEmpty(FilterBomItemIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    const searchBomItemIds = [];

    const filterWorkCenterId = request.filter?.find(
      (item) => item.column === 'workCenterId',
    );

    let workCenter;

    if (!isEmpty(filterWorkCenterId)) {
      workCenter = await this.workCenterRepository.findOneById(
        +filterWorkCenterId.text,
      );
      if (!isEmpty(workCenter) && workCenter.type == WorkCenterTypeEnum.PLC) {
        const virtualWorkCenters =
          await this.workCenterRepository.findWithRelations({
            where: {
              isVirtual: 1,
              parentId: workCenter.id,
            },
          });
        request.filter.forEach((filter) => {
          if (filter.column === 'workCenterId') {
            filter.text = map(virtualWorkCenters, 'id').join(',');
          }
        });
      }
    }

    const { result, count } = await this.workOrderRepository.getList(
      request,
      filterMoDetailItemIds,
      FilterBomItemIds,
      filterItemNameIds,
      filterItemCodeIds,
      searchBomItemIds,
    );

    const moDetailItemIds = uniq(map(flatMap(result, 'moDetail'), 'itemId'));
    const bomItemIds = uniq(map(flatMap(result, 'moBom'), 'itemId'));
    const parentBomItemIds = uniq(
      map(result, (r) => {
        if (!isEmpty(r.bom?.parentBom)) {
          return r.bom?.parentBom.itemId;
        }
      }).filter((i) => !isNaN(i)),
    );
    const manufacturingRequestOrderIds = uniq(
      map(flatMap(result, 'mo'), 'manufacturingRequestOrderId'),
    );
    const itemIds = [
      ...new Set([...moDetailItemIds, ...bomItemIds, ...parentBomItemIds]),
    ];

    const items = await this.itemService.getItemsByIds(itemIds, true);

    const manufacturingRequestOrderMap =
      await this.requestService.getManufacturingRequestOrderByIds(
        manufacturingRequestOrderIds,
        true,
      );
    const userIds = uniq(map(flatMap(result), 'approverId'));
    userIds.push(
      ...flattenDeep(
        result.map((i) => i.workCenters?.map((j) => j['leaderId'])),
      ),
    );
    const users = await this.userService.getUserByIds(userIds, true);

    let itemUnitIds = [];
    for (const key in items) {
      itemUnitIds.push(items[key].itemUnitId);
    }
    itemUnitIds = uniq(itemUnitIds);

    const itemUnits = await this.itemService.getItemUnitByIds(
      itemUnitIds,
      true,
    );

    const data = result.map((workOrder) => {
      let canStart = false;
      if (!isEmpty(workCenter)) {
        if (!workCenter.currentRunningWorkOrderId) canStart = true;
        if (workCenter.currentRunningWorkOrderId == workOrder.id)
          canStart = true;
      }
      return {
        ...workOrder,
        moDetail: {
          ...workOrder.moDetail,
          itemName: !isEmpty(items[workOrder.moDetail.itemId])
            ? items[workOrder.moDetail.itemId].name
            : null,
          itemUnit: !isEmpty(
            itemUnits[items[workOrder.moDetail.itemId]?.itemUnitId],
          )
            ? {
                id: items[workOrder.moDetail.itemId].itemUnitId,
                name: itemUnits[items[workOrder.moDetail.itemId].itemUnitId]
                  .name,
                code: itemUnits[items[workOrder.moDetail.itemId].itemUnitId]
                  .code,
              }
            : {},
        },
        bom: {
          ...workOrder.bom,
          itemName: !isEmpty(items[workOrder.bom.itemId])
            ? items[workOrder.bom.itemId].name
            : null,
          itemUnit: !isEmpty(itemUnits[items[workOrder.bom.itemId]?.itemUnitId])
            ? {
                id: items[workOrder.bom.itemId].itemUnitId,
                name: itemUnits[items[workOrder.bom.itemId].itemUnitId].name,
                code: itemUnits[items[workOrder.bom.itemId].itemUnitId].code,
              }
            : {},
          parentBom: {
            ...workOrder.bom?.parentBom,
            itemName: !isEmpty(items[workOrder.bom?.parentBom?.itemId])
              ? items[workOrder.bom?.parentBom?.itemId].name
              : null,
            itemUnit: !isEmpty(
              itemUnits[items[workOrder.bom.parentBom?.itemId]?.itemUnitId],
            )
              ? {
                  id: items[workOrder.bom.parentBom?.itemId].itemUnitId,
                  name: itemUnits[
                    items[workOrder.bom.parentBom?.itemId].itemUnitId
                  ].name,
                  code: itemUnits[
                    items[workOrder.bom.parentBom?.itemId].itemUnitId
                  ].code,
                }
              : {},
          },
        },
        workCenters: workOrder.workCenters?.map((wc) => ({
          ...wc,
          leader: users[wc['leaderId']] || {},
        })),
        approver: !isEmpty(users[workOrder.approverId])
          ? users[workOrder.approverId]
          : {},
        manufacturingRequestOrder: !isEmpty(
          manufacturingRequestOrderMap[
            workOrder.mo.manufacturingRequestOrderId
          ],
        )
          ? manufacturingRequestOrderMap[
              workOrder.mo.manufacturingRequestOrderId
            ]
          : {},
        canStart: canStart,
      };
    });
    const response = plainToInstance(WorkOrderResponseAbstractDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { userId, id } = request;
    const workOrder = await this.workOrderRepository.findOneById(id);

    if (!workOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }
    const plan = await this.moPlanRepository.findOneById(workOrder.moPlanId);
    if (!plan || (plan && !PLAN_STATUS_ALLOW_CONFIRM.includes(plan.status))) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.MO_PLAN_NEED_CONFIRMED'))
        .build();
    }

    const workCenterSchedule =
      await this.workOrderScheduleRepository.getDetailByWorkOrderId(id);
    if (
      !workCenterSchedule ||
      isEmpty(workCenterSchedule.workOrderScheduleDetails)
    ) {
      const generatePayload = new GetWorkOrderScheduleRequestDto();
      generatePayload.id = id;
      const workOrderSchedules = await this.getWorkOrderSchedule(
        generatePayload,
      );
      if (workOrderSchedules.statusCode !== ResponseCodeEnum.SUCCESS) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          workOrderSchedules.message,
        ).toResponse();
      }
    }
    workOrder.approverId = userId;
    workOrder.approvedAt = new Date(Date.now());
    workOrder.status = WorkOrderStatusEnum.CONFIRMED;
    const result = await this.workOrderRepository.create(workOrder);
    const response = plainToInstance(WorkOrderResponseAbstractDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async reject(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { userId, id } = request;
    const workOrder = await this.workOrderRepository.findOneById(id);

    if (!workOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }
    workOrder.approverId = userId;
    workOrder.approvedAt = new Date(Date.now());
    workOrder.status = WorkOrderStatusEnum.REJECTED;
    const result = await this.workOrderRepository.create(workOrder);
    const response = plainToInstance(WorkOrderResponseAbstractDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  private async validateWorkOrder(
    request: CreateWorkOrderRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { moId, moPlanId, moDetailId, bomId, routingId, producingStepId } =
      request;

    const routing = await this.routingRepository.getDetail(routingId);

    if (!routing) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.ROUTING_NOT_FOUND'),
      ).toResponse();
    }

    const producingStep = routing?.producingSteps?.filter(
      (producingStep) => producingStep.id === producingStepId,
    );

    if (producingStep?.length === 0) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.PRODUCING_STEP_NOT_FOUND'),
      ).toResponse();
    }

    const mo = await this.moRepository.getDetail(moId);

    if (!mo) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.MO_NOT_FOUND'),
      ).toResponse();
    }

    const moDetail = mo?.moDetails?.filter(
      (moDetail) => moDetail.id === moDetailId,
    );

    if (moDetail?.length === 0) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.MO_DETAIL_NOT_FOUND'),
      ).toResponse();
    }

    const moPlan = await this.moPlanRepository.findOneByCondition({
      id: moPlanId,
      moId: moId,
    });

    if (!moPlan) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.MO_PLAN_NOT_FOUND'),
      ).toResponse();
    }

    const bom = await this.bomRepository.findOneByCondition({
      id: bomId,
      routingId: routingId,
    });

    if (!bom) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.BOM_NOT_FOUND'),
      ).toResponse();
    }

    const moPlanBom = await this.moPlanBomRepository.findOneByCondition({
      moDetailId: moDetailId,
      moPlanId: moPlanId,
      bomId: bomId,
    });

    if (!moPlanBom) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.MO_PLAN_BOM_NOT_FOUND'),
      ).toResponse();
    }

    const response = {
      mo: mo,
      moPlan: moPlan,
      moDetail: moDetail ? moDetail[0] : {},
      moPlanBom: moPlanBom,
      bom: bom,
      routing: routing,
      producingStep: producingStep ? producingStep[0] : {},
    };
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async scan(
    payload: ScanWorkOrderRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { qrCode, user } = payload;
    if (!qrCode.includes(WORK_ORDER_CODE_PREFIX) && isNaN(+qrCode)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.QR_CODE_INVALID'),
      ).toResponse();
    }

    const id = extractWorkOrderIdFromQrCode(qrCode);
    const workOrder = await this.workOrderRepository.scan(parseInt(id));

    if (!workOrder || !CAN_SCAN_WORK_ORDER_STATUS.includes(workOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }

    const qualityAlert =
      await this.qualityControlAlertRepository.findOneWithRelations({
        where: {
          manufacturingOrderId: workOrder.mo.id,
          manufacturingOrderPlanId: workOrder.moPlanId,
          producingStepId: workOrder.producingStep.id,
        },
        orderBy: {
          type: 'ASC',
        },
        limit: 1,
      });

    workOrder.qualityControlAlert = isEmpty(qualityAlert)
      ? ''
      : qualityAlert.message;
    workOrder.errorReport = {
      errorReports: [],
      actionCategories: [],
    };
    if (
      workOrder.status === WorkOrderStatusEnum.IN_PROGRESS &&
      workOrder.producingStep.qcCheck
    ) {
      try {
        workOrder.errorReport =
          await this.qmsxService.getErrorReportByWorkOrderId(workOrder.id);
      } catch (e) {
        console.log('QMSX_ERRROR', e);
      }
    }
    const itemIds = uniq(
      [workOrder.bom.itemId, workOrder.bom?.parentBom?.itemId].concat(
        map(workOrder.inputs, 'itemId'),
        map(workOrder.previousBoms, 'itemId'),
      ),
    );
    const items = await this.itemService.getItemsByIds(itemIds, true);

    workOrder.bom = {
      ...workOrder.bom,
      parentBom: workOrder?.bom?.parentBom?.itemId
        ? {
            ...workOrder?.bom?.parentBom,
            item: items[workOrder.bom?.parentBom?.itemId],
          }
        : null,
      item: items[workOrder.bom.itemId],
    };

    workOrder.inputs = workOrder?.inputs?.map((i) => ({
      ...i,
      item: items[i?.itemId],
    }));
    workOrder.materials = workOrder.inputs
      ?.filter((input) => isEmpty(input.bom))
      .map((material) => ({
        ...material,
        qcCheck: workOrder.producingStep.inputQcCheck,
        criteriaId: workOrder.producingStep.inputQcCriteriaId,
      }));

    workOrder.previousBoms = workOrder.previousBoms?.map((i) => ({
      ...i,
      planQuantity: workOrder.quantity,
      item: items[i?.itemId],
    }));

    const workCentersOfUser =
      await this.workCenterUserRepository.findWithRelations({
        select: ['workCenterId'],
        where: {
          memberId: user?.id,
        },
      });

    const workCenterIds = map(workCentersOfUser, 'workCenterId');

    workOrder.workCenters = workOrder.workCenters
      .filter((workCenter) => workCenterIds.includes(workCenter.id))
      .map((workCenter) => {
        let workCenterMaterials = filter(
          workOrder.materials,
          (m) => m.workCenterId === workCenter.id,
        );
        const workCenterPreviousBoms = filter(
          workOrder.previousBoms,
          (m) => m.workCenterId === workCenter.id,
        );
        if (isEmpty(workCenterMaterials)) {
          workCenterMaterials = workOrder.materials.map((material) => ({
            ...material,
            planQuantity: mul(
              workCenter.totalPlanQuantity,
              material.bomProducingStepRate || 1,
            ),
          }));
        } else {
          workCenterMaterials = workCenterMaterials.map((material) => ({
            ...material,
            planQuantity: mul(
              workCenter.totalPlanQuantity,
              material.bomProducingStepRate || 1,
            ),
          }));
        }
        workCenter.materials = workCenterMaterials;
        workCenter.previousBoms = workCenterPreviousBoms;
        workCenter.remainQuantity = workOrder.producingStep?.qcCheck
          ? minus(
              workCenter.totalPlanQuantity,
              workCenter.totalQcPassQuantity || 0,
            )
          : minus(workCenter.totalPlanQuantity, workCenter.actualQuantity || 0);
        return workCenter;
      });

    const getLogTimeRequest = new GetWorkOrderLogTimeRequestDto();
    getLogTimeRequest.id = workOrder.id;
    const logTime = await this.getLogTimeWorkOrder(getLogTimeRequest);

    workOrder.currentLogTime =
      isEmpty(logTime.data) || !logTime.data?.id ? null : logTime.data;
    const response = plainToInstance(WorkOrderScanResponseDto, workOrder, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async exportScan(
    payload: ScanWorkOrderRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { qrCode } = payload;
    if (!qrCode.includes(WORK_ORDER_CODE_PREFIX) && isNaN(+qrCode)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.QR_CODE_INVALID'),
      ).toResponse();
    }
    const id = extractWorkOrderIdFromQrCode(qrCode);
    const workOrder = await this.workOrderRepository.exportScan(parseInt(id));

    if (!workOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }

    if (!CAN_EXPORT_WORK_ORDER_STATUS.includes(workOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }
    workOrder.producingSteps =
      await this.producingStepRepository.getProducingStepsByRoutingId(
        workOrder.routingId,
      );
    const currentStep = workOrder.producingSteps.find(
      (producingStep) => producingStep.id == workOrder?.exportProducingStep?.id,
    );

    workOrder.importProducingSteps = workOrder.producingSteps.filter(
      (producingStep) =>
        producingStep.stepNumber === currentStep.stepNumber + 1,
    );

    if (isEmpty(workOrder.importProducingSteps)) {
      // is lastes step at current routing
      if (!isEmpty(workOrder.bom?.parentBom)) {
        workOrder.importProducingSteps =
          await this.producingStepRepository.getFirstStepOfBom(
            workOrder.bom?.parentBom?.id,
            workOrder.planId,
          );
      }
      // is lastest product
    }

    workOrder.workCenters = workOrder.workCenters.map((wc) => ({
      ...wc,
      lots: [
        {
          lotNumber: workOrder.lotNumber,
          quantity: wc.quantity,
          totalQcPassQuantity: wc.qcPassQuantity,
          totalQcRejectQuantity: wc.qcRejectQuantity,
          date: workOrder.createdAt,
        },
      ],
    }));
    const itemIds = uniq(
      [workOrder.bom.itemId, workOrder.bom?.parentBom?.itemId].concat(
        map(workOrder.inputs, 'itemId'),
      ),
    );
    const items = await this.itemService.getItemsByIds(itemIds, true);
    workOrder.bom = {
      ...workOrder.bom,
      parentBom: workOrder?.bom?.parentBom?.itemId
        ? {
            ...workOrder?.bom?.parentBom,
            item: items[workOrder.bom?.parentBom?.itemId],
          }
        : null,
      item: items[workOrder.bom.itemId],
    };
    const response = plainToInstance(WorkOrderScanResponseDto, workOrder, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async exportDetail(
    payload: DetailWorkOrderExportRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { id } = payload;
    const workOrder = await this.workOrderRepository.exportScan(id);

    if (!workOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }
    workOrder.producingSteps =
      await this.producingStepRepository.getProducingStepsByRoutingId(
        workOrder.routingId,
      );
    workOrder.importProducingSteps = workOrder.producingSteps.filter(
      (producingStep) =>
        producingStep.id !== workOrder?.exportProducingStep?.id,
    );
    const itemIds = uniq(
      [workOrder.bom.itemId, workOrder.bom?.parentBom?.itemId].concat(
        map(workOrder.inputs, 'itemId'),
      ),
    );
    const items = await this.itemService.getItemsByIds(itemIds, true);
    workOrder.bom = {
      ...workOrder.bom,
      parentBom: {
        ...workOrder?.bom?.parentBom,
        item: items[workOrder.bom?.parentBom?.itemId],
      },
      item: items[workOrder.bom.itemId],
    };
    const response = plainToInstance(WorkOrderScanResponseDto, workOrder, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   * Submit nguyên vật liệu đầu vào
   */
  public async materialInputSubmit(
    payload: SubmitWorkOrderInputRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, materialItems, createdByUserId, workCenterId } = payload;
    const workOrder = await this.workOrderRepository.findOneWithRelations({
      where: {
        id: id,
      },
      relations: ['producingStep', 'workOrderSchedule'],
    });
    if (!workOrder || isEmpty(workOrder.workOrderSchedule)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }

    if (!CAN_SUBMIT_WORK_ORDER_INPUT.includes(workOrder.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_IS_INVALID'),
      ).toResponse();
    }

    const workOrderScheduleDetail =
      await this.workOrderScheduleDetailRepository.findOneByCondition({
        workCenterId,
        workOrderScheduleId: first(workOrder.workOrderSchedule).id,
      });

    if (isEmpty(workOrderScheduleDetail)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_CENTER_NOT_FOUND'))
        .build();
    }

    const { items, errorInputItems } = await this.validateMaterialInput(
      id,
      materialItems,
    );
    if (errorInputItems.length > 0) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'),
      ).toResponse();
    }

    let workOrderMaterialInputs: any[];
    if (workOrder.producingStep.inputQcCheck === 1) {
      // cần qc kiểm tra đầu vào
      workOrderMaterialInputs =
        await this.workOrderMaterialInputRepository.findByCondition({
          workOrderId: id,
          itemId: In(map(items, 'itemId')),
        });
      for (let i = 0; i < materialItems.length; i++) {
        const item = materialItems[i];
        const existedItemIndex = findIndex(
          workOrderMaterialInputs,
          (workOrderMaterialInput) =>
            workOrderMaterialInput.itemId === item.itemId,
        );

        if (existedItemIndex === -1) {
          return new ApiError(
            ResponseCodeEnum.BAD_REQUEST,
            await this.i18n.t('error.MATERIAL_INPUT_QUANTITY_INVALID'),
          ).toResponse();
        }
        if (
          minus(
            parseFloat(
              workOrderMaterialInputs[existedItemIndex].qcPassQuantity,
            ),
            plus(
              item.quantity,
              parseFloat(
                workOrderMaterialInputs[existedItemIndex].producedQuantity,
              ),
            ),
          ) < 0
        ) {
          return new ApiError(
            ResponseCodeEnum.BAD_REQUEST,
            await this.i18n.t('error.MATERIAL_INPUT_QUANTITY_INVALID'),
          ).toResponse();
        }

        workOrderMaterialInputs[existedItemIndex].producedQuantity = plus(
          parseFloat(
            workOrderMaterialInputs[existedItemIndex].producedQuantity,
          ),
          item.quantity,
        );
      }
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const inputHistoryEntity = new WorkOrderInputHistoryEntity();
      inputHistoryEntity.workOrderId = id;
      inputHistoryEntity.createdByUserId = createdByUserId;
      const inputHistory = await queryRunner.manager.save(
        WorkOrderInputHistoryEntity,
        inputHistoryEntity,
      );

      const workOrderInputDetailEntities = [];
      const workOrderTransits = materialItems.map((inputItem) => {
        const existedItem = find(items, (i) => i.itemId === inputItem.itemId);
        const newEntity = new WorkOrderBomTransitEntity();
        newEntity.workOrderId = id;
        newEntity.bomDetailBomId = existedItem.bomId;
        newEntity.bomDetailItemId = existedItem.itemId;
        newEntity.workCenterId = workCenterId;
        newEntity.inputQuantity = plus(
          parseFloat(existedItem.inputQuantity || 0),
          inputItem.quantity,
        );

        const history = this.workOrderInputDetailRepository.createEntity({
          workOrderId: id,
          inputHistoryId: inputHistory.id,
          workOrderBomTransitsBomDetailBomId: existedItem.bomId,
          workOrderBomTransitsBomDetailItemId: existedItem.itemId,
          createdByUserId: createdByUserId,
          quantity: plus(
            parseFloat(existedItem.quantity || 0),
            inputItem.quantity,
          ),
        });
        workOrderInputDetailEntities.push(history);
        return newEntity;
      });
      if (workOrder.producingStep.inputQcCheck === 1) {
        await queryRunner.manager.save(
          WorkOrderMaterialInputEntity,
          workOrderMaterialInputs,
        );
      }

      const result = await queryRunner.manager.save(
        WorkOrderBomTransitEntity,
        workOrderTransits,
      );
      await queryRunner.manager.save(
        WorkOrderInputDetailEntity,
        workOrderInputDetailEntities,
      );
      const response = plainToInstance(
        SubmitWorkOrderInputResponseDto,
        result,
        {
          excludeExtraneousValues: true,
        },
      );

      await queryRunner.commitTransaction();
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      console.log({ error });

      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }
  }

  /**
   * Nhập nguyên vật liệu
   */
  public async materialInputImport(
    payload: ImportWorkOrderMaterialInputRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, materialItems } = payload;
    const workOrder = await this.workOrderRepository.findOneById(id);

    if (!workOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }

    if (!CAN_SUBMIT_WORK_ORDER_INPUT.includes(workOrder.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_IS_INVALID'),
      ).toResponse();
    }

    const { items, errorInputItems } = await this.validateMaterialInput(
      id,
      materialItems,
    );

    if (errorInputItems.length > 0) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        errorInputItems.join('/n'),
      ).toResponse();
    }

    const workOrderMaterialInputs =
      await this.workOrderMaterialInputRepository.findByCondition({
        workOrderId: id,
        itemId: In(map(items, 'itemId')),
      });
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const workOrderMaterialInputEntities = materialItems.map((inputItem) => {
        let entity = find(
          workOrderMaterialInputs,
          (i) => i.itemId === inputItem.itemId,
        );
        if (isEmpty(entity)) {
          entity = new WorkOrderMaterialInputEntity();
          entity.workOrderId = id;
          entity.quantity = 0;
          entity.itemId = inputItem.itemId;
        }
        entity.quantity = plus(entity.quantity, inputItem.quantity);
        return entity;
      });

      await queryRunner.manager.save(
        WorkOrderMaterialInputEntity,
        workOrderMaterialInputEntities,
      );

      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }
  }

  /**
   * Sumbit phế liệu
   */
  public async scrapSubmit(
    payload: SubmitWorkOrderScrapRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, quantity, createdByUserId, scrapMaterials, workCenterId } =
      payload;
    const workOrder = await this.workOrderRepository.findOneWithRelations({
      where: {
        id: id,
      },
      relations: ['producingStep'],
    });

    if (!workOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }

    if (!CAN_SUBMIT_WORK_ORDER_SCRAP.includes(workOrder.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_IS_INVALID'),
      ).toResponse();
    }

    const workOrderMaterials = await this.workOrderRepository.getMaterialInputs(
      id,
      workCenterId,
    );

    if (!isEmpty(scrapMaterials)) {
      const bomWithMaterial = await this.bomRepository.getMaterialItems(
        workOrder.bomId,
      );

      if (
        !bomWithMaterial ||
        (bomWithMaterial && isEmpty(bomWithMaterial.materials))
      ) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.BOM_IS_WITHOUT_MATERIAL'),
          )
          .build();
      }
      const invalidMaterials = [];
      if (!isEmpty(bomWithMaterial.materials)) {
        for (let index = 0; index < scrapMaterials.length; index++) {
          const scrapMaterial: any = scrapMaterials[index];
          if (
            isEmpty(
              find(
                bomWithMaterial.materials,
                (m) => m.itemId === scrapMaterial.itemId,
              ),
            )
          ) {
            invalidMaterials.push(
              await this.i18n.t('error.MATERIAL_ITEM_IS_INVALID', {
                args: { itemId: scrapMaterial.itemId },
              }),
            );
          }
          const inputMaterial = find(
            workOrderMaterials,
            (input) => input.itemId === scrapMaterial.itemId,
          );

          if (isEmpty(inputMaterial)) {
            invalidMaterials.push(
              await this.i18n.t('error.MATERIAL_ITEM_IS_INVALID', {
                args: { itemId: scrapMaterial.itemId },
              }),
            );
          } else if (
            minus(
              workOrder.producingStep.inputQcCheck
                ? inputMaterial.totalQcPassQuantity || 0
                : inputMaterial.inputQuantity || 0,
              inputMaterial.producedQuantity || 0,
            ) < scrapMaterial.quantity
          ) {
            return new ApiError(
              ResponseCodeEnum.BAD_REQUEST,
              await this.i18n.translate(
                'error.SCRAP _QUANTITY_MUST_LESS_THAN_MATERIAL_INPUT_QUANTITY_REMANING',
              ),
            ).toResponse();
          }
        }
        if (!isEmpty(invalidMaterials)) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(invalidMaterials.join('//n'))
            .build();
        }
      }
    } else if (isEmpty(scrapMaterials) && !quantity) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.INVALID_QUANTITY'),
      ).toResponse();
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(WorkOrderEntity, workOrder);
      if (quantity) {
        workOrder.scrapQuantity = plus(workOrder.scrapQuantity, quantity);

        await queryRunner.manager.save(
          WorkOrderScrapTransactionEntity,
          this.workOrderScrapTransactionRepository.createEntity({
            workOrderId: id,
            createdByUserId: createdByUserId,
            quantity: quantity,
          }),
        );
        await queryRunner.manager.save(WorkOrderEntity, workOrder);
      }

      if (!isEmpty(scrapMaterials)) {
        const scrapMaterialEntities = scrapMaterials.map((scrapMaterial) =>
          this.workOrderScrapTransactionRepository.createEntity({
            workOrderId: id,
            createdByUserId: createdByUserId,
            quantity: scrapMaterial.quantity,
            itemId: scrapMaterial.itemId,
          }),
        );
        await queryRunner.manager.save(
          WorkOrderScrapTransactionEntity,
          scrapMaterialEntities,
        );
      }
      const response = plainToInstance(WorkOrderScanResponseDto, workOrder, {
        excludeExtraneousValues: true,
      });
      await queryRunner.commitTransaction();
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (e) {
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }
  }

  /**
   * Cập nhật tiến độ
   * @param payload
   * @returns
   */
  public async progressSubmit(
    payload: SubmitWorkOrderProgressRequestDto,
    innoreValidateInput?,
  ): Promise<ResponsePayload<any>> {
    const {
      id,
      quantity,
      repairQuantity,
      createdByUserId,
      workCenterId,
      passQuantity,
      rejectQuantity,
    } = payload;

    const executionDay = payload.executionDay || new Date();

    let shouldDispatchUpdateMoStatusEvent = false;

    const workOrder = await this.workOrderRepository.findOneWithRelations({
      where: {
        id,
      },
      relations: ['workOrderSchedule', 'producingStep', 'bom'],
    });

    const lotNumber = workOrder.lotNumber || 'lotNumberDefault';

    if (!workOrder || !first(workOrder.workOrderSchedule)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }

    if (!CAN_SUBMIT_WORK_ORDER_SCRAP.includes(workOrder.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_IS_INVALID'),
      ).toResponse();
    }

    const workOrderSchedule = first(workOrder.workOrderSchedule);

    const workCenterUser = await this.workCenterUserRepository.findByCondition({
      memberId: createdByUserId,
    });

    // if (
    //   !workCenterUser ||
    //   isEmpty(find(workCenterUser, (wc) => wc.workCenterId === workCenterId))
    // ) {
    //   return new ResponseBuilder()
    //     .withCode(ResponseCodeEnum.BAD_REQUEST)
    //     .withMessage(await this.i18n.translate('error.WORK_CENTER_NOT_FOUND'))
    //     .build();
    // }

    const workOrderScheduleDetail =
      await this.workOrderScheduleDetailRepository.findOneByCondition({
        workCenterId,
        workOrderScheduleId: workOrderSchedule.id,
      });
    if (!workOrderScheduleDetail) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.STATUS_WORK_ORDER_SCHEDULE_NOT_ACCEPTED',
          ),
        )
        .build();
    }

    // if (!repairQuantity && !quantity) {
    //   return new ApiError(
    //     ResponseCodeEnum.FORBIDDEN,
    //     await this.i18n.translate('error.INVALID_QUANTITY'),
    //   ).toResponse();
    // }

    // if (!innoreValidateInput) {
    //   if (
    //     (quantity &&
    //       quantity >
    //         minus(
    //           workOrder.quantity,
    //           minus(workOrder.actualQuantity, workOrder.repairedQuantity) || 0,
    //         )) ||
    //     0
    //   ) {
    //     return new ApiError(
    //       ResponseCodeEnum.FORBIDDEN,
    //       await this.i18n.translate('error.INPUT_QUANTITY_INVALID'),
    //     ).toResponse();
    //   }
    // }

    if (repairQuantity && repairQuantity > workOrder.qcRejectQuantity) {
      return new ApiError(
        ResponseCodeEnum.FORBIDDEN,
        await this.i18n.translate('error.REPAIR_QUANTITY_IN_VALID'),
      ).toResponse();
    }

    // Validate Input
    const inputValidator: any =
      await this.validateWorkOrderInputForSubmitProgress(
        workOrder.id,
        workOrder.bomId,
        workOrder.moId,
        workOrder.moPlanId,
        workOrder.routingId,
        workOrder.producingStepId,
        quantity,
        !!workOrder.producingStep.inputQcCheck,
        workCenterId,
      );
    // if (validateInput && inputValidator?.status !== true) {
    //   return new ApiError(
    //     ResponseCodeEnum.FORBIDDEN,
    //     inputValidator?.msg,
    //   ).toResponse();
    // }

    const mo = await this.moRepository.getDetail(workOrder.moId);

    if (
      ![
        ManufacturingOrderStatusEnum.CONFIRMED,
        ManufacturingOrderStatusEnum.IN_PROGRESS,
      ].includes(mo.status)
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.STATUS_IS_INVALID'))
        .build();
    }

    const workCenterShifts =
      await this.workCenterShiftRepository.findByCondition({
        workCenterId,
      });

    if (isEmpty(workCenterShifts)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WORK_CENTER_SHIFT_N_NOT_FOUND'),
        )
        .build();
    }
    let shift = workCenterShifts.find((workCenterShift) => {
      const { start, end } = getShiftTime(
        workCenterShift.startAt,
        workCenterShift.endAt,
      );
      const range = moment.range(start, end);
      return range.contains(moment(executionDay));
    });
    if (isEmpty(shift)) {
      shift = first(workCenterShifts);
    }

    const defaultTimeZone = this.configService.get('defaultTimeZone');
    const executionDate = getFullDateString(executionDay);
    let workCenterDailySchedule =
      await this.workCenterDailyScheduleRepository.findOneWithRelations({
        where: {
          workOrderScheduleDetailId: workOrderScheduleDetail.id,
          workCenterId: workCenterId,
          executionDay: Raw(
            () =>
              `to_char(execution_day AT TIME ZONE '${defaultTimeZone}', 'yyyy-mm-dd' ) = '${executionDate}'`,
          ),
        },
      });

    let workCenterDailyScheduleShift = !isEmpty(workCenterDailySchedule)
      ? await this.workCenterDailyScheduleShiftRepository.findOneByCondition({
          workCenterDailyScheduleId: workCenterDailySchedule.id,
          workCenterShiftId: shift.id,
          executionDay: Raw(
            () =>
              `to_char(execution_day AT TIME ZONE '${defaultTimeZone}', 'yyyy-mm-dd' ) = '${executionDate}'`,
          ),
        })
      : null;

    if (isEmpty(workCenterDailySchedule)) {
      workCenterDailySchedule =
        this.workCenterDailyScheduleRepository.createEntity({
          workOrderScheduleDetailId: workOrderScheduleDetail.id,
          executionDay: executionDate,
          workCenterId: workCenterId,
          quantity: 0,
          moderationQuantity: 0,
          actualQuantity: 0,
        });
      workCenterDailySchedule.isOutOfPlan = true;
    }

    if (isEmpty(workCenterDailyScheduleShift)) {
      workCenterDailyScheduleShift =
        this.workCenterDailyScheduleShiftRepository.createEntity({
          workCenterDailyScheduleId: 0,
          workCenterShiftId: shift.id,
          quantity: 0,
          executionDay: executionDate,
          actualQuantity: 0,
          repairQuantity,
        });
      workCenterDailyScheduleShift.isOutOfPlan = true;
    }

    let workOrderLot = await this.workOrderLotRepository.findOneWithRelations({
      where: {
        workOrderId: id,
        lotNumber: lotNumber.toUpperCase(),
      },
    });
    let workOrderWorkCenterLot;

    // Start Update
    if (isEmpty(workOrderLot)) {
      workOrderLot = new WorkOrderLotEntity();
      workOrderLot.workOrderId = id;
      workOrderLot.lotNumber = lotNumber.toUpperCase();
      workOrderLot.totalQuantity = 0;
      workOrderLot.qcPassQuantity = 0;
      workOrderLot.qcRejectQuantity = 0;

      workOrderWorkCenterLot = new WorkOrderWorkCenterLotEntity();
      workOrderWorkCenterLot.workOrderId = id;
      workOrderWorkCenterLot.workCenterId = workCenterId;
      workOrderWorkCenterLot.totalQuantity = 0;
      workOrderWorkCenterLot.qcPassQuantity = 0;
      workOrderWorkCenterLot.qcRejectQuantity = 0;
    } else {
      workOrderWorkCenterLot =
        await this.workOrderWorkCenterLotRepository.findOneWithRelations({
          where: {
            workOrderId: id,
            workOrderLotId: workOrderLot.id,
            workCenterId: workCenterId,
          },
        });
      if (isEmpty(workOrderWorkCenterLot)) {
        workOrderWorkCenterLot = new WorkOrderWorkCenterLotEntity();
        workOrderWorkCenterLot.workOrderId = id;
        workOrderWorkCenterLot.workCenterId = workCenterId;
        workOrderWorkCenterLot.totalQuantity = 0;
        workOrderWorkCenterLot.qcPassQuantity = 0;
        workOrderWorkCenterLot.qcRejectQuantity = 0;
      }
    }

    workOrderLot.totalQuantity = plus(workOrderLot.totalQuantity, quantity);
    workOrderWorkCenterLot.totalQuantity = plus(
      workOrderWorkCenterLot.totalQuantity,
      quantity,
    );

    workOrderLot.setProgressQuantity(
      quantity,
      repairQuantity,
      workOrder.producingStep.qcCheck,
    );

    workOrderWorkCenterLot.setProgressQuantity(
      quantity,
      repairQuantity,
      workOrder.producingStep.qcCheck,
    );

    //update material plan schedule
    const materialPlanSchedules =
      await this.materialPlanScheduleRepository.findByCondition({
        workCenterDailyScheduleId: workCenterDailySchedule.id,
      });

    const materialPlanScheduleUpdate = !isEmpty(materialPlanSchedules)
      ? materialPlanSchedules.map((record) => ({
          id: record.id,
          actualQuantity: plus(
            Number(record.actualQuantity),
            mul(
              Number(record.bomProducingStepQuantity),
              Number(workCenterDailySchedule.actualQuantity),
            ),
          ),
        }))
      : [];
    let response;
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();

    try {
      const workOrderTransactionEntity =
        this.workOrderRepository.createTransactionEntity({
          createdByUserId: createdByUserId,
          workOrderId: id,
          quantity: quantity,
          approverId: createdByUserId,
          repairQuantity: repairQuantity,
          remainQuantity: minus(
            workOrder.quantity,
            minus(workOrder.actualQuantity, workOrder.repairedQuantity || 0),
          ),
          producedQuantity: minus(
            workOrder.actualQuantity,
            workOrder.repairedQuantity || 0,
          ),
        });
      await queryRunner.manager.save(
        WorkOrderTransactionEntity,
        workOrderTransactionEntity,
      );

      workOrder.setProgressQuantity(quantity, repairQuantity);

      if (workOrder.status == WorkOrderStatusEnum.COMPLETED) {
        const workCenter = await this.workCenterRepository.findOneByCondition({
          id: workCenterId,
        });
        if (!isEmpty(workCenter)) {
          workCenter.currentRunningWorkOrderId = null;
          await queryRunner.manager.save(WorkCenterEntity, workCenter);
        }
      }
      workOrderScheduleDetail.setProgressQuantity(
        quantity,
        repairQuantity,
        workOrder.producingStep?.qcCheck,
      );
      workCenterDailyScheduleShift.setProgressQuantity(
        quantity,
        repairQuantity,
        workOrder.producingStep?.qcCheck,
      );
      workCenterDailySchedule.setProgressQuantity(
        quantity,
        repairQuantity,
        workOrder.producingStep?.qcCheck,
      );

      if (!isEmpty(inputValidator.data)) {
        if (!isEmpty(inputValidator.data?.previousBoms)) {
          const workOrderBomTransitEntities =
            inputValidator.data?.previousBoms.map((p) => {
              const wobt = new WorkOrderBomTransitEntity();
              wobt.workOrderId = workOrder.id;
              wobt.bomDetailBomId = p.id;
              wobt.bomDetailItemId = p.itemId;
              wobt.workCenterId = workCenterId;
              wobt.producedQuantity = p.producedQuantity;
              return wobt;
            });

          await queryRunner.manager.save(
            WorkOrderBomTransitEntity,
            workOrderBomTransitEntities,
          );
        }

        if (!isEmpty(inputValidator.data.materialInputs)) {
          await queryRunner.manager.save(
            WorkOrderBomTransitEntity,
            inputValidator.data.materialInputs,
          );
        }
      }
      // check is latest step of routing
      if (!workOrder.producingStep.qcCheck) {
        const [moPlanBom, isLastStepOfRouting] = await Promise.all([
          await this.moPlanBomRepository.findOneById(workOrder.moPlanBomId),
          await this.routingRepository.isLatestStepInRouting(
            workOrder.routingId,
            workOrder.producingStepId,
          ),
        ]);
        if (isLastStepOfRouting && moPlanBom) {
          shouldDispatchUpdateMoStatusEvent =
            await this.updateMoPlanBomProgress(
              moPlanBom,
              quantity,
              queryRunner,
            );
        }
      }

      if (
        ![
          ManufacturingOrderStatusEnum.COMPLETED,
          ManufacturingOrderStatusEnum.IN_PROGRESS,
        ].includes(mo.status)
      ) {
        const toUpdateMo = mo;
        delete toUpdateMo.manufacturingOrderDetails;
        delete toUpdateMo.plan;
        delete toUpdateMo.materialRequestWarning;
        mo.status = ManufacturingOrderStatusEnum.IN_PROGRESS;
        await queryRunner.manager.save(ManufacturingOrderEntity, toUpdateMo);
      }

      await queryRunner.manager.save(
        WorkOrderScheduleDetailEntity,
        workOrderScheduleDetail,
      );

      await queryRunner.manager.save(
        WorkOrderScheduleEntity,
        workOrderSchedule,
      );

      const workCenterDailyScheduleEntity = await queryRunner.manager.save(
        WorkCenterDailyScheduleEntity,
        workCenterDailySchedule,
      );

      if (!workCenterDailyScheduleShift.id) {
        workCenterDailyScheduleShift.workCenterDailyScheduleId =
          workCenterDailyScheduleEntity.id;
      }
      await queryRunner.manager.save(
        WorkCenterDailyScheduleShiftEntity,
        workCenterDailyScheduleShift,
      );

      if (!isEmpty(materialPlanScheduleUpdate)) {
        await queryRunner.manager.save(
          MaterialPlanScheduleEntity,
          materialPlanScheduleUpdate,
        );
      }

      const workOrderLotEntity = await queryRunner.manager.save(
        WorkOrderLotEntity,
        workOrderLot,
      );

      workOrderWorkCenterLot.workOrderLotId = workOrderLotEntity.id;
      await queryRunner.manager.save(
        WorkOrderWorkCenterLotEntity,
        workOrderWorkCenterLot,
      );

      if (
        minus(+workOrder.qcPassQuantity || 0, +workOrder.quantity || 0) >= 0
      ) {
        workOrder.status = WorkOrderStatusEnum.COMPLETED;
      }
      const result = await queryRunner.manager.save(WorkOrderEntity, workOrder);

      response = plainToInstance(WorkOrderResponseAbstractDto, result, {
        excludeExtraneousValues: true,
      });
      await queryRunner.commitTransaction();
      this.logger.debug('PROGRESS SUBMIT DONE');
    } catch (error) {
      console.log({ error });

      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
      this.fireWorkOrderPrgressSubmitedEvent(
        mo,
        workOrder,
        workCenterDailySchedule,
        workCenterDailyScheduleShift,
        quantity,
        shouldDispatchUpdateMoStatusEvent,
      );
    }

    if (passQuantity || rejectQuantity) {
      await this.updateQualityControlWorkOrder(
        {
          id: id,
          passQuantity: passQuantity,
          rejectQuantity: rejectQuantity,
          workCenterId: workCenterId,
          userId: createdByUserId,
          executionDay: executionDay,
        } as UpdateQualityControlWorkOrderRequestDto,
        workOrder,
      );
    }

    //update manufacturing request order status to inprogress
    const updateMORequestStatusToInprogressRequestDto =
      new ManufacturingRequestOrderIdParamRequestDto();
    updateMORequestStatusToInprogressRequestDto.id =
      mo.manufacturingRequestOrderId;
    const updateSaleOrderStatusResponse =
      await this.requestService.updateMORequestStatusToInprogress(
        updateMORequestStatusToInprogressRequestDto,
      );
    if (updateSaleOrderStatusResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(updateSaleOrderStatusResponse?.message)
        .build();
    }

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param workOrderId
   * @param bomId
   * @param moId
   * @param planId
   * @param routingId
   * @param producingStepId
   * @param quantity
   * @param isInputQcCheck
   * @param workCenterId
   * @returns
   */
  private async validateWorkOrderInputForSubmitProgress(
    workOrderId,
    bomId,
    moId,
    planId,
    routingId,
    producingStepId,
    quantity,
    isInputQcCheck?,
    workCenterId?,
  ) {
    const result = {
      status: true,
      data: {},
      msg: '',
    };
    const isLastSemiFinishedProduct =
      await this.moPlanBomRepository.checkIsLastSemiFinishedProduct(
        bomId,
        moId,
        planId,
      ); // Product is build by material
    const isFirstStep =
      await this.producingStepRepository.checkIsFirstStepInRouting(
        routingId,
        producingStepId,
      );
    const bomInput = await this.workOrderRepository.getBomInputById(
      workOrderId,
      workCenterId,
    );

    // Validate previous bom
    if (isLastSemiFinishedProduct) {
      if (isFirstStep) {
        result.status = true;
      } else {
        if (isEmpty(bomInput)) {
          result.status = false;
          result.msg = await this.i18n.t(
            'error.WORK_ORDER_INPUT_MUST_BE_FILLED',
          );
        } else {
          const previousBom: any = first(bomInput?.previousBoms);
          if (
            quantity <=
            minus(
              (isInputQcCheck
                ? previousBom?.qcPassQuantity
                : previousBom?.inputQuantity) || 0,
              previousBom?.producedQuantity || 0,
            )
          ) {
            result.status = true;
            result.data = {
              ...bomInput,
              previousBoms: bomInput.previousBoms.map((p) => ({
                ...p,
                producedQuantity: plus(p.producedQuantity || 0, quantity || 0),
              })),
            };
          } else {
            result.status = false;
            result.msg = await this.i18n.t(
              'error.PRODUCITION_QUANTITY_MUST_LESS_THAN_PLAN_QUANTITY_REMANING',
            );
          }
        }
      }
    }

    if (!isEmpty(bomInput)) {
      if (isFirstStep) {
        if (bomInput.previousBoms.length !== bomInput.bomDetails.length) {
          result.status = false;
          result.msg = await this.i18n.t(
            'error.WORK_ORDER_INPUT_MUST_BE_FILLED',
          );
        } else if (!isEmpty(bomInput.bomDetails)) {
          const inputQuantities = bomInput.previousBoms.map((i) => {
            const bomDetail = find(
              bomInput.bomDetails,
              (d) => d.itemId === i.itemId,
            );
            return div(
              minus(
                (isInputQcCheck ? i?.qcPassQuantity : i?.inputQuantity) || 0,
                i.producedQuantity || 0,
              ),
              bomDetail?.bom?.quantity || 1,
            );
          });
          const minQuantity = parseFloat(min(inputQuantities)) || 0;

          if (quantity <= minQuantity) {
            result.status = true;
            result.data = {
              ...bomInput,
              previousBoms: bomInput.previousBoms.map((p) => {
                const bomDetail = find(
                  bomInput.bomDetails,
                  (d) => d.itemId === p.itemId,
                );
                return {
                  ...p,
                  producedQuantity: plus(
                    p.producedQuantity || 0,
                    mul(quantity || 0, bomDetail?.bom?.quantity || 1),
                  ),
                };
              }),
            };
          } else {
            result.status = false;
            result.msg = await this.i18n.t('error.INVALID_QUANTITY');
          }
        }
      } else {
        const previousBom: any = first(bomInput?.previousBoms);
        if (
          quantity <=
          minus(
            (isInputQcCheck
              ? previousBom?.qcPassQuantity
              : previousBom?.inputQuantity) || 0,
            previousBom?.producedQuantity || 0,
          )
        ) {
          result.status = true;
          result.data = {
            ...bomInput,
            previousBoms: bomInput.previousBoms.map((p) => ({
              ...p,
              producedQuantity: plus(p.producedQuantity || 0, quantity),
            })),
          };
        } else {
          result.status = false;
          result.msg = await this.i18n.t(
            'error.PRODUCITION_QUANTITY_MUST_LESS_THAN_INPUT_QUANTITY_REMANING',
          );
        }
      }
    }

    // Validate material
    const bomProducingStepStruct =
      await this.bomProducingStepDetailsRepository.findWithRelations({
        where: {
          bomId: bomId,
          producingStepId: producingStepId,
          routingId: routingId,
          status: 1,
        },
      });

    const workOrderMaterialInputs =
      await this.workOrderRepository.getMaterialInputs(
        workOrderId,
        workCenterId,
      );

    if (!isEmpty(bomProducingStepStruct)) {
      const inputs = [];
      for (let i = 0; i < bomProducingStepStruct.length; i++) {
        const bomProducingStep = bomProducingStepStruct[i];
        const materialQuantity = mul(bomProducingStep.quantity || 1, quantity);
        const materialInput = find(
          workOrderMaterialInputs,
          (workOrderMaterialInput) =>
            workOrderMaterialInput.itemId === bomProducingStep.itemId,
        );
        if (isEmpty(materialInput)) {
          result.status = false;
          result.msg = await this.i18n.t(
            'error.PRODUCITION_QUANTITY_MUST_LESS_THAN_MATERIAL_INPUT_QUANTITY_REMANING',
          );

          return result;
        } else if (
          minus(
            isInputQcCheck
              ? materialInput.totalQcPassQuantity
              : materialInput.inputQuantity || 0,
            materialInput.producedQuantity || 0,
          ) < materialQuantity
        ) {
          result.status = false;
          result.msg = await this.i18n.t(
            'error.PRODUCITION_QUANTITY_MUST_LESS_THAN_MATERIAL_INPUT_QUANTITY_REMANING',
          );
          return result;
        }

        materialInput.producedQuantity = plus(
          materialInput.producedQuantity || 0,
          materialQuantity || 0,
        );
        const materialInputEntity = new WorkOrderBomTransitEntity();
        materialInputEntity.workOrderId = workOrderId;
        materialInputEntity.inputQuantity = materialInput.inputQuantity;
        materialInputEntity.producedQuantity = materialInput.producedQuantity;
        materialInputEntity.qcPassQuantity =
          materialInput.totalQcPassQuantity || 0;
        materialInputEntity.qcRejectQuantity =
          materialInput.totalQcRejectQuantity || 0;
        materialInputEntity.bomDetailBomId = materialInput.bomId;
        materialInputEntity.bomDetailItemId = materialInput.itemId;
        materialInputEntity.workCenterId = workCenterId;
        inputs.push(materialInputEntity);
      }

      result.data = {
        ...result.data,
        materialInputs: inputs,
      };
    }
    return result;
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getTransactionList(
    payload: GetListWorkOrderTransactionRequestDto,
  ): Promise<ResponsePayload<GetListWorkOrderResponseDto | any>> {
    const { filter, page } = payload;
    const itemNameFilter = filter?.find((item) => item.column === 'itemName');

    let filterItemIds = [];

    if (!isEmpty(itemNameFilter)) {
      filterItemIds = await this.itemService.getItemsByName(
        itemNameFilter,
        true,
      );

      if (isEmpty(filterItemIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: 0 },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    const { result, count } = await this.workOrderTransactionRepository.getList(
      payload,
      filterItemIds,
    );

    const bomItemIds = uniq(map(flatMap(result, 'bom'), 'itemId'));
    const parentBomItemIds = uniq(map(flatMap(result, 'parentBom'), 'itemId'));

    const itemIds = [...new Set([...parentBomItemIds, ...bomItemIds])];

    const items = await this.itemService.getItemsByIds(itemIds, true);

    const data = result.map((transaction) => ({
      ...transaction,
      bom: {
        ...transaction.bom,
        item: items[transaction.bom?.itemId],
      },
      parentBom: {
        ...transaction.parentBom,
        item: items[transaction.parentBom?.itemId],
      },
    }));

    const response = plainToInstance(WorkOrderTransactionResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getTransactionDetail(
    payload: GetDetailWorkOrderTransactionRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { id } = payload;
    const transaction = await this.workOrderTransactionRepository.getDetail(id);

    if (!transaction) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    transaction.createdByUser = {};
    if (transaction.createdByUserId !== null) {
      const users = await this.userService.getUserByIds(
        [transaction.createdByUserId],
        true,
      );
      transaction.createdByUser = users[transaction.createdByUserId];
    }

    const itemIds = [transaction.bom.itemId, transaction.parentBom?.itemId];

    const items = await this.itemService.getItemsByIds(itemIds, true);

    transaction.bom = {
      ...transaction.bom,
      item: items[transaction.bom?.itemId],
    };
    transaction.parentBom = {
      ...transaction?.parentBom,
      item: items[transaction.parentBom?.itemId],
    };

    const response = plainToInstance(
      WorkOrderTransactionDetailResponseDto,
      transaction,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   * Create transit work order
   * Check producing step switch rule before create in-transit
   * @param payload
   * @returns
   */
  public async exportSubmit(
    payload: SubmitWorkOrderExportRequestDto,
  ): Promise<ResponsePayload<any>> {
    const {
      id,
      quantity,
      createdByUserId,
      toProducingStepId,
      exportDate,
      note,
      workCenterId,
    } = payload;
    const workOrder = await this.workOrderRepository.findOneWithRelations({
      where: {
        id: id,
      },
      relations: ['producingStep', 'workOrderSchedule'],
    });

    if (!workOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }

    if (
      workOrder.producingStep.switchMode ===
        ProducingStepSwitchModeEnum.CANNOT_MOVE_WHEN_UN_FULL_FILL &&
      minus(workOrder.qcPassQuantity || 0, workOrder.quantity) < 0
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.STEP_MUST_BE_FULL_FILL_BEFORE_MOVE_TO_OTHER_STEP',
          ),
        )
        .build();
    }

    if (!CAN_EXPORT_WORK_ORDER_STATUS.includes(workOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.STATUS_IS_INVALID'))
        .build();
    }

    const workCenter =
      await this.workOrderWorkCenterLotRepository.findOneWithRelations({
        where: {
          workOrderId: id,
          workCenterId: workCenterId,
        },
      });
    if (!workCenter) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WORK_ORDER_LOT_NOT_FOUND'),
        )
        .build();
    }

    if (
      quantity > minus(workCenter.qcPassQuantity, workCenter.exportQuantity)
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INVALID_QUANTITY'))
        .build();
    }

    const { producingSteps, toRoutingId, toBomId } =
      await this.getTransitImportProducingSteps(
        workOrder.routingId,
        workOrder.producingStepId,
        workOrder.moPlanId,
        workOrder.bomId,
      );

    if (
      isEmpty(
        find(
          producingSteps,
          (producingStep) => producingStep.id === toProducingStepId,
        ),
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.TO_PRODUCING_STEP_INVALID'),
        )
        .build();
    }
    workOrder.exportQuantity = plus(workOrder.exportQuantity, quantity);
    workCenter.exportQuantity = plus(workCenter.exportQuantity, quantity);

    const workOrderScheduleDetail =
      await this.workOrderScheduleDetailRepository.findOneWithRelations({
        where: {
          workCenterId: workCenterId,
          workOrderScheduleId: first(workOrder.workOrderSchedule).id,
        },
      });

    workOrderScheduleDetail.exportQuantity = plus(
      workOrderScheduleDetail.exportQuantity || 0,
      quantity,
    );

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(WorkOrderEntity, workOrder);
      await queryRunner.manager.save(workCenter);
      await queryRunner.manager.save(workOrderScheduleDetail);

      const inTransitEntity = this.inTransitRepository.createEntity({
        workOrder: workOrder,
        quantity: quantity,
        planId: workOrder.moPlanId,
        toProducingStepId,
        createdByUserId,
        exportDate,
        note,
        toBomId,
        toRoutingId,
        workCenterId,
      });

      const inTranist = await queryRunner.manager.save(
        InTransitEntity,
        inTransitEntity,
      );

      await queryRunner.commitTransaction();
      return new ResponseBuilder(inTranist)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getListWorkOrderScrapTransaction(
    payload: GetListWorkOrderScrapTransactionRequestDto,
  ): Promise<
    ResponsePayload<GetListWorkOrderScrapTransactionResponseDto | any>
  > {
    const { filter, page } = payload;
    const itemNameFilter = filter?.find((item) => item.column === 'itemName');

    let filterItemIds = [];

    if (!isEmpty(itemNameFilter)) {
      filterItemIds = await this.itemService.getItemsByName(
        itemNameFilter,
        true,
      );

      if (isEmpty(filterItemIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: 0 },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    const { result, count } =
      await this.workOrderScrapTransactionRepository.getList(
        payload,
        filterItemIds,
      );

    const bomItemIds = uniq(map(flatMap(result, 'bom'), 'itemId'));
    const parentBomItemIds = uniq(map(flatMap(result, 'parentBom'), 'itemId'));

    const itemIds = [...new Set([...parentBomItemIds, ...bomItemIds])];

    const items = await this.itemService.getItemsByIds(itemIds, true);

    const data = result.map((scrapTransaction) => ({
      ...scrapTransaction,
      bom: {
        ...scrapTransaction.bom,
        item: items[scrapTransaction.bom?.itemId],
      },
      parentBom: scrapTransaction.bom.parentBom
        ? {
            ...scrapTransaction.bom.parentBom,
            item: items[scrapTransaction.bom.parentBom?.itemId],
          }
        : {},
    }));

    const response = plainToInstance(
      WorkOrderScrapTransactionResponseAbstractDto,
      data,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getDetailWorkOrderScrapTransaction(
    payload: GetDetailWorkOrderScrapTransactionRequestDto,
  ): Promise<ResponsePayload<WorkOrderScrapTransactionResponseDto | any>> {
    const { id } = payload;
    const scrapTransaction =
      await this.workOrderScrapTransactionRepository.getDetail(id);
    if (!scrapTransaction) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    scrapTransaction.createdByUser = {};

    if (scrapTransaction.createdByUserId !== null) {
      const users = await this.userService.getUserByIds(
        [scrapTransaction.createdByUserId],
        false,
      );
      scrapTransaction.createdByUser = !isEmpty(users[0]) ? users[0] : {};
    }
    const itemIds = [
      scrapTransaction.bom.itemId,
      scrapTransaction?.parentBom?.itemId,
    ];

    const items = await this.itemService.getItemsByIds(itemIds, true);

    scrapTransaction.bom = {
      ...scrapTransaction.bom,
      item: items[scrapTransaction.bom?.itemId],
    };
    scrapTransaction.parentBom = {
      ...scrapTransaction?.parentBom,
      item: items[scrapTransaction?.parentBom?.itemId],
    };
    const response = plainToInstance(
      WorkOrderScrapTransactionResponseAbstractDto,
      scrapTransaction,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getListWorkOrderBomTransitHistory(
    payload: GetListWorkOrderBomTransitHistoryRequestDto,
  ): Promise<
    ResponsePayload<GetListWorkOrderBomTransitHistoryResponseDto | any>
  > {
    const { filter, page } = payload;
    const itemNameFilter = filter?.find((item) => item.column === 'itemName');

    let filterItemIds = [];

    if (!isEmpty(itemNameFilter)) {
      filterItemIds = await this.itemService.getItemsByName(
        itemNameFilter,
        true,
      );

      if (isEmpty(filterItemIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: 0 },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    const { result, count } =
      await this.workOrderInputHistoryRepository.getList(
        payload,
        filterItemIds,
      );

    const bomItemIds = uniq(map(flatMap(result, 'bom'), 'itemId'));
    const parentBomItemIds = uniq(map(flatMap(result, 'parentBom'), 'itemId'));

    const itemIds = [...new Set([...parentBomItemIds, ...bomItemIds])];

    const items = await this.itemService.getItemsByIds(itemIds, true);

    const data = result.map((workOrderBomTransitHistory) => ({
      ...workOrderBomTransitHistory,
      bom: {
        ...workOrderBomTransitHistory.bom,
        item: items[workOrderBomTransitHistory.bom?.itemId],
      },
      parentBom: {
        ...workOrderBomTransitHistory.parentBom,
        item: items[workOrderBomTransitHistory.parentBom?.itemId],
      },
    }));

    const response = plainToInstance(
      WorkOrderBomTransitHistoryResponseAbstractDto,
      data,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count.cnt, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getDetailWorkOrderBomTransitHistory(
    payload: GetDetailWorkOrderBomTransitHistoryRequestDto,
  ): Promise<ResponsePayload<WorkOrderBomTransitHistoryResponseDto | any>> {
    const { id } = payload;
    const workOrderBomTransitHistory =
      await this.workOrderInputHistoryRepository.getDetail(id);

    if (!workOrderBomTransitHistory) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    workOrderBomTransitHistory.createdByUser = {};

    const itemIds = uniq(
      [
        workOrderBomTransitHistory.bom?.itemId,
        workOrderBomTransitHistory?.parentBom?.itemId,
      ].concat(map(workOrderBomTransitHistory.materials, 'itemId')),
    );
    const userIds = [workOrderBomTransitHistory.createdByUserId];
    const [items, users] = await Promise.all([
      this.itemService.getItemsByIds(itemIds, true),
      this.userService.getUserByIds(userIds, true),
    ]);

    workOrderBomTransitHistory.createdByUser = !isEmpty(users)
      ? users[workOrderBomTransitHistory.createdByUserId]
      : {};

    workOrderBomTransitHistory.bom = {
      ...workOrderBomTransitHistory.bom,

      item: items[workOrderBomTransitHistory.bom.itemId],
    };
    workOrderBomTransitHistory.parentBom = {
      ...workOrderBomTransitHistory?.parentBom,
      item: items[workOrderBomTransitHistory.parentBom?.itemId],
    };
    workOrderBomTransitHistory.materials =
      workOrderBomTransitHistory?.materials?.map((i) => ({
        ...i,
        item: items[i?.itemId],
      }));

    const response = plainToInstance(
      WorkOrderBomTransitHistoryResponseAbstractDto,
      workOrderBomTransitHistory,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  public async getInTransitList(
    request: GetListInTransitRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { keyword } = request;

    let filterItemIds = [];

    if (!isEmpty(keyword)) {
      filterItemIds = await this.itemService.getItemsByName(
        { text: keyword },
        true,
      );
    }

    const { result, count } = await this.inTransitRepository.getList(
      request,
      filterItemIds,
    );

    const bomItemIds = uniq(map(flatMap(result, 'bom'), 'itemId'));
    const parentBomItemIds = uniq(map(flatMap(result, 'parentBom'), 'itemId'));

    const items = await this.itemService.getItemsByIds(
      uniq(bomItemIds.concat(parentBomItemIds)),
      true,
    );

    const data = result.map((inTransit) => ({
      ...inTransit,
      bom: {
        ...inTransit.bom,
        item: items[inTransit.bom.itemId],
      },
      parentBom: {
        ...inTransit.parentBom,
        item: items[inTransit.parentBom?.itemId],
      },
    }));

    const response = plainToInstance(InTransitResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  public async getInTransitImportHistoryList(
    request: GetListInTransitRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { keyword } = request;

    let filterItemIds = [];

    if (!isEmpty(keyword)) {
      filterItemIds = await this.itemService.getItemsByName(
        { text: keyword },
        true,
      );
    }

    const { result, count } = await this.inTransitHistoryRepository.getList(
      request,
      filterItemIds,
    );

    const bomItemIds = uniq(map(flatMap(result, 'bom'), 'itemId'));
    const parentBomItemIds = uniq(map(flatMap(result, 'parentBom'), 'itemId'));
    const items = await this.itemService.getItemsByIds(
      uniq(bomItemIds.concat(parentBomItemIds)),
      true,
    );

    const data = result.map((inTransit) => ({
      ...inTransit,
      bom: {
        ...inTransit.bom,
        item: items[inTransit.bom.itemId],
      },
      parentBom: {
        ...inTransit.parentBom,
        item: items[inTransit.parentBom?.itemId],
      },
    }));

    const response = plainToInstance(InTransitResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getInTransitDetail(
    payload: GetDetailInTransitRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id } = payload;
    const inTransit = await this.inTransitRepository.getDetail(id);

    if (isEmpty(inTransit)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const itemIds = uniq([inTransit.bom?.itemId, inTransit.parentBom?.itemId]);
    const items = await this.itemService.getItemsByIds(itemIds, true);
    inTransit.bom = {
      ...inTransit.bom,
      item: {
        ...items[inTransit.bom.itemId],
        itemUnit: items[inTransit.bom.itemId]?.itemUnitName,
      },
      parentBom: !isEmpty(inTransit.parentBom)
        ? {
            ...inTransit.parentBom,
            item: {
              ...items[inTransit.parentBom.itemId],
              itemUnit: items[inTransit.parentBom.itemId]?.itemUnitName,
            },
          }
        : {},
    };

    const importWorkOrder: any = first(inTransit.importWorkOrders);
    inTransit.importWorkOrder = {
      ...importWorkOrder,
      workCenters: importWorkOrder.workCenters.map((wc) => ({
        ...wc,
        lots: [
          {
            lotNumber: importWorkOrder.lotNumber,
            date: importWorkOrder.createdAt,
          },
        ],
      })),
    };

    inTransit.importWorkOrders = inTransit.importWorkOrders.map((iWo) => ({
      ...iWo,
      workCenters: iWo.workCenters.map((wc) => ({
        ...wc,
        lots: [
          {
            lotNumber: iWo.lotNumber,
            date: iWo.createdAt,
          },
        ],
      })),
    }));
    const response = plainToInstance(InTransitResponseDto, inTransit, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getInTransitImportHistoryDetail(
    payload: GetDetailInTransitRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id } = payload;
    const inTransit = await this.inTransitHistoryRepository.getDetail(id);
    if (isEmpty(inTransit)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const itemIds = uniq([inTransit.bom?.itemId, inTransit.parentBom?.itemId]);
    const items = await this.itemService.getItemsByIds(itemIds, true);
    inTransit.bom = {
      ...inTransit.bom,
      item: items[inTransit.bom.itemId],
    };
    inTransit.parentBom = {
      ...inTransit.parentBom,
      item: items[inTransit?.parentBom?.itemId],
    };
    const response = plainToInstance(InTransitResponseDto, inTransit, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async confirmInTransit(
    payload: ChangeStatusInTransitRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id } = payload;
    const inTransit = await this.inTransitRepository.findOneById(id);
    if (isEmpty(inTransit)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_CONFIRM_IN_TRANSIT_STATUS.includes(inTransit.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.STATUS_IS_INVALID'))
        .build();
    }

    inTransit.status = TransitStatusEnum.CONFIRMED;
    try {
      await this.inTransitRepository.create(inTransit);

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (e) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('success.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async rejectInTransit(
    payload: ChangeStatusInTransitRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id } = payload;
    const inTransit = await this.inTransitRepository.findOneById(id);
    if (isEmpty(inTransit)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_REJECT_IN_TRANSIT_STATUS.includes(inTransit.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.STATUS_IS_INVALID'))
        .build();
    }
    const workOrder = await this.workOrderRepository.findOneById(
      inTransit.workOrderId,
    );
    if (isEmpty(workOrder)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    inTransit.status = TransitStatusEnum.REJECTED;
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(InTransitEntity, inTransit);
      workOrder.exportQuantity = minus(
        workOrder.exportQuantity,
        inTransit.quantity,
      );

      await queryRunner.manager.save(WorkOrderEntity, workOrder);
      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.INTERNAL_SERVER_ERROR'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }
  }

  /**
   * Nhập đầu vào từ công đoạn trước
   * @param payload
   * @returns
   */
  public async importInTransit(
    payload: ImportInTransitRequestDto,
  ): Promise<ResponsePayload<any>> {
    const {
      id,
      quantity,
      workOrderId,
      workCenterId,
      note,
      importDate,
      createdByUserId,
    } = payload;
    const inTransit = await this.inTransitRepository.getDetail(id);

    if (isEmpty(inTransit)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CAN_IMPORT_IN_TRANSIT_STATUS.includes(inTransit.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.STATUS_IS_INVALID'))
        .build();
    }
    if (quantity > minus(inTransit.quantity, inTransit.actualQuantity)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INVALID_QUANTITY'))
        .build();
    }
    const importWorkOrders =
      await this.workOrderRepository.getImportWorkOrderByInTransitId(id);

    const workOrder = find(importWorkOrders, (wo) => wo.id === workOrderId);
    if (isEmpty(workOrder)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }

    const workOrderScheduleDetail =
      await this.workOrderScheduleDetailRepository.getByWorkCenterAndWorkOrderId(
        workCenterId,
        workOrderId,
      );
    if (isEmpty(workOrderScheduleDetail)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_CENTER_NOT_FOUND'))
        .build();
    }

    const toBom = inTransit.bom;

    const updateInTransit = new InTransitEntity();
    updateInTransit.id = inTransit.id;
    updateInTransit.actualQuantity = plus(inTransit.actualQuantity, quantity);
    updateInTransit.status =
      updateInTransit.actualQuantity >= inTransit.quantity
        ? TransitStatusEnum.COMPLETED
        : TransitStatusEnum.IN_PROGRESS;
    const oldWorkOrderTransit =
      await this.workOrderRepository.getBomTransitByItemId(
        workOrder.id,
        toBom.itemId,
        workCenterId,
      );

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(InTransitEntity, updateInTransit);
      let workOrderTransit =
        await this.workOrderBomTransitRepository.findOneByCondition({
          workOrderId: workOrder.id,
          workCenterId: workCenterId,
          bomDetailBomId: workOrder.bomId,
          bomDetailItemId: inTransit?.bom?.itemId,
        });
      if (isEmpty(workOrderTransit)) {
        workOrderTransit = new WorkOrderBomTransitEntity();
      }
      workOrderTransit.workOrderId = workOrder.id;
      workOrderTransit.bomDetailBomId = workOrder.bomId;
      workOrderTransit.bomDetailItemId = inTransit?.bom?.itemId;
      workOrderTransit.workCenterId = workCenterId;
      workOrderTransit.inputQuantity = plus(
        parseFloat(oldWorkOrderTransit?.quantity) || 0,
        quantity,
      );

      await queryRunner.manager.save(
        WorkOrderBomTransitEntity,
        workOrderTransit,
      );
      const inTransitHistoriyEntity =
        this.inTransitHistoryRepository.createEntity({
          workOrderId: workOrderId,
          inTransitId: inTransit.id,
          quantity: quantity,
          note: note,
          importDate: importDate,
          createdByUserId: createdByUserId,
        });
      await queryRunner.manager.save(
        InTransitHistoryEntity,
        inTransitHistoriyEntity,
      );
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }

    const bom = await this.bomRepository.findOneById(workOrder.bomId);
    const mo = await this.moRepository.findOneById(updateInTransit.moId);

    const requestQmsx: any = {
      qcStageId: STAGE_OPTIONS.INPUT_PRODUCTION,
      orderId: mo.manufacturingRequestOrderId,
      actualQuantity: quantity,
      moId: mo.id,
      itemId: bom.itemId,
      producingStepId: workOrder.producingStepId,
    };

    try {
      await this.qmsxService.createActualQuantityProduceStepsImportHistory(
        requestQmsx,
      );
    } catch (e) {
      console.log('QMSX_ERRROR', e);
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param routingId
   * @param currentProducingStepId
   * @param planId
   * @param bomId
   * @returns
   */
  private async getTransitImportProducingSteps(
    routingId: number,
    currentProducingStepId: number,
    planId: number,
    bomId: number,
  ): Promise<any> {
    let producingSteps = [];
    let toBomId: number;
    let toRoutingId: number;

    const isLastStep = await this.routingRepository.isLatestStepInRouting(
      routingId,
      currentProducingStepId,
    );

    if (isLastStep) {
      // To do: get next routing version
      const moPlanBom = await this.moPlanBomRepository.findOneByCondition({
        moPlanId: planId,
        bomId: bomId,
      });

      const parentMoPlanBom = await this.moPlanBomRepository.findOneByCondition(
        {
          moPlanId: planId,
          bomId: moPlanBom?.parentBomId,
        },
      );

      producingSteps = await this.producingStepRepository.getFirstStepOfBom(
        moPlanBom?.parentBomId,
        planId,
      );

      toBomId = moPlanBom?.parentBomId;
      toRoutingId = parentMoPlanBom.routingId;
    } else {
      producingSteps =
        await this.producingStepRepository.getProducingStepsByRoutingId(
          routingId,
        );
      toBomId = bomId;
      toRoutingId = routingId;
    }

    return {
      producingSteps: producingSteps,
      toBomId: toBomId,
      toRoutingId: toRoutingId,
    };
  }

  /**
   *
   * @param request
   * @returns
   */
  public async printQrCode(
    request: PrintQrcodeRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { items } = request;

    const raw = await this.workOrderRepository.findWithRelations({
      where: {
        id: In(map(items, 'id')),
      },
    });

    if (isEmpty(raw)) {
      return new ApiError(ResponseCodeEnum.NOT_FOUND).toResponse();
    }
    const serilizeItems = {};
    items.forEach((item) => {
      serilizeItems[item.id] = item;
    });
    const formatItems = raw.map((item) => {
      return {
        ...item,
        ...serilizeItems[item.id],
      };
    });
    const data = this.formatQrCodeData(formatItems);
    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param items
   * @returns
   */
  formatQrCodeData = (items) => {
    let responseString = '';
    items.forEach((item) => {
      const title = item.name;
      const itemCode = `${WORK_ORDER_CODE_PREFIX}${item.id}`;
      responseString +=
        `${startCommandChars}^FT27,365^BQN,2,9^FH\^FDLA,${itemCode}^FS^CI27^FO0,25^FB750,0,0,c,0^A@N,34,34,E:TIM000.TTF^FH^CI28^FD${title}^FS^CI27^FO250,150^FB450,100^A@N,34,34,E:TIM000.TTF^FH^CI28^FDMã: ${itemCode}\\&Tên: ${item.name}${endCommandChars}`.repeat(
          item.quantity,
        );
    });
    return responseString;
  };

  /**
   *
   * @param request
   * @returns
   */
  public async createWorkOrderSchedule(
    request: CreateWorkOrderScheduleRequestDto,
  ): Promise<ResponsePayload<WorkOrderScheduleResponseDto | any>> {
    const { workOrderId, scheduleDetails } = request;
    const workCenterIds = map(scheduleDetails, 'workCenterId');
    if (
      workCenterIds.length <= 0 ||
      workCenterIds.length !== workCenterIds.length
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INVALID_WORK_CENTER'))
        .build();
    }

    const workOrder = await this.workOrderRepository.getWorkOrderAndMO(
      workOrderId,
      workCenterIds,
    );

    if (!workOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!workOrder.totalWorkCenter || workOrder.totalWorkCenter <= 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_CENTER_NOT_FOUND'))
        .build();
    }

    if (workCenterIds.length !== workOrder.totalWorkCenter) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INVALID_WORK_CENTER'))
        .build();
    }

    const totalQuantity = sumBy(scheduleDetails, 'quantity');
    if (minus(totalQuantity, workOrder.quantity) !== 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INVALID_QUANTITY'))
        .build();
    }
    let result = await this.workOrderScheduleRepository.findOneByCondition({
      workOrderId: workOrderId,
    });

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (!result) {
        const workOrderScheduleEntity =
          this.workOrderScheduleRepository.createEntity({
            ...request,
            status: WorkOrderStatusEnum.CREATED,
            quantity: workOrder.quantity,
            planFrom: workOrder.planFrom,
            planTo: workOrder.planTo,
          });
        result = await queryRunner.manager.save(
          WorkOrderScheduleEntity,
          workOrderScheduleEntity,
        );
      } else {
        await queryRunner.manager.delete(WorkOrderScheduleDetailEntity, {
          workOrderScheduleId: result.id,
        });
      }

      const itemDetailSchedules = [];
      scheduleDetails.forEach((e) => {
        const detailScheduleEntity =
          this.workOrderScheduleDetailRepository.createEntity({
            workOrderScheduleId: result.id,
            status: WorkOrderStatusEnum.CREATED,
            moderationQuantity: e.quantity,
            ...e,
          });
        itemDetailSchedules.push(detailScheduleEntity);
      });

      result.workOrderScheduleDetail = await queryRunner.manager.save(
        itemDetailSchedules,
      );

      const response = plainToInstance(WorkOrderScheduleResponseDto, result, {
        excludeExtraneousValues: true,
      });

      await queryRunner.commitTransaction();

      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getWorkOrderSchedule(
    payload: GetWorkOrderScheduleRequestDto,
  ): Promise<any> {
    const { id } = payload;
    const workOrder = await this.workOrderRepository.getWorkOrderAndFactoryId(
      id,
    );
    if (!workOrder) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    let workCenterSchedule =
      await this.workOrderScheduleRepository.getDetailByWorkOrderId(id);

    const items = await this.itemService.getItemsByIds(
      [workOrder.itemId],
      true,
    );

    if (
      !workCenterSchedule ||
      isEmpty(workCenterSchedule.workOrderScheduleDetails)
    ) {
      workCenterSchedule = {
        id: workOrder.id,
        quantity: workOrder.quantity,
        actualQuantity: workOrder.quantity,
        status: WorkOrderStatusEnum.CREATED,
        workOrder: {
          id: workOrder.id,
          code: WORK_ORDER_CODE_PREFIX + workOrder.id,
        },
      };
      const workOrderRequest = {
        workOrderId: workOrder.id,
        scheduleDetails: [],
      };
      const scheduleDetails = await this.genWorkOrderSchedule(id);
      if (scheduleDetails.statusCode !== ResponseCodeEnum.SUCCESS) {
        return scheduleDetails;
      }
      scheduleDetails.data.workOrderScheduleDetails.map((scheduleDetail) => {
        if (scheduleDetail.quantity > 0) {
          workOrderRequest.scheduleDetails.push({
            workCenterId: scheduleDetail.workCenter.id,
            quantity: scheduleDetail.quantity,
          });
        }
      });
      if (isEmpty(workOrderRequest.scheduleDetails)) {
        workCenterSchedule.workOrderScheduleDetails =
          workOrderRequest.scheduleDetails;

        workCenterSchedule.workOrderScheduleDetails.forEach((schedule) => {
          Object.assign(schedule, {
            mpCode: workOrder.mpCode,
            producingStepName: workOrder.producingStepName,
            item: items[workOrder.itemId],
          });
        });

        return new ResponseBuilder(workCenterSchedule)
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
      }
      const createworkOrderSchedule = await this.autoCreateWorkOrderSchedule(
        workOrderRequest,
      );
      if (createworkOrderSchedule.statusCode !== ResponseCodeEnum.SUCCESS) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          createworkOrderSchedule.message,
        ).toResponse();
      }

      workCenterSchedule.workOrderScheduleDetails =
        scheduleDetails.data.workOrderScheduleDetails.map((scheduleDetail) => {
          const createScheduleDetail =
            createworkOrderSchedule.data.workOrderScheduleDetail.find((e) => {
              e.workCenterId === scheduleDetail.workCenter.id;
            });
          if (!isEmpty(createScheduleDetail)) {
            scheduleDetail.id = createScheduleDetail.id;
          }

          Object.assign(scheduleDetail, {
            mpCode: workOrder.mpCode,
            producingStepName: workOrder.producingStepName,
            item: items[workOrder.itemId],
          });
          return scheduleDetail;
        });
    } else {
      const workCenterIds = [];
      workCenterSchedule.workOrderScheduleDetails.forEach(
        (workOrderScheduleDetail) => {
          workCenterIds.push(workOrderScheduleDetail?.workCenter.id);
        },
      );
      const workCenters = await this.workCenterRepository.getWorkCenterNotInIds(
        workOrder.factoryId,
        workCenterIds,
        workOrder.producingStepId,
      );
      workCenters.forEach((workCenter) => {
        workCenterSchedule.workOrderScheduleDetails.push({
          quantity: 0,
          actualQuantity: 0,
          moderationQuantity: 0,
          workCenter: {
            id: workCenter.id,
            code: workCenter.code,
            name: workCenter.name,
          },
        });
      });
    }

    workCenterSchedule.workOrderScheduleDetails.forEach((schedule) => {
      Object.assign(schedule, {
        mpCode: workOrder.mpCode,
        producingStepName: workOrder.producingStepName,
        item: items[workOrder.itemId],
      });
    });

    const response = plainToInstance(WOScheduleDetailDto, workCenterSchedule, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  private async autoCreateWorkOrderSchedule(request): Promise<any> {
    const { workOrderId, scheduleDetails } = request;
    const workCenterIds = map(scheduleDetails, 'workCenterId');

    const workOrder = await this.workOrderRepository.getWorkOrderAndMO(
      workOrderId,
      workCenterIds,
    );

    let result = await this.workOrderScheduleRepository.findOneByCondition({
      workOrderId: workOrderId,
    });

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (!result) {
        const workOrderScheduleEntity =
          this.workOrderScheduleRepository.createEntity({
            ...request,
            status: WorkOrderStatusEnum.CREATED,
            quantity: workOrder.quantity,
            planFrom: workOrder.planFrom,
            planTo: workOrder.planTo,
          });
        result = await queryRunner.manager.save(
          WorkOrderScheduleEntity,
          workOrderScheduleEntity,
        );
      } else {
        await queryRunner.manager.delete(WorkOrderScheduleDetailEntity, {
          workOrderScheduleId: result.id,
        });
      }

      const itemDetailSchedules = [];
      scheduleDetails.forEach((e) => {
        const detailScheduleEntity =
          this.workOrderScheduleDetailRepository.createEntity({
            workOrderScheduleId: result.id,
            status: WorkOrderStatusEnum.CREATED,
            moderationQuantity: e.quantity,
            ...e,
          });
        itemDetailSchedules.push(detailScheduleEntity);
      });

      result.workOrderScheduleDetail = await queryRunner.manager.save(
        itemDetailSchedules,
      );

      await queryRunner.commitTransaction();

      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }
  }

  /**
   *
   * @param id
   * @returns
   */
  public async genWorkOrderSchedule(id: number): Promise<any> {
    const workOrder = await this.workOrderRepository.getWorkOrderAndWorkCenter(
      id,
    );
    if (!workOrder) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (!workOrder?.factoryId) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.WORK_CENTER_FOR_THIS_MO_NOT_FOUND'),
      ).toResponse();
    }

    if (isEmpty(workOrder.workCenters)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.WORK_CENTER_FOR_THIS_MO_NOT_FOUND'),
      ).toResponse();
    }
    let workCenters = workOrder.workCenters;

    workCenters = genDailySchedule(
      workOrder.planFrom,
      workOrder.planTo,
      workOrder.quantity,
      workCenters,
      workOrder.productionTimePerItem,
    );
    const workOrderScheduleDetail = [];
    workCenters.forEach((workCenter) => {
      const quantityWorkCenter = sumBy(
        values(workCenter.dailySchedule),
        'quantity',
      );
      workOrderScheduleDetail.push({
        quantity: quantityWorkCenter || 0,
        moderationQuantity: quantityWorkCenter || 0,
        actualQuantity: quantityWorkCenter || 0,
        workCenter: plainToInstance(WorkCenterResponseAbstractDto, workCenter, {
          excludeExtraneousValues: true,
        }),
      });
    });

    const workOrderSchedule = {
      ...workOrder,
      actualQuantity: 0,
      workOrder: {
        ...workOrder,
        code: `${WORK_ORDER_CODE_PREFIX}${workOrder.id}`,
      },
      workOrderScheduleDetails: workOrderScheduleDetail,
    };
    const response = plainToInstance(WOScheduleDetailDto, workOrderSchedule, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  public async approveWorkOrderSchedule(
    request: ChangeStatusWorkOrderScheduleRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { userId, id } = request;
    const workOrderSchedule =
      await this.workOrderScheduleRepository.findOneWithRelations({
        where: {
          workOrderId: id,
        },
      });

    if (!workOrderSchedule) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WORK_ORDER_SCHEDULE_NOT_FOUND'),
        )
        .build();
    }

    if (
      !CAN_APPROVE_WORK_ORDER_SCHEDULE_STATUS.includes(workOrderSchedule.status)
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.MO_PLAN_NEED_CONFIRMED'))
        .build();
    }
    workOrderSchedule.approverId = userId;
    workOrderSchedule.approvedAt = new Date(Date.now());
    workOrderSchedule.status = WorkOrderScheduleStatusEnum.CONFIRMED;

    const result = await this.workOrderScheduleRepository.create(
      workOrderSchedule,
    );
    const response = plainToInstance(WorkOrderScheduleResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  public async rejectWorkOrderSchedule(
    request: ChangeStatusWorkOrderScheduleRequestDto,
  ): Promise<ResponsePayload<WorkOrderResponseDto | any>> {
    const { userId, id } = request;
    const workOrderSchedule =
      await this.workOrderScheduleRepository.findOneWithRelations({
        where: {
          workOrderId: id,
        },
      });

    if (!workOrderSchedule) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WORK_ORDER_SCHEDULE_NOT_FOUND'),
        )
        .build();
    }

    if (
      !CAN_REJECT_WORK_ORDER_SCHEDULE_STATUS.includes(workOrderSchedule.status)
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.MO_PLAN_NEED_CONFIRMED'))
        .build();
    }
    workOrderSchedule.approverId = userId;
    workOrderSchedule.approvedAt = new Date(Date.now());
    workOrderSchedule.status = WorkOrderScheduleStatusEnum.REJECTED;

    const result = await this.workOrderScheduleRepository.create(
      workOrderSchedule,
    );
    const response = plainToInstance(WorkOrderScheduleResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  public async approveWorkOrderScheduleDetail(
    request: ChangeStatusWorkOrderScheduleRequestDto,
  ): Promise<ResponsePayload<GetWorkOrderScheduleDetailResponseDto | any>> {
    const { userId, id } = request;
    const workOrderScheduleDetail =
      await this.workOrderScheduleDetailRepository.findOneWithRelations({
        where: {
          id: id,
        },
        relations: ['workOrderSchedule'],
      });

    if (!workOrderScheduleDetail) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WORK_ORDER_SCHEDULE_NOT_FOUND'),
        )
        .build();
    }

    if (
      !CAN_APPROVE_WORK_ORDER_SCHEDULE_DETAIL_BY_WOS_STATUS.includes(
        workOrderScheduleDetail?.workOrderSchedule?.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.STATUS_WORK_ORDER_SCHEDULE_NOT_ACCEPTED',
          ),
        )
        .build();
    }

    if (
      !CAN_APPROVE_WORK_ORDER_SCHEDULE_DETAIL_STATUS.includes(
        workOrderScheduleDetail.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.STATUS_WORK_ORDER_SCHEDULE_NOT_ACCEPTED',
          ),
        )
        .build();
    }

    workOrderScheduleDetail.approverId = userId;
    workOrderScheduleDetail.approvedAt = new Date(Date.now());
    workOrderScheduleDetail.status =
      WorkOrderScheduleDetailStatusEnum.CONFIRMED;
    const result = await this.workOrderScheduleDetailRepository.create(
      workOrderScheduleDetail,
    );
    await this.workCenterService.genAndSaveDailySchedule(
      workOrderScheduleDetail.workCenterId,
      workOrderScheduleDetail.id,
    );

    const response = plainToInstance(
      GetWorkOrderScheduleDetailResponseDto,
      result,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param workOrderScheduleDetailId
   */
  public async syncToMaterialPlanSchedules(workOrderScheduleDetailId: number) {
    await this.workOrderScheduleDetailRepository.syncToMaterialPlanSchedules(
      workOrderScheduleDetailId,
    );
  }

  /**
   *
   * @param request
   * @returns
   */
  public async rejectWorkOrderScheduleDetail(
    request: ChangeStatusWorkOrderScheduleRequestDto,
  ): Promise<ResponsePayload<GetWorkOrderScheduleDetailResponseDto | any>> {
    const { userId, id } = request;
    const workOrderSchedule =
      await this.workOrderScheduleDetailRepository.findOneWithRelations({
        where: {
          id: id,
        },
      });

    if (!workOrderSchedule) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WORK_ORDER_SCHEDULE_NOT_FOUND'),
        )
        .build();
    }

    if (
      !CAN_REJECT_WORK_ORDER_SCHEDULE_DETAIL_STATUS.includes(
        workOrderSchedule.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.MO_PLAN_NEED_CONFIRMED'))
        .build();
    }
    workOrderSchedule.approverId = userId;
    workOrderSchedule.approvedAt = new Date(Date.now());
    workOrderSchedule.status = WorkOrderScheduleDetailStatusEnum.REJECTED;

    const result = await this.workOrderScheduleDetailRepository.create(
      workOrderSchedule,
    );
    const response = plainToInstance(
      GetWorkOrderScheduleDetailResponseDto,
      result,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  public async getListWorkOrderSchedules(
    request: GetListWorkOrderScheduleRequestDto,
  ): Promise<any> {
    const { filter, sort } = request;
    const filterItemUnitName = filter?.filter(
      (record) => record.column === 'itemUnitName',
    );
    const sortItemUnitName = sort?.filter(
      (record) => record.column === 'itemUnitName',
    );

    let itemIds = [];
    let items = {};

    if (!isEmpty(sortItemUnitName)) {
      const workOrders =
        await this.workOrderRepository.getWorkOrderDistinctBomId();
      itemIds = map(flatMap(workOrders), 'itemId');
    }

    if (!isEmpty(filterItemUnitName)) {
      items = await this.itemService.getItemByItemUnitNameKeyWord(
        first(filterItemUnitName),
      );

      if (isEmpty(items)) {
        return new ResponseBuilder([])
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
      }
    }

    if (isEmpty(items) && !isEmpty(itemIds)) {
      items = await this.itemService.getItemsByIds(itemIds);
    }

    const { result, total } = await this.workOrderScheduleRepository.getList(
      request,
      items,
    );

    let data = result;
    if (isEmpty(items)) {
      itemIds = uniq(map(flatMap(result, 'bom'), 'itemId'));
      items = await this.itemService.getItemsByIds(itemIds, true);

      data = result.map((record) => ({
        ...record,
        item: items[record.bom.itemId],
      }));
    }

    const response = plainToInstance(WorkOrderScheduleResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: total, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  async deleteWorkOrderScheduleDetail(
    request: DeleteWorkOrderScheduleDetailRequestDto,
  ): Promise<any> {
    const { id, workCenterId } = request;
    const workOrderSchedule =
      await this.workOrderScheduleRepository.findOneWithRelations({
        where: {
          workOrderId: id,
        },
        relations: ['workOrderScheduleDetail'],
      });
    if (
      isEmpty(workOrderSchedule) ||
      isEmpty(workOrderSchedule.workOrderScheduleDetail)
    ) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.WORK_ORDER_SCHEDULE_NOT_FOUND'),
      ).toResponse();
    }
    const workOrderScheduleDetails = workOrderSchedule.workOrderScheduleDetail;
    const workOrderScheduleDetail = workOrderScheduleDetails.find(
      (workOrderScheduleDetail) =>
        workOrderScheduleDetail.workCenterId === workCenterId,
    );
    if (isEmpty(workOrderScheduleDetail)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.WORK_ORDER_SCHEDULE_DETAIL_NOT_FOUND'),
      ).toResponse();
    }
    if (
      !CAN_DELETE_WORK_ORDER_SCHEDULE_DETAIL_STATUS.includes(
        workOrderScheduleDetail.status,
      )
    ) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate(
          'error.STATUS_WORK_ORDER_SCHEDULE_DETAIL_INVALID',
        ),
      ).toResponse();
    }
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.delete(WorkOrderScheduleDetailEntity, {
        id: workOrderScheduleDetail.id,
      });
      await queryRunner.manager.delete(WorkCenterDailyScheduleEntity, {
        workOrderScheduleDetailId: workOrderScheduleDetail.id,
      });
      await queryRunner.commitTransaction();
      await queryRunner.release();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      await queryRunner.release();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_DELETE'),
      ).toResponse();
    }
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getGranttWorkOrderSchedules(
    payload: GetListWorkOrderScheduleRequestDto,
  ): Promise<ResponsePayload<any>> {
    const data: any = await this.moPlanBomRepository.getGranttChart(payload);
    let serializeItems;
    if (!isEmpty(data.result)) {
      const itemIds = map(data.result, 'itemId');
      serializeItems = await this.itemService.getItemsByIds(itemIds, true);
    }
    const response = [];
    data.result.forEach((d) => {
      const startDate = moment(d.planFrom).utc().format('YYYY-MM-DD HH:mm');
      let endDate = moment(d.planTo)
        .add(1, 'day')
        .utc()
        .format('YYYY-MM-DD HH:mm');
      if (startDate === endDate) {
        endDate = moment(d.planTo).add(1, 'day').format('YYYY-MM-DD HH:mm');
      }
      const level1Key = `MPB_${d.id}`;
      response.push({
        id: level1Key,
        rId: d.id,
        start_date: startDate,
        end_date: endDate,
        text: serializeItems[d.itemId]?.name,
        progress: div(d.actualQuantity || 0, d.quantity || 1),
      });

      d.workOrders.forEach((workOrder) => {
        const startDate = moment(workOrder.planFrom)
          .utc()
          .format('YYYY-MM-DD HH:mm');
        let endDate = moment(workOrder.planTo)
          .add(1, 'day')
          .utc()
          .format('YYYY-MM-DD HH:mm');
        if (startDate === endDate) {
          endDate = moment(workOrder.planTo)
            .add(1, 'day')
            .format('YYYY-MM-DD HH:mm');
        }
        response.push({
          id: `WO_${workOrder.id}`,
          rId: workOrder.id,
          text: workOrder.producingStep.name,
          parent: level1Key,
          start_date: startDate,
          end_date: endDate,
          progress: div(
            workOrder.woActualQuantity || 0,
            workOrder.woQuantity || 1,
          ),
        });
        response.push(
          ...workOrder.schedules.map((schedule) => {
            const startDate = moment(schedule.planFrom)
              .utc()
              .format('YYYY-MM-DD HH:mm');
            let endDate = moment(schedule.planTo)
              .add(1, 'day')
              .utc()
              .format('YYYY-MM-DD HH:mm');

            if (startDate === endDate) {
              endDate = moment(schedule.planTo)
                .add(1, 'day')
                .format('YYYY-MM-DD HH:mm');
            }
            return {
              id: `SD_${schedule.id}`,
              rId: schedule.id,
              text: schedule.workCenter.name,
              parent: `WO_${workOrder.id}`,
              start_date: startDate,
              end_date: endDate,
              status:
                schedule.quantity < schedule.planQuantityToNow
                  ? 0
                  : schedule.quantity === schedule.planQuantityToNow
                  ? 1
                  : 2,
              progress: div(
                schedule.actualQuantity || 0,
                schedule.quantity || 1,
              ),
            };
          }),
        );
      });
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: data.count, page: payload.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async updateGranttWorkOrderSchedule(
    payload: UpdateWorkOrderGranttDataRequestDto,
  ): Promise<any> {
    const { startDate, endDate, rId } = payload;
    const planFrom = new Date(startDate);
    const planTo = new Date(endDate);
    const workOrder = await this.workOrderRepository.findOneById(rId);

    if (!workOrder) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'),
      ).toResponse();
    }
    const moPlanBom = await this.moPlanBomRepository.findOneById(
      workOrder.moPlanBomId,
    );
    if (!moPlanBom) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.MO_PLAN_BOM_NOT_FOUND'),
      ).toResponse();
    }
    if (
      !moment(planFrom).isSameOrAfter(workOrder.planFrom) ||
      !moment(planTo).isSameOrAfter(workOrder.planTo)
    ) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.GRANTT_TIME_UPDATE_INVALID'),
      ).toResponse();
    }
    workOrder.planFrom = planFrom;
    workOrder.planTo = planTo;

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(workOrder);
      if (
        moment(planFrom).isBefore(moment(moPlanBom.planFrom)) ||
        moment(planTo).isAfter(moment(moPlanBom.planTo))
      ) {
        moPlanBom.planFrom = planFrom;
        moPlanBom.planTo = planTo;
        await queryRunner.manager.save(moPlanBom);
      }
      await queryRunner.commitTransaction();
      await queryRunner.release();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (err) {
      await queryRunner.rollbackTransaction();
      await queryRunner.release();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  /**
   *
   * @param workOrderId
   * @param materialItems
   * @returns
   */
  private async validateMaterialInput(
    workOrderId: number,
    materialItems: { itemId?: number; quantity?: number }[],
  ): Promise<{ items: any[]; errorInputItems: any[] }> {
    const itemInputIds = map(materialItems, 'itemId');
    const items = await this.bomDetailRepository.getMaterialInputItems(
      workOrderId,
      itemInputIds,
    );
    const errorInputItems = [];
    for (let i = 0; i < materialItems.length; i++) {
      const inputItem = materialItems[i];
      const existedItem = find(items, (i) => i.itemId === inputItem.itemId);

      if (isEmpty(existedItem) || !existedItem) {
        errorInputItems.push(
          `ITEM: ${inputItem.itemId} ${await this.i18n.translate(
            'error.NOT_FOUND',
          )}`,
        );
      }
    }

    return {
      items: items,
      errorInputItems: errorInputItems,
    };
  }

  /**
   *
   * @param request
   * @returns
   */
  public async getListWorkOrderScheduleDetails(
    request: GetListWorkOrderScheduleRequestDto,
  ): Promise<ResponsePayload<GetListWorkOrderScheduleDetailResponseDto | any>> {
    const { sort, filter } = request;
    let items = {};
    let itemList, itemIdMap;
    if (
      sort?.find((s) => s.column === 'itemName') ||
      filter?.find((s) => s.column === 'itemName')
    ) {
      const workOrder = await this.bomRepository.getItemByBoms();
      itemIdMap = uniq(map(workOrder, 'itemId'));
      itemList = await this.itemService.getItemsByIds(itemIdMap);
    }
    const { result, count } =
      await this.workOrderScheduleDetailRepository.getListDetail(
        request,
        itemList,
      );

    let data = result;
    if (!isEmpty(data)) {
      itemIdMap = uniq(map(result, 'itemId'));
      items = await this.itemService.getItemsByIds(itemIdMap, true);
      data = result.map((record) => ({
        ...record,
        item: items[record.itemId],
        itemName: items[record.itemId].name,
      }));
    }
    const response = plainToInstance(
      GetListWorkOrderScheduleDetailResponseDto,
      data,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  async getLogTimeByMoIds(request: LogTimeByWoIdsRequestDto): Promise<any> {
    const { ids, workCenterId } = request;

    const data = await this.workOrderRepository.getLogTimeByMoIds({
      moIds: ids,
      workCenterId: workCenterId,
    });

    const result = { workOrders: data };

    const response = plainToInstance(LogTimeByWoIdsResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param moPlanBom
   * @param quantity
   * @param queryRunner
   * @returns
   */
  private async updateMoPlanBomProgress(
    moPlanBom: MoPlanBomEntity,
    quantity: number,
    queryRunner: QueryRunner,
  ) {
    let shouldDispatchUpdateMoStatusEvent = false;
    moPlanBom.actualQuantity = moPlanBom.confirmedQuantity = plus(
      moPlanBom.actualQuantity,
      quantity,
    );

    const moDetail = await this.moDetailRepository.findOneByCondition({
      id: moPlanBom.moDetailId,
      manufacturingOrderId: moPlanBom.moId,
      bomId: moPlanBom.bomId,
    });

    // BOM is finished product!!
    if (moDetail) {
      moDetail.actualQuantity = plus(moDetail.actualQuantity || 0, quantity);
      await queryRunner.manager.save(ManufacturingOrderDetailEntity, moDetail);
      shouldDispatchUpdateMoStatusEvent = true;
    }
    moPlanBom.setActualQuantity(moPlanBom.actualQuantity, moPlanBom.quantity);
    if (minus(moPlanBom.actualQuantity, moPlanBom.quantity) >= 0) {
      moPlanBom.status = WorkOrderStatusEnum.COMPLETED;
      const plc = await this.workCenterRepository.findOneWithRelations({
        where: {
          currentRunningWorkOrderId: moPlanBom.id,
        },
      });

      if (!isEmpty(plc)) {
        plc.currentRunningWorkOrderId = null;
        const virtualDevices =
          await this.workCenterRepository.findWithRelations({
            where: {
              parentId: plc.id,
              isVirtual: 1,
            },
          });
        if (!isEmpty(virtualDevices)) {
          for (let index = 0; index < virtualDevices.length; index++) {
            const currentWC = virtualDevices[index];
            currentWC.currentRunningWorkOrderId = null;
          }
          await queryRunner.manager.save(WorkCenterEntity, virtualDevices);
        }
        await queryRunner.manager.save(WorkCenterEntity, plc);
      }
    }
    await queryRunner.manager.save(MoPlanBomEntity, moPlanBom);

    //update produced quantity mo-request
    const mo = await this.manufacturingOrderRepository.findOneWithRelations({
      where: {
        id: moPlanBom.moId,
      },
    });

    if (!isEmpty(mo) && mo.manufacturingRequestOrderId) {
      await this.requestService.updateProducedQuantity({
        id: mo.manufacturingRequestOrderId,
        items: [
          {
            itemId: moPlanBom.itemId,
            bomVersionId: moPlanBom.bomVersionId,
            quantity: quantity,
          },
        ],
      } as UpdateProducedQuantityRequestDto);
    }

    this.eventEmitter.emit(
      'manufacturing-order.mo-plan-bom-actual-quantity-updated',
      new MoPlanBomProgressUpdateEvent({
        moPlanBom: moPlanBom,
        quantity: quantity,
      }),
    );

    return shouldDispatchUpdateMoStatusEvent;
  }

  /**
   *
   * @param mo
   * @param workOrder
   * @param workCenterDailySchedule
   * @param workCenterDailyScheduleShift
   * @param quantity
   * @param shouldDispatchUpdateMoStatusEvent
   */
  private async fireWorkOrderPrgressSubmitedEvent(
    mo: ManufacturingOrderEntity,
    workOrder: WorkOrderEntity,
    workCenterDailySchedule: WorkCenterDailyScheduleEntity,
    workCenterDailyScheduleShift: WorkCenterDailyScheduleShiftEntity,
    quantity: number,
    shouldDispatchUpdateMoStatusEvent: boolean,
  ) {
    if (shouldDispatchUpdateMoStatusEvent) {
      this.eventEmitter.emit(
        'quality-control.created',
        new QualityControlCreatedEvent({
          moId: workOrder.moId,
        }),
      );
    }
    this.eventEmitter.emit(
      'manufacturing-order.gen-pro',
      new ManufacturingOrderProgressSetEvent({
        mo,
        moPlanId: workOrder.moPlanId,
      }),
    );

    if (workOrder.producingStep.qcCheck) {
      try {
        await this.qmsxService.createActualQuantityProduceStepsImportHistory({
          qcStageId: STAGE_OPTIONS.OUTPUT_PRODUCTION,
          orderId: mo.manufacturingRequestOrderId,
          actualQuantity: quantity,
          moId: mo.id,
          itemId: workOrder.bom.itemId,
          producingStepId: workOrder.producingStepId,
        });
      } catch (e) {
        this.logger.error('createActualQuantityProduceStepsImportHistory', e);
      }
    }
    this.eventEmitter.emit(
      'manufacturing-order.work-order-actual-quantity-updated',
      new WorkOrderProgressUpdateEvent({
        mo: mo,
        workOrder: workOrder,
        workCenterDailySchedule: workCenterDailySchedule,
        workCenterDailyScheduleShift: workCenterDailyScheduleShift,
        quantity: quantity,
      }),
    );
  }

  /**
   *
   * @param request
   * @returns
   */
  public async autocomplete(request: AutocompleteRequestDto): Promise<any> {
    const {
      id,
      quantity: q,
      workCenterId,
      rejectQuantity,
      passQuantity,
    } = request;
    const quantity = q || null;
    const createdByUserId = 1;
    const workOrder = await this.workOrderRepository.scan(id);

    if (!CAN_SUBMIT_WORK_ORDER_INPUT.includes(workOrder.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_IS_INVALID'),
      ).toResponse();
    }

    workOrder.materials = workOrder.inputs?.filter((input) =>
      isEmpty(input.bom),
    );

    workOrder.previousBoms = workOrder.previousBoms?.map((i) => ({
      ...i,
      planQuantity: workOrder.quantity,
    }));

    const workOrderSchedule =
      await this.workOrderScheduleRepository.findOneWithRelations({
        where: {
          workOrderId: id,
        },
      });

    const workOrderScheduleDetailEntities =
      await this.workOrderScheduleDetailRepository.findWithRelations({
        where: {
          workOrderScheduleId: workOrderSchedule.id,
        },
        relations: ['workCenterDailySchedule'],
      });

    const workOrderScheduleDetails = keyBy(
      workOrderScheduleDetailEntities,
      'workCenterId',
    );
    const exportWorkOrder = await this.workOrderRepository.exportScan(id);

    exportWorkOrder.producingSteps =
      await this.producingStepRepository.getProducingStepsByRoutingId(
        exportWorkOrder.routingId,
      );
    const currentStep = exportWorkOrder.producingSteps.find(
      (producingStep) =>
        producingStep.id == exportWorkOrder?.exportProducingStep?.id,
    );

    exportWorkOrder.importProducingSteps =
      exportWorkOrder.producingSteps.filter(
        (producingStep) =>
          producingStep.stepNumber === currentStep.stepNumber + 1,
      );

    if (isEmpty(exportWorkOrder.importProducingSteps)) {
      // is lastes step at current routing
      if (!isEmpty(exportWorkOrder.bom?.parentBom)) {
        exportWorkOrder.importProducingSteps =
          await this.producingStepRepository.getFirstStepOfBom(
            exportWorkOrder.bom?.parentBom?.id,
            exportWorkOrder.planId,
          );
      }
      // is lastest product
    }

    workOrder.workCenters = workOrder.workCenters.map((workCenter) => {
      let workCenterMaterials = filter(
        workOrder.materials,
        (m) => m.workCenterId === workCenter.id,
      );
      const workCenterPreviousBoms = filter(
        workOrder.previousBoms,
        (m) => m.workCenterId === workCenter.id,
      );
      if (isEmpty(workCenterMaterials)) {
        workCenterMaterials = workOrder.materials.map((material) => ({
          ...material,
          planQuantity: mul(
            workCenter.totalPlanQuantity,
            material.bomProducingStepRate || 1,
          ),
        }));
      } else {
        workCenterMaterials = workCenterMaterials.map((material) => ({
          ...material,
          planQuantity: mul(
            workCenter.totalPlanQuantity,
            material.bomProducingStepRate || 1,
          ),
        }));
      }
      workCenter.materials = workCenterMaterials;
      workCenter.previousBoms = workCenterPreviousBoms;
      return workCenter;
    });

    let importDate;

    const inTransits = [];

    // Fullfil material
    if (workCenterId) {
      const workCenter = find(
        workOrder.workCenters,
        (wc) => wc.id === workCenterId,
      );
      const result = await this.autocompleteWorkCenter(
        workCenter,
        workOrder,
        workOrderScheduleDetails,
        exportWorkOrder,
        importDate,
        createdByUserId,
        quantity,
        rejectQuantity,
        passQuantity,
      );
      inTransits.push(result);
    } else {
      for (let i = 0; i < workOrder.workCenters.length; i++) {
        const workCenter = workOrder.workCenters[i];
        const result = this.autocompleteWorkCenter(
          workCenter,
          workOrder,
          workOrderScheduleDetails,
          exportWorkOrder,
          importDate,
          createdByUserId,
          quantity,
          rejectQuantity,
          passQuantity,
        );
        inTransits.push(result);
      }
    }
    if (!isEmpty(inTransits)) {
      // complete instranits
      // await this.autocompleteInTransits(
      //   inTransits,
      //   workOrder,
      //   createdByUserId,
      //   importDate,
      // );
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   */
  async produceMonitoring(request: IotValue): Promise<any> {
    const { readings } = request;
    let systemStatus = readings.find(
      (reading) => reading.resourceName == 'SystemStatus',
    );

    if (!systemStatus) {
      systemStatus = readings[0];
    }
    const device = await this.workCenterRepository.findOneByCondition({
      code: systemStatus.deviceName,
    });
    this.logger.debug('IOT PRODUCE MONITOR - DEVICE: ', {
      device,
      readings,
    });
    if (isEmpty(device)) return;
    const producingStepReadings = readings.filter((reading) =>
      reading.resourceName.startsWith('ProducingStep'),
    );
    if (isEmpty(producingStepReadings)) return;

    producingStepReadings.forEach((producingStepReading) => {
      producingStepReading.producingStepId = +producingStepReading.resourceName
        .split('ProducingStep')[1]
        .split('-')[0];
      producingStepReading.deviceId = device.id;
    });

    const producingSteps = await this.producingStepRepository.findWithRelations(
      {
        where: {
          id: In(map(producingStepReadings, 'producingStepId')),
        },
      },
    );

    const devices = [device];
    if (device.type === WorkCenterTypeEnum.PLC) {
      const virtualDevices = await this.workCenterRepository.findWithRelations({
        where: {
          isVirtual: 1,
          parentId: device.id,
        },
      });
      devices.push(...virtualDevices);
    }

    if (isEmpty(producingSteps)) return;

    const currentWorkOrders =
      await this.workOrderRepository.getCurrentWorkOrdersByDevice(
        map(devices, 'id'),
        map(producingSteps, 'id'),
      );

    const requests = [];

    if (!isEmpty(currentWorkOrders)) {
      currentWorkOrders?.forEach((workOrder) => {
        workOrder.scheduleDetails.forEach((scheduleDetail) => {
          const thisProducingStepReadings = filter(
            producingStepReadings,
            (ps) => ps.producingStepId == workOrder.producingStepId,
          );

          if (!isEmpty(thisProducingStepReadings)) {
            // @TODO add case without QC
            const passReading = find(
              thisProducingStepReadings,
              (ps) => ps.resourceName.split('-')[1] === 'PASS',
            );
            const rejectReading = find(
              thisProducingStepReadings,
              (ps) => ps.resourceName.split('-')[1] === 'FAILED',
            );
            const thisStepQuantityPass = minus(
              +passReading?.value || 0,
              parseFloat(scheduleDetail.passQuantity || 0),
            );
            const thisStepQuantityReject = minus(
              +rejectReading?.value || 0,
              parseFloat(scheduleDetail.rejectQuantity) || 0,
            );
            const inValidQuantity =
              thisStepQuantityPass <= 0 && thisStepQuantityReject <= 0;
            this.logger.debug('IOT Start Insert Producing Data: ', {
              device: device?.code,
              readings,
              inValidQuantity,
              thisStepQuantityPass,
              thisStepQuantityReject,
            });
            if (!inValidQuantity) {
              const qcPassQty =
                minus(thisStepQuantityPass, 0) > 0 ? thisStepQuantityPass : 0;

              const qcRejectQty =
                minus(thisStepQuantityReject, 0) > 0
                  ? thisStepQuantityReject
                  : 0;
              const qty = plus(qcPassQty, qcRejectQty);
              requests.push(
                this.autocomplete({
                  id: workOrder.id,
                  quantity: qty,
                  passQuantity: qcPassQty,
                  rejectQuantity: qcRejectQty,
                  workCenterId: scheduleDetail.workCenterId,
                } as SubmitWorkOrderProgressRequestDto),
              );

              this.logger.debug('IOT PRODUCE MONITOR - INSERT WO: ', {
                id: workOrder.id,
                quantity: qty,
                passQuantity: qcPassQty,
                rejectQuantity: qcRejectQty,
                workCenterId: scheduleDetail.workCenterId,
              });
            }
          }
        });
      });
    }

    await Promise.all(requests);
  }

  /**
   *
   * @param workCenter
   * @param workOrder
   * @param workOrderScheduleDetails
   * @param exportWorkOrder
   * @param importDate
   * @param createdByUserId
   * @param quantity
   * @returns
   */
  private async autocompleteWorkCenter(
    workCenter,
    workOrder,
    workOrderScheduleDetails,
    exportWorkOrder,
    importDate,
    createdByUserId,
    quantity?,
    rejectQuantity?,
    passQuantity?,
  ) {
    const { materials } = workCenter;
    const workOrderScheduleDetail: any =
      workOrderScheduleDetails[workCenter.id];
    const materialSubmitRequest = {
      id: workOrder.id,
      workCenterId: workCenter.id,
      createdByUserId: createdByUserId,
      materialItems: materials.map((material) => ({
        itemId: material.itemId,
        quantity: material.planQuantity,
      })),
    } as SubmitWorkOrderInputRequestDto;
    // await this.materialInputSubmit(materialSubmitRequest);

    const { workCenterDailySchedule } = workOrderScheduleDetail;
    for (let j = 0; j < workCenterDailySchedule.length; j++) {
      const workCenterDaily = workCenterDailySchedule[j];
      const progressSubmitRequest = {
        id: workOrder.id,
        workCenterId: workCenter.id,
        createdByUserId: createdByUserId,
        quantity: quantity || 0,
        rejectQuantity: rejectQuantity || 0,
        passQuantity: passQuantity || 0,
        executionDay: workCenterDaily.executionDay,
      } as SubmitWorkOrderProgressRequestDto;

      const a = await this.progressSubmit(progressSubmitRequest, true);
    }

    const importProducingStep: any = first(
      exportWorkOrder.importProducingSteps,
    );
    const lastWorkCenterDailySchedule: any = last(workCenterDailySchedule);
    importDate = lastWorkCenterDailySchedule?.executionDay;
    const exportSubmitRequest = {
      id: workOrder.id,
      workCenterId: workCenter.id,
      createdByUserId: createdByUserId,
      toProducingStepId: importProducingStep?.id,
      quantity: quantity || workOrderScheduleDetail.quantity,
      exportDate: lastWorkCenterDailySchedule?.executionDay,
    } as SubmitWorkOrderExportRequestDto;

    const result = await this.exportSubmit(exportSubmitRequest);

    return result.data;
  }

  /**
   *
   * @param inTransits
   * @param workOrder
   * @param createdByUserId
   * @param importDate
   */
  private async autocompleteInTransits(
    inTransits,
    workOrder,
    createdByUserId,
    importDate,
  ) {
    for (let index = 0; index < inTransits.length; index++) {
      const inTransit = await this.inTransitRepository.getDetail(
        inTransits[index]?.id,
      );

      if (isEmpty(inTransit)) continue;
      const importWorkOrder: any = first(inTransit.importWorkOrders);
      const importWorkOrderInfo = await this.workOrderRepository.scan(
        importWorkOrder.id,
      );

      const bomDetailOfImportWorkOrder =
        await this.bomRepository.findOneWithRelations({
          where: {
            id: importWorkOrderInfo.bom.id,
          },
          relations: ['bomDetails'],
        });

      let bomDetail;
      if (workOrder.routing.id !== importWorkOrderInfo.routing.id) {
        bomDetail = find(
          bomDetailOfImportWorkOrder.bomDetails,
          (bd) => bd.itemId === workOrder.bom.itemId,
        );
      }
      importWorkOrderInfo.workCenters = importWorkOrderInfo.workCenters.map(
        (workCenter) => {
          if (workOrder.routing.id === importWorkOrderInfo.routing.id) {
            workCenter.importPreviousBomQuantity = workCenter.totalPlanQuantity;
          } else {
            workCenter.importPreviousBomQuantity =
              workCenter.totalPlanQuantity * bomDetail.quantity;
          }
          return workCenter;
        },
      );

      inTransit.status = TransitStatusEnum.CONFIRMED;

      await this.inTransitRepository.create(inTransits);
      let exportedQuantity = 0;
      for (let j = 0; j < importWorkOrderInfo.workCenters.length; j++) {
        const workCenter = importWorkOrderInfo.workCenters[j];
        if (minus(inTransit.quantity, exportedQuantity) > 0) {
          const importQuantity =
            minus(inTransit.quantity, exportedQuantity) >
            workCenter.importPreviousBomQuantity
              ? workCenter.importPreviousBomQuantity
              : minus(inTransit.quantity, exportedQuantity);

          const importInTransitRequest = {
            id: inTransit.id,
            workOrderId: importWorkOrderInfo.id,
            workCenterId: workCenter.id,
            createdByUserId: createdByUserId,
            quantity: importQuantity,
            importDate: importDate,
          } as ImportInTransitRequestDto;
          workCenter.importPreviousBomQuantity -= importQuantity;
          exportedQuantity += importQuantity;

          await this.importInTransit(importInTransitRequest);
        }
      }
    }
  }
}
