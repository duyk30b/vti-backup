import { IsArray, IsOptional } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';
import { WorkOrderResponseAbstractDto } from './work-order.response.abstract.dto';
import { GetErrorReportDetailByWoResponseDto } from '@components/qmx/dto/response/error_report_detail_by_work_order_id.response.dto';
import { WorkCenterResponseAbstractDto } from '@components/work-center/dto/response/work-center.response.abstract.dto';
import { WorkOrderLogTimeResponseDto } from './work-order-log-time.response.dto';
import { BasicResponseDto } from '@core/dto/response/basic.response.dto';

class ItemResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'boq 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  itemUnitCode: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  itemUnitName: string;

  @ApiProperty({
    example: {
      id: 1,
      name: 'Bán TP',
      code: 'BTP',
    },
    description: '',
  })
  @Expose()
  @Type(() => BasicResponseDto)
  itemType: BasicResponseDto;
}

class ProducingStep {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'boq 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({})
  @Expose()
  qcQuantityRule: number;
}

class ParentBomResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'bom 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 1, description: 'Item', type: ItemResponse })
  @Expose()
  @Type(() => ItemResponse)
  item: ItemResponse;
}

class Lot {
  @ApiProperty({ example: 400, description: 'Số lượng kế hoạch' })
  @Expose()
  @Type(() => Number)
  quantity: number;

  @ApiProperty()
  @Expose()
  @ApiProperty({
    example: 300,
    description: 'Tổng số NVL đã nhập vào kho sx và đã pass QC',
  })
  @Expose()
  @Type(() => Number)
  totalQcPassQuantity?: number;

  @ApiProperty({
    example: 300,
  })
  @Expose()
  @Type(() => Number)
  totalQcRejectQuantity?: number;

  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  date: string;
}

class BomResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'bom 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 1, description: 'Item', type: ItemResponse })
  @Expose()
  @Type(() => ItemResponse)
  item: ItemResponse;

  @ApiProperty({
    example: 1,
    description:
      'Parent Bom: bom cha, với những bom có xuất hiện bom cha thì nó là bán thành phẩm',
    type: ParentBomResponse,
  })
  @Expose()
  @IsOptional()
  @Type(() => ParentBomResponse)
  parentBom?: ParentBomResponse;
}

class MaterialResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 100, description: 'Số lượng đã sx' })
  @Expose()
  @Type(() => Number)
  @ApiProperty({ example: 400, description: 'Số lượng kế hoạch' })
  @Expose()
  @Type(() => Number)
  planQuantity: number;

  @ApiProperty({ example: 400, description: 'Tổng số NVL đã nhập vào kho sx' })
  @Expose()
  @Type(() => Number)
  totalImportQuantity: number;

  @ApiProperty({
    example: 300,
    description: 'Tổng số NVL đã nhập vào kho sx và đã pass QC',
  })
  @Expose()
  @Type(() => Number)
  totalQcPassQuantity?: number;

  @ApiProperty({
    example: 300,
    description: 'Qc ?',
  })
  @Expose()
  @Type(() => Number)
  qcCheck?: number;

  @ApiProperty({
    example: 300,
  })
  @Expose()
  @Type(() => Number)
  bomProducingStepRate?: number;

  @ApiProperty({
    example: 300,
    description: 'Tiêu chí Qc ?',
  })
  @Expose()
  @Type(() => Number)
  criteriaId?: number;

  @ApiProperty({
    example: 300,
    description: 'Tổng số NVL đã nhập vào kho sx và đã fail QC',
  })
  @Expose()
  @Type(() => Number)
  totalQcRejectQuantity?: number;

  @ApiProperty({
    example: 300,
  })
  @Expose()
  @Type(() => Number)
  totalUnQcQuantity?: number;

  @ApiProperty({ example: 300, description: 'Số lượng nhập' })
  @Expose()
  @Type(() => Number)
  inputQuantity?: number;

  @ApiProperty({ example: 100, description: 'Số lượng đã sx' })
  @Expose()
  @Type(() => Number)
  producedQuantity?: number;

  @ApiProperty({
    description: 'Có phải là bán thành phẩm hay không',
  })
  @Expose()
  isSemiFinishedProduct: boolean;

  @ApiProperty({ example: 1, description: 'Item', type: ItemResponse })
  @Expose()
  @Type(() => ItemResponse)
  item: ItemResponse;
}

class BasePreviousBomResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 100, description: 'Số lượng đã sx' })
  @Expose()
  @Type(() => Number)
  @ApiProperty({ example: 400, description: 'Số lượng kế hoạch' })
  @Expose()
  @Type(() => Number)
  planQuantity: number;

  @ApiProperty({
    example: 300,
    description: 'Tổng số đã nhập vào kho sx và đã pass QC',
  })
  @Expose()
  @Type(() => Number)
  totalQcPassQuantity?: number;

  @ApiProperty({
    example: 300,
    description: 'Qc ?',
  })
  @Expose()
  @Type(() => Number)
  qcCheck?: number;

  @ApiProperty({
    example: 300,
    description: 'Tiêu chí Qc ?',
  })
  @Expose()
  @Type(() => Number)
  criteriaId?: number;

  @ApiProperty({
    example: 300,
    description: 'Tổng số đã nhập vào kho sx và đã fail QC',
  })
  @Expose()
  @Type(() => Number)
  totalQcRejectQuantity?: number;

  @ApiProperty({ example: 300, description: 'Số lượng nhập' })
  @Expose()
  @Type(() => Number)
  inputQuantity?: number;

  @ApiProperty({ example: 300, description: 'Số lượng nhập' })
  @Expose()
  @Type(() => Number)
  totalImportQuantity?: number;

  @ApiProperty({
    example: 300,
  })
  @Expose()
  @Type(() => Number)
  totalUnQcQuantity?: number;

  @ApiProperty({ example: 100, description: 'Số lượng đã sx' })
  @Expose()
  @Type(() => Number)
  producedQuantity?: number;

  @ApiProperty({
    description: 'Có phải là bán thành phẩm hay không',
  })
  @Expose()
  isSemiFinishedProduct: boolean;

  @ApiProperty({ example: 1, description: 'Item', type: ItemResponse })
  @Expose()
  @Type(() => ItemResponse)
  item: ItemResponse;
}

export class WorkCenterResponseDto extends WorkCenterResponseAbstractDto {
  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  remainQuantity: number;

  @ApiProperty()
  @IsArray()
  @Expose()
  lots: Lot[];

  @ApiProperty({
    type: [MaterialResponse],
    description: 'Nguyên vật liệu',
    isArray: true,
  })
  @Expose()
  @Type(() => MaterialResponse)
  @IsArray()
  materials?: MaterialResponse[];

  @ApiProperty({
    type: [BasePreviousBomResponse],
    description: 'Sẩn phẩm ở công đoạn trước',
    isArray: true,
  })
  @Expose()
  @Type(() => BasePreviousBomResponse)
  @IsArray()
  previousBoms?: BasePreviousBomResponse[];
}

class PreviousBomResponse extends BasePreviousBomResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  @Type(() => WorkCenterResponseDto)
  workCenter: WorkCenterResponseDto;
}

export class WorkOrderScanResponseDto extends WorkOrderResponseAbstractDto {
  @ApiProperty({ type: BomResponse })
  @Expose()
  @Type(() => BomResponse)
  bom: BomResponse;

  @ApiProperty({ type: WorkOrderLogTimeResponseDto })
  @Expose()
  @Type(() => WorkOrderLogTimeResponseDto)
  currentLogTime: WorkOrderLogTimeResponseDto;

  @ApiProperty({
    type: MaterialResponse,
    description: 'Nguyên vật liệu',
    isArray: true,
  })
  @Expose()
  @Type(() => MaterialResponse)
  @IsArray()
  materials?: MaterialResponse[];

  @ApiProperty({
    type: PreviousBomResponse,
    description: 'Sẩn phẩm ở công đoạn trước',
    isArray: true,
  })
  @Expose()
  @Type(() => PreviousBomResponse)
  @IsArray()
  previousBoms?: PreviousBomResponse[];

  @ApiProperty({
    type: ProducingStep,
    description: 'Danh sách công đoạn nhập',
    isArray: true,
  })
  @Expose()
  @Type(() => ProducingStep)
  @IsArray()
  importProducingSteps: ProducingStep[];

  @ApiProperty({
    type: ProducingStep,
    description: 'Chi tiết công đoạn xuất',
  })
  @Expose()
  @Type(() => ProducingStep)
  exportProducingStep: ProducingStep;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  @Type(() => GetErrorReportDetailByWoResponseDto)
  errorReport: GetErrorReportDetailByWoResponseDto;

  @ApiProperty({ type: WorkCenterResponseDto, isArray: true })
  @Expose()
  @Type(() => WorkCenterResponseDto)
  workCenters: WorkCenterResponseDto[];

  @ApiProperty()
  @Expose()
  qualityControlAlert: string;

  @ApiProperty()
  @Expose()
  moPlanId: number;
}
