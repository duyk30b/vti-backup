import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';

class ProducingStepResponse {
  @ApiProperty({ example: '1' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'ABC' })
  @Expose()
  name: string;

  @ApiProperty({ example: '1234' })
  @Expose()
  code: string;
}

class RoutingVersionResponse {
  @ApiProperty({ example: '1' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'ABC' })
  @Expose()
  name: string;
}

class WOTItemResponse {
  @ApiProperty({ example: '1' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'ABC' })
  @Expose()
  name: string;

  @ApiProperty({ example: '1234' })
  @Expose()
  code: string;

  @ApiProperty({ example: '1234' })
  @Expose()
  itemUnitName: string;

  @ApiProperty({ example: '1234' })
  @Expose()
  itemUnitCode: string;
}

class MoResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'boq 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;
}

class WOResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'boq 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({
    example: '2021-07-13 09:13:15.562609+00',
    description: '',
  })
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  planFrom: Date;

  @ApiProperty({
    example: '2021-07-13 09:13:15.562609+00',
    description: '',
  })
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  planTo: Date;

  @ApiProperty({ example: 400, description: '' })
  @Expose()
  @Type(() => Number)
  planQuantity: number;

  @ApiProperty({ example: 400, description: '' })
  @Expose()
  @Type(() => Number)
  actualQuantity: number;

  @ApiProperty({ example: 400, description: '' })
  @Expose()
  @Type(() => Number)
  scrapQuantity: number;
}

class BomResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'bom 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 400, description: '' })
  @Expose()
  @Type(() => Number)
  planQuantity: number;

  @ApiProperty({ description: '', type: WOTItemResponse })
  @Expose()
  @Type(() => WOTItemResponse)
  item: WOTItemResponse;
}

class CreatedByUserResponse {
  @ApiProperty({ example: '1' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'ABC' })
  @Expose()
  fullName: string;

  @ApiProperty({ example: '1234' })
  @Expose()
  code: string;

  @ApiProperty({ example: '1234' })
  @Expose()
  username: string;
}

export class WorkOrderScrapTransactionResponseAbstractDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 400, description: '' })
  @Expose()
  @Type(() => Number)
  quantity: number;

  @ApiProperty({
    example: '2021-07-13 09:13:15.562609+00',
    description: '',
  })
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  createdAt: Date;

  @ApiProperty({
    example: '2021-07-13 09:13:15.562609+00',
    description: '',
  })
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  updatedAt: Date;

  @ApiProperty({ type: MoResponse })
  @Expose()
  @Type(() => MoResponse)
  manufacturingOrder: MoResponse;

  @ApiProperty({ type: BomResponse })
  @Expose()
  @Type(() => BomResponse)
  bom: BomResponse;

  @ApiProperty({ type: BomResponse })
  @Expose()
  @Type(() => BomResponse)
  parentBom: BomResponse;

  @ApiProperty({ type: WOResponse })
  @Expose()
  @Type(() => WOResponse)
  workOrder: WOResponse;

  @ApiProperty({ type: ProducingStepResponse })
  @Expose()
  @Type(() => ProducingStepResponse)
  producingStep: ProducingStepResponse;

  @ApiProperty({ type: RoutingVersionResponse })
  @Expose()
  @Type(() => RoutingVersionResponse)
  routingVersion: RoutingVersionResponse;

  @ApiProperty({ type: CreatedByUserResponse })
  @Expose()
  @Type(() => CreatedByUserResponse)
  createdByUser: CreatedByUserResponse;
}
