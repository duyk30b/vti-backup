import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';

class ITWorkOrder {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  quantity: number;

  @ApiProperty({
    example: '2021-07-13 09:13:15.562609+00',
    description: '',
  })
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  planFrom: Date;

  @ApiProperty({
    example: '2021-07-13 09:13:15.562609+00',
    description: '',
  })
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  planTo: Date;
}

class ProducingStepResponse {
  @ApiProperty({ example: '1' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'ABC' })
  @Expose()
  name: string;

  @ApiProperty({ example: '1234' })
  @Expose()
  code: string;
}

class WOTItemResponse {
  @ApiProperty({ example: '1' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'ABC' })
  @Expose()
  name: string;

  @ApiProperty({ example: '1234' })
  @Expose()
  code: string;
}

class MoResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'boq 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;
}

class BomResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'bom 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ description: '', type: WOTItemResponse })
  @Expose()
  @Type(() => WOTItemResponse)
  item: WOTItemResponse;
}

export class WorkOrderTransactionResponseDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 400, description: 'Số lượng' })
  @Expose()
  @Type(() => Number)
  quantity: number;

  @ApiProperty({ example: 400, description: 'Số lượng đã sửa' })
  @Expose()
  @Type(() => Number)
  reportQuantity: number;

  @ApiProperty({
    example: '2021-07-13 09:13:15.562609+00',
    description: 'Ngày sản xuất',
  })
  @Expose()
  createdAt: Date;

  @ApiProperty({ type: ITWorkOrder })
  @Expose()
  @Type(() => ITWorkOrder)
  workOrder: ITWorkOrder;

  @ApiProperty({ type: MoResponse })
  @Expose()
  @Type(() => MoResponse)
  mo: MoResponse;

  @ApiProperty({ type: BomResponse })
  @Expose()
  @Type(() => BomResponse)
  bom: BomResponse | any;

  @ApiProperty({ type: BomResponse })
  @Expose()
  @Type(() => BomResponse)
  parentBom: BomResponse | any;

  @ApiProperty({ type: ProducingStepResponse })
  @Expose()
  @Type(() => ProducingStepResponse)
  producingStep: ProducingStepResponse;
}
