import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { WorkOrderScrapTransactionResponseAbstractDto } from '@components/work-order/dto/response/work-order-scrap-transaction.response.abstract.dto';

export class WorkOrderScrapTransactionResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: WorkOrderScrapTransactionResponseAbstractDto;
}
