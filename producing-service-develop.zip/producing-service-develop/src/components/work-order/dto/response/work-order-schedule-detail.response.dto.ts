import { SuccessResponse } from '@utils/success.response.dto';
import { ItemResponseDto } from '@components/item/dto/response/item.dto.response';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class WorkCenter {
  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  name: string;
}

class WorkOrder {
  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  name: string;
}

class ScheduleDetail {
  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  quantity: number;

  @ApiProperty({ example: '1', description: '' })
  @Expose()
  status: number;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  actualQuantity: number;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  moderationQuantity: number;

  @ApiProperty({ example: 'ps1' })
  @Expose()
  producingStepName: string;

  @ApiProperty({ example: 1 })
  @Expose()
  mpCode: number;

  @ApiProperty({ type: ItemResponseDto })
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => WorkCenter)
  workCenter: WorkCenter;
}

export class GetWorkOrderScheduleDetailResponseDto extends ScheduleDetail {}

export class WOScheduleDetailDto {
  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: '10.00', description: '' })
  @Expose()
  quantity: number;

  @ApiProperty({ example: '10.00', description: '' })
  @Expose()
  actualQuantity: number;

  @ApiProperty({ example: 1 })
  @Expose()
  status: number;

  @ApiProperty({ type: WorkOrder })
  @Expose()
  @Type(() => WorkOrder)
  workOrder: WorkOrder;

  @ApiProperty({ isArray: true, type: ScheduleDetail })
  @Expose()
  @IsArray()
  @Type(() => ScheduleDetail)
  workOrderScheduleDetails: ScheduleDetail[];
}
export class WorkOrderScheduleDetailResponseDto extends SuccessResponse {
  @ApiProperty({ type: WOScheduleDetailDto })
  @Expose()
  @Type(() => WOScheduleDetailDto)
  data: WOScheduleDetailDto;
}
