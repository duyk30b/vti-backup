import { IsArray } from 'class-validator';
import { Expose, Transform, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

class Lot {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;
}

class WorkCenter {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @Expose()
  @Type(() => Lot)
  lots: Lot[];
}

class ITWorkOrder {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  quantity: number;

  @ApiProperty({
    example: '2021-07-13 09:13:15.562609+00',
    description: '',
  })
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  planFrom: Date;

  @ApiProperty({
    example: '2021-07-13 09:13:15.562609+00',
    description: '',
  })
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  planTo: Date;

  @ApiProperty({ type: WorkCenter, isArray: true })
  @Expose()
  @Type(() => WorkCenter)
  @IsArray()
  workCenters: WorkCenter[];
}
class ITRoutingVersion {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;
}

class ITWMo {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  planFrom: string;

  @ApiProperty()
  @Expose()
  planTo: string;
}

class ITProducingStep {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ITWBomItem {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  itemUnit: string;
}

class ITWBom {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty({ type: ITWBomItem })
  @Expose()
  @Type(() => ITWBomItem)
  item: ITWBomItem;

  @ApiProperty({ type: ITWBom })
  @Expose()
  @Type(() => ITWBom)
  parentBom: ITWBom;
}

export class InTransitResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  quantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  workCenterQuantity: number;

  @ApiProperty()
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  createdAt: Date;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  exportQuantity: number;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  exportDate: string;

  @ApiProperty()
  @Expose()
  importDate: string;

  @ApiProperty()
  @Expose()
  note: string;

  @ApiProperty({ type: ITWorkOrder })
  @Expose()
  @Type(() => ITWorkOrder)
  workOrder: ITWorkOrder;

  @ApiProperty({ type: ITWMo })
  @Expose()
  @Type(() => ITWMo)
  manufacturingOrder: ITWMo;

  @ApiProperty({ type: ITWBom })
  @Expose()
  @Type(() => ITWBom)
  bom: ITWBom;

  @ApiProperty({ type: ITProducingStep })
  @Expose()
  @Type(() => ITProducingStep)
  producingStep: ITProducingStep;

  @ApiProperty({ type: ITProducingStep })
  @Expose()
  @Type(() => ITProducingStep)
  exportProducingStep: ITProducingStep;

  @ApiProperty({ type: ITProducingStep })
  @Expose()
  @Type(() => ITProducingStep)
  importProducingStep: ITProducingStep;

  @ApiProperty({ type: ITWorkOrder })
  @Expose()
  @Type(() => ITWorkOrder)
  importWorkOrder: ITWorkOrder;

  @ApiProperty({ type: ITWorkOrder, isArray: true })
  @Expose()
  @Type(() => ITWorkOrder)
  importWorkOrders: ITWorkOrder[];

  @ApiProperty({ type: ITRoutingVersion })
  @Expose()
  @Type(() => ITRoutingVersion)
  routingVersion: ITRoutingVersion;

  @ApiProperty({ type: Lot })
  @Expose()
  @Type(() => Lot)
  lot: Lot;

  @ApiProperty({ type: WorkCenter })
  @Expose()
  @Type(() => WorkCenter)
  workCenter: WorkCenter;
}
