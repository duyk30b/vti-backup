import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';

class ProducingStepResponse {
  @ApiProperty({ example: '1' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'ABC' })
  @Expose()
  name: string;

  @ApiProperty({ example: '1234' })
  @Expose()
  code: string;
}

class CreatedByUserResponse {
  @ApiProperty({ example: '1' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'ABC' })
  @Expose()
  fullName: string;

  @ApiProperty({ example: 'ABC' })
  @Expose()
  username: string;

  @ApiProperty({ example: '1234' })
  @Expose()
  code: string;
}

class RoutingVersionResponse {
  @ApiProperty({ example: '1' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'ABC' })
  @Expose()
  name: string;
}

class WOTItemResponse {
  @ApiProperty({ example: '1' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'ABC' })
  @Expose()
  name: string;

  @ApiProperty({ example: '1234' })
  @Expose()
  code: string;

  @ApiProperty({ example: '1234' })
  @Expose()
  itemUnitName: string;

  @ApiProperty({ example: '1234' })
  @Expose()
  itemUnitCode: string;
}

class MoResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'mo 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;
}

class WOResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'mo 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({
    example: '2021-07-13 09:13:15.562609+00',
    description: 'Ngày bắt đầu',
  })
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  planFrom: Date;

  @ApiProperty({
    example: '2021-07-13 09:13:15.562609+00',
    description: 'Ngày kết thúc',
  })
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  planTo: Date;

  @ApiProperty({ example: 400, description: 'Số lượng kế hoạch' })
  @Expose()
  planQuantity: number;

  @ApiProperty({ example: 400, description: 'Số lượng đã sản xuất' })
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @Expose()
  @Type(() => Number)
  totalUnQcQuantity: number;

  @Expose()
  @Type(() => Number)
  totalQcRejectQuantity: number;

  @Expose()
  @Type(() => Number)
  exportedQuantity: number;
}

class BomResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'bom 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 400, description: 'Số lượng kế hoạch' })
  @Expose()
  planQuantity: number;

  @ApiProperty({ description: '', type: WOTItemResponse })
  @Expose()
  @Type(() => WOTItemResponse)
  item: WOTItemResponse;
}

export class WorkOrderTransactionDetailResponseDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 400, description: 'Số lượng' })
  @Expose()
  quantity: number;

  @ApiProperty({ example: 400, description: 'Số lượng đã sửa' })
  @Expose()
  @Type(() => Number)
  repairQuantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  remainQuantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  producedQuantity: number;

  @ApiProperty({
    example: '2021-07-13 09:13:15.562609+00',
    description: 'Ngày sản xuất',
  })
  @Expose()
  createdAt: Date;

  @ApiProperty({ type: MoResponse })
  @Expose()
  @Type(() => MoResponse)
  manufacturingOrder: MoResponse;

  @ApiProperty({ type: BomResponse })
  @Expose()
  @Type(() => BomResponse)
  bom: BomResponse | any;

  @ApiProperty({ type: BomResponse })
  @Expose()
  @Type(() => BomResponse)
  parentBom?: BomResponse | any;

  @ApiProperty({ type: WOResponse })
  @Expose()
  @Type(() => WOResponse)
  workOrder: WOResponse | any;

  @ApiProperty({ type: ProducingStepResponse })
  @Expose()
  @Type(() => ProducingStepResponse)
  producingStep: ProducingStepResponse;

  @ApiProperty({ type: ProducingStepResponse })
  @Expose()
  @Type(() => ProducingStepResponse)
  routingVersion: RoutingVersionResponse;

  @ApiProperty({ type: CreatedByUserResponse })
  @Expose()
  @Type(() => CreatedByUserResponse)
  createdByUser: CreatedByUserResponse;
}
