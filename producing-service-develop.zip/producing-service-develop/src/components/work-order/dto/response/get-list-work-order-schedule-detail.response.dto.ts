import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { WorkCenterResponseAbstractDto } from '@components/work-center/dto/response/work-center.response.abstract.dto';
import { ItemResponseDto } from '@components/item/dto/response/item.dto.response';

export class GetListWorkOrderScheduleDetailResponseDto {
  @ApiProperty({ example: 1 })
  @Expose()
  id: number;

  @ApiProperty({ example: 1 })
  @Expose()
  status: number;

  @ApiProperty({ example: 'WO1000' })
  @Expose()
  woCode: string;

  @ApiProperty({ example: 'KH01' })
  @Expose()
  mpCode: string;

  @ApiProperty({ example: 'MO001' })
  @Expose()
  moCode: string;

  @ApiProperty({ example: 'Name' })
  @Expose()
  itemName: string;

  @ApiProperty({ example: '1' })
  @Expose()
  itemId: number;

  @ApiProperty({ example: 'Công đoạn 1' })
  @Expose()
  producingStepName: string;

  @ApiProperty({ type: WorkCenterResponseAbstractDto })
  @Expose()
  @Type(() => WorkCenterResponseAbstractDto)
  workCenter: WorkCenterResponseAbstractDto;

  @ApiProperty({ type: ItemResponseDto })
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;
}
