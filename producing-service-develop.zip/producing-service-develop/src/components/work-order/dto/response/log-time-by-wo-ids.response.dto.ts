import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class WorkCenterDailyScheduleShift {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  workCenterDailyScheduleId: number;

  @ApiProperty()
  @Expose()
  workCenterShiftId: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  qcPassQuantity: number;

  @ApiProperty()
  @Expose()
  qcRejectQuantity: number;

  @ApiProperty()
  @Expose()
  repairedQuantity: number;

  @ApiProperty()
  @Expose()
  errorQuantity: number;

  @ApiProperty()
  @Expose()
  moderationQuantity: number;

  @ApiProperty()
  @Expose()
  executionDay: Date;

  @ApiProperty()
  @Expose()
  actualQuantity: number;
}

class WorkCenterDailySchedule {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  workCenterId: number;

  @ApiProperty()
  @Expose()
  workOrderScheduleDetailId: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  workingDuration: number;

  @ApiProperty()
  @Expose()
  moderationQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  repairedQuantity: number;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  approverId: number;

  @ApiProperty()
  @Expose()
  approvedAt: Date;

  @ApiProperty()
  @Expose()
  logTimeDuration: number;

  @ApiProperty()
  @Expose()
  executionDay: string;

  @ApiProperty()
  @Expose()
  workCenterDailyScheduleShifts: WorkCenterDailyScheduleShift[];
}

class WorkOrder {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  errorQuantity: number;

  @ApiProperty()
  @Expose()
  scrapQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  confirmedQuantity: number;

  @ApiProperty()
  @Expose()
  qcPassQuantity: number;

  @ApiProperty()
  @Expose()
  qcRejectQuantity: number;

  @ApiProperty()
  @Expose()
  exportQuantity: number;

  @ApiProperty()
  @Expose()
  exportedQuantity: number;

  @ApiProperty()
  @Expose()
  repairedQuantity: number;

  @ApiProperty()
  @Expose()
  planFrom: Date;

  @ApiProperty()
  @Expose()
  planTo: Date;

  @ApiProperty()
  @Expose()
  startAt: Date;

  @ApiProperty()
  @Expose()
  endAt: Date;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  moName: string;

  @ApiProperty()
  @Expose()
  moId: number;

  @ApiProperty()
  @Expose()
  routingId: number;

  @ApiProperty()
  @Expose()
  bomId: number;

  @ApiProperty()
  @Expose()
  parentBomId: number;

  @ApiProperty()
  @Expose()
  producingStepId: number;

  @ApiProperty()
  @Expose()
  moDetailId: number;

  @ApiProperty()
  @Expose()
  moPlanId: number;

  @ApiProperty()
  @Expose()
  moPlanBomId: number;

  @ApiProperty()
  @Expose()
  lotNumber: number;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  approverId: number;

  @ApiProperty()
  @Expose()
  approvedAt: Date;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty()
  @Expose()
  workCenterDailySchedules: WorkCenterDailySchedule[];
}

export class LogTimeByWoIdsResponseDto {
  @ApiProperty({
    type: WorkOrder,
    isArray: true,
  })
  @Expose()
  @Type(() => WorkOrder)
  workOrders: WorkOrder[];
}
