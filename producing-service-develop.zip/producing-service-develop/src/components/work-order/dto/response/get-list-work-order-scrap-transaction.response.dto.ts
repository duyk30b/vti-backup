import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { WorkOrderScrapTransactionResponseAbstractDto } from '@components/work-order/dto/response/work-order-scrap-transaction.response.abstract.dto';
import { IsArray } from 'class-validator';

export class MetaDataWorkOrderScrapTransaction {
  @Expose()
  @ApiProperty({
    type: WorkOrderScrapTransactionResponseAbstractDto,
    isArray: true,
  })
  @IsArray()
  @Type(() => WorkOrderScrapTransactionResponseAbstractDto)
  items: WorkOrderScrapTransactionResponseAbstractDto[];
}

export class GetListWorkOrderScrapTransactionResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: MetaDataWorkOrderScrapTransaction;
}
