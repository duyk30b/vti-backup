import { WorkCenterResponseAbstractDto } from '@components/work-center/dto/response/work-center.response.abstract.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { ArrayUnique } from 'class-validator';

export class WorkOrderScheduleDetailResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty({ type: WorkCenterResponseAbstractDto })
  @Expose()
  workCenter: WorkCenterResponseAbstractDto;

  @ApiProperty({ example: '10.00', description: '' })
  @Expose()
  quantity: number;

  @ApiProperty({ example: '10.00', description: '' })
  @Expose()
  moderationQuantity: number;

  @ApiProperty({ example: '10.00', description: '' })
  @Expose()
  actualQuantity: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  status: number;
}

export class WorkOrderItemResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  itemUnitId: number;

  @ApiProperty()
  @Expose()
  itemUnitName: string;

  @ApiProperty()
  @Expose()
  itemUnitCode: string;
}

class WorkOrderResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class WorkCenterResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

export class WorkOrderScheduleResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  planFrom: Date;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  planTo: Date;

  @ApiProperty({ example: '10.00', description: '' })
  @Expose()
  quantity: number;

  @ApiProperty({ example: '10.00', description: '' })
  @Expose()
  actualQuantity: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  status: number;

  @ApiProperty({ type: WorkOrderResponse })
  @Type(() => WorkOrderResponse)
  @Expose()
  workOrder: WorkOrderResponse;

  @ApiProperty({ type: WorkOrderItemResponse })
  @Type(() => WorkOrderItemResponse)
  @Expose()
  item: WorkOrderItemResponse;

  @ApiProperty({ type: WorkCenterResponse, isArray: true })
  @ArrayUnique((e: WorkCenterResponse) => e.id)
  @Expose()
  workCenters: WorkCenterResponse[];

  @ApiProperty({ type: WorkOrderScheduleDetailResponse, isArray: true })
  @ArrayUnique((e: WorkOrderScheduleDetailResponse) => e.id)
  @Expose()
  workOrderScheduleDetails: WorkOrderScheduleDetailResponse[];
}
