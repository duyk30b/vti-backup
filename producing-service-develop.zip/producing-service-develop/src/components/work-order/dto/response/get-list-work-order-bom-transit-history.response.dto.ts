import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { WorkOrderBomTransitHistoryResponseAbstractDto } from '@components/work-order/dto/response/work-order-bom-transit-history.response.abstract.dto';
import { IsArray } from 'class-validator';

export class MetaDataWorkOrderBomTransitHistory {
  @Expose()
  @ApiProperty({
    type: WorkOrderBomTransitHistoryResponseAbstractDto,
    isArray: true,
  })
  @IsArray()
  @Type(() => WorkOrderBomTransitHistoryResponseAbstractDto)
  items: WorkOrderBomTransitHistoryResponseAbstractDto[];
}

export class GetListWorkOrderBomTransitHistoryResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: MetaDataWorkOrderBomTransitHistory;
}
