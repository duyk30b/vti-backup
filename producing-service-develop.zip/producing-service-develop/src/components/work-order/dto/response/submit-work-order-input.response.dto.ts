import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform } from 'class-transformer';

export class SubmitWorkOrderInputResponseDto {
  @Expose()
  @ApiProperty()
  workOrderId: number;

  @Expose({ name: 'bomDetailBomId' })
  @ApiProperty()
  bomId: number;

  @Expose({ name: 'bomDetailItemId' })
  @ApiProperty()
  itemId: number;

  @Expose()
  @ApiProperty()
  producedQuantity: number;
}
