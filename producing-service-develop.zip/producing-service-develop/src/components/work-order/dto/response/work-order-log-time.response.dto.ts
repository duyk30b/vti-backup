import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform } from 'class-transformer';
import { mul } from '@utils/common';

export class WorkOrderLogTimeResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  start: string;

  @ApiProperty()
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  end: string;

  @ApiProperty()
  @Expose()
  @Transform((value) => {
    return value.value ? mul(value.value, 60) : 0;
  })
  duration: number;

  @ApiProperty()
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  lastPlay: string;

  @ApiProperty()
  @Expose()
  isOpenning: boolean;
}
