import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { WorkOrderBomTransitHistoryResponseAbstractDto } from '@components/work-order/dto/response/work-order-bom-transit-history.response.abstract.dto';

export class WorkOrderBomTransitHistoryResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: WorkOrderBomTransitHistoryResponseAbstractDto;
}
