import { WorkOrderResponseAbstractDto } from '@components/work-order/dto/response/work-order.response.abstract.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class Meta {
  @ApiProperty({ example: 1 })
  @Expose()
  total: number;

  @ApiProperty({ example: 1 })
  @Expose()
  page: number;
}
export class MetaData {
  @ApiProperty({ type: WorkOrderResponseAbstractDto, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => WorkOrderResponseAbstractDto)
  items: WorkOrderResponseAbstractDto[];

  @ApiProperty({ type: Meta })
  @Expose()
  @Type(() => Meta)
  meta: Meta;
}

export class GetListWorkOrderResponseDto extends SuccessResponse {
  @ApiProperty({ type: MetaData })
  @Expose()
  @Type(() => MetaData)
  data: MetaData;
}
