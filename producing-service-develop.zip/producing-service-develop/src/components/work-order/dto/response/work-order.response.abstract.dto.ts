import { WorkCenterResponseAbstractDto } from '@components/work-center/dto/response/work-center.response.abstract.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';
class ProducingStepResponse {
  @ApiProperty({ example: '1' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'ABC' })
  @Expose()
  name: string;

  @ApiProperty({ example: '1234' })
  @Expose()
  code: string;

  @ApiProperty({})
  @Expose()
  qcCriteriaId: number;

  @ApiProperty({})
  @Expose()
  qcCheck: number;

  @ApiProperty({})
  @Expose()
  inputQcCheck: number;

  @ApiProperty({})
  @Expose()
  qcQuantityRule: number;
}

class RoutingResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'routing 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;
}

class RoutingVersionResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: '0.1', description: '' })
  @Expose()
  name: string;
}

class MoResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'boq 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;
}

class FactoryResponse {
  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'factory 1', description: '' })
  @Expose()
  name: string;
}

class WorkCenter {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'routing 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;
}

class ManufacturingRequestOrderResponse {
  @ApiProperty({ example: '', description: '' })
  @Expose()
  id: string;

  @ApiProperty({ example: 'boq 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;
}

class ItemUnitResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'cai', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'c', description: '' })
  @Expose()
  code: string;
}

class ParentBomResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'bom 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  itemId: number;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  itemCode: string;

  @ApiProperty({ example: 'chân bàn', description: '' })
  @Expose()
  itemName: string;

  @ApiProperty({ example: 1, description: '', type: ItemUnitResponse })
  @Type(() => ItemUnitResponse)
  @Expose()
  itemUnit: ItemUnitResponse;
}
class MoPlanResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'boq 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;
}

class MoDetailResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  itemId: number;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  itemCode: string;

  @ApiProperty({ example: 'bàn', description: '' })
  @Expose()
  itemName: string;

  @ApiProperty({ example: 1, description: '', type: ItemUnitResponse })
  @Type(() => ItemUnitResponse)
  @Expose()
  itemUnit: ItemUnitResponse;
}

class BomResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'bom 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  itemId: number;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  itemCode: string;

  @ApiProperty({ example: 'chân bàn', description: '' })
  @Expose()
  itemName: string;

  @ApiProperty({ example: 1, description: '', type: ItemUnitResponse })
  @Type(() => ItemUnitResponse)
  @Expose()
  itemUnit: ItemUnitResponse;

  @ApiProperty({
    example: 1,
    description:
      'Parent Bom: bom cha, với những bom có xuất hiện bom cha thì nó là bán thành phẩm',
    type: ParentBomResponse,
  })
  @Expose()
  @Type(() => ParentBomResponse)
  parentBom?: ParentBomResponse;
}

class MoPlanBomResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;
}

class UserResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'abc', description: '' })
  @Expose()
  username: string;

  @ApiProperty({ example: 'abc', description: '' })
  @Expose()
  fullName: string;
}

export class WorkOrderResponseAbstractDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'work order 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  status: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  runningStatus: number;

  @ApiProperty({ example: 'abc', description: '' })
  @Expose()
  description: string;

  @ApiProperty({
    example: 400,
    description: 'Số lượng kế hoạch của lệnh làm việc',
  })
  @Expose()
  @Type(() => Number)
  quantity: number;

  @ApiProperty({
    example: 400,
    description: 'Số lượng lỗi của lệnh làm việc',
  })
  @Expose()
  @Type(() => Number)
  errorQuantity: number;

  @ApiProperty({ example: 400, description: 'Số lượng kế hoạch' })
  @Expose()
  @Type(() => Number)
  totalPlanQuantity: number;

  @ApiProperty({ example: 300, description: 'Số lượng đã sx' })
  @Expose()
  @Type(() => Number)
  actualQuantity: number;

  @ApiProperty({ example: 100, description: 'Số lượng đã sx được xác nhận' })
  @Expose()
  @Type(() => Number)
  confirmedQuantity: number;

  @ApiProperty({
    example: 100,
    description: 'Tổng số sản phẩm lỗi đã sx - phế liệu',
  })
  @Expose()
  @Type(() => Number)
  scrapQuantity: number;

  @ApiProperty({
    example: 100,
    description: 'Tổng số sản phẩm xuất công đoạn',
  })
  @Expose()
  @Type(() => Number)
  exportQuantity: number;

  @ApiProperty({ example: 100, description: 'Số lượng chưa qc' })
  @Expose()
  @Type(() => Number)
  totalUnQcQuantity: number;

  @ApiProperty({ example: 100, description: 'Số lượng qc lỗi' })
  @Expose()
  @Type(() => Number)
  totalQcRejectQuantity: number;

  @ApiProperty({ example: 100, description: 'Số lượng pass qc' })
  @Expose()
  @Type(() => Number)
  totalQcPassQuantity: number;

  @ApiProperty({ example: 100, description: 'Số lượng pass qc' })
  @Expose()
  @Type(() => Number)
  totalQcQuantity: number;

  @Expose()
  @Type(() => Boolean)
  hasSchedule: boolean;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  planFrom: Date;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  planTo: Date;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  moId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  routingId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  workCenterId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  moPlanId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  moDetailId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  moPlanBomId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  producingStepId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  bomId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  approverId: number;

  @ApiProperty({ description: '' })
  @Expose()
  canStart: number;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  approvedAt: Date;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  createdAt: Date;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: ManufacturingRequestOrderResponse })
  @Expose()
  @Type(() => ManufacturingRequestOrderResponse)
  manufacturingRequestOrder: ManufacturingRequestOrderResponse;

  @ApiProperty({ type: MoResponse })
  @Expose()
  @Type(() => MoResponse)
  mo: MoResponse;

  @ApiProperty({ type: MoPlanResponse })
  @Expose()
  @Type(() => MoPlanResponse)
  moPlan: MoPlanResponse;

  @ApiProperty({ type: MoDetailResponse })
  @Expose()
  @Type(() => MoDetailResponse)
  moDetail: MoDetailResponse;

  @ApiProperty({ type: BomResponse })
  @Expose()
  @Type(() => BomResponse)
  bom: BomResponse | any;

  @ApiProperty({ type: MoPlanBomResponse })
  @Expose()
  @Type(() => MoPlanBomResponse)
  moPlanBom: MoPlanBomResponse;

  @ApiProperty({ type: ProducingStepResponse })
  @Expose()
  @Type(() => ProducingStepResponse)
  producingStep: ProducingStepResponse;

  @ApiProperty({ type: [WorkCenterResponseAbstractDto] })
  @Expose()
  @Type(() => WorkCenterResponseAbstractDto)
  workCenters: WorkCenterResponseAbstractDto[];

  @ApiProperty({ type: RoutingResponse })
  @Expose()
  @Type(() => RoutingResponse)
  routing: RoutingResponse;

  @ApiProperty({ type: RoutingVersionResponse })
  @Expose()
  @Type(() => RoutingVersionResponse)
  routingVersion: RoutingVersionResponse;

  @ApiProperty({ type: UserResponse })
  @Expose()
  @Type(() => UserResponse)
  approver: UserResponse;

  @ApiProperty({ type: FactoryResponse })
  @Expose()
  @Type(() => FactoryResponse)
  factory: FactoryResponse;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  startAt: Date;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  endAt: Date;

  @Expose()
  @Type(() => WorkCenter)
  workCenter: WorkCenter;
}
