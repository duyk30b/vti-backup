import { WorkOrderResponseAbstractDto } from '@components/work-order/dto/response/work-order.response.abstract.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';
import { FormatCodeWorkOrder } from '@components/work-order/work-order.constant';

class data extends WorkOrderResponseAbstractDto {
  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  @Transform((data) => FormatCodeWorkOrder + data.value)
  code: string;
}
export class WorkOrderResponseDto extends SuccessResponse {
  @ApiProperty({ type: WorkOrderResponseAbstractDto })
  @Expose()
  @Type(() => WorkOrderResponseAbstractDto)
  data: data;
}
