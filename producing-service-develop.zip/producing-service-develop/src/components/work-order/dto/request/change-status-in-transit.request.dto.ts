import { BaseDto } from '@core/dto/base.dto';
import { IsInt } from 'class-validator';

export class ChangeStatusInTransitRequestDto extends BaseDto {
  @IsInt()
  id: number;
}
