import { WorkOrderRequestAbstractDto } from '@components/work-order/dto/request/work-order.request.abstract.dto';

export class CreateWorkOrderRequestDto extends WorkOrderRequestAbstractDto {}
