import { IoTRequestDto } from '@core/dto/request/iot.request.dto';

export class ProduceMonitoringRequestDto extends IoTRequestDto {}
