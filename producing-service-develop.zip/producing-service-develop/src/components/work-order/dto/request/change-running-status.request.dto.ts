import { WorkOrderRunningStatusEnum } from '@components/work-order/work-order.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsEnum, IsInt } from 'class-validator';

export class ChangeRunningStatusRequestDto extends BaseDto {
  @IsOptional()
  id: number;

  @IsInt()
  @IsOptional()
  workCenterId: number;

  @ApiProperty({ description: '0: Stop, 1: Running, 2: Pause' })
  @IsEnum(WorkOrderRunningStatusEnum)
  status: number;
}
