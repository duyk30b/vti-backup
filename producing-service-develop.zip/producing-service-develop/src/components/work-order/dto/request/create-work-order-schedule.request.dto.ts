import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsInt,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { BaseDto } from '@core/dto/base.dto';

export class WorkOrderScheduleDetailDto {
  @ApiProperty()
  @IsInt()
  workCenterId: number;

  @ApiProperty()
  @IsNumber()
  @IsPositive()
  quantity: number;
}

export class CreateWorkOrderScheduleRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  @IsOptional()
  workOrderId: number;

  @ApiProperty({
    description: 'Chi tiết lịch làm việc',
    isArray: true,
    type: WorkOrderScheduleDetailDto,
  })
  @IsArray()
  @ValidateNested()
  @ArrayUnique((e: WorkOrderScheduleDetailDto) => e.workCenterId)
  @ArrayNotEmpty()
  scheduleDetails: WorkOrderScheduleDetailDto[];

  @ApiProperty()
  @IsString()
  @IsOptional()
  @MaxLength(255)
  description: string;
}
