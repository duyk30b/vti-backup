import { BaseDto } from '@core/dto/base.dto';
import { IsInt, IsNotEmpty } from 'class-validator';

export class GetDetailInTransitRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsInt()
  id: number;
}
