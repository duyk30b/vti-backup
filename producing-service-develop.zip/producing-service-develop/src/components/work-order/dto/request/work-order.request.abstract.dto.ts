import { ApiProperty } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsString,
  MaxLength,
  IsInt,
  IsOptional,
  IsPositive,
  IsNumber,
  IsDateString,
  Min,
  Max,
} from 'class-validator';
import { decimal } from '@utils/common';

import { BaseDto } from '@core/dto/base.dto';

export class WorkOrderRequestAbstractDto extends BaseDto {
  @ApiProperty({ example: 'work order 1', description: 'name' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiProperty({ example: 1, description: 'boq id' })
  @IsNotEmpty()
  @IsInt()
  moId: number;

  @ApiProperty({ example: 1, description: 'routing id' })
  @IsNotEmpty()
  @IsInt()
  routingId: number;

  @ApiProperty({ example: 1, description: 'work center id' })
  @IsOptional()
  @IsInt()
  workCenterId: number;

  @ApiProperty({ example: 1, description: 'boq plan id' })
  @IsNotEmpty()
  @IsInt()
  moPlanId: number;

  @ApiProperty({ example: 1, description: 'boq detail id' })
  @IsNotEmpty()
  @IsInt()
  moDetailId: number;

  @ApiProperty({ example: 1, description: 'producing step id' })
  @IsNotEmpty()
  @IsInt()
  producingStepId: number;

  @ApiProperty({ example: 1, description: 'bom id' })
  @IsNotEmpty()
  @IsInt()
  bomId: number;

  @ApiProperty({ example: 1, description: 'boq plan bom id' })
  @IsOptional()
  @IsInt()
  moPlanBomId: number;

  @ApiProperty({
    example: '2021-07-13 09:13:15.562609+00',
    description: 'plan from',
  })
  @IsDateString()
  @IsNotEmpty()
  planFrom: Date;

  @ApiProperty({
    example: '2021-07-13 09:13:15.562609+00',
    description: 'plan to',
  })
  @IsDateString()
  @IsNotEmpty()
  planTo: Date;

  @ApiProperty({ example: 400.2, description: 'quantity' })
  @IsNotEmpty()
  @IsNumber()
  @IsPositive()
  @Min(0)
  @Max(decimal(10, 2))
  quantity: number;

  @ApiProperty({ example: 'description', description: 'description' })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;
}
