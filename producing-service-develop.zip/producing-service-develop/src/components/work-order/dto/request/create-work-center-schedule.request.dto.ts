import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  MaxLength,
  ValidateNested,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { BaseDto } from '@core/dto/base.dto';
import { Type } from 'class-transformer';

export class WorkCenterScheduleShiftDetailDto {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  workCenterShiftId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @IsPositive()
  quantity: number;
}

export class WorkCenterScheduleDetailDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  executionDay: Date;

  @ApiProperty({
    description: 'Chi tiết ca làm việc',
    isArray: true,
    type: WorkCenterScheduleShiftDetailDto,
  })
  @Type(() => WorkCenterScheduleShiftDetailDto)
  @IsArray()
  @ArrayNotEmpty()
  @ValidateNested({ each: true })
  @ArrayUnique((e: WorkCenterScheduleShiftDetailDto) => e.workCenterShiftId)
  scheduleShiftDetails: WorkCenterScheduleShiftDetailDto[];
}

class ScheduleDetailDto {
  @ApiProperty({
    isArray: true,
    type: WorkCenterScheduleDetailDto,
  })
  @IsArray()
  @ArrayNotEmpty()
  @ValidateNested({ each: true })
  @ArrayUnique((e: WorkCenterScheduleDetailDto) => e.executionDay)
  workCenterScheduleDetails: WorkCenterScheduleDetailDto[];

  @ApiProperty({
    isArray: true,
    type: WorkCenterScheduleDetailDto,
  })
  @IsArray()
  @ArrayNotEmpty()
  @ValidateNested({ each: true })
  @ArrayUnique((e: WorkCenterScheduleDetailDto) => e.executionDay)
  workCenterRepairScheduleDetails: WorkCenterScheduleDetailDto[];
}

export class CreateWorkCenterScheduleRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  @IsOptional()
  id: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  workOrderId: number;

  @ApiProperty({
    description: 'Chi tiết lịch làm việc',
    isArray: true,
    type: ScheduleDetailDto,
  })
  @IsNotEmpty()
  scheduleDetails: ScheduleDetailDto;

  @ApiProperty()
  @IsString()
  @IsOptional()
  @MaxLength(255)
  description: string;

  @ApiProperty()
  @IsNumber()
  @IsOptional()
  status: number;
}
