import { PaginationQuery } from '@utils/pagination.query';

export class GetListWorkOrderTransactionRequestDto extends PaginationQuery {}
