import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsDecimal, IsInt, IsNotEmpty, IsOptional, IsNumber } from 'class-validator';

export class AutocompleteRequestDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'id' })
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty({ example: 1, description: 'id' })
  @IsOptional()
  @IsDecimal()
  quantity: number;

  @ApiProperty({ example: 1, description: 'id' })
  @IsOptional()
  @IsInt()
  workCenterId: number;

  @IsOptional()
  @IsNumber()
  rejectQuantity: number;

  @IsOptional()
  @IsNumber()
  passQuantity: number;
}

