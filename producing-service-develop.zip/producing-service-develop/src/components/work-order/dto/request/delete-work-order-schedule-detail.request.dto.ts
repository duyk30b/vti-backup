import { IsInt, IsNotEmpty } from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';

export class DeleteWorkOrderScheduleDetailRequestDto extends BaseDto {
  @IsInt()
  @IsNotEmpty()
  id: number;

  @IsInt()
  @IsNotEmpty()
  workCenterId: number;
}
