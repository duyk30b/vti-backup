import {
  IsNotEmpty,
  IsInt,
  IsNumber,
  IsString,
  IsDateString,
} from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional } from 'class-validator';

export class UpdateQualityControlWorkOrderRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  passQuantity: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  rejectQuantity: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  note: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  userId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  workCenterId: number;

  @ApiProperty({
    description: 'execution day',
  })
  @IsNotEmpty()
  @IsDateString()
  executionDay: Date;
}
