import { IsInt, IsOptional } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { Transform } from 'class-transformer';

export class GetWorkOrderLogTimeRequestDto extends BaseDto {
  @IsOptional()
  @IsInt()
  id: number;

  @IsInt()
  @Transform(({ value }) => Number(value))
  workCenterId: number;
}
