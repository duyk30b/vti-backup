import {
  ValidateNested,
  ArrayUnique,
  IsArray,
  IsNumber,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { Type } from 'class-transformer';
import { BaseDto } from '@core/dto/base.dto';

class MaterialItemDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  productionOrderDetailId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  quantity: number;
}

export class ImportWorkOrderMaterialInputRequestDto extends BaseDto {
  @ApiProperty({
    description: 'Id Work order',
  })
  @IsInt()
  id: number;

  @ApiProperty({
    description: 'Đơn sản xuất nhập nguyên vật liệu',
  })
  @IsInt()
  productionOrderId: number;

  @ApiProperty({
    description: 'Đầu vào',
    isArray: true,
    type: MaterialItemDto,
  })
  @ValidateNested()
  @ArrayUnique((e: MaterialItemDto) => e.itemId)
  @IsArray()
  @Type(() => MaterialItemDto)
  materialItems: MaterialItemDto[];
}
