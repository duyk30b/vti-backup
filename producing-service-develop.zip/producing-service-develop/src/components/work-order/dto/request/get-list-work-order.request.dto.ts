import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsArray, IsEnum, IsOptional, isString } from 'class-validator';
import { Transform } from 'class-transformer';

export class GetListWorkOrderRequestDto extends PaginationQuery {
  @ApiPropertyOptional({
    example: '[{"id": "1", "itemId": "2"}]',
  })
  @IsOptional()
  @IsArray()
  @Transform((e) => {
    if (isString(e.value)) {
      e.value = e.value.replace(/'/g, '"');
      return JSON.parse(e.value);
    }
    return e.value;
  })
  queryIds?: any[];
}
