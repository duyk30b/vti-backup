import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform } from 'class-transformer';
import { IsInt } from 'class-validator';

export class LogTimeByWoIdsRequestDto extends BaseDto {
  @ApiProperty()
  @Expose()
  @Transform(({ value }) => value.split(',').map((id) => Number(id)))
  ids: number[];

  @ApiProperty()
  @IsInt()
  @Expose()
  workCenterId: number;
}
