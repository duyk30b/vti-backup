import { BaseDto } from '@core/dto/base.dto';
import {
  IsDateString,
  IsInt,
  IsNumber,
  IsOptional,
  Min,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class SubmitWorkOrderProgressRequestDto extends BaseDto {
  @IsOptional()
  @IsInt()
  id: number;

  @IsOptional()
  @IsInt()
  createdByUserId: number;

  @ApiProperty({ description: 'ID thiết bị' })
  @IsInt()
  workCenterId: number;

  @ApiProperty({
    description: 'SL sản xuất',
  })
  @IsNumber()
  @Min(0)
  quantity: number;

  @ApiPropertyOptional({
    description: 'SL sửa lại',
  })
  @IsOptional()
  @IsNumber()
  @Min(0)
  repairQuantity: number;

  @ApiPropertyOptional({
    description: 'SL đạt',
  })
  @IsOptional()
  @IsNumber()
  @Min(0)
  passQuantity: number;

  @ApiPropertyOptional({
    description: 'SL lỗi',
  })
  @IsOptional()
  @IsNumber()
  @Min(0)
  rejectQuantity: number;

  @ApiPropertyOptional({ description: 'Bắt đầu' })
  @IsOptional()
  @IsDateString()
  start: Date;

  @ApiPropertyOptional({ description: 'Kết thúc' })
  @IsOptional()
  @IsDateString()
  end: Date;

  @ApiProperty({
    description: 'work center id',
  })
  @IsDateString()
  executionDay: Date;
}
