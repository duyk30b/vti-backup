import { BaseDto } from './../../../../core/dto/base.dto';
import { IsNotEmpty, IsString } from 'class-validator';

export class ScanWorkOrderRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsString()
  qrCode: string;
}
