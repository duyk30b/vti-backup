import { BaseDto } from '@core/dto/base.dto';
import {
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  MaxLength,
} from 'class-validator';

export class SubmitWorkOrderExportRequestDto extends BaseDto {
  @IsOptional()
  @IsInt()
  id: number;

  @IsNotEmpty()
  @IsInt()
  workCenterId: number;

  @IsOptional()
  @IsInt()
  createdByUserId: number;

  @IsNotEmpty()
  @IsInt()
  toProducingStepId: number;

  @IsNotEmpty()
  @IsNumber()
  @IsPositive()
  quantity: number;

  @IsNotEmpty()
  @IsDateString()
  exportDate: Date;

  @IsOptional()
  @IsString()
  @MaxLength(255)
  note: string;
}
