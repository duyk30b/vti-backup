import { WorkOrderRequestAbstractDto } from '@components/work-order/dto/request/work-order.request.abstract.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsOptional } from 'class-validator';

export class UpdateWorkOrderRequestDto extends WorkOrderRequestAbstractDto {
  @ApiProperty({ example: 1, description: 'id' })
  @IsOptional()
  @IsInt()
  id: number;
}
