import { BaseDto } from '@core/dto/base.dto';
import { IsInt, IsNotEmpty } from 'class-validator';

export class GetDetailWorkOrderByBomAndProducingStepRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsInt()
  bomId: number;

  @IsNotEmpty()
  @IsInt()
  producingStepId: number;
}
