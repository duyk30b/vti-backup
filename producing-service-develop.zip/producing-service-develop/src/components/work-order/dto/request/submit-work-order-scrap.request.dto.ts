import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  ArrayUnique,
  IsArray,
  IsInt,
  IsNumber,
  IsOptional,
  IsPositive,
  ValidateNested,
} from 'class-validator';

class ScrapMaterial {
  @ApiProperty({
    description: 'ID',
  })
  @IsInt()
  itemId: number;

  @ApiProperty({
    description: 'Số lượng',
  })
  @IsNumber()
  @IsPositive()
  quantity: number;
}

export class SubmitWorkOrderScrapRequestDto extends BaseDto {
  @IsOptional()
  @IsInt()
  id: number;

  @IsInt()
  workCenterId: number;

  @IsOptional()
  @IsInt()
  createdByUserId: number;

  @ApiProperty({
    description: 'Khối lượng phế liệu',
  })
  @IsOptional()
  @IsNumber()
  @IsPositive()
  quantity: number;

  @ApiProperty({
    description: 'Nguyên vật liệu',
    isArray: true,
    type: ScrapMaterial,
  })
  @IsArray()
  @ValidateNested()
  @ArrayUnique((e: ScrapMaterial) => e.itemId)
  scrapMaterials: ScrapMaterial[];
}
