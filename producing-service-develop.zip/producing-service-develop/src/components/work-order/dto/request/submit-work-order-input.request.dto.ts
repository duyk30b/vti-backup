import { BaseDto } from 'src/core/dto/base.dto';
import {
  ValidateNested,
  ArrayUnique,
  IsArray,
  IsNumber,
  IsPositive,
  IsOptional,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt } from 'class-validator';
import { Type } from 'class-transformer';

class MaterialItemDto {
  @IsInt()
  itemId: number;

  @IsNumber()
  @IsPositive()
  quantity: number;
}

export class SubmitWorkOrderInputRequestDto extends BaseDto {
  @IsOptional()
  @IsInt()
  id: number;

  @IsOptional()
  @IsInt()
  createdByUserId: number;

  @IsInt()
  workCenterId: number;

  @ApiProperty({
    description: 'Đầu vào',
  })
  @ValidateNested()
  @ArrayUnique((e: MaterialItemDto) => e.itemId)
  @IsArray()
  @Type(() => MaterialItemDto)
  materialItems: MaterialItemDto[];
}
