import { PaginationQuery } from '@utils/pagination.query';

export class GetListInTransitRequestDto extends PaginationQuery {}
