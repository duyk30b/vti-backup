import { IsInt, IsNotEmpty } from 'class-validator';
import { BaseDto } from '../../../../core/dto/base.dto';

export class GetDetailWorkOrderBomTransitHistoryRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsInt()
  id: number;
}
