import { IsDateString, IsOptional } from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsInt,
  IsPositive,
  IsString,
  MaxLength,
  IsNumber,
} from 'class-validator';

export class ImportInTransitRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsInt()
  workOrderId: number;

  @ApiProperty()
  @IsInt()
  workCenterId: number;

  @ApiProperty()
  @IsInt()
  @IsOptional()
  createdByUserId: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @MaxLength(255)
  note: string;

  @ApiProperty()
  @IsNumber()
  @IsPositive()
  quantity: number;

  @ApiProperty()
  @IsDateString()
  importDate: Date;
}
