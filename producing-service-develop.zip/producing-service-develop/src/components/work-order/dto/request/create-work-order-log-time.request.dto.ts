import { IsInt, IsDateString, IsNumber, IsOptional } from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { BaseDto } from '@core/dto/base.dto';

export class CreateWorkOrderLogTimeRequestDto extends BaseDto {
  @IsOptional()
  @IsInt()
  id: number;

  @IsInt()
  userId: number;

  @ApiPropertyOptional({ description: 'Bắt đầu' })
  @IsOptional()
  @IsDateString()
  start: Date;

  @ApiPropertyOptional({ description: 'Kết thúc' })
  @IsOptional()
  @IsDateString()
  end: Date;

  @ApiPropertyOptional({ description: 'Pause' })
  @IsOptional()
  @IsDateString()
  pause: Date;

  @ApiPropertyOptional({ description: 'Play' })
  @IsOptional()
  @IsDateString()
  play: Date;

  @ApiPropertyOptional({ description: 'Thời gian thực hiện' })
  @IsOptional()
  @IsNumber()
  duration: number;

  @IsInt()
  workCenterId: number;
}
