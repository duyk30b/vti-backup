import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WorkCenterUserEntity } from '@entities/work-center/work-center-user.entity';

export interface WorkCenterUserRepositoryInterface
  extends BaseInterfaceRepository<WorkCenterUserEntity> {
  createEntity(data: any): WorkCenterUserEntity;
  isExist(request: any): Promise<any>;
}
