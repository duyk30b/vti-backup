import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WorkCenterShiftRelaxTimeEntity } from '@entities/work-center/work-center-shift-relax-time.entity';

export type WorkCenterShiftRelaxTimeRepositoryInterface =
  BaseInterfaceRepository<WorkCenterShiftRelaxTimeEntity>;
