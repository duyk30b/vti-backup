import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WorkCenterEntity } from '@entities/work-center/work-center.entity';
import { GetListWorkCenterRequestDto } from '../dto/request/get-list-work-center.request.dto';
import { GetListPlcBomItemRequestDto } from '../dto/request/get-list-plc-bom-item.request.dto';

export interface WorkCenterRepositoryInterface
  extends BaseInterfaceRepository<WorkCenterEntity> {
  createVirtualEntities(
    workCenter: WorkCenterEntity,
    producingSteps?: any[],
  ): any;
  getDetail(id: number, baseInfo?: boolean): Promise<any>;
  getList(request: GetListWorkCenterRequestDto, factories: any): Promise<any>;
  createEntity(data: any): WorkCenterEntity;
  updateEntity(workCenterEntity: WorkCenterEntity, data: any): WorkCenterEntity;
  getWorkCenterByWorkOrderSchedule(
    workCenterId: number,
    workOrderScheduleDetailId: number,
  ): Promise<any>;
  getWorkCenterNotInIds(
    factoryId: number,
    notWorkCenterIds: number[],
    producingStepId: number,
  );
  getWorkCenterByProStepIds(
    producingStepIds: any[],
    factoryId: any,
  ): Promise<any>;
}
