import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WorkCenterDailyScheduleEntity } from '@entities/work-center/work-center-daily-schedule.entity';

export interface WorkCenterDailyScheduleRepositoryInterface
  extends BaseInterfaceRepository<WorkCenterDailyScheduleEntity> {
  createEntity(data: any): WorkCenterDailyScheduleEntity;
  getListByWorkOrderScheduleDetail(
    workCenterId: number,
    workOrderScheduleDetailId: number,
  ): Promise<any>;
  getWorkCenterDailyScheduleByCondition(condition: any): Promise<any>;
}
