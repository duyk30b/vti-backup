import { CreateWorkCenterScheduleRequestDto } from '@components/work-order/dto/request/create-work-center-schedule.request.dto';
import { DetailRequestDto } from '@utils/common.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { CreateWorkCenterShiftRequestDto } from '../dto/request/create-work-center-shift.dto';
import { CreateWorkCenterRequestDto } from '../dto/request/create-work-center.request.dto';
import { DeleteWorkCenterDailyScheduleRequestDto } from '../dto/request/delete-work-center-daily-schedule.request.dto';
import { GetListWorkCenterRequestDto } from '../dto/request/get-list-work-center.request.dto';
import { UpdateWorkCenterScheduleStatusRequestDto } from '../dto/request/update-work-center-schedule-status.request.dto';
import { UpdateWorkCenterRequestDto } from '../dto/request/update-work-center.request.dto';
import { GetListWorkCenterResponseDto } from '../dto/response/get-list-work-center.response.dto';
import { WorkCenterResponseDto } from '../dto/response/work-center.response.dto';
import { SetStatusRequestDto } from '@components/work-center/dto/request/set-status.request.dto';
import { GetListPlcBomItemRequestDto } from '../dto/request/get-list-plc-bom-item.request.dto';

export interface WorkCenterServiceInterface {
  setRunningStatus(id: number, moBomId: number, payload: any): any;
  getBomItemListPlc(
    request: GetListPlcBomItemRequestDto,
  ): ResponsePayload<any> | PromiseLike<ResponsePayload<any>>;
  getBomItemDetailPlc(
    id: number,
    moBomId: number,
  ): ResponsePayload<any> | PromiseLike<ResponsePayload<any>>;
  create(
    request: CreateWorkCenterRequestDto,
  ): Promise<ResponsePayload<WorkCenterResponseDto | any>>;
  update(
    request: UpdateWorkCenterRequestDto,
  ): Promise<ResponsePayload<WorkCenterResponseDto | any>>;
  delete(id: number): Promise<ResponsePayload<SuccessResponse | any>>;
  detail(
    id: number,
    baseInfo?: boolean,
  ): Promise<ResponsePayload<WorkCenterResponseDto | any>>;
  confirm(request: SetStatusRequestDto): Promise<ResponsePayload<any>>;
  reject(request: SetStatusRequestDto): Promise<ResponsePayload<any>>;
  getList(
    request: GetListWorkCenterRequestDto,
  ): Promise<ResponsePayload<GetListWorkCenterResponseDto | any>>;
  createWorkCenterShift(
    request: CreateWorkCenterShiftRequestDto,
  ): Promise<ResponsePayload<any>>;
  deleteWorkCenterShift(id: number): Promise<ResponsePayload<any>>;
  createWorkCenterSchedule(
    payload: CreateWorkCenterScheduleRequestDto,
  ): Promise<any>;
  getDailySchedule(workCenterId: number, workOrderDetailId: number);
  genAndSaveDailySchedule(workCenterId: number, workOrderDetailId: number);
  approveWorkCenterSchedule(payload: UpdateWorkCenterScheduleStatusRequestDto);
  rejectWorkCenterSchedule(payload: UpdateWorkCenterScheduleStatusRequestDto);
  deleteWorkCenterDailySchedule(
    payload: DeleteWorkCenterDailyScheduleRequestDto,
  );
  isExist(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<WorkCenterResponseDto | any>>;
  getWorkCenterByIds(ids: number[]): Promise<any>;
  saveWorkCenters(request: any): Promise<any>;
}
