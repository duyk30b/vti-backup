import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WorkCenterDailyScheduleShiftEntity } from '@entities/work-center/work-center-daily-schedule-shift.entity';

export interface WorkCenterDailyScheduleShiftRepositoryInterface
  extends BaseInterfaceRepository<WorkCenterDailyScheduleShiftEntity> {
  createEntity(data: any): WorkCenterDailyScheduleShiftEntity;
}
