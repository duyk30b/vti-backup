import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { WorkCenterShiftEntity } from '@entities/work-center/work-center-shift.entity';

export interface WorkCenterShiftRepositoryInterface
  extends BaseInterfaceRepository<WorkCenterShiftEntity> {
  createEntity(data: any): WorkCenterShiftEntity;
  createEntities(data: any[]): WorkCenterShiftEntity[];

  getWorkCenterShiftByWorkCenterIdGroupping(
    workCenterIds: number[],
  ): Promise<any[]>;
}
