import { ProducingStepEntity } from '@entities/producing-step/producing-step.entity';
import { ProducingStepRepository } from '@repositories/produce/producing-step.repository';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { WorkCenterDailyScheduleShiftEntity } from '@entities/work-center/work-center-daily-schedule-shift.entity';
import { WorkCenterDailyScheduleEntity } from '@entities/work-center/work-center-daily-schedule.entity';
import { WorkCenterShiftRelaxTimeEntity } from '@entities/work-center/work-center-shift-relax-time.entity';
import { WorkCenterShiftEntity } from '@entities/work-center/work-center-shift.entity';
import { WorkCenterUserEntity } from '@entities/work-center/work-center-user.entity';
import { WorkCenterEntity } from '@entities/work-center/work-center.entity';
import { WorkOrderScheduleDetailEntity } from '@entities/work-order/work-order-schedule-detail.entity';
import { Module, forwardRef } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WorkCenterShiftRelaxTimeRepository } from '@repositories/work-center/work-center-shift-relax-time.repository';
import { WorkCenterShiftRepository } from '@repositories/work-center/work-center-shift.repository';
import { WorkCenterDailyScheduleShiftRepository } from '@repositories/work-center/work-center-daily-schedule-shift.repository';
import { WorkCenterDailyScheduleRepository } from '@repositories/work-center/work-center-daily-schedule.repository';
import { WorkCenterUserRepository } from '@repositories/work-center/work-center-user.repository';
import { WorkCenterRepository } from '@repositories/work-center/work-center.repository';
import { WorkOrderScheduleDetailRepository } from '@repositories/work-order/work-order-schedule-detail.repository';
import { WorkCenterController } from './work-center.controller';
import { WorkCenterService } from './work-center.service';
import { WorkOrderRepository } from '@repositories/work-order/work-order.repository';
import { WorkOrderEntity } from '@entities/work-order/work-order.entity';
import { QualityControlService } from '@components/qmx/quality-control.service';
import { ItemService } from '@components/item/item.service';
import { MmsModule } from '@components/mms/mms.module';
import { MmsService } from '@components/mms/mms.service';
import { ConfigModule } from '@nestjs/config';
import { RoutingEntity } from '@entities/routing/routing.entity';
import { RoutingRepository } from '@repositories/routing.repository';
import { WorkCenterListener } from './listeners/work-center.listener';
import { DeviceService } from '@components/device/device.service';
import { MoPlanBomEntity } from '@entities/manufacturing-order/mo-plan-boms.entity';
import { MoPlanBomRepository } from '@repositories/plan/mo-plan-bom.repository';
import { WorkOrderRunningLogsRepository } from '@repositories/work-order/work-order-running-logs.repository';
import { WorkOrderRunningLogsEntity } from '@entities/work-order/work-order-running-logs.entity';

@Module({
  imports: [
    ConfigModule,
    TypeOrmModule.forFeature([
      WorkCenterEntity,
      MoPlanBomEntity,
      WorkCenterUserEntity,
      WorkOrderRunningLogsEntity,
      WorkCenterShiftEntity,
      WorkCenterShiftRelaxTimeEntity,
      WorkOrderScheduleDetailEntity,
      WorkCenterDailyScheduleEntity,
      WorkCenterDailyScheduleShiftEntity,
      ProducingStepEntity,
      RoutingEntity,
      WorkOrderEntity,
    ]),
    UserModule,
    MmsModule,
  ],
  providers: [
    {
      provide: 'WorkCenterRepositoryInterface',
      useClass: WorkCenterRepository,
    },
    {
      provide: 'MoPlanBomRepositoryInterface',
      useClass: MoPlanBomRepository,
    },
    {
      provide: 'WorkOrderRunningLogsRepositoryInterface',
      useClass: WorkOrderRunningLogsRepository,
    },
    {
      provide: 'WorkOrderRepositoryInterface',
      useClass: WorkOrderRepository,
    },
    {
      provide: 'WorkOrderScheduleDetailRepositoryInterface',
      useClass: WorkOrderScheduleDetailRepository,
    },
    {
      provide: 'WorkCenterDailyScheduleShiftRepositoryInterface',
      useClass: WorkCenterDailyScheduleShiftRepository,
    },
    {
      provide: 'WorkCenterDailyScheduleRepositoryInterface',
      useClass: WorkCenterDailyScheduleRepository,
    },
    {
      provide: 'WorkCenterServiceInterface',
      useClass: WorkCenterService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'DeviceServiceInterface',
      useClass: DeviceService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'WorkCenterUserRepositoryInterface',
      useClass: WorkCenterUserRepository,
    },
    {
      provide: 'WorkCenterShiftRepositoryInterface',
      useClass: WorkCenterShiftRepository,
    },
    {
      provide: 'WorkCenterShiftRelaxTimeRepositoryInterface',
      useClass: WorkCenterShiftRelaxTimeRepository,
    },
    {
      provide: 'ProducingStepRepositoryInterface',
      useClass: ProducingStepRepository,
    },
    {
      provide: 'RoutingRepositoryInterface',
      useClass: RoutingRepository,
    },
    {
      provide: 'QmsxServiceInterface',
      useClass: QualityControlService,
    },
    {
      provide: 'MmsServiceInterface',
      useClass: MmsService,
    },
    WorkCenterListener,
  ],
  controllers: [WorkCenterController],
  exports: [
    {
      provide: 'WorkCenterRepositoryInterface',
      useClass: WorkCenterRepository,
    },
    {
      provide: 'WorkOrderRepositoryInterface',
      useClass: WorkOrderRepository,
    },
    {
      provide: 'WorkOrderRunningLogsRepositoryInterface',
      useClass: WorkOrderRunningLogsRepository,
    },
    {
      provide: 'WorkOrderScheduleDetailRepositoryInterface',
      useClass: WorkOrderScheduleDetailRepository,
    },
    {
      provide: 'WorkCenterDailyScheduleShiftRepositoryInterface',
      useClass: WorkCenterDailyScheduleShiftRepository,
    },
    {
      provide: 'WorkCenterDailyScheduleRepositoryInterface',
      useClass: WorkCenterDailyScheduleRepository,
    },
    {
      provide: 'WorkCenterServiceInterface',
      useClass: WorkCenterService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'WorkCenterUserRepositoryInterface',
      useClass: WorkCenterUserRepository,
    },
    {
      provide: 'WorkCenterShiftRepositoryInterface',
      useClass: WorkCenterShiftRepository,
    },
    {
      provide: 'WorkCenterShiftRelaxTimeRepositoryInterface',
      useClass: WorkCenterShiftRelaxTimeRepository,
    },
    {
      provide: 'ProducingStepRepositoryInterface',
      useClass: ProducingStepRepository,
    },
    {
      provide: 'QmsxServiceInterface',
      useClass: QualityControlService,
    },
    {
      provide: 'MmsServiceInterface',
      useClass: MmsService,
    },
    {
      provide: 'RoutingRepositoryInterface',
      useClass: RoutingRepository,
    },
    {
      provide: 'DeviceServiceInterface',
      useClass: DeviceService,
    },
    {
      provide: 'MoPlanBomRepositoryInterface',
      useClass: MoPlanBomRepository,
    },
  ],
})
export class WorkCenterModule {}
