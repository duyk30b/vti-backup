export enum WorkCenterDailyScheduleStatusEnum {
  CREATED = 0,
  REJECTED = 1,
  CONFIRMED = 2,
  IN_PROGRESS = 3,
  COMPLETED = 4,
}

export enum QcCriteriaFormalityEnum {
  ALL = 0,
  PERCENTAGE = 1,
}

export enum WorkCenterTypeEnum {
  NORMAL = 0,
  PLC = 1,
}

export enum QcNumberOfTimeEnum {
  ONE = 0,
  TWO = 1,
}

export const CAN_CONFIRM_WORK_CENTER_DAILY_SCHEDULE_STATUS: number[] = [
  WorkCenterDailyScheduleStatusEnum.CREATED,
  WorkCenterDailyScheduleStatusEnum.REJECTED,
];

export const CAN_REJECT_WORK_CENTER_DAILY_SCHEDULE_STATUS: number[] = [
  WorkCenterDailyScheduleStatusEnum.CREATED,
];

export const CAN_DELETE_WORK_CENTER_DAILY_SCHEDULE_STATUS: number[] = [
  WorkCenterDailyScheduleStatusEnum.CREATED,
  WorkCenterDailyScheduleStatusEnum.REJECTED,
];

export enum WorkCenterStatusEnum {
  CREATED,
  REJECTED,
  CONFIRMED,
  IN_PROGRESS,
  COMPLETE,
}

export const CAN_CONFIRM_WORK_CENTER_STATUS: number[] = [
  WorkCenterStatusEnum.CREATED,
  WorkCenterStatusEnum.REJECTED,
];

export const CAN_REJECT_WORK_CENTER_STATUS: number[] = [
  WorkCenterDailyScheduleStatusEnum.CREATED,
];

export const CAN_DELETE_WORK_CENTER_STATUS: number[] = [
  WorkCenterDailyScheduleStatusEnum.CREATED,
  WorkCenterDailyScheduleStatusEnum.REJECTED,
];
