import { Inject, Injectable, Logger } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { DeviceServiceInterface } from '@components/device/interface/device.service.interface';
import { ConfigService } from '@config/config.service';

@Injectable()
export class WorkCenterListener {
  private configService;
  private readonly logger = new Logger(WorkCenterListener.name);

  constructor(
    @Inject('DeviceServiceInterface')
    protected readonly deviceService: DeviceServiceInterface,
  ) {
    this.configService = new ConfigService();
  }

  /**
   *
   * @param param0
   * @returns
   */
  @OnEvent('work-center.confirmed')
  public async checkAndGenPro(workCenter) {
    const isIotEnable = this.configService.get('modules')?.iotEnable;
    if (isIotEnable) {
      try {
        const r = await this.deviceService.registerIotDevice(workCenter);
        this.logger.debug('IOT_DEVICE: Register device:', {
          workCenter: workCenter,
          response: r,
        });
      } catch (e) {
        this.logger.error(`IOT_DEVICE: Register device error:'`, e);
      }
    }

    return;
  }
}
