import { IsInt, IsOptional } from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';

export class DeleteWorkCenterDailyScheduleRequestDto extends BaseDto {
  @IsInt()
  @IsOptional()
  id: number;

  @IsInt()
  @IsOptional()
  workOrderScheduleDetailId: number;
}
