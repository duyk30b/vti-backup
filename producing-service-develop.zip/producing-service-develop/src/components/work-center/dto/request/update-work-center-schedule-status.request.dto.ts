import { BaseDto } from '@core/dto/base.dto';
import { Expose } from 'class-transformer';
import { IsInt, IsNotEmpty, IsOptional } from 'class-validator';

export class UpdateWorkCenterScheduleStatusRequestDto extends BaseDto {
  @Expose()
  @IsOptional()
  @IsInt()
  id: number;

  @Expose()
  @IsOptional()
  @IsInt()
  scheduleId: number;

  @Expose()
  @IsNotEmpty()
  @IsInt()
  userId: number;
}
