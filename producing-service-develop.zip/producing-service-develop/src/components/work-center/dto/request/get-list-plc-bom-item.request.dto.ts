import { PaginationQuery } from '@utils/pagination.query';
import { IsNumber, IsOptional } from 'class-validator';

export class GetListPlcBomItemRequestDto extends PaginationQuery {
  @IsOptional()
  @IsNumber()
  id: number;
}
