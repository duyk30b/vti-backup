import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsNotEmpty,
  IsString,
  MaxLength,
  IsInt,
  IsOptional,
  ArrayNotEmpty,
  IsArray,
  ValidateNested,
  IsMilitaryTime,
  IsNumber,
} from 'class-validator';

export class WorkCenterShift {
  @ApiProperty({ example: 'ca 1', description: 'tên ca' })
  @IsString()
  @MaxLength(255)
  @IsNotEmpty({ message: 'Tên ca làm việc không được trống' })
  name: string;

  @ApiProperty({ example: '06:00', description: 'thời gian bắt đầu ca' })
  @IsNotEmpty({ message: 'Thời gian bắt đầu ca không được trống' })
  @IsMilitaryTime({
    message: 'Thời gian bắt đầu ca không được trống và có định dạng là HH/MM',
  })
  startAt: string;

  @ApiProperty({ example: '18:00', description: 'thời gian kết thúc ca' })
  @IsNotEmpty({ message: 'Thời gian kết thúc ca không được trống' })
  @IsMilitaryTime({
    message: 'Thời gian kết thúc ca không được trống và có định dạng là HH/MM',
  })
  endAt: string;

  @ApiProperty({
    example: 200,
    description: 'đơn giá/giờ',
  })
  @IsOptional()
  @IsNumber()
  pricePerHour: number;

  @ApiProperty({
    example: 'VND',
    description: 'đơn vị',
  })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  priceUnit: string;

  @ApiProperty({
    example: [
      {
        name: 'nghỉ đầu ca',
        startAt: '06:00',
        endAt: '06:30',
      },
    ],
    description: 'thời gian nghỉ trong ca',
  })
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => WorkCenterShiftRelaxTime)
  @IsArray()
  relaxTimes: WorkCenterShiftRelaxTime[];
}

export class WorkCenterShiftRelaxTime {
  @ApiProperty({ example: 'ca 1', description: 'tên ca' })
  @IsString()
  @MaxLength(255)
  @IsNotEmpty({ message: 'Tên ca nghỉ không được trống' })
  name: string;

  @ApiProperty({
    example: '06:00',
    description: 'Thời gian bắt đầu nghỉ đầu ca',
  })
  @IsNotEmpty({ message: 'Thời gian bắt đầu của ca nghỉ không được trống' })
  @IsMilitaryTime({
    message:
      'Thời gian bắt đầu ca nghỉ không được trống và có định dạng là HH/MM',
  })
  startAt: string;

  @ApiProperty({
    example: '06:30',
    description: 'thời gian kết thúc nghỉ đầu ca',
  })
  @IsNotEmpty({ message: 'thời gian kết thúc của ca nghỉ không được trống' })
  @IsMilitaryTime({
    message:
      'Thời gian kết thúc ca nghỉ không được trống và có định dạng là HH/MM',
  })
  endAt: string;
}

export class CreateWorkCenterShiftRequestDto extends BaseDto {
  @IsOptional()
  @IsInt()
  @ApiProperty({ example: '1', description: 'work center id' })
  workCenterId: number;

  @ArrayNotEmpty()
  @ValidateNested({ each: true })
  @Type(() => WorkCenterShift)
  @ApiProperty({
    example: [
      {
        name: 'ca 1',
        startAt: '06:00',
        endAt: '18:00',
        pricePerHour: 200,
        priceUnit: 'VND',
      },
      {
        name: 'ca 2',
        startAt: '18:00',
        endAt: '01:00',
        pricePerHour: 400,
        priceUnit: 'VND',
      },
    ],
    description: 'các ca làm việc của xưởng',
  })
  workCenterShifts: WorkCenterShift[];
}
