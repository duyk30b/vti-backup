import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { decimal } from '@utils/common';
import { Type } from 'class-transformer';
import {
  IsNotEmpty,
  IsString,
  MaxLength,
  IsInt,
  IsOptional,
  ArrayUnique,
  IsArray,
  ArrayNotEmpty,
  ValidateNested,
  Min,
  Max,
  IsNumber,
  IsEnum,
} from 'class-validator';
import { WorkCenterShift } from './create-work-center-shift.dto';
import { WorkCenterTypeEnum } from '@components/work-center/work-center.constant';

export class Member {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;
}

export class WorkCenterRequestAbstractDto extends BaseDto {
  @IsNotEmpty()
  @IsString()
  @MaxLength(20)
  @ApiProperty({ example: 'WC001', description: 'code' })
  code: string;

  @ApiProperty({ example: 'Xưởng lắp ráp', description: 'name' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiProperty({ example: 1, description: 'mã nhà máy' })
  @IsNotEmpty()
  @IsInt()
  factoryId: number;

  @ApiPropertyOptional({ example: 1, description: 'Mã chuyền' })
  @IsOptional()
  @IsInt()
  routingId: number;

  @ApiPropertyOptional({ example: 1, description: 'Mã cấu hình IOT' })
  @IsOptional()
  @IsString()
  profileId: string;

  @ApiProperty({ example: 1, description: 'PLC/Normal' })
  @IsInt()
  @IsEnum(WorkCenterTypeEnum)
  type: WorkCenterTypeEnum;

  @ApiProperty({ example: 1, description: 'mã tổ trưởng' })
  @IsNotEmpty()
  @IsInt()
  leaderId: number;

  @ApiProperty({
    example: 'Xưởng lắp ráp sản phẩm',
    description: 'mô tả xưởng',
  })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;

  @ApiProperty({
    example: 100,
    description: 'Hiệu suất làm việc(%)',
  })
  performance: number;

  @ApiProperty({
    example: 100,
    description: 'Công suất làm việc',
  })
  @IsNumber()
  @IsNotEmpty()
  @Min(0, {
    message: 'Công suất làm việc không nhỏ hơn 0 giờ ',
  })
  @Max(decimal(10, 2), {
    message: 'Công suất làm việc không hợp lệ',
  })
  workingCapacity: number;

  @ApiProperty({
    example: 90,
    description: 'Mục tiêu OEE(%)',
  })
  @Min(0, {
    message: 'Mục tiêu OEE không được nhỏ hơn 0 ',
  })
  @Max(100, {
    message: 'Mục tiêu OEE không được lớn hơn 100',
  })
  @IsNotEmpty()
  oeeTarget: number;

  @ApiProperty({
    example: 2000,
    description: 'Chi phí trên giờ',
  })
  @IsInt()
  @IsOptional()
  cost: number;

  @ApiProperty({ example: 30, description: 'Thời gian trước sản xuất(phút)' })
  preProductionTime: number;

  @ApiProperty({ example: 30, description: 'Thời gian sau sản xuất(phút)' })
  postProductionTime: number;

  @ApiPropertyOptional({
    example: 'Chuẩn (40 giờ/tuần)',
    description: 'Giờ làm việc',
  })
  @IsOptional()
  workingHours: string;

  @ApiProperty()
  @ValidateNested()
  @ArrayUnique((e: Member) => e.id)
  @IsArray()
  @ArrayNotEmpty()
  @Type(() => Member)
  members: Member[];

  @ApiPropertyOptional({
    example: 1,
    description: 'công đoạn sản xuất của xưởng',
  })
  @IsOptional()
  @IsInt()
  producingStepId: number;

  @ArrayNotEmpty()
  @ValidateNested({ each: true })
  @Type(() => WorkCenterShift)
  @ApiProperty({
    example: [
      {
        name: 'ca 1',
        startAt: '06:00',
        endAt: '18:00',
        pricePerHour: 200,
        priceUnit: 'VND',
      },
      {
        name: 'ca 2',
        startAt: '18:00',
        endAt: '01:00',
        pricePerHour: 400,
        priceUnit: 'VND',
      },
    ],
    description: 'các ca làm việc của xưởng',
  })
  workCenterShifts: WorkCenterShift[];
}
