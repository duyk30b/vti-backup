import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { BasicResponseDto } from '@core/dto/response/basic.response.dto';
import { PagingResponse } from '@utils/paging.response';
import { IsArray } from 'class-validator';

class PlcBom {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  runningStatus: number;

  @ApiProperty({ description: 'SL Kế hoạch' })
  @Expose()
  quantity: number;

  @ApiProperty({ description: 'SL thực tế' })
  @Expose()
  actualQuantity: number;
}

export class PlcBomItem {
  @ApiProperty()
  @Expose()
  canStart: number;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  mo: BasicResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  item: BasicResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  routing: BasicResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => PlcBom)
  moBom: PlcBom;
}

export class PlcBomItemResponseDto extends PagingResponse {
  @ApiProperty({ isArray: true, type: PlcBomItem })
  @Expose()
  @IsArray()
  items: PlcBomItem[];
}
