import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { BasicResponseDto } from '@core/dto/response/basic.response.dto';
import { IsArray } from 'class-validator';
import { SuccessResponse } from '@utils/success.response.dto';

class PlcBom {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  runningStatus: number;

  @ApiProperty()
  @Expose()
  startAt: string;

  @ApiProperty({ description: 'SL Kế hoạch' })
  @Expose()
  quantity: number;

  @ApiProperty({ description: 'SL thực tế' })
  @Expose()
  actualQuantity: number;
}

class PlcBomItemWo extends BasicResponseDto {
  @ApiProperty({
    example: 400,
    description: 'Số lượng kế hoạch của lệnh làm việc',
  })
  @Expose()
  @Type(() => Number)
  quantity: number;

  @ApiProperty({})
  @Expose()
  @Type(() => Number)
  actualQuantity: number;

  @ApiProperty({})
  @Expose()
  @Type(() => Number)
  qcPassQuantity: number;

  @Expose()
  @Type(() => Number)
  qcRejectQuantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  producingStep: BasicResponseDto;
}

export class PlcBomItemDetail extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  startAt: number;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  item: BasicResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  routing: BasicResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => PlcBomItemWo)
  workOrders: PlcBomItemWo;

  @ApiProperty()
  @Expose()
  @Type(() => PlcBom)
  moBom: PlcBom;
}

export class PlcBomItemDetailResponseDto extends SuccessResponse {
  @ApiProperty({ isArray: true, type: PlcBomItemDetail })
  @Expose()
  @IsArray()
  data: PlcBomItemDetail[];
}
