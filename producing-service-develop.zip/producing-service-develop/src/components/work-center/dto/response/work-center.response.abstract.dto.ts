import { UserResponseDto } from '@components/user/dto/response/user.response.dto';
import { BasicResponseDto } from '@core/dto/response/basic.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

export class FactoryDataResponseDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 2, description: '' })
  @Expose()
  companyId: number;

  @ApiProperty({ example: 'factory 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'ABCDEF', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'Ha Noi', description: '' })
  @Expose()
  location: string;

  @ApiProperty({ example: '0955-015-1458', description: '' })
  @Expose()
  phone: string;

  @ApiProperty({ example: 'description', description: '' })
  @Expose()
  description: string;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  createdAt: Date;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  updatedAt: Date;
}
class AttributeProducingStep extends BasicResponseDto {}
class AttributeRouting extends BasicResponseDto {}
class Attribute {
  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  producingStepId: number;

  @ApiProperty()
  @Expose()
  dataType: string;

  @ApiProperty({ type: AttributeProducingStep })
  @Expose()
  @Type(() => AttributeProducingStep)
  producingStep: AttributeProducingStep;
}

export class DeviceProfile {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty({ type: AttributeProducingStep })
  @Expose()
  @Type(() => AttributeProducingStep)
  producingStep: AttributeProducingStep;

  @ApiProperty({ type: AttributeProducingStep })
  @Expose()
  @Type(() => AttributeProducingStep)
  routing: AttributeRouting;

  @ApiProperty({ type: Attribute, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => Attribute)
  attributes: Attribute[];
}

export class WorkCenterShiftDataDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  workCenterId: number;

  @ApiProperty({ example: 'WCS1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: '07:00:00', description: '' })
  @Expose()
  startAt: string;

  @ApiProperty({ example: '17:00:00', description: '' })
  @Expose()
  endAt: string;

  @ApiProperty({ example: '200.00', description: '' })
  @Expose()
  pricePerHour: number;

  @ApiProperty({ example: 'VND', description: '' })
  @Expose()
  priceUnit: string;
}

class UserResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  username: string;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  fullName: string;
}

export class ProducingStepDataDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'ca 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 's1', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  description: string;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  status: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  approverId: number;

  @ApiProperty({ example: '2021-07-17T09:27:30.840Z', description: '' })
  @Expose()
  approvedAt: Date;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  switchMode: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  qcQuantityRule: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  qcCheck: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  workCenterId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  qcCriteriaId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  productionTimePerItem: number;

  @ApiProperty({ example: '2021-07-17T09:27:30.840Z', description: '' })
  @Expose()
  createdAt: Date;

  @ApiProperty({ example: '2021-07-17T09:27:30.840Z', description: '' })
  @Expose()
  updatedAt: Date;
}

export class WorkCenterShiftRelaxTimeDataDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  workCenterId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  workCenterShiftId: number;

  @ApiProperty({ example: 'nghỉ đầu ca', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: '07:00:00', description: '' })
  @Expose()
  startAt: string;

  @ApiProperty({ example: '08:00:00', description: '' })
  @Expose()
  endAt: Date;
}

export class WorkCenterResponseAbstractDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'Xưởng lắp ráp', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'Mã Xưởng', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  factoryId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  leaderId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  type: number;

  @ApiProperty({ example: 'Xưởng lắp ráp sản phẩm', description: '' })
  @Expose()
  description: string;

  @ApiProperty({ type: FactoryDataResponseDto })
  @Expose()
  @Type(() => FactoryDataResponseDto)
  factory: FactoryDataResponseDto;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  leader: UserResponseDto;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  createdBy: UserResponseDto;

  @ApiProperty({ example: 100, description: 'Hiệu suất làm việc(%)' })
  @Expose()
  performance: number;

  @ApiProperty({ example: 5, description: 'Công suất làm việc' })
  @Expose()
  productivityIndex: number;

  @ApiProperty({ example: 90, description: 'Mục tiêu OEE(%)' })
  @Expose()
  oeeIndex: number;

  @ApiProperty({ example: 2000, description: 'Chi phí trên giờ(VNĐ)' })
  @Expose()
  cost: number;

  @ApiProperty({ example: 2000, description: 'Thời gian trước sản xuất(phút)' })
  @Expose()
  preProductionTime: number;

  @ApiProperty({ example: 2000, description: 'Thời gian sau sản xuất(phút)' })
  @Expose()
  postProductionTime: number;

  @ApiProperty({
    example: 'Chuẩn (40h/tuần)',
    description: 'Thời gian làm việc(giờ/tuần)',
  })
  @Expose()
  workingHours: string;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  createdAt: Date;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  members: UserResponseDto[];

  @ApiProperty({ example: 400, description: 'Số lượng kế hoạch' })
  @Expose()
  @Type(() => Number)
  planQuantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  remainQuantity: number;

  @ApiProperty({ example: 300, description: 'Số lượng nhập' })
  @Expose()
  @Type(() => Number)
  actualQuantity?: number;

  @ApiProperty({
    example: 400,
    description: 'Số lượng kế hoạch của lệnh làm việc',
  })
  @Expose()
  @Type(() => Number)
  quantity: number;

  @ApiProperty({ example: 400, description: 'Số lượng kế hoạch' })
  @Expose()
  @Type(() => Number)
  totalPlanQuantity: number;

  @ApiProperty({ example: 100, description: 'Số lượng đã sx được xác nhận' })
  @Expose()
  @Type(() => Number)
  confirmedQuantity: number;

  @ApiProperty({ example: 'ssN02', description: 'serial thiết bị' })
  @Expose()
  deviceSerial: string;

  @ApiProperty({
    example: 100,
    description: 'Tổng số sản phẩm lỗi đã sx - phế liệu',
  })
  @Expose()
  @Type(() => Number)
  scrapQuantity: number;

  @ApiProperty({
    example: 100,
    description: 'Tổng số sản phẩm xuất công đoạn',
  })
  @Expose()
  @Type(() => Number)
  exportQuantity: number;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  @Type(() => UserResponse)
  approve: UserResponse;

  @ApiProperty({ example: 100, description: 'Số lượng chưa qc' })
  @Expose()
  @Type(() => Number)
  totalUnQcQuantity: number;

  @ApiProperty({ example: 100, description: 'Số lượng qc lỗi' })
  @Expose()
  @Type(() => Number)
  totalQcRejectQuantity: number;

  @ApiProperty({ example: 100, description: 'Số lượng pass qc' })
  @Expose()
  @Type(() => Number)
  totalQcPassQuantity: number;

  @ApiProperty({ example: 100, description: 'Số lượng pass qc' })
  @Expose()
  @Type(() => Number)
  totalQcQuantity: number;

  @ApiProperty({ example: {}, description: 'producing step' })
  @Expose()
  @Type(() => ProducingStepDataDto)
  producingStep: ProducingStepDataDto;

  @ApiProperty({})
  @Expose()
  @Type(() => ProducingStepDataDto)
  routing: ProducingStepDataDto;

  @ApiProperty({ type: DeviceProfile })
  @Expose()
  @Type(() => DeviceProfile)
  deviceProfile: DeviceProfile;

  @ApiProperty({ example: {}, description: 'shifts' })
  @Expose()
  @Type(() => WorkCenterShiftDataDto)
  workCenterShifts: WorkCenterShiftDataDto[];

  @ApiProperty({ example: {}, description: 'shifts' })
  @Expose()
  @Type(() => WorkCenterShiftRelaxTimeDataDto)
  workCenterShiftRelaxTimes: WorkCenterShiftRelaxTimeDataDto[];
}
