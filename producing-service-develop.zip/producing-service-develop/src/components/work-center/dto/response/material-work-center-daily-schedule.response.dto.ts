import { BasicResponseDto } from '@core/dto/response/basic.response.dto';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class MaterialWorkCenterDailySchedule {
  @Expose()
  id: number;

  @Expose()
  qcCheck: number;

  @Expose()
  criteriaId: number;

  @Expose()
  quantity: number;

  @Expose()
  inputQuantity: number;

  @Expose()
  qcPassQuantity: number;

  @Expose()
  qcRejectQuantity: number;

  @Expose()
  @Type(() => BasicResponseDto)
  item: BasicResponseDto;
}

export class MaterialWorkCenterDailyScheduleResponseDto {
  @Expose()
  executionDay: string;

  @Expose()
  @IsArray()
  @Type(() => MaterialWorkCenterDailySchedule)
  materials: MaterialWorkCenterDailySchedule;
}
