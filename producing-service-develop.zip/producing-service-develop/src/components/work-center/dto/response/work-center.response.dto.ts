import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { WorkCenterResponseAbstractDto } from './work-center.response.abstract.dto';

export class WorkCenterResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: WorkCenterResponseAbstractDto;
}
