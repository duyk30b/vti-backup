import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { WorkCenterResponseAbstractDto } from './work-center.response.abstract.dto';
import { PagingResponse } from '@utils/paging.response';
export class WorkCenterListData extends PagingResponse {
  @ApiProperty({ type: WorkCenterResponseAbstractDto, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => WorkCenterResponseAbstractDto)
  items: WorkCenterResponseAbstractDto[];
}

export class GetListWorkCenterResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: WorkCenterListData;
}
