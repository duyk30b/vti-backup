import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose } from 'class-transformer';

export class ScheduleShiftDetailDto {
  @ApiProperty({ example: '1.00', description: '' })
  @Expose()
  quantity: number;

  @ApiProperty({ example: '1.00', description: '' })
  @Expose()
  moderationQuantity: number;

  @ApiProperty({ example: '1.00', description: '' })
  @Expose()
  actualQuantity: number;

  @ApiProperty({ example: '1', description: '' })
  @Expose()
  workCenterShiftId: number;

  @ApiProperty({ example: 'Ca 1', description: '' })
  @Expose()
  name: string;
}
export class WorkCenterDailyScheduleResponseDto {
  @Expose()
  executionDay: Date;

  @ApiProperty({ type: ScheduleShiftDetailDto, isArray: true })
  @Expose()
  scheduleShiftDetails: ScheduleShiftDetailDto[];
}
