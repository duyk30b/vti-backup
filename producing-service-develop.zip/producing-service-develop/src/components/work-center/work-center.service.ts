import { WorkCenterShift } from './dto/request/create-work-center-shift.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { CreateWorkCenterScheduleRequestDto } from '@components/work-order/dto/request/create-work-center-schedule.request.dto';
import { WorkOrderScheduleDetailRepositoryInterface } from '@components/work-order/interface/work-order-schedule-detail.repository.interface';
import {
  WorkOrderRunningStatusEnum,
  WorkOrderScheduleDetailStatusEnum,
} from '@components/work-order/work-order.constant';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { WorkCenterShiftRelaxTimeEntity } from '@entities/work-center/work-center-shift-relax-time.entity';
import { WorkCenterShiftEntity } from '@entities/work-center/work-center-shift.entity';
import { WorkCenterUserEntity } from '@entities/work-center/work-center-user.entity';
import { WorkCenterEntity } from '@entities/work-center/work-center.entity';
import { Inject, Injectable, Logger } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import {
  checkTimeRangeOverlap,
  getShiftTime,
  getTimes,
  validateTimeFormatHHMM,
} from '@utils/helper';
import { div, minus, mul, plus } from '@utils/common';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { plainToInstance } from 'class-transformer';
import {
  first,
  flatMap,
  isEmpty,
  last,
  map,
  sortBy,
  uniq,
  filter,
  keyBy,
  has,
  values,
  sumBy,
  orderBy,
} from 'lodash';
import * as Moment from 'moment';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, ILike, In, Not, QueryRunner } from 'typeorm';
import { CreateWorkCenterRequestDto } from './dto/request/create-work-center.request.dto';
import { GetListWorkCenterRequestDto } from './dto/request/get-list-work-center.request.dto';
import { UpdateWorkCenterRequestDto } from './dto/request/update-work-center.request.dto';
import { GetListWorkCenterResponseDto } from './dto/response/get-list-work-center.response.dto';
import { WorkCenterResponseAbstractDto } from './dto/response/work-center.response.abstract.dto';
import { WorkCenterResponseDto } from './dto/response/work-center.response.dto';
import { WorkCenterShiftRepositoryInterface } from './interface/work-center-shift.repository.interface';
import { extendMoment } from 'moment-range';
import { WorkCenterShiftRelaxTimeRepository } from '@repositories/work-center/work-center-shift-relax-time.repository';
import { WorkCenterDailyScheduleShiftRepositoryInterface } from './interface/work-center-daily-schedule-shift.repository.interface';
import { WorkCenterDailyScheduleRepositoryInterface } from './interface/work-center-daily-schedule.repository.interface';
import { WorkCenterUserRepositoryInterface } from './interface/work-center-user.repository.interface';
import { WorkCenterRepositoryInterface } from './interface/work-center.repository.interface';
import { WorkCenterServiceInterface } from './interface/work-center.service.interface';
import { WorkCenterDailyScheduleShiftEntity } from '@entities/work-center/work-center-daily-schedule-shift.entity';
import { WorkCenterDailyScheduleEntity } from '@entities/work-center/work-center-daily-schedule.entity';
import {
  genScheduleByShifts,
  genScheduleQcByShifts,
  genScheduleRepairByShifts,
  getDiffDay,
} from '@utils/generate-schedule';
import { UpdateWorkCenterScheduleStatusRequestDto } from './dto/request/update-work-center-schedule-status.request.dto';
import {
  CAN_DELETE_WORK_CENTER_DAILY_SCHEDULE_STATUS,
  CAN_CONFIRM_WORK_CENTER_DAILY_SCHEDULE_STATUS,
  CAN_REJECT_WORK_CENTER_DAILY_SCHEDULE_STATUS,
  WorkCenterDailyScheduleStatusEnum,
  WorkCenterStatusEnum,
  CAN_CONFIRM_WORK_CENTER_STATUS,
  CAN_REJECT_WORK_CENTER_STATUS,
  CAN_DELETE_WORK_CENTER_STATUS,
  QcCriteriaFormalityEnum,
  QcNumberOfTimeEnum,
  WorkCenterTypeEnum,
} from './work-center.constant';
import { ProducingStepRepository } from '@repositories/produce/producing-step.repository';
import { DeleteWorkCenterDailyScheduleRequestDto } from './dto/request/delete-work-center-daily-schedule.request.dto';
import { WorkCenterDailyScheduleResponseDto } from './dto/response/work-center-daily-schedule.response.dto';
import { WorkOrderRepositoryInterface } from '@components/work-order/interface/work-order.repository.interface';
import { QualityControlService } from '@components/qmx/quality-control.service';
import { SetStatusRequestDto } from '@components/work-center/dto/request/set-status.request.dto';
import { ItemService } from '@components/item/item.service';
import { MaterialWorkCenterDailyScheduleResponseDto } from './dto/response/material-work-center-daily-schedule.response.dto';
import { MmsService } from '@components/mms/mms.service';
import { Producer } from 'kafkajs';
import { RoutingRepositoryInterface } from '@components/routing/interface/routing.repository.interface';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { DeviceServiceInterface } from '@components/device/interface/device.service.interface';
import { GetListPlcBomItemRequestDto } from './dto/request/get-list-plc-bom-item.request.dto';
import { PlcBomItem } from '@components/work-center/dto/response/plc-bom-item.response.dto';
import { MoPlanBomRepositoryInteface } from '@components/plan/inteface/mo-plan-bom.repository.inteface';
import { PlcBomItemDetail } from './dto/response/plc-bom-item-detail.response.dto';
import { ChangeRunningStatusRequestDto } from '@components/work-order/dto/request/change-running-status.request.dto';
import { WorkOrderRunningLogsRepositoryInterface } from '@components/work-order/interface/work-order-running-logs.repository.interface';
import { CreateWorkOrderLogTimeRequestDto } from '@components/work-order/dto/request/create-work-order-log-time.request.dto';
import { WorkOrderLogTimeResponseDto } from '@components/work-order/dto/response/work-order-log-time.response.dto';
import { DEFAULT_TIME_FORMAT } from '@constant/common';

const moment = extendMoment(Moment);

@Injectable()
export class WorkCenterService implements WorkCenterServiceInterface {
  private readonly logger = new Logger(WorkCenterService.name);

  constructor(
    @Inject('WorkCenterRepositoryInterface')
    private readonly workCenterRepository: WorkCenterRepositoryInterface,

    @Inject('MoPlanBomRepositoryInterface')
    private readonly moPlanBomRepository: MoPlanBomRepositoryInteface,

    @Inject('WorkOrderRunningLogsRepositoryInterface')
    private readonly workOrderRunningLogsRepository: WorkOrderRunningLogsRepositoryInterface,

    @Inject('WorkCenterUserRepositoryInterface')
    private readonly workCenterUserRepository: WorkCenterUserRepositoryInterface,

    @Inject('WorkOrderScheduleDetailRepositoryInterface')
    private readonly workOrderScheduleDetailRepository: WorkOrderScheduleDetailRepositoryInterface,

    @Inject('WorkCenterDailyScheduleRepositoryInterface')
    private readonly workCenterDailyScheduleRepository: WorkCenterDailyScheduleRepositoryInterface,

    @Inject('WorkCenterDailyScheduleShiftRepositoryInterface')
    private readonly workCenterDailyScheduleShiftRepository: WorkCenterDailyScheduleShiftRepositoryInterface,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('WorkCenterShiftRepositoryInterface')
    private readonly workCenterShiftRepository: WorkCenterShiftRepositoryInterface,

    @Inject('WorkOrderRepositoryInterface')
    private readonly workOrderRepository: WorkOrderRepositoryInterface,

    @Inject('WorkCenterShiftRelaxTimeRepositoryInterface')
    private readonly workCenterShiftRelaxTimeRepository: WorkCenterShiftRelaxTimeRepository,

    @Inject('ProducingStepRepositoryInterface')
    private readonly producingStepRepository: ProducingStepRepository,

    @Inject('RoutingRepositoryInterface')
    private readonly routingRepository: RoutingRepositoryInterface,

    @Inject('QmsxServiceInterface')
    private readonly qmsxService: QualityControlService,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemService,

    @Inject('MmsServiceInterface')
    private readonly mmsService: MmsService,

    @Inject('DeviceServiceInterface')
    private readonly deviceService: DeviceServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    // @Inject('KAFKA_PRODUCER')
    // private kafkaProducer: Producer,

    private readonly i18n: I18nRequestScopeService,

    private readonly eventEmitter: EventEmitter2,
  ) {}

  async setRunningStatus(id: number, moBomId: number, payload: any) {
    const { status } = payload;
    const plc = await this.workCenterRepository.findOneById(id);

    const requests = [];
    if (isEmpty(plc)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const virtualDevices = await this.workCenterRepository.findWithRelations({
      where: {
        isVirtual: 1,
        parentId: id,
      },
    });

    const workOrderSchedules: any =
      await this.workOrderRepository.getByVirtualDevices(
        map(virtualDevices, 'id'),
        moBomId,
      );

    if (
      plc.currentRunningWorkOrderId &&
      plc.currentRunningWorkOrderId != moBomId
    ) {
      return new ApiError(
        ResponseCodeEnum.FORBIDDEN,
        await this.i18n.translate('error.CAN_NOT_START_WORK_ORDER_REASON_1'),
      ).toResponse();
    }

    const moBom = await this.moPlanBomRepository.findOneWithRelations({
      where: {
        id: moBomId,
      },
    });
    if (status == WorkOrderRunningStatusEnum.RUNNING) {
      moBom.startAt = new Date();
    }
    moBom.runningStatus = status;

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      plc.currentRunningWorkOrderId = status == 1 ? moBom.id : 0;

      await queryRunner.manager.save(moBom);
      await queryRunner.manager.save(plc);
      workOrderSchedules.forEach((workOrderSchedule) => {
        workOrderSchedule.schedules.forEach((schedule) => {
          requests.push(
            this.changeWoRunningStatus({
              id: workOrderSchedule.id,
              workCenterId: schedule.workCenterId,
              status: status,
            } as ChangeRunningStatusRequestDto),
          );
        });
      });

      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (e) {
      this.logger.error(`WORK_ORDER Create running error: `, e);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } finally {
      await queryRunner.release();
      await Promise.all(requests);
    }
  }

  public async changeWoRunningStatus(
    request: ChangeRunningStatusRequestDto,
  ): Promise<any> {
    const { id, status, workCenterId, userId } = request;
    const workOrder = await this.workOrderRepository.findOneById(id);

    if (!workOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }
    const workCenter = await this.workCenterRepository.findOneByCondition({
      id: workCenterId,
    });
    if (isEmpty(workCenter)) {
      return new ApiError(
        ResponseCodeEnum.FORBIDDEN,
        await this.i18n.translate('error.WOKR_CENTER_NOT_FOUND'),
      ).toResponse();
    }
    if (
      workCenter.currentRunningWorkOrderId &&
      workCenter.currentRunningWorkOrderId != id
    ) {
      return new ApiError(
        ResponseCodeEnum.FORBIDDEN,
        await this.i18n.translate('error.CAN_NOT_START_WORK_ORDER_REASON_1'),
      ).toResponse();
    }

    const runningLogEntity = this.workOrderRunningLogsRepository.createEntity({
      ...request,
      workOrderId: workOrder.id,
    });
    if (status == WorkOrderRunningStatusEnum.RUNNING) {
      workOrder.startAt = new Date();
    }

    workOrder.runningStatus = status;
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      workCenter.currentRunningWorkOrderId = status == 1 ? id : 0;

      if (workCenter.type === WorkCenterTypeEnum.PLC) {
        const virtualWorkCenters =
          await this.workCenterRepository.findWithRelations({
            parentId: workCenter.id,
            isVirtual: 1,
          });
        virtualWorkCenters.forEach((virtualWorkCenter) => {
          virtualWorkCenter.currentRunningWorkOrderId = status == 1 ? id : 0;
        });
        await queryRunner.manager.save(virtualWorkCenters);
      }

      await queryRunner.manager.save(workOrder);
      await queryRunner.manager.save(workCenter);
      await queryRunner.manager.save(runningLogEntity);
      let logTimeRequest;
      if (status == 1) {
        logTimeRequest = {
          id: id,
          userId: userId,
          start: new Date(),
          workCenterId: workCenterId,
        } as CreateWorkOrderLogTimeRequestDto;
      } else if (status == 2) {
        logTimeRequest = {
          id: id,
          userId: userId,
          end: new Date(),
          workCenterId: workCenterId,
        } as CreateWorkOrderLogTimeRequestDto;
      }

      await queryRunner.commitTransaction();

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (e) {
      this.logger.error(`WORK_ORDER Create running error: `, e);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  async getBomItemDetailPlc(id: number, moBomId: number): Promise<any> {
    const plc = await this.workCenterRepository.findOneById(id);
    if (isEmpty(plc)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const moBom = await this.moPlanBomRepository.findOneWithRelations({
      where: {
        id: moBomId,
      },
      relations: ['manufacturingOrder', 'routing'],
    });

    const items = await this.itemService.getItemsByIds([moBom.itemId], true);

    const virtualDevices = await this.workCenterRepository.findWithRelations({
      where: {
        isVirtual: 1,
        parentId: id,
      },
    });
    const workOrderSchedules: any =
      await this.workOrderRepository.getByVirtualDevices(
        map(virtualDevices, 'id'),
        moBomId,
      );
    const wos = [];
    workOrderSchedules.forEach((workOrderSchedule) => {
      workOrderSchedule.schedules.forEach((schedule) => {
        wos.push({
          producingStep: workOrderSchedule.producingStep,
          ...schedule,
        });
      });
    });
    const result = {
      ...plc,
      item: items[moBom.itemId],
      routing: moBom.routing,
      moBom: moBom,
      workOrders: wos,
    };

    const response = plainToInstance(PlcBomItemDetail, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<any>(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async getBomItemListPlc(
    request: GetListPlcBomItemRequestDto,
  ): Promise<any> {
    const { id } = request;

    const device = await this.workCenterRepository.findOneById(id);
    if (
      isEmpty(device) ||
      (!isEmpty(device) && device.type != WorkCenterTypeEnum.PLC)
    ) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const virtualDevices = await this.workCenterRepository.findWithRelations({
      where: {
        parentId: device.id,
      },
    });

    if (isEmpty(virtualDevices)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const { data, count } = await this.workOrderRepository.getPlcBomItem(
      first(virtualDevices)?.id,
      request,
    );
    const moDetailItemIds = uniq(map(flatMap(data, 'moBom'), 'itemId'));
    const items = await this.itemService.getItemsByIds(moDetailItemIds, true);

    const result = map(data, (d) => {
      let canStart = false;
      if (!device.currentRunningWorkOrderId) canStart = true;
      if (device.currentRunningWorkOrderId == d.moBom.id) canStart = true;
      return {
        ...d,
        canStart: canStart,
        item: items[d.moBom?.itemId],
      };
    });

    const response = plainToInstance(PlcBomItem, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async create(
    request: CreateWorkCenterRequestDto,
  ): Promise<ResponsePayload<WorkCenterResponseDto | any>> {
    const {
      name,
      code,
      factoryId,
      producingStepId,
      type,
      routingId,
      workCenterShifts,
    } = request;
    let responseCode = ResponseCodeEnum.SUCCESS;
    let data, message, routing;

    const workCenter = await this.workCenterRepository.findByCondition([
      { name: name },
      { code: ILike(code) },
    ]);

    if (!isEmpty(workCenter)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_OR_NAME_ALREADY_EXISTS'),
      ).toResponse();
    }

    if (type == WorkCenterTypeEnum.NORMAL) {
      const producingStep = await this.producingStepRepository.findOneById(
        producingStepId,
      );
      if (isEmpty(producingStep)) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.PRODUCING_STEP_NOT_FOUND'),
        ).toResponse();
      }
    } else {
      routing = await this.routingRepository.findOneWithRelations({
        where: {
          id: +routingId || 0,
        },
        relations: ['routingProducingStep'],
      });
      if (isEmpty(routing)) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.ROUTING_NOT_FOUND'),
        ).toResponse();
      }
    }

    const factoriesData = await this.userService.getFactoriesByIds([factoryId]);
    if (factoriesData.length === 0) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.FACTORY_NOT_FOUND'),
      ).toResponse();
    }

    const shiftAfterShort = sortBy(workCenterShifts, function (shift) {
      const startTime = getTimes(shift.startAt);
      return +moment().set(startTime);
    });

    const firstShift = first(shiftAfterShort);
    const lastShift = last(shiftAfterShort);

    const firstShiftStart = getShiftTime(
      firstShift.startAt,
      firstShift.endAt,
    ).start.set({ seconds: 0, milliseconds: 0 });
    const lastShiftEnd = getShiftTime(
      lastShift.startAt,
      lastShift.endAt,
    ).end.set({ seconds: 0, milliseconds: 0 });

    if (
      lastShiftEnd.diff(firstShiftStart, 'hours', true) > 24 ||
      this.hasShiftInvalid(shiftAfterShort)
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.SHIFT_DATA_INVALID'))
        .build();
    }

    const relaxTimesInvalid = shiftAfterShort.map((shift) =>
      this.checkRelaxTimeInvalid(shift),
    );

    if (relaxTimesInvalid.some((isInvalid) => isInvalid)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.SHIFT_RELAX_TIME_DATA_INVALID'),
        )
        .build();
    }

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const workCenterEntity = this.workCenterRepository.createEntity(request);
      const workCenterResponse = await this.save(
        queryRunner,
        [workCenterEntity],
        request,
      );
      // if (type == WorkCenterTypeEnum.PLC) {
      //   // Make virtual machine
      //   const virtualWorkCenters =
      //     this.workCenterRepository.createVirtualEntities(
      //       workCenterEntity,
      //       routing.routingProducingStep,
      //     );
      //   if (!isEmpty(virtualWorkCenters)) {
      //     await this.save(queryRunner, virtualWorkCenters, request);
      //   }
      // }

      const workCenterData = first(workCenterResponse?.data);

      const shifts = shiftAfterShort.map((workCenterShift) => ({
        workCenterId: workCenterData.id,
        ...workCenterShift,
      }));

      const workCenterShiftEntities =
        await this.workCenterShiftRepository.createEntities(shifts);

      const workCenterShiftData = await queryRunner.manager.save(
        workCenterShiftEntities,
      );

      const shiftRelaxTimeEntities = [];
      shiftAfterShort.map((shift, index) => {
        if (shift?.relaxTimes && shift?.relaxTimes.length > 0) {
          shift.relaxTimes.map((relaxTime) => {
            shiftRelaxTimeEntities.push(
              this.workCenterShiftRelaxTimeRepository.createEntity({
                ...relaxTime,
                workCenterId: workCenterData.id,
                workCenterShiftId: workCenterShiftData[index].id,
              }),
            );
          });
        }
      });
      await queryRunner.manager.save(shiftRelaxTimeEntities);
      data = workCenterData;
      await queryRunner.commitTransaction();
    } catch (err) {
      console.log({ err });
      await queryRunner.rollbackTransaction();
      responseCode = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      message = err;
    }

    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(responseCode)
      .withMessage(
        responseCode === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  public async update(
    request: UpdateWorkCenterRequestDto,
  ): Promise<ResponsePayload<WorkCenterResponseDto> | any> {
    const {
      id,
      name,
      code,
      factoryId,
      producingStepId,
      workCenterShifts,
      routingId,
      type,
    } = request;
    let routing, response;
    const workCenter = await this.workCenterRepository.findOneById(id);
    if (!workCenter) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const workCenterExist = await this.workCenterRepository.findByCondition([
      {
        name: name,
        id: Not(id),
      },
      {
        code: code,
        id: Not(id),
      },
    ]);
    if (!isEmpty(workCenterExist)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_OR_NAME_ALREADY_EXISTS'),
      ).toResponse();
    }

    if (type == WorkCenterTypeEnum.NORMAL) {
      const producingStep = await this.producingStepRepository.findOneById(
        producingStepId,
      );
      if (isEmpty(producingStep)) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.PRODUCING_STEP_NOT_FOUND'),
        ).toResponse();
      }
    } else {
      routing = await this.routingRepository.findOneWithRelations({
        where: {
          id: +routingId || 0,
        },
        relations: ['routingProducingStep'],
      });
      if (isEmpty(routing)) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.ROUTING_NOT_FOUND'),
        ).toResponse();
      }
    }

    const factoriesData = await this.userService.getFactoriesByIds([factoryId]);
    if (factoriesData.length === 0) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.FACTORY_NOT_FOUND'),
      );
    }

    const shiftAfterShort = sortBy(workCenterShifts, function (shift) {
      const startTime = getTimes(shift.startAt);
      return +moment().set(startTime);
    });

    const firstShift = first(shiftAfterShort);
    const lastShift = last(shiftAfterShort);

    const firstShiftStart = getShiftTime(
      firstShift.startAt,
      firstShift.endAt,
    ).start.set({ seconds: 0, milliseconds: 0 });
    const lastShiftEnd = getShiftTime(
      lastShift.startAt,
      lastShift.endAt,
    ).end.set({ seconds: 0, milliseconds: 0 });
    if (
      lastShiftEnd.diff(firstShiftStart, 'hours', true) > 24 ||
      this.hasShiftInvalid(shiftAfterShort)
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.SHIFT_DATA_INVALID'))
        .build();
    }

    const relaxTimesInvalid = shiftAfterShort.map((shift) =>
      this.checkRelaxTimeInvalid(shift),
    );
    if (relaxTimesInvalid.some((isInvalid) => isInvalid)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.SHIFT_RELAX_TIME_DATA_INVALID'),
        )
        .build();
    }
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const workCenterEntity = this.workCenterRepository.updateEntity(
        workCenter,
        request,
      );
      await queryRunner.manager.delete(WorkCenterEntity, {
        parentId: workCenter.id,
      });
      // if (
      //   type == WorkCenterTypeEnum.PLC &&
      //   workCenter.routingId !== routingId
      // ) {
      //   // Make virtual machine
      //   const virtualWorkCenters =
      //     this.workCenterRepository.createVirtualEntities(
      //       workCenter,
      //       routing.routingProducingStep,
      //     );
      //   if (!isEmpty(virtualWorkCenters)) {
      //     await this.save(queryRunner, virtualWorkCenters, request);
      //   }
      // }

      await this.createWorkCenterShift({
        workCenterId: id,
        workCenterShifts,
      });
      response = await this.save(queryRunner, [workCenterEntity], request);
      await queryRunner.commitTransaction();
    } catch (err) {
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.INTERNAL_SERVER_ERROR'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }

    return response;
  }

  public async delete(
    id: number,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    let response, message;
    let code = ResponseCodeEnum.SUCCESS;

    const workCenter = await this.workCenterRepository.findOneById(id);

    if (!workCenter) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (!CAN_DELETE_WORK_CENTER_STATUS.includes(workCenter.status)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.delete(WorkCenterEntity, {
        id: id,
      });

      await queryRunner.manager.delete(WorkCenterUserEntity, {
        workCenterId: id,
      });

      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      message = error;
    }

    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(code)
      .withData(response)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  public async detail(
    id: number,
    baseInfo = true,
  ): Promise<ResponsePayload<WorkCenterResponseDto | any>> {
    const workCenter = await this.workCenterRepository.getDetail(id, baseInfo);

    if (!workCenter) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (baseInfo) {
      try {
        if (workCenter.profileId) {
          workCenter.deviceProfile = await this.deviceService.getDeviceProfile({
            id: workCenter.profileId,
          });
        }
        const memberIds = map(workCenter.workCenterUsers, 'memberId');
        const userIds = [
          ...memberIds,
          workCenter.leaderId,
          workCenter.createdBy,
        ];
        const users = await this.userService.getUserByIds(
          userIds.filter((uId) => uId),
          true,
        );

        workCenter.leader = {};
        if (users[workCenter.leaderId]) {
          workCenter.leader = users[workCenter.leaderId];
        }

        workCenter.members = workCenter.workCenterUsers.map((member) => ({
          ...users[member.memberId],
        }));

        workCenter.createdBy = users[workCenter.createdBy];

        workCenter.factory = {};
        if (workCenter.factoryId !== null) {
          const factories = await this.userService.getFactoriesByIds([
            workCenter.factoryId,
          ]);
          workCenter.factory = !isEmpty(factories) ? factories[0] : {};
        }

        const device = await this.mmsService.getDeviceByWorkCenterId({
          workCenterId: workCenter.id,
        });

        if (device) {
          workCenter.deviceSerial = device?.serial;
        }
      } catch (e) {
        this.logger.error(`WORK_CENTER Detail error: `, e);
      }
    }

    const response = plainToInstance(
      WorkCenterResponseAbstractDto,
      workCenter,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async getList(
    request: GetListWorkCenterRequestDto,
  ): Promise<ResponsePayload<GetListWorkCenterResponseDto | any>> {
    const { result, total } = await this.workCenterRepository.getList(
      request,
      [],
    );

    const factories = await this.userService.getFactoriesByIds(
      map(result, 'factoryId'),
      true,
    );

    try {
      const deviceProfiles = await this.deviceService.getDeviceProfiles(
        map(result, 'profileId').filter((p) => !isEmpty(p)),
      );

      if (!isEmpty(deviceProfiles)) {
        result.forEach((r) => {
          r.deviceProfile = deviceProfiles[r.profileId];
        });
      }
    } catch (error) {
      this.logger.debug('ERROR FROM DEVICE SERVICE: ', error);
    }

    result.forEach((r) => {
      r.factory = factories[r.factoryId];
    });

    const response = plainToInstance(WorkCenterResponseAbstractDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: total, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<WorkCenterResponseDto | any>> {
    const { id, userId } = request;
    const workCenter = await this.workCenterRepository.findOneWithRelations({
      where: {
        id: id,
      },
      relations: [
        'routing',
        'routing.routingProducingStep',
        'workCenterUsers',
        'workCenterShifts',
        'workCenterShifts.workCenterShiftRelaxTime',
      ],
    });
    if (!workCenter) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_CONFIRM_WORK_CENTER_STATUS.includes(workCenter.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    workCenter.approvedAt = new Date(Date.now());
    workCenter.approverId = userId;
    workCenter.status = WorkCenterStatusEnum.CONFIRMED;

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    let result;
    try {
      result = await queryRunner.manager.save(workCenter);

      //create virtual devices
      if (workCenter.type == WorkCenterTypeEnum.PLC) {
        const routing = workCenter.routing;
        // Make virtual machine
        const virtualWorkCenters =
          this.workCenterRepository.createVirtualEntities(
            workCenter,
            routing.routingProducingStep,
          );
        if (!isEmpty(virtualWorkCenters)) {
          const request = new CreateWorkCenterRequestDto();
          for (const key in workCenter) {
            request[key] = workCenter[key];
          }
          request['members'] = workCenter.workCenterUsers.map(
            (workCenterUser) => ({ id: workCenterUser.memberId }),
          );
          const workCenterResponse = await this.save(
            queryRunner,
            virtualWorkCenters,
            request,
          );

          const workCenterData = workCenterResponse?.data;
          const shiftAfterShort = orderBy(
            workCenter.workCenterShifts,
            'startAt',
            'ASC',
          );
          let shifts = [];
          shiftAfterShort.forEach((shiftAfterShortItem) => {
            shifts.push(
              ...workCenterData.map((workCenterItem) => {
                return {
                  ...shiftAfterShortItem,
                  workCenterId: workCenterItem.id,
                  relaxTimes: shiftAfterShortItem.workCenterShiftRelaxTime,
                };
              }),
            );
          });
          const workCenterShiftEntities =
            await this.workCenterShiftRepository.createEntities(shifts);

          const workCenterShiftData = await queryRunner.manager.save(
            WorkCenterShiftEntity,
            workCenterShiftEntities,
          );

          const shiftRelaxTimeEntities = [];
          workCenterShiftData.map((workCenterShift, index) => {
            if (
              shifts[index]?.relaxTimes &&
              shifts[index]?.relaxTimes.length > 0
            ) {
              shifts[index].relaxTimes.map((relaxTime) => {
                shiftRelaxTimeEntities.push(
                  this.workCenterShiftRelaxTimeRepository.createEntity({
                    ...relaxTime,
                    workCenterId: workCenterShift.workCenterId,
                    workCenterShiftId: workCenterShift.id,
                  }),
                );
              });
            }
          });
          await queryRunner.manager.save(
            WorkCenterShiftRelaxTimeEntity,
            shiftRelaxTimeEntities,
          );
        }
      }
      await queryRunner.commitTransaction();
      this.eventEmitter.emit('work-center.confirmed', workCenter);
      const response = plainToInstance(WorkCenterResponseAbstractDto, result, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    } finally {
      await queryRunner.manager.release();
    }
  }

  public async reject(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<WorkCenterResponseDto | any>> {
    const { id, userId } = request;
    const workCenter = await this.workCenterRepository.findOneById(id);

    if (!workCenter) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!CAN_REJECT_WORK_CENTER_STATUS.includes(workCenter.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    workCenter.approvedAt = new Date(Date.now());
    workCenter.approverId = userId;
    workCenter.status = WorkCenterStatusEnum.CONFIRMED;

    const result = await this.workCenterRepository.create(workCenter);
    const response = plainToInstance(WorkCenterResponseAbstractDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  private async save(
    queryRunner: QueryRunner,
    workCenterEntities: WorkCenterEntity[],
    request: CreateWorkCenterRequestDto,
  ): Promise<any> {
    const { members, leaderId } = request;

    let message;

    const workCenters = [];
    const code = ResponseCodeEnum.SUCCESS;

    const memberIds = uniq(members.map((e) => e.id));
    const userIds = uniq([...memberIds, leaderId]);
    const users = await this.userService.getUserByIds(userIds);

    if (!users || userIds.length !== users.length) {
      const userIdsFound = users ? users.map((e) => e.id) : [];
      return new ResponseBuilder({
        invalidUserIds: userIds.filter((id) => !userIdsFound.includes(id)),
      })
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_USERS_NOT_FOUND'))
        .build();
    }

    for (let i = 0; i < workCenterEntities.length; i++) {
      const workCenterEntity = workCenterEntities[i];

      const isUpdate = workCenterEntity.id !== undefined;
      const workCenter = await queryRunner.manager.save(workCenterEntity);
      console.log(workCenter);

      const workCenterUserEntities = members.map((member: any) =>
        this.workCenterUserRepository.createEntity({
          workCenterId: workCenter.id,
          memberId: member.id,
        }),
      );

      if (isUpdate) {
        await queryRunner.manager.delete(WorkCenterUserEntity, {
          workCenterId: workCenter.id,
        });
      }
      workCenter.workCenterUsers = await queryRunner.manager.save(
        workCenterUserEntities,
      );
      workCenters.push(workCenter);
    }

    const response = plainToInstance(
      WorkCenterResponseAbstractDto,
      workCenters,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder()
      .withCode(code)
      .withData(response)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  public async createWorkCenterShift(request: any) {
    const { workCenterId, workCenterShifts } = request;
    let code = ResponseCodeEnum.SUCCESS;
    let data, message;

    const workCenter = await this.workCenterRepository.findOneWithRelations({
      where: {
        id: workCenterId,
      },
      relations: ['workCenterShifts', 'workCenterShiftRelaxTimes'],
    });

    if (!workCenter) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const shiftAfterShort = sortBy(workCenterShifts, function (shift) {
      const startTime = getTimes(shift.startAt);
      return +moment().set(startTime);
    });

    const firstShift = first(shiftAfterShort);
    const lastShift = last(shiftAfterShort);

    const firstShiftStart = getShiftTime(
      firstShift.startAt,
      firstShift.endAt,
    ).start;
    const lastShiftEnd = getShiftTime(lastShift.startAt, lastShift.endAt).end;

    if (
      lastShiftEnd.diff(firstShiftStart, 'hours', true) > 24 ||
      this.hasShiftInvalid(shiftAfterShort)
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.SHIFT_DATA_INVALID'))
        .build();
    }

    const relaxTimesInvalid = shiftAfterShort.map((shift) =>
      this.checkRelaxTimeInvalid(shift),
    );

    if (relaxTimesInvalid.some((isInvalid) => isInvalid)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.SHIFT_RELAX_TIME_DATA_INVALID'),
        )
        .build();
    }

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (workCenter.workCenterShiftRelaxTimes.length > 0) {
        await queryRunner.manager.delete(WorkCenterShiftRelaxTimeEntity, {
          workCenterId: workCenter.id,
        });
      }
      if (workCenter.workCenterShifts.length > 0) {
        await queryRunner.manager.delete(WorkCenterShiftEntity, {
          workCenterId: workCenter.id,
        });
      }

      const shifts = shiftAfterShort.map((workCenterShift) => ({
        workCenterId,
        ...workCenterShift,
      }));

      const workCenterShiftEntities =
        await this.workCenterShiftRepository.createEntities(shifts);

      data = await queryRunner.manager.save(workCenterShiftEntities);
      const shiftRelaxTimeEntities = [];

      shiftAfterShort.map((shift, index) => {
        if (shift.relaxTimes && shift.relaxTimes.length > 0) {
          shift.relaxTimes.map((relaxTime) => {
            shiftRelaxTimeEntities.push(
              this.workCenterShiftRelaxTimeRepository.createEntity({
                ...relaxTime,
                workCenterId,
                workCenterShiftId: data[index].id,
              }),
            );
          });
        }
      });
      await queryRunner.manager.save(shiftRelaxTimeEntities);

      await queryRunner.commitTransaction();
    } catch (err) {
      await queryRunner.rollbackTransaction();
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      message = err;
    }

    await queryRunner.release();
    return new ResponseBuilder(data)
      .withCode(code)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  public async deleteWorkCenterShift(
    id: number,
  ): Promise<ResponsePayload<any>> {
    let response, message;
    let code = ResponseCodeEnum.SUCCESS;
    const workCenterShift =
      await this.workCenterShiftRepository.findOneWithRelations({
        where: {
          id: id,
        },
      });
    if (!workCenterShift) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.delete(WorkCenterShiftEntity, {
        id: id,
      });

      await queryRunner.manager.delete(WorkCenterShiftRelaxTimeEntity, {
        workCenterShiftId: id,
      });

      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      message = error;
    }

    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(code)
      .withData(response)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  private getRelaxTime(relaxTime, startShift) {
    const { startAt, endAt } = relaxTime;
    const startRelaxTime = getTimes(startAt);
    const endRelaxTime = getTimes(endAt);
    const startShiftTime = getTimes(startShift);
    let start = moment().add().set(startRelaxTime);
    let end = moment().set(endRelaxTime);
    if (
      startRelaxTime.hour < startShiftTime.hour ||
      (startRelaxTime.hour === startShiftTime.hour &&
        startRelaxTime.minute < startShiftTime.minute)
    ) {
      start = moment().add(1, 'days').set(startRelaxTime);
      end = moment().add(1, 'days').set(endRelaxTime);
    } else if (
      startRelaxTime.hour > endRelaxTime.hour ||
      (startRelaxTime.hour === endRelaxTime.hour &&
        startRelaxTime.minute > endRelaxTime.minute)
    ) {
      start = moment().add().set(startRelaxTime);
      end = moment().add(1, 'days').set(endRelaxTime);
    }
    return { start, end };
  }

  private hasShiftInvalid(shifts) {
    const shiftTimeInvalid = [];
    const timeShifts = shifts.map((shift, i) => {
      let preShift = null;
      if (i > 0) {
        preShift = shifts[i - 1];
      }
      if (
        !validateTimeFormatHHMM(shift.startAt) ||
        !validateTimeFormatHHMM(shift.endAt) ||
        (!isEmpty(preShift) && preShift.endAt !== shift.startAt)
      ) {
        shiftTimeInvalid.push(shift);
      }
      return getShiftTime(shift.startAt, shift.endAt);
    });
    if (shiftTimeInvalid.length > 0) {
      return true;
    }
    const shiftOverlap = [];
    if (timeShifts.length === 1) {
      return false;
    } else {
      for (let i = 0; i <= timeShifts.length; i++) {
        shiftOverlap.push(
          checkTimeRangeOverlap(timeShifts[i], timeShifts[i - 1]),
        );
      }
    }

    return shiftOverlap.some((isOverlap) => isOverlap);
  }

  private checkRelaxTimeInvalid(shift: WorkCenterShift) {
    const { startAt, endAt, relaxTimes } = shift;
    if (isEmpty(relaxTimes)) {
      return false;
    }
    const shiftTime = getShiftTime(startAt, endAt);
    const relaxTimeAfterShort = sortBy(relaxTimes, (relaxTime) => {
      const startTime = this.getRelaxTime(relaxTime, startAt).start;
      return +startTime;
    });

    const firstRelax = first(relaxTimeAfterShort);
    const lastRelax = last(relaxTimeAfterShort);
    const startFirstRelax = this.getRelaxTime(firstRelax, startAt);
    const endLastRelax = this.getRelaxTime(lastRelax, startAt);
    const shiftRange = moment.range(
      shiftTime.start.set({ seconds: 0, milliseconds: 0 }),
      shiftTime.end.set({ seconds: 0, milliseconds: 0 }),
    );
    const relaxRange = moment.range(
      startFirstRelax.start.set({ seconds: 0, milliseconds: 0 }),
      endLastRelax.end.set({ seconds: 0, milliseconds: 0 }),
    );
    if (
      relaxRange.diff('hours', true) > shiftRange.diff('hours', true) ||
      !shiftRange.contains(relaxRange)
    ) {
      return true;
    }

    const relaxTimeInvalid = [];
    const relaxTimesShift = relaxTimeAfterShort.map((shift) => {
      if (
        !validateTimeFormatHHMM(shift.startAt) ||
        !validateTimeFormatHHMM(shift.endAt)
      ) {
        relaxTimeInvalid.push(shift);
      }
      return getShiftTime(shift.startAt, shift.endAt);
    });
    if (relaxTimeInvalid.length > 0) {
      return true;
    }
    const relaxTimeOverlap = [];
    if (relaxTimesShift.length === 1) {
      return false;
    } else {
      for (let i = 0; i <= relaxTimesShift.length; i++) {
        relaxTimeOverlap.push(
          checkTimeRangeOverlap(relaxTimesShift[i], relaxTimesShift[i - 1]),
        );
      }
    }
    return relaxTimeOverlap.some((isOverlap) => isOverlap);
  }

  public async createWorkCenterSchedule(
    request: CreateWorkCenterScheduleRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id, workOrderId, scheduleDetails } = request;

    const workCenter = await this.workCenterRepository.findOneWithRelations({
      where: {
        id: id,
      },
      relations: ['workCenterShifts'],
    });

    if (!workCenter) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const workOrderScheduleDetail =
      await this.workOrderScheduleDetailRepository.getByWorkCenterAndWorkOrderId(
        id,
        workOrderId,
      );
    if (!workOrderScheduleDetail) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WORK_ORDER_SCHEDULE_NOT_FOUND'),
        )
        .build();
    }
    const workCenterShiftIds = map(workCenter.workCenterShifts, 'id');
    let workCenterScheduleShiftIds = [];
    const inValidWorkCenterSchedules = [];
    const workCenterDailyScheduleEntites = [];
    const serializeWorkCenterDailyScheduleShiftEntites = {};
    let totalPlanning = 0;
    const planFrom = moment(workOrderScheduleDetail.planFrom).set({
      hour: 0,
      minute: 0,
      second: 0,
    });
    const planTo = moment(workOrderScheduleDetail.planTo).set({
      hour: 0,
      minute: 0,
      second: 0,
    });
    scheduleDetails.workCenterScheduleDetails.forEach((schedule) => {
      const executionDay = moment(schedule.executionDay)
        .set({
          hour: 0,
          minute: 0,
          second: 0,
        })
        .toISOString();
      const executionDate = moment(schedule.executionDay).set({
        hour: 0,
        minute: 0,
        second: 0,
      });

      if (
        executionDate.isBefore(planFrom, 'day') ||
        executionDate.isAfter(planTo, 'day')
      ) {
        inValidWorkCenterSchedules.push(executionDay);
      } else {
        workCenterScheduleShiftIds.push(
          ...map(schedule.scheduleShiftDetails, 'workCenterShiftId'),
        );

        let totalInDay = 0;
        serializeWorkCenterDailyScheduleShiftEntites[
          executionDate.toISOString()
        ] = [];
        schedule.scheduleShiftDetails.forEach((scheduleShiftDetail) => {
          totalInDay = plus(totalInDay, scheduleShiftDetail.quantity);
          serializeWorkCenterDailyScheduleShiftEntites[
            executionDate.toISOString()
          ].push(
            this.workCenterDailyScheduleShiftRepository.createEntity({
              workCenterShiftId: scheduleShiftDetail.workCenterShiftId,
              quantity: scheduleShiftDetail.quantity,
              moderationQuantity: scheduleShiftDetail.quantity,
              executionDay: executionDay,
              actualQuantity: 0,
            }),
          );
        });
        workCenterDailyScheduleEntites.push(
          this.workCenterDailyScheduleRepository.createEntity({
            workCenterId: id,
            workOrderScheduleDetailId: workOrderScheduleDetail.id,
            quantity: totalInDay,
            moderationQuantity: totalInDay,
            actualQuantity: 0,
            executionDay: executionDay,
          }),
        );
        totalPlanning = plus(totalInDay, totalPlanning);
      }
    });
    if (!isEmpty(inValidWorkCenterSchedules)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.EXECUTION_DAY_N_INVALID', {
            args: { executionDay: inValidWorkCenterSchedules.join(',') },
          }),
        )
        .build();
    }
    workCenterScheduleShiftIds = uniq(workCenterScheduleShiftIds);
    const inValidWorkCenterShifts = filter(
      workCenterScheduleShiftIds,
      (id) => !workCenterShiftIds.includes(id),
    );

    if (!isEmpty(inValidWorkCenterShifts)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.WORK_CENTER_SHIFT_N_NOT_FOUND', {
            args: { workCenterShift: inValidWorkCenterShifts.join(',') },
          }),
        )
        .build();
    }

    if (minus(totalPlanning, workOrderScheduleDetail.quantity) !== 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INVALID_QUANTITY'))
        .build();
    }
    const existingWorkCenterDailySchedule =
      await this.workCenterDailyScheduleRepository.findWithRelations({
        where: {
          workCenterId: id,
          workOrderScheduleDetailId: workOrderScheduleDetail.id,
        },
      });
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (!isEmpty(existingWorkCenterDailySchedule)) {
        const existingWorkCenterDailyScheduleIds = map(
          existingWorkCenterDailySchedule,
          'id',
        );
        await queryRunner.manager.delete(WorkCenterDailyScheduleShiftEntity, {
          workCenterDailyScheduleId: In(existingWorkCenterDailyScheduleIds),
        });
        await queryRunner.manager.delete(WorkCenterDailyScheduleEntity, {
          id: In(existingWorkCenterDailyScheduleIds),
        });
      }

      const result: any = await queryRunner.manager.save(
        WorkCenterDailyScheduleEntity,
        workCenterDailyScheduleEntites,
      );
      const workCenterDailyScheduleShiftEntites = [];
      result.forEach((workCenterDailySchedule) => {
        workCenterDailyScheduleShiftEntites.push(
          ...serializeWorkCenterDailyScheduleShiftEntites[
            moment(workCenterDailySchedule.executionDay).toISOString()
          ].map((shift) => {
            shift.workCenterDailyScheduleId = workCenterDailySchedule.id;

            return shift;
          }),
        );
      });

      result.workCenterDailyScheduleShifts = await queryRunner.manager.save(
        workCenterDailyScheduleShiftEntites,
      );

      // const queryCreateMaterialDailySchedule =
      //   await this.workOrderScheduleDetailRepository.syncToMaterialPlanSchedules(
      //     workOrderScheduleDetail.id,
      //   );

      // await queryRunner.manager.query(queryCreateMaterialDailySchedule, [
      //   workOrderScheduleDetail.id,
      // ]);

      // const response = plainToInstance(WorkOrderScheduleResponseDto, result, {
      //   excludeExtraneousValues: true,
      // });

      await queryRunner.commitTransaction();

      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }
  }

  public async getDailySchedule(
    workCenterId: number,
    workOrderScheduleDetailId: number,
  ): Promise<any> {
    const workCenterDailySchedule =
      await this.workCenterDailyScheduleRepository.getListByWorkOrderScheduleDetail(
        workCenterId,
        workOrderScheduleDetailId,
      );
    const workOrder =
      await this.workOrderRepository.getDetailByWorkOrderScheduleDetail(
        workOrderScheduleDetailId,
      );

    const workOrderMaterialResponse =
      await this.workOrderRepository.getMaterials(workOrder.id);
    const materials = workOrderMaterialResponse.inputs?.filter((input) =>
      isEmpty(input.bom),
    );

    const materialItemIds = map(materials, 'itemId');
    if (!isEmpty(materialItemIds)) {
      const materiaItems = await this.itemService.getItemsByIds(
        materialItemIds,
        true,
      );
      materials.forEach((material) => {
        material.item = materiaItems[material.itemId];
      });
    }

    let qcCriteria = {};
    let workCenterQcPlan = {};
    let qcPlanByWorkOrder = {};
    if (
      workOrder &&
      workOrder.producingStep.qcCheck &&
      workOrder.producingStep.qcCriteriaId
    ) {
      try {
        [qcCriteria, workCenterQcPlan, qcPlanByWorkOrder] = await Promise.all([
          this.qmsxService.getQuanlityPointById(
            workOrder.producingStep.qcCriteriaId,
          ),
          this.qmsxService.getWorkCenterQcPlan(workCenterId, workOrder.id),
          this.qmsxService.getQuanlityPlanBomsByWorkOrderId(workOrder.id),
        ]);
      } catch (e) {
        console.log('ERROR_QMSX:', e);
      }
    }
    if (!isEmpty(workCenterDailySchedule)) {
      const workCenterShifts =
        await this.workCenterShiftRepository.findWithRelations({
          where: { workCenterId },
          relations: ['workCenterShiftRelaxTime'],
        });
      workCenterShifts.map((shift) => {
        shift['workCenterShiftsRelaxTimes'] = shift.workCenterShiftRelaxTime;
        return shift;
      });
      return new ResponseBuilder(
        await this.formatDetailScheduleByPlan(
          workCenterId,
          workOrderScheduleDetailId,
          workCenterDailySchedule,
          workCenterDailySchedule[0].planFrom,
          workCenterDailySchedule[0].planTo,
          workCenterShifts,
          qcCriteria,
          workCenterQcPlan,
          qcPlanByWorkOrder,
          workOrder?.outputQc?.itemPerMemberTime,
          workOrder?.producingStep?.productionTimePerItem,
          materials,
        ),
      )
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    return await this.genAndSaveDailySchedule(
      workCenterId,
      workOrderScheduleDetailId,
    );
  }

  public async genAndSaveDailySchedule(
    workCenterId,
    workOrderScheduleDetailId,
  ): Promise<any> {
    let workCenter =
      await this.workCenterRepository.getWorkCenterByWorkOrderSchedule(
        workCenterId,
        workOrderScheduleDetailId,
      );
    if (!workCenter || isEmpty(workCenter)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.BAD_REQUEST'),
      ).toResponse();
    }

    workCenter = genScheduleByShifts(
      workCenter.workOrderScheduleDetail.planFrom,
      workCenter.workOrderScheduleDetail.planTo,
      workCenter.workOrderScheduleDetail.quantity,
      workCenter,
      workCenter.performance,
      workCenter.workOrderScheduleDetail.productionTimePerItem,
    );
    const scheduleDetails = workCenter.scheduleDetails.map((e) => ({
      executionDay: moment(e.executionDay).toISOString(),
      scheduleShiftDetails: e.scheduleShiftDetails,
    }));
    const response = await this.formatDetailScheduleByPlan(
      workCenterId,
      workOrderScheduleDetailId,
      scheduleDetails,
      workCenter.workOrderScheduleDetail.planFrom,
      workCenter.workOrderScheduleDetail.planTo,
      workCenter.workCenterShifts,
    );
    if (
      ![WorkOrderScheduleDetailStatusEnum.CONFIRMED].includes(
        workCenter.workOrderScheduleDetail.status,
      )
    ) {
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    if (!isEmpty(scheduleDetails)) {
      const requestCreateWorkCenterSchedule =
        new CreateWorkCenterScheduleRequestDto();
      requestCreateWorkCenterSchedule.id = workCenterId;
      requestCreateWorkCenterSchedule.workOrderId = workCenter.workOrderId;
      requestCreateWorkCenterSchedule.scheduleDetails = {
        workCenterScheduleDetails: response.workCenterScheduleDetails.filter(
          (workCenterScheduleDetail) =>
            sumBy(workCenterScheduleDetail.scheduleShiftDetails, 'quantity') >
            0,
        ),
        workCenterRepairScheduleDetails:
          response.workCenterRepairScheduleDetails.filter(
            (workCenterRepairScheduleDetail) =>
              sumBy(
                workCenterRepairScheduleDetail.scheduleShiftDetails,
                'quantity',
              ) > 0,
          ),
      };
      await this.createWorkCenterSchedule(requestCreateWorkCenterSchedule);
    }

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async formatDetailScheduleByPlan(
    workCenterId,
    worOrderScheduleDetailId,
    scheduleDetails,
    planFrom,
    planTo,
    workCenterShifts,
    qcCriteria?,
    workCenterQcPlan?,
    qcPlanByWorkOrder?,
    itemPerMemberTime?,
    productionTimePerItem?,
    materials?,
  ) {
    const workCenterResponse = await this.detail(workCenterId);
    const workOrderScheduleDetail =
      await this.workOrderScheduleDetailRepository.findOneWithRelations({
        where: {
          id: worOrderScheduleDetailId,
        },
      });
    const scheduleDetailsByPlan = this.formatScheduleByPlan(
      scheduleDetails,
      planFrom,
      planTo,
      workCenterShifts,
    );

    let workCenterRepairSchedule = [],
      scheduleQcDetails = [];

    if (!isEmpty(qcCriteria) && !isEmpty(qcPlanByWorkOrder)) {
      const qcCriteriaQuantity = qcCriteria?.quantity || 0;
      const qcCriteriaNumberOfTime =
        +qcCriteria?.numberOfTime === QcNumberOfTimeEnum.TWO ? 2 : 1;
      const qcCriteriaErrorAcceptanceRate =
        (qcPlanByWorkOrder?.planErrorRate || 0) / 100 || 0;
      const qcQuantityPercentage =
        +qcCriteria?.formality === QcCriteriaFormalityEnum.PERCENTAGE
          ? qcCriteriaQuantity / 100
          : 1;
      const totalQuantityQc = Math.ceil(
        mul(
          +qcCriteriaNumberOfTime,
          mul(
            mul(+qcQuantityPercentage, plus(1, +qcCriteriaErrorAcceptanceRate)),
            +workOrderScheduleDetail.quantity,
          ),
        ),
      );
      const totalQuantityRepair = Math.ceil(
        mul(
          +qcQuantityPercentage,
          mul(+qcCriteriaErrorAcceptanceRate, workOrderScheduleDetail.quantity),
        ),
      );
      try {
        scheduleQcDetails = genScheduleQcByShifts(
          planFrom,
          planTo,
          totalQuantityQc,
          workCenterShifts,
          qcPlanByWorkOrder?.qualityPlanBomQualityPointUsers?.length,
          itemPerMemberTime,
          scheduleDetailsByPlan,
        );
      } catch (e) {
        console.log({ e });
      }

      scheduleQcDetails = this.formatScheduleByPlan(
        scheduleQcDetails,
        planFrom,
        planTo,
        workCenterShifts,
      );

      const workCenter = await this.workCenterRepository.findOneById(
        workCenterId,
      );
      workCenterRepairSchedule = genScheduleRepairByShifts(
        planFrom,
        planTo,
        totalQuantityRepair,
        workCenterShifts,
        workCenter.productivityIndex,
        productionTimePerItem,
        scheduleDetailsByPlan,
      );
      workCenterRepairSchedule = this.formatScheduleByPlan(
        workCenterRepairSchedule,
        planFrom,
        planTo,
        workCenterShifts,
      );
    }

    const materialScheduleDetails = isEmpty(scheduleDetailsByPlan)
      ? []
      : scheduleDetailsByPlan?.map((workCenterDailySchedule) => {
          const totalQuantity = sumBy(
            workCenterDailySchedule.scheduleShiftDetails,
            'quantity',
          );
          return {
            executionDay: workCenterDailySchedule.executionDay,
            materials: materials?.map((material) => ({
              ...material,
              quantity: material.quantity * totalQuantity,
            })),
          };
        });

    return {
      workCenter: workCenterResponse.data,
      workOrderScheduleDetail,
      workCenterScheduleDetails: scheduleDetailsByPlan,
      materialScheduleDetails: plainToInstance(
        MaterialWorkCenterDailyScheduleResponseDto,
        materialScheduleDetails,
        {
          excludeExtraneousValues: true,
        },
      ),
      workCenterRepairScheduleDetails: workCenterRepairSchedule,
      defaultScheduleQcDetails: scheduleQcDetails,
      workCenterQcPlan: workCenterQcPlan,
    };
  }

  private formatScheduleByPlan(
    scheduleDetails,
    planFrom,
    planTo,
    workCenterShifts,
  ) {
    const diffDay = getDiffDay(planFrom, planTo);
    const scheduleDetailsByPlan = keyBy(scheduleDetails, (schedule) =>
      moment(schedule.executionDay)
        .set({
          hour: 0,
          minute: 0,
          second: 0,
          millisecond: 0,
        })
        .utcOffset(0, true)
        .format(),
    );
    for (let i = 0; i < diffDay; i++) {
      const executionDay = moment(planFrom)
        .add(i, 'days')
        .set({
          hour: 0,
          minute: 0,
          second: 0,
          millisecond: 0,
        })
        .utcOffset(0, true)
        .format();
      const scheduleByDay = has(scheduleDetailsByPlan, executionDay)
        ? scheduleDetailsByPlan[executionDay]
        : {
            executionDay: moment(planFrom)
              .add(i, 'days')
              .set({
                hour: 0,
                minute: 0,
                second: 0,
                millisecond: 0,
              })
              .utcOffset(0)
              .format(),
            scheduleShiftDetails: [],
          };
      const shiftIds = map(flatMap(scheduleByDay), 'workCenterShiftId');
      workCenterShifts.forEach((workCenterShift) => {
        if (shiftIds.length > 0 && !shiftIds.includes(workCenterShift.id)) {
          scheduleByDay.scheduleShiftDetails.push({
            quantity: 0,
            workCenterShiftId: workCenterShift.id,
            name: workCenterShift.name,
            moderationQuantity: 0,
            actualQuantity: 0,
            qcRejectQuantity: 0,
            qcPassQuantity: 0,
            errorQuantity: 0,
          });
        }
      });
      scheduleDetailsByPlan[executionDay] = plainToInstance(
        WorkCenterDailyScheduleResponseDto,
        scheduleByDay,
        {
          excludeExtraneousValues: true,
        },
      );
    }
    return sortBy(values(scheduleDetailsByPlan), 'executionDay');
  }

  public async approveWorkCenterSchedule(
    request: UpdateWorkCenterScheduleStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { userId, id, scheduleId } = request;
    const workCenterSchedule =
      await this.workCenterDailyScheduleRepository.findOneWithRelations({
        where: {
          workCenterId: id,
          id: scheduleId,
        },
      });

    if (!workCenterSchedule) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.WORK_CENTER_DAILY_SCHEDULE_NOT_FOUND',
          ),
        )
        .build();
    }

    if (
      !CAN_CONFIRM_WORK_CENTER_DAILY_SCHEDULE_STATUS.includes(
        workCenterSchedule.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.STATUS_IS_INVALID'))
        .build();
    }
    workCenterSchedule.approverId = userId;
    workCenterSchedule.approvedAt = new Date(Date.now());
    workCenterSchedule.status = WorkCenterDailyScheduleStatusEnum.CONFIRMED;

    const result = await this.workCenterDailyScheduleRepository.create(
      workCenterSchedule,
    );

    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async rejectWorkCenterSchedule(
    request: UpdateWorkCenterScheduleStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { userId, id, scheduleId } = request;
    const workCenterSchedule =
      await this.workCenterDailyScheduleRepository.findOneWithRelations({
        where: {
          workCenterId: id,
          id: scheduleId,
        },
      });

    if (!workCenterSchedule) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.WORK_CENTER_DAILY_SCHEDULE_NOT_FOUND',
          ),
        )
        .build();
    }

    if (
      !CAN_REJECT_WORK_CENTER_DAILY_SCHEDULE_STATUS.includes(
        workCenterSchedule.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.STATUS_IS_INVALID'))
        .build();
    }
    workCenterSchedule.approverId = userId;
    workCenterSchedule.approvedAt = new Date(Date.now());
    workCenterSchedule.status = WorkCenterDailyScheduleStatusEnum.REJECTED;

    const result = await this.workCenterDailyScheduleRepository.create(
      workCenterSchedule,
    );

    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async deleteWorkCenterDailySchedule(
    request: DeleteWorkCenterDailyScheduleRequestDto,
  ) {
    const { id, workOrderScheduleDetailId } = request;
    const workCenterDailySchedule =
      await this.workCenterDailyScheduleRepository.findOneByCondition({
        workCenterId: id,
        workOrderScheduleDetailId,
      });
    if (isEmpty(workCenterDailySchedule)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.WORK_CENTER_DAILY_SCHEDULE_NOT_FOUND'),
      ).toResponse();
    }
    if (
      !CAN_DELETE_WORK_CENTER_DAILY_SCHEDULE_STATUS.includes(
        workCenterDailySchedule.status,
      )
    ) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_IS_INVALID'),
      ).toResponse();
    }
    await this.workCenterDailyScheduleRepository.removeByCondition({
      workCenterId: id,
      workOrderScheduleDetailId,
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async isExist(request: SetStatusRequestDto): Promise<ResponsePayload<any>> {
    const { id, userId } = request;

    const workCenter = await this.workCenterRepository.findOneById(id);

    if (!workCenter) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.EXIST_WORK_CENTER)
        .build();
    }

    const userWorkCenters = await this.workCenterUserRepository.isExist({
      workCenterId: id,
      memberId: userId,
    });

    if (userWorkCenters.length == 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_EXIST_USER_WORK_CENTER)
        .build();
    }
    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async getWorkCenterByIds(ids: number[]): Promise<any> {
    const response = await this.workCenterRepository.findWithRelations({
      where: { id: In(ids) },
      relations: [
        'workCenterShifts',
        'producingStep',
        'workCenterShiftRelaxTimes',
      ],
    });

    let returnData = [];
    if (!isEmpty(response)) {
      returnData = response.map((workCenter) => {
        const totalWorkingTime = workCenter.workCenterShifts.reduce(
          (total, shift) => {
            const duration = moment(shift.endAt, DEFAULT_TIME_FORMAT).diff(
              moment(shift.startAt, DEFAULT_TIME_FORMAT),
              'minutes',
            );
            return total + duration;
          },
          0,
        );

        const totalRelaxTime = workCenter.workCenterShiftRelaxTimes.reduce(
          (total, shiftRelax) => {
            const duration = moment(shiftRelax.endAt, DEFAULT_TIME_FORMAT).diff(
              moment(shiftRelax.startAt, DEFAULT_TIME_FORMAT),
              'minutes',
            );
            return total + duration;
          },
          0,
        );
        const actualWorkingTime = minus(totalWorkingTime, totalRelaxTime);
        const workingCapacity = div(
          actualWorkingTime || 1,
          +workCenter.producingStep.productionTimePerItem || 1,
        );
        return {
          ...workCenter,
          actualWorkingCapacity: mul(
            workingCapacity || 1,
            +workCenter.productivityIndex || 1,
          ),
        };
      });
    }
    return new ResponseBuilder(returnData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  async saveWorkCenters(request: any): Promise<any> {
    const dataCreate = [];
    const dataUpdate = [];
    const dataNewEntities: WorkCenterEntity[] = [];
    const dataUpdateEntities: WorkCenterEntity[] = [];
    const error = [];

    return new ResponseBuilder([
      [...dataNewEntities, ...dataUpdateEntities],
      error,
    ])
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
