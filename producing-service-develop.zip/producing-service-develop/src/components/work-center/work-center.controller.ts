import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { CreateWorkCenterScheduleRequestDto } from '@components/work-order/dto/request/create-work-center-schedule.request.dto';
import { MessagePattern } from '@nestjs/microservices';
import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateWorkCenterShiftRequestDto } from './dto/request/create-work-center-shift.dto';
import { CreateWorkCenterRequestDto } from './dto/request/create-work-center.request.dto';
import { GetListWorkCenterRequestDto } from './dto/request/get-list-work-center.request.dto';
import { UpdateWorkCenterBodyDto } from './dto/request/update-work-center.request.dto';
import { GetListWorkCenterResponseDto } from './dto/response/get-list-work-center.response.dto';
import { WorkCenterResponseDto } from './dto/response/work-center.response.dto';
import { WorkCenterServiceInterface } from './interface/work-center.service.interface';
import { UpdateWorkCenterScheduleStatusRequestDto } from './dto/request/update-work-center-schedule-status.request.dto';
import { DeleteWorkCenterDailyScheduleRequestDto } from './dto/request/delete-work-center-daily-schedule.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  DELETE_WORK_CENTER_DAILY_SCHEDULE_PERMISSION,
  DETAIL_WORK_CENTER_DAILY_SCHEDULE_PERMISSION,
  UPDATE_WORK_CENTER_DAILY_SCHEDULE_PERMISSION,
} from '@utils/permissions/work-center-plan';
import {
  CREATE_WORK_CENTER_PERMISSION,
  UPDATE_WORK_CENTER_PERMISSION,
  DELETE_WORK_CENTER_PERMISSION,
  DETAIL_WORK_CENTER_PERMISSION,
  LIST_WORK_CENTER_PERMISSION,
} from '@utils/permissions/work-center';
import { DetailRequestDto } from '@utils/common.request.dto';
import { SetStatusRequestDto } from '@components/work-center/dto/request/set-status.request.dto';
import { ApiOperation, ApiParam, ApiResponse } from '@nestjs/swagger';
import { WorkCenterDailyScheduleResponseDto } from './dto/response/work-center-daily-schedule.response.dto';
import { DEFAULT_TRANSPORT } from '@utils/constant';
import { GetListPlcBomItemRequestDto } from './dto/request/get-list-plc-bom-item.request.dto';
import { PlcBomItemResponseDto } from '@components/work-center/dto/response/plc-bom-item.response.dto';
import { SuccessResponseDto } from '@components/producing-step/dto/response/success.response.dto';
import { ChangeRunningStatusRequestDto } from '@components/work-order/dto/request/change-running-status.request.dto';
import { PlcBomItemDetailResponseDto } from './dto/response/plc-bom-item-detail.response.dto';
import { NATS_PRODUCE } from '@config/nats.config';

@Controller('work-centers')
export class WorkCenterController {
  constructor(
    @Inject('WorkCenterServiceInterface')
    private readonly workCenterService: WorkCenterServiceInterface,
  ) {}

  @PermissionCode(CREATE_WORK_CENTER_PERMISSION.code)
  @Post('create')
  @ApiOperation({
    tags: ['Work Center'],
    summary: 'Create Work Center',
    description: 'Tạo mới xưởng',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: WorkCenterResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.work_center_create`, DEFAULT_TRANSPORT)
  public async create(
    @Body() payload: CreateWorkCenterRequestDto,
  ): Promise<ResponsePayload<WorkCenterResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workCenterService.create(request);
  }

  @PermissionCode(UPDATE_WORK_CENTER_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Work Center'],
    summary: 'Update Work Center',
    description: 'Sửa thông tin xưởng',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: WorkCenterResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.work_center_update`, DEFAULT_TRANSPORT)
  public async update(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateWorkCenterBodyDto,
  ): Promise<ResponsePayload<WorkCenterResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;

    return await this.workCenterService.update(request);
  }

  @PermissionCode(DELETE_WORK_CENTER_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Work Center'],
    summary: 'Delete Work Center',
    description: 'Xóa thông tin xưởng',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  @MessagePattern(`${NATS_PRODUCE}.work_center_delete`, DEFAULT_TRANSPORT)
  public async delete(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    return await this.workCenterService.delete(id);
  }

  // @PermissionCode(DELETE_WORK_CENTER_PERMISSION.code)
  @Get('/:id/plc-bom-items')
  @ApiOperation({
    tags: ['Work Center'],
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: PlcBomItemResponseDto,
  })
  public async getBomItemListPlc(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: GetListPlcBomItemRequestDto,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.workCenterService.getBomItemListPlc(request);
  }

  @Get('/:id/plc-bom-items/:moBomId')
  @ApiOperation({
    tags: ['Work Center'],
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: PlcBomItemDetailResponseDto,
  })
  public async getBomItemDetailPlc(
    @Param('id', new ParseIntPipe()) id,
    @Param('moBomId', new ParseIntPipe()) moBomId,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    return await this.workCenterService.getBomItemDetailPlc(id, moBomId);
  }

  @Put(':id/plc/:moBomId/running-status')
  @ApiOperation({
    tags: ['Work Order'],
    summary: 'Submit Work Order Running Status',
  })
  @ApiResponse({
    status: 200,
    description: 'Submit successfully',
    type: SuccessResponseDto,
  })
  public async setRunningStatus(
    @Param('id', new ParseIntPipe()) id: number,
    @Param('moBomId', new ParseIntPipe()) moBomId: number,
    @Body() payload: ChangeRunningStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.workCenterService.setRunningStatus(id, moBomId, request);
  }

  @PermissionCode(DETAIL_WORK_CENTER_PERMISSION.code)
  @Get(':id')
  @ApiOperation({
    tags: ['Work Center'],
    summary: 'Detail Work Center',
    description: 'Chi tiết xưởng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: WorkCenterResponseDto,
  })
  //@MessagePattern('work_center_detail')
  public async detail(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<WorkCenterResponseDto | any>> {
    return await this.workCenterService.detail(id);
  }

  @PermissionCode(LIST_WORK_CENTER_PERMISSION.code)
  @Get('list')
  @ApiOperation({
    tags: ['Work Center'],
    summary: 'List Work Center',
    description: 'Danh sách xưởng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListWorkCenterResponseDto,
  })
  //@MessagePattern('work_center_list')
  public async getList(
    @Query() payload: GetListWorkCenterRequestDto,
  ): Promise<ResponsePayload<GetListWorkCenterResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workCenterService.getList(request);
  }

  @Put(':id/confirm')
  @ApiOperation({
    tags: ['WorkCenter Confirm'],
    summary: 'Confirmed WorkCenter ',
    description: 'Confirm WorkCenter',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: WorkCenterResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.work_center_confirm`, DEFAULT_TRANSPORT)
  public async confirmWorkCenter(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<WorkCenterResponseDto | any>> {
    return await this.workCenterService.confirm({ id } as SetStatusRequestDto);
  }

  @Post(':id/work-center-shifts/create')
  @ApiOperation({
    tags: ['Work Center', 'Work Center Shift'],
    summary: 'Create Work Center Shift',
    description: 'Tạo ca làm việc cho xưởng',
  })
  @MessagePattern(`${NATS_PRODUCE}.create_work_center_shift`, DEFAULT_TRANSPORT)
  public async createWorkCenterShift(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: CreateWorkCenterShiftRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.workCenterId = id;
    return await this.workCenterService.createWorkCenterShift(request);
  }

  @PermissionCode(UPDATE_WORK_CENTER_DAILY_SCHEDULE_PERMISSION.code)
  @Post(':id/schedules')
  @ApiOperation({
    tags: ['Work Center', 'Schedule'],
    summary: 'Create Schedule Detail Work Center',
    description: 'Tạo lịch làm việc theo ngày',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: WorkCenterResponseDto,
  })
  @MessagePattern(
    `${NATS_PRODUCE}.create_work_center_schedule`,
    DEFAULT_TRANSPORT,
  )
  public async createWorkCenterSchedule(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: CreateWorkCenterScheduleRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.workCenterService.createWorkCenterSchedule(request);
  }

  @Delete('work-center-shifts/:id')
  @ApiOperation({
    tags: ['Work Center', 'Work Center Shift'],
    summary: 'xóa ca làm việc',
  })
  @ApiParam({
    name: 'id',
    example: '1',
    type: Number,
    description: 'work center shift id',
  })
  @ApiResponse({
    status: 200,
    description: 'delete successfully',
  })
  @MessagePattern(`${NATS_PRODUCE}.delete_work_center_shift`, DEFAULT_TRANSPORT)
  public async deleteWorkCenterShift(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    return await this.workCenterService.deleteWorkCenterShift(id);
  }

  @PermissionCode(DETAIL_WORK_CENTER_DAILY_SCHEDULE_PERMISSION.code)
  @Get(':id/schedules/work-order-schedule-details/:workOrderScheduleDetailId')
  @ApiOperation({
    tags: ['Work Center', 'Schedule'],
    summary: 'List Daily Schedule Work Center',
    description: 'Danh sách lịch làm việc theo ngày',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully',
    type: WorkCenterDailyScheduleResponseDto,
  })
  @ApiParam({
    name: 'workCenterId',
    type: Number,
    example: 601,
    required: true,
    description: 'Work Center ID',
  })
  @ApiParam({
    name: 'workOrderScheduleDetailId',
    type: Number,
    example: 601,
    required: true,
    description: 'Work Order Schedule Detail ID',
  })
  // @MessagePats----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------q                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  qsśs                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            tern('daily_schedule_list')
  public async getListDailySchedule(
    @Param('id', new ParseIntPipe()) id,
    @Param('workOrderScheduleDetailId', new ParseIntPipe())
    workOrderScheduleDetailId,
  ): Promise<any> {
    return await this.workCenterService.getDailySchedule(
      id,
      workOrderScheduleDetailId,
    );
  }

  @Put(':id/daily-schedules/:scheduleId/approve')
  @ApiOperation({
    tags: ['Work Center', 'Shift', 'Schedule'],
    summary: 'Approve Schedule Detail Work Center',
    description: 'Approve lịch làm việc theo ngày',
  })
  @ApiResponse({
    status: 200,
    description: 'Approve successfully',
  })
  @MessagePattern(
    `${NATS_PRODUCE}.approve_work_center_schedule`,
    DEFAULT_TRANSPORT,
  )
  public async approveWorkCenterSchedule(
    @Param('id', new ParseIntPipe()) id,
    @Param('scheduleId', new ParseIntPipe()) scheduleId,
    payload: UpdateWorkCenterScheduleStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    request.scheduleId = scheduleId;
    return await this.workCenterService.approveWorkCenterSchedule(request);
  }

  @Put(':id/daily-schedules/:scheduleId/reject')
  @ApiOperation({
    tags: ['Work Center', 'Shift', 'Schedule'],
    summary: 'Reject Schedule Detail Work Center',
    description: 'Reject lịch làm việc theo ngày',
  })
  @ApiResponse({
    status: 200,
    description: 'REject successfully',
  })
  @MessagePattern(
    `${NATS_PRODUCE}.reject_work_center_schedule`,
    DEFAULT_TRANSPORT,
  )
  public async rejectWorkCenterSchedule(
    @Param('id', new ParseIntPipe()) id,
    @Param('scheduleId', new ParseIntPipe()) scheduleId,
    payload: UpdateWorkCenterScheduleStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    request.scheduleId = scheduleId;
    return await this.workCenterService.rejectWorkCenterSchedule(request);
  }

  @PermissionCode(DELETE_WORK_CENTER_DAILY_SCHEDULE_PERMISSION.code)
  @Delete(
    '/:id/schedules/work-order-schedule-details/:workOrderScheduleDetailId',
  )
  @ApiOperation({
    tags: ['Work Center', 'Schedule'],
    summary: 'Delete Daily Schedule Work Center',
    description: 'xóa work center daily schedule',
  })
  @ApiResponse({
    status: 200,
    description: 'Successfully',
    type: SuccessResponse,
  })
  @ApiParam({
    name: 'id',
    type: Number,
    example: 601,
    required: true,
    description: 'Work Center ID',
  })
  @ApiParam({
    name: 'workOrderScheduleDetailId',
    type: Number,
    example: 601,
    required: true,
    description: 'Work Order Schedule Detail ID',
  })
  @MessagePattern(
    `${NATS_PRODUCE}.delete_work_center_daily_schedule`,
    DEFAULT_TRANSPORT,
  )
  public async deleteWorkCenterDailySchedule(
    @Param('id', new ParseIntPipe()) id,
    @Param('workOrderScheduleDetailId', new ParseIntPipe())
    workOrderScheduleDetailId,
    payload: DeleteWorkCenterDailyScheduleRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;
    request.workOrderScheduleDetailId = workOrderScheduleDetailId;
    return await this.workCenterService.deleteWorkCenterDailySchedule(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.is_exist_work_center`, DEFAULT_TRANSPORT)
  public async isExist(
    @Body() payload: SetStatusRequestDto,
  ): Promise<ResponsePayload<WorkCenterResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workCenterService.isExist(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.is_exist_work_center`, DEFAULT_TRANSPORT)
  public async isExistTcp(
    @Body() payload: SetStatusRequestDto,
  ): Promise<ResponsePayload<WorkCenterResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workCenterService.isExist(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.get_work_center_by_ids`, DEFAULT_TRANSPORT)
  public async getWorkCenterByIds(
    @Body() request: any,
  ): Promise<ResponsePayload<any>> {
    return await this.workCenterService.getWorkCenterByIds(request.ids);
  }
  // @TODO: remove when refactor done
  @MessagePattern(`${NATS_PRODUCE}.get_work_center_by_ids`, DEFAULT_TRANSPORT)
  public async getWorkCenterByIdsTcp(
    @Body() request: any,
  ): Promise<ResponsePayload<any>> {
    return await this.workCenterService.getWorkCenterByIds(request.ids);
  }

  // TODO remove when refactor done
  @PermissionCode(DETAIL_WORK_CENTER_PERMISSION.code)
  @MessagePattern(`${NATS_PRODUCE}.work_center_detail`, DEFAULT_TRANSPORT)
  public async detailTcp(
    @Body() payload: DetailRequestDto,
  ): Promise<ResponsePayload<WorkCenterResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.workCenterService.detail(request.id, request.baseInfo);
  }

  // TODO remove when refactor done
  @PermissionCode(LIST_WORK_CENTER_PERMISSION.code)
  @MessagePattern(`${NATS_PRODUCE}.work_center_list`, DEFAULT_TRANSPORT)
  public async getListTcp(
    @Body() payload: GetListWorkCenterRequestDto,
  ): Promise<ResponsePayload<GetListWorkCenterResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.workCenterService.getList(request);
  }

  @PermissionCode(DETAIL_WORK_CENTER_DAILY_SCHEDULE_PERMISSION.code)
  @MessagePattern(`${NATS_PRODUCE}.daily_schedule_list`, DEFAULT_TRANSPORT)
  public async getListDailyScheduleTcp(
    @Body() payload: any,
    workOrderScheduleDetailId,
  ): Promise<any> {
    const { request } = payload;
    return await this.workCenterService.getDailySchedule(
      request.id,
      workOrderScheduleDetailId,
    );
  }
}
