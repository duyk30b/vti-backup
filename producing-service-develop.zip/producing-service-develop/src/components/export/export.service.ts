import { Inject, Injectable } from '@nestjs/common';
import { ExportServiceInterface } from './interface/export.service.interface';
import { Alignment, Borders, Font, Workbook } from 'exceljs';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import {
  EXCEL_STYLE,
  MAX_NUMBER_PAGE,
  ROW,
  SHEET,
  TypeEnum,
} from './export.constant';
import { flatMap, isEmpty, keyBy, map, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ExportRequestDto } from './dto/request/export.request.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { GetListProducingStepRequestDto } from '@components/producing-step/dto/request/get-list-producing-step.request.dto';
import { GetListRoutingRequestDto } from '@components/routing/dto/request/get-list-routing.request.dto';
import { RoutingRepositoryInterface } from '@components/routing/interface/routing.repository.interface';
import { ProducingStepRepositoryInterface } from '@components/producing-step/interface/producing-step.repository.interface';
import { BoqRepositoryInterface } from '@components/boq/interface/boq.repository.interface';
import { GetBoqListRequestDto } from '@components/boq/dto/request/get-boq-list.request.dto';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { ManufacturingOrderRepositoryInterface } from '@components/manufacturing-order/interface/manufacturing-order.repository.interface';
import { MaterialRequestWarningRepositoryInterface } from '@components/material-request-warning/interface/material-request-warning.repository.interface';
import { MaterialRequestWarningServiceInterface } from '@components/material-request-warning/interface/material-request-warning.service.interface';
import { MaterialPlanRepositoryInterface } from '@components/material/interface/material-plan.repository.interface';
import { MoPlanBomRepositoryInteface } from '@components/plan/inteface/mo-plan-bom.repository.inteface';
import { SaleServiceInterface } from '@components/sale-order/interface/sale.service.interface';
import { ReportQualityRequestDto } from '@components/boq/dto/request/report-quality.request.dto';
import { GetListMaterialRequestWarningRequestDto } from '@components/material-request-warning/dto/request/get-list-material-request-warning.request.dto';
import { GetListManufacturingOrderRequestDto } from '@components/manufacturing-order/dto/request/get-list-manufacturing-order.request.dto';
import { ReportServiceInterface } from '@components/report/interface/report.service.interface';
@Injectable()
export class ExportService implements ExportServiceInterface {
  constructor(
    @Inject('RoutingRepositoryInterface')
    private readonly routingRepository: RoutingRepositoryInterface,

    @Inject('ProducingStepRepositoryInterface')
    private readonly producingStepRepository: ProducingStepRepositoryInterface,

    @Inject('BoqRepositoryInterface')
    private readonly boqRepository: BoqRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('MaterialPlanRepositoryInterface')
    private readonly materialPlanRepository: MaterialPlanRepositoryInterface,

    @Inject('MaterialRequestWarningRepositoryInterface')
    private readonly materialRequestWarningRepository: MaterialRequestWarningRepositoryInterface,

    @Inject('MoPlanBomRepositoryInterface')
    private readonly moPlanBomRepository: MoPlanBomRepositoryInteface,

    @Inject('ManufacturingOrderRepositoryInterface')
    private readonly manufacturingOrderRepository: ManufacturingOrderRepositoryInterface,

    @Inject('SaleServiceInterface')
    private readonly saleService: SaleServiceInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    @Inject('MaterialRequestWarningServiceInterface')
    private readonly materialRequestWarningService: MaterialRequestWarningServiceInterface,

    @Inject('ReportServiceInterface')
    private readonly reportService: ReportServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async export(request: ExportRequestDto, res: any): Promise<any> {
    const { queryIds, type } = request;
    if (!isEmpty(queryIds) && queryIds.length > ROW.LIMIT_EXPORT) {
      return new ResponseBuilder()
        .withMessage(
          await this.i18n.translate('error.LIMIT_EXPORT_ONE_SHEET_ERROR'),
        )
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }

    let workbook;
    switch (type) {
      case TypeEnum.ROUTING:
        workbook = await this.exportRoutings(request);
        break;
      case TypeEnum.PRODUCING_STEP:
        workbook = await this.exportProducingSteps(request);
        break;
      case TypeEnum.BOQ:
        workbook = await this.exportBoqs(request);
        break;
      case TypeEnum.EXPORT_REPORT_QUANLITY:
        workbook = await this.exportReportQuality(request);
        break;
      case TypeEnum.MATERIAL_REQUEST_WARNING:
        workbook = await this.exportMaterialRequestWarning(request);
        break;
      case TypeEnum.REPORT_MATERIAL:
        workbook = await this.exportReportMaterial(request);
        break;
      case TypeEnum.MANUFACTURING_ORDER_REPORT:
        workbook = await this.exportManufacturingOrderReport(request);
        break;
      default:
        break;
    }
    if (workbook?.xlsx) {
      // await workbook?.xlsx.writeFile('export.xlsx');
      const file = await workbook.xlsx.writeBuffer();
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(file)
        .build();
    } else {
      return workbook;
    }
  }

  async exportRoutings(payload: any) {
    let users: any;
    let routings: any[] = [];
    let producingSteps: any[] = [];
    const titleMap: any = new Map();
    const headersMap: any = new Map();
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListRoutingRequestDto();
      request.page = i;
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const { result } = await this.routingRepository.getList(request);
      if (!isEmpty(result)) {
        routings = routings.concat(result);
      }
      if (result.length > ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }
    if (!routings || isEmpty(routings)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }
    const userIds = uniq(map(routings, 'createdBy'));
    if (!isEmpty(userIds)) {
      users = await this.userService.getUsers(userIds);
    }
    const userMap = keyBy(users, 'id');
    const requestProducingStep = new GetListProducingStepRequestDto();
    const listProducingStep = await this.producingStepRepository.getList(
      requestProducingStep,
    );
    producingSteps = producingSteps.concat(listProducingStep.data);

    const headers = [
      {
        key: 'code',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.routing.code'),
      },
      {
        key: 'name',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.routing.name'),
      },
      {
        key: 'status',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.routing.status'),
      },
      {
        key: 'description',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.routing.description'),
      },
      {
        key: 'createdBy',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.common.createdBy'),
      },
      {
        key: 'createdAt',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
          numFmt: EXCEL_STYLE.DDMMYYYYHHMMSS,
        },
        title: await this.i18n.translate('export.common.createdAt'),
      },
    ];
    const subHeaders = [
      {
        key: 'code',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.routing.code'),
      },
      {
        key: 'producingStepCode',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.producingStep.code'),
      },
      {
        key: 'producingStepName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.producingStep.name'),
      },
      {
        key: 'stepNumber',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.producingStep.stepNumber'),
      },
    ];
    const items: any[] = routings?.map((routing) => {
      const item: any = {
        code: routing.code || '',
        name: routing.name || '',
        status: routing.status || '',
        description: routing.description || '',
        createdBy: userMap[routing.createdBy]?.fullName || '',
        createdAt: routing.createdAt || '',
      };
      return item;
    });
    titleMap.set(1, [await this.i18n.translate('export.routing.title')]);
    titleMap.set(2, [
      await this.i18n.translate('export.routing.detailRouting.title'),
    ]);
    headersMap.set(1, headers);
    headersMap.set(2, subHeaders);

    for (let i = 0; i < routings.length; i++) {
      const routing = routings[i];
      const arrProducingStepId = routing.producingSteps.map((producingId) => {
        return producingId.id;
      });
      items[i].subItem = [];
      for (let j = 0; j < producingSteps.length; j++) {
        const producingStep = producingSteps[j];
        if (arrProducingStepId.includes(producingStep.id)) {
          items[i].subItem.push({
            code: routing.code || '',
            producingStepCode: producingStep.code || '',
            producingStepName: producingStep.name || '',
          });
        }
      }
    }
    let workbook = new Workbook();

    workbook = await this.exportMultiSheetUtil(
      workbook,
      items,
      1,
      titleMap,
      headersMap,
      '',
    );
    return workbook;
  }
  async exportProducingSteps(payload: any) {
    let users: any;
    let producingSteps: any[] = [];
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListProducingStepRequestDto();
      request.page = i;
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const { data } = await this.producingStepRepository.getList(request);
      if (!isEmpty(data)) {
        producingSteps = producingSteps.concat(data);
      }
      if (data.length > ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }
    if (!producingSteps || isEmpty(producingSteps)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }
    const userIds = uniq(map(producingSteps, 'createdBy'));
    if (!isEmpty(userIds)) {
      users = await this.userService.getUsers(uniq(userIds));
    }
    const userMap = keyBy(users, 'id');
    const data = producingSteps.map((producingStep) => {
      return {
        name: producingStep.name || '',
        code: producingStep.code || '',
        description: producingStep.description || '',
        createdAt: producingStep.createdAt || '',
        updatedAt: producingStep.updatedAt || '',
        status: producingStep.status || '',
        switchMode: producingStep.switchMode || '',
        productionTimePerItem: producingStep.productionTimePerItem || '',
        qcQuantityRule: producingStep.qcQuantityRule || '',
        createdBy: userMap[producingStep.createdBy]?.fullName || '',
      };
    });
    const headers = [
      {
        key: 'code',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.producingStep.code'),
      },
      {
        key: 'name',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.producingStep.name'),
      },
      {
        key: 'description',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.producingStep.description'),
      },
      {
        key: 'createdAt',
        width: 25,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
          numFmt: EXCEL_STYLE.DDMMYYYYHHMMSS,
        },
        title: await this.i18n.translate('export.common.createdAt'),
      },
      {
        key: 'updatedAt',
        width: 25,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
          numFmt: EXCEL_STYLE.DDMMYYYYHHMMSS,
        },
        title: await this.i18n.translate('export.common.updatedAt'),
      },
      {
        key: 'status',
        width: 25,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
        },
        title: await this.i18n.translate('export.producingStep.status'),
      },
      {
        key: 'switchMode',
        width: 25,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
        },
        title: await this.i18n.translate('export.producingStep.switchMode'),
      },
      {
        key: 'productionTimePerItem',
        width: 25,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.producingStep.productionTimePerItem',
        ),
      },
      {
        key: 'qcQuantityRule',
        width: 25,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
        },
        title: await this.i18n.translate('export.producingStep.qcQuantityRule'),
      },
      {
        key: 'createdBy',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.common.createdBy'),
      },
    ];
    const workbook = await this.exportOneSheetUtil(
      data,
      [await this.i18n.translate('export.producingStep.title')],
      headers,
    );
    return workbook;
  }

  async exportOneSheetUtil(data: any[], title: any, headers: any) {
    const workbook = new Workbook();
    let countRowData = ROW.COUNT_START_ROW;
    let countSheet = SHEET.START_SHEET;
    data.forEach((element) => {
      let worksheet = workbook.getWorksheet(SHEET.NAME + countSheet);
      if (countRowData == ROW.COUNT_START_ROW) {
        worksheet = workbook.addWorksheet(SHEET.NAME + countSheet);

        const titleRow = worksheet.getRow(1);
        titleRow.values = title;
        titleRow.font = <Font>EXCEL_STYLE.TITLE_FONT;

        const headerRow = worksheet.getRow(3);
        headerRow.values = headers.map((header) => header.title);
        headerRow.eachCell(function (cell) {
          cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
          cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        });
      }
      worksheet.columns = headers;
      worksheet
        .addRow({
          ...element,
        })
        .eachCell(function (cell) {
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          cell.font = <Font>EXCEL_STYLE.DEFAULT_FONT;
        });

      countRowData++;
      if (countRowData == ROW.COUNT_END_ROW) {
        countSheet++;
        countRowData = ROW.COUNT_START_ROW;
      }
    });
    return workbook;
  }

  async exportBoqs(payload: any) {
    let users: any;
    let boqs: any[] = [];
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetBoqListRequestDto();
      request.page = i;
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }

      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const { result } = await this.boqRepository.getList(request);
      boqs = boqs.concat(result);
      if (result.length > ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }
    if (isEmpty(boqs)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }
    const userIds = uniq(map(boqs, 'createdByUserId'));
    if (!isEmpty(userIds)) {
      users = await this.userService.getUsers(uniq(userIds));
    }
    const userMap = keyBy(users, 'id');

    const data = boqs.map((boq) => {
      return {
        code: boq.code || '',
        name: boq.name || '',
        status: boq.status || '',
        pm: boq.pm || '',
        planFrom: boq.planFrom || '',
        planTo: boq.planTo || '',
        description: boq.description || '',
        createdByUserId: userMap[boq.createdByUserId]?.fullName || '',
        createdAt: boq.createdAt || '',
      };
    });
    const headers = [
      {
        key: 'code',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.boq.code'),
      },
      {
        key: 'name',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.boq.name'),
      },
      {
        key: 'pm',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.boq.pm'),
      },
      {
        key: 'planFrom',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.boq.planFrom'),
      },
      {
        key: 'planTo',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.boq.planTo'),
      },
      {
        key: 'status',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.boq.status'),
      },
      {
        key: 'description',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.boq.description'),
      },
      {
        key: 'createdAt',
        width: 25,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
          numFmt: EXCEL_STYLE.DDMMYYYYHHMMSS,
        },
        title: await this.i18n.translate('export.common.createdAt'),
      },
      {
        key: 'createdByUserId',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.common.createdBy'),
      },
    ];
    const workbook = await this.exportOneSheetUtil(
      data,
      [await this.i18n.translate('export.boq.title')],
      headers,
    );
    return workbook;
  }
  async exportReportQuality(payload: any) {
    let reportQualitys: any[] = [];
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new ReportQualityRequestDto();
      const allItemIds = await this.moPlanBomRepository.allItemIds();
      const sortedItems = await this.itemService.getItemsByRelations({
        where: allItemIds.map((i) => {
          return { id: i.itemId };
        }),
        order: {
          name: 'ASC',
        },
      });
      const sortedItemIds = sortedItems.map((i) => i.id);
      let saleOrderIds = [];
      let saleOrders;
      const moPlanBoms = await this.moPlanBomRepository.getAllSaleOrderIds();
      saleOrderIds = map(moPlanBoms, 'saleOrderId');
      if (isEmpty(saleOrders) && !isEmpty(saleOrderIds)) {
        saleOrders = await this.saleService.getSaleOrdersByIds(saleOrderIds);
      }
      request.page = i;
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const { data } = await this.moPlanBomRepository.reportQualityList(
        request,
        sortedItemIds,
        saleOrders,
      );
      reportQualitys = reportQualitys.concat(data);

      if (data.lenth >= ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }
    if (!reportQualitys || isEmpty(reportQualitys)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const itemIds = uniq(map(reportQualitys, 'itemId'));

    let listItem;
    if (!isEmpty(itemIds)) {
      listItem = await this.itemService.getItemsByIds(itemIds, true);
    }
    const itemMap = keyBy(listItem, 'id');
    const data = reportQualitys?.map((reportQuality) => {
      return {
        moCode: reportQuality.manufacturingOrder.code || '',
        soCode: reportQuality.saleOrder.name || '',
        itemName: itemMap[reportQuality.itemId].name || '',
        routingName: reportQuality.routing.name || '',
        producingStepName: reportQuality.producingStep.name || '',
        quantity: reportQuality.quantity || '',
        exportQuantity: reportQuality.exportQuantity || '',
        quantityNeedQC: reportQuality.quantityNeedQC || '',
        errorQuantity: reportQuality.errorQuantity || '',
        remainingErrors: reportQuality.remainingErrors || '',
      };
    });
    const headers = [
      {
        key: 'moCode',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.reportQuality.manufacturingOrder.code',
        ),
      },
      {
        key: 'soCode',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.reportQuality.saleOrder.name'),
      },
      {
        key: 'itemName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.reportQuality.item.name'),
      },
      {
        key: 'routingName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.reportQuality.routing.name'),
      },
      {
        key: 'producingStepName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.reportQuality.producing-step.name',
        ),
      },
      {
        key: 'quantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.reportQuality.quantity'),
      },
      {
        key: 'exportQuantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.reportQuality.exportQuantity'),
      },
      {
        key: 'quantityNeedQC',
        width: 25,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
        },
        title: await this.i18n.translate('export.reportQuality.quantityNeedQC'),
      },
      {
        key: 'errorQuantity',
        width: 25,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
        },
        title: await this.i18n.translate('export.reportQuality.errorQuantity'),
      },
      {
        key: 'remainingErrors',
        width: 25,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.reportQuality.remainingErrors',
        ),
      },
    ];
    const workbook = await this.exportOneSheetUtil(
      data,
      [await this.i18n.translate('export.reportQuality.title')],
      headers,
    );
    return workbook;
  }
  async exportMaterialRequestWarning(payload: any) {
    let responseData: any[] = [];
    let list;
    const titleMap: any = new Map();
    const headersMap: any = new Map();
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListMaterialRequestWarningRequestDto();
      request.page = i;
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      list =
        await this.materialRequestWarningService.getListMaterialRequestWarningItem(
          request,
        );
      if (!isEmpty(list.data.items)) {
        responseData = responseData.concat(list.data.items);
      }
      if (list.data.items.length > ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    let listItem: any = {};
    const itemIds = uniq(map(flatMap(responseData, 'itemDetails'), 'id'));
    if (!isEmpty(itemIds)) {
      listItem = await this.itemService.getItemsByIds(itemIds, true);
    }

    const headers = [
      {
        key: 'code',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.materialWarning.code'),
      },
      {
        key: 'name',
        width: 40,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.materialWarning.name'),
      },
      {
        key: 'moName',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.materialWarning.moName'),
      },
      {
        key: 'soName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.materialWarning.soName'),
      },
      {
        key: 'planFrom',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.materialWarning.planFrom'),
      },
      {
        key: 'planTo',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.materialWarning.planTo'),
      },
      {
        key: 'factoryName',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.materialWarning.factoryName'),
      },
      {
        key: 'createdAt',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
          numFmt: EXCEL_STYLE.DDMMYYYYHHMMSS,
        },
        title: await this.i18n.translate('export.common.createdAt'),
      },
      {
        key: 'status',
        width: 15,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
        },
        title: await this.i18n.translate('export.materialWarning.status'),
      },
    ];
    const subHeaders = [
      {
        key: 'code',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.materialWarning.code'),
      },
      {
        key: 'itemCode',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.materialWarning.item.code'),
      },
      {
        key: 'itemName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.materialWarning.item.name'),
      },
      {
        key: 'itemTypeName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.materialWarning.item.itemTypeName',
        ),
      },
      {
        key: 'quantity',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.materialWarning.item.quantity',
        ),
      },
      {
        key: 'itemUnitName',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.materialWarning.item.itemUnitName',
        ),
      },
    ];

    const items: any[] = responseData.map((materialWarning) => {
      const item: any = {
        code: materialWarning?.code,
        name: materialWarning?.name,
        moName: materialWarning?.manufacturingOrder?.name || '',
        soName: materialWarning?.saleOrder?.name || '',
        planFrom: materialWarning?.planFrom,
        planTo: materialWarning?.planTo,
        factoryName: materialWarning?.factory?.name || '',
        createdAt: materialWarning?.createdAt,
        status: materialWarning?.status,
      };
      return item;
    });
    titleMap.set(1, [
      await this.i18n.translate('export.materialWarning.title'),
    ]);
    titleMap.set(2, [
      await this.i18n.translate('export.materialWarning.item.title'),
    ]);
    headersMap.set(1, headers);
    headersMap.set(2, subHeaders);

    for (let i = 0; i < responseData.length; i++) {
      const materialWarning = responseData[i];
      items[i].subItem = materialWarning.itemDetails.map((item) => {
        const itemDetail = listItem[item.id];
        return {
          code: materialWarning.code,
          itemCode: itemDetail?.code || '',
          itemName: itemDetail?.name || '',
          itemTypeName: itemDetail?.itemType?.name || '',
          quantity: materialWarning.itemDetails.quantity,
          itemUnitName: itemDetail?.itemUnitName || '',
        };
      });
    }
    let workbook = new Workbook();
    workbook = await this.exportMultiSheetUtil(
      workbook,
      items,
      1,
      titleMap,
      headersMap,
      '',
    );
    return workbook;
  }
  async exportReportMaterial(payload: any) {
    let listMaterialsReport: any[] = [];
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListManufacturingOrderRequestDto();
      request.page = i;
      if (payload.queryIds) {
        request.queryIds = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const { result } = await this.manufacturingOrderRepository.getList(
        request,
      );
      if (!isEmpty(result)) {
        listMaterialsReport = listMaterialsReport.concat(result);
      }
      if (result.length > ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    let saleOrderIds: any[] = [];
    let saleOrders;
    saleOrderIds = uniq(map(listMaterialsReport, 'saleOrderId'));
    if (!isEmpty(saleOrderIds)) {
      saleOrders = await this.saleService.getSaleOrdersByIds(
        saleOrderIds,
        true,
      );
    }
    const saleOrderMap = keyBy(saleOrders, 'id');

    if (!listMaterialsReport || isEmpty(listMaterialsReport)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }
    const data = listMaterialsReport.map((materialReport) => {
      return {
        moCode: materialReport.code || '',
        moName: materialReport.code || '',
        soName: saleOrderMap[materialReport.saleOrderId]?.name || '',
        planFrom: materialReport.planFrom || '',
        planTo: materialReport.planTo || '',
        status: materialReport.status || '',
      };
    });
    const headers = [
      {
        key: 'moCode',
        width: 15,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: await this.i18n.translate('export.materialReport.moCode'),
      },
      {
        key: 'moName',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: await this.i18n.translate('export.materialReport.moName'),
      },
      {
        key: 'soName',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE,
        },
        title: await this.i18n.translate('export.materialReport.soName'),
      },
      {
        key: 'planFrom',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
          numFmt: EXCEL_STYLE.DDMMYYYYHHMMSS,
        },
        title: await this.i18n.translate('export.materialReport.planFrom'),
      },
      {
        key: 'planTo',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
          numFmt: EXCEL_STYLE.DDMMYYYYHHMMSS,
        },
        title: await this.i18n.translate('export.materialReport.planTo'),
      },
      {
        key: 'status',
        width: 25,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
        },
        title: await this.i18n.translate('export.materialReport.status'),
      },
    ];
    const workbook = await this.exportOneSheetUtil(
      data,
      [await this.i18n.translate('export.materialReport.title')],
      headers,
    );
    return workbook;
  }

  async exportManufacturingOrderReport(payload: any) {
    const titleMap: any = new Map();
    const headersMap: any = new Map();
    const { id, itemId, productionLineId } = payload;
    const reportMOResponse =
      await this.reportService.getManufacturingOrderReport(payload);
    if (reportMOResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
      return reportMOResponse;
    }
    if (isEmpty(reportMOResponse?.data)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const {
      materialReport,
      producingStepReport,
      // workerWorkloadReport
    } = reportMOResponse.data;
    //lay lenh san xuat
    const manufacturingOrder =
      await this.manufacturingOrderRepository.findOneById(id);
    // lay san pham
    // let itemIds = workerWorkloadReport.map(
    //   (workerWorkload) => workerWorkload.bom.itemId,
    // );
    // itemIds = uniq([...itemIds, itemId]);
    const items = await this.itemService.getItemsByIds([itemId]);
    const itemMap = keyBy(items, 'id');

    //header vat tu
    const materialReportHeaders = [
      {
        key: 'code',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.manufacturingOrderReport.material.code',
        ),
      },
      {
        key: 'name',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.manufacturingOrderReport.material.name',
        ),
      },
      {
        key: 'unit',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.manufacturingOrderReport.material.unit',
        ),
      },
      {
        key: 'planQuantity',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.manufacturingOrderReport.material.planQuantity',
        ),
      },
      {
        key: 'availableStock',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.manufacturingOrderReport.material.availableStock',
        ),
      },
    ];

    //header nhan cong
    // const workerWorkloadReportHeaders = [
    //   {
    //     key: 'producingStep',
    //     width: 15,
    //     style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
    //     title: await this.i18n.translate(
    //       'export.manufacturingOrderReport.workerWorkload.producingStep',
    //     ),
    //   },
    //   {
    //     key: 'unit',
    //     width: 30,
    //     style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
    //     title: await this.i18n.translate(
    //       'export.manufacturingOrderReport.workerWorkload.unit',
    //     ),
    //   },
    //   {
    //     key: 'workerWorkload',
    //     width: 30,
    //     style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
    //     title: await this.i18n.translate(
    //       'export.manufacturingOrderReport.workerWorkload.workerWorkload',
    //     ),
    //   },
    //   {
    //     key: 'actualWorkerWorkload',
    //     width: 30,
    //     style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
    //     title: await this.i18n.translate(
    //       'export.manufacturingOrderReport.workerWorkload.actualWorkerWorkload',
    //     ),
    //   },
    // ];

    //header giai doan
    const producingStepReportHeaders = [
      {
        key: 'name',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.manufacturingOrderReport.producingStep.name',
        ),
      },
      {
        key: 'unit',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.manufacturingOrderReport.producingStep.unit',
        ),
      },
      {
        key: 'planQuantity',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.manufacturingOrderReport.producingStep.planQuantity',
        ),
      },
      {
        key: 'producedQuantity',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.manufacturingOrderReport.producingStep.producedQuantity',
        ),
      },
      // {
      //   key: 'fromAnotherLotQuantity',
      //   width: 30,
      //   style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      //   title: await this.i18n.translate(
      //     'export.manufacturingOrderReport.producingStep.fromAnotherLotQuantity',
      //   ),
      // },
      // {
      //   key: 'keepQuantity',
      //   width: 30,
      //   style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      //   title: await this.i18n.translate(
      //     'export.manufacturingOrderReport.producingStep.keepQuantity',
      //   ),
      // },
      {
        key: 'scrapQuantity',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.manufacturingOrderReport.producingStep.scrapQuantity',
        ),
      },
      // {
      //   key: 'sampleQuantity',
      //   width: 30,
      //   style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      //   title: await this.i18n.translate(
      //     'export.manufacturingOrderReport.producingStep.sampleQuantity',
      //   ),
      // },
      {
        key: 'inputQuantity',
        width: 30,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
        },
        title: await this.i18n.translate(
          'export.manufacturingOrderReport.producingStep.inputQuantity',
        ),
      },
      // {
      //   key: 'performance',
      //   width: 30,
      //   style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
      //   title: await this.i18n.translate(
      //     'export.manufacturingOrderReport.producingStep.performance',
      //   ),
      // },
    ];

    const titles = [
      `${await this.i18n.translate('export.manufacturingOrderReport.title')}`,
      `${await this.i18n.translate(
        'export.manufacturingOrderReport.codeTitle',
      )} ${manufacturingOrder?.code || ''}`,
      `${await this.i18n.translate(
        'export.manufacturingOrderReport.itemTitle',
      )} ${itemMap[itemId]?.name || ''}`,
    ];
    titleMap.set(1, titles);
    titleMap.set(2, titles);
    titleMap.set(3, titles);

    headersMap.set(1, materialReportHeaders);
    // headersMap.set(2, workerWorkloadReportHeaders);
    headersMap.set(2, producingStepReportHeaders);

    const materialReportData: any[] = materialReport.map((item) => {
      return {
        code: item.code || '',
        name: item.name || '',
        unit: item.itemUnitName || '',
        planQuantity: +item.planQuantity || 0,
        availableStock: +item.inputQuantity || 0,
      };
    });
    // const workerWorkloadReportData: any[] = workerWorkloadReport.map((item) => {
    //   return {
    //     producingStep: item.producingStep.name || '',
    //     unit: 'Giờ',
    //     workerWorkload: item.workerWorkload || '',
    //     actualWorkerWorkload: item.actualWorkerWorkload || '',
    //   };
    // });
    const producingStepReportData: any[] = producingStepReport.map((item) => {
      // const performance = (
      //   ((+item.inputQuantity + +item.sampleQuantity + +item.keepQuantity) /
      //     (+item.planQuantity + +item.fromAnotherLotQuantity)) *
      //   100
      // ).toFixed(5);
      return {
        name: item.producingStep.name || '',
        unit: itemMap[item?.bom?.itemId]?.itemUnitName || '',
        planQuantity: +item.planQuantity || 0, //sl ke hoach
        // fromAnotherLotQuantity: +item.fromAnotherLotQuantity || 0, //sl chuyen tu lo cu
        // keepQuantity: +item.keepQuantity || 0, //so luong giu lai cho cong doan sau
        producedQuantity: +item.producedQuantity || 0, //so luong da san xuat
        scrapQuantity: +item.scrapQuantity || 0, //so luong loi
        // sampleQuantity: +item.sampleQuantity || 0, //so luong lay mau
        inputQuantity: +item.inputQuantity || 0, //so luong chuyen giao
        //hieu suat
        // performance: `${performance || 0}%`,
      };
    });
    let workbook = new Workbook();
    workbook = await this.exportMultiSheetUtil(
      workbook,
      materialReportData,
      1,
      titleMap,
      headersMap,
      'Nguyên vật liệu',
    );
    // workbook = await this.exportMultiSheetUtil(
    //   workbook,
    //   workerWorkloadReportData,
    //   2,
    //   titleMap,
    //   headersMap,
    //   'Nhân công',
    // );
    workbook = await this.exportMultiSheetUtil(
      workbook,
      producingStepReportData,
      2,
      titleMap,
      headersMap,
      'Giai đoạn',
    );
    return workbook;
  }
  async exportMultiSheetUtil(
    workbook: Workbook,
    items: any[],
    level: any,
    titleMap: any,
    headersMap: any,
    sheetName: string,
  ) {
    let countRowData = ROW.COUNT_START_ROW;

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      let worksheet = sheetName
        ? workbook.getWorksheet(sheetName)
        : workbook.getWorksheet(SHEET.NAME + level);
      if (!worksheet) {
        worksheet = sheetName
          ? workbook.addWorksheet(sheetName)
          : workbook.addWorksheet(SHEET.NAME + level);

        if (countRowData == ROW.COUNT_START_ROW) {
          let titleRowCount = 1;
          let titles = titleMap.get(level);

          while (titleRowCount <= titles.length) {
            const titleRow = worksheet.getCell('A' + titleRowCount);

            titleRow.value = titles[titleRowCount - 1];
            titleRow.font = <Font>EXCEL_STYLE.TITLE_FONT;
            ++titleRowCount;
          }

          const headerRow = worksheet.getRow(titles.length + 2);
          headerRow.values = headersMap
            .get(level)
            .map((header) => header.title);
          headerRow.eachCell(function (cell) {
            cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
            cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
            cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          });
        }
        worksheet.columns = headersMap.get(level);
      }

      worksheet
        .addRow({
          ...item,
        })
        .eachCell(function (cell) {
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          cell.font = <Font>EXCEL_STYLE.DEFAULT_FONT;
        });
      if (item.subItem?.length > 0) {
        workbook = await this.exportMultiSheetUtil(
          workbook,
          item.subItem,
          level + 1,
          titleMap,
          headersMap,
          '',
        );
      }
    }

    return workbook;
  }

  // async exportTemplateUtil(
  //   data: any[],
  //   title: any,
  //   headerTitles: any,
  //   headers: any,
  // ) {
  //   const workbook = new Workbook();
  //   await workbook.xlsx.readFile('static/template/export/company.xlsx');

  //   let countRowData = ROW.countStartRow;
  //   let countSheet = SHEET.startSheet;

  //   data.forEach((element, index) => {
  //     if (countRowData == ROW.countStartRow && index > 0) {
  //       workbook.addWorksheet(SHEET.name + countSheet).model =
  //         workbook.getWorksheet(SHEET.name + SHEET.startSheet).model;
  //     }

  //     workbook.getWorksheet(SHEET.name + countSheet).addRow({
  //       ...element,
  //     });

  //     countRowData++;
  //     if (countRowData == ROW.countEndRow) {
  //       countSheet++;
  //       countRowData = ROW.countStartRow;
  //     }
  //   });
  //   return workbook;
  // }
}
