import { MaterialRequestWarningService } from '@components/material-request-warning/material-request-warning.service';
import { MaterialService } from '@components/material/material.service';
import { RoutingModule } from '@components/routing/routing.module';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { BomProducingStepDetailEntity } from '@entities/bom/bom-producing-steps.entity';
import { BomEntity } from '@entities/bom/boms.entity';
import { Boq } from '@entities/boq/boqs.entity';
import { ManufacturingOrderEntity } from '@entities/manufacturing-order/manufacturing-orders.entity';
import { MoPlanBomEntity } from '@entities/manufacturing-order/mo-plan-boms.entity';
import { MaterialRequestWarningEntity } from '@entities/material-request-warning/material-request-warning.entity';
import { MaterialPlanStructureEntity } from '@entities/material/material-plan-structure.entity';
import { MaterialPlanEntity } from '@entities/material/material-plan.entity';
import { MaterialToRepairErrorEntity } from '@entities/material/material-quantity-to-repair-error.entity';
import { ProducingStepEntity } from '@entities/producing-step/producing-step.entity';
import { RoutingEntity } from '@entities/routing/routing.entity';
import { WorkOrderScrapTransactionEntity } from '@entities/work-order/work-order-scrap-transaction.entity';
import { WorkOrderEntity } from '@entities/work-order/work-order.entity';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BomProducingStepDetailsRepository } from '@repositories/bom/bom-producing-step-details.repository';
import { BomRepository } from '@repositories/bom/bom.repository';
import { BoqRepository } from '@repositories/boq/boq.repository';
import { ManufacturingOrderRepository } from '@repositories/manufacturing-order/manufacturing-order.repository';
import { MaterialRequestWarningRepository } from '@repositories/material-request-warning/material-request-warning.repository';
import { MaterialPlanStructureRepository } from '@repositories/material/material-plan-structure.repository';
import { MaterialPlanRepository } from '@repositories/material/material-plan.repository';
import { MaterialToRepairErrorRepository } from '@repositories/material/material-to-repair-error.repository';
import { MoPlanBomRepository } from '@repositories/plan/mo-plan-bom.repository';
import { ProducingStepRepository } from '@repositories/produce/producing-step.repository';
import { RoutingRepository } from '@repositories/routing.repository';
import { WorkOrderRepository } from '@repositories/work-order/work-order.repository';
import { ExportController } from './export.controller';
import { ExportService } from './export.service';
import { ReportService } from '@components/report/report.service';
import { ReportModule } from '@components/report/report.module';

@Global()
@Module({
  imports: [
    ConfigModule,
    TypeOrmModule.forFeature([
      RoutingEntity,
      ProducingStepEntity,
      Boq,
      MaterialPlanEntity,
      MaterialRequestWarningEntity,
      MoPlanBomEntity,
      ManufacturingOrderEntity,
      MaterialToRepairErrorEntity,
      WorkOrderEntity,
      WorkOrderScrapTransactionEntity,
      BomProducingStepDetailEntity,
      BomEntity,
    ]),
    UserModule,
    RoutingModule,
    ReportModule,
  ],
  providers: [
    {
      provide: 'ExportServiceInterface',
      useClass: ExportService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'RoutingRepositoryInterface',
      useClass: RoutingRepository,
    },
    {
      provide: 'ProducingStepRepositoryInterface',
      useClass: ProducingStepRepository,
    },
    {
      provide: 'BoqRepositoryInterface',
      useClass: BoqRepository,
    },
    {
      provide: 'MaterialPlanRepositoryInterface',
      useClass: MaterialPlanRepository,
    },
    {
      provide: 'MaterialRequestWarningRepositoryInterface',
      useClass: MaterialRequestWarningRepository,
    },
    {
      provide: 'MoPlanBomRepositoryInterface',
      useClass: MoPlanBomRepository,
    },
    {
      provide: 'ManufacturingOrderRepositoryInterface',
      useClass: ManufacturingOrderRepository,
    },
    {
      provide: 'MaterialServiceInterface',
      useClass: MaterialService,
    },
    {
      provide: 'MaterialPlanStructureRepositoryInterface',
      useClass: MaterialPlanStructureRepository,
    },
    {
      provide: 'MaterialToRepairErrorRepositoryInterface',
      useClass: MaterialToRepairErrorRepository,
    },
    {
      provide: 'BomRepositoryInterface',
      useClass: BomRepository,
    },
    {
      provide: 'BomProducingStepDetailsRepositoryInterface',
      useClass: BomProducingStepDetailsRepository,
    },
    {
      provide: 'WorkOrderRepositoryInterface',
      useClass: WorkOrderRepository,
    },
    {
      provide: 'MaterialPlanStructureEntityRepository',
      useClass: MaterialPlanStructureEntity,
    },
    {
      provide: 'MaterialRequestWarningServiceInterface',
      useClass: MaterialRequestWarningService,
    },
    {
      provide: 'ReportServiceInterface',
      useClass: ReportService,
    },
  ],
  controllers: [ExportController],
  exports: [
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
  ],
})
export class ExportModule {}
