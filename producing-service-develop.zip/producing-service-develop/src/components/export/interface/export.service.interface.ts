import { ExportRequestDto } from '../dto/request/export.request.dto';

export interface ExportServiceInterface {
  export(request: ExportRequestDto, res: any): Promise<any>;
}
