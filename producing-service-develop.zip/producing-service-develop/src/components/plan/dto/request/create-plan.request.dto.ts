import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';

export class ProducingStepDto {
  @ApiProperty()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsInt()
  @IsOptional()
  workOrderId?: number;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  quantity: number;

  @ApiProperty()
  @IsDateString()
  planFrom: Date;

  @ApiProperty()
  @IsDateString()
  planTo: Date;
}
export class PlanBomDto {
  @ApiProperty()
  @IsInt()
  bomId: number;

  @IsInt()
  @ApiProperty()
  moDetailId: number;

  @ApiProperty()
  @IsInt()
  routingId: number;

  @ApiProperty()
  @IsNumber()
  quantity: number;

  @ApiProperty()
  @IsDateString()
  planFrom: Date;

  @ApiProperty()
  @IsDateString()
  planTo: Date;

  @ApiProperty()
  producingSteps: ProducingStepDto[];
}

export class CreatePlanRequest extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @MaxLength(4)
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @IsNotEmpty()
  @ApiProperty()
  @IsInt()
  moId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  planFrom: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  planTo: Date;

  @ApiProperty()
  @MaxLength(255)
  @IsString()
  description: string;

  @ApiProperty({
    type: [PlanBomDto],
  })
  @IsArray()
  @Type(() => PlanBomDto)
  planBoms: PlanBomDto[];
}
