import { IsNotEmpty, IsInt } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';

export class GetDetailPlanRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsInt()
  planId: number;
}
