import { IsNotEmpty, IsInt } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';

export class GetPlanWorkCenterScheduleListRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsInt()
  id: number;
}
