import { Progress } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { BasicResponseDto } from '@core/dto/response/basic.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { div, minus, mul, plus } from '@utils/common';
import { ResponsePayload } from '@utils/response-payload';
import { Expose, plainToInstance, Type } from 'class-transformer';
import { camelCase, isEmpty, mapKeys, max, min } from 'lodash';
import { BomDetailDto } from './detail-bom-plan.response';

export class BoqDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  code: string;

  @ApiProperty()
  name: string;
}

export class MoDto extends BasicResponseDto {}

export class BomDto extends BasicResponseDto {}

export class WorkCenterDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  code: string;

  @ApiProperty()
  name: string;
}

export class ItemDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  code: string;

  @ApiProperty()
  name: string;

  @ApiProperty()
  unit: string;

  @ApiProperty()
  itemTypeCode: string;

  @ApiProperty()
  itemType: string;
}

export class RoutingVersionDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  name: string;
}

export class RoutingDto extends BasicResponseDto {}
export class ProducingStepDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  code: string;

  @ApiProperty()
  name: string;

  @ApiProperty()
  stepNumber: number;
}
export class PlanBomMaterial {
  @ApiProperty()
  itemId: number;

  @ApiProperty()
  code: string;

  @ApiProperty()
  name: string;

  @ApiProperty()
  quantity: number;
}

export class PlanBomWorkOrderDto extends BasicResponseDto {
  @ApiProperty()
  moDetailId: number;

  @ApiProperty()
  parentBomId: number;

  @ApiProperty()
  moPlanBomId: number;

  @ApiProperty()
  code: string;

  @ApiProperty()
  quantity: number;

  @ApiProperty()
  errorQuantity: number;

  @ApiProperty()
  scrapQuantity: number;

  @ApiProperty()
  actualQuantity: number;

  @ApiProperty()
  confirmedQuantity: number;

  @ApiProperty()
  qcPassQuantity: number;

  @ApiProperty()
  qcRejectQuantity: number;

  @ApiProperty()
  exportQuantity: number;

  @ApiProperty()
  exportedQuantity: number;

  @ApiProperty()
  planFrom: Date;

  @ApiProperty()
  planTo: Date;

  @ApiProperty()
  startAt: Date;

  @ApiProperty()
  endAt: Date;

  @ApiProperty()
  description: string;

  @ApiProperty()
  status: number;

  @ApiProperty({
    enum: Progress,
  })
  progress: Progress;

  setProgress(): Progress {
    const now = new Date();
    const actual = this.actualQuantity ? this.actualQuantity : 0;
    const plan = this.quantity ? this.quantity : 0;
    const start = new Date(this.planFrom);
    const end = new Date(this.planTo);
    if (actual == 0 && now <= end) return Progress.NOTHING;
    if (plan == actual) return Progress.DONE;
    if (plan > actual && now > end) return Progress.LATE;
    const forcastQuantity = mul(
      plan,
      div(
        minus(now.getTime(), start.getTime()),
        minus(end.getTime(), start.getTime()),
      ),
    );
    if (forcastQuantity > actual && now > end) return Progress.LATE;
    return Progress.NORMAL;
  }
}

export class PlanProducingStep extends BasicResponseDto {
  @ApiProperty()
  producingStep: ProducingStepDto;

  @ApiProperty()
  actualQuantity: number;

  @ApiProperty()
  quantity: number;

  @ApiProperty()
  planDate: Date;

  @ApiProperty()
  executeDate: Date;

  @ApiProperty()
  endDate: Date;

  @ApiProperty()
  startAt: Date;

  @ApiProperty()
  endAt: Date;

  @ApiProperty()
  sumQuantity: number;

  @ApiProperty()
  sumActualQuantity: number;

  @ApiProperty()
  numberPlan: number;

  @ApiProperty()
  status: string;

  @ApiProperty({
    type: () => [PlanBomWorkOrderDto],
  })
  @Expose()
  workOrders: PlanBomWorkOrderDto[];

  @ApiProperty({
    enum: Progress,
  })
  progress: Progress;

  set progres(value) {
    this.progress = this.setProgress();
    this.startAt = min(
      this.workOrders.map((wo) => (wo.startAt ? wo.startAt : null)),
    );
    this.endAt = max(this.workOrders.map((wo) => (wo.endAt ? wo.endAt : null)));
    this.endAt = this.sumQuantity == this.sumActualQuantity ? this.endAt : null;
  }

  setProgress() {
    const now = new Date();
    this.workOrders = this.workOrders.map((wo) => {
      const woCammelCase = mapKeys(wo, (v, k) => camelCase(k));
      wo = plainToInstance(PlanBomWorkOrderDto, woCammelCase);
      wo.progress = wo.setProgress();
      return wo;
    });
    const actual = this.workOrders
      ? this.workOrders.reduce(
          (result, w) => plus(w.actualQuantity || 0, result),
          0,
        )
      : 0;
    const plan = this.workOrders
      ? this.workOrders.reduce((result, w) => plus(w.quantity || 0, result), 0)
      : 0;

    this.sumQuantity = plan;
    this.sumActualQuantity = actual;
    const start = new Date(this.executeDate);
    const end = new Date(this.endDate);
    if (actual == 0 && now <= end) return Progress.NOTHING;
    if (plan == actual) return Progress.DONE;
    if (plan > actual && now > end) return Progress.LATE;
    const forcastQuantity = mul(
      plan,
      div(
        minus(now.getTime(), start.getTime()),
        minus(end.getTime(), start.getTime()),
      ),
    );
    if (forcastQuantity > actual && now > end) return Progress.LATE;
    return Progress.NORMAL;
  }
}

export class PlansBom {
  @ApiProperty()
  moPlanId: number;

  @ApiProperty()
  moDetailId: number;

  bomId: number;

  itemId: number;

  @ApiProperty({
    type: RoutingDto,
  })
  routing: RoutingDto;

  @ApiProperty()
  quantity: number;

  @ApiProperty()
  confirmedQuantity: number;

  @ApiProperty()
  actualQuantity: number;

  @ApiProperty()
  planningQuantity: number;

  @ApiProperty()
  planDate: Date;

  @ApiProperty()
  executeDate: Date;

  @ApiProperty()
  planFrom: Date;

  @ApiProperty()
  planTo: Date;

  @ApiProperty()
  endDate: Date;

  @ApiProperty()
  startAt: Date;

  @ApiProperty()
  endAt: Date;

  @ApiProperty()
  status: string;

  @ApiProperty({
    type: [PlanProducingStep],
  })
  producingSteps: PlanProducingStep[];

  @ApiProperty({
    type: [BomDetailDto],
  })
  @Type(() => BomDetailDto)
  subBom: BomDetailDto[];

  @ApiProperty({
    enum: Progress,
  })
  progress: Progress;

  @ApiProperty({
    isArray: true,
    type: PlanBomMaterial,
  })
  materials: PlanBomMaterial[];

  setProgress(): Progress {
    const now = new Date();
    const actual = this.producingSteps
      ? this.producingSteps.reduce(
          (result, ps) => plus(ps.sumActualQuantity || 0, result),
          0,
        )
      : 0;
    const plan = this.producingSteps
      ? this.producingSteps.reduce(
          (result, ps) => plus(ps.sumQuantity || 0, result),
          0,
        )
      : 0;
    const start = new Date(this.executeDate);
    const end = new Date(this.endDate);
    if (actual == 0 && now <= end) return Progress.NOTHING;
    if (plan == actual) return Progress.DONE;
    if (plan > actual && now > end) return Progress.LATE;
    const forcastQuantity = mul(
      plan,
      div(
        minus(now.getTime(), start.getTime()),
        minus(end.getTime(), start.getTime()),
      ),
    );
    if (forcastQuantity > actual && now > end) return Progress.LATE;
    return Progress.NORMAL;
  }

  setMaterials(items: any): PlanBomMaterial[] {
    if (!isEmpty(this.materials)) {
      return this.materials.map((material) => ({
        ...material,
        ...items[material.itemId],
        quantity: mul(material.quantity, this.quantity),
      }));
    }

    return [];
  }
}

export class DetailPlanDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  code: string;

  @ApiProperty()
  name: string;

  @ApiProperty({
    type: MoDto,
  })
  mo: MoDto;

  @ApiProperty()
  planFrom: Date;

  @ApiProperty()
  planTo: Date;

  @ApiProperty()
  pmId: number;

  @ApiProperty()
  apmId: number;

  @ApiProperty()
  pmName: string;

  @ApiProperty()
  apmName: string;

  @ApiProperty()
  description: string;

  @ApiProperty({
    type: [BomDetailDto],
  })
  planBoms: BomDetailDto[];
}

export class DetailPlanResponse implements ResponsePayload<DetailPlanDto> {
  statusCode: ResponseCodeEnum;

  @ApiProperty({
    type: String,
  })
  message?: string;

  @ApiProperty({
    type: DetailPlanDto,
  })
  data?: DetailPlanDto;
}
