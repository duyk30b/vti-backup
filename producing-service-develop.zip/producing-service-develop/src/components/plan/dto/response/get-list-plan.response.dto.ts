import { Progress } from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ApiProperty } from '@nestjs/swagger';
import { PagingResponse } from '@utils/paging.response';
import { ResponsePayload } from '@utils/response-payload';

export class ListPlanResponse extends PagingResponse {
  items: PlanDto[];
}

export class PlanDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  code: string;

  @ApiProperty()
  name: string;

  @ApiProperty()
  planFrom: Date;

  @ApiProperty()
  planTo: Date;

  @ApiProperty()
  version: string;

  @ApiProperty()
  description: string;

  @ApiProperty()
  moId: number;

  @ApiProperty()
  moName: string;

  @ApiProperty()
  manufacturingRequestOrderId: string;

  @ApiProperty()
  manufacturingRequestOrderCode: string;

  @ApiProperty()
  status: number;

  @ApiProperty()
  progress: Progress;
}

export class GetListPlanResponse implements ResponsePayload<ListPlanResponse> {
  statusCode: ResponseCodeEnum;

  @ApiProperty({
    type: String,
  })
  message?: string;

  @ApiProperty({
    type: ListPlanResponse,
  })
  data?: ListPlanResponse;
}
