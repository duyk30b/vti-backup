import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { ManufacturingOrderResponseAbstractDto } from '@components/manufacturing-order/dto/response/manufacturing-order.response.abstract.dto';
import { BomResponseDto } from '@components/bom/dto/response/bom.response.dto';
import { RoutingResponseAbstractDto } from '@components/routing/dto/response/routing.response.abstract.dto';
import { ProducingStepResponseDto } from '@components/producing-step/dto/response/producing-step.response.dto';

class SaleOrderResponseDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'Đơn hàng gỗ', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'SO001', description: '' })
  @Expose()
  code: string;
}

export class MoPlanBomResponse {
  @ApiProperty({ type: ManufacturingOrderResponseAbstractDto })
  @Expose()
  @Type(() => ManufacturingOrderResponseAbstractDto)
  manufacturingOrder: ManufacturingOrderResponseAbstractDto;

  @ApiProperty({ type: BomResponseDto })
  @Expose()
  @Type(() => BomResponseDto)
  bom: BomResponseDto;

  @ApiProperty({ type: RoutingResponseAbstractDto })
  @Expose()
  @Type(() => RoutingResponseAbstractDto)
  routing: RoutingResponseAbstractDto;

  @ApiProperty({ type: ProducingStepResponseDto })
  @Expose()
  @Type(() => ProducingStepResponseDto)
  producingStep: ProducingStepResponseDto;

  @ApiProperty({ type: SaleOrderResponseDto })
  @Expose()
  @Type(() => SaleOrderResponseDto)
  saleOrder: SaleOrderResponseDto;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  quantity: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  actualQuantity: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  confirmedQuantity: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  errorQuantity: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  exportQuantity: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  exportedQuantity: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  qcPassQuantity: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  qcRejectQuantity: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  scrapQuantity: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  quantityNeedQC: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  totalQcQuantity: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  remainingErrors: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;
}

class MetaQuanlityReport {
  @ApiProperty({ example: 1 })
  @Expose()
  total: number;

  @ApiProperty({ example: 1 })
  @Expose()
  page: number;
}
export class QuanlityReport {
  @ApiProperty({ type: MoPlanBomResponse, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => MoPlanBomResponse)
  items: MoPlanBomResponse[];

  @ApiProperty({ type: MetaQuanlityReport })
  @Expose()
  @Type(() => MetaQuanlityReport)
  meta: MetaQuanlityReport;
}

export class GetListQuanlityReportResponseDto extends SuccessResponse {
  @ApiProperty({ type: QuanlityReport })
  @Expose()
  @Type(() => QuanlityReport)
  data: QuanlityReport;
}
