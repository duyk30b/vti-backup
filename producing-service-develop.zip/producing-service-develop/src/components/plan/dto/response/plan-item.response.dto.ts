import { BasicResponseDto } from '@core/dto/response/basic.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class PlanItemResponseDto extends BasicResponseDto {
  @Expose()
  @ApiProperty()
  itemUnitName: string;

  @Expose()
  @ApiProperty()
  itemUnitCode: string;
}
