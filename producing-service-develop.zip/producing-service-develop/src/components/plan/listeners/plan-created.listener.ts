import { BoqStatusEnum } from '@components/boq/boq.constant';
import { BoqRepositoryInterface } from '@components/boq/interface/boq.repository.interface';
import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';

@Injectable()
export class PlanCreatedListener {
  constructor(
    @Inject('MoRepositoryInterface')
    private readonly boqRepository: BoqRepositoryInterface,
  ) {}

  @OnEvent('plan.created')
  public async planCreatedHandler({ planId }) {
    return;
  }
}
