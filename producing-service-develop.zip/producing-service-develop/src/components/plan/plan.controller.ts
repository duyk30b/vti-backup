import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import {
  Body,
  Controller,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Query,
} from '@nestjs/common';
import { MessagePattern, Payload } from '@nestjs/microservices';
import { PlanServiceInterface } from './inteface/plan.service.interface';
import { ReportQualityRequestDto } from '@components/boq/dto/request/report-quality.request.dto';
import { isEmpty } from 'lodash';
import { CreatePlanRequest } from './dto/request/create-plan.request.dto';
import { UpdatePlanRequest } from './dto/request/update-plan.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { GetPlanWorkCenterScheduleListRequestDto } from './dto/request/get-plan-work-center-schedule-list.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CREATE_MANUFACTURING_ORDER_PLAN_PERMISSION,
  UPDATE_MANUFACTURING_ORDER_PLAN_PERMISSION,
  DELETE_MANUFACTURING_ORDER_PLAN_PERMISSION,
  DETAIL_MANUFACTURING_ORDER_PLAN_PERMISSION,
  LIST_MANUFACTURING_ORDER_PLAN_PERMISSION,
  CONFIRM_MANUFACTURING_ORDER_PLAN_PERMISSION,
  REJECT_MANUFACTURING_ORDER_PLAN_PERMISSION,
  COMPLETE_MANUFACTURING_ORDER_PLAN_PERMISSION,
} from '@utils/permissions/manufacturing-order-plan';
import { DeleteRequestDto } from '@utils/common.request.dto';
import { PRODUCTION_REPORT_PERMISSION } from '@utils/permissions/report';
import { generatePermissionCodes } from '@utils/common';
import { GetListPlanResponse } from './dto/response/get-list-plan.response.dto';
import { GetListPlanRequest } from './dto/request/get-list-plan.request.dto';
import { DetailBomPlanResponse } from './dto/response/detail-bom-plan.response';
import { DetailPlanResponse } from './dto/response/detail-plan.response';
import { ReportQualityResponseDto } from '@components/boq/dto/response/report-quality.response.dto';
import { GetDetailPlanRequestDto } from './dto/request/get-detail-plan.request.dto';
import {
  DEFAULT_MESSAGE_PATTERN_CONFIG,
  DEFAULT_TRANSPORT,
} from '@utils/constant';
const PERMISSION_CONFIRM_PLAN = generatePermissionCodes([
  CONFIRM_MANUFACTURING_ORDER_PLAN_PERMISSION.code,
  REJECT_MANUFACTURING_ORDER_PLAN_PERMISSION.code,
  COMPLETE_MANUFACTURING_ORDER_PLAN_PERMISSION.code,
]);
const PERMISSION_LIST_PLAN = generatePermissionCodes([
  LIST_MANUFACTURING_ORDER_PLAN_PERMISSION.code,
  PRODUCTION_REPORT_PERMISSION.code,
]);

@Controller('')
export class PlanController {
  constructor(
    @Inject('PlanServiceInterface')
    private readonly planService: PlanServiceInterface,
  ) {}

  @PermissionCode(PERMISSION_LIST_PLAN)
  @ApiOperation({
    tags: ['plans'],
    summary: 'Search plan',
    description: 'tìm kiếm hay lấy các plan',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: GetListPlanResponse,
  })
  @Get('/plans/list')
  public async listPlan(@Query() payload: GetListPlanRequest) {
    const { request } = payload;
    return await this.planService.listPlan(request);
  }

  @PermissionCode(DETAIL_MANUFACTURING_ORDER_PLAN_PERMISSION.code)
  @ApiOperation({
    tags: ['plans'],
    summary: 'Details plan',
    description: 'Lấy chi tiết plan',
  })
  @ApiResponse({
    description: 'Get successfully',
    type: DetailBomPlanResponse,
  })
  @Get('/plans/:id')
  public async getPlanById(@Param('id', new ParseIntPipe()) planId: number) {
    return await this.planService.getPLanById(planId);
  }

  @MessagePattern('plan_detail', DEFAULT_TRANSPORT)
  public async getPlanByIdTcp(@Body() payload: GetDetailPlanRequestDto) {
    const { request } = payload;
    return await this.planService.getPLanById(request.planId);
  }

  @ApiOperation({
    tags: ['plans'],
    summary: 'Details plan',
    description: 'Lấy chi tiết plan theo công trình lúc chưa tạo plan',
  })
  @ApiResponse({
    description: 'Get successfully',
    type: DetailBomPlanResponse,
  })
  @Get('/plans/mos/:id')
  @MessagePattern('detail_plan_by_mo', DEFAULT_TRANSPORT)
  public async getPlanByBoqId(@Param('id', new ParseIntPipe()) moId: number) {
    return await this.planService.getPLanByMoId(moId);
  }

  @PermissionCode(CREATE_MANUFACTURING_ORDER_PLAN_PERMISSION.code)
  @ApiOperation({
    tags: ['plans'],
    summary: 'Create plan',
    description: 'tạo plan',
  })
  @ApiResponse({
    description: 'Create successfully',
    type: DetailPlanResponse,
  })
  @Post('/plans')
  @MessagePattern('create_plan', DEFAULT_TRANSPORT)
  public async createPlan(@Body() payload: CreatePlanRequest) {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.planService.createPLan(request);
  }

  @PermissionCode(UPDATE_MANUFACTURING_ORDER_PLAN_PERMISSION.code)
  @MessagePattern('update_plan', DEFAULT_TRANSPORT)
  public async updatePlan(@Body() payload: UpdatePlanRequest) {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.planService.updatePLan(request);
  }

  @PermissionCode(PERMISSION_CONFIRM_PLAN)
  @MessagePattern('change_status_plan', DEFAULT_TRANSPORT)
  public async updateStatusPlan(@Body() request: any) {
    const { planId, status } = request;
    return await this.planService.updateStatusPlan(planId, status);
  }

  @Get('/reports/boqs-quality/list')
  @ApiOperation({
    tags: ['Reports', 'Produces'],
    summary: 'Get report of quality',
    description: 'Lấy thông tin chất lượng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ReportQualityResponseDto,
  })
  @MessagePattern('report_quality', DEFAULT_TRANSPORT)
  public async reportQualityList(
    @Query() body: ReportQualityRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.planService.reportQualityList(request);
  }

  @MessagePattern('report_proccess', DEFAULT_TRANSPORT)
  public async reportProccess(
    @Body() body: ReportQualityRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.planService.reportProccess();
  }

  @PermissionCode(DELETE_MANUFACTURING_ORDER_PLAN_PERMISSION.code)
  @MessagePattern('delete_plan', DEFAULT_TRANSPORT)
  public async deletePlan(
    @Body() payload: DeleteRequestDto,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.planService.deletePlan(request.id);
  }

  @ApiOperation({
    tags: ['Plan', 'Schedule'],
    summary: "Work center's plan",
    description: 'Danh sách kế hoạch xưởng theo master plan',
  })
  @ApiResponse({
    description: 'Get successfully',
    type: DetailBomPlanResponse,
  })
  @Get('/plans/:id/work-centers/schedules')
  public async getPlanWorkCenterScheduleList(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    return await this.planService.getPlanWorkCenterScheduleList({
      id,
    } as GetPlanWorkCenterScheduleListRequestDto);
  }

  @MessagePattern('get_plan_work_center_schedule_list')
  public async getPlanWorkCenterScheduleListTcp(
    @Payload() payload: any,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    return await this.planService.getPlanWorkCenterScheduleList({
      id: payload.id,
    } as GetPlanWorkCenterScheduleListRequestDto);
  }

  // TO DO: refactor when refactor done
  @PermissionCode(PERMISSION_LIST_PLAN)
  @MessagePattern('list_plan', DEFAULT_TRANSPORT)
  public async listPlanTcp(@Body() payload: GetListPlanRequest) {
    const { request } = payload;
    return await this.planService.listPlan(request);
  }
}
