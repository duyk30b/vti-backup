export class PlanCreatedEvent {
  constructor({ planId }) {
    this.planId = planId;
  }
  planId: number;
}
