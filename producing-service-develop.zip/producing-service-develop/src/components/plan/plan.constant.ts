export const PLAN_ID = 'moPlanId';
export const BOM_ID = 'bomId';
export const BOM_PARENT_ID = 'bomParentId';
export const PARENT_BOM_ID = 'parentBomId';
export const ROUTING_ID = 'routingId';
export const PRODUCING_STEP_ID = 'producingStepId';
