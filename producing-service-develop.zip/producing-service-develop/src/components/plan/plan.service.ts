import { ReportQualityRequestDto } from '@components/boq/dto/request/report-quality.request.dto';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { ManufacturingOrderDetailRepositoryInterface } from '@components/manufacturing-order/interface/manufacturing-order-detail.repository.interface';
import { ManufacturingOrderRepositoryInterface } from '@components/manufacturing-order/interface/manufacturing-order.repository.interface';
import { ManufacturingOrderStatusEnum } from '@components/manufacturing-order/manufacturing-order.constant';
import { RoutingRepositoryInterface } from '@components/routing/interface/routing.repository.interface';
import { SaleServiceInterface } from '@components/sale-order/interface/sale.service.interface';
import { WorkOrderScheduleDetailRepositoryInterface } from '@components/work-order/interface/work-order-schedule-detail.repository.interface';
import { WorkOrderRepositoryInterface } from '@components/work-order/interface/work-order.repository.interface';
import { WorkOrderStatusEnum } from '@components/work-order/work-order.constant';
import {
  CAN_DELETE_MO_PLAN_STATUS,
  getProccess,
  MoPlanStatus,
  Progress,
  REPORT_PROCCESS_HEADER,
  REPORT_QUALITY_HEADER,
} from '@constant/common';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { CsvWriter } from '@core/csv/csv.write';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { BomEntity } from '@entities/bom/boms.entity';
import { MoPlanBomEntity } from '@entities/manufacturing-order/mo-plan-boms.entity';
import { MoPlanEntity } from '@entities/manufacturing-order/mo-plans.entity';
import { WorkOrderEntity } from '@entities/work-order/work-order.entity';
import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource, InjectRepository } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import {
  convertArrayToMap,
  convertArrayToObject,
  convertToSkip,
  convertToTake,
  distinctArray,
  div,
  minus,
  mul,
  plus,
} from '@utils/common';
import { lotNumberGenerator } from '@utils/helper';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { plainToInstance } from 'class-transformer';
import { randomBytes } from 'crypto';
import {
  filter,
  find,
  flatMap,
  indexOf,
  isEmpty,
  keyBy,
  map,
  uniq,
  uniqBy,
} from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, Repository } from 'typeorm';
import {
  CreatePlanRequest,
  PlanBomDto,
} from './dto/request/create-plan.request.dto';
import { GetListPlanRequest } from './dto/request/get-list-plan.request.dto';
import { GetPlanWorkCenterScheduleListRequestDto } from './dto/request/get-plan-work-center-schedule-list.request.dto';
import { UpdatePlanRequest } from './dto/request/update-plan.request.dto';
import {
  BomDetailDto,
  DetailBomPlanResponse,
} from './dto/response/detail-bom-plan.response';
import {
  BomDto,
  DetailPlanDto,
  DetailPlanResponse,
  PlansBom,
  RoutingDto,
} from './dto/response/detail-plan.response';
import {
  ListPlanResponse,
  PlanDto,
} from './dto/response/get-list-plan.response.dto';
import {
  GetListQuanlityReportResponseDto,
  MoPlanBomResponse,
} from './dto/response/get-list-quality-report.response.dto';
import { PlanItemResponseDto } from './dto/response/plan-item.response.dto';
import { MoPlanBomRepositoryInteface } from './inteface/mo-plan-bom.repository.inteface';
import { MoPlanRepositoryInteface } from './inteface/mo-plan.repository.inteface';
import { PlanServiceInterface } from './inteface/plan.service.interface';
import { BOM_ID, PARENT_BOM_ID, PLAN_ID, ROUTING_ID } from './plan.constant';
import { RequestServiceInterface } from '@components/request/interface/request.service.interface';
import { NATS_PLAN } from '@config/nats.config';

@Injectable()
export class PlanService implements PlanServiceInterface {
  private readonly CAN_CREATE_MO_PLAN_STATUSES = [
    ManufacturingOrderStatusEnum.CONFIRMED,
    ManufacturingOrderStatusEnum.IN_PROGRESS,
  ];
  private readonly STATUS_TRANSITION_RULE = {
    [MoPlanStatus.REJECTED]: [
      MoPlanStatus.CREATED,
      MoPlanStatus.CONFIRMED,
      MoPlanStatus.IN_PROGRESS,
    ],
    [MoPlanStatus.CREATED]: [],
    [MoPlanStatus.CONFIRMED]: [MoPlanStatus.CREATED],
    [MoPlanStatus.IN_PROGRESS]: [MoPlanStatus.CONFIRMED],
    [MoPlanStatus.COMPLETED]: [MoPlanStatus.IN_PROGRESS],
  };

  constructor(
    @Inject('MoPlanRepositoryInterface')
    private readonly moPlanRepository: MoPlanRepositoryInteface,

    @Inject('MoPlanBomRepositoryInterface')
    private readonly moPlanBomRepository: MoPlanBomRepositoryInteface,

    @Inject('MoRepositoryInterface')
    private readonly moRepository: ManufacturingOrderRepositoryInterface,

    @Inject('MoDetailRepositoryInterface')
    private readonly moDetailRepository: ManufacturingOrderDetailRepositoryInterface,

    @InjectRepository(BomEntity)
    private readonly bomRepository: Repository<BomEntity>,

    @Inject('RoutingRepositoryInterface')
    private readonly routingRepository: RoutingRepositoryInterface,

    @Inject('WorkOrderRepositoryInterface')
    private readonly workOrderRepository: WorkOrderRepositoryInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    @Inject('WorkOrderScheduleDetailRepositoryInterface')
    private readonly workOrderScheduleDetailRepository: WorkOrderScheduleDetailRepositoryInterface,

    @Inject('SaleServiceInterface')
    private readonly saleService: SaleServiceInterface,

    @Inject('RequestServiceInterface')
    private readonly requestService: RequestServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,
    private readonly i18n: I18nRequestScopeService,
    private readonly natsClientService: NatsClientService,
  ) {}

  async listPlan(
    searchRequest: GetListPlanRequest,
  ): Promise<ResponsePayload<any>> {
    const planResponse = new ListPlanResponse();
    const where = {};
    where['itemIds'] = [];
    const [plans, count] = await this.moPlanRepository.listPlan(searchRequest);
    const moRequestMap =
      await this.requestService.getManufacturingRequestOrderByIds(
        plans.map((plan) => plan.mo.manufacturingRequestOrderId),
        true,
      );
    planResponse.items = plans.map((plan) => {
      const moRequest = moRequestMap[plan.mo.manufacturingRequestOrderId];
      const dto = plainToInstance(PlanDto, plan);
      dto.moId = plan.mo.id;
      dto.moName = plan.mo.name;
      dto.manufacturingRequestOrderId = moRequest?.id || null;
      dto.manufacturingRequestOrderCode = moRequest?.code || null;
      dto.progress = this.setProgress(
        plan.actualQuantity,
        plan.quantity,
        dto.planFrom,
        dto.planTo,
      );
      return dto;
    });
    planResponse.meta = {
      total: count,
      page: searchRequest.page,
    };
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(planResponse)
      .build();
  }

  async getPLanById(planId: number): Promise<ResponsePayload<any>> {
    const detailResponse = new DetailPlanResponse();
    const moPlan = await this.moPlanRepository.findOneById(planId);

    if (!moPlan)
      return new ResponseBuilder().withCode(ResponseCodeEnum.NOT_FOUND).build();
    const detailPlanDto = plainToInstance(DetailPlanDto, moPlan);
    const planBomsResponse = await this.getPLanByMoIdAndPlanId(
      moPlan.moId,
      planId,
    );

    detailPlanDto.planBoms = planBomsResponse.data;
    detailResponse.data = detailPlanDto;

    return detailResponse;
  }

  async getPLanByMoId(moId: number): Promise<ResponsePayload<any>> {
    return this.getPLanByMoIdAndPlanId(moId, null);
  }

  async getPLanByMoIdAndPlanId(
    moId: number,
    planId: number,
  ): Promise<ResponsePayload<any>> {
    const detailResponse = new DetailBomPlanResponse();
    let oldPlanbomMap = {}; // key = bomId
    if (planId) {
      const [planBomDetails, planBomProducingSteps] = await Promise.all([
        this.moPlanBomRepository.getAllBomDetailByPlanId(planId),
        this.moPlanBomRepository.getAllBomProducingStepByPlanId(planId),
      ]);

      planBomDetails.forEach((planBomDetail) => {
        const producingSteps = filter(
          planBomProducingSteps,
          (planBomProducingStep) =>
            planBomProducingStep.bomId === planBomDetail.bomId &&
            planBomDetail.parentBomId === planBomProducingStep.parentBomId &&
            planBomDetail.id === planBomProducingStep.id,
        );

        planBomDetail.producingSteps = flatMap(
          map(producingSteps, 'producingSteps'),
        );
      });

      oldPlanbomMap = await this.toPlanBomDto(planBomDetails);
    }

    const allBom = await this.moDetailRepository.getAllByMoId(moId);

    if (allBom.length == 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const root = distinctArray(allBom.map((b) => b.modtItemId));
    const itemIds = distinctArray(allBom.map((e) => e.itemId));
    itemIds.push(...root);
    const routingIds = allBom.map((e) => e.routingId);
    routingIds.push(...allBom.map((e) => e.parent.routingId));

    const [itemDtos, routing, aggreateActualQuantityByBomId] =
      await Promise.all([
        this.getItemInfoByIds(itemIds),
        isEmpty(distinctArray(routingIds))
          ? []
          : this.routingRepository.getAllVersionByIds(
              distinctArray(routingIds),
            ),
        this.workOrderRepository.aggreateActualQuantityByBomId(moId),
      ]);

    const itemDtoMap = convertArrayToObject(itemDtos, 'id');

    const actualQuantityStepMap = convertArrayToObject(
      aggreateActualQuantityByBomId,
      'indentity',
    );

    const routingMap = convertArrayToObject(routing, 'id');
    // const allBomMap = convertArrayToObject(allBom, 'itemId');
    const allBomMap = keyBy(
      allBom,
      (bom) => `${bom.itemId}_${bom.parentId || ''}`,
    );

    const rootMap = convertArrayToObject(allBom, 'modtItemId');
    const relations = allBom.reduce((result, element) => {
      if (!result[element.parentItemId]) result[element.parentItemId] = [];
      result[element.parentItemId].push(element.itemId);
      return result;
    }, {});

    detailResponse.data = root.map((rootId) => {
      const moItem = new BomDetailDto();
      const rawBomRoot = rootMap[rootId];
      moItem.moDetailId = rawBomRoot.modtId;
      moItem.item = itemDtoMap[rootId];

      moItem.bom = plainToInstance(BomDto, rawBomRoot.parent, {
        excludeExtraneousValues: true,
      });
      if (planId) {
        (moItem.quantity = rawBomRoot.modtPlaningQuantity),
          (moItem.actualQuantity = rawBomRoot.actualQuantityParent);
      } else {
        moItem.quantity = minus(
          rawBomRoot.modtQuantity,
          rawBomRoot.modtPlaningQuantity,
        );
      }

      const key =
        moItem.bom.id === rawBomRoot.parent?.id || null
          ? `${moItem.bom.id}_`
          : `${moItem.bom.id}_${rawBomRoot.parent?.id || ''}`;

      moItem.multiplier = 1;
      moItem.planBom = oldPlanbomMap[key];
      moItem.actualQuantity = rawBomRoot.actualQuantityParent;
      moItem.planingQuantity = rawBomRoot.modtPlaningQuantity;
      moItem.routing = routingMap[rawBomRoot.parent.routingId];
      moItem.planDate = moItem.planBom?.planDate;

      if (moItem.routing) {
        moItem.routing.producingSteps.forEach(
          (ps) =>
            (ps.actualQuantity = actualQuantityStepMap[
              `${moItem.bom.id}_${ps.id}`
            ]
              ? actualQuantityStepMap[`${moItem.bom.id}_${ps.id}`]
                  .actualQuantity
              : 0),
        );
      }
      if (relations[rootId]) {
        moItem.subBom = relations[rootId]
          .map((s) =>
            this.toBomDetailDto(
              moItem.bom.id,
              s,
              allBomMap,
              relations,
              itemDtoMap,
              routingMap,
              moItem.moDetailId,
              oldPlanbomMap,
              actualQuantityStepMap,
            ),
          )
          .filter((s) => s.bom);
      } else moItem.subBom = [];
      return moItem;
    });
    detailResponse.statusCode = ResponseCodeEnum.SUCCESS;
    detailResponse.message = await this.i18n.translate('error.SUCCESS');
    return detailResponse;
  }

  async toPlanBomDto(moPlanBoms: any): Promise<any> {
    const checker = {};
    const done = await this.i18n.translate('text.DONE');
    const toDo = await this.i18n.translate('text.TO_DO');
    const doing = await this.i18n.translate('text.DOING');
    const materialItemIds = [];
    moPlanBoms.forEach((moPlanBom) => {
      moPlanBom.producingSteps?.forEach((producingStep) => {
        producingStep.materials?.map((material) => {
          materialItemIds.push(material.itemId);
        });
      });
    });

    const materialItems = await this.getItemInfoByIds(materialItemIds);

    const serMaterialItems = keyBy(materialItems, 'id');

    moPlanBoms.forEach((e) => {
      const key = `${e.bomId}_${e.moBomPlan.parentBomId || ''}`;
      const producingSteps = e.producingSteps;

      producingSteps.forEach((producingStep) => {
        producingStep.producingStep = {
          id: producingStep.id,
          name: producingStep.name,
          code: producingStep.code,
          qcCriteriaId: producingStep.qcCriteriaId,
          qcCheck: producingStep.qcCheck,
          inputQcCheck: producingStep.inputQcCheck,
          inputQcCriteriaId: producingStep.inputQcCriteriaId,
          description: producingStep.description,
          moPlanBomId: producingStep.moPlanBomId,
          stepNumber: producingStep.stepNumber,
        };
        if ((producingStep.actualQuantity || 0) <= 0) {
          producingStep.status = toDo;
        } else if (
          (producingStep.actualQuantity || 0) ==
          (producingStep.sumQuantity || 0)
        ) {
          producingStep.status = done;
        } else {
          producingStep.status = doing;
        }

        if (!isEmpty(producingStep.workOrders)) {
          producingStep.workOrders = uniqBy(producingStep.workOrders, 'id');
          producingStep.workOrders.map((wo) => ({
            ...wo,
            previousBoms: wo?.previousBoms.map((pb) => ({
              ...pb,
            })),
          }));
        }

        if (!isEmpty(producingStep.materials)) {
          producingStep.materials = producingStep.materials
            .filter((material) => material.id)
            .map((material) => {
              const woInputMaterials = flatMap(
                producingStep.workOrders,
                'materials',
              );
              const inputMaterial = find(
                woInputMaterials,
                (woInputMaterial) => woInputMaterial.itemId === material.itemId,
              );
              return {
                ...serMaterialItems[material.itemId],
                quantity: producingStep.quantity * material.quantity,
                inputQuantity: inputMaterial?.quantity || 0,
                qcPassQuantity: inputMaterial?.qcPassQuantity || 0,
                qcRejectQuantity: inputMaterial?.qcRejectQuantity || 0,
              };
            });
        }
      });

      const planBom = plainToInstance(PlansBom, e.moBomPlan, {});

      planBom.producingSteps = producingSteps;
      planBom.progress = planBom.setProgress();
      planBom.materials = planBom.setMaterials(serMaterialItems);

      if (planBom.actualQuantity <= 0) {
        planBom.status = toDo;
      } else if (planBom.actualQuantity == planBom.quantity) {
        planBom.status = done;
      } else {
        planBom.status = doing;
      }
      planBom.routing = plainToInstance(RoutingDto, e.routing, {
        excludeExtraneousValues: true,
      });
      checker[key] = planBom;
    });

    return checker;
  }

  private toSubBom(id: number, bomsMap: any, relations: any): PlansBom[] {
    if (relations[id]) {
      return relations[id].map((subId) => {
        const plansBom = bomsMap[subId];
        plansBom.subBoms = this.toSubBom(subId, bomsMap, relations);
        return plansBom;
      });
    } else {
      return [];
    }
  }

  async createPLan(
    planRequest: CreatePlanRequest,
  ): Promise<ResponsePayload<any>> {
    const existPlanByMoId = await this.moPlanRepository.findOneByCondition({
      moId: planRequest.moId,
    });
    if (existPlanByMoId) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.MO_PLAN_EXISTS'),
      ).toResponse();
    }
    const moPlanOld = await this.moPlanRepository.findOneByCondition({
      code: planRequest.code,
    });
    if (moPlanOld) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_OR_NAME_ALREADY_EXISTS'),
      ).toResponse();
    }
    const mo = await this.moRepository.findOneById(planRequest.moId);
    if (!mo || (mo && !this.CAN_CREATE_MO_PLAN_STATUSES.includes(mo.status))) {
      return new ApiError(
        ResponseCodeEnum.FORBIDDEN,
        await this.i18n.translate('error.MO_NOT_FOUND'),
      ).toResponse();
    }
    const { relationBom, error } = await this.validatePlanBom(
      planRequest.planBoms,
      planRequest.moId,
      null,
    );

    if (error.length > 0) {
      const errResponse = new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_CREATE'),
      ).toResponse();
      errResponse['debug'] = JSON.stringify(error);

      return errResponse;
    }
    let planEntity = plainToInstance(MoPlanEntity, planRequest);
    planEntity.status = MoPlanStatus.CREATED;
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      planEntity = await queryRunner.manager.save(MoPlanEntity, planEntity);
      const { moPlanBoms, workOrders } =
        await this.toMoPlanBomEntityAndWorkOrder(
          planRequest,
          relationBom,
          planEntity.id,
        );

      const moPlanBomInserted = await queryRunner.manager.save(
        MoPlanBomEntity,
        moPlanBoms,
      );
      moPlanBomInserted.forEach((moPlanBomInsert) => {
        moPlanBomInsert.lotNumber = lotNumberGenerator(
          moPlanBomInsert.id.toString(),
        );
      });

      await queryRunner.manager.save(MoPlanBomEntity, moPlanBomInserted);
      const moPlanBomInsertedMap = convertArrayToMap(moPlanBomInserted, [
        PLAN_ID,
        BOM_ID,
        PARENT_BOM_ID,
        ROUTING_ID,
      ]);
      workOrders.forEach((e) => {
        const moPlanBom =
          moPlanBomInsertedMap[
            `_${e.moPlanId}_${e.bomId}_${e.parentBomId || null}_${e.routingId}`
          ];
        if (moPlanBom) {
          e.moPlanBomId = moPlanBom.id;
          e.lotNumber = moPlanBom.lotNumber;
        }
        return e;
      });
      await queryRunner.manager.save(WorkOrderEntity, workOrders);
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_CREATE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
      await this.updatePlaningQuantity(planRequest.moId);
    }
    return new ApiError(ResponseCodeEnum.SUCCESS).toResponse();
  }

  async updatePLan(
    planRequest: UpdatePlanRequest,
  ): Promise<ResponsePayload<any>> {
    let oldPlan = await this.moPlanRepository.findOneById(planRequest.id);
    if (!oldPlan) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.BAD_REQUEST'),
      ).toResponse();
    }
    if (oldPlan.status >= MoPlanStatus.CONFIRMED) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    }
    const isChangeMo = oldPlan.moId != planRequest.moId;
    const oldMoId = oldPlan.moId;
    const { relationBom, error } = await this.validatePlanBom(
      planRequest.planBoms,
      planRequest.moId,
      oldPlan.id,
    );
    if (error.length > 0) {
      const errResponse = new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
      errResponse['debug'] = JSON.stringify(error);
      return errResponse;
    }
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      oldPlan = this.moPlanRepository.updateEntity(oldPlan, planRequest);
      oldPlan = await queryRunner.manager.save(MoPlanEntity, oldPlan);
      const { moPlanBoms, workOrders, moPlanBomsDeletedId } =
        await this.toMoPlanBomEntityAndWorkOrder(
          planRequest,
          relationBom,
          oldPlan.id,
        );
      await queryRunner.manager.delete(WorkOrderEntity, {
        moPlanId: oldPlan.id,
      });
      const moPlanBomsNeedUpdate = moPlanBoms.filter((e) => e != null);
      if (!isEmpty(moPlanBomsNeedUpdate)) {
        const moPlanBomUpdated = await queryRunner.manager.save(
          MoPlanBomEntity,
          moPlanBomsNeedUpdate,
        );
        const moPlanBomInsertedMap = convertArrayToMap(moPlanBomUpdated, [
          PLAN_ID,
          BOM_ID,
          PARENT_BOM_ID,
          ROUTING_ID,
        ]);

        workOrders.forEach((e) => {
          const moPlanBom =
            moPlanBomInsertedMap[
              `_${e.moPlanId}_${e.bomId}_${e.parentBomId || null}_${
                e.routingId
              }`
            ];
          if (moPlanBom) {
            e.moPlanBomId = moPlanBom.id;
            e.lotNumber = moPlanBom.lotNumber;
          } else {
            console.log(e);
          }
          return e;
        });

        await queryRunner.manager.save(WorkOrderEntity, workOrders);
      }
      if (!isEmpty(moPlanBomsDeletedId)) {
        await queryRunner.manager.delete(MoPlanBomEntity, moPlanBomsDeletedId);
      }
      if (isChangeMo) {
        // delete old Mo
        await queryRunner.manager.delete(MoPlanBomEntity, {
          moPlanId: planRequest.id,
          moId: oldMoId,
        });
        await queryRunner.manager.delete(WorkOrderEntity, {
          moPlanId: planRequest.id,
          moId: oldMoId,
        });
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    } finally {
      await this.updatePlaningQuantity(planRequest.moId); // alaway update
      await this.updatePlaningQuantity(oldMoId);
      await queryRunner.release();
    }
    return new ApiError(ResponseCodeEnum.SUCCESS).toResponse();
  }

  async updateStatusPlan(
    planId: number,
    status: MoPlanStatus,
  ): Promise<ResponsePayload<any>> {
    const plan = await this.moPlanRepository.findOneById(planId);
    if (!plan)
      return new ResponseBuilder().withCode(ResponseCodeEnum.NOT_FOUND).build();
    const lastStatus = plan.status;
    const rule = this.STATUS_TRANSITION_RULE[status];
    if (!rule)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    if (indexOf(rule, lastStatus) < 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    plan.status = status;
    await this.moPlanRepository.update(plan);
    if (status == MoPlanStatus.REJECTED) {
      await this.updatePlaningQuantity(plan.moId);
    }
    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async getItemInfoByIds(itemIds: number[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PLAN}.get_items_by_ids`,
      {
        itemIds: itemIds,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    if (isEmpty(response.data)) return [];
    const data = plainToInstance(PlanItemResponseDto, response.data, {
      excludeExtraneousValues: true,
    });

    return data;
  }

  /**
   * Tạo Work Order
   * @param planRequest
   * @param relationBom
   * @param planId
   * @returns
   */
  async toMoPlanBomEntityAndWorkOrder(
    planRequest: CreatePlanRequest,
    moBoms: any,
    planId: number,
  ): Promise<any> {
    const boms = await this.bomRepository.findByIds(
      planRequest.planBoms.map((req) => req.bomId),
    );
    const oldMoPlanBoms = await this.moPlanBomRepository.findByCondition({
      moPlanId: planId,
      moId: planRequest.moId,
    });

    const oldMoPlanBomMap = convertArrayToMap(oldMoPlanBoms, [PLAN_ID, BOM_ID]);
    const workOrders = [];
    const moPlanBomsDeletedId = [];
    const moPlanBoms = planRequest.planBoms.map((req: any) => {
      const entity = plainToInstance(MoPlanBomEntity, req);
      const oldMoPlanBom = oldMoPlanBomMap[`_${planId}_${req.bomId}`];
      if (oldMoPlanBom) {
        if (req.quantity <= 0) {
          moPlanBomsDeletedId.push(oldMoPlanBom.id);
          return null;
        }
        entity.id = oldMoPlanBom.id;
      }

      const rawMoBom = filter(moBoms, (rBom) => rBom.bomId === entity.bomId);

      let moBom: any = {};
      if (req.parentIndex !== null) {
        const parentBomReq = find(
          planRequest.planBoms,
          (planB: any) => planB.index === req.parentIndex,
        );

        moBom = find(rawMoBom, (mB) => mB.parentId === parentBomReq.bomId);
      } else {
        moBom = find(boms, (b) => b.id === entity.bomId);
      }

      entity.moId = planRequest.moId;
      entity.itemId = moBom.itemId;
      entity.parentBomId = moBom.parentId || null;
      entity.status = MoPlanStatus.CREATED;
      entity.moPlanId = planId;
      entity.actualQuantity = 0;
      entity.confirmedQuantity = 0;
      workOrders.push(
        ...req.producingSteps.map((raw) => {
          const wo = new WorkOrderEntity();
          if (raw.workOrderId) wo.id = raw.workOrderId;
          wo.bomId = req.bomId;
          wo.moId = planRequest.moId;
          wo.actualQuantity = 0;
          wo.parentBomId = moBom.parentId || null;
          wo.moDetailId = req.moDetailId;
          wo.moPlanId = planId;
          wo.confirmedQuantity = 0;
          wo.producingStepId = raw.id;
          wo.routingId = moBom.routingId;
          wo.quantity = raw.quantity;
          wo.planFrom = raw.planFrom;
          wo.planTo = raw.planTo;
          wo.errorQuantity = 0;
          wo.exportedQuantity = 0;
          wo.scrapQuantity = 0;
          wo.qcPassQuantity = 0;
          wo.qcRejectQuantity = 0;
          wo.exportQuantity = 0;
          wo.status = WorkOrderStatusEnum.CREATED;
          wo.name = `${planRequest.code}_${wo.bomId}_${
            wo.routingId
          }_${randomBytes(3).toString('hex')}`;
          return wo;
        }),
      );
      return entity;
    });

    return {
      moPlanBoms: moPlanBoms,
      workOrders: workOrders,
      moPlanBomsDeletedId: moPlanBomsDeletedId,
    };
  }

  async validatePlanBom(
    planBoms: PlanBomDto[],
    moId: number,
    planId: number,
  ): Promise<any> {
    const moPlanBomOldMap = {};
    if (planId) {
      const moPlanBomOld = await this.moPlanBomRepository.findByCondition({
        moPlanId: planId,
        moId: moId,
      });
      moPlanBomOld.forEach((e) => {
        moPlanBomOldMap[e.bomId + '_' + e.routingId] = {
          quantity: e.quantity,
        };
        moPlanBomOldMap[e.bomId] = {
          quantity: e.quantity,
        };
      });
    }
    const boms =
      await this.moDetailRepository.getAllBomAndRoutingVersionIdByMoId(moId);
    const error = [];
    const planBomsExpectMap = {};

    boms.forEach((e) => {
      if (e.bom.id) {
        planBomsExpectMap[e.bom.id + '_' + e.routingId] = {
          planingQuantity: e.quantityPlaningCalculate,
          quantity: e.quantityCalculate,
        };
      }
      if (e.parent.id && e.modtId) {
        planBomsExpectMap[e.parent.id + '_' + e.parentRoutingId] = {
          planingQuantity: e.modtPlaningQuantity,
          quantity: e.modtQuantity,
        };
      }
    });

    // const checkExisted = {};
    // calculate and validate
    await Promise.all(
      planBoms.map(async (e) => {
        const old = moPlanBomOldMap[e.bomId];
        const oldQuantity = old ? old.quantity : 0;
        // expect and planing
        const quantityExpectAndPlaning = planBomsExpectMap[
          e.bomId + '_' + e.routingId
        ] as {
          planingQuantity;
          quantity;
        };

        if (!quantityExpectAndPlaning)
          error.push({
            bomId: e.bomId,
            routingId: e.routingId,
            err: await this.i18n.translate('PLAN_INVALID', {
              args: { bomId: e.bomId, routingId: e.routingId },
            }),
          });
        // rule:  planing + new - old <= expect
        else if (
          minus(
            plus(
              quantityExpectAndPlaning.planingQuantity || 0,
              e.quantity || 0,
            ),
            oldQuantity || 0,
          ) > quantityExpectAndPlaning.quantity
        ) {
          error.push({
            bomId: e.bomId,
            routingId: e.routingId,
            err: await this.i18n.translate('PLAN_QUANTITY_INVALID', {
              args: { bomId: e.bomId, routingId: e.routingId },
            }),
          });
        }
        if (e.producingSteps) {
          e.producingSteps.forEach(async (ps) => {
            if (ps.quantity > e.quantity) {
              error.push({
                bomId: e.bomId,
                routingId: e.routingId,
                err: await this.i18n.translate('PLAN_QUANTITY_INVALID', {
                  args: {
                    bomId: e.bomId,
                    routingId: e.routingId,
                    producingStepId: ps.id,
                  },
                }),
              });
            }
          });
        }
        return e;
      }),
    );
    return {
      relationBom: boms,
      error: error,
    };
  }

  updatePlaningQuantity(moId: number): Promise<any> {
    return this.moDetailRepository.updatePlaningQuantity(moId, [
      MoPlanStatus.COMPLETED,
      MoPlanStatus.CONFIRMED,
      MoPlanStatus.CREATED,
      MoPlanStatus.IN_PROGRESS,
    ]);
  }

  public async reportQualityList(
    request: ReportQualityRequestDto,
  ): Promise<ResponsePayload<GetListQuanlityReportResponseDto | any>> {
    const { page } = request;
    if (request.filter) {
      await Promise.all(
        request.filter.map(async (f) => {
          if (f.column == 'itemName') {
            const items = await this.itemService.getItemsByName(f);
            f.text = items.map((i) => i.id);
          }
          return f;
        }),
      );
    }
    const allItemIds = await this.moPlanBomRepository.allItemIds();
    const sortedItems = await this.itemService.getItemsByRelations({
      where: allItemIds.map((i) => {
        return { id: i.itemId };
      }),
      order: {
        name: 'ASC',
      },
    });
    const sortedItemIds = sortedItems.map((i) => i.id);
    const sortSaleOrderName = request.sort?.filter(
      (record) => record.column === 'saleOrderName',
    );
    const filterSaleOrderName = request.filter?.find(
      (item) => item.column === 'saleOrderName',
    );
    let isHasSortOrFilterSaleOrderName = true;
    let saleOrderIds = [];
    let saleOrders;
    if (!isEmpty(sortSaleOrderName)) {
      const moPlanBoms = await this.moPlanBomRepository.getAllSaleOrderIds();
      saleOrderIds = map(moPlanBoms, 'saleOrderId');
    }
    if (!isEmpty(filterSaleOrderName)) {
      saleOrders = await this.saleService.getSaleOrdersByNameKeyword(
        filterSaleOrderName,
      );

      if (isEmpty(saleOrders)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    if (isEmpty(saleOrders) && !isEmpty(saleOrderIds)) {
      saleOrders = await this.saleService.getSaleOrdersByIds(saleOrderIds);
    }

    const { data, count } = await this.moPlanBomRepository.reportQualityList(
      request,
      sortedItemIds,
      saleOrders,
    );

    const itemIds = data.map((i) => i.itemId);
    const itemMap = convertArrayToObject(
      await this.getItemInfoByIds(itemIds),
      'id',
    );
    let countId = request.skip;
    if (isEmpty(saleOrders)) {
      isHasSortOrFilterSaleOrderName = false;
      saleOrderIds = uniq(map(flatMap(data, 'manufacturingOrder'), 'soId'));
      saleOrders = await this.saleService.getSaleOrdersByIds(
        saleOrderIds,
        true,
      );
    }
    const responseData = data.map((item) => {
      item.bom.item = itemMap[item.itemId];
      item.id = ++countId;
      item.saleOrder = !isHasSortOrFilterSaleOrderName
        ? saleOrders[item.manufacturingOrder.soId]
        : item.saleOrder;
      return item;
    });

    const response = plainToInstance(MoPlanBomResponse, responseData, {
      excludeExtraneousValues: true,
    });
    if (request.isGetFile && request.isGetFile === '1') {
      const csvWriter = new CsvWriter();
      csvWriter.mapHeader = REPORT_QUALITY_HEADER;
      csvWriter.i18n = this.i18n;
      let index = 0;
      const dataCsv = responseData.map((i) => {
        index++;
        return {
          i: index,
          moName: i.manufacturingOrder.name,
          itemName: i.bom.item.name,
          routingName: i.routing.name,
          producingStep: i.producingStep.name,
          planQuantity: i.quantity ? i.quantity : '0.00',
          quantity: i.actualQuantity ? i.actualQuantity : '0.00',
          needQcQuantity: i.confirmedQuantity ? i.confirmedQuantity : '0.00',
          qcQuantity: i.qcPassQuantity ? i.qcPassQuantity : '0.00',
          failQuantity: i.errorQuantity ? i.errorQuantity : '0.00',
          failedQuantity: i.qcRejectQuantity ? i.qcRejectQuantity : '0.00',
        };
      });
      return new ResponseBuilder<any>({
        file: await csvWriter.writeBase64(dataCsv),
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async reportProccess(): Promise<any> {
    const result = await this.moPlanBomRepository.reportProccessList();
    const itemIds = result.map((i) => i.itemId);
    const itemMap = convertArrayToObject(
      await this.getItemInfoByIds(itemIds),
      'id',
    );
    const csvWriter = new CsvWriter();
    csvWriter.mapHeader = REPORT_PROCCESS_HEADER;
    csvWriter.i18n = this.i18n;
    let index = 0;
    const dataCsv = result.map((i) => {
      index++;
      i.item = itemMap[i.itemId] || { name: '', code: '' };
      return {
        i: index,
        moCode: i.mo[0].code,
        moName: i.mo[0].name,
        planCode: i.plan[0].code,
        planName: i.plan[0].name,
        bomCode: i.bom[0].code,
        itemCode: i.item.code,
        itemName: i.item.name,
        versionName: i.r[0].name,
        producingStep: i.producingStep[0].name,
        process: getProccess(
          i.actualQuantity,
          i.quantity,
          i.planBom[0]['plan_from'],
          i.planBom[0]['plan_to'],
        ).toString(),
      };
    });
    return new ResponseBuilder<any>({
      file: await csvWriter.writeBase64(dataCsv),
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  toBomDetailDto(
    parentBomId: number,
    itemId: number,
    rawBoms: any,
    relation: any,
    itemDtoMap: any,
    routingMap: any,
    moDetailId: number,
    planBomMap: any,
    actualQuantityStepMap: any,
  ): BomDetailDto {
    const result = new BomDetailDto();

    const rawBom = rawBoms[`${itemId}_${parentBomId || ''}`];
    result.moDetailId = moDetailId;
    result.item = itemDtoMap[itemId];

    result.quantity = minus(
      rawBom.quantityCalculate ? rawBom.quantityCalculate : 0,
      rawBom.quantityPlaningCalculate ? rawBom.quantityPlaningCalculate : 0,
    );
    // result.quantity = result.planingQuantity = Math.round(
    //   rawBom.quantityPlaningCalculate ? rawBom.quantityPlaningCalculate : 0,
    // );
    result.routing = routingMap[rawBom.routingId];
    if (result.routing) {
      result.routing.producingSteps.forEach(
        (ps) =>
          (ps.actualQuantity = actualQuantityStepMap[
            `${rawBom.bom.id}_${ps.id}`
          ]
            ? actualQuantityStepMap[`${rawBom.bom.id}_${ps.id}`].actualQuantity
            : 0),
      );
    }
    result.actualQuantity = rawBom.actualQuantity;
    if (rawBom.bom.id) {
      result.bom = plainToInstance(BomDto, rawBom.bom);
      const key =
        rawBom.bom.id === rawBom.parent?.id || null
          ? `${rawBom.bom.id}_`
          : `${rawBom.bom.id}_${rawBom.parent?.id || ''}`;
      result.planBom = planBomMap[key];
    }
    result.multiplier = rawBom.multiplier;
    if (relation[itemId])
      result.subBom = relation[itemId]
        .map((parentItemId) =>
          this.toBomDetailDto(
            result.bom.id,
            parentItemId,
            rawBoms,
            relation,
            itemDtoMap,
            routingMap,
            moDetailId,
            planBomMap,
            actualQuantityStepMap,
          ),
        )
        .filter((s) => s.bom);
    return result;
  }

  public async deletePlan(
    id: number,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const moPlan = await this.moPlanRepository.findOneById(id);
    if (!moPlan) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.MO_PLAN_NOT_FOUND'))
        .build();
    }

    if (!CAN_DELETE_MO_PLAN_STATUS.includes(moPlan.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_DELETE'),
      ).toResponse();
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.delete(MoPlanBomEntity, { moPlanId: id });
      await queryRunner.manager.delete(WorkOrderEntity, { moPlanId: id });
      await queryRunner.manager.delete(MoPlanEntity, { id: id });
      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_DELETE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
      await this.updatePlaningQuantity(moPlan.moId);
    }
  }

  setProgress(actual, plan, start, end): Progress {
    const now = new Date();
    start = new Date(start);
    end = new Date(end);
    if (actual == 0 && now <= end) return Progress.NOTHING;
    if (plan == actual) return Progress.DONE;
    if (plan > actual && now >= end) return Progress.LATE;
    const forcastQuantity = mul(
      plan,
      div(
        minus(now.getTime(), start.getTime()),
        minus(end.getTime(), start.getTime()),
      ),
    );
    if (forcastQuantity > actual && now > end) return Progress.LATE;
    return Progress.NORMAL;
  }

  /**
   * Lấy danh sách kế hoạch xưởng theo mo plan
   * @param payload
   */
  public async getPlanWorkCenterScheduleList(
    payload: GetPlanWorkCenterScheduleListRequestDto,
  ): Promise<any> {
    const { id } = payload;

    const plan = await this.moPlanRepository.findOneById(id);

    if (isEmpty(plan)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const data =
      await this.workOrderScheduleDetailRepository.getWorkCenterScheduleListByPlanId(
        id,
      );
    return new ResponseBuilder()
      .withData(data)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }
}
