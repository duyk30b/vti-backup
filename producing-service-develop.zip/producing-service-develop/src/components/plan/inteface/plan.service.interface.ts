import { MoPlanStatus } from '@constant/common';
import { ResponsePayload } from '@utils/response-payload';
import { CreatePlanRequest } from '../dto/request/create-plan.request.dto';
import { GetListPlanRequest } from '../dto/request/get-list-plan.request.dto';
import { UpdatePlanRequest } from '../dto/request/update-plan.request.dto';
import { ReportQualityRequestDto } from '@components/boq/dto/request/report-quality.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { GetListQuanlityReportResponseDto } from '../dto/response/get-list-quality-report.response.dto';
import { GetPlanWorkCenterScheduleListRequestDto } from '../dto/request/get-plan-work-center-schedule-list.request.dto';

export interface PlanServiceInterface {
  listPlan(searchRequest: GetListPlanRequest): Promise<ResponsePayload<any>>;
  getPlanWorkCenterScheduleList(
    payload: GetPlanWorkCenterScheduleListRequestDto,
  ): Promise<ResponsePayload<any>>;

  getPLanById(planId: number): Promise<ResponsePayload<any>>;

  getPLanByMoId(planId: number): Promise<ResponsePayload<any>>;

  createPLan(planRequest: CreatePlanRequest): Promise<ResponsePayload<any>>;

  updatePLan(planRequest: UpdatePlanRequest): Promise<ResponsePayload<any>>;

  updateStatusPlan(
    planId: number,
    status: MoPlanStatus,
  ): Promise<ResponsePayload<any>>;

  reportQualityList(
    request: ReportQualityRequestDto,
  ): Promise<ResponsePayload<GetListQuanlityReportResponseDto | any>>;

  reportProccess(): Promise<any>;

  deletePlan(id: number): Promise<ResponsePayload<SuccessResponse | any>>;
}
