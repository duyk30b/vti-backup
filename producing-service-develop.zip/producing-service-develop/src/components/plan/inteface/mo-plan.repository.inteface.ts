import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { MoPlanEntity } from '@entities/manufacturing-order/mo-plans.entity';
import { GetListPlanRequest } from '../dto/request/get-list-plan.request.dto';

export interface MoPlanRepositoryInteface
  extends BaseInterfaceRepository<MoPlanEntity> {
  updateEntity(old: MoPlanEntity, newData: any): MoPlanEntity;
  getDetail(id: number): Promise<any>;
  getRawDetail(id: number): Promise<any>;
  listPlan(request: GetListPlanRequest): Promise<any>;

  getAllMoRequestIds(): Promise<any[]>;
  getMoItemList(moId: number, filter?: any[]): Promise<any[]>;
  getMoItemListV2(moId: number, filter?: any[]): Promise<any>;
}
