import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { ReportQualityRequestDto } from '@components/boq/dto/request/report-quality.request.dto';
import { MoPlanBomEntity } from '@entities/manufacturing-order/mo-plan-boms.entity';
import { GetListWorkOrderScheduleRequestDto } from '@components/work-order/dto/request/get-list-work-order-schedule.request.dto';
export interface MoPlanBomRepositoryInteface
  extends BaseInterfaceRepository<MoPlanBomEntity> {
  getChildBom(
    moDetailId: number,
    moId: number,
    parentBomId: number,
    planId?: number,
    filter?: any,
  ): Promise<any>;
  getItemBom(
    moId: number,
    itemIds: number[],
    planId?: number,
    filter?: any[],
    moDetailId?: number,
  ): Promise<any>;
  getMoPlanBomDetail(
    moId: number,
    moPlanBomId: number,
    filter?: any[],
  ): Promise<any>;
  getAllBomByPlanId(planId: number): Promise<any>;
  getAllBomDetailByPlanId(planId: number): Promise<any>;
  getAllBomProducingStepByPlanId(planId: number): Promise<any>;
  reportQualityList(
    payload: ReportQualityRequestDto,
    sortedItemIds: number[],
    saleOrders?: number[],
  ): Promise<any>;
  allItemIds(): Promise<any>;
  reportProccessList(): Promise<any>;
  getTotalSemiFinishItems(moIds: number[]): Promise<any>;
  checkIsLastSemiFinishedProduct(
    moId: number,
    planId: number,
    bomId: number,
  ): Promise<boolean>;

  updateStartAt(id: number): Promise<any>;
  updateEndAt(id: number): Promise<any>;
  getGranttChart(payload: GetListWorkOrderScheduleRequestDto): Promise<any>;
  getAllSaleOrderIds(): Promise<any>;
  getFinishedItemScheduleByMoIds(
    moIds: number[],
    itemId?: number,
  ): Promise<any>;
  getExportWorkCenters(moId: number, itemIds: number[]): Promise<any>;
  getAllItemScheduleByMoIds(
    moIds: number[],
    itemId?: number,
    routingId?: number,
    producingStepId?: number,
  ): Promise<any>;
  getAllItemQualityControlScheduleByMoIds(
    moIds: number[],
    itemId?: number,
    routingId?: number,
    producingStepId?: number,
    defaultTimeZone?: any,
  ): Promise<any>;
  getCount(): Promise<any>;
}
