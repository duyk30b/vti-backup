import { MoPlanBomTransactionEntity } from '../../../entities/manufacturing-order/mo-plan-bom-transactions.entity';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';

export interface MoPlanBomTransactionRepositoryInteface
  extends BaseInterfaceRepository<MoPlanBomTransactionEntity> {
  getCompletedItemByDay(
    days: any[],
    moIds?: number[],
    itemId?: number,
  ): Promise<any>;
}
