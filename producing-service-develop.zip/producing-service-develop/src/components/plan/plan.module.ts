import { UserService } from '@components/user/user.service';
import { ConfigService } from '@config/config.service';
import { BomDetailEntity } from '@entities/bom/bom-details.entity';
import { BomEntity } from '@entities/bom/boms.entity';
import { BoqDetail } from '@entities/boq/boq-details.entity';
import { Boq } from '@entities/boq/boqs.entity';
import { ProducingStepEntity } from '@entities/producing-step/producing-step.entity';
import { RoutingProducingStepEntity } from '@entities/producing-step/routing-producing-step.entity';
import { RoutingEntity } from '@entities/routing/routing.entity';
import { WorkOrderEntity } from '@entities/work-order/work-order.entity';
import { Module } from '@nestjs/common';
import { ClientProxyFactory } from '@nestjs/microservices';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MoPlanRepository } from '@repositories/plan/mo-plan.repository';
import { BoqDetailRepository } from '@repositories/boq/boq-detail.repository';
import { BoqRepository } from '@repositories/boq/boq.repository';
import { PlanController } from './plan.controller';
import { PlanService } from './plan.service';
import { MoPlanBomRepository } from '@repositories/plan/mo-plan-bom.repository';
import { WorkOrderRepository } from '@repositories/work-order/work-order.repository';
import { RoutingRepository } from '@repositories/routing.repository';
import { MoPlanEntity } from '@entities/manufacturing-order/mo-plans.entity';
import { MoPlanBomEntity } from '@entities/manufacturing-order/mo-plan-boms.entity';
import { ManufacturingOrderRepository } from '@repositories/manufacturing-order/manufacturing-order.repository';
import { ManufacturingOrderEntity } from '@entities/manufacturing-order/manufacturing-orders.entity';
import { ManufacturingOrderDetailRepository } from '@repositories/manufacturing-order/manufacturing-order-detail.repository';
import { ManufacturingOrderDetailEntity } from '@entities/manufacturing-order/manufacturing-order-details.entity';
import { WorkOrderScheduleDetailRepository } from '@repositories/work-order/work-order-schedule-detail.repository';
import { WorkOrderScheduleDetailEntity } from '@entities/work-order/work-order-schedule-detail.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Boq,
      BoqDetail,
      BomEntity,
      BomDetailEntity,
      RoutingEntity,
      RoutingProducingStepEntity,
      ProducingStepEntity,
      ManufacturingOrderEntity,
      ManufacturingOrderDetailEntity,
      MoPlanEntity,
      MoPlanBomEntity,
      WorkOrderEntity,
      WorkOrderScheduleDetailEntity,
    ]),
  ],
  providers: [
    ConfigService,
    {
      provide: 'ITEM_SERVICE_CLIENT',
      useFactory: (configService: ConfigService) => {
        const itemServiceOptions = configService.get('itemService');
        return ClientProxyFactory.create(itemServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'MoRepositoryInterface',
      useClass: ManufacturingOrderRepository,
    },
    {
      provide: 'MoDetailRepositoryInterface',
      useClass: ManufacturingOrderDetailRepository,
    },
    {
      provide: 'MoPlanRepositoryInterface',
      useClass: MoPlanRepository,
    },
    {
      provide: 'MoPlanBomRepositoryInterface',
      useClass: MoPlanBomRepository,
    },
    {
      provide: 'RoutingRepositoryInterface',
      useClass: RoutingRepository,
    },
    {
      provide: 'WorkOrderScheduleDetailRepositoryInterface',
      useClass: WorkOrderScheduleDetailRepository,
    },
    {
      provide: 'BoqDetailRepositoryInterface',
      useClass: BoqDetailRepository,
    },
    {
      provide: 'BoqRepositoryInterface',
      useClass: BoqRepository,
    },
    {
      provide: 'WorkOrderRepositoryInterface',
      useClass: WorkOrderRepository,
    },
    {
      provide: 'PlanServiceInterface',
      useClass: PlanService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
  ],
  controllers: [PlanController],
})
export class PlanModule {}
