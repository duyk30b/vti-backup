import { convertArrayToObject, div, mul, plus } from '@utils/common';
import { remove, find, isEmpty } from 'lodash';

export const calculateCostMaterialActual = function (
  rawParent,
  item,
  quantity,
  qcPlan,
  qcByItemId,
) {
  if (!rawParent) return 0;

  const planBomQcPlan = qcPlan[rawParent.id];

  // cost = costRaw + costFixError
  let costRaw = 0;
  let bomProducingSteps;
  if (typeof rawParent?.bomProducingSteps !== 'object') {
    bomProducingSteps = JSON.parse(rawParent?.bomProducingSteps);
  } else {
    bomProducingSteps = rawParent?.bomProducingSteps;
  }

  const bomProducingStepsMap = convertArrayToObject(
    remove(bomProducingSteps, (i) => i['item_id'] == item?.id),
    'producing_step_id',
  );
  const producingSteps = rawParent?.producingSteps || [];
  let costFixError = 0;

  producingSteps.forEach((ps) => {
    const producingStepQcPlan = !isEmpty(planBomQcPlan)
      ? find(planBomQcPlan.planBom.producingStep, (pQc) => {
          return pQc.producingStep.id === ps.id;
        })
      : null;
    const qcErrorRate = div(qcByItemId || 100, 100);
    let errorRate = 0;

    if (
      !isEmpty(producingStepQcPlan) &&
      !isEmpty(producingStepQcPlan.producingStep) &&
      !isEmpty(producingStepQcPlan.producingStep.qualityPlanBom)
    ) {
      errorRate = div(
        +producingStepQcPlan.producingStep.qualityPlanBom.planErrorRate,
        100,
      );
    }
    const materialQuantity = mul(
      rawParent.quantity || 0,
      bomProducingStepsMap[ps.id]?.quantity || 0,
    );
    const costQcErrorTemp = mul(
      qcErrorRate,
      mul(errorRate, mul(materialQuantity, item?.price || 0)),
    );

    costRaw = plus(costRaw, mul(materialQuantity, item?.price || 0));

    costFixError = plus(costFixError, costQcErrorTemp);
  });

  return Math.round(plus(costRaw, costFixError));
};
