export enum ManufacturingOrderStatusEnum {
  PENDING = 0,
  CONFIRMED = 1,
  REJECTED = 2,
  IN_PROGRESS = 3,
  COMPLETED = 4,
}

export const STATUS_TO_UPDATE_MO: number[] = [
  ManufacturingOrderStatusEnum.PENDING,
  ManufacturingOrderStatusEnum.REJECTED,
];

export const STATUS_TO_CONFIRM_MO_STATUS: number[] = [
  ManufacturingOrderStatusEnum.PENDING,
  ManufacturingOrderStatusEnum.REJECTED,
];

export const STATUS_TO_REJECT_MO_STATUS: number[] = [
  ManufacturingOrderStatusEnum.PENDING,
];

export const STATUS_TO_COMPLETE_MO_STATUS: number[] = [
  ManufacturingOrderStatusEnum.IN_PROGRESS,
];

export const STATUS_TO_DELETE_MO_STATUS: number[] = [
  ManufacturingOrderStatusEnum.PENDING,
  ManufacturingOrderStatusEnum.REJECTED,
];

export const MAXIMUM_REPORT_SIZE = 10000;
