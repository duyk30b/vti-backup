import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ManufacturingOrderService } from './manufacturing-order.service';
import { ManufacturingOrderController } from './manufacturing-order.controller';
import { ItemService } from '@components/item/item.service';
import { ItemModule } from '@components/item/item.module';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { BomRepository } from '@repositories/bom/bom.repository';
import { BomEntity } from '@entities/bom/boms.entity';
import { ManufacturingOrderEntity } from '@entities/manufacturing-order/manufacturing-orders.entity';
import { ManufacturingOrderDetailEntity } from '@entities/manufacturing-order/manufacturing-order-details.entity';
import { ManufacturingOrderRepository } from '@repositories/manufacturing-order/manufacturing-order.repository';
import { ManufacturingOrderDetailRepository } from '@repositories/manufacturing-order/manufacturing-order-detail.repository';
import { MoPlanRepository } from '@repositories/plan/mo-plan.repository';
import { MoPlanEntity } from '@entities/manufacturing-order/mo-plans.entity';
import { SaleService } from '@components/sale-order/sale-order.service';
import { SaleModule } from '@components/sale-order/sale-order.module';
import { MoPlanBomRepository } from '@repositories/plan/mo-plan-bom.repository';
import { MoPlanBomEntity } from '@entities/manufacturing-order/mo-plan-boms.entity';
import { BomDetailEntity } from '@entities/bom/bom-details.entity';
import { BomDetailRepository } from '@repositories/bom/bom-detail.repository';
import { BomProducingStepDetailsRepository } from '@repositories/bom/bom-producing-step-details.repository';
import { BomProducingStepDetailEntity } from '@entities/bom/bom-producing-steps.entity';
import { MaterialPlanScheduleEntity } from '@entities/material/material-plan-schedules.entity';
import { MaterialPlanStructureRepository } from '@repositories/material/material-plan-structure.repository';
import { MaterialPlanProducingStepEntity } from '@entities/material/material-plan-producing-steps.entity';
import { MaterialPlanProducingStepRepository } from '@repositories/material/material-plan-producing-step.repository';
import { MaterialPlanStructureEntity } from '@entities/material/material-plan-structure.entity';
import { MaterialPlanRepository } from '@repositories/material/material-plan.repository';
import { MaterialPlanEntity } from '@entities/material/material-plan.entity';
import { WorkCenterShiftRepository } from '@repositories/work-center/work-center-shift.repository';
import { WorkCenterShiftEntity } from '@entities/work-center/work-center-shift.entity';
import { WorkOrderEntity } from '@entities/work-order/work-order.entity';
import { WorkOrderRepository } from '@repositories/work-order/work-order.repository';
import { SaleCronService } from '@components/sale-order/sale-order-cron.service';
import { MasterPlanService } from '@components/master-plan/master-plan.service';
import { MasterPlanModule } from '@components/master-plan/master-plan.module';
import { WorkCenterRepository } from '@repositories/work-center/work-center.repository';
import { WorkCenterEntity } from '@entities/work-center/work-center.entity';
import { ManufacturingOrderConfirmedListener } from './listeners/manufacturing-order-confirm.listener';
import { WorkOrderScheduleDetailEntity } from '@entities/work-order/work-order-schedule-detail.entity';
import { WorkOrderScheduleDetailRepository } from '@repositories/work-order/work-order-schedule-detail.repository';
import { ConfigModule } from '@nestjs/config';
import { RequestModule } from '@components/request/request.module';
import { RequestService } from '@components/request/request.service';
import { BomUserProducingStepDetailRepository } from '@repositories/bom/bom-user-producing-step-detail.repository';
import { BomUserProducingStepDetailEntity } from '@entities/bom/bom-user-producing-step-details.entity';
import { BomModule } from '@components/bom/bom.module';
import { BomVersionEntity } from '@entities/bom/bom-versions.entity';
import { BomVersionRepository } from '@repositories/bom/bom-version.repository';
import { ProductionOrderService } from '@components/production-order/production-order.service';

@Module({
  imports: [
    ConfigModule,
    TypeOrmModule.forFeature([
      ManufacturingOrderEntity,
      ManufacturingOrderDetailEntity,
      BomEntity,
      BomDetailEntity,
      MoPlanEntity,
      MoPlanBomEntity,
      BomProducingStepDetailEntity,
      BomUserProducingStepDetailEntity,
      MaterialPlanStructureEntity,
      MaterialPlanScheduleEntity,
      MaterialPlanProducingStepEntity,
      MaterialPlanEntity,
      WorkCenterShiftEntity,
      WorkOrderEntity,
      WorkCenterEntity,
      WorkOrderScheduleDetailEntity,
      BomVersionEntity,
    ]),
    ItemModule,
    UserModule,
    SaleModule,
    MasterPlanModule,
    RequestModule,
    BomModule,
  ],
  providers: [
    {
      provide: 'MoDetailRepositoryInterface',
      useClass: ManufacturingOrderDetailRepository,
    },
    {
      provide: 'WorkCenterShiftRepositoryInterface',
      useClass: WorkCenterShiftRepository,
    },
    {
      provide: 'WorkOrderScheduleDetailRepositoryInterface',
      useClass: WorkOrderScheduleDetailRepository,
    },
    {
      provide: 'MoPlanRepositoryInterface',
      useClass: MoPlanRepository,
    },
    {
      provide: 'ManufacturingOrderRepositoryInterface',
      useClass: ManufacturingOrderRepository,
    },
    {
      provide: 'ManufacturingOrderDetailRepositoryInterface',
      useClass: ManufacturingOrderDetailRepository,
    },
    {
      provide: 'MoPlanBomRepositoryInteface',
      useClass: MoPlanBomRepository,
    },
    {
      provide: 'MoPlanRepositoryInteface',
      useClass: MoPlanRepository,
    },
    {
      provide: 'ManufacturingOrderServiceInterface',
      useClass: ManufacturingOrderService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
    {
      provide: 'MasterPlanServiceInterface',
      useClass: MasterPlanService,
    },
    {
      provide: 'BomRepositoryInterface',
      useClass: BomRepository,
    },
    {
      provide: 'BomDetailRepositoryInterface',
      useClass: BomDetailRepository,
    },
    {
      provide: 'MaterialPlanRepositoryInterface',
      useClass: MaterialPlanRepository,
    },
    {
      provide: 'BomProducingStepDetailsRepositoryInterface',
      useClass: BomProducingStepDetailsRepository,
    },
    {
      provide: 'MaterialPlanProducingStepRepositoryInterface',
      useClass: MaterialPlanProducingStepRepository,
    },
    {
      provide: 'MaterialPlanStructureRepositoryInterface',
      useClass: MaterialPlanStructureRepository,
    },
    {
      provide: 'WorkOrderRepositoryInterface',
      useClass: WorkOrderRepository,
    },
    {
      provide: 'WorkCenterRepositoryInterface',
      useClass: WorkCenterRepository,
    },
    {
      provide: 'RequestServiceInterface',
      useClass: RequestService,
    },
    {
      provide: 'BomUserProducingStepRepositoryInterface',
      useClass: BomUserProducingStepDetailRepository,
    },
    {
      provide: 'BomVersionRepositoryInterface',
      useClass: BomVersionRepository,
    },
    {
      provide: 'ProductionOrderServiceInterface',
      useClass: ProductionOrderService,
    },
    SaleCronService,
    MasterPlanService,
    ManufacturingOrderConfirmedListener,
  ],
  controllers: [ManufacturingOrderController],
})
export class ManufacturingOrderModule {}
