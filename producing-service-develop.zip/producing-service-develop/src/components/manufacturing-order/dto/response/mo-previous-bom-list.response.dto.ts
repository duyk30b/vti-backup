import { BasicResponseDto } from '@core/dto/response/basic.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';

export class MoPreviousBomListResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  inputQuantity: number;

  @ApiProperty()
  @Expose()
  qcPassQuantity: number;

  @ApiProperty()
  @Expose()
  qcRejectQuantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  manufacturingOrder: BasicResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  producingStep: BasicResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  currentProducingStep: BasicResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  routing: BasicResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  item: BasicResponseDto;

  @ApiProperty()
  @Expose()
  totalUnQcQuantity: number;

  @ApiProperty()
  @Expose()
  totalQcQuantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => BasicResponseDto)
  workOrder: BasicResponseDto;
}

export class MoPreviousBomListResponse extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: MoPreviousBomListResponseDto;
}
