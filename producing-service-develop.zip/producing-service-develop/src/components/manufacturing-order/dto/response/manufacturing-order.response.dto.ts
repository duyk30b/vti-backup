import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { ManufacturingOrderResponseAbstractDto } from './manufacturing-order.response.abstract.dto';

export class ManufacturingOrderResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  @Type(() => ManufacturingOrderResponseAbstractDto)
  @IsArray()
  data: ManufacturingOrderResponseAbstractDto;
}
