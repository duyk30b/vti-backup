import { ItemResponseDto } from '@components/item/dto/response/item.dto.response';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class WorkOrderResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;
}

class ProducingStepResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  qcCheck: string;

  @ApiProperty()
  @Expose()
  inputQcCheck: string;

  @ApiProperty({ type: WorkOrderResponseDto, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => WorkOrderResponseDto)
  workOrders: WorkOrderResponseDto[];
}

export class MoItemDetailResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  bomId: number;

  @ApiProperty()
  @Expose()
  isParent: boolean;

  @ApiProperty()
  @Expose()
  hasChild: boolean;

  @ApiProperty({ type: ItemResponseDto })
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;

  @ApiProperty({ type: ProducingStepResponseDto, isArray: true })
  @Type(() => ProducingStepResponseDto)
  @Expose()
  producingSteps: ProducingStepResponseDto;
}
