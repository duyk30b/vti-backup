import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { MoWorkOrderResponseDto } from './manufacturing-order.response.abstract.dto';

class MoPlanBomDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  itemName: string;

  @ApiProperty({ type: MoWorkOrderResponseDto, isArray: true })
  @Type(() => MoWorkOrderResponseDto)
  @Expose()
  @IsArray()
  workOrders: MoWorkOrderResponseDto[];
}

export class MoSubListDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  manufacturingOrderId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  itemCode: string;

  @ApiProperty()
  @Expose()
  itemName: string;

  @ApiProperty({ type: MoPlanBomDto, isArray: true })
  @Type(() => MoPlanBomDto)
  @Expose()
  @IsArray()
  moPlanBom: MoPlanBomDto[];
}
