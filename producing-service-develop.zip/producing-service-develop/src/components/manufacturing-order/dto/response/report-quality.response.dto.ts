import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { IsArray } from 'class-validator';
import { PagingResponse } from '@utils/paging.response';

export class ReportQuality {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  moName: string;

  @ApiProperty()
  @Expose()
  itemCode: string;

  @ApiProperty()
  @Expose()
  itemName: string;

  @ApiProperty()
  @Expose()
  subItemName: string;

  @ApiProperty()
  @Expose()
  versionName: string;

  @ApiProperty()
  @Expose()
  producingStepName: string;

  @ApiProperty()
  @Expose()
  planingQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  qcQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  qcPassQuantity: number;

  @ApiProperty()
  @Expose()
  qcErrorQuantity: number;

  @ApiProperty()
  @Expose()
  qcRecheckQuantity: number;
}

export class ReportQualityResponseDto extends PagingResponse {
  @ApiProperty()
  @IsArray()
  items: ReportQuality[];
}
