import { Expose, Type } from 'class-transformer';

class ManufacturingRequestOrderResponseDto {
  @Expose()
  id: string;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  status: number;

  @Expose()
  orderedAt: string;

  @Expose()
  deadline: string;

  @Expose()
  isHasPlan: string;
}

class MasterPlan {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  dateFrom: string;

  @Expose()
  dateTo: string;

  @Expose()
  status: number;
}

export class StatisticProgressProductionResponseDto {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  planFrom: string;

  @Expose()
  planTo: string;

  @Expose()
  completedAt: string;

  @Expose()
  status: number;

  @Expose()
  planQuantity: number;

  @Expose()
  actualQuantity: number;

  @Type(() => ManufacturingRequestOrderResponseDto)
  @Expose()
  manufacturingRequestOrder: ManufacturingRequestOrderResponseDto;

  @Type(() => MasterPlan)
  @Expose()
  masterPlan: MasterPlan;
}
