import { ItemResponseDto } from '@components/item/dto/response/item.dto.response';
import { UserResponseDto } from '@components/user/dto/response/user.dto.response';
import { BasicResponseDto } from '@core/dto/response/basic.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

export class BaseResponseDto {
  @Expose()
  id: number;

  @Expose()
  code: string;

  @Expose()
  name: string;
}

class MoMaterialPlanResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;
}

class FactoryDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  location: string;

  @ApiProperty()
  @Expose()
  phone: string;
}

class WorkCenterResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;
}

export class MoWorkOrderResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  producingStepId: number;

  @ApiProperty()
  @Expose()
  producingStepName: string;

  @ApiProperty({ type: WorkCenterResponseDto, isArray: true })
  @Type(() => WorkCenterResponseDto)
  @Expose()
  @IsArray()
  workCenters: WorkCenterResponseDto[];
}

class ManufacturingOrderDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  bomId: number;

  @ApiProperty()
  @Expose()
  bomVersionId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  quantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  planningQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty({ type: ItemResponseDto })
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;

  @ApiProperty({ type: BaseResponseDto })
  @Type(() => BaseResponseDto)
  @Expose()
  bomVersion: BaseResponseDto;

  @ApiProperty({ type: MoWorkOrderResponseDto, isArray: true })
  @Type(() => MoWorkOrderResponseDto)
  @Expose()
  @IsArray()
  workOrders: MoWorkOrderResponseDto[];
}

class MoPlanBom {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemId: number;
}

class ManufacturingRequestOrderResponseDto {
  @ApiProperty({ example: '', description: '' })
  @Expose()
  id: string;

  @ApiProperty({ example: 'Đơn hàng gỗ', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'SO001', description: '' })
  @Expose()
  code: string;
}
class MaterPlanResponseDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({})
  @Expose()
  name: string;

  @ApiProperty({ example: 'SO001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ type: ManufacturingRequestOrderResponseDto })
  @Expose()
  @Type(() => ManufacturingRequestOrderResponseDto)
  saleOrders: ManufacturingRequestOrderResponseDto;
}

export class ManufacturingOrderResponseAbstractDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  factoryId: number;

  @ApiProperty()
  @Expose()
  manufacturingRequestOrderId: string;

  @ApiProperty()
  @Transform(({ obj }) => obj?.materialRequestWarning?.id)
  @Expose()
  materialRequestWarningId: number;

  @ApiProperty()
  @Expose()
  planFrom: Date;

  @ApiProperty()
  @Expose()
  planTo: Date;

  @ApiProperty()
  @Expose()
  status: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty()
  @Expose()
  approverId: number;

  @ApiProperty()
  @Expose()
  createdByUserId: number;

  @ApiProperty()
  @Expose()
  approvedAt: Date;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  createdByUser: UserResponseDto;

  @ApiProperty({ type: BaseResponseDto })
  @Expose()
  @Type(() => BaseResponseDto)
  requestBuyMaterial: BaseResponseDto;

  @ApiProperty({ type: FactoryDto })
  @Expose()
  @Type(() => FactoryDto)
  factory: FactoryDto;

  @ApiProperty({ type: MaterPlanResponseDto })
  @Expose()
  @Type(() => MaterPlanResponseDto)
  masterPlan: MaterPlanResponseDto;

  @ApiProperty({ type: ManufacturingRequestOrderResponseDto })
  @Expose()
  @Type(() => ManufacturingRequestOrderResponseDto)
  manufacturingRequestOrder: ManufacturingRequestOrderResponseDto;

  @ApiProperty({ type: MoMaterialPlanResponseDto })
  @Type(() => MoMaterialPlanResponseDto)
  @Expose()
  materialPlan: MoMaterialPlanResponseDto;

  @ApiProperty({ type: ManufacturingOrderDetail, isArray: true })
  @Expose()
  @Type(() => ManufacturingOrderDetail)
  @IsArray()
  manufacturingOrderDetails: ManufacturingOrderDetail[];

  @ApiProperty({ type: MoPlanBom, isArray: true })
  @Expose()
  @Type(() => MoPlanBom)
  @IsArray()
  moPlanBoms: MoPlanBom[];
}
