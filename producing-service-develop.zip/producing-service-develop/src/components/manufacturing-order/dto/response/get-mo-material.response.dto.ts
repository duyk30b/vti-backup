import { BasicResponseDto } from '@core/dto/response/basic.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { BaseResponseDto } from './manufacturing-order.response.abstract.dto';

class ProducingStepResponse extends BasicResponseDto {}

class ItemResponseDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  @Type(() => BaseResponseDto)
  itemUnit: BaseResponseDto;

  @ApiProperty()
  @Expose()
  itemConvertUnits: any;
}

export class GetMoMaterialResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  bomId: number;

  @ApiProperty()
  @Expose()
  bomVersionId: number;

  @ApiProperty()
  @Expose()
  producingStepId: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  normQuantity: number;

  @ApiProperty()
  @Expose()
  proExportQuantity: number;

  @ApiProperty()
  @Expose()
  stepNumber: number;

  @ApiProperty({ type: ProducingStepResponse })
  @Type(() => ProducingStepResponse)
  @Expose()
  producingStep: ProducingStepResponse;

  @ApiProperty({ type: ItemResponseDto })
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;
}
