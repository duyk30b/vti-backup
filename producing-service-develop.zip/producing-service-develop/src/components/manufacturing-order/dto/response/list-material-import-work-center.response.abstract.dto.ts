import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { IsArray } from 'class-validator';

class WorkCenter {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'Đơn hàng gỗ', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'SO001', description: '' })
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  quantity: number;
}

export class ListMaterialImportWorkCenterResponseAbstractDto {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  lotDate: string;

  @ApiProperty()
  @Expose()
  @IsArray()
  workCenters: WorkCenter[];
}
