import { BomResponseDto } from '@components/bom/dto/response/bom.response.dto';
import { ItemResponseDto } from '@components/item/dto/response/item.dto.response';
import { ProducingStepDto } from '@components/plan/dto/response/detail-plan.response';
import { ProducingStepResponseDto } from '@components/producing-step/dto/response/producing-step.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { minus } from '@utils/common';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';

export class ProducingStep {
  constructor() {
    this.multiler = 1;
    this.remainingQuantity = 0;
    this.minInventoryLimit = 0;
    this.needInputQuantity = 0;
    this.planQuantity = 0;
    this.planningQuantity = 0;
    this.producedQuantity = 0;
    this.scapQuantity = 0;
    this.inputQuantity = 0;
    this.errorRepairQuantity = 0;
  }

  producingStep: ProducingStepResponseDto;

  multiler: number;

  remainingQuantity: number;

  minInventoryLimit: number;

  needInputQuantity: number;

  planQuantity: number;

  planningQuantity: number;

  producedQuantity: number;

  scapQuantity: number;

  inputQuantity: number;

  errorRepairQuantity: number;

  manufactureQuantity: number;
}

export class BomItem {
  constructor() {
    this.multiler = 1;
    this.remainningQuantity = 0;
    this.remainningMinQuantity = 0;
    this.needInputQuantity = 0;
    this.planQuantity = 0;
    this.planningQuantity = 0;
    this.producedQuantity = 0;
    this.scapQuantity = 0;
    this.inputQuantity = 0;
    this.errorRepairQuantity = 0;
  }
  item: ItemResponseDto;

  bom: BomResponseDto;

  multiler: number;

  remainningQuantity: number;

  costManufacture: number;

  costQc: number;

  remainningMinQuantity: number;

  needInputQuantity: number;

  planQuantity: number;

  planningQuantity: number;

  producedQuantity: number;

  scapQuantity: number;

  inputQuantity: number;

  errorRepairQuantity: number;

  producingSteps: ProducingStep[];

  subBoms: BomItem[];

  manufactureQuantity: number;

  planFrom: Date;

  planTo: Date;

  status: number;
}

export class MoBomProducingStepStructResponse extends SuccessResponse {
  data: BomItem[];
}
