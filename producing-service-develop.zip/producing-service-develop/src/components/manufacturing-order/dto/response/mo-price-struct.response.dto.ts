import {
  BomDto,
  ItemDto,
} from '@components/plan/dto/response/detail-plan.response';
import { minus, plus } from '@utils/common';
import { SuccessResponse } from '@utils/success.response.dto';

export class MoPriceStructResponse {
  id: number;
  bom: BomDto;
  item: any;

  multiplier: number;
  quantity: number;
  actualQuantity: number;

  costProducing: number;
  costMaterial: number;

  costProducingActual: number;
  costMaterialActual: number;
  productQuantity: number;

  subBoms: MoPriceStructResponse[];

  aggregate() {
    this.productQuantity = minus(
      this.quantity,
      this?.item?.remainingQuantity || 0,
    );
    // tính tổng costProducing = costProducing + (costProducing of sub)
    this.costProducing = this.costProducing || 0;
    this.subBoms.forEach((s) => {
      s.aggregate();

      this.costProducing = plus(this.costProducing, s.costProducing);
      this.costProducingActual = plus(
        this.costProducingActual,
        s.costProducingActual,
      );
      this.costMaterial = plus(this.costMaterial, s.costMaterial);
      this.costMaterialActual = plus(
        this.costMaterialActual,
        s.costMaterialActual,
      );
    });
  }
}
export class MoBomPriceStructResponse extends SuccessResponse {
  data: MoPriceStructResponse[];
}
