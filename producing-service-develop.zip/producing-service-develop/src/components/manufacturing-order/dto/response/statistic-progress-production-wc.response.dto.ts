import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class WorkOrderEntity {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  planFrom: string;

  @ApiProperty()
  @Expose()
  planTo: string;
}

class MasterPlan {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  dateFrom: string;

  @ApiProperty()
  @Expose()
  dateTo: string;

  @ApiProperty()
  @Expose()
  status: number;
}

class WorkCenter {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class MoPlan {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  planFrom: string;

  @ApiProperty()
  @Expose()
  PlanTo: string;

  @ApiProperty()
  @Expose()
  status: number;
}

class Mo {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  manufacturingRequestOrderId: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  planFrom: string;

  @ApiProperty()
  @Expose()
  planTo: string;

  @ApiProperty()
  @Expose()
  completedAt: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;
}

export class StatisticProgressProductionWcResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Type(() => WorkOrderEntity)
  @Expose()
  workOrder: WorkOrderEntity;

  @ApiProperty()
  @Type(() => MasterPlan)
  @Expose()
  masterPlan: MasterPlan;

  @ApiProperty()
  @Type(() => WorkCenter)
  @Expose()
  workCenter: WorkCenter;

  @ApiProperty()
  @Type(() => MoPlan)
  @Expose()
  moPlan: MoPlan;

  @ApiProperty()
  @Type(() => Mo)
  @Expose()
  mo: Mo;
}
