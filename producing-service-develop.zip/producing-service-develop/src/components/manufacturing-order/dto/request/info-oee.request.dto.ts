import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform } from 'class-transformer';
import { IsInt, IsNotEmpty, IsOptional } from 'class-validator';

export class InfoOeeRequestDto extends BaseDto {
  @ApiProperty()
  @Expose()
  @IsNotEmpty()
  @Transform(({ value }) => value.split(',').map((id) => Number(id)))
  ids: number[];

  @ApiProperty()
  @IsInt()
  @Expose()
  @IsOptional()
  workCenterId: number;
}
