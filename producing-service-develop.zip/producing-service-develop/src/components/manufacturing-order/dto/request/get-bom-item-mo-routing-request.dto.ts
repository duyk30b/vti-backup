import { IsInt, IsOptional } from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';
export class GetBomItemMoRoutingRequestDto extends BaseDto {
  @IsOptional()
  @IsInt()
  id: number;

  @IsOptional()
  @IsInt()
  itemId: number;
}
