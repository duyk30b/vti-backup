import { PaginationQuery } from '@utils/pagination.query';
import { IsInt, IsOptional } from 'class-validator';
export class GetItemMoDetailRequestDto extends PaginationQuery {
  @IsOptional()
  @IsInt()
  id: number;

  @IsOptional()
  @IsInt()
  itemMoId: number;

  @IsOptional()
  @IsInt()
  planId: number;
}
export class GetMoPlanBomDetailRequestDto extends PaginationQuery {
  @IsOptional()
  @IsInt()
  id: number;

  @IsOptional()
  @IsInt()
  moPlanBomId: number;
}
