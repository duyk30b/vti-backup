import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsOptional } from 'class-validator';

export class GetMoMaterialRequestDto extends PaginationQuery {
  @ApiProperty()
  @IsOptional()
  moId: number;

  @ApiProperty()
  @IsOptional()
  isHasBom: string;
}
