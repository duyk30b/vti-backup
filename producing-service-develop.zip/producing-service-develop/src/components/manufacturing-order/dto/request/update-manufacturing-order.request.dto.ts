import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsOptional } from 'class-validator';
import { CreateManufacturingOrderByPlanRequestDto } from './create-manufacturing-order-by-plan.request.dto';
import { ManufacturingOrderRequestAbstractDto } from './manufacturing-order.request.abstract.dto';

export class UpdateManufacturingOrderRequestDto extends ManufacturingOrderRequestAbstractDto {
  @ApiProperty({ example: 1, description: 'id' })
  @IsOptional()
  @IsInt()
  id: number;
}
export class UpdateManufacturingOrderByPlanRequestDto extends CreateManufacturingOrderByPlanRequestDto {
  @ApiProperty({ example: 1, description: 'id' })
  @IsOptional()
  @IsInt()
  id: number;
}
