import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsDateString, IsNotEmpty, IsNumberString } from 'class-validator';

export class GetListMoSelectRequestDto extends PaginationQuery {
  @ApiProperty()
  @IsNumberString()
  @IsNotEmpty()
  workCenterId: string;

  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  from: string;

  @ApiProperty()
  @IsDateString()
  @IsNotEmpty()
  to: number;
}
