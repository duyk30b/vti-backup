import { GetStatisticProgressProductionRequestDto } from './get-statistic-progress-production.request.dto';

export class GetMoGroupByManufacturingRequestOrderRequestDto extends GetStatisticProgressProductionRequestDto {}
