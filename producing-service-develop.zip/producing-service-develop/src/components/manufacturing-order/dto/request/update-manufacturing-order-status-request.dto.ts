import { Transform } from 'class-transformer';
import { IsNotEmpty, IsInt } from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';

export class UpdateManufacturingOrderStatusParamDto extends BaseDto {
  @IsNotEmpty()
  @IsInt()
  @Transform(({ value }) => Number(value))
  id: number;
}

export class UpdateManufacturingOrderStatusRequestDto extends UpdateManufacturingOrderStatusParamDto {
  @IsNotEmpty()
  @IsInt()
  userId: number;
}
