import { BaseDto } from '@core/dto/base.dto';
import { Expose } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';

export class MasterPlanModeratedHanlderRequestDto extends BaseDto {
  @Expose()
  @IsNotEmpty()
  @IsInt()
  masterPlanId: number;
}
