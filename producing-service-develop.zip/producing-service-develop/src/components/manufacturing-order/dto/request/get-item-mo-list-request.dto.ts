import { Expose } from 'class-transformer';
import { IsInt, IsOptional, IsEnum } from 'class-validator';
import { PaginationQuery } from '@utils/pagination.query';
export class GetItemMoListRequestDto extends PaginationQuery {
  @IsOptional()
  @IsInt()
  id: number;

  @Expose()
  @IsOptional()
  @IsEnum(['0', '1'])
  onlyInProgressItem: string;
}
