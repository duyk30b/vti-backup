import { Transform } from 'class-transformer';
import { ArrayUnique, IsArray, IsNotEmpty } from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';

export class GetFactoryIdsByManufacturingRequestOrderIdsRequestDto extends BaseDto {
  @IsNotEmpty()
  @ArrayUnique()
  @IsArray()
  manufacturingRequestOrderIds: string[];
}
