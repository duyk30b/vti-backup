import { PaginationQuery } from '@utils/pagination.query';
import { Expose } from 'class-transformer';
import { IsNotEmpty, IsInt, IsOptional, IsEnum } from 'class-validator';
export class GetItemMoListRequestDto extends PaginationQuery {
  @IsNotEmpty()
  @IsInt()
  id: number;

  @Expose()
  @IsOptional()
  @IsEnum(['0', '1'])
  onlyInProgressItem: string;
}
