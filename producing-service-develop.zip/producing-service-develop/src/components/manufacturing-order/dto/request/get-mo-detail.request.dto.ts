import { PaginationQuery } from '@utils/pagination.query';
import { IsOptional } from 'class-validator';

export class GetMoDetailRequestDto extends PaginationQuery {
  @IsOptional()
  id: number;

  @IsOptional()
  isHasBom: string;
}
