import { PaginationQuery } from '@utils/pagination.query';
import { ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsArray,
  IsEnum,
  IsOptional,
  isString,
  IsString,
} from 'class-validator';
import { MAXIMUM_REPORT_SIZE } from '@components/manufacturing-order/manufacturing-order.constant';
import { Transform } from 'class-transformer';

export class GetMoPreviousBomList extends PaginationQuery {
  @ApiPropertyOptional({
    example: '[{"id": "1", "itemId": "2"}]',
  })
  @IsOptional()
  @IsArray()
  @Transform((e) => {
    if (isString(e.value)) {
      e.value = e.value.replace(/'/g, '"');
      return JSON.parse(e.value);
    }
    return e.value;
  })
  queryIds?: any[];

  get take(): number {
    const limit = Number(this.limit) || 10;
    if (limit > 0 && limit <= 200) {
      return limit;
    } else if (limit < 0) {
      return 10;
    } else if (limit > 200) {
      return limit < MAXIMUM_REPORT_SIZE ? limit : MAXIMUM_REPORT_SIZE;
    }
  }

  getTake(): number {
    const limit = Number(this.limit) || 10;
    if (limit > 0 && limit <= 200) {
      return limit;
    } else if (limit < 0) {
      return 10;
    } else if (limit > 200) {
      return limit < MAXIMUM_REPORT_SIZE ? limit : MAXIMUM_REPORT_SIZE;
    }
  }
}
