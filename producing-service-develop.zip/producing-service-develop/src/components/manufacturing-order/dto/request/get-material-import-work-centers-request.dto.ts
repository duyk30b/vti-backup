import { BaseDto } from '@core/dto/base.dto';
import { IsInt, IsNotEmpty, IsArray } from 'class-validator';

export class GetMaterialImportWorkCentersRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsInt()
  moId: number;

  @IsNotEmpty()
  @IsArray()
  itemIds: number[];
}
