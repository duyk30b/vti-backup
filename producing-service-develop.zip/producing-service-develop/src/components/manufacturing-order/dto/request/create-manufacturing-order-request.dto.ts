import { ManufacturingOrderRequestAbstractDto } from './manufacturing-order.request.abstract.dto';

export class CreateManufacturingOrderRequestDto extends ManufacturingOrderRequestAbstractDto {}
