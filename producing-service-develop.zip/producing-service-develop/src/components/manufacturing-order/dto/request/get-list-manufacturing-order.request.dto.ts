import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsEnum, IsOptional, IsString } from 'class-validator';

export class GetListManufacturingOrderRequestDto extends PaginationQuery {
  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isPlanning: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  qcCheckIn: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  qcCheckOut: string;

  @ApiPropertyOptional({
    example: '[{"id": "1", "itemId": "2"}]',
  })
  @IsOptional()
  @IsString()
  queryIds?: string;
}
