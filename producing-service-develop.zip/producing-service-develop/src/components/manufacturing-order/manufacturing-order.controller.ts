import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern, Transport } from '@nestjs/microservices';
import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateManufacturingOrderRequestDto } from './dto/request/create-manufacturing-order-request.dto';
import { GetBomItemMoRoutingRequestDto } from './dto/request/get-bom-item-mo-routing-request.dto';
import {
  GetItemMoDetailRequestDto,
  GetMoPlanBomDetailRequestDto,
} from './dto/request/get-item-mo-detail-request.dto';
import { GetItemMoListRequestDto } from './dto/request/get-item-mo-list-request.dto';
import { GetListManufacturingOrderRequestDto } from './dto/request/get-list-manufacturing-order.request.dto';
import { GetMoDetailRequestDto } from './dto/request/get-mo-detail.request.dto';
import {
  UpdateManufacturingOrderByPlanRequestDto,
  UpdateManufacturingOrderRequestDto,
} from './dto/request/update-manufacturing-order.request.dto';
import { ManufacturingOrderResponseDto } from './dto/response/manufacturing-order.response.dto';
import { ManufacturingOrderServiceInterface } from './interface/manufacturing-order.service.interface';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  COMPLETE_MANUFACTURING_ORDER_PERMISSION,
  CONFIRM_MANUFACTURING_ORDER_PERMISSION,
  CREATE_MANUFACTURING_ORDER_PERMISSION,
  DELETE_MANUFACTURING_ORDER_PERMISSION,
  DETAIL_MANUFACTURING_ORDER_PERMISSION,
  UPDATE_MANUFACTURING_ORDER_PERMISSION,
  LIST_MANUFACTURING_ORDER_PERMISSION,
  REJECT_MANUFACTURING_ORDER_PERMISSION,
} from '@utils/permissions/manufacturing-order';
import { GetListDataByCodes } from '@utils/common.request.dto';
import { LIST_WORK_ORDER_SCHEDULE_PERMISSION } from '@utils/permissions/work-order-schedule';
import { LIST_WORK_CENTER_DAILY_SCHEDULE_PERMISSION } from '@utils/permissions/work-center-plan';
import { DETAIL_MATERIAL_PLAN_PERMISSION } from '@utils/permissions/material-plan';
import {
  MATERIAL_CONSUMPTION_REPORT_PERMISSION,
  QUALITY_REPORT_PERMISSION,
} from '@utils/permissions/report';
import { generatePermissionCodes } from '@utils/common';
import { LIST_PRICE_REPORT_PERMISSION } from '@utils/permissions/price-report';
import { GetMaterialImportWorkCentersRequestDto } from './dto/request/get-material-import-work-centers-request.dto';
import { CreateManufacturingOrderByPlanRequestDto } from './dto/request/create-manufacturing-order-by-plan.request.dto';
import { GetMoItemLotsRequestDto } from './dto/request/get-mo-item-lots.request.dto';
import { InfoOeeRequestDto } from './dto/request/info-oee.request.dto';
import { GetMoPreviousBomList } from './dto/request/get-mo-previous-bom-list.request.dto';
import { GetStatisticProgressProductionRequestDto } from './dto/request/get-statistic-progress-production.request.dto';
import { MasterPlanModeratedHanlderRequestDto } from './dto/request/master-plan-moderated.request.dto';
import { GetFactoryIdsByManufacturingRequestOrderIdsRequestDto } from './dto/request/get-factory-ids-by-sale-order-ids.request.dto';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { GetListManufacturingOrderResponseDto } from './dto/response/get-list-manufacturing-order.response.dto';
import { GetMoItemListResponseDto } from './dto/response/mo-item.response.dto';
import { GetMoPlanItemListResponseDto } from './dto/response/mo-plan-item.response.dto';
import { InfoOeeByMoResponseDto } from './dto/response/info-oee-by-mo.response.dto';
import { MoPreviousBomListResponse } from './dto/response/mo-previous-bom-list.response.dto';
import { MoBomProducingStepStructResponse } from './dto/response/mo-bom-producing-step-struct.response.dto';
import { DashboardSummaryResponseDto } from '@components/dashboard/dto/response/summary.response.dto';
import { UpdateManufacturingOrderStatusParamDto } from './dto/request/update-manufacturing-order-status-request.dto';
import { DEFAULT_TRANSPORT } from '@utils/constant';
import { GetMoGroupByManufacturingRequestOrderRequestDto } from './dto/request/get-mo-group-by-manufacturing-request-order.request.dto';
import { ManufacturingRequestOrderIdParamRequestDto } from '@components/request/dto/request/manufacturing-request-order-id-param.request.dto';
import { NATS_PRODUCE } from '@config/nats.config';
import { GetMoMaterialRequestDto } from './dto/request/get-mo-material.request.dto';

const LIST_MO_PERMISSION = generatePermissionCodes([
  LIST_MANUFACTURING_ORDER_PERMISSION.code,
  LIST_WORK_ORDER_SCHEDULE_PERMISSION.code,
  LIST_WORK_CENTER_DAILY_SCHEDULE_PERMISSION.code,
  DETAIL_MATERIAL_PLAN_PERMISSION.code,
  QUALITY_REPORT_PERMISSION.code,
  MATERIAL_CONSUMPTION_REPORT_PERMISSION.code,
]);
@Controller('manufacturing-orders')
export class ManufacturingOrderController {
  constructor(
    @Inject('ManufacturingOrderServiceInterface')
    private readonly manufacturingOrderService: ManufacturingOrderServiceInterface,
  ) {}

  /**
   * Create new manufacturing_order
   * @param request CreateManufacturingOrderRequestDto
   * @returns
   */
  @PermissionCode(CREATE_MANUFACTURING_ORDER_PERMISSION.code)
  @Post('create')
  @ApiOperation({
    tags: ['MO'],
    summary: 'Create new MO',
    description: 'Tạo 1 lệnh sản xuất mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async create(
    @Body() payload: CreateManufacturingOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.create(request);
  }

  public async getMaterialImportWorkCenters(
    @Body() payload: GetMaterialImportWorkCentersRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getMaterialImportWorkCenters(
      request,
    );
  }

  public async getExportWorkCenters(
    @Body() payload: GetMaterialImportWorkCentersRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getExportWorkCenters(request);
  }

  /**
   * Update manufacturing_order
   * @param request UpdateManufacturingOrderRequestDto
   * @returns
   */
  @PermissionCode(UPDATE_MANUFACTURING_ORDER_PERMISSION.code)
  @Put(':id')
  @ApiOperation({
    tags: ['MO'],
    summary: 'Update MO',
    description: 'Cập nhật thông tin lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  @MessagePattern(`${NATS_PRODUCE}.update_mo`, DEFAULT_TRANSPORT)
  public async update(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateManufacturingOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.update({
      id: id,
      ...request,
    });
  }

  /**
   * Update manufacturing_order
   * @param request UpdateManufacturingOrderRequestDto
   * @returns
   */
  @PermissionCode(UPDATE_MANUFACTURING_ORDER_PERMISSION.code)
  @Put(':id/update-by-plan')
  @ApiOperation({
    tags: ['MO'],
    summary: 'Update MO',
    description: 'Cập nhật thông tin lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  @MessagePattern(`${NATS_PRODUCE}.update_mo_by_plan`, DEFAULT_TRANSPORT)
  public async update_mo_by_plan(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateManufacturingOrderByPlanRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.updateByPlan({
      id: id,
      ...request,
    });
  }

  /**
   * Get manufacturing_order detail
   * @param request GetManufacturingOrderDetailRequest
   * @returns
   */
  @PermissionCode(DETAIL_MANUFACTURING_ORDER_PERMISSION.code)
  @Get(':id')
  @ApiOperation({
    tags: ['MO'],
    summary: 'MO Detail',
    description: 'Chi tiết lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ManufacturingOrderResponseDto,
  })
  public async getDetail(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<ManufacturingOrderResponseDto | any> {
    return await this.manufacturingOrderService.detail(id);
  }

  /**
   * Get manufacturing_order list
   * @param request GetManufacturingOrderListRequest
   * @returns
   */
  @PermissionCode(LIST_MO_PERMISSION)
  @Get('list')
  @ApiOperation({
    tags: ['MO'],
    summary: 'List MO',
    description: 'Danh sách lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: GetListManufacturingOrderRequestDto,
  })
  public async getList(
    @Query() payload: GetListManufacturingOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getList(request);
  }

  @Get(':id/plan/producing-steps/list')
  @ApiOperation({
    tags: ['MO'],
    summary: 'List MO',
    description: 'Danh sách lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: GetListManufacturingOrderResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.get_sub_mo_list`, DEFAULT_TRANSPORT)
  public async getSubMoList(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    return await this.manufacturingOrderService.getMoSubListByMoId(id);
  }

  @PermissionCode(DELETE_MANUFACTURING_ORDER_PERMISSION.code)
  @Delete(':id')
  @ApiOperation({
    tags: ['MO'],
    summary: 'Delete MO',
    description: 'Xóa công lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  @MessagePattern(`${NATS_PRODUCE}.delete_mo`, DEFAULT_TRANSPORT)
  public async delete(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    return await this.manufacturingOrderService.delete(id);
  }

  /**
   * Reject
   * @param payload
   * @returns
   */
  @PermissionCode(REJECT_MANUFACTURING_ORDER_PERMISSION.code)
  @Put(':id/reject')
  @ApiOperation({
    tags: ['Produces', 'MO'],
    summary: 'Reject MO',
    description: 'Từ chối lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: ManufacturingOrderResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.reject_mo`, DEFAULT_TRANSPORT)
  public async reject(@Param('id', new ParseIntPipe()) id): Promise<any> {
    return await this.manufacturingOrderService.reject(id);
  }

  /**
   * Confirm
   * @param payload
   * @returns
   */
  @PermissionCode(CONFIRM_MANUFACTURING_ORDER_PERMISSION.code)
  @Put(':id/confirm')
  @ApiOperation({
    tags: ['Produces', 'MO'],
    summary: 'Confirm MO',
    description: 'Xác nhận lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ManufacturingOrderResponseDto,
  })
  public async confirm(
    @Param() payload: UpdateManufacturingOrderStatusParamDto,
  ): Promise<any> {
    const { request } = payload;
    return await this.manufacturingOrderService.confirm(request);
  }

  /**
   * Complete
   * @param payload
   * @returns
   */
  @PermissionCode(COMPLETE_MANUFACTURING_ORDER_PERMISSION.code)
  @Put(':id/complete')
  @ApiOperation({
    tags: ['Produces', 'MO'],
    summary: 'Complete MO',
    description: 'Hoàn tất Lệnh sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Complete successfully',
    type: ManufacturingOrderResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.complete_mo`, DEFAULT_TRANSPORT)
  public async complete(@Param('id', new ParseIntPipe()) id): Promise<any> {
    return await this.manufacturingOrderService.complete(id);
  }

  /**
   * Get manufacturing_order list by ids
   * @param
   * @returns
   */
  public async getListMoByManufacturingRequestOrderId(
    id: string,
  ): Promise<any> {
    return await this.manufacturingOrderService.getListMOByManufacturingRequestOrderId(
      id,
    );
  }

  /**
   * Get manufacturing_order list by manufacturingRequestOrderIds
   * @param
   * @returns
   */
  public async getListMoByManufacturingRequestOrderIds(
    manufacturingRequestOrderIds: string[],
  ): Promise<any> {
    return await this.manufacturingOrderService.getListMOByManufacturingRequestOrderIds(
      manufacturingRequestOrderIds,
    );
  }

  /**
   * Get manufacturing_order list by ids
   * @param
   * @returns
   */
  public async getListMoByIds(ids: number[]): Promise<any> {
    return await this.manufacturingOrderService.getListMoByIds(ids);
  }

  /**
   *
   * @param payload
   * @returns
   */
  @Get(':id/items/list')
  @ApiOperation({
    tags: ['MO', 'MO item'],
    summary: 'MO item list',
    description: 'Danh sách thành phẩm của MO',
  })
  @ApiResponse({
    status: 200,
    description: 'Get list successfully',
    type: GetMoItemListResponseDto,
  })
  public async getItemMoList(
    @Param('id', new ParseIntPipe()) id: number,
    @Query() payload: GetItemMoListRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getItemMoList({
      id: id,
      ...request,
    });
  }

  /**
   *
   * @param payload
   * @returns
   */
  @Get(':id/plans/items')
  @ApiOperation({
    tags: ['MO', 'MO item'],
    summary: 'MO item list by plan',
    description: 'Danh sách thành phẩm của công trình theo plan',
  })
  @ApiResponse({
    status: 200,
    description: 'Get list successfully',
    type: GetMoPlanItemListResponseDto,
  })
  public async getPlanItemMoList(
    @Param('id', new ParseIntPipe()) id: number,
    @Query() payload: GetItemMoListRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getPlanItemMoList({
      id: id,
      ...request,
    });
  }

  /**
   *
   * @param payload
   * @returns
   */
  @Get(':id/plan-items')
  @ApiOperation({
    tags: ['MO', 'MO item'],
    summary: 'MO item list by plan',
    description: 'Danh sách thành phẩm của công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Get list successfully',
    type: GetMoPlanItemListResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.get_plan_item_mo_list_v2`, DEFAULT_TRANSPORT)
  public async getPlanItemMoListV2(
    @Param('id', new ParseIntPipe()) id: number,
    @Query() payload: GetItemMoListRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getPlanItemMoListV2({
      id: id,
      ...request,
    });
  }

  /**
   *
   * @param payload
   * @returns
   */
  @Get(':id/items/:itemMoId')
  @ApiOperation({
    tags: ['MO', 'MO item'],
    summary: 'MO item list',
    description: 'Danh sách bán thành phẩm của MO',
  })
  @ApiResponse({
    status: 200,
    description: 'Get detail successfully',
  })
  public async getItemMoDetail(
    @Param('id', new ParseIntPipe()) id: number,
    @Param('itemMoId', new ParseIntPipe()) itemMoId: number,
    @Query() payload: GetItemMoDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getItemMoDetail({
      ...request,
      id: id,
      itemMoId: itemMoId,
    });
  }

  /**
   *
   * @param payload
   * @returns
   */
  @Get(':id/mo-plan-boms/:moPlanBomId')
  @ApiOperation({
    tags: ['MO', 'MO item'],
    summary: 'MO bom item list',
  })
  @ApiResponse({
    status: 200,
    description: 'Get detail successfully',
  })
  @MessagePattern(`${NATS_PRODUCE}.get_mo_plan_bom_detail`, DEFAULT_TRANSPORT)
  public async getMoPlanBomDetail(
    @Param('id', new ParseIntPipe()) id: number,
    @Param('moPlanBomId', new ParseIntPipe()) moPlanBomId: number,
    @Query() payload: GetMoPlanBomDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getMoPlanBomDetail({
      id: id,
      moPlanBomId: moPlanBomId,
      ...request,
    });
  }

  /**
   *
   * @param payload
   * @returns
   */
  @Get(':id/bom-items/:itemId/routings')
  @ApiOperation({
    tags: ['Mo', 'Mo item', 'Routing Version'],
    summary: 'Mo item list',
    description: 'Danh sách phiên bản quy trình của item ',
  })
  @ApiResponse({
    status: 200,
    description: 'Get list successfully',
    type: GetMoItemListResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.get_bom_item_mo_routing`, DEFAULT_TRANSPORT)
  public async getBomItemMoRouting(
    @Param('id', new ParseIntPipe()) id: number,
    @Param('itemId', new ParseIntPipe()) itemId: number,
    @Query() payload: GetBomItemMoRoutingRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getBomItemMoRouting({
      id: id,
      itemId: itemId,
      ...request,
    });
  }

  @Get('in-progress/list')
  @ApiOperation({
    tags: ['Dashboard'],
    summary: 'Dashboard List In In Progress Boqs',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: DashboardSummaryResponseDto,
  })
  public async getInProgressMoList(): Promise<any> {
    return await this.manufacturingOrderService.getInProgressMoList();
  }

  /**
   * Get mo detail
   * @param request GetMoDetailRequest
   * @returns
   */
  @Get(':id/bom-items/list')
  @ApiOperation({
    tags: ['Mo'],
    summary: 'Mo all item',
    description: 'Tất cả các item của MO',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  public async getAllItemMo(
    @Param('id', new ParseIntPipe()) id: number,
    @Query() payload: GetMoDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getAllItem({
      id: id,
      ...request,
    });
  }

  /**
   *
   * @param payload
   * @returns
   */
  @Get('/:id/item-lots')
  @ApiOperation({
    tags: ['MO', 'MO item lots'],
    summary: 'Get Mo Item Lots',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Mo Item Lots',
  })
  public async getMoItemLots(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    return await this.manufacturingOrderService.getMoItemLots(id);
  }

  /**
   *
   * @param payload
   * @returns
   */
  @PermissionCode(DETAIL_MANUFACTURING_ORDER_PERMISSION.code)
  @Get(':id/bom-producing-step-struct')
  @ApiOperation({
    tags: ['MO'],
    summary: '',
    description: '',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: MoBomProducingStepStructResponse,
  })
  @MessagePattern(
    `${NATS_PRODUCE}.get_mo_bom_producing_step_struct`,
    DEFAULT_TRANSPORT,
  )
  public async getMoBomProducingStepStruct(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    return await this.manufacturingOrderService.getBomProducingStepStruct(id);
  }

  /**
   *
   * @param payload
   * @returns
   */
  @PermissionCode(LIST_PRICE_REPORT_PERMISSION.code)
  @Get(':id/bom-price-structures')
  @ApiOperation({
    tags: ['MO'],
    summary: '',
    description: '',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: MoBomProducingStepStructResponse,
  })
  @MessagePattern(`${NATS_PRODUCE}.get_mo_bom_price_struct`, DEFAULT_TRANSPORT)
  public async getMoBomPriceStruct(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: GetMoDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getBomPriceStruct({
      id: id,
      ...request,
    });
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getListMoByCodes(
    @Body() payload: GetListDataByCodes,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getListMoByCodes(request.codes);
  }

  /**
   *
   * @param payload
   * @returns
   */
  @PermissionCode(CREATE_MANUFACTURING_ORDER_PERMISSION.code)
  @Post('create-by-plan')
  @ApiOperation({
    tags: ['MO'],
    summary: 'Create new MO',
    description: 'Tạo 1 lệnh sản xuất mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  @MessagePattern(`${NATS_PRODUCE}.create_mo_by_plan`, DEFAULT_TRANSPORT)
  public async createByPlan(
    @Body() payload: CreateManufacturingOrderByPlanRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.createByPlan(request);
  }

  /**
   *
   * @param payload
   * @returns
   */
  @Get('work-center/:workCenterId/info-oee')
  @ApiOperation({
    tags: ['Mo', 'Info oee'],
    summary: 'Info oee',
    description: 'Thông tin oee theo MO',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: InfoOeeByMoResponseDto,
  })
  public async getInfoOeeByMo(
    @Param('workCenterId', new ParseIntPipe()) workCenterId: number,
    @Query() payload: InfoOeeRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getInfoOeeByMo({
      workCenterId: workCenterId,
      ...request,
    });
  }

  /**
   *
   * @param payload
   * @returns
   */
  @Get('previous-boms/list')
  @ApiOperation({
    tags: ['MO', 'MO item lots'],
    summary: 'Get Mo Item Lots',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Mo Item Lots',
    type: MoPreviousBomListResponse,
  })
  @MessagePattern(`${NATS_PRODUCE}.get_mo_previous_bom_list`, DEFAULT_TRANSPORT)
  public async getMoPreviousBomList(
    @Query() payload: GetMoPreviousBomList,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getMoPreviousBomList(request);
  }

  /**
   *
   * @param payload
   * @returns
   */
  @Get('statistic/manufacturing-request-orders')
  @ApiOperation({
    tags: ['Mo', 'Statistic'],
    summary: 'Statistic Progress Production',
    description: 'Thống kê tiến độ sản xuất theo đơn hàng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  @MessagePattern(
    `${NATS_PRODUCE}.statistic_progress_production_manufacturing_request_order`,
    DEFAULT_TRANSPORT,
  )
  public async getStatisticProgressProductionManufacturingRequestOrder(
    @Query() payload: GetStatisticProgressProductionRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getStatisticProgressProductionManufacturingRequestOrder(
      request,
    );
  }

  /**
   *
   * @param payload
   * @returns
   */
  @Get('statistic/work-centers')
  @ApiOperation({
    tags: ['Mo', 'Statistic'],
    summary: 'Statistic Progress Production',
    description: 'Thống kê tiến độ sản xuất theo xưởng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  @MessagePattern(
    `${NATS_PRODUCE}.statistic_progress_production_wc`,
    DEFAULT_TRANSPORT,
  )
  public async getStatisticProgressProductionWc(
    @Query() payload: GetStatisticProgressProductionRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getStatisticProgressProductionWc(
      request,
    );
  }

  @MessagePattern(
    `${NATS_PRODUCE}.handler_master_plan_moderated`,
    DEFAULT_TRANSPORT,
  )
  public async masterPlanModeratedHandler(
    @Body() payload: MasterPlanModeratedHanlderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.masterPlanModeratedHandler(
      request,
    );
  }
  // @TODO: remove when refactor done
  @MessagePattern(
    `${NATS_PRODUCE}.handler_master_plan_moderated`,
    DEFAULT_TRANSPORT,
  )
  public async masterPlanModeratedHandlerTcp(
    @Body() payload: MasterPlanModeratedHanlderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.masterPlanModeratedHandler(
      request,
    );
  }

  /**
   *
   * @param payload
   * @returns
   */
  @MessagePattern(
    `${NATS_PRODUCE}.get_factory_ids_by_sale_order_ids`,
    DEFAULT_TRANSPORT,
  )
  public async getFactoryIdsByManufacturingRequestOrderIds(
    @Body() payload: GetFactoryIdsByManufacturingRequestOrderIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getFactoryIdsByManufacturingRequestOrderIds(
      request,
    );
  }
  // @TODO: remove when refactor done
  @MessagePattern(
    `${NATS_PRODUCE}.get_factory_ids_by_sale_order_ids`,
    DEFAULT_TRANSPORT,
  )
  public async getFactoryIdsByManufacturingRequestOrderIdsTcp(
    @Body() payload: GetFactoryIdsByManufacturingRequestOrderIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getFactoryIdsByManufacturingRequestOrderIds(
      request,
    );
  }

  /**
   *
   * @param payload
   * @returns
   */
  // @MessagePattern('get_mo_group_by_manufacturing_request_order')
  public async getMoGroupByManufacturingRequestOrder(
    @Body() payload: GetMoGroupByManufacturingRequestOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getMoGroupByManufacturingRequestOrder(
      request,
    );
  }

  //TODO remove when refactor done
  @MessagePattern(
    `${NATS_PRODUCE}.get_material_import_work_centers`,
    DEFAULT_TRANSPORT,
  )
  public async getMaterialImportWorkCentersTcp(
    @Body() payload: GetMaterialImportWorkCentersRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getMaterialImportWorkCenters(
      request,
    );
  }

  @MessagePattern(
    `${NATS_PRODUCE}.get_item_export_work_centers`,
    DEFAULT_TRANSPORT,
  )
  public async getExportWorkCentersTcp(
    @Body() payload: GetMaterialImportWorkCentersRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getExportWorkCenters(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.get_list_mo_by_ids`, DEFAULT_TRANSPORT)
  public async getListMoByIdsTcp(ids: number[]): Promise<any> {
    return await this.manufacturingOrderService.getListMoByIds(ids);
  }

  @MessagePattern(`${NATS_PRODUCE}.get_mo_item_lots`, DEFAULT_TRANSPORT)
  public async getMoItemLotsTcp(
    @Body() payload: GetMoItemLotsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getMoItemLots(request.id);
  }

  @MessagePattern(`${NATS_PRODUCE}.get_list_mo_by_codes`, DEFAULT_TRANSPORT)
  public async getListMoByCodesTcp(
    @Body() payload: GetListDataByCodes,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getListMoByCodes(request.codes);
  }

  @MessagePattern(
    `${NATS_PRODUCE}.get_list_mo_by_sale_order_id`,
    DEFAULT_TRANSPORT,
  )
  public async getListMoByManufacturingRequestOrderIdTcp(
    id: string,
  ): Promise<any> {
    return await this.manufacturingOrderService.getListMOByManufacturingRequestOrderId(
      id,
    );
  }

  @MessagePattern(`${NATS_PRODUCE}.create_mo`, DEFAULT_TRANSPORT)
  public async createTcp(
    @Body() payload: CreateManufacturingOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.create(request);
  }

  @MessagePattern(
    `${NATS_PRODUCE}.get_list_mo_by_manufacturing_request_order_ids`,
    DEFAULT_TRANSPORT,
  )
  public async getListMoByManufacturingRequestOrderIdsTcp(
    manufacturingRequestOrderIds: string[],
  ): Promise<any> {
    return await this.manufacturingOrderService.getListMOByManufacturingRequestOrderIds(
      manufacturingRequestOrderIds,
    );
  }

  @MessagePattern(
    `${NATS_PRODUCE}.get_mo_group_by_manufacturing_request_order`,
    DEFAULT_TRANSPORT,
  )
  public async getMoGroupByManufacturingRequestOrderTcp(
    @Body() payload: GetMoGroupByManufacturingRequestOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getMoGroupByManufacturingRequestOrder(
      request,
    );
  }

  // TODO: remove when refactor done
  @PermissionCode(LIST_MO_PERMISSION)
  @MessagePattern(`${NATS_PRODUCE}.get_mo_list`, DEFAULT_TRANSPORT)
  public async getListTcp(
    @Body() payload: GetListManufacturingOrderRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getList(request);
  }

  // TODO: remove when refactor done
  @MessagePattern(`${NATS_PRODUCE}.get_info_oee_by_mo`, DEFAULT_TRANSPORT)
  public async getInfoOeeByMoTcp(
    @Body() payload: InfoOeeRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getInfoOeeByMo(request);
  }

  @PermissionCode(DETAIL_MANUFACTURING_ORDER_PERMISSION.code)
  @MessagePattern(`${NATS_PRODUCE}.get_mo_detail`, DEFAULT_TRANSPORT)
  public async getDetailTcp(
    @Body() payload: GetMoDetailRequestDto,
  ): Promise<ManufacturingOrderResponseDto | any> {
    const { request } = payload;
    return await this.manufacturingOrderService.detail(request.id);
  }

  @MessagePattern(`${NATS_PRODUCE}.get_item_mo_list`, DEFAULT_TRANSPORT)
  public async getItemMoListTcp(
    @Body() payload: GetItemMoListRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getItemMoList(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.get_plan_item_mo_list`, DEFAULT_TRANSPORT)
  public async getPlanItemMoListTcp(
    @Body() payload: GetItemMoListRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getPlanItemMoList(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.get_item_mo_detail`, DEFAULT_TRANSPORT)
  public async getItemMoDetailTcp(
    @Body() payload: GetItemMoDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getItemMoDetail(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.mo_in_progress_list`, DEFAULT_TRANSPORT)
  public async getInProgressMoListTcp(): Promise<any> {
    return await this.manufacturingOrderService.getInProgressMoList();
  }

  @MessagePattern(`${NATS_PRODUCE}.get_mo_all_item`, DEFAULT_TRANSPORT)
  public async getAllItemMoTcp(
    @Body() payload: GetMoDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getAllItem(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.get_bom_item_mo_routing`, DEFAULT_TRANSPORT)
  public async getBomItemMoRoutingTcp(
    @Body() payload: GetBomItemMoRoutingRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getBomItemMoRouting(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.get_mo_previous_bom_list`, DEFAULT_TRANSPORT)
  public async getMoPreviousBomListTcp(
    @Body() payload: GetMoPreviousBomList,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getMoPreviousBomList(request);
  }

  @MessagePattern(
    `${NATS_PRODUCE}.complete_mo_by_completed_manufacturing_request_order_id`,
  )
  public async completedMoByCompletedManufacturingRequestOrderId(
    @Body() payload: ManufacturingRequestOrderIdParamRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.completeMoByCompletedManufacturingRequestOrderId(
      request,
    );
  }

  // @PermissionCode(CREATE_MANUFACTURING_ORDER_PERMISSION.code)
  @Get('/materials')
  @ApiOperation({
    tags: ['MO'],
    summary: 'get mo supplies',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async getMoMaterials(
    @Query() query: GetMoMaterialRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingOrderService.getMoMaterials(request);
  }
}
