import { BomResponseDto } from '@components/bom/dto/response/bom.response.dto';
import { BomDetailRepositoryInterface } from '@components/bom/interface/bom-detail.repository.interface';
import { BomProducingStepDetailsRepositoryInterface } from '@components/bom/interface/bom-producing-step-details.repository.interface';
import { BomRepositoryInterface } from '@components/bom/interface/bom.repository.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { MasterPlanServiceInterface } from '@components/master-plan/interface/master-plan.service.interface';
import { MaterialPlanProducingStepRepositoryInterface } from '@components/material/interface/material-plan-prodcing-step.repository.interface';
import { MaterialPlanStructureRepositoryInterface } from '@components/material/interface/material-plan-structure.repository.interface';
import { MaterialPlanRepositoryInterface } from '@components/material/interface/material-plan.repository.interface';
import {
  FORMAT_NAME_MATERIAL,
  ProductionOrderTypeEnum,
} from '@components/material/material.constant';
import { MoPlanBomRepositoryInteface } from '@components/plan/inteface/mo-plan-bom.repository.inteface';
import { MoPlanRepositoryInteface } from '@components/plan/inteface/mo-plan.repository.inteface';
import { ProducingStepResponseDto } from '@components/producing-step/dto/response/producing-step.response.dto';
import { QualityControlService } from '@components/qmx/quality-control.service';
import { SaleServiceInterface } from '@components/sale-order/interface/sale.service.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { WorkCenterShiftRepositoryInterface } from '@components/work-center/interface/work-center-shift.repository.interface';
import { WorkCenterRepositoryInterface } from '@components/work-center/interface/work-center.repository.interface';
import { WorkOrderRepositoryInterface } from '@components/work-order/interface/work-order.repository.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ManufacturingOrderDetailEntity } from '@entities/manufacturing-order/manufacturing-order-details.entity';
import { ManufacturingOrderEntity } from '@entities/manufacturing-order/manufacturing-orders.entity';
import { MaterialPlanProducingStepEntity } from '@entities/material/material-plan-producing-steps.entity';

import { MaterialPlanStructureEntity } from '@entities/material/material-plan-structure.entity';
import { MaterialPlanEntity } from '@entities/material/material-plan.entity';
import { WorkCenterShiftEntity } from '@entities/work-center/work-center-shift.entity';
import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import {
  convertArrayToObject,
  convertArrayToMap,
  distinctArray,
  minus,
  mul,
  plus,
  div,
  getListDateInStartEnd,
  escapeCharForSearch,
} from '@utils/common';
import { MILISECOND, ONE_HOUR, ONE_MINUTE } from '@utils/constant';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { plainToInstance } from 'class-transformer';
import {
  flatMap,
  isEmpty,
  map,
  uniq,
  values,
  find,
  orderBy,
  without,
  groupBy,
  first,
  keyBy,
  unset,
  mapValues,
  sortBy,
  last,
  uniqBy,
  forEach,
  reduce,
} from 'lodash';
import * as moment from 'moment';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, In, Not, QueryRunner } from 'typeorm';
import { CreateManufacturingOrderByPlanRequestDto } from './dto/request/create-manufacturing-order-by-plan.request.dto';
import { CreateManufacturingOrderRequestDto } from './dto/request/create-manufacturing-order-request.dto';
import { GetBomItemMoRoutingRequestDto } from './dto/request/get-bom-item-mo-routing-request.dto';
import {
  GetItemMoDetailRequestDto,
  GetMoPlanBomDetailRequestDto,
} from './dto/request/get-item-mo-detail-request.dto';
import { GetItemMoListRequestDto } from './dto/request/get-item-mo-list-request.dto copy';
import { GetListManufacturingOrderRequestDto } from './dto/request/get-list-manufacturing-order.request.dto';
import { GetMaterialImportWorkCentersRequestDto } from './dto/request/get-material-import-work-centers-request.dto';
import { GetMoDetailRequestDto } from './dto/request/get-mo-detail.request.dto';
import { InfoOeeRequestDto } from './dto/request/info-oee.request.dto';
import { UpdateManufacturingOrderStatusRequestDto } from './dto/request/update-manufacturing-order-status-request.dto';
import {
  UpdateManufacturingOrderByPlanRequestDto,
  UpdateManufacturingOrderRequestDto,
} from './dto/request/update-manufacturing-order.request.dto';
import { InfoOeeByMoResponse } from './dto/response/info-oee-by-mo.response.dto';
import { ListMaterialImportWorkCenterResponseAbstractDto } from './dto/response/list-material-import-work-center.response.abstract.dto';
import { ListMoItemLotsResponse } from './dto/response/list-mo-item-lots.response.abstract.dto';
import { ManufacturingOrderResponseAbstractDto } from './dto/response/manufacturing-order.response.abstract.dto';
import { ManufacturingOrderResponseDto } from './dto/response/manufacturing-order.response.dto';
import {
  BomItem,
  MoBomProducingStepStructResponse,
  ProducingStep,
} from './dto/response/mo-bom-producing-step-struct.response.dto';
import { MoBomRoutingResponseDto } from './dto/response/mo-bom-routing.response.dto';
import { MoItemDetailResponseDto } from './dto/response/mo-item-detail.response.dto';
import { MoItemResponseDto } from './dto/response/mo-item.response.dto';
import { MoPlanItemResponseDto } from './dto/response/mo-plan-item.response.dto';
import {
  MoBomPriceStructResponse,
  MoPriceStructResponse,
} from './dto/response/mo-price-struct.response.dto';
import { MoSubListDto } from './dto/response/mo-sub-list.response.dto';
import { ManufacturingOrderDetailRepositoryInterface } from './interface/manufacturing-order-detail.repository.interface';
import { ManufacturingOrderRepositoryInterface } from './interface/manufacturing-order.repository.interface';
import { ManufacturingOrderServiceInterface } from './interface/manufacturing-order.service.interface';
import {
  ManufacturingOrderStatusEnum,
  STATUS_TO_COMPLETE_MO_STATUS,
  STATUS_TO_CONFIRM_MO_STATUS,
  STATUS_TO_DELETE_MO_STATUS,
  STATUS_TO_REJECT_MO_STATUS,
  STATUS_TO_UPDATE_MO,
} from './manufacturing-order.constant';
import { calculateCostMaterialActual } from './manufacturing-order.logic';
import { MoPlanBomEntity } from '@entities/manufacturing-order/mo-plan-boms.entity';
import { WorkOrderEntity } from '@entities/work-order/work-order.entity';
import {
  WorkOrderStatusEnum,
  WorkOrderScheduleStatusEnum,
  WorkOrderScheduleDetailStatusEnum,
} from '@components/work-order/work-order.constant';
import { WorkOrderScheduleEntity } from '../../entities/work-order/work-order-schedule.entity';
import { WorkCenterDailyScheduleEntity } from '@entities/work-center/work-center-daily-schedule.entity';
import { WorkCenterDailyScheduleShiftEntity } from '@entities/work-center/work-center-daily-schedule-shift.entity';
import { MoPlanEntity } from '@entities/manufacturing-order/mo-plans.entity';
import { lotNumberGenerator } from '@utils/helper';
import { randomBytes } from 'crypto';
import { WorkOrderScheduleDetailEntity } from '@entities/work-order/work-order-schedule-detail.entity';
import { MoPlanStatus } from '@constant/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { GetMoPreviousBomList } from './dto/request/get-mo-previous-bom-list.request.dto';
import { MoPreviousBomListResponseDto } from './dto/response/mo-previous-bom-list.response.dto';
import { WorkOrderScheduleDetailRepositoryInterface } from '@components/work-order/interface/work-order-schedule-detail.repository.interface';
import { GetStatisticProgressProductionRequestDto } from './dto/request/get-statistic-progress-production.request.dto';
import { StatisticProgressProductionResponseDto } from './dto/response/statistic-progress-production.response.dto';
import { StatisticProgressProductionWcResponseDto } from './dto/response/statistic-progress-production-wc.response.dto';
import { MasterPlanModeratedHanlderRequestDto } from './dto/request/master-plan-moderated.request.dto';
import { GetFactoryIdsByManufacturingRequestOrderIdsRequestDto } from './dto/request/get-factory-ids-by-sale-order-ids.request.dto';
import { RequestServiceInterface } from '@components/request/interface/request.service.interface';
import { GetMoGroupByManufacturingRequestOrderRequestDto } from './dto/request/get-mo-group-by-manufacturing-request-order.request.dto';
import { BomUserProducingStepDetailRepositoryInterface } from '@components/bom/interface/bom-user-producing-step-details.repository.interface';
import { ManufacturingRequestOrderIdParamRequestDto } from '@components/request/dto/request/manufacturing-request-order-id-param.request.dto';
import { ProductionOrderServiceInterface } from '@components/production-order/interface/production-order.service.interface';
import { CreateProductionOrderFormData } from '@components/production-order/dto/request/create-production-order-draft-request.dto';
import { GetMoMaterialRequestDto } from './dto/request/get-mo-material.request.dto';
import { GetMoMaterialResponseDto } from './dto/response/get-mo-material.response.dto';

@Injectable()
export class ManufacturingOrderService
  implements ManufacturingOrderServiceInterface
{
  constructor(
    @Inject('ManufacturingOrderRepositoryInterface')
    private readonly manufacturingOrderRepository: ManufacturingOrderRepositoryInterface,

    @Inject('ManufacturingOrderDetailRepositoryInterface')
    private readonly manufacturingOrderDetailRepository: ManufacturingOrderDetailRepositoryInterface,

    @Inject('MaterialPlanRepositoryInterface')
    private readonly materialPlanRepository: MaterialPlanRepositoryInterface,

    @Inject('BomProducingStepDetailsRepositoryInterface')
    private readonly bomProducingStepDetailsRepository: BomProducingStepDetailsRepositoryInterface,

    @Inject('MaterialPlanStructureRepositoryInterface')
    private readonly materialPlanStructureRepository: MaterialPlanStructureRepositoryInterface,

    @Inject('MaterialPlanProducingStepRepositoryInterface')
    private readonly materialPlanProducingStepRepository: MaterialPlanProducingStepRepositoryInterface,

    @Inject('WorkOrderScheduleDetailRepositoryInterface')
    private readonly workOrderScheduleDetailRepository: WorkOrderScheduleDetailRepositoryInterface,

    @Inject('BomDetailRepositoryInterface')
    private readonly bomDetailRepository: BomDetailRepositoryInterface,

    @Inject('MoPlanBomRepositoryInteface')
    private readonly moPlanBomRepository: MoPlanBomRepositoryInteface,

    @Inject('MoPlanRepositoryInteface')
    private readonly moPlanRepository: MoPlanRepositoryInteface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('MasterPlanServiceInterface')
    protected readonly masterPlanService: MasterPlanServiceInterface,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('BomRepositoryInterface')
    private readonly bomRepository: BomRepositoryInterface,

    @Inject('SaleServiceInterface')
    protected readonly saleService: SaleServiceInterface,

    @Inject('QualityControlServiceInterface')
    protected readonly qualityControlService: QualityControlService,

    @Inject('WorkCenterShiftRepositoryInterface')
    private readonly workCenterShiftRepository: WorkCenterShiftRepositoryInterface,

    @Inject('WorkOrderRepositoryInterface')
    private readonly workOrderRepository: WorkOrderRepositoryInterface,

    @Inject('WorkCenterRepositoryInterface')
    private readonly workCenterRepository: WorkCenterRepositoryInterface,

    @Inject('RequestServiceInterface')
    private readonly requestService: RequestServiceInterface,

    @Inject('BomUserProducingStepDetailRepositoryInterface')
    private readonly bomUserProducingStepDetailRepository: BomUserProducingStepDetailRepositoryInterface,

    @Inject('ProductionOrderServiceInterface')
    private readonly productionOrderService: ProductionOrderServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nRequestScopeService,

    private readonly eventEmitter: EventEmitter2,
  ) {}

  /**
   *
   * @param id
   * @returns
   */
  public async getMoItemLots(id: number): Promise<ResponsePayload<any>> {
    const data = await this.manufacturingOrderDetailRepository.getMoItemLots(
      id,
    );

    const response = plainToInstance(ListMoItemLotsResponse, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .withData(response)
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getMaterialImportWorkCenters(
    payload: GetMaterialImportWorkCentersRequestDto,
  ): Promise<any> {
    const { moId, itemIds } = payload;
    const result =
      await this.materialPlanStructureRepository.getMaterialImportWorkCenters(
        moId,
        itemIds,
      );

    const response = plainToInstance(
      ListMaterialImportWorkCenterResponseAbstractDto,
      result,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .withData(response)
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getExportWorkCenters(
    payload: GetMaterialImportWorkCentersRequestDto,
  ): Promise<any> {
    const { moId, itemIds } = payload;
    const result = await this.moPlanBomRepository.getExportWorkCenters(
      moId,
      itemIds,
    );
    const response = plainToInstance(
      ListMaterialImportWorkCenterResponseAbstractDto,
      result,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .withData(response)
      .build();
  }

  /**
   *
   * @param id
   * @returns
   */
  async getListMOByManufacturingRequestOrderId(id: string): Promise<any> {
    const result =
      await this.manufacturingOrderRepository.getListMOByManufacturingRequestOrderId(
        id,
      );

    const response = plainToInstance(
      ManufacturingOrderResponseAbstractDto,
      result,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .withData(response)
      .build();
  }

  /**
   *
   * @param payload UpdateManufacturingOrderStatusRequestDto
   * @returns
   */
  public async complete(
    payload: UpdateManufacturingOrderStatusRequestDto,
  ): Promise<any> {
    const { id } = payload;

    const manufacturingOrder =
      await this.manufacturingOrderRepository.findOneById(id);
    if (!manufacturingOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_COMPLETE_MO_STATUS.includes(manufacturingOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }
    return await this.updateManufacturingOrderStatus(
      manufacturingOrder,
      ManufacturingOrderStatusEnum.COMPLETED,
    );
  }

  /**
   *
   * @param payload UpdateManufacturingOrderStatusRequestDto
   * @returns
   */
  public async confirm(
    payload: UpdateManufacturingOrderStatusRequestDto,
  ): Promise<any> {
    const { id, userId } = payload;
    const manufacturingOrder =
      await this.manufacturingOrderRepository.getDetail(id);

    if (!manufacturingOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!STATUS_TO_CONFIRM_MO_STATUS.includes(manufacturingOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }

    const moByMasterPlan = await this.masterPlanService.getMOByMasterPlan(
      manufacturingOrder.masterPlanId,
    );

    if (!isEmpty(moByMasterPlan)) {
      const lastMoByMasterPlan = last(
        sortBy(moByMasterPlan, (mo) => mo.dateTo),
      );

      if (
        !moment(manufacturingOrder.dateFrom).isSame(
          lastMoByMasterPlan.dateTo,
          'day',
        )
      ) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
          .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
          .build();
      }
    }

    // const materialPlanStructure =
    //   await this.materialPlanStructureRepository.findByCondition({
    //     manufacturingOrderId: id,
    //   });
    // const materialPlanProducingSteps =
    //   await this.generateMaterialPlanProducingStep(materialPlanStructure);
    // await this.materialPlanProducingStepRepository.create(
    //   materialPlanProducingSteps,
    // );

    //auto generate prO
    const materialPlan = await this.materialPlanRepository.findOneByCondition({
      manufacturingOrderId: id,
    });

    const materialItems =
      await this.materialPlanStructureRepository.getSumMaterialByMaterialPlanId(
        materialPlan.id,
      );

    const exportMaterialItems = materialItems.map((mi) => ({
      itemId: mi.itemId,
      bomQuantity: parseInt(mi.totalQuantity),
      quantity: parseInt(mi.totalQuantity),
    }));

    const createPrORequest = new CreateProductionOrderFormData();
    let createProductionOrderResponse;
    const data = {
      moId: id,
      moCode: manufacturingOrder.code,
      createdByUserId: manufacturingOrder.createdByUserId,
      requestDate: new Date(),
    };
    //gen pro-exp
    createPrORequest.data = {
      ...data,
      isDraft: true,
      type: ProductionOrderTypeEnum.Export,
      productionOrderDetails: exportMaterialItems,
    };

    createProductionOrderResponse =
      await this.productionOrderService.createProductionOrderDraft(
        createPrORequest,
      );

    if (createProductionOrderResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate(
          'error.CAN_NOT_CREATE_PRODUCTION_ORDER_FROM_MO',
        ),
      ).toResponse();
    }

    //gen pro-imp
    createPrORequest.data = {
      ...data,
      isDraft: true,
      type: ProductionOrderTypeEnum.Import,
      productionOrderDetails: manufacturingOrder.manufacturingOrderDetails.map(
        (manufacturingOrderDetail) => ({
          itemId: manufacturingOrderDetail.itemId,
          quantity: manufacturingOrderDetail.quantity,
          bomVersionId: manufacturingOrderDetail.bomVersionId,
        }),
      ),
    };

    createProductionOrderResponse =
      await this.productionOrderService.createProductionOrderDraft(
        createPrORequest,
      );
    if (createProductionOrderResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate(
          'error.CAN_NOT_CREATE_PRODUCTION_ORDER_FROM_MO',
        ),
      ).toResponse();
    }

    const moPlan = await this.createMoPlan(manufacturingOrder);

    if (moPlan) {
      return await this.updateManufacturingOrderStatus(
        manufacturingOrder,
        ManufacturingOrderStatusEnum.CONFIRMED,
        userId,
      );
    }

    return new ApiError(
      ResponseCodeEnum.BAD_REQUEST,
      await this.i18n.translate('error.INTERNAL_SERVER_ERROR'),
    ).toResponse();
  }

  /**
   *
   * @param payload UpdateManufacturingOrderStatusRequestDto
   * @returns
   */
  public async reject(
    payload: UpdateManufacturingOrderStatusRequestDto,
  ): Promise<any> {
    const { id } = payload;

    const manufacturingOrder =
      await this.manufacturingOrderRepository.findOneById(id);
    if (!manufacturingOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_REJECT_MO_STATUS.includes(manufacturingOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }

    return await this.updateManufacturingOrderStatus(
      manufacturingOrder,
      ManufacturingOrderStatusEnum.REJECTED,
    );
  }

  /**
   *
   * @param payload
   * @returns
   */
  async getList(payload: GetListManufacturingOrderRequestDto): Promise<any> {
    const filterWorkCenterId = payload.filter?.find(
      (item) => item.column === 'workCenterId',
    );
    const filterIsWO = payload.filter?.find((item) => item.column === 'isWO');

    if (!isEmpty(filterWorkCenterId)) {
      const workCenter = await this.workCenterRepository.findOneById(
        Number(filterWorkCenterId.text),
      );

      if (!workCenter) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.WORK_CENTER_NOT_FOUND'))
          .build();
      }
    }

    const filterFactoryName = payload.filter?.find(
      (item) => item.column === 'factoryName',
    );

    let filterFactoryIds = [];
    if (!isEmpty(filterFactoryName)) {
      filterFactoryIds = await this.userService.getFactoriesByNameKeyword(
        filterFactoryName,
        true,
      );

      if (isEmpty(filterFactoryIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: payload.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    const filterManufacturingRequestOrderName = payload.filter?.find(
      (item) => item.column === 'manufacturingRequestOrderName',
    );
    let filterManufacturingRequestOrderIds = [];

    const filterManufacturingRequestOrderCode = payload.filter?.find(
      (item) => item.column === 'manufacturingRequestOrderCode',
    );
    if (!isEmpty(filterManufacturingRequestOrderCode)) {
      filterManufacturingRequestOrderIds =
        await this.requestService.getManufacturingRequestOrderByCode(
          filterManufacturingRequestOrderCode.text,
          true,
        );

      if (isEmpty(filterManufacturingRequestOrderIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: payload.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    const filterItemName = payload.filter?.find(
      (item) => item.column === 'itemName',
    );
    let itemIds = [];
    if (!isEmpty(filterItemName)) {
      itemIds = await this.itemService.getItemsByName(filterItemName, true);
      if (isEmpty(itemIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: payload.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    const filterWOList = payload?.filter?.find(
      (item) => item.column === 'workOrderIds',
    );
    let moIds = [];
    if (!isEmpty(filterWOList)) {
      const workOrders = await this.workOrderRepository.findByCondition({
        id: In(filterWOList.text.split(',')),
      });
      if (isEmpty(workOrders)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: payload.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
      moIds = uniq(map(workOrders, 'moId'));
    }

    const { result, count } = await this.manufacturingOrderRepository.getList(
      payload,
      filterFactoryIds,
      filterManufacturingRequestOrderIds,
      itemIds,
      moIds,
      filterWorkCenterId?.text,
      filterIsWO?.text,
    );

    const factoryIds = uniq(map(flatMap(result), 'factoryId'));
    const factories = await this.userService.getFactoriesByIds(
      factoryIds,
      true,
    );

    const manufacturingRequestOrderIds = uniq(
      map(flatMap(result), 'manufacturingRequestOrderId'),
    );
    const masterPlanIds = uniq(map(flatMap(result), 'masterPlanId'));
    const [manufacturingRequestOrders, masterPlans] = await Promise.all([
      this.requestService.getManufacturingRequestOrderByIds(
        manufacturingRequestOrderIds,
        true,
      ),
      this.masterPlanService.getMasterPlans(masterPlanIds, true),
    ]);
    const itemResponseIds = map(
      result,
      (item) => item.manufacturingOrderDetails[0].itemId,
    );
    const serializeItem = await this.itemService.getItemsByIds(
      itemResponseIds,
      true,
    );
    const data = result.map((mo) => ({
      ...mo,
      factory: factories[mo.factoryId],
      manufacturingRequestOrder:
        manufacturingRequestOrders[mo.manufacturingRequestOrderId],
      masterPlan: masterPlans[mo.masterPlanId],
      manufacturingOrderDetails: mo.manufacturingOrderDetails.map(
        (manufacturingOrderDetail) => ({
          ...manufacturingOrderDetail,
          item: serializeItem[manufacturingOrderDetail.itemId],
        }),
      ),
    }));

    const response = plainToInstance(
      ManufacturingOrderResponseAbstractDto,
      data,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: payload.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param manufacturingRequestOrderIds
   * @returns
   */
  async getListMOByManufacturingRequestOrderIds(
    manufacturingRequestOrderIds: string[],
  ): Promise<any> {
    const data = !isEmpty(manufacturingRequestOrderIds)
      ? await this.manufacturingOrderRepository.getListMOByManufacturingRequestOrderIds(
          manufacturingRequestOrderIds,
        )
      : [];

    return new ResponseBuilder<PagingResponse>({
      items: data,
      meta: { total: data.length, page: 1 },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param id
   * @returns
   */
  async getMoSubListByMoId(id: number): Promise<any> {
    let itemIds: any[] = [];
    let data = await this.manufacturingOrderDetailRepository.getMoSubListByMoId(
      id,
    );

    data.forEach((mo) => {
      itemIds.push(mo.itemId);
      mo.moPlanBom.forEach((moPlan) => {
        itemIds.push(moPlan.itemId);
      });
    });
    itemIds = uniq(itemIds);

    const dataResponseItemService = await this.itemService.getItemsByIds(
      itemIds,
    );

    const items = keyBy(dataResponseItemService, 'id');

    data = data.map((mo) => {
      return {
        ...mo,
        itemName: items[mo.itemId].name,
        moPlanBom: mo.moPlanBom.map((moPlan) => {
          return {
            ...moPlan,
            itemName: items[moPlan.itemId].name,
          };
        }),
      };
    });

    const response = plainToInstance(MoSubListDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<any>({
      moDetail: response,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async update(
    payload: UpdateManufacturingOrderRequestDto,
  ): Promise<any> {
    const { id, code, factoryId, manufacturingRequestOrderId, masterPlanId } =
      payload;
    const manufacturingOrder =
      await this.manufacturingOrderRepository.findOneById(id);
    if (!manufacturingOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_UPDATE_MO.includes(manufacturingOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }

    const manufacturingOrderExist =
      await this.manufacturingOrderRepository.findByCondition({
        code: code,
        id: Not(id),
      });
    if (!isEmpty(manufacturingOrderExist)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_ALREADY_EXISTS'),
      ).toResponse();
    }

    const factoriesData = await this.userService.getFactoriesByIds([factoryId]);
    if (factoriesData.length === 0) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.FACTORY_NOT_FOUND'),
      );
    }

    const masterPlan = await this.masterPlanService.getMasterPlanById(
      masterPlanId,
    );

    if (isEmpty(masterPlan)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.PLAN_MASTER_NOT_FOUND'),
      ).toResponse();
    }

    //todo: validate manufacturing request order
    const manufacturingRequestOrderData =
      await this.requestService.getManufacturingRequestOrderByIds([
        manufacturingRequestOrderId,
      ]);
    if (isEmpty(manufacturingRequestOrderData[0])) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate(
          'error.MANUFACTURING_REQUEST_ORDER_NOT_FOUND',
        ),
      ).toResponse();
    }

    if (manufacturingOrder.status === ManufacturingOrderStatusEnum.REJECTED) {
      manufacturingOrder.status = ManufacturingOrderStatusEnum.PENDING;
    }

    const manufacturingOrderEntity =
      await this.manufacturingOrderRepository.updateEntity(
        manufacturingOrder,
        payload,
      );

    return await this.save(manufacturingOrderEntity, payload);
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async create(
    payload: CreateManufacturingOrderRequestDto,
  ): Promise<any> {
    const {
      code,
      factoryId,
      manufacturingRequestOrderId,
      masterPlanId,
      userId,
    } = payload;

    const manufacturingOrder =
      await this.manufacturingOrderRepository.findByCondition({ code: code });
    if (!isEmpty(manufacturingOrder)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_ALREADY_EXISTS'),
      ).toResponse();
    }

    const factoriesData = await this.userService.getFactoriesByIds([factoryId]);
    if (factoriesData.length === 0) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.FACTORY_NOT_FOUND'),
      ).toResponse();
    }

    const masterPlan = await this.masterPlanService.getMasterPlanById(
      masterPlanId,
    );

    if (isEmpty(masterPlan)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.PLAN_MASTER_NOT_FOUND'),
      ).toResponse();
    }

    //todo: validate sale order
    const manufacturingRequestOrderData =
      await this.requestService.getManufacturingRequestOrderByIds([
        manufacturingRequestOrderId,
      ]);
    if (isEmpty(manufacturingRequestOrderData[0])) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate(
          'error.MANUFACTURING_REQUEST_ORDER_NOT_FOUND',
        ),
      ).toResponse();
    }

    const manufacturingOrderEntity =
      this.manufacturingOrderRepository.createEntity({
        ...payload,
        createdByUserId: userId,
        manufacturingRequestOrderCode: manufacturingRequestOrderData[0].code,
      });
    return await this.save(manufacturingOrderEntity, payload);
  }

  /**
   *
   * @param id
   * @returns
   */
  public async delete(
    id: number,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    let response, message;
    let code = ResponseCodeEnum.SUCCESS;

    const manufacturingOrder =
      await this.manufacturingOrderRepository.findOneById(id);

    if (!manufacturingOrder) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (!STATUS_TO_DELETE_MO_STATUS.includes(manufacturingOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.delete(ManufacturingOrderEntity, {
        id: id,
      });

      await queryRunner.manager.delete(ManufacturingOrderDetailEntity, {
        manufacturingOrderId: id,
      });

      await queryRunner.manager.delete(MaterialPlanEntity, {
        manufacturingOrderId: id,
      });

      await queryRunner.manager.delete(MaterialPlanStructureEntity, {
        manufacturingOrderId: id,
      });

      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      message = error;
    }

    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(code)
      .withData(response)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  /**
   *
   * @param id
   * @returns
   */
  public async detail(
    id: number,
  ): Promise<ResponsePayload<ManufacturingOrderResponseDto | any>> {
    const manufacturingOrder =
      await this.manufacturingOrderRepository.getDetail(id);
    if (!manufacturingOrder) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const materialPlan = await this.materialPlanRepository.findOneByCondition({
      manufacturingOrderId: manufacturingOrder.id,
    });

    const users = await this.userService.getUserByIds([
      manufacturingOrder.createdByUserId,
    ]);

    manufacturingOrder.createdByUser = {};
    if (users[0]) {
      manufacturingOrder.createdByUser = users[0];
    }

    manufacturingOrder.factory = {};
    if (manufacturingOrder.factoryId !== null) {
      const factories = await this.userService.getFactoriesByIds([
        manufacturingOrder.factoryId,
      ]);

      manufacturingOrder.factory = !isEmpty(factories[0]) ? factories[0] : {};
    }

    manufacturingOrder.manufacturingRequestOrder = {};
    if (manufacturingOrder.manufacturingRequestOrderId !== null) {
      const manufacturingRequestOrders =
        await this.requestService.getManufacturingRequestOrderByIds([
          manufacturingOrder.manufacturingRequestOrderId,
        ]);
      manufacturingOrder.manufacturingRequestOrder = !isEmpty(
        manufacturingRequestOrders[0],
      )
        ? manufacturingRequestOrders[0]
        : {};
    }

    if (manufacturingOrder.masterPlanId !== null) {
      const masterPlans = await this.masterPlanService.getMasterPlans({
        filter: [
          {
            column: 'masterPlanIds',
            text: [manufacturingOrder.masterPlanId].join(','),
          },
        ],
      });
      manufacturingOrder.masterPlan =
        (!isEmpty(masterPlans) && masterPlans[0]) || {};
    }

    manufacturingOrder.materialPlan = materialPlan;

    const itemIds = map(manufacturingOrder.manufacturingOrderDetails, 'itemId');
    const items = await this.itemService.getItemsByIds(itemIds, true);

    manufacturingOrder.manufacturingOrderDetails =
      manufacturingOrder.manufacturingOrderDetails.map((detail) => ({
        ...detail,
        item: items[detail.itemId],
      }));

    //to do: get so detail

    const response = plainToInstance(
      ManufacturingOrderResponseAbstractDto,
      manufacturingOrder,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param manufacturingOrderEntity
   * @param payload
   * @param itemSchedules
   * @returns
   */
  private async save(
    manufacturingOrderEntity: ManufacturingOrderEntity,
    payload: CreateManufacturingOrderRequestDto,
    itemSchedules?: any,
  ): Promise<any> {
    const { moItems, manufacturingRequestOrderId } = payload;
    const isUpdate = manufacturingOrderEntity.id !== undefined;
    let response, message;
    let code = ResponseCodeEnum.SUCCESS;

    //validate mo items
    const itemIds = uniq(moItems.map((e) => e.id));
    const items = await this.itemService.getItemsByIds(itemIds, true);
    if (!items || itemIds.length !== values(items).length) {
      const itemIdsFound = items ? values(items).map((e) => e.id) : [];
      return new ResponseBuilder({
        invalidItems: moItems.filter((e) => !itemIdsFound.includes(e.id)),
      })
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }

    //validate mo items via manufacturing request order items
    const manufacturingRequestOrders =
      await this.requestService.getManufacturingRequestOrderByIds([
        manufacturingRequestOrderId,
      ]);

    const manufacturingRequestOrderDetails =
      manufacturingRequestOrders[0]?.requestOrderDetails;

    let invalidItems = [];
    const invalidBomVersionIds = [];
    let moRequestItemIds = [];

    manufacturingRequestOrderDetails.forEach(
      (manufacturingRequestOrderDetail) => {
        moRequestItemIds.push(manufacturingRequestOrderDetail.itemId);
        invalidBomVersionIds.push(manufacturingRequestOrderDetail.bomVersionId);
      },
    );

    moRequestItemIds = uniq(moRequestItemIds);

    values(items).forEach((item) => {
      if (!moRequestItemIds.includes(item.id)) {
        invalidItems.push(item);
      }
    });
    if (invalidItems.length > 0) {
      return new ResponseBuilder({
        invalidItems: invalidItems,
      })
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate(
            'error.REQUEST_ITEMS_DO_NOT_EXIST_IN_MANUFACTURING_REQUEST_ORDER',
          ),
        )
        .build();
    }

    // validate whether item has bom
    const boms = await this.bomRepository.findByCondition({
      itemId: In(itemIds),
    });

    if (!boms || itemIds.length !== values(boms).length) {
      const bomIdsFound = boms ? values(boms).map((e) => e.itemId) : [];
      return new ResponseBuilder({
        invalidItems: moItems.filter((e) => !bomIdsFound.includes(e.id)),
      })
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate('error.BOM_FOR_THIS_ITEM_NOT_FOUND'),
        )
        .build();
    }
    const serilizeBoms = {};
    boms.forEach((bom) => {
      serilizeBoms[bom.itemId] = bom;
    });

    const manufacturingOrderDetailRaws = {};
    moItems.forEach((item) => {
      const key = `${item.id}_${item.bomVersionId}`;
      if (manufacturingOrderDetailRaws[key]) {
        manufacturingOrderDetailRaws[key].quantity = plus(
          manufacturingOrderDetailRaws[key].quantity,
          item.quantity,
        );
      } else {
        manufacturingOrderDetailRaws[key] = {
          itemId: item.id,
          quantity: item.quantity,
          code: items[item.id].code,
          bomVersionId: item.bomVersionId,
        };
      }
    });

    //Get all material quantity for mo
    const moBomStruct = {};
    for (const item of moItems) {
      const bomId = serilizeBoms[item.id].id;
      const bomVersionId = item.bomVersionId;
      const bomStruct = await this.bomRepository.getBomStructure(
        bomId,
        [],
        bomVersionId,
      );

      //assign quantity to material of bom at lever 1
      for (const bs of bomStruct) {
        const { bom, bomVersion } = JSON.parse(bs.bom);
        const bomParent = await this.bomDetailRepository.findOneByCondition({
          itemId: bs.itemId,
          bomVersionId: bomVersion.id,
        });
        for (const sub of bs.sub) {
          const moBomKey = `${bs.itemId}_${sub.bomDetailVersionId || ''}_${
            sub.itemId
          }`;
          sub.parentItemId = bs.itemId;
          sub.parentItemVersionId = bomVersion.id;
          moBomStruct[moBomKey] = {
            ...sub,
            moQuantity:
              sub.quantity *
              manufacturingOrderDetailRaws[`${item.id}_${item.bomVersionId}`]
                .quantity,
            bomId: bom.id,
            bomVersionId: item.bomVersionId,
            productId: item.id,
            bomParentId: bomParent ? bomParent.bomId : null,
          };
        }
      }

      //assign quantity to material of bom at lever 2 and lower
      values(moBomStruct).forEach((sub: any) => {
        values(moBomStruct).forEach((innerSub: any) => {
          if (innerSub.parentItemId === sub.itemId) {
            const moBomKey = `${sub.itemId}_${
              innerSub.bomDetailVersionId || ''
            }_${innerSub.itemId}`;
            moBomStruct[moBomKey].moQuantity =
              sub.quantity *
              innerSub.quantity *
              manufacturingOrderDetailRaws[`${item.id}_${item.bomVersionId}`]
                .quantity;
          }
        });
      });
    }

    const moItemIds = values(moBomStruct).map((e: any) => e.itemId);
    const allBoms = await this.bomRepository.findByCondition({
      itemId: In(moItemIds),
    });
    const bomItemIds = allBoms.map((e) => e.itemId);
    const materialItems = values(moBomStruct).filter(
      (e: any) => !bomItemIds.includes(e.itemId) && !e.bomDetailVersionId,
    );

    if (manufacturingOrderEntity.planFrom > manufacturingOrderEntity.planTo) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.PLAN_TO_MUST_GREATER_THAN_PLAN_FROM',
          ),
        )
        .build();
    }

    // create manufacturingOrder
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const manufacturingOrder = await queryRunner.manager.save(
        manufacturingOrderEntity,
      );

      const manufacturingOrderDetailEntities = values(
        manufacturingOrderDetailRaws,
      ).map((manufacturingOrderDetail: any) =>
        this.manufacturingOrderDetailRepository.createEntity({
          manufacturingOrderId: manufacturingOrder.id,
          itemId: manufacturingOrderDetail.itemId,
          itemCode: manufacturingOrderDetail.code,
          bomVersionId: manufacturingOrderDetail.bomVersionId,
          quantity: manufacturingOrderDetail.quantity,
          planFrom: manufacturingOrder.planFrom,
          planTo: manufacturingOrder.planTo,
          bomId: serilizeBoms[manufacturingOrderDetail.itemId].id,
        }),
      );
      if (isUpdate) {
        await queryRunner.manager.delete(ManufacturingOrderDetailEntity, {
          manufacturingOrderId: manufacturingOrder.id,
        });
      }

      manufacturingOrder.manufacturingOrderDetails =
        await queryRunner.manager.save(manufacturingOrderDetailEntities);

      const moDetail = manufacturingOrder.manufacturingOrderDetails;
      const lookUpMoDetail = {};
      moDetail.forEach((mod) => {
        const lookUpMoDetailKey =
          mod.manufacturingOrderId + '_' + mod.itemId + '_' + mod.bomVersionId;
        lookUpMoDetail[lookUpMoDetailKey] = mod;
      });

      if (isUpdate) {
        await queryRunner.manager.delete(MaterialPlanEntity, {
          manufacturingOrderId: manufacturingOrder.id,
        });

        await queryRunner.manager.delete(MaterialPlanStructureEntity, {
          manufacturingOrderId: manufacturingOrder.id,
        });
      }

      const materialPlan = new MaterialPlanEntity();
      materialPlan.name = FORMAT_NAME_MATERIAL + manufacturingOrder.name;
      materialPlan.manufacturingOrderId = manufacturingOrder.id;
      materialPlan.pmId = 1; // change when add pm Field to MO
      await queryRunner.manager.save(materialPlan);

      const materialPlanStructures = [];
      materialItems.forEach((mi: any) => {
        const materialPlanStructure = new MaterialPlanStructureEntity();
        const lookUpMoDetailKey =
          manufacturingOrder.id + '_' + mi.productId + '_' + mi.bomVersionId;
        materialPlanStructure.itemId = mi.itemId;
        materialPlanStructure.quantity = mi.moQuantity;
        materialPlanStructure.ratio = mi.quantity;
        materialPlanStructure.materialPlanId = materialPlan.id;
        materialPlanStructure.manufacturingOrderId = manufacturingOrder.id;
        materialPlanStructure.moDetailId = lookUpMoDetail[lookUpMoDetailKey].id;
        materialPlanStructure.bomId = mi.bomId;
        materialPlanStructure.bomVersionId = mi.bomVersionId;
        materialPlanStructure.bomParentId = mi.bomParentId;
        materialPlanStructures.push(materialPlanStructure);
      });

      await queryRunner.manager.save(materialPlanStructures);

      await queryRunner.manager.save(materialPlanStructures);
      await queryRunner.commitTransaction();
      response = plainToInstance(
        ManufacturingOrderResponseAbstractDto,
        manufacturingOrder,
        {
          excludeExtraneousValues: true,
        },
      );
    } catch (error) {
      await queryRunner.rollbackTransaction();
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      message = error;
    }

    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(code)
      .withData(response)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  /**
   *
   * @param materialPlanStructure
   * @returns
   */
  async generateMaterialPlanProducingStep(
    materialPlanStructure: MaterialPlanStructureEntity[],
  ): Promise<MaterialPlanProducingStepEntity[]> {
    const materialPlanStructureMap = {};
    const bomIds = [];
    const materialPlanProducingStep = [];
    materialPlanStructure.forEach((mps) => {
      materialPlanStructureMap[`${mps.bomId}_${mps.itemId}`] = mps;
      bomIds.push(mps.bomId);
    });
    const bomProducingSteps =
      await this.bomProducingStepDetailsRepository.getBomProducingStep(bomIds);

    const bomProducingStepMap = convertArrayToObject(bomProducingSteps, 'keyz');
    materialPlanStructure.forEach((mps) => {
      const producingSteps = bomProducingStepMap[`${mps.bomId}_${mps.itemId}`]
        ? bomProducingStepMap[`${mps.bomId}_${mps.itemId}`].ps
        : [];
      producingSteps.forEach((ps) => {
        const materialPlanProducingStepEntity =
          new MaterialPlanProducingStepEntity();
        materialPlanProducingStepEntity.materialPlanStructureId =
          materialPlanStructureMap[`${mps.bomId}_${mps.itemId}`].id;
        materialPlanProducingStepEntity.producingStepId = ps.producingStepId;
        materialPlanProducingStepEntity.quantity = mul(ps.rate, mps.quantity);
        materialPlanProducingStepEntity.actualQuantity = 0;
        materialPlanProducingStep.push(materialPlanProducingStepEntity);
      });
    });

    return materialPlanProducingStep;
  }

  // /**
  //  *
  //  * @param manufacturingOrderEntity
  //  * @param status
  //  * @returns
  //  */
  private async updateManufacturingOrderStatus(
    manufacturingOrderEntity: ManufacturingOrderEntity,
    status: number,
    userId?: number,
  ): Promise<any> {
    const moData = { ...manufacturingOrderEntity };
    delete manufacturingOrderEntity.manufacturingOrderDetails;
    delete manufacturingOrderEntity.plan;
    delete manufacturingOrderEntity.materialRequestWarning;

    manufacturingOrderEntity.status = status;
    if (status === ManufacturingOrderStatusEnum.COMPLETED)
      manufacturingOrderEntity.completedAt = new Date();
    await this.manufacturingOrderRepository.update(manufacturingOrderEntity);

    if (status === ManufacturingOrderStatusEnum.CONFIRMED) {
      this.eventEmitter.emit('manufacturing-order.confirmed', {
        mo: moData,
        userId: userId,
      });
    }

    const response = plainToInstance(
      ManufacturingOrderResponseAbstractDto,
      manufacturingOrderEntity,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .withData(response)
      .build();
  }

  /**
   *
   * @param ids
   * @returns
   */
  public async getListMoByIds(ids: number[]): Promise<any> {
    const result = await this.manufacturingOrderRepository.getListMoByIds(ids);

    const manufacturingRequestOrderIds = uniq(
      map(flatMap(result), 'manufacturingRequestOrderId'),
    );
    const manufacturingRequestOrders =
      await this.requestService.getManufacturingRequestOrderByIds(
        manufacturingRequestOrderIds,
        true,
      );

    const itemIds = flatMap(
      map(result, (i) => {
        return map(i.manufacturingOrderDetails, 'itemId');
      }),
    );

    const [serializedItem] = await Promise.all([
      await this.itemService.getItemsByIds(itemIds, true),
    ]);

    const data = result.map((mo) => ({
      ...mo,
      manufacturingOrderDetails: map(mo.manufacturingOrderDetails, (i) => {
        return {
          ...i,
          item: serializedItem[i.itemId],
        };
      }),
      manufacturingRequestOrder:
        manufacturingRequestOrders[mo.manufacturingRequestOrderId],
    }));

    const response = plainToInstance(
      ManufacturingOrderResponseAbstractDto,
      data,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getBomItemMoRouting(
    payload: GetBomItemMoRoutingRequestDto,
  ): Promise<any> {
    const { id, itemId } = payload;
    const mo = await this.manufacturingOrderRepository.findOneById(id);
    if (!mo) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const data = await this.manufacturingOrderRepository.getBomItemMoRouting(
      mo.id,
      itemId,
    );
    const response = plainToInstance(MoBomRoutingResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getItemMoList(payload: GetItemMoListRequestDto): Promise<any> {
    const { id, onlyInProgressItem, filter } = payload;

    const filterIsProductionObject = filter?.find(
      (item) => item.column === 'isProductionObject',
    );

    const filterItemCode = filter?.find((item) => item.column === 'itemCode');

    let data;

    const mo = await this.manufacturingOrderRepository.findOneById(id);
    if (!mo) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const moItems =
      onlyInProgressItem === '1'
        ? await this.manufacturingOrderDetailRepository.getInProgressMoItem(id)
        : await this.manufacturingOrderDetailRepository.findWithRelations({
            where: {
              manufacturingOrderId: id,
            },
          });
    if (!isEmpty(moItems)) {
      const itemIds = uniq(map(moItems, 'itemId'));
      const bomIds = uniq(map(moItems, 'bomId'));
      const producingSteps = await this.moPlanBomRepository.getItemBom(
        id,
        bomIds,
      );
      const filterItem = {
        filterIsProductionObject,
        filterItemCode,
      };
      const items = await this.itemService.getItemsByIds(
        itemIds,
        true,
        null,
        filterItem,
      );
      data = moItems.map((moItem) => {
        const p = find(producingSteps, (ps) => ps.itemId === moItem.itemId);
        return {
          ...moItem,
          producingSteps: p?.producingSteps || [],
          item: items[moItem.itemId] || {},
        };
      });
    } else {
      data = moItems;
    }

    const response = plainToInstance(MoItemResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getPlanItemMoList(
    payload: GetItemMoListRequestDto,
  ): Promise<any> {
    const { id, filter } = payload;
    let data;

    const mo = await this.manufacturingOrderRepository.findOneById(id);
    if (!mo) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const moPlans = await this.moPlanRepository.getMoItemList(id, filter);
    if (!isEmpty(moPlans)) {
      const itemIds = [];
      const bomIds = [];
      moPlans.forEach((moPlan) => {
        itemIds.push(...map(moPlan.moPlanBoms, 'itemId'));
        bomIds.push(...map(moPlan.moPlanBoms, 'bomId'));
      });
      const producingSteps = await this.moPlanBomRepository.getItemBom(
        id,
        itemIds,
      );
      const items = await this.itemService.getItemsByIds(itemIds, true);
      data = moPlans.map((moPlan) => {
        return {
          ...moPlan,
          moPlanBoms: moPlan.moPlanBoms.map((bpb) => {
            const p = find(producingSteps, (ps) => ps.itemId === bpb.itemId);
            return {
              ...bpb,
              producingSteps: p?.producingSteps || [],
              item: items[bpb.itemId],
            };
          }),
        };
      });
    } else {
      data = moPlans;
    }
    const response = plainToInstance(MoPlanItemResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getPlanItemMoListV2(
    payload: GetItemMoListRequestDto,
  ): Promise<any> {
    const { id, filter } = payload;
    let data;

    const mo = await this.manufacturingOrderRepository.findOneById(id);

    if (!mo) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const moPlan = await this.moPlanRepository.getMoItemListV2(id, filter);

    if (!isEmpty(moPlan)) {
      const itemIds = [];
      const bomIds = [];
      itemIds.push(...map(moPlan.moPlanBoms, 'itemId'));
      bomIds.push(...map(moPlan.moPlanBoms, 'bomId'));
      const producingSteps = await this.moPlanBomRepository.getItemBom(
        id,
        itemIds,
      );
      const items = await this.itemService.getItemsByIds(itemIds, true);
      data = {
        ...moPlan,
        moPlanBoms: moPlan.moPlanBoms.map((bpb) => {
          const p = find(producingSteps, (ps) => ps.itemId === bpb.itemId);
          return {
            ...bpb,
            producingSteps: p?.producingSteps || [],
            item: items[bpb.itemId],
          };
        }),
      };
    } else {
      data = moPlan;
    }
    const response = plainToInstance(MoPlanItemResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getItemMoDetail(
    payload: GetItemMoDetailRequestDto,
  ): Promise<any> {
    const { id, itemMoId, planId, filter } = payload;

    const itemMo =
      await this.manufacturingOrderDetailRepository.findOneByCondition({
        manufacturingOrderId: id,
        id: itemMoId,
      });

    if (!itemMo) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const childMoItems = await this.moPlanBomRepository.getChildBom(
      itemMo.id,
      id,
      itemMo.bomId,
      planId,
      filter,
    );

    const parentItem =
      await this.manufacturingOrderDetailRepository.findOneByCondition({
        manufacturingOrderId: id,
        itemId: itemMo.itemId,
      });

    const itemBoms = await this.moPlanBomRepository.getItemBom(
      id,
      [parentItem.itemId],
      planId,
      filter,
      parentItem.id,
    );

    const itemIds = uniq([...map(childMoItems, 'itemId'), itemMo.itemId]);
    const items = await this.itemService.getItemsByIds(itemIds, true);

    const itemBom = find(itemBoms, (ps) => ps.bomId === parentItem.bomId);

    const data = [
      {
        ...parentItem,
        isParent: true,
        producingSteps: orderBy(itemBom?.producingSteps, 'number') || [],
        item: items[itemMo.itemId],
      },
    ].concat(
      childMoItems.map((moItem) => ({
        ...moItem,
        producingSteps: orderBy(moItem?.producingSteps, 'number'),
        isParent: false,
        item: items[moItem.itemId],
      })),
    );

    const response = plainToInstance(MoItemDetailResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getMoPlanBomDetail(
    payload: GetMoPlanBomDetailRequestDto,
  ): Promise<any> {
    const { id, moPlanBomId, filter } = payload;

    const itemMo = await this.moPlanBomRepository.getMoPlanBomDetail(
      id,
      moPlanBomId,
      filter,
    );

    if (!itemMo) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const childMoItems = await this.moPlanBomRepository.getChildBom(
      itemMo.moDetailId,
      id,
      itemMo.bomId,
      null,
      filter,
    );

    const itemIds = uniq([...map(childMoItems, 'itemId'), itemMo.itemId]);
    const items = await this.itemService.getItemsByIds(itemIds, true);

    const data = [
      {
        ...itemMo,
        isParent: true,
        producingSteps: orderBy(itemMo?.producingSteps, 'number') || [],
        item: items[itemMo.itemId],
      },
    ].concat(
      childMoItems.map((moItem) => ({
        ...moItem,
        producingSteps: orderBy(moItem?.producingSteps, 'number'),
        isParent: false,
        item: items[moItem.itemId],
      })),
    );

    const response = plainToInstance(MoItemDetailResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  public async getInProgressMoList(): Promise<any> {
    const data =
      await this.manufacturingOrderRepository.getInProgressMoWithPlan(true);
    const response = plainToInstance(
      ManufacturingOrderResponseAbstractDto,
      data,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  async getAllItem(payload: GetMoDetailRequestDto): Promise<any> {
    const mo = await this.manufacturingOrderRepository.findOneById(payload.id);
    if (!mo) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const allBom = await this.manufacturingOrderDetailRepository.getAllByMoId(
      payload.id,
    );
    const itemIds = [];
    allBom.forEach((bom) => {
      itemIds.push(bom.parentItemId);
      if (bom.bomId) {
        itemIds.push(bom.itemId);
      }
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(
        await this.itemService.getItemsByIds(distinctArray(itemIds), false),
      )
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param moId
   * @returns
   */
  async getBomProducingStepStruct(moId: number): Promise<any> {
    const [mo, allBomOfMoActual, allBomOfMo, aggreateItem] = await Promise.all([
      this.manufacturingOrderRepository.findOneById(moId),
      this.manufacturingOrderRepository.getBomOfMoActualQuantity(moId),
      this.manufacturingOrderRepository.getBomProducingStepStruct(moId),
      this.manufacturingOrderRepository.aggreateItemByMo(moId),
    ]);

    // collect all itemId

    const itemIds = [];
    allBomOfMo.forEach((i, index) => {
      if (i.itemId) itemIds.push(i.itemId);

      const bomOfMoActual = allBomOfMoActual.find(
        (b) =>
          b.mo_detail_id === i.moDetailId && JSON.parse(i.bom).id === b.bom_id,
      );

      if (bomOfMoActual)
        Object.assign(allBomOfMo[index], {
          actual: bomOfMoActual.actualQuantity,
        });

      allBomOfMo[index].bomDetails.forEach((i, index2) => {
        Object.assign(allBomOfMo[index].bomDetails[index2], {
          usedProductionQuantity: i.mul * allBomOfMo[index].actual || 0,
        });
      });

      if (i.bomDetails) {
        itemIds.push(
          ...i.bomDetails.map((i) => i.bomDetail.itemId).filter((i) => i),
        );
      }
    });

    // key mo_id||'_'||item_id||'_'||bom_id||'_'||item_id||'_'||producing_step_id
    const aggreateItemMap = convertArrayToObject(aggreateItem, 'key');
    const allBomOfMoMap = convertArrayToMap(allBomOfMo, [
      'moDetailId',
      'parentItemId',
      'itemId',
    ]);

    const itemMap = await this.itemService.getItemsByIds(
      itemIds,
      true,
      mo.factoryId,
      null,
      true,
    );

    const itemInventoryNorm =
      await this.itemService.getItemInventoryNormByItemIds(itemIds);
    const itemInventoryNormById = mapValues(
      keyBy(itemInventoryNorm, 'itemId'),
      'inventoryLimit',
    );

    const response = new MoBomProducingStepStructResponse();
    const root = allBomOfMo.filter((b) => b.root === '1');
    response.data = root.map((i) => {
      return this.toBomItem(
        i.moDetailId,
        i.parentItemId,
        i.itemId,
        i.bom.id,
        null,
        i.quantity,
        0,
        i.quantity,
        i.planning,
        [],
        allBomOfMoMap,
        aggreateItemMap,
        itemMap,
        moId,
        true,
        0,
        itemInventoryNormById,
      );
    });

    response.data.forEach((d) => {
      d.producedQuantity = this.formatProducedBom(d);
    });
    return response;
  }

  private formatProducedBom(bom) {
    if (!isEmpty(bom.subBoms)) {
      let d = 0;
      d += bom.subBoms.forEach((subBom) => {
        let i = 0;
        i += this.formatProducedBom(subBom);
        if (!subBom.bom) {
          subBom.producedQuantity = i;
        }
      });
      return d;
    }
    let producedQuantity = 0;
    bom.producingSteps.forEach((ps) => {
      producedQuantity += plus(producedQuantity, ps.producedQuantity);
    });
    bom.producedQuantity = producedQuantity;
    return producedQuantity;
  }

  /**
   *
   * @param request
   * @returns
   */
  async getBomPriceStruct(request: GetMoDetailRequestDto): Promise<any> {
    const { sort, id } = request;
    const filterItemName = request.filter?.find(
      (item) => item.column === 'itemName',
    );
    let itemIds = [];
    if (!isEmpty(filterItemName)) {
      itemIds = await this.itemService.getItemsByName(filterItemName, true);
      if (isEmpty(itemIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    const allBomOfMo =
      await this.manufacturingOrderRepository.getPriceManufacture(request);
    const allBomOfMoGroupById = groupBy(allBomOfMo, 'id');
    const qcCriteriaIds = uniq(map(allBomOfMo, 'qcCriteriaId')).filter(
      (id: number) => id != null,
    );
    const quanlityInputPoints =
      await this.qualityControlService.getQualityPointsByIds(qcCriteriaIds);
    const qcById = keyBy(quanlityInputPoints, 'id');
    const qcByItemId = {};
    const finalAllBomOfMo = Object.keys(allBomOfMoGroupById).map((bom) => {
      return allBomOfMoGroupById[bom]
        .map((item) => {
          const qc = qcById[item.qcCriteriaId]?.quantity || 100;
          qcByItemId[item.itemId] = qc;
          return {
            ...item,
            costProducing: plus(
              plus(item.productionCost, item.repairCostWithoutQc || 0),
              item.qcCostWithoutQcNumber * (qc / 100),
            ),
            producingSteps: [item.producingSteps],
          };
        })
        .reduce((object, item) => ({
          ...object,
          costProducing: object.costProducing + item.costProducing,
          producingSteps: uniqBy(
            object.producingSteps.concat(item.producingSteps),
            'id',
          ),
        }));
    });

    const rawQcPlan = await this.qualityControlService.getMoQcPlan(id);
    const formattedQcPlan = {};
    if (!isEmpty(rawQcPlan)) {
      rawQcPlan.planBomOutputs.forEach((bom) => {
        formattedQcPlan[`${bom.planBom.id}`] = bom;
        bom.subBom.forEach((subBom) => {
          formattedQcPlan[`${subBom.planBom.id}`] = subBom;
        });
      });
    }

    const allItemId = [];
    const root = [];
    const allBomMap = {};
    let workCenterIds = [];
    finalAllBomOfMo.forEach((bom) => {
      allItemId.push(bom.itemId);
      allItemId.push(...bom.subItems.map((j) => j.itemId));
      if (!bom.parentBomId) root.push(bom);
      allBomMap[`${bom.itemId}_${bom.parentItemId || 0}`] = bom;
      workCenterIds.push(
        ...without(
          uniq(
            bom?.logTimeData?.map((logTime) =>
              logTime ? logTime['work_center_id'] : null,
            ),
          ),
          null,
          undefined,
        ),
      );
    });

    workCenterIds = uniq(workCenterIds);
    const workCenterShifts =
      await this.workCenterShiftRepository.findByCondition({
        workCenterId: In(workCenterIds),
      });

    const itemMap = await this.itemService.getItemsByIds(allItemId, true, null);

    const response = new MoBomPriceStructResponse();
    const workCenterShiftMap =
      groupBy(workCenterShifts || [], 'workCenterId') || {};
    response.data = await Promise.all(
      root.map((i, idx) =>
        this.toPriceStructItem(
          i,
          null,
          i.itemId,
          i.parentItemId,
          i.quantity,
          1,
          allBomMap,
          itemMap,
          ++idx,
          workCenterShiftMap,
          qcByItemId[i.itemId.toString()],
          formattedQcPlan,
        ),
      ),
    );

    response.data.forEach((bomResponse) => {
      bomResponse.aggregate();
    });

    if (!isEmpty(sort)) {
      sort.forEach((i) => {
        const order = i.order.toLocaleLowerCase();
        switch (i.column) {
          case 'itemName':
            response.data = orderBy(
              response.data,
              (item) => item.item.name,
              order,
            );
            break;
          case 'quantity':
            response.data = orderBy(response.data, 'quantity', order);
            break;
          case 'actualQuantity':
            response.data = orderBy(response.data, 'actualQuantity', order);
            break;
          case 'unit':
            response.data = orderBy(
              response.data,
              (item) => item.item.itemUnitName,
              order,
            );
            break;
          case 'costProducing':
            response.data = orderBy(response.data, 'costProducing', order);
            break;
          case 'costProducingActual':
            response.data = orderBy(
              response.data,
              'costProducingActual',
              order,
            );
            break;
          case 'costMaterial':
            response.data = orderBy(response.data, 'costMaterial', order);
            break;
          case 'costMaterialActual':
            response.data = orderBy(response.data, 'costMaterialActual', order);
            break;
          default:
            break;
        }
      });
    }
    return response;
  }

  private async toPriceStructItem(
    bom,
    bomParent,
    itemId,
    parentItemId,
    quantity,
    multiplier,
    data,
    itemMap,
    index,
    workCenterShiftMap,
    qcByItemId,
    qcPlan?,
  ): Promise<MoPriceStructResponse> {
    const responseItem = new MoPriceStructResponse();
    const iItem = itemMap[itemId];

    responseItem.id = index;
    responseItem.item = iItem;
    responseItem.actualQuantity = bom?.actualQuantity || 0;
    responseItem.multiplier = multiplier;
    responseItem.quantity = quantity;
    responseItem.costProducing = Math.round(bom?.costProducing) || 0;
    let costMaterialActual = 0;

    bom?.materialConsummingData?.forEach((material) => {
      const materialItem = itemMap[material.itemId];
      if (!materialItem) return;
      if (!materialItem.isProductionObject) {
        costMaterialActual = Math.round(
          plus(
            costMaterialActual,
            mul(
              materialItem.price,
              plus(
                material.producedQuantity,
                material.scrapQuantityByItemId
                  ? material.scrapQuantityByItemId[material.itemId] || 0
                  : 0,
              ),
            ),
          ),
        );
      }
    });
    responseItem.costMaterialActual = costMaterialActual;
    responseItem.costProducingActual = await this.calculateCostProducingActual(
      bom?.logTimeData
        ? bom?.logTimeData
        : without(bom?.logTimeData, null, undefined),
      workCenterShiftMap,
      bom?.manualDuration || 0,
    );

    responseItem.costMaterial = Math.round(
      iItem && iItem?.isProductionObject
        ? 0
        : calculateCostMaterialActual(
            bomParent,
            itemMap[itemId],
            quantity,
            qcPlan,
            qcByItemId,
          ),
    );

    responseItem.subBoms = await Promise.all(
      bom?.subItems?.map((j, idx) => {
        return this.toPriceStructItem(
          data[`${j.itemId}_${itemId || 0}`],
          bom,
          j.itemId || 0,
          itemId || 0,
          mul(bom.quantity, j.quantity),
          j.quantity,
          data,
          itemMap,
          ++idx,
          workCenterShiftMap,
          qcByItemId,
          qcPlan,
        );
      }) || [],
    );

    return responseItem;
  }

  /**
   *
   * @param logTimes
   * @param workCenterShiftMap
   * @returns
   */
  private async calculateCostProducingActual(
    logTimes: any[],
    workCenterShiftMap: any,
    manualDuration: number,
  ): Promise<number> {
    if (isEmpty(logTimes)) return 0;
    let cost = 0;
    logTimes.forEach((lt) => {
      if (!lt) return;
      const workCenterId = lt['work_center_id'];
      const shifts = workCenterShiftMap[
        workCenterId
      ] as WorkCenterShiftEntity[];
      const startDateB = lt['start_time'];
      const endDateB = lt['end_time'];

      if (startDateB && endDateB) {
        const dateStart = moment(startDateB);
        const dateEnd = moment(endDateB);
        const dateStartB = +dateStart.format('X');
        const dateEndB = +dateEnd.format('X');
        const data = getListDateInStartEnd(dateStart, dateEnd);

        shifts?.forEach((s) => {
          data.forEach((date) => {
            const startShift = +moment(`${date}T${s.startAt}`).format('X');
            const endShift = +moment(`${date}T${s.endAt}`).format('X');
            // if (dateStartB >= startShift || endDateB <= endShift) return;
            const start = mul(
              startShift > dateStartB ? startShift : dateStartB,
              MILISECOND,
            );
            const end = mul(
              endShift > dateEndB ? dateEndB : endShift,
              MILISECOND,
            );
            if (end < start) return;

            const workTime = div(minus(end, start), ONE_HOUR);
            cost = plus(cost, mul(s.pricePerHour, workTime));
          });
          cost = plus(
            cost,
            mul(s.pricePerHour, div(mul(manualDuration, ONE_MINUTE), ONE_HOUR)),
          );
        });
      } else if (+lt.duration > 0) {
        const firstShift = first(shifts);
        const workTime = div(lt.duration * 1000, ONE_HOUR);
        cost = plus(cost, mul(firstShift.pricePerHour, workTime));
      }
    });

    return Math.round(cost);
  }

  /**
   *
   * @param moDetailId
   * @param parentItemId
   * @param itemOfBom
   * @param bomId
   * @param itemId
   * @param multiler
   * @param remainningQuantity
   * @param planQuantity
   * @param planningQuantity
   * @param steps
   * @param dataMap
   * @param aggDataMap
   * @param itemMap
   * @param moId
   * @param root
   * @param producedQuantity
   * @param remainningMinQuantity
   * @returns
   */
  public toBomItem(
    moDetailId: number,
    parentItemId: number,
    itemOfBom: number,
    bomId: number,
    itemId: number,
    multiler: number,
    remainningQuantity: number,
    planQuantity: number,
    planningQuantity: number,
    steps: any[],
    dataMap: any,
    aggDataMap: any,
    itemMap: any,
    moId: number,
    root: boolean,
    producedQuantity: number,
    remainningMinQuantity: object,
  ) {
    // eslint-disable-next-line @typescript-eslint/no-this-alias
    const that = this;
    // key = _moDetailId_parentItemId_itemId;
    const key = `_${moDetailId}_${parentItemId}_${itemOfBom}`;
    const i = dataMap[key];
    const item = new BomItem();

    item.multiler = multiler;
    item.remainningQuantity = +remainningQuantity;
    item.planningQuantity = +planningQuantity;
    item.costManufacture = i?.costManufacture || 0;
    item.producedQuantity = producedQuantity;
    item.costQc = i?.costQc || 0;
    item.planQuantity = +planQuantity;
    item.status = i?.status;
    item.planFrom = i?.planFrom;
    item.planTo = i?.planTo;
    item.remainningMinQuantity =
      +remainningMinQuantity[itemOfBom || itemId] || 0;

    if (i && i.bom) {
      item.bom = plainToInstance(BomResponseDto, JSON.parse(i.bom));

      item.item = itemMap[itemOfBom] || {};
      item.manufactureQuantity = minus(
        plus(item.planQuantity, item.remainningMinQuantity),
        minus(
          +item.item?.remainingQuantity || 0,
          +item.item?.planningQuantity || 0,
        ),
      );
      if (root) item.multiler = 1;

      item.subBoms = i.bomDetails.map((c) => {
        // key = _moDetailId_itemId;
        const bomDetail = c.bomDetail;
        const keyS = `_${moDetailId}_${itemOfBom}_${bomDetail.itemId}`;
        const child = dataMap[keyS] || {};
        return that.toBomItem(
          moDetailId,
          itemOfBom,
          child.itemId,
          child.bom ? child.bom.id : null,
          bomDetail.itemId,
          c.bomDetail.quantity,
          0,
          c.quantity,
          c.planning,
          c.step,
          dataMap,
          aggDataMap,
          itemMap,
          moId,
          false,
          c.usedProductionQuantity,
          remainningMinQuantity,
        );
      });
    } else {
      if (!itemId) return item;
      let sumInput = 0;
      let sumScap = 0;
      let sumErrorRepair = 0;

      item.item = itemMap[itemId] || {};
      item.manufactureQuantity = minus(
        plus(item.planQuantity, item.remainningMinQuantity),
        minus(
          +item.item?.remainingQuantity || 0,
          +item.item?.planningQuantity || 0,
        ),
      );

      item.producingSteps = steps.map((ps) => {
        // mo_id||'_'||item_id||'_'||bom_id||'_'||item_id||'_'||producing_step_id
        const psResponse = new ProducingStep();
        psResponse.producingStep = plainToInstance(
          ProducingStepResponseDto,
          JSON.parse(ps),
        );
        const key = `${moId}_${parentItemId}_${itemId}_${psResponse.producingStep.id}`;
        const aggData = aggDataMap[key];
        if (aggData) {
          psResponse.multiler = 1;
          psResponse.remainingQuantity = item.item?.remainingQuantity || 0;
          psResponse.scapQuantity = +aggData.scapQuantity || 0;
          psResponse.minInventoryLimit = item.item.minInventoryLimit;
          psResponse.planQuantity = div(
            mul(aggData.planQuantity, item.planQuantity),
            item.multiler,
          );
          psResponse.inputQuantity = aggData.inputQuantity || 0;
          psResponse.errorRepairQuantity = aggData.errorRepairQuantity;
          // psResponse.producedQuantity = div(
          //   mul(aggData.planQuantity, item.producedQuantity),
          //   item.multiler,
          // );

          psResponse.producedQuantity = mul(
            aggData.actualQuantity || 0,
            item.multiler || 1,
          );

          psResponse.manufactureQuantity = item?.manufactureQuantity
            ? div(
                mul(psResponse.planQuantity, item?.planQuantity),
                +item?.manufactureQuantity,
              ) || 0
            : 0;

          psResponse.manufactureQuantity = Math.round(
            psResponse.manufactureQuantity,
          );
        }
        sumInput = plus(sumInput, psResponse.inputQuantity) || 0;
        sumScap = plus(sumScap, psResponse.scapQuantity) || 0;
        sumErrorRepair =
          plus(sumErrorRepair, psResponse.errorRepairQuantity) || 0;

        return psResponse;
      });
      item.scapQuantity = sumScap;
      item.errorRepairQuantity = sumErrorRepair;
      item.inputQuantity = sumInput;
    }
    return item;
  }

  public async getListMoByCodes(
    codes: string[],
  ): Promise<ResponsePayload<any>> {
    const manufacturingOrders =
      await this.manufacturingOrderRepository.findByCondition({
        code: In(codes),
      });
    const response = plainToInstance(
      ManufacturingOrderResponseAbstractDto,
      manufacturingOrders,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  public async createByPlan(
    request: CreateManufacturingOrderByPlanRequestDto,
  ): Promise<any> {
    const {
      name,
      code,
      description,
      userId,
      masterPlanId,
      itemIds,
      manufacturingRequestOrderId,
      planFrom,
      planTo,
    } = request;

    const existedManufacturingOrder =
      await this.manufacturingOrderRepository.findByCondition({ code: code });
    if (!isEmpty(existedManufacturingOrder)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_ALREADY_EXISTS'),
      ).toResponse();
    }

    const masterPlan = await this.masterPlanService.getMasterPlanWithFlatItems({
      masterPlanId: masterPlanId,
      saleOrderId: manufacturingRequestOrderId,
      itemIds: itemIds.join(','),
    });

    if (isEmpty(masterPlan)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.PLAN_MASTER_NOT_FOUND'),
      ).toResponse();
    }

    const items = [];
    const bomIds = [];
    const moItems = {};
    let isMissingQuantity = false;

    masterPlan.saleOrderSchedules.forEach((saleOrder) => {
      saleOrder.itemSchedules.forEach((itemSchedule) => {
        const { bomId, itemId } = itemSchedule;
        items.push(itemSchedule);
        let producingStepItemQuantity = 0;
        bomIds.push(bomId);

        itemSchedule.producingSteps.forEach((producingStep) => {
          producingStep.workCenterSchedules?.forEach((workCenterSchedule) => {
            producingStepItemQuantity = plus(
              workCenterSchedule.quantity || 0,
              producingStepItemQuantity,
            );
          });
        });
        if (itemIds.includes(itemSchedule.itemId)) {
          // Is Finished Item
          if (!itemSchedule.quantity) {
            isMissingQuantity = true;
          }
          moItems[itemId] = {
            id: itemId,
            quantity: itemSchedule.quantity,
          };
        }
      });
    });
    if (isMissingQuantity) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate(
          'error.END_DATE_MO_GREATER_START_DATE_LASTEST_PRODUCING_STEP',
        ),
      ).toResponse();
    }

    const payload = {
      name,
      code,
      description,
      masterPlanId: masterPlan.id,
      planFrom,
      planTo,
      factoryId: masterPlan.factoryId,
      manufacturingRequestOrderId,
      moItems: values(moItems),
    } as CreateManufacturingOrderRequestDto;

    const manufacturingOrderEntity =
      this.manufacturingOrderRepository.createEntity({
        ...payload,
        createdByUserId: userId,
      });

    return await this.save(manufacturingOrderEntity, payload);
  }

  /**
   *
   * @param request
   * @returns
   */
  public async updateByPlan(
    request: UpdateManufacturingOrderByPlanRequestDto,
  ): Promise<any> {
    const {
      id,
      name,
      code,
      description,
      userId,
      masterPlanId,
      itemIds,
      manufacturingRequestOrderId,
      planFrom,
      planTo,
    } = request;

    const manufacturingOrder =
      await this.manufacturingOrderRepository.findOneById(id);
    if (!manufacturingOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_UPDATE_MO.includes(manufacturingOrder.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }

    const manufacturingOrderExist =
      await this.manufacturingOrderRepository.findByCondition({
        code: code,
        id: Not(id),
      });
    if (!isEmpty(manufacturingOrderExist)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_ALREADY_EXISTS'),
      ).toResponse();
    }

    const masterPlan = await this.masterPlanService.getMasterPlanWithFlatItems({
      masterPlanId: masterPlanId,
      saleOrderId: manufacturingRequestOrderId,
      itemIds: itemIds.join(','),
    });

    if (isEmpty(masterPlan)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.PLAN_MASTER_NOT_FOUND'),
      ).toResponse();
    }

    const items = [];
    const bomIds = [];
    const moItems = {};
    let isMissingQuantity = false;

    masterPlan.saleOrderSchedules.forEach((saleOrder) => {
      saleOrder.itemSchedules.forEach((itemSchedule) => {
        const { bomId, itemId } = itemSchedule;
        items.push(itemSchedule);
        let producingStepItemQuantity = 0;
        bomIds.push(bomId);

        itemSchedule.producingSteps.forEach((producingStep) => {
          producingStep.workCenterSchedules?.forEach((workCenterSchedule) => {
            producingStepItemQuantity = plus(
              workCenterSchedule.quantity || 0,
              producingStepItemQuantity,
            );
          });
        });
        if (itemIds.includes(itemSchedule.itemId)) {
          // Is Finished Item
          if (!itemSchedule.quantity) {
            isMissingQuantity = true;
          }
          moItems[itemId] = {
            id: itemId,
            quantity: itemSchedule.quantity,
          };
        }
      });
    });
    if (isMissingQuantity || isEmpty(moItems)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.INVALID_QUANTITY'),
      ).toResponse();
    }

    const payload = {
      name,
      code,
      description,
      masterPlanId: masterPlan.id,
      planFrom,
      planTo,
      factoryId: masterPlan.factoryId,
      manufacturingRequestOrderId,
      moItems: values(moItems),
    } as CreateManufacturingOrderRequestDto;

    const manufacturingOrderEntity =
      this.manufacturingOrderRepository.createEntity({
        ...payload,
        createdByUserId: userId,
      });
    manufacturingOrderEntity.id = id;

    return await this.save(manufacturingOrderEntity, payload);
  }

  /**
   *
   * @param manufacturingOrder
   * @returns
   */
  public async createMoPlan(manufacturingOrder: any): Promise<any> {
    const {
      masterPlanId,
      manufacturingRequestOrderId,
      planFrom,
      planTo,
      manufacturingOrderDetails,
    } = manufacturingOrder;

    const itemIds = map(manufacturingOrderDetails, 'itemId');

    const masterPlan = await this.masterPlanService.getMasterPlanWithFlatItems({
      planFrom: planFrom,
      planTo: planTo,
      masterPlanId: masterPlanId,
      saleOrderId: manufacturingRequestOrderId,
      itemIds: itemIds.join(','),
    });

    if (isEmpty(masterPlan)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.PLAN_MASTER_NOT_FOUND'),
      ).toResponse();
    }

    const items = [];
    const bomIds = [];
    const bomVersionIds = [];
    const moItems = {};
    const moPlanBomEntities = [];
    const toCreateWorkOrders = {};

    await this.generatePreMoPlanFromMasterPlan(
      masterPlan,
      items,
      moItems,
      itemIds,
      bomIds,
      bomVersionIds,
      toCreateWorkOrders,
      moPlanBomEntities,
    );

    const bomVersionProducingStepWorkLoads =
      await this.bomUserProducingStepDetailRepository.findWithRelations({
        where: {
          bomVersionId: In(bomVersionIds),
        },
      });
    const boms = await this.bomRepository.findWithRelations({
      where: {
        id: In(bomIds),
      },
      relations: ['routing'],
    });
    const serializeBoms = keyBy(boms, 'id');

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const moPlanEntity = new MoPlanEntity();
      moPlanEntity.name = manufacturingOrder.name;
      moPlanEntity.code = this.moPlanGenerator(
        manufacturingOrder.id.toString(),
      );
      moPlanEntity.moId = manufacturingOrder.id;
      moPlanEntity.planFrom = planFrom;
      moPlanEntity.planTo = planTo;
      moPlanEntity.status = MoPlanStatus.CONFIRMED;

      const moPlan = await queryRunner.manager.save(moPlanEntity);

      const moPlanBoms = await this.createMoPlanBoms(
        queryRunner,
        manufacturingOrder.id,
        manufacturingOrderDetails,
        moPlan.id,
        moPlanBomEntities,
        serializeBoms,
      );

      const { workOrders, toCreateMoWorkOrderSchedules } =
        await this.createMoPlanWorkOrders(
          queryRunner,
          moPlanBoms,
          bomVersionProducingStepWorkLoads,
          toCreateWorkOrders,
          moPlan.id,
          moPlan.code,
          manufacturingOrder.id,
          serializeBoms,
        );

      const { workOrderSchedules, toCreateMoWorkCenterSchedules } =
        await this.createMoPlanWorkOrderSchedules(
          queryRunner,
          workOrders,
          toCreateMoWorkOrderSchedules,
        );

      const {
        workOrderScheduleDetails,
        toCreateMoWorkCenterDailySchedules,
        queryCreateMaterialDailySchedule,
      } = await this.createMoPlanWorkOrderScheduleDetails(
        queryRunner,
        workOrderSchedules,
        toCreateMoWorkCenterSchedules,
      );

      const {
        workCenterDailySchedules,
        toCreateMoWorkCenterDailyScheduleDetails,
      } = await this.createMoPlanWorkCenterDailySchedules(
        queryRunner,
        workOrderScheduleDetails,
        toCreateMoWorkCenterDailySchedules,
      );

      await this.createMoPlanWorkCenterDailyScheduleDetails(
        queryRunner,
        workCenterDailySchedules,
        toCreateMoWorkCenterDailyScheduleDetails,
      );

      // TODO: refactor sync material
      await queryRunner.manager.query(
        queryCreateMaterialDailySchedule.join(';'),
      );
      await queryRunner.commitTransaction();
      return true;
    } catch (e) {
      await queryRunner.rollbackTransaction();
      console.log({ e });

      return false;
    } finally {
      await queryRunner.release();
    }
  }

  /**
   *
   * @param masterPlan
   * @param items
   * @param moItems
   * @param itemIds
   * @param bomIds
   * @param toCreateWorkOrders
   * @param moPlanBomEntities
   */
  private async generatePreMoPlanFromMasterPlan(
    masterPlan: any,
    items: any[],
    moItems: any,
    itemIds: number[],
    bomIds: number[],
    bomVersionIds: number[],
    toCreateWorkOrders: any,
    moPlanBomEntities: MoPlanBomEntity[],
  ): Promise<any> {
    masterPlan.saleOrderSchedules.forEach((saleOrder) => {
      saleOrder.itemSchedules.forEach((itemSchedule) => {
        const {
          bomId,
          itemId,
          parentBomId,
          itemFinishId,
          bomVersionId,
          parentBomVersionId,
        } = itemSchedule;
        let moItemQuantity = 0;
        items.push(itemSchedule);
        bomIds.push(bomId);
        bomVersionIds.push(bomVersionId);
        let producingStepItemQuantity = 0;

        const moPlanBomEntity = new MoPlanBomEntity();
        const toCreateWorkOrderKey = `${itemId}_${bomVersionId}_${bomId}_${
          parentBomId || ''
        }_${parentBomVersionId || ''}`;
        moPlanBomEntity.bomId = bomId;
        moPlanBomEntity.bomVersionId = bomVersionId;
        moPlanBomEntity.parentBomVersionId = parentBomVersionId;
        moPlanBomEntity.masterPlanItemScheduleId = itemSchedule.id;
        moPlanBomEntity.itemId = itemId;
        moPlanBomEntity.parentBomId = parentBomId;
        moPlanBomEntity.actualQuantity = 0;
        moPlanBomEntity.confirmedQuantity = 0;
        moPlanBomEntity.itemFinishId = itemFinishId;
        moPlanBomEntity.status = MoPlanStatus.CONFIRMED;
        toCreateWorkOrders[toCreateWorkOrderKey] = [];

        itemSchedule.producingSteps.forEach((producingStep) => {
          producingStepItemQuantity = 0;
          const { producingStepId, dateFrom, dateTo } = producingStep;
          const workCenterDailySchedules = [];

          producingStep.workCenterSchedules?.forEach((workCenterSchedule) => {
            const { workCenterId, excutionDate, workCenterDetailSchedules } =
              workCenterSchedule;
            const wcSchedule =
              this.generateWorkCenterScheduleEntitesFromMasterPlan(
                workCenterSchedule.id,
                workCenterId,
                workCenterSchedule.quantity,
                excutionDate,
                workCenterDetailSchedules,
              );
            workCenterDailySchedules.push({
              workCenterSchedule: wcSchedule.workCenterDailySchedule,
              workCenterDailyScheduleDetails:
                wcSchedule.workCenterDailyDetailSchedules,
            });
            producingStepItemQuantity = plus(
              workCenterSchedule.quantity || 0,
              producingStepItemQuantity,
            );
          });

          //
          const { workOrder, workOrderSchedule } =
            this.generateWorkOrderEntitesFromMasterPlan(
              producingStep.id,
              bomId,
              bomVersionId,
              parentBomId,
              parentBomVersionId,
              producingStepItemQuantity,
              producingStepId,
              dateFrom,
              dateTo,
            );
          toCreateWorkOrders[toCreateWorkOrderKey] = toCreateWorkOrders[
            toCreateWorkOrderKey
          ].concat({
            workOrder,
            workOrderSchedule,
            workCenterDailySchedules,
          });

          if (itemIds.includes(itemSchedule.itemId)) {
            // Is Finished Item
            moItemQuantity = plus(moItemQuantity, producingStepItemQuantity);

            moItems[itemId] = {
              id: itemId,
              quantity: moItemQuantity,
            };
          }
          moPlanBomEntity.quantity = producingStepItemQuantity;
        });

        moPlanBomEntities.push(moPlanBomEntity);
      });
    });
  }

  /**
   *
   * @param bomId
   * @param parentBomId
   * @param quantity
   * @param producingStepId
   * @param dateFrom
   * @param dateTo
   * @returns
   */
  private generateWorkOrderEntitesFromMasterPlan(
    masterPlanProducingStepScheduleId,
    bomId,
    bomVersionId,
    parentBomId,
    parentBomVersionId,
    quantity,
    producingStepId,
    dateFrom,
    dateTo,
  ): {
    workOrder: WorkOrderEntity;
    workOrderSchedule: WorkOrderScheduleEntity;
  } {
    const workOrderEntity = new WorkOrderEntity();
    workOrderEntity.bomId = bomId;
    workOrderEntity.bomVersionId = bomVersionId;
    workOrderEntity.masterPlanProducingStepScheduleId =
      masterPlanProducingStepScheduleId;
    workOrderEntity.actualQuantity = 0;
    workOrderEntity.parentBomId = parentBomId || null;
    workOrderEntity.parentBomVersionId = parentBomVersionId || null;
    workOrderEntity.confirmedQuantity = 0;
    workOrderEntity.producingStepId = producingStepId;
    workOrderEntity.quantity = quantity;
    workOrderEntity.planFrom = dateFrom;
    workOrderEntity.planTo = dateTo;
    workOrderEntity.errorQuantity = 0;
    workOrderEntity.exportedQuantity = 0;
    workOrderEntity.scrapQuantity = 0;
    workOrderEntity.qcPassQuantity = 0;
    workOrderEntity.qcRejectQuantity = 0;
    workOrderEntity.exportQuantity = 0;
    workOrderEntity.status = WorkOrderStatusEnum.CONFIRMED;

    const workOrderScheduleEntity = new WorkOrderScheduleEntity();
    workOrderScheduleEntity.quantity = quantity;
    workOrderScheduleEntity.planFrom = dateFrom;
    workOrderScheduleEntity.planTo = dateTo;

    return {
      workOrder: workOrderEntity,
      workOrderSchedule: workOrderScheduleEntity,
    };
  }

  /**
   *
   * @param workCenterId
   * @param quantity
   * @param executionDay
   * @param workCenterDetailSchedules
   * @returns
   */
  private generateWorkCenterScheduleEntitesFromMasterPlan(
    masterPlanWorkCenterDailyScheduleId,
    workCenterId,
    quantity,
    executionDay,
    workCenterDetailSchedules,
  ) {
    const workCenterDailyScheduleEntity = new WorkCenterDailyScheduleEntity();
    workCenterDailyScheduleEntity.executionDay = executionDay;
    workCenterDailyScheduleEntity.masterPlanWorkCenterDailyScheduleId =
      masterPlanWorkCenterDailyScheduleId;
    workCenterDailyScheduleEntity.quantity = quantity;
    workCenterDailyScheduleEntity.workCenterId = workCenterId;
    workCenterDailyScheduleEntity.actualQuantity = 0;

    const workCenterDailyDetailSchedules = workCenterDetailSchedules.map(
      (workCenterDetailSchedule) => {
        const workCenterDailyDetailSchedule =
          new WorkCenterDailyScheduleShiftEntity();
        workCenterDailyDetailSchedule.quantity =
          workCenterDetailSchedule.quantity;
        workCenterDailyDetailSchedule.workCenterShiftId =
          workCenterDetailSchedule.workCenterShiftScheduleId;
        workCenterDailyDetailSchedule.executionDay = executionDay;
        workCenterDailyDetailSchedule.masterPlanWorkCenterDailyScheduleShiftId =
          workCenterDetailSchedule.id;

        return workCenterDailyDetailSchedule;
      },
    );

    return {
      workCenterDailySchedule: workCenterDailyScheduleEntity,
      workCenterDailyDetailSchedules: workCenterDailyDetailSchedules,
    };
  }

  /**
   *
   * @param request
   * @returns
   */
  async getInfoOeeByMo(request: InfoOeeRequestDto): Promise<any> {
    const { ids, workCenterId } = request;

    const data = await this.manufacturingOrderRepository.getInfoOeeByMo({
      manufacturingOrderIds: ids,
      workCenterId: workCenterId,
    });

    let planExecutionTime = 0;
    let totalActualQuantity = 0;
    let totalProductivityIndex = 0;
    let totalProductionTimePerItem = 0;
    let totalActualExecutionTime = 0;
    let totalPlanExecutionTime = 0;
    let totalLogTimeDuration = 0;
    let totalQcPassQuantity = 0;
    let productivityRatio = 0;
    let resultTotalActuaQuantity = 0;
    let resultTotalQcPassQuantity = 0;
    let resultTotalActualExecutionTime = 0;
    let resultTotalPlanExecutionTime = 0;
    let resultProductivityRatio = 0;

    for (let i = 0; i < data.length; i++) {
      const element = data[i];

      const dataSort = orderBy(
        element.productivityAssessmentReportSchedules,
        [(obj) => new Date(obj.executionDay)],
        ['asc'],
      );

      for (let i = 0; i < dataSort.length; i++) {
        if (
          new Date(dataSort[0].executionDay) <=
          new Date(dataSort[i].executionDay)
        ) {
          totalActualQuantity = plus(
            Number(totalActualQuantity),
            Number(dataSort[i].actualQuantity),
          );
          totalLogTimeDuration = plus(
            Number(totalLogTimeDuration),
            Number(dataSort[i].logTimeDuration),
          );
          totalQcPassQuantity = plus(
            Number(totalQcPassQuantity),
            Number(dataSort[i].qcPassQuantity),
          );
          totalProductivityIndex = plus(
            Number(totalProductivityIndex),
            Number(dataSort[i].productivityIndex),
          );
          totalProductionTimePerItem = plus(
            Number(totalProductionTimePerItem),
            Number(dataSort[i].productionTimePerItem),
          );
          resultTotalActuaQuantity += totalActualQuantity;
          resultTotalQcPassQuantity += totalQcPassQuantity;
        } else {
          break;
        }
        planExecutionTime =
          Number(dataSort[i].productivityIndex) > 0
            ? div(
                Number(dataSort[i].productionTimePerItem),
                Number(dataSort[i].productivityIndex),
              )
            : 0;
        totalActualExecutionTime =
          totalActualQuantity > 0
            ? div(totalLogTimeDuration, totalActualQuantity)
            : 0;
        totalPlanExecutionTime =
          totalProductivityIndex > 0
            ? div(totalProductionTimePerItem, totalProductivityIndex)
            : 0;
        productivityRatio =
          totalActualExecutionTime > 0
            ? mul(div(planExecutionTime, totalActualExecutionTime), 100)
            : 0;
        resultTotalActualExecutionTime += totalActualExecutionTime;
        resultTotalPlanExecutionTime += totalPlanExecutionTime;
        resultProductivityRatio += productivityRatio;
      }
    }
    const result: any = {
      totalPlanExecutionTime: resultTotalPlanExecutionTime,
      totalActualExecutionTime: resultTotalActualExecutionTime,
      totalActualQuantity: resultTotalActuaQuantity,
      totalQcPassQuantity: resultTotalQcPassQuantity,
      productivityRatio: resultProductivityRatio,
    };

    const response = plainToInstance(InfoOeeByMoResponse, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  private moPlanGenerator = (string) => `PMO${string.padStart(8, '0')}`;

  /**
   *
   * @param queryRunner
   * @param manufacturingOrderId
   * @param manufacturingOrderDetails
   * @param moPlanId
   * @param moPlanBomEntities
   * @param boms
   * @returns
   */
  private async createMoPlanBoms(
    queryRunner: QueryRunner,
    manufacturingOrderId: number,
    manufacturingOrderDetails: any[],
    moPlanId: number,
    moPlanBomEntities: MoPlanBomEntity[],
    boms: any,
  ): Promise<MoPlanBomEntity[] | any> {
    const moDetails = {};
    moPlanBomEntities.forEach((moPlanBomEntity: MoPlanBomEntity) => {
      const moDetail = find(
        manufacturingOrderDetails,
        (manufacturingOrderDetail) =>
          manufacturingOrderDetail.itemId === moPlanBomEntity.itemFinishId,
      );

      moDetails[`${moPlanBomEntity.bomId}`] = moDetail?.id;
      moPlanBomEntity.moDetailId = moDetail?.id;

      moPlanBomEntity.moId = manufacturingOrderId;
      moPlanBomEntity.moPlanId = moPlanId;
      moPlanBomEntity.routingId = boms[moPlanBomEntity.bomId]?.routingId;
      moPlanBomEntity.lotNumber = lotNumberGenerator(
        manufacturingOrderId.toString(),
      );
    });

    return await queryRunner.manager.save(moPlanBomEntities);
  }

  /**
   *
   * @param queryRunner
   * @param moPlanBoms
   * @param toCreateWorkOrders
   * @param moPlanId
   * @param moPlanCode
   * @param manufacturingOrderId
   * @param boms
   * @returns
   */
  private async createMoPlanWorkOrders(
    queryRunner: QueryRunner,
    moPlanBoms: MoPlanBomEntity[],
    bomVersionProducingStepWorkLoads: any[],
    toCreateWorkOrders,
    moPlanId: number,
    moPlanCode: string,
    manufacturingOrderId: number,
    boms: any,
  ): Promise<
    { workOrders: WorkOrderEntity[]; toCreateMoWorkOrderSchedules: any } | any
  > {
    const workOrderEntities = [];
    const toCreateMoWorkOrderSchedules = {};
    moPlanBoms.forEach((moPlanBom) => {
      const toCreateMoPlanWorkOrderKey = `${moPlanBom.itemId}_${
        moPlanBom.bomVersionId
      }_${moPlanBom.bomId}_${moPlanBom.parentBomId || ''}_${
        moPlanBom.parentBomVersionId || ''
      }`;
      const toCreateMoPlanWorkOrders =
        toCreateWorkOrders[toCreateMoPlanWorkOrderKey];

      // Map Work Orders
      toCreateMoPlanWorkOrders?.forEach((toUpdateWorkOrder) => {
        const { workOrder, workOrderSchedule, workCenterDailySchedules } =
          toUpdateWorkOrder;

        workOrder.status = WorkOrderStatusEnum.CONFIRMED;

        workOrder.moId = manufacturingOrderId;
        workOrder.routingId = boms[workOrder.bomId]?.routingId;

        workOrder.name = `${moPlanCode}_${workOrder.bomId}_${
          workOrder.routingId
        }_${randomBytes(3).toString('hex')}`;
        workOrder.moDetailId = moPlanBom.moDetailId;
        workOrder.moPlanId = moPlanId;
        workOrder.moPlanBomId = moPlanBom.id;
        workOrder.lotNumber = moPlanBom.lotNumber;

        const bomUserProducingWorkLoad = find(
          bomVersionProducingStepWorkLoads,
          (bomVersionProducingStepWorkLoad) =>
            bomVersionProducingStepWorkLoad.bomVersionId ==
              workOrder.bomVersionId &&
            bomVersionProducingStepWorkLoad.producingStepId ==
              workOrder.producingStepId,
        );

        if (bomUserProducingWorkLoad) {
          workOrder.workerWorkload = div(
            mul(workOrder.quantity, bomUserProducingWorkLoad.quantity || 1),
            boms[workOrder.bomId]?.quantity || 1,
          );
        }

        workOrderEntities.push(workOrder);

        const toCreateMoWorkOrderScheduleKey = `${workOrder.bomId}_${
          workOrder.parentBomId || ''
        }_${workOrder.producingStepId}_${workOrder.moPlanBomId}`;

        toCreateMoWorkOrderSchedules[toCreateMoWorkOrderScheduleKey] = {
          workOrderSchedule,
          workCenterDailySchedules,
        };
      });
    });

    const workOrders = await queryRunner.manager.save(workOrderEntities);

    return {
      workOrders: workOrders,
      toCreateMoWorkOrderSchedules: toCreateMoWorkOrderSchedules,
    };
  }

  /**
   *
   * @param queryRunner
   * @param workOrders
   * @param toCreateMoWorkOrderSchedules
   * @returns
   */
  private async createMoPlanWorkOrderSchedules(
    queryRunner: QueryRunner,
    workOrders: WorkOrderEntity[],
    toCreateMoWorkOrderSchedules,
  ) {
    const workOrderScheduleEntities = [];
    const toCreateMoWorkCenterSchedules = {};
    workOrders.forEach((workOrder: WorkOrderEntity) => {
      const toCreateMoWorkOrderScheduleKey = `${workOrder.bomId}_${
        workOrder.parentBomId || ''
      }_${workOrder.producingStepId}_${workOrder.moPlanBomId}`;

      const toCreateMoWorkOrderSchedule =
        toCreateMoWorkOrderSchedules[toCreateMoWorkOrderScheduleKey];

      const { workOrderSchedule, workCenterDailySchedules } =
        toCreateMoWorkOrderSchedule;
      workOrderSchedule.status = WorkOrderScheduleStatusEnum.CONFIRMED;
      workOrderSchedule.workOrderId = workOrder.id;
      workOrderScheduleEntities.push(workOrderSchedule);
      toCreateMoWorkCenterSchedules[`${workOrder.id}`] = {
        workCenterDailySchedules,
      };
    });

    const workOrderSchedules = await queryRunner.manager.save(
      workOrderScheduleEntities,
    );

    return {
      workOrderSchedules: workOrderSchedules,
      toCreateMoWorkCenterSchedules: toCreateMoWorkCenterSchedules,
    };
  }

  /**
   *
   * @param queryRunner
   * @param workOrderSchedules
   * @param toCreateMoWorkCenterSchedules
   * @returns
   */
  private async createMoPlanWorkOrderScheduleDetails(
    queryRunner: QueryRunner,
    workOrderSchedules: WorkOrderScheduleEntity[],
    toCreateMoWorkCenterSchedules,
    currentWorkOrderScheduleDetails?: any[],
  ) {
    const workOrderScheduleDetailEntities = [];
    const toCreateMoWorkCenterDailySchedules = {};

    workOrderSchedules.forEach((workOrderSchedule) => {
      const toCreateMoWorkCenterSchedule =
        toCreateMoWorkCenterSchedules[workOrderSchedule.workOrderId];
      const { workCenterDailySchedules } = toCreateMoWorkCenterSchedule;

      const tmpWorkCenters = {};

      workCenterDailySchedules.forEach((workCenterDailySchedule) => {
        if (
          isEmpty(
            tmpWorkCenters[
              workCenterDailySchedule.workCenterSchedule.workCenterId
            ],
          )
        ) {
          tmpWorkCenters[
            workCenterDailySchedule.workCenterSchedule.workCenterId
          ] = {
            ...workCenterDailySchedule.workCenterSchedule,
          };
        } else {
          tmpWorkCenters[
            workCenterDailySchedule.workCenterSchedule.workCenterId
          ] = {
            ...workCenterDailySchedule.workCenterSchedule,
            quantity:
              tmpWorkCenters[
                workCenterDailySchedule.workCenterSchedule.workCenterId
              ].quantity + workCenterDailySchedule.workCenterSchedule.quantity,
          };
        }
        const toCreateMoWorkCenterDailyScheduleKey = `${workOrderSchedule.id}_${workCenterDailySchedule.workCenterSchedule.workCenterId}`;
        if (
          !toCreateMoWorkCenterDailySchedules[
            toCreateMoWorkCenterDailyScheduleKey
          ]
        ) {
          toCreateMoWorkCenterDailySchedules[
            toCreateMoWorkCenterDailyScheduleKey
          ] = [workCenterDailySchedule];
        } else {
          toCreateMoWorkCenterDailySchedules[
            toCreateMoWorkCenterDailyScheduleKey
          ].push(workCenterDailySchedule);
        }
      });

      Object.keys(tmpWorkCenters).forEach((key: any) => {
        const tmpWorkCenter = tmpWorkCenters[key];
        const currentWorkOrderScheduleDetailEntity = find(
          currentWorkOrderScheduleDetails,
          (currentWorkOrderScheduleDetail) =>
            currentWorkOrderScheduleDetail.workOrderScheduleId ===
              workOrderSchedule.id &&
            currentWorkOrderScheduleDetail.workCenterId ===
              tmpWorkCenter.workCenterId,
        );

        const workOrderScheduleDetailEntity =
          new WorkOrderScheduleDetailEntity();
        if (currentWorkOrderScheduleDetailEntity) {
          workOrderScheduleDetailEntity.id =
            currentWorkOrderScheduleDetailEntity.id;
        }
        workOrderScheduleDetailEntity.workOrderScheduleId =
          workOrderSchedule.id;
        workOrderScheduleDetailEntity.workCenterId = tmpWorkCenter.workCenterId;
        workOrderScheduleDetailEntity.quantity = tmpWorkCenter.quantity;
        workOrderScheduleDetailEntity.status =
          WorkOrderScheduleDetailStatusEnum.CONFIRMED;
        workOrderScheduleDetailEntities.push(workOrderScheduleDetailEntity);
      });
    });

    const workOrderScheduleDetails = await queryRunner.manager.save(
      workOrderScheduleDetailEntities,
    );

    const queryCreateMaterialDailySchedule = [];
    for (let i = 0; i < workOrderScheduleDetails.length; i++) {
      const workOrderScheduleDetail = workOrderScheduleDetails[i];
      queryCreateMaterialDailySchedule.push(
        await this.workOrderScheduleDetailRepository.syncToMaterialPlanSchedules(
          workOrderScheduleDetail.id,
        ),
      );
    }

    return {
      workOrderScheduleDetails: workOrderScheduleDetails,
      toCreateMoWorkCenterDailySchedules: toCreateMoWorkCenterDailySchedules,
      queryCreateMaterialDailySchedule: queryCreateMaterialDailySchedule,
    };
  }

  /**
   *
   * @param queryRunner
   * @param workOrderScheduleDetails
   * @param toCreateMoWorkCenterDailySchedules
   * @returns
   */
  private async createMoPlanWorkCenterDailySchedules(
    queryRunner: QueryRunner,
    workOrderScheduleDetails: WorkOrderScheduleDetailEntity[],
    toCreateMoWorkCenterDailySchedules,
  ) {
    const workCenterDailyScheduleEntities = [];
    const toCreateMoWorkCenterDailyScheduleDetails = {};
    workOrderScheduleDetails.forEach((workOrderScheduleDetail) => {
      const toCreateMoWorkCenterDailyScheduleKey = `${workOrderScheduleDetail.workOrderScheduleId}_${workOrderScheduleDetail.workCenterId}`;
      const toCreateMoWorkCenterDailySchedule =
        toCreateMoWorkCenterDailySchedules[
          toCreateMoWorkCenterDailyScheduleKey
        ];

      toCreateMoWorkCenterDailySchedule.forEach(
        (iToCreateMoWorkCenterDailySchedule) => {
          const { workCenterSchedule, workCenterDailyScheduleDetails } =
            iToCreateMoWorkCenterDailySchedule;
          workCenterSchedule.workOrderScheduleDetailId =
            workOrderScheduleDetail.id;
          workCenterDailyScheduleEntities.push(workCenterSchedule);

          const toCreateMoWorkCenterDailyScheduleDetailKey = `${workOrderScheduleDetail.id}_${workCenterSchedule.workCenterId}_${workCenterSchedule.executionDay}`;
          toCreateMoWorkCenterDailyScheduleDetails[
            toCreateMoWorkCenterDailyScheduleDetailKey
          ] = workCenterDailyScheduleDetails;
        },
      );
    });

    const workCenterDailySchedules = await queryRunner.manager.save(
      workCenterDailyScheduleEntities,
    );

    return {
      workCenterDailySchedules: workCenterDailySchedules,
      toCreateMoWorkCenterDailyScheduleDetails:
        toCreateMoWorkCenterDailyScheduleDetails,
    };
  }

  /**
   *
   * @param queryRunner
   * @param workCenterDailySchedules
   * @param toCreateMoWorkCenterDailyScheduleDetails
   * @returns
   */
  private async createMoPlanWorkCenterDailyScheduleDetails(
    queryRunner: QueryRunner,
    workCenterDailySchedules: WorkCenterDailyScheduleEntity[],
    toCreateMoWorkCenterDailyScheduleDetails,
  ) {
    const workCenterDailyScheduleDetailEntities = [];
    workCenterDailySchedules.forEach((workCenterDailySchedule) => {
      const toCreateMoWorkCenterDailyScheduleDetailKey = `${workCenterDailySchedule.workOrderScheduleDetailId}_${workCenterDailySchedule.workCenterId}_${workCenterDailySchedule.executionDay}`;
      const toCreateMoWorkCenterDailyScheduleDetail =
        toCreateMoWorkCenterDailyScheduleDetails[
          toCreateMoWorkCenterDailyScheduleDetailKey
        ];
      toCreateMoWorkCenterDailyScheduleDetail.forEach(
        (iToCreateMoWorkCenterDailyScheduleDetail) => {
          iToCreateMoWorkCenterDailyScheduleDetail.workCenterDailyScheduleId =
            workCenterDailySchedule.id;

          workCenterDailyScheduleDetailEntities.push(
            iToCreateMoWorkCenterDailyScheduleDetail,
          );
        },
      );
    });

    const workCenterDailyScheduleDetails = queryRunner.manager.save(
      workCenterDailyScheduleDetailEntities,
    );

    return workCenterDailyScheduleDetails;
  }

  /**
   *
   * @param request
   * @returns
   */
  public async getMoPreviousBomList(
    request: GetMoPreviousBomList,
  ): Promise<any> {
    const { keyword, filter, sort } = request;
    let filterItemIds = [];
    let itemCondition;
    const itemSort = [];
    // filter item by keyword
    if (keyword) {
      itemCondition =
        'LOWER(unaccent(name)) LIKE ' +
        `LOWER(unaccent('%${escapeCharForSearch(keyword)}%'))`;
    }

    // filter item by filter name and code
    if (!isEmpty(filter)) {
      const itemCodeFilter = filter.find((x) => x.column === 'itemCode');
      if (!isEmpty(itemCodeFilter)) {
        itemCondition = itemCondition
          ? itemCondition +
            ' AND ' +
            'LOWER(unaccent(code)) LIKE ' +
            `LOWER(unaccent('%${escapeCharForSearch(itemCodeFilter.text)}%'))`
          : 'LOWER(unaccent(code)) LIKE ' +
            `LOWER(unaccent('%${escapeCharForSearch(itemCodeFilter.text)}%'))`;
      }
      const itemNameFilter = filter.find((x) => x.column === 'itemName');
      if (!isEmpty(itemNameFilter)) {
        itemCondition = itemCondition
          ? itemCondition +
            ' AND ' +
            'LOWER(unaccent(name)) LIKE ' +
            `LOWER(unaccent('%${escapeCharForSearch(itemNameFilter.text)}%'))`
          : 'LOWER(unaccent(name)) LIKE ' +
            `LOWER(unaccent('%${escapeCharForSearch(itemNameFilter.text)}%'))`;
      }
    }

    // sort item by name

    if (!isEmpty(sort)) {
      const itemNameSort = sort.find((x) => x.column === 'itemName');
      if (!isEmpty(itemNameSort)) {
        itemSort.push(itemNameSort);
      }
    }

    if (itemCondition) {
      itemCondition += `escape '\\'`;
    }

    const itemResponse = await this.itemService.getItemsByConditions(
      itemCondition,
      itemSort,
    );

    if (itemResponse.statusCode === 200) {
      filterItemIds = map(itemResponse.data, 'id');
    } else {
      return new ResponseBuilder({
        items: [],
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    }
    const { result, count } = await this.workOrderRepository.getPrevousBoms(
      request,
      filterItemIds,
    );

    if (!isEmpty(result)) {
      const itemIds = map(result, 'itemId');
      const items = await this.itemService.getItemsByIds(itemIds, true);
      result.forEach((d) => {
        d.item = items[d.itemId] || {};
      });

      // sort by filterItemIds
      if (!isEmpty(itemSort) && !isEmpty(filterItemIds)) {
        result.sort(function (a, b) {
          return (
            filterItemIds.indexOf(a.itemId) - filterItemIds.indexOf(b.itemId)
          );
        });
      }
    }

    const response = plainToInstance(MoPreviousBomListResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  async getStatisticProgressProductionManufacturingRequestOrder(
    request: GetStatisticProgressProductionRequestDto,
  ): Promise<any> {
    const { user, filter } = request;
    let result;
    const filterIsHasPlanFalse = filter?.find(
      (item) => item.column === 'isHasPlan' && item.text === 'false',
    );
    const filterManufacturingRequestOrderIds = filter?.find(
      (item) => item.column === 'manufacturingRequestOrderIds',
    );

    const filterManufacturingRequestOrderOrderedAt = filter?.find(
      (item) => item.column === 'orderedAt',
    );
    const filterManufacturingRequestOrderDeadline = filter?.find(
      (item) => item.column === 'deadline',
    );
    const filterMasterPlanIds = filter?.find(
      (item) => item.column === 'masterPlanIds',
    );
    const filterMpPlan = filter?.find((item) => item.column === 'planDate');
    const filterMasterPlanStatus = filter?.find(
      (item) => item.column === 'status',
    );

    let manufacturingRequestOrders;
    // isHasPlan false
    if (filterIsHasPlanFalse) {
      manufacturingRequestOrders =
        await this.requestService.getManufacturingRequestOrders({
          filter: [filterIsHasPlanFalse],
        });
      result = manufacturingRequestOrders.map((manufacturingRequestOrder) => {
        return {
          manufacturingRequestOrder: manufacturingRequestOrder,
        };
      });
      const response = plainToInstance(
        StatisticProgressProductionResponseDto,
        result,
        {
          excludeExtraneousValues: true,
        },
      );
      return new ResponseBuilder<PagingResponse>({
        items: response,
        meta: { total: 0, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    // isHasPlan true

    // filter lv1
    if (
      filterManufacturingRequestOrderOrderedAt ||
      filterManufacturingRequestOrderDeadline ||
      filterManufacturingRequestOrderIds
    ) {
      if (filterManufacturingRequestOrderIds)
        filterManufacturingRequestOrderIds.column = 'ids';
      manufacturingRequestOrders =
        await this.requestService.getManufacturingRequestOrders({
          filter: [
            filterManufacturingRequestOrderOrderedAt,
            filterManufacturingRequestOrderDeadline,
            filterManufacturingRequestOrderIds,
          ],
        });
      const { result, count } =
        await this.statisticProgressProductionManufacturingRequestOrder(
          request,
          manufacturingRequestOrders,
          [filterMasterPlanIds, filterMpPlan, filterMasterPlanStatus],
          null,
        );
      const response = plainToInstance(
        StatisticProgressProductionResponseDto,
        result,
        {
          excludeExtraneousValues: true,
        },
      );

      return new ResponseBuilder<PagingResponse>({
        items: response,
        meta: { total: count, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    // no lv1 -> filter lv2
    if (filterMasterPlanIds || filterMpPlan || filterMasterPlanStatus) {
      const masterPlans = await this.masterPlanService.getMasterPlans({
        filter: [filterMasterPlanIds, filterMpPlan, filterMasterPlanStatus],
      });
      if (isEmpty(masterPlans)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
      }

      const { result, count } =
        await this.statisticProgressProductionManufacturingRequestOrder(
          request,
          null,
          [filterMasterPlanIds, filterMpPlan, filterMasterPlanStatus],
          masterPlans,
        );
      const response = plainToInstance(
        StatisticProgressProductionResponseDto,
        result,
        {
          excludeExtraneousValues: true,
        },
      );

      return new ResponseBuilder<PagingResponse>({
        items: response,
        meta: { total: count, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    // no filter
    const masterPlanMap: any = new Map(); // key: saleOrderId, value: masterPlan
    const { data, count } =
      await this.manufacturingOrderRepository.getStatisticProgressProductionManufacturingRequestOrder(
        request,
      );
    const manufacturingRequestOrderIds = uniq(
      data.map((mo) => mo.manufacturingRequestOrderId),
    );
    manufacturingRequestOrders =
      await this.requestService.getManufacturingRequestOrderByIds(
        manufacturingRequestOrderIds,
      );
    const manufacturingRequestOrdersMap = keyBy(
      manufacturingRequestOrders,
      'id',
    );
    const filterMasterPlan: any[] = [];
    filterMasterPlan.push({
      column: 'soIds',
      text: manufacturingRequestOrderIds.join(),
    });
    const masterPlans = await this.masterPlanService.getMasterPlans({
      filter: filterMasterPlan,
    });
    for (let i = 0; i < masterPlans.length; i++) {
      const masterPlan = masterPlans[i];
      for (let j = 0; j < masterPlan.saleOrders.length; j++) {
        const saleOrder = masterPlan.saleOrders[j];
        masterPlanMap.set(saleOrder.id, masterPlan);
      }
    }
    result = data.map((mo) => {
      return {
        ...mo,
        manufacturingRequestOrder:
          manufacturingRequestOrdersMap[mo.manufacturingRequestOrderId],
        masterPlan: masterPlanMap.get(mo.manufacturingRequestOrderId),
      };
    });

    const response = plainToInstance(
      StatisticProgressProductionResponseDto,
      result,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @param saleOrders
   * @param filter
   * @param masterPlans
   * @returns
   */
  async statisticProgressProductionManufacturingRequestOrder(
    request: any,
    manufacturingRequestOrders: any,
    filter: any,
    masterPlans: any,
  ) {
    const masterPlanMap: any = new Map(); // key: saleOrderId, value: masterPlan
    let manufacturingRequestOrdersMap;
    let manufacturingRequestOrderIds: any[] = [];

    if (manufacturingRequestOrders && !masterPlans) {
      manufacturingRequestOrderIds = uniq(
        manufacturingRequestOrders.map((so) => so.id),
      );
      manufacturingRequestOrdersMap = keyBy(manufacturingRequestOrders, 'id');
      const filterMasterPlan: any[] = [];
      filterMasterPlan.push({
        column: 'soIds',
        text: manufacturingRequestOrderIds.join(),
      });
      filterMasterPlan.concat(filter);
      masterPlans = await this.masterPlanService.getMasterPlans({
        filter: filterMasterPlan,
      });
    }

    if (!manufacturingRequestOrders && masterPlans) {
      for (let i = 0; i < masterPlans.length; i++) {
        const masterPlan = masterPlans[i];
        for (let j = 0; j < masterPlan.saleOrders.length; j++) {
          const saleOrder = masterPlan.saleOrders[j];
          if (!manufacturingRequestOrderIds.includes(saleOrder.id))
            manufacturingRequestOrderIds.push(saleOrder.id);
          masterPlanMap.set(saleOrder.id, masterPlan);
        }
      }
      const manufacturingRequestOrders =
        await this.requestService.getManufacturingRequestOrderByIds(
          manufacturingRequestOrderIds,
        );
      manufacturingRequestOrdersMap = keyBy(manufacturingRequestOrders, 'id');
    }

    for (let i = 0; i < masterPlans.length; i++) {
      const masterPlan = masterPlans[i];
      for (let j = 0; j < masterPlan.saleOrders.length; j++) {
        const saleOrder = masterPlan.saleOrders[j];
        masterPlanMap.set(saleOrder.id, masterPlan);
      }
    }

    const requestMo = new GetStatisticProgressProductionRequestDto();
    requestMo.filter = [];
    requestMo.filter.push({
      column: 'soIds',
      text: manufacturingRequestOrderIds.join(),
    });
    const { data, count } =
      await this.manufacturingOrderRepository.getStatisticProgressProductionManufacturingRequestOrder(
        requestMo,
      );
    const result = data.map((mo) => {
      return {
        ...mo,
        manufacturingRequestOrder:
          manufacturingRequestOrdersMap[mo.manufacturingRequestOrderId],
        masterPlan: masterPlanMap.get(mo.manufacturingRequestOrderId),
      };
    });

    return { result, count };
  }

  /**
   *
   * @param request
   * @returns
   */
  async getStatisticProgressProductionWc(
    request: GetStatisticProgressProductionRequestDto,
  ): Promise<any> {
    const { filter } = request;
    let result;
    let manufacturingRequestOrderIds: any[] = [];
    const masterPlanMap: any = new Map(); // key: saleOrderId, value: masterPlan
    const filterMasterPlanIds = filter?.find(
      (item) => item.column === 'masterPlanIds',
    );
    const filterMpPlan = filter?.find((item) => item.column === 'planDate');
    if (filterMasterPlanIds || filterMpPlan) {
      const filterMP: any[] = [];
      filterMP.push(filterMasterPlanIds);
      filterMP.push(filterMpPlan);
      const masterPlans = await this.masterPlanService.getMasterPlans({
        filter: filterMP,
      });
      if (isEmpty(masterPlans)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
      }

      for (let i = 0; i < masterPlans.length; i++) {
        const masterPlan = masterPlans[i];
        for (let j = 0; j < masterPlan.saleOrders.length; j++) {
          const saleOrder = masterPlan.saleOrders[j];
          manufacturingRequestOrderIds.push(saleOrder.id);
          masterPlanMap.set(saleOrder.id, masterPlan);
        }
      }
      request.filter.push({
        column: 'manufacturingRequestOrderIds',
        text: manufacturingRequestOrderIds.join(','),
      });
      const { data, count } =
        await this.workOrderScheduleDetailRepository.getStatisticProgressProductionWc(
          request,
        );
      result = data.map((wosd) => {
        return {
          ...wosd,
          masterPlan: masterPlanMap.get(wosd.mo?.manufacturingRequestOrderId),
        };
      });

      const response = plainToInstance(
        StatisticProgressProductionWcResponseDto,
        result,
        {
          excludeExtraneousValues: true,
        },
      );
      return new ResponseBuilder<PagingResponse>({
        items: response,
        meta: { total: count, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const { data, count } =
      await this.workOrderScheduleDetailRepository.getStatisticProgressProductionWc(
        request,
      );
    manufacturingRequestOrderIds = uniq(
      data.map((wosd) => {
        return wosd.mo?.manufacturingRequestOrderId;
      }),
    );
    if (isEmpty(manufacturingRequestOrderIds)) {
      return new ResponseBuilder<PagingResponse>({
        items: [],
        meta: { total: 0, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    const filterMasterPlan: any[] = [];
    filterMasterPlan.push({
      column: 'soIds',
      text: manufacturingRequestOrderIds.join(),
    });
    filterMasterPlan.concat(filter);

    const masterPlans = await this.masterPlanService.getMasterPlans({
      filter: filterMasterPlan,
    });
    if (isEmpty(masterPlans)) {
      return new ResponseBuilder<PagingResponse>({
        items: [],
        meta: { total: 0, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    for (let i = 0; i < masterPlans.length; i++) {
      const masterPlan = masterPlans[i];
      for (let j = 0; j < masterPlan.saleOrders.length; j++) {
        const saleOrder = masterPlan.saleOrders[j];
        manufacturingRequestOrderIds.push(saleOrder.id);
        masterPlanMap.set(saleOrder.id, masterPlan);
      }
    }
    result = data.map((wosd) => {
      return {
        ...wosd,
        masterPlan: masterPlanMap.get(wosd.mo?.manufacturingRequestOrderId),
      };
    });
    const response = plainToInstance(
      StatisticProgressProductionWcResponseDto,
      result,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async masterPlanModeratedHandler(
    request: MasterPlanModeratedHanlderRequestDto,
  ): Promise<any> {
    const { masterPlanId } = request;

    const manufacturingOrders =
      await this.manufacturingOrderRepository.findWithRelations({
        where: {
          masterPlanId: masterPlanId,
        },
        relations: ['manufacturingOrderDetails', 'plan'],
      });

    if (isEmpty(manufacturingOrders)) return;

    for (let i = 0; i < manufacturingOrders.length; i++) {
      const manufacturingOrder = manufacturingOrders[i];
      await this.syncMoPlanWithModeratedMasterPlan(manufacturingOrder);
    }

    return;
  }

  private async syncMoPlanWithModeratedMasterPlan(
    manufacturingOrder: ManufacturingOrderEntity,
  ): Promise<any> {
    const {
      plan,
      masterPlanId,
      manufacturingRequestOrderId,
      manufacturingOrderDetails,
    } = manufacturingOrder;
    const itemIds = map(manufacturingOrderDetails, 'itemId');

    const masterPlan = await this.masterPlanService.getMasterPlanWithFlatItems({
      masterPlanId: masterPlanId,
      saleOrderId: manufacturingRequestOrderId,
      itemIds: itemIds.join(','),
    });

    if (isEmpty(masterPlan)) {
      return;
    }

    const items = [];
    const bomIds = [];
    const bomVersionIds = [];
    const moItems = {};
    const moPlanBomEntities = [];
    const toCreateWorkOrders = {};

    await this.generatePreMoPlanFromMasterPlan(
      masterPlan,
      items,
      moItems,
      itemIds,
      bomIds,
      bomVersionIds,
      toCreateWorkOrders,
      moPlanBomEntities,
    );

    const bomVersionProducingStepWorkLoads =
      await this.bomUserProducingStepDetailRepository.findWithRelations({
        where: {
          bomVersionId: In(bomVersionIds),
        },
      });

    const moPlan = await this.moPlanRepository.getRawDetail(plan.id);
    if (isEmpty(moPlan)) return;

    const boms = await this.bomRepository.findWithRelations({
      where: {
        id: In(bomIds),
      },
      relations: ['routing'],
    });
    const serializeBoms = keyBy(boms, 'id');

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      moPlanBomEntities.forEach((moPlanBomEntity: MoPlanBomEntity) => {
        const currentMoPlanBomEntity = find(
          moPlan.moPlanBoms,
          (mpb) =>
            mpb.masterPlanItemScheduleId ===
            moPlanBomEntity.masterPlanItemScheduleId,
        );

        if (currentMoPlanBomEntity) {
          moPlanBomEntity.id = currentMoPlanBomEntity.id;
          moPlanBomEntity.actualQuantity =
            currentMoPlanBomEntity.actualQuantity;
          moPlanBomEntity.confirmedQuantity =
            currentMoPlanBomEntity.confirmedQuantity;
          moPlanBomEntity.status = currentMoPlanBomEntity.status;
          moPlanBomEntity.lotNumber = currentMoPlanBomEntity.lotNumber;
        }
      });

      const currentWorkOrderEntities = flatMap(moPlan.moPlanBoms, 'workOrders');
      const currentWorkOrderScheduleDetails = flatMap(
        currentWorkOrderEntities,
        'workOrderScheduleDetails',
      );
      Object.keys(toCreateWorkOrders).forEach((key) => {
        toCreateWorkOrders[key].forEach((toCreateWorkOrder) => {
          const currentWorkOrderEntity = find(
            currentWorkOrderEntities,
            (wo) =>
              wo.masterPlanProducingStepScheduleId ===
              toCreateWorkOrder.workOrder.masterPlanProducingStepScheduleId,
          );

          if (currentWorkOrderEntity) {
            toCreateWorkOrder.workOrder.id = currentWorkOrderEntity.id;
            toCreateWorkOrder.workOrderSchedule.id =
              currentWorkOrderEntity.workOrderScheduleDetails[0].workOrderScheduleId;
            unset(toCreateWorkOrder.workOrder, 'actualQuantity');
            unset(toCreateWorkOrder.workOrder, 'confirmedQuantity');
            unset(toCreateWorkOrder.workOrder, 'qcPassQuantity');
            unset(toCreateWorkOrder.workOrder, 'qcRejectQuantity');
            unset(toCreateWorkOrder.workOrder, 'status');
            unset(toCreateWorkOrder.workOrder, 'errorQuantity');
            unset(toCreateWorkOrder.workOrder, 'scrapQuantity');
            unset(toCreateWorkOrder.workOrder, 'exportQuantity');
            unset(toCreateWorkOrder.workOrder, 'exportedQuantity');
            unset(toCreateWorkOrder.workOrder, 'repaireddQuantity');
            unset(toCreateWorkOrder.workOrder, 'lotNumber');
            unset(toCreateWorkOrder.workOrderSchedule, 'actualQuantity');
          }

          const currentWorkCenterDailySchedules = flatMap(
            currentWorkOrderEntity.workOrderScheduleDetails,
            'workCenterDailySchedules',
          );

          toCreateWorkOrder.workCenterDailySchedules.forEach(
            (workCenterDailySchedule) => {
              const currentWorkOrderDailyScheduleEntity = find(
                currentWorkCenterDailySchedules,
                (currentWorkCenterDailySchedule) =>
                  currentWorkCenterDailySchedule.masterPlanWorkCenterDailyScheduleId ===
                  workCenterDailySchedule.workCenterSchedule
                    .masterPlanWorkCenterDailyScheduleId,
              );
              if (currentWorkOrderDailyScheduleEntity) {
                workCenterDailySchedule.workCenterSchedule.id =
                  currentWorkOrderDailyScheduleEntity.id;
                unset(
                  workCenterDailySchedule.workCenterSchedule,
                  'actualQuantity',
                );
                workCenterDailySchedule.workCenterDailyScheduleDetails.forEach(
                  (workCenterDailyScheduleDetail) => {
                    const currentWorkCenterDailyScheduleDetailEntity = find(
                      currentWorkOrderDailyScheduleEntity.workCenterDailyScheduleDetails,
                      (workCenterDailyScheduleDetailEntity) =>
                        workCenterDailyScheduleDetailEntity.masterPlanWorkCenterDailyScheduleId ===
                        workCenterDailyScheduleDetail.masterPlanWorkCenterDailyScheduleId,
                    );

                    if (currentWorkCenterDailyScheduleDetailEntity) {
                      workCenterDailyScheduleDetail.id =
                        currentWorkCenterDailyScheduleDetailEntity.id;
                      unset(workCenterDailyScheduleDetail, 'lotNumber');
                    }
                  },
                );
              }
            },
          );
        });
      });

      const { moPlanBoms } = moPlan;
      const { workOrders, toCreateMoWorkOrderSchedules } =
        await this.createMoPlanWorkOrders(
          queryRunner,
          moPlanBoms,
          bomVersionProducingStepWorkLoads,
          toCreateWorkOrders,
          moPlan.id,
          moPlan.code,
          manufacturingOrder.id,
          serializeBoms,
        );

      const { workOrderSchedules, toCreateMoWorkCenterSchedules } =
        await this.createMoPlanWorkOrderSchedules(
          queryRunner,
          workOrders,
          toCreateMoWorkOrderSchedules,
        );

      const {
        workOrderScheduleDetails,
        toCreateMoWorkCenterDailySchedules,
        queryCreateMaterialDailySchedule,
      } = await this.createMoPlanWorkOrderScheduleDetails(
        queryRunner,
        workOrderSchedules,
        toCreateMoWorkCenterSchedules,
        currentWorkOrderScheduleDetails,
      );

      const {
        workCenterDailySchedules,
        toCreateMoWorkCenterDailyScheduleDetails,
      } = await this.createMoPlanWorkCenterDailySchedules(
        queryRunner,
        workOrderScheduleDetails,
        toCreateMoWorkCenterDailySchedules,
      );

      await this.createMoPlanWorkCenterDailyScheduleDetails(
        queryRunner,
        workCenterDailySchedules,
        toCreateMoWorkCenterDailyScheduleDetails,
      );

      // TODO: refactor sync material
      // await queryRunner.manager.query(
      //   queryCreateMaterialDailySchedule.join(';'),
      // );
      await queryRunner.commitTransaction();
      return true;
    } catch (e) {
      await queryRunner.rollbackTransaction();
      console.log({ e });

      return false;
    } finally {
      await queryRunner.release();
    }
  }

  public async getFactoryIdsByManufacturingRequestOrderIds(
    request: GetFactoryIdsByManufacturingRequestOrderIdsRequestDto,
  ): Promise<any> {
    const { manufacturingRequestOrderIds } = request;
    const moByManufacturingRequestOrderIds =
      await this.manufacturingOrderRepository.findByCondition({
        manufacturingRequestOrderId: In(manufacturingRequestOrderIds),
      });

    if (isEmpty(moByManufacturingRequestOrderIds)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.MANUFACTURING_ORDER_NOT_FOUND'),
      ).toResponse();
    }

    const factoryIds = moByManufacturingRequestOrderIds.map(
      (mo) => mo.factoryId,
    );

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(factoryIds)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async getMoGroupByManufacturingRequestOrder(
    request: GetMoGroupByManufacturingRequestOrderRequestDto,
  ) {
    const { data, count } =
      await this.manufacturingOrderRepository.getMoGroupByManufacturingRequestOrder(
        request,
      );

    return new ResponseBuilder<PagingResponse>({
      items: data,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async completeMoByCompletedManufacturingRequestOrderId(
    payload: ManufacturingRequestOrderIdParamRequestDto,
  ): Promise<any> {
    const { id } = payload;

    const manufacturingOrders =
      await this.manufacturingOrderRepository.findByCondition({
        manufacturingRequestOrderId: id,
      });

    if (manufacturingOrders.length > 0) {
      for (let manufacturingOrder of manufacturingOrders) {
        manufacturingOrder.completedAt = new Date();
        manufacturingOrder.status = ManufacturingOrderStatusEnum.COMPLETED;
      }
    }
    try {
      await this.manufacturingOrderRepository.create(manufacturingOrders);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getMoMaterials(payload: GetMoMaterialRequestDto): Promise<any> {
    const mo = await this.manufacturingOrderRepository.findOneWithRelations({
      where: {
        id: payload.moId,
      },
      relations: ['manufacturingOrderDetails'],
    });
    if (!mo) {
      return new ResponseBuilder([])
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const moDetail = first(mo.manufacturingOrderDetails);
    if (isEmpty(moDetail)) {
      return new ResponseBuilder([])
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    const materials =
      await this.bomProducingStepDetailsRepository.getBomProducingStepsByBomId(
        moDetail.bomId,
        moDetail.bomVersionId,
        payload.isHasBom,
      );

    if (isEmpty(materials)) {
      return new ResponseBuilder([])
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    const [serializedProd, serializedItem] = await Promise.all([
      this.productionOrderService.getProQuantityTotal(
        {
          moId: mo.id,
          type: ProductionOrderTypeEnum.Import,
        },
        true,
      ),
      this.itemService.getItemsByIds(uniq(map(materials, 'itemId')), true),
    ]);

    forEach(materials, (i) => {
      const bomRate = div(+i.quantity || 1, +i.bomQuantity || 1);

      const normQuantity = i.quantity
        ? mul(+moDetail.quantity || 1, bomRate)
        : 1;
      i.normQuantity = normQuantity;
    });

    const groupedMaterials = this.sumQuantity(materials, {
      keys: ['itemId'],
      quantityField: 'normQuantity',
    });

    const resData = plainToInstance(
      GetMoMaterialResponseDto,
      map(groupedMaterials, (i) => {
        return {
          ...i,
          item: serializedItem[i.itemId],
          proExportQuantity: serializedProd[i.itemId]?.quantity || 0,
        };
      }),
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(resData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private sumQuantity(
    objArr: any[],
    options: {
      keys: string[];
      quantityField: string;
    },
  ) {
    const { keys, quantityField: QuantityField } = options;
    return reduce(
      objArr,
      (result, i) => {
        const key = map(keys, (key) => {
          return i[key];
        }).join('-');

        const existing = find(result, (j) => {
          i['key'] = key;
          return j['key'] === i['key'];
        });

        if (isEmpty(existing)) {
          result.push({ ...i, key });
        } else {
          existing[QuantityField] = plus(
            i[QuantityField] | 0,
            existing[QuantityField] | 0,
          );
        }
        return result;
      },
      [],
    );
  }
}
