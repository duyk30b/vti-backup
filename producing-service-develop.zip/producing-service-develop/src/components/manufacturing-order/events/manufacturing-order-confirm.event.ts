import { ManufacturingOrderResponseAbstractDto } from '@components/manufacturing-order/dto/response/manufacturing-order.response.abstract.dto';

export class ManufacturingOrderConfirmedEvent {
  constructor({ mo, userId }) {
    this.mo = mo;
    this.userId = userId;
  }

  mo: ManufacturingOrderResponseAbstractDto;
  userId: number;
}
