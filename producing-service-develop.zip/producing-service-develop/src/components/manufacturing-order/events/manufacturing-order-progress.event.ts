import { ManufacturingOrderResponseAbstractDto } from '@components/manufacturing-order/dto/response/manufacturing-order.response.abstract.dto';
import { ManufacturingOrderEntity } from '@entities/manufacturing-order/manufacturing-orders.entity';
import { WorkOrderEntity } from '@entities/work-order/work-order.entity';
import { WorkCenterDailyScheduleEntity } from '@entities/work-center/work-center-daily-schedule.entity';
import { WorkCenterDailyScheduleShiftEntity } from '@entities/work-center/work-center-daily-schedule-shift.entity';
import { MoPlanBomEntity } from '@entities/manufacturing-order/mo-plan-boms.entity';

export class ManufacturingOrderProgressSetEvent {
  constructor({ mo, moPlanId }) {
    this.mo = mo;
    this.moPlanId = moPlanId;
  }

  mo: ManufacturingOrderResponseAbstractDto;
  moPlanId: number;
}

export class WorkOrderProgressUpdateEvent {
  constructor({
    mo,
    workOrder,
    workCenterDailySchedule,
    workCenterDailyScheduleShift,
    quantity,
  }) {
    this.mo = mo;
    this.quantity = quantity;
    this.workOrder = workOrder;
    this.workCenterDailySchedule = workCenterDailySchedule;
    this.workCenterDailyScheduleShift = workCenterDailyScheduleShift;
  }

  mo: ManufacturingOrderEntity;
  workOrder: WorkOrderEntity;
  quantity: number;
  workCenterDailySchedule: WorkCenterDailyScheduleEntity;
  workCenterDailyScheduleShift: WorkCenterDailyScheduleShiftEntity;
}

export class MoPlanBomProgressUpdateEvent {
  constructor({ moPlanBom, quantity }) {
    this.moPlanBom = moPlanBom;
    this.quantity = quantity;
  }

  moPlanBom: MoPlanBomEntity;
  quantity: number;
}
