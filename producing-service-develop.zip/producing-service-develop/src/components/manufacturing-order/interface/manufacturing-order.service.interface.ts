import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { CreateManufacturingOrderRequestDto } from '../dto/request/create-manufacturing-order-request.dto';
import { GetBomItemMoRoutingRequestDto } from '../dto/request/get-bom-item-mo-routing-request.dto';
import {
  GetItemMoDetailRequestDto,
  GetMoPlanBomDetailRequestDto,
} from '../dto/request/get-item-mo-detail-request.dto';
import { GetItemMoListRequestDto } from '../dto/request/get-item-mo-list-request.dto copy';
import { GetListManufacturingOrderRequestDto } from '../dto/request/get-list-manufacturing-order.request.dto';
import { GetMoDetailRequestDto } from '../dto/request/get-mo-detail.request.dto';
import { UpdateManufacturingOrderStatusRequestDto } from '../dto/request/update-manufacturing-order-status-request.dto';
import {
  UpdateManufacturingOrderByPlanRequestDto,
  UpdateManufacturingOrderRequestDto,
} from '../dto/request/update-manufacturing-order.request.dto';
import { ManufacturingOrderResponseDto } from '../dto/response/manufacturing-order.response.dto';
import { GetMaterialImportWorkCentersRequestDto } from '../dto/request/get-material-import-work-centers-request.dto';
import { CreateManufacturingOrderByPlanRequestDto } from '../dto/request/create-manufacturing-order-by-plan.request.dto';
import { InfoOeeRequestDto } from '../dto/request/info-oee.request.dto';
import { GetMoPreviousBomList } from '../dto/request/get-mo-previous-bom-list.request.dto';
import { GetStatisticProgressProductionRequestDto } from '../dto/request/get-statistic-progress-production.request.dto';
import { MasterPlanModeratedHanlderRequestDto } from '../dto/request/master-plan-moderated.request.dto';
import { GetFactoryIdsByManufacturingRequestOrderIdsRequestDto } from '../dto/request/get-factory-ids-by-sale-order-ids.request.dto';
import { GetMoGroupByManufacturingRequestOrderRequestDto } from '../dto/request/get-mo-group-by-manufacturing-request-order.request.dto';
import { ManufacturingRequestOrderIdParamRequestDto } from '@components/request/dto/request/manufacturing-request-order-id-param.request.dto';
import { GetMoMaterialRequestDto } from '../dto/request/get-mo-material.request.dto';

export interface ManufacturingOrderServiceInterface {
  create(payload: CreateManufacturingOrderRequestDto): Promise<any>;
  getMaterialImportWorkCenters(
    payload: GetMaterialImportWorkCentersRequestDto,
  ): Promise<any>;
  getExportWorkCenters(
    payload: GetMaterialImportWorkCentersRequestDto,
  ): Promise<any>;
  update(payload: UpdateManufacturingOrderRequestDto): Promise<any>;
  updateByPlan(payload: UpdateManufacturingOrderByPlanRequestDto): Promise<any>;
  detail(
    id: number,
  ): Promise<ResponsePayload<ManufacturingOrderResponseDto | any>>;
  getMoItemLots(id: number): Promise<ResponsePayload<any>>;
  delete(id: number): Promise<ResponsePayload<SuccessResponse | any>>;
  getList(payload: GetListManufacturingOrderRequestDto): Promise<any>;
  reject(payload: UpdateManufacturingOrderStatusRequestDto): Promise<any>;
  confirm(payload: UpdateManufacturingOrderStatusRequestDto): Promise<any>;
  complete(payload: UpdateManufacturingOrderStatusRequestDto): Promise<any>;
  getListMoByIds(ids: number[]): Promise<any>;

  getBomProducingStepStruct(moId: number): Promise<any>;
  getBomPriceStruct(request: any): Promise<any>;
  getAllItem(payload: GetMoDetailRequestDto): Promise<any>;
  getInProgressMoList(): Promise<any>;
  getItemMoDetail(payload: GetItemMoDetailRequestDto): Promise<any>;
  getMoPlanBomDetail(payload: GetMoPlanBomDetailRequestDto): Promise<any>;
  getBomItemMoRouting(payload: GetBomItemMoRoutingRequestDto): Promise<any>;
  getItemMoList(payload: GetItemMoListRequestDto): Promise<any>;
  getPlanItemMoList(payload: GetItemMoListRequestDto): Promise<any>;
  getPlanItemMoListV2(payload: GetItemMoListRequestDto): Promise<any>;
  getListMOByManufacturingRequestOrderId(id: string): Promise<any>;
  getMoSubListByMoId(id: number): Promise<any>;
  getListMOByManufacturingRequestOrderIds(
    manufacturingRequestOrderIds: string[],
  ): Promise<any>;
  getListMoByCodes(codes: string[]): Promise<ResponsePayload<any>>;
  createByPlan(request: CreateManufacturingOrderByPlanRequestDto): Promise<any>;
  getInfoOeeByMo(request: InfoOeeRequestDto): Promise<any>;
  getMoPreviousBomList(request: GetMoPreviousBomList): Promise<any>;
  getStatisticProgressProductionManufacturingRequestOrder(
    request: GetStatisticProgressProductionRequestDto,
  ): Promise<any>;
  getStatisticProgressProductionWc(
    request: GetStatisticProgressProductionRequestDto,
  ): Promise<any>;
  masterPlanModeratedHandler(
    request: MasterPlanModeratedHanlderRequestDto,
  ): Promise<any>;
  getFactoryIdsByManufacturingRequestOrderIds(
    request: GetFactoryIdsByManufacturingRequestOrderIdsRequestDto,
  ): Promise<any>;
  getMoGroupByManufacturingRequestOrder(
    request: GetMoGroupByManufacturingRequestOrderRequestDto,
  ): Promise<any>;
  completeMoByCompletedManufacturingRequestOrderId(
    payload: ManufacturingRequestOrderIdParamRequestDto,
  ): Promise<any>;
  getMoMaterials(payload: GetMoMaterialRequestDto): Promise<any>;
}
