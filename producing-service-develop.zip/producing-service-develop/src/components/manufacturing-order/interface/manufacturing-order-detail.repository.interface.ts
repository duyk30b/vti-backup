import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { ManufacturingOrderDetailEntity } from '@entities/manufacturing-order/manufacturing-order-details.entity';

export interface ManufacturingOrderDetailRepositoryInterface
  extends BaseInterfaceRepository<ManufacturingOrderDetailEntity> {
  createEntity(data: any): ManufacturingOrderDetailEntity;

  getAllBomAndRoutingVersionIdByMoId(moId: number): Promise<any[]>;
  getTotalInProgressFinishedItems(moIds?: number[]): Promise<any>;
  getItemList(moId: number): Promise<any[]>;
  getInProgressMoItem(
    moId: number,
    onlyInProgressItem?: boolean,
    groupByPlan?: boolean,
  ): Promise<any[]>;
  getItemListByItemIds(itemIds: number[], moId: number): Promise<any[]>;

  updatePlaningQuantity(moId: number, planStatus: number[]): Promise<any>;

  getAllByMoId(moId: number): Promise<any[]>;
  getMoItemLots(moId: number): Promise<any[]>;
  getMoSubListByMoId(moId: number): Promise<any>;
}
