import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { ManufacturingOrderEntity } from '@entities/manufacturing-order/manufacturing-orders.entity';
import { GetListManufacturingOrderRequestDto } from '../dto/request/get-list-manufacturing-order.request.dto';
import { GetStatisticProgressProductionRequestDto } from '../dto/request/get-statistic-progress-production.request.dto';
import { GetMoGroupByManufacturingRequestOrderRequestDto } from '../dto/request/get-mo-group-by-manufacturing-request-order.request.dto';

export interface ManufacturingOrderRepositoryInterface
  extends BaseInterfaceRepository<ManufacturingOrderEntity> {
  createEntity(data: any): ManufacturingOrderEntity;
  getDetail(id: number): Promise<any>;
  getList(
    request: GetListManufacturingOrderRequestDto,
    factoryIds?: number[],
    manufacturingRequestOrderIds?: string[],
    itemIds?: number[],
    moIds?: number[],
    workCenterId?: any,
    isWO?: any,
  ): Promise<any>;
  updateEntity(
    moEntity: ManufacturingOrderEntity,
    data: any,
  ): ManufacturingOrderEntity;
  getListMoByIds(ids: number[]): Promise<any>;

  getInProgressMoWithPlan(
    onlyRootItem: boolean,
    withWorkOrder?: boolean,
    moId?: number,
    itemId?: number,
    routingId?: number,
    producingStepId?: number,
  ): Promise<any>;
  getInProgressMoWithPlanByTime(
    createdFrom: Date,
    createdTo: Date,
  ): Promise<any>;
  getBomItemMoRouting(moId: number, itemId: number): Promise<any>;
  getBomProducingStepStruct(moId: number): Promise<any>;
  getPriceManufacture(request: any): Promise<any[]>;
  getTotalInProgressMos(): Promise<any>;
  countToDoMo(createdFrom: Date, createdTo: Date): Promise<any>;
  countCompletedMo(createdFrom: Date, createdTo: Date): Promise<any>;
  countLateMo(createdFrom: Date, createdTo: Date): Promise<any>;
  countInProgressMo(createdFrom?: Date, createdTo?: Date): Promise<any>;
  aggreateItemByMo(moId: number): Promise<any[]>;
  getListMOByManufacturingRequestOrderId(id: string): Promise<any>;
  getProductivityReport(request: any): Promise<any>;
  getProductivityAssessmentReport(request: any): Promise<any>;
  getMoDistinctManufacturingRequestOrderId(): Promise<any>;
  getListMOByManufacturingRequestOrderIds(
    manufacturingRequestOrderIds: string[],
  ): Promise<any>;
  getProduceProgressByMoId(
    moId: number,
    itemId?: number,
    producingStepId?: number,
    workCenterId?: number,
    defaultTimeZone?: any,
  ): Promise<any>;
  getBomOfMoActualQuantity(moId: number): Promise<any>;
  getInfoOeeByMo(request: any): Promise<any>;
  getStatisticProgressProductionManufacturingRequestOrder(
    request: GetStatisticProgressProductionRequestDto,
  ): Promise<any>;
  getMoGroupByManufacturingRequestOrder(
    request: GetMoGroupByManufacturingRequestOrderRequestDto,
  ): Promise<any>;
  getCount(): Promise<any>;
}
