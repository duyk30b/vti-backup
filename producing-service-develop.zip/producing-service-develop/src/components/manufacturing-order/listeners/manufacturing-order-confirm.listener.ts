import { Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { MasterPlanService } from '../../master-plan/master-plan.service';

@Injectable()
export class ManufacturingOrderConfirmedListener {
  constructor(protected readonly planService: MasterPlanService) {}

  @OnEvent('manufacturing-order.confirmed')
  public async confirmedListener(data) {
    const { mo, userId } = data;
    return await this.planService.manufacturingOrderConfirmedEvent({
      id: mo.masterPlanId,
      manufacturingRequestOrderId: mo.manufacturingRequestOrderId,
      dateFrom: mo.dateFrom,
      dateTo: mo.dateTo,
      items: mo.manufacturingOrderDetails.map((manufacturingOrderDetail) => ({
        id: manufacturingOrderDetail.itemId,
        quantity: manufacturingOrderDetail.quantity,
      })),
      userId: userId,
    });
  }
}
