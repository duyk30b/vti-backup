import { Inject, Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { ProductionOrderTypeEnum } from '@components/sale-order/sale-order.constant';
import { SaleCronService } from '@components/sale-order/sale-order-cron.service';
import { MoPlanBomRepositoryInteface } from '@components/plan/inteface/mo-plan-bom.repository.inteface';
import { In, IsNull } from 'typeorm';
import { map, keyBy } from 'lodash';
import { MasterPlanServiceInterface } from '@components/master-plan/interface/master-plan.service.interface';

@Injectable()
export class ManufacturingOrderProgressListener {
  constructor(
    @Inject('MoPlanBomRepositoryInterface')
    private readonly moPlanBomRepository: MoPlanBomRepositoryInteface,

    @Inject('MasterPlanServiceInterface')
    private readonly masterPlanService: MasterPlanServiceInterface,

    protected readonly saleService: SaleCronService,
  ) {}

  /**
   *
   * @param param0
   * @returns
   */
  @OnEvent('manufacturing-order.gen-pro')
  public async checkAndGenPro({ mo, moPlanId }) {
    if (!mo || !moPlanId) return;

    const rawFinishedProducts =
      await this.moPlanBomRepository.findWithRelations({
        where: {
          moPlanId: moPlanId,
          moId: mo.id,
          itemId: In(map(mo.manufacturingOrderDetails, 'itemId')),
          parentBomId: IsNull(),
        },
      });
    const finishedProducts = keyBy(rawFinishedProducts, 'itemId');
    const importProductItems = mo.manufacturingOrderDetails?.map((mod) => ({
      id: mod.itemId,
      quantity: Number(mod.quantity),
      qcCheck: false,
      lotNumber: finishedProducts[mod.itemId].lotNumber,
    }));

    const importProductPrORequest = {
      name: mo.name,
      code: mo.code + 'IMP',
      manufacturingOrderId: mo.id,
      createdByUserId: mo.createdByUserId,
      type: ProductionOrderTypeEnum.Import,
      description: '',
      deadline: mo.planTo,
      items: importProductItems,
    };

    await this.saleService.createProductionOrderDraft(importProductPrORequest);
    return;
  }

  /**
   *
   * @param param0
   */
  @OnEvent('manufacturing-order.work-order-actual-quantity-updated')
  public async workOrderProgressUpdatedHandler({
    workOrder,
    mo,
    workCenterDailySchedule,
    workCenterDailyScheduleShift,
    quantity,
  }) {
    if (mo.masterPlanId && workOrder.masterPlanProducingStepScheduleId) {
      await this.masterPlanService.updateItemProducingStepScheudleActualQuantity(
        mo.masterPlanId,
        workOrder.masterPlanProducingStepScheduleId,
        workCenterDailySchedule.masterPlanWorkCenterDailyScheduleId,
        workCenterDailyScheduleShift.masterPlanWorkCenterDailyScheduleShiftId,
        quantity,
      );
    }
  }

  @OnEvent('manufacturing-order.mo-plan-bom-actual-quantity-updated')
  public async moPlanBomProgressUpdatedHandler({ moPlanBom, quantity }) {
    if (moPlanBom.masterPlanItemScheduleId) {
      await this.masterPlanService.updateItemScheudleActualQuantity(
        moPlanBom.masterPlanItemScheduleId,
        quantity,
      );
    }
  }
}
