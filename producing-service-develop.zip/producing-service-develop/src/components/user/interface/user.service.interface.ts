import { UserResponseDto } from '../dto/response/user.response.dto';

export interface UserServiceInterface {
  getUsers(userIds: number[]): Promise<UserResponseDto[]>;
  getFactoriesByIds(ids: number[], serilize?: boolean): Promise<any>;
  getUserByIds(condition, serilize?: boolean): Promise<any>;
  getUsersByConditions(condition, serilize?: boolean): Promise<any>;
  getUsersByRelations(relation, serilize?: boolean): Promise<any>;
  getUsersByUsernameOrFullName(filterByUser, onlyId?): Promise<any>;
  getFactoriesByNameKeyword(
    filterByName,
    onlyId?: boolean,
    serilize?: boolean,
  ): Promise<any>;
  insertPermission(permissions): Promise<any>;
  deletePermissionNotActive(): Promise<any>;
  getUserById(id: number): Promise<any>;
}
