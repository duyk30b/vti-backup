export enum ProductionOrderTypeEnum {
  Import = 0,
  Export = 1,
}
