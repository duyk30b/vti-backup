import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ClientProxyFactory } from '@nestjs/microservices';
import { ConfigService } from '@config/config.service';
import { ProductionOrderService } from './production-order.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    'PRODUCTION_ORDER_SERVICE_CLIENT',
    {
      provide: 'ProductionOrderServiceInterface',
      useClass: ProductionOrderService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'PRODUCTION_ORDER_SERVICE_CLIENT',
      useFactory: (configService: ConfigService) => {
        const productionOrderServiceOptions = configService.get(
          'productionOrderService',
        );
        return ClientProxyFactory.create(productionOrderServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'ProductionOrderServiceInterface',
      useClass: ProductionOrderService,
    },
  ],
  controllers: [],
})
export class ProductionOrderModule {}
