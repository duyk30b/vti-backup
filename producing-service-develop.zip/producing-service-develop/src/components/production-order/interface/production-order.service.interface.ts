import { CreateProductionOrderFormData } from '../dto/request/create-production-order-draft-request.dto';

export interface ProductionOrderServiceInterface {
  createProductionOrderDraft(
    payload: CreateProductionOrderFormData,
  ): Promise<any>;
  getProQuantityTotal(
    payload: { moId: number; type: number },
    serialized?: boolean,
  ): Promise<any>;
}
