import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import { IsInt, IsNumber, IsOptional, ValidateNested } from 'class-validator';

export class ProductionOrderDetailRequestDto {
  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsInt()
  itemUnitId: number;

  @ApiProperty()
  @IsOptional()
  quantity: number;

  @ApiProperty()
  @IsOptional()
  bomQuantity: number;
}

export class ProductionOrderRequestDto {
  @ApiProperty()
  @IsOptional()
  isDraft: boolean;

  @ApiProperty()
  @IsNumber()
  type: number;

  @ApiProperty()
  @IsNumber()
  moId: number;

  @ApiProperty()
  @IsOptional()
  moCode: string;

  @ApiProperty()
  @IsOptional()
  warehouseId?: number; //kho nhap

  @ApiProperty()
  @IsOptional()
  createdByUserId: number;

  @ApiProperty()
  @IsOptional()
  requestDate: Date;

  @ApiProperty()
  @IsOptional()
  @Type(() => ProductionOrderDetailRequestDto)
  productionOrderDetails: ProductionOrderDetailRequestDto[];
}

export class CreateProductionOrderRequestDto extends ProductionOrderRequestDto {}

export class CreateProductionOrderFormData extends BaseDto {
  @ApiProperty()
  @Transform(({ value }) => JSON.parse(value), { toClassOnly: true })
  @Type(() => CreateProductionOrderRequestDto)
  @ValidateNested()
  data: CreateProductionOrderRequestDto;
}
