import { NATS_ITEM, NATS_PRODUCTION_ORDER } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { escapeCharForSearch } from '@utils/common';
import { isEmpty } from 'class-validator';
import { map, keyBy } from 'lodash';
import { ProductionOrderServiceInterface } from './interface/production-order.service.interface';

@Injectable()
export class ProductionOrderService implements ProductionOrderServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async createProductionOrderDraft(request: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCTION_ORDER}.create_production_order_draft`,
      request,
    );

    return response;
  }

  async getProQuantityTotal(
    request: {
      moId: number;
      type: number;
    },
    serialized?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCTION_ORDER}.get_pro_quantity_total`,
      request,
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return serialized ? {} : [];
    }

    return serialized ? keyBy(response.data, 'itemId') : response.data;
  }
}
