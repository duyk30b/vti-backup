import { ProducingStepRepositoryInterface } from '@components/producing-step/interface/producing-step.repository.interface';
import { Inject, Injectable, Logger } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ApiError } from '@utils/api.error';
import { ResponsePayload } from '@utils/response-payload';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { plainToInstance } from 'class-transformer';
import { ResponseBuilder } from '@utils/response-builder';
import { DataSource, ILike, In, Not } from 'typeorm';
import { flatMap, isEmpty, map, uniq, first } from 'lodash';
import { PagingResponse } from '@utils/paging.response';
import { SuccessResponse } from '@utils/success.response.dto';
import { RoutingEntity } from '@entities/routing/routing.entity';
import {
  RoutingStatusEnum,
  CAN_UPDATE_ROUTING_STATUS,
  CAN_DELETE_ROUTING_STATUS,
} from '@components/routing/routing.constant';
import { RoutingServiceInterface } from '@components/routing/interface/routing.service.interface';
import { RoutingRepositoryInterface } from '@components/routing/interface/routing.repository.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { CreateRoutingRequestDto } from '@components/routing/dto/request/create-routing.request.dto';
import { GetListRoutingRequestDto } from '@components/routing/dto/request/get-list-routing.request.dto';
import { UpdateRoutingRequestDto } from '@components/routing/dto/request/update-routing.request.dto';
import { SetStatusRequestDto } from '@components/routing/dto/request/set-status.request.dto';
import { GetListRoutingResponseDto } from '@components/routing/dto/response/get-list-routing.response.dto';
import { RoutingResponseDto } from '@components/routing/dto/response/routing.response.dto';
import { RoutingResponseAbstractDto } from '@components/routing/dto/response/routing.response.abstract.dto';
import { GetListRoutingVersionRequestDto } from '@components/routing/dto/request/get-list-routing-version.request.dto';
import { GetListRoutingVersionResponseDto } from '@components/routing/dto/response/get-list-routing-version.response.dto';
import { RoutingVersionResponseDto } from '@components/routing/dto/response/routing-version.response.dto';
import { RoutingProducingStepEntity } from '@entities/producing-step/routing-producing-step.entity';
import { log } from 'console';

@Injectable()
export class RoutingService implements RoutingServiceInterface {
  private readonly logger = new Logger(RoutingService.name);
  constructor(
    @Inject('RoutingRepositoryInterface')
    private readonly routingRepository: RoutingRepositoryInterface,

    @Inject('ProducingStepRepositoryInterface')
    private readonly producingStepRepository: ProducingStepRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async listByIds(payload: any): Promise<any> {
    const { ids } = payload;

    const result: any = await this.routingRepository.findWithRelations({
      where: {
        id: In(ids),
      },
      relations: ['routingProducingStep.producingStep'],
    });

    result.forEach((r) => {
      r.producingSteps = r.routingProducingStep?.map((rp) => rp?.producingStep);
    });

    const response = plainToInstance(RoutingResponseAbstractDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<any>(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async create(
    request: CreateRoutingRequestDto,
  ): Promise<ResponsePayload<RoutingResponseDto | any>> {
    const { code, name, producingSteps } = request;
    const checkExistCode = await this.checkUniqueRouting([
      { code: ILike(code) },
    ]);
    if (checkExistCode) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_ALREADY_EXISTS'))
        .build();
    }

    const checkExistName = await this.checkUniqueRouting([{ name: name }]);
    if (checkExistName) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NAME_ALREADY_EXISTS'))
        .build();
    }

    const producingStepIds = uniq(map(flatMap(producingSteps), 'id'));
    const producingStepData =
      await this.producingStepRepository.findWithRelations({
        where: {
          id: In(producingStepIds),
          status: 1,
        },
      });

    if (producingStepData.length !== producingStepIds.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.PRODUCING_STEP_NOT_FOUND'),
        )
        .build();
    }
    const queryRunner = this.connection.createQueryRunner();

    await queryRunner.startTransaction();
    try {
      const routingEntity = await this.routingRepository.createEntity(request);
      const routing = await queryRunner.manager.save(
        RoutingEntity,
        routingEntity,
      );
      const routingProducingStepData = producingSteps.map((item) => ({
        routingId: routing.id,
        producingStepId: item.id,
        stepNumber: item.stepNumber,
      }));
      await queryRunner.manager.save(
        'routing_producing_steps',
        routingProducingStepData,
      );
      await queryRunner.commitTransaction();
      const response = plainToInstance(RoutingResponseAbstractDto, routing, {
        excludeExtraneousValues: true,
      });
      response.producingSteps = producingSteps;
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate('message.defineRouting.createSuccess'),
        )
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_CREATE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }
  }

  public async update(
    request: UpdateRoutingRequestDto,
  ): Promise<ResponsePayload<RoutingResponseDto | any>> {
    const { name, code, id, description, producingSteps } = request;
    let routing = await this.routingRepository.findOneById(request.id);

    if (!routing) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ROUTING_NOT_FOUND'))
        .build();
    }

    if (!CAN_UPDATE_ROUTING_STATUS.includes(routing.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    }

    const checkExistCode = await this.checkUniqueRouting([
      { code: ILike(code), id: Not(id) },
    ]);
    if (checkExistCode) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_ALREADY_EXISTS'))
        .build();
    }

    const checkExistName = await this.checkUniqueRouting([
      { name: name, id: Not(id) },
    ]);
    if (checkExistName) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NAME_ALREADY_EXISTS'))
        .build();
    }

    const producingStepIds = uniq(map(flatMap(producingSteps), 'id'));
    const producingStepData =
      await this.producingStepRepository.findWithRelations({
        where: {
          id: In(producingStepIds),
          status: 1,
        },
      });

    if (producingStepData.length !== producingStepIds.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.PRODUCING_STEP_NOT_FOUND'),
        )
        .build();
    }
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      routing.code = code;
      routing.name = name;
      routing.description = description;
      routing = await queryRunner.manager.save(RoutingEntity, routing);
      const routingProducingStepData = producingSteps.map((item) => ({
        routingId: routing.id,
        producingStepId: item.id,
        stepNumber: item.stepNumber,
      }));
      await queryRunner.manager.delete('routing_producing_steps', {
        routingId: routing.id,
      });
      await queryRunner.manager.save(
        'routing_producing_steps',
        routingProducingStepData,
      );
      await queryRunner.commitTransaction();
      const response = plainToInstance(RoutingResponseAbstractDto, routing, {
        excludeExtraneousValues: true,
      });
      response.producingSteps = producingSteps;
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate('message.defineRouting.updateSuccess'),
        )
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_CREATE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }
  }

  public async detail(
    id: number,
  ): Promise<ResponsePayload<RoutingResponseDto | any>> {
    const routing = await this.routingRepository.getDetail(id);
    if (!routing) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ROUTING_NOT_FOUND'))
        .build();
    }
    const result = {
      ...routing,
    };
    try {
      routing.approver = {};
      const userIds = [];
      if (routing.approverId !== null) {
        userIds.push(routing.approverId);
      }
      if (routing.createdBy) {
        userIds.push(routing.createdBy);
      }
      if (!isEmpty(userIds.filter)) {
        const users = this.userService.getUserByIds(userIds, true);
        routing.approver = users[routing.approverId];
        routing.createdBy = users[routing.createdBy];
      }

      const producingStepData =
        await this.producingStepRepository.getProducingStepsByRoutingId(
          routing.id,
        );
      result.producingSteps = producingStepData;
    } catch (error) {
      this.logger.error('detail ERROR: ', error);
    }

    const response = plainToInstance(RoutingResponseAbstractDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async delete(
    id: number,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const routing = await this.routingRepository.findOneById(id);

    if (!routing) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.ROUTING_NOT_FOUND'))
        .build();
    }

    if (!CAN_DELETE_ROUTING_STATUS.includes(routing.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_DELETE'),
      ).toResponse();
    }
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.delete(RoutingProducingStepEntity, {
        routingId: routing.id,
      });
      await queryRunner.manager.delete(RoutingEntity, { id: routing.id });
      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withMessage(
          await this.i18n.translate('message.defineRouting.deleteSuccess'),
        )
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_DELETE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }
  }

  public async getList(
    request: GetListRoutingRequestDto,
  ): Promise<ResponsePayload<GetListRoutingResponseDto | any>> {
    const { result, count } = await this.routingRepository.getList(request);

    const userIds = uniq(map(flatMap(result), 'approverId'));

    const users = await this.userService.getUserByIds(userIds, true);

    const data = result.map((routing) => ({
      ...routing,
      approver: !isEmpty(users[routing.approverId])
        ? users[routing.approverId]
        : {},
    }));

    const response = plainToInstance(RoutingResponseAbstractDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<RoutingResponseDto | any>> {
    const { userId, id } = request;
    const routing = await this.routingRepository.findOneById(id);

    if (!routing) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ROUTING_NOT_FOUND'))
        .build();
    }
    routing.approverId = userId;
    routing.approvedAt = new Date(Date.now());
    routing.status = RoutingStatusEnum.CONFIRMED;
    const result = await this.save(routing);
    const response = plainToInstance(RoutingResponseAbstractDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(
        await this.i18n.translate('message.defineRouting.confirmedRouting'),
      )
      .build();
  }

  public async reject(
    id: number,
  ): Promise<ResponsePayload<RoutingResponseDto | any>> {
    const routing = await this.routingRepository.findOneById(id);

    if (!routing) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ROUTING_NOT_FOUND'))
        .build();
    }
    routing.approverId = null;
    routing.approvedAt = null;
    routing.status = RoutingStatusEnum.CREATED;
    const result = await this.save(routing);
    const response = plainToInstance(RoutingResponseAbstractDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  private async save(routingEntity: RoutingEntity): Promise<any> {
    try {
      return await this.routingRepository.create(routingEntity);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  private async checkUniqueRouting(condition: any): Promise<boolean> {
    const result = await this.routingRepository.findByCondition(condition);
    return result.length > 0;
  }

  public async detailRoutingVersion(
    id: number,
  ): Promise<ResponsePayload<RoutingVersionResponseDto | any>> {
    return;
  }
  public async deleteRoutingVersion(
    id: number,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    return;
  }
  public async getListRoutingVersion(
    request: GetListRoutingVersionRequestDto,
  ): Promise<ResponsePayload<GetListRoutingVersionResponseDto | any>> {
    return;
  }

  public async confirmRoutingVersion(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<RoutingVersionResponseDto | any>> {
    return;
  }
  public async rejectRoutingVersion(
    id: number,
  ): Promise<ResponsePayload<RoutingVersionResponseDto | any>> {
    return;
  }
}
