import { ProducingStepEntity } from '@entities/producing-step/producing-step.entity';
import { ProducingStepRepository } from '@repositories/produce/producing-step.repository';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RoutingEntity } from '@entities/routing/routing.entity';
import { RoutingRepository } from '@repositories/routing.repository';
import { RoutingService } from '@components/routing/routing.service';
import { RoutingController } from '@components/routing/routing.controller';
import { UserService } from '@components/user/user.service';
import { UserModule } from '@components/user/user.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([RoutingEntity, ProducingStepEntity]),
    UserModule,
  ],
  providers: [
    {
      provide: 'RoutingRepositoryInterface',
      useClass: RoutingRepository,
    },
    {
      provide: 'ProducingStepRepositoryInterface',
      useClass: ProducingStepRepository,
    },
    {
      provide: 'RoutingServiceInterface',
      useClass: RoutingService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
  ],
  controllers: [RoutingController],
})
export class RoutingModule {}
