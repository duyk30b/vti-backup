import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { RoutingResponseAbstractDto } from '@components/routing/dto/response/routing.response.abstract.dto';
import { IsArray } from 'class-validator';

class Meta {
  @ApiProperty({ example: 1 })
  @Expose()
  total: number;

  @ApiProperty({ example: 1 })
  @Expose()
  page: number;
}
export class Data {
  @ApiProperty({ type: RoutingResponseAbstractDto, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => RoutingResponseAbstractDto)
  items: RoutingResponseAbstractDto[];

  @ApiProperty()
  @Expose()
  @Type(() => Meta)
  meta: Meta;
}

export class GetListRoutingResponseDto extends SuccessResponse {
  @ApiProperty({ type: Data })
  @Expose()
  @Type(() => Data)
  data: Data;
}
