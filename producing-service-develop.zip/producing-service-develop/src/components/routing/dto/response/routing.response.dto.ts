import { RoutingResponseAbstractDto } from '@components/routing/dto/response/routing.response.abstract.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

export class RoutingResponseDto extends SuccessResponse {
  @ApiProperty({ type: RoutingResponseAbstractDto })
  @Expose()
  @Type(() => RoutingResponseAbstractDto)
  data: RoutingResponseAbstractDto;
}
