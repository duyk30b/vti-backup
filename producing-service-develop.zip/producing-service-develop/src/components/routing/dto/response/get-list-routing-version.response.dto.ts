import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { RoutingVersionResponseAbstractDto } from '@components/routing/dto/response/routing-version.response.abstract.dto';
import { IsArray } from 'class-validator';

class Meta {
  @ApiProperty({ example: 1 })
  @Expose()
  total: number;

  @ApiProperty({ example: 1 })
  @Expose()
  page: number;
}
export class DataRoutingVersion {
  @ApiProperty({ type: RoutingVersionResponseAbstractDto, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => RoutingVersionResponseAbstractDto)
  items: RoutingVersionResponseAbstractDto[];

  @ApiProperty()
  @Expose()
  @Type(() => Meta)
  meta: Meta;
}

export class GetListRoutingVersionResponseDto extends SuccessResponse {
  @ApiProperty({ type: DataRoutingVersion })
  @Expose()
  @Type(() => DataRoutingVersion)
  data: DataRoutingVersion;
}
