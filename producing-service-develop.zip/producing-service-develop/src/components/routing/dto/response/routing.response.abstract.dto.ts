import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class ProducingSteps {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  stepNumber: number;

  @ApiProperty({ description: '' })
  @Expose()
  name?: string;

  @ApiProperty({ description: '' })
  @Expose()
  code?: string;
}

class UserResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'abc', description: '' })
  @Expose()
  username: string;

  @ApiProperty({ example: 'abc', description: '' })
  @Expose()
  fullName: string;
}

export class RoutingResponseAbstractDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'routing 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'R0001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  status: number;

  @ApiProperty({ example: 'description', description: '' })
  @Expose()
  description: string;

  @ApiProperty({ example: '1.0.0', description: '' })
  @Expose()
  latestVersion: string;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  approverId: number;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  approvedAt: Date;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  createdAt: Date;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: UserResponse })
  @Expose()
  @Type(() => UserResponse)
  approver: UserResponse;

  @ApiProperty({ type: UserResponse })
  @Expose()
  @Type(() => UserResponse)
  createdBy: UserResponse;

  @ApiProperty({
    type: ProducingSteps,
    isArray: true,
  })
  @Expose()
  @IsArray()
  @Type(() => ProducingSteps)
  producingSteps: ProducingSteps[];
}
