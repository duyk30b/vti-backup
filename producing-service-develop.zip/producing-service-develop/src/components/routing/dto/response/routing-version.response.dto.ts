import { RoutingVersionResponseAbstractDto } from '@components/routing/dto/response/routing-version.response.abstract.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

export class RoutingVersionResponseDto extends SuccessResponse {
  @ApiProperty({ type: RoutingVersionResponseAbstractDto })
  @Expose()
  @Type(() => RoutingVersionResponseAbstractDto)
  data: RoutingVersionResponseAbstractDto;
}
