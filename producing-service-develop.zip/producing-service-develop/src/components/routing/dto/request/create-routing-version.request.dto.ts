import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsNotEmpty, IsInt, IsArray, ArrayUnique } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';

class ProducingSteps {
  @ApiProperty({ example: 1, description: 'producing step id' })
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty({ example: 1, description: 'step number' })
  @IsInt()
  @IsNotEmpty()
  stepNumber: number;
}

export class CreateRoutingVersionRequestDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'routing id' })
  @IsNotEmpty()
  @IsInt()
  routingId: number;

  @ApiPropertyOptional({ type: [ProducingSteps] })
  @IsNotEmpty()
  @IsArray()
  @ArrayUnique<ProducingSteps>((e: ProducingSteps) => e.id)
  @Type(() => ProducingSteps)
  producingSteps: ProducingSteps[];
}
