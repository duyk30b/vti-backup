import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsString,
  MaxLength,
  IsOptional,
  IsArray,
  ArrayUnique,
  IsInt,
} from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { Type } from 'class-transformer';

class ProducingSteps {
  @ApiProperty({ example: 1, description: 'producing step id' })
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty({ example: 1, description: 'step number' })
  @IsInt()
  @IsNotEmpty()
  stepNumber: number;
}

export class CreateRoutingRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsString()
  @MaxLength(20)
  @ApiProperty({ example: 'R001', description: 'code' })
  code: string;

  @ApiProperty({ example: 'routing 1', description: 'name' })
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiProperty({ example: 'description', description: 'description' })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;

  @ApiPropertyOptional({ type: [ProducingSteps] })
  @IsNotEmpty()
  @IsArray()
  @ArrayUnique<ProducingSteps>((e: ProducingSteps) => e.id)
  @Type(() => ProducingSteps)
  producingSteps: ProducingSteps[];

  @ApiProperty({ example: 1, description: 'userId' })
  @IsNotEmpty()
  @IsInt()
  userId: number;
}
