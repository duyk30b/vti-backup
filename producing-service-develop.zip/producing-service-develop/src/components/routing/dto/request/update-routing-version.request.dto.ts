import { CreateRoutingVersionRequestDto } from '@components/routing/dto/request/create-routing-version.request.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class UpdateRoutingVersionRequestDto extends CreateRoutingVersionRequestDto {
  @ApiProperty({ example: 1, description: 'id' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
