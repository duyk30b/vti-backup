import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { RoutingEntity } from '@entities/routing/routing.entity';

export interface RoutingRepositoryInterface
  extends BaseInterfaceRepository<RoutingEntity> {
  createEntity(request: any): RoutingEntity;
  getList(request: any): Promise<any>;
  getDetail(id: number): Promise<any>;
  isLatestStepInRouting(
    routingId: number,
    producingStepId: number,
  ): Promise<boolean>;
  getAllVersionByIds(ids: number[]): Promise<any>;
  getCount(): Promise<any>;
}
