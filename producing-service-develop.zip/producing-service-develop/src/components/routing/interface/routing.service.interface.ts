import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { CreateRoutingRequestDto } from '@components/routing/dto/request/create-routing.request.dto';
import { GetListRoutingRequestDto } from '@components/routing/dto/request/get-list-routing.request.dto';
import { UpdateRoutingRequestDto } from '@components/routing/dto/request/update-routing.request.dto';
import { SetStatusRequestDto } from '@components/routing/dto/request/set-status.request.dto';
import { GetListRoutingResponseDto } from '@components/routing/dto/response/get-list-routing.response.dto';
import { RoutingResponseDto } from '@components/routing/dto/response/routing.response.dto';
import { CreateRoutingVersionRequestDto } from '@components/routing/dto/request/create-routing-version.request.dto';
import { GetListRoutingVersionRequestDto } from '@components/routing/dto/request/get-list-routing-version.request.dto';
import { UpdateRoutingVersionRequestDto } from '@components/routing/dto/request/update-routing-version.request.dto';
import { GetListRoutingVersionResponseDto } from '@components/routing/dto/response/get-list-routing-version.response.dto';
import { RoutingVersionResponseDto } from '@components/routing/dto/response/routing-version.response.dto';

export interface RoutingServiceInterface {
  listByIds(
    payload: any,
  ): ResponsePayload<any> | PromiseLike<ResponsePayload<any>>;
  create(
    request: CreateRoutingRequestDto,
  ): Promise<ResponsePayload<RoutingResponseDto | any>>;
  update(
    request: UpdateRoutingRequestDto,
  ): Promise<ResponsePayload<RoutingResponseDto | any>>;
  detail(id: number): Promise<ResponsePayload<RoutingResponseDto | any>>;
  delete(id: number): Promise<ResponsePayload<SuccessResponse | any>>;
  getList(
    request: GetListRoutingRequestDto,
  ): Promise<ResponsePayload<GetListRoutingResponseDto | any>>;
  confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<RoutingResponseDto | any>>;
  reject(id: number): Promise<ResponsePayload<RoutingResponseDto | any>>;
  detailRoutingVersion(
    id: number,
  ): Promise<ResponsePayload<RoutingVersionResponseDto | any>>;
  deleteRoutingVersion(
    id: number,
  ): Promise<ResponsePayload<SuccessResponse | any>>;
  getListRoutingVersion(
    request: GetListRoutingVersionRequestDto,
  ): Promise<ResponsePayload<GetListRoutingVersionResponseDto | any>>;
  confirmRoutingVersion(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<RoutingVersionResponseDto | any>>;
  rejectRoutingVersion(
    id: number,
  ): Promise<ResponsePayload<RoutingVersionResponseDto | any>>;
}
