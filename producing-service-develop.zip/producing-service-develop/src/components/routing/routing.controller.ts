import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { isEmpty } from 'lodash';
import { MessagePattern, Payload } from '@nestjs/microservices';
import { ResponsePayload } from '@utils/response-payload';
import { RoutingServiceInterface } from '@components/routing/interface/routing.service.interface';
import { CreateRoutingRequestDto } from '@components/routing/dto/request/create-routing.request.dto';
import { GetListRoutingRequestDto } from '@components/routing/dto/request/get-list-routing.request.dto';
import { UpdateRoutingRequestDto } from '@components/routing/dto/request/update-routing.request.dto';
import { SetStatusRequestDto } from '@components/routing/dto/request/set-status.request.dto';
import { GetListRoutingVersionRequestDto } from '@components/routing/dto/request/get-list-routing-version.request.dto';
import { GetListRoutingResponseDto } from '@components/routing/dto/response/get-list-routing.response.dto';
import { RoutingResponseDto } from '@components/routing/dto/response/routing.response.dto';
import { GetListRoutingVersionResponseDto } from '@components/routing/dto/response/get-list-routing-version.response.dto';
import { RoutingVersionResponseDto } from '@components/routing/dto/response/routing-version.response.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CREATE_ROUTING_PERMISSION,
  UPDATE_ROUTING_PERMISSION,
  DELETE_ROUTING_PERMISSION,
  DETAIL_ROUTING_PERMISSION,
  LIST_ROUTING_PERMISSION,
  CONFIRM_ROUTING_PERMISSION,
  REJECT_ROUTING_PERMISSION,
} from '@utils/permissions/routing';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { DEFAULT_TRANSPORT } from '@utils/constant';
import { NATS_PRODUCE } from '@config/nats.config';

@Controller('routings')
export class RoutingController {
  constructor(
    @Inject('RoutingServiceInterface')
    private readonly routingService: RoutingServiceInterface,
  ) {}

  @PermissionCode(CREATE_ROUTING_PERMISSION.code)
  @Post('/create')
  @ApiOperation({
    tags: ['Routing'],
    summary: 'Create Routing',
    description: 'Tạo mới quy trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: RoutingResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.routing_create`, DEFAULT_TRANSPORT)
  public async create(
    @Body() payload: CreateRoutingRequestDto,
  ): Promise<ResponsePayload<RoutingResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.routingService.create(request);
  }

  @PermissionCode(UPDATE_ROUTING_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Routing'],
    summary: 'Update Routing',
    description: 'Sửa thông tin quy trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: RoutingResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.routing_update`, DEFAULT_TRANSPORT)
  public async update(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateRoutingRequestDto,
  ): Promise<ResponsePayload<RoutingResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;
    return await this.routingService.update(request);
  }

  @PermissionCode(DETAIL_ROUTING_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Routing'],
    summary: 'Detail Routing',
    description: 'Chi tiết quy trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: RoutingResponseDto,
  })
  public async detail(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<RoutingResponseDto | any>> {
    return await this.routingService.detail(id);
  }

  @PermissionCode(DELETE_ROUTING_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Routing'],
    summary: 'Delete Routing',
    description: 'Xóa quy trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  @MessagePattern(`${NATS_PRODUCE}.routing_delete`, DEFAULT_TRANSPORT)
  public async delete(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    return await this.routingService.delete(id);
  }

  @PermissionCode(LIST_ROUTING_PERMISSION.code)
  @Get('/list')
  @ApiOperation({
    tags: ['Routing'],
    summary: 'List Routing',
    description: 'Danh sách quy trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListRoutingResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.routing_list`, DEFAULT_TRANSPORT)
  public async getList(
    @Query() payload: GetListRoutingRequestDto,
  ): Promise<ResponsePayload<GetListRoutingResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.routingService.getList(request);
  }

  @PermissionCode(CONFIRM_ROUTING_PERMISSION.code)
  @Post('/:id/confirm')
  @ApiOperation({
    tags: ['Routing'],
    summary: 'Confirm Routing',
    description: 'Xác nhận quy trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: RoutingResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.confirm_routing`, DEFAULT_TRANSPORT)
  public async confirm(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<RoutingResponseDto | any>> {
    return await this.routingService.confirm({ id } as SetStatusRequestDto);
  }

  @PermissionCode(REJECT_ROUTING_PERMISSION.code)
  @Post('/:id/reject')
  @ApiOperation({
    tags: ['Routing'],
    summary: 'Reject Routing',
    description: 'Từ chối quy trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: RoutingResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.reject_routing`, DEFAULT_TRANSPORT)
  public async reject(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<RoutingResponseDto | any>> {
    return await this.routingService.reject(id);
  }

  @MessagePattern(`${NATS_PRODUCE}.routing_version_detail`, DEFAULT_TRANSPORT)
  public async detailRoutingVersion(
    id: number,
  ): Promise<ResponsePayload<RoutingVersionResponseDto | any>> {
    return await this.routingService.detailRoutingVersion(id);
  }

  @MessagePattern(`${NATS_PRODUCE}.routing_version_delete`, DEFAULT_TRANSPORT)
  public async deleteRoutingVersion(
    id: number,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    return await this.routingService.deleteRoutingVersion(id);
  }

  @MessagePattern(`${NATS_PRODUCE}.routing_version_list`, DEFAULT_TRANSPORT)
  public async getListRoutingVersion(
    @Body() payload: GetListRoutingVersionRequestDto,
  ): Promise<ResponsePayload<GetListRoutingVersionResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.routingService.getListRoutingVersion(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.confirm_routing_version`, DEFAULT_TRANSPORT)
  public async confirmRoutingVersion(
    @Body() payload: SetStatusRequestDto,
  ): Promise<ResponsePayload<RoutingVersionResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.routingService.confirmRoutingVersion(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.reject_routing_version`, DEFAULT_TRANSPORT)
  public async rejectRoutingVersion(
    id: number,
  ): Promise<ResponsePayload<RoutingVersionResponseDto | any>> {
    return await this.routingService.rejectRoutingVersion(id);
  }

  @MessagePattern(`${NATS_PRODUCE}.routing_detail`, DEFAULT_TRANSPORT)
  public async detailTcp(
    @Body() payload: any,
  ): Promise<ResponsePayload<RoutingResponseDto | any>> {
    console.log({ payload });

    return await this.routingService.detail(payload.id);
  }

  @MessagePattern(`${NATS_PRODUCE}.list_routing_by_ids`, DEFAULT_TRANSPORT)
  public async listRoutingByIdsTcp(
    @Body() payload: any,
  ): Promise<ResponsePayload<RoutingResponseDto | any>> {
    return await this.routingService.listByIds(payload);
  }
}
