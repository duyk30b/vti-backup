export enum RoutingStatusEnum {
  CREATED = 0,
  CONFIRMED = 1,
}

export const CAN_UPDATE_ROUTING_STATUS: number[] = [RoutingStatusEnum.CREATED];

export const CAN_DELETE_ROUTING_STATUS: number[] = [RoutingStatusEnum.CREATED];
