import { NATS_DEVICE } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { keyBy } from 'lodash';
import { DeviceServiceInterface } from './interface/device.service.interface';

@Injectable()
export class DeviceService implements DeviceServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async getDeviceProfiles(ids: number[]) {
    const response = await this.natsClientService.send(
      `${NATS_DEVICE}.get_device_profile_by_ids`,
      { ids },
    );

    if (response.statusCode == ResponseCodeEnum.SUCCESS) {
      return keyBy(response.data, 'id');
    }

    return {};
  }

  async getDeviceProfile(data: any) {
    const response = await this.natsClientService.send(
      `${NATS_DEVICE}.get_device_profile`,
      data,
    );

    if (response.statusCode == ResponseCodeEnum.SUCCESS) {
      return response.data;
    }

    return {};
  }

  public async registerIotDevice(data: any) {
    return this.natsClientService.send(`${NATS_DEVICE}.register_device`, data);
  }
}
