import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ClientProxyFactory } from '@nestjs/microservices';
import { DeviceService } from './device.service';
import { ConfigService } from '@config/config.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    'DEVICE_SERVICE_CLIENT',
    {
      provide: 'DeviceServiceInterface',
      useClass: DeviceService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'DEVICE_SERVICE_CLIENT',
      useFactory: (configService: ConfigService) => {
        const deviceServiceOptions = configService.get('deviceService');
        return ClientProxyFactory.create(deviceServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'DeviceServiceInterface',
      useClass: DeviceService,
    },
  ],
  controllers: [],
})
export class DeviceModule {}
