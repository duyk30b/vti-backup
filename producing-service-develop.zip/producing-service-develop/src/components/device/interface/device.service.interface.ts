export interface DeviceServiceInterface {
  registerIotDevice(data: any);
  getDeviceProfile(data: any);
  getDeviceProfiles(ids: number[]);
}
