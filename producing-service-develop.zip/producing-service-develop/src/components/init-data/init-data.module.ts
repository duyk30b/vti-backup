import { Module } from '@nestjs/common';
import { InitDataRepository } from '@repositories/init-data/init-data.repository';
import { InitDataController } from './init-data.controller';
import { InitDataService } from './init-data.service';

@Module({
  imports: [],
  providers: [
    {
      provide: 'InitDataServiceInterface',
      useClass: InitDataService,
    },
    {
      provide: 'InitDataRepositoryInterface',
      useClass: InitDataRepository,
    },
  ],
  exports: [
    {
      provide: 'InitDataServiceInterface',
      useClass: InitDataService,
    },
    {
      provide: 'InitDataRepositoryInterface',
      useClass: InitDataRepository,
    },
  ],
  controllers: [InitDataController],
})
export class InitDataModule {}
