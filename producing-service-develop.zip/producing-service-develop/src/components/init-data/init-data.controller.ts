import { Controller, Inject } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { InitDataServiceInterface } from './interface/init-data.service.interface';

@Controller('init-data')
export class InitDataController {
  constructor(
    @Inject('InitDataServiceInterface')
    private readonly initDataService: InitDataServiceInterface,
  ) {}

  // @MessagePattern('produce_service_insert_data')
  public async createSector(payload: any): Promise<any> {
    return await this.initDataService.insertData(payload);
  }
}
