import { BomMachineProducingStepDetailRepositoryInterface } from '@components/bom/interface/bom-machine-producing-step-details.repository.interface';
import { BomUserProducingStepDetailRepositoryInterface } from '@components/bom/interface/bom-user-producing-step-details.repository.interface';
import { BomVersionRepositoryInterface } from '@components/bom/interface/bom-version.repository.interface';
import { Inject, Injectable } from '@nestjs/common';
import { BomServiceInterface } from '@components/bom/interface/bom.service.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, ILike, In, Not } from 'typeorm';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { BomRepositoryInterface } from '@components/bom/interface/bom.repository.interface';
import { BomDetailRepositoryInterface } from '@components/bom/interface/bom-detail.repository.interface';
import { CreateBomFormDataDto } from '@components/bom/dto/request/create-bom.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { UpdateBomFormDataDto } from '@components/bom/dto/request/update-bom.request.dto';
import {
  BomProducingStepStatusEnum,
  BomStatusEnum,
  BOM_VERSION_CODE,
  STATUS_BOM_TO_REJECT_BOM_VERSION,
  STATUS_TO_CONFIRM_BOM_STATUS,
  STATUS_TO_DELETE_BOM_STATUS,
  STATUS_TO_REJECT_BOM_STATUS,
  STATUS_TO_UPDATE_BOM,
  TYPE_ITEM_NOT_CHECK_ITEM_VERSION,
  STATUS_TO_UPDATE_BOM_VERSION,
  ITEM_TYPE,
  STATUS_BOM_TO_CLONE_BOM_VERSION_STATUS,
} from '@components/bom/bom.constant';
import { BomEntity } from '@entities/bom/boms.entity';
import {
  camelCase,
  difference,
  flatMap,
  isEmpty,
  map,
  mapKeys,
  uniq,
  values,
  keyBy,
  filter,
  compact,
  first,
  last,
} from 'lodash';
import { convertArrayToObject, minus, mul, plus } from '@utils/common';
import { BomDetailEntity } from '@entities/bom/bom-details.entity';
import { DeleteBomRequestDto } from './dto/request/delete-bom.request.dto';
import { GetBomDetailRequestDto } from './dto/request/get-bom-detail.request.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { RoutingServiceInterface } from '@components/routing/interface/routing.service.interface';
import { GetBomListRequestDto } from './dto/request/get-bom-list.request.dto';
import { PagingResponse } from '@utils/paging.response';
import { UpdateBomStatusRequestDto } from './dto/request/update-bom-status-request.dto';
import {
  BomResponseDto,
  BomVersion,
} from '@components/bom/dto/response/bom.response.dto';
import { GetBomByItemIdRequestDto } from './dto/request/get-bom-by-item-id.request.dto';
import { RoutingStatusEnum } from '@components/routing/routing.constant';
import { GetBomStructRequestDto } from './dto/request/get-bom-struct.request.dto';
import { RoutingResponseAbstractDto } from '@components/routing/dto/response/routing.response.abstract.dto';
import {
  BomDetailDto,
  BomMaterialDetail,
  BomProducingStepStructResponseDto,
  ProducingStepData,
} from './dto/response/bom-producing-step.response.dto';
import { ProducingStepResponseDto } from '@components/producing-step/dto/response/producing-step.response.dto';
import { CreateBomProducingStepRequestDto } from './dto/request/create-bom-producing-step-detail.request.dto';
import { BomProducingStepDetailsRepositoryInterface } from './interface/bom-producing-step-details.repository.interface';
import { BomProducingStepDetailEntity } from '@entities/bom/bom-producing-steps.entity';
import { GetBomProducingStepListRequestDto } from './dto/request/get-bom-producing-step-list.request.dto';
import { ItemResponseDto } from '@components/item/dto/response/item.dto.response';
import { WorkCenterRepositoryInterface } from '@components/work-center/interface/work-center.repository.interface';
import { GetBomByItemIdsRequestDto } from './dto/request/get-bom-by-item-ids.request.dto';
import { GetBomTreeByItemIds } from './dto/request/get-bom-tree-by-item-ids.request.dto';
import { GetMaterialBomByIdsRequestDto } from './dto/request/get-material-bom-by-ids.request.dto';
import { plainToInstance } from 'class-transformer';
import { BomUserProducingStepDetailEntity } from '@entities/bom/bom-user-producing-step-details.entity';
import { BomMachineProducingStepDetailEntity } from '@entities/bom/bom-machine-producing-step-details.entity';
import { FileService } from '@components/file/file.service';
import {
  FileResource,
  MAX_SIZE_FILE_UPLOAD,
} from '@components/file/constant/file-upload.constant';
import { BomVersionEntity } from '@entities/bom/bom-versions.entity';
import { FileRepositoryInterface } from '@components/file/interface/file.repository.interface';
import { ConfirmRejectBomVersionRequestDto } from './dto/request/confirm-reject-bom-version.request.dto';
import { GetListBomVersionByBomVersionIdsRequestDto } from './dto/request/get-list-bom-version-by-bom-version-id.request.dto';
import { ProducingStepRepositoryInterface } from '@components/producing-step/interface/producing-step.repository.interface';
import { GetBomVersionByBomIdRequestDto } from './dto/request/get-list-bom-version-by-bom-id.request.dto';
import { File } from '@core/dto/request/file.request.dto';
import { GetBomDetailByItemIdsRequestDto } from './dto/request/get-bom-detail-by-item-ids.request.dto';
import { GetBomDetailByItemIdsResponseDto } from './dto/response/get-bom-detail-by-item-ids.response.ts.dto';
// import { NotificationEntityEnum } from '@components/notification/notification.constant';
import { BomEvent } from './events/bom.event';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { WorkCenterServiceInterface } from '@components/work-center/interface/work-center.service.interface';
import { GetBomVersionByItemIdsResponseDto } from './dto/response/get-bom-version-by-item_ids.response.dto';
import { GetBomVersionByItemIdsRequestDto } from './dto/request/get-bom-version-by-item-ids.request.dto';

@Injectable()
export class BomService implements BomServiceInterface {
  constructor(
    @Inject('BomRepositoryInterface')
    private readonly bomRepository: BomRepositoryInterface,

    @Inject('BomProducingStepDetailsRepositoryInterface')
    private readonly bomProducingStepDetailsRepository: BomProducingStepDetailsRepositoryInterface,

    @Inject('BomDetailRepositoryInterface')
    private readonly bomDetailRepository: BomDetailRepositoryInterface,

    @Inject('BomVersionRepositoryInterface')
    private readonly bomVersionRepository: BomVersionRepositoryInterface,

    @Inject('BomUserProducingStepDetailRepositoryInterface')
    private readonly bomUserProducingStepDetailRepository: BomUserProducingStepDetailRepositoryInterface,

    @Inject('BomMachineProducingStepDetailRepositoryInterface')
    private readonly bomMachineProducingStepDetailRepository: BomMachineProducingStepDetailRepositoryInterface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('RoutingServiceInterface')
    protected readonly routingService: RoutingServiceInterface,

    @Inject('WorkCenterRepositoryInterface')
    protected readonly workCenterRepository: WorkCenterRepositoryInterface,

    @Inject('WorkCenterServiceInterface')
    protected readonly workCenterService: WorkCenterServiceInterface,

    @Inject('FileRepositoryInterface')
    private readonly fileRepository: FileRepositoryInterface,

    @Inject('FileServiceInterface')
    private readonly fileService: FileService,

    @Inject('ProducingStepRepositoryInterface')
    private readonly producingStepRepository: ProducingStepRepositoryInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nRequestScopeService,

    private readonly eventEmitter: EventEmitter2,
  ) {}

  /**
   *
   * @param payload UpdateBomStatusRequestDto
   * @returns
   */
  public async confirm(payload: UpdateBomStatusRequestDto): Promise<any> {
    const { id, userId } = payload;

    const bom = await this.bomRepository.findOneById(id);
    if (!bom) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_CONFIRM_BOM_STATUS.includes(bom.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }

    const result = await this.updateBomStatus(
      bom,
      BomStatusEnum.CONFIRMED,
      userId,
    );

    const updateItemData = {
      id: result?.data?.itemId,
      isHasBom: '1',
      isConfirmedBom: '1',
    };
    await this.itemService.updateIsHasBomItem(updateItemData);

    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.CONFIRM_SUCCESSFULLY'))
      .build();
  }

  /**
   *
   * @param payload UpdateBomStatusRequestDto
   * @returns
   */
  public async reject(payload: UpdateBomStatusRequestDto): Promise<any> {
    const { id } = payload;

    const bom = await this.bomRepository.findOneById(id);
    if (!bom) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_REJECT_BOM_STATUS.includes(bom.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }

    const updatedBomData = await this.updateBomStatus(
      bom,
      BomStatusEnum.REJECTED,
    );

    if (updatedBomData.statusCode !== ResponseCodeEnum.SUCCESS) {
      return updatedBomData;
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.REJECT_SUCCESSFULLY'))
      .build();
  }

  async getList(payload: GetBomListRequestDto): Promise<any> {
    const { sort } = payload;
    const filterItemName = payload.filter?.find(
      (item) => item.column === 'itemName',
    );

    let filterItemIds = [];

    if (!isEmpty(filterItemName)) {
      filterItemIds = await this.itemService.getItemsByName(
        filterItemName,
        true,
      );

      if (isEmpty(filterItemIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: payload.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    if (
      payload?.filter?.find((f) => f.column === 'canCreateBomProducingStep')
    ) {
      payload.filter.push({
        column: 'status',
        text: BomStatusEnum.CONFIRMED.toString(),
      });
    }

    const { result, count } = await this.bomRepository.getList(
      payload,
      filterItemIds,
    );

    const itemIds = uniq(map(flatMap(result), 'itemId'));
    const items = await this.itemService.getItemsByIds(itemIds, true);

    let data = result.map((bom) => ({
      ...bom,
      item: items[bom.itemId],
      confirmedVersionQuantity: bom?.bomVersions.length,
    }));

    if (!isEmpty(sort)) {
      sort.forEach((i) => {
        const sort = i.order === 'ASC' ? 1 : -1;
        switch (i.column) {
          case 'itemName':
            data.sort((a, b) => {
              const itemNameA = a?.item?.name
                ? a?.item?.name.toLowerCase()
                : '';
              const itemNameB = b?.item?.name
                ? b?.item?.name.toLowerCase()
                : '';
              if (itemNameA > itemNameB) {
                return sort;
              }
              if (itemNameA < itemNameB) {
                return -sort;
              }
              return 0;
            });
            break;
          case 'itemCode':
            data.sort((a, b) => {
              const itemCodeA = a?.item?.code
                ? a?.item?.code.toLowerCase()
                : '';
              const itemCodeB = b?.item?.code
                ? b?.item?.code.toLowerCase()
                : '';
              if (itemCodeA > itemCodeB) {
                return sort;
              }
              if (itemCodeA < itemCodeB) {
                return -sort;
              }
              return 0;
            });
            break;
          default:
            break;
        }
      });
    }

    const resData = plainToInstance(BomResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: resData,
      meta: { total: count, page: payload.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Get bom detail
   */
  public async getDetail(payload: GetBomDetailRequestDto): Promise<any> {
    const { id, bomVersionId } = payload;
    let bomVersionLastest;
    if (!bomVersionId) {
      bomVersionLastest = await this.bomVersionRepository.findByCondition(
        {
          bomId: id,
        },
        {
          id: 'DESC',
        },
      );
    }

    const bomVersionIdTemp = isEmpty(bomVersionLastest)
      ? bomVersionId
      : bomVersionLastest[0].id;

    const bom = await this.bomRepository.getDetail(id, bomVersionIdTemp);

    if (!bom) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (bom.createdBy) {
      const responseUserService = await this.userService.getUserById(
        bom.createdBy,
      );
      bom.createdBy = responseUserService;
    }

    let itemIds = map(bom.bomDetails, 'itemId');
    const userIds = [bom.approverId];
    itemIds = uniq([...itemIds, , bom.itemId]);

    const { normalizeUsers, normalizeItems } = await this.getBomExtraInfo(
      itemIds,
      userIds,
    );
    const producingStepIds = map(
      bom.bomUserProducingStepDetails,
      'producingStepId',
    );
    const bomVersionIds = map(bom.bomUserProducingStepDetails, 'bomVersionId');

    const [producingSteps, bomVersions] = await Promise.all([
      this.producingStepRepository.findByCondition({
        id: In(producingStepIds),
      }),
      this.bomVersionRepository.findByCondition({
        id: In(bomVersionIds),
      }),
    ]);

    const producingStepMap = keyBy(producingSteps, 'id');
    const bomVersionMap = keyBy(bomVersions, 'id');

    bom.approver = normalizeUsers[bom.approverId];
    bom.item = normalizeItems[bom.itemId];

    bom.bomDetails = bom.bomDetails.map((bomDetail) => ({
      ...bomDetail,
      item: {
        ...normalizeItems[bomDetail.itemId],
        itemUnit: {
          id: normalizeItems[bomDetail.itemId]?.itemUnitId,
          code: normalizeItems[bomDetail.itemId]?.itemUnitName,
          name: normalizeItems[bomDetail.itemId]?.itemUnitCode,
        },
      },
    }));
    bom.bomProducingStepDetails = bom.bomProducingStepDetails.map((i) => ({
      ...i,
      item: normalizeItems[i.itemId],
      producingStep: producingStepMap[i.producingStepId],
      bomVersion: bomVersionMap[i.bomVersionId],
    }));
    bom.bomUserProducingStepDetails = bom.bomUserProducingStepDetails.map(
      (i) => ({
        ...i,
        producingStep: producingStepMap[i.producingStepId],
        bomVersion: bomVersionMap[i.bomVersionId],
      }),
    );
    bom.bomMachineProducingStepDetails = bom.bomMachineProducingStepDetails.map(
      (i) => ({
        ...i,
        producingStep: producingStepMap[i.producingStepId],
        bomVersion: bomVersionMap[i.bomVersionId],
      }),
    );

    // get file bom
    if (!isEmpty(bom?.files)) {
      const fileIds = bom.files.map((e) => e.fileId);
      const fileInfor = await this.fileService.getFilesByIds(fileIds);
      bom.files = fileInfor;
    }

    const dataReturn = plainToInstance(
      BomResponseDto,
      { ...bom, bomVersionId: bomVersionIdTemp },
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Get bom struct
   */
  public async getBomStruct(payload: GetBomStructRequestDto): Promise<any> {
    const { id, bomVersionId, quantity } = payload;
    const rootItemIds = payload.items ? payload.items.map((i) => i.itemId) : [];

    let bomVersionLastest;
    if (!bomVersionId) {
      bomVersionLastest = await this.bomVersionRepository.findByCondition(
        {
          bomId: id,
        },
        {
          id: 'DESC',
        },
      );
    }
    const bomVersionIdTemp = isEmpty(bomVersionLastest)
      ? bomVersionId
      : bomVersionLastest[0].id;

    const boms = await this.bomRepository.getBomStructure(
      id,
      rootItemIds,
      bomVersionIdTemp,
      quantity || 0,
    );

    const bom = await this.bomRepository.getDetail(id, bomVersionIdTemp);
    const bomMap = {};
    const allItemIds = [];
    let bomVersionIds = [];
    boms.forEach((e) => {
      allItemIds.push(e.itemId);
      allItemIds.push(...e.sub.map((s) => s.itemId));
      bomVersionIds.push(...e.sub.map((i) => i.bomDetailVersionId));
      bomMap[e.itemId] = e;
      bomMap[e.itemId].bom = JSON.parse(e.bom);
      bomMap[e.itemId].sub = bomMap[e.itemId].sub?.map((sub) => {
        return {
          ...sub,
          bomParentId: bomMap[e.itemId].bom?.bom?.id,
          bomQuantity: bomMap[e.itemId].bom?.bom?.quantity,
          bomParentItemId: bomMap[e.itemId].bom?.bom?.item_id,
        };
      });
      if (e.bom.bom.id == id) {
        rootItemIds.push(e.bom.bom['item_id']);
      }
    });

    bomVersionIds = compact(uniq(bomVersionIds));

    const [bomVersions, bomVersionByItemIds] = await Promise.all([
      this.bomVersionRepository.findByCondition({
        id: In([...bomVersionIds, bomVersionId]),
      }),
      this.bomVersionRepository.getBomVersionByItemIds(allItemIds),
    ]);
    const bomVersionMap = keyBy(bomVersions, 'id');
    const bomVersionByIdMap = keyBy(bomVersionByItemIds, 'itemId');

    const allItemMap = await this.itemService.getItemsByIds(allItemIds, true);
    const response = rootItemIds.map((itemId) => {
      const response = this.toBomResponseDto(
        itemId,
        allItemMap,
        bomMap,
        bom.quantity,
        bomVersionMap,
        bomVersionId,
        null,
        bomVersionByIdMap,
        bom,
        {},
        1,
      );
      return response;
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private toBomResponseDto(
    itemId: number,
    allItemMap: any,
    bomMap: any,
    quantity: number,
    bomVersionMap: any,
    bomVersionId: number,
    parentItemId,
    bomVersionByIdMap: any,
    rootBom: any,
    tempSub: any,
    level?: number,
  ) {
    let result = new BomResponseDto();
    if (bomMap[itemId]) {
      result = plainToInstance(
        BomResponseDto,
        mapKeys(bomMap[itemId].bom.bom, (v, k) => camelCase(k)),
        {
          excludeExtraneousValues: true,
        },
      );
      result.routing = plainToInstance(
        RoutingResponseAbstractDto,
        mapKeys(bomMap[itemId].bom.routing, (v, k) => camelCase(k)),
        {
          excludeExtraneousValues: true,
        },
      );
      if (bomVersionMap[bomVersionId]) {
        result.bomVersion = plainToInstance(
          BomVersion,
          bomVersionMap[bomVersionId],
          {
            excludeExtraneousValues: true,
          },
        );
      }
      if (bomVersionByIdMap[itemId]?.bomVersions) {
        result.bomVersions = plainToInstance(
          BomVersion,
          bomVersionByIdMap[itemId].bomVersions as any[],
          {
            excludeExtraneousValues: true,
          },
        );
      }
      result.subBoms = bomMap[itemId].sub.map((sub) => {
        const isRoot = +bomMap[itemId]?.bom?.bom?.id === +rootBom?.id;

        const rate = +sub.quantity / +sub.bomQuantity;

        sub.tempQuantity = !isRoot
          ? mul(tempSub?.tempQuantity, rate)
          : sub.quantity;

        return this.toBomResponseDto(
          sub.itemId,
          allItemMap,
          bomMap,
          isRoot ? sub.quantity : mul(tempSub?.tempQuantity, rate),
          bomVersionMap,
          sub.bomDetailVersionId,
          itemId,
          bomVersionByIdMap,
          rootBom,
          sub,
          level + 1,
        );
      });
    }
    result.quantity = quantity;
    result.level = level;
    result.item = { ...allItemMap[itemId], parentItemId: parentItemId };
    return result;
  }

  public async create(
    payload: CreateBomFormDataDto,
  ): Promise<ResponsePayload<any>> {
    const { data, userId } = payload;

    const checkedResult = await this.checkExistence({
      itemId: data.itemId,
      name: data.name,
      code: data.code,
      itemVersionId: data.itemVersionId,
    });
    if (checkedResult.statusCode !== ResponseCodeEnum.SUCCESS) {
      return checkedResult;
    }
    const { code, name, itemVersionId } = data;

    const bomVersionEntity = this.bomVersionRepository.createEntity({
      itemVersionId,
      userId,
      code: this.getCodeBom(code, BOM_VERSION_CODE.FIRST, 0),
    });

    const existParentBomItems =
      await this.bomDetailRepository.findWithRelations({
        where: {
          itemId: data.itemId,
        },
        relations: ['bom'],
      });

    const existParentItemIds = existParentBomItems?.map(
      (bomItem) => bomItem?.bom?.itemId,
    );

    const parentItemId = data.itemId;
    const childItemIds = map(data.bomItems, 'id');
    const isInvalidBomItem =
      !isEmpty(existParentItemIds) &&
      childItemIds.some((itemId) => existParentItemIds.includes(itemId));
    if (childItemIds.some((i) => i === parentItemId) || isInvalidBomItem) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.CHILD_BOM_ALREADY_HAVE_PARENT'),
        )
        .build();
    }

    const bomEntity = this.bomRepository.createEntity(data, userId);
    bomEntity.bomVersions = [bomVersionEntity];

    const bomItemsFilter = payload.data.bomItems?.filter(
      (bom) => bom.itemTypeCode === ITEM_TYPE.SEMI_PRODUCT,
    );

    const bomVersionStatusList = map(bomItemsFilter, 'bomVersionStatus');

    const createBom = await this.save(
      bomEntity,
      payload,
      'message.defineBOM.createSuccess',
    );
    return createBom;
  }

  public async update(
    payload: UpdateBomFormDataDto,
  ): Promise<ResponsePayload<any>> {
    const { data, userId } = payload;
    const { id, code, name, itemVersionId, bomVersionId } = data;

    const checkedResult = await this.checkExistence({ bomId: id });
    if (checkedResult.statusCode !== ResponseCodeEnum.SUCCESS) {
      return checkedResult;
    }

    const bom = await this.bomRepository.findOneById(id);
    if (!bom) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (bom.status === BomStatusEnum.REJECTED) {
      bom.status = BomStatusEnum.PENDING;
    }
    const bomItemId = bom.itemId;

    // check bom version create/update
    const bomVersion = await this.bomVersionRepository.findOneByCondition({
      id: bomVersionId,
    });

    if (isEmpty(bomVersion))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BOM_VERSION_NOT_FOUND'))
        .build();

    const bomVersions = await this.bomVersionRepository.findByCondition({
      bomId: id,
    });

    const existParentBomItems =
      await this.bomDetailRepository.findWithRelations({
        where: {
          itemId: data.itemId,
        },
        relations: ['bom'],
      });

    const existParentItemIds = existParentBomItems?.map(
      (bomItem) => bomItem?.bom?.itemId,
    );

    const parentItemId = data.itemId;
    const childItemIds = map(data.bomItems, 'id');
    const isInvalidBomItem =
      !isEmpty(existParentItemIds) &&
      childItemIds.some((itemId) => existParentItemIds.includes(itemId));
    if (childItemIds.some((i) => i === parentItemId) || isInvalidBomItem) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.CHILD_BOM_ALREADY_HAVE_PARENT'),
        )
        .build();
    }

    // check status bom version
    let bomVersionEntity: BomVersionEntity;
    if (STATUS_TO_UPDATE_BOM_VERSION.includes(bomVersion.status))
      bomVersionEntity = bomVersion;
    else
      bomVersionEntity = this.bomVersionRepository.createEntity({
        itemVersionId,
        userId,
        code: this.getCodeBom(code, BOM_VERSION_CODE.FIRST, bomVersions.length),
      });

    // check status bom
    let bomEntity: BomEntity;
    if (STATUS_TO_UPDATE_BOM.includes(bom.status))
      bomEntity = this.bomRepository.updateEntity(bom, data);
    else bomEntity = bom;

    bomEntity.bomVersions = [bomVersionEntity];

    const bomItemsFilter = payload.data.bomItems?.filter(
      (bom) => bom.itemTypeCode === ITEM_TYPE.SEMI_PRODUCT,
    );

    const bomVersionStatusList = map(bomItemsFilter, 'bomVersionStatus');

    const updatedBom = await this.save(
      bomEntity,
      payload,
      'message.defineBOM.updateSuccess',
    );

    if (bomItemId !== updatedBom.data?.itemId) {
      const updateItemData = {
        id: bomItemId,
        isHasBom: '0',
      };
      await this.itemService.updateIsHasBomItem(updateItemData);
    }

    return updatedBom;
  }

  public async delete(payload: DeleteBomRequestDto): Promise<any> {
    const { id } = payload;
    let response, message;
    let code = ResponseCodeEnum.SUCCESS;

    const bom = await this.bomRepository.findOneById(id);
    if (!bom) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_DELETE_BOM_STATUS.includes(bom.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.delete(BomEntity, {
        id: id,
      });
      await queryRunner.manager.delete(BomDetailEntity, {
        bomId: id,
      });
      await queryRunner.commitTransaction();
      const updateItemData = {
        id: bom.itemId,
        isHasBom: '0',
      };
      await this.itemService.updateIsHasBomItem(updateItemData);
    } catch (error) {
      await queryRunner.rollbackTransaction();
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      message = error;
    }

    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(code)
      .withData(response)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('message.defineBOM.deleteSuccess')
          : message,
      )
      .build();
  }

  private async save(
    bomEntity: BomEntity,
    payload: CreateBomFormDataDto | UpdateBomFormDataDto,
    responseMessage?: string,
  ): Promise<any> {
    const { data, files } = payload;
    const {
      bomItems,
      routingId,
      itemId,
      itemVersionId,
      bomVersionId,
      bomProducingStepDetails,
      userProducingSteps,
      machineProducingSteps,
    } = data;
    let response, message;
    let code = ResponseCodeEnum.SUCCESS;

    const routeStatus = await this.routingService.detail(routingId);

    if (
      routeStatus.statusCode === ResponseCodeEnum.SUCCESS &&
      routeStatus.data.status !== RoutingStatusEnum.CONFIRMED
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.ROUTING_NOT_CONFIRM'))
        .build();
    }
    const checkItem = await this.itemService.getItemsByIds([itemId]);

    const itemCode = checkItem[0]?.code;

    //if (!itemCode) {
    //  return new ResponseBuilder({
    //    invalidItems: itemCode,
    //  })
    //    .withCode(ResponseCodeEnum.NOT_FOUND)
    //    .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
    //    .build();
    //}
    bomEntity.itemCode = itemCode;

    if (!checkItem[0].isProductionObject) {
      return new ResponseBuilder({
        invalidItems: checkItem[0],
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.ITEM_IS_NOT_PRODUCTION_OBJECT'),
        )
        .build();
    }

    // Validate itemseteSuccess
    const itemIds = uniq(map(bomItems, 'id'));
    let itemVersionIds = uniq(map(bomItems, 'itemVersionId'));
    itemVersionIds.push(itemVersionId);
    itemVersionIds = compact(itemVersionIds);

    const [itemsExist, itemVersionExist] = await Promise.all([
      this.itemService.getItemsByIds(itemIds),
      this.itemService.getItemVersionByIds(itemVersionIds),
    ]);

    if (!itemsExist || itemIds.length !== itemsExist.length) {
      const itemIdsExist = itemsExist ? itemsExist.map((e) => e.itemId) : [];
      return new ResponseBuilder({
        invalidItems: bomItems.filter((e) => !itemIdsExist.includes(e.id)),
      })
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }

    const itemVersionMap = keyBy(itemVersionExist, 'itemId');
    //if (itemVersionExist?.length !== itemVersionIds?.length) {
    //  return new ResponseBuilder()
    //    .withCode(ResponseCodeEnum.NOT_FOUND)
    //    .withMessage(await this.i18n.translate('error.ITEM_VERSION_NOT_FOUND'))
    //    .build();
    //}

    //for (let i = 0; i < itemsExist.length; i++) {
    //  const item = itemsExist[i];
    //  if (
    //    !TYPE_ITEM_NOT_CHECK_ITEM_VERSION[item.itemType.code] &&
    //    !itemVersionMap[item.id]
    //  ) {
    //    return new ResponseBuilder()
    //      .withCode(ResponseCodeEnum.BAD_REQUEST)
    //      .withMessage(await this.i18n.translate('error.ITEM_VERSION_INVALID'))
    //      .build();
    //  }
    //}

    const bomVersionCondition = compact(
      bomItems.map((i) => {
        if (i.bomVersionId)
          return {
            id: i.bomVersionId,
            itemVersionId: i.itemVersionId,
          };
      }),
    );

    if (!isEmpty(bomVersionCondition)) {
      const bomVersions = await this.bomVersionRepository.findByCondition(
        bomVersionCondition,
      );

      if (bomVersions.length !== bomVersionCondition.length) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.ITEM_BOM_VERSION_NOT_FOUND'),
          )
          .build();
      }
    }

    // const isCycleValid = await this.bomCycleValid(
    //   bomEntity.itemId,
    //   bomItems.map((i) => i.id),
    // );
    // if (!isCycleValid) {
    //   return new ResponseBuilder()
    //     .withCode(ResponseCodeEnum.BAD_REQUEST)
    //     .withMessage(await this.i18n.translate('error.ITEM_INVALID'))
    //     .build();
    // }
    const childBoms = await this.bomRepository.getBomsByItemIds(itemIds);
    // const parentBomsExist = childBoms.filter(
    //   (e) => e.parentId !== null && e.parentId !== bomEntity.id,
    // );
    // if (parentBomsExist.length > 0) {
    //   const parentBomIdsExist = parentBomsExist.map((e) => e.id);
    //   return new ResponseBuilder({
    //     invalidBoms: childBoms.filter((e) => parentBomIdsExist.includes(e.id)),
    //   })
    //     .withCode(ResponseCodeEnum.BAD_REQUEST)
    //     .withMessage(
    //       await this.i18n.translate('error.CHILD_BOM_ALREADY_HAVE_PARENT'),
    //     )
    //     .build();
    // }

    //const childBomItemIds = childBoms.map((e) => e.itemId);
    const childBomItemIds = map(childBoms, 'itemId');
    const childBomItems = bomItems.filter((e) =>
      childBomItemIds.includes(e.id),
    );

    const bomDetailRaws = {};
    bomItems.forEach((item) => {
      if (bomDetailRaws[item.id]) {
        bomDetailRaws[item.id].quantity = plus(
          bomDetailRaws[item.id].quantity,
          item.quantity,
        );
      } else {
        bomDetailRaws[item.id] = {
          id: item.id,
          itemVersionId: item.itemVersionId,
          bomVersionId: item.bomVersionId,
          quantity: item.quantity,
        };
      }
    });

    const childBomRaws = {};
    childBomItems.forEach((item) => {
      if (childBomRaws[item.id]) {
        childBomRaws[item.id].quantity = plus(
          childBomRaws[item.id].quantity,
          item.quantity,
        );
      } else {
        childBomRaws[item.id] = {
          id: item.id,
          quantity: item.quantity,
        };
      }
    });

    // check update bom version
    const isUpdateBomVersion = bomEntity.bomVersions[0].id !== undefined;

    let isNewVersion = false;
    if (bomVersionId) {
      const [
        bomDetailExist,
        bomProducingStepDetailExists,
        bomUserProducingStepDetailExist,
        bomMachineProducingStepDetailExist,
      ] = await Promise.all([
        this.bomDetailRepository.findByCondition({
          bomVersionId: bomVersionId,
        }),
        this.bomProducingStepDetailsRepository.findByCondition({
          bomVersionId: bomVersionId,
        }),
        this.bomUserProducingStepDetailRepository.findByCondition({
          bomVersionId: bomVersionId,
        }),
        this.bomMachineProducingStepDetailRepository.findByCondition({
          bomVersionId: bomVersionId,
        }),
      ]);
      if (
        !isEmpty(bomDetailExist) &&
        !isEmpty(bomProducingStepDetailExists) &&
        !isEmpty(bomUserProducingStepDetailExist) &&
        !isEmpty(bomMachineProducingStepDetailExist)
      ) {
        const bomDetailMap = keyBy(bomDetailExist, 'itemId');
        const bomProducingStepDetailMap = keyBy(
          bomProducingStepDetailExists,
          (i) => {
            //return `${i.itemId}-${i.itemVersionId}-${i.bomVersionId}-${i.producingStepId}`;
            return [
              i.itemId,
              i.itemVersionId,
              i.bomVersionId,
              i.producingStepId,
            ].join('-');
          },
        );
        const bomUserProducingStepDetailMap = keyBy(
          bomUserProducingStepDetailExist,
          (i) => {
            //return `${i.userId}-${i.bomVersionId}-${i.producingStepId}`;
            return [i.userId, i.bomVersionId, i.producingStepId].join('-');
          },
        );
        const bomMachineProducingStepDetailMap = keyBy(
          bomMachineProducingStepDetailExist,
          (i) => {
            //return `${i.name}-${i.bomVersionId}-${i.producingStepId}`;
            return [i.name, i.bomVersionId, i.producingStepId].join('-');
          },
        );

        isNewVersion = this.validateNewVersionBom(
          bomItems,
          bomProducingStepDetails,
          userProducingSteps,
          machineProducingSteps,
          bomDetailMap,
          bomProducingStepDetailMap,
          bomUserProducingStepDetailMap,
          bomMachineProducingStepDetailMap,
          itemVersionId,
          bomVersionId,
        );
      } else isNewVersion = true;
    } else isNewVersion = true;
    const bomProducingStepMap = keyBy(bomProducingStepDetails, 'id');

    // create bom
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    let bom = {} as BomEntity;
    try {
      const bomVersion = bomEntity.bomVersions[0];
      delete bomEntity.bomVersions;
      bom = await queryRunner.manager.save(BomEntity, bomEntity);
      const bomVersionEntity = await queryRunner.manager.save(
        BomVersionEntity,
        {
          ...bomVersion,
          bomId: bom.id,
        },
      );

      bom.bomVersions = [bomVersionEntity];

      childBoms.forEach((item) => {
        if (childBomRaws[item.itemId]) {
          item.quantity = childBomRaws[item.itemId].quantity;
          item.parentId = bom.id;
        }
      });

      // await queryRunner.manager.save(BomEntity, childBoms);

      if (isUpdateBomVersion && isNewVersion) {
        Promise.all([
          queryRunner.manager.delete(BomDetailEntity, {
            bomVersionId: bomVersion.id,
          }),
          queryRunner.manager.delete(BomProducingStepDetailEntity, {
            bomVersionId: bomVersion.id,
          }),
          queryRunner.manager.delete(BomUserProducingStepDetailEntity, {
            bomVersionId: bomVersion.id,
          }),
          queryRunner.manager.delete(BomMachineProducingStepDetailEntity, {
            bomVersionId: bomVersion.id,
          }),
        ]);
      }

      if (isNewVersion) {
        const bomDetailEntities = values(bomDetailRaws).map((bomDetail: any) =>
          this.bomDetailRepository.createEntity({
            bomId: bom.id,
            itemId: bomDetail.id,
            itemVersionId: bomDetail.itemVersionId,
            quantity: bomDetail.quantity,
            bomVersionId: bomVersionEntity.id,
            bomDetailVersionId: bomDetail.bomVersionId,
            parentBomQuantity: bom.quantity,
          }),
        );
        bom.bomDetails = await queryRunner.manager.save(bomDetailEntities);

        // create bomProducingStepDetails
        const bomProducingStepDetailEntities: BomProducingStepDetailEntity[] =
          [];
        bom.bomDetails.forEach((bomDetail) => {
          bomProducingStepMap[bomDetail.itemId]?.producingSteps.forEach(
            (producingStep) => {
              bomProducingStepDetailEntities.push(
                this.bomProducingStepDetailsRepository.createEntity({
                  bomId: bom.id,
                  bomDetailId: bomDetail.id,
                  bomVersionId: bomVersionEntity.id,
                  itemVersionId: bomVersionEntity.itemVersionId,
                  itemId: bomDetail.itemId,
                  producingStepId: producingStep.id,
                  quantity: producingStep.quantity,
                  routingId: bom.routingId,
                }),
              );
            },
          );
        });

        // create bomUserProducingStepDetails
        const bomUserProducingStepDetailEntities: BomUserProducingStepDetailEntity[] =
          [];
        userProducingSteps.forEach((user) => {
          user.producingSteps.forEach((producingStep) => {
            bomUserProducingStepDetailEntities.push(
              this.bomUserProducingStepDetailRepository.createEntity({
                userId: user.id,
                bomId: bom.id,
                bomVersionId: bomVersionEntity.id,
                producingStepId: producingStep.id,
                quantity: producingStep.quantity,
              }),
            );
          });
        });

        // create bomMachineProducingStepDetails
        const bomMachineProducingStepDetailEntities: BomMachineProducingStepDetailEntity[] =
          [];
        machineProducingSteps.forEach((machine) => {
          machine.producingSteps.forEach((producingStep) => {
            bomMachineProducingStepDetailEntities.push(
              this.bomMachineProducingStepDetailRepository.createEntity({
                name: machine.name,
                unit: machine.unit,
                bomId: bom.id,
                bomVersionId: bomVersionEntity.id,
                producingStepId: producingStep.id,
                quantity: producingStep.quantity,
              }),
            );
          });
        });

        await queryRunner.manager.save(bomProducingStepDetailEntities);
        await queryRunner.manager.save(bomUserProducingStepDetailEntities);
        await queryRunner.manager.save(bomMachineProducingStepDetailEntities);

        bom.bomUserProducingStepDetails = bomUserProducingStepDetailEntities;
        bom.bomMachineProducingStepDetails =
          bomMachineProducingStepDetailEntities;
      }

      const saveFileResponse = await this.fileService.handleSaveFiles(
        bomEntity.id || null,
        FileResource.BOM,
        data.files ? data.files.filter((file) => !isEmpty(file)) : null,
        files,
      );
      if (saveFileResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
        await queryRunner.rollbackTransaction();
        return saveFileResponse;
      }

      await queryRunner.commitTransaction();
      response = plainToInstance(BomResponseDto, bom, {
        excludeExtraneousValues: true,
      });

      const updateItemData = {
        id: bom.itemId,
        isHasBom: '1',
      };
      await this.itemService.updateIsHasBomItem(updateItemData);
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      message = error;
    } finally {
      await queryRunner.release();
    }

    return new ResponseBuilder()
      .withCode(code)
      .withData(response)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate(responseMessage || 'message.SUCCESS')
          : message,
      )
      .build();
  }

  private async getBomExtraInfo(
    itemIds: number[],
    userIds: number[],
  ): Promise<any> {
    const data = await Promise.all([
      this.itemService.getItemsByIds(itemIds),
      this.userService.getUserByIds(userIds),
    ]);
    const items = data[0];
    const users = data[1];
    const normalizeItems = {};
    const normalizeUsers = {};

    items.forEach((item) => {
      normalizeItems[item.id] = item;
    });
    users.forEach((user) => {
      normalizeUsers[user.id] = user;
    });

    return { normalizeUsers, normalizeItems };
  }

  /**
   *
   * @param bomEntity
   * @param status
   * @returns
   */
  private async updateBomStatus(
    bomEntity: BomEntity,
    status: number,
    userId?: number,
  ): Promise<any> {
    bomEntity.status = status;
    bomEntity.approverId = userId;
    bomEntity.approvedAt = new Date(Date.now());
    await this.bomRepository.update(bomEntity);

    const response = plainToInstance(BomResponseDto, bomEntity, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  public async getBomByItemId(
    payload: GetBomByItemIdRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { itemId } = payload;
    const bomData = await this.bomRepository.findOneByCondition({ itemId });
    if (!bomData) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const bomDetails = await this.bomDetailRepository.findByCondition({
      bomId: bomData.id,
    });
    const childBomsData = await this.bomRepository.findByCondition({
      itemId: In(bomDetails.map((d) => d.itemId)),
    });
    let itemIds = childBomsData.map((bom) => bom.itemId);
    itemIds = [...itemIds, itemId];
    const items = await this.itemService.getItemsByIds(itemIds);
    const normalizeItems = {};
    items.forEach((item) => {
      normalizeItems[item.id] = item;
    });
    let childBoms = [];
    if (childBomsData.length > 0) {
      childBoms = childBomsData.map((childBom) => ({
        id: childBom.id,
        name: childBom.name,
        routingId: childBom.routingId,
        itemName: normalizeItems[childBom.itemId].name,
      }));
    }
    const bom = {
      bomId: bomData.id,
      bomName: bomData.name,
      routingId: bomData.routingId,
      itemName: normalizeItems[bomData.itemId].name,
      childBoms,
    };

    return new ResponseBuilder(bom)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getBomsByItemIds(itemIds: number[], serilize?: boolean): Promise<any> {
    const boms = await this.bomRepository.findByCondition({
      itemId: In(itemIds),
    });
    const serilizeBoms = {};
    if (serilize) {
      boms.forEach((item) => {
        serilizeBoms[item.id] = item;
      });
      return serilizeBoms;
    }
    return boms;
  }

  private async bomCycleValid(
    itemId: number,
    childItemIds: number[],
  ): Promise<boolean> {
    let parentIds = await this.bomRepository.listParentByItem(itemId);
    parentIds = parentIds.map((i) => i.parentItemId);
    for (const childItemId of childItemIds) {
      let childIds = await this.bomRepository.listChildByItem(childItemId);
      childIds = childIds.map((i) => i.childItemId);
      const diffCheck = difference(parentIds || [], childIds || []);
      if (diffCheck.length < parentIds.length) {
        return false;
      }
    }
    return true;
  }

  // bom step start

  async getBomProducingStep(req): Promise<any> {
    const { bomId, itemId } = req;
    let result = await this.bomRepository.getBomProducingStepStruct(
      bomId,
      itemId,
    );
    const items = await this.itemService.getItemsByIds(
      result.map((bps) => bps.bomDetail.itemId),
      false,
    );
    const itemMap = {};
    const itemIds = items
      .filter((i) => {
        const item = plainToInstance(ItemResponseDto, i);
        itemMap[i.id] = item;
        return !item.isProductionObject;
      })
      .map((i) => i.id);
    result = result.filter((i) => itemIds.includes(i.bomDetail.itemId));
    let oldData = [];
    if (bomId) {
      oldData = await this.bomProducingStepDetailsRepository.findWithRelations({
        where: {
          bomId: bomId,
        },
      });
    }
    const oldDataMap = {};
    oldData.forEach((old) => {
      oldDataMap[`${old.bomDetailId}_${old.itemId}_${old.producingStepId}`] =
        old;
    });
    if (isEmpty(result)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const response = new BomProducingStepStructResponseDto();
    response.materialDetails = result.map((item) => {
      const bomMaterialDetail = new BomMaterialDetail();
      bomMaterialDetail.bomDetail = plainToInstance(BomDetailDto, {
        ...item.bomDetail,
        item: itemMap[item.bomDetail.itemId],
      });
      bomMaterialDetail['item'] = itemMap[bomMaterialDetail.bomDetail.itemId];
      bomMaterialDetail.producingStepData = item.step.map((i) => {
        const ps = new ProducingStepData();
        ps.producingStep = plainToInstance(
          ProducingStepResponseDto,
          JSON.parse(i),
        );
        const old =
          oldDataMap[
            `${bomMaterialDetail.bomDetail.id}_${bomMaterialDetail.bomDetail.itemId}_${ps.producingStep.id}`
          ];
        ps.quantity = old ? old.quantity : 0;
        ps.status = old ? old.status : BomProducingStepStatusEnum.EMPTY;
        return ps;
      });
      return bomMaterialDetail;
    });
    return new ResponseBuilder()
      .withData(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async createOrUpdateBomProducingStep(
    req: CreateBomProducingStepRequestDto,
  ): Promise<any> {
    const { bomId, itemId, detail, description } = req;
    let isUpdate = false;
    let struct = await this.bomRepository.getBomProducingStepStruct(
      bomId,
      itemId,
    );
    const items = await this.itemService.getItemsByIds(
      struct.map((bps) => bps.bomDetail.itemId),
      false,
    );
    const itemIds = items
      .filter((i) => {
        const item = plainToInstance(ItemResponseDto, i);
        return !item.isProductionObject;
      })
      .map((i) => i.id);
    struct = struct.filter((i) => itemIds.includes(i.bomDetail.itemId));
    if (isEmpty(struct)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    let oldData = [];
    if (bomId) {
      oldData = await this.bomProducingStepDetailsRepository.findWithRelations({
        where: {
          bomId: bomId,
        },
      });
    }
    let removeIds = [];
    const oldDataMap = {};
    oldData.forEach((old) => {
      removeIds.push(old.id);
      oldDataMap[`${old.bomDetailId}_${old.itemId}_${old.producingStepId}`] =
        old;
    });
    //
    const detailRequestMap = {};
    detail.forEach((i) => {
      detailRequestMap[`${i.bomDetailId}_${i.itemId}_${i.producingStepId}`] = i;
    });
    // validate and convert to entity
    const entity = [];
    let hasError = false;
    struct.forEach((item) => {
      const bomMaterialDetail = new BomMaterialDetail();
      bomMaterialDetail.bomDetail = plainToInstance(
        BomDetailDto,
        item.bomDetail,
      );
      bomMaterialDetail.producingStepData = item.step.map((i) => {
        const ps = new ProducingStepData();
        ps.producingStep = JSON.parse(i);
        return ps;
      });
      let sumQuantity = 0;
      const itemQuantity = bomMaterialDetail.bomDetail.quantity;
      bomMaterialDetail.producingStepData.forEach((ps) => {
        const bomDetail = bomMaterialDetail.bomDetail;
        const key = `${bomDetail.id}_${bomDetail.itemId}_${ps.producingStep.id}`;
        const old = oldDataMap[key] || {};
        if (detailRequestMap[key]) {
          if (old.status === BomProducingStepStatusEnum.CONFIRMED) {
            removeIds = removeIds.filter((i) => i != old.id);
            sumQuantity = plus(sumQuantity, old.quantity);
          } else {
            if (detailRequestMap[key].quantity <= 0) {
              return;
            }
            if (old.id) {
              isUpdate = true;
              removeIds = removeIds.filter((i) => i != old.id);
            }
            const bomProducingStepDetails = new BomProducingStepDetailEntity();
            bomProducingStepDetails.id = old.id;
            bomProducingStepDetails.bomDetailId = bomDetail.id;
            bomProducingStepDetails.bomId = bomId;
            bomProducingStepDetails.itemId = bomDetail.itemId;
            bomProducingStepDetails.producingStepId = ps.producingStep.id;
            bomProducingStepDetails.routingId = item.routing.id;
            bomProducingStepDetails.quantity = detailRequestMap[key].quantity;
            bomProducingStepDetails.status = BomProducingStepStatusEnum.CREATED;
            bomProducingStepDetails.description = description;
            entity.push(bomProducingStepDetails);
            sumQuantity = plus(sumQuantity, detailRequestMap[key].quantity);
          }
        }
      });
      if (minus(itemQuantity, sumQuantity) != 0) {
        hasError = true;
      }
      return bomMaterialDetail;
    });
    if (hasError) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (!isEmpty(removeIds)) {
        await queryRunner.manager.delete(
          BomProducingStepDetailEntity,
          removeIds,
        );
      }
      await queryRunner.manager.save(BomProducingStepDetailEntity, entity);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
    } finally {
      await queryRunner.release();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(
        isUpdate
          ? await this.i18n.translate(
              'message.defineBOMProducingStep.updateSuccess',
            )
          : await this.i18n.translate(
              'message.defineBOMProducingStep.createSuccess',
            ),
      )
      .build();
  }

  async updateBomProducingStepStatus(id: number, status: number): Promise<any> {
    const bomProducingStepDetailOlds =
      await this.bomProducingStepDetailsRepository.findByCondition({
        bomId: id,
      });
    if (bomProducingStepDetailOlds.length === 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const dataNotConfirmed = bomProducingStepDetailOlds.filter(
      (record) =>
        record.status === BomProducingStepStatusEnum.CREATED ||
        record.status === BomProducingStepStatusEnum.REJECTED,
    );

    if (
      (status === BomProducingStepStatusEnum.CONFIRMED &&
        dataNotConfirmed.length === 0) ||
      (status === BomProducingStepStatusEnum.REJECTED &&
        dataNotConfirmed.length !== bomProducingStepDetailOlds.length)
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    const dataUpdate = bomProducingStepDetailOlds.map((record) => ({
      ...record,
      status: status,
    }));

    const bomEntity = new BomEntity();
    bomEntity.id = id;
    bomEntity.isHasBomProducingStep = true;
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(BomProducingStepDetailEntity, dataUpdate);
      await queryRunner.manager.save(BomEntity, bomEntity);
      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  async deleteBomProducingStep(id: number): Promise<any> {
    const bomProducingStepDetailOlds =
      await this.bomProducingStepDetailsRepository.findByCondition({
        bomId: id,
      });
    if (bomProducingStepDetailOlds.length === 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const dataNotConfirmed = bomProducingStepDetailOlds.filter(
      (record) =>
        record.status === BomProducingStepStatusEnum.CREATED ||
        record.status === BomProducingStepStatusEnum.REJECTED,
    );
    if (dataNotConfirmed.length !== bomProducingStepDetailOlds.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.FORBIDDEN)
        .withMessage(await this.i18n.translate('error.FORBIDDEN'))
        .build();
    }

    const bomEntity = new BomEntity();
    bomEntity.id = id;
    bomEntity.isHasBomProducingStep = false;
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.delete(
        BomProducingStepDetailEntity,
        bomProducingStepDetailOlds,
      );
      await queryRunner.manager.save(BomEntity, bomEntity);
      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            'message.defineBOMProducingStep.deleteSuccess',
          ),
        )
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  async getListBomProducingStep(
    req: GetBomProducingStepListRequestDto,
  ): Promise<any> {
    const items = [];
    const itemIds =
      await this.bomProducingStepDetailsRepository.getAllItemIdOfBoms();
    items.push(
      ...(await this.itemService.getItemsByRelations({
        where: itemIds.map((i) => {
          return { id: i['item_id'] };
        }),
      })),
    );

    const response = new PagingResponse();

    const { result, count } =
      await this.bomProducingStepDetailsRepository.getList(req, items);

    if (isEmpty(items)) {
      items.push(
        ...(await this.itemService.getItemsByRelations({
          where: result.map((i) => {
            return { id: i.itemId };
          }),
        })),
      );
    }

    const itemMap = convertArrayToObject(items, 'id');
    response.items = result.map((i) => {
      return {
        id: i.id,
        bomName: i.name,
        bomCode: i.code,
        routingName: i.routingName,
        itemId: i.itemId,
        itemName: itemMap[i.itemId]['name'],
        itemCode: itemMap[i.itemId]['code'],
        status: i.status,
        createdAt: i.createdAt,
        updatedAt: i.updatedAt,
      };
    });

    response.meta = {
      total: count || 0,
      page: req.page,
    };
    return new ResponseBuilder()
      .withData(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  async getBomTreeByItemIds(request: GetBomTreeByItemIds): Promise<any> {
    const { itemIds, bomVersionIds, factoryId } = request;

    const tempBoms: any[] = [];
    const daddyBoms: any[] = [];
    const producingSteps: any[] = [];
    const bomMap: any = new Map(); // key: itemId-stepNumber / subItemIds, value: bom

    const boms = await this.bomRepository.bomStructPlanning(
      itemIds,
      bomVersionIds,
    );

    let serializeBomProducingStepMaterials = {};
    let serializeBomProducingSteps = {};
    let producingStepWorkCenters = [];
    if (!isEmpty(boms)) {
      const bomIds = map(boms, 'bomId');

      const bomProducingStepMaterials =
        await this.bomRepository.getBomMaterialProducingSteps(bomIds);
      const bomProducingSteps = await this.bomRepository.getBomProducingSteps(
        bomIds,
      );
      const workCenterIds = [];

      bomProducingSteps.forEach((bom) => {
        bom.bomProducingSteps.forEach((producingStep) => {
          const stepWorkCenterIds = producingStep.producingSteps.flatMap(
            (step) => step.workCenterIds,
          );
          workCenterIds.push(...stepWorkCenterIds);
        });
      });

      const getWorkCentersResponse =
        await this.workCenterService.getWorkCenterByIds(workCenterIds);
      if (getWorkCentersResponse.statusCode === ResponseCodeEnum.SUCCESS) {
        producingStepWorkCenters = getWorkCentersResponse.data;
      }

      serializeBomProducingStepMaterials = keyBy(
        bomProducingStepMaterials,
        'id',
      );
      serializeBomProducingSteps = keyBy(bomProducingSteps, 'id');
    }

    // handle boms -> bomMap, producingSteps
    for (let i = 0; i < boms.length; i++) {
      const bom = boms[i];
      boms[i].subBom = [];
      const objBom: any = {};
      objBom.itemId = bom.itemId;
      objBom.bomVersionId = bom.bomVersionId;
      objBom.itemVersionId = bom.itemVersionId;
      objBom.stepNumber = bom.stepNumber;
      objBom.subItemIds = bom.sub.map((e) => e.itemId);
      objBom.subBomVersionIds = bom.sub.map((e) => e.bomDetailVersionId);
      bom.proStep = serializeBomProducingSteps[
        bom.bomId
      ]?.bomProducingSteps?.find(
        (ps) => ps.stepNumber == bom.stepNumber,
      )?.producingSteps;

      tempBoms.push(objBom);

      bom.proStep?.forEach((proStep) => {
        const proStepWorkCenters = producingStepWorkCenters?.filter(
          (workCenter) => workCenter.producingStepId === proStep.id,
        );
        const filterFactoryWorkCenters = proStepWorkCenters?.filter(
          (workCenter) => workCenter.factoryId === factoryId,
        );
        const psWorkCenters = factoryId
          ? filterFactoryWorkCenters
          : proStepWorkCenters;

        proStep.workCenters = psWorkCenters;
        let workingCapacity;
        if (!isEmpty(psWorkCenters)) {
          workingCapacity = map(psWorkCenters, 'actualWorkingCapacity')?.reduce(
            (prev, cur) => plus(prev, cur),
            0,
          );
        }
        proStep.workCenterIds = psWorkCenters?.map(
          (workCenter) => workCenter.id,
        );
        proStep.workingCapacity = workingCapacity || 0;
        const bomProducingStepMaterial: any =
          serializeBomProducingStepMaterials[bom.bomId];
        proStep.materials = filter(
          bomProducingStepMaterial?.bomProducingSteps,
          (bomProducingStep) =>
            bomProducingStep?.producingStepId === proStep.producingStepId &&
            bomProducingStep.bomVersionId === bom.bomVersionId,
        );
      });
      producingSteps.push(...bom.proStep);
      const key = bom.itemId + '-' + bom.stepNumber + '-' + bom.bomVersionId;

      bomMap.set(key, boms[i]);
      bomMap.set(objBom, boms[i]);
    }
    const stepNumbers = uniq(tempBoms.map((bom) => bom.stepNumber));
    this.mapBomTree(tempBoms, bomMap, stepNumbers);

    for (let i = 0; i < boms.length; i++) {
      const bom = boms[i];
      if (itemIds.includes(bom.itemId)) {
        daddyBoms.push(bom);
      }
    }

    return new ResponseBuilder(daddyBoms)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  // map bom tree, bom -> subBom -> ...
  mapBomTree(boms: any[], bomMap: any, stepNumbers) {
    for (let i = 0; i < boms.length; i++) {
      const e = boms[i];
      for (let j = 0; j < e.subItemIds.length; j++) {
        const itemId = e.subItemIds[j];
        const bomVersionId = e.subBomVersionIds[j];
        for (let k = 0; k < stepNumbers.length; k++) {
          // key = itemId + numberStep
          if (bomMap.get(itemId + '-' + stepNumbers[k] + '-' + bomVersionId)) {
            bomMap
              .get(e)
              ?.subBom?.push(
                bomMap.get(itemId + '-' + stepNumbers[k] + '-' + bomVersionId),
              );
          }
        }
      }
    }
  }

  public async getBomByItemIds(
    request: GetBomByItemIdsRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { itemIds } = request;
    const boms = await this.bomRepository.findWithRelations({
      where: {
        itemId: In(itemIds),
      },
      relations: ['routing', 'routing.productionLines'],
    });

    const dataReturn = boms?.map((bom) => ({
      ...bom,
      routing: {
        ...bom.routing,
        productionLine: first(bom.routing.productionLines),
      },
    }));

    if (!boms) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const response = plainToInstance(BomResponseDto, dataReturn, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getMaterialBomByIds(
    request: GetMaterialBomByIdsRequestDto,
  ): Promise<any> {
    const { ids } = request;

    const bomProducingStepMaterials =
      await this.bomRepository.getBomMaterialProducingSteps(ids);

    return new ResponseBuilder(bomProducingStepMaterials)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  getCodeBom(code, subfix, length) {
    return code + '_' + `${subfix + length}`.slice(-2);
  }

  private async uploadFile(files): Promise<any> {
    for (let i = 0; i < files.length; i++) {
      const file = files[i] as File;
      if (MAX_SIZE_FILE_UPLOAD.SIZE < Buffer.byteLength(file.data)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.FILE_UPLOAD_MAX_SIZE'))
          .build();
      }
    }

    const fileResponse = await this.fileService.uploadFiles(
      files,
      FileResource.BOM,
    );

    return fileResponse;
  }

  validateNewVersionBom(
    bomItems,
    bomProducingStepDetails,
    userProducingSteps,
    machineProducingSteps,
    bomDetailMap,
    bomProducingStepDetailMap,
    bomUserProducingStepDetailMap,
    bomMachineProducingStepDetailMap,
    itemVersionId,
    bomVersionId,
  ) {
    let isNewVersion = false;
    bomItems.forEach((item) => {
      if (+bomDetailMap[item.id]?.quantity !== +item.quantity) {
        isNewVersion = true;
      }
    });
    bomProducingStepDetails.forEach((bomProducingStep) => {
      bomProducingStep.producingSteps.forEach((producingStep) => {
        const key =
          bomProducingStep.id +
          '-' +
          itemVersionId +
          '-' +
          bomVersionId +
          '-' +
          producingStep.id;

        if (
          +bomProducingStepDetailMap[key]?.quantity !== +producingStep.quantity
        ) {
          isNewVersion = true;
        }
      });
    });
    userProducingSteps.forEach((userProducingStep) => {
      userProducingStep.producingSteps.forEach((producingStep) => {
        const key =
          userProducingStep.id + '-' + bomVersionId + '-' + producingStep.id;

        if (
          +bomUserProducingStepDetailMap[key]?.quantity !==
          +producingStep.quantity
        ) {
          isNewVersion = true;
        }
      });
    });
    machineProducingSteps.forEach((machineProducingStep) => {
      machineProducingStep.producingSteps.forEach((producingStep) => {
        const key =
          machineProducingStep.name +
          '-' +
          bomVersionId +
          '-' +
          producingStep.id;

        if (
          +bomMachineProducingStepDetailMap[key]?.quantity !==
          +producingStep.quantity
        ) {
          isNewVersion = true;
        }
      });
    });
    return isNewVersion;
  }

  async rejectBomVersion(
    request: ConfirmRejectBomVersionRequestDto,
  ): Promise<any> {
    const { id, bomVersionId, note } = request;
    const bom = await this.bomRepository.findOneById(id);

    if (isEmpty(bom)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const bomVersion = await this.bomVersionRepository.findOneById(
      bomVersionId,
    );
    if (isEmpty(bomVersion)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    // if (!STATUS_BOM_TO_REJECT_BOM_VERSION.includes(bom.status)) {
    //   return new ResponseBuilder()
    //     .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
    //     .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
    //     .build();
    // }

    if (!STATUS_TO_REJECT_BOM_STATUS.includes(bomVersion.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }

    const result = await this.bomVersionRepository.create({
      ...bomVersion,
      status: BomStatusEnum.REJECTED,
      note: note,
    });

    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async confirmBomVersion(
    request: ConfirmRejectBomVersionRequestDto,
  ): Promise<any> {
    const { id, bomVersionId, note, userId } = request;
    const bom = await this.bomRepository.findOneById(id);

    if (isEmpty(bom)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const bomVersion = await this.bomVersionRepository.findOneById(
      bomVersionId,
    );
    if (isEmpty(bomVersion)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (!STATUS_TO_CONFIRM_BOM_STATUS.includes(bomVersion.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }

    if (!STATUS_TO_CONFIRM_BOM_STATUS.includes(bomVersion.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }

    const bomDetail = await this.bomDetailRepository.findByCondition({
      bomId: bom.id,
      bomVersionId: bomVersionId,
    });
    //check whether child boms is confirmed or not
    const unconfirmedChildBoms =
      await this.bomVersionRepository.findByCondition({
        id: In(bomDetail.map((i) => i.bomDetailVersionId)),
        status: In([BomStatusEnum.REJECTED, BomStatusEnum.PENDING]),
      });

    if (unconfirmedChildBoms.length > 0) {
      return new ResponseBuilder({
        unconfirmedChildBoms: unconfirmedChildBoms,
      })
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.CHILD_BOM_IS_UNCONFIRMED'),
        )
        .build();
    }

    const result = await this.bomVersionRepository.create({
      ...bomVersion,
      status: BomStatusEnum.CONFIRMED,
      note: note,
      approverAt: new Date(Date.now()),
      approverId: userId,
    });

    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getListBomVersionByBomVersionIds(
    request: GetListBomVersionByBomVersionIdsRequestDto,
  ): Promise<any> {
    const { bomVersionIds } = request;
    const bomVersions = await this.bomVersionRepository.findByCondition({
      id: In(bomVersionIds),
    });

    return new ResponseBuilder(bomVersions)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getBomVersionByItemId(itemId: number, request?: any): Promise<any> {
    const bomVersions = await this.bomVersionRepository.getBomVersionByItemId(
      itemId,
      request,
    );

    return new ResponseBuilder(bomVersions)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getListBomVersionByBomId(
    request: GetBomVersionByBomIdRequestDto,
  ): Promise<any> {
    const { result, count } =
      await this.bomVersionRepository.getBomVersionByBomId(request);
    return new ResponseBuilder<PagingResponse>({
      items: result,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
  async getBomDetailByItemIds(
    request: GetBomDetailByItemIdsRequestDto,
  ): Promise<any> {
    const { itemIds } = request;

    const resData = plainToInstance(
      GetBomDetailByItemIdsResponseDto,
      await this.bomDetailRepository.findByCondition({
        itemId: In(itemIds),
      }),
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(resData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getBomStructProducingStep(
    payload: GetBomStructRequestDto,
  ): Promise<any> {
    const { id, bomVersionId } = payload;
    const rootItemIds = payload.items ? payload.items.map((i) => i.itemId) : [];

    let bomVersionLastest;
    if (!bomVersionId) {
      bomVersionLastest = await this.bomVersionRepository.findByCondition(
        {
          bomId: id,
        },
        {
          id: 'DESC',
        },
      );
    }
    const bomVersionIdTemp = isEmpty(bomVersionLastest)
      ? bomVersionId
      : bomVersionLastest[0].id;

    const boms = await this.bomRepository.getBomStructProducingStep(
      id,
      rootItemIds,
      bomVersionIdTemp,
    );

    const bom = await this.bomRepository.getDetail(id, bomVersionIdTemp);

    const bomMap = {};
    const allItemIds = [];
    let bomVersionIds = [];

    boms.forEach((e) => {
      allItemIds.push(e.itemId);
      allItemIds.push(...e.sub.map((s) => s.itemId));
      bomVersionIds.push(...e.sub.map((i) => i.bomDetailVersionId));
      bomMap[e.itemId] = e;
      bomMap[e.itemId].bom = JSON.parse(e.bom);
      bomMap[e.itemId].producingSteps = JSON.parse(e.producingSteps);
      bomMap[e.itemId].sub = bomMap[e.itemId].sub?.map((sub) => {
        return {
          ...sub,
          bomParentId: bomMap[e.itemId].bom?.bom?.id,
          bomQuantity: bomMap[e.itemId].bom?.bom?.quantity,
          bomParentItemId: bomMap[e.itemId].bom?.bom?.item_id,
        };
      });
      if (e.bom.bom.id == id) {
        rootItemIds.push(e.bom.bom['item_id']);
      }
    });

    bomVersionIds = compact(uniq(bomVersionIds));

    const [bomVersions, bomVersionByItemIds] = await Promise.all([
      this.bomVersionRepository.findByCondition({
        id: In([...bomVersionIds, bomVersionId]),
      }),
      this.bomVersionRepository.getBomVersionByItemIds(allItemIds),
    ]);

    const bomVersionMap = keyBy(bomVersions, 'id');
    const bomVersionByIdMap = keyBy(bomVersionByItemIds, 'itemId');
    const allItemMap = await this.itemService.getItemsByIds(allItemIds, true);
    const response = rootItemIds.map((itemId) => {
      const response = this.toBomProducingStepResponseDto(
        itemId,
        allItemMap,
        bomMap,
        [],
        bom.quantity,
        bomVersionMap,
        bomVersionId,
        null,
        bomVersionByIdMap,
        bom,
        {},
        1,
      );
      return response;
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private toBomProducingStepResponseDto(
    itemId: number,
    allItemMap: any,
    bomMap: any,
    producingSteps: any,
    quantity: number,
    bomVersionMap: any,
    bomVersionId: number,
    parentItemId,
    bomVersionByIdMap: any,
    rootBom: any,
    tempSub: any,
    level?: number,
  ) {
    let result = new BomResponseDto();
    if (bomMap[itemId]) {
      result = plainToInstance(
        BomResponseDto,
        mapKeys(bomMap[itemId].bom.bom, (v, k) => camelCase(k)),
        {
          excludeExtraneousValues: true,
        },
      );

      result.routing = plainToInstance(
        RoutingResponseAbstractDto,
        mapKeys(bomMap[itemId].bom.routing, (v, k) => camelCase(k)),
        {
          excludeExtraneousValues: true,
        },
      );

      result.producingSteps = plainToInstance(
        ProducingStepResponseDto,
        bomMap[itemId].producingSteps as any[],
        {
          excludeExtraneousValues: true,
        },
      );

      if (bomVersionMap[bomVersionId]) {
        result.bomVersion = plainToInstance(
          BomVersion,
          bomVersionMap[bomVersionId],
          {
            excludeExtraneousValues: true,
          },
        );
      }
      if (bomVersionByIdMap[itemId]?.bomVersions) {
        result.bomVersions = plainToInstance(
          BomVersion,
          bomVersionByIdMap[itemId].bomVersions as any[],
          {
            excludeExtraneousValues: true,
          },
        );
      }
      result.subBoms = bomMap[itemId].sub.map((sub) => {
        const isRoot = +bomMap[itemId]?.bom?.bom?.id === +rootBom?.id;

        const rate = +sub.quantity / +sub.bomQuantity;

        sub.tempQuantity = !isRoot
          ? mul(tempSub?.tempQuantity, rate)
          : sub.quantity;

        return this.toBomProducingStepResponseDto(
          sub.itemId,
          allItemMap,
          bomMap,
          sub.producingSteps,
          isRoot ? sub.quantity : mul(tempSub?.tempQuantity, rate),
          bomVersionMap,
          sub.bomDetailVersionId,
          itemId,
          bomVersionByIdMap,
          rootBom,
          sub,
          level + 1,
        );
      });
    }
    if (!isEmpty(producingSteps)) {
      result.producingSteps = plainToInstance(
        ProducingStepResponseDto,
        producingSteps as any[],
        {
          excludeExtraneousValues: true,
        },
      );
    }
    result.quantity = quantity;
    result.level = level;
    result.item = { ...allItemMap[itemId], parentItemId: parentItemId };

    return result;
  }

  public async cloneBomVersion(
    payload: UpdateBomFormDataDto,
  ): Promise<ResponsePayload<any>> {
    const { data, userId } = payload;
    const { id, itemVersionId, bomVersionCode } = data;
    const bom = await this.bomRepository.findOneById(id);
    if (isEmpty(bom)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_BOM_TO_CLONE_BOM_VERSION_STATUS.includes(bom.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(
          await this.i18n.translate(
            'error.BOM_VERSION_CLONE_STATUS_NOT_ACCEPTED',
          ),
        )
        .build();
    }
    const bomItemId = bom.itemId;

    // check bom version create/update
    const bomVersion = await this.bomVersionRepository.findOneByCondition({
      code: bomVersionCode,
    });

    if (bomVersion)
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.BOM_VERSION_CODE_IS_ALREADY_EXIST'),
        )
        .build();

    const bomVersionEntity = this.bomVersionRepository.createEntity({
      itemVersionId,
      userId,
      code: bomVersionCode,
    });

    // check status bom
    let bomEntity: BomEntity;
    bomEntity = this.bomRepository.updateEntity(bom, data);

    bomEntity.bomVersions = [bomVersionEntity];

    const bomItemsFilter = payload.data.bomItems?.filter(
      (bom) => bom.itemTypeCode === ITEM_TYPE.SEMI_PRODUCT,
    );

    const bomVersionStatusList = map(bomItemsFilter, 'bomVersionStatus');

    const updatedBom = await this.save(
      bomEntity,
      payload,
      'message.defineBOM.cloneSuccess',
    );

    if (bomItemId !== updatedBom.data?.itemId) {
      const updateItemData = {
        id: bomItemId,
        isHasBom: '0',
      };
      await this.itemService.updateIsHasBomItem(updateItemData);
    }

    return updatedBom;
  }

  private async checkExistence(data: any): Promise<ResponsePayload<any>> {
    const { bomId, itemId, name, code } = data;
    switch (true) {
      case itemId &&
        !isEmpty(
          await this.bomRepository.findOneByCondition({
            itemId,
          }),
        ):
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.BOM_FOR_THIS_ITEM_ALREADY_EXISTS'),
          )
          .build();

      case itemId && isEmpty(await this.itemService.getItemsByIds([itemId])):
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(
            await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'),
          )
          .build();

      case name &&
        !isEmpty(await this.bomRepository.findByCondition([{ name }])):
      case bomId &&
        name &&
        !isEmpty(
          await this.bomRepository.findByCondition({
            name: name,
            id: Not(bomId),
          }),
        ):
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.BOM_NAME_IS_EXIST'))
          .build();

      case code &&
        !isEmpty(
          await this.bomRepository.findByCondition([{ code: ILike(code) }]),
        ):
      case bomId &&
        code &&
        !isEmpty(
          await this.bomRepository.findByCondition({
            code: ILike(code),
            id: Not(bomId),
          }),
        ):
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.BOM_CODE_IS_EXIST'))
          .build();

      //is update
      case bomId && isEmpty(await this.bomRepository.findOneById(bomId)):
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.NOT_FOUND'))
          .build();

      default:
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
    }
  }

  async getBomVersionByItemIds(
    request: GetBomVersionByItemIdsRequestDto,
  ): Promise<any> {
    const { itemIds } = request;

    const data = await this.bomVersionRepository.getBomVersionByItemIds(
      itemIds,
    );

    const resData = plainToInstance(
      GetBomVersionByItemIdsResponseDto,
      map(data, (i) => {
        return {
          ...i,
          latestVersion: last(i.bomVersions),
        };
      }),
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(resData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
