import { CreateBomRequestDto } from '@components/bom/dto/request/create-bom.request.dto';
import { MIMETYPE_FILE_UPLOAD_BOM } from '@components/file/constant/file-upload.constant';
import { ErrorMessageEnum } from '@constant/error-message.enum';
import { BaseDto } from '@core/dto/base.dto';
import { File } from '@core/dto/request/file.request.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type, plainToInstance } from 'class-transformer';
import { IsIn, IsNumber, IsOptional, ValidateNested } from 'class-validator';

class FileUpload extends File {
  @IsIn(MIMETYPE_FILE_UPLOAD_BOM, {
    // message: ErrorMessageEnum.MIMETYPE_FILE,
  })
  mimetype: string;
}
export class UpdateBomRequestDto extends CreateBomRequestDto {
  @ApiProperty()
  @IsOptional()
  @IsNumber()
  id: number;
}

export class UpdateBomFormDataDto extends BaseDto {
  @ApiProperty({
    description: `
    {
      "name": "bomItem7",
      "code": "BOMITEM7",
      "description": "BOMITEM7",
      "routingId": 2,
      "itemId": 7,
      "itemVersionId": 7,
      "quantity": 91,
      "klNumber": 91,
      "ttNumber": 91,
      "bomItems": [
          {
              "id": 8,
              "bomVersionId": 7,
              "quantity": 5
          },
          {
              "id": 6,
              "bomVersionId": null,
              "quantity": 5
          }
      ],
      "bomProducingStepDetails": [
          {
              "id": 6,
              "quantity": 5,
              "producingSteps": [
                  {
                      "id": 2,
                      "quantity": 3
                  },
                  {
                      "id": 3,
                      "quantity": 2
                  }
              ]
          }
      ],
      "userProducingSteps": [
          {
              "id": 1,
              "producingSteps": [
                  {
                      "id": 2,
                      "quantity": 3
                  },
                  {
                      "id": 3,
                      "quantity": 2
                  }
              ]
          }
      ],
      "machineProducingSteps": [
          {
              "name": "may 1",
              "producingSteps": [
                  {
                      "id": 2,
                      "quantity": 3
                  },
                  {
                      "id": 3,
                      "quantity": 2
                  }
              ]
          }
      ]
    }
    `,
  })
  @ValidateNested({ each: true })
  @Transform((v) => plainToInstance(UpdateBomRequestDto, JSON.parse(v.value)))
  @Type(() => UpdateBomRequestDto)
  data: UpdateBomRequestDto;

  @ApiProperty()
  @Type(() => FileUpload)
  files: FileUpload[];
}
