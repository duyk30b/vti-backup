import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty, IsOptional } from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';

export class GetBomDetailRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsOptional()
  id: number;

  @ApiProperty()
  @IsOptional()
  @Transform((v) => +v.value)
  @IsInt()
  bomVersionId: number;
}
