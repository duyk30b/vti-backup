import { IsArray, IsNotEmpty } from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';

export class GetBomDetailByItemIdsRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsArray()
  itemIds: number[];
}
