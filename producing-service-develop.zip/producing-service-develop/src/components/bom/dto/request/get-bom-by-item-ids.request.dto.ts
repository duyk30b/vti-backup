import { IsArray, IsNotEmpty } from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';

export class GetBomByItemIdsRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsArray()
  itemIds: number[];
}
