import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  ArrayNotEmpty,
  IsArray,
  IsNotEmpty,
  ValidateNested,
} from 'class-validator';

export class GetListBomVersionByBomVersionIdsRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @ArrayNotEmpty()
  @ValidateNested()
  @IsArray()
  bomVersionIds: number[];
}
