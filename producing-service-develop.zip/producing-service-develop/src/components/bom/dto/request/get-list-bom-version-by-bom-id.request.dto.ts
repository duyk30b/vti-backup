import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsOptional } from 'class-validator';

export class GetBomVersionByBomIdRequestDto extends PaginationQuery {
  @ApiProperty()
  @IsOptional()
  bomId: number;
}
