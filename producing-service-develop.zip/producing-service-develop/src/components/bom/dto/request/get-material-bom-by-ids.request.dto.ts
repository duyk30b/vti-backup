import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class GetMaterialBomByIdsRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  ids: number[];
}
