import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsArray,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  MaxLength,
  Min,
} from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';

export class BomProducingStepDetailsDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  bomDetailId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  producingStepId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  @Min(0)
  quantity: number;
}

export class CreateBomProducingStepRequestDto extends BaseDto {
  @ApiProperty()
  @IsNumber()
  bomId: number;

  @ApiProperty()
  @IsNumber()
  itemId: number;

  @ApiPropertyOptional()
  @MaxLength(255)
  @IsOptional()
  description: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  detail: BomProducingStepDetailsDto[];
}
