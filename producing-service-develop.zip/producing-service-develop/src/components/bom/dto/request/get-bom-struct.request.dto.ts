import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional } from 'class-validator';
import { Type } from 'class-transformer';
import { BaseDto } from 'src/core/dto/base.dto';

export class BomItemDto {
  @ApiProperty()
  @IsNotEmpty()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  quantity: number;
}

export class GetBomStructRequestDto extends BaseDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  @IsOptional()
  bomVersionId: number;

  @ApiPropertyOptional()
  @Type(() => BomItemDto)
  @IsOptional()
  items: BomItemDto[];

  @ApiProperty()
  @IsOptional()
  quantity: number;
}
