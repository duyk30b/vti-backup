import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsOptional, IsString } from 'class-validator';

export class ConfirmRejectBomVersionRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  bomVersionId: number;

  @ApiProperty()
  @IsString()
  @IsOptional()
  note: string;
}
