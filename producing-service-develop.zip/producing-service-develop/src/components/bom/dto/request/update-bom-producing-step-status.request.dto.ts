import { BaseDto } from "@core/dto/base.dto";
import { IsInt, IsNotEmpty } from "class-validator";

export class UpdateBomProducingStepStatusRequestDto extends BaseDto {
  
  @IsInt()
  @IsNotEmpty()
  id: number;

  @IsInt()
  @IsNotEmpty()
  status: number;

}