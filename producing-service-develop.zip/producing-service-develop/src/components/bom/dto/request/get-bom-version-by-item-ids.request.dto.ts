import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { ArrayNotEmpty, IsBoolean, IsEnum, IsOptional } from 'class-validator';

export class GetBomVersionByItemIdsRequestDto extends BaseDto {
  @ApiProperty()
  @Transform(({ value }) => {
    if (typeof value === 'string') {
      return JSON.parse(value);
    }
    return value;
  })
  @ArrayNotEmpty()
  itemIds: number[];

  @ApiProperty()
  @IsOptional()
  @IsEnum(['0', '1'])
  isLatestVersion: string;
}
