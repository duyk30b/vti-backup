import { IsNotEmpty, IsInt } from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';
export class UpdateBomStatusRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsInt()
  id: number;
}
