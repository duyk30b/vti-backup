import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsOptional } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';

export class GetBomProducingStepRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @IsNumber()
  bomId: number;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  itemId: number;
}
