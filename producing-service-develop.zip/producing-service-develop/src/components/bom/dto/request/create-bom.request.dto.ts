import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type, plainToInstance } from 'class-transformer';
import {
  ArrayUnique,
  IsArray,
  IsInt,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  IsPositive,
  ValidateNested,
  Max,
  Min,
  IsIn,
  IsNotEmpty,
} from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { File } from '@core/dto/request/file.request.dto';
import { MIMETYPE_FILE_UPLOAD_BOM } from '@components/file/constant/file-upload.constant';
import { ErrorMessageEnum } from '@constant/error-message.enum';

class FileUpload extends File {
  @IsIn(MIMETYPE_FILE_UPLOAD_BOM, {
    // message: ErrorMessageEnum.MIMETYPE_FILE,
  })
  mimetype: string;
}

class ProducingStep {
  @ApiProperty()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsNumber()
  @IsOptional()
  @Transform((v) => +v.value)
  quantity: number;
}

class ProducingStepMachine extends ProducingStep {
  @ApiProperty()
  @IsNumber()
  @Min(0)
  @Max(100)
  @Transform((v) => +v.value)
  quantity: number;
}

class BomProducingStepDetail {
  @ApiProperty({ description: 'id nvl' })
  @IsInt()
  id: number;

  @ApiProperty()
  @ValidateNested()
  @ArrayUnique((e: ProducingStep) => e.id)
  @IsArray()
  @Type(() => ProducingStep)
  producingSteps: ProducingStep[];
}

class UserProducingStep {
  @ApiProperty()
  @IsInt()
  @IsOptional()
  id: number;

  @ApiProperty()
  @ValidateNested()
  @ArrayUnique((e: ProducingStep) => e.id)
  @IsArray()
  @Type(() => ProducingStep)
  producingSteps: ProducingStep[];
}

class MachineProducingStep {
  @ApiProperty()
  @IsString()
  @MaxLength(100)
  name: string;

  @ApiProperty()
  @IsString()
  @MaxLength(50)
  unit: string;

  @ApiProperty()
  @ValidateNested()
  @ArrayUnique((e: ProducingStepMachine) => e.id)
  @IsArray()
  @Type(() => ProducingStepMachine)
  producingSteps: ProducingStepMachine[];
}

export class OldFile {
  id: string;
  filNameRaw: string;
  fileUrl: string;
}

export class CreateBomRequestDto {
  @ApiProperty()
  @MaxLength(255)
  @IsString()
  name: string;

  @ApiProperty()
  @MaxLength(20)
  @IsString()
  code: string;

  @ApiPropertyOptional()
  @MaxLength(255)
  @IsOptional()
  description: string;

  @ApiProperty()
  @IsInt()
  routingId: number;

  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsInt()
  @IsOptional()
  itemVersionId: number;

  @ApiProperty()
  @IsNumber()
  @Transform((v) => +v.value)
  quantity: number;

  @ApiProperty()
  @IsNumber()
  @IsOptional()
  @Max(100000)
  @Transform((v) => +v.value)
  klNumber: number;

  @ApiProperty()
  @IsNumber()
  @IsOptional()
  @Max(100)
  @Transform((v) => +v.value)
  ttNumber: number;

  @ApiProperty({ description: 'bom version id cần update' })
  @IsOptional()
  @IsInt()
  bomVersionId: number;

  @ApiProperty()
  @MaxLength(20)
  @IsString()
  @IsOptional()
  bomVersionCode: string;

  @ApiProperty()
  @IsOptional()
  @IsArray()
  fileIds: string[];

  @ApiProperty()
  @IsNotEmpty()
  @ValidateNested()
  @ArrayUnique((e: BomItemDto) => e.id)
  @IsArray()
  @Type(() => BomItemDto)
  bomItems: BomItemDto[];

  @ApiProperty()
  @ValidateNested()
  @ArrayUnique((e: BomProducingStepDetail) => e.id)
  @IsArray()
  @Type(() => BomProducingStepDetail)
  bomProducingStepDetails: BomProducingStepDetail[];

  @ApiProperty()
  @ValidateNested()
  @IsArray()
  @Type(() => UserProducingStep)
  userProducingSteps: UserProducingStep[];

  @ApiProperty()
  @ValidateNested()
  @ArrayUnique((e: MachineProducingStep) => e.name)
  @IsArray()
  @Type(() => MachineProducingStep)
  machineProducingSteps: MachineProducingStep[];

  @ApiProperty()
  @IsOptional()
  @Type(() => OldFile)
  files: OldFile[];
}

export class BomItemDto {
  @ApiProperty()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  itemVersionId: number;

  @ApiProperty()
  @IsNumber()
  @IsPositive()
  @Transform((v) => +v.value)
  quantity: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  bomVersionId: number;

  @ApiProperty()
  @IsInt()
  @IsOptional()
  bomVersionStatus: number;

  @ApiProperty()
  @IsString()
  @IsOptional()
  itemTypeCode: string;
}

export class CreateBomFormDataDto extends BaseDto {
  @ApiProperty({
    description: `
    {
      "name": "bomItem7",
      "code": "BOMITEM7",
      "description": "BOMITEM7",
      "routingId": 2,
      "itemId": 7,
      "itemVersionId": 7,
      "quantity": 91,
      "klNumber": 91,
      "ttNumber": 91,
      "bomItems": [
          {
              "id": 8,
              "bomVersionId": 7,
              "quantity": 5
          },
          {
              "id": 6,
              "bomVersionId": null,
              "quantity": 5
          }
      ],
      "bomProducingStepDetails": [
          {
              "id": 6,
              "quantity": 5,
              "producingSteps": [
                  {
                      "id": 2,
                      "quantity": 3
                  },
                  {
                      "id": 3,
                      "quantity": 2
                  }
              ]
          }
      ],
      "userProducingSteps": [
          {
              "id": 1,
              "producingSteps": [
                  {
                      "id": 2,
                      "quantity": 3
                  },
                  {
                      "id": 3,
                      "quantity": 2
                  }
              ]
          }
      ],
      "machineProducingSteps": [
          {
              "name": "may 1",
              "producingSteps": [
                  {
                      "id": 2,
                      "quantity": 3
                  },
                  {
                      "id": 3,
                      "quantity": 2
                  }
              ]
          }
      ]
    }
    `,
  })
  @ValidateNested({ each: true })
  @Transform((v) => {
    return plainToInstance(CreateBomRequestDto, JSON.parse(v.value));
  })
  @Type(() => CreateBomRequestDto)
  data: CreateBomRequestDto;

  @ApiProperty()
  @Type(() => FileUpload)
  files: FileUpload[];
}
