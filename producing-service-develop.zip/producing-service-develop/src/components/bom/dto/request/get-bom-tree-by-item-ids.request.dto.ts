import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsNotEmpty, IsOptional } from 'class-validator';

export class GetBomTreeByItemIds extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  itemIds: number[];

  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  bomVersionIds: number[];

  @ApiProperty()
  @IsOptional()
  factoryId: number;
}
