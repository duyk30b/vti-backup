import { ItemResponseDto } from '@components/item/dto/response/item.dto.response';
import { ProducingStepResponseDto } from '@components/producing-step/dto/response/producing-step.response.dto';
import { RoutingResponseAbstractDto } from '@components/routing/dto/response/routing.response.abstract.dto';
import { UserResponseDto } from '@components/user/dto/response/user.dto.response';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

export class BomDetailDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  itemName: number;

  @ApiProperty()
  @Expose()
  itemCode: string;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  quantity: number;

  @ApiProperty({ type: ItemResponseDto })
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;
}

export class ProducingStepData { 
  producingStep: ProducingStepResponseDto;
  quantity: number;
  status: number;
}

export class BomMaterialDetail {

  @ApiProperty({ type: BomDetailDto })
  @Type(() => BomDetailDto)
  @Expose()
  bomDetail: BomDetailDto;

  item: ItemResponseDto;

  @ApiProperty({ type: ProducingStepData })
  @Type(() => ProducingStepData)
  @Expose()
  producingStepData: ProducingStepData[];
}

export class BomProducingStepStructResponseDto {
  @ApiProperty({ type: BomMaterialDetail })
  @Type(() => BomMaterialDetail)
  @Expose()
  materialDetails: BomMaterialDetail[];
}
