import { FileInforResponeDto } from '@components/file/dto/file-infor.respone';
import { ItemResponseDto } from '@components/item/dto/response/item.dto.response';
import { RoutingResponseAbstractDto } from '@components/routing/dto/response/routing.response.abstract.dto';
import { UserResponseDto } from '@components/user/dto/response/user.dto.response';
import { BasicResponseDto } from '@core/dto/response/basic.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { PagingResponse } from '@utils/paging.response';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class UserResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  username: string;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  fullName: string;
}

export class BomVersion extends BasicResponseDto {
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  approverAt: Date;
}

class ProducingStep extends BasicResponseDto {}
class BomDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  itemName: number;

  @ApiProperty()
  @Expose()
  itemCode: string;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  quantity: number;

  @ApiProperty({ type: ItemResponseDto })
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;
}
class BomProducingStepDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  bomVersionId: number;

  @ApiProperty()
  @Expose()
  producingStepId: string;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  quantity: number;

  @ApiProperty({ type: ItemResponseDto })
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;

  @ApiProperty({ type: BomVersion })
  @Type(() => BomVersion)
  @Expose()
  bomVersion: BomVersion;

  @ApiProperty({ type: ProducingStep })
  @Type(() => ProducingStep)
  @Expose()
  producingStep: ProducingStep;
}
class BomUserProducingStepDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  userId: number;

  @ApiProperty()
  @Expose()
  bomVersionId: number;

  @ApiProperty()
  @Expose()
  producingStepId: string;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  quantity: number;

  @ApiProperty({ type: BomVersion })
  @Type(() => BomVersion)
  @Expose()
  bomVersion: BomVersion;

  @ApiProperty({ type: ProducingStep })
  @Type(() => ProducingStep)
  @Expose()
  producingStep: ProducingStep;
}
class BomMachineProducingStepDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  unit: string;

  @ApiProperty()
  @Expose()
  bomVersionId: number;

  @ApiProperty()
  @Expose()
  producingStepId: number;

  @ApiProperty()
  @Expose()
  @Type(() => Number)
  quantity: number;

  @ApiProperty({ type: BomVersion })
  @Type(() => BomVersion)
  @Expose()
  bomVersion: BomVersion;

  @ApiProperty({ type: ProducingStep })
  @Type(() => ProducingStep)
  @Expose()
  producingStep: ProducingStep;
}

export class BomResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  confirmedVersionQuantity: number;

  @ApiProperty()
  @Expose()
  klNumber: number;

  @ApiProperty()
  @Expose()
  ttNumber: number;

  @ApiProperty()
  @Expose()
  level: number;

  @ApiProperty()
  @Expose()
  status: string;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty()
  @Expose()
  approvedAt: Date;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty({ type: BomResponseDto })
  @Expose()
  @Type(() => BomResponseDto)
  parentBom: BomResponseDto;

  @ApiProperty()
  @Expose()
  routingId: number;

  @ApiProperty({ type: RoutingResponseAbstractDto })
  @Expose()
  @Type(() => RoutingResponseAbstractDto)
  routing: RoutingResponseAbstractDto;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  bomVersionId: number;

  @ApiProperty({ type: ItemResponseDto })
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;

  @ApiProperty()
  @Expose()
  approverId: number;

  @ApiProperty({ type: UserResponseDto })
  @Expose()
  @Type(() => UserResponseDto)
  approver: UserResponseDto;

  @ApiProperty({ type: BomDetail })
  @Expose()
  @Type(() => BomDetail)
  bomDetails: BomDetail[];

  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  producingSteps: BasicResponseDto[];

  @ApiProperty({ type: BomProducingStepDetail })
  @Expose()
  @Type(() => BomProducingStepDetail)
  bomProducingStepDetails: BomProducingStepDetail[];

  @ApiProperty({ type: BomUserProducingStepDetail })
  @Expose()
  @Type(() => BomUserProducingStepDetail)
  bomUserProducingStepDetails: BomUserProducingStepDetail[];

  @ApiProperty({ type: BomMachineProducingStepDetail })
  @Expose()
  @Type(() => BomMachineProducingStepDetail)
  bomMachineProducingStepDetails: BomMachineProducingStepDetail[];

  @ApiProperty({ type: BomResponseDto })
  @Expose()
  @Type(() => BomResponseDto)
  subBoms: BomResponseDto[];

  @ApiProperty({ type: UserResponse })
  @Expose()
  @Type(() => UserResponse)
  createdBy: UserResponse;

  @ApiProperty({ type: BomVersion })
  @Expose()
  @Type(() => BomVersion)
  bomVersions: BomVersion[];

  @ApiProperty({ type: BomVersion })
  @Expose()
  @Type(() => BomVersion)
  bomVersion: BomVersion;

  @ApiProperty({ type: FileInforResponeDto })
  @Expose()
  @Type(() => FileInforResponeDto)
  files: FileInforResponeDto[];
}

export class DataListBom extends PagingResponse {
  @ApiProperty({ type: BomResponseDto, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => BomResponseDto)
  items: BomResponseDto[];
}

export class GetListBomResponseDto extends SuccessResponse {
  @ApiProperty({
    type: DataListBom,
  })
  @Expose()
  @Type(() => DataListBom)
  data: DataListBom;
}
