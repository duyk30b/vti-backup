import { BasicResponseDto } from '@core/dto/response/basic.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class BomVersionResponseDto extends BasicResponseDto {}

export class GetBomVersionByItemIdsResponseDto {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  @Type(() => BomVersionResponseDto)
  bomVersions: BomVersionResponseDto[];

  @ApiProperty()
  @Expose()
  @Type(() => BomVersionResponseDto)
  latestVersion: BomVersionResponseDto;
}
