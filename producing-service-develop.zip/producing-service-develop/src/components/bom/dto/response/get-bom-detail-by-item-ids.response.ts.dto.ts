import { BasicResponseDto } from '@core/dto/response/basic.response.dto';

export class GetBomDetailByItemIdsResponseDto extends BasicResponseDto { }
