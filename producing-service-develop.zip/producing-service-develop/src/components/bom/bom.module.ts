import { BomMachineProducingStepDetailEntity } from '@entities/bom/bom-machine-producing-step-details.entity';
import { BomUserProducingStepDetailEntity } from '@entities/bom/bom-user-producing-step-details.entity';
import { ProducingStepEntity } from '@entities/producing-step/producing-step.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BomEntity } from '@entities/bom/boms.entity';
import { BomDetailEntity } from '@entities/bom/bom-details.entity';
import { ItemModule } from '@components/item/item.module';
import { ItemService } from '@components/item/item.service';
import { BomDetailRepository } from '@repositories/bom/bom-detail.repository';
import { BomRepository } from '@repositories/bom/bom.repository';
import { BomService } from '@components/bom/bom.service';
import { BomController } from './bom.controller';
import { BoqDetail } from '@entities/boq/boq-details.entity';
import { RoutingService } from '@components/routing/routing.service';
import { RoutingRepository } from '@repositories/routing.repository';
import { RoutingEntity } from '@entities/routing/routing.entity';
import { UserModule } from '@components/user/user.module';
import { RoutingModule } from '@components/routing/routing.module';
import { ProducingStepRepository } from '@repositories/produce/producing-step.repository';
import { BomProducingStepDetailEntity } from '@entities/bom/bom-producing-steps.entity';
import { BomProducingStepDetailsRepository } from '@repositories/bom/bom-producing-step-details.repository';
import { WorkCenterRepository } from '@repositories/work-center/work-center.repository';
import { WorkCenterEntity } from '@entities/work-center/work-center.entity';
import { ConfigService } from '@config/config.service';
import { ClientProxyFactory } from '@nestjs/microservices';
import { BomVersionRepository } from '@repositories/bom/bom-version.repository';
import { BomUserProducingStepDetailRepository } from '@repositories/bom/bom-user-producing-step-detail.repository';
import { BomMachineProducingStepDetailRepository } from '@repositories/bom/bom-machine-producing-step-detail.repository';
import { BomVersionEntity } from '@entities/bom/bom-versions.entity';
import { FileService } from '@components/file/file.service';
import { FileRepository } from '@repositories/file/file.repository';
import { FileEntity } from '@entities/file/file.entity';
// import { NotificationModule } from '@components/notification/notification.module';
// import { NotificationService } from '@components/notification/notification.service';
// import { BomListener } from './listeners/bom.notification.listener';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      BomEntity,
      BomDetailEntity,
      BomProducingStepDetailEntity,
      BoqDetail,
      RoutingEntity,
      ProducingStepEntity,
      WorkCenterEntity,
      BomVersionEntity,
      BomUserProducingStepDetailEntity,
      BomMachineProducingStepDetailEntity,
      FileEntity,
    ]),
    ItemModule,
    UserModule,
    RoutingModule,
    // NotificationModule,
  ],
  providers: [
    {
      provide: 'BomRepositoryInterface',
      useClass: BomRepository,
    },
    {
      provide: 'BomProducingStepDetailsRepositoryInterface',
      useClass: BomProducingStepDetailsRepository,
    },
    {
      provide: 'BomDetailRepositoryInterface',
      useClass: BomDetailRepository,
    },
    {
      provide: 'BomVersionRepositoryInterface',
      useClass: BomVersionRepository,
    },
    {
      provide: 'BomUserProducingStepDetailRepositoryInterface',
      useClass: BomUserProducingStepDetailRepository,
    },
    {
      provide: 'BomMachineProducingStepDetailRepositoryInterface',
      useClass: BomMachineProducingStepDetailRepository,
    },
    {
      provide: 'BomServiceInterface',
      useClass: BomService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'RoutingServiceInterface',
      useClass: RoutingService,
    },
    {
      provide: 'RoutingRepositoryInterface',
      useClass: RoutingRepository,
    },
    {
      provide: 'ProducingStepRepositoryInterface',
      useClass: ProducingStepRepository,
    },
    {
      provide: 'WorkCenterRepositoryInterface',
      useClass: WorkCenterRepository,
    },
    {
      provide: 'FileRepositoryInterface',
      useClass: FileRepository,
    },
    {
      provide: 'FileServiceInterface',
      useClass: FileService,
    },
    //{
    //   provide: 'NotificationServiceInterface',
    //   useClass: NotificationService,
    // },
    //{
    //  provide: 'PLAN_SERVICE',
    //  useFactory: (configService: ConfigService) => {
    //    const planServiceOptions = configService.get('planService');
    //    return ClientProxyFactory.create(planServiceOptions);
    //  },
    //  inject: [ConfigService],
    //},
    ConfigService,
    // BomListener,
  ],
  controllers: [BomController],
  exports: [
    {
      provide: 'BomServiceInterface',
      useClass: BomService,
    },
    {
      provide: 'BomRepositoryInterface',
      useClass: BomRepository,
    },
    {
      provide: 'BomProducingStepDetailsRepositoryInterface',
      useClass: BomProducingStepDetailsRepository,
    },
    {
      provide: 'BomUserProducingStepDetailRepositoryInterface',
      useClass: BomUserProducingStepDetailRepository,
    },
    {
      provide: 'BomDetailRepositoryInterface',
      useClass: BomDetailRepository,
    },
    {
      provide: 'BomMachineProducingStepDetailRepositoryInterface',
      useClass: BomMachineProducingStepDetailRepository,
    },
    {
      provide: 'RoutingServiceInterface',
      useClass: RoutingService,
    },
    {
      provide: 'RoutingRepositoryInterface',
      useClass: RoutingRepository,
    },
    {
      provide: 'ProducingStepRepositoryInterface',
      useClass: ProducingStepRepository,
    },
    {
      provide: 'WorkCenterRepositoryInterface',
      useClass: WorkCenterRepository,
    },
  ],
})
export class BomModule {}
