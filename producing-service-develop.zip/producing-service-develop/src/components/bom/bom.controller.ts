import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { BomServiceInterface } from '@components/bom/interface/bom.service.interface';
import { MessagePattern } from '@nestjs/microservices';
import { isEmpty } from 'lodash';
import { UpdateBomFormDataDto } from '@components/bom/dto/request/update-bom.request.dto';
import { CreateBomFormDataDto } from '@components/bom/dto/request/create-bom.request.dto';
import { DeleteBomRequestDto } from './dto/request/delete-bom.request.dto';
import { GetBomDetailRequestDto } from './dto/request/get-bom-detail.request.dto';
import { GetBomListRequestDto } from './dto/request/get-bom-list.request.dto';
import { UpdateBomStatusRequestDto } from './dto/request/update-bom-status-request.dto';
import { GetBomByItemIdRequestDto } from './dto/request/get-bom-by-item-id.request.dto';
import { GetBomStructRequestDto } from './dto/request/get-bom-struct.request.dto';
import { CreateBomProducingStepRequestDto } from './dto/request/create-bom-producing-step-detail.request.dto';
import { GetBomProducingStepListRequestDto } from './dto/request/get-bom-producing-step-list.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CREATE_BOM_PERMISSION,
  UPDATE_BOM_PERMISSION,
  DELETE_BOM_PERMISSION,
  DETAIL_BOM_PERMISSION,
  LIST_BOM_PERMISSION,
  CONFIRM_BOM_PERMISSION,
  REJECT_BOM_PERMISSION,
  CONFIRM_VERSION_BOM_PERMISSION,
  REJECT_VERSION_BOM_PERMISSION,
  CLONE_VERSION_BOM_PERMISSION,
} from '@utils/permissions/bom';
import {
  CREATE_BOM_PRODUCING_STEP_PERMISSION,
  UPDATE_BOM_PRODUCING_STEP_PERMISSION,
  DELETE_BOM_PRODUCING_STEP_PERMISSION,
  DETAIL_BOM_PRODUCING_STEP_PERMISSION,
  LIST_BOM_PRODUCING_STEP_PERMISSION,
  CONFIRM_BOM_PRODUCING_STEP_PERMISSION,
  REJECT_BOM_PRODUCING_STEP_PERMISSION,
} from '@utils/permissions/bom-producing-step';
import { generatePermissionCodes } from '@utils/common';
import { GetBomByItemIdsRequestDto } from './dto/request/get-bom-by-item-ids.request.dto';
import { GetBomTreeByItemIds } from './dto/request/get-bom-tree-by-item-ids.request.dto';
import { GetMaterialBomByIdsRequestDto } from './dto/request/get-material-bom-by-ids.request.dto';
import { ApiConsumes, ApiOperation, ApiResponse } from '@nestjs/swagger';
import {
  BomResponseDto,
  GetListBomResponseDto,
} from './dto/response/bom.response.dto';
import { BomProducingStepStructResponseDto } from './dto/response/bom-producing-step.response.dto';
import { ConfirmRejectBomVersionRequestDto } from './dto/request/confirm-reject-bom-version.request.dto';
import { GetListBomVersionByBomVersionIdsRequestDto } from './dto/request/get-list-bom-version-by-bom-version-id.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { GetBomVersionByBomIdRequestDto } from './dto/request/get-list-bom-version-by-bom-id.request.dto';
import { GetBomDetailByItemIdsRequestDto } from './dto/request/get-bom-detail-by-item-ids.request.dto';
import { PaginationQuery } from '@utils/pagination.query';
import { NATS_PRODUCE } from '@config/nats.config';
import { GetBomVersionByItemIdsRequestDto } from './dto/request/get-bom-version-by-item-ids.request.dto';
const PERMISSION_CREATE_BOM = generatePermissionCodes([
  CREATE_BOM_PRODUCING_STEP_PERMISSION.code,
  UPDATE_BOM_PRODUCING_STEP_PERMISSION.code,
]);
const PERMISSION_CONFIRM_BOM = generatePermissionCodes([
  CONFIRM_BOM_PRODUCING_STEP_PERMISSION.code,
  REJECT_BOM_PRODUCING_STEP_PERMISSION.code,
]);
@Controller('boms')
export class BomController {
  constructor(
    @Inject('BomServiceInterface')
    private readonly bomService: BomServiceInterface,
  ) {}

  @PermissionCode(CREATE_BOM_PERMISSION.code)
  @Post('create')
  @ApiOperation({
    tags: ['Bom'],
    summary: 'Create new bom',
    description: 'Tạo 1 bom mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: SuccessResponse,
  })
  @ApiConsumes('multipart/form-data')
  @MessagePattern(`${NATS_PRODUCE}.create_bom`)
  public async create(@Body() payload: CreateBomFormDataDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.bomService.create(request);
  }

  @PermissionCode(UPDATE_BOM_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Bom'],
    summary: 'Update bom',
    description: 'Cập nhật thông tin bom',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  @ApiConsumes('multipart/form-data')
  @MessagePattern(`${NATS_PRODUCE}.update_bom`)
  public async update(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateBomFormDataDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.bomService.update({
      ...request,
      data: {
        ...request.data,
        id: id,
      },
    });
  }

  @PermissionCode(DELETE_BOM_PERMISSION.code)
  @Delete(':id')
  @ApiOperation({
    tags: ['Bom'],
    summary: 'Delete bom (soft delete)',
    description: 'Xóa BOM',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  @MessagePattern(`${NATS_PRODUCE}.delete_bom`)
  public async delete(@Param('id', new ParseIntPipe()) id): Promise<any> {
    return await this.bomService.delete({ id: id } as DeleteBomRequestDto);
  }

  /**
   * Get bom detail
   * @param request GetBomDetailRequest
   * @returns
   */
  @PermissionCode(DETAIL_BOM_PERMISSION.code)
  @Get(':id')
  @ApiOperation({
    tags: ['Bom'],
    summary: 'Bom Detail',
    description: 'Chi tiết BOM',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: BomResponseDto,
  })
  // @MessagePattern(`${NATS_ITEM}.get_bom_detail`)
  public async getDetail(
    @Param('id', new ParseIntPipe()) id: number,
    @Query() payload: GetBomDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bomService.getDetail({
      ...request,
      id,
    });
  }

  /**
   * Get bom detail
   * @param request GetBomDetailRequest
   * @returns
   */
  @Get('/structures')
  @ApiOperation({
    tags: ['Bom'],
    summary: 'Bom Detail',
    description: 'Chi tiết BOM',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: [BomResponseDto],
  })
  // @MessagePattern('get_bom_structure')
  public async getBomStruct(
    @Query() query: GetBomStructRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bomService.getBomStruct(request);
  }

  /**
   * Get bom list
   * @param request GetBomListRequest
   * @returns
   */
  @PermissionCode(LIST_BOM_PERMISSION.code)
  @Get('list')
  @ApiOperation({
    tags: ['Boms'],
    summary: 'List Bom',
    description: 'Danh sách BOM',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: GetListBomResponseDto,
  })
  public async getList(@Query() payload: GetBomListRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.bomService.getList(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.get_bom_list`)
  public async getListTCP(@Body() payload: GetBomListRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.bomService.getList(request);
  }

  /**
   * Reject
   * @param payload
   * @returns
   */
  @PermissionCode(REJECT_BOM_PERMISSION.code)
  @Put(':id/reject')
  @ApiOperation({
    tags: ['Produces', 'Bom'],
    summary: 'Reject Bom',
    description: 'Từ chối BOM',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: BomResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.reject_bom`)
  public async reject(@Param('id', new ParseIntPipe()) id): Promise<any> {
    return await this.bomService.reject({
      id: id,
    } as UpdateBomStatusRequestDto);
  }

  /**
   * Confirm
   * @param payload
   * @returns
   */
  @PermissionCode(CONFIRM_BOM_PERMISSION.code)
  @Put(':id/confirm')
  @ApiOperation({
    tags: ['Produces', 'Bom'],
    summary: 'Confirm Bom',
    description: 'Xác nhận BOM',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: BomResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.confirm_bom`)
  public async confirm(
    @Param() payload: UpdateBomStatusRequestDto,
  ): Promise<any> {
    const { request } = payload;
    return await this.bomService.confirm(request);
  }

  /**
   * Get bom detail
   * @param request GetBomDetailRequest
   * @returns
   */
  @Get('get-by-item/:itemId')
  @ApiOperation({
    tags: ['Bom', 'Item'],
    summary: 'Get Bom By Item Id',
    description: 'Lấy thông tin Bom theo mã item',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: BomResponseDto,
  })
  // @MessagePattern('get_bom_by_item_id')
  public async getBomByItemId(
    @Param('itemId', new ParseIntPipe()) itemId: number,
  ): Promise<any> {
    return this.bomService.getBomByItemId({
      itemId: itemId,
    } as GetBomByItemIdRequestDto);
  }

  @PermissionCode(LIST_BOM_PRODUCING_STEP_PERMISSION.code)
  @Get('bom-producing-steps/list')
  @ApiOperation({
    tags: ['Bom'],
    summary: 'Bom Detail',
    description: 'Chi tiết BOM',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: [BomProducingStepStructResponseDto],
  })
  @MessagePattern(`${NATS_PRODUCE}.get_list_bom_producing_step_details`)
  public async getListBomProducingStepDetailsByBomIdOrItemId(
    @Query() payload: GetBomProducingStepListRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return this.bomService.getListBomProducingStep(request);
  }

  @PermissionCode(DETAIL_BOM_PRODUCING_STEP_PERMISSION.code)
  @Get('bom-producing-steps/:bomId')
  @ApiOperation({
    tags: ['Bom'],
    summary: 'Bom Detail',
    description: 'Chi tiết BOM',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: [BomProducingStepStructResponseDto],
  })
  @MessagePattern(`${NATS_PRODUCE}.get_bom_producing_step_details`)
  public async getBomProducingStepDetailsByBomIdOrItemId(
    @Param('bomId', new ParseIntPipe()) bomId: number,
  ): Promise<any> {
    return this.bomService.getBomProducingStep({ bomId: bomId });
  }

  @PermissionCode(PERMISSION_CREATE_BOM)
  @Put('bom-producing-steps')
  @ApiOperation({
    tags: ['Bom'],
    summary: 'Bom Detail',
    description: 'Chi tiết BOM',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: [BomProducingStepStructResponseDto],
  })
  @MessagePattern(`${NATS_PRODUCE}.update_bom_producing_step_details`)
  public async updateBomProducingStep(
    @Body() payload: CreateBomProducingStepRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return this.bomService.createOrUpdateBomProducingStep(request);
  }

  @PermissionCode(PERMISSION_CONFIRM_BOM)
  @Put('bom-producing-steps/:id/status/:status')
  @ApiOperation({
    tags: ['Bom'],
    summary: 'Bom Detail',
    description: 'Chi tiết BOM',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: [BomProducingStepStructResponseDto],
  })
  @MessagePattern(`${NATS_PRODUCE}.update_bom_producing_step_status`)
  public async updateBomProducingStepStatus(
    @Param('id', new ParseIntPipe()) id: number,
    @Param('status', new ParseIntPipe()) status: number,
  ): Promise<any> {
    return this.bomService.updateBomProducingStepStatus(id, status);
  }

  @PermissionCode(DELETE_BOM_PRODUCING_STEP_PERMISSION.code)
  @Delete('bom-producing-steps/:id')
  @ApiOperation({
    tags: ['Bom'],
    summary: 'Bom Detail',
    description: '',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: [BomProducingStepStructResponseDto],
  })
  @MessagePattern(`${NATS_PRODUCE}.delete_bom_producing_step`)
  public async deleteBomProducingStep(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    return this.bomService.deleteBomProducingStep(id);
  }

  @Post('get-bom-tree-by-items')
  public async getBomTreeByItemIds(
    @Body() payload: GetBomTreeByItemIds,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return this.bomService.getBomTreeByItemIds(request);
  }
  // @TODO: remove when refactor done
  @MessagePattern(`${NATS_PRODUCE}.get_boms_tree_by_item_ids`)
  public async getBomTreeByItemIdsTcp(
    @Body() payload: GetBomTreeByItemIds,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return this.bomService.getBomTreeByItemIds(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.get_bom_by_item_ids`)
  public async getBomByItemIds(
    @Body() payload: GetBomByItemIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return this.bomService.getBomByItemIds(request);
  }
  // @TODO: remove when refactor done
  @MessagePattern(`${NATS_PRODUCE}.get_bom_by_item_ids`)
  public async getBomByItemIdsTcp(
    @Body() payload: GetBomByItemIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return this.bomService.getBomByItemIds(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.get_material_bom_by_ids`)
  public async getMaterialBomByIds(
    @Body() payload: GetMaterialBomByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return this.bomService.getMaterialBomByIds(request);
  }

  // @TODO: remove when refactor done
  @MessagePattern(`${NATS_PRODUCE}.get_material_bom_by_ids`)
  public async getMaterialBomByIdsTcp(
    @Body() payload: GetMaterialBomByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return this.bomService.getMaterialBomByIds(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.get_bom_structure`)
  public async getBomStructTcp(
    @Body() payload: GetBomStructRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bomService.getBomStruct(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.get_bom_by_item_id`)
  public async getBomByItemIdTcp(
    @Param('itemId', new ParseIntPipe()) itemId: number,
    @Body() payload: GetBomByItemIdRequestDto,
  ): Promise<any> {
    const { request } = payload;
    return this.bomService.getBomByItemId(request);
  }

  @PermissionCode(DETAIL_BOM_PERMISSION.code)
  @MessagePattern(`${NATS_PRODUCE}.get_bom_detail`)
  public async getDetailTcp(
    @Body() payload: GetBomDetailRequestDto,
  ): Promise<any> {
    const { request } = payload;
    return await this.bomService.getDetail(request);
  }

  @PermissionCode(REJECT_VERSION_BOM_PERMISSION.code)
  @Put(':id/bom-versions/:bomVersionId/reject')
  @ApiOperation({
    tags: ['Produces', 'Bom'],
    summary: 'Reject Bom Version',
    description: 'Từ chối BOM Version',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: BomResponseDto,
  })
  public async rejectBomVersion(
    @Param('id', new ParseIntPipe()) id,
    @Param('bomVersionId', new ParseIntPipe()) bomVersionId,
    @Body() payload: ConfirmRejectBomVersionRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bomService.rejectBomVersion({
      ...request,
      id,
      bomVersionId,
    });
  }

  @PermissionCode(CONFIRM_VERSION_BOM_PERMISSION.code)
  @Put(':id/bom-versions/:bomVersionId/confirm')
  @ApiOperation({
    tags: ['Produces', 'Bom'],
    summary: 'Confirm Bom Version',
    description: 'Xác nhận BOM Version',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: BomResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.confirm_bom`)
  public async confirmBomVersion(
    @Param('id', new ParseIntPipe()) id,
    @Param('bomVersionId', new ParseIntPipe()) bomVersionId,
    @Body() payload: ConfirmRejectBomVersionRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bomService.confirmBomVersion({
      ...request,
      id,
      bomVersionId,
    });
  }

  @MessagePattern(`${NATS_PRODUCE}.get_list_bom_version_by_bom_version_ids`)
  public async getListBomVersionByBomVersionIdsTcp(
    @Body() payload: GetListBomVersionByBomVersionIdsRequestDto,
  ): Promise<any> {
    const { request } = payload;
    return await this.bomService.getListBomVersionByBomVersionIds(request);
  }

  @Get('/bom-versions/item/:itemId')
  @ApiOperation({
    tags: ['Produces', 'Bom'],
    summary: 'Get Bom Version',
    description: 'Get BOM Version By itemId',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: BomResponseDto,
  })
  public async getBomVersionByItemId(
    @Param('itemId', new ParseIntPipe()) itemId,
    @Query() payload: PaginationQuery,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bomService.getBomVersionByItemId(itemId, request);
  }

  @Get(':bomId/bom-versions')
  @ApiOperation({
    tags: ['Bom'],
    summary: 'List Bom Version By Bom Id',
    description: 'List Bom Version By Bom Id',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: null,
  })
  public async getListBomVersionByBomId(
    @Param('bomId', new ParseIntPipe()) bomId: number,
    @Query() payload: GetBomVersionByBomIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bomService.getListBomVersionByBomId({
      ...request,
      bomId,
    });
  }

  @MessagePattern(`${NATS_PRODUCE}.get_bom_detail_by_item_ids`)
  public async getBomDetailByItemIds(
    @Body() payload: GetBomDetailByItemIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return this.bomService.getBomDetailByItemIds(request);
  }

  @Get('/structures/producing-steps')
  @ApiOperation({
    tags: ['Bom'],
    summary: 'Bom Detail',
    description: 'Chi tiết BOM',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: [BomResponseDto],
  })
  // @MessagePattern('get_bom_structure')
  public async getBomStructProducingStep(
    @Query() query: GetBomStructRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.bomService.getBomStructProducingStep(request);
  }

  @PermissionCode(CLONE_VERSION_BOM_PERMISSION.code)
  @Post(':bomId/bom-versions/clone')
  @ApiOperation({
    tags: ['Bom'],
    summary: 'Clone bom version',
    description: 'Clone thông tin phiên bản bom',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: SuccessResponse,
  })
  @ApiConsumes('multipart/form-data')
  @MessagePattern(`${NATS_PRODUCE}.update_bom_version`)
  public async cloneBomVersion(
    @Param('bomId', new ParseIntPipe()) bomId,
    @Body() payload: UpdateBomFormDataDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.bomService.cloneBomVersion({
      ...request,
      data: {
        ...request.data,
        id: bomId,
      },
    });
  }

  @ApiOperation({
    tags: ['Bom', 'Bom version'],
    summary: 'Get bom version by item ids ',
  })
  @ApiResponse({
    status: 200,
    description: 'get successfully',
  })
  @MessagePattern(`${NATS_PRODUCE}.get_bom_version_by_item_ids`)
  public async getBomVersionByItemIdsNAT(
    @Body() payload: GetBomVersionByItemIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.bomService.getBomVersionByItemIds(request);
  }

  @Get('/bom-versions/items')
  @ApiOperation({
    tags: ['Bom', 'Bom version'],
    summary: 'Get bom version by item ids ',
  })
  @ApiResponse({
    status: 200,
    description: 'get successfully',
  })
  public async getBomVersionByItemIds(
    @Query() query: GetBomVersionByItemIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.bomService.getBomVersionByItemIds(request);
  }
}
