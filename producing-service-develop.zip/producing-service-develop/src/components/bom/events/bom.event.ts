export class BomEvent {
  constructor({ id, name, code, type }) {
    this.id = id;
    this.name = name;
    this.code = code;
    this.type = type;
  }
  id: number;
  name: string;
  code: string;
  type: string;
}
