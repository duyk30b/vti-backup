export enum BomProducingStepStatusEnum {
  EMPTY = -1,
  CREATED = 0,
  CONFIRMED = 1,
  REJECTED = 2,
}

export const BOM_PRODUCING_STEP_STATUS_CHANGE_RULE = {
  [BomProducingStepStatusEnum.CONFIRMED]: [BomProducingStepStatusEnum.CREATED],
  [BomProducingStepStatusEnum.REJECTED]: [BomProducingStepStatusEnum.CREATED],
};

export const CONFIRM_BOM_PRODUCING_STEP_STATUS: number[] = [
  BomProducingStepStatusEnum.CREATED,
  BomProducingStepStatusEnum.REJECTED,
];

export const REJECT_BOM_PRODUCING_STEP_STATUS: number[] = [
  BomProducingStepStatusEnum.CREATED,
];

export enum BomStatusEnum {
  PENDING = 0,
  CONFIRMED = 1,
  REJECTED = 2,
  IN_PROGRESS = 3,
  COMPLETED = 4,
}

export const STATUS_TO_UPDATE_BOM: number[] = [
  BomStatusEnum.PENDING,
  BomStatusEnum.REJECTED,
];

export const STATUS_TO_UPDATE_BOM_VERSION: number[] = [BomStatusEnum.PENDING];

export const STATUS_TO_CONFIRM_BOM_STATUS: number[] = [
  BomStatusEnum.PENDING,
  BomStatusEnum.REJECTED,
];

export const STATUS_TO_REJECT_BOM_STATUS: number[] = [BomStatusEnum.PENDING];

export const STATUS_BOM_TO_REJECT_BOM_VERSION: number[] = [
  BomStatusEnum.CONFIRMED,
];

export const STATUS_TO_COMPLETE_BOM_STATUS: number[] = [
  BomStatusEnum.IN_PROGRESS,
];

export const STATUS_TO_DELETE_BOM_STATUS: number[] = [
  BomStatusEnum.PENDING,
  BomStatusEnum.REJECTED,
];

export const STATUS_BOM_TO_CLONE_BOM_VERSION_STATUS: number[] = [
  BomStatusEnum.CONFIRMED,
];

export const BOM_VERSION_CODE = {
  FIRST: '00',
};

export const ITEM_TYPE = {
  MATERIA: '00',
  SEMI_PRODUCT: '02',
};

export const TYPE_ITEM_NOT_CHECK_ITEM_VERSION = {
  '00': 'Nguyên vật liệu',
  '03': 'Bao bì cấp 1',
  '04': 'Bao bì cấp 2',
};
