import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { BomMachineProducingStepDetailEntity } from '@entities/bom/bom-machine-producing-step-details.entity';

export interface BomMachineProducingStepDetailRepositoryInterface
  extends BaseInterfaceRepository<BomMachineProducingStepDetailEntity> {
  createEntity(data: any): BomMachineProducingStepDetailEntity;
}
