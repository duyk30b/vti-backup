import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { BomUserProducingStepDetailEntity } from '@entities/bom/bom-user-producing-step-details.entity';

export interface BomUserProducingStepDetailRepositoryInterface
  extends BaseInterfaceRepository<BomUserProducingStepDetailEntity> {
  createEntity(data: any): BomUserProducingStepDetailEntity;
}
