import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { BomEntity } from '@entities/bom/boms.entity';
import { CreateBomRequestDto } from '../dto/request/create-bom.request.dto';
import { GetBomListRequestDto } from '../dto/request/get-bom-list.request.dto';

export interface BomRepositoryInterface
  extends BaseInterfaceRepository<BomEntity> {
  createEntity(data: CreateBomRequestDto, userId: number): BomEntity;
  updateEntity(bom: BomEntity, data: any): BomEntity;
  getDetail(id: number, bomVersionId: number): Promise<any>;
  getList(request: GetBomListRequestDto, itemIds?: number[]): Promise<any>;
  getBomsByItemIds(itemIds: any): Promise<any>;
  getBomStructure(
    id: any,
    itemIds: number[],
    bomVersionId?: any,
    quantity?: number,
  ): Promise<any>;
  getMaterialItems(id: number, bomVersionId?: number): Promise<any>;
  getMaterialItemByIds(ids: number[], bomVersionIds?: number[]): Promise<any>;
  getBomProducingStepStruct(bomId: number, itemId: number): Promise<any>;
  getBomProducingSteps(
    bomIds: number[],
    bomVersionIds?: number[],
  ): Promise<any>;
  getBomMaterialProducingSteps(bomIds: number[]): Promise<any>;
  listParentByItem(itemId: number): Promise<any>;
  listChildByItem(itemId: number): Promise<any>;
  bomStructPlanning(itemIds: number[], bomVersionIds?: number[]): Promise<any>;
  getItemByBoms(): Promise<any>;
  getBomStructProducingStep(
    id: any,
    itemIds: number[],
    bomVersionId?: any,
  ): Promise<any>;
  getBomExportData(
    request: GetBomListRequestDto,
    itemIds?: number[],
  ): Promise<any>;
  getCount(): Promise<any>;
}
