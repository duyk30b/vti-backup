import { CreateBomFormDataDto } from '@components/bom/dto/request/create-bom.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { UpdateBomFormDataDto } from '@components/bom/dto/request/update-bom.request.dto';
import { DeleteBomRequestDto } from '../dto/request/delete-bom.request.dto';
import { GetBomDetailRequestDto } from '../dto/request/get-bom-detail.request.dto';
import { GetBomListRequestDto } from '../dto/request/get-bom-list.request.dto';
import { UpdateBomStatusRequestDto } from '../dto/request/update-bom-status-request.dto';
import { GetBomByItemIdRequestDto } from '../dto/request/get-bom-by-item-id.request.dto';
import { GetBomStructRequestDto } from '../dto/request/get-bom-struct.request.dto';
import { CreateBomProducingStepRequestDto } from '../dto/request/create-bom-producing-step-detail.request.dto';
import { GetBomProducingStepListRequestDto } from '../dto/request/get-bom-producing-step-list.request.dto';
import { GetBomByItemIdsRequestDto } from '../dto/request/get-bom-by-item-ids.request.dto';
import { GetBomTreeByItemIds } from '../dto/request/get-bom-tree-by-item-ids.request.dto';
import { GetMaterialBomByIdsRequestDto } from '../dto/request/get-material-bom-by-ids.request.dto';
import { ConfirmRejectBomVersionRequestDto } from '../dto/request/confirm-reject-bom-version.request.dto';
import { GetListBomVersionByBomVersionIdsRequestDto } from '../dto/request/get-list-bom-version-by-bom-version-id.request.dto';
import { GetBomVersionByBomIdRequestDto } from '../dto/request/get-list-bom-version-by-bom-id.request.dto';
import { GetBomDetailByItemIdsRequestDto } from '../dto/request/get-bom-detail-by-item-ids.request.dto';

export interface BomServiceInterface {
  create(payload: CreateBomFormDataDto): Promise<ResponsePayload<any>>;
  update(payload: UpdateBomFormDataDto): Promise<ResponsePayload<any>>;
  delete(payload: DeleteBomRequestDto): Promise<any>;
  getDetail(payload: GetBomDetailRequestDto): Promise<any>;
  getList(payload: GetBomListRequestDto): Promise<any>;
  reject(payload: UpdateBomStatusRequestDto): Promise<any>;
  confirm(payload: UpdateBomStatusRequestDto): Promise<any>;
  getBomByItemId(
    payload: GetBomByItemIdRequestDto,
  ): Promise<ResponsePayload<any>>;
  getBomsByItemIds(itemIds: number[], serilize?: boolean): Promise<any>;
  getBomStruct(payload: GetBomStructRequestDto): Promise<any>;
  createOrUpdateBomProducingStep(
    req: CreateBomProducingStepRequestDto,
  ): Promise<any>;
  getBomProducingStep(req): Promise<any>;
  updateBomProducingStepStatus(id: number, status: number): Promise<any>;
  deleteBomProducingStep(id: number): Promise<any>;
  getListBomProducingStep(req: GetBomProducingStepListRequestDto): Promise<any>;
  getBomTreeByItemIds(playload: GetBomTreeByItemIds): Promise<any>;
  getBomByItemIds(payload: GetBomByItemIdsRequestDto): Promise<any>;
  getMaterialBomByIds(request: GetMaterialBomByIdsRequestDto): Promise<any>;
  rejectBomVersion(request: ConfirmRejectBomVersionRequestDto): Promise<any>;
  confirmBomVersion(request: ConfirmRejectBomVersionRequestDto): Promise<any>;
  getListBomVersionByBomVersionIds(
    request: GetListBomVersionByBomVersionIdsRequestDto,
  ): Promise<any>;
  getBomVersionByItemId(itemId: number, request?: any): Promise<any>;
  getListBomVersionByBomId(
    request: GetBomVersionByBomIdRequestDto,
  ): Promise<any>;
  getBomDetailByItemIds(request: GetBomDetailByItemIdsRequestDto): Promise<any>;
  getBomStructProducingStep(payload: GetBomStructRequestDto): Promise<any>;
  cloneBomVersion(payload: UpdateBomFormDataDto): Promise<ResponsePayload<any>>;
  getBomVersionByItemIds(request: any): Promise<any>;
}
