import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { BomDetailEntity } from '@entities/bom/bom-details.entity';

export interface BomDetailRepositoryInterface
  extends BaseInterfaceRepository<BomDetailEntity> {
  createEntity(data: any): BomDetailEntity;
  getMaterialInputItems(
    workOrderId: number,
    inputItemIds: number[],
  ): Promise<any>;
}
