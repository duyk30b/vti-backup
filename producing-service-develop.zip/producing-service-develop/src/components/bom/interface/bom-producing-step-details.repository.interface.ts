import { GetMoMaterialList } from '@components/material/dto/request/get-mo-material-list.request.dto';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { BomProducingStepDetailEntity } from '@entities/bom/bom-producing-steps.entity';
import { GetBomProducingStepListRequestDto } from '../dto/request/get-bom-producing-step-list.request.dto';

export interface BomProducingStepDetailsRepositoryInterface
  extends BaseInterfaceRepository<BomProducingStepDetailEntity> {
  createEntity(data: any): BomProducingStepDetailEntity;
  getList(
    req: GetBomProducingStepListRequestDto,
    itemFilter: any[],
  ): Promise<any>;
  getAllItemIds(): Promise<any>;
  getBomProducingStep(bomIds: number[]): Promise<any>;
  getAllItemIdOfBoms(): Promise<any>;
  deleteByBomIds(bomIds: number[]): Promise<any>;
  getListMaterial(request: GetMoMaterialList, itemIds?: number[]): Promise<any>;
  getBomProducingStepsByBomId(
    bomId: number,
    bomVersionId: number,
    isHasBom?: string,
  ): Promise<any>;
}
