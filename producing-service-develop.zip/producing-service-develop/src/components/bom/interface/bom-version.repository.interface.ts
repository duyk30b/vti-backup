import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { BomVersionEntity } from '@entities/bom/bom-versions.entity';
import { GetBomVersionByBomIdRequestDto } from '../dto/request/get-list-bom-version-by-bom-id.request.dto';

export interface BomVersionRepositoryInterface
  extends BaseInterfaceRepository<BomVersionEntity> {
  createEntity(data: any): BomVersionEntity;
  getBomVersionByItemId(itemId: number, request?: any): Promise<any>;
  getBomVersionByBomId(request: GetBomVersionByBomIdRequestDto): Promise<any>;
  getBomVersionByItemIds(itemIds: number[]): Promise<any>;
}
