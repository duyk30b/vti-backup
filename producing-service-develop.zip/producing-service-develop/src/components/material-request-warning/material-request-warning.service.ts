import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ApiError } from '@utils/api.error';
import { ResponsePayload } from '@utils/response-payload';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { plainToInstance } from 'class-transformer';
import { ResponseBuilder } from '@utils/response-builder';
import { DataSource, Not } from 'typeorm';
import { first, flatMap, isEmpty, map, uniq } from 'lodash';
import { PagingResponse } from '@utils/paging.response';
import { SuccessResponse } from '@utils/success.response.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';

import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { SaleServiceInterface } from '@components/sale-order/interface/sale.service.interface';
import { MaterialRequestWarningServiceInterface } from './interface/material-request-warning.service.interface';
import { MaterialRequestWarningRepositoryInterface } from './interface/material-request-warning.repository.interface';
import {
  MaterialRequestWarningResponse,
  MaterialRequestWarningResponseDto,
} from './dto/response/material-request-warning.response.dto';
import { GetListMaterialRequestWarningRequestDto } from './dto/request/get-list-material-request-warning.request.dto';
import { CreateMaterialRequestWarningRequestDto } from './dto/request/create-material-request-warning.request.dto';
import { UpdateMaterialRequestWarningRequestDto } from './dto/request/update-material-request-warning.request.dto';
import { SetStatusRequestDto } from './dto/request/set-status.request.dto';
import { GetListMaterialRequestWarningResponseDto } from './dto/response/get-list-material-request-warning.response.dto';
import { MaterialServiceInterface } from '@components/material/interface/material.service.interface';
import { ManufacturingOrderRepositoryInterface } from '@components/manufacturing-order/interface/manufacturing-order.repository.interface';
import {
  CAN_CONFIRM_MATERIAL_REQUEST_WARNING_STATUS,
  CAN_DELETE_MATERIAL_REQUEST_WARNING_STATUS,
  CAN_REJECT_MATERIAL_REQUEST_WARNING_STATUS,
  CAN_UPDATE_MATERIAL_REQUEST_WARNING_STATUS,
  MaterialRequestWarningStatusEnum,
} from './material-request-warning.constant';
import { MaterialPlanRepositoryInterface } from '@components/material/interface/material-plan.repository.interface';
import { CreatePurchaseOrderDraftRequestDto } from '@components/sale-order/dto/request/create-purchase-order-draft-request.dto';
import { MaterialRequestWarningItemResponse } from './dto/response/material-request-warning-item.response.dto';
import { RequestServiceInterface } from '@components/request/interface/request.service.interface';

@Injectable()
export class MaterialRequestWarningService
  implements MaterialRequestWarningServiceInterface
{
  constructor(
    @Inject('MaterialRequestWarningRepositoryInterface')
    private readonly materialRequestWarningRepository: MaterialRequestWarningRepositoryInterface,

    @Inject('ManufacturingOrderRepositoryInterface')
    private readonly manufacturingOrderRepository: ManufacturingOrderRepositoryInterface,

    @Inject('MaterialPlanRepositoryInterface')
    private readonly materialPlanRepository: MaterialPlanRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('MaterialServiceInterface')
    private readonly materialService: MaterialServiceInterface,

    @Inject('SaleServiceInterface')
    private readonly saleService: SaleServiceInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,

    @Inject('RequestServiceInterface')
    private readonly requestService: RequestServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  public async detail(
    id: number,
  ): Promise<ResponsePayload<MaterialRequestWarningResponseDto | any>> {
    const materialRequestWarning =
      await this.materialRequestWarningRepository.findOneById(id);
    if (!materialRequestWarning) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.MATERIAL_REQUEST_WARNING_NOT_FOUND'),
      ).toResponse();
    }

    const materialPlan = await this.materialPlanRepository.findOneByCondition({
      manufacturingOrderId: materialRequestWarning.manufacturingOrderId,
    });

    if (!materialPlan) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.MATERIAL_PLAN_NOT_FOUND'),
      ).toResponse();
    }

    const manufacturingOrder =
      await this.manufacturingOrderRepository.findOneById(
        materialRequestWarning.manufacturingOrderId,
      );

    if (!manufacturingOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.MANUFACTURING_ORDER_NOT_FOUND'),
        )
        .build();
    }

    let purchasedOrders = [];
    if (
      materialRequestWarning.status ===
      MaterialRequestWarningStatusEnum.CONFIRMED
    ) {
      purchasedOrders = await this.saleService.getPurchaseOrderByIds([
        materialRequestWarning.poId,
      ]);
    }

    const factories = await this.userService.getFactoriesByIds([
      manufacturingOrder.factoryId,
    ]);

    const manufacturingRequestOrders =
      await this.requestService.getManufacturingRequestOrderByIds([
        manufacturingOrder.manufacturingRequestOrderId,
      ]);

    const dataCheckMaterial = await this.materialService.checkMaterialPlan(
      materialPlan.id,
    );

    let itemIds = [];
    let itemDetails = [];
    if (!isEmpty(purchasedOrders)) {
      const purchasedOrder = first(purchasedOrders);

      itemIds = uniq(
        map(
          flatMap(purchasedOrder['purchasedOrderWarehouseDetails']),
          'itemId',
        ),
      );
      const items = await this.itemService.getItemsByIds(itemIds, true);
      itemDetails = purchasedOrder['purchasedOrderWarehouseDetails'].map(
        (record) => ({
          id: record.itemId,
          name: items[record.itemId]?.name,
          code: items[record.itemId]?.code,
          itemTypeId: items[record.itemId]?.itemTypeId,
          itemUnitId: items[record.itemId]?.itemUnitId,
          itemType: items[record.id].itemType,
          itemUnit: items[record.id].itemUnit,
          quantity: record.quantity,
        }),
      );
    } else {
      itemIds = uniq(map(flatMap(dataCheckMaterial.data.items), 'id'));
      const items = await this.itemService.getItemsByIds(itemIds, true);
      itemDetails = dataCheckMaterial.data.items.map((record) => ({
        id: record.id,
        name: items[record.id].name,
        code: items[record.id].code,
        itemTypeId: items[record.id].itemTypeId,
        itemUnitId: items[record.id].itemUnitId,
        itemType: items[record.id].itemType,
        itemUnit: items[record.id].itemUnit,
        quantity: record.quantity,
      }));
    }

    const createdBy = await this.userService.getUserById(
      materialRequestWarning.createdBy,
    );

    const result = {
      id: materialRequestWarning.id,
      name: materialRequestWarning.name,
      code: materialRequestWarning.code,
      status: materialRequestWarning.status,
      planTo: materialRequestWarning.planTo,
      planFrom: !isEmpty(purchasedOrders)
        ? first(purchasedOrders)['deadline']
        : materialRequestWarning.planFrom,
      createdAt: materialRequestWarning.createdAt,
      updatedAt: materialRequestWarning.updatedAt,
      createdBy: createdBy,
      factory: factories[0] ? factories[0] : [],
      manufacturingRequestOrder: manufacturingRequestOrders[0]
        ? manufacturingRequestOrders[0]
        : [],
      manufacturingOrder: manufacturingOrder,
      description: materialRequestWarning.description,
      itemDetails: itemDetails,
    };
    const response = plainToInstance(MaterialRequestWarningResponse, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }
  public async getList(
    request: GetListMaterialRequestWarningRequestDto,
  ): Promise<ResponsePayload<GetListMaterialRequestWarningResponseDto | any>> {
    const { filter, sort } = request;
    const filterManufacturingRequestOrder = filter?.filter(
      (record) => record.column === 'manufacturingRequestOrderCode',
    );

    const sortmanufacturingRequestOrder = sort?.filter(
      (record) => record.column === 'manufacturingRequestOrderCode',
    );

    let manufacturingRequestOrderIds = [];
    let manufacturingRequestOrders = {};

    if (!isEmpty(sortmanufacturingRequestOrder)) {
      const materialRequestWarnings =
        await this.manufacturingOrderRepository.getMoDistinctManufacturingRequestOrderId();
      manufacturingRequestOrderIds = map(
        flatMap(materialRequestWarnings),
        'manufacturingRequestOrderId',
      );
    }

    if (!isEmpty(filterManufacturingRequestOrder)) {
      manufacturingRequestOrders =
        await this.requestService.getManufacturingRequestOrderByCode(
          first(filterManufacturingRequestOrder),
        );

      if (isEmpty(manufacturingRequestOrders)) {
        return new ResponseBuilder([])
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
      }
    }

    if (
      isEmpty(manufacturingRequestOrders) &&
      !isEmpty(manufacturingRequestOrderIds)
    ) {
      manufacturingRequestOrders =
        await this.requestService.getManufacturingRequestOrderByIds(
          manufacturingRequestOrderIds,
        );
    }

    const { result, count } =
      await this.materialRequestWarningRepository.getList(
        request,
        manufacturingRequestOrders,
      );

    let data = result;
    if (isEmpty(manufacturingRequestOrders)) {
      manufacturingRequestOrderIds = uniq(
        map(flatMap(result, 'manufacturingOrder'), 'sale_order_id'),
      );
      manufacturingRequestOrders =
        await this.requestService.getManufacturingRequestOrderByIds(
          manufacturingRequestOrderIds,
          true,
        );

      data = result.map((record) => ({
        ...record,
        manufacturingRequestOrder:
          manufacturingRequestOrders[
            record.manufacturingOrder.manufacturing_request_order_id
          ],
      }));
    }

    const response = plainToInstance(MaterialRequestWarningResponse, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async getListMaterialRequestWarningItem(
    request: GetListMaterialRequestWarningRequestDto,
  ): Promise<ResponsePayload<GetListMaterialRequestWarningResponseDto | any>> {
    const { filter, sort } = request;
    const filtermanufacturingRequestOrder = filter?.filter(
      (record) => record.column === 'manufacturingRequestOrderCode',
    );

    const sortmanufacturingRequestOrder = sort?.filter(
      (record) => record.column === 'manufacturingRequestOrderCode',
    );

    let manufacturingRequestOrderIds = [];
    let manufacturingRequestOrders = {};

    if (!isEmpty(sortmanufacturingRequestOrder)) {
      const materialRequestWarnings =
        await this.manufacturingOrderRepository.getMoDistinctManufacturingRequestOrderId();
      manufacturingRequestOrderIds = map(
        flatMap(materialRequestWarnings),
        'manufacturingRequestOrderId',
      );
    }

    if (!isEmpty(filtermanufacturingRequestOrder)) {
      manufacturingRequestOrders =
        await this.requestService.getManufacturingRequestOrderByCode(
          first(filtermanufacturingRequestOrder),
        );

      if (isEmpty(manufacturingRequestOrders)) {
        return new ResponseBuilder([])
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
      }
    }

    if (
      isEmpty(manufacturingRequestOrders) &&
      !isEmpty(manufacturingRequestOrderIds)
    ) {
      manufacturingRequestOrders =
        await this.requestService.getManufacturingRequestOrderByIds(
          manufacturingRequestOrderIds,
        );
    }

    const { result, count } =
      await this.materialRequestWarningRepository.getListMaterialRequestWarningItem(
        request,
        manufacturingRequestOrders,
      );
    let data = result;
    if (isEmpty(manufacturingRequestOrders)) {
      manufacturingRequestOrderIds = uniq(
        map(flatMap(result, 'manufacturingOrder'), 'sale_order_id'),
      );
      manufacturingRequestOrders =
        await this.requestService.getManufacturingRequestOrderByIds(
          manufacturingRequestOrderIds,
          true,
        );
    }
    let factoryIds: any[] = [];
    let factories;
    factoryIds = uniq(map(flatMap(result, 'manufacturingOrder'), 'factory_id'));
    if (!isEmpty(factoryIds)) {
      factories = await this.userService.getFactoriesByIds(factoryIds, true);
    }
    manufacturingRequestOrderIds = uniq(
      map(flatMap(result, 'manufacturingOrder'), 'sale_order_id'),
    );
    manufacturingRequestOrders =
      await this.requestService.getManufacturingRequestOrderByIds(
        manufacturingRequestOrderIds,
        true,
      );
    let purchasedOrders = [];
    let purchasedOrderIds: any[] = [];
    purchasedOrderIds = uniq(map(result, 'poId'));

    purchasedOrders = await this.saleService.getPurchaseOrderByIds(
      purchasedOrderIds,
    );
    let itemIds = [];
    let itemDetails = [];
    if (!isEmpty(purchasedOrders)) {
      const purchasedOrder = first(purchasedOrders);
      itemIds = uniq(
        map(
          flatMap(purchasedOrder['purchasedOrderWarehouseDetails']),
          'itemId',
        ),
      );
      const items = await this.itemService.getItemsByIds(itemIds, true);

      itemDetails = purchasedOrder['purchasedOrderWarehouseDetails'].map(
        (record) => ({
          id: record.itemId,
          name: items[record.itemId]?.name,
          code: items[record.itemId]?.code,
          itemType: items[record.itemId]?.itemType,
          itemUnitName: items[record.itemId]?.itemUnitName,
          quantity: record.quantity,
        }),
      );
    }
    data = result.map((record) => ({
      ...record,
      manufacturingRequestOrder:
        manufacturingRequestOrders[record.manufacturingOrder.sale_order_id],
      factory: factories[record.manufacturingOrder.factory_id],
      itemDetails: itemDetails,
    }));

    const response = plainToInstance(MaterialRequestWarningItemResponse, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }
  public async create(
    request: CreateMaterialRequestWarningRequestDto,
  ): Promise<ResponsePayload<MaterialRequestWarningResponseDto | any>> {
    const { code, manufacturingOrderId } = request;
    const checkExistCodeMaterialRequestWarning =
      await this.materialRequestWarningRepository.findByCondition({
        code: code,
      });
    if (!isEmpty(checkExistCodeMaterialRequestWarning)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_ALREADY_EXISTS'),
      ).toResponse();
    }

    const checkExistMOIdMaterialRequestWarning =
      await this.materialRequestWarningRepository.findByCondition({
        manufacturingOrderId: manufacturingOrderId,
      });
    if (!isEmpty(checkExistMOIdMaterialRequestWarning)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate(
          'error.MATERIAL_REQUEST_WARNING_MO_ALREADY_EXISTS',
        ),
      ).toResponse();
    }

    const manufacturingOrder =
      await this.manufacturingOrderRepository.findOneById(manufacturingOrderId);

    if (!manufacturingOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.MANUFACTURING_ORDER_NOT_FOUND'),
        )
        .build();
    }

    const MaterialRequestWarningEntity =
      await this.materialRequestWarningRepository.createEntity(request);

    try {
      const result = await this.materialRequestWarningRepository.create(
        MaterialRequestWarningEntity,
      );

      const response = plainToInstance(MaterialRequestWarningResponse, result, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(response)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CREATE'))
        .build();
    }
  }
  public async update(
    request: UpdateMaterialRequestWarningRequestDto,
  ): Promise<ResponsePayload<MaterialRequestWarningResponseDto | any>> {
    const { id, code, manufacturingOrderId } = request;
    const materialRequestWarning =
      await this.materialRequestWarningRepository.findOneById(id);
    if (!materialRequestWarning) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.MATERIAL_REQUEST_WARNING_NOT_FOUND'),
      ).toResponse();
    }

    const checkExistCodeMaterialRequestWarning =
      await this.materialRequestWarningRepository.findByCondition({
        code: code,
        id: Not(id),
      });
    if (!isEmpty(checkExistCodeMaterialRequestWarning)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_ALREADY_EXISTS'),
      ).toResponse();
    }

    const checkExistMOIdMaterialRequestWarning =
      await this.materialRequestWarningRepository.findByCondition({
        manufacturingOrderId: manufacturingOrderId,
        id: Not(id),
      });
    if (!isEmpty(checkExistMOIdMaterialRequestWarning)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate(
          'error.MATERIAL_REQUEST_WARNING_MO_ALREADY_EXISTS',
        ),
      ).toResponse();
    }

    const manufacturingOrder =
      await this.manufacturingOrderRepository.findOneById(manufacturingOrderId);

    if (!manufacturingOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.MANUFACTURING_ORDER_NOT_FOUND'),
        )
        .build();
    }

    if (
      !CAN_UPDATE_MATERIAL_REQUEST_WARNING_STATUS.includes(
        materialRequestWarning.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }

    const MaterialRequestWarningEntity =
      await this.materialRequestWarningRepository.createEntity(
        request,
        materialRequestWarning,
      );

    try {
      const result = await this.materialRequestWarningRepository.create(
        MaterialRequestWarningEntity,
      );

      const response = plainToInstance(MaterialRequestWarningResponse, result, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(response)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_UPDATE'))
        .build();
    }
  }
  public async delete(
    id: number,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const materialRequestWarning =
      await this.materialRequestWarningRepository.findOneById(id);
    if (!materialRequestWarning) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.MATERIAL_REQUEST_WARNING_NOT_FOUND'),
      ).toResponse();
    }
    if (
      !CAN_DELETE_MATERIAL_REQUEST_WARNING_STATUS.includes(
        materialRequestWarning.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }
    await this.materialRequestWarningRepository.remove(id);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }
  public async confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<MaterialRequestWarningResponseDto | any>> {
    const { id, userId } = request;
    const materialRequestWarning =
      await this.materialRequestWarningRepository.findOneById(id);
    if (!materialRequestWarning) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.MATERIAL_REQUEST_WARNING_NOT_FOUND'),
      ).toResponse();
    }
    if (
      !CAN_CONFIRM_MATERIAL_REQUEST_WARNING_STATUS.includes(
        materialRequestWarning.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CONFIRM'))
        .build();
    }
    const materialPlan = await this.materialPlanRepository.findOneByCondition({
      manufacturingOrderId: materialRequestWarning.manufacturingOrderId,
    });

    if (!materialPlan) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.MATERIAL_PLAN_NOT_FOUND'),
      ).toResponse();
    }

    const manufacturingOrder =
      await this.manufacturingOrderRepository.findOneById(
        materialRequestWarning.manufacturingOrderId,
      );

    if (!manufacturingOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.MANUFACTURING_ORDER_NOT_FOUND'),
        )
        .build();
    }

    const dataCheckMaterial = await this.materialService.checkMaterialPlan(
      materialPlan.id,
    );
    //purchase order entity
    const createPurchaseOrderRequestDto =
      new CreatePurchaseOrderDraftRequestDto();
    createPurchaseOrderRequestDto.createdByUserId = userId;
    createPurchaseOrderRequestDto.name = dataCheckMaterial.data.name;
    createPurchaseOrderRequestDto.code = dataCheckMaterial.data.code;
    createPurchaseOrderRequestDto.manufacturingOrderId =
      dataCheckMaterial.data.manufacturingOrderId;
    createPurchaseOrderRequestDto.deadline = dataCheckMaterial.data.planTo;
    createPurchaseOrderRequestDto.vendorId = dataCheckMaterial.data.vendorId;
    createPurchaseOrderRequestDto.companyId = dataCheckMaterial.data.companyId;
    createPurchaseOrderRequestDto.purchasedAt =
      dataCheckMaterial.data.purchasedAt;
    createPurchaseOrderRequestDto.items = dataCheckMaterial.data.items;

    //material request warning entity
    materialRequestWarning.status = MaterialRequestWarningStatusEnum.CONFIRMED;
    materialRequestWarning.approverId = userId;
    materialRequestWarning.createdAt = new Date(Date.now());
    try {
      const purchaseOrder = await this.saleService.createPurchaseOrderDraft(
        createPurchaseOrderRequestDto,
      );
      if (purchaseOrder.statusCode !== ResponseCodeEnum.SUCCESS) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.CREATE_PURCHASE_ORDER_ERROR'),
          )
          .build();
      }
      materialRequestWarning.poId = purchaseOrder.data.id;
      const result = await this.materialRequestWarningRepository.create(
        materialRequestWarning,
      );

      const response = plainToInstance(MaterialRequestWarningResponse, result, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(response)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CONFIRM'))
        .build();
    }
  }

  public async reject(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<MaterialRequestWarningResponseDto | any>> {
    const { id, userId } = request;
    const materialRequestWarning =
      await this.materialRequestWarningRepository.findOneById(id);
    if (!materialRequestWarning) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.MATERIAL_REQUEST_WARNING_NOT_FOUND'),
      ).toResponse();
    }
    if (
      !CAN_REJECT_MATERIAL_REQUEST_WARNING_STATUS.includes(
        materialRequestWarning.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_REJECT'))
        .build();
    }
    materialRequestWarning.status = MaterialRequestWarningStatusEnum.REJECTED;
    materialRequestWarning.approverId = userId;
    materialRequestWarning.createdAt = new Date(Date.now());

    try {
      const result = await this.materialRequestWarningRepository.create(
        materialRequestWarning,
      );

      const response = plainToInstance(MaterialRequestWarningResponse, result, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(response)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_REJECT'))
        .build();
    }
  }
}
