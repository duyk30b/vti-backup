export enum MaterialRequestWarningStatusEnum {
  CREATED = 0,
  CONFIRMED = 1,
  REJECTED = 2,
}

export const CAN_UPDATE_MATERIAL_REQUEST_WARNING_STATUS: number[] = [
  MaterialRequestWarningStatusEnum.CREATED,
  MaterialRequestWarningStatusEnum.REJECTED,
];

export const CAN_DELETE_MATERIAL_REQUEST_WARNING_STATUS: number[] = [
  MaterialRequestWarningStatusEnum.CREATED,
  MaterialRequestWarningStatusEnum.REJECTED,
];

export const CAN_CONFIRM_MATERIAL_REQUEST_WARNING_STATUS: number[] = [
  MaterialRequestWarningStatusEnum.CREATED,
  MaterialRequestWarningStatusEnum.REJECTED,
];

export const CAN_REJECT_MATERIAL_REQUEST_WARNING_STATUS: number[] = [
  MaterialRequestWarningStatusEnum.CREATED,
];
