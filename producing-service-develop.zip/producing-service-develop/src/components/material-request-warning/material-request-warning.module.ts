import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserService } from '@components/user/user.service';
import { UserModule } from '@components/user/user.module';
import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { WarehouseService } from '@components/warehouse/warehouse.service';
import { ItemModule } from '@components/item/item.module';
import { ItemService } from '@components/item/item.service';
import { SaleModule } from '@components/sale-order/sale-order.module';
import { SaleService } from '@components/sale-order/sale-order.service';
import { MaterialRequestWarningRepository } from '@repositories/material-request-warning/material-request-warning.repository';
import { MaterialRequestWarningService } from './material-request-warning.service';
import { MaterialRequestWarningEntity } from '@entities/material-request-warning/material-request-warning.entity';
import { MaterialRequestWarningController } from './material-request-warning.controller';
import { MaterialService } from '@components/material/material.service';
import { MaterialModule } from '@components/material/material.module';
import { ManufacturingOrderRepository } from '@repositories/manufacturing-order/manufacturing-order.repository';
import { ManufacturingOrderEntity } from '@entities/manufacturing-order/manufacturing-orders.entity';
import { BomEntity } from '@entities/bom/boms.entity';
import { BomRepository } from '@repositories/bom/bom.repository';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      MaterialRequestWarningEntity,
      ManufacturingOrderEntity,
      BomEntity,
    ]),
    MaterialModule,
    UserModule,
    WarehouseModule,
    ItemModule,
    SaleModule,
  ],
  providers: [
    {
      provide: 'MaterialRequestWarningRepositoryInterface',
      useClass: MaterialRequestWarningRepository,
    },
    {
      provide: 'ManufacturingOrderRepositoryInterface',
      useClass: ManufacturingOrderRepository,
    },
    {
      provide: 'BomRepositoryInterface',
      useClass: BomRepository,
    },
    {
      provide: 'MaterialRequestWarningServiceInterface',
      useClass: MaterialRequestWarningService,
    },
    {
      provide: 'MaterialServiceInterface',
      useClass: MaterialService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
  ],
  controllers: [MaterialRequestWarningController],
})
export class MaterialRequestWarningModule {}
