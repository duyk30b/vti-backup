import { SetStatusRequestDto } from '@components/material/dto/request/set-status.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { DEFAULT_TRANSPORT } from '@utils/constant';
import {
  CREATE_MATERIAL_REQUEST_WARNING_PERMISSION,
  UPDATE_MATERIAL_REQUEST_WARNING_PERMISSION,
  DELETE_MATERIAL_REQUEST_WARNING_PERMISSION,
  DETAIL_MATERIAL_REQUEST_WARNING_PERMISSION,
  LIST_MATERIAL_REQUEST_WARNING_PERMISSION,
  CONFIRM_MATERIAL_REQUEST_WARNING_PERMISSION,
  REJECT_MATERIAL_REQUEST_WARNING_PERMISSION,
} from '@utils/permissions/material-request-warning';
import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { CreateMaterialRequestWarningRequestDto } from './dto/request/create-material-request-warning.request.dto';
import { DetailMaterialRequestDto } from './dto/request/detail-material-request-warning.request.dto';
import { GetListMaterialRequestWarningRequestDto } from './dto/request/get-list-material-request-warning.request.dto';
import { UpdateMaterialRequestWarningRequestDto } from './dto/request/update-material-request-warning.request.dto';
import { GetListMaterialRequestWarningResponseDto } from './dto/response/get-list-material-request-warning.response.dto';
import { MaterialRequestWarningResponseDto } from './dto/response/material-request-warning.response.dto';
import { MaterialRequestWarningServiceInterface } from './interface/material-request-warning.service.interface';

@Controller('material-request-warnings')
export class MaterialRequestWarningController {
  constructor(
    @Inject('MaterialRequestWarningServiceInterface')
    private readonly materialRequestWarningService: MaterialRequestWarningServiceInterface,
  ) {}

  @Get(':id')
  @ApiOperation({
    tags: ['Material Request Warning'],
    summary: 'Material Request Warning Detail',
    description: 'Chi tiết cảnh báo yêu cầu nguyên vật liệu',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: MaterialRequestWarningResponseDto,
  })
  @PermissionCode(DETAIL_MATERIAL_REQUEST_WARNING_PERMISSION.code)
  public async detail(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<ResponsePayload<MaterialRequestWarningResponseDto | any>> {
    return await this.materialRequestWarningService.detail(id);
  }

  @ApiOperation({
    tags: ['Material Request Warning'],
    summary: 'Material Request Warning Detail',
    description: 'Chi tiết cảnh báo yêu cầu nguyên vật liệu',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: MaterialRequestWarningResponseDto,
  })
  @PermissionCode(DETAIL_MATERIAL_REQUEST_WARNING_PERMISSION.code)
  @MessagePattern('material_request_warning_detail', DEFAULT_TRANSPORT)
  public async detailTcp(
    @Body() payload: DetailMaterialRequestDto,
  ): Promise<ResponsePayload<MaterialRequestWarningResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.materialRequestWarningService.detail(request.id);
  }

  @PermissionCode(LIST_MATERIAL_REQUEST_WARNING_PERMISSION.code)
  @Get('list')
  @ApiOperation({
    tags: ['Material Request Warning'],
    summary: 'List Material Request Warning',
    description: 'Danh sách cảnh báo yêu cầu nguyên vật liệu',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: GetListMaterialRequestWarningResponseDto,
  })
  @MessagePattern('material_request_warning_list', DEFAULT_TRANSPORT)
  public async getList(
    @Query() payload: GetListMaterialRequestWarningRequestDto,
  ): Promise<ResponsePayload<GetListMaterialRequestWarningResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.materialRequestWarningService.getList(request);
  }

  @PermissionCode(LIST_MATERIAL_REQUEST_WARNING_PERMISSION.code)
  @Get('item/list')
  @MessagePattern('material_request_warning_list_item', DEFAULT_TRANSPORT)
  public async getListMaterialRequestWarningItem(
    @Body() payload: GetListMaterialRequestWarningRequestDto,
  ): Promise<ResponsePayload<GetListMaterialRequestWarningResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.materialRequestWarningService.getListMaterialRequestWarningItem(
      request,
    );
  }

  @PermissionCode(CREATE_MATERIAL_REQUEST_WARNING_PERMISSION.code)
  @Post('create')
  @ApiOperation({
    tags: ['Material Request Warning'],
    summary: 'Create new Material Request Warning',
    description: 'Tạo cảnh báo yêu cầu nguyên vật liệu',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: MaterialRequestWarningResponseDto,
  })
  @MessagePattern('material_request_warning_create', DEFAULT_TRANSPORT)
  public async create(
    @Body() payload: CreateMaterialRequestWarningRequestDto,
  ): Promise<ResponsePayload<MaterialRequestWarningResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.materialRequestWarningService.create(request);
  }

  @PermissionCode(UPDATE_MATERIAL_REQUEST_WARNING_PERMISSION.code)
  @Put(':id')
  @ApiOperation({
    tags: ['Material Request Warning'],
    summary: 'Update Material Request Warning',
    description: 'Cập nhật thông tin cảnh báo yêu cầu nguyên vật liệu',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: MaterialRequestWarningResponseDto,
  })
  @MessagePattern('material_request_warning_update', DEFAULT_TRANSPORT)
  public async update(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateMaterialRequestWarningRequestDto,
  ): Promise<ResponsePayload<MaterialRequestWarningResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.materialRequestWarningService.update({
      id: id,
      ...request,
    });
  }

  @PermissionCode(CONFIRM_MATERIAL_REQUEST_WARNING_PERMISSION.code)
  @Put(':id/confirm')
  @ApiOperation({
    tags: ['Material Request Warning'],
    summary: 'Confirm Material Request Warning',
    description: 'Xác nhận cảnh báo yêu cầu nguyên vật liệu',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: MaterialRequestWarningResponseDto,
  })
  @MessagePattern('confirm_material_request_warning', DEFAULT_TRANSPORT)
  public async confirm(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: SetStatusRequestDto,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.materialRequestWarningService.confirm({
      id: id,
      userId: request.user?.id,
    } as SetStatusRequestDto);
  }

  @PermissionCode(REJECT_MATERIAL_REQUEST_WARNING_PERMISSION.code)
  @Put(':id/reject')
  @ApiOperation({
    tags: ['Material Request Warning'],
    summary: 'Reject Material Request Warning',
    description: 'Từ chối cảnh báo yêu cầu nguyên vật liệu',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: MaterialRequestWarningResponseDto,
  })
  @MessagePattern('reject_material_request_warning', DEFAULT_TRANSPORT)
  public async reject(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: SetStatusRequestDto,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.materialRequestWarningService.reject({
      id: id,
      userId: request.user?.id,
    } as SetStatusRequestDto);
  }

  @PermissionCode(DELETE_MATERIAL_REQUEST_WARNING_PERMISSION.code)
  @Delete(':id')
  @ApiOperation({
    tags: ['Material Request Warning'],
    summary: 'Delete Material Request Warning',
    description: 'Xóa cảnh báo yêu cầu nguyên vật liệu',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  @MessagePattern('material_request_warning_delete', DEFAULT_TRANSPORT)
  public async delete(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    return await this.materialRequestWarningService.delete(id);
  }
}
