import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class UserResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  username: string;
}
class ManufacturingRequestOrder {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: string;

  @ApiProperty({ example: 'Đơn hàng 300 cái bàn', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'SO001', description: '' })
  @Expose()
  code: string;
}

class ManufacturingOrder {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'Lệnh sản xuất 300 cái bàn', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'MO001', description: '' })
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  planFrom: Date;

  @ApiProperty()
  @Expose()
  planTo: Date;
}

class ItemType {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ItemUnit {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ItemDetailMaterialRequestWarning {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'gỗ', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'MO001', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 100, description: '' })
  @Expose()
  quantity: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  itemTypeId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  itemUnitId: number;

  @ApiProperty({ type: ItemUnit })
  @Expose()
  @Type(() => ItemUnit)
  itemUnit: ItemUnit;

  @ApiProperty({ type: ItemType })
  @Expose()
  @Type(() => ItemType)
  itemType: ItemType;
}

class Factory {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'nhà máy A', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'F001', description: '' })
  @Expose()
  code: string;
}

export class MaterialRequestWarningResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  planFrom: Date;

  @ApiProperty()
  @Expose()
  planTo: Date;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  createdAt: Date;

  @ApiProperty()
  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: UserResponse })
  @Expose()
  @Type(() => UserResponse)
  createdBy: UserResponse;

  @ApiProperty({ type: ManufacturingOrder })
  @Expose()
  @Type(() => ManufacturingOrder)
  manufacturingOrder: ManufacturingOrder;

  @ApiProperty({ type: ManufacturingRequestOrder })
  @Expose()
  @Type(() => ManufacturingRequestOrder)
  manufacturingRequestOrder: ManufacturingRequestOrder;

  @ApiProperty({ type: Factory })
  @Expose()
  @Type(() => Factory)
  factory: Factory;

  @ApiProperty({ type: ItemDetailMaterialRequestWarning, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => ItemDetailMaterialRequestWarning)
  itemDetails: ItemDetailMaterialRequestWarning[];
}

export class MaterialRequestWarningResponseDto extends SuccessResponse {
  @ApiProperty({ type: MaterialRequestWarningResponse })
  @Expose()
  @Type(() => MaterialRequestWarningResponse)
  data: MaterialRequestWarningResponse;
}
