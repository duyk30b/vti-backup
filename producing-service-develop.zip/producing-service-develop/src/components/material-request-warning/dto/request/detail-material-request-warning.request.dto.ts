import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsInt } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';

export class DetailMaterialRequestDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'id' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
