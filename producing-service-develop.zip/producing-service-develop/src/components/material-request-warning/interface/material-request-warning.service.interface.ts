import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { CreateMaterialRequestWarningRequestDto } from '../dto/request/create-material-request-warning.request.dto';
import { GetListMaterialRequestWarningRequestDto } from '../dto/request/get-list-material-request-warning.request.dto';
import { SetStatusRequestDto } from '../dto/request/set-status.request.dto';
import { UpdateMaterialRequestWarningRequestDto } from '../dto/request/update-material-request-warning.request.dto';
import { MaterialRequestWarningResponseDto } from '../dto/response/material-request-warning.response.dto';

export interface MaterialRequestWarningServiceInterface {
  detail(
    id: number,
  ): Promise<ResponsePayload<MaterialRequestWarningResponseDto | any>>;
  getList(
    request: GetListMaterialRequestWarningRequestDto,
  ): Promise<ResponsePayload<SuccessResponse | any>>;
  create(
    request: CreateMaterialRequestWarningRequestDto,
  ): Promise<ResponsePayload<MaterialRequestWarningResponseDto | any>>;
  update(
    request: UpdateMaterialRequestWarningRequestDto,
  ): Promise<ResponsePayload<MaterialRequestWarningResponseDto | any>>;
  delete(id: number): Promise<ResponsePayload<SuccessResponse | any>>;
  confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<MaterialRequestWarningResponseDto | any>>;
  reject(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<MaterialRequestWarningResponseDto | any>>;
  getListMaterialRequestWarningItem(
    request: GetListMaterialRequestWarningRequestDto,
  ): Promise<ResponsePayload<SuccessResponse | any>>;
}
