import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { MaterialRequestWarningEntity } from '@entities/material-request-warning/material-request-warning.entity';
import { GetListMaterialRequestWarningRequestDto } from '../dto/request/get-list-material-request-warning.request.dto';

export interface MaterialRequestWarningRepositoryInterface
  extends BaseInterfaceRepository<MaterialRequestWarningEntity> {
  createEntity(request: any, materialRequestWarning?: any);
  getList(
    request: GetListMaterialRequestWarningRequestDto,
    manufacturingRequestOrders: any,
  );
  getCount(): Promise<any>;
  getListMaterialRequestWarningItem(
    request: GetListMaterialRequestWarningRequestDto,
    manufacturingRequestOrders: any,
  );
}
