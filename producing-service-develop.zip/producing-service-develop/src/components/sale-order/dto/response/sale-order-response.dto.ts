import { ItemResponseDto } from './../../../item/dto/response/item.dto.response';
import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { OrderResponseDto } from './order-response.dto';

class SaleOrderDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  saleOrderId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  confirmQuantity: number;

  @ApiProperty({ type: ItemResponseDto })
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;
}

class SaleOrderWarehouseDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  saleOrderId: number;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  actualQuantity: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  confirmQuantity: number;
}

class SaleOrderCustomer {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  email: string;

  @ApiProperty()
  @Expose()
  fax: string;

  @ApiProperty()
  @Expose()
  phone: string;
}
export class SaleOrderResponseDto extends OrderResponseDto {
  @ApiProperty()
  @Expose()
  customerId: number;

  @ApiProperty()
  @Expose()
  orderedAt: string;

  @ApiProperty({ type: SaleOrderCustomer })
  @Expose()
  @Type(() => SaleOrderCustomer)
  customer: SaleOrderCustomer;

  @ApiProperty({ type: SaleOrderDetail })
  @Expose()
  @Type(() => SaleOrderDetail)
  saleOrderDetails: SaleOrderDetail[];

  @ApiProperty({ type: SaleOrderWarehouseDetail })
  @Expose()
  @Type(() => SaleOrderWarehouseDetail)
  saleOrderWarehouseDetails: SaleOrderWarehouseDetail[];
}
