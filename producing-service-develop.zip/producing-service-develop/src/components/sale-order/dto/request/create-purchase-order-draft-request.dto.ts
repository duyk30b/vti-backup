import { ProductionOrderTypeEnum } from '@components/material/material.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsBoolean,
  IsDateString,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Length,
  Min,
  ValidateNested,
} from 'class-validator';

class PODraftItemRequest {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  quantity: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsBoolean()
  qcCheck: boolean;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  qcCriteriaId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  price: number;
}

export class CreatePurchaseOrderDraftRequestDto {
  @ApiProperty()
  @ArrayUnique<PODraftItemRequest>()
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => PODraftItemRequest)
  items: PODraftItemRequest[];

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  manufacturingOrderId: number;

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  createdByUserId: number;

  @ApiProperty()
  @IsInt()
  @IsOptional()
  companyId: number;

  @ApiProperty()
  @IsInt()
  @IsOptional()
  vendorId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @Length(1, 255)
  name: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @Length(1, 9)
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  deadline: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  purchasedAt: Date;
}
