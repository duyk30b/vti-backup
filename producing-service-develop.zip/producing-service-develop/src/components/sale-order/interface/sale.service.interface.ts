import { ResponsePayload } from '@utils/response-payload';
import { CreateProductionOrderDraftRequestDto } from '../dto/request/create-production-order-draft-request.dto';
import { CreatePurchaseOrderDraftRequestDto } from '../dto/request/create-purchase-order-draft-request.dto';

export interface SaleServiceInterface {
  getSaleOrdersByIds(
    ids: number[] | any,
    serilize?: boolean,
  ): Promise<ResponsePayload<any>>;

  getSaleOrdersByRelation(relation: any): Promise<any[]>;

  getSaleOrdersByName(name: string): Promise<any[]>;
  getSaleOrdersByCode(code: string, onlyId?: boolean): Promise<any[]>;

  getSaleOrdersByIdsSorted(ids: number[]): Promise<any[]>;

  getProductionOrdersByCondition(
    request: any,
    serilize?: boolean,
  ): Promise<any>;
  getTotalQuantityItemProductionOrdersByCondition(
    request: any,
    serilize?: boolean,
  ): Promise<any>;
  getTotalQuantityItemPurchasedOrdersByCondition(
    request: any,
    serilize?: boolean,
  ): Promise<any>;

  getSaleOrdersByNameKeyword(filterByName, onlyId?: boolean);

  createProductionOrderDraft(
    payload: CreateProductionOrderDraftRequestDto,
  ): Promise<any>;
  createPurchaseOrderDraft(
    payload: CreatePurchaseOrderDraftRequestDto,
  ): Promise<any>;
  getPurchaseOrderByMOId(MoId: number): Promise<any>;
  getPurchaseOrderByIds(ids: number[]): Promise<any>;
  getSaleOrdersByCodeKeyword(filterByCode, onlyId?: boolean): Promise<any>;
  getSaleOrders(request: any): Promise<any>;
}
