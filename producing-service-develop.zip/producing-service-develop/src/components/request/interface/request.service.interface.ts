import { ManufacturingRequestOrderIdParamRequestDto } from '../dto/request/manufacturing-request-order-id-param.request.dto';
import { UpdateProducedQuantityRequestDto } from '../dto/request/update-produced-quantity.request.dto';

export interface RequestServiceInterface {
  getManufacturingRequestOrders(
    payload: any,
    serialize?: boolean,
  ): Promise<any>;
  getManufacturingRequestOrderByIds(
    ids: string[],
    serialize?: boolean,
  ): Promise<any>;
  getManufacturingRequestOrderByCode(
    code: string,
    serialize?: boolean,
  ): Promise<any>;
  updateManufacturingRequestOrderIsHasPlan(ids: string[]): Promise<any>;
  updateMORequestStatusToInprogress(
    request: ManufacturingRequestOrderIdParamRequestDto,
  ): Promise<any>;
  updateProducedQuantity(
    request: UpdateProducedQuantityRequestDto,
  ): Promise<any>;
}
