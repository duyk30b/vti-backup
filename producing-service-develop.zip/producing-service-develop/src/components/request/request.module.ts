import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ClientProxyFactory } from '@nestjs/microservices';
import { ConfigService } from '@config/config.service';
import { RequestService } from './request.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    'REQUEST_SERVICE_CLIENT',
    {
      provide: 'RequestServiceInterface',
      useClass: RequestService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'REQUEST_SERVICE_CLIENT',
      useFactory: (configService: ConfigService) => {
        const requestServiceOptions = configService.get('requestService');

        return ClientProxyFactory.create(requestServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'RequestServiceInterface',
      useClass: RequestService,
    },
  ],
  controllers: [],
})
export class RequestModule {}
