import { Inject, Injectable } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { REQUEST } from '@nestjs/core';
import { Request } from 'express';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { keyBy } from 'lodash';
import { RequestServiceInterface } from './interface/request.service.interface';
import { firstValueFrom } from 'rxjs';
import { isEmpty } from 'lodash';
import { ManufacturingRequestOrderIdParamRequestDto } from './dto/request/manufacturing-request-order-id-param.request.dto';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { NATS_REQUEST } from '@config/nats.config';
import { UpdateProducedQuantityRequestDto } from './dto/request/update-produced-quantity.request.dto';

@Injectable()
export class RequestService implements RequestServiceInterface {
  constructor(
    private readonly natsClientService: NatsClientService,

    @Inject(REQUEST) private readonly req: Request,
  ) {}

  async getManufacturingRequestOrderByIds(
    ids: string[],
    serialize?: boolean,
  ): Promise<any> {
    if (isEmpty(ids)) return [];
    const response = await this.natsClientService.send(
      `${NATS_REQUEST}.get_manufacturing_request_orders`,
      {
        filter: [
          {
            column: 'ids',
            text: ids.join(','),
          },
        ],
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      if (serialize) {
        return {};
      } else {
        return [];
      }
    }
    if (serialize) {
      return keyBy(response.data, 'id');
    }
    return response.data;
  }

  async updateManufacturingRequestOrderIsHasPlan(
    manufacturingRequestOrderIds: string[],
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_REQUEST}.update_manufacturing_request_order_is_has_plan`,
      {
        ids: manufacturingRequestOrderIds,
      },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
    return response.data;
  }

  async getManufacturingRequestOrderByCode(
    code: string,
    serialize?: boolean,
  ): Promise<any> {
    if (isEmpty(code)) return [];
    const response = await this.natsClientService.send(
      `${NATS_REQUEST}.get_manufacturing_request_orders`,
      {
        filter: [
          {
            column: 'code',
            text: code,
          },
        ],
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      if (serialize) {
        return {};
      } else {
        return [];
      }
    }
    if (serialize) {
      return keyBy(response.data, 'id');
    }
    return response.data;
  }
  async getManufacturingRequestOrders(
    payload: any,
    serialize?: boolean,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_REQUEST}.get_manufacturing_request_orders`,
      payload,
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      if (serialize) {
        return {};
      } else {
        return [];
      }
    }
    if (serialize) {
      return keyBy(response.data, 'id');
    }
    return response.data;
  }

  async updateMORequestStatusToInprogress(
    request: ManufacturingRequestOrderIdParamRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_REQUEST}.update_manufacturing_request_order_status_to_inprogress`,
      request,
    );
    return response;
  }

  async updateProducedQuantity(
    request: UpdateProducedQuantityRequestDto,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_REQUEST}.update_produced_quantity`,
      request,
    );

    return response;
  }
}
