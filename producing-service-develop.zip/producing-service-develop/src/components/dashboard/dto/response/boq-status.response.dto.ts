import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

export class DashboardMoStatusResponseDto {
  @ApiProperty({ example: 1 })
  @Expose()
  totalToDoMo: number;

  @ApiProperty({ example: 5 })
  @Expose()
  totalCompletedMo: number;

  @ApiProperty({ example: 20 })
  @Expose()
  totalLateMo: number;

  @ApiProperty({ example: 40 })
  @Expose()
  totalInProgressMo: number;
}
