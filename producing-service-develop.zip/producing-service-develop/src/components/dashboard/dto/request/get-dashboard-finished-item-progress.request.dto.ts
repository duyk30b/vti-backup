import { BaseDto } from './../../../../core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsOptional } from 'class-validator';
import { Type } from 'class-transformer';

export class GetDashboardFinishedItemProgressRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  moId: number;

  @ApiProperty()
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  routingId: number;

  @ApiProperty()
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  producingStepId: number;
}
