import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsNotEmpty } from 'class-validator';
import { PaginationQuery } from '@utils/pagination.query';

export class GetDashboardMoStatusRequestDto extends PaginationQuery {
  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  createdFrom: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  createdTo: Date;
}
