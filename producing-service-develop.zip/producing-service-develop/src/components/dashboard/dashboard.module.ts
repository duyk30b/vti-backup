import { QualityControlEntity } from '@entities/quality-control/quality-control.entity';
import { QualityControlRepository } from '@repositories/quality-control/quality-control.repository';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DashboardService } from '@components/dashboard/dashboard.service';
import { DashboardController } from '@components/dashboard/dashboard.controller';
import { BomEntity } from '@entities/bom/boms.entity';
import { ProducingStepEntity } from '@entities/producing-step/producing-step.entity';
import { BomRepository } from '@repositories/bom/bom.repository';
import { ProducingStepRepository } from '@repositories/produce/producing-step.repository';
import { MoPlanBomRepository } from '@repositories/plan/mo-plan-bom.repository';
import { WorkOrderEntity } from '@entities/work-order/work-order.entity';
import { WorkOrderRepository } from '@repositories/work-order/work-order.repository';
import { MoPlanBomTransactionRepository } from '@repositories/plan/mo-plan-bom-transaction.repository';
import { MoPlanBomTransactionEntity } from '@entities/manufacturing-order/mo-plan-bom-transactions.entity';
import { WorkOrderTransactionEntity } from '@entities/work-order/work-order-transaction.entity';
import { WorkOrderTransactionRepository } from '@repositories/work-order/work-order-transaction.repository';
import { MoPlanBomEntity } from '@entities/manufacturing-order/mo-plan-boms.entity';
import { ManufacturingOrderRepository } from '@repositories/manufacturing-order/manufacturing-order.repository';
import { ManufacturingOrderDetailRepository } from '@repositories/manufacturing-order/manufacturing-order-detail.repository';
import { ManufacturingOrderEntity } from '@entities/manufacturing-order/manufacturing-orders.entity';
import { ManufacturingOrderDetailEntity } from '@entities/manufacturing-order/manufacturing-order-details.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      ManufacturingOrderEntity,
      ManufacturingOrderDetailEntity,
      BomEntity,
      ProducingStepEntity,
      MoPlanBomEntity,
      WorkOrderEntity,
      MoPlanBomTransactionEntity,
      WorkOrderTransactionEntity,
      QualityControlEntity,
    ]),
  ],
  providers: [
    {
      provide: 'ManufacturingOrderRepositoryInterface',
      useClass: ManufacturingOrderRepository,
    },
    {
      provide: 'ManufacturingOrderDetailRepositoryInterface',
      useClass: ManufacturingOrderDetailRepository,
    },
    {
      provide: 'DashboardServiceInterface',
      useClass: DashboardService,
    },
    {
      provide: 'MoPlanBomRepositoryInterface',
      useClass: MoPlanBomRepository,
    },
    {
      provide: 'MoPlanBomTransactionRepositoryInterface',
      useClass: MoPlanBomTransactionRepository,
    },
    {
      provide: 'QualityControlRepositoryInterface',
      useClass: QualityControlRepository,
    },
    {
      provide: 'WorkOrderTransactionRepositoryInterface',
      useClass: WorkOrderTransactionRepository,
    },
    {
      provide: 'BomRepositoryInterface',
      useClass: BomRepository,
    },
    {
      provide: 'WorkOrderRepositoryInterface',
      useClass: WorkOrderRepository,
    },
    {
      provide: 'ProducingStepRepositoryInterface',
      useClass: ProducingStepRepository,
    },
  ],
  controllers: [DashboardController],
})
export class DashboardModule {}
