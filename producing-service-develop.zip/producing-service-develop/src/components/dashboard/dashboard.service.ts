import { div, getDaysBetweenDates, plus } from '@utils/helper';
import { WorkOrderRepositoryInterface } from './../work-order/interface/work-order.repository.interface';
import { MoPlanBomRepositoryInteface } from '@components/plan/inteface/mo-plan-bom.repository.inteface';
import { Inject, Injectable } from '@nestjs/common';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { DashboardSummaryResponseDto } from '@components/dashboard/dto/response/summary.response.dto';
import { DashboardServiceInterface } from '@components/dashboard/interface/dashboard.service.interface';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { GetDashboardMoStatusRequestDto } from './dto/request/get-dashboard-mo-status.request.dto';
import { GetDashboardFinishedItemProgressRequestDto } from './dto/request/get-dashboard-finished-item-progress.request.dto';
import { map, isEmpty } from 'lodash';
import { minus, mul } from '@utils/common';
import * as moment from 'moment';
import { ManufacturingOrderDetailRepositoryInterface } from '@components/manufacturing-order/interface/manufacturing-order-detail.repository.interface';
import { ManufacturingOrderRepositoryInterface } from '@components/manufacturing-order/interface/manufacturing-order.repository.interface';
import { DashboardMoStatusResponseDto } from './dto/response/boq-status.response.dto';
import { ConfigService } from '@config/config.service';

@Injectable()
export class DashboardService implements DashboardServiceInterface {
  private readonly configService: ConfigService;

  constructor(
    @Inject('ManufacturingOrderRepositoryInterface')
    private readonly manufacturingOrderRepository: ManufacturingOrderRepositoryInterface,

    @Inject('ManufacturingOrderDetailRepositoryInterface')
    private readonly manufacturingOrderDetailRepository: ManufacturingOrderDetailRepositoryInterface,

    @Inject('MoPlanBomRepositoryInterface')
    private readonly moPlanBomRepository: MoPlanBomRepositoryInteface,

    @Inject('WorkOrderRepositoryInterface')
    private readonly workOrderRepository: WorkOrderRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {
    this.configService = new ConfigService();
  }

  public async getDashboardSummary(): Promise<any> {
    let totalFinishItem = 0,
      totalSemiFinishItem = 0,
      totalInProgressProducingStep = 0;
    const totalInProgressMo =
      await this.manufacturingOrderRepository.countInProgressMo();
    const inProgressMos =
      await this.manufacturingOrderRepository.getInProgressMoWithPlan(true);

    const inProgressMoIds = map(inProgressMos, 'id');
    if (!isEmpty(inProgressMoIds)) {
      totalFinishItem =
        await this.manufacturingOrderDetailRepository.getTotalInProgressFinishedItems(
          inProgressMoIds,
        );

      totalSemiFinishItem =
        await this.moPlanBomRepository.getTotalSemiFinishItems(inProgressMoIds);

      totalInProgressProducingStep =
        await this.workOrderRepository.getTotalInProgressProducingStep(
          inProgressMoIds,
        );
    }

    const result = {
      totalInProgressMo: totalInProgressMo,
      totalFinishItem: totalFinishItem,
      totalSemiFinishItem:
        minus(totalSemiFinishItem, totalFinishItem) > 0
          ? minus(totalSemiFinishItem, totalFinishItem)
          : 0,
      totalInProgressProducingStep: totalInProgressProducingStep,
    };

    const response = plainToInstance(DashboardSummaryResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getDashboardMoStatus(
    payload: GetDashboardMoStatusRequestDto,
  ): Promise<any> {
    const { createdFrom, createdTo } = payload;

    const data = await Promise.all([
      this.manufacturingOrderRepository.countToDoMo(createdFrom, createdTo),
      this.manufacturingOrderRepository.getInProgressMoWithPlanByTime(
        createdFrom,
        createdTo,
      ),
      this.manufacturingOrderRepository.countCompletedMo(
        createdFrom,
        createdTo,
      ),
    ]);
    let inTimeMos = 0;
    let lateMos = 0;
    data[1].forEach((inProgressMo) => {
      const totalDays = getDaysBetweenDates(inProgressMo.from, inProgressMo.to);
      const today = new Date();
      const timeFromToNow =
        today.setHours(0, 0, 0, 0) >
        new Date(inProgressMo.to).setHours(0, 0, 0, 0)
          ? totalDays
          : getDaysBetweenDates(inProgressMo.from, new Date());

      const forecastPlan = mul(
        div(inProgressMo.totalPlanQuantity || 0, totalDays || 1),
        timeFromToNow || 1,
      );
      if (forecastPlan <= inProgressMo.totalActualQuantity) {
        inTimeMos++;
      } else {
        lateMos++;
      }
    });

    const response = plainToInstance(
      DashboardMoStatusResponseDto,
      {
        totalToDoMo: data[0] > 0 ? data[0] : 0,
        totalInProgressBoq: inTimeMos,
        totalLateMo: lateMos,
        totalCompletedMo: data[2],
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getDashboardFinishedItemProgress(
    payload: GetDashboardFinishedItemProgressRequestDto,
  ): Promise<any> {
    const { moId, itemId } = payload;
    let data = [];
    const inProgressMos =
      await this.manufacturingOrderRepository.getInProgressMoWithPlan(
        true,
        false,
        moId,
      );
    if (!isEmpty(inProgressMos)) {
      data = await this.getFinishedItemPlanChart(
        moId ? [moId] : map(inProgressMos, 'id'),
        itemId,
      );
    }

    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async getFinishedItemPlanChart(moIds: number[], itemId?: number) {
    const moSchedules =
      await this.moPlanBomRepository.getFinishedItemScheduleByMoIds(
        moIds,
        itemId,
      );

    const data = [];
    let accumlateQuantity = 0;
    let accumlateActualQuantity = 0;
    let accumlateDelayQuantity = 0;

    if (!isEmpty(moSchedules)) {
      moSchedules.forEach((schedule) => {
        if (schedule.executionDay) {
          const amountOfDelay = minus(
            schedule.quantity || 0,
            schedule.actualQuantity || 0,
          );
          accumlateQuantity = plus(accumlateQuantity, schedule.quantity || 0);
          accumlateActualQuantity = plus(
            accumlateActualQuantity,
            schedule.actualQuantity || 0,
          );
          accumlateDelayQuantity = plus(
            accumlateDelayQuantity,
            amountOfDelay || 0,
          );
          data.push({
            date: moment(schedule.executionDay).format('DD/MM/YYYY'),
            planQuantity: accumlateQuantity,
            producedQuantity: accumlateActualQuantity,
            todoQuantity:
              accumlateDelayQuantity > 0 ? accumlateDelayQuantity : 0,
          });
        }
      });
    }

    return data;
  }

  private async getAllItemPlanChart(
    moIds: number[],
    itemId?: number,
    routingId?: number,
    producingStepId?: number,
  ) {
    const moSchedules =
      await this.moPlanBomRepository.getAllItemScheduleByMoIds(
        moIds,
        itemId,
        routingId,
        producingStepId,
      );
    const data = [];
    let accumlateQuantity = 0;
    let accumlateActualQuantity = 0;
    let accumlateDelayQuantity = 0;
    let accumlateRepairedQuantity = 0;

    if (!isEmpty(moSchedules)) {
      moSchedules.forEach((schedule) => {
        if (schedule.executionDay) {
          const amountOfDelay = minus(
            schedule.quantity || 0,
            schedule.actualQuantity || 0,
          );
          accumlateQuantity = plus(accumlateQuantity, schedule.quantity || 0);
          accumlateActualQuantity = plus(
            accumlateActualQuantity,
            schedule.actualQuantity || 0,
          );
          accumlateRepairedQuantity = plus(
            accumlateRepairedQuantity,
            schedule.repairedQuantity || 0,
          );
          accumlateDelayQuantity = plus(
            accumlateDelayQuantity,
            amountOfDelay || 0,
          );
          data.push({
            date: moment(schedule.executionDay).format('DD/MM/YYYY'),
            planQuantity: accumlateQuantity,
            producedQuantity: accumlateActualQuantity,
            todoQuantity:
              accumlateDelayQuantity > 0 ? accumlateDelayQuantity : 0,
            repairedQuantity: accumlateRepairedQuantity,
          });
        }
      });
    }

    return data;
  }

  public async getDashboardQualityControlProgress(
    payload: GetDashboardFinishedItemProgressRequestDto,
  ): Promise<any> {
    const { moId, itemId, routingId, producingStepId } = payload;
    let moSchedules = [];
    const defaultTimeZone = this.configService.get('defaultTimeZone');
    const inProgressMos =
      await this.manufacturingOrderRepository.getInProgressMoWithPlan(
        false,
        true,
        moId,
        itemId,
        routingId,
        producingStepId,
      );
    if (!isEmpty(inProgressMos)) {
      moSchedules =
        await this.moPlanBomRepository.getAllItemQualityControlScheduleByMoIds(
          moId ? [moId] : map(inProgressMos, 'id'),
          itemId,
          routingId,
          producingStepId,
          defaultTimeZone,
        );
    }

    const data = [];
    if (!isEmpty(moSchedules)) {
      let accumlateQuantity = 0;
      let accumlateActualQuantity = 0;
      let accumlateDelayQuantity = 0;
      let accumlateRepairedQuantity = 0;
      let accumlateQcPassQuantity = 0;
      let accumlateQcRejectQuantity = 0;

      moSchedules.forEach((schedule, i) => {
        if (schedule.executionDay) {
          const amountOfDelay = minus(
            schedule.quantity || 0,
            schedule.actualQuantity || 0,
          );
          accumlateQuantity = plus(accumlateQuantity, schedule.quantity || 0);
          accumlateActualQuantity = plus(
            accumlateActualQuantity,
            schedule.actualQuantity || 0,
          );
          accumlateQcPassQuantity = plus(
            accumlateQcPassQuantity,
            schedule.qcPassQuantity || 0,
          );
          accumlateQcRejectQuantity = plus(
            accumlateQcRejectQuantity,
            schedule.errorQuantity || 0,
          );
          accumlateRepairedQuantity = plus(
            accumlateRepairedQuantity,
            schedule.repairedQuantity || 0,
          );
          accumlateDelayQuantity = plus(
            accumlateDelayQuantity,
            amountOfDelay || 0,
          );
          let needToBeRepair = 0;
          if (i === 0) {
            needToBeRepair =
              minus(
                parseFloat(schedule?.errorQuantity) || 0,
                parseFloat(schedule?.repairedQuantity) || 0,
              ) || 0;
          } else {
            needToBeRepair = plus(
              data[i - 1].needToBeRepair || 0,
              minus(
                schedule?.errorQuantity || 0,
                schedule?.repairedQuantity || 0,
              ) || 0,
            );
          }
          data.push({
            date: moment(schedule.executionDay).format('DD/MM/YYYY'),
            planQuantity: accumlateQuantity,
            producedQuantity: accumlateActualQuantity,
            todoQuantity:
              accumlateDelayQuantity > 0 ? accumlateDelayQuantity : 0,
            repairedQuantity: accumlateRepairedQuantity,
            qcPassQuantity: accumlateQcPassQuantity,
            qcRejectQuantity: accumlateQcRejectQuantity,
            needToBeRepair: needToBeRepair,
          });
        }
      });
    }

    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getDashboardProducingStepProgress(
    payload: GetDashboardFinishedItemProgressRequestDto,
  ): Promise<any> {
    const { moId, itemId, routingId, producingStepId } = payload;

    let data = [];
    const inProgressMos =
      await this.manufacturingOrderRepository.getInProgressMoWithPlan(
        false,
        true,
        moId,
        itemId,
        routingId,
        producingStepId,
      );
    if (!isEmpty(inProgressMos)) {
      data = await this.getAllItemPlanChart(
        moId ? [moId] : map(inProgressMos, 'id'),
        itemId,
        routingId,
        producingStepId,
      );
    }

    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
