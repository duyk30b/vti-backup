import { GetDashboardFinishedItemProgressRequestDto } from '../dto/request/get-dashboard-finished-item-progress.request.dto';
import { GetDashboardMoStatusRequestDto } from '../dto/request/get-dashboard-mo-status.request.dto';
export interface DashboardServiceInterface {
  getDashboardSummary(): Promise<any>;
  getDashboardMoStatus(payload: GetDashboardMoStatusRequestDto): Promise<any>;
  getDashboardFinishedItemProgress(
    payload: GetDashboardFinishedItemProgressRequestDto,
  ): Promise<any>;
  getDashboardQualityControlProgress(
    payload: GetDashboardFinishedItemProgressRequestDto,
  ): Promise<any>;
  getDashboardProducingStepProgress(
    payload: GetDashboardFinishedItemProgressRequestDto,
  ): Promise<any>;
}
