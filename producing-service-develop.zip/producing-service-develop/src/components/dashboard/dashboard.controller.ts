import { Body, Controller, Get, Inject, Query } from '@nestjs/common';
import { MessagePattern, Transport } from '@nestjs/microservices';
import { DashboardServiceInterface } from '@components/dashboard/interface/dashboard.service.interface';
import { isEmpty } from 'lodash';
import { GetDashboardFinishedItemProgressRequestDto } from './dto/request/get-dashboard-finished-item-progress.request.dto';
import { GetDashboardMoStatusRequestDto } from './dto/request/get-dashboard-mo-status.request.dto';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { DashboardSummaryResponseDto } from './dto/response/summary.response.dto';
import { DEFAULT_TRANSPORT } from '@utils/constant';

@Controller('dashboards')
export class DashboardController {
  constructor(
    @Inject('DashboardServiceInterface')
    private readonly dashboardService: DashboardServiceInterface,
  ) {}

  @Get('summary')
  @ApiOperation({
    tags: ['Dashboard'],
    summary: 'Dashboard summary',
    description: 'thông tin thống kê tổng',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: DashboardSummaryResponseDto,
  })
  @MessagePattern('dashboard_summary', DEFAULT_TRANSPORT)
  public async getDashboardSummary(): Promise<any> {
    return await this.dashboardService.getDashboardSummary();
  }

  @Get('/mo-status/summary')
  @ApiOperation({
    tags: ['Dashboard'],
    summary: 'Dashboard mo Status Chart',
    description: 'Trạng thái MO',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: DashboardSummaryResponseDto,
  })
  @MessagePattern('dashboard_mo_status', DEFAULT_TRANSPORT)
  public async getDashboardMoStatus(
    @Query() payload: GetDashboardMoStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.dashboardService.getDashboardMoStatus(request);
  }

  @Get('/finished-items/progress')
  @ApiOperation({
    tags: ['Dashboard'],
    summary: 'Dashboard Finished Item Chart',
    description: 'Tiến độ sản xuất theo thành phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: DashboardSummaryResponseDto,
  })
  @MessagePattern('dashboard_finished_item_progress', DEFAULT_TRANSPORT)
  public async getDashboardFinishedItemProgress(
    @Query() payload: GetDashboardFinishedItemProgressRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.dashboardService.getDashboardFinishedItemProgress(
      request,
    );
  }

  @Get('/quality-controls/progress')
  @ApiOperation({
    tags: ['Dashboard'],
    summary: 'Dashboard Quality Control Chart',
    description: 'Chất lượng sản xuất theo thành phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: DashboardSummaryResponseDto,
  })
  public async getDashboardQualityControlProgress(
    @Query() payload: GetDashboardFinishedItemProgressRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.dashboardService.getDashboardQualityControlProgress(
      request,
    );
  }

  @Get('/producing-steps/progress')
  @ApiOperation({
    tags: ['Dashboard'],
    summary: 'Dashboard Quality Control Chart',
    description: 'Tiến độ sản xuất theo công đoạn',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: DashboardSummaryResponseDto,
  })
  @MessagePattern('dashboard_producing_step_progress', DEFAULT_TRANSPORT)
  public async getDashboardProducingStepProgress(
    @Query() payload: GetDashboardFinishedItemProgressRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.dashboardService.getDashboardProducingStepProgress(
      request,
    );
  }

  // TO DO: remove when refactor done
  @MessagePattern('dashboard_quality_control_progress', DEFAULT_TRANSPORT)
  public async getDashboardQualityControlProgressTcp(
    @Body() payload: GetDashboardFinishedItemProgressRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.dashboardService.getDashboardQualityControlProgress(
      request,
    );
  }
}
