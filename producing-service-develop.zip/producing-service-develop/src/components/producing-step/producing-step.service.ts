import { ConfigService } from '@config/config.service';
import { Inject, Injectable } from '@nestjs/common';
import { ProducingStepServiceInterface } from '@components/producing-step/interface/producing-step.service.interface';
import { ProducingStepRepositoryInterface } from '@components/producing-step/interface/producing-step.repository.interface';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { CreateProducingStepRequestDto } from '@components/producing-step/dto/request/create-producing-step.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { ProducingStepResponseDto } from '@components/producing-step/dto/response/producing-step.response.dto';
import { ApiError } from '@utils/api.error';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { plainToInstance } from 'class-transformer';
import { ResponseBuilder } from '@utils/response-builder';
import { UpdateProducingStepsRequestDto } from '@components/producing-step/dto/request/update-producing-steps.request.dto';
import { ILike, In, Not } from 'typeorm';
import { GetListProducingStepRequestDto } from '@components/producing-step/dto/request/get-list-producing-step.request.dto';
import { PagingResponse } from '@utils/paging.response';
import { GetProducingStepDto } from '@components/producing-step/dto/request/get-producing-step.dto';
import { ProducingStepSuccessResponseDto } from '@components/producing-step/dto/response/producing-step-success.response.dto';
import { isEmpty, keyBy, uniq, flatMap, map, forEach } from 'lodash';
import { RoutingProducingStepRepositoryInterface } from '@components/producing-step/interface/routing-producing-step.repository.interface';
import { GetProducingStepByRoutingVersionIdRequestDto } from '@components/producing-step/dto/request/get-producing-step-by-routing-version-id.request.dto';
import { GetProducingStepByRoutingVersionIdResponse } from '@components/producing-step/dto/response/get-producing-step-by-routing-version-id.response.dto';
import { SetStatusRequestDto } from './dto/request/set-status.request.dto';
import {
  CAN_DELETE_PRODUCING_STEP_STATUS,
  CAN_UPDATE_PRODUCING_STEP_STATUS,
  ProducingStepStatusEnum,
} from './producing-step.constant';
import { QualityControlServiceInterface } from '@components/qmx/interface/quality-control.service.interface';
import { GetProducingStepProgressDashboardRequestDto } from './dto/request/get-producing-step-progress-dashboard.request.dto';
import { ManufacturingOrderRepositoryInterface } from '@components/manufacturing-order/interface/manufacturing-order.repository.interface';
import { minus, plus } from '@utils/common';
import { GetProducingStepProgressDashboardResponseDto } from './dto/response/get-producing-step-progress-dashboard.response.dto';
import { GetProducingStepsAndWorkCenterByIdsRequestDto } from './dto/request/get-producing-step-and-work-center-by-ids.request.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { WorkCenterServiceInterface } from '@components/work-center/interface/work-center.service.interface';

@Injectable()
export class ProducingStepService implements ProducingStepServiceInterface {
  constructor(
    @Inject('ProducingStepRepositoryInterface')
    private readonly producingStepRepository: ProducingStepRepositoryInterface,

    @Inject('RoutingProducingStepRepositoryInterface')
    private readonly routingProducingStepRepository: RoutingProducingStepRepositoryInterface,

    @Inject('ManufacturingOrderRepositoryInterface')
    private readonly manufacturingOrderRepository: ManufacturingOrderRepositoryInterface,

    @Inject('QmxServiceInterface')
    private readonly qualityControlService: QualityControlServiceInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('WorkCenterServiceInterface')
    protected readonly workCenterService: WorkCenterServiceInterface,

    private readonly i18n: I18nRequestScopeService,

    @Inject('ConfigServiceInterface')
    private readonly configService: ConfigService,
  ) {}

  public async createProducingStep(
    request: CreateProducingStepRequestDto,
  ): Promise<ResponsePayload<ProducingStepResponseDto | any>> {
    const { name, code, inputQc, outputQc } = request;
    const producingStep = await this.producingStepRepository.findByCondition([
      { name: ILike(name) },
      { code: ILike(code) },
    ]);
    if (!isEmpty(producingStep)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_OR_NAME_ALREADY_EXISTS'),
      ).toResponse();
    }
    if (inputQc?.enable) {
      const quanlityInputPoint =
        await this.qualityControlService.getQuanlityPointById(
          inputQc.qcCriteriaId,
        );
      if (!quanlityInputPoint) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.QUANLITY_INPUT_POINT_INVALID'),
        ).toResponse();
      }
    }

    if (outputQc?.enable) {
      const quanlityOutputPoint =
        await this.qualityControlService.getQuanlityPointById(
          outputQc.qcCriteriaId,
        );
      if (!quanlityOutputPoint) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.QUANLITY_OUTPUT_POINT_INVALID'),
        ).toResponse();
      }
    }

    const payloadCreate = {
      ...request,
      createdBy: request.userId,
      qcCheck: request.outputQc.qcCriteriaId ? 1 : 0,
      qcCriteriaId: request.outputQc.qcCriteriaId || 0,
      inputQcCheck: request.inputQc.qcCriteriaId ? 1 : 0,
      inputQcCriteriaId: request.inputQc.qcCriteriaId || 0,
    };
    const data = await this.producingStepRepository.create(payloadCreate);
    const response = plainToInstance(ProducingStepResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async updateProducingStep(
    request: UpdateProducingStepsRequestDto,
  ): Promise<ResponsePayload<ProducingStepResponseDto | any>> {
    const { id, name, code, inputQc, outputQc } = request;
    const findProducingStep = await this.producingStepRepository.findOneById(
      id,
    );
    if (!findProducingStep) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (!CAN_UPDATE_PRODUCING_STEP_STATUS.includes(findProducingStep.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.PRODUCING_STEP_WAS_CONFIRMED'),
      ).toResponse();
    }

    if (inputQc.enable) {
      const quanlityInputPoint =
        await this.qualityControlService.getQuanlityPointById(
          inputQc.qcCriteriaId,
        );
      if (!quanlityInputPoint) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.QUANLITY_INPUT_POINT_INVALID'),
        ).toResponse();
      }
    }

    if (outputQc.enable) {
      const quanlityOutputPoint =
        await this.qualityControlService.getQuanlityPointById(
          outputQc.qcCriteriaId,
        );
      if (!quanlityOutputPoint) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.QUANLITY_OUTPUT_POINT_INVALID'),
        ).toResponse();
      }
    }

    const producingStep = await this.producingStepRepository.findByCondition([
      {
        code,
        id: Not(id),
      },
      {
        name,
        id: Not(id),
      },
    ]);
    if (!isEmpty(producingStep)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_OR_NAME_ALREADY_EXISTS'),
      ).toResponse();
    }
    const payloadCreate = {
      ...request,
      qcCheck: request.outputQc.qcCriteriaId ? 1 : 0,
      qcCriteriaId: request.outputQc.qcCriteriaId || 0,
      inputQcCheck: request.inputQc.qcCriteriaId ? 1 : 0,
      inputQcCriteriaId: request.inputQc.qcCriteriaId || 0,
      createdBy: request.userId,
    };
    const data = await this.producingStepRepository.create(payloadCreate);
    const response = plainToInstance(ProducingStepResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(
        await this.i18n.translate('message.defineProducingSteps.updateSuccess'),
      )
      .build();
  }

  public async getListProducingStep(
    payload: GetListProducingStepRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { data, count } = await this.producingStepRepository.getList(payload);
    const dataReturn = plainToInstance(ProducingStepResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: payload.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getDetailProducingStep(
    request: GetProducingStepDto,
  ): Promise<ResponsePayload<ProducingStepResponseDto | any>> {
    const producingStep: any = await this.producingStepRepository.findOneById(
      request.id,
    );

    if (!producingStep) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const qcCriteriaIds = uniq([
      producingStep.inputQc?.qcCriteriaId,
      producingStep.outputQc?.qcCriteriaId,
    ]).filter((qcCriteriaId) => qcCriteriaId);
    let qcCriterialByIds = {};
    if (!isEmpty(qcCriteriaIds)) {
      const qcCriterials =
        await this.qualityControlService.getQualityPointsByIds(qcCriteriaIds);
      qcCriterialByIds = keyBy(qcCriterials, 'id');
    }

    if (producingStep?.createdBy) {
      const createdUser = await this.userService.getUserById(
        producingStep?.createdBy,
      );
      producingStep.createdBy = {
        id: producingStep.createdBy,
        fullName: createdUser?.fullName,
        username: createdUser?.username,
      };
    }
    const response = plainToInstance(
      ProducingStepResponseDto,
      {
        ...producingStep,
        inputQc: {
          ...producingStep.inputQc,
          qcName: qcCriterialByIds[producingStep.inputQc?.qcCriteriaId]?.name,
        },
        outputQc: {
          ...producingStep.outputQc,
          qcName: qcCriterialByIds[producingStep.outputQc?.qcCriteriaId]?.name,
        },
      },
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async deleteProducingStep(
    request: GetProducingStepDto,
  ): Promise<ResponsePayload<ProducingStepSuccessResponseDto | any>> {
    const producingStep = await this.producingStepRepository.findOneById(
      request.id,
    );

    if (!producingStep) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (!CAN_DELETE_PRODUCING_STEP_STATUS.includes(producingStep.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.PRODUCING_STEP_WAS_CONFIRMED'),
      ).toResponse();
    }

    const routingVersion =
      await this.routingProducingStepRepository.findOneByCondition({
        producingStepId: request.id,
      });
    if (routingVersion) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_DELETE'),
      ).toResponse();
    }

    try {
      await this.producingStepRepository.remove(request.id);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    const response = plainToInstance(
      ProducingStepSuccessResponseDto,
      { id: request.id },
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withMessage(
        await this.i18n.translate('message.defineProducingSteps.deleteSuccess'),
      )
      .build();
  }

  async getProducingStepByRoutingVersionId(
    request: GetProducingStepByRoutingVersionIdRequestDto,
  ): Promise<
    ResponsePayload<GetProducingStepByRoutingVersionIdResponse | any>
  > {
    const routeVersionProducingStepRaw =
      await this.routingProducingStepRepository.findByCondition({
        routingId: request.routeVersionId,
      });
    if (isEmpty(routeVersionProducingStepRaw)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const producingSteps =
      await this.producingStepRepository.getProducingStepsByRoutingId(
        request.routeVersionId,
      );

    const response = plainToInstance(
      GetProducingStepByRoutingVersionIdResponse,
      { producingSteps: producingSteps },
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<ProducingStepResponseDto | any>> {
    const { userId, id } = request;
    const producingStep = await this.producingStepRepository.findOneById(id);

    if (!producingStep) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.PRODUCING_STEP_NOT_FOUND'),
        )
        .build();
    }

    producingStep.approverId = userId;
    producingStep.approvedAt = new Date(Date.now());
    producingStep.status = ProducingStepStatusEnum.CONFIRMED;
    const result = await this.producingStepRepository.create(producingStep);
    const response = plainToInstance(ProducingStepResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.PRODUCING_STEP_CONFIRMED'))
      .build();
  }

  public async reject(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<ProducingStepResponseDto | any>> {
    const { userId, id } = request;
    const producingStep = await this.producingStepRepository.findOneById(id);

    if (!producingStep) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.PRODUCING_STEP_NOT_FOUND'),
        )
        .build();
    }

    if (producingStep.status === ProducingStepStatusEnum.CONFIRMED) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.PRODUCING_STEP_WAS_CONFIRMED'),
      ).toResponse();
    }

    producingStep.approverId = userId;
    producingStep.approvedAt = new Date(Date.now());
    producingStep.status = ProducingStepStatusEnum.REJECT;
    const result = await this.producingStepRepository.create(producingStep);
    const response = plainToInstance(ProducingStepResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async getProducingStepProgresssDashboard(
    request: GetProducingStepProgressDashboardRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { manufacturingOrderId, itemId, producingStepId, workCenterId } =
      request;
    const defaultTimeZone = this.configService.get('defaultTimeZone');
    const moSchedule =
      await this.manufacturingOrderRepository.getProduceProgressByMoId(
        manufacturingOrderId,
        itemId,
        producingStepId,
        workCenterId,
        defaultTimeZone,
      );
    const data = [];
    let accumlateQuantity = 0;
    let accumlateModerationQuantity = 0;
    let accumlateActualQuantity = 0;
    let accumlateDelayQuantity = 0;
    if (!isEmpty(moSchedule?.schedules)) {
      moSchedule.schedules.forEach((schedule) => {
        if (schedule.executionDay) {
          const amountOfDelay = minus(
            schedule.quantity || 0,
            schedule.actualQuantity || 0,
          );
          accumlateQuantity = plus(accumlateQuantity, schedule.quantity || 0);
          accumlateModerationQuantity = plus(
            accumlateModerationQuantity,
            schedule.moderationQuantity || 0,
          );
          accumlateActualQuantity = plus(
            accumlateActualQuantity,
            schedule.actualQuantity || 0,
          );
          accumlateDelayQuantity = plus(
            accumlateDelayQuantity,
            amountOfDelay || 0,
          );
          data.push({
            ...schedule,
            delayQuantity: amountOfDelay > 0 ? amountOfDelay : 0,
            accumlateQuantity: accumlateQuantity,
            accumlateModerationQuantity: accumlateModerationQuantity,
            accumlateActualQuantity: accumlateActualQuantity,
            accumlateDelayQuantity:
              accumlateDelayQuantity > 0 ? accumlateDelayQuantity : 0,
          });
        }
      });
    }

    const response = plainToInstance(
      GetProducingStepProgressDashboardResponseDto,
      data,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async getProducingStepsAndWorkCenter(
    request: GetProducingStepsAndWorkCenterByIdsRequestDto,
  ): Promise<any> {
    const { producingStepIds, factoryId, routingIds } = request;
    const response =
      await this.producingStepRepository.getProducingStepsAndWorkCenter(
        producingStepIds,
        factoryId,
        routingIds,
      );

    const workCenterIds = uniq(map(flatMap(response, 'workCenters'), 'id'));
    let producingStepWorkCenters = [];
    const getWorkCentersResponse =
      await this.workCenterService.getWorkCenterByIds(workCenterIds);
    if (getWorkCentersResponse.statusCode === ResponseCodeEnum.SUCCESS) {
      producingStepWorkCenters = getWorkCentersResponse.data;
    }
    const serializedWorkCenters = keyBy(producingStepWorkCenters, 'id');

    const returnData = response?.map((producingStep) => {
      const proStepWorkCenters = producingStepWorkCenters?.filter(
        (workCenter) => workCenter.producingStepId === producingStep.id,
      );
      let workingCapacity = 0;
      if (!isEmpty(proStepWorkCenters)) {
        workingCapacity = map(
          proStepWorkCenters,
          'actualWorkingCapacity',
        )?.reduce((prev, cur) => plus(prev, cur), 0);
      }

      return {
        ...producingStep,
        workingCapacity,
        workCenters: producingStep?.workCenters?.map((workCenter) => ({
          ...workCenter,
          actualWorkingCapacity:
            serializedWorkCenters[workCenter.id]?.actualWorkingCapacity,
        })),
      };
    });

    return new ResponseBuilder(returnData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  async getListProducingStepByIds(ids: number[]): Promise<any> {
    const response = await this.producingStepRepository.findWithRelations({
      where: {
        id: In(ids),
      },
      relations: ['workCenter'],
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }
}
