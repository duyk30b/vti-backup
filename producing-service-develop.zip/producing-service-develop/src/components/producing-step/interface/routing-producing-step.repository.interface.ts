import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { RoutingProducingStepEntity } from '@entities/producing-step/routing-producing-step.entity';

export type RoutingProducingStepRepositoryInterface =
  BaseInterfaceRepository<RoutingProducingStepEntity>;
