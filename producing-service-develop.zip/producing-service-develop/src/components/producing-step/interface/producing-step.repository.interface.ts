import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { ProducingStepEntity } from '@entities/producing-step/producing-step.entity';
import { GetListProducingStepRequestDto } from '@components/producing-step/dto/request/get-list-producing-step.request.dto';

export interface ProducingStepRepositoryInterface
  extends BaseInterfaceRepository<ProducingStepEntity> {
  getList(payload: GetListProducingStepRequestDto): Promise<any>;
  getProducingStepsByRoutingId(request: any);
  getFirstStepOfBom(bomId: number, planId: number): Promise<any>;
  checkIsFirstStepInRouting(
    routingId: number,
    producingStepId: number,
  ): Promise<boolean>;
  getProducingStepsAndWorkCenter(
    producingStepIds: number[],
    factoryId: number,
    routingIds?: number[],
  ): Promise<any>;
  getCount(): Promise<any>;
  getLatestStepInRouting(routingId: number): Promise<any>;
}
