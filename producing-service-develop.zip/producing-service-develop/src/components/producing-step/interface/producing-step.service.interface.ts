import { CreateProducingStepRequestDto } from '@components/producing-step/dto/request/create-producing-step.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { ProducingStepResponseDto } from '@components/producing-step/dto/response/producing-step.response.dto';
import { UpdateProducingStepsRequestDto } from '@components/producing-step/dto/request/update-producing-steps.request.dto';
import { GetListProducingStepRequestDto } from '@components/producing-step/dto/request/get-list-producing-step.request.dto';
import { GetProducingStepDto } from '@components/producing-step/dto/request/get-producing-step.dto';
import { ProducingStepSuccessResponseDto } from '@components/producing-step/dto/response/producing-step-success.response.dto';
import { GetProducingStepByRoutingVersionIdRequestDto } from '@components/producing-step/dto/request/get-producing-step-by-routing-version-id.request.dto';
import { GetProducingStepByRoutingVersionIdResponse } from '@components/producing-step/dto/response/get-producing-step-by-routing-version-id.response.dto';
import { SetStatusRequestDto } from '../dto/request/set-status.request.dto';
import { GetProducingStepProgressDashboardRequestDto } from '../dto/request/get-producing-step-progress-dashboard.request.dto';
import { GetProducingStepsAndWorkCenterByIdsRequestDto } from '../dto/request/get-producing-step-and-work-center-by-ids.request.dto';

export interface ProducingStepServiceInterface {
  createProducingStep(
    request: CreateProducingStepRequestDto,
  ): Promise<ResponsePayload<ProducingStepResponseDto | any>>;
  updateProducingStep(
    request: UpdateProducingStepsRequestDto,
  ): Promise<ResponsePayload<ProducingStepResponseDto | any>>;
  getListProducingStep(
    payload: GetListProducingStepRequestDto,
  ): Promise<ResponsePayload<any>>;
  getDetailProducingStep(
    request: GetProducingStepDto,
  ): Promise<ResponsePayload<ProducingStepResponseDto | any>>;
  deleteProducingStep(
    request: GetProducingStepDto,
  ): Promise<ResponsePayload<ProducingStepSuccessResponseDto | any>>;
  getProducingStepByRoutingVersionId(
    request: GetProducingStepByRoutingVersionIdRequestDto,
  ): Promise<ResponsePayload<GetProducingStepByRoutingVersionIdResponse | any>>;
  confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<ProducingStepResponseDto | any>>;
  reject(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<ProducingStepResponseDto | any>>;
  getProducingStepProgresssDashboard(
    request: GetProducingStepProgressDashboardRequestDto,
  ): Promise<ResponsePayload<ProducingStepResponseDto | any>>;
  getProducingStepsAndWorkCenter(
    request: GetProducingStepsAndWorkCenterByIdsRequestDto,
  ): Promise<any>;
  getListProducingStepByIds(ids: number[]): Promise<any>;
}
