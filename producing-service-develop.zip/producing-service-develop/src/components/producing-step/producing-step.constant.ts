export enum ProducingStepStatusEnum {
  CREATED = 0,
  CONFIRMED = 1,
  REJECT = 2,
}

export enum ProducingStepSwitchModeEnum {
  CANNOT_MOVE_WHEN_UN_FULL_FILL = 0,
  MOVE_WHEN_UN_FULL_FILL = 1,
}

export const CAN_UPDATE_PRODUCING_STEP_STATUS: number[] = [
  ProducingStepStatusEnum.CREATED,
  ProducingStepStatusEnum.REJECT,
];

export const CAN_DELETE_PRODUCING_STEP_STATUS: number[] = [
  ProducingStepStatusEnum.CREATED,
  ProducingStepStatusEnum.REJECT,
];
