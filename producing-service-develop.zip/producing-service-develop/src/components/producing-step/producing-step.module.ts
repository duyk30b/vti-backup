import { RoutingProducingStepEntity } from '@entities/producing-step/routing-producing-step.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProducingStepEntity } from '@entities/producing-step/producing-step.entity';
import { ProducingStepRepository } from '@repositories/produce/producing-step.repository';
import { ProducingStepService } from '@components/producing-step/producing-step.service';
import { ProducingStepController } from '@components/producing-step/producing-step.controller';
import { RoutingProducingStepRepository } from '@repositories/produce/routing-producing-step.repository';
import { WorkCenterRepository } from '@repositories/work-center/work-center.repository';
import { WorkCenterEntity } from '@entities/work-center/work-center.entity';
import { QualityControlService } from '@components/qmx/quality-control.service';
import { ManufacturingOrderEntity } from '@entities/manufacturing-order/manufacturing-orders.entity';
import { ManufacturingOrderRepository } from '@repositories/manufacturing-order/manufacturing-order.repository';
import { UserService } from '@components/user/user.service';
import { ConfigService } from '@config/config.service';
import { ConfigModule } from '@nestjs/config';

@Module({
  imports: [
    ConfigModule,
    TypeOrmModule.forFeature([
      ProducingStepEntity,
      RoutingProducingStepEntity,
      WorkCenterEntity,
      ManufacturingOrderEntity,
    ]),
  ],
  providers: [
    {
      provide: 'ProducingStepRepositoryInterface',
      useClass: ProducingStepRepository,
    },
    {
      provide: 'ManufacturingOrderRepositoryInterface',
      useClass: ManufacturingOrderRepository,
    },
    {
      provide: 'WorkCenterRepositoryInterface',
      useClass: WorkCenterRepository,
    },
    {
      provide: 'ProducingStepServiceInterface',
      useClass: ProducingStepService,
    },
    {
      provide: 'RoutingProducingStepRepositoryInterface',
      useClass: RoutingProducingStepRepository,
    },
    {
      provide: 'QmxServiceInterface',
      useClass: QualityControlService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'ConfigServiceInterface',
      useClass: ConfigService,
    },
  ],
  exports: [
    {
      provide: 'ProducingStepRepositoryInterface',
      useClass: ProducingStepRepository,
    },
  ],
  controllers: [ProducingStepController],
})
export class ProducingStepModule {}
