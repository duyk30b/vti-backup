import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ProducingStepServiceInterface } from '@components/producing-step/interface/producing-step.service.interface';
import { MessagePattern, Transport } from '@nestjs/microservices';
import { CreateProducingStepRequestDto } from '@components/producing-step/dto/request/create-producing-step.request.dto';
import { isEmpty } from 'lodash';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { UpdateProducingStepsRequestDto } from '@components/producing-step/dto/request/update-producing-steps.request.dto';
import { GetListProducingStepRequestDto } from '@components/producing-step/dto/request/get-list-producing-step.request.dto';
import { GetProducingStepDto } from '@components/producing-step/dto/request/get-producing-step.dto';
import { GetProducingStepByRoutingVersionIdRequestDto } from '@components/producing-step/dto/request/get-producing-step-by-routing-version-id.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { SetStatusRequestDto } from './dto/request/set-status.request.dto';
import { ProducingStepResponseDto } from './dto/response/producing-step.response.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CREATE_PRODUCING_STEP_PERMISSION,
  UPDATE_PRODUCING_STEP_PERMISSION,
  DELETE_PRODUCING_STEP_PERMISSION,
  DETAIL_PRODUCING_STEP_PERMISSION,
  LIST_PRODUCING_STEP_PERMISSION,
  CONFIRM_PRODUCING_STEP_PERMISSION,
  REJECT_PRODUCING_STEP_PERMISSION,
} from '@utils/permissions/producing-step';
import { GetProducingStepProgressDashboardRequestDto } from './dto/request/get-producing-step-progress-dashboard.request.dto';
import { GetProducingStepsAndWorkCenterByIdsRequestDto } from './dto/request/get-producing-step-and-work-center-by-ids.request.dto';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { GetListProducingStepResponseDto } from './dto/response/get-list-producing-step.response.dto';
import { DEFAULT_TRANSPORT } from '@utils/constant';
import { NATS_PRODUCE } from '@config/nats.config';

@Controller('producing-steps')
export class ProducingStepController {
  constructor(
    @Inject('ProducingStepServiceInterface')
    private readonly producingStepService: ProducingStepServiceInterface,
  ) {}

  @MessagePattern(`${NATS_PRODUCE}.ping`, DEFAULT_TRANSPORT)
  public async get(): Promise<any> {
    return new ResponseBuilder('ITEM: PONG')
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  @PermissionCode(CREATE_PRODUCING_STEP_PERMISSION.code)
  @Post('create')
  @ApiOperation({
    tags: ['Produces'],
    summary: 'Create new producing-step',
    description: 'Tao moi mot producing-step',
  })
  @ApiResponse({
    status: 200,
    description: 'Created successfully',
    type: ProducingStepResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.create_producing_steps`, DEFAULT_TRANSPORT)
  public async createProducingStep(
    @Body() body: CreateProducingStepRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.producingStepService.createProducingStep(request);
  }

  @PermissionCode(UPDATE_PRODUCING_STEP_PERMISSION.code)
  @Put(':id')
  @ApiOperation({
    tags: ['Produces'],
    summary: 'Update producing-step',
    description: 'Cap nhat mot producing-step',
  })
  @ApiResponse({
    status: 200,
    description: 'Update Successfully',
    type: CreateProducingStepRequestDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.update_producing_step`, DEFAULT_TRANSPORT)
  public async updateProducingStep(
    @Param('id', new ParseIntPipe()) id,
    @Body() body: UpdateProducingStepsRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;

    return await this.producingStepService.updateProducingStep(request);
  }

  @PermissionCode(LIST_PRODUCING_STEP_PERMISSION.code)
  @Get('list')
  @ApiOperation({
    tags: ['Produces'],
    summary: 'Get list producing-step',
    description: 'Get list producing-step',
  })
  @ApiResponse({
    status: 200,
    description: 'Get list successfully',
    type: GetListProducingStepResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.get_list_producing_step`, DEFAULT_TRANSPORT)
  public async getListProducingStep(
    @Query() body: GetListProducingStepRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.producingStepService.getListProducingStep(request);
  }

  @PermissionCode(DETAIL_PRODUCING_STEP_PERMISSION.code)
  @Get(':id')
  @ApiOperation({
    tags: ['Produces'],
    summary: 'Get detail producing-step',
    description: 'Lay thong tin chi tiet producing-step',
  })
  @ApiResponse({
    status: 200,
    description: 'Get detail successfully',
  })
  public async getDetailProducingStep(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<any> {
    return await this.producingStepService.getDetailProducingStep({
      id,
    } as GetProducingStepDto);
  }

  @PermissionCode(DELETE_PRODUCING_STEP_PERMISSION.code)
  @Delete(':id')
  @ApiOperation({
    tags: ['Produces'],
    summary: 'Delete producing-step',
    description: 'Xoa mot producing-step',
  })
  @ApiResponse({
    status: 200,
    description: 'Deleted successfully',
  })
  @MessagePattern(`${NATS_PRODUCE}.delete_producing_step`, DEFAULT_TRANSPORT)
  public async deleteProducingStep(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<any> {
    return await this.producingStepService.deleteProducingStep({
      id,
    } as GetProducingStepDto);
  }

  @Get('get-by-routing-version/:routingVersionId')
  @ApiOperation({
    tags: ['Routing_version'],
    summary: 'Get Produce Step By Route Version Id',
    description: 'Lấy tất cả Producing Step trong một Route Version',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  async getProducingStepByRoutingVersionId(
    @Param('routingVersionId', new ParseIntPipe()) routingVersionId,
  ): Promise<any> {
    return await this.producingStepService.getProducingStepByRoutingVersionId({
      routeVersionId: routingVersionId,
    } as GetProducingStepByRoutingVersionIdRequestDto);
  }

  @PermissionCode(CONFIRM_PRODUCING_STEP_PERMISSION.code)
  @Put(':id/confirm')
  @ApiOperation({
    tags: ['Produces'],
    summary: 'Confirm Producing Step',
    description: 'Xác nhận công đoạn',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
  })
  @MessagePattern(`${NATS_PRODUCE}.confirm_producing_step`, DEFAULT_TRANSPORT)
  public async confirm(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<ProducingStepResponseDto | any>> {
    return await this.producingStepService.confirm({
      id,
    } as SetStatusRequestDto);
  }

  @PermissionCode(REJECT_PRODUCING_STEP_PERMISSION.code)
  @Put(':id/reject')
  @ApiOperation({
    tags: ['Produces'],
    summary: 'Reject Producing Step',
    description: 'Từ chối xác nhận công đoạn',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
  })
  @MessagePattern(`${NATS_PRODUCE}.reject_producing_step`, DEFAULT_TRANSPORT)
  public async reject(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<ProducingStepResponseDto | any>> {
    return await this.producingStepService.reject({
      id,
    } as SetStatusRequestDto);
  }

  @PermissionCode(LIST_PRODUCING_STEP_PERMISSION.code)
  @Get('reports/progress/dashboard')
  @ApiOperation({
    tags: ['Produces'],
    summary: 'Get dashboard producing-step',
    description: 'Producing-step',
  })
  @ApiResponse({
    status: 200,
    description: 'Get list successfully',
  })
  @MessagePattern(
    `${NATS_PRODUCE}.get_producing_step_progress_dashboard`,
    DEFAULT_TRANSPORT,
  )
  public async getProducingStepProgresssDashboard(
    @Query()
    payload: GetProducingStepProgressDashboardRequestDto,
  ): Promise<ResponsePayload<ProducingStepResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.producingStepService.getProducingStepProgresssDashboard(
      request,
    );
  }

  @MessagePattern(
    `${NATS_PRODUCE}.get_producing_steps_and_work_center`,
    DEFAULT_TRANSPORT,
  )
  public async getProducingStepsAndWorkCenter(
    @Body()
    payload: GetProducingStepsAndWorkCenterByIdsRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.producingStepService.getProducingStepsAndWorkCenter(
      request,
    );
  }

  @MessagePattern(
    `${NATS_PRODUCE}.get_list_producing_step_by_ids`,
    DEFAULT_TRANSPORT,
  )
  public async getListProducingStepByIds(
    @Body()
    payload: any,
  ): Promise<ResponsePayload<any>> {
    return await this.producingStepService.getListProducingStepByIds(
      payload.ids,
    );
  }

  // @TODO: remove when refacator done
  @MessagePattern(
    `${NATS_PRODUCE}.get_list_producing_step_by_ids`,
    DEFAULT_TRANSPORT,
  )
  public async getListProducingStepByIdsTcp(
    @Body()
    payload: any,
  ): Promise<ResponsePayload<any>> {
    return await this.producingStepService.getListProducingStepByIds(
      payload.ids,
    );
  }

  @PermissionCode(LIST_PRODUCING_STEP_PERMISSION.code)
  @MessagePattern(`${NATS_PRODUCE}.get_list_producing_step`, DEFAULT_TRANSPORT)
  public async getListProducingStepTcp(
    @Body() body: GetListProducingStepRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.producingStepService.getListProducingStep(request);
  }

  @PermissionCode(DETAIL_PRODUCING_STEP_PERMISSION.code)
  @MessagePattern(
    `${NATS_PRODUCE}.get_producing_step_detail`,
    DEFAULT_TRANSPORT,
  )
  public async getDetailProducingStepTcp(
    @Body() payload: GetProducingStepDto,
  ): Promise<any> {
    const { request } = payload;
    return await this.producingStepService.getDetailProducingStep(request);
  }

  @MessagePattern(
    `${NATS_PRODUCE}.get_producing_step_by_routing_version_id`,
    DEFAULT_TRANSPORT,
  )
  async getProducingStepByRoutingVersionIdTcp(
    @Body() payload: GetProducingStepByRoutingVersionIdRequestDto,
  ): Promise<any> {
    const { request } = payload;
    return await this.producingStepService.getProducingStepByRoutingVersionId(
      request,
    );
  }
}
