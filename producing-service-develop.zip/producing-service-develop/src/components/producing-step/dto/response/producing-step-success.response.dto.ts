import { Expose } from 'class-transformer';

export class ProducingStepSuccessResponseDto {
  @Expose()
  id: number;
}
