import { IsArray } from 'class-validator';
import { PagingResponse } from './../../../../utils/paging.response';
import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponseDto } from '@components/producing-step/dto/response/success.response.dto';

class ProducingStep {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  description: string;

  @Expose()
  status: number;

  @Expose()
  switchMode: number;

  @Expose()
  qcQuantityRule: number;

  @Expose()
  qcCheck: number;

  @Expose()
  createdAt: Date;

  @Expose()
  updatedAt: Date;
}

export class DataList extends PagingResponse {
  @ApiProperty({ type: ProducingStep, isArray: true })
  @Type(() => ProducingStep)
  @Expose()
  @IsArray()
  items: ProducingStep[];
}

export class GetListProducingStepResponseDto extends SuccessResponseDto {
  @ApiProperty({
    type: DataList,
  })
  @Expose()
  @Type(() => DataList)
  data: DataList;
}
