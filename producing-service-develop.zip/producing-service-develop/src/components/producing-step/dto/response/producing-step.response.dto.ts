import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { QcObject } from '../request/create-producing-step.request.dto';

class UserResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'abc', description: '' })
  @Expose()
  username: string;

  @ApiProperty({ example: 'abc', description: '' })
  @Expose()
  fullName: string;
}

class WorkcenterResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'abc', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'abc', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'abc', description: '' })
  @Expose()
  leader: UserResponse;
}
export class ProducingStepResponseDto {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  description: string;

  @Expose()
  status: number;

  @Expose()
  switchMode: number;

  @Expose()
  qcQuantityRule: number;

  @Expose()
  workCenterId: number;

  @Expose()
  workCenter: WorkcenterResponse;

  @Expose()
  productionTimePerItem: number;

  @Expose()
  file: string;

  @Expose()
  createdAt: Date;

  @Expose()
  updatedAt: Date;

  @ApiProperty({ type: UserResponse })
  @Expose()
  @Type(() => UserResponse)
  approver: UserResponse;

  @ApiProperty({ type: UserResponse })
  @Expose()
  @Type(() => UserResponse)
  createdBy: UserResponse;

  @Expose()
  inputQc: QcObject;

  @Expose()
  outputQc: QcObject;
}
