import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class GetProducingStepProgressDashboardResponseDto {
  @Expose()
  @ApiProperty()
  executionDay: string;

  @Expose()
  @ApiProperty()
  quantity: string;

  @Expose()
  @ApiProperty()
  moderationQuantity: string;

  @Expose()
  @ApiProperty()
  actualQuantity: string;

  @Expose()
  @ApiProperty()
  delayQuantity: string;

  @Expose()
  @ApiProperty()
  accumlateQuantity: string;

  @Expose()
  @ApiProperty()
  accumlateModerationQuantity: string;

  @Expose()
  @ApiProperty()
  accumlateActualQuantity: string;

  @Expose()
  @ApiProperty()
  accumlateDelayQuantity: string;
}
