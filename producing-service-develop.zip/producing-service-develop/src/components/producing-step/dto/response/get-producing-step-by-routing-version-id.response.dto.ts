import { Expose, Type } from 'class-transformer';

class ProducingStep {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  description: string;

  @Expose()
  status: number;

  @Expose()
  switchMode: number;

  @Expose()
  qcQuantityRule: number;

  @Expose()
  qcCheck: number;

  @Expose()
  createdAt: Date;

  @Expose()
  updatedAt: Date;
}

export class GetProducingStepByRoutingVersionIdResponse {
  @Expose()
  @Type(() => ProducingStep)
  producingSteps: ProducingStep[];
}
