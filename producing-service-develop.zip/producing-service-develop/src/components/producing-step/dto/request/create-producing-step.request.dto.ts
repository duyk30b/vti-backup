import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { decimal } from '@utils/common';
import { Type } from 'class-transformer';
import {
  IsAlphanumeric,
  IsBoolean,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';

export class QcObject {
  @ApiProperty({ example: true, description: 'trạng thái' })
  @IsOptional()
  @IsBoolean()
  enable: boolean;

  @ApiProperty({ example: 1, description: 'qc id' })
  @IsOptional()
  @IsInt()
  qcCriteriaId: number;

  @ApiProperty({ example: 1, description: 'Tên QC' })
  @IsOptional()
  @IsInt()
  qcName: string;

  @ApiProperty({ example: 1, description: 'item_per_member_time' })
  @IsOptional()
  @IsInt()
  itemPerMemberTime: number;

  @ApiProperty({ example: 1, description: 'Số lần QC' })
  @IsOptional()
  @IsInt()
  numberOfTime: number;

  @ApiProperty({ example: 1, description: 'Hình thức' })
  @IsOptional()
  @IsInt()
  formality: number;

  @ApiProperty({ example: 1, description: '% Lỗi' })
  @IsOptional()
  @IsInt()
  errorAcceptanceRate: number;
}
export class CreateProducingStepRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @MaxLength(20)
  @IsAlphanumeric()
  code: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @IsEnum(['0', '1'])
  status: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @IsEnum(['0', '1'])
  switchMode: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  @Max(101)
  qcQuantityRule: number;

  @ApiProperty({ example: 1, description: 'productionTimePerItem' })
  @IsOptional()
  @IsNumber()
  @Min(0, {
    message: 'Thời gian thực hiện 1 sản phẩm/công đoạn phải lớn hơn 0 phút',
  })
  @Max(decimal(6, 2), {
    message: 'Thời gian thực hiện 1 sản phẩm/công đoạn phải nhỏ hơn 10000 phút',
  })
  productionTimePerItem: number;

  @ApiPropertyOptional({
    example: {
      enable: true,
      qcCriteriaId: 1,
      itemPerMemberTime: '1,22',
      formality: '',
      numberOfTime: '2',
      errorAcceptanceRate: '20',
    },
    description: 'Input QC',
  })
  @IsOptional()
  @ValidateNested()
  @Type(() => QcObject)
  inputQc: QcObject;

  @ApiPropertyOptional({
    example: {
      enable: true,
      qcCriteriaId: 1,
      itemPerMemberTime: '1,22',
      formality: '',
      numberOfTime: '2',
      errorAcceptanceRate: '20',
    },
    description: 'outputQc',
  })
  @IsOptional()
  @ValidateNested()
  @Type(() => QcObject)
  outputQc: QcObject;

  @IsOptional()
  @IsInt()
  userId: number;
}
