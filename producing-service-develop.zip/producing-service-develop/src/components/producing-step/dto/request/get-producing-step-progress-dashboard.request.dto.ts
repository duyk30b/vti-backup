import { IsInt, IsOptional } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { BaseDto } from '@core/dto/base.dto';

export class GetProducingStepProgressDashboardRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  @Transform((value) => parseInt(value.value))
  manufacturingOrderId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  @Transform((value) => parseInt(value.value))
  itemId: number;

  @ApiPropertyOptional()
  @IsInt()
  @IsOptional()
  @Transform((value) => parseInt(value.value))
  producingStepId: number;

  @ApiPropertyOptional()
  @IsInt()
  @IsOptional()
  @Transform((value) => parseInt(value.value))
  workCenterId: number;
}
