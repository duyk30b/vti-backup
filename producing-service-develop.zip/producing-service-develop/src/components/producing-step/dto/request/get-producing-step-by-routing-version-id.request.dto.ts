import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber } from 'class-validator';

export class GetProducingStepByRoutingVersionIdRequestDto extends BaseDto {
  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  routeVersionId: number;
}
