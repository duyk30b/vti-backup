import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsNotEmpty } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';

export class GetProducingStepDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  id: number;
}
