import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsInt, IsNotEmpty, IsOptional } from 'class-validator';

export class GetProducingStepsAndWorkCenterByIdsRequestDto extends BaseDto {
  @ApiProperty()
  @IsArray()
  @IsNotEmpty()
  producingStepIds: number[];

  @IsArray()
  @IsOptional()
  routingIds: number[];

  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  factoryId: number;
}
