import { CreateProducingStepRequestDto } from '@components/producing-step/dto/request/create-producing-step.request.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsOptional } from 'class-validator';

export class UpdateProducingStepsRequestDto extends CreateProducingStepRequestDto {
  @ApiProperty()
  @IsOptional()
  @IsNumber()
  id: number;
}
