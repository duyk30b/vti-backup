import { Inject, Injectable } from '@nestjs/common';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ImportServiceInterface } from './interface/import.service.interface';
import { ImportRequestDto } from './dto/request/import.request.dto';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Workbook } from 'exceljs';
import { ACTION_IMPORT, TEMPLATE, TypeEnum } from './import.constant';
import { isNotEmpty } from 'class-validator';
import {
  forEach,
  has,
  isEmpty,
  map,
  uniq,
  keyBy,
  flatMap,
  find,
  filter,
  isArray,
  compact,
} from 'lodash';
import { getDataDuplicate } from '@utils/common';
import { toStringTrim } from '@utils/object.util';
import { WorkCenterService } from '@components/work-center/work-center.service';

@Injectable()
export class ImportService implements ImportServiceInterface {
  constructor(
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('WorkCenterServiceInterface')
    private readonly workCenterService: WorkCenterService,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async handleWorkbook(
    workbook: any,
    template: any,
    header: any,
    sheetName: any,
    userId: any,
    keyCheckDuplicate: any,
    subHeader?: any,
  ) {
    const sizeHeader = Object.keys(header).length;
    const templateMap = new Map(
      Object.keys(template).map((key) => [key, template[key]]),
    );

    const templateKeyMap = new Map(
      Object.keys(template).map((key, index) => [index, key]),
    );

    const worksheet = workbook.getWorksheet(sheetName);
    return await this.getDataWorksheet(
      worksheet,
      templateMap,
      templateKeyMap,
      sizeHeader,
      header,
      userId,
      keyCheckDuplicate,
      subHeader,
    );
  }

  async getDataWorksheet(
    worksheet,
    templateMap,
    templateKeyMap,
    sizeHeader,
    header,
    userId,
    keyCheckDuplicate,
    subHeader?,
  ) {
    const data: any[] = [];
    const dataError: any[] = [];
    let isData = false;
    let isSubHeader = !isEmpty(subHeader);
    for (let i = 0; i <= worksheet?.rowCount; i++) {
      const row = worksheet.getRow(i);
      if (isData) {
        const obj: any = {};
        let error = '';
        obj['createdBy'] = userId;
        obj['line'] = i;
        for (let j = 0; j < row.cellCount; j++) {
          const cell = row.getCell(j + 1);
          obj[templateKeyMap.get(j)] = cell.value;
          error = await this.validateDataCell(
            header,
            templateMap.get(templateKeyMap.get(j)),
            cell.value,
          );
          if (isNotEmpty(error)) {
            break;
          }
        }
        if (isNotEmpty(error)) {
          dataError[i] = error;
          error = '';
        } else data.push(obj);
      }
      if (row.cellCount === sizeHeader && !isData) {
        for (let j = 0; j < row.cellCount; j++) {
          const cell = row.getCell(j + 1);
          if (
            !isSubHeader &&
            header[templateKeyMap.get(j)]?.trim() !== cell.value?.trim()
          ) {
            return [
              [
                {
                  statusCode: ResponseCodeEnum.NOT_FOUND,
                  message: await this.i18n.translate(
                    'error.HEADER_TEMPLATE_ERROR',
                  ),
                },
              ],
              [],
            ];
          } else if (j == row.cellCount - 1 && !isSubHeader) {
            isData = true;
          }
          if (
            isSubHeader &&
            subHeader[templateKeyMap.get(j)]?.trim() !== cell.value?.trim()
          ) {
            return [
              [
                {
                  statusCode: ResponseCodeEnum.NOT_FOUND,
                  message: await this.i18n.translate(
                    'error.HEADER_TEMPLATE_ERROR',
                  ),
                },
              ],
              [],
            ];
          } else if (j == row.cellCount - 1) {
            isSubHeader = false;
          }
        }
      }
    }
    return await this.validateDataUniqueCode(
      data,
      dataError,
      keyCheckDuplicate,
    );
  }

  async validateDataCell(header, template, value) {
    let error: any = '';
    // check not null
    if (template.notNull) {
      error = isNotEmpty(value)
        ? error
        : await this.i18n.translate('import.error.notNull', {
            args: {
              value: header[template.key],
            },
          });
    }

    // check key
    if (
      template.key === ACTION_IMPORT.KEY &&
      !(
        value === (await this.i18n.translate('import.common.add')) ||
        value === (await this.i18n.translate('import.common.edit'))
      )
    ) {
      error = this.i18n.translate('import.error.acction');
    }

    // check string max length
    if (template.maxLength && template.type === 'string') {
      error =
        value && toStringTrim(value)?.length > template.maxLength
          ? await this.i18n.translate('import.error.maxLength', {
              args: {
                value: header[template.key],
                number: template.maxLength,
              },
            })
          : error;
    }

    return error;
  }

  async validateDataUniqueCode(
    data: any[],
    dataError: any[],
    keyCheckDuplicate,
  ) {
    const listKey = data.map((i) => {
      let key = '';
      for (let j = 0; j < keyCheckDuplicate.length; j++) {
        key += i[keyCheckDuplicate[j]] + ' ';
      }
      return key;
    });
    if (isEmpty(listKey)) return [data, dataError];
    let dataDuplicate = getDataDuplicate(listKey);
    dataDuplicate = uniq(dataDuplicate);
    if (dataDuplicate.length > 0) {
      const newData: any[] = [];
      const newDataError: any[] = [...dataError];
      for (let i = 0; i < data.length; i++) {
        const item = data[i];
        if (dataDuplicate.includes(item.code)) {
          newDataError[item.line] = await this.i18n.translate(
            'import.error.duplicateCode',
            {
              args: {
                value: item.code,
              },
            },
          );
        } else {
          newData.push(item);
        }
      }
      return [newData, newDataError];
    }

    return [data, dataError];
  }

  async import(request: ImportRequestDto): Promise<any> {
    const { type, files, userId } = request;

    const workbook = new Workbook();
    await workbook.xlsx.load(Buffer.from(files[0].data));
    switch (type) {
      case TypeEnum.WORKCENTER:
        return this.importWorkCenters(workbook, userId);
      default:
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .build();
    }
  }

  async importWorkCenters(workbook: any, userId) {
    const result: any[] = [];
    const resultError: any[] = [];
    const header1 = {
      action: await this.i18n.translate('import.common.action'),
      code: await this.i18n.translate('import.workCenter.header1.code'),
      name: await this.i18n.translate('import.workCenter.header1.name'),
      factoryName: await this.i18n.translate(
        'import.workCenter.header1.factoryName',
      ),
      members: await this.i18n.translate('import.workCenter.header1.members'),
      leader: await this.i18n.translate('import.workCenter.header1.leader'),
      producingStep: await this.i18n.translate(
        'import.workCenter.header1.producingStep',
      ),
      description: await this.i18n.translate(
        'import.workCenter.header1.description',
      ),
      oeeTarget: await this.i18n.translate(
        'import.workCenter.header1.oeeTarget',
      ),
      workingCapacity: await this.i18n.translate(
        'import.workCenter.header1.workingCapacity',
      ),
    };
    const header2 = {
      code: await this.i18n.translate('import.workCenter.header2.code'),
      shiftName: await this.i18n.translate(
        'import.workCenter.header2.shiftName',
      ),
      shiftStartAt: await this.i18n.translate(
        'import.workCenter.header2.shiftStartAt',
      ),
      shiftEndAt: await this.i18n.translate(
        'import.workCenter.header2.shiftEndAt',
      ),
      pricePerHour: await this.i18n.translate(
        'import.workCenter.header2.pricePerHour',
      ),
      relaxName: await this.i18n.translate(
        'import.workCenter.header2.relaxName',
      ),
      relaxStartAt: await this.i18n.translate(
        'import.workCenter.header2.relaxStartAt',
      ),
      relaxEndAt: await this.i18n.translate(
        'import.workCenter.header2.relaxEndAt',
      ),
    };
    const subHeader2 = {
      code: await this.i18n.translate('import.workCenter.header2.code'),
      shiftName: await this.i18n.translate(
        'import.workCenter.header2.sub1.shift',
      ),
      shiftStartAt: await this.i18n.translate(
        'import.workCenter.header2.sub1.shift',
      ),
      shiftEndAt: await this.i18n.translate(
        'import.workCenter.header2.sub1.shift',
      ),
      pricePerHour: await this.i18n.translate(
        'import.workCenter.header2.sub1.shift',
      ),
      relaxName: await this.i18n.translate(
        'import.workCenter.header2.sub1.relax',
      ),
      relaxStartAt: await this.i18n.translate(
        'import.workCenter.header2.sub1.relax',
      ),
      relaxEndAt: await this.i18n.translate(
        'import.workCenter.header2.sub1.relax',
      ),
    };
    const headers = [header1, header2];
    const subHeaders = [null, subHeader2];
    const templates = [TEMPLATE.workCenter.sheet1, TEMPLATE.workCenter.sheet2];
    const sheetNames = [
      await this.i18n.translate('import.workCenter.sheetName.sheet1'),
      await this.i18n.translate('import.workCenter.sheetName.sheet2'),
    ];

    const keyCheckDuplicate = [['code'], ['code', 'shiftName']];

    const tempData = [];
    const tempDateError = [];
    for (let i = 0; i < sheetNames.length; i++) {
      const [data, dataError] = await this.handleWorkbook(
        workbook,
        templates[i],
        headers[i],
        sheetNames[i],
        userId,
        keyCheckDuplicate[i],
        subHeaders[i],
      );

      if (data[0]?.statusCode === ResponseCodeEnum.NOT_FOUND) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(data[0]?.message)
          .build();
      }
      tempData.push(data);
      tempDateError.push(dataError);
    }
    let dataSheet1 = tempData[0];
    const dataSheet2 = tempData[1];
    const workCenterShifts = [];
    for (let i = 0; i < dataSheet2.length; i++) {
      const element = dataSheet2[i];
      if (!isEmpty(element.code)) {
        workCenterShifts.push({
          code: element.code,
          name: element.shiftName,
          startAt: element.shiftStartAt,
          endAt: element.shiftEndAt,
          pricePerHour: element.pricePerHour,
          relaxTimes: [],
        });
      }
      workCenterShifts[workCenterShifts.length - 1].relaxTimes.push({
        name: element.relaxName,
        startAt: element.relaxStartAt,
        endAt: element.relaxEndAt,
      });
    }
    dataSheet1 = dataSheet1.map((i) => {
      return {
        ...i,
        workCenterShifts: workCenterShifts.filter((wcs) => wcs.code === i.code),
      };
    });

    const resultSave = await this.workCenterService.saveWorkCenters(dataSheet1);
    // if (resultSave.statusCode !== ResponseCodeEnum.SUCCESS) {
    //   return new ResponseBuilder()
    //     .withCode(ResponseCodeEnum.BAD_REQUEST)
    //     .withMessage(resultSave.message)
    //     .build();
    // }
    // const [resultSaveData, resultSaveError] = resultSave.data;
    // result = resultSaveData;
    // for (let i = 0; i < tempDateError.length; i++) {
    //   if (tempDateError[i]) resultError[i] = tempDateError[i];
    // }
    // for (let i = 0; i < resultSaveError.length; i++) {
    //   if (resultSaveError[i]) resultError[0][i] = resultSaveError[i];
    // }

    return new ResponseBuilder({ dataSheet1, tempDateError })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  // async fileImportResult(
  //   workbook,
  //   sheetName,
  //   columnResultReason,
  //   firstIndexData,
  //   resultSaveError,
  // ) {
  //   const worksheet = workbook.getWorksheet(sheetName);
  //   const headers = worksheet.getRow(3);
  //   headers.getCell(columnResultReason[0]).value = await this.i18n.translate(
  //     'import.factory.result',
  //   );
  //   headers.getCell(columnResultReason[1]).value = await this.i18n.translate(
  //     'import.factory.reason',
  //   );

  //   for (let i = firstIndexData; i < resultSaveError.length; i++) {
  //     const element = resultSaveError[i];
  //     const row = worksheet.getRow(i);
  //     if (!element)
  //       row.getCell(columnResultReason[0]).value = await this.i18n.translate(
  //         'import.common.success',
  //       );
  //     else {
  //       row.getCell(columnResultReason[0]).value = await this.i18n.translate(
  //         'import.common.fail',
  //       );
  //       row.getCell(columnResultReason[1]).value = element;
  //     }
  //   }

  //   await workbook.xlsx.writeFile('file-import-result.xlsx');

  //   return workbook;
  // }
}
