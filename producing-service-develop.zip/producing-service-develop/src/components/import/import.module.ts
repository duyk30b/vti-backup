import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { WorkCenterModule } from '@components/work-center/work-center.module';
import { WorkCenterService } from '@components/work-center/work-center.service';
import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ImportController } from './import.controller';
import { ImportService } from './import.service';

@Global()
@Module({
  imports: [TypeOrmModule.forFeature([]), UserModule, WorkCenterModule],
  exports: [
    {
      provide: 'ImportServiceInterface',
      useClass: ImportService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'WorkCenterServiceInterface',
      useClass: WorkCenterService,
    },
  ],
  providers: [
    {
      provide: 'ImportServiceInterface',
      useClass: ImportService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'WorkCenterServiceInterface',
      useClass: WorkCenterService,
    },
  ],
  controllers: [ImportController],
})
export class ImportModule {}
