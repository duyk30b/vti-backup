import { TypeEnum } from '@components/import/import.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsEnum } from 'class-validator';

export class File {
  filename: string;
  data: ArrayBuffer;
  encoding: string;
  mimetype: string;
  limit: boolean;
}

export class ImportBodyRequestDto extends BaseDto {}

export class ImportRequestDto extends ImportBodyRequestDto {
  @ApiProperty()
  @IsEnum(TypeEnum)
  @Transform(({ value }) => Number(value))
  type: number;

  @ApiProperty()
  files: File[];
}
