export enum TypeEnum {
  WORKCENTER = 1,
}

export enum ACTION_IMPORT {
  KEY = 'action',
  CREATE = 'Tạo',
  UPDATE = 'Sửa',
}

export const TEMPLATE = {
  workCenter: {
    sheet1: {
      action: {
        key: 'action',
        notNull: true,
      },
      code: {
        key: 'code',
        type: 'string',
        maxLength: 20,
        notNull: true,
      },
      name: {
        key: 'name',
        type: 'string',
        maxLength: 255,
        notNull: true,
      },
      factoryName: {
        key: 'factoryName',
        type: 'string',
        notNull: true,
      },
      members: {
        key: 'members',
        type: 'string',
        notNull: false,
      },
      leader: {
        key: 'leader',
        type: 'string',
        notNull: true,
      },
      producingStep: {
        key: 'producingStep',
        type: 'string',
        notNull: true,
      },
      description: {
        key: 'description',
        type: 'string',
        maxLength: 255,
        notNull: false,
      },
      oeeTarget: {
        key: 'oeeTarget',
        type: 'number',
        notNull: true,
      },
      workingCapacity: {
        key: 'workingCapacity',
        type: 'number',
        notNull: true,
      },
    },
    sheet2: {
      code: {
        key: 'code',
        type: 'string',
        maxLength: 20,
        notNull: false,
      },
      shiftName: {
        key: 'shiftName',
        type: 'string',
        notNull: false,
      },
      shiftStartAt: {
        key: 'shiftStartAt',
        type: 'time',
        notNull: false,
      },
      shiftEndAt: {
        key: 'shiftEndAt',
        type: 'time',
        notNull: false,
      },
      pricePerHour: {
        key: 'pricePerHour',
        type: 'number',
        notNull: false,
      },
      relaxName: {
        key: 'relaxName',
        type: 'string',
        notNull: true,
      },
      relaxStartAt: {
        key: 'relaxStartAt',
        type: 'time',
        notNull: true,
      },
      relaxEndAt: {
        key: 'relaxEndAt',
        type: 'time',
        notNull: true,
      },
    },
  },
};
