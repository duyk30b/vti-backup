import { Global, Module } from '@nestjs/common';
import { ConfigService } from '@config/config.service';
import { FileService } from './file.service';
import { HttpClientModule } from '@core/components/http-client/http-client.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FileEntity } from '@entities/file/file.entity';
import { FileRepository } from '@repositories/file/file.repository';

@Global()
@Module({
  imports: [TypeOrmModule.forFeature([FileEntity]), HttpClientModule],
  exports: [
    ConfigService,
    //{
    //  provide: 'ConfigServiceInterface',
    //  useClass: ConfigService,
    //},
    {
      provide: 'FileServiceInterface',
      useClass: FileService,
    },
    {
      provide: 'FileRepositoryInterface',
      useClass: FileRepository,
    },
  ],
  providers: [
    ConfigService,
    //{
    //  provide: 'ConfigServiceInterface',
    //  useClass: ConfigService,
    //},
    {
      provide: 'FileServiceInterface',
      useClass: FileService,
    },
    {
      provide: 'FileRepositoryInterface',
      useClass: FileRepository,
    },
  ],
  controllers: [],
})
export class FileModule {}
