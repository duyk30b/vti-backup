import { SetStatusRequestDto } from '@components/material/dto/request/set-status.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  Body,
  Controller,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern, Transport } from '@nestjs/microservices';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { DEFAULT_TRANSPORT } from '@utils/constant';
import { DETAIL_MANUFACTURING_ORDER_PERMISSION } from '@utils/permissions/manufacturing-order';
import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { isEmpty } from 'lodash';
import { GetMoMaterialList } from './dto/request/get-mo-material-list.request.dto';
import { GetListMaterialPlanRequestDto } from './dto/request/material-plan-list.request.dto';
import { PreviewAvailableStockMaterialRequestDto } from './dto/request/preview-available-stock-material.request.dto';
import { UpdateMaterialToRepairErrorRequestDto } from './dto/request/update-material-to-repair-error.request.dto';
import { CheckMaterialPlanResponseDto } from './dto/response/check-material-plan.response.dto';
import { GetListMaterialPlanResponseDto } from './dto/response/material-plan-list.response.dto';
import { MaterialPlanResponseDto } from './dto/response/material-plan.response.dto';
import { PreviewAvailableStockMaterialResponseDto } from './dto/response/preview-available-stock.response.dto';
import { MaterialServiceInterface } from './interface/material.service.interface';
import { NATS_PRODUCE } from '@config/nats.config';

@Controller('')
export class MaterialController {
  constructor(
    @Inject('MaterialServiceInterface')
    private readonly materialService: MaterialServiceInterface,
  ) {}

  @Get('/material-plans/:id')
  @ApiOperation({
    tags: ['Material Plan'],
    summary: 'Detail Material Plan',
    description: 'Chi tiết kế hoạch nguyên vật liệu',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: MaterialPlanResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.material_plan_detail`, DEFAULT_TRANSPORT)
  public async detail(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<MaterialPlanResponseDto | any>> {
    return await this.materialService.detail({ id: id });
  }

  @Get('/material-plans/list')
  @ApiOperation({
    tags: ['Material Plan'],
    summary: 'List Material Plan',
    description: 'Danh sách kế hoạch nguyên vật liệu',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListMaterialPlanResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.material_plan_list`, DEFAULT_TRANSPORT)
  public async getList(
    @Query() payload: GetListMaterialPlanRequestDto,
  ): Promise<ResponsePayload<GetListMaterialPlanResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.materialService.getList(request);
  }

  @Put('/material-plans/:id/confirm')
  @ApiOperation({
    tags: ['Material Plan'],
    summary: 'Confirm Material Plan',
    description: 'Xác nhận kế hoạch nguyên vật liệu',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: MaterialPlanResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.confirm_material_plan`, DEFAULT_TRANSPORT)
  public async confirm(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<MaterialPlanResponseDto | any>> {
    return await this.materialService.confirm({
      id: id,
    } as SetStatusRequestDto);
  }

  @Put('/material-plans/:id/reject')
  @ApiOperation({
    tags: ['Material Plan'],
    summary: 'Reject Material Plan',
    description: 'Từ chối kế hoạch nguyên vật liệu',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: MaterialPlanResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.reject_material_plan`, DEFAULT_TRANSPORT)
  public async reject(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<MaterialPlanResponseDto | any>> {
    return await this.materialService.reject({
      id: id,
    } as SetStatusRequestDto);
  }

  @Get('/material-plans/:id/check')
  @ApiOperation({
    tags: ['Material Plan'],
    summary: 'Check Material Plan',
    description: 'Kiểm tra kế hoạch nguyên vật liệu',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: CheckMaterialPlanResponseDto,
  })
  @PermissionCode(DETAIL_MANUFACTURING_ORDER_PERMISSION.code)
  @MessagePattern(`${NATS_PRODUCE}.check_material_plan`, DEFAULT_TRANSPORT)
  public async checkMaterialPlan(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<ResponsePayload<SuccessResponse | any>> {
    return await this.materialService.checkMaterialPlan(id);
  }

  @Post('materials/material-quantity-to-repair-error')
  @ApiOperation({
    tags: ['Material'],
    summary: 'Create new Material Request Warning',
    description: 'Tạo cảnh báo yêu cầu nguyên vật liệu',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
  })
  public async updateMaterialToRepairQuantity(
    @Body() payload: UpdateMaterialToRepairErrorRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.materialService.updateMaterialToRepairQuantity(request);
  }

  @Get('materials/manufacturing-orders/list')
  @ApiOperation({
    tags: ['Material'],
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: MaterialPlanResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.get_mo_material_list`, DEFAULT_TRANSPORT)
  public async getMoMaterialList(
    @Query() payload: GetMoMaterialList,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.materialService.getMoMaterialList(request);
  }

  @Post('materials/stocks/available/preview')
  @ApiOperation({
    tags: ['Material', 'Preview'],
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: PreviewAvailableStockMaterialResponseDto,
  })
  @MessagePattern(
    `${NATS_PRODUCE}.preview_available_stock_materials`,
    DEFAULT_TRANSPORT,
  )
  public async previewAvailableStockMaterials(
    @Body() payload: PreviewAvailableStockMaterialRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.materialService.previewAvailableStockMaterials(request);
  }

  @MessagePattern(
    `${NATS_PRODUCE}.update_material_quantity_to_repair_error`,
    DEFAULT_TRANSPORT,
  )
  public async updateMaterialToRepairQuantityTcp(
    @Body() payload: UpdateMaterialToRepairErrorRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.materialService.updateMaterialToRepairQuantity(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.get_mo_material_list`, DEFAULT_TRANSPORT)
  public async getMoMaterialListTcp(
    @Body() payload: GetMoMaterialList,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.materialService.getMoMaterialList(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.material_plan_list`, DEFAULT_TRANSPORT)
  public async getListTcp(
    @Body() payload: GetListMaterialPlanRequestDto,
  ): Promise<ResponsePayload<GetListMaterialPlanResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.materialService.getList(request);
  }
}
