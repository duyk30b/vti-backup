import { ApiProperty } from '@nestjs/swagger';
import { BaseDto } from '@core/dto/base.dto';
import { IsArray, IsInt, IsString, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';

class MaterialToRepairError {
  @ApiProperty()
  @IsInt()
  workOrderId: number;

  @ApiProperty()
  @IsInt()
  errorRepairQuantity: number;

  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsString()
  itemUnit: string;

  @ApiProperty()
  @IsString()
  itemName: string;
}

export class UpdateMaterialToRepairErrorRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  workCenterId: number;

  @ApiProperty()
  @IsArray()
  @ValidateNested()
  @Type(() => MaterialToRepairError)
  materials: MaterialToRepairError[];
}
