import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { BasicResponseDto } from '@core/dto/response/basic.response.dto';

class Material extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  planQuantity: number;

  @ApiProperty()
  @Expose()
  availableStock: number;

  @ApiProperty()
  @Expose()
  requestQuantity: number;

  @ApiProperty()
  @Expose()
  itemUnitName: string;

  @ApiProperty()
  @Expose()
  itemUnitCode: string;

  @ApiProperty()
  @Expose()
  price: string;
}

export class PreviewAvailableStockMaterialResponseDto {
  @ApiProperty({ type: BasicResponseDto })
  @Expose()
  @Type(() => BasicResponseDto)
  item: BasicResponseDto;

  @ApiProperty({ type: Material })
  @Expose()
  @Type(() => Material)
  material: Material;
}
