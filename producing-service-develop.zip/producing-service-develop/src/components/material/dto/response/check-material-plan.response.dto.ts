import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class Item {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  warehouseId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  qcCheck: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  qcCriteriaId: number;

  @ApiProperty({ example: 100, description: '' })
  @Expose()
  quantity: number;

  @ApiProperty({ example: 100, description: '' })
  @Expose()
  price: number;
}

export class CheckMaterialPlan {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  createdByUserId: number;

  @ApiProperty({ example: 'PO', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'PO', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  manufacturingOrderId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  companyId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  vendorId: number;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  purchasedAt: Date;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  planFrom: Date;

  @ApiProperty({ example: '', description: '' })
  @Expose()
  planTo: Date;

  @ApiProperty({ type: Item, isArray: true })
  @Expose()
  @Type(() => Item)
  @IsArray()
  items: Item[];
}

export class CheckMaterialPlanResponseDto extends SuccessResponse {
  @ApiProperty({ type: CheckMaterialPlan })
  @Expose()
  @Type(() => CheckMaterialPlan)
  data: CheckMaterialPlan;
}
