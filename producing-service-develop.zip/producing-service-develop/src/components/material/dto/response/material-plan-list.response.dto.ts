import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { MaterialPlanResponseAbstractDto } from './material-plan.response.abstract.dto';

class Meta {
  @ApiProperty({ example: 1 })
  @Expose()
  total: number;

  @ApiProperty({ example: 1 })
  @Expose()
  page: number;
}
export class MaterialPlanData {
  @ApiProperty({ type: MaterialPlanResponseAbstractDto, isArray: true })
  @Expose()
  @IsArray()
  @Type(() => MaterialPlanResponseAbstractDto)
  items: MaterialPlanResponseAbstractDto[];

  @ApiProperty()
  @Expose()
  @Type(() => Meta)
  meta: Meta;
}

export class GetListMaterialPlanResponseDto extends SuccessResponse {
  @ApiProperty({ type: MaterialPlanData })
  @Expose()
  @Type(() => MaterialPlanData)
  data: MaterialPlanData;
}
