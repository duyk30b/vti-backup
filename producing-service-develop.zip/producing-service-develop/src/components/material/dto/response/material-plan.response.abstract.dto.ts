import { ItemResponseDto } from '@components/item/dto/response/item.dto.response';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class User {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  username: string;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  fullName: string;
}

class MaterialPlanStructure {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 2, description: '' })
  @Expose()
  bomId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  bomParentId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  itemId: number;

  @ApiProperty({ example: 'Gỗ', description: '' })
  @Expose()
  itemName: string;

  @ApiProperty({ example: 'kg', description: '' })
  @Expose()
  itemUnitName: string;

  @ApiProperty({ example: 'Bàn', description: '' })
  @Expose()
  finishItemName: string;

  @ApiProperty({ example: 'Chân Bàn', description: '' })
  @Expose()
  semiFinishItemName: string;

  @ApiProperty({
    example: 400,
    description: '',
  })
  @Expose()
  @Type(() => Number)
  quantity: number;

  @ApiProperty({
    example: 2,
    description: '',
  })
  @Expose()
  @Type(() => Number)
  ratio: number;

  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;
}

class ManufacturingOrder {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'MO 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'MO1', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  planFrom: Date;

  @ApiProperty({ example: '2021-07-13 09:13:15.562609+00', description: '' })
  @Expose()
  planTo: Date;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  status: number;

  @ApiProperty({ example: 'MO 01', description: '' })
  @Expose()
  description: string;
}

export class MaterialPlanResponseAbstractDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'material 1', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'MAT_PLAN1', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  pmId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  status: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  poRequestCreated: number;

  @ApiProperty({ type: MaterialPlanStructure, isArray: true })
  @Expose()
  @Type(() => MaterialPlanStructure)
  @IsArray()
  materialPlanStructures: MaterialPlanStructure[];

  @ApiProperty({ type: ManufacturingOrder })
  @Expose()
  @Type(() => ManufacturingOrder)
  manufacturingOrder: ManufacturingOrder;

  @ApiProperty({ type: User })
  @Expose()
  @Type(() => User)
  approver: User;
}
