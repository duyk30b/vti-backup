import { SuccessResponse } from '@utils/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { MaterialPlanResponseAbstractDto } from './material-plan.response.abstract.dto';
import { IsArray } from 'class-validator';

export class MaterialPlanResponseDto extends SuccessResponse {
  @ApiProperty({ type: MaterialPlanResponseAbstractDto, isArray: true })
  @Expose()
  @Type(() => MaterialPlanResponseAbstractDto)
  @IsArray()
  data: MaterialPlanResponseAbstractDto[];
}
