export enum MaterialStatusEnum {
  PEDING = 0,
  CONFIRMED = 1,
  REJECTED = 2,
  IN_PROGRESS = 3,
  COMPLETED = 4,
}

export enum PoRequestCreated {
  NOT_SENT_REQUEST = 0,
  SENT_REQUEST = 1,
}

export const CAN_UPDATE_MATERIAL_STATUS: number[] = [
  MaterialStatusEnum.PEDING,
  MaterialStatusEnum.REJECTED,
];

export const CAN_DELETE_MATERIAL_STATUS: number[] = [
  MaterialStatusEnum.PEDING,
  MaterialStatusEnum.REJECTED,
];

export const CAN_CONFIRM_MATERIAL_STATUS: number[] = [
  MaterialStatusEnum.PEDING,
  MaterialStatusEnum.REJECTED,
];

export const CAN_REJECT_MATERIAL_STATUS: number[] = [MaterialStatusEnum.PEDING];

export const FORMAT_CODE_MATERIAL = 'MAT_PLAN';

export const FORMAT_NAME_MATERIAL = 'Kế hoạch nguyên vật liệu ';

export enum ProductionOrderStatusEnum {
  Pending = 0,
  Confirmed = 1,
  InProgress = 2,
  Approved = 3,
  Completed = 4,
  Reject = 5,
}

export enum PurchasedOrderStatusEnum {
  Pending = 0,
  Confirmed = 1,
  InProgress = 2,
  Approved = 3,
  Completed = 4,
  Reject = 5,
}

export enum ProductionOrderTypeEnum {
  Import = 0,
  Export = 1,
}

export const PURCHASE_ORDER_CODE = 'Imp';
