import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserService } from '@components/user/user.service';
import { UserModule } from '@components/user/user.module';
import { MaterialPlanStructureEntity } from '@entities/material/material-plan-structure.entity';
import { MaterialPlanEntity } from '@entities/material/material-plan.entity';
import { MaterialPlanRepository } from '@repositories/material/material-plan.repository';
import { MaterialPlanStructureRepository } from '@repositories/material/material-plan-structure.repository';
import { MaterialService } from './material.service';
import { MaterialController } from './material.controller';
import { ManufacturingOrderRepository } from '@repositories/manufacturing-order/manufacturing-order.repository';
import { ManufacturingOrderEntity } from '@entities/manufacturing-order/manufacturing-orders.entity';
import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { WarehouseService } from '@components/warehouse/warehouse.service';
import { ItemModule } from '@components/item/item.module';
import { ItemService } from '@components/item/item.service';
import { SaleModule } from '@components/sale-order/sale-order.module';
import { SaleService } from '@components/sale-order/sale-order.service';
import { MaterialToRepairErrorEntity } from '@entities/material/material-quantity-to-repair-error.entity';
import { WorkOrderEntity } from '@entities/work-order/work-order.entity';
import { MaterialToRepairErrorRepository } from '@repositories/material/material-to-repair-error.repository';
import { WorkOrderRepository } from '@repositories/work-order/work-order.repository';
import { WorkOrderScrapTransactionEntity } from '@entities/work-order/work-order-scrap-transaction.entity';
import { BomProducingStepDetailEntity } from '@entities/bom/bom-producing-steps.entity';
import { BomProducingStepDetailsRepository } from '@repositories/bom/bom-producing-step-details.repository';
import { BomEntity } from '@entities/bom/boms.entity';
import { BomRepository } from '@repositories/bom/bom.repository';
import { ConfigModule } from '@nestjs/config';

@Module({
  imports: [
    ConfigModule,
    TypeOrmModule.forFeature([
      MaterialPlanStructureEntity,
      MaterialPlanEntity,
      ManufacturingOrderEntity,
      MaterialToRepairErrorEntity,
      WorkOrderEntity,
      WorkOrderScrapTransactionEntity,
      BomProducingStepDetailEntity,
      BomEntity,
    ]),
    UserModule,
    WarehouseModule,
    ItemModule,
    SaleModule,
  ],
  providers: [
    {
      provide: 'MaterialPlanRepositoryInterface',
      useClass: MaterialPlanRepository,
    },
    {
      provide: 'MaterialPlanStructureRepositoryInterface',
      useClass: MaterialPlanStructureRepository,
    },
    {
      provide: 'MaterialToRepairErrorRepositoryInterface',
      useClass: MaterialToRepairErrorRepository,
    },
    {
      provide: 'ManufacturingOrderRepositoryInterface',
      useClass: ManufacturingOrderRepository,
    },
    {
      provide: 'BomProducingStepDetailsRepositoryInterface',
      useClass: BomProducingStepDetailsRepository,
    },
    {
      provide: 'BomRepositoryInterface',
      useClass: BomRepository,
    },
    {
      provide: 'MaterialServiceInterface',
      useClass: MaterialService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'WorkOrderRepositoryInterface',
      useClass: WorkOrderRepository,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
  ],
  exports: [
    {
      provide: 'MaterialPlanRepositoryInterface',
      useClass: MaterialPlanRepository,
    },
    {
      provide: 'MaterialToRepairErrorRepositoryInterface',
      useClass: MaterialToRepairErrorRepository,
    },
    {
      provide: 'MaterialPlanStructureRepositoryInterface',
      useClass: MaterialPlanStructureRepository,
    },
    {
      provide: 'ManufacturingOrderRepositoryInterface',
      useClass: ManufacturingOrderRepository,
    },
    {
      provide: 'MaterialServiceInterface',
      useClass: MaterialService,
    },
    {
      provide: 'WorkOrderRepositoryInterface',
      useClass: WorkOrderRepository,
    },
    {
      provide: 'BomProducingStepDetailsRepositoryInterface',
      useClass: BomProducingStepDetailsRepository,
    },
    {
      provide: 'MaterialToRepairErrorRepositoryInterface',
      useClass: MaterialToRepairErrorRepository,
    },
  ],
  controllers: [MaterialController],
})
export class MaterialModule {}
