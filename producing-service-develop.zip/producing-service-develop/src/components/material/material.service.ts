import { Inject, Injectable } from '@nestjs/common';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ResponsePayload } from '@utils/response-payload';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { plainToInstance } from 'class-transformer';
import { ResponseBuilder } from '@utils/response-builder';
import {
  flatMap,
  map,
  uniq,
  isEmpty,
  keyBy,
  find,
  groupBy,
  sumBy,
} from 'lodash';
import { PagingResponse } from '@utils/paging.response';
import { MaterialServiceInterface } from './interface/material.service.interface';
import { MaterialPlanRepositoryInterface } from './interface/material-plan.repository.interface';
import { MaterialPlanStructureRepositoryInterface } from './interface/material-plan-structure.repository.interface';
import { MaterialPlanResponseDto } from './dto/response/material-plan.response.dto';
import { MaterialPlanResponseAbstractDto } from './dto/response/material-plan.response.abstract.dto';
import { GetListMaterialPlanRequestDto } from './dto/request/material-plan-list.request.dto';
import { GetListMaterialPlanResponseDto } from './dto/response/material-plan-list.response.dto';
import { SetStatusRequestDto } from '@components/material/dto/request/set-status.request.dto';
import {
  CAN_CONFIRM_MATERIAL_STATUS,
  CAN_REJECT_MATERIAL_STATUS,
  MaterialStatusEnum,
  ProductionOrderStatusEnum,
  ProductionOrderTypeEnum,
  PurchasedOrderStatusEnum,
  PURCHASE_ORDER_CODE,
} from './material.constant';
import { ManufacturingOrderRepositoryInterface } from '@components/manufacturing-order/interface/manufacturing-order.repository.interface';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { SaleServiceInterface } from '@components/sale-order/interface/sale.service.interface';
import { escapeCharForSearch, minus, plus, mul } from '@utils/common';
import {
  CheckMaterialPlan,
  CheckMaterialPlanResponseDto,
} from './dto/response/check-material-plan.response.dto';
import { MaterialToRepairErrorRepositoryInterface } from './interface/material-to-repair-error.interface.repository';
import { UpdateMaterialToRepairErrorRequestDto } from './dto/request/update-material-to-repair-error.request.dto';
import { WorkOrderRepositoryInterface } from '@components/work-order/interface/work-order.repository.interface';
import { DataSource, In, Not } from 'typeorm';
import { WorkOrderBomTransitEntity } from '@entities/work-order/work-order-bom-transit.entity';
import { InjectDataSource } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import { GetMoMaterialList } from './dto/request/get-mo-material-list.request.dto';
import { BomProducingStepDetailsRepositoryInterface } from '@components/bom/interface/bom-producing-step-details.repository.interface';
import { MoMaterialResponseDto } from './dto/request/mo-material.response.dto';
import { PreviewAvailableStockMaterialRequestDto } from './dto/request/preview-available-stock-material.request.dto';
import { BomRepositoryInterface } from '@components/bom/interface/bom.repository.interface';
import { PreviewAvailableStockMaterialResponseDto } from './dto/response/preview-available-stock.response.dto';
import { div } from '@utils/helper';
import { BomServiceInterface } from '@components/bom/interface/bom.service.interface';

@Injectable()
export class MaterialService implements MaterialServiceInterface {
  constructor(
    @Inject('MaterialPlanRepositoryInterface')
    private readonly materialPlanRepository: MaterialPlanRepositoryInterface,

    @Inject('MaterialPlanStructureRepositoryInterface')
    private readonly materialPlanStructureRepository: MaterialPlanStructureRepositoryInterface,

    @Inject('MaterialToRepairErrorRepositoryInterface')
    private readonly materialToRepairErrorRepository: MaterialToRepairErrorRepositoryInterface,

    @Inject('ManufacturingOrderRepositoryInterface')
    private readonly manufacturingOrderRepository: ManufacturingOrderRepositoryInterface,

    @Inject('BomRepositoryInterface')
    private readonly bomRepository: BomRepositoryInterface,

    @Inject('BomProducingStepDetailsRepositoryInterface')
    private readonly bomProducingStepDetailsRepository: BomProducingStepDetailsRepositoryInterface,

    @Inject('WorkOrderRepositoryInterface')
    private readonly workOrderRepository: WorkOrderRepositoryInterface,

    @Inject('SaleServiceInterface')
    private readonly saleService: SaleServiceInterface,

    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,

    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  /**
   *
   * @param request
   * @returns
   */
  public async detail(
    request: any,
  ): Promise<ResponsePayload<MaterialPlanResponseDto | any>> {
    const { id } = request;
    const materialPlan = await this.materialPlanRepository.getDetail(id);

    if (!materialPlan) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.MATERIAL_NOT_FOUND'))
        .build();
    }

    const itemIds = uniq(map(materialPlan.materialPlanStructures, 'itemId'));

    const serilizeItems = await this.itemService.getItemsByIds(itemIds, true);

    materialPlan.materialPlanStructures =
      materialPlan.materialPlanStructures.map((plan) => {
        plan.item = serilizeItems[plan.itemId]
          ? serilizeItems[plan.itemId]
          : {};
        return plan;
      });

    const response = plainToInstance(
      MaterialPlanResponseAbstractDto,
      materialPlan,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  public async getList(
    request: GetListMaterialPlanRequestDto,
  ): Promise<ResponsePayload<GetListMaterialPlanResponseDto | any>> {
    const { data, count } = await this.materialPlanRepository.getList(request);

    const response = plainToInstance(MaterialPlanResponseAbstractDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }
  /**
   *
   * @param request
   * @returns
   */
  public async confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<MaterialPlanResponseDto | any>> {
    const { id } = request;
    const materialPlan = await this.materialPlanRepository.findOneById(id);
    if (!materialPlan) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.MATERIAL_NOT_FOUND'))
        .build();
    }

    if (!CAN_CONFIRM_MATERIAL_STATUS.includes(materialPlan.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_REJECT'))
        .build();
    }

    const manufacturingOrder =
      await this.manufacturingOrderRepository.findOneById(
        materialPlan.manufacturingOrderId,
      );

    if (manufacturingOrder) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.MANUFACTURING_ORDER_WAS_NOT_CONFIRM',
          ),
        )
        .build();
    }

    materialPlan.approverId = null;
    materialPlan.approvedAt = null;
    materialPlan.status = MaterialStatusEnum.CONFIRMED;
    const result = await this.materialPlanRepository.create(materialPlan);
    const response = plainToInstance(MaterialPlanResponseAbstractDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  public async reject(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<MaterialPlanResponseDto | any>> {
    const { id } = request;
    const materialPlan = await this.materialPlanRepository.findOneById(id);

    if (!materialPlan) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.MATERIAL_NOT_FOUND'))
        .build();
    }

    if (!CAN_REJECT_MATERIAL_STATUS.includes(materialPlan.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_REJECT'))
        .build();
    }

    materialPlan.approverId = null;
    materialPlan.approvedAt = null;
    materialPlan.status = MaterialStatusEnum.REJECTED;
    const result = await this.materialPlanRepository.create(materialPlan);
    const response = plainToInstance(MaterialPlanResponseAbstractDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param id
   * @returns
   */
  public async checkMaterialPlan(
    id: number,
  ): Promise<ResponsePayload<CheckMaterialPlanResponseDto | any>> {
    const materialPlan = await this.materialPlanRepository.findOneById(id);

    if (!materialPlan) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.MATERIAL_NOT_FOUND'))
        .build();
    }
    const data = await Promise.all([
      await this.materialPlanStructureRepository.getSumMaterialByMaterialPlanId(
        id,
      ),
      await this.manufacturingOrderRepository.findOneById(
        materialPlan.manufacturingOrderId,
      ),
    ]);
    // get total quantity material of material plan
    const sumMaterialOfMaterialPlans = data[0];
    //arr item id of material plan
    const materialPlanStructureItemIds = uniq(
      map(flatMap(sumMaterialOfMaterialPlans), 'itemId'),
    );
    // get MO of material plan
    const manufacturingOrder = data[1];
    // get warehouses by factory id
    const warehouses = await this.warehouseService.getWarehouseListByConditions(
      {
        factoryId: manufacturingOrder.factoryId,
      },
    );
    // array warehouse id
    const warehouseIds = uniq(map(flatMap(warehouses), 'id'));
    // get data stock warehouse by arr item id , arr warehouse id
    const itemWarehouses =
      await this.itemService.getItemWarehouseListByItemIdsAndWarehouseIds(
        {
          itemIds: materialPlanStructureItemIds,
          warehouseIds: warehouseIds,
        },
        true,
        true,
      );
    // get list MO (not request MO) by factory id
    const manufacturingOrdersByFactoryId =
      await this.manufacturingOrderRepository.findByCondition({
        factoryId: manufacturingOrder.factoryId,
        id: Not(manufacturingOrder.id),
      });
    // arr MO id
    const manufacturingOrderIds = uniq(
      map(flatMap(manufacturingOrdersByFactoryId), 'id'),
    );
    // get Pro by condition
    const totalQuantityItemProductionOrders =
      await this.saleService.getTotalQuantityItemProductionOrdersByCondition(
        {
          status: [
            ProductionOrderStatusEnum.InProgress,
            ProductionOrderStatusEnum.Confirmed,
          ],
          type: ProductionOrderTypeEnum.Export,
          manufacturingOrderIds: manufacturingOrderIds,
          itemIds: materialPlanStructureItemIds,
        },
        true,
      );

    //mo id for purchased order
    manufacturingOrderIds.push(manufacturingOrder.id);

    const totalQuantityItemPurchasedOrders =
      await this.saleService.getTotalQuantityItemPurchasedOrdersByCondition(
        {
          status: [
            PurchasedOrderStatusEnum.InProgress,
            PurchasedOrderStatusEnum.Confirmed,
          ],
          manufacturingOrderIds: manufacturingOrderIds,
          itemIds: materialPlanStructureItemIds,
        },
        true,
      );

    const totalUnplanningQuantityItem = itemWarehouses;

    // match total unplanning quantity item after minus unplanning Pro
    if (totalQuantityItemProductionOrders.length !== 0) {
      totalQuantityItemProductionOrders.forEach((record) => {
        totalUnplanningQuantityItem[record.itemId].totalUnplanningQuantity =
          minus(
            Number(itemWarehouses[record.itemId]?.itemQuantity) || 0,
            Number(
              minus(
                Number(record.totalQuantity) || 0,
                Number(record.totalActualQuantity) || 0,
              ),
            ),
          );
      });
    } else {
      itemWarehouses.forEach((record) => {
        totalUnplanningQuantityItem[record.itemId].totalUnplanningQuantity =
          record.itemQuantity;
      });
    }

    // match total unplanning quantity item after plus unplanning Po
    if (totalQuantityItemPurchasedOrders.length !== 0) {
      totalQuantityItemPurchasedOrders.forEach((record) => {
        totalUnplanningQuantityItem[record.itemId].totalUnplanningQuantity =
          plus(
            Number(
              totalUnplanningQuantityItem[record.itemId]
                ?.totalUnplanningQuantity,
            ) || 0,
            Number(
              minus(
                Number(record.totalQuantity) || 0,
                Number(record.totalActualQuantity) || 0,
              ),
            ),
          );
      });
    }

    // match total quantity item need purchase
    const totalQuantityItemNeedPurchase = [];
    let missingQuantity = 0;
    for (let i = 0; i < sumMaterialOfMaterialPlans.length; i++) {
      missingQuantity = minus(
        Number(sumMaterialOfMaterialPlans[i]?.totalQuantity) || 0,
        Number(
          totalUnplanningQuantityItem[sumMaterialOfMaterialPlans[i].itemId]
            ?.totalUnplanningQuantity || 0,
        ) || 0,
      );
      // if (missingQuantity > 0) {
      totalQuantityItemNeedPurchase[sumMaterialOfMaterialPlans[i].itemId] = {
        itemId: sumMaterialOfMaterialPlans[i].itemId,
        missingQuantity:
          Number(sumMaterialOfMaterialPlans[i]?.totalQuantity) || 0,
        // missingQuantity: missingQuantity, // TODO @manh.lethe keep checking
      };
      // }
    }
    // TODO @manh.lethe keep checking
    // response
    // if (totalQuantityItemNeedPurchase.length === 0) {
    //   return new ResponseBuilder()
    //     .withCode(ResponseCodeEnum.SUCCESS)
    //     .withMessage(await this.i18n.translate('success.SUCCESS'))
    //     .build();
    // } else {
    const itemIds = uniq(map(flatMap(totalQuantityItemNeedPurchase), 'itemId'));
    const items = await this.itemService.getItemsByIds(itemIds);

    const dataItems = items.map((item) => ({
      id: item.id,
      quantity: totalQuantityItemNeedPurchase[item.id].missingQuantity,
      warehouseId: null,
      qcCheck: false,
      qcCriteriaId: null,
      price: +item.price || 0,
    }));

    const result = new CheckMaterialPlan();
    result.items = dataItems;
    result.manufacturingOrderId = materialPlan.manufacturingOrderId;
    result.code = manufacturingOrder.code + PURCHASE_ORDER_CODE;
    result.name = materialPlan.name;
    result.companyId = null;
    result.createdByUserId = null;
    result.vendorId = null;
    result.purchasedAt = new Date(Date.now());
    result.planTo = manufacturingOrder.planTo;
    result.planFrom = manufacturingOrder.planFrom;

    const response = plainToInstance(CheckMaterialPlan, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .withData(response)
      .build();
    // }
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async updateMaterialToRepairQuantity(
    payload: UpdateMaterialToRepairErrorRequestDto,
  ): Promise<any> {
    const { materials, workCenterId } = payload;
    const workOrderIds = uniq(map(materials, 'workOrderId'));
    const workOrders = await this.workOrderRepository.findWithRelations({
      where: {
        id: In(workOrderIds),
      },
    });

    if (!workOrders || workOrders.length !== workOrderIds.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }

    const rawWorkOrderMaterials =
      await this.workOrderRepository.getMaterialInputsByWorkOrderIds(
        workOrderIds,
      );
    const rawWorkOrderScrapMaterials =
      await this.workOrderRepository.getMaterialScrapByWorkOrderIds(
        workOrderIds,
      );

    if (isEmpty(rawWorkOrderMaterials)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.WORK_ORDER_NOT_FOUND'))
        .build();
    }

    const workOrderMaterials = keyBy(rawWorkOrderMaterials, 'id');
    const workOrderScrapMaterials = keyBy(rawWorkOrderScrapMaterials, 'id');
    const workOrderScrapTransactionEntities = [];
    const workOrderBomTransitEntities = [];

    for (let i = 0; i < materials.length; i++) {
      const material: any = materials[i];
      const workOrder = workOrderMaterials[material.workOrderId];
      const scrap = workOrderScrapMaterials[material.workOrderId];

      const input = find(workOrder.inputs, (j) => j.itemId === material.itemId);
      const scrapItem = !isEmpty(scrap)
        ? find(scrap.inputs, (j) => j.itemId === material.itemId)
        : null;
      if (isEmpty(input)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.MATERIAL_NOT_FOUND'))
          .build();
      }
      if (
        minus(
          minus(
            workOrder.inputQcCheck
              ? input.totalQcPassQuantity || 0
              : input.inputQuantity || 0,
            scrapItem ? scrapItem.quantity : 0,
          ),

          input.producedQuantity || 0,
        ) < material.errorRepairQuantity
      ) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.REPAIR_MTERIAL_QUANTITY_MUST_LESS_THAN_MATERIAL_INPUT_QUANTITY_REMANING',
            ),
          )
          .build();
      }

      input.producedQuantity = minus(
        input.producedQuantity || 0,
        material.errorRepairQuantity || 0,
      );

      const materialInputEntity = new WorkOrderBomTransitEntity();
      materialInputEntity.workOrderId = material.workOrderId;
      materialInputEntity.inputQuantity = input.inputQuantity;
      materialInputEntity.producedQuantity = input.producedQuantity;
      materialInputEntity.qcPassQuantity = input.totalQcPassQuantity || 0;
      materialInputEntity.qcRejectQuantity = input.totalQcRejectQuantity || 0;
      materialInputEntity.bomDetailBomId = input.bomId;
      materialInputEntity.bomDetailItemId = input.itemId;
      materialInputEntity.workCenterId = workCenterId;

      workOrderScrapTransactionEntities.push(
        this.materialToRepairErrorRepository.createEntity(material),
      );
      workOrderBomTransitEntities.push(materialInputEntity);
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const result = await queryRunner.manager.save(
        workOrderScrapTransactionEntities,
      );
      await queryRunner.manager.save(workOrderBomTransitEntities);

      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      console.log({ error });

      await queryRunner.rollbackTransaction();
      return new ApiError(
        ResponseCodeEnum.INTERNAL_SERVER_ERROR,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    } finally {
      await queryRunner.release();
    }
  }

  public async getMoMaterialList(request: GetMoMaterialList): Promise<any> {
    const { keyword, filter, sort } = request;

    let filterItemIds = [];
    let itemCondition;
    const itemSort = [];
    // filter item by keyword
    if (keyword) {
      itemCondition =
        'LOWER(unaccent(name)) LIKE ' +
        `LOWER(unaccent('%${escapeCharForSearch(keyword)}%'))`;
    }

    // filter item by filter name and code
    if (!isEmpty(filter)) {
      const itemCodeFilter = filter.find((x) => x.column === 'itemCode');
      if (!isEmpty(itemCodeFilter)) {
        itemCondition = itemCondition
          ? itemCondition +
            ' AND ' +
            'LOWER(unaccent(code)) LIKE ' +
            `LOWER(unaccent('%${escapeCharForSearch(itemCodeFilter.text)}%'))`
          : 'LOWER(unaccent(code)) LIKE ' +
            `LOWER(unaccent('%${escapeCharForSearch(itemCodeFilter.text)}%'))`;
      }
      const itemNameFilter = filter.find((x) => x.column === 'itemName');
      if (!isEmpty(itemNameFilter)) {
        itemCondition = itemCondition
          ? itemCondition +
            ' AND ' +
            'LOWER(unaccent(name)) LIKE ' +
            `LOWER(unaccent('%${escapeCharForSearch(itemNameFilter.text)}%'))`
          : 'LOWER(unaccent(name)) LIKE ' +
            `LOWER(unaccent('%${escapeCharForSearch(itemNameFilter.text)}%'))`;
      }
    }

    // sort item by name

    if (!isEmpty(sort)) {
      const itemNameSort = sort.find((x) => x.column === 'itemName');
      if (!isEmpty(itemNameSort)) {
        itemSort.push(itemNameSort);
      }
    }

    if (itemCondition) {
      itemCondition += `escape '\\'`;
    }

    const itemResponse = await this.itemService.getItemsByConditions(
      itemCondition,
      itemSort,
    );

    if (itemResponse.statusCode === 200) {
      filterItemIds = map(itemResponse.data, 'id');
    } else {
      return new ResponseBuilder({
        items: [],
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    }

    const { result, count } =
      await this.bomProducingStepDetailsRepository.getListMaterial(
        request,
        filterItemIds,
      );

    if (!isEmpty(result)) {
      const itemIds = map(result, 'itemId');
      const items = await this.itemService.getItemsByIds(itemIds, true);
      result.forEach((d) => {
        d.item = items[d.itemId];
      });

      // sort by filterItemIds
      if (!isEmpty(itemSort) && !isEmpty(filterItemIds)) {
        result.sort(function (a, b) {
          return (
            filterItemIds.indexOf(a.itemId) - filterItemIds.indexOf(b.itemId)
          );
        });
      }
    }

    const response = plainToInstance(MoMaterialResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  public async previewAvailableStockMaterials(
    request: PreviewAvailableStockMaterialRequestDto,
  ): Promise<any> {
    const { items } = request;
    const itemIds = map(items, 'id');
    const bomVersionIds = map(items, 'bomVersionId');
    const tempBoms = {};
    const boms = await this.bomRepository.bomStructPlanning(
      itemIds,
      bomVersionIds,
    );
    const key = (bom) => `${bom.itemId}-${bom.bomVersionId}`;

    if (isEmpty(boms)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('success.NOT_FOUND'))
        .build();
    }

    const serializedBomItem = keyBy(boms, key);

    const bomMaterials = await this.bomRepository.getMaterialItemByIds(
      uniq(map(boms, 'bomId')),
      uniq(map(boms, 'bomVersionId')),
    );

    const serializedBomMaterial = keyBy(bomMaterials, 'bomId');
    // // handle boms -> bomMap, producingSteps
    for (let i = 0; i < boms.length; i++) {
      const bom = boms[i];
      const bomMaterials: any = serializedBomMaterial[bom.bomId];

      bom.materials = [];
      bomMaterials?.materials?.forEach((item) => {
        bom.materials.push({
          id: item.itemId,
          bomVersionId: item.bomVersionId,
          quantity: item.quantity,
        });
      });
      if (bomVersionIds.includes(bom.bomVersionId)) {
        tempBoms[bom.itemId] = {
          ...bom,
          materials: bom.materials.filter((material) =>
            bomVersionIds.includes(material.bomVersionId),
          ),
        };
      }
    }

    const infoItemIds = [...itemIds];
    const materials = {};

    const itemBoms = items.map((item) => {
      const bom = tempBoms[item.id];
      if (!isEmpty(bom.sub)) {
        bom.materials
          .filter((m) => m.bomVersionId === bom.bomVersionId)
          .forEach((material) => {
            material.planQuantity = mul(
              item.quantity,
              div(material.quantity || 1, +bom.bomQuantity || 1) || 0,
            );
          });
        bom.sub = bom.sub?.map((subBom) => {
          return {
            ...subBom,
            bomQuantity: serializedBomItem[subBom.itemId]?.bomQuantity || 1,
          };
        });
        bom.materials.push(
          ...this.mapSubBom(bom, item.quantity, serializedBomItem, bom.sub),
        );
      }
      const groupMaterials: any = groupBy(bom.materials, 'id');

      bom.materials = Object.keys(groupMaterials).map((key) => ({
        id: key,
        planQuantity: sumBy(groupMaterials[key], 'planQuantity'),
        // soConfirmedQuantity: sumBy(groupMaterials[key], 'soConfirmedQuantity'),
      }));
      infoItemIds.push(...map(bom.materials, 'id'));
      return bom;
    });
    const serializeItems = await this.itemService.getItemsByIds(
      infoItemIds,
      true,
    );

    const result = [];
    itemBoms.forEach((itemBom) => {
      itemBom.materials.forEach((material) => {
        const availableQuantity =
          serializeItems[material.id]?.remainingQuantity > 0
            ? serializeItems[material.id].remainingQuantity
            : 0;
        result.push({
          item: serializeItems[itemBom.itemId],
          material: {
            ...serializeItems[material.id],
            planQuantity: material.planQuantity,
            // soConfirmedQuantity: materials[material.id]?.quantity || 0,
            availableStock: availableQuantity,
            requestQuantity:
              minus(material.planQuantity || 0, availableQuantity || 0) > 0
                ? minus(material.planQuantity || 0, availableQuantity || 0)
                : 0,
          },
        });

        serializeItems[material.id].remainingQuantity -=
          minus(material.planQuantity || 0, availableQuantity || 0) > 0
            ? minus(material.planQuantity || 0, availableQuantity || 0)
            : 0;
      });
    });

    const response = plainToInstance(
      PreviewAvailableStockMaterialResponseDto,
      result,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .withData(response)
      .build();
  }

  private mapSubBom(bom, quantity, boms, subBoms?: any[]) {
    const materials = [];

    subBoms.forEach((subBom) => {
      const childBom = boms[subBom.itemId];
      if (childBom) {
        childBom.materials.forEach((material) => {
          material.planQuantity = mul(
            mul(quantity, material.quantity),
            subBom.quantity,
          );
        });
        materials.push(...childBom.materials);
        if (!isEmpty(childBom.subItemIds)) {
          materials.push(
            ...this.mapSubBom(childBom, boms, childBom.subItemIds),
          );
        }
      }
    });

    return materials;
  }
}
