import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { MaterialPlanEntity } from '@entities/material/material-plan.entity';
import { GetListMaterialPlanRequestDto } from '../dto/request/material-plan-list.request.dto';

export interface MaterialPlanRepositoryInterface
  extends BaseInterfaceRepository<MaterialPlanEntity> {
  getDetail(id: number): Promise<any>;
  getList(payload: GetListMaterialPlanRequestDto): Promise<any>;
}
