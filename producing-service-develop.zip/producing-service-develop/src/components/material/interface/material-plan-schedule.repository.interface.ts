import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { MaterialPlanScheduleEntity } from '@entities/material/material-plan-schedules.entity';

export type MaterialPlanScheduleRepositoryInterface =
  BaseInterfaceRepository<MaterialPlanScheduleEntity>;
