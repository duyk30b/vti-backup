import { MaterialReportRequestDto } from '@components/report/dto/request/material-report.request.dto';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { MaterialPlanStructureEntity } from '@entities/material/material-plan-structure.entity';

export interface MaterialPlanStructureRepositoryInterface
  extends BaseInterfaceRepository<MaterialPlanStructureEntity> {
  getSumMaterialByMaterialPlanId(materialPlanId: number): Promise<any>;
  getMaterialReportList(request: MaterialReportRequestDto): Promise<any>;
  getMaterialImportWorkCenters(moId: number, itemIds: number[]): Promise<any>;
}
