import { ResponsePayload } from '@utils/response-payload';
import { GetListMaterialPlanRequestDto } from '../dto/request/material-plan-list.request.dto';
import { GetListMaterialPlanResponseDto } from '../dto/response/material-plan-list.response.dto';
import { MaterialPlanResponseDto } from '../dto/response/material-plan.response.dto';
import { SetStatusRequestDto } from '@components/material/dto/request/set-status.request.dto';
import { CheckMaterialPlanResponseDto } from '../dto/response/check-material-plan.response.dto';
import { UpdateMaterialToRepairErrorRequestDto } from '../dto/request/update-material-to-repair-error.request.dto';
import { GetMoMaterialList } from '../dto/request/get-mo-material-list.request.dto';
import { PreviewAvailableStockMaterialRequestDto } from '../dto/request/preview-available-stock-material.request.dto';

export interface MaterialServiceInterface {
  detail(request: any): Promise<ResponsePayload<MaterialPlanResponseDto | any>>;
  getList(
    request: GetListMaterialPlanRequestDto,
  ): Promise<ResponsePayload<GetListMaterialPlanResponseDto | any>>;
  confirm(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<MaterialPlanResponseDto | any>>;
  reject(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<MaterialPlanResponseDto | any>>;
  checkMaterialPlan(
    id: number,
  ): Promise<ResponsePayload<CheckMaterialPlanResponseDto | any>>;
  updateMaterialToRepairQuantity(
    request: UpdateMaterialToRepairErrorRequestDto,
  ): Promise<any>;
  getMoMaterialList(request: GetMoMaterialList): Promise<any>;
  previewAvailableStockMaterials(
    request: PreviewAvailableStockMaterialRequestDto,
  ): Promise<any>;
}
