import { MaterialReportRequestDto } from '@components/report/dto/request/material-report.request.dto';
import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { MaterialPlanProducingStepEntity } from '@entities/material/material-plan-producing-steps.entity';
import { MaterialPlanStructureEntity } from '@entities/material/material-plan-structure.entity';

export type MaterialPlanProducingStepRepositoryInterface =
  BaseInterfaceRepository<MaterialPlanProducingStepEntity>;
