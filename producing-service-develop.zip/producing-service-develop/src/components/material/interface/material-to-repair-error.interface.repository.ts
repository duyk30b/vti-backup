import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { MaterialToRepairErrorEntity } from '@entities/material/material-quantity-to-repair-error.entity';
export interface MaterialToRepairErrorRepositoryInterface
  extends BaseInterfaceRepository<MaterialToRepairErrorEntity> {
  createEntity(data: any): any;
}
