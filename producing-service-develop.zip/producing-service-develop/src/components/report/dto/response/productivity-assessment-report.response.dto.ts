import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class ProductivityAssessmentReportSchedules {
  @ApiProperty({ example: '1/10/2021', description: '' })
  @Expose()
  executionDay: Date;

  @ApiProperty({ example: 10, description: '' })
  @Expose()
  productivityRatio: number;

  @ApiProperty({ example: 10, description: '' })
  @Expose()
  oeeRatio: number;
}

export class ProductivityAssessmentReport {
  @ApiProperty({ example: 'xưởng A', description: '' })
  @Expose()
  workCenterName: string;

  @ApiProperty({ type: ProductivityAssessmentReportSchedules, isArray: true })
  @Expose()
  @Type(() => ProductivityAssessmentReportSchedules)
  @IsArray()
  productivityAssessmentReportSchedules: ProductivityAssessmentReportSchedules[];
}

export class ProductivityAssessmentReportResponseDto extends SuccessResponse {
  @ApiProperty({ type: ProductivityAssessmentReport, isArray: true })
  @Expose()
  @Type(() => ProductivityAssessmentReport)
  @IsArray()
  data: ProductivityAssessmentReport[];
}
