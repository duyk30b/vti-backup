import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

export class ProductivityReport {
  @ApiProperty({ example: '1/10/2021', description: '' })
  @Expose()
  executionDay: Date;

  @ApiProperty({ example: 10, description: '' })
  @Expose()
  planExecutionTime: number;

  @ApiProperty({ example: 10, description: '' })
  @Expose()
  actualExecutionTime: number;

  @ApiProperty({ example: 10, description: '' })
  @Expose()
  planProductivity: number;

  @ApiProperty({ example: 10, description: '' })
  @Expose()
  actualProductivity: number;

  @ApiProperty({ example: 10, description: '' })
  @Expose()
  cumulativePlanProductivity: number;

  @ApiProperty({ example: 10, description: '' })
  @Expose()
  cumulativeActualProductivity: number;

  @ApiProperty({ example: 10, description: '' })
  @Expose()
  oeePlan: number;

  @ApiProperty({ example: 10, description: '' })
  @Expose()
  oeeActual: number;

  @ApiProperty({ example: 10, description: '' })
  @Expose()
  oeeQuality: number;

  @ApiProperty({ example: 10, description: '' })
  @Expose()
  oeeAvailablility: number;

  @ApiProperty({ example: 10, description: '' })
  @Expose()
  oeePerformance: number;

  @ApiProperty({ example: 10, description: '' })
  @Expose()
  cumulativeActualOee: number;
}

export class ProductivityReportResponseDto extends SuccessResponse {
  @ApiProperty({ type: ProductivityReport, isArray: true })
  @Expose()
  @Type(() => ProductivityReport)
  @IsArray()
  data: ProductivityReport[];
}
