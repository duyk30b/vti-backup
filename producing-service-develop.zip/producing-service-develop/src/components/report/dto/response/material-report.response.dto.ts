import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class MaterialPlanSchedules {
  @ApiProperty({ example: '1/10/2021', description: '' })
  @Expose()
  executionDay: Date;

  @ApiProperty({ example: 10, description: '' })
  @Expose()
  planQuantityMaterial: number;

  @ApiProperty({ example: 10, description: '' })
  @Expose()
  actualQuantityMaterial: number;

  @ApiProperty({ example: 10, description: '' })
  @Expose()
  remainingQuantityMaterial: number;
}

export class MaterialReport {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  itemId: number;

  @ApiProperty({ example: 'đinh', description: '' })
  @Expose()
  itemName: string;

  @ApiProperty({ type: MaterialPlanSchedules, isArray: true })
  @Expose()
  @Type(() => MaterialPlanSchedules)
  @IsArray()
  materialPlanSchedules: MaterialPlanSchedules[];
}

export class ManufacturingOrderPlan {
  @ApiProperty({ example: '1/10/2021', description: '' })
  @Expose()
  executionDay: Date;

  @ApiProperty({ example: 10, description: '' })
  @Expose()
  planQuantityMaterial: number;

  @ApiProperty({ example: 10, description: '' })
  @Expose()
  actualQuantityMaterial: number;

  @ApiProperty({ example: 10, description: '' })
  @Expose()
  shortageQuantityMaterial: number;
}

export class DataMaterialReport {
  @ApiProperty({ type: MaterialReport, isArray: true })
  @Expose()
  @Type(() => MaterialReport)
  @IsArray()
  materialReport: MaterialReport[];

  @ApiProperty({ type: ManufacturingOrderPlan, isArray: true })
  @Expose()
  @Type(() => ManufacturingOrderPlan)
  @IsArray()
  manufacturingOrderPlan: ManufacturingOrderPlan[];
}

export class MaterialReportResponseDto extends SuccessResponse {
  @ApiProperty({ type: DataMaterialReport })
  @Expose()
  @Type(() => DataMaterialReport)
  data: DataMaterialReport;
}
