import { BaseDto } from '@core/dto/base.dto';
import { BasicResponseDto } from '@core/dto/response/basic.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class ItemUnit extends BasicResponseDto {}

class User extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  fullName: string;
}

export class GetGeneralLotProfileReportResponseDto extends BaseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  moName: string;

  @ApiProperty()
  @Expose()
  moCode: string;

  @ApiProperty()
  @Expose()
  mfg: Date;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  planningQuantity: number;

  @ApiProperty()
  @Expose()
  keepQuantity: number;

  @ApiProperty()
  @Expose()
  errorQuantity: number;

  @ApiProperty()
  @Expose()
  fromAnotherLotQuantity: number;

  @ApiProperty()
  @Expose()
  samplingQuantity: number;

  @ApiProperty()
  @Expose()
  importProQuantity: number;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  @Type(() => User)
  confirmedBy: User;

  @ApiProperty()
  @Expose()
  confirmedAt: Date;

  @ApiProperty()
  @Expose()
  productivity: number;

  @ApiProperty()
  @Expose()
  ownProd: number;

  @ApiProperty()
  @Expose()
  removalRate: number;

  @ApiProperty()
  @Expose()
  itemName: string;

  @ApiProperty()
  @Expose()
  itemCode: string;

  @ApiProperty()
  @Expose()
  itemUnitName: string;
}
