import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty, IsOptional } from 'class-validator';

export class MaterialReportRequestDto extends BaseDto {
  @ApiProperty({
    example: 1,
    description: '',
  })
  @Transform((data) => {
    return Number(data.value);
  })
  @IsNotEmpty()
  @IsInt()
  manufacturingOrderId: number;

  @ApiProperty({
    example: 1,
    description: '',
  })
  @Transform((data) => {
    return Number(data.value);
  })
  @IsOptional()
  @IsInt()
  itemId: number;

  @ApiProperty({
    example: 1,
    description: '',
  })
  @Transform((data) => {
    return Number(data.value);
  })
  @IsOptional()
  @IsInt()
  producingStepId: number;

  @ApiProperty({
    example: 1,
    description: '',
  })
  @Transform((data) => {
    return Number(data.value);
  })
  @IsOptional()
  @IsInt()
  workCenterId: number;
}
