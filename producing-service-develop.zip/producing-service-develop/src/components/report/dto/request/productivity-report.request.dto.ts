import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsNotEmpty } from 'class-validator';

export class ProductivityReportRequestDto extends BaseDto {
  @ApiProperty({
    example: 1,
    description: '',
  })
  @Transform((data) => {
    return Number(data.value);
  })
  @IsNotEmpty()
  @IsInt()
  manufacturingOrderId: number;

  @ApiProperty({
    example: 1,
    description: '',
  })
  @Transform((data) => {
    return Number(data.value);
  })
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty({
    example: 1,
    description: '',
  })
  @Transform((data) => {
    return Number(data.value);
  })
  @IsNotEmpty()
  @IsInt()
  producingStepId: number;

  @ApiProperty({
    example: 1,
    description: '',
  })
  @Transform((data) => {
    return Number(data.value);
  })
  @IsNotEmpty()
  @IsInt()
  workCenterId: number;
}
