import { ApiProperty } from '@nestjs/swagger';
import { BaseDto } from '@core/dto/base.dto';

import { Transform } from 'class-transformer';
import { IsNumber, IsOptional } from 'class-validator';

export class GetManufacturingOrderReportRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @Transform((v) => Number(v.value))
  @IsNumber()
  id: number;

  @ApiProperty()
  @Transform((v) => Number(v.value))
  @IsNumber()
  itemId: number;

  @ApiProperty()
  @IsOptional()
  @Transform((v) => Number(v.value))
  @IsNumber()
  productionLineId: number;
}
