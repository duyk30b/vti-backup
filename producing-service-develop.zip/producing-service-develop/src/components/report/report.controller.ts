import {
  Controller,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Query,
} from '@nestjs/common';
import { isEmpty } from 'lodash';
import { MessagePattern, Transport } from '@nestjs/microservices';
import { ResponsePayload } from '@utils/response-payload';
import { ReportServiceInterface } from './interface/report.service.interface';
import { ProductivityReportRequestDto } from './dto/request/productivity-report.request.dto';
import { ProductivityReportResponseDto } from './dto/response/productivity-report.response.dto';
import { MaterialReportResponseDto } from './dto/response/material-report.response.dto';
import { MaterialReportRequestDto } from './dto/request/material-report.request.dto';
import { ProductivityAssessmentReportRequestDto } from './dto/request/productivity-assessment-report.request.dto';
import { ProductivityAssessmentReportResponseDto } from './dto/response/productivity-assessment-report.response.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  LIST_MANUFACTURING_ORDER_REPORT_PERMISSION,
  PRODUCTIVITY_ASSESSMENT_REPORT_PERMISSION,
  PRODUCTIVITY_REPORT_PERMISSION,
} from '@utils/permissions/report';
import { DETAIL_MATERIAL_PLAN_PERMISSION } from '@utils/permissions/material-plan';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { DEFAULT_TRANSPORT } from '@utils/constant';
import { NATS_PRODUCE } from '@config/nats.config';
import { GetGeneralLotProfileReportResponseDto } from './dto/response/get-general-lot-profile-report.response.dto';
import { GetManufacturingOrderReportRequestDto } from './dto/request/get-manufacturing-order-report.request.dto';

@Controller('reports')
export class ReportController {
  constructor(
    @Inject('ReportServiceInterface')
    private readonly reportService: ReportServiceInterface,
  ) {}

  /**
   *
   * @param payload
   * @returns
   */
  @Get('productivities')
  @ApiOperation({
    tags: ['Report'],
    summary: 'Productivity Report',
    description: 'báo cáo năng suất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Productivity Report successfully',
    type: ProductivityReportResponseDto,
  })
  @PermissionCode(PRODUCTIVITY_REPORT_PERMISSION.code)
  @MessagePattern(`${NATS_PRODUCE}.productivity_report`, DEFAULT_TRANSPORT)
  public async getProductivityReport(
    @Query() payload: ProductivityReportRequestDto,
  ): Promise<ResponsePayload<ProductivityReportResponseDto | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.reportService.getProductivityReport(request);
  }

  @PermissionCode(DETAIL_MATERIAL_PLAN_PERMISSION.code)
  @Get('/materials')
  @ApiOperation({
    tags: ['Report'],
    summary: 'Material Report',
    description: 'báo cáo nguyên vật liệu',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Material Report successfully',
    type: MaterialReportResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.material_report`, DEFAULT_TRANSPORT)
  public async getMaterialReportList(
    @Query() payload: MaterialReportRequestDto,
  ): Promise<ResponsePayload<MaterialReportResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.reportService.getMaterialReportList(request);
  }

  @PermissionCode(PRODUCTIVITY_ASSESSMENT_REPORT_PERMISSION.code)
  @Get('/productivity-assessments')
  @ApiOperation({
    tags: ['Report'],
    summary: 'Productivity Assessment Report',
    description: 'báo cáo đánh giá năng suất',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Productivity Assessment Report successfully',
    type: ProductivityAssessmentReportResponseDto,
  })
  @MessagePattern(
    `${NATS_PRODUCE}.productivity_assessment_report`,
    DEFAULT_TRANSPORT,
  )
  public async getProductivityAssessmentReport(
    @Query() payload: ProductivityAssessmentReportRequestDto,
  ): Promise<ResponsePayload<ProductivityAssessmentReportResponseDto | any>> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.reportService.getProductivityAssessmentReport(request);
  }

  @PermissionCode(LIST_MANUFACTURING_ORDER_REPORT_PERMISSION.code)
  @Get('/manufacturing-orders/:id')
  @ApiOperation({
    tags: ['Report'],
    summary: 'Manufacturing Order Report',
    description: 'Báo cáo tổng kết sản xuất',
  })
  @ApiResponse({
    status: 200,
    type: GetGeneralLotProfileReportResponseDto,
  })
  public async getManufacturingOrderReport(
    @Param('id', new ParseIntPipe()) id: number,
    @Query() query: GetManufacturingOrderReportRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.reportService.getManufacturingOrderReport(request);
  }
}
