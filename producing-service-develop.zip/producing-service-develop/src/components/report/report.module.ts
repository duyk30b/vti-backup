import { ManufacturingOrderEntity } from '@entities/manufacturing-order/manufacturing-orders.entity';
import { MaterialPlanStructureEntity } from '@entities/material/material-plan-structure.entity';
import { MaterialPlanEntity } from '@entities/material/material-plan.entity';
import { WorkOrderEntity } from '@entities/work-order/work-order.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ManufacturingOrderRepository } from '@repositories/manufacturing-order/manufacturing-order.repository';
import { MaterialPlanStructureRepository } from '@repositories/material/material-plan-structure.repository';
import { MaterialPlanRepository } from '@repositories/material/material-plan.repository';
import { WorkOrderRepository } from '@repositories/work-order/work-order.repository';
import { ReportController } from './report.controller';
import { ReportService } from './report.service';
import { ConfigModule } from '@nestjs/config';
import { ProducingStepRepository } from '@repositories/produce/producing-step.repository';
import { ManufacturingOrderDetailRepository } from '@repositories/manufacturing-order/manufacturing-order-detail.repository';
import { MaterialService } from '@components/material/material.service';
import { WorkOrderBomTransitRepository } from '@repositories/work-order/work-order-bom-transit.repository';
import { ProducingStepEntity } from '@entities/producing-step/producing-step.entity';
import { ManufacturingOrderDetailEntity } from '@entities/manufacturing-order/manufacturing-order-details.entity';
import { MaterialModule } from '@components/material/material.module';
import { BomModule } from '@components/bom/bom.module';
import { WorkOrderBomTransitEntity } from '@entities/work-order/work-order-bom-transit.entity';

@Module({
  imports: [
    ConfigModule,
    TypeOrmModule.forFeature([
      ManufacturingOrderEntity,
      MaterialPlanEntity,
      MaterialPlanStructureEntity,
      WorkOrderEntity,
      ProducingStepEntity,
      ManufacturingOrderDetailEntity,
      WorkOrderBomTransitEntity,
    ]),
    MaterialModule,
    BomModule,
  ],
  providers: [
    {
      provide: 'ReportServiceInterface',
      useClass: ReportService,
    },
    {
      provide: 'ManufacturingOrderRepositoryInterface',
      useClass: ManufacturingOrderRepository,
    },
    {
      provide: 'MaterialPlanRepositoryInterface',
      useClass: MaterialPlanRepository,
    },
    {
      provide: 'MaterialPlanStructureRepositoryInterface',
      useClass: MaterialPlanStructureRepository,
    },
    {
      provide: 'WorkOrderRepositoryInterface',
      useClass: WorkOrderRepository,
    },
    {
      provide: 'ProducingStepRepositoryInterface',
      useClass: ProducingStepRepository,
    },
    {
      provide: 'ManufacturingOrderDetailRepositoryInterface',
      useClass: ManufacturingOrderDetailRepository,
    },
    {
      provide: 'MaterialServiceInterface',
      useClass: MaterialService,
    },
    {
      provide: 'WorkOrderBomTransitRepositoryInterface',
      useClass: WorkOrderBomTransitRepository,
    },
  ],
  controllers: [ReportController],
  exports: [
    {
      provide: 'ManufacturingOrderRepositoryInterface',
      useClass: ManufacturingOrderRepository,
    },
    {
      provide: 'MaterialPlanRepositoryInterface',
      useClass: MaterialPlanRepository,
    },
    {
      provide: 'MaterialPlanStructureRepositoryInterface',
      useClass: MaterialPlanStructureRepository,
    },
    {
      provide: 'WorkOrderRepositoryInterface',
      useClass: WorkOrderRepository,
    },
    {
      provide: 'ProducingStepRepositoryInterface',
      useClass: ProducingStepRepository,
    },
    {
      provide: 'ManufacturingOrderDetailRepositoryInterface',
      useClass: ManufacturingOrderDetailRepository,
    },
    {
      provide: 'MaterialServiceInterface',
      useClass: MaterialService,
    },
    {
      provide: 'WorkOrderBomTransitRepositoryInterface',
      useClass: WorkOrderBomTransitRepository,
    },
  ],
})
export class ReportModule {}
