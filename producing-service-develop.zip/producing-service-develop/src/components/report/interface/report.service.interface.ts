import { ResponsePayload } from '@utils/response-payload';
import { MaterialReportRequestDto } from '../dto/request/material-report.request.dto';
import { ProductivityAssessmentReportRequestDto } from '../dto/request/productivity-assessment-report.request.dto';
import { ProductivityReportRequestDto } from '../dto/request/productivity-report.request.dto';
import { MaterialReportResponseDto } from '../dto/response/material-report.response.dto';
import { ProductivityAssessmentReportResponseDto } from '../dto/response/productivity-assessment-report.response.dto';
import { ProductivityReportResponseDto } from '../dto/response/productivity-report.response.dto';
import { GetManufacturingOrderReportRequestDto } from '../dto/request/get-manufacturing-order-report.request.dto';

export interface ReportServiceInterface {
  getProductivityReport(
    request: ProductivityReportRequestDto,
  ): Promise<ResponsePayload<ProductivityReportResponseDto | any>>;
  getMaterialReportList(
    request: MaterialReportRequestDto,
  ): Promise<ResponsePayload<MaterialReportResponseDto | any>>;
  getProductivityAssessmentReport(
    request: ProductivityAssessmentReportRequestDto,
  ): Promise<ResponsePayload<ProductivityAssessmentReportResponseDto | any>>;
  getManufacturingOrderReport(
    request: GetManufacturingOrderReportRequestDto,
  ): ResponsePayload<any> | PromiseLike<ResponsePayload<any>>;
}
