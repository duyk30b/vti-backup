import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ResponsePayload } from '@utils/response-payload';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { plainToInstance } from 'class-transformer';
import { ResponseBuilder } from '@utils/response-builder';
import { DataSource } from 'typeorm';
import { flatMap, map, orderBy, uniq, filter } from 'lodash';
import { ReportServiceInterface } from './interface/report.service.interface';
import {
  ProductivityReport,
  ProductivityReportResponseDto,
} from './dto/response/productivity-report.response.dto';
import { ProductivityReportRequestDto } from './dto/request/productivity-report.request.dto';
import { ManufacturingOrderRepositoryInterface } from '@components/manufacturing-order/interface/manufacturing-order.repository.interface';
import { div, mul, plus } from '@utils/common';
import {
  DataMaterialReport,
  MaterialReportResponseDto,
} from './dto/response/material-report.response.dto';
import { MaterialReportRequestDto } from './dto/request/material-report.request.dto';
import { MaterialPlanRepositoryInterface } from '@components/material/interface/material-plan.repository.interface';
import { MaterialPlanStructureRepositoryInterface } from '@components/material/interface/material-plan-structure.repository.interface';
import { WorkOrderRepositoryInterface } from '@components/work-order/interface/work-order.repository.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { ProductivityAssessmentReportRequestDto } from './dto/request/productivity-assessment-report.request.dto';
import {
  ProductivityAssessmentReport,
  ProductivityAssessmentReportResponseDto,
} from './dto/response/productivity-assessment-report.response.dto';
import { GetManufacturingOrderReportRequestDto } from './dto/request/get-manufacturing-order-report.request.dto';
import { ProducingStepRepositoryInterface } from '@components/producing-step/interface/producing-step.repository.interface';
import { ManufacturingOrderDetailRepositoryInterface } from '@components/manufacturing-order/interface/manufacturing-order-detail.repository.interface';
import { MaterialServiceInterface } from '@components/material/interface/material.service.interface';
import { PreviewAvailableStockMaterialRequestDto } from '@components/material/dto/request/preview-available-stock-material.request.dto';
import { WorkOrderBomTransitRepositoryInterface } from '@components/work-order/interface/work-order-bom-transit.repository.interface';

@Injectable()
export class ReportService implements ReportServiceInterface {
  constructor(
    @Inject('ManufacturingOrderRepositoryInterface')
    private readonly manufacturingOrderRepository: ManufacturingOrderRepositoryInterface,

    @Inject('MaterialPlanRepositoryInterface')
    private readonly materialPlanRepository: MaterialPlanRepositoryInterface,

    @Inject('MaterialPlanStructureRepositoryInterface')
    private readonly materialPlanStructureRepository: MaterialPlanStructureRepositoryInterface,

    @Inject('WorkOrderRepositoryInterface')
    private readonly workOrderRepository: WorkOrderRepositoryInterface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('ProducingStepRepositoryInterface')
    private readonly producingStepRepository: ProducingStepRepositoryInterface,

    @Inject('ManufacturingOrderDetailRepositoryInterface')
    private readonly manufacturingOrderDetailRepository: ManufacturingOrderDetailRepositoryInterface,

    @Inject('MaterialServiceInterface')
    protected readonly materialService: MaterialServiceInterface,

    @Inject('WorkOrderBomTransitRepositoryInterface')
    private readonly workOrderBomTransitRepository: WorkOrderBomTransitRepositoryInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  public async getProductivityReport(
    request: ProductivityReportRequestDto,
  ): Promise<ResponsePayload<ProductivityReportResponseDto | any>> {
    const result =
      await this.manufacturingOrderRepository.getProductivityReport(request);

    let totalActualQuantity = 0;
    let totalWorkingDuration = 0;
    let totalProductivityIndex = 0;
    let totalProductionTimePerItem = 0;
    let totalActualExecutionTime = 0;
    let totalPlanExecutionTime = 0;
    let totalLogTimeDuration = 0;
    let totalQcPassQuantity = 0;
    let cumulativeOeeAvailablility = 0;
    let cumulativeOeePerformance = 0;
    let cumulativeOeeQuality = 0;
    for (let i = 0; i < result.length; i++) {
      if (
        new Date(result[0].executionDay) <= new Date(result[i].executionDay)
      ) {
        totalActualQuantity = plus(
          Number(totalActualQuantity),
          Number(result[i].actualQuantity),
        );
        totalWorkingDuration = plus(
          Number(totalWorkingDuration),
          Number(result[i].workingDuration),
        );
        totalLogTimeDuration = plus(
          Number(totalLogTimeDuration),
          Number(result[i].logTimeDuration),
        );
        totalQcPassQuantity = plus(
          Number(totalQcPassQuantity),
          Number(result[i].qcPassQuantity),
        );
        totalProductivityIndex = plus(
          Number(totalProductivityIndex),
          Number(result[i].productivityIndex),
        );
        totalProductionTimePerItem = plus(
          Number(totalProductionTimePerItem),
          Number(result[i].productionTimePerItem),
        );
      } else {
        break;
      }

      totalActualExecutionTime =
        totalActualQuantity > 0
          ? div(totalLogTimeDuration, totalActualQuantity)
          : 0;
      totalPlanExecutionTime =
        totalProductivityIndex > 0
          ? div(totalProductionTimePerItem, totalProductivityIndex)
          : 0;

      cumulativeOeeQuality =
        totalActualQuantity > 0
          ? div(totalQcPassQuantity, totalActualQuantity)
          : 0;
      cumulativeOeeAvailablility =
        totalWorkingDuration > 0
          ? div(totalLogTimeDuration, totalWorkingDuration)
          : 0;
      cumulativeOeePerformance =
        totalActualExecutionTime > 0
          ? div(totalPlanExecutionTime, totalActualExecutionTime)
          : 0;

      result[i].cumulativeActualProductivity =
        totalActualExecutionTime > 0
          ? mul(
              div(
                Number(result[i].planExecutionTime),
                totalActualExecutionTime,
              ),
              100,
            )
          : 0;

      result[i].oeeQuality = mul(Number(result[i].oeeQuality), 100);

      result[i].oeeAvailablility = mul(Number(result[i].oeeAvailablility), 100);

      result[i].oeePerformance = mul(Number(result[i].oeePerformance), 100);

      result[i].oeeActual = mul(Number(result[i].oeeActual), 100);

      result[i].cumulativeActualOee = mul(
        mul(
          cumulativeOeeQuality,
          mul(cumulativeOeeAvailablility, cumulativeOeePerformance),
        ),
        100,
      );
    }
    const response = plainToInstance(ProductivityReport, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  public async getMaterialReportList(
    request: MaterialReportRequestDto,
  ): Promise<ResponsePayload<MaterialReportResponseDto | any>> {
    const materialReportList =
      await this.materialPlanStructureRepository.getMaterialReportList(request);

    const materialReport = materialReportList.reduce((record, item) => {
      const temp = record.find((x) => x.itemId === item.itemId);
      if (!temp) {
        record.push({
          itemId: item.itemId,
          materialPlanSchedules: [item],
        });
      } else {
        temp.materialPlanSchedules.push(item);
      }
      return record;
    }, []);

    const itemIds = uniq(map(flatMap(materialReport), 'itemId'));

    const items = await this.itemService.getItemsByIds(itemIds, true);

    const materialReports = materialReport.map((record) => ({
      ...record,
      itemName: items[record.itemId].name,
    }));

    const manufacturingOrderPlan =
      await this.workOrderRepository.getManufacturingOrderPlanReportList(
        request,
      );

    const response = plainToInstance(
      DataMaterialReport,
      {
        materialReport: materialReports,
        manufacturingOrderPlan: manufacturingOrderPlan,
      },
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async getProductivityAssessmentReport(
    request: ProductivityAssessmentReportRequestDto,
  ): Promise<ResponsePayload<ProductivityAssessmentReportResponseDto | any>> {
    const result =
      await this.manufacturingOrderRepository.getProductivityAssessmentReport(
        request,
      );

    const data = result.map((record) => ({
      workCenterName: record.workCenterName,
      productivityAssessmentReportSchedules:
        this.cumulativeOEECalculationOfProductivityAssessmentReport(
          record.productivityAssessmentReportSchedules,
        ),
    }));

    const response = plainToInstance(ProductivityAssessmentReport, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  private cumulativeOEECalculationOfProductivityAssessmentReport(
    data: any[],
  ): any[] {
    if (data.length === 0) return [];

    const dataSort = orderBy(
      data,
      [(obj) => new Date(obj.executionDay)],
      ['asc'],
    );

    let planExecutionTime = 0;
    let totalActualQuantity = 0;
    let totalWorkingDuration = 0;
    let totalProductivityIndex = 0;
    let totalProductionTimePerItem = 0;
    let totalActualExecutionTime = 0;
    let totalPlanExecutionTime = 0;
    let totalLogTimeDuration = 0;
    let totalQcPassQuantity = 0;
    let cumulativeOeeAvailablility = 0;
    let cumulativeOeePerformance = 0;
    let cumulativeOeeQuality = 0;
    const result = [];

    for (let i = 0; i < dataSort.length; i++) {
      if (
        new Date(dataSort[0].executionDay) <= new Date(dataSort[i].executionDay)
      ) {
        totalActualQuantity = plus(
          Number(totalActualQuantity),
          Number(dataSort[i].actualQuantity),
        );
        totalWorkingDuration = plus(
          Number(totalWorkingDuration),
          Number(dataSort[i].workingDuration),
        );
        totalLogTimeDuration = plus(
          Number(totalLogTimeDuration),
          Number(dataSort[i].logTimeDuration),
        );
        totalQcPassQuantity = plus(
          Number(totalQcPassQuantity),
          Number(dataSort[i].qcPassQuantity),
        );
        totalProductivityIndex = plus(
          Number(totalProductivityIndex),
          Number(dataSort[i].productivityIndex),
        );
        totalProductionTimePerItem = plus(
          Number(totalProductionTimePerItem),
          Number(dataSort[i].productionTimePerItem),
        );
      } else {
        break;
      }

      planExecutionTime =
        Number(dataSort[i].productivityIndex) > 0
          ? div(
              Number(dataSort[i].productionTimePerItem),
              Number(dataSort[i].productivityIndex),
            )
          : 0;

      totalActualExecutionTime =
        totalActualQuantity > 0
          ? div(totalLogTimeDuration, totalActualQuantity)
          : 0;
      totalPlanExecutionTime =
        totalProductivityIndex > 0
          ? div(totalProductionTimePerItem, totalProductivityIndex)
          : 0;

      cumulativeOeeQuality =
        totalActualQuantity > 0
          ? div(totalQcPassQuantity, totalActualQuantity)
          : 0;
      cumulativeOeeAvailablility =
        totalWorkingDuration > 0
          ? div(totalLogTimeDuration, totalWorkingDuration)
          : 0;
      cumulativeOeePerformance =
        totalActualExecutionTime > 0
          ? div(totalPlanExecutionTime, totalActualExecutionTime)
          : 0;

      result[i] = {
        executionDay: dataSort[i].executionDay,
        oeeRatio: mul(
          mul(
            cumulativeOeeQuality,
            mul(cumulativeOeeAvailablility, cumulativeOeePerformance),
          ),
          100,
        ),
        productivityRatio:
          totalActualExecutionTime > 0
            ? mul(div(planExecutionTime, totalActualExecutionTime), 100)
            : 0,
      };
    }

    return result;
  }

  async getManufacturingOrderReport(
    request: GetManufacturingOrderReportRequestDto,
  ): Promise<any> {
    const { id, itemId, productionLineId } = request;
    const [
      materialReport,
      // workerWorkloadReport,
      producingStepReport,
      serializeItem,
    ] = await Promise.all([
      await this.getMaterialReport(id, itemId, productionLineId),
      // await this.workOrderRepository.workerWorkloadReport(id, itemId),
      await this.workOrderRepository.producingStepReport(
        id,
        itemId,
        productionLineId,
      ),
      await this.itemService.getItemsByIds([itemId], true),
    ]);

    //get sampleQuantity from latest producing step
    let producingStepReportResponse = producingStepReport;
    const routingId = producingStepReport.find((i) => {
      return i.bom.itemId === itemId;
    })?.bom.routingId;
    if (routingId) {
      const latestStep =
        await this.producingStepRepository.getLatestStepInRouting(routingId);
      producingStepReportResponse = producingStepReport.map((i) => {
        if (i.producingStep.id !== latestStep.id || i?.bom.itemId !== itemId) {
          i.sampleQuantity = 0;
        }
        return i;
      });
    }

    producingStepReportResponse.forEach((psReport) => {
      psReport.bom = {
        ...psReport.bom,
        item: serializeItem[psReport.bom.itemId],
      };
    });

    return new ResponseBuilder({
      materialReport,
      // workerWorkloadReport,
      producingStepReport: producingStepReportResponse,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getMaterialReport(
    id: number,
    itemId: number,
    productionLineId: number,
  ): Promise<any> {
    const moDetail =
      await this.manufacturingOrderDetailRepository.findOneWithRelations({
        where: {
          manufacturingOrderId: id,
          itemId: itemId,
        },
      });
    const materialItemResponse =
      await this.materialService.previewAvailableStockMaterials({
        items: [
          {
            id: itemId,
            bomVersionId: moDetail.bomVersionId,
            quantity: moDetail.quantity,
          },
        ],
      } as PreviewAvailableStockMaterialRequestDto);
    if (materialItemResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    const materialItems = map(materialItemResponse.data, 'material');

    const materialItemInput =
      await this.workOrderBomTransitRepository.materialReport(
        id,
        itemId,
        productionLineId,
      );

    materialItems.forEach((materialItem) => {
      materialItem.inputQuantity = 0;
      filter(materialItemInput, (mI) => mI.itemId === materialItem.id).forEach(
        (mi) => {
          materialItem.inputQuantity = plus(
            materialItem.inputQuantity || 0,
            mi.quantity,
          );
        },
      );
    });

    return materialItems;
  }
}
