import { Expose } from 'class-transformer';
import { IsNotEmpty, IsInt, IsOptional, IsEnum } from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';
export class GetItemBoqListRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsInt()
  id: number;

  @Expose()
  @IsOptional()
  @IsEnum(['0', '1'])
  onlyInProgressItem: string;
}
