import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsEnum, IsOptional, IsString } from 'class-validator';

export class GetBoqListRequestDto extends PaginationQuery {
  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isPlanning: string;

  @ApiPropertyOptional({
    example: '[{"id": "1", "itemId": "2"}]',
  })
  @IsOptional()
  @IsString()
  queryIds?: string;
}
