import { IsInt, IsOptional } from 'class-validator';
import { PaginationQuery } from '@utils/pagination.query';
export class GetItemBoqDetailRequestDto extends PaginationQuery {
  @IsOptional()
  @IsInt()
  id: number;

  @IsOptional()
  @IsInt()
  itemBoqId: number;

  @IsOptional()
  @IsInt()
  planId: number;
}
