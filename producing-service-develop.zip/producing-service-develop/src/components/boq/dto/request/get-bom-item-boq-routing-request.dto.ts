import { IsNotEmpty, IsInt } from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';
export class GetBomItemBoqRoutingRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsInt()
  id: number;

  @IsNotEmpty()
  @IsInt()
  itemId: number;
}
