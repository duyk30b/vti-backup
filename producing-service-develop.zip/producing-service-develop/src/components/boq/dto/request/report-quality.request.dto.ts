import { PaginationQuery } from '@utils/pagination.query';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString, MaxLength } from 'class-validator';

export class ReportQualityRequestDto extends PaginationQuery {
  @ApiPropertyOptional({ example: 'example', description: 'search' })
  @IsOptional()
  @IsString()
  keyword: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetFile: string;

  @ApiPropertyOptional({
    example: '[{"id": "1", "itemId": "2"}]',
  })
  @IsOptional()
  @IsString()
  queryIds?: string;
}
