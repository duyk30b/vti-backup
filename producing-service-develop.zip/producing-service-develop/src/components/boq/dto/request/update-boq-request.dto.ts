import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsOptional } from 'class-validator';
import { CreateBoqRequestDto } from './create-boq-request.dto';

export class UpdateBoqRequestDto extends CreateBoqRequestDto {
  @ApiProperty()
  @IsInt()
  @IsOptional()
  id: number;
}
