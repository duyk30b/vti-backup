import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsArray,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  MaxLength,
  IsPositive,
  ValidateNested,
} from 'class-validator';

export class BoqItemDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @IsPositive()
  quantity: number;
}

export class CreateBoqRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @MaxLength(255)
  @IsString()
  name: string;

  @ApiProperty()
  @MaxLength(20)
  @IsNotEmpty()
  @IsString()
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  pmId: number;

  @ApiProperty()
  @IsInt()
  @IsOptional()
  apmId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  planFrom: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  planTo: Date;

  @ApiPropertyOptional()
  @MaxLength(255)
  @IsOptional()
  description: string;

  @ApiProperty({
    example: 1,
    description: 'User id của người tạo item',
  })
  @IsOptional()
  @IsInt()
  createdByUserId: number;

  @ApiProperty()
  @ValidateNested()
  @ArrayUnique((e: BoqItemDto) => e.id)
  @IsArray()
  @ArrayNotEmpty()
  @Type(() => BoqItemDto)
  boqItems: BoqItemDto[];
}
