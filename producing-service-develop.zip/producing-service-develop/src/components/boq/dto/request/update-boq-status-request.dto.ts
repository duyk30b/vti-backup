import { IsNotEmpty, IsInt } from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';
export class UpdateBoqStatusRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsInt()
  id: number;
}
