import { IsNotEmpty } from 'class-validator';
import { BaseDto } from 'src/core/dto/base.dto';

export class GetBoqDetailRequestDto extends BaseDto {
  @IsNotEmpty()
  id: number;
}
