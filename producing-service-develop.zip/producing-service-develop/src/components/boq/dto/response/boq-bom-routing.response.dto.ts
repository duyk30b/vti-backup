import { ItemResponseDto } from '@components/item/dto/response/item.dto.response';
import { UserResponseDto } from '@components/user/dto/response/user.dto.response';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class Routing {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;
}

class ProducingStep {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;
}

class RoutingVersion {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  @IsArray()
  @Type(() => ProducingStep)
  producingSteps: ProducingStep[];
}

export class BoqBomRoutingResponseDto {
  @ApiProperty()
  @Type(() => Routing)
  @Expose()
  routing: Routing;

  @ApiProperty()
  @IsArray()
  @Type(() => RoutingVersion)
  @Expose()
  routingVersions: RoutingVersion[];
}
