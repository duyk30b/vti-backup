import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern, Transport } from '@nestjs/microservices';
import { isEmpty } from 'lodash';
import { CreateBoqRequestDto } from './dto/request/create-boq-request.dto';
import { DeleteBoqRequestDto } from './dto/request/delete-boq.request.dto';
import { GetBoqDetailRequestDto } from './dto/request/get-boq-detail.request.dto';
import { GetBoqListRequestDto } from './dto/request/get-boq-list.request.dto';
import { UpdateBoqStatusRequestDto } from './dto/request/update-boq-status-request.dto';
import { UpdateBoqRequestDto } from './dto/request/update-boq-request.dto';
import { BoqServiceInterface } from './interface/boq.service.interface';
import { GetItemBoqListRequestDto } from './dto/request/get-item-boq-list-request.dto';
import { GetItemBoqDetailRequestDto } from './dto/request/get-item-boq-detail-request.dto';
import { GetBomItemBoqRoutingRequestDto } from './dto/request/get-bom-item-boq-routing-request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CREATE_BOQ_PERMISSION,
  UPDATE_BOQ_PERMISSION,
  DELETE_BOQ_PERMISSION,
  DETAIL_BOQ_PERMISSION,
  LIST_BOQ_PERMISSION,
  CONFIRM_BOQ_PERMISSION,
  REJECT_BOQ_PERMISSION,
  COMPLETE_BOQ_PERMISSION,
} from '@utils/permissions/boq';
import { GetListDataByCodes } from '@utils/common.request.dto';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { BoqResponseDto } from './dto/response/boq.response.dto';
import { ItemDto } from '@components/plan/dto/response/detail-plan.response';
import { DEFAULT_TRANSPORT } from '@utils/constant';
import { NATS_PRODUCE } from '@config/nats.config';

@Controller('boqs')
export class BoqController {
  constructor(
    @Inject('BoqServiceInterface')
    private readonly boqService: BoqServiceInterface,
  ) {}

  /**
   * Create new boq
   * @param request CreateBoqRequestDto
   * @returns
   */
  @PermissionCode(CREATE_BOQ_PERMISSION.code)
  @Post('create')
  @ApiOperation({
    tags: ['Boq'],
    summary: 'Create new boq',
    description: 'Tạo 1 boq mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  @MessagePattern(`${NATS_PRODUCE}.create_boq`, DEFAULT_TRANSPORT)
  public async create(@Body() payload: CreateBoqRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.boqService.create({
      ...request,
      createdByUserId: request.user?.id,
    });
  }

  /**
   * Update boq
   * @param request UpdateBoqRequestDto
   * @returns
   */
  @PermissionCode(UPDATE_BOQ_PERMISSION.code)
  @Put(':id')
  @ApiOperation({
    tags: ['Boq'],
    summary: 'Update boq',
    description: 'Cập nhật thông tin công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  @MessagePattern(`${NATS_PRODUCE}.update_boq`, DEFAULT_TRANSPORT)
  public async update(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateBoqRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.boqService.update({
      ...request,
      createdByUserId: request.user?.id,
      id: id,
    });
  }

  /**
   * Get boq detail
   * @param request GetBoqDetailRequest
   * @returns
   */
  @PermissionCode(DETAIL_BOQ_PERMISSION.code)
  @Get(':id')
  @ApiOperation({
    tags: ['Boq'],
    summary: 'Boq Detail',
    description: 'Chi tiết công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: BoqResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.get_boq_detail`, DEFAULT_TRANSPORT)
  public async getDetail(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    return await this.boqService.getDetail({
      id: id,
    } as GetBoqDetailRequestDto);
  }

  /**
   * Get boq detail
   * @param request GetBoqDetailRequest
   * @returns
   */
  @Get(':id/bom-items/list')
  @ApiOperation({
    tags: ['Boq'],
    summary: 'Boq all item',
    description: 'Tất cả các item của công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: [ItemDto],
  })
  @MessagePattern(`${NATS_PRODUCE}.get_boq_all_item`, DEFAULT_TRANSPORT)
  public async getAllItemBoq(
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    return await this.boqService.getAllItem({
      id: id,
    } as GetBoqDetailRequestDto);
  }

  /**
   * Get boq list
   * @param request GetBoqListRequest
   * @returns
   */
  @PermissionCode(LIST_BOQ_PERMISSION.code)
  @Get('list')
  @ApiOperation({
    tags: ['Boq', 'Boqs'],
    summary: 'List Boq',
    description: 'Danh sách công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  public async getList(@Query() payload: GetBoqListRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.boqService.getList(request);
  }

  @PermissionCode(DELETE_BOQ_PERMISSION.code)
  @Delete(':id')
  @ApiOperation({
    tags: ['Boq'],
    summary: 'Delete boq (soft delete)',
    description: 'Xóa công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  @MessagePattern(`${NATS_PRODUCE}.delete_boq`, DEFAULT_TRANSPORT)
  public async delete(@Param('id', new ParseIntPipe()) id): Promise<any> {
    return await this.boqService.delete({ id: id } as DeleteBoqRequestDto);
  }

  /**
   * Reject
   * @param payload
   * @returns
   */
  @PermissionCode(REJECT_BOQ_PERMISSION.code)
  @Put(':id/reject')
  @ApiOperation({
    tags: ['Produces', 'Boq'],
    summary: 'Reject Boq',
    description: 'Từ chối Công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: BoqResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.reject_boq`, DEFAULT_TRANSPORT)
  public async reject(@Param('id', new ParseIntPipe()) id): Promise<any> {
    return await this.boqService.reject({
      id: id,
    } as UpdateBoqStatusRequestDto);
  }

  /**
   * Confirm
   * @param payload
   * @returns
   */
  @PermissionCode(CONFIRM_BOQ_PERMISSION.code)
  @Put(':id/confirm')
  @ApiOperation({
    tags: ['Produces', 'Boq'],
    summary: 'Confirm Boq',
    description: 'Xác nhận Công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: BoqResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.confirm_boq`, DEFAULT_TRANSPORT)
  public async confirm(@Param('id', new ParseIntPipe()) id): Promise<any> {
    return await this.boqService.confirm({
      id: id,
    } as UpdateBoqStatusRequestDto);
  }

  /**
   * Complete
   * @param payload
   * @returns
   */
  @PermissionCode(COMPLETE_BOQ_PERMISSION.code)
  @Put(':id/complete')
  @ApiOperation({
    tags: ['Produces', 'Boq'],
    summary: 'Complete Boq',
    description: 'Hoàn tất Công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Complete successfully',
    type: BoqResponseDto,
  })
  @MessagePattern(`${NATS_PRODUCE}.complete_boq`, DEFAULT_TRANSPORT)
  public async complete(@Param('id', new ParseIntPipe()) id): Promise<any> {
    return await this.boqService.complete({
      id: id,
    } as UpdateBoqStatusRequestDto);
  }

  /**
   * Get boq list by ids
   * @param
   * @returns
   */
  public async getListBoqByIds(ids: number[]): Promise<any> {
    return await this.boqService.getListBoqByIds(ids);
  }

  @MessagePattern(`${NATS_PRODUCE}.get_item_boq_list`, DEFAULT_TRANSPORT)
  public async getItemBoqList(
    @Body() payload: GetItemBoqListRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.boqService.getItemBoqList(request);
  }

  @MessagePattern(`${NATS_PRODUCE}.get_plan_item_boq_list`, DEFAULT_TRANSPORT)
  public async getPlanItemBoqList(
    @Body() payload: GetItemBoqListRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.boqService.getPlanItemBoqList(request);
  }

  @Get(':id/plans/:planId/items/:itemBoqId')
  @ApiOperation({
    tags: ['Boq', 'Boq item'],
    summary: 'Boq item list',
    description: 'Danh sách bán thành phẩm của công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Get detail successfully',
  })
  @MessagePattern(`${NATS_PRODUCE}.get_item_boq_detail`, DEFAULT_TRANSPORT)
  public async getItemBoqDetail(
    @Param('id', new ParseIntPipe()) id: number,
    @Param('itemBoqId', new ParseIntPipe()) itemBoqId: number,
    @Param('planId', new ParseIntPipe()) planId: number,
    @Query() payload: GetItemBoqDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.boqService.getItemBoqDetail({
      id: id,
      itemBoqId: itemBoqId,
      planId: planId,
      ...request,
    });
  }

  @Get(':id/bom-items/:itemId/routings')
  @ApiOperation({
    tags: ['Boq', 'Boq item', 'Routing Version'],
    summary: 'Boq item list',
    description: 'Danh sách phiên bản quy trình của item công trình',
  })
  @ApiResponse({
    status: 200,
    description: 'Get list successfully',
  })
  @MessagePattern(`${NATS_PRODUCE}.get_bom_item_boq_routing`, DEFAULT_TRANSPORT)
  public async getBomItemBoqRouting(
    @Param('id', new ParseIntPipe()) id: number,
    @Param('itemId', new ParseIntPipe()) itemId: number,
  ): Promise<any> {
    return await this.boqService.getBomItemBoqRouting({
      id: id,
      itemId: itemId,
    } as GetBomItemBoqRoutingRequestDto);
  }

  @MessagePattern(`${NATS_PRODUCE}.boq_in_progress_list`, DEFAULT_TRANSPORT)
  public async getInProgressBoqList(): Promise<any> {
    return await this.boqService.getInProgressBoqList();
  }

  public async getListBoqByCodes(
    @Body() payload: GetListDataByCodes,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.boqService.getListBoqByCodes(request.codes);
  }

  //TODO remove when refactor done
  @MessagePattern(`${NATS_PRODUCE}.get_list_boq_by_ids`, DEFAULT_TRANSPORT)
  public async getListBoqByIdsTcp(ids: number[]): Promise<any> {
    return await this.boqService.getListBoqByIds(ids);
  }
  @MessagePattern(`${NATS_PRODUCE}.get_list_boq_by_codes`, DEFAULT_TRANSPORT)
  public async getListBoqByCodesTcp(
    @Body() payload: GetListDataByCodes,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.boqService.getListBoqByCodes(request.codes);
  }

  @MessagePattern(`${NATS_PRODUCE}.get_boq_list`, DEFAULT_TRANSPORT)
  public async getListTcp(@Body() payload: GetBoqListRequestDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.boqService.getList(request);
  }
}
