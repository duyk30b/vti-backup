import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Boq } from '@entities/boq/boqs.entity';
import { BoqDetail } from '@entities/boq/boq-details.entity';
import { BoqService } from './boq.service';
import { BoqController } from './boq.controller';
import { BoqRepository } from '@repositories/boq/boq.repository';
import { BoqDetailRepository } from '@repositories/boq/boq-detail.repository';
import { ItemService } from '@components/item/item.service';
import { ItemModule } from '@components/item/item.module';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { BomRepository } from '@repositories/bom/bom.repository';
import { BomEntity } from '@entities/bom/boms.entity';
import { MoPlanRepository } from '@repositories/plan/mo-plan.repository';
import { MoPlanBomRepository } from '@repositories/plan/mo-plan-bom.repository';
import { MoPlanEntity } from '@entities/manufacturing-order/mo-plans.entity';
import { MoPlanBomEntity } from '@entities/manufacturing-order/mo-plan-boms.entity';
@Module({
  imports: [
    TypeOrmModule.forFeature([
      Boq,
      BoqDetail,
      BomEntity,
      MoPlanEntity,
      MoPlanBomEntity,
    ]),
    ItemModule,
    UserModule,
  ],
  providers: [
    {
      provide: 'BoqRepositoryInterface',
      useClass: BoqRepository,
    },
    {
      provide: 'BoqDetailRepositoryInterface',
      useClass: BoqDetailRepository,
    },
    {
      provide: 'MoPlanBomRepositoryInteface',
      useClass: MoPlanBomRepository,
    },
    {
      provide: 'MoPlanRepositoryInteface',
      useClass: MoPlanRepository,
    },
    {
      provide: 'BoqServiceInterface',
      useClass: BoqService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'BomRepositoryInterface',
      useClass: BomRepository,
    },
  ],
  controllers: [BoqController],
})
export class BoqModule {}
