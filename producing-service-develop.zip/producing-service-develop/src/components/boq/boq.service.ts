import { MoPlanBomRepositoryInteface } from '@components/plan/inteface/mo-plan-bom.repository.inteface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { BoqDetail } from '@entities/boq/boq-details.entity';
import { Boq } from '@entities/boq/boqs.entity';
import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { distinctArray, plus } from '@utils/common';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { flatMap, isEmpty, map, uniq, values, find, orderBy } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, In, Not } from 'typeorm';
import {
  BoqStatusEnum,
  STATUS_TO_UPDATE_BOQ,
  STATUS_TO_COMPLETE_BOQ_STATUS,
  STATUS_TO_CONFIRM_BOQ_STATUS,
  STATUS_TO_DELETE_BOQ_STATUS,
  STATUS_TO_REJECT_BOQ_STATUS,
} from './boq.constant';
import { CreateBoqRequestDto } from './dto/request/create-boq-request.dto';
import { DeleteBoqRequestDto } from './dto/request/delete-boq.request.dto';
import { GetBoqDetailRequestDto } from './dto/request/get-boq-detail.request.dto';
import { GetBoqListRequestDto } from './dto/request/get-boq-list.request.dto';
import { UpdateBoqStatusRequestDto } from './dto/request/update-boq-status-request.dto';
import { UpdateBoqRequestDto } from './dto/request/update-boq-request.dto';
import { BoqResponseDto } from './dto/response/boq.response.dto';
import { BoqDetailRepositoryInterface } from './interface/boq-detail.repository.interface';
import { BoqRepositoryInterface } from './interface/boq.repository.interface';
import { BoqServiceInterface } from './interface/boq.service.interface';
import { BomRepositoryInterface } from '@components/bom/interface/bom.repository.interface';
import { GetItemBoqListRequestDto } from './dto/request/get-item-boq-list-request.dto';
import { BoqItemResponseDto } from './dto/response/boq-item.response.dto';
import { GetItemBoqDetailRequestDto } from './dto/request/get-item-boq-detail-request.dto';
import { BoqItemDetailResponseDto } from './dto/response/boq-item-detail.response.dto';
import { GetBomItemBoqRoutingRequestDto } from './dto/request/get-bom-item-boq-routing-request.dto';
import { BoqBomRoutingResponseDto } from './dto/response/boq-bom-routing.response.dto';
import { BoqPlanItemResponseDto } from './dto/response/boq-plan-item.response.dto';
import { MoPlanRepositoryInteface } from '@components/plan/inteface/mo-plan.repository.inteface';
import { ResponsePayload } from '@utils/response-payload';

@Injectable()
export class BoqService implements BoqServiceInterface {
  constructor(
    @Inject('BoqRepositoryInterface')
    private readonly boqRepository: BoqRepositoryInterface,

    @Inject('MoPlanRepositoryInteface')
    private readonly moPlanRepository: MoPlanRepositoryInteface,

    @Inject('BoqDetailRepositoryInterface')
    private readonly boqDetailRepository: BoqDetailRepositoryInterface,

    @Inject('MoPlanBomRepositoryInteface')
    private readonly moPlanBomRepository: MoPlanBomRepositoryInteface,

    @Inject('ItemServiceInterface')
    protected readonly itemService: ItemServiceInterface,

    @Inject('UserServiceInterface')
    protected readonly userService: UserServiceInterface,

    @Inject('BomRepositoryInterface')
    private readonly bomRepository: BomRepositoryInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  public async getListBoqByIds(ids: number[]): Promise<any> {
    const result = await this.boqRepository.getListBoqByIds(ids);

    const response = plainToInstance(BoqResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .withData(response)
      .build();
  }

  async getAllItem(payload: GetBoqDetailRequestDto): Promise<any> {
    const boq = await this.boqRepository.findOneById(payload.id);
    if (!boq) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const allBom = await this.boqDetailRepository.getAllByBoqId(payload.id);
    const itemIds = [];
    allBom.forEach((bom) => {
      itemIds.push(bom.parentItemId);
      if (bom.bomId) {
        itemIds.push(bom.itemId);
      }
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(
        await this.itemService.getItemsByIds(distinctArray(itemIds), false),
      )
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async delete(payload: DeleteBoqRequestDto): Promise<any> {
    const { id } = payload;
    let response, message;
    let code = ResponseCodeEnum.SUCCESS;

    const boq = await this.boqRepository.findOneById(id);
    if (!boq) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_DELETE_BOQ_STATUS.includes(boq.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.delete(Boq, {
        id: id,
      });

      await queryRunner.manager.delete(BoqDetail, {
        boqId: id,
      });

      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      message = error;
    }

    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(code)
      .withData(response)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  /**
   *
   * @param payload UpdateBoqStatusRequestDto
   * @returns
   */
  public async complete(payload: UpdateBoqStatusRequestDto): Promise<any> {
    const { id } = payload;

    const boq = await this.boqRepository.findOneById(id);
    if (!boq) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_COMPLETE_BOQ_STATUS.includes(boq.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }

    return await this.updateBoqStatus(boq, BoqStatusEnum.COMPLETED);
  }

  /**
   *
   * @param payload UpdateBoqStatusRequestDto
   * @returns
   */
  public async confirm(payload: UpdateBoqStatusRequestDto): Promise<any> {
    const { id } = payload;

    const boq = await this.boqRepository.findOneById(id);
    if (!boq) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_CONFIRM_BOQ_STATUS.includes(boq.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }

    return await this.updateBoqStatus(boq, BoqStatusEnum.CONFIRMED);
  }

  /**
   *
   * @param payload UpdateBoqStatusRequestDto
   * @returns
   */
  public async reject(payload: UpdateBoqStatusRequestDto): Promise<any> {
    const { id } = payload;

    const boq = await this.boqRepository.findOneById(id);
    if (!boq) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_REJECT_BOQ_STATUS.includes(boq.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }

    return await this.updateBoqStatus(boq, BoqStatusEnum.REJECTED);
  }

  async getList(payload: GetBoqListRequestDto): Promise<any> {
    const filterPMName = payload.filter?.find(
      (item) => item.column === 'pmName',
    );

    let filterPmIds = [];

    if (!isEmpty(filterPMName)) {
      filterPmIds = await this.userService.getUsersByUsernameOrFullName(
        filterPMName,
        true,
      );

      if (isEmpty(filterPmIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: payload.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    const { result, count } = await this.boqRepository.getList(
      payload,
      filterPmIds,
    );

    const userIds = uniq(map(flatMap(result), 'pmId'));
    const users = await this.userService.getUserByIds(userIds, true);

    const data = result.map((boq) => ({
      ...boq,
      pm: users[boq.pmId],
    }));

    const dataReturn = plainToInstance(BoqResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: payload.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   * Get boq detail
   */
  public async getDetail(payload: GetBoqDetailRequestDto): Promise<any> {
    const { id } = payload;
    const boq = await this.boqRepository.getDetail(id);
    if (!boq) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const itemIds = map(boq.boqDetails, 'itemId');

    const userIds = uniq([boq.createdByUserId, boq.pmId, boq.apmId]);
    const { normalizeUsers, normalizeItems } = await this.getBoqExtraInfo(
      itemIds,
      userIds,
    );

    boq.createdByUser = normalizeUsers[boq.createdByUserId];
    boq.pm = normalizeUsers[boq.pmId];
    boq.apm = normalizeUsers[boq.apmId];

    boq.boqDetails = boq.boqDetails.map((boqDetail) => ({
      ...boqDetail,
      itemName: normalizeItems[boqDetail.itemId].name,
      item: normalizeItems[boqDetail.itemId],
    }));

    const dataReturn = plainToInstance(BoqResponseDto, boq, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async update(payload: UpdateBoqRequestDto): Promise<any> {
    const { id, name, code } = payload;
    const boq = await this.boqRepository.findOneById(id);
    if (!boq) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!STATUS_TO_UPDATE_BOQ.includes(boq.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_ACCEPTABLE)
        .withMessage(await this.i18n.translate('error.NOT_ACCEPTABLE'))
        .build();
    }
    //check code
    const isExistCode = await this.boqRepository.findByCondition({
      code: code,
      id: Not(id),
    });
    if (isExistCode.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BOQ_CODE_IS_EXIST'))
        .build();
    }

    //check name
    const isExistName = await this.boqRepository.findByCondition({
      name: name,
      id: Not(id),
    });
    if (isExistName.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BOQ_NAME_IS_EXIST'))
        .build();
    }

    if (boq.status === BoqStatusEnum.REJECTED) {
      boq.status = BoqStatusEnum.PENDING;
    }

    const boqEntity = await this.boqRepository.updateEntity(boq, payload);

    return await this.save(boqEntity, payload);
  }

  public async create(payload: CreateBoqRequestDto): Promise<any> {
    const { code, name } = payload;

    const isCodeExist = await this.boqRepository.findByCondition({
      code: code,
    });
    if (isCodeExist.length > 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BOQ_CODE_IS_EXIST'))
        .build();
    }

    const isNameExist = await this.boqRepository.findByCondition({
      name: name,
    });

    if (isNameExist.length > 0) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BOQ_NAME_IS_EXIST'))
        .build();
    }

    const boqEntity = this.boqRepository.createEntity(payload);
    return await this.save(boqEntity, payload);
  }

  private async save(
    boqEntity: Boq,
    payload: CreateBoqRequestDto,
  ): Promise<any> {
    const { boqItems } = payload;
    const isUpdate = boqEntity.id !== null;
    let response, message;
    let code = ResponseCodeEnum.SUCCESS;
    // To do validate with pm(project manager)

    const itemIds = uniq(boqItems.map((e) => e.id));
    const itemsExist = await this.itemService.getItemsByIds(itemIds);
    if (!itemsExist || itemIds.length !== itemsExist.length) {
      const itemIdsExist = itemsExist ? itemsExist.map((e) => e.itemId) : [];
      return new ResponseBuilder({
        invalidItems: boqItems.filter((e) => !itemIdsExist.includes(e.id)),
      })
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.REQUEST_ITEM_NOT_FOUND'))
        .build();
    }
    const items = {};
    itemsExist.forEach((item) => {
      items[item.id] = item;
    });

    const bomsData = await this.bomRepository.getBomsByItemIds(itemIds);
    const boms = {};
    bomsData.forEach((bom) => {
      boms[bom.itemId] = {
        id: bom.id,
      };
    });

    const boqDetailRaws = {};
    boqItems.forEach((item) => {
      if (boqDetailRaws[item.id]) {
        boqDetailRaws[item.id].quantity = plus(
          boqDetailRaws[item.id].quantity,
          item.quantity,
        );
      } else {
        boqDetailRaws[item.id] = {
          id: item.id,
          quantity: item.quantity,
          code: items[item.id].code,
        };
      }
    });

    if (boqEntity.planFrom > boqEntity.planTo) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.PLAN_TO_MUST_GREATER_THAN_PLAN_FROM',
          ),
        )
        .build();
    }

    // create boq
    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const boq = await queryRunner.manager.save(boqEntity);

      const boqDetailEntities = values(boqDetailRaws).map((boqDetail: any) =>
        this.boqDetailRepository.createEntity({
          boqId: boq.id,
          itemId: boqDetail.id,
          itemCode: boqDetail.code,
          quantity: boqDetail.quantity,
          planFrom: boq.planFrom,
          planTo: boq.planTo,
          bomId: boms[boqDetail.id],
        }),
      );

      if (isUpdate) {
        await queryRunner.manager.delete(BoqDetail, {
          boqId: boq.id,
        });
      }
      boq.boqDetails = await queryRunner.manager.save(boqDetailEntities);

      await queryRunner.commitTransaction();
      response = plainToInstance(BoqResponseDto, boq, {
        excludeExtraneousValues: true,
      });
    } catch (error) {
      await queryRunner.rollbackTransaction();
      code = ResponseCodeEnum.INTERNAL_SERVER_ERROR;
      message = error;
    }

    await queryRunner.release();
    return new ResponseBuilder()
      .withCode(code)
      .withData(response)
      .withMessage(
        code === ResponseCodeEnum.SUCCESS
          ? await this.i18n.translate('error.SUCCESS')
          : message,
      )
      .build();
  }

  private async getBoqExtraInfo(
    itemIds: number[],
    userIds: number[],
  ): Promise<any> {
    const data = await Promise.all([
      this.itemService.getItemsByIds(itemIds),
      this.userService.getUserByIds(userIds),
    ]);
    const items = data[0];
    const users = data[1];
    const normalizeItems = {};
    const normalizeUsers = {};

    items.forEach((item) => {
      normalizeItems[item.id] = item;
    });
    users.forEach((user) => {
      normalizeUsers[user.id] = user;
    });

    return { normalizeUsers, normalizeItems };
  }

  /**
   *
   * @param boqEntity
   * @param status
   * @returns
   */
  private async updateBoqStatus(boqEntity: Boq, status: number): Promise<any> {
    boqEntity.status = status;
    await this.boqRepository.update(boqEntity);

    const response = plainToInstance(BoqResponseDto, boqEntity, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  public async getItemBoqList(payload: GetItemBoqListRequestDto): Promise<any> {
    const { id, onlyInProgressItem } = payload;
    let data;

    const boq = await this.boqRepository.findOneById(id);
    if (!boq) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const boqItems =
      onlyInProgressItem === '1'
        ? await this.boqDetailRepository.getInProgressBoqItem(id)
        : await this.boqDetailRepository.findWithRelations({
            where: {
              boqId: id,
            },
          });
    if (!isEmpty(boqItems)) {
      const itemIds = uniq(map(boqItems, 'itemId'));
      const bomIds = uniq(map(boqItems, 'bomId'));
      const producingSteps = await this.moPlanBomRepository.getItemBom(
        id,
        bomIds,
      );
      const items = await this.itemService.getItemsByIds(itemIds, true);
      data = boqItems.map((boqItem) => {
        const p = find(producingSteps, (ps) => ps.itemId === boqItem.itemId);
        return {
          ...boqItem,
          producingSteps: p?.producingSteps || [],
          item: items[boqItem.itemId],
        };
      });
    } else {
      data = boqItems;
    }

    const response = plainToInstance(BoqItemResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  public async getPlanItemBoqList(
    payload: GetItemBoqListRequestDto,
  ): Promise<any> {
    const { id } = payload;
    let data;

    const boq = await this.boqRepository.findOneById(id);
    if (!boq) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const boqPlans = await this.moPlanRepository.getMoItemList(id);
    if (!isEmpty(boqPlans)) {
      const itemIds = [];
      const bomIds = [];
      boqPlans.forEach((boqPlan) => {
        itemIds.push(...map(boqPlan.boqPlanBoms, 'itemId'));
        bomIds.push(...map(boqPlan.boqPlanBoms, 'bomId'));
      });
      const producingSteps = await this.moPlanBomRepository.getItemBom(
        id,
        bomIds,
      );
      const items = await this.itemService.getItemsByIds(itemIds, true);
      data = boqPlans.map((boqPlan) => {
        return {
          ...boqPlan,
          boqPlanBoms: boqPlan.boqPlanBoms.map((bpb) => {
            const p = find(producingSteps, (ps) => ps.itemId === bpb.itemId);
            return {
              ...bpb,
              producingSteps: p?.producingSteps || [],
              item: items[bpb.itemId],
            };
          }),
        };
      });
    } else {
      data = boqPlans;
    }
    const response = plainToInstance(BoqPlanItemResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  public async getItemBoqDetail(
    payload: GetItemBoqDetailRequestDto,
  ): Promise<any> {
    const { id, itemBoqId, planId } = payload;

    const itemBoq = await this.boqDetailRepository.findOneWithRelations({
      where: {
        boqId: id,
        id: itemBoqId,
      },
    });
    if (!itemBoq) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const childBoqItems = await this.moPlanBomRepository.getChildBom(
      itemBoq.id,
      id,
      itemBoq.bomId,
      planId,
    );

    const parentItem = await this.boqDetailRepository.findOneByCondition({
      boqId: id,
      itemId: itemBoq.itemId,
    });

    const producingSteps = await this.moPlanBomRepository.getItemBom(
      id,
      [parentItem.bomId],
      planId,
    );
    const itemIds = uniq([...map(childBoqItems, 'itemId'), itemBoq.itemId]);
    const items = await this.itemService.getItemsByIds(itemIds, true);

    const p = find(producingSteps, (ps) => ps.bomId === parentItem.bomId);

    const data = [
      {
        ...parentItem,
        isParent: true,
        producingSteps: orderBy(p?.producingSteps, 'number') || [],
        item: items[itemBoq.itemId],
      },
    ].concat(
      childBoqItems.map((boqItem) => ({
        ...boqItem,
        producingSteps: orderBy(boqItem?.producingSteps, 'number'),
        isParent: false,
        item: items[boqItem.itemId],
      })),
    );

    const response = plainToInstance(BoqItemDetailResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .withData(response)
      .build();
  }

  public async getInProgressBoqList(): Promise<any> {
    const data = await this.boqRepository.getInProgressBoqWithPlan(true);

    const response = plainToInstance(BoqResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getBomItemBoqRouting(
    payload: GetBomItemBoqRoutingRequestDto,
  ): Promise<any> {
    const { id, itemId } = payload;
    const boq = await this.boqRepository.findOneById(id);
    if (!boq) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const data = await this.boqRepository.getBomItemBoqRouting(boq.id, itemId);

    const response = plainToInstance(BoqBomRoutingResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getListBoqByCodes(
    codes: string[],
  ): Promise<ResponsePayload<any>> {
    const boqs = await this.boqRepository.findByCondition({
      code: In(codes),
    });
    const response = plainToInstance(BoqResponseDto, boqs, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }
}
