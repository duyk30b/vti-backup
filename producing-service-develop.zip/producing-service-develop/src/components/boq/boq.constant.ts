export enum BoqStatusEnum {
  PENDING = 0,
  CONFIRMED = 1,
  REJECTED = 2,
  IN_PROGRESS = 3,
  COMPLETED = 4,
}

export const STATUS_TO_UPDATE_BOQ: number[] = [
  BoqStatusEnum.PENDING,
  BoqStatusEnum.REJECTED,
];

export const STATUS_TO_CONFIRM_BOQ_STATUS: number[] = [
  BoqStatusEnum.PENDING,
  BoqStatusEnum.REJECTED,
];

export const STATUS_TO_REJECT_BOQ_STATUS: number[] = [BoqStatusEnum.PENDING];

export const STATUS_TO_COMPLETE_BOQ_STATUS: number[] = [
  BoqStatusEnum.IN_PROGRESS,
];

export const STATUS_TO_DELETE_BOQ_STATUS: number[] = [
  BoqStatusEnum.PENDING,
  BoqStatusEnum.REJECTED,
];
