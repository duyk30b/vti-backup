import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { Boq } from '@entities/boq/boqs.entity';
import { GetBoqListRequestDto } from '../dto/request/get-boq-list.request.dto';

export interface BoqRepositoryInterface extends BaseInterfaceRepository<Boq> {
  createEntity(data: any): Boq;
  getDetail(id: number): Promise<any>;
  getTotalInProgressBoqs(): Promise<any>;
  countToDoBoq(createdFrom: Date, createdTo: Date): Promise<any>;
  countCompletedBoq(createdFrom: Date, createdTo: Date): Promise<any>;
  countLateBoq(createdFrom: Date, createdTo: Date): Promise<any>;
  countInProgressBoq(createdFrom?: Date, createdTo?: Date): Promise<any>;
  getStatusSummary(boqId: number): Promise<any>;
  getList(request: GetBoqListRequestDto, pmIds?: number[]): Promise<any>;
  getInProgressBoqWithPlan(
    onlyRootItem: boolean,
    withWorkOrder?: boolean,
    boqId?: number,
    itemId?: number,
    routingId?: number,
    routingVersionId?: number,
    producingStepId?: number,
  ): Promise<any>;
  getInProgressBoqWithPlanByTime(
    createdFrom: Date,
    createdTo: Date,
  ): Promise<any>;
  getBomItemBoqRouting(boqId: number, itemId: number): Promise<any>;
  delete(id: number): Promise<any>;
  updateEntity(boqEntity: Boq, data: any): Boq;
  getListBoqByIds(ids: number[]): Promise<any>;
  getCount(): Promise<any>;
}
