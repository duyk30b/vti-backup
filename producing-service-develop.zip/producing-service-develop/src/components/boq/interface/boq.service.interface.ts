import { GetItemBoqDetailRequestDto } from './../dto/request/get-item-boq-detail-request.dto';
import { CreateBoqRequestDto } from '../dto/request/create-boq-request.dto';
import { DeleteBoqRequestDto } from '../dto/request/delete-boq.request.dto';
import { GetBoqDetailRequestDto } from '../dto/request/get-boq-detail.request.dto';
import { GetBoqListRequestDto } from '../dto/request/get-boq-list.request.dto';
import { GetItemBoqListRequestDto } from '../dto/request/get-item-boq-list-request.dto';
import { UpdateBoqRequestDto } from '../dto/request/update-boq-request.dto';
import { UpdateBoqStatusRequestDto } from '../dto/request/update-boq-status-request.dto';
import { GetBomItemBoqRoutingRequestDto } from '../dto/request/get-bom-item-boq-routing-request.dto';
import { ResponsePayload } from '@utils/response-payload';

export interface BoqServiceInterface {
  create(payload: CreateBoqRequestDto): Promise<any>;
  update(payload: UpdateBoqRequestDto): Promise<any>;
  delete(payload: DeleteBoqRequestDto): Promise<any>;
  getDetail(payload: GetBoqDetailRequestDto): Promise<any>;
  getAllItem(payload: GetBoqDetailRequestDto): Promise<any>;
  getItemBoqDetail(payload: GetItemBoqDetailRequestDto): Promise<any>;
  getBomItemBoqRouting(payload: GetBomItemBoqRoutingRequestDto): Promise<any>;
  getList(payload: GetBoqListRequestDto): Promise<any>;
  getInProgressBoqList(): Promise<any>;
  getItemBoqList(payload: GetItemBoqListRequestDto): Promise<any>;
  getPlanItemBoqList(payload: GetItemBoqListRequestDto): Promise<any>;
  reject(payload: UpdateBoqStatusRequestDto): Promise<any>;
  confirm(payload: UpdateBoqStatusRequestDto): Promise<any>;
  complete(payload: UpdateBoqStatusRequestDto): Promise<any>;
  getListBoqByIds(ids: number[]): Promise<any>;
  getListBoqByCodes(codes: string[]): Promise<ResponsePayload<any>>;
}
