import { BaseInterfaceRepository } from '@core/repositories/base.interface.repository';
import { BoqDetail } from '@entities/boq/boq-details.entity';

export interface BoqDetailRepositoryInterface
  extends BaseInterfaceRepository<BoqDetail> {
  createEntity(data: any): BoqDetail;
  getAllBomAndRoutingVersionIdByBoqId(boqId: number): Promise<any[]>;
  getTotalInProgressFinishedItems(boqIds?: number[]): Promise<any>;
  getItemList(boqId: number): Promise<any[]>;
  getInProgressBoqItem(
    boqId: number,
    onlyInProgressItem?: boolean,
    groupByPlan?: boolean,
  ): Promise<any[]>;
  getItemListByItemIds(itemIds: number[], boqId: number): Promise<any[]>;

  updatePlaningQuantity(boqId: number, planStatus: number[]): Promise<any>;

  getAllByBoqId(boqId: number): Promise<any[]>;
}
