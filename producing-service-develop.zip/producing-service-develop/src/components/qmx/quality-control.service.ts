import { NATS_QMSX } from '@config/nats.config';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { QualityControlServiceInterface } from './interface/quality-control.service.interface';

@Injectable()
export class QualityControlService implements QualityControlServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}

  async getQuanlityPointById(id: number): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_QMSX}.detail_quality_point`,
      {
        id: id,
      },
    );
    return response.data;
  }

  async getMoQcPlan(moId: number): Promise<any> {
    try {
      const response: any = await this.natsClientService.send(
        `${NATS_QMSX}.quality_plan_detail_by_mo_id`,
        moId,
      );
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) return null;

      return response.data;
    } catch {
      return null;
    }
  }

  async getWorkCenterQcPlan(
    workCenterId: number,
    workOrderId: number,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_QMSX}.get_work_center_plan_qc_shift_by_wo_id_and_wc_id`,
      {
        workCenterId: workCenterId,
        workOrderId: workOrderId,
      },
    );
    return response.data;
  }

  async getErrorReportByWorkOrderId(workOrderId: number): Promise<any> {
    const request = {
      workOrderId,
    };
    const response = await this.natsClientService.send(
      `${NATS_QMSX}.get_error_report_detail_by_work_order`,
      request,
    );
    return response.data;
  }

  async getQuanlityPlanBoms(request: any): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_QMSX}.quality_plan_bom_list`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return null;
    }
    return response.data;
  }

  async getQuanlityPlanBomsByWorkOrderId(workOrderId: number): Promise<any> {
    const request = {
      filter: [
        {
          column: 'workOrderId',
          text: workOrderId.toString(),
        },
      ],
    };
    const data = await this.getQuanlityPlanBoms(request);
    return data?.items?.find((e) => e?.workOrderId === workOrderId);
  }

  async getQualityPointsByIds(ids: number[]): Promise<any> {
    try {
      const response = await this.natsClientService.send(
        `${NATS_QMSX}.quality_points_by_ids`,
        { ids },
      );
      return response.data;
    } catch {
      return [];
    }
  }

  async createActualQuantityProduceStepsImportHistory(
    request: any,
  ): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_QMSX}.create_actual_quantity_produce_steps_import_history`,
      request,
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return null;
    }
    return response.data;
  }
}
