import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ClientProxyFactory } from '@nestjs/microservices';
import { ConfigService } from '@config/config.service';
import { QualityControlService } from './quality-control.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    'QMX_SERVICE_CLIENT',
    {
      provide: 'QualityControlServiceInterface',
      useClass: QualityControlService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'QMX_SERVICE_CLIENT',
      useFactory: (configService: ConfigService) => {
        const qmxServiceOptions = configService.get('qmxService');
        return ClientProxyFactory.create(qmxServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'QualityControlServiceInterface',
      useClass: QualityControlService,
    },
  ],
  controllers: [],
})
export class QmxModule {}
