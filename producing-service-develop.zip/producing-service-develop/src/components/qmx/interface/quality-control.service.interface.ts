export interface QualityControlServiceInterface {
  getQuanlityPointById(id: number): Promise<any>;
  getWorkCenterQcPlan(workCenterId: number, workOrderId: number): Promise<any>;
  getQuanlityPlanBoms(request: any): Promise<any>;
  getQuanlityPlanBomsByWorkOrderId(workOrderId: number): Promise<any>;
  getMoQcPlan(moId: number): Promise<any>;
  createActualQuantityProduceStepsImportHistory(request: any): Promise<any>;
  getQualityPointsByIds(ids: number[]): Promise<any>;
}
