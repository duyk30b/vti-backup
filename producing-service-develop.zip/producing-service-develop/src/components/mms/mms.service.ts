import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { Injectable } from '@nestjs/common';
import { GetDeviceByWorkCenterId } from './dto/request/get-device-by-work-center-id.request.dto';
import { MmsServiceInterface } from './interface/mms.service.interface';

@Injectable()
export class MmsService implements MmsServiceInterface {
  constructor(private readonly natsClientService: NatsClientService) {}
  async getDeviceByWorkCenterId(
    payload: GetDeviceByWorkCenterId,
  ): Promise<any> {
    const res: any = await this.natsClientService.send(
      'get_device_assignment_by_work_center_id',
      payload,
    );
    if (res.statusCode !== ResponseCodeEnum.SUCCESS) {
      return null;
    }
    return res.data;
  }
}
