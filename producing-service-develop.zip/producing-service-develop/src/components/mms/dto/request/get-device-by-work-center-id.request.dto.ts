import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class GetDeviceByWorkCenterId {
  @ApiProperty()
  @IsInt()
  @IsNotEmpty()
  workCenterId: number;
}
