import { GetDeviceByWorkCenterId } from '../dto/request/get-device-by-work-center-id.request.dto';

export interface MmsServiceInterface {
  getDeviceByWorkCenterId(workCenterId: GetDeviceByWorkCenterId): Promise<any>;
}
