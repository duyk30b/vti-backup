import { QualityControlModule } from './components/quality-control/quality-control.module';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { CoreModule } from './core/core.module';
import { I18nJsonLoader, I18nModule } from 'nestjs-i18n';
import * as path from 'path';
import { APP_GUARD, APP_PIPE } from '@nestjs/core';
import { ValidationPipe } from '@core/pipe/validation.pipe';
import { PlanModule } from '@components/plan/plan.module';
import { ProducingStepModule } from '@components/producing-step/producing-step.module';
import { BoqModule } from '@components/boq/boq.module';
import { RoutingModule } from '@components/routing/routing.module';
import { UserModule } from '@components/user/user.module';
import { BomModule } from '@components/bom/bom.module';
import { WorkOrderModule } from '@components/work-order/work-order.module';
import { DashboardModule } from '@components/dashboard/dashboard.module';
import { WorkCenterModule } from '@components/work-center/work-center.module';
import { MaterialModule } from '@components/material/material.module';
import { QmxModule } from '@components/qmx/qmx.module';
import { ManufacturingOrderModule } from '@components/manufacturing-order/manufacturing-order.module';
import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { SaleModule } from '@components/sale-order/sale-order.module';
import { ReportModule } from '@components/report/report.module';
import { MaterialRequestWarningModule } from '@components/material-request-warning/material-request-warning.module';
import { AuthorizationGuard } from '@core/guards/authorization.guard';
import { ConfigService } from '@config/config.service';
import { ClientProxyFactory } from '@nestjs/microservices';
import { QueryResolver } from './i18n/query-resolver';
import { MasterPlanModule } from '@components/master-plan/master-plan.module';
import { HttpClientModule } from '@core/components/http-client/http-client.module';
import { InitDataModule } from '@components/init-data/init-data.module';
import { ExportModule } from '@components/export/export.module';
import { BootModule } from '@nestcloud/boot';
import { resolve } from 'path';
import { BOOT, CONSUL } from '@nestcloud/common';
import { ConsulModule } from '@nestcloud/consul';
import { ServiceModule } from '@nestcloud/service';
import { KongGatewayModule } from '@core/components/kong-gateway/kong-gateway.module';
import { AuthModule } from '@components/auth/auth.module';
import { SnakeNamingStrategy } from 'typeorm-naming-strategies';
import { ImportModule } from '@components/import/import.module';
import { isDevMode } from '@utils/helper';
import { KafkaProducerModule } from '@core/components/kafka-producer/kafka-producer.module';
import { DeviceModule } from '@components/device/device.module';
import { RequestModule } from '@components/request/request.module';
import { NatsClientModule } from '@core/transporter/nats-transporter/nats-client.module';
@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),

    I18nModule.forRoot({
      fallbackLanguage: 'vi',
      loader: I18nJsonLoader,
      loaderOptions: {
        path: path.join(__dirname, '/i18n/'),
        watch: true,
      },
      resolvers: [{ use: QueryResolver, options: ['lang', 'locale', 'l'] }],
    }),
    EventEmitterModule.forRoot(),
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: process.env.DATABASE_POSTGRES_HOST,
      port: parseInt(process.env.DATABASE_POSTGRES_PORT),
      username: process.env.DATABASE_POSTGRES_USERNAME,
      password: process.env.DATABASE_POSTGRES_PASSWORD,
      database: process.env.DATABASE_NAME,
      logging: isDevMode(),
      entities: [path.join(__dirname, '/entities/**/*.entity.{ts,js}')],
      migrations: [path.join(__dirname, '/database/migrations/*.{ts,js}')],
      subscribers: ['dist/observers/subscribers/*.subscriber.{ts,js}'],
      // We are using migrations, synchronize should be set to false.
      synchronize: false,
      // Run migrations automatically,
      // you can disable this if you prefer running migration manually.
      migrationsRun: !isDevMode(),
      extra: {
        max: parseInt(process.env.DATABASE_MAX_POOL) || 20,
      },
      namingStrategy: new SnakeNamingStrategy(),
    }),
    BootModule.forRoot({
      filePath: resolve(__dirname, '../config.yaml'),
    }),
    ConsulModule.forRootAsync({ inject: [BOOT] }),
    ServiceModule.forRootAsync({ inject: [BOOT, CONSUL] }),
    HttpClientModule,
    KongGatewayModule.forRootAsync(),
    CoreModule,
    // KafkaProducerModule,
    DeviceModule,
    AuthModule,
    PlanModule,
    ProducingStepModule,
    BoqModule,
    BomModule,
    RoutingModule,
    UserModule,
    WorkOrderModule,
    QualityControlModule,
    DashboardModule,
    WorkCenterModule,
    ManufacturingOrderModule,
    SaleModule,
    MaterialModule,
    QmxModule,
    ManufacturingOrderModule,
    WarehouseModule,
    ReportModule,
    MaterialRequestWarningModule,
    MasterPlanModule,
    HttpClientModule,
    InitDataModule,
    ExportModule,
    ImportModule,
    RequestModule,
    NatsClientModule,
  ],
  controllers: [AppController],
  providers: [
    {
      provide: APP_PIPE,
      useClass: ValidationPipe,
    },
    {
      provide: APP_GUARD,
      useClass: AuthorizationGuard,
    },
    ConfigService,
    {
      provide: 'USER_SERVICE',
      useFactory: (configService: ConfigService) => {
        const userServiceOptions = configService.get('userService');
        return ClientProxyFactory.create(userServiceOptions);
      },
      inject: [ConfigService],
    },
    AppService,
  ],
  exports: [],
})
export class AppModule {}
