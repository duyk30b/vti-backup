export class BaseDto {
  request: any;

  responseError: any;

  userId?: number;
  user?: any;
}
