import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addColumnToBoqTable1629872813147 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumns('boqs', [
      new TableColumn({
        name: 'apm_id',
        type: 'int',
        isNullable: true,
      }),
    ]);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropColumns('boqs', [
      new TableColumn({ name: 'apm_id', type: 'int' }),
    ]);
  }
}
