import { MigrationInterface, QueryRunner, Table } from 'typeorm';

export class createBoqDetailsTable1629796767223 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'boq_details',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'quantity',
            type: 'decimal',
            precision: 10,
            scale: 2,
            default: 0,
          },
          {
            name: 'boq_id',
            type: 'int',
          },
          {
            name: 'plan_from',
            type: 'timestamptz',
          },
          {
            name: 'plan_to',
            type: 'timestamptz',
          },
          {
            name: 'bom_id',
            type: 'int',
            unsigned: true,
            isNullable: true,
          },
          {
            name: 'item_id',
            type: 'int',
          },
          {
            name: 'item_code',
            type: 'varchar',
            length: '12',
            isNullable: true,
          },
          {
            name: 'actual_quantity',
            type: 'decimal',
            precision: 10,
            scale: 2,
            isNullable: true,
          },
          {
            name: 'created_at',
            type: 'timestamptz',
            default: 'now()',
          },
          {
            name: 'updated_at',
            type: 'timestamptz',
            default: 'now()',
          },
        ],
      }),
      true,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable('boq_details');
  }
}
