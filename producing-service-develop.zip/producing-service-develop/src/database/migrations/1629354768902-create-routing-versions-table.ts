import { MigrationInterface, QueryRunner, Table } from 'typeorm';

export class createRoutingVersionsTable1629354768902
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'routing_versions',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'name',
            type: 'varchar',
            length: '6',
            isUnique: true,
          },
          {
            name: 'routing_id',
            type: 'int',
          },
          {
            name: 'status',
            default: 0,
            type: 'int',
          },
          {
            name: 'approver_id',
            type: 'int',
            isNullable: true,
          },
          {
            name: 'approved_at',
            type: 'timestamptz',
            isNullable: true,
          },
          {
            name: 'created_at',
            type: 'timestamptz',
            default: 'now()',
          },
          {
            name: 'updated_at',
            type: 'timestamptz',
            default: 'now()',
          },
        ],
      }),
      true,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable('routing_versions');
  }
}
