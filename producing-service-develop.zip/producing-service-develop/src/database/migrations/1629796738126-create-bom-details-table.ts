import { MigrationInterface, QueryRunner, Table } from 'typeorm';

export class createBomDetailsTable1629796738126 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'bom_details',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'bom_id',
            type: 'int',
            unsigned: true,
            isPrimary: true,
          },
          {
            name: 'item_id',
            type: 'int',
            isPrimary: true,
          },
          {
            name: 'quantity',
            type: 'decimal',
            isNullable: true,
            precision: 10,
            scale: 2,
          },
          {
            name: 'item_code',
            type: 'varchar',
            isNullable: true,
            length: '12',
          },
          {
            name: 'created_at',
            type: 'timestamptz',
            default: 'now()',
          },
          {
            name: 'updated_at',
            type: 'timestamptz',
            default: 'now()',
          },
        ],
      }),
      true,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable('bom_details');
  }
}
