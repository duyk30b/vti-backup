import { MigrationInterface, QueryRunner, Table } from 'typeorm';

export class createBoqsTable1629781560265 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'boqs',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'name',
            type: 'varchar',
            length: '255',
          },
          {
            name: 'code',
            type: 'varchar',
            isUnique: true,
            length: '12',
          },
          {
            name: 'pm_id',
            type: 'int',
            isNullable: false,
          },
          {
            name: 'plan_from',
            type: 'timestamptz',
            default: 'now()',
          },
          {
            name: 'plan_to',
            type: 'timestamptz',
          },
          {
            name: 'description',
            type: 'varchar',
            isNullable: true,
            length: '255',
          },
          {
            name: 'status',
            type: 'int',
            default: 0,
          },
          {
            name: 'created_at',
            type: 'timestamptz',
            default: 'now()',
          },
          {
            name: 'updated_at',
            type: 'timestamptz',
            default: 'now()',
          },
          {
            name: 'created_by_user_id',
            type: 'int',
          },
          {
            name: 'approved_at',
            type: 'timestamptz',
            isNullable: true,
          },
        ],
      }),
      true,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable('boqs');
  }
}
