import { MigrationInterface, QueryRunner, TableColumn } from 'typeorm';

export class addColumnDescriptionRoutingsTable1629959101862
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.addColumn(
      'routings',
      new TableColumn({
        name: 'description',
        type: 'varchar',
        length: '255',
        isNullable: true,
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE routings drop column description`);
  }
}
