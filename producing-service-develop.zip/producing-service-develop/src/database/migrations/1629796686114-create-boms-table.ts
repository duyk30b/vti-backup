import { MigrationInterface, QueryRunner, Table } from 'typeorm';

export class createBomsTable1629796686114 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'boms',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'name',
            type: 'varchar',
            length: '255',
          },
          {
            name: 'code',
            type: 'varchar',
            isUnique: true,
            length: '20',
          },
          {
            name: 'description',
            type: 'varchar',
            isNullable: true,
            length: '255',
          },
          {
            name: 'parent_id',
            type: 'int',
            isNullable: true,
          },
          {
            name: 'quantity',
            type: 'decimal',
            isNullable: true,
            precision: 10,
            scale: 2,
          },
          {
            name: 'status',
            type: 'int',
            default: 0,
          },
          {
            name: 'routing_id',
            type: 'int',
          },
          {
            name: 'item_id',
            type: 'int',
          },
          {
            name: 'item_code',
            type: 'varchar',
            length: '255',
          },
          {
            name: 'created_at',
            type: 'timestamptz',
            default: 'now()',
          },
          {
            name: 'updated_at',
            type: 'timestamptz',
            default: 'now()',
          },
        ],
      }),
      true,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable('boms');
  }
}
