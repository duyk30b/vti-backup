import { MigrationInterface, QueryRunner, Table } from 'typeorm';

export class createRoutingsTable1629354768901 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'routings',
        columns: [
          {
            name: 'id',
            type: 'int',
            isPrimary: true,
            isGenerated: true,
            generationStrategy: 'increment',
          },
          {
            name: 'name',
            type: 'varchar',
            length: '255',
            isUnique: true,
          },
          {
            name: 'code',
            type: 'varchar',
            length: '4',
            isUnique: true,
          },
          {
            name: 'latest_version',
            type: 'varchar',
            length: '6',
            isNullable: true,
          },
          {
            name: 'status',
            default: 0,
            type: 'int',
          },
          {
            name: 'approver_id',
            type: 'int',
            isNullable: true,
          },
          {
            name: 'approved_at',
            type: 'timestamptz',
            isNullable: true,
          },
          {
            name: 'created_at',
            type: 'timestamptz',
            default: 'now()',
          },
          {
            name: 'updated_at',
            type: 'timestamptz',
            default: 'now()',
          },
        ],
      }),
      true,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropTable('routings');
  }
}
