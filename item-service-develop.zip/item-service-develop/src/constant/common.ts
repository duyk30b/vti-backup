import { ConfigService } from './../config/config.service';
export enum APIPrefix {
  Version = 'api/v1',
}

export enum OrderTypeEnum {
  Import = 0,
  Export = 1,
}

export const DEFAULT_ITEM_TYPES = {
  MATERIAL: {
    id: 1,
    code: '00',
    name: 'Nguyên vật liệu',
  },
  PRODUCT: {
    id: 2,
    code: '01',
    name: 'Thành phẩm',
  },
  SEMI_PRODUCT: {
    id: 3,
    code: '02',
    name: 'Bán thành phẩm',
  },
  DEVICE: {
    id: 4,
    code: '04',
    name: 'Devices',
  },
  SUPPLY: {
    id: 5,
    code: '05',
    name: 'Supplies',
  },
  ACCESSORY: {
    id: 6,
    code: '06',
    name: 'Accessories',
  },
};

export const DEFAULT_ITEM_GROUP = {
  MMS: {
    code: 'MMS',
    name: 'Mms group',
  },
};

export const DEFAULT_ITEM_UNIT = {
  CA: {
    code: 'CA',
    name: 'Cái',
  },
};

export const DATA_NOT_CHANGE = {
  ITEM_TYPE_SETTINGS: {
    code: ['00', '01', '02', '04', '05', '06'],
  },
  ITEM_UNIT: {
    code: ['CA'],
  },
  ITEM_GROUP: {
    code: ['MMS', '001'],
  },
};
export const DATA_ITEM_CAN_NOT_UPDATE_AND_DELETE = {
  ITEMS: {
    code: ['04', '05', '06'],
  },
};

//permission
export enum StatusPermission {
  ACTIVE = 1,
  INACTIVE = 0,
}

export const FORMAT_CODE_PERMISSION = 'ITEM_';

export enum ChannelSocketItemEnum {
  PRINT_QR = 'print_item_qr_code',
}

export enum QUEUES_NAME_ENUM {
  SYNC_DATA_QUEUE = 'ITEM_SYNC_DATA_QUEUE',
  CALCULATE_ITEM_PRICE_EBS = 'CALCULATE_ITEM_PRICE_EBS',
}

export const MIME_TYPES = {
  PDF: ['application/pdf'],
  IMAGE: ['png', 'jpg', 'jpeg', 'apng'],
};

export const COMPANY_DEFAULT = new ConfigService().get('companyDefault')
  ?.options?.code;

export const DOT_SEPARATOR = '.';
export const DASH_SEPARATOR = ' - ';
