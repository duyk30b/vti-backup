import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { WarehouseService } from '@components/warehouse/warehouse.service';
import { ItemStockWarehouseLocatorEntity } from '@entities/item/item-stock-warehouse-locator.entity';
import { SuspendItemEntity } from '@entities/suspend-item/suspend-item.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ItemStockWarehouseLocatorRepository } from '@repositories/item-stock-warehouse-locator.repository';
import { SuspendItemRepository } from '@repositories/suspend-item.repository';
import { SuspendItemController } from './suspend-item.controller';
import { SuspendItemService } from './suspend-item.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      SuspendItemEntity,
      ItemStockWarehouseLocatorEntity,
    ]),
    WarehouseModule,
  ],
  exports: [],
  providers: [
    {
      provide: 'SuspendItemRepositoryInterface',
      useClass: SuspendItemRepository,
    },
    {
      provide: 'ItemStockWarehouseLocatorRepositoryInterface',
      useClass: ItemStockWarehouseLocatorRepository,
    },
    {
      provide: 'SuspendItemServiceInterface',
      useClass: SuspendItemService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
  ],
  controllers: [SuspendItemController],
})
export class SuspendItemModule {}
