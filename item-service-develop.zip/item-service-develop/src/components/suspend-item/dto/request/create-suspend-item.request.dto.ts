import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { decimal } from '@utils/common';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Length,
  Max,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';

export class SuspendItemDetailDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  @Max(decimal(10, 2))
  quantity: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @Length(10)
  lotNumber: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  mfg: Date;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  packageId: number;
}

export class CreateSuspendItemRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsOptional()
  @MaxLength(255)
  description: string;

  @ApiProperty({
    type: SuspendItemDetailDto,
    isArray: true,
  })
  @ArrayNotEmpty()
  @ValidateNested()
  @ArrayUnique(
    (e: SuspendItemDetailDto) => `${e.itemId}_${e.warehouseId}_${e.lotNumber}`,
  )
  @Type(() => SuspendItemDetailDto)
  items: SuspendItemDetailDto[];
}
