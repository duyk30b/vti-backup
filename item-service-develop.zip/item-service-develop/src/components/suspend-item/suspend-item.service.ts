import { PagingResponse } from '@utils/paging.response';
import { plainToInstance } from 'class-transformer';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Injectable, Inject } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { DataSource } from 'typeorm';
import { first, isEmpty, map, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { SuspendItemServiceInterface } from './interface/suspend-item.service.interface';
import { SuspendItemRepositoryInterface } from './interface/suspend-item.repository.interface';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { CreateSuspendItemRequestDto } from './dto/request/create-suspend-item.request.dto';
import { GetListSuspendItemRequestDto } from './dto/request/get-list-suspend-item.request.dto';
import { GetListSuspendItemResponseDto } from './dto/response/get-list-suspend-item.response.dto';
import {
  SuspendItemResponse,
  SuspendItemResponseDto,
} from './dto/response/suspend-item.response.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { SuspendItemStatusEnum } from './suspend-item.constant';
import { convertArrayToMap } from '@utils/common';
import { ItemStockWarehouseLocatorRepositoryInterface } from '@components/item/interface/item-stock-warehouse-locator.repository.interface';

@Injectable()
export class SuspendItemService implements SuspendItemServiceInterface {
  constructor(
    @Inject('SuspendItemRepositoryInterface')
    private readonly suspendItemRepository: SuspendItemRepositoryInterface,

    @Inject('ItemStockWarehouseLocatorRepositoryInterface')
    private readonly itemStockMovementWarehouseShelfFloorRepository: ItemStockWarehouseLocatorRepositoryInterface,

    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,

    private readonly i18n: I18nRequestScopeService,

    @InjectDataSource()
    private readonly connection: DataSource,
  ) {}

  async createSuspendItem(
    request: CreateSuspendItemRequestDto,
  ): Promise<ResponsePayload<any | SuspendItemResponseDto>> {
    const { items } = request;

    const queryCondition = items.map((record) => ({
      itemId: record.itemId,
      warehouseId: record.warehouseId,
      lotNumber: record.lotNumber,
    }));

    const suspendItemExist = await this.suspendItemRepository.findByCondition(
      queryCondition,
    );

    if (!isEmpty(suspendItemExist)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.SUSPEND_ITEM_ALREADY_EXIST_FOR_THIS_ITEM',
          ),
        )
        .build();
    }

    const itemStockMovementWarehouses =
      await this.itemStockMovementWarehouseShelfFloorRepository.getTotalQuantityItemStockMovementByCondition(
        queryCondition,
      );

    if (itemStockMovementWarehouses.length !== items.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ITEM_NOT_EXIST_IN_STOCK'))
        .build();
    }

    const itemsRequestMap = convertArrayToMap(items, [
      'itemId',
      'warehouseId',
      'lotNumber',
    ]);

    let checkOverLoadQuantity = false;

    for (let i = 0; i < itemStockMovementWarehouses.length; i++) {
      const key =
        '_' +
        itemStockMovementWarehouses[i].itemId +
        '_' +
        itemStockMovementWarehouses[i].warehouseId +
        '_' +
        itemStockMovementWarehouses[i].lotNumber;
      const itemQuantityRequest = itemsRequestMap[key].quantity;
      if (itemQuantityRequest > itemStockMovementWarehouses[i].quantity) {
        checkOverLoadQuantity = true;
        break;
      }
    }

    if (checkOverLoadQuantity) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.QUANTITY_REQUEST_EXCEED_STOCK_QUANTITY',
          ),
        )
        .build();
    }

    const suspendItemEntities = await this.suspendItemRepository.createEntities(
      request,
    );
    try {
      const result = await this.suspendItemRepository.create(
        suspendItemEntities,
      );
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  async getDetail(
    id: number,
  ): Promise<ResponsePayload<any | SuspendItemResponseDto>> {
    const suspendItem = await this.suspendItemRepository.getSuspendItem(id);
    if (!suspendItem) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.SUSPEND_ITEM_NOT_FOUND'),
      ).toResponse();
    }

    const warehouses = await this.warehouseService.getListByIDs([
      suspendItem.warehouseId,
    ]);

    const data = {
      ...suspendItem,
      warehouse: first(warehouses),
    };

    const response = plainToInstance(SuspendItemResponse, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(
    request: GetListSuspendItemRequestDto,
  ): Promise<ResponsePayload<any | GetListSuspendItemResponseDto>> {
    const { filter } = request;
    const filterWarehouseName = filter?.filter(
      (record) => record.column === 'warehouseName',
    );

    const warehouseIdsFilter = !isEmpty(filterWarehouseName)
      ? await this.warehouseService.getWarehouseByNameKeyword(
          first(filterWarehouseName),
          true,
        )
      : [];

    if (!isEmpty(filterWarehouseName) && isEmpty(warehouseIdsFilter)) {
      return new ResponseBuilder<PagingResponse>({
        items: [],
        meta: { total: 0, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    const { data, count } = await this.suspendItemRepository.getSuspendItems(
      request,
      warehouseIdsFilter,
    );

    const warehouseIds = uniq(map(data, 'warehouseId'));
    const warehouses = await this.warehouseService.getListByIDs(
      warehouseIds,
      true,
    );

    const suspendItems = data.map((record) => ({
      ...record,
      warehouse: warehouses[record.warehouseId],
    }));
    const dataReturn = plainToInstance(SuspendItemResponse, suspendItems, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async deleteSuspendItem(
    id: number,
  ): Promise<ResponsePayload<any | SuccessResponse>> {
    try {
      await this.suspendItemRepository.remove(id);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  async openSuspendItem(
    id: number,
  ): Promise<ResponsePayload<any | SuspendItemResponseDto>> {
    const suspendItem = await this.suspendItemRepository.findOneById(id);
    if (!suspendItem) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.SUSPEND_ITEM_NOT_FOUND'),
      ).toResponse();
    }
    suspendItem.status = SuspendItemStatusEnum.Open;

    try {
      const result = await this.suspendItemRepository.create(suspendItem);
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  async closeSuspendItem(
    id: number,
  ): Promise<ResponsePayload<any | SuspendItemResponseDto>> {
    const suspendItem = await this.suspendItemRepository.findOneById(id);
    if (!suspendItem) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.SUSPEND_ITEM_NOT_FOUND'),
      ).toResponse();
    }
    suspendItem.status = SuspendItemStatusEnum.Close;

    try {
      const result = await this.suspendItemRepository.create(suspendItem);
      return new ResponseBuilder(result)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }
}
