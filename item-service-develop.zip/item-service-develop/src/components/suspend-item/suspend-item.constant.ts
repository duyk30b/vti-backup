export enum SuspendItemStatusEnum {
  Open = 0,
  Close = 1,
}
