import { SuspendItemServiceInterface } from './interface/suspend-item.service.interface';
import {
  Controller,
  Inject,
  Body,
  Post,
  Delete,
  Get,
  Put,
  Query,
  Param,
  ParseIntPipe,
  Req,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { isEmpty } from 'lodash';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { SuspendItemResponseDto } from './dto/response/suspend-item.response.dto';
import { CreateSuspendItemRequestDto } from './dto/request/create-suspend-item.request.dto';
import {
  ChangeStatusRequestDto,
  DeleteRequestDto,
  DetailParamDto,
  DetailRequestDto,
} from '@utils/common.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { GetListSuspendItemResponseDto } from './dto/response/get-list-suspend-item.response.dto';
import { GetListSuspendItemRequestDto } from './dto/request/get-list-suspend-item.request.dto';
import {
  CHANGE_STATUS_SUSPEND_ITEM_LOCATION_PERMISSION,
  CREATE_SUSPEND_ITEM_LOCATION_PERMISSION,
  DELETE_SUSPEND_ITEM_LOCATION_PERMISSION,
  DETAIL_SUSPEND_ITEM_LOCATION_PERMISSION,
  LIST_SUSPEND_ITEM_LOCATION_PERMISSION,
} from '@utils/permissions/suspend-item';
import { NATS_ITEM } from '@config/nats.config';

@Controller('suspends')
export class SuspendItemController {
  constructor(
    @Inject('SuspendItemServiceInterface')
    private readonly suspendItemService: SuspendItemServiceInterface,
  ) {}

  @PermissionCode(CREATE_SUSPEND_ITEM_LOCATION_PERMISSION.code)
  @Post('/create')
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: SuspendItemResponseDto,
  })
  @MessagePattern(`${NATS_ITEM}.create_suspend_item`)
  public async createSuspendItem(
    @Body() body: CreateSuspendItemRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.suspendItemService.createSuspendItem(request);
  }

  @PermissionCode(DELETE_SUSPEND_ITEM_LOCATION_PERMISSION.code)
  @Delete('/:id')
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  @MessagePattern(`${NATS_ITEM}.delete_suspend_item`)
  public async deleteSuspendItem(
    @Param('id', new ParseIntPipe()) id,
    @Req() body: DeleteRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.suspendItemService.deleteSuspendItem({ id, ...request });
  }

  @PermissionCode(DETAIL_SUSPEND_ITEM_LOCATION_PERMISSION.code)
  @Get('/:id')
  @ApiResponse({
    status: 200,
    description: 'Detail successfully',
    type: SuspendItemResponseDto,
  })
  @MessagePattern(`${NATS_ITEM}.detail_suspend_item`)
  public async getSuspendItem(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<any> {
    return await this.suspendItemService.getDetail(id);
  }

  @PermissionCode(LIST_SUSPEND_ITEM_LOCATION_PERMISSION.code)
  @Get('/list')
  @ApiResponse({
    status: 200,
    description: 'List successfully',
    type: GetListSuspendItemResponseDto,
  })
  @MessagePattern(`${NATS_ITEM}.list_suspend_item`)
  public async getSuspendItems(
    @Query() body: GetListSuspendItemRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.suspendItemService.getList(request);
  }

  @PermissionCode(CHANGE_STATUS_SUSPEND_ITEM_LOCATION_PERMISSION.code)
  @MessagePattern(`${NATS_ITEM}.open_suspend_item`)
  @Put('/:id/open')
  @ApiOperation({
    tags: ['Items'],
    summary: 'open suspend item',
    description: 'mở khóa sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Open successfully',
    type: SuspendItemResponseDto,
  })
  public async openSuspendItem(
    @Param('id', new ParseIntPipe()) id,
    @Req() body: ChangeStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.suspendItemService.openSuspendItem({
      id,
      ...request,
    });
  }

  @PermissionCode(CHANGE_STATUS_SUSPEND_ITEM_LOCATION_PERMISSION.code)
  @Put('/:id/close')
  @ApiOperation({
    tags: ['Items'],
    summary: 'close suspend item',
    description: 'khóa sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Close successfully',
    type: SuspendItemResponseDto,
  })
  @MessagePattern(`${NATS_ITEM}.close_suspend_item`)
  public async closeSuspendItem(
    @Param('id', new ParseIntPipe()) id,
    @Req() body: ChangeStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.suspendItemService.closeSuspendItem({
      id,
      ...request,
    });
  }
}
