import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { SuspendItemEntity } from '@entities/suspend-item/suspend-item.entity';
import { CreateSuspendItemRequestDto } from '../dto/request/create-suspend-item.request.dto';
import { GetListSuspendItemRequestDto } from '../dto/request/get-list-suspend-item.request.dto';

export interface SuspendItemRepositoryInterface
  extends BaseInterfaceRepository<SuspendItemEntity> {
  createEntities(
    request: CreateSuspendItemRequestDto,
  ): Promise<SuspendItemEntity[]>;
  getSuspendItems(
    request: GetListSuspendItemRequestDto,
    warehouseIdsFilter: any[],
  ): Promise<any>;
  getSuspendItem(id: number): Promise<any>;
}
