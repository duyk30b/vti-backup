import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { CreateSuspendItemRequestDto } from '../dto/request/create-suspend-item.request.dto';
import { GetListSuspendItemRequestDto } from '../dto/request/get-list-suspend-item.request.dto';
import { GetListSuspendItemResponseDto } from '../dto/response/get-list-suspend-item.response.dto';
import { SuspendItemResponseDto } from '../dto/response/suspend-item.response.dto';

export interface SuspendItemServiceInterface {
  createSuspendItem(
    request: CreateSuspendItemRequestDto,
  ): Promise<ResponsePayload<any | SuspendItemResponseDto>>;
  getDetail(id: number): Promise<ResponsePayload<any | SuspendItemResponseDto>>;
  getList(
    request: GetListSuspendItemRequestDto,
  ): Promise<ResponsePayload<any | GetListSuspendItemResponseDto>>;
  deleteSuspendItem(
    id: number,
  ): Promise<ResponsePayload<any | SuccessResponse>>;
  openSuspendItem(
    id: number,
  ): Promise<ResponsePayload<any | SuspendItemResponseDto>>;
  closeSuspendItem(
    id: number,
  ): Promise<ResponsePayload<any | SuspendItemResponseDto>>;
}
