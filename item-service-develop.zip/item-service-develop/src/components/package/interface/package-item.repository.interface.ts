import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { PackageItem } from '@entities/package/package-item.entity';
import { PackageItemDto } from '../dto/request/create-package.dto';

export interface PackageItemRepositoryInterface
  extends BaseInterfaceRepository<PackageItem> {
  createEntity(request: PackageItemDto): PackageItem;
}
