import { GetListPackageRequestDto } from './../dto/request/get-list-package.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreatePackageDto } from '../dto/request/create-package.dto';
import { DeletePackageDto } from '../dto/request/delete-package.dto';
import { UpdatePackageDto } from '../dto/request/update-package.dto';
import { GetDetailRequestDto } from '@components/item/dto/request/get-detail.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { SetStatusPackageRequestDto } from '../dto/request/set-status-package.request.dto';
import { PackageResponseDto } from '../dto/response/package.response.dto';

export interface PackageServiceInterface {
  createPackage(request: CreatePackageDto): Promise<ResponsePayload<any>>;
  updatePackage(request: UpdatePackageDto): Promise<ResponsePayload<any>>;
  deletePackage(request: DeletePackageDto): Promise<ResponsePayload<any>>;
  deleteMultiplePackage(
    request: DeleteMultipleDto,
  ): Promise<ResponsePayload<any>>;
  getDetail(request: GetDetailRequestDto): Promise<ResponsePayload<any>>;
  getList(request: GetListPackageRequestDto): Promise<ResponsePayload<any>>;
  getPackageByIds(ids: number[]): Promise<ResponsePayload<any>>;
  confirmPackage(
    request: SetStatusPackageRequestDto,
  ): Promise<ResponsePayload<PackageResponseDto | any>>;
  rejectPackage(
    request: SetStatusPackageRequestDto,
  ): Promise<ResponsePayload<PackageResponseDto | any>>;
  getPackageEvenlyByItem(itemId: number): Promise<any>;
}
