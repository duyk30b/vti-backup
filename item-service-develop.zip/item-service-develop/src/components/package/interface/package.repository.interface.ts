import { GetListPackageRequestDto } from './../dto/request/get-list-package.request.dto';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { Package } from '@entities/package/package.entity';
import { CreatePackageDto } from '../dto/request/create-package.dto';
import { UpdatePackageDto } from '../dto/request/update-package.dto';

export interface PackageRepositoryInterface
  extends BaseInterfaceRepository<Package> {
  createEntity(request: CreatePackageDto): Package;
  getList(request: GetListPackageRequestDto): Promise<any>;
  getDetail(id: number): Promise<any>;
  getDetailByCode(code: string): Promise<any>;
  updateEntity(
    packageUpdate: Package,
    request: UpdatePackageDto | CreatePackageDto,
  ): Package;
  getPackageByIds(ids: number[]): Promise<any>;
  getPackageEvenlyByItem(itemId: number): Promise<any[]>;
}
