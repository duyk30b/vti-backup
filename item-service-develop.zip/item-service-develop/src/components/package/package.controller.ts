import { GetDetailRequestDto } from '@components/item/dto/request/get-detail.request.dto';
import { GetPackageRequestDto } from '@components/package/dto/request/get-package.request.dto';
import {
  Controller,
  Inject,
  Body,
  Post,
  Get,
  Req,
  Param,
  ParseIntPipe,
  Put,
  Delete,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { isEmpty } from 'lodash';
import { CreatePackageDto } from './dto/request/create-package.dto';
import { DeletePackageDto } from './dto/request/delete-package.dto';
import { GetListPackageRequestDto } from './dto/request/get-list-package.request.dto';
import { UpdatePackgaeBodyRequestDto } from './dto/request/update-package.dto';
import { PackageServiceInterface } from './interface/package.service.interface';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CREATE_PACKAGE_PERMISSION,
  UPDATE_PACKAGE_PERMISSION,
  DELETE_PACKAGE_PERMISSION,
  DETAIL_PACKAGE_PERMISSION,
  LIST_PACKAGE_PERMISSION,
} from '@utils/permissions/package';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { PackageResponseDto } from './dto/response/package.response.dto';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { SetStatusPackageParamDto } from './dto/request/set-status-package.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { NATS_ITEM } from '@config/nats.config';

@Controller('packages')
export class PackageController {
  constructor(
    @Inject('PackageServiceInterface')
    private readonly packageService: PackageServiceInterface,
  ) {}

  @PermissionCode(CREATE_PACKAGE_PERMISSION.code)
  // @MessagePattern('create_package')
  @Post('/create')
  @ApiOperation({
    tags: ['Item', 'Package'],
    summary: 'Create new package',
    description: 'Tạo 1 package mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async CreatePackage(@Body() body: CreatePackageDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.packageService.createPackage(request);
  }

  @PermissionCode(UPDATE_PACKAGE_PERMISSION.code)
  // @MessagePattern('update_package')
  @Put('/:id')
  @ApiOperation({
    tags: ['Package', 'Item'],
    summary: 'Update package',
    description: 'Cập nhật thông tin package',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  public async UpdatePackage(
    @Param('id', new ParseIntPipe()) id,
    @Body() body: UpdatePackgaeBodyRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.packageService.updatePackage({
      id,
      ...request,
    });
  }
  @PermissionCode(DELETE_PACKAGE_PERMISSION.code)
  // @MessagePattern('delete_package')
  @Delete('/:id')
  @ApiOperation({
    tags: ['Package', 'Item'],
    summary: 'Delete package',
    description: 'Xóa package',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deletePackage(
    @Param('id', new ParseIntPipe()) id,
    @Req() body: DeletePackageDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.packageService.deletePackage({
      id,
      ...request,
    });
  }

  @PermissionCode(DELETE_PACKAGE_PERMISSION.code)
  // @MessagePattern('delete_package_multiple')
  @Delete('/multiple')
  @ApiOperation({
    tags: ['Package', 'Item'],
    summary: 'Delete multiple package',
    description: 'Xóa nhiều package',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deleteMultiplePackage(
    @Query() body: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.packageService.deleteMultiplePackage(request);
  }

  @PermissionCode(LIST_PACKAGE_PERMISSION.code)
  // @MessagePattern('get_package_list')
  @Get('/list')
  @ApiOperation({
    tags: ['Item', 'Package'],
    summary: 'List Package',
    description: 'Danh sách package',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: null,
  })
  public async getList(@Query() body: GetListPackageRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.packageService.getList(request);
  }

  @PermissionCode(DETAIL_PACKAGE_PERMISSION.code)
  // @MessagePattern('get_package_detail')
  @Get('/:id')
  @ApiOperation({
    tags: ['Item', 'Package'],
    summary: 'Package Detail',
    description: 'Chi tiết package',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: PackageResponseDto,
  })
  public async getDetail(
    @Param('id', new ParseIntPipe()) id,
    @Req() body: GetDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.packageService.getDetail({
      id,
      ...request,
    });
  }

  // @MessagePattern('get_package_by_ids')
  public async getPackageByIds(
    @Body() body: GetPackageRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.packageService.getPackageByIds(request.ids);
  }

  @MessagePattern(`${NATS_ITEM}.get_package_evenly`)
  @Get('/:id/evenly')
  public async getPackageEvenlyByItem(
    @Param('id', new ParseIntPipe()) itemId,
  ): Promise<any> {
    return await this.packageService.getPackageEvenlyByItem(itemId);
  }

  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Package'],
    summary: 'confirm package',
    description: 'xác nhận package',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: PackageResponseDto,
  })
  // @MessagePattern('confirm_package')
  public async confirmPackage(
    @Param() payload: SetStatusPackageParamDto,
  ): Promise<ResponsePayload<PackageResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.packageService.confirmPackage(request);
  }

  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Package'],
    summary: 'reject package',
    description: 'từ chối package',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: PackageResponseDto,
  })
  // @MessagePattern('reject_package')
  public async rejectPackage(
    @Param() payload: SetStatusPackageParamDto,
  ): Promise<ResponsePayload<PackageResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.packageService.rejectPackage(request);
  }

  @MessagePattern(`${NATS_ITEM}.get_package_by_ids`)
  public async getPackageByIdsTcp(
    @Body() body: GetPackageRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.packageService.getPackageByIds(request.ids);
  }

  @PermissionCode(LIST_PACKAGE_PERMISSION.code)
  @MessagePattern(`${NATS_ITEM}.get_package_list`)
  public async getListTcp(
    @Body() body: GetListPackageRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.packageService.getList(request);
  }
}
