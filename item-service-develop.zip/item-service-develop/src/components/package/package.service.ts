import { PagingResponse } from './../../utils/paging.response';
import { plainToInstance } from 'class-transformer';
import { GetListPackageRequestDto } from './dto/request/get-list-package.request.dto';
import { ItemRepositoryInterface } from '@components/item/interface/item.repository.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { PackageItem } from '@entities/package/package-item.entity';
import { Package } from '@entities/package/package.entity';
import { Injectable, Inject } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import {
  formatUnitMeasures,
  formatUnitWeight,
  validateVolumeWeightItems,
  VALIDATE_TYPE,
} from '@utils/common';
import { DataSource, In } from 'typeorm';
import { CreatePackageDto } from './dto/request/create-package.dto';
import { DeletePackageDto } from './dto/request/delete-package.dto';
import { UpdatePackageDto } from './dto/request/update-package.dto';
import { PackageItemRepositoryInterface } from './interface/package-item.repository.interface';
import { PackageRepositoryInterface } from './interface/package.repository.interface';
import { PackageServiceInterface } from './interface/package.service.interface';
import { PackageResponseDto } from './dto/response/package.response.dto';
import { GetDetailRequestDto } from '@components/item/dto/request/get-detail.request.dto';
import { isEmpty } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { stringFormat } from '@utils/object.util';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { SetStatusPackageRequestDto } from './dto/request/set-status-package.request.dto';
import {
  CAN_CONFIRM_STATUS_PACKAGE,
  CAN_REJECT_STATUS_PACKAGE,
  PackageStatusEnum,
  STATUS_TO_DELETE_OR_UPDATE_PACKAGE,
} from './package.constant';
@Injectable()
export class PackageService implements PackageServiceInterface {
  constructor(
    @Inject('PackageRepositoryInterface')
    private readonly packageRepository: PackageRepositoryInterface,

    @Inject('PackageItemRepositoryInterface')
    private readonly packageItemRepository: PackageItemRepositoryInterface,

    @Inject('ItemRepositoryInterface')
    private readonly itemRepository: ItemRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,

    @InjectDataSource()
    private readonly connection: DataSource,
  ) {}

  async createPackage(
    request: CreatePackageDto,
  ): Promise<ResponsePayload<any>> {
    const newPackageEntity = this.packageRepository.createEntity(request);
    return await this.save(newPackageEntity, request);
  }

  async updatePackage(
    request: UpdatePackageDto,
  ): Promise<ResponsePayload<any>> {
    const packageFind = await this.packageRepository.findOneById(request.id);
    if (!packageFind) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (!STATUS_TO_DELETE_OR_UPDATE_PACKAGE.includes(packageFind.status))
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();

    return await this.save(packageFind, request);
  }

  private async save(
    packageEntity: Package,
    request: CreatePackageDto | UpdatePackageDto,
  ): Promise<ResponsePayload<any> | any> {
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const isUpdate = packageEntity.id !== undefined;
      //Validate
      const itemIds = request.packageItems.map((e) => e.itemId);
      const items = await this.itemRepository.findWithRelations({
        where: {
          id: In(itemIds),
        },
      });

      if (items.length !== itemIds.length) {
        return new ResponseBuilder({
          invalidDetail: request.packageItems.filter(
            (e) => !items.find((e2) => e.itemId === e2.id),
          ),
        })
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.ITEM_NOT_FOUND'))
          .build();
      }

      //Validate unquie code block
      if (!isUpdate || packageEntity.code !== request.code) {
        const packageCheck = await this.packageRepository.findByCondition({
          code: request.code,
        });

        if (packageCheck) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(await this.i18n.translate('error.CODE_EXIST'))
            .build();
        }
      }

      //Create
      if (request.packageItems && request.packageItems.length > 0) {
        packageEntity.packageItems = request.packageItems.map((e) =>
          this.packageItemRepository.createEntity(e),
        );
      }

      if (isUpdate) {
        await queryRunner.manager.delete(PackageItem, {
          packageId: packageEntity.id,
        });
        packageEntity = this.packageRepository.updateEntity(
          packageEntity,
          request,
        );
      }

      // Validate volume and weight
      const checkVolume = validateVolumeWeightItems(
        {
          ...packageEntity,
          long: formatUnitMeasures(
            packageEntity.long.value,
            packageEntity.long.unit,
          ),
          width: formatUnitMeasures(
            packageEntity.width.value,
            packageEntity.width.unit,
          ),
          height: formatUnitMeasures(
            packageEntity.height.value,
            packageEntity.height.unit,
          ),
        },
        items.map((item) => ({
          ...item,
          long: formatUnitMeasures(item.long.value, item.long.unit),
          width: formatUnitMeasures(item.width.value, item.width.unit),
          height: formatUnitMeasures(item.height.value, item.height.unit),
          quantity: request.packageItems.find((it) => it.itemId === item.id)
            ?.quantity,
        })),
        VALIDATE_TYPE.VOLUME,
      );

      const checkWeight = validateVolumeWeightItems(
        {
          ...packageEntity,
          weight: formatUnitWeight(
            packageEntity.weight.value,
            packageEntity.weight.unit,
          ),
        },
        items.map((item) => ({
          ...item,
          weight: formatUnitMeasures(item.weight.value, item.weight.unit),
          quantity: request.packageItems.find((it) => it.itemId === item.id)
            ?.quantity,
        })),
        VALIDATE_TYPE.WEIGHT,
      );

      if (!checkVolume) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.TOTAL_VOLUME_ITEMS_EXCEEDS_PACKAGE_VOLUME',
            ),
          )
          .build();
      }

      if (!checkWeight) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.TOTAL_WEIGHT_ITEMS_EXCEEDS_PACKAGE_WEIGHT',
            ),
          )
          .build();
      }

      const savePackage = await queryRunner.manager.save(packageEntity);
      await queryRunner.commitTransaction();
      return new ResponseBuilder(savePackage)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  async deletePackage(
    request: DeletePackageDto,
  ): Promise<ResponsePayload<any>> {
    const packageFind = await this.packageRepository.findOneWithRelations({
      relations: ['packageItems'],
      where: {
        id: request.id,
      },
    });
    if (!packageFind) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (!STATUS_TO_DELETE_OR_UPDATE_PACKAGE.includes(packageFind.status))
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.CAN_NOT_DELETE'),
      ).toResponse();
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await this.connection.manager.remove(packageFind.packageItems);
      await this.connection.manager.remove(packageFind);
      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  async deleteMultiplePackage(
    request: DeleteMultipleDto,
  ): Promise<ResponsePayload<any>> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const packages = await this.packageRepository.findWithRelations({
      relations: ['packageItems'],
      where: {
        id: In(ids),
      },
    });

    const packageIds = packages.map((pk) => pk.id);
    if (packages.length !== ids.length) {
      ids.forEach((id) => {
        if (!packageIds.includes(id)) failIdsList.push(id);
      });
    }

    const validIds = packages
      .filter((block) => !failIdsList.includes(block.id))
      .map((block) => block.id);

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (!isEmpty(validIds)) {
        await this.connection.manager.delete(PackageItem, {
          packageId: In(validIds),
        });
        await this.connection.manager.delete(Package, validIds);
        await queryRunner.commitTransaction();
      }
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    } finally {
      await queryRunner.release();
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async getList(
    payload: GetListPackageRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { data, count } = await this.packageRepository.getList(payload);
    const dataReturn = plainToInstance(PackageResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: payload.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async confirmPackage(
    request: SetStatusPackageRequestDto,
  ): Promise<ResponsePayload<PackageResponseDto | any>> {
    const { userId, id } = request;
    const itemPackage = await this.packageRepository.findOneById(id);
    if (!itemPackage) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('err.NOT_FOUND'))
        .build();
    }
    if (!CAN_CONFIRM_STATUS_PACKAGE.includes(itemPackage.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.PACKAGE_WAS_CONFIRMED'),
      ).toResponse();
    }
    itemPackage.approverId = userId;
    itemPackage.approvedAt = new Date(Date.now());
    itemPackage.status = PackageStatusEnum.CONFIRMED;
    const result = await this.packageRepository.create(itemPackage);
    const response = plainToInstance(PackageResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  async rejectPackage(
    request: SetStatusPackageRequestDto,
  ): Promise<ResponsePayload<PackageResponseDto | any>> {
    const { userId, id } = request;
    const itemPackage = await this.packageRepository.findOneById(id);
    if (!itemPackage) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('err.NOT_FOUND'))
        .build();
    }
    if (!CAN_REJECT_STATUS_PACKAGE.includes(itemPackage.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.PACKAGE_WAS_CONFIRMED'),
      ).toResponse();
    }
    itemPackage.approverId = userId;
    itemPackage.approvedAt = new Date(Date.now());
    itemPackage.status = PackageStatusEnum.REJECT;
    const result = await this.packageRepository.create(itemPackage);
    const response = plainToInstance(PackageResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getDetail(payload: GetDetailRequestDto) {
    const { id } = payload;
    const item = await this.packageRepository.getDetail(id);
    if (isEmpty(item)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.ITEM_NOT_FOUND'),
      ).toResponse();
    }
    const response = plainToInstance(PackageResponseDto, item, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getPackageByIds(ids: number[]): Promise<ResponsePayload<any>> {
    const packages = await this.packageRepository.getPackageByIds(ids);
    const response = plainToInstance(PackageResponseDto, packages, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getPackageEvenlyByItem(itemId: number) {
    const data = await this.packageRepository.getPackageEvenlyByItem(itemId);

    const dataFilter = data.filter((item) => {
      if (item.details.includes(itemId) && item.details.length === 1)
        return true;
      return false;
    });

    const response = plainToInstance(PackageResponseDto, dataFilter, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
