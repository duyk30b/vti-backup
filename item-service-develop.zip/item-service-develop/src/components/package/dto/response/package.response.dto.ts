import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray } from 'class-validator';
import { ItemResponseDto } from '@components/item/dto/response/item.response.dto';
import { MeaseuresUnitAbstractResponse } from '@components/item/dto/response/measures-unit-abstract.response.dto';
import { WeightUnitAbstractResponse } from '@components/item/dto/response/weight-unit-abstract.response.dto';

class PackageItem {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  packageId: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose({ name: 'itemQuantity' })
  quantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;
}
class UserResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  username: string;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  fullName: string;
}
export class PackageResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  @Type(() => MeaseuresUnitAbstractResponse)
  width: MeaseuresUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => MeaseuresUnitAbstractResponse)
  height: MeaseuresUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => MeaseuresUnitAbstractResponse)
  long: MeaseuresUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => WeightUnitAbstractResponse)
  weight: WeightUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  updatedAt: string;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty({ type: PackageItem, isArray: true })
  @Expose()
  @Type(() => PackageItem)
  @IsArray()
  packageItems: PackageItem[];

  @ApiProperty({ type: UserResponse })
  @Expose()
  @Type(() => UserResponse)
  approver: UserResponse;
}
