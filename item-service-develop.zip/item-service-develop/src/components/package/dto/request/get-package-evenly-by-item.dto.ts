import { BaseDto } from '@core/dto/base.dto';
import { IsNotEmpty, IsNumber } from 'class-validator';
import { Transform } from 'class-transformer';

export class GetPalletAndPackageEvenlyByItemDto extends BaseDto {
  @IsNumber()
  @IsNotEmpty()
  @Transform((obj) => Number(obj.value))
  itemId: number;
}
