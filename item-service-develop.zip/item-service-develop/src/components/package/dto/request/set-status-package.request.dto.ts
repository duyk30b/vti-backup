import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsInt } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { Transform } from 'class-transformer';

export class SetStatusPackageParamDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'id' })
  @IsNotEmpty()
  @IsInt()
  @Transform(({ value }) => Number(value))
  id: number;
}

export class SetStatusPackageRequestDto extends SetStatusPackageParamDto {
  @ApiProperty({ example: 1, description: 'user id' })
  @IsNotEmpty()
  @IsInt()
  userId?: number;
}
