import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class DeletePackageDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'Mã id package cần xóa' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
