import { BaseDto } from '@core/dto/base.dto';
import { IsArray, IsNotEmpty } from 'class-validator';

export class GetPackageRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsArray()
  ids: number[];
}
