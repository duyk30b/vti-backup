export enum PackageStatusEnum {
  PENDING = 0,
  CONFIRMED = 1,
  REJECT = 2,
}
export const STATUS_TO_DELETE_OR_UPDATE_PACKAGE = [PackageStatusEnum.PENDING];
export const CAN_CONFIRM_STATUS_PACKAGE = [PackageStatusEnum.PENDING];
export const CAN_REJECT_STATUS_PACKAGE = [PackageStatusEnum.PENDING];
