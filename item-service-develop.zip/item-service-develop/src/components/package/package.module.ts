import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ItemModule } from '@components/item/item.module';
import { Package } from '@entities/package/package.entity';
import { PackageRepository } from '@repositories/package.repository';
import { PackageController } from './package.controller';
import { PackageItem } from '@entities/package/package-item.entity';
import { PackageItemRepository } from '@repositories/package-item.repository';
import { PackageService } from './package.service';
import { Item } from '@entities/item/item.entity';
import { ItemRepository } from '@repositories/item.repository';

@Module({
  imports: [TypeOrmModule.forFeature([Package, PackageItem, Item]), ItemModule],
  exports: [
    {
      provide: 'PackageItemRepositoryInterface',
      useClass: PackageItemRepository,
    },
  ],
  providers: [
    {
      provide: 'PackageRepositoryInterface',
      useClass: PackageRepository,
    },
    {
      provide: 'PackageItemRepositoryInterface',
      useClass: PackageItemRepository,
    },
    {
      provide: 'ItemRepositoryInterface',
      useClass: ItemRepository,
    },
    {
      provide: 'PackageServiceInterface',
      useClass: PackageService,
    },
  ],
  controllers: [PackageController],
})
export class PackageModule {}
