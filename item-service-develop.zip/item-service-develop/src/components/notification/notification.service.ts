import { ConfigService } from '@config/config.service';
import { APIPrefix } from '@constant/common';
import { HttpClientService } from '@core/components/http-client/http-client.service';
import { Injectable } from '@nestjs/common';
import { PushSocketRequestDto } from './dto/request/push-socket.request.dto';
import { NotificationServiceInterface } from './interface/notification.service.interface';
import { ResourceItemSocket } from './notification.const';

@Injectable()
export class NotificationService implements NotificationServiceInterface {
  constructor(
    private configService: ConfigService,
    private readonly httpClientService: HttpClientService,
  ) {}
  protected readonly urlConfig = this.configService.get('notificationService');
  protected readonly url = `http://${
    this.urlConfig.options.host + ':' + this.urlConfig.options.port
  }`;

  async pushSocket(request: PushSocketRequestDto): Promise<any> {
    try {
      const response = await this.httpClientService.post(
        `${this.url}/${APIPrefix.Version}/notifications/push-socket/create`,
        { ...request, resource: ResourceItemSocket },
      );
      return response;
    } catch (error) {
      console.log(error);
    }
  }
}
