export const ResourceItemSocket = 'ITEM';
