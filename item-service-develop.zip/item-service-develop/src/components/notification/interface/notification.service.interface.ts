import { PushSocketRequestDto } from '../dto/request/push-socket.request.dto';

export interface NotificationServiceInterface {
  pushSocket(request: PushSocketRequestDto): Promise<any>;
}
