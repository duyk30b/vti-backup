import { ApiProperty } from '@nestjs/swagger';

export class PushSocketRequestDto {
  @ApiProperty()
  payload: any;

  @ApiProperty()
  channel: string;
}
