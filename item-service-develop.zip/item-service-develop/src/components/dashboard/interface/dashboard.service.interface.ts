import { ReportItemMovementRequestDto } from '../dto/request/report-item-movement-request.dto';
import { ReportItemStockConstructionScl } from '../dto/request/report-item-stock-construction-scl.request.dto';
import { ReportItemStockRequestDto } from '../dto/request/report-item-stock.request.dto';
import { GetListItemRequestDto } from '@components/item/dto/request/get-list-item.request.dto';

export interface DashboardServiceInterface {
  reportItemStock(request: ReportItemStockRequestDto): Promise<any>;
  reportItemMovement(request: ReportItemMovementRequestDto): Promise<any>;
  getListItem(request: GetListItemRequestDto): Promise<any>;
  reportItemStockWithConstrucitonScl(
    request: ReportItemStockConstructionScl,
  ): Promise<any>;
  getListItemStockInformation(
    request: ReportItemStockConstructionScl,
  ): Promise<any>;
}
