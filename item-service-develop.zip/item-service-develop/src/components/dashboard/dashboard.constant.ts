export enum ReportType {
  DAY = 0,
  MONTH = 1,
  QUARTER = 2,
}

export enum UNIT_DASHBOARD {
  MILLION = 1000000,
}
