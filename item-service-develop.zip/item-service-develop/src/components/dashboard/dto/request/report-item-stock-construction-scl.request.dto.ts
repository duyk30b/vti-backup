import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';
import { ReportTotalOrderRequestDto } from './report-total-order.request.dto';

export class ReportItemStockConstructionScl extends ReportTotalOrderRequestDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  type?: string;
}
