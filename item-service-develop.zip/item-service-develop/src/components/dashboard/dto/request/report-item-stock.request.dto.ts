import { ReportTotalOrderRequestDto } from './report-total-order.request.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsInt } from 'class-validator';
import { Transform } from 'class-transformer';

export class ReportItemStockRequestDto extends ReportTotalOrderRequestDto {
  @ApiPropertyOptional()
  @Transform((data) => Number(data.value))
  @IsOptional()
  @IsInt()
  itemId: number;

  @ApiPropertyOptional()
  @Transform((data) => Number(data.value))
  @IsOptional()
  @IsInt()
  warehouseId: number;

  @ApiPropertyOptional()
  @Transform((data) => +data.value)
  @IsOptional()
  @IsInt()
  locatorId: number;
}
