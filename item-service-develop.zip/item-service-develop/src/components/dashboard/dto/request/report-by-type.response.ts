import { Expose } from 'class-transformer';

export class ReportByDay {
  @Expose()
  day: number;

  @Expose()
  count: number;
}

export class StockMovementIdByDate {
  @Expose()
  ids: number[];

  @Expose()
  date: string;
}

export class ReportCountTranfer {
  @Expose()
  tag: string;

  @Expose()
  import: number;

  @Expose()
  export: number;

  @Expose()
  tranfer: number;

  constructor(
    tag: string,
    dataImport: number,
    dataExport: number,
    dataTranfer: number,
  ) {
    this.tag = tag;
    this.import = dataImport;
    this.export = dataExport;
    this.tranfer = dataTranfer;
  }
}

export class ReportTransfer {
  @Expose()
  reportType: number;

  @Expose()
  tag: string;

  @Expose()
  rangeDate: string;

  @Expose()
  import: number;

  @Expose()
  export: number;

  @Expose()
  tranfer: number;

  constructor(
    reportType: number,
    tag: string,
    rangeDate: string,
    dataImport: number,
    dataExport: number,
    dataTranfer: number,
  ) {
    this.reportType = reportType;
    this.tag = tag;
    this.rangeDate = rangeDate;
    this.import = dataImport;
    this.export = dataExport;
    this.tranfer = dataTranfer;
  }
}

export class ReportStockByDay {
  @Expose()
  reportType: number;

  @Expose()
  tag: string;

  @Expose()
  rangeDate: string;

  @Expose()
  stock: number;

  constructor(
    reportType: number,
    tag: string,
    stock: number,
    rangeDate: string,
  ) {
    this.reportType = reportType;
    this.tag = tag;
    this.stock = stock;
    this.rangeDate = rangeDate;
  }
}

export class RangeDate {
  @Expose()
  type: number;

  @Expose()
  tag: string;

  @Expose()
  startDate: string;

  @Expose()
  endDate: string;

  constructor(type: number, tag: string, startDate: string, endDate: string) {
    this.type = type;
    this.tag = tag;
    this.startDate = startDate;
    this.endDate = endDate;
  }
}
