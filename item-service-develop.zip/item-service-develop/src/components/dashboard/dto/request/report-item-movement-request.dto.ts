import { ApiPropertyOptional } from '@nestjs/swagger';
import { ReportTotalOrderRequestDto } from './report-total-order.request.dto';
import { IsInt, IsOptional, IsEnum } from 'class-validator';
import { Transform } from 'class-transformer';
import { ReportType } from '@components/dashboard/dashboard.constant';

export class ReportItemMovementRequestDto extends ReportTotalOrderRequestDto {
  @ApiPropertyOptional()
  @Transform((data) => Number(data.value))
  @IsOptional()
  @IsInt()
  itemId: number;

  @ApiPropertyOptional()
  @Transform((data) => Number(data.value))
  @IsOptional()
  @IsInt()
  warehouseId: number;

  @ApiPropertyOptional()
  @IsEnum(ReportType)
  @Transform((data) => Number(data.value))
  reportType: ReportType;
}
