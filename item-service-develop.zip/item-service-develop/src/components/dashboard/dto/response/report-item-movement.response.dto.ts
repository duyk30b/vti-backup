import { Expose } from 'class-transformer';

export class ReportItemMovementResponseDto {
  @Expose()
  reportType: number;

  @Expose()
  tag: string;

  @Expose()
  exportQuantity: number;

  @Expose()
  importQuantity: number;

  @Expose()
  exportAmount: number;

  @Expose()
  importAmount: number;

  @Expose()
  rangeDate: string;
}
