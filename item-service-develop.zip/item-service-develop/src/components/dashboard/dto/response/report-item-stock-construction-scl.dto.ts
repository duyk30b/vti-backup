import { Expose } from 'class-transformer';

export class ReportItemStockConstructionSclResponseDto {
  @Expose()
  index: number;

  @Expose()
  type: string;

  @Expose()
  totalItemStockAmount: number;
}
