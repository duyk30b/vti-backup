import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { WarehouseService } from '@components/warehouse/warehouse.service';
import { ItemStockMovementRepository } from '@repositories/item-stock-movement.repository';
import { ItemRepository } from '@repositories/item.repository';
import { Item } from '@entities/item/item.entity';
import { ItemWarehouseEntity } from '@entities/item/item-warehouse.entity';
import { ItemWarehouseRepository } from '@repositories/item-warehouse.repository';
import { ItemPlanningQuantityRepository } from './../../repositories/item-planning-quantity.repository';
import { ItemPlanningQuantityEntity } from './../../entities/item/item-planning-quantity.entity';
import { DashboardService } from './dashboard.service';

import { Global, Module } from '@nestjs/common';
import { DashboardController } from './dashboard.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ItemStockMovement } from '@entities/item/item-stock-movement.entity';
import { ConfigService } from '@config/config.service';
import { ItemStockWarehousePriceEntity } from '@entities/item/item-stock-warehouse-price.entity';
import { ItemStockWarehousePriceRepository } from '@repositories/item-stock-warehouse-price.repository';
import { ItemStockInformationEntity } from '@entities/item/item-stock-information.entity';
import { ItemStockInformationRepository } from '@repositories/item-stock-information.repository';

@Global()
@Module({
  imports: [
    TypeOrmModule.forFeature([
      ItemWarehouseEntity,
      ItemPlanningQuantityEntity,
      Item,
      ItemStockMovement,
      ItemStockWarehousePriceEntity,
      ItemStockInformationEntity,
    ]),
    WarehouseModule,
  ],
  providers: [
    {
      provide: 'DashboardServiceInterface',
      useClass: DashboardService,
    },
    {
      provide: 'ItemWarehouseRepositoryInterface',
      useClass: ItemWarehouseRepository,
    },
    {
      provide: 'ItemPlanningQuantityRepositoryInterface',
      useClass: ItemPlanningQuantityRepository,
    },
    {
      provide: 'ItemRepositoryInterface',
      useClass: ItemRepository,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'ItemStockMovementRepositoryInterface',
      useClass: ItemStockMovementRepository,
    },
    {
      provide: 'ItemStockInformationRepositoryInterface',
      useClass: ItemStockInformationRepository,
    },
    {
      provide: 'ConfigServiceInterface',
      useClass: ConfigService,
    },
    {
      provide: 'ItemStockWarehousePriceRepositoryInterface',
      useClass: ItemStockWarehousePriceRepository,
    },
  ],
  controllers: [DashboardController],
})
export class DashboardModule {}
