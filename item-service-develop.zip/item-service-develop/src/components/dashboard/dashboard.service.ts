import { ItemPlanningQuantityRepositoryInterface } from '@components/item-planning-quantity/interface/item-planning-quantity.repository.interface';
import { ItemWarehouseRepositoryInterface } from '@components/item-warehouse/interface/item-warehouse.repository.interface';
import { ItemStockMovementRepositoryInterface } from '@components/item/interface/item-stock-movement.repository.interface';
import { ItemStockWarehousePriceRepositoryInterface } from '@components/item/interface/item-stock-warehouse-price.repository.interface';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { ConfigService } from '@config/config.service';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { minusBigNumber } from '@utils/common';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { isEmpty } from 'lodash';
import * as moment from 'moment';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { plus } from './../../utils/helper';
import { PagingResponse } from './../../utils/paging.response';
import { ItemResponseDto } from './../inventory-time-norm/dto/response/inventory-time-norm.response.dto';
import { GetListItemRequestDto } from './../item/dto/request/get-list-item.request.dto';
import { ItemRepositoryInterface } from './../item/interface/item.repository.interface';
import { ReportType } from './dashboard.constant';
import { RangeDate } from './dto/request/report-by-type.response';
import { ReportItemMovementRequestDto } from './dto/request/report-item-movement-request.dto';
import { ReportItemStockRequestDto } from './dto/request/report-item-stock.request.dto';
import { ReportItemMovementResponseDto } from './dto/response/report-item-movement.response.dto';
import { DashboardServiceInterface } from './interface/dashboard.service.interface';
import { ReportItemStockConstructionScl } from './dto/request/report-item-stock-construction-scl.request.dto';
import { ItemStockInformationRepositoryInterface } from '@components/item-stock-information/interface/item-stock-information.repository.interface';
import { ReportItemStockConstructionSclResponseDto } from './dto/response/report-item-stock-construction-scl.dto';
import { ItemStockInformationResponseDto } from '@components/item-stock-information/dto/response/item-stock-information.response.dto';

@Injectable()
export class DashboardService implements DashboardServiceInterface {
  constructor(
    private readonly i18n: I18nRequestScopeService,

    @Inject('ItemWarehouseRepositoryInterface')
    private readonly itemWarehouseRepository: ItemWarehouseRepositoryInterface,

    @Inject('ItemPlanningQuantityRepositoryInterface')
    private readonly itemPlanningRepository: ItemPlanningQuantityRepositoryInterface,

    @Inject('ItemRepositoryInterface')
    private readonly itemRepository: ItemRepositoryInterface,

    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,

    @Inject('ItemStockMovementRepositoryInterface')
    private readonly itemStockMovementRepository: ItemStockMovementRepositoryInterface,

    @Inject('ItemStockWarehousePriceRepositoryInterface')
    private readonly itemStockWarehousePriceRepository: ItemStockWarehousePriceRepositoryInterface,

    @Inject('ItemStockInformationRepositoryInterface')
    private readonly itemStockInformationRepository: ItemStockInformationRepositoryInterface,

    @Inject('ConfigServiceInterface')
    private readonly configService: ConfigService,
  ) {}

  async reportItemStockWithConstrucitonScl(
    request: ReportItemStockConstructionScl,
  ): Promise<any> {
    const defaultTimeZone = this.configService.get('defaultTimeZone');
    const totalItemStock =
      await this.itemStockWarehousePriceRepository.getTotalItemStockConstructionSclDashboard(
        request,
        defaultTimeZone,
      );
    const dataFormat = [];
    totalItemStock.forEach((item, index) => {
      dataFormat.push({
        index: index + 1,
        type: item.type,
        totalItemStockAmount: item.totalAmount > 0 ? item?.totalAmount : 0,
      });
    });
    const data = plainToInstance(
      ReportItemStockConstructionSclResponseDto,
      dataFormat,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
  async reportItemStock(request: ReportItemStockRequestDto): Promise<any> {
    const [totalItemStock, totalItemPlanning] = await Promise.all([
      this.itemStockWarehousePriceRepository.getTotalItemStockDashboard(
        request,
      ),
      this.itemPlanningRepository.getTotalItemPlanning(request),
    ]);
    return new ResponseBuilder({
      totalItemStockAvaiable:
        minusBigNumber(
          totalItemStock?.totalQuantity || 0,
          totalItemPlanning?.totalQuantity || 0,
        ) || 0,
      totalItemPlanning: totalItemPlanning?.totalQuantity || 0,
      totalItemStockAmount:
        minusBigNumber(
          totalItemStock?.totalAmount || 0,
          totalItemPlanning?.totalAmount || 0,
        ) || 0,
      totalItemPlanningAmount: totalItemPlanning?.totalAmount || 0,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async reportItemMovement(
    request: ReportItemMovementRequestDto,
  ): Promise<any> {
    const { reportType, from, to, warehouseId, itemId } = request;
    const { listRangeDate, startDate, endDate } = this.getRangeDateByDateType(
      reportType,
      from,
      to,
    );
    const defaultTimeZone = this.configService.get('defaultTimeZone');
    const warehouseStockMovementIds =
      await this.warehouseService.getWarehouseStockMovementImport(request);
    const dataImport = !isEmpty(warehouseStockMovementIds)
      ? await this.itemStockMovementRepository.reportItemStockMovementImportByDateRange(
          startDate,
          endDate,
          warehouseId,
          itemId,
          warehouseStockMovementIds,
          defaultTimeZone,
        )
      : [];

    const dataExport =
      await this.itemStockMovementRepository.reportItemStockMovementExportByDateRange(
        startDate,
        endDate,
        warehouseId,
        itemId,
        defaultTimeZone,
      );
    const reportData: ReportItemMovementResponseDto[] = [];
    listRangeDate.forEach((rangeDate) => {
      const { startDate: startRangeDate, endDate: endRangeDate } = rangeDate;
      const importRangeDateStock = dataImport.filter(
        (e) =>
          moment(e.confirmedAt, 'YYYY-MM-DD').isSameOrAfter(
            moment(startRangeDate, 'YYYYMMDD'),
            'day',
          ) &&
          moment(e.confirmedAt, 'YYYY-MM-DD').isSameOrBefore(
            moment(endRangeDate, 'YYYYMMDD'),
            'day',
          ),
      );
      const exportRangeDateStock = dataExport.filter(
        (e) =>
          moment(e.confirmedAt, 'YYYY-MM-DD').isSameOrAfter(
            moment(startRangeDate, 'YYYYMMDD'),
            'day',
          ) &&
          moment(e.confirmedAt, 'YYYY-MM-DD').isSameOrBefore(
            moment(endRangeDate, 'YYYYMMDD'),
            'day',
          ),
      );
      let exportQuantity = 0;
      let importQuantity = 0;
      let exportAmount = 0;
      let importAmount = 0;
      importRangeDateStock.forEach((itemMovement) => {
        importQuantity = plus(importQuantity, itemMovement.quantity);
        importAmount = plus(importAmount, itemMovement.amount);
      });

      exportRangeDateStock.forEach((itemMovement) => {
        exportQuantity = plus(exportQuantity, itemMovement.quantity);
        exportAmount = plus(exportAmount, itemMovement.amount);
      });
      reportData.push({
        reportType: reportType,
        tag: rangeDate.tag,
        exportQuantity: exportQuantity,
        exportAmount: exportAmount,
        importQuantity: importQuantity,
        importAmount: importAmount,
        rangeDate: this.getRangeDate(startRangeDate, endRangeDate, reportType),
      } as ReportItemMovementResponseDto);
    });
    return new ResponseBuilder(reportData)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private getRangeDate(
    startDate: string,
    endDate: string,
    reportType: ReportType,
  ): string {
    return reportType === ReportType.DAY
      ? `${moment(startDate, 'YYYYMMDD').format('DD/MM/y')}`
      : `${moment(startDate, 'YYYYMMDD').format('DD/MM/y')}-${moment(
          endDate,
          'YYYYMMDD',
        ).format('DD/MM/y')}`;
  }

  private getRangeDateByDateType(
    reportType: number,
    startDate?: Date,
    endDate?: Date,
  ): {
    listRangeDate: RangeDate[];
    startDate: Date;
    endDate: Date;
  } {
    const listRangeDate: RangeDate[] = [];
    let unit: 'day' | 'month' | 'quarter' = 'day';
    switch (reportType) {
      case ReportType.MONTH:
        unit = 'month';
        break;
      case ReportType.QUARTER:
        unit = 'quarter';
        break;
      default:
        break;
    }
    const from = startDate
      ? moment(startDate)
      : reportType === ReportType.MONTH
      ? moment().month(moment().month()).startOf('month')
      : reportType === ReportType.QUARTER
      ? moment().quarter(moment().quarter()).startOf('quarter')
      : moment().isoWeek(moment().isoWeek()).startOf('isoWeek');

    const to = endDate
      ? moment(endDate)
      : reportType === ReportType.MONTH
      ? moment().month(moment().month()).endOf('month')
      : reportType === ReportType.QUARTER
      ? moment().quarter(moment().quarter()).endOf('quarter')
      : moment().isoWeek(moment().isoWeek()).endOf('isoWeek');
    let tag = 30;
    for (
      let date = to.clone();
      date.isSameOrAfter(from, unit) && listRangeDate.length < 30;
      date = date.clone().endOf(unit).subtract(1, unit)
    ) {
      let startUnit = date.clone().startOf(unit).format('YYYYMMDD');
      if (from.isSameOrAfter(startUnit)) {
        startUnit = from.format('YYYYMMDD');
      }
      let endUnit = date.clone().endOf(unit);
      if (to.isSameOrBefore(endUnit)) {
        endUnit = to;
      }
      listRangeDate.push(
        new RangeDate(
          reportType,
          `${tag}`,
          startUnit,
          endUnit.format('YYYYMMDD'),
        ),
      );
      tag--;
    }
    return {
      listRangeDate: listRangeDate.reverse(),
      startDate: from.toDate(),
      endDate: to.toDate(),
    };
  }
  async getListItem(request: GetListItemRequestDto): Promise<any> {
    const { data, count } = await this.itemRepository.getList(request);

    const dataReturn = plainToInstance(ItemResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getListItemStockInformation(
    request: ReportItemStockConstructionScl,
  ): Promise<any> {
    const result =
      await this.itemStockInformationRepository.getListItemStockInformationWithScl(
        request,
      );
    const data = plainToInstance(ItemStockInformationResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }
}
