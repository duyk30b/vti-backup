import { GetListItemRequestDto } from '@components/item/dto/request/get-list-item.request.dto';
import { ReportItemMovementRequestDto } from './dto/request/report-item-movement-request.dto';
import { ReportItemStockRequestDto } from './dto/request/report-item-stock.request.dto';
import { Controller, Get, Inject, Query } from '@nestjs/common';
import { DashboardServiceInterface } from './interface/dashboard.service.interface';
import { isEmpty } from 'lodash';
import { ReportItemStockConstructionScl } from './dto/request/report-item-stock-construction-scl.request.dto';
@Controller('dashboard')
export class DashboardController {
  constructor(
    @Inject('DashboardServiceInterface')
    private readonly dashboardService: DashboardServiceInterface,
  ) {}

  @Get('item-stocks')
  async reportItemStock(
    @Query() query: ReportItemStockRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.dashboardService.reportItemStock(request);
  }
  @Get('item-stock-construction-scl')
  async reportItemStockConstructionScl(
    @Query() query: ReportItemStockConstructionScl,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.dashboardService.reportItemStockWithConstrucitonScl(
      request,
    );
  }

  @Get('item-movements')
  async reportItemMovement(
    @Query() query: ReportItemMovementRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.dashboardService.reportItemMovement(request);
  }

  @Get('items/list')
  async getListItem(@Query() query: GetListItemRequestDto): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.dashboardService.getListItem(request);
  }
  @Get('item-stock-informations/list')
  async getListItemStockInformation(
    @Query() query: ReportItemStockConstructionScl,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.dashboardService.getListItemStockInformation(request);
  }
}
