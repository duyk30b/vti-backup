import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsOptional } from 'class-validator';

export class GetLocatorRequest extends BaseDto {
  @ApiProperty({ example: 1 })
  @IsOptional()
  @IsInt()
  warehouseId: number;

  @ApiProperty({ example: 1 })
  @IsOptional()
  @IsInt()
  locatorId: number;
}
