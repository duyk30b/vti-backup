import { WarehouseLayoutService } from './warehouse-layout.service';
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ClientProxyFactory } from '@nestjs/microservices';
import { ConfigService } from '@config/config.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    'WAREHOUSE_LAYOUT_SERVICE_CLIENT',
    {
      provide: 'WarehouseLayoutServiceInterface',
      useClass: WarehouseLayoutService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'WAREHOUSE_LAYOUT_SERVICE_CLIENT',
      useFactory: (configService: ConfigService) => {
        const warehouseLayoutServiceOptions = configService.get(
          'warehouseLayoutService',
        );
        return ClientProxyFactory.create(warehouseLayoutServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'WarehouseLayoutServiceInterface',
      useClass: WarehouseLayoutService,
    },
  ],
})
export class WarehouseLayoutModule {}
