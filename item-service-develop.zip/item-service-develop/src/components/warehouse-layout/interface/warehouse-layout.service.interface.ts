export interface WarehouseLayoutServiceInterface {
  getLocatorByIds(ids: number[], serilize?: boolean): Promise<any>;
  getLocatorById(id: number): Promise<any>;
  getLocatorsByRootIds(rootIds: number[], type?: number): Promise<any>;
  getLocatorByCode(code: string): Promise<any>;
  getLocatorByKeyword(
    locatorCode: string,
    warehouseIds: number[],
    onlyId?: boolean,
    serilize?: boolean,
  ): Promise<any>;
}
