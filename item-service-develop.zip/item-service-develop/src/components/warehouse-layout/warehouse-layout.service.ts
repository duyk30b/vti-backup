import { keyBy } from 'lodash';
import { ClientProxy } from '@nestjs/microservices';
import { Inject, Injectable } from '@nestjs/common';
import { WarehouseLayoutServiceInterface } from './interface/warehouse-layout.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { plainToInstance } from 'class-transformer';
import { LocatorResponseDto } from './dto/response/locator.response.dto';
import { isEmpty, uniq, map, flatMap } from 'lodash';
@Injectable()
export class WarehouseLayoutService implements WarehouseLayoutServiceInterface {
  constructor(
    @Inject('WAREHOUSE_LAYOUT_SERVICE_CLIENT')
    private readonly warehouseLayoutServiceClient: ClientProxy,
  ) {}

  async getLocatorByIds(ids: number[], serilize?: boolean): Promise<any> {
    const response = await this.warehouseLayoutServiceClient
      .send('get_locator_by_ids', {
        locatorIds: ids,
      })
      .toPromise();
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];

    const dataReturn = plainToInstance(
      LocatorResponseDto,
      <any[]>response.data,
      {
        excludeExtraneousValues: true,
      },
    );

    return serilize ? keyBy(dataReturn, 'locatorId') : dataReturn;
  }

  public async getLocatorById(locatorId: number): Promise<any> {
    const response = await this.warehouseLayoutServiceClient
      .send('get_detail', { locatorId: locatorId })
      .toPromise();

    if (response.statusCode != ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return response.data;
  }

  public async getLocatorByCode(code: string): Promise<any> {
    const response = await this.warehouseLayoutServiceClient
      .send('get_locator_by_code', { code: code })
      .toPromise();
    if (response.statusCode != ResponseCodeEnum.SUCCESS) {
      return {};
    }
    return response.data;
  }

  public async getLocatorsByRootIds(
    rootIds: number[],
    type?: number,
  ): Promise<any> {
    const response = await this.warehouseLayoutServiceClient
      .send('get_locators_by_root_ids', { rootIds, type: type })
      .toPromise();

    if (response.statusCode != ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }

  async getLocatorByKeyword(
    locatorCode: string,
    warehouseIds: number[],
    onlyId?: boolean,
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.warehouseLayoutServiceClient
      .send('get_locator_by_keyword', {
        locatorCodeKeyword: locatorCode,
        rootId: warehouseIds,
      })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    if (!isEmpty(response.data) && onlyId === true) {
      return uniq(map(flatMap(response.data), 'id'));
    }

    if (serilize) {
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
      const serilizeWarehouses = [];
      response.data.forEach((warehouse) => {
        serilizeWarehouses[warehouse.id] = warehouse;
      });

      return serilizeWarehouses;
    }

    return response.data;
  }
}
