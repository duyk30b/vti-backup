export const WAREHOUSE_LAYOUT_TYPE = {
  REAL: 0,
  VIRTUAL: 1,
};
