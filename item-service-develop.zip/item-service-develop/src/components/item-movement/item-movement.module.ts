import { MovementEntity } from '@entities/item-movement/movement.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MovementRepository } from '@repositories/item-movement.repository';
import { MovementController } from './item-movement.controller';
import { MovementService } from './item-movement.service';

@Module({
  imports: [TypeOrmModule.forFeature([MovementEntity])],
  providers: [
    {
      provide: 'MovementRepositoryInterface',
      useClass: MovementRepository,
    },
    {
      provide: 'MovementServiceInterface',
      useClass: MovementService,
    },
  ],
  controllers: [MovementController],
  exports: [
    {
      provide: 'MovementRepositoryInterface',
      useClass: MovementRepository,
    },
    {
      provide: 'MovementServiceInterface',
      useClass: MovementService,
    },
  ],
})
export class MovementModule {}
