import { CreateItemMovementsRequestDto } from '../dto/request/create-item-movement.request.dto';
import { GetItemMovementByConditionRequestDto } from '../dto/request/get-item-movement-by-condition.request.dto';

export interface MovementServiceInterface {
  createMultiple(request: CreateItemMovementsRequestDto): Promise<any>;
  createMovement(itemMovements: CreateItemMovementsRequestDto): Promise<any>;
  getItemMovementByCondition(
    request: GetItemMovementByConditionRequestDto,
  ): Promise<any>;
}
