import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { MovementEntity } from '@entities/item-movement/movement.entity';
import { GetItemMovementByConditionRequestDto } from '../dto/request/get-item-movement-by-condition.request.dto';

export interface MovementRepositoryInterface
  extends BaseAbstractRepository<MovementEntity> {
  createEntity(data: any): MovementEntity;
  getItemMovementByCondition(
    request: GetItemMovementByConditionRequestDto,
  ): Promise<any>;
}
