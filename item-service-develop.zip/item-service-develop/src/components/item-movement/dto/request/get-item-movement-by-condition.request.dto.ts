import { Transform } from 'class-transformer';
import { BaseDto } from '@core/dto/base.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsInt, IsOptional, IsString } from 'class-validator';
import { isJson } from 'src/helper/string.helper';

export class GetItemMovementByConditionRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  @IsInt()
  itemId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => {
    if (value) value = value.replace(/\\/g, '');
    if (isJson(value)) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    }
  })
  itemIds: number[];

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  @IsInt()
  warehouseId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => {
    if (value) value = value.replace(/\\/g, '');
    if (isJson(value)) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    }
  })
  warehouseIds: number[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  ticketId: string;

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => {
    if (value) value = value.replace(/\\/g, '');
    if (isJson(value)) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    }
  })
  ticketIds: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  locatorId: string;

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => {
    if (value) value = value.replace(/\\/g, '');
    if (isJson(value)) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    }
  })
  locatorIds: string[];
}
