import { TYPE_ENUM_MOVEMENT } from '@components/item-movement/item-movement.constants';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsDateString,
  IsEnum,
  IsInt,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

export class CreateMovementRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsString()
  ticketId: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  locatorId: string;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  warehouseLocatorId: number;

  @ApiProperty()
  @IsEnum(TYPE_ENUM_MOVEMENT)
  @IsInt()
  type: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiProperty()
  @IsInt()
  quantity: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  storedQuantity: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  exportedQuantity: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  mfg: Date;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  importDate: Date;
}

export class CreateItemMovementsRequestDto extends BaseDto {
  @ApiProperty()
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => CreateMovementRequestDto)
  items: CreateMovementRequestDto[];
}
