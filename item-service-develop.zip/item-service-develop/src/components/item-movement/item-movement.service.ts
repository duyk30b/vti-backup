import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { I18nService } from 'nestjs-i18n';
import { DataSource } from 'typeorm';
import { CreateItemMovementsRequestDto } from './dto/request/create-item-movement.request.dto';
import { MovementRepositoryInterface } from './interfaces/item-movement.repository.interface';
import { MovementServiceInterface } from './interfaces/item-movement.service.interface';
import { isEmpty } from 'lodash';
import { MovementEntity } from '@entities/item-movement/movement.entity';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { GetItemMovementByConditionRequestDto } from './dto/request/get-item-movement-by-condition.request.dto';
@Injectable()
export class MovementService implements MovementServiceInterface {
  constructor(
    @Inject('MovementRepositoryInterface')
    private readonly movementRepository: MovementRepositoryInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nService,
  ) {}

  async createMultiple(request: CreateItemMovementsRequestDto): Promise<any> {
    const { items } = request;
    const type = items[0].type;
    const conditionFilterItemMovement = items.map((item) => {
      return {
        ticketId: item.ticketId,
        type: item.type,
      };
    });
    const itemMovementByOrderId =
      await this.movementRepository.findAllByCondition(
        conditionFilterItemMovement,
      );
    const idsRemove = [];
    const deleteItemMovement = [];
    let itemMovementEnities = items.map((itemMovementRequest) => {
      const itemMovement = itemMovementByOrderId.find(
        (item) =>
          item.itemId === itemMovementRequest.itemId &&
          item.ticketId === itemMovementRequest.ticketId &&
          item.type === itemMovementRequest.type &&
          (item?.lotNumber?.toUpperCase() || null) ===
            (itemMovementRequest?.lotNumber?.toUpperCase() || null) &&
          (item?.locatorId || null) ===
            (itemMovementRequest?.locatorId || null),
      );
      // const entity = itemMovement
      //   ? this.movementRepository.updateEntity(
      //       itemMovementRequest,
      //       itemMovement,
      //     )
      //   :this.movementRepository.createEntity(itemMovementRequest);
      const entity = this.movementRepository.createEntity(itemMovementRequest);

      if (itemMovement && entity.quantity === 0) {
        idsRemove.push(itemMovement.id);
        deleteItemMovement.push(itemMovement);
      }
      return entity;
    });
    itemMovementEnities = itemMovementEnities.filter(
      (item) => item.quantity != 0,
    );
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (!isEmpty(idsRemove)) {
        await queryRunner.manager.delete(MovementEntity, idsRemove);
      }
      if (!isEmpty(itemMovementEnities)) {
        await queryRunner.manager.save(MovementEntity, itemMovementEnities);
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
    } finally {
      await queryRunner.release();
    }
  }
  async createMovement(
    itemMovements: CreateItemMovementsRequestDto,
  ): Promise<any> {
    const listItemMovementEntities = itemMovements.items.map((e) => {
      return this.movementRepository.createEntity(e);
    });
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    let itemStockMovements;
    try {
      itemStockMovements = await queryRunner.manager.save(
        listItemMovementEntities,
      );
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }

    return new ResponseBuilder(itemStockMovements)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getItemMovementByCondition(
    request: GetItemMovementByConditionRequestDto,
  ): Promise<any> {
    const response = await this.movementRepository.getItemMovementByCondition(
      request,
    );
    if (isEmpty(response)) {
      return new ResponseBuilder([])
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }
}
