import { NATS_ITEM } from '@config/nats.config';
import { Body, Controller, Get, Inject, Query } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { isEmpty } from 'lodash';
import { CreateItemMovementsRequestDto } from './dto/request/create-item-movement.request.dto';
import { GetItemMovementByConditionRequestDto } from './dto/request/get-item-movement-by-condition.request.dto';
import { MovementServiceInterface } from './interfaces/item-movement.service.interface';
@Controller('movements')
export class MovementController {
  constructor(
    @Inject('MovementServiceInterface')
    private readonly movementService: MovementServiceInterface,
  ) {}

  @MessagePattern(`${NATS_ITEM}.create_item_movements`)
  async createMultiple(
    @Body() payload: CreateItemMovementsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.movementService.createMovement(request);
  }

  @Get('/movement-item')
  @MessagePattern(`${NATS_ITEM}.get_movement_by_condition`)
  async getItemMovementByCondition(
    @Query() payload: GetItemMovementByConditionRequestDto,
  ): Promise<any> {
    const { responseError, request } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.movementService.getItemMovementByCondition(request);
  }
}
