export enum TYPE_ENUM_MOVEMENT {
  POI = 0,
  SOE = 1,
  TRANSFER = 2,
  PICK_UP = 3,
  CONFIRM_EXPORT = 4,
}
