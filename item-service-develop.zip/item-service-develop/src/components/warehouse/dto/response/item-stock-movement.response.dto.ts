import { Expose } from 'class-transformer';

export class ItemStockMovementResponse {
  @Expose()
  itemId: number;

  @Expose()
  quantity: number;

  @Expose()
  warehouseId: number;
}
