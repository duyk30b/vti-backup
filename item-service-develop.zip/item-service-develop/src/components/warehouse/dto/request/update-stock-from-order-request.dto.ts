import { OrderTypeEnum } from '@constant/common';
import { BaseDto } from '@core/dto/base.dto';
import { Transform } from 'class-transformer';
import { IsEnum, IsInt, IsNotEmpty } from 'class-validator';

export class UpdateStockFromOrderRequest extends BaseDto {
  @IsInt()
  @IsNotEmpty()
  @Transform(({ value }) => +value)
  warehouseStockMovementId: number;

  @IsEnum(OrderTypeEnum)
  @IsNotEmpty()
  orderType: OrderTypeEnum;
}
