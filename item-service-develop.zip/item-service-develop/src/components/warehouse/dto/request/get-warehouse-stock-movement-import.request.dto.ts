import { ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsDateString, IsInt, IsOptional } from 'class-validator';
export class GetWarehouseStockMovementImportRequestDto {
  @ApiPropertyOptional()
  @Transform((data) => Number(data.value))
  @IsOptional()
  @IsInt()
  warehouseId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  from: Date;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  to: Date;
}
