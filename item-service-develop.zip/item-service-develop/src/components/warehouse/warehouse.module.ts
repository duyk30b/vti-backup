import { Module } from '@nestjs/common';
import { WarehouseService } from './warehouse.service';
import { ConfigService } from '@config/config.service';
import { ClientProxyFactory } from '@nestjs/microservices';
import { ConfigModule } from '@nestjs/config';
import { WarehouseCronService } from './warehouse-cron.service';

@Module({
  imports: [ConfigModule],
  exports: [
    'WAREHOUSE_SERVICE_CLIENT',
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'WAREHOUSE_SERVICE_CLIENT',
      useFactory: (configService: ConfigService) => {
        const warehouseServiceOptions = configService.get('warehouseService');
        return ClientProxyFactory.create(warehouseServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    WarehouseCronService,
  ],
  controllers: [],
})
export class WarehouseModule {}
