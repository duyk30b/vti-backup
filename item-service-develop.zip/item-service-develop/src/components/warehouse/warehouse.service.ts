import { Inject, Injectable } from '@nestjs/common';
import { WarehouseServiceInterface } from './interface/warehouse.service.interface';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ClientProxy } from '@nestjs/microservices';
import { GetWarehouseLocationRequest } from './dto/request/get-warehouse-location.request.dto';
import { REQUEST } from '@nestjs/core';
import { isEmpty, first, uniq, map, flatMap, keyBy } from 'lodash';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { PaginationQuery } from '@utils/pagination.query';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { GetListItemInventoryRequestDto } from './dto/request/get-list-item-inventory.request.dto';
import { GetListWarehouseByIsGetAll } from './warehouse.constant';
import { GetWarehouseStockMovementImportRequestDto } from './dto/request/get-warehouse-stock-movement-import.request.dto';
@Injectable()
export class WarehouseService implements WarehouseServiceInterface {
  constructor(
    private readonly i18n: I18nRequestScopeService,

    @Inject(REQUEST) private readonly req: any,

    @InjectDataSource()
    private readonly connection: DataSource,

    @Inject('WAREHOUSE_SERVICE_CLIENT')
    private readonly warehouseServiceClient: ClientProxy,
  ) {}

  async getListByIDs(
    ids: number[],
    serilize?: boolean,
    relation?: string[],
  ): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('get_warehouses_by_ids', { warehouseIds: ids, relation })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    const serilizeWarehouses = {};
    if (serilize) {
      response.data.forEach((warehouse) => {
        serilizeWarehouses[warehouse.id] = warehouse;
      });

      return serilizeWarehouses;
    }

    return response.data;
  }

  async getTransferDetaild(
    id: number,
    transferType?: number,
    warehouseShelfFloorId?: number,
  ): Promise<any> {
    const userId = await this.req['user']?.id;
    const request = { id: id, userId } as any;
    if (transferType) {
      request.type = transferType;
    }

    if (warehouseShelfFloorId) {
      request.warehouseShelfFloorId = warehouseShelfFloorId;
    }

    const response = await this.warehouseServiceClient
      .send('get_transfer', request)
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return null;
    }

    return response.data;
  }

  async suggestTransferDetaild(
    id: number,
    transferType: number,
    itemId: number,
  ): Promise<any> {
    const userId = await this.req['user']?.id;
    const request = {
      warehouseTransferId: +id,
      type: +transferType,
      itemId: +itemId,
      userId,
    } as any;

    const response = await this.warehouseServiceClient
      .send('suggest_action_by_item', request)
      .toPromise();

    return response;
  }

  async getFloorByIds(floorIds: number[]): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('list_warehouse_floor_by_ids', { ids: floorIds })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return null;
    }

    return response.data;
  }

  async getWarehouseDetail(warehouseId: number, userId: number): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('detail', { id: warehouseId, userId: userId })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return null;
    }

    return response.data;
  }

  async getMovementDetail(id: number): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('get_floor_by_ids', { id })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return null;
    }

    return response.data;
  }

  async getWarehouseSectorDetail(
    warehouseSectorId: number,
    userId: number,
  ): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('detail_sector', { id: warehouseSectorId, userId: userId })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return null;
    }

    return response.data;
  }

  async getWarehouseShelfFloorDetail(
    warehouseShelfFloorId: number,
    userId: number,
  ): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('detail_warehouse_floor', {
        id: warehouseShelfFloorId,
        userId: userId,
      })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return null;
    }

    return response.data;
  }

  async getWarehouseShelfDetail(
    warehouseShelfId: number,
    userId: number,
  ): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('detail_warehouse_shelf', { id: warehouseShelfId, userId: userId })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return null;
    }

    return response.data;
  }

  async getWarehouseLocation(
    request: GetWarehouseLocationRequest,
  ): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('get_warehouse_location', request)
      .toPromise();

    return response;
  }

  /**
   *
   * @param request
   * @returns
   */
  async getWarehouseLocationByWarehouseId(
    request: GetWarehouseLocationRequest,
  ): Promise<any> {
    const response: any = await this.warehouseServiceClient
      .send('get_warehouse_location', request)
      .toPromise();
    if (isEmpty(response.data)) return null;
    const data: any = first(response.data);

    return {
      id: data.id,
      code: data.code,
      name: data.name,
      long: data.long,
      width: data.width,
      height: data.height,
      warehouseSectors: this.serializeWarehouseLocation(data.warehouseSectors),
    };
  }

  async getWarehousesByFactory(request: any): Promise<any> {
    const response: any = await this.warehouseServiceClient
      .send('get_warehouse_factory', request)
      .toPromise();
    if (isEmpty(response.data)) return null;
    return response.data;
  }

  async getWarehousesByCodes(warehouseCodes: string[]): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('get_warehouse_by_codes', { warehouseCodes: warehouseCodes })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  serializeWarehouseLocation = (warehouseDesignSectors): any => {
    const warehouseSectors = {};
    warehouseDesignSectors.forEach((warehouseSector) => {
      const warehouseShelfs = {};

      warehouseSector.warehouseShelfs.forEach((warehouseShelf) => {
        const warehouseShelfFloors = {};

        warehouseShelf.warehouseShelfFloors.forEach((warehouseShelfFloor) => {
          warehouseShelfFloors[warehouseShelfFloor.id] = {
            id: warehouseShelfFloor.id,
            code: warehouseShelfFloor.code,
            name: warehouseShelfFloor.name,
          };
        });

        warehouseShelfs[warehouseShelf.id] = {
          id: warehouseShelf.id,
          code: warehouseShelf.code,
          name: warehouseShelf.name,
          warehouseShelfFloors: warehouseShelfFloors,
        };
      });
      warehouseSectors[warehouseSector.id] = {
        id: warehouseSector.id,
        code: warehouseSector.code,
        name: warehouseSector.name,
        warehouseShelfs: warehouseShelfs,
      };
    });

    return warehouseSectors;
  };

  async getWarehouseByNameKeyword(
    filterByName,
    onlyId?: boolean,
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('get_warehouse_by_name_keyword', {
        nameKeyword: filterByName.text,
      })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    if (!isEmpty(response.data) && onlyId === true) {
      return uniq(map(flatMap(response.data), 'id'));
    }

    if (serilize) {
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
      const serilizeWarehouses = [];
      response.data.forEach((warehouse) => {
        serilizeWarehouses[warehouse.id] = warehouse;
      });

      return serilizeWarehouses;
    }

    return response.data;
  }

  async getWarehouseSectorByNameKeyword(
    filterByName,
    onlyId?: boolean,
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('get_warehouse_sector_by_name_keyword', {
        nameKeyword: filterByName.text,
      })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    if (!isEmpty(response.data) && onlyId === true) {
      return uniq(map(flatMap(response.data), 'id'));
    }

    if (serilize) {
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
      const serilizeWarehouseSectors = keyBy(response.data, 'id');
      return serilizeWarehouseSectors;
    }

    return response.data;
  }
  async getWarehouseShelfByNameKeyword(
    filterByName,
    onlyId?: boolean,
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('get_warehouse_shelf_by_name_keyword', {
        nameKeyword: filterByName.text,
      })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    if (!isEmpty(response.data) && onlyId === true) {
      return uniq(map(flatMap(response.data), 'id'));
    }

    if (serilize) {
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
      const serilizeWarehouseShelfs = keyBy(response.data, 'id');
      return serilizeWarehouseShelfs;
    }

    return response.data;
  }

  async getWarehouseShelfFloorByNameKeyword(
    filterByName,
    onlyId?: boolean,
    serilize?: boolean,
  ): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('get_warehouse_shelf_floor_by_name_keyword', {
        nameKeyword: filterByName.text,
      })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    if (!isEmpty(response.data) && onlyId === true) {
      return uniq(map(flatMap(response.data), 'id'));
    }

    if (serilize) {
      if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];
      const serilizeWarehouseShelfFloors = keyBy(response.data, 'id');
      return serilizeWarehouseShelfFloors;
    }

    return response.data;
  }

  /**
   * getWarehouseShelfFloorByWarehouseIds
   * @param warehouseIds
   * @returns
   */
  public async getWarehouseShelfFloorByWarehouseIds(
    warehouseIds: number[],
    onlyId?: boolean,
  ): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('get_warehouse_shelf_floor_by_warehouse_ids', {
        warehouseIds: warehouseIds,
      })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    if (!isEmpty(response.data) && onlyId === true) {
      return uniq(map(response.data, 'id'));
    }

    return response.data;
  }

  public async getListFloor(request: PaginationQuery): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('list_warehouse_floor', {
        ...request,
        isGetAll: '1',
      })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data.items;
  }

  public async getListItemInventory(
    request: GetListItemInventoryRequestDto,
  ): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('get_list_item_inventory', {
        ...request,
        isGetAll: GetListWarehouseByIsGetAll,
      })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data.items;
  }

  async getListByCodes(codes: string[], serilize?: boolean): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('get_warehouse_by_codes', { warehouseCodes: codes })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    const serilizeWarehouses = {};
    if (serilize) {
      response.data.forEach((warehouse) => {
        serilizeWarehouses[warehouse.id] = warehouse;
      });

      return serilizeWarehouses;
    }

    return response.data;
  }
  public async getWarehouseStockMovementImport(
    request: GetWarehouseStockMovementImportRequestDto,
  ): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('get_warehouse_stock_movement_import', request)
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response?.data?.warehouseStockMovementIds;
  }

  async getMovementByIds(ids: number[]): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('get_movement_by_ids', { ids })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getWarehouseByCode(warehouseCode: string) {
    const response = await this.warehouseServiceClient
      .send('get_warehose_id_by_code', { warehouseCode })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }

    return response.data;
  }

  async getInventoryTimeLimitByWarehouseId(warehouseId: number): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('get_inventory_time_limit_by_warehouse', { warehouseId })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return null;
    }

    return response.data;
  }

  async getListWarehouseTransferOpenTransaction(request: any): Promise<any> {
    try {
      const response = await this.warehouseServiceClient
        .send('get_list_warehouse_transfer_open_transaction', { request })
        .toPromise();

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return null;
      }

      return response.data;
    } catch (error) {
      console.error('Get open transaction warehouse transfer error: ', error);
      return null;
    }
  }

  async getListInventoryAdjustmentOpenTransaction(request: any): Promise<any> {
    try {
      const response = await this.warehouseServiceClient
        .send('get_list_inventory_adjustment_open_transaction', { request })
        .toPromise();

      if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
        return null;
      }

      return response.data;
    } catch (error) {
      console.error('Get open transaction warehouse transfer error: ', error);
      return null;
    }
  }

  async getWarehouseTransferByIds(ids: number[]): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('get_warehouse_transfer_by_ids', { ids })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }

  async getProposalByIds(ids: number[]): Promise<any> {
    const response = await this.warehouseServiceClient
      .send('get_warehouse_export_proposal_by_ids', { ids })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return [];
    }
    return response.data;
  }
}
