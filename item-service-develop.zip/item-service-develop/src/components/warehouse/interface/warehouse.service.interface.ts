import { PaginationQuery } from '@utils/pagination.query';
import { GetListItemInventoryRequestDto } from '../dto/request/get-list-item-inventory.request.dto';
import { GetWarehouseLocationRequest } from '../dto/request/get-warehouse-location.request.dto';
import { GetWarehouseStockMovementImportRequestDto } from '../dto/request/get-warehouse-stock-movement-import.request.dto';

export interface WarehouseServiceInterface {
  getListByIDs(
    ids: number[],
    serilize?: boolean,
    relation?: string[],
  ): Promise<any>;
  getTransferDetaild(
    id: number,
    transferType?: number,
    warehouseShelfFloorId?: number,
  ): Promise<any>;
  suggestTransferDetaild(
    id: number,
    transferType: number,
    itemId: number,
  ): Promise<any>;
  getFloorByIds(floorIds: number[]): Promise<any>;
  getMovementDetail(id: number): Promise<any>;
  getWarehouseDetail(warehouseId: number, userId: number): Promise<any>;
  getWarehouseShelfDetail(
    warehouseShelfId: number,
    userId: number,
  ): Promise<any>;
  getWarehouseSectorDetail(
    warehouseSectorId: number,
    userId: number,
  ): Promise<any>;
  getWarehouseShelfFloorDetail(
    warehouseShelfFloorId: number,
    userId: number,
  ): Promise<any>;
  getWarehouseLocation(request: GetWarehouseLocationRequest): Promise<any>;
  getWarehouseLocationByWarehouseId(
    request: GetWarehouseLocationRequest,
  ): Promise<any>;
  serializeWarehouseLocation(warehouseLocation: any): Promise<any>;
  getWarehousesByFactory(factoryId: number): Promise<any>;
  getWarehousesByCodes(warehouseCodes: string[]): Promise<any>;
  getWarehouseByNameKeyword(
    filterByName,
    onlyId?: boolean,
    serilize?: boolean,
  ): Promise<any>;
  getWarehouseSectorByNameKeyword(
    filterByName,
    onlyId?: boolean,
    serilize?: boolean,
  ): Promise<any>;
  getWarehouseShelfByNameKeyword(
    filterByName,
    onlyId?: boolean,
    serilize?: boolean,
  ): Promise<any>;
  getWarehouseShelfFloorByNameKeyword(
    filterByName,
    onlyId?: boolean,
    serilize?: boolean,
  ): Promise<any>;
  getWarehouseShelfFloorByWarehouseIds(
    warehouseIds: number[],
    onlyId?: boolean,
  ): Promise<any>;
  getListFloor(request: PaginationQuery): Promise<any>;
  getListItemInventory(request: GetListItemInventoryRequestDto): Promise<any>;
  getListByCodes(codes: string[], serilize?: boolean): Promise<any>;
  getWarehouseStockMovementImport(
    request: GetWarehouseStockMovementImportRequestDto,
  ): Promise<any>;
  getMovementByIds(ids: number[]): Promise<any>;
  getWarehouseByCode(warehouseCode: string): Promise<any>;
  getInventoryTimeLimitByWarehouseId(warehouseId: number): Promise<any>;
  getListWarehouseTransferOpenTransaction(request: any): Promise<any>;
  getListInventoryAdjustmentOpenTransaction(request: any): Promise<any>;
  getWarehouseTransferByIds(ids: number[]): Promise<any>;
  getProposalByIds(ids: number[]): Promise<any>;
}
