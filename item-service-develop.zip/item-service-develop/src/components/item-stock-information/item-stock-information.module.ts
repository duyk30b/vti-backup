import { ItemStockWarehouseLocatorRepository } from './../../repositories/item-stock-warehouse-locator.repository';
import { ItemStockWarehouseLocatorEntity } from '@entities/item/item-stock-warehouse-locator.entity';
import { ItemStockWarehouseLocatorHistoryRepository } from './../../repositories/item-stock-warehouse-locator-history.repository';
import { ItemStockInformationEntity } from './../../entities/item/item-stock-information.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from '@nestjs/config';
import { ItemStockInformationService } from './item-stock-information.service';
import { ItemStockInformationController } from './item-stock-information.controller';
import { ItemStockInformationRepository } from '@repositories/item-stock-information.repository';

@Module({
  imports: [
    ConfigModule,
    TypeOrmModule.forFeature([
      ItemStockInformationEntity,
      ItemStockWarehouseLocatorEntity,
    ]),
  ],
  exports: [],
  providers: [
    {
      provide: 'ItemStockInformationServiceInterface',
      useClass: ItemStockInformationService,
    },
    {
      provide: 'ItemStockInformationRepositoryInterface',
      useClass: ItemStockInformationRepository,
    },
    {
      provide: 'ItemStockWarehouseLocatorRepositoryInterface',
      useClass: ItemStockWarehouseLocatorRepository,
    },
  ],
  controllers: [ItemStockInformationController],
})
export class ItemStockInformationModule {}
