import { WarehouseLayoutModule } from '@components/warehouse-layout/warehouse-layout.module';
import { ItemStockWarehouseLocatorEntity } from '@entities/item/item-stock-warehouse-locator.entity';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ItemStockInformationRepository } from '@repositories/item-stock-information.repository';
import { ItemStockInformationEntity } from './../../entities/item/item-stock-information.entity';
import { ItemStockWarehouseLocatorRepository } from './../../repositories/item-stock-warehouse-locator.repository';
import { ItemStockInformationController } from './item-stock-information.controller';
import { ItemStockInformationService } from './item-stock-information.service';

@Module({
  imports: [
    ConfigModule,
    TypeOrmModule.forFeature([
      ItemStockInformationEntity,
      ItemStockWarehouseLocatorEntity,
    ]),
    WarehouseLayoutModule,
  ],
  exports: [],
  providers: [
    {
      provide: 'ItemStockInformationServiceInterface',
      useClass: ItemStockInformationService,
    },
    {
      provide: 'ItemStockInformationRepositoryInterface',
      useClass: ItemStockInformationRepository,
    },
    {
      provide: 'ItemStockWarehouseLocatorRepositoryInterface',
      useClass: ItemStockWarehouseLocatorRepository,
    },
  ],
  controllers: [ItemStockInformationController],
})
export class ItemStockInformationModule {}
