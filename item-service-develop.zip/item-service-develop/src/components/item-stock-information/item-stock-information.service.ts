import { plainToInstance } from 'class-transformer';
import { ApiError } from '@utils/api.error';
import { ItemStockWarehouseLocatorRepositoryInterface } from '@components/item/interface/item-stock-warehouse-locator.repository.interface';
import { isEmpty } from 'lodash';
import { ItemStockInformationRepositoryInterface } from '@components/item-stock-information/interface/item-stock-information.repository.interface';
import { CreateItemStockInformationRequestDto } from './dto/request/create-item-stock-information.request.dto';
import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, ILike, IsNull } from 'typeorm';
import { ItemStockInformationServiceInterface } from './interface/item-stock-information.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ResponseBuilder } from '@utils/response-builder';

@Injectable()
export class ItemStockInformationService
  implements ItemStockInformationServiceInterface
{
  constructor(
    @Inject('ItemStockInformationRepositoryInterface')
    private readonly itemStockInformationRepository: ItemStockInformationRepositoryInterface,

    @Inject('ItemStockWarehouseLocatorRepositoryInterface')
    private readonly itemStockWarehouseLocatorRepository: ItemStockWarehouseLocatorRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,

    @InjectDataSource()
    private readonly connection: DataSource,
  ) {}

  async save(request: CreateItemStockInformationRequestDto): Promise<any> {
    const { itemId, locatorId, warehouseId, lotNumber } = request;
    const condition = {
      itemId,
      warehouseId,
      locatorId,
      lotNumber: lotNumber ? ILike(lotNumber) : IsNull(),
    };
    const itemStockInfo =
      await this.itemStockInformationRepository.findByCondition(condition);
    if (isEmpty(itemStockInfo)) {
      const itemStock =
        await this.itemStockWarehouseLocatorRepository.findByCondition(
          condition,
        );
      if (isEmpty(itemStock)) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }
    }

    const entity = isEmpty(itemStockInfo)
      ? await this.itemStockInformationRepository.createEntity(request)
      : await this.itemStockInformationRepository.updateEntity(
        request,
        itemStockInfo,
      );

    await this.itemStockInformationRepository.create(entity);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
