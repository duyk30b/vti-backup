import { ItemStockInformationRepositoryInterface } from '@components/item-stock-information/interface/item-stock-information.repository.interface';
import { ItemStockWarehouseLocatorRepositoryInterface } from '@components/item/interface/item-stock-warehouse-locator.repository.interface';
import { WarehouseLayoutServiceInterface } from '@components/warehouse-layout/interface/warehouse-layout.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { ResponseBuilder } from '@utils/response-builder';
import { isEmpty, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ILike, IsNull } from 'typeorm';
import { CreateItemStockInformationRequestDto } from './dto/request/create-item-stock-information.request.dto';
import { GetListLocatorByExportStockDto } from './dto/request/get-list-locator-by-export-stock.request';
import { GetListLocatorByImportStockDto } from './dto/request/get-list-locator-by-import-stock.request';
import { ItemStockInformationServiceInterface } from './interface/item-stock-information.service.interface';
import { PICK_ITEM_METHOD } from './item-stock-information.constant';
@Injectable()
export class ItemStockInformationService
  implements ItemStockInformationServiceInterface
{
  constructor(
    @Inject('ItemStockInformationRepositoryInterface')
    private readonly itemStockInformationRepository: ItemStockInformationRepositoryInterface,

    @Inject('ItemStockWarehouseLocatorRepositoryInterface')
    private readonly itemStockWarehouseLocatorRepository: ItemStockWarehouseLocatorRepositoryInterface,

    @Inject('WarehouseLayoutServiceInterface')
    private readonly warehouseLayoutService: WarehouseLayoutServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async getListLocatorByExportStock(request: GetListLocatorByExportStockDto) {
    const sort: Record<string, 'ASC' | 'DESC'> = {};

    if (request.pickItemMethod === PICK_ITEM_METHOD.FIFO) {
      sort.storageDate = 'ASC';
    } else if (request.pickItemMethod === PICK_ITEM_METHOD.FEFO) {
      sort.mfg = 'ASC';
    }

    const itemStock =
      await this.itemStockWarehouseLocatorRepository.findAdvance({
        where: {
          itemId: request.itemId,
          lotNumber: request.lotNumber,
          warehouseId: request.warehouseId,
          mfg: request.mfg,
          storageDate: request.storageDate,
        },
        sort,
      });

    const locatorIds = uniq(itemStock.map((i) => i.ticketLocatorId));
    const locators = await this.warehouseLayoutService.getLocators({
      ids: locatorIds,
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(locators)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getListLocatorByImportStock(request: GetListLocatorByImportStockDto) {
    const itemStock =
      await this.itemStockWarehouseLocatorRepository.findAdvance({
        where: {
          itemId: request.itemId,
          warehouseId: request.warehouseId,
        },
        sort: { quantity: 'DESC' },
      });

    // tao map de giu sap xep
    const locatorMapHasStock: Record<string, any> = {};
    itemStock.forEach((item) => {
      if (locatorMapHasStock[item.ticketLocatorId] === undefined) {
        locatorMapHasStock[item.ticketLocatorId] = 'temp';
      }
    });

    const locatorAll = await this.warehouseLayoutService.getLocators({
      warehouseId: request.warehouseId,
    });

    // sort
    const locatorArrNoStock = [];
    locatorAll.forEach((locator) => {
      if (locatorMapHasStock[locator.id] === 'temp') {
        locatorMapHasStock[locator.id] = locator;
      } else {
        locatorArrNoStock.push(locator);
      }
    });
    const locatorArrHasStock = Object.values(locatorMapHasStock);

    const result = [...locatorArrHasStock, ...locatorArrNoStock];

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(result)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async save(request: CreateItemStockInformationRequestDto): Promise<any> {
    const { itemId, locatorId, warehouseId, lotNumber } = request;
    const condition = {
      itemId,
      warehouseId,
      locatorId,
      lotNumber: lotNumber ? ILike(lotNumber) : IsNull(),
    };
    const itemStockInfo =
      await this.itemStockInformationRepository.findByCondition(condition);
    if (isEmpty(itemStockInfo)) {
      const itemStock =
        await this.itemStockWarehouseLocatorRepository.findByCondition(
          condition,
        );
      if (isEmpty(itemStock)) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }
    }

    const entity = isEmpty(itemStockInfo)
      ? await this.itemStockInformationRepository.createEntity(request)
      : await this.itemStockInformationRepository.updateEntity(
          request,
          itemStockInfo,
        );

    await this.itemStockInformationRepository.create(entity);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
