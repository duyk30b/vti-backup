import { CreateItemStockInformationRequestDto } from './dto/request/create-item-stock-information.request.dto';
import { isEmpty } from 'lodash';
import { Body, Controller, Inject, Post } from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { ItemStockInformationResponseDto } from './dto/response/item-stock-information.response.dto';
import { ItemStockInformationServiceInterface } from './interface/item-stock-information.service.interface';

@Controller('item-stock-information')
export class ItemStockInformationController {
  constructor(
    @Inject('ItemStockInformationServiceInterface')
    private readonly itemStockInformationService: ItemStockInformationServiceInterface,
  ) {}

  @Post('save')
  @ApiOperation({
    tags: ['Item Stock Information'],
    summary: 'Item Stock Information',
    description: 'Create Item Stock Information',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: ItemStockInformationResponseDto,
  })
  public async save(
    @Body() body: CreateItemStockInformationRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemStockInformationService.save(request);
  }
}
