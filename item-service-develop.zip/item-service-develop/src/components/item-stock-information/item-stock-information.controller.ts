import { Body, Controller, Get, Inject, Post, Query } from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { isEmpty } from 'lodash';
import { CreateItemStockInformationRequestDto } from './dto/request/create-item-stock-information.request.dto';
import { GetListLocatorByExportStockDto } from './dto/request/get-list-locator-by-export-stock.request';
import { GetListLocatorByImportStockDto } from './dto/request/get-list-locator-by-import-stock.request';
import { ItemStockInformationResponseDto } from './dto/response/item-stock-information.response.dto';
import { ItemStockInformationServiceInterface } from './interface/item-stock-information.service.interface';

@Controller('item-stock-information')
@ApiTags('Item Stock Information')
@ApiBearerAuth('access-token')
export class ItemStockInformationController {
  constructor(
    @Inject('ItemStockInformationServiceInterface')
    private readonly itemStockInformationService: ItemStockInformationServiceInterface,
  ) {}

  @Get('/list-locator-export')
  @ApiOperation({
    summary: 'List Locator By Export Item Stock',
    description: 'Danh sách vị trí xuat theo item',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
  })
  public async getListLocatorByExportStock(
    @Query() payload: GetListLocatorByExportStockDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemStockInformationService.getListLocatorByExportStock(
      request,
    );
  }

  @Get('/list-locator-import')
  @ApiOperation({
    summary: 'List Locator By Import Item Stock',
    description: 'Danh sách vị trí nhap theo item',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
  })
  public async getListLocatorByImportStock(
    @Query() payload: GetListLocatorByImportStockDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemStockInformationService.getListLocatorByImportStock(
      request,
    );
  }

  @Post('save')
  @ApiOperation({
    tags: ['Item Stock Information'],
    summary: 'Item Stock Information',
    description: 'Create Item Stock Information',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: ItemStockInformationResponseDto,
  })
  public async save(
    @Body() body: CreateItemStockInformationRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemStockInformationService.save(request);
  }
}
