import { CreateItemStockInformationRequestDto } from './../dto/request/create-item-stock-information.request.dto';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ItemStockInformationEntity } from '@entities/item/item-stock-information.entity';
import { ReportItemStockConstructionScl } from '@components/dashboard/dto/request/report-item-stock-construction-scl.request.dto';

export interface ItemStockInformationRepositoryInterface
  extends BaseInterfaceRepository<ItemStockInformationEntity> {
  createEntity(
    request: CreateItemStockInformationRequestDto,
  ): ItemStockInformationEntity;

  updateEntity(
    request: CreateItemStockInformationRequestDto,
    entity: ItemStockInformationEntity,
  ): ItemStockInformationEntity;
  getListItemStockInformationWithScl(
    request: ReportItemStockConstructionScl,
  ): Promise<any>;
}
