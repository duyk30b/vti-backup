import { CreateItemStockInformationRequestDto } from '../dto/request/create-item-stock-information.request.dto';
import { GetListLocatorByExportStockDto } from '../dto/request/get-list-locator-by-export-stock.request';
import { GetListLocatorByImportStockDto } from '../dto/request/get-list-locator-by-import-stock.request';

export interface ItemStockInformationServiceInterface {
  save(request: CreateItemStockInformationRequestDto): Promise<any>;
  getListLocatorByExportStock(
    request: GetListLocatorByExportStockDto,
  ): Promise<any>;
  getListLocatorByImportStock(
    request: GetListLocatorByImportStockDto,
  ): Promise<any>;
}
