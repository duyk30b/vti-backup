import { CreateItemStockInformationRequestDto } from '../dto/request/create-item-stock-information.request.dto';

export interface ItemStockInformationServiceInterface {
  save(request: CreateItemStockInformationRequestDto): Promise<any>;
}
