import { PICK_ITEM_METHOD } from '@components/item-stock-information/item-stock-information.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsNumber, IsPositive } from 'class-validator';

export class GetListLocatorByExportStockDto extends BaseDto {
  @ApiProperty({ example: 5 })
  @Expose()
  itemId: number;

  @ApiPropertyOptional({ example: '' })
  @Expose()
  lotNumber: string;

  @ApiPropertyOptional({ example: 27 })
  @Expose()
  @Type(() => Number)
  @IsPositive()
  warehouseId: number;

  @ApiPropertyOptional({})
  @Expose()
  mfg: Date;

  @ApiPropertyOptional({})
  @Expose()
  storageDate: Date;

  @ApiPropertyOptional({
    enum: PICK_ITEM_METHOD,
    example: PICK_ITEM_METHOD.FIFO,
  })
  @Expose()
  pickItemMethod: PICK_ITEM_METHOD;
}
