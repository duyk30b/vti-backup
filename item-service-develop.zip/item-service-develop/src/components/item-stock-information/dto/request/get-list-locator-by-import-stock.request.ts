import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { IsPositive } from 'class-validator';

export class GetListLocatorByImportStockDto extends BaseDto {
  @ApiProperty({ example: 5 })
  @Expose()
  itemId: number;

  @ApiPropertyOptional({ example: 27 })
  @Expose()
  @Type(() => Number)
  @IsPositive()
  warehouseId: number;
}
