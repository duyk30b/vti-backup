import { Expose } from 'class-transformer';

export class ItemStockInformationResponseDto {
  @Expose()
  itemId: number;

  @Expose()
  warehouseId: number;

  @Expose()
  locatorId: number;

  @Expose()
  lotNumber: string;

  @Expose()
  type: string;

  @Expose()
  purpose: string;
}
