export const PREFIX_TYPE = 'SCL';
