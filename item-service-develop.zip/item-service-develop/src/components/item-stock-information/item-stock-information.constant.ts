export const PREFIX_TYPE = 'SCL';

export enum PICK_ITEM_METHOD {
  FIFO = 'FIFO',
  FEFO = 'FEFO',
}
