export enum StatusObjectCategoryEnum {
  INACTIVE = 0,
  ACTIVE = 1,
}

export const CAN_CONFIRM_OBJECT_CATEGORY_STATUS = [
  StatusObjectCategoryEnum.INACTIVE,
];

export const CAN_REJECT_OBJECT_CATEGORY_STATUS = [
  StatusObjectCategoryEnum.ACTIVE,
];

export const RULES_OBJECT_CATEGORIES = {
  NAME: {
    MAX_LENGTH: 255,
    MIN_LENGTH: 2,
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
  CODE: {
    MAX_LENGTH: 3,
    MIN_LENGTH: 3,
  },
};

export enum EventSyncObjectCategoryEnum {
  Create = 'event.syncObjectCategory.create',
  Update = 'event.syncObjectCategory.update',
  Confirm = 'event.syncObjectCategory.confirm',
  Reject = 'event.syncObjectCategory.reject',
  Delete = 'event.syncObjectCategory.delete',
}
