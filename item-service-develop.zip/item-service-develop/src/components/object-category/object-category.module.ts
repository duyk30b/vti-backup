import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { ObjectCategoryEntity } from '@entities/object-category/object-category.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ObjectCategoryRepository } from '@repositories/object-category.repository';
import { ObjectCategoryController } from './object-category.controller';
import { ObjectCategoryService } from './object-category.service';

@Module({
  imports: [TypeOrmModule.forFeature([ObjectCategoryEntity]), UserModule],
  providers: [
    {
      provide: 'ObjectCategoryRepositoryInterface',
      useClass: ObjectCategoryRepository,
    },
    {
      provide: 'ObjectCategoryServiceInterface',
      useClass: ObjectCategoryService,
    },

    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
  ],
  controllers: [ObjectCategoryController],
})
export class ObjectCategoryModule {}
