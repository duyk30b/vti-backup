import { DetailObjectCategoryRequestDto } from './dto/request/detail-object-category.request.dto';
import { plainToInstance } from 'class-transformer';
import { UpdateObjectCategoryRequestDto } from './dto/request/update-object-category.rquest.dto';
import { CreateObjectCategoryRequestDto } from './dto/request/create-object-category.request.dto';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nService } from 'nestjs-i18n';
import { ObjectCategoryServiceInterface } from './interface/object-category.service.interface';
import { ObjectCategoryResponseDto } from './dto/response/object-category.response.dto';
import { ApiError } from '@utils/api.error';
import { GetListObjectCategoryRequestDto } from './dto/request/get-list-object-category.request.dto';
import { PagingResponse } from '@utils/paging.response';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { isEmpty, map, uniq } from 'lodash';
import { UserResponseDto } from './dto/response/user.response.dto';
import { ResponsePayload } from '@utils/response-payload';
import { ILike, In, Not } from 'typeorm';
import {
  CAN_CONFIRM_OBJECT_CATEGORY_STATUS,
  CAN_REJECT_OBJECT_CATEGORY_STATUS,
  StatusObjectCategoryEnum,
} from './object-category.constants';
import { ObjectCategoryRepositoryInterface } from './interface/object-category.repository.interface';
import { GetObjectCategoriesRequestDto } from './dto/request/get-object-category-by-ids.request.dto';
import { ObjectCategoryEntity } from '@entities/object-category/object-category.entity';

@Injectable()
export class ObjectCategoryService implements ObjectCategoryServiceInterface {
  constructor(
    @Inject('ObjectCategoryRepositoryInterface')
    private readonly objectCategoryRepository: ObjectCategoryRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    private readonly i18n: I18nService,
  ) {}

  async create(request: CreateObjectCategoryRequestDto): Promise<any> {
    const { code, name } = request;
    const objectCategoryExist =
      await this.objectCategoryRepository.findByCondition([
        {
          code: ILike(code),
        },
      ]);
    if (objectCategoryExist) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CODE_OR_NAME_IS_EXISTED'),
      ).toResponse();
    }
    const objectCategoryEntity =
      this.objectCategoryRepository.createEntity(request);

    const data = await this.objectCategoryRepository.create(
      objectCategoryEntity,
    );

    const response = plainToInstance(ObjectCategoryResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withMessage(
        await this.i18n.translate('message.defineObjectCategory.createSuccess'),
      )
      .build();
  }

  public async update(request: UpdateObjectCategoryRequestDto): Promise<any> {
    const objectCategory = await this.objectCategoryRepository.findOneById(
      request.id,
    );
    if (!objectCategory) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const isExistObjectCategory =
      await this.objectCategoryRepository.findByCondition([
        {
          name: request.name,
          id: Not(request.id),
        },
      ]);
    if (isExistObjectCategory) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.NAME_IS_EXISTED'),
      ).toResponse();
    }

    const result = this.objectCategoryRepository.updateEntity(
      objectCategory,
      request,
    );
    const dataReturn = await this.objectCategoryRepository.create(result);

    const response = plainToInstance(ObjectCategoryResponseDto, dataReturn, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(
        await this.i18n.translate('message.defineObjectCategory.updateSuccess'),
      )
      .build();
  }

  public async getList(request: GetListObjectCategoryRequestDto): Promise<any> {
    const { result, count } = await this.objectCategoryRepository.getList(
      request,
    );
    const userIds = uniq(map(result, 'createdBy'));
    if (!isEmpty(userIds)) {
      const userResponse = await this.userService.getUsers(userIds, true);
      result.forEach((user) => {
        user.createdBy = userResponse[user.createdBy];
      });
    }

    const response = plainToInstance(ObjectCategoryResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async detail(request: DetailObjectCategoryRequestDto): Promise<any> {
    const objectCategory = await this.objectCategoryRepository.detail(request);
    if (!objectCategory) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const userIds = [objectCategory.createdBy, objectCategory.updatedBy];
    if (!isEmpty(userIds)) {
      const userResponse = await this.userService.getUsers(userIds, true);
      objectCategory.createdBy = plainToInstance(
        UserResponseDto,
        userResponse[objectCategory.createdBy]
          ? userResponse[objectCategory.createdBy]
          : {},
      );
      objectCategory.updatedBy = plainToInstance(
        UserResponseDto,
        userResponse[objectCategory.updatedBy]
          ? userResponse[objectCategory.updatedBy]
          : {},
        { excludeExtraneousValues: true },
      );
    }
    const response = plainToInstance(
      ObjectCategoryResponseDto,
      objectCategory,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  public async delete(
    request: DetailObjectCategoryRequestDto,
  ): Promise<ResponsePayload<any>> {
    const objectCategory = await this.objectCategoryRepository.findByCondition({
      id: request.id,
      deletedAt: null,
    });
    if (!objectCategory) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    try {
      objectCategory.deletedAt = new Date();
      objectCategory.deletedBy = request.userId;
      await this.objectCategoryRepository.create(objectCategory);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            'message.defineObjectCategory.deleteSuccess',
          ),
        )
        .build();
    } catch (error) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_DELETE'),
      ).toResponse();
    }
  }

  public async confirm(
    request: DetailObjectCategoryRequestDto,
  ): Promise<ResponsePayload<any>> {
    const objectCategory = await this.objectCategoryRepository.findByCondition({
      id: request.id,
      deletedAt: null,
    });
    if (!objectCategory) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CAN_CONFIRM_OBJECT_CATEGORY_STATUS.includes(objectCategory.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CONFIRM'))
        .build();
    }

    try {
      objectCategory.status = StatusObjectCategoryEnum.ACTIVE;
      await this.objectCategoryRepository.create(objectCategory);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            'message.defineObjectCategory.confirmSuccess',
          ),
        )
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CONFIRM'))
        .build();
    }
  }

  public async reject(
    request: DetailObjectCategoryRequestDto,
  ): Promise<ResponsePayload<any>> {
    const objectCategory = await this.objectCategoryRepository.findByCondition({
      id: request.id,
      deletedAt: null,
    });
    if (!objectCategory) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CAN_REJECT_OBJECT_CATEGORY_STATUS.includes(objectCategory.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_REJECT'))
        .build();
    }

    try {
      objectCategory.status = StatusObjectCategoryEnum.INACTIVE;
      await this.objectCategoryRepository.create(objectCategory);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            'message.defineObjectCategory.rejectSuccess',
          ),
        )
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_REJECT'))
        .build();
    }
  }

  public async getObjectCategoryByIds(
    request: GetObjectCategoriesRequestDto,
  ): Promise<ObjectCategoryEntity[] | ResponsePayload<any>> {
    const result = await this.objectCategoryRepository.findAllByCondition({
      id: In(request.objectCategoryIds),
    });
    const response = plainToInstance(ObjectCategoryResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }
}
