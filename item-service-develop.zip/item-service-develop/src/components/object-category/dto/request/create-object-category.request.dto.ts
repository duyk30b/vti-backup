import { IsString, MaxLength, IsOptional, MinLength } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {} from 'class-transformer';
import { RULES_OBJECT_CATEGORIES } from '@components/object-category/object-category.constants';

export class CreateObjectCategoryRequestDto extends BaseDto {
  @ApiProperty({ example: 'name: Đối tượng A' })
  @IsString()
  @MaxLength(RULES_OBJECT_CATEGORIES.NAME.MAX_LENGTH)
  @MinLength(RULES_OBJECT_CATEGORIES.NAME.MIN_LENGTH)
  name: string;

  @ApiProperty({ example: 'code:1111' })
  @IsString()
  @MaxLength(RULES_OBJECT_CATEGORIES.CODE.MAX_LENGTH)
  @MinLength(RULES_OBJECT_CATEGORIES.CODE.MIN_LENGTH)
  code: string;

  @ApiPropertyOptional({ example: 'description:abc' })
  @IsString()
  @IsOptional()
  @MaxLength(RULES_OBJECT_CATEGORIES.DESCRIPTION.MAX_LENGTH)
  description: string;
}
