import { ApiProperty } from '@nestjs/swagger';
import { IsInt } from 'class-validator';
import { Transform } from 'class-transformer';
import { CreateObjectCategoryRequestDto } from './create-object-category.request.dto';
export class UpdateObjectCategoryBodyDto extends CreateObjectCategoryRequestDto {}
export class UpdateObjectCategoryRequestDto extends UpdateObjectCategoryBodyDto {
  @ApiProperty({ example: 1, description: 'Mã id object' })
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
