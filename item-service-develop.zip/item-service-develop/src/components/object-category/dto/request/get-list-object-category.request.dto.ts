import { PaginationQuery } from '@utils/pagination.query';

export class GetListObjectCategoryRequestDto extends PaginationQuery {}
