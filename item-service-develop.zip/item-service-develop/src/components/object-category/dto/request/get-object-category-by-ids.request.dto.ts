import { BaseDto } from '@core/dto/base.dto';
import { ArrayNotEmpty } from 'class-validator';
export class GetObjectCategoriesRequestDto extends BaseDto {
  @ArrayNotEmpty()
  objectCategoryIds: number[];
}
