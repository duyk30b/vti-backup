import { UpdateObjectCategoryBodyDto } from './dto/request/update-object-category.rquest.dto';
import { DetailObjectCategoryRequestDto } from './dto/request/detail-object-category.request.dto';
import { CreateObjectCategoryRequestDto } from './dto/request/create-object-category.request.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { ObjectCategoryResponseDto } from './dto/response/object-category.response.dto';
import { ObjectCategoryServiceInterface } from './interface/object-category.service.interface';
import { isEmpty } from 'lodash';
import { GetListObjectCategoryRequestDto } from './dto/request/get-list-object-category.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CREATE_OBJECT_CATEGORY_PERMISSION,
  LIST_OBJECT_CATEGORY_PERMISSION,
  DETAIL_OBJECT_CATEGORY_PERMISSION,
  DELETE_OBJECT_CATEGORY_PERMISSION,
  UPDATE_OBJECT_CATEGORY_PERMISSION,
  CONFIRM_OBJECT_CATEGORY_PERMISSION,
  REJECT_OBJECT_CATEGORY_PERMISSION,
} from '@utils/permissions/object-category';
import { MessagePattern } from '@nestjs/microservices';
import { GetObjectCategoriesRequestDto } from './dto/request/get-object-category-by-ids.request.dto';

@Controller('object-categories')
export class ObjectCategoryController {
  constructor(
    @Inject('ObjectCategoryServiceInterface')
    private readonly objectCategoryService: ObjectCategoryServiceInterface,
  ) {}

  @PermissionCode(CREATE_OBJECT_CATEGORY_PERMISSION.code)
  @Post('/create')
  @ApiOperation({
    tags: ['Object Category'],
    summary: 'Create Object Category',
    description: 'Định nghĩa đối tượng',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ObjectCategoryResponseDto,
  })
  public async create(
    @Body() body: CreateObjectCategoryRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.objectCategoryService.create(request);
  }

  // @PermissionCode(LIST_OBJECT_CATEGORY_PERMISSION.code)
  @Get('/list')
  @ApiOperation({
    tags: ['Object Category'],
    summary: 'Get List Object',
    description: 'Danh sách đối tượng',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ObjectCategoryResponseDto,
  })
  async getList(
    @Query() payload: GetListObjectCategoryRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.objectCategoryService.getList(request);
  }

  @PermissionCode(DETAIL_OBJECT_CATEGORY_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Object Category'],
    summary: 'Get Detail Object ',
    description: 'Chi tiết đối tượng',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ObjectCategoryResponseDto,
  })
  async detail(@Param() param: DetailObjectCategoryRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.objectCategoryService.detail(request);
  }

  @PermissionCode(UPDATE_OBJECT_CATEGORY_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Object Category'],
    summary: 'Update Object category',
    description: 'Sửa danh sách đối tượng',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ObjectCategoryResponseDto,
  })
  async update(
    @Body() body: UpdateObjectCategoryBodyDto,
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.objectCategoryService.update(request);
  }

  @PermissionCode(DELETE_OBJECT_CATEGORY_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Object Category'],
    summary: 'Delete object category',
    description: 'Xóa danh mục đối tương',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: ObjectCategoryResponseDto,
  })
  public async delete(
    @Param() param: DetailObjectCategoryRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.objectCategoryService.delete(request);
  }

  @PermissionCode(CONFIRM_OBJECT_CATEGORY_PERMISSION.code)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['Object Category'],
    summary: 'Confirm object category',
    description: 'Xác nhận danh mục đối tương',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ObjectCategoryResponseDto,
  })
  public async confirm(
    @Param() param: DetailObjectCategoryRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.objectCategoryService.confirm(request);
  }

  @PermissionCode(REJECT_OBJECT_CATEGORY_PERMISSION.code)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['Object Category'],
    summary: 'Reject object category',
    description: 'Từ chối danh mục đối tương',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: ObjectCategoryResponseDto,
  })
  public async reject(
    @Param() param: DetailObjectCategoryRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.objectCategoryService.reject(request);
  }
  @MessagePattern('get_list_object_category')
  async getListTcp(
    @Body() payload: GetListObjectCategoryRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.objectCategoryService.getList(request);
  }

  @MessagePattern('get_detail_object_category')
  async detailTcp(@Body() param: DetailObjectCategoryRequestDto): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.objectCategoryService.detail(request);
  }

  @MessagePattern('get_object_category_by_ids')
  public async getObjectCategoryByIds(
    @Body() payload: GetObjectCategoriesRequestDto,
  ): Promise<ResponsePayload<ObjectCategoryResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.objectCategoryService.getObjectCategoryByIds(request);
  }
}
