import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { ObjectCategoryEntity } from '@entities/object-category/object-category.entity';
import { CreateObjectCategoryRequestDto } from '../dto/request/create-object-category.request.dto';
import { DetailObjectCategoryRequestDto } from '../dto/request/detail-object-category.request.dto';
import { GetListObjectCategoryRequestDto } from '../dto/request/get-list-object-category.request.dto';
import { UpdateObjectCategoryRequestDto } from '../dto/request/update-object-category.rquest.dto';

export interface ObjectCategoryRepositoryInterface
  extends BaseAbstractRepository<ObjectCategoryEntity> {
  createEntity(request: CreateObjectCategoryRequestDto): ObjectCategoryEntity;
  getList(request: GetListObjectCategoryRequestDto): Promise<any>;
  detail(request: DetailObjectCategoryRequestDto): Promise<any>;
  updateEntity(
    objectCategory: ObjectCategoryEntity,
    request: UpdateObjectCategoryRequestDto,
  ): ObjectCategoryEntity;
}
