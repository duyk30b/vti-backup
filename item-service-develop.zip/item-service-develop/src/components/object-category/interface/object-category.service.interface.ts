import { ResponsePayload } from '@utils/response-payload';
import { CreateObjectCategoryRequestDto } from '../dto/request/create-object-category.request.dto';
import { DetailObjectCategoryRequestDto } from '../dto/request/detail-object-category.request.dto';
import { GetListObjectCategoryRequestDto } from '../dto/request/get-list-object-category.request.dto';
import { GetObjectCategoriesRequestDto } from '../dto/request/get-object-category-by-ids.request.dto';
import { UpdateObjectCategoryRequestDto } from '../dto/request/update-object-category.rquest.dto';

export interface ObjectCategoryServiceInterface {
  create(request: CreateObjectCategoryRequestDto): Promise<any>;
  update(request: UpdateObjectCategoryRequestDto): Promise<any>;
  getList(request: GetListObjectCategoryRequestDto): Promise<any>;
  detail(request: DetailObjectCategoryRequestDto): Promise<any>;
  delete(
    request: DetailObjectCategoryRequestDto,
  ): Promise<ResponsePayload<any>>;
  confirm(request: DetailObjectCategoryRequestDto): Promise<any>;
  reject(request: DetailObjectCategoryRequestDto): Promise<any>;
  getObjectCategoryByIds(request: GetObjectCategoriesRequestDto): Promise<any>;
}
