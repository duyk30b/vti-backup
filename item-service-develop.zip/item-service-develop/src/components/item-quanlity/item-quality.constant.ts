export const ITEM_QUALITY_RULES = {
  NAME: {
    MAX_LENGTH: 50,
    MIN_LENGTH: 20,
  },
  CODE: {
    MAX_LENGTH: 3,
    REGEX: /(^[A-Z][0-9]{2}$)/,
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
};

export enum ItemQualityStatus {
  CREATED = 0,
  CONFIRMED = 1,
}

export const CONFIRMABLE_STATUSES = [ItemQualityStatus.CREATED];

export const REJECTABLE_STATUSES = [ItemQualityStatus.CONFIRMED];
