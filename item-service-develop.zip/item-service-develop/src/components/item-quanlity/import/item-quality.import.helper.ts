import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectDataSource } from '@nestjs/typeorm';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty, keyBy, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, In } from 'typeorm';
import { ImportFileDataAbstract } from '@core/abstracts/import-file-data.abstract';
import { ItemQualityRepositoryInterface } from '../interface/item-quality.repository.interface';

@Injectable()
export class ItemQualityImport extends ImportFileDataAbstract {
  private readonly FIELD_TEMPLATE_CONST = {
    CODE: {
      DB_COL_NAME: 'code',
      COL_NAME: 'Mã chất lượng vật tư',
      MAX_LENGTH: 4,
      ALLOW_NULL: false,
      REGEX: /^([a-zA-Z0-9]+)$/,
    },
    NAME: {
      DB_COL_NAME: 'name',
      COL_NAME: 'Tên chất lượng vật tư',
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    DESCRIPTION: {
      DB_COL_NAME: 'description',
      COL_NAME: 'Mô tả',
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    REQUIRED_COL_NUM: 3,
  };
  private readonly SHEET_NAME = this.i18n.translate(
    'file-header.SHEET_NAME_FILE_IMPORT_ITEM_QUANLITY',
  );

  private readonly ROW_NUMBER_START = 0;

  constructor(
    @Inject('ItemQualityRepositoryInterface')
    private readonly itemQualityRepository: ItemQualityRepositoryInterface,
    @InjectDataSource()
    private readonly connection: DataSource,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    const arrayField = [];
    for (const [key, value] of Object.entries(this.FIELD_TEMPLATE_CONST)) {
      arrayField.push(value);
    }
    this.fieldsMap.groupSet([1, 2, 3], arrayField);
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
    error: number,
    total: number,
    userId?: number,
  ): Promise<ImportResponseDto> {
    const itemQualityCodes = uniq(dataDto.map((i) => i.code));
    const oldItemQualities =
      await this.itemQualityRepository.findAllByCondition({
        code: In(itemQualityCodes),
      });
    let oldItemQualityKeyByCodes = keyBy(oldItemQualities, 'code');

    const { successMsg, unsuccessMsg } = await this.getMessage();
    let entities = [];
    let logRows = [];

    dataDto.forEach((data) => {
      const { i, code } = data;
      const logRow = {
        log: [],
        id: i,
        row: i,
      } as ImportResultDto;

      if (oldItemQualityKeyByCodes[code]) {
        let entity = this.itemQualityRepository.updateEntity(
          oldItemQualityKeyByCodes[code],
          data,
        );
        entities.push(entity);
      } else {
        let entity = this.itemQualityRepository.createEntity(data);
        entities.push(entity);
      }
      logRow.log = [successMsg];
      logRows.push(logRow);
    });

    const response = new ImportResponseDto();
    if (!isEmpty(entities)) {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(entities);
        await queryRunner.commitTransaction();
        response.successCount = entities.length;
      } catch (error) {
        await queryRunner.rollbackTransaction();
        logRows.forEach((l) => {
          l.log = [unsuccessMsg];
        });
        response.successCount = 0;
      } finally {
        await queryRunner.release();
        logs.push(...logRows);
      }
    }

    response.result = logs;
    response.totalCount = total;
    return response;
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<ImportResponseDto | any>> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_CONST.REQUIRED_COL_NUM,
      this.SHEET_NAME,
    );
  }
}
