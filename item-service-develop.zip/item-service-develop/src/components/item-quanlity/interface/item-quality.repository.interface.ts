import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ItemQualityEntity } from '@entities/item-quality/item-quality.entity';
import { CreateItemQualityRequestDto } from '../dto/request/create-item-quality.request.dto';
import { GetItemQualityListRequestDto } from '../dto/request/get-item-quality-list.request.dto';
import { UpdateItemQualityRequestDto } from '../dto/request/update-item-quality.request.dto';

export interface ItemQualityRepositoryInterface
  extends BaseInterfaceRepository<ItemQualityEntity> {
  createEntity(request: CreateItemQualityRequestDto): ItemQualityEntity;
  updateEntity(
    itemquality: ItemQualityEntity,
    request: UpdateItemQualityRequestDto,
  ): ItemQualityEntity;
  getList(request: GetItemQualityListRequestDto): Promise<any>;
}
