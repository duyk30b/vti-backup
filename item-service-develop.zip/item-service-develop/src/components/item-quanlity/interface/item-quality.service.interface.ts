import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { ConfirmItemQualityRequestDto } from '../dto/request/confirm-item-quality.request.dto';
import { CreateItemQualityRequestDto } from '../dto/request/create-item-quality.request.dto';
import { DeleteItemQualityRequestDto } from '../dto/request/delete-item-quality.request.dto';
import { GetItemQualityRequestDto } from '../dto/request/get-item-quality-detail.request.dto';
import { GetItemQualityListRequestDto } from '../dto/request/get-item-quality-list.request.dto';
import { GetItemQuanlityByIdsRequestDto } from '../dto/request/get-item-quanlity-by-ids.request.dto';
import { UpdateItemQualityRequestDto } from '../dto/request/update-item-quality.request.dto';

export interface ItemQualityServiceInterface {
  getDetail(request: GetItemQualityRequestDto): Promise<any>;
  getList(request: GetItemQualityListRequestDto): Promise<any>;
  create(request: CreateItemQualityRequestDto): Promise<any>;
  update(request: UpdateItemQualityRequestDto): Promise<any>;
  delete(request: DeleteItemQualityRequestDto): Promise<any>;
  confirm(request: ConfirmItemQualityRequestDto): Promise<any>;
  reject(request: ConfirmItemQualityRequestDto): Promise<any>;
  getItemQuanlityByIds(request: GetItemQuanlityByIdsRequestDto): Promise<any>;
  import(request: FileUpdloadRequestDto): Promise<any>;
}
