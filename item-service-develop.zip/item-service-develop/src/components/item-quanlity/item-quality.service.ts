import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ItemQualityEntity } from '@entities/item-quality/item-quality.entity';
import { Inject, Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ResponsePayload } from '@utils/response-payload';
import { DataSource, ILike, In, Not } from 'typeorm';
import { CreateItemQualityRequestDto } from './dto/request/create-item-quality.request.dto';
import { ItemQualityServiceInterface } from './interface/item-quality.service.interface';
import { ResponseBuilder } from '@utils/response-builder';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ItemQualityRepositoryInterface } from './interface/item-quality.repository.interface';
import { UpdateItemQualityRequestDto } from './dto/request/update-item-quality.request.dto';
import { DeleteItemQualityRequestDto } from './dto/request/delete-item-quality.request.dto';
import { GetItemQualityRequestDto } from './dto/request/get-item-quality-detail.request.dto';
import { ItemQualityResponseDto } from './dto/response/item-quality.response.dto';
import { plainToInstance } from 'class-transformer';
import { GetItemQualityListRequestDto } from './dto/request/get-item-quality-list.request.dto';
import { PagingResponse } from '@utils/paging.response';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { uniq } from 'lodash';
import {
  CONFIRMABLE_STATUSES,
  ItemQualityStatus,
  REJECTABLE_STATUSES,
} from './item-quality.constant';
import { ConfirmItemQualityRequestDto } from './dto/request/confirm-item-quality.request.dto';
import { RejectItemQualityRequestDto } from './dto/request/reject-item-quality.request.dto';
import { GetItemQuanlityByIdsRequestDto } from './dto/request/get-item-quanlity-by-ids.request.dto';
import { FileUploadRequestDto } from '@core/dto/file-upload.request';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ItemQualityImport } from './import/item-quality.import.helper';

@Injectable()
export class ItemQualityService implements ItemQualityServiceInterface {
  constructor(
    @InjectDataSource()
    private readonly connection: DataSource,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ItemQualityImport')
    private readonly itemQualityImport: ItemQualityImport,

    @Inject('ItemQualityRepositoryInterface')
    private readonly itemQualityRepository: ItemQualityRepositoryInterface,
    private readonly i18n: I18nRequestScopeService,
  ) {}

  async import(request: FileUploadRequestDto): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
    } as ImportRequestDto;
    importRequestDto.userId = request.userId;
    return this.itemQualityImport.importUtil(importRequestDto);
  }

  async create(request: CreateItemQualityRequestDto): Promise<any> {
    const existingItemQualityEntity =
      await this.itemQualityRepository.findByCondition({
        code: ILike(request.code),
      });
    if (existingItemQualityEntity) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'message.defineItemQuality.codeAlreadyExists',
          ),
        )
        .build();
    }
    const itemQuality = this.itemQualityRepository.createEntity(request);
    return await this.save(itemQuality);
  }

  async update(request: UpdateItemQualityRequestDto): Promise<any> {
    const existingItemQualityEntity =
      await this.itemQualityRepository.findOneById(request.id);

    if (!existingItemQualityEntity) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const existingCode = await this.itemQualityRepository.findByCondition({
      code: ILike(request.code),
      id: Not(request.id),
    });
    if (existingCode) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'message.defineItemQuality.codeAlreadyExists',
          ),
        )
        .build();
    }

    const itemQuality = this.itemQualityRepository.updateEntity(
      existingItemQualityEntity,
      request,
    );
    return await this.save(itemQuality, true);
  }

  async delete(request: DeleteItemQualityRequestDto): Promise<any> {
    const itemQuality = await this.itemQualityRepository.findOneById(
      request.id,
    );
    if (!itemQuality) {
      return new ResponseBuilder(itemQuality)
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    itemQuality.deletedAt = new Date();
    itemQuality.deletedBy = request.userId;
    await this.itemQualityRepository.create(itemQuality);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(
        await this.i18n.translate('message.defineItemQuality.deleteSuccess'),
      )
      .build();
  }

  async confirm(request: ConfirmItemQualityRequestDto): Promise<any> {
    const itemQuality = await this.itemQualityRepository.findOneById(
      request.id,
    );
    if (!itemQuality) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!CONFIRMABLE_STATUSES.includes(itemQuality.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CONFIRM'))
        .build();
    }
    itemQuality.status = ItemQualityStatus.CONFIRMED;
    await this.itemQualityRepository.create(itemQuality);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.changeStatusSuccess'))
      .build();
  }

  async reject(request: RejectItemQualityRequestDto): Promise<any> {
    const itemQuality = await this.itemQualityRepository.findOneById(
      request.id,
    );
    if (!itemQuality) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    if (!REJECTABLE_STATUSES.includes(itemQuality.status)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_REJECT'))
        .build();
    }
    itemQuality.status = ItemQualityStatus.CREATED;
    await this.itemQualityRepository.create(itemQuality);
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.changeStatusSuccess'))
      .build();
  }

  async getDetail(request: GetItemQualityRequestDto): Promise<any> {
    const itemQuality = await this.itemQualityRepository.findOneById(
      request.id,
    );

    if (!itemQuality) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const response = await this.generateRespone(itemQuality);
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(request: GetItemQualityListRequestDto): Promise<any> {
    const { page } = request;
    const [data, count] = await this.itemQualityRepository.getList(request);
    const creatorIds = uniq(data.map((item) => item.createdBy));
    const updaterIds = uniq(data.map((item) => item.updatedBy));
    const userIds = [...creatorIds, ...updaterIds];
    const users = await this.userService.getUsers(uniq(userIds), true);

    data.forEach((item) => {
      item.createdBy = users[item.createdBy];
      item.updatedBy = users[item.updatedBy];
    });

    const dataReturn = plainToInstance(ItemQualityResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async save(
    itemQualityEntity: ItemQualityEntity,
    isUpdate = false,
  ): Promise<ResponsePayload<any> | any> {
    try {
      const result = await this.itemQualityRepository.create(itemQualityEntity);
      const response = await this.generateRespone(result);
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          isUpdate
            ? await this.i18n.translate(
                'message.defineItemQuality.updateSuccess',
              )
            : await this.i18n.translate(
                'message.defineItemQuality.createSuccess',
              ),
        )
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder(error)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .build();
    }
  }

  private async generateRespone(
    itemQualityEntity: ItemQualityEntity,
  ): Promise<ItemQualityResponseDto> {
    const userIds = [itemQualityEntity.createdBy, itemQualityEntity.updatedBy];
    const users = await this.userService.getUsers(uniq(userIds), true);

    itemQualityEntity.createdBy = users[itemQualityEntity.createdBy];
    itemQualityEntity.updatedBy = users[itemQualityEntity.updatedBy];

    const response = plainToInstance(
      ItemQualityResponseDto,
      itemQualityEntity,
      {
        excludeExtraneousValues: true,
      },
    );

    return response;
  }

  public async getItemQuanlityByIds(
    request: GetItemQuanlityByIdsRequestDto,
  ): Promise<any> {
    const result = await this.itemQualityRepository.findAllByCondition({
      id: In(request.itemQuanlityIds),
    });
    const response = plainToInstance(ItemQualityResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }
}
