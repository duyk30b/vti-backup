import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt } from 'class-validator';
import { CreateItemQualityRequestDto } from './create-item-quality.request.dto';

export class UpdateItemQualityBodyDto extends CreateItemQualityRequestDto {}

export class UpdateItemQualityRequestDto extends UpdateItemQualityBodyDto {
  @ApiProperty({ example: '', description: '' })
  @Transform(({ value }) => Number(value))
  @IsInt()
  id: number;
}
