import { ITEM_QUALITY_RULES } from '@components/item-quanlity/item-quality.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsOptional,
  IsString,
  MaxLength,
  Matches,
  MinLength,
} from 'class-validator';

export class CreateItemQualityRequestDto extends BaseDto {
  @ApiProperty({ example: '', description: '' })
  @IsString()
  @MaxLength(ITEM_QUALITY_RULES.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: '', description: '' })
  @IsString()
  @Matches(ITEM_QUALITY_RULES.CODE.REGEX)
  code: string;

  @ApiProperty({ example: '', description: '' })
  @IsOptional()
  @IsString()
  @MaxLength(ITEM_QUALITY_RULES.DESCRIPTION.MAX_LENGTH)
  description: string;
}
