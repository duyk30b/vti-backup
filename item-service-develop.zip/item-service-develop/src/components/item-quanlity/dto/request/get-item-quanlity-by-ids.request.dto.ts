import { ArrayNotEmpty } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';

export class GetItemQuanlityByIdsRequestDto extends BaseDto {
  @ApiProperty({ example: '', description: '' })
  @ArrayNotEmpty()
  itemQuanlityIds: number[];
}
