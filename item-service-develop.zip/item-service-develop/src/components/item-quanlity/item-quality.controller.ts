import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { CreateItemQualityRequestDto } from './dto/request/create-item-quality.request.dto';
import { isEmpty } from 'lodash';
import { ItemQualityServiceInterface } from './interface/item-quality.service.interface';
import { UpdateItemQualityBodyDto } from './dto/request/update-item-quality.request.dto';
import { DeleteItemQualityRequestDto } from './dto/request/delete-item-quality.request.dto';
import { GetItemQualityListRequestDto } from './dto/request/get-item-quality-list.request.dto';
import { ItemQualityResponseDto } from './dto/response/item-quality.response.dto';
import { GetItemQualityRequestDto } from './dto/request/get-item-quality-detail.request.dto';
import {
  DETAIL_ITEM_QUALITY_PERMISSION,
  CREATE_ITEM_QUALITY_PERMISSION,
  DELETE_ITEM_QUALITY_PERMISSION,
  UPDATE_ITEM_QUALITY_PERMISSION,
  LIST_ITEM_QUALITY_PERMISSION,
  CONFIRM_ITEM_QUALITY_PERMISSION,
  REJECT_ITEM_QUALITY_PERMISSION,
} from '@utils/permissions/item-quality';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { ConfirmItemQualityRequestDto } from './dto/request/confirm-item-quality.request.dto';
import { RejectItemQualityRequestDto } from './dto/request/reject-item-quality.request.dto';
import { MessagePattern } from '@nestjs/microservices';
import { GetItemQuanlityByIdsRequestDto } from './dto/request/get-item-quanlity-by-ids.request.dto';
import { FileUploadRequestDto } from '@core/dto/file-upload.request';
import { NATS_ITEM } from '@config/nats.config';

@Controller('item-qualities')
export class ItemQualityController {
  constructor(
    @Inject('ItemQualitysServiceInterface')
    private readonly itemQualityService: ItemQualityServiceInterface,
  ) {}

  @PermissionCode(CREATE_ITEM_QUALITY_PERMISSION.code)
  @Post('create')
  @ApiOperation({
    tags: ['ItemQuality'],
    summary: 'Create new reason',
    description: 'Tạo 1 reason mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async create(@Body() body: CreateItemQualityRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemQualityService.create(request);
  }

  //@PermissionCode(CREATE_ITEM_QUALITY_PERMISSION.code)
  @Post('import')
  @ApiOperation({
    tags: ['ItemQuality'],
    summary: 'Import new reason',
    description: 'import',
  })
  @ApiResponse({
    status: 200,
    description: 'import successfully',
    type: null,
  })
  public async import(@Body() body: FileUploadRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemQualityService.import(request);
  }

  @PermissionCode(UPDATE_ITEM_QUALITY_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['ItemQuality'],
    summary: 'Update reason',
    description: 'Sửa reason',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async update(
    @Body() body: UpdateItemQualityBodyDto,
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemQualityService.update({ ...request, id });
  }

  @PermissionCode(DELETE_ITEM_QUALITY_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['ItemQuality'],
    summary: 'Delete item quality',
    description: 'Xóa chất lượng vật tư',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async delete(
    @Param() param: DeleteItemQualityRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemQualityService.delete(request);
  }

  @PermissionCode(CONFIRM_ITEM_QUALITY_PERMISSION.code)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['ItemQuality'],
    summary: 'confirm item quality',
    description: 'Xác nhận chất lượng vật tư',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async confirm(
    @Param() param: ConfirmItemQualityRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemQualityService.confirm(request);
  }

  @PermissionCode(REJECT_ITEM_QUALITY_PERMISSION.code)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['ItemQuality'],
    summary: 'reject item quality',
    description: 'Từ chối chất lượng vật tư',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: null,
  })
  public async reject(
    @Param() param: RejectItemQualityRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemQualityService.reject(request);
  }

  @PermissionCode(DETAIL_ITEM_QUALITY_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['ItemQuality'],
    summary: 'Delete reason',
    description: 'Xóa reason',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: ItemQualityResponseDto,
  })
  public async getDetail(
    @Param() param: GetItemQualityRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemQualityService.getDetail(request);
  }

  @PermissionCode(LIST_ITEM_QUALITY_PERMISSION.code)
  @Get('list')
  @ApiOperation({
    tags: ['ItemQuality'],
    summary: 'Get list reason',
    description: 'Lấy danh sách reason',
  })
  @ApiResponse({
    status: 200,
    description: 'Get list successfully',
    type: null,
  })
  public async getList(
    @Query() query: GetItemQualityListRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemQualityService.getList(request);
  }

  @MessagePattern(`${NATS_ITEM}.get_item_quanlity_by_ids`)
  public async getObjectCategoryByIds(
    @Body() payload: GetItemQuanlityByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemQualityService.getItemQuanlityByIds(request);
  }
}
