import { ItemQualityEntity } from '@entities/item-quality/item-quality.entity';
import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ItemQualityController } from './item-quality.controller';
import { ItemQualityRepository } from '@repositories/item-quality.repository';
import { ItemQualityService } from './item-quality.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { ItemQualityImport } from './import/item-quality.import.helper';

@Global()
@Module({
  imports: [TypeOrmModule.forFeature([ItemQualityEntity]), UserModule],
  exports: [],
  providers: [
    {
      provide: 'ItemQualityRepositoryInterface',
      useClass: ItemQualityRepository,
    },
    {
      provide: 'ItemQualitysServiceInterface',
      useClass: ItemQualityService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'ItemQualityImport',
      useClass: ItemQualityImport,
    },
  ],
  controllers: [ItemQualityController],
})
export class ItemQualityModule { }
