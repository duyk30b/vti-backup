import { Inject, Injectable } from '@nestjs/common';
import { ExportServiceInterface } from './interface/export.service.interface';
import { Alignment, Borders, FillPattern, Font, Workbook } from 'exceljs';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import {
  EXCEL_STYLE,
  MAX_NUMBER_PAGE,
  ROW,
  SHEET,
  TypeEnum,
} from './export.constant';
import { isEmpty, keyBy, map, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ExportRequestDto } from './dto/request/export.request.dto';

import { ItemGroupSettingRepositoryInterface } from '@components/item-setting/interface/item-group-setting.repository.interface';
import { ItemUnitSettingRepositoryInterface } from '@components/item/interface/item-unit-setting.repository.interface';
import { ItemTypeSettingRepositoryInterface } from '@components/item/interface/item-type-setting.repository.interface';
import { GetListItemGroupSettingRequestDto } from '@components/item-setting/dto/request/get-list-item-group-setting.request.dto';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { GetListItemTypeSettingRequestDto } from '@components/item-setting/dto/request/get-list-item-type-setting.request.dto';
import { GetListItemUnitSettingRequestDto } from '@components/item-setting/dto/request/get-list-item-unit-setting.request.dto';
import { GetListInventoryQuantityNormExportRequestDto } from '@components/inventory-quantity-norm/dto/request/get-list-inventory-norm-export.request.dto';
import { InventoryQuantityNormRepositoryInterface } from '@components/inventory-quantity-norm/interface/inventory-quantity-norm.repository.interface';
import { In } from 'typeorm';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { GetListManufacturingCountryRequestDto } from '@components/manufacturing-country/dto/request/get-list-manufacturing-country.request.dto';
import { ManufacturingCountryRepositoryInterface } from '@components/manufacturing-country/interface/manufacturing-country.repository.interface';
import { Item } from '@entities/item/item.entity';
import { GetListItemRequestDto } from '@components/item/dto/request/get-list-item.request.dto';
import { ItemRepositoryInterface } from '@components/item/interface/item.repository.interface';
import { DASH_SEPARATOR, DOT_SEPARATOR } from '@constant/common';
import { ItemQualityRepositoryInterface } from '@components/item-quanlity/interface/item-quality.repository.interface';
import { ObjectCategoryRepositoryInterface } from '@components/object-category/interface/object-category.repository.interface';

@Injectable()
export class ExportService implements ExportServiceInterface {
  constructor(
    @Inject('ItemGroupSettingRepositoryInterface')
    private readonly itemGroupSettingRepository: ItemGroupSettingRepositoryInterface,

    @Inject('ItemUnitSettingRepositoryInterface')
    private readonly itemUnitSettingRepository: ItemUnitSettingRepositoryInterface,

    @Inject('ItemTypeSettingRepositoryInterface')
    private readonly itemTypeSettingRepository: ItemTypeSettingRepositoryInterface,

    @Inject('InventoryQuantityNormRepositoryInterface')
    private readonly inventoryQuantityNormRepository: InventoryQuantityNormRepositoryInterface,

    @Inject('ManufacturingCountryRepositoryInterface')
    private readonly manufacturingCountryRepository: ManufacturingCountryRepositoryInterface,

    @Inject('ItemQualityRepositoryInterface')
    private readonly itemQualityRepository: ItemQualityRepositoryInterface,

    @Inject('ObjectCategoryRepositoryInterface')
    private readonly objectCategoryRepository: ObjectCategoryRepositoryInterface,

    @Inject('ItemRepositoryInterface')
    private readonly itemRepository: ItemRepositoryInterface,

    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async export(request: ExportRequestDto): Promise<any> {
    const { queryIds, type } = request;
    if (!isEmpty(queryIds) && queryIds.length > ROW.LIMIT_EXPORT) {
      return new ResponseBuilder()
        .withMessage(
          await this.i18n.translate('error.LIMIT_EXPORT_ONE_SHEET_ERROR'),
        )
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }

    let workbook;
    switch (type) {
      case TypeEnum.ITEM_GROUP:
        workbook = await this.exportItemGroups(request);
        break;
      case TypeEnum.ITEM_TYPE:
        workbook = await this.exportItemTypes(request);
        break;
      case TypeEnum.ITEM_UNIT:
        workbook = await this.exportItemUnits(request);
        break;
      case TypeEnum.INVENTORY_QUANTITY_NORM:
        workbook = await this.exportInventoryQuantityNorm(request);
        break;
      case TypeEnum.MANUFACTURING_COUNTRY:
        workbook = await this.exportManufacturingCountry(request);
        break;
      case TypeEnum.ITEM:
        workbook = await this.exportItem(request);
        break;
      default:
        break;
    }
    if (workbook?.xlsx) {
      // await workbook?.xlsx.writeFile('export.xlsx');
      const file = await workbook.xlsx.writeBuffer();
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .withCode(ResponseCodeEnum.SUCCESS)
        .withData(file)
        .build();
    } else {
      return workbook;
    }
  }

  async exportItemGroups(payload: any) {
    let users: any;
    let itemGroups: any[] = [];
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListItemGroupSettingRequestDto();
      if (payload.queryIds) {
        request.ids = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.page = i;
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const { result } = await this.itemGroupSettingRepository.getList(request);
      if (!isEmpty(result)) {
        itemGroups = itemGroups.concat(result);
      }
      if (result.length > ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!itemGroups || isEmpty(itemGroups)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const userIds = uniq(map(itemGroups, 'createdBy'));

    if (!isEmpty(userIds)) {
      users = await this.userService.getUsers(uniq(userIds));
    }
    const userMap = keyBy(users, 'id');

    const data = itemGroups.map((itemGroup) => {
      return {
        code: itemGroup.code || '',
        name: itemGroup.name || '',
        description: itemGroup.description || '',
        createdBy: userMap[itemGroup.createdBy]?.fullName || '',
        createdAt: itemGroup.createdAt || '',
      };
    });
    const headers = [
      {
        key: 'code',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.itemGroup.code'),
      },
      {
        key: 'name',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.itemGroup.name'),
      },
      {
        key: 'description',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.itemGroup.description'),
      },
      {
        key: 'createdBy',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.common.createdBy'),
      },
      {
        key: 'createdAt',
        width: 25,
        style: {
          alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE,
          numFmt: EXCEL_STYLE.DDMMYYYYHHMMSS,
        },
        title: await this.i18n.translate('export.common.createdAt'),
      },
    ];
    let workbook = new Workbook();
    workbook = await this.exportOneSheetUtil(
      data,
      [await this.i18n.translate('export.itemGroup.title')],
      headers,
    );

    return workbook;
  }

  async exportItemTypes(payload: any) {
    let itemTypes: any[] = [];
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListItemTypeSettingRequestDto();
      request.page = i;
      if (payload.queryIds) {
        request.ids = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      // request.isExport = 1;
      const { result } = await this.itemTypeSettingRepository.getList(request);
      if (!isEmpty(result)) {
        itemTypes = itemTypes.concat(result);
      }
      if (result.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!itemTypes || isEmpty(itemTypes)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const data = [];
    for (let i = 0; i < itemTypes.length; i++) {
      const itemType = itemTypes[i];

      let item: any = {
        code: itemType.code,
        name: itemType.name,
        description: itemType.description || '',
        status: await this.i18n.translate(`export.common.${itemType.status}`),
        codeMainGroup: '',
        nameMainGroup: '',
        descriptionMainGroup: '',
        codeSubGroup: '',
        nameSubGroup: '',
        descriptionSubGroup: '',
      };

      for (let j = 0; j < itemType.childrens.length; j++) {
        const itemTypeMainChild = itemType.childrens[j];

        if (j === 1) {
          item.code = '';
          item.name = '';
          item.description = '';
          item.status = '';
        }

        item.codeMainGroup = itemTypeMainChild.code;
        item.nameMainGroup = itemTypeMainChild.name;
        item.descriptionMainGroup = itemTypeMainChild.description || '';

        for (let k = 0; k < itemTypeMainChild.childrens.length; k++) {
          const itemTypeSubChild = itemTypeMainChild.childrens[k];

          if (k === 1) {
            item.code = '';
            item.name = '';
            item.description = '';
            item.status = '';
            item.codeMainGroup = '';
            item.nameMainGroup = '';
            item.descriptionMainGroup = '';
          }

          item.codeSubGroup = itemTypeSubChild.code;
          item.nameSubGroup = itemTypeSubChild.name;
          item.descriptionSubGroup = itemTypeSubChild.description || '';

          data.push({ ...item });
        }

        if (!itemTypeMainChild.childrens.length) {
          data.push({ ...item });
        }
      }

      if (!itemType.childrens.length) {
        data.push({ ...item });
      }
    }

    const headers = [
      {
        key: 'code',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.itemType.code'),
      },
      {
        key: 'name',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.itemType.name'),
      },
      {
        key: 'description',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.itemType.description'),
      },
      {
        key: 'codeMainGroup',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.itemType.codeMainGroup'),
      },
      {
        key: 'nameMainGroup',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.itemType.nameMainGroup'),
      },
      {
        key: 'descriptionMainGroup',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.itemType.description'),
      },
      {
        key: 'codeSubGroup',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.itemType.codeSubGroup'),
      },
      {
        key: 'nameSubGroup',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.itemType.nameSubGroup'),
      },
      {
        key: 'descriptionSubGroup',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.itemType.description'),
      },
      {
        key: 'status',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.common.status'),
      },
    ];

    const workbook = await this.exportOneSheetUtil(
      data,
      [await this.i18n.translate('export.itemType.title')],
      headers,
      true,
    );
    return workbook;
  }
  async exportItemUnits(payload: any) {
    let itemUnits: any[] = [];
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListItemUnitSettingRequestDto();
      request.page = i;
      if (payload.queryIds) {
        request.ids = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const { result } = await this.itemUnitSettingRepository.getList(request);
      if (!isEmpty(result)) {
        itemUnits = itemUnits.concat(result);
      }
      if (result.lenght < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!itemUnits || isEmpty(itemUnits)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const data = await Promise.all(
      itemUnits.map(async (itemUnit) => {
        const item = {
          code: itemUnit.code || '',
          name: itemUnit.name || '',
          shortName: itemUnit.shortName || '',
          description: itemUnit.description || '',
          status: await this.i18n.translate(`export.common.${itemUnit.status}`),
        };

        return item;
      }),
    );
    const headers = [
      {
        key: 'code',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.itemUnit.code'),
      },
      {
        key: 'name',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.itemUnit.name'),
      },
      {
        key: 'shortName',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.itemUnit.shortName'),
      },
      {
        key: 'description',
        width: 40,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.itemUnit.description'),
      },
      {
        key: 'status',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.common.status'),
      },
    ];

    const workbook = await this.exportOneSheetUtil(
      data,
      [await this.i18n.translate('export.itemUnit.title')],
      headers,
    );
    return workbook;
  }

  async exportManufacturingCountry(payload: any) {
    let manufacturingCountries: any[] = [];
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListManufacturingCountryRequestDto();
      request.page = i;
      if (payload.queryIds) {
        request.ids = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const { result } = await this.manufacturingCountryRepository.getList(
        request,
      );

      if (!isEmpty(result)) {
        manufacturingCountries = manufacturingCountries.concat(result);
      }
      if (result.lenght < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!manufacturingCountries || isEmpty(manufacturingCountries)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const data = await Promise.all(
      manufacturingCountries.map(async (country) => {
        const item = {
          code: country.code || '',
          name: country.name || '',
          description: country.description || '',
          status: await this.i18n.translate(`export.common.${country.status}`),
        };

        return item;
      }),
    );
    const headers = [
      {
        key: 'code',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.manufacturingCountry.code'),
      },
      {
        key: 'name',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.manufacturingCountry.name'),
      },
      {
        key: 'description',
        width: 40,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.manufacturingCountry.description',
        ),
      },
      {
        key: 'status',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.common.status'),
      },
    ];

    const workbook = await this.exportOneSheetUtil(
      data,
      [await this.i18n.translate('export.manufacturingCountry.title')],
      headers,
    );
    return workbook;
  }

  async exportItem(payload: any) {
    let items: Item[] = [];

    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListItemRequestDto();
      request.page = i;
      if (payload.queryIds) {
        request.ids = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const { data: result } = await this.itemRepository.getList(request);

      if (!isEmpty(result)) {
        items = items.concat(result);
      }
      if (result.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!items || isEmpty(items)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const itemTypeIds: number[] = [];
    const itemQualityIds: number[] = [];
    const manufacturingCountryIds: number[] = [];
    const objectCategoryIds: number[] = [];

    items.forEach((item) => {
      if (item.itemType) {
        itemTypeIds.push(item.itemType.id);
      }
      itemQualityIds.push(item.itemQualityId);
      manufacturingCountryIds.push(item.manufacturingCountryId);
      objectCategoryIds.push(item.objectCategoryId);
    });

    const itemTypeRequest = {} as any;
    (itemTypeRequest.isGetAll = '1'),
      (itemTypeRequest.ids = uniq(itemTypeIds).join(','));

    const [itemTypes, itemQualities, manufacturingCountries] =
      await Promise.all([
        // this.itemTypeSettingRepository.getListSubGroup(itemTypeRequest),
        this.itemQualityRepository.findAllByCondition({
          id: In(uniq(itemQualityIds)),
        }),
        this.manufacturingCountryRepository.findAllByCondition({
          id: In(uniq(manufacturingCountryIds)),
        }),
        this.objectCategoryRepository.findAllByCondition({
          id: In(uniq(objectCategoryIds)),
        }),
      ]);

    const itemTypeMap = keyBy(itemTypes, 'id');
    const itemQualityMap = keyBy(itemQualities, 'id');
    const manufacturingCountryMap = keyBy(manufacturingCountries, 'id');
    const objectCategoryMap = keyBy([], 'id');

    const data = await Promise.all(
      items.map(async (item) => {
        const itemType = itemTypeMap[item.itemType?.id];
        const itemTypeCode = itemType
          ? [itemType.code, itemType.mainGroupCode, itemType.subGroupCode].join(
              DOT_SEPARATOR,
            )
          : '';

        const itemQuality = itemQualityMap[item.itemQualityId];
        const itemQualityCode = itemQuality
          ? [itemQuality.code, itemQuality.name].join(DOT_SEPARATOR)
          : '';

        const manufacturingCountry =
          manufacturingCountryMap[item.manufacturingCountryId];
        const manufacturingCountryCode = manufacturingCountry
          ? [manufacturingCountry.code, manufacturingCountry.name].join(
              DASH_SEPARATOR,
            )
          : '';

        const objectCategory = objectCategoryMap[item.objectCategoryId];
        const objectCategoryCode = objectCategory
          ? [objectCategory.code, objectCategory.name].join(DASH_SEPARATOR)
          : '';

        const element = {
          code: item.code || '',
          name: item.name || '',
          itemType: itemTypeCode,
          normalizeCode: item.normalizeCode,
          itemQuality: itemQualityCode,
          manufacturingCountry: manufacturingCountryCode,
          objectCategory: objectCategoryCode,
          itemUnit: item.itemUnit ? item.itemUnit.name : '',
          description: item.description || '',
          status: await this.i18n.translate(`export.common.${item.status}`),
        };

        return element;
      }),
    );
    const headers = [
      {
        key: 'name',
        width: 40,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.item.name'),
      },
      {
        key: 'code',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.item.code'),
      },
      {
        key: 'itemType',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.item.itemType'),
      },
      {
        key: 'normalizeCode',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.item.normalizeCode'),
      },
      {
        key: 'itemQuality',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.item.itemQuality'),
      },
      {
        key: 'manufacturingCountry',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.item.manufacturingCountry'),
      },
      {
        key: 'objectCategory',
        width: 25,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.item.objectCategory'),
      },
      {
        key: 'itemUnit',
        width: 15,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.item.itemUnit'),
      },
      {
        key: 'description',
        width: 30,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.item.description'),
      },
      {
        key: 'status',
        width: 20,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.common.status'),
      },
    ];

    const workbook = await this.exportOneSheetUtil(
      data,
      [await this.i18n.translate('export.item.title')],
      headers,
    );
    return workbook;
  }

  async exportOneSheetUtil(
    data: any[],
    title: any,
    headers: any,
    isMultiLevel?: boolean,
  ) {
    const workbook = new Workbook();
    let isBorderTop = false;
    let countRowData = ROW.COUNT_START_ROW;
    let countSheet = SHEET.START_SHEET;
    data.forEach((element) => {
      let worksheet = workbook.getWorksheet(SHEET.NAME + countSheet);
      if (countRowData == ROW.COUNT_START_ROW) {
        worksheet = workbook.addWorksheet(SHEET.NAME + countSheet);

        const titleRow = worksheet.getRow(1);
        titleRow.values = title;
        titleRow.font = <Font>EXCEL_STYLE.TITLE_FONT;

        const headerRow = worksheet.getRow(3);
        headerRow.values = headers.map((header) => header.title);
        headerRow.eachCell(function (cell) {
          cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
          cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        });
      }
      worksheet.columns = headers;
      worksheet
        .addRow({
          ...element,
        })
        .eachCell(function (cell) {
          cell.font = <Font>EXCEL_STYLE.DEFAULT_FONT;

          if (isMultiLevel) {
            if (cell.col == '1') {
              isBorderTop = Boolean(cell.value);
            }

            if (isBorderTop) {
              cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_TOP;
            }
          } else {
            cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          }
        });

      countRowData++;
      if (countRowData == ROW.COUNT_END_ROW) {
        countSheet++;
        countRowData = ROW.COUNT_START_ROW;
      }
    });
    return workbook;
  }

  async exportMultiSheetUtil(
    workbook: Workbook,
    items: any[],
    level: any,
    titleMap: any,
    headersMap: any,
  ) {
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      let worksheet = workbook.getWorksheet(SHEET.NAME + level);
      if (!worksheet) {
        worksheet = workbook.addWorksheet(SHEET.NAME + level);

        const titleRow = worksheet.getRow(1);
        titleRow.values = titleMap.get(level);
        titleRow.font = <Font>EXCEL_STYLE.TITLE_FONT;

        const headerRow = worksheet.getRow(3);
        headerRow.values = headersMap.get(level).map((header) => header.title);
        headerRow.eachCell(function (cell) {
          cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
          cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
        });
        worksheet.columns = headersMap.get(level);
      }

      worksheet
        .addRow({
          ...item,
        })
        .eachCell(function (cell) {
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          cell.font = <Font>EXCEL_STYLE.DEFAULT_FONT;
        });
      if (item.subItem?.length > 0) {
        workbook = await this.exportMultiSheetUtil(
          workbook,
          item.subItem,
          level + 1,
          titleMap,
          headersMap,
        );
      }
    }

    return workbook;
  }

  async exportInventoryQuantityNorm(payload: any) {
    let countRowData = ROW.COUNT_START_ROW;
    let countSheet = SHEET.START_SHEET;
    let inventoryQuantityNorms: any[] = [];
    for (let i = 1; i <= MAX_NUMBER_PAGE; i++) {
      const request = new GetListInventoryQuantityNormExportRequestDto();
      request.page = i;
      if (payload.queryIds) {
        request.ids = map(JSON.parse(payload.queryIds), 'id').join(',');
      }
      request.limit = ROW.LIMIT_EXPORT_ON_SHEET;
      request.filter = payload.filter;
      request.sort = payload.sort;
      const { result } =
        await this.inventoryQuantityNormRepository.getListExport(request);
      const warehouseIds = result.map((item) => item.warehouseId);
      const warehouses = await this.warehouseService.getListByIDs(
        uniq(warehouseIds),
        true,
      );
      const itemUnitIds = map(result, 'item.itemUnitId');

      const itemUnitSettings =
        await this.itemUnitSettingRepository.findAllByCondition({
          id: In(itemUnitIds),
        });
      const itemUnitMap = keyBy(itemUnitSettings, 'id');

      result.forEach((item) => {
        const warehouse = warehouses[item.warehouseId];
        const itemUnit = itemUnitMap[item.item.itemUnitId];

        if (warehouse) {
          item.warehouse = warehouse;
        }
        if (itemUnit) {
          item.item.itemUnit = itemUnit;
        }
      });
      if (!isEmpty(result)) {
        inventoryQuantityNorms = inventoryQuantityNorms.concat(result);
      }
      if (result.length < ROW.LIMIT_EXPORT_ON_SHEET) {
        break;
      }
    }

    if (!inventoryQuantityNorms || isEmpty(inventoryQuantityNorms)) {
      return new ResponseBuilder()
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .build();
    }

    const data = inventoryQuantityNorms.map((item) => {
      return {
        warehouseCode: item?.warehouse?.code || '',
        itemCode: item?.item?.code || '',
        itemName: item?.item?.name || '',
        itemUnit: item?.item?.itemUnit?.name || '',
        minInventoryLimit: item?.minInventoryLimit || '0',
        maxInventoryLimit: item?.maxInventoryLimit || '0',
        inventoryLimit: item?.inventoryLimit || '0',
        reorderPoint: item?.reorderPoint || '0',
        eoq: item?.eoq || '0',
        leadtiem: item?.leadtiem || '0',
        reorderPointSys: '',
      };
    });

    while (data.length < 14) {
      data.push({
        warehouseCode: '',
        itemCode: '',
        itemName: '',
        itemUnit: '',
        minInventoryLimit: '',
        maxInventoryLimit: '',
        inventoryLimit: '',
        reorderPoint: '',
        eoq: '',
        leadtiem: '',
        reorderPointSys: '',
      });
    }

    const headers = [
      {
        key: 'warehouseCode',
        width: 10,
        height: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.inventoryQuantityNorm.warehouseCode',
        ),
      },
      {
        key: 'itemCode',
        width: 25,
        height: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.inventoryQuantityNorm.itemCode',
        ),
      },
      {
        key: 'itemName',
        width: 30,
        height: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.inventoryQuantityNorm.itemName',
        ),
      },
      {
        key: 'itemUnit',
        width: 10,
        height: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.inventoryQuantityNorm.itemUnit',
        ),
      },
      {
        key: 'minInventoryLimit',
        width: 20,
        height: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.inventoryQuantityNorm.minInventoryLimit',
        ),
      },
      {
        key: 'maxInventoryLimit',
        width: 20,
        height: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.inventoryQuantityNorm.maxInventoryLimit',
        ),
      },
      {
        key: 'inventoryLimit',
        width: 20,
        height: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.inventoryQuantityNorm.inventoryLimit',
        ),
      },
      {
        key: 'reorderPoint',
        width: 30,
        height: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.inventoryQuantityNorm.reorderPoint',
        ),
      },
      {
        key: 'eoq',
        width: 10,
        height: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate('export.inventoryQuantityNorm.eoq'),
      },
      {
        key: 'leadtiem',
        width: 25,
        height: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.inventoryQuantityNorm.leadtiem',
        ),
      },
      {
        key: 'reorderPointSys',
        width: 30,
        height: 10,
        style: { alignment: <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE },
        title: await this.i18n.translate(
          'export.inventoryQuantityNorm.reorderPointSys',
        ),
      },
    ];

    const workbook = new Workbook();
    data.forEach((element) => {
      let worksheet = workbook.getWorksheet(SHEET.NAME + countSheet);
      if (countRowData == ROW.COUNT_START_ROW) {
        worksheet = workbook.addWorksheet(SHEET.NAME + countSheet);
        const headerRow = worksheet.getRow(1);
        headerRow.values = headers.map((header) => header.title);
        headerRow.eachCell(function (cell) {
          cell.font = <Font>EXCEL_STYLE.TITLE_FONT_IN;
          cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE;
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          cell.fill = <FillPattern>EXCEL_STYLE.HEADER_FILL_IN;
        });
      }
      worksheet.columns = headers;
      worksheet
        .addRow({
          ...element,
        })
        .eachCell(function (cell, index) {
          if (index > 4) {
            cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_RIGHT_MIDDLE;
          }
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          cell.font = <Font>EXCEL_STYLE.DEFAULT_FONT_IN;
        });

      countRowData++;
      if (countRowData == ROW.COUNT_END_ROW) {
        countSheet++;
        countRowData = ROW.COUNT_START_ROW;
      }
    });
    return workbook;
  }

  // async exportTemplateUtil(
  //   data: any[],
  //   title: any,
  //   headerTitles: any,
  //   headers: any,
  // ) {
  //   const workbook = new Workbook();
  //   await workbook.xlsx.readFile('static/template/export/company.xlsx');

  //   let countRowData = ROW.countStartRow;
  //   let countSheet = SHEET.startSheet;

  //   data.forEach((element, index) => {
  //     if (countRowData == ROW.countStartRow && index > 0) {
  //       workbook.addWorksheet(SHEET.name + countSheet).model =
  //         workbook.getWorksheet(SHEET.name + SHEET.startSheet).model;
  //     }

  //     workbook.getWorksheet(SHEET.name + countSheet).addRow({
  //       ...element,
  //     });

  //     countRowData++;
  //     if (countRowData == ROW.countEndRow) {
  //       countSheet++;
  //       countRowData = ROW.countStartRow;
  //     }
  //   });
  //   return workbook;
  // }
}
