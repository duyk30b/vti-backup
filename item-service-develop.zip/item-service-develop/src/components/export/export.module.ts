import { ItemSettingService } from '@components/item-setting/item-setting.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { WarehouseService } from '@components/warehouse/warehouse.service';
import { InventoryQuantityNorm } from '@entities/inventory-norm/inventory-quantity-norm.entity';
import { ItemQualityEntity } from '@entities/item-quality/item-quality.entity';
import { ItemGroupSetting } from '@entities/item/item-group-setting.entity';
import { ItemTypeSetting } from '@entities/item/item-type-setting.entity';
import { ItemUnitSetting } from '@entities/item/item-unit-setting.entity';
import { Item } from '@entities/item/item.entity';
import { ManufacturingCountryEntity } from '@entities/manufacturing-country/manufacturing-country.entity';
import { ObjectCategoryEntity } from '@entities/object-category/object-category.entity';
import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InventoryQuantityNormRepository } from '@repositories/inventory-quantity-norm.repository';
import { ItemGroupSettingRepository } from '@repositories/item-group-setting.repository';
import { ItemQualityRepository } from '@repositories/item-quality.repository';
import { ItemTypeSettingRepository } from '@repositories/item-type-setting.repository';
import { ItemUnitSettingRepository } from '@repositories/item-unit-setting.repository';
import { ItemRepository } from '@repositories/item.repository';
import { ManufacturingCountryRepository } from '@repositories/manufacturing-country.repository';
import { ObjectCategoryRepository } from '@repositories/object-category.repository';
import { ExportController } from './export.controller';
import { ExportService } from './export.service';

@Global()
@Module({
  imports: [
    TypeOrmModule.forFeature([
      ItemUnitSetting,
      ItemTypeSetting,
      ItemGroupSetting,
      InventoryQuantityNorm,
      ManufacturingCountryEntity,
      Item,
      ItemQualityEntity,
      ObjectCategoryEntity,
    ]),
    UserModule,
    WarehouseModule,
  ],
  exports: [
    {
      provide: 'ExportServiceInterface',
      useClass: ExportService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'ItemGroupSettingRepositoryInterface',
      useClass: ItemGroupSettingRepository,
    },
    {
      provide: 'ItemUnitSettingRepositoryInterface',
      useClass: ItemUnitSettingRepository,
    },
    {
      provide: 'ItemTypeSettingRepositoryInterface',
      useClass: ItemTypeSettingRepository,
    },
    {
      provide: 'InventoryQuantityNormRepositoryInterface',
      useClass: InventoryQuantityNormRepository,
    },
  ],
  providers: [
    {
      provide: 'ExportServiceInterface',
      useClass: ExportService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'ItemGroupSettingRepositoryInterface',
      useClass: ItemGroupSettingRepository,
    },
    {
      provide: 'ItemUnitSettingRepositoryInterface',
      useClass: ItemUnitSettingRepository,
    },
    {
      provide: 'ItemTypeSettingRepositoryInterface',
      useClass: ItemTypeSettingRepository,
    },
    {
      provide: 'InventoryQuantityNormRepositoryInterface',
      useClass: InventoryQuantityNormRepository,
    },
    {
      provide: 'ManufacturingCountryRepositoryInterface',
      useClass: ManufacturingCountryRepository,
    },
    {
      provide: 'ItemRepositoryInterface',
      useClass: ItemRepository,
    },
    {
      provide: 'ItemQualityRepositoryInterface',
      useClass: ItemQualityRepository,
    },
    {
      provide: 'ObjectCategoryRepositoryInterface',
      useClass: ObjectCategoryRepository,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
  ],
  controllers: [ExportController],
})
export class ExportModule {}
