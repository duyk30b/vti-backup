import {
  Controller,
  Inject,
  Body,
  Post,
  Get,
  Query,
  Param,
  ParseIntPipe,
  Req,
  Delete,
  Put,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { isEmpty } from 'lodash';
import { CreateBlockDto } from './dto/request/create-block.dto';
import { DeleteBlockDto } from './dto/request/delete-block.dto';
import { GetListBlockRequestDto } from './dto/request/get-list-block.request.dto';
import { UpdateBlockDto } from './dto/request/update-block.dto';
import { BlockServiceInterface } from './interface/block.service.interface';
import { GetDetailRequestDto } from '@components/item/dto/request/get-detail.request.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import {
  CREATE_BLOCK_PERMISSION,
  UPDATE_BLOCK_PERMISSION,
  DELETE_BLOCK_PERMISSION,
  DETAIL_BLOCK_PERMISSION,
  LIST_BLOCK_PERMISSION,
} from '@utils/permissions/block';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { BlockResponseDto } from './dto/response/block.response.dto';

@Controller('blocks')
export class BlockController {
  constructor(
    @Inject('BlockServiceInterface')
    private readonly blockService: BlockServiceInterface,
  ) {}

  @PermissionCode(CREATE_BLOCK_PERMISSION.code)
  @MessagePattern('create_block')
  @Post('/create')
  @ApiOperation({
    tags: ['Item', 'Block'],
    summary: 'Create new block',
    description: 'Tạo 1 kiện mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  public async CreateBlock(@Body() body: CreateBlockDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.blockService.createBlock(request);
  }

  @PermissionCode(UPDATE_BLOCK_PERMISSION.code)
  @MessagePattern('update_block')
  @Put('/:id')
  @ApiOperation({
    tags: ['Block', 'Item'],
    summary: 'Update block',
    description: 'Cập nhật thông tin kiện',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  public async UpdateBlock(
    @Param('id', new ParseIntPipe()) id,
    @Body() body: UpdateBlockDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.blockService.updateBlock({
      id,
      ...request,
    });
  }

  @PermissionCode(DELETE_BLOCK_PERMISSION.code)
  @MessagePattern('delete_block')
  @Delete('/:id')
  @ApiOperation({
    tags: ['Block', 'Item'],
    summary: 'Delete block',
    description: 'Xóa kiện',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async removeBlock(
    @Param('id', new ParseIntPipe()) id,
    @Req() body: DeleteBlockDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.blockService.deleteBlock({
      id,
      ...request,
    });
  }

  @PermissionCode(DELETE_BLOCK_PERMISSION.code)
  @MessagePattern('delete_block_multiple')
  @Delete('/multiple')
  @ApiOperation({
    tags: ['Block', 'Item'],
    summary: 'Delete multiple block',
    description: 'Xóa nhiều kiện',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async removeMultipleBlock(
    @Query() body: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.blockService.deleteMultipleBlock(request);
  }

  @PermissionCode(LIST_BLOCK_PERMISSION.code)
  @MessagePattern('get_block_list')
  @Get('/list')
  @ApiOperation({
    tags: ['Item', 'Block'],
    summary: 'List Block',
    description: 'Danh sách kiện',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: GetListBlockRequestDto,
  })
  public async getList(@Query() body: GetListBlockRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.blockService.getList(request);
  }

  @PermissionCode(DETAIL_BLOCK_PERMISSION.code)
  @MessagePattern('get_block_detail')
  @Get('/:id')
  @ApiOperation({
    tags: ['Item', 'Blocks'],
    summary: 'Block Detail',
    description: 'Chi tiết block',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: BlockResponseDto,
  })
  public async getDetail(
    @Param('id', new ParseIntPipe()) id: number,
    @Req() body: GetDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.blockService.getDetail({
      id,
      ...request,
    });
  }

  @PermissionCode(LIST_BLOCK_PERMISSION.code)
  @MessagePattern('get_block_list')
  public async getListTcp(@Body() body: GetListBlockRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.blockService.getList(request);
  }
}
