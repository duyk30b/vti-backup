import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';
import { UnitMeasuresRequest } from '@components/item/dto/request/unit-measures.request.dto';
import { UnitWeightRequest } from '@components/item/dto/request/unit-weight.request.dto';

export class BlockItemDetailDto {
  @ApiProperty({
    example: 1,
    description: 'Mã chi tiết cấu thành kiện',
  })
  @IsInt()
  @IsNotEmpty()
  itemDetailId: number;

  @ApiProperty({
    example: 1,
    description: 'Mã thành phẩm cấu thành lên chi tiết',
  })
  @IsInt()
  @IsNotEmpty()
  itemId: number;

  @ApiProperty({
    example: 1,
    description: 'Số lượng chi tiết cấu thành kiện',
  })
  @Min(1)
  @IsInt()
  @IsNotEmpty()
  quantity: number;
}

export class CreateBlockDto extends BaseDto {
  @ApiProperty({ example: 'Cái bàn', description: 'Tên kiện' })
  @MaxLength(255)
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({ example: 'BAN_GO_XXX', description: 'Mã code của kiện' })
  @MaxLength(12)
  @IsString()
  @IsNotEmpty()
  code: string;

  @ApiProperty({
    example: 'Đây là cái bàn',
    description: 'Mô tả thông tin kiện',
  })
  @MaxLength(255)
  @IsOptional()
  description: string;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: 'Chiều rộng kiện',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  width: UnitMeasuresRequest;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: 'Chiều dài kiện',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  height: UnitMeasuresRequest;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: 'Chiều cao kiện',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  long: UnitMeasuresRequest;

  @ApiProperty({
    example: { value: 1, unit: 1 },
    description: 'Khối lượng kiện',
  })
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitWeightRequest)
  weight: UnitWeightRequest;

  @ApiProperty({
    type: BlockItemDetailDto,
    example: [
      { itemDetailId: 1, itemId: 1, quantity: 2 },
      { itemDetailId: 2, itemId: 1, quantity: 4 },
    ],
    description: 'Chi tiết của kiện (nếu có)',
  })
  @ValidateNested()
  @ArrayUnique((e: BlockItemDetailDto) => `${e.itemId}_${e.itemDetailId}`)
  @ArrayNotEmpty({
    message: 'Chi tiết không được để trống',
  })
  @Type(() => BlockItemDetailDto)
  itemDetails: BlockItemDetailDto[];
}
