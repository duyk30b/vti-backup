import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray } from 'class-validator';
import { ItemResponseDto } from '@components/item/dto/response/item.response.dto';
import { MeaseuresUnitAbstractResponse } from '@components/item/dto/response/measures-unit-abstract.response.dto';
import { WeightUnitAbstractResponse } from '@components/item/dto/response/weight-unit-abstract.response.dto';
class ItemDetail {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;
}
class BlockDetail {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  packageId: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose({ name: 'itemDetailQuantity' })
  quantity: number;

  @ApiProperty()
  @Expose()
  itemDetailId: number;

  @ApiProperty()
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty()
  @Expose()
  @Type(() => ItemDetail)
  itemDetail: ItemDetail;
}

export class BlockResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  @Type(() => MeaseuresUnitAbstractResponse)
  width: MeaseuresUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => MeaseuresUnitAbstractResponse)
  height: MeaseuresUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => MeaseuresUnitAbstractResponse)
  long: MeaseuresUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => WeightUnitAbstractResponse)
  weight: WeightUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  updatedAt: string;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty({ type: BlockDetail, isArray: true })
  @Expose()
  @Type(() => BlockDetail)
  @IsArray()
  blockItemDetails: BlockDetail[];
}
