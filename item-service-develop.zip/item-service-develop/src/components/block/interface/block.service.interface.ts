import { GetListBlockRequestDto } from '../dto/request/get-list-block.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreateBlockDto } from '../dto/request/create-block.dto';
import { DeleteBlockDto } from '../dto/request/delete-block.dto';
import { UpdateBlockDto } from '../dto/request/update-block.dto';
import { GetDetailRequestDto } from '@components/item/dto/request/get-detail.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';

export interface BlockServiceInterface {
  createBlock(request: CreateBlockDto): Promise<ResponsePayload<any>>;
  updateBlock(request: UpdateBlockDto): Promise<ResponsePayload<any>>;
  deleteBlock(request: DeleteBlockDto): Promise<ResponsePayload<any>>;
  deleteMultipleBlock(request: DeleteMultipleDto): Promise<ResponsePayload<any>>;
  getList(request: GetListBlockRequestDto): Promise<ResponsePayload<any>>;
  getDetail(request: GetDetailRequestDto): Promise<ResponsePayload<any>>;
}
