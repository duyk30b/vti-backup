import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { BlockItemDetail } from '@entities/block/block-item-detail.entity';
import { BlockItemDetailDto } from '../dto/request/create-block.dto';

export interface BlockItemDetailRepositoryInterface
  extends BaseInterfaceRepository<BlockItemDetail> {
  createEntity(request: BlockItemDetailDto): BlockItemDetail;
}
