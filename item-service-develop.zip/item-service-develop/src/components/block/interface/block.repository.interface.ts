import { GetListBlockRequestDto } from '../dto/request/get-list-block.request.dto';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { Block } from '@entities/block/block.entity';
import { CreateBlockDto } from '../dto/request/create-block.dto';
import { UpdateBlockDto } from '../dto/request/update-block.dto';

export interface BlockRepositoryInterface
  extends BaseInterfaceRepository<Block> {
  createEntity(request: CreateBlockDto): Block;
  getList(request: GetListBlockRequestDto): Promise<any>;
  getDetail(id: number): Promise<any>;
  getDetailByCode(code: string): Promise<any>;
  updateEntity(
    packageUpdate: Block,
    request: UpdateBlockDto | CreateBlockDto,
  ): Block;
}
