import { plainToInstance } from 'class-transformer';
import { FilterItemDetail } from '@components/item/dto/request/filter-item-detail.dto';
import { ItemDetailRepositoryInterface } from '@components/item/interface/item-detail.repository.interface';
import { ItemRepositoryInterface } from '@components/item/interface/item.repository.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { BlockItemDetail } from '@entities/block/block-item-detail.entity';
import { Block } from '@entities/block/block.entity';
import { Injectable, Inject } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import {
  formatUnitMeasures,
  formatUnitWeight,
  validateVolumeWeightItems,
  VALIDATE_TYPE,
} from '@utils/common';
import { DataSource, In } from 'typeorm';
import { CreateBlockDto } from './dto/request/create-block.dto';
import { DeleteBlockDto } from './dto/request/delete-block.dto';
import { GetListBlockRequestDto } from './dto/request/get-list-block.request.dto';
import { UpdateBlockDto } from './dto/request/update-block.dto';
import { BlockItemDetailRepositoryInterface } from './interface/block-item-detail.repository.interface';
import { BlockRepositoryInterface } from './interface/block.repository.interface';
import { BlockServiceInterface } from './interface/block.service.interface';
import { BlockResponseDto } from './dto/response/block.response.dto';
import { PagingResponse } from '@utils/paging.response';
import { GetDetailRequestDto } from '@components/item/dto/request/get-detail.request.dto';
import { isEmpty } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { stringFormat } from '@utils/object.util';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
@Injectable()
export class BlockService implements BlockServiceInterface {
  constructor(
    @Inject('BlockRepositoryInterface')
    private readonly blockRepository: BlockRepositoryInterface,

    @Inject('BlockItemDetailRepositoryInterface')
    private readonly blockItemDetailRepository: BlockItemDetailRepositoryInterface,

    @Inject('ItemDetailRepositoryInterface')
    private readonly itemDetailRepository: ItemDetailRepositoryInterface,

    @Inject('ItemRepositoryInterface')
    private readonly itemRepository: ItemRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,

    @InjectDataSource()
    private readonly connection: DataSource,
  ) {}

  public async getList(
    payload: GetListBlockRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { data, count } = await this.blockRepository.getList(payload);
    const dataReturn = plainToInstance(BlockResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: payload.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async createBlock(request: CreateBlockDto): Promise<ResponsePayload<any>> {
    const newBlockEntity = this.blockRepository.createEntity(request);
    return await this.save(newBlockEntity, request);
  }

  async updateBlock(request: UpdateBlockDto): Promise<ResponsePayload<any>> {
    const block = await this.blockRepository.findOneById(request.id);
    if (!block) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    return await this.save(block, request);
  }

  private async save(
    blockEntity: Block,
    request: CreateBlockDto | UpdateBlockDto,
  ): Promise<ResponsePayload<any> | any> {
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const isUpdate = blockEntity.id !== undefined;
      //Validate
      const itemDetailIds = request.itemDetails.map((e) => e.itemDetailId);
      const itemDetails =
        await this.itemDetailRepository.findWithListPrimaryKey(
          request.itemDetails.map((e) => {
            return new FilterItemDetail(e.itemId, e.itemDetailId);
          }),
        );

      if (itemDetails.length !== itemDetailIds.length) {
        return new ResponseBuilder({
          invalidDetail: request.itemDetails.filter(
            (e) =>
              !itemDetails.find(
                (e2) =>
                  e.itemId === e2.itemId &&
                  e.itemDetailId === e2.itemDetailSettingId,
              ),
          ),
        })
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.ITEM_DETAIL_NOT_FOUND'))
          .build();
      }

      //Validate unquie code block
      if (!isUpdate || blockEntity.code !== request.code) {
        const block = await this.blockRepository.findByCondition({
          code: request.code,
        });

        if (block) {
          return new ResponseBuilder()
            .withCode(ResponseCodeEnum.BAD_REQUEST)
            .withMessage(await this.i18n.translate('error.CODE_EXIST'))
            .build();
        }
      }

      //Create
      if (request.itemDetails && request.itemDetails.length > 0) {
        blockEntity.blockItemDetails = request.itemDetails.map((e) =>
          this.blockItemDetailRepository.createEntity(e),
        );
      }

      if (isUpdate) {
        await queryRunner.manager.delete(BlockItemDetail, {
          blockId: blockEntity.id,
        });
        blockEntity = this.blockRepository.updateEntity(blockEntity, request);
      }

      const itemIds = request.itemDetails.map((e) => e.itemId);
      const items = await this.itemRepository.findWithRelations({
        where: {
          id: In(itemIds),
        },
      });

      // Validate volume and weight
      const checkVolume = validateVolumeWeightItems(
        {
          ...blockEntity,
          long: formatUnitMeasures(
            blockEntity.long.value,
            blockEntity.long.unit,
          ),
          width: formatUnitMeasures(
            blockEntity.width.value,
            blockEntity.width.unit,
          ),
          height: formatUnitMeasures(
            blockEntity.height.value,
            blockEntity.height.unit,
          ),
        },
        items.map((item) => ({
          ...item,
          long: formatUnitMeasures(item.long.value, item.long.unit),
          width: formatUnitMeasures(item.width.value, item.width.unit),
          height: formatUnitMeasures(item.height.value, item.height.unit),
          quantity: request.itemDetails.find((it) => it.itemId === item.id)
            ?.quantity,
        })),
        VALIDATE_TYPE.VOLUME,
      );

      const checkWeight = validateVolumeWeightItems(
        {
          ...blockEntity,
          weight: formatUnitWeight(
            blockEntity.weight.value,
            blockEntity.weight.unit,
          ),
        },
        items.map((item) => ({
          ...item,
          weight: formatUnitMeasures(item.weight.value, item.weight.unit),
          quantity: request.itemDetails.find((it) => it.itemId === item.id)
            ?.quantity,
        })),
        VALIDATE_TYPE.WEIGHT,
      );

      if (!checkVolume) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.TOTAL_VOLUME_ITEMS_EXCEEDS_BLOCK_VOLUME',
            ),
          )
          .build();
      }

      if (!checkWeight) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.TOTAL_WEIGHT_ITEMS_EXCEEDS_BLOCK_WEIGHT',
            ),
          )
          .build();
      }

      const saveBlock = await queryRunner.manager.save(blockEntity);
      await queryRunner.commitTransaction();
      return new ResponseBuilder(saveBlock)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  async deleteBlock(request: DeleteBlockDto): Promise<ResponsePayload<any>> {
    const block = await this.blockRepository.findOneWithRelations({
      relations: ['blockItemDetails'],
      where: {
        id: request.id,
      },
    });
    if (!block) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await this.connection.manager.remove(block.blockItemDetails);
      await this.connection.manager.remove(block);
      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  async deleteMultipleBlock(
    request: DeleteMultipleDto,
  ): Promise<ResponsePayload<any>> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const blocks = await this.blockRepository.findWithRelations({
      relations: ['blockItemDetails'],
      where: {
        id: In(ids),
      },
    });

    const blockIds = blocks.map((block) => block.id);
    if (blocks.length !== ids.length) {
      ids.forEach((id) => {
        if (!blockIds.includes(id)) failIdsList.push(id);
      });
    }

    const validIds = blocks
      .filter((block) => !failIdsList.includes(block.id))
      .map((block) => block.id);

    const queryRunner = this.connection.createQueryRunner();
    try {
      if (!isEmpty(validIds)) {
        await queryRunner.startTransaction();
        await queryRunner.manager.delete(BlockItemDetail, {
          blockId: In(validIds),
        });
        await queryRunner.manager.delete(Block, validIds);
        await queryRunner.commitTransaction();
      }
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    } finally {
      await queryRunner.release();
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getDetail(payload: GetDetailRequestDto) {
    const { id } = payload;
    const item = await this.blockRepository.getDetail(id);
    if (isEmpty(item)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.ITEM_NOT_FOUND'),
      ).toResponse();
    }
    const response = plainToInstance(BlockResponseDto, item, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
