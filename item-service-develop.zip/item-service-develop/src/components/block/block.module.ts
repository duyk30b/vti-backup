import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ItemDetail } from '@entities/item/item-detail.entity';
import { ItemDetailRepository } from '@repositories/item-detail.repository';
import { Block } from '@entities/block/block.entity';
import { Item } from '@entities/item/item.entity';
import { BlockItemDetail } from '@entities/block/block-item-detail.entity';
import { BlockController } from './block.controller';
import { BlockItemDetailRepository } from '@repositories/block-item-detail.repository';
import { BlockRepository } from '@repositories/block.repository';
import { ItemModule } from '@components/item/item.module';
import { BlockService } from './block.service';
import { ItemRepository } from '@repositories/item.repository';

@Module({
  imports: [
    TypeOrmModule.forFeature([Block, BlockItemDetail, ItemDetail, Item]),
    ItemModule,
  ],
  providers: [
    {
      provide: 'BlockRepositoryInterface',
      useClass: BlockRepository,
    },
    {
      provide: 'BlockItemDetailRepositoryInterface',
      useClass: BlockItemDetailRepository,
    },
    {
      provide: 'ItemDetailRepositoryInterface',
      useClass: ItemDetailRepository,
    },
    {
      provide: 'BlockServiceInterface',
      useClass: BlockService,
    },
    {
      provide: 'ItemRepositoryInterface',
      useClass: ItemRepository,
    },
  ],
  controllers: [BlockController],
  exports: [
    {
      provide: 'BlockRepositoryInterface',
      useClass: BlockRepository,
    },
    {
      provide: 'BlockItemDetailRepositoryInterface',
      useClass: BlockItemDetailRepository,
    },
  ],
})
export class BlockModule {}
