import { ImportDataAbstract } from '@core/abstracts/import-data.abstract';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { ItemDetail } from '@entities/item/item-detail.entity';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectDataSource } from '@nestjs/typeorm';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty, keyBy, map, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, In } from 'typeorm';
import { ItemDetailSettingRepositoryInterface } from '../interface/item-detail-setting.repository.interface';
import { ItemRepositoryInterface } from '../interface/item.repository.interface';
import { REGEX_ITEM_CODE } from '../item.constant';
@Injectable()
export class ItemDetailsImport extends ImportDataAbstract {
  private readonly FIELD_TEMPLATE_ITEM_DETAIL_CONST = {
    CODE: {
      DB_COL_NAME: 'code',
      COL_NAME: ['Mã sản phẩm', 'Item code', '製品コード'],
      MAX_LENGTH: 7,
      ALLOW_NULL: false,
    },
    ITEM_DETAIL_CODE: {
      DB_COL_NAME: 'itemDetailCode',
      COL_NAME: ['Mã chi tiết', 'Detail code', '詳細なコード'],
      MAX_LENGTH: 4,
      ALLOW_NULL: false,
    },
    ITEM_DETAIL_QUANTITY: {
      DB_COL_NAME: 'itemDetailQuantity',
      COL_NAME: ['Số lượng chi tiết', 'Detail quantity', '詳細数量'],
      MAX_LENGTH: 2,
      ALLOW_NULL: false,
    },
    REQUIRED_COL_NUM: 4,
  };

  private readonly SHEET_NAME = 'Chi tiết sản phẩm';

  constructor(
    @Inject('ItemRepositoryInterface')
    private readonly itemRepositoryRepository: ItemRepositoryInterface,

    @Inject('ItemDetailSettingRepositoryInterface')
    private readonly itemDetailSettingRepository: ItemDetailSettingRepositoryInterface,

    @InjectDataSource()
    private readonly connection: DataSource,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    const arrayField = [];
    for (const [key, value] of Object.entries(
      this.FIELD_TEMPLATE_ITEM_DETAIL_CONST,
    )) {
      arrayField.push(value);
    }

    this.fieldsMap.groupSet([2, 3, 4], arrayField);
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
    error: number,
    total: number,
    userId: number,
  ): Promise<ImportResponseDto | any> {
    const getData = await Promise.all([
      this.itemRepositoryRepository.findWithRelations({
        where: {
          code: In(dataDto.map((i) => i.code)),
        },
      }),
      this.itemDetailSettingRepository.findWithRelations({
        where: {
          code: In(dataDto.map((i) => i.itemDetailCode)),
        },
      }),
    ]);

    const itemMaps = keyBy(getData[0], 'code');
    const itemDetailMaps = keyBy(getData[1], 'code');
    const entities = [];
    const valid = [];
    const {
      successMsg,
      unsuccessMsg,
      itemCodeNotFound,
      itemDetailCodeNotFound,
      quantityMustBeGreaterThanZero,
      malformedItemCode,
      sameItemDetailCodeInDataImport,
    } = await this.getMessage();
    dataDto.forEach((data) => {
      const { i, action, code, itemDetailCode, itemDetailQuantity } = data;
      const logRow = {
        id: i,
        row: i,
        action: action,
      } as ImportResultDto;
      const sameItemDetailNew = dataDto.filter(
        (i) => i.itemDetailCode === itemDetailCode,
      );
      const msgLogs = [];
      if (isEmpty(code.match(REGEX_ITEM_CODE))) {
        msgLogs.push(malformedItemCode);
      } else if (!itemMaps[code]) {
        msgLogs.push(itemCodeNotFound);
      } else if (!itemDetailMaps[itemDetailCode]) {
        msgLogs.push(itemDetailCodeNotFound);
      } else if (itemDetailQuantity < 0) {
        msgLogs.push(quantityMustBeGreaterThanZero);
      } else if (sameItemDetailNew.length > 1) {
        msgLogs.push(sameItemDetailCodeInDataImport);
      } else {
        const itemDetailEntity = new ItemDetail();
        itemDetailEntity.itemId = itemMaps[code].id;
        itemDetailEntity.itemDetailSettingId =
          itemDetailMaps[itemDetailCode].id;
        itemDetailEntity.itemDetailQuantity = itemDetailQuantity;
        entities.push(itemDetailEntity);
      }
      if (isEmpty(msgLogs)) {
        logRow.log = [successMsg];
        valid.push(logRow);
      } else {
        logRow.log = msgLogs;
        logs.push(logRow);
      }
    });
    const response = new ImportResponseDto();

    if (!isEmpty(entities)) {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        const itemIds = uniq(map(entities, 'itemId'));
        if (!isEmpty(itemIds)) {
          await queryRunner.manager.delete(ItemDetail, {
            itemId: In(itemIds),
          });
        }
        await queryRunner.manager.save(ItemDetail, entities);
        await queryRunner.commitTransaction();
        response.successCount = valid.length;
      } catch (error) {
        await queryRunner.rollbackTransaction();
        response.successCount = 0;
        valid.forEach((e) => (e.log = [unsuccessMsg]));
      } finally {
        await queryRunner.release();
        logs.push(...valid);
      }
    }
    response.result = logs;
    response.totalCount = total;

    return response;
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<ImportResponseDto>> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_ITEM_DETAIL_CONST.REQUIRED_COL_NUM,
      this.SHEET_NAME,
    );
  }
}
