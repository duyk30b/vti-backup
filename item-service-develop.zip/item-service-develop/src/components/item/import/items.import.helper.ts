import { ImportDataAbstract } from '@core/abstracts/import-data.abstract';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectDataSource } from '@nestjs/typeorm';
import { ResponsePayload } from '@utils/response-payload';
import { compact, filter, first, isEmpty, keyBy, map, uniq } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, In } from 'typeorm';
import { ItemRepositoryInterface } from '../interface/item.repository.interface';
import { ItemGroupSettingRepositoryInterface } from '../../item-setting/interface/item-group-setting.repository.interface';
import { ItemUnitSettingRepositoryInterface } from '../interface/item-unit-setting.repository.interface';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import {
  DATA_DEFAULT_MEASURES,
  DATA_DEFAULT_WEIGHT,
  UnitMeasuresEnum,
  UnitWeightEnum,
} from '@utils/constant';
import { CreateItemDto } from '../dto/request/create-item.dto';
import { ItemTypeSettingRepositoryInterface } from '../interface/item-type-setting.repository.interface';
import { UpdateItemDto } from '../dto/request/update-item.dto';
import { ItemWarehouseLocation } from '@entities/item/item-warehouse-locations.entity';
import { Item } from '@entities/item/item.entity';
import { REGEX_ITEM_CODE } from '../item.constant';
import { ItemGroupSetting } from '@entities/item/item-group-setting.entity';
import { ItemUnitSetting } from '@entities/item/item-unit-setting.entity';
import { ItemTypeSetting } from '@entities/item/item-type-setting.entity';
import { EnumBoolean } from '@utils/common';

@Injectable()
export class ItemsImport extends ImportDataAbstract {
  private readonly FIELD_TEMPLATE_ITEM_CONST = {
    CODE: {
      DB_COL_NAME: 'code',
      COL_NAME: ['Mã sản phẩm', 'Item code', '商品コード'],
      MAX_LENGTH: 7,
      ALLOW_NULL: false,
      REGEX: /^([a-zA-Z0-9]+)$/,
    },
    NAME: {
      DB_COL_NAME: 'name',
      COL_NAME: ['Tên sản phẩm', 'Item name', '商品名'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    GROUP: {
      DB_COL_NAME: 'itemGroupCode',
      COL_NAME: ['Mã nhóm sản phẩm', 'Item group code', '商品グループコード'],
      MAX_LENGTH: 4,
      ALLOW_NULL: false,
    },
    TYPE: {
      DB_COL_NAME: 'itemTypeCode',
      COL_NAME: ['Mã kiểu sản phẩm', 'Item type code', '商品タイプコード'],
      MAX_LENGTH: 2,
      ALLOW_NULL: false,
    },
    UNIT: {
      DB_COL_NAME: 'itemUnitCode',
      COL_NAME: ['Mã đơn vị sản phẩm', 'Item unit code', '商品単位コード'],
      MAX_LENGTH: 2,
      ALLOW_NULL: false,
    },
    PRICE: {
      DB_COL_NAME: 'price',
      COL_NAME: ['Giá sản phẩm', 'Item price', '商品価格'],
      MAX_LENGTH: 10,
      ALLOW_NULL: true,
      default: 0,
    },
    EXPIRE: {
      DB_COL_NAME: 'dayExpire',
      COL_NAME: ['Hạn sử dụng sản phẩm', 'Expiry', '使用期限'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
      default: 0,
    },
    STORAGE_SPACE: {
      DB_COL_NAME: 'storageSpace',
      COL_NAME: ['Không gian lưu trữ', 'Storaging space', '保管スペース'],
      MAX_LENGTH: 1,
      ALLOW_NULL: false,
      default: 0,
    },
    LONG: {
      DB_COL_NAME: 'long',
      COL_NAME: ['Chiều dài', 'Long', '長辺'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
      default: 0,
    },
    LONG_UNIT: {
      DB_COL_NAME: 'longUnit',
      COL_NAME: ['Đơn vị chiều dài', 'Unit', '長辺の単位'],
      MAX_LENGTH: 20,
      ALLOW_NULL: true,
      default: 0,
    },
    WIDTH: {
      DB_COL_NAME: 'width',
      COL_NAME: ['Chiều rộng', 'Width', '短辺'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
      default: 0,
    },
    WIDTH_UNIT: {
      DB_COL_NAME: 'widthUnit',
      COL_NAME: ['Đơn vị chiều rộng', 'Unit', '短辺の単位'],
      MAX_LENGTH: 20,
      ALLOW_NULL: true,
      default: 0,
    },
    HEIGHT: {
      DB_COL_NAME: 'height',
      COL_NAME: ['Chiều cao', 'Height', '厚さ'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
      default: 0,
    },
    HEIGHT_UNIT: {
      DB_COL_NAME: 'heightUnit',
      COL_NAME: ['Đơn vị chiều cao', 'Unit', '厚さの単位'],
      MAX_LENGTH: 20,
      ALLOW_NULL: true,
      default: 0,
    },
    WEIGHT: {
      DB_COL_NAME: 'weight',
      COL_NAME: ['Khối lượng', 'Weight', '重量'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
      default: 0,
    },
    WEIGHT_UNIT: {
      DB_COL_NAME: 'weightUnit',
      COL_NAME: ['Đơn vị khối lượng', 'Unit', '重量の単位'],
      MAX_LENGTH: 20,
      ALLOW_NULL: true,
      default: 0,
    },
    LOCATION: {
      DB_COL_NAME: 'location',
      COL_NAME: ['Vị trí lưu kho', 'Storaging location', '保管ロケーション'],
      MAX_LENGTH: 1,
      ALLOW_NULL: false,
      default: 0,
    },
    WAREHOUSE: {
      DB_COL_NAME: 'warehouseCode',
      COL_NAME: ['Mã kho', '倉庫コード', 'Warehouse code'],
      MAX_LENGTH: 4,
      ALLOW_NULL: false,
    },
    SECTOR: {
      DB_COL_NAME: 'warehouseSectorCode',
      COL_NAME: ['Mã khu vực', 'Warehouse sector code', 'エリアコード'],
      MAX_LENGTH: 50,
      ALLOW_NULL: false,
    },
    SHELF: {
      DB_COL_NAME: 'warehouseShelfCode',
      COL_NAME: ['Mã kệ', 'Warehouse shelf code', '棚コード'],
      MAX_LENGTH: 50,
      ALLOW_NULL: false,
    },
    DESCRIPTION: {
      DB_COL_NAME: 'description',
      COL_NAME: ['Mô tả sản phẩm', 'Item description', '説明'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    IS_PRODUCTION: {
      DB_COL_NAME: 'isProductionObject',
      COL_NAME: ['Đối tượng sản xuất', 'Production Object', '製造対象'],
      MAX_LENGTH: 1,
      default: false,
      ALLOW_NULL: true,
    },
    REQUIRED_COL_NUM: 23,
  };

  private readonly SHEET_NAME = 'Sản phẩm';

  constructor(
    @Inject('ItemRepositoryInterface')
    private readonly itemRepositoryRepository: ItemRepositoryInterface,

    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,

    @Inject('ItemGroupSettingRepositoryInterface')
    private readonly itemGroupSettingRepository: ItemGroupSettingRepositoryInterface,

    @Inject('ItemUnitSettingRepositoryInterface')
    private readonly itemUnitSettingRepository: ItemUnitSettingRepositoryInterface,

    @Inject('ItemTypeSettingRepositoryInterface')
    private readonly itemTypeSettingRepository: ItemTypeSettingRepositoryInterface,

    @InjectDataSource()
    private readonly connection: DataSource,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    const arrayField = [];
    for (const [, value] of Object.entries(this.FIELD_TEMPLATE_ITEM_CONST)) {
      arrayField.push(value);
    }

    this.fieldsMap.groupSet(
      [
        2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21,
        22, 23,
      ],
      arrayField,
    );
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
    error: number,
    total: number,
    userId: number,
  ): Promise<ImportResponseDto | any> {
    const itemCodeImport = [];
    const itemGroupCodeImport = [];
    const itemUnitCodeImport = [];
    const itemTypeCodeImport = [];
    const warehouseCodeImport = [];

    for (let i = 0; i < dataDto.length; i++) {
      itemCodeImport.push(dataDto[i].code);
      itemGroupCodeImport.push(dataDto[i].itemGroupCode);
      itemUnitCodeImport.push(dataDto[i].itemUnitCode);
      itemTypeCodeImport.push(dataDto[i].itemTypeCode);
      warehouseCodeImport.push(dataDto[i].warehouseCode);
    }
    const getData = await Promise.all([
      this.itemRepositoryRepository.findWithRelations({
        where: {
          code: In(compact(uniq(itemCodeImport))),
        },
      }),
      this.itemGroupSettingRepository.findWithRelations({
        where: {
          code: In(compact(uniq(itemGroupCodeImport))),
        },
      }),
      this.itemUnitSettingRepository.findWithRelations({
        where: {
          code: In(compact(uniq(itemUnitCodeImport))),
        },
      }),
      this.itemTypeSettingRepository.findWithRelations({
        where: {
          code: In(compact(uniq(itemTypeCodeImport))),
        },
      }),
      this.warehouseService.getWarehousesByCodes(
        compact(uniq(warehouseCodeImport)),
      ),
    ]);

    const findItemByCodeMap = keyBy(getData[0], 'code');
    const findGroupByCodeMap = keyBy(getData[1], 'code');
    const findUnitByCodeMap = keyBy(getData[2], 'code');
    const findTypeByCodeMap = keyBy(getData[3], 'code');
    const findWarehouseByCodeMap = keyBy(getData[4], 'code');
    const result = {
      entities: [],
      location: [],
    };
    const valid = [];

    const messages = await this.getMessage();
    for (const data of dataDto) {
      const {
        i,
        action,
        code,
        name,
        itemGroupCode,
        itemUnitCode,
        itemTypeCode,
        storageSpace,
        long,
        width,
        height,
        weight,
        longUnit,
        widthUnit,
        heightUnit,
        weightUnit,
        location,
        warehouseCode,
        warehouseSectorCode,
        warehouseShelfCode,
        price,
        dayExpire,
        isProductionObject,
        description,
      } = data;
      const logRow = {
        id: i,
        row: i,
        action: action,
      } as ImportResultDto;
      const itemOld = findItemByCodeMap[code] ? findItemByCodeMap[code] : null;
      const itemGroup = findGroupByCodeMap[itemGroupCode]
        ? findGroupByCodeMap[itemGroupCode]
        : null;
      const itemUnit = findUnitByCodeMap[itemUnitCode]
        ? findUnitByCodeMap[itemUnitCode]
        : null;
      const itemType = findTypeByCodeMap[itemTypeCode]
        ? findTypeByCodeMap[itemTypeCode]
        : null;
      const warehouse = findWarehouseByCodeMap[warehouseCode]
        ? findWarehouseByCodeMap[warehouseCode]
        : null;
      const sameItemCode = dataDto.filter((i) => i.code === code);
      const msgLogs = [];
      const warehouseSectorLocation = warehouse
        ? filter(
            warehouse.warehouseSectors,
            (record) => record.code === warehouseSectorCode.toString(),
          )
        : [];

      const warehouseShelfLocation = !isEmpty(warehouseSectorLocation)
        ? filter(
            first(warehouseSectorLocation).warehouseShelfs,
            (record) => record.code === warehouseShelfCode.toString(),
          )
        : [];
      const warehouseLocationId = warehouse ? warehouse.id : null;
      const warehouseSectorLocationId = !isEmpty(warehouseSectorLocation)
        ? first(warehouseSectorLocation).id
        : null;
      const warehouseShelfLocationId = !isEmpty(warehouseShelfLocation)
        ? first(warehouseShelfLocation).id
        : null;
      if (action.toLowerCase() === messages.addText) {
        let msgLog = '';
        msgLog = this.validateItemImport(
          false,
          data,
          itemOld,
          itemGroup,
          itemUnit,
          itemType,
          warehouse,
          sameItemCode,
          messages,
        );

        if (msgLog === '') {
          const createItemDto = new CreateItemDto();
          createItemDto.name = name;
          createItemDto.code = code;
          createItemDto.itemTypeId = itemType.id;
          createItemDto.itemUnitId = itemUnit.id;
          createItemDto.description = description;
          createItemDto.userId = userId;
          const entity =
            this.itemRepositoryRepository.createEntity(createItemDto);
          result.entities.push(entity);
          if (location.toLowerCase() === EnumBoolean.YES.toLowerCase()) {
            result.location.push({
              itemCode: code,
              warehouseId: warehouseLocationId,
              warehouseSectorId: warehouseSectorLocationId,
              warehouseShelfId: warehouseShelfLocationId,
            });
          }
        } else {
          msgLogs.push(msgLog);
        }
      } else if (action.toLowerCase() === messages.updateText) {
        let msgLog = '';
        msgLog = this.validateItemImport(
          true,
          data,
          itemOld,
          itemGroup,
          itemUnit,
          itemType,
          warehouse,
          sameItemCode,
          messages,
        );

        if (msgLog === '') {
          const updateItemDto = new UpdateItemDto();
          updateItemDto.name = name;
          updateItemDto.code = code;
          updateItemDto.itemTypeId = findTypeByCodeMap[itemTypeCode].id;
          updateItemDto.itemUnitId = findUnitByCodeMap[itemUnitCode].id;
          updateItemDto.description = description;

          const entity = this.itemRepositoryRepository.updateEntity(
            itemOld,
            updateItemDto,
          );

          result.entities.push(entity);
          if (location.toLowerCase() === EnumBoolean.YES.toLowerCase()) {
            result.location.push({
              itemCode: code,
              warehouseId: warehouseLocationId,
              warehouseSectorId: warehouseSectorLocationId,
              warehouseShelfId: warehouseShelfLocationId,
            });
          }
        } else {
          msgLogs.push(msgLog);
        }
      }

      if (isEmpty(msgLogs)) {
        logRow.log = [messages.successMsg];
        valid.push(logRow);
      } else {
        logRow.log = msgLogs;
        logs.push(logRow);
      }
    }

    let successCount = 0;
    if (!isEmpty(result.entities)) {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        const itemIds = uniq(map(result.entities, 'id'));
        if (!isEmpty(itemIds)) {
          await queryRunner.manager.delete(ItemWarehouseLocation, {
            itemId: In(itemIds),
          });
        }

        const items = await queryRunner.manager.save(Item, result.entities);
        const itemMaps = keyBy(items, 'code');
        const itemWarehouses = result.location.map((record) => ({
          itemId: itemMaps[record.itemCode].id,
          warehouseId: record.warehouseId,
          warehouseSectorId: record.warehouseSectorId,
          warehouseShelfId: record.warehouseShelfId,
        }));
        await queryRunner.manager.save(ItemWarehouseLocation, itemWarehouses);
        await queryRunner.commitTransaction();
        successCount = valid.length;
      } catch (error) {
        await queryRunner.rollbackTransaction();
        valid.forEach((e) => (e.log = [messages.unsuccessMsg]));
      } finally {
        await queryRunner.release();
        logs.push(...valid);
      }
    }

    return {
      result: logs,
      totalCount: total,
      successCount: successCount,
    };
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<ImportResponseDto>> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_ITEM_CONST.REQUIRED_COL_NUM,
      this.SHEET_NAME,
    );
  }

  private validateItemImport(
    isUpdate: boolean,
    itemNew: any,
    itemOld: Item,
    itemGroup: ItemGroupSetting,
    itemUnit: ItemUnitSetting,
    itemType: ItemTypeSetting,
    warehouse: any,
    sameItemCode: any[],
    messages: any,
  ): any {
    const {
      code,
      storageSpace,
      long,
      width,
      height,
      longUnit,
      widthUnit,
      heightUnit,
      location,
      warehouseCode,
      warehouseSectorCode,
      warehouseShelfCode,
      price,
      dayExpire,
    } = itemNew;

    const {
      duplicateCodeOrNameMsg,
      codeNotExistMsg,
      groupNotFound,
      unitNotFound,
      typeNotFound,
      isValidStorageSpace,
      missingWarehouseCode,
      incorrectWarehouseShelfCode,
      incorrectWarehouseSectorCode,
      incorrectWarehouseCode,
      malformedItemCode,
      dayExpireMustBeGreaterThanOrEqualZero,
      priceMustBeGreaterThanOrEqualZero,
      sameItemCodeInDataImport,
    } = messages;

    if (isUpdate && !itemOld) return codeNotExistMsg;
    if (!isUpdate && itemOld) return duplicateCodeOrNameMsg;
    if (isEmpty(code.match(REGEX_ITEM_CODE))) return malformedItemCode;
    if (!itemGroup) return groupNotFound;
    if (!itemUnit) return unitNotFound;
    if (!itemType) return typeNotFound;
    if (
      storageSpace.toLowerCase() === EnumBoolean.YES.toLowerCase() &&
      (!long || !longUnit || !width || !widthUnit || !height || !heightUnit)
    )
      return isValidStorageSpace;
    if (
      location.toLowerCase() === EnumBoolean.YES.toLowerCase() &&
      !warehouseCode
    )
      return missingWarehouseCode;
    if (location.toLowerCase() === EnumBoolean.YES.toLowerCase() && !warehouse)
      return incorrectWarehouseCode;
    if (location.toLowerCase() === EnumBoolean.YES.toLowerCase() && warehouse) {
      const warehouseSectorLocation = warehouse
        ? filter(
            warehouse.warehouseSectors,
            (record) => record.code === warehouseSectorCode.toString(),
          )
        : [];
      if (warehouseSectorCode && isEmpty(warehouseSectorLocation))
        return incorrectWarehouseSectorCode;
      const warehouseShelfLocation = !isEmpty(warehouseSectorLocation)
        ? filter(
            first(warehouseSectorLocation).warehouseShelfs,
            (record) => record.code === warehouseShelfCode.toString(),
          )
        : [];
      if (warehouseShelfCode && isEmpty(warehouseShelfLocation))
        return incorrectWarehouseShelfCode;
    }
    if (sameItemCode.length > 1) return sameItemCodeInDataImport;
    if (price && Number(price) < 0) return priceMustBeGreaterThanOrEqualZero;
    if (dayExpire && Number(dayExpire) <= 0)
      return dayExpireMustBeGreaterThanOrEqualZero;
    return '';
  }
}
