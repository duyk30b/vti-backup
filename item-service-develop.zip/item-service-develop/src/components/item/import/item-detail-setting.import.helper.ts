import { ImportDataAbstract } from '@core/abstracts/import-data.abstract';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectDataSource } from '@nestjs/typeorm';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty, keyBy } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, In } from 'typeorm';
import { ItemDetailSettingRepositoryInterface } from '../interface/item-detail-setting.repository.interface';

@Injectable()
export class ItemDetailSettingImport extends ImportDataAbstract {
  private readonly FIELD_TEMPLATE_CONST = {
    CODE: {
      DB_COL_NAME: 'code',
      COL_NAME: ['Mã', 'Detail code', '部品コード'],
      MAX_LENGTH: 50,
      ALLOW_NULL: false,
      REGEX: /^([a-zA-Z0-9]+)$/,
    },
    NAME: {
      DB_COL_NAME: 'name',
      COL_NAME: ['Tên', 'Detail name', '部品名'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    DESCRIPTION: {
      DB_COL_NAME: 'description',
      COL_NAME: ['Mô tả', 'Description', '説明'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    REQUIRED_COL_NUM: 4,
  };

  constructor(
    @Inject('ItemDetailSettingRepositoryInterface')
    private readonly itemDetailSettingRepository: ItemDetailSettingRepositoryInterface,
    @InjectDataSource()
    private readonly connection: DataSource,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    this.fieldsMap.groupSet(
      [2, 3, 4],
      [
        this.FIELD_TEMPLATE_CONST.CODE,
        this.FIELD_TEMPLATE_CONST.NAME,
        this.FIELD_TEMPLATE_CONST.DESCRIPTION,
      ],
    );
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
    error: number,
    total: number,
  ): Promise<ImportResponseDto> {
    const findByCode = await this.itemDetailSettingRepository.findWithRelations(
      {
        where: {
          code: In(dataDto.map((i) => i.code)),
        },
      },
    );
    const findByName = await this.itemDetailSettingRepository.findWithRelations(
      {
        where: {
          name: In(dataDto.map((i) => i.name)),
        },
      },
    );

    findByCode.forEach((i) => Object.assign(i, { type: 'old' }));
    findByName.forEach((i) => Object.assign(i, { type: 'old' }));

    const findByCodeMap = keyBy(findByCode, 'code');
    const findByNameMap = keyBy(findByName, 'name');
    const entities = [];
    const valid = [];
    const {
      duplicateCodeOrNameMsg,
      codeNotExistMsg,
      successMsg,
      unsuccessMsg,
      addText,
      updateText,
    } = await this.getMessage();
    dataDto.forEach((data) => {
      const { i, action, code, name } = data;
      const logRow = {
        id: i,
        row: i,
        action: action,
      } as ImportResultDto;
      const msgLogs = [];
      if (action.toLowerCase() === addText) {
        if (findByCodeMap[code] || findByNameMap[name]) {
          msgLogs.push(duplicateCodeOrNameMsg);
        } else {
          const entity = this.itemDetailSettingRepository.createEntity(data);
          entities.push(entity);
          Object.assign(entity, { type: 'new' });
          findByCodeMap[code] = entity;
          findByNameMap[name] = entity;
        }
      } else if (action.toLowerCase() === updateText) {
        if (findByCodeMap[code] && findByCodeMap[code]?.['type'] === 'old') {
          if (
            findByNameMap[name] &&
            findByNameMap[name].id != findByCodeMap[code].id
          ) {
            msgLogs.push(duplicateCodeOrNameMsg);
          } else {
            const entity = this.itemDetailSettingRepository.updateEntity(
              findByCodeMap[code],
              data,
            );
            entities.push(entity);
            Object.assign(entity, { type: 'new' });
            findByCodeMap[code] = entity;
            findByNameMap[name] = entity;
          }
        } else {
          msgLogs.push(codeNotExistMsg);
        }
      }
      if (isEmpty(msgLogs)) {
        logRow.log = [successMsg];
        valid.push(logRow);
      } else {
        logRow.log = msgLogs;
        logs.push(logRow);
      }
    });
    const response = new ImportResponseDto();
    if (!isEmpty(entities)) {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(entities);
        await queryRunner.commitTransaction();
        response.successCount = valid.length;
      } catch (error) {
        await queryRunner.rollbackTransaction();
        response.successCount = 0;
        valid.forEach((l) => (l.log = [unsuccessMsg]));
      } finally {
        await queryRunner.release();
        logs.push(...valid);
      }
    }
    response.result = logs;
    response.totalCount = total;
    response.result;
    return response;
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<ImportResponseDto | any>> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_CONST.REQUIRED_COL_NUM,
    );
  }
}
