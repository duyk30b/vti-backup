import { ExoBarcodeQuery } from '@components/item/dto/request/qr-code/exo-barcode.query';
import { ImoBarcodeQuery } from '@components/item/dto/request/qr-code/imo-barcode.query';
import { InfoItemBarcodeQuery } from '@components/item/dto/request/qr-code/info-item.query';
import { InventoryItemBarcodeQuery } from '@components/item/dto/request/qr-code/inventory-item-barcode.query';
import { ItemBarcodeQuery } from '@components/item/dto/request/qr-code/item-barcode.query';
import { ItemBarcodeScanQuery } from '@components/item/dto/request/qr-code/item-scan.query';
import { POBarcodeQuery } from '@components/item/dto/request/qr-code/po-barcode.query';
import { PrOBarcodeQuery } from '@components/item/dto/request/qr-code/pro-barcode.query';
import { SOItemBarcodeQuery } from '@components/item/dto/request/qr-code/so-item-barcode.query';
import { StockItemBarcodeQuery } from '@components/item/dto/request/qr-code/stock-item-barcode.query';
import { SuggestCollectedByPoExportIdBarcodeQuery } from '@components/item/dto/request/qr-code/suggest-collected-by-so-export-id.query';
import { SuggestStoredByPoImportIdBarcodeQuery } from '@components/item/dto/request/qr-code/suggest-stored-by-po-import-id-barcode.query';
import { SuggestStoredByRoIdBarcodeQuery } from '@components/item/dto/request/qr-code/suugest-stored-by-ro-id.query.dto';
import { TransitItemBarcodeQuery } from '@components/item/dto/request/qr-code/transit-item-barcode.query';
import { ItemBarcodeTypeEnum } from '@components/item/item.constant';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ApiError } from '@utils/api.error';
import { plainToInstance } from 'class-transformer';
import { validate, ValidationError } from 'class-validator';

export const barcodeScanValidator = async (
  plain,
): Promise<ItemBarcodeScanQuery & any> => {
  const { type } = plain;
  let transformed = null;
  if (!type) {
    transformed = plainToInstance(ItemBarcodeQuery, plain);
  }

  switch (type) {
    case ItemBarcodeTypeEnum.PO: {
      transformed = plainToInstance(POBarcodeQuery, plain);
      break;
    }

    case ItemBarcodeTypeEnum.PRO: {
      transformed = plainToInstance(PrOBarcodeQuery, plain);
      break;
    }
    case ItemBarcodeTypeEnum.IMO: {
      transformed = plainToInstance(ImoBarcodeQuery, plain);
      break;
    }
    case ItemBarcodeTypeEnum.EMO: {
      transformed = plainToInstance(ExoBarcodeQuery, plain);
      break;
    }
    case ItemBarcodeTypeEnum.SO: {
      transformed = plainToInstance(SOItemBarcodeQuery, plain);
      break;
    }
    case ItemBarcodeTypeEnum.TRANSFER: {
      transformed = plainToInstance(TransitItemBarcodeQuery, plain);
      break;
    }
    case ItemBarcodeTypeEnum.INVENTORY: {
      transformed = plainToInstance(InventoryItemBarcodeQuery, plain);
      break;
    }
    case ItemBarcodeTypeEnum.POI: {
      transformed = plainToInstance(
        SuggestStoredByPoImportIdBarcodeQuery,
        plain,
      );
      break;
    }
    case ItemBarcodeTypeEnum.SOE: {
      transformed = plainToInstance(
        SuggestCollectedByPoExportIdBarcodeQuery,
        plain,
      );
      break;
    }
    case ItemBarcodeTypeEnum.RO: {
      transformed = plainToInstance(SuggestStoredByRoIdBarcodeQuery, plain);
      break;
    }
    case ItemBarcodeTypeEnum.INFO_ITEM: {
      transformed = plainToInstance(InfoItemBarcodeQuery, plain);
      break;
    }
    default: {
      transformed = plainToInstance(StockItemBarcodeQuery, plain);
      break;
    }
  }

  if (Array.isArray(transformed)) {
    return [
      transformed,
      new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        'Only accept object',
      ).toResponse(),
    ];
  }

  const errors = await validate(
    transformed,
    Object.assign({ whitelist: true }, {}),
  );
  if (errors.length) {
    return [
      transformed,
      new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        getMessage(errors),
      ).toResponse(),
    ];
  }

  return [transformed, null];
};

function getMessage(errors: ValidationError[]): string {
  const error = errors[0];
  if (!error) return 'Unknown error';

  if (!error.children || !error.children.length) {
    return Object.values(error.constraints)[0];
  }

  return getMessage(error.children);
}
