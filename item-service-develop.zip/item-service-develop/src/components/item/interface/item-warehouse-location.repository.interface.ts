import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ItemWarehouseLocation } from '@entities/item/item-warehouse-locations.entity';

export interface ItemWarehouseLocationRepositoryInterface
  extends BaseInterfaceRepository<ItemWarehouseLocation> {
}
