import { FilterItemByCondition } from './../../item-warehouse/dto/request/get-item-stock-available.request.dto';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ItemStockWarehouseLocatorEntity } from '@entities/item/item-stock-warehouse-locator.entity';
import { CreateItemStockWarehouseLocatorRequestDto } from '../dto/request/create-item-stock-warehouse-locator-request.dto';
import { GetItemStockMovementWarehouseShelfFloorByItemIdsDto } from '../dto/request/get-item-stock-movement-warehouse-shelf-floor-item-ids.request.dto';
import { GetItemWarehouseStockRequestDto } from '../dto/request/get-item-stock.dto';
import { GetListReportStockQueryDto } from '../dto/request/get-list-report-stock.query.dto';
import { GetLotsByItemRequestDto } from '../dto/request/get-lots-by-item.request.dto';
import { GetPositionExistItemsRequestDto } from '../dto/request/get-position-exits-items.request.dto';
import { ItemStockRequest } from '../dto/request/item-stock.request.dto';
import { GetLotNumberByItemIdRequestDto } from '../dto/request/list-lot-number.request.dto';
import { GetItemStockMovementInWarehouseLocatorByDay } from '../dto/request/get-item-stock-warehouse-locator-by-day.request.dto';
import { GetItemStockWarehouseExpireStorageTimeRequestDto } from '@components/item-warehouse/dto/request/get-item-stock-warehouse-expire-storage-time.request.dto';
import { GetListStorageDateByItemIdRequestDto } from '../dto/request/get-storage-dates-by-item-id.request.dto';
import { GetStorageDateByItemIdsRequestDto } from '../dto/request/get-storage-date-item-ids.request.dto';
import { FilterItemAllWarehouseByCondition } from '@components/item-warehouse/dto/request/get-item-stock-available-all-warehouse.request.dto';
import { GetListItemStockWarehouseLocatorByCondition } from '../dto/request/item-stock-warehouse-locator/get-list-item-stock-warehouse-locator.request.dto';
import {
  GetItemStockWarehouseLocatorByConditionRequestDto,
  GetListItemStockWarehouseLocatorsRequestDto,
} from '../dto/request/item-stock-warehouse-locator/get-item-stock-warehouse-locator-by-condition.requets.dto';

export interface ItemStockWarehouseLocatorCriteria {
  locatorIds?: string[];
  itemId?: number;
  lotNumber?: string;
  warehouseId?: number;
  mfg?: Date;
  storageDate?: Date;
}

export interface ItemStockWarehouseLocatorRepositoryInterface
  extends BaseInterfaceRepository<ItemStockWarehouseLocatorEntity> {
  findOne(
    condition: ItemStockWarehouseLocatorCriteria,
  ): Promise<ItemStockWarehouseLocatorEntity>;
  findAdvance(options: {
    where: ItemStockWarehouseLocatorCriteria;
    sort?: { [P in keyof ItemStockWarehouseLocatorEntity]?: 'ASC' | 'DESC' };
  }): Promise<ItemStockWarehouseLocatorEntity[]>;

  createEntity(
    request: CreateItemStockWarehouseLocatorRequestDto,
  ): ItemStockWarehouseLocatorEntity;
  updateEntity(request: CreateItemStockWarehouseLocatorRequestDto): any;
  getListByLotNumber(floorId: number, lotNumbers: string[]): Promise<any>;
  getItemWarehousesByFloorId(
    request: ItemStockRequest,
    floorId: number,
  ): Promise<any>;
  getItemWarehouseStock(
    request: GetItemWarehouseStockRequestDto,
    warehouseSectorIds: number[],
  ): Promise<any>;
  getListWarning(request: any, warehouseIds: number[]): Promise<any>;
  findByItemIdsLotNumbersWarehouseShelfFloorIds(
    itemIds: any[],
    lotNumbers: any[],
    warehouseShelfFloorIds: any[],
  ): Promise<any>;
  getLotsByItem(request: GetLotsByItemRequestDto): Promise<any>;
  getStorageDatesByItem(
    request: GetListStorageDateByItemIdRequestDto,
  ): Promise<any>;
  getStorageDatesByItemIds(
    request: GetStorageDateByItemIdsRequestDto,
  ): Promise<any>;
  getPositionExistItem(request: GetPositionExistItemsRequestDto): Promise<any>;
  getListLotNumber(request: GetLotNumberByItemIdRequestDto): Promise<any>;
  getItemStockWarehouseShelfFloorForReport(
    request: GetListReportStockQueryDto,
    warehouseIds: number[],
  ): Promise<any>;
  getItemStockAndCostWarehouseShelfFloor(
    request: GetListReportStockQueryDto,
    warehouseIds: number[],
  ): Promise<any>;
  getTotalQuantityItemStockMovementByCondition(condition: any[]): Promise<any>;
  suggestItemSameType(
    request: GetItemStockMovementWarehouseShelfFloorByItemIdsDto,
  ): Promise<ItemStockWarehouseLocatorEntity[]>;
  getTotalQuantityItemStockByCondition(
    conditions: FilterItemByCondition[],
  ): Promise<any>;
  getItemWarehouseLocatorByDay(
    payload: GetItemStockMovementInWarehouseLocatorByDay,
  ): Promise<any>;
  getItemStockWarehouseExpireStorageTime(
    payload: GetItemStockWarehouseExpireStorageTimeRequestDto[],
  ): Promise<any>;
  getTotalItemStock(
    itemId: number,
    warehouseId?: number,
    locatorId?: number,
  ): Promise<any>;
  getTotalQuantityAllItemStockByCondition(
    conditions: FilterItemAllWarehouseByCondition[],
  ): Promise<any>;
  getWarehouseAvailableByItemId(itemId: number): Promise<any>;
  getListLotStorageDatesByItemIds(
    request: GetLotNumberByItemIdRequestDto,
  ): Promise<any>;
  findItemStockLocatorsByConditions(
    itemIds: any[],
    lotNumbers: any[],
    warehouseIds: any[],
    locatorIds?: any[],
  ): Promise<any>;
  getItemStockWarehouseLocators(
    request: GetListItemStockWarehouseLocatorByCondition,
  ): Promise<any>;
  getItemSockWarehouseLocatorByCondition(
    request: GetItemStockWarehouseLocatorByConditionRequestDto,
  ): Promise<any>;
  getListItemWarehouseStock(
    request: GetListItemStockWarehouseLocatorsRequestDto,
  ): Promise<any>;
}
