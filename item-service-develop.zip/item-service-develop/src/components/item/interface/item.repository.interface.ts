import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { Item } from '@entities/item/item.entity';
import { CreateItemDto } from '../dto/request/create-item.dto';
import { GetItemByItemTypeRequest } from '../dto/request/get-item-by-item_type.request.dto';
import {
  GetItemStockRequestDto,
  GetItemWarehouseStockRequestDto,
} from '../dto/request/get-item-stock.dto';
import { GetListItemRequestDto } from '../dto/request/get-list-item.request.dto';
import { GetListReportStockQueryDto } from '../dto/request/get-list-report-stock.query.dto';
import { ItemStockAvailable } from '../dto/request/item-stock-available-request.dto';
import { ItemStockRequest } from '../dto/request/item-stock.request.dto';
import { UpdateItemDto } from '../dto/request/update-item.dto';
import { ItemConvertUnitEntity } from '@entities/item/item-convert-unit.entity';

export interface ItemRepositoryInterface extends BaseInterfaceRepository<Item> {
  getItemWarehouseQuantity(
    listItemId: number[],
    warehouseId: number,
  ): Promise<any[]>;
  getItemWarehouseQuantityWithLocation(
    listItemId: number[],
    warehouseId: number,
    warehouseSectorId: number,
    warehouseShelfId: number,
    warehouseShelfFloorId: number,
    lotNumbers?: string[],
  ): Promise<any[]>;

  createEntity(
    request: CreateItemDto,
    itemConvertUnitEntities?: ItemConvertUnitEntity[],
  ): Item;
  getAllStock(id: number): Promise<any>;
  getList(
    payload: GetListItemRequestDto,
    bomItems?: number[],
    filteredItemIds?: number[],
    itemIdsByQcStageId?: number[],
    materialRequestWarningItemIds?: number[],
  ): Promise<any>;
  getByIds(
    request: any,
    warehouseIds?: number[],
    filter?: any,
    basicInfor?: any,
    forceFilterByFactoryId?: boolean,
  ): Promise<any>;
  getItemStock(request: GetItemStockRequestDto): Promise<any>;
  getDetail(id: number): Promise<any>;
  getDetailByQrcode(qrCode: string): Promise<any>;
  updateEntity(
    item: Item,
    request: UpdateItemDto | CreateItemDto,
    itemConvertUnitEntities?: ItemConvertUnitEntity[],
  ): Item;
  getItemStockQuantity(request: ItemStockAvailable[]): Promise<any[]>;
  updateItemsById(request: number, id: number): Promise<any>;
  updateItemsByIds(request: number[], id: number): Promise<any>;
  getItemByItemType(request: GetItemByItemTypeRequest): Promise<any[]>;
  countTotalItem(): Promise<number>;
  countTotalOtherItem(): Promise<number>;
  findItemsByCondition(condition: any, sort?: any): Promise<any>;
  getItemsByItemUnitName(itemUnitName: string): Promise<any>;
  getItemWarehouseStockGroupByLotNumber(
    itemId: number,
    warehouseId: number,
    warehouseSectorId: number,
    warehouseShelfId: number,
    warehouseShelfFloorId: number,
  ): Promise<any>;
  getItemWarehouseStock(
    request: GetItemWarehouseStockRequestDto,
    locatorIds: number[],
    itemIds: number[],
  ): Promise<any>;
  getItemWarehouseStockByQrCode(
    itemId: number,
    warehouseSectorIds: number[],
  ): Promise<any>;
  getItemWarehousesByFloorId(
    request: ItemStockRequest,
    floorIds: number[],
    shelfIds?: number[],
    sectorIds?: number[],
  ): Promise<any>;
  getAllStockByCode(codes: string[]): Promise<any>;
  updateItemGroupIdByItemId(entity: Item, othergroupId: number): Item;
  getItemByCodes(codes: string[]): Promise<any>;
  getItemLotWarehouseStockReport(
    request: GetItemWarehouseStockRequestDto,
  ): Promise<any>;
  getItemStockWarehouseShelfFloorForReport(
    request: GetListReportStockQueryDto,
    warehouseIds: number[],
  ): Promise<[any[], number]>;
}
