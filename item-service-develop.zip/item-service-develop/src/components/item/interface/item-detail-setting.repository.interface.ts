import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ItemDetailSetting } from '@entities/item/item-detail-setting.entity';
import { CreateItemDetailSettingDto } from '../dto/request/create-item-detail-setting.dto';
import { GetListDetailRequestDto } from '../dto/request/get-list-detail.request.dto';
import { UpdateItemDetailSettingDto } from '../dto/request/update-item-detail-setting.dto';

export interface ItemDetailSettingRepositoryInterface
  extends BaseInterfaceRepository<ItemDetailSetting> {
  createEntity(request: CreateItemDetailSettingDto): ItemDetailSetting;
  getList(request: GetListDetailRequestDto): Promise<any>;
  updateEntity(
    updateEntity: ItemDetailSetting,
    request: UpdateItemDetailSettingDto,
  ): ItemDetailSetting;
}
