import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ItemWarehouseSourceEntity } from '@entities/item/item-warehouse-source.entity';
import { ItemWarehouseSourceDto } from '../dto/request/update-item-warehouse-source.request.dto';

export interface ItemWarehouseSourceRepositoryInterface
  extends BaseInterfaceRepository<ItemWarehouseSourceEntity> {
  createEntity(
    data: ItemWarehouseSourceDto
  ): ItemWarehouseSourceEntity;

  updateEntity(
    entity: ItemWarehouseSourceEntity,
    data: ItemWarehouseSourceDto
  ): ItemWarehouseSourceEntity;
}
