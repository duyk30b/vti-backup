import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ItemDetail } from '@entities/item/item-detail.entity';
import { ItemDetailDto } from '../dto/request/create-item.dto';
import { FilterItemDetail } from '../dto/request/filter-item-detail.dto';

export interface ItemDetailRepositoryInterface
  extends BaseInterfaceRepository<ItemDetail> {
  createEntity(request: ItemDetailDto): ItemDetail;
  findWithListPrimaryKey(request: FilterItemDetail[]): Promise<ItemDetail[]>;
}
