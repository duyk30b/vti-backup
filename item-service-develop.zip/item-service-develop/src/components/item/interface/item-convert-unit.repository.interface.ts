import { ItemConvertUnit } from './../dto/request/create-item.dto';
import { Item } from '@entities/item/item.entity';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ItemConvertUnitEntity } from '@entities/item/item-convert-unit.entity';

export interface ItemConvertUnitRepositoryInterface
  extends BaseInterfaceRepository<ItemConvertUnitEntity> {
  createEntity(
    request: ItemConvertUnit,
    itemEntity?: Item,
  ): ItemConvertUnitEntity;
}
