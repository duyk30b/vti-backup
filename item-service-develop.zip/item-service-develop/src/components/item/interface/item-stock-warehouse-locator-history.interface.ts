import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ItemStockWarehouseLocatorHistoryEntity } from '@entities/item/item-stock-warehouse-locator-history.entity';
import { CreateItemStockWarehouseLocatorHistoryRequestDto } from '../dto/request/create-item-stock-warehouse-locator-history.request.dto';
import { CreateItemStockWarehouseLocatorHistoryTicketRequestDto } from '../dto/response/item-warehouse-stock-locator/create-item-stock-warehouse-locator-history-ticket.request.dto';

export interface ItemStockWarehouseLocatorHistoryRepositoryInterface
  extends BaseInterfaceRepository<ItemStockWarehouseLocatorHistoryEntity> {
  createEntity(
    request: CreateItemStockWarehouseLocatorHistoryRequestDto,
  ): ItemStockWarehouseLocatorHistoryEntity;
  createEntityLocatorWarehouse(
    request: CreateItemStockWarehouseLocatorHistoryTicketRequestDto,
  ): ItemStockWarehouseLocatorHistoryEntity;
}
