import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ItemStockWarehouseLocatorHistoryEntity } from '@entities/item/item-stock-warehouse-locator-history.entity';
import { CreateItemStockWarehouseLocatorHistoryRequestDto } from '../dto/request/create-item-stock-warehouse-locator-history.request.dto';

export interface ItemStockWarehouseLocatorHistoryRepositoryInterface
  extends BaseInterfaceRepository<ItemStockWarehouseLocatorHistoryEntity> {
  createEntity(
    request: CreateItemStockWarehouseLocatorHistoryRequestDto,
  ): ItemStockWarehouseLocatorHistoryEntity;
}
