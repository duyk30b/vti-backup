import { ReportItemStockRequestDto } from '@components/dashboard/dto/request/report-item-stock.request.dto';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ItemStockWarehousePriceEntity } from '@entities/item/item-stock-warehouse-price.entity';
import { GetListItemStockWarehousePriceRequestDto } from '../dto/request/get-list-item-stock-warehouse-price.request.dto';
import { ReportItemStockConstructionScl } from '@components/dashboard/dto/request/report-item-stock-construction-scl.request.dto';

export interface ItemStockWarehousePriceRepositoryInterface
  extends BaseInterfaceRepository<ItemStockWarehousePriceEntity> {
  createEntity(request): ItemStockWarehousePriceEntity;
  getTotalItemStockDashboard(request: ReportItemStockRequestDto): Promise<any>;
  getList(request: GetListItemStockWarehousePriceRequestDto): Promise<any>;
  getTotalItemStockConstructionSclDashboard(
    request: ReportItemStockConstructionScl,
    defaultTimeZone?: string,
  ): Promise<any>;
}
