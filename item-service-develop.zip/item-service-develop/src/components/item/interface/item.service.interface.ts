import { IsGetAllEnum } from '@components/inventory-quantity-norm/inventory-quantity-norm.constant';
import { SetStatusRequestDto } from '@components/item-setting/dto/request/set-status.request.dto';
import { CheckStockAvailableRequest } from '@components/item/dto/request/check-stock-available-request.dto';
import { PrintQrcodeRequestDto } from '@components/qr-code/dto/request/print.request.dto';
import { GetByItemIdRequestDto } from '@components/sale/dto/request/get-by-item-id.request.dto';
import { FileUploadRequestDto } from '@core/dto/file-upload.request';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreateItemDetailSettingDto } from '../dto/request/create-item-detail-setting.dto';
import { CreateItemStockMovementDto } from '../dto/request/create-item-stock-movement.request.dto';
import { CreateItemDto } from '../dto/request/create-item.dto';
import { DeleteItemDto } from '../dto/request/delete-item.dto';
import { GetAllItemStockByCodesRequestDto } from '../dto/request/get-all-item-stock-by-codes.request.dto';
import { GetAllItemStockRequestDto } from '../dto/request/get-all-item-stock.request.dto';
import { GetCountTransferByDateRequest } from '../dto/request/get-count-transfer-by-date.request.dto';
import { GetDetailRequestDto } from '../dto/request/get-detail.request.dto';
import { GetHistoriesItemStockMovements } from '../dto/request/get-histories-item-stock-movements.request.dto';
import { GetItemByItemTypeRequest } from '../dto/request/get-item-by-item_type.request.dto';
import { GetItemDetailSettingRequestDto } from '../dto/request/get-item-detail-setitng.request.dto';
import { GetItemStockQuantityRequestDto } from '../dto/request/get-item-stock-quantity.request.dto';
import { GetItemStockMovementInWarehouseLocatorByDay } from '../dto/request/get-item-stock-warehouse-locator-by-day.request.dto';
import {
  GetItemStockRequestDto,
  GetItemWarehouseStockRequestDto,
} from '../dto/request/get-item-stock.dto';
import { GetItemWarehouseWithLocationRequestDto } from '../dto/request/get-item-warehouse-with-location.dto';
import { GetItemWarehouseDto } from '../dto/request/get-item-warehouse.dto';
import { GetListDetailRequestDto } from '../dto/request/get-list-detail.request.dto';
import {
  GetListItemStockMovementByLotNumberRequestDto,
  GetListItemStockMovementByWarehouseStockMovementIdsRequestDto,
  GetListItemStockMovementRequestDto,
} from '../dto/request/get-list-item-stock-movements.request.dto';
import { GetListItemRequestDto } from '../dto/request/get-list-item.request.dto';
import { GetListReportStockQueryDto } from '../dto/request/get-list-report-stock.query.dto';
import { GetLotsByItemRequestDto } from '../dto/request/get-lots-by-item.request.dto';
import { GetPositionExistItemsRequestDto } from '../dto/request/get-position-exits-items.request.dto';
import { GetQrCodeItemsRequestDto } from '../dto/request/get-qr-code-items.request.dto';
import { GetQuantityItemWarehouseRequestDto } from '../dto/request/get-quantity-item-warehouse-request.dto';
import { GetReportDailyDto } from '../dto/request/get-report-daily.dto';
import { GetStorageDateByItemIdsRequestDto } from '../dto/request/get-storage-date-item-ids.request.dto';
import { GetListStorageDateByItemIdRequestDto } from '../dto/request/get-storage-dates-by-item-id.request.dto';
import { ItemStockByItemGroupQueryDto } from '../dto/request/item-stock-by-item-group.query.dto';
import { ItemStockRequest } from '../dto/request/item-stock.request.dto';
import {
  GetLotNumberByItemIdQueryDto,
  GetLotNumberByItemIdRequestDto,
} from '../dto/request/list-lot-number.request.dto';
import { UpdateIsHasBomItemDto } from '../dto/request/update-is-has-bom-item.dto';
import { UpdateItemDetailSettingDto } from '../dto/request/update-item-detail-setting.dto';
import { UpdateItemStockMovementWarehouseShelfFloorRequestDto } from '../dto/request/update-item-stock-movement-warehouse-shelf-floor.request.dto';
import { UpdateItemWarehouseSourceRequestDto } from '../dto/request/update-item-warehouse-source.request.dto';
import { UpdateItemDto } from '../dto/request/update-item.dto';
import { UploadImageItemRequestDto } from '../dto/request/upload-image-item.request.dto';
import { GetDetailItemByCode } from './../dto/request/get-detail-item-by-code.dto';
import { GetInfoItemRequestDto } from './../dto/request/get-info-item.request.dto';
import { RemoveImageItemRequestDto } from './../dto/request/remove-image-item.request.dto';
import { GetItemStockWarehouseLocatorRequestDto } from '../dto/request/get-items-stock-warehouse-locator.request.dto';
import { UpdateItemWarehouseLocatorRequestDto } from '../dto/request/update-item-stock-warehouse-locator.request.dto';
import { ConfirmExportReceiptItemsRequestDto } from '../dto/request/confirm-export-receipt-items.request.dto';
import { GetListItemStockWarehouseLocatorByCondition } from '../dto/request/item-stock-warehouse-locator/get-list-item-stock-warehouse-locator.request.dto';
import { GetItemStockInWarehouseLocatorRequestDto } from '../dto/request/get-items-stock-in-warehouse-locator.request.dto';
import { UpdateItemStockWarehouseLocatorRequestDto } from '../dto/request/update-item-stock-in-warehouse-locator.request.dto';
import { GetListItemStockWarehouseLocatorsRequestDto } from '../dto/request/item-stock-warehouse-locator/get-item-stock-warehouse-locator-by-condition.requets.dto';
import { CheckExistStockInLocatorRequest } from '../dto/request/check-exist-stock-in-locator.request';

export interface ItemServiceInterface {
  createItem(request: CreateItemDto): Promise<ResponsePayload<any>>;
  updateItem(request: UpdateItemDto): Promise<ResponsePayload<any>>;
  getList(request: GetListItemRequestDto): Promise<ResponsePayload<any>>;
  getAllItemStock(
    request: GetAllItemStockRequestDto,
  ): Promise<ResponsePayload<any>>;
  getItemsStockMovements(
    request: GetListItemStockMovementRequestDto,
  ): Promise<ResponsePayload<any>>;
  getItemStockMovementsByWarehouseStockMovementIds(
    request: GetListItemStockMovementByWarehouseStockMovementIdsRequestDto,
  ): Promise<any>;
  getItemStockMovementByLotNumbers(
    request: GetListItemStockMovementByLotNumberRequestDto,
  ): Promise<ResponsePayload<any>>;
  getDetailList(
    request: GetListDetailRequestDto,
  ): Promise<ResponsePayload<any>>;
  getDetail(
    request: GetDetailRequestDto,
    isGetAllWarehouse?: IsGetAllEnum,
  ): Promise<ResponsePayload<any>>;
  scanQrCode(request: any): Promise<ResponsePayload<any>>;
  deleteItem(request: DeleteItemDto): Promise<ResponsePayload<any>>;
  deleteMultipleItem(request: DeleteMultipleDto): Promise<ResponsePayload<any>>;
  runSeeders(): Promise<any>;
  getEnv(): Promise<any>;
  getItemStock(request: GetItemStockRequestDto): Promise<ResponsePayload<any>>;
  getItemWarehouseStock(
    request: GetItemWarehouseStockRequestDto,
  ): Promise<ResponsePayload<any>>;
  getItemLotWarehouseStock(
    request: GetItemWarehouseStockRequestDto,
  ): Promise<ResponsePayload<any>>;
  printQrCode(request: PrintQrcodeRequestDto): Promise<ResponsePayload<any>>;
  getItemWarehouse(itemDto: GetItemWarehouseDto): Promise<ResponsePayload<any>>;
  getItemWarehouseWithLocation(
    itemDto: GetItemWarehouseWithLocationRequestDto,
  ): Promise<ResponsePayload<any>>;
  createItemsStockMovement(
    itemsStockMovement: CreateItemStockMovementDto,
  ): Promise<ResponsePayload<any>>;

  importItems(request: FileUploadRequestDto): Promise<ResponsePayload<any>>;
  importItemDetailSetting(request: FileUploadRequestDto): Promise<any>;
  createItemsDetailSetting(
    request: CreateItemDetailSettingDto,
  ): Promise<ResponsePayload<any>>;
  updateItemsDetailSetting(
    request: UpdateItemDetailSettingDto,
  ): Promise<ResponsePayload<any>>;
  getItemsDetailSetting(
    request: GetItemDetailSettingRequestDto,
  ): Promise<ResponsePayload<any>>;
  deleteItemDetailSetting(
    request: DeleteItemDto,
  ): Promise<ResponsePayload<any>>;
  deleteMultipleItemDetailSetting(
    request: DeleteMultipleDto,
  ): Promise<ResponsePayload<any>>;
  confirmItem(request: SetStatusRequestDto): Promise<ResponsePayload<any>>;
  rejectItem(request: SetStatusRequestDto): Promise<ResponsePayload<any>>;
  confirmItemDetailSetting(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<any>>;
  rejectItemDetailSetting(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<any>>;
  checkStockAvaiable(request: CheckStockAvailableRequest): Promise<any>;
  getItemsById(
    items: number[],
    factoryId?: number,
    filter?: any,
    basicInfor?: boolean,
    forceFilterByFactoryId?: boolean,
  ): Promise<ResponsePayload<any>>;
  getDailyReport(request: GetReportDailyDto): Promise<ResponsePayload<any>>;
  getQuantityItemWarehouse(
    request: GetQuantityItemWarehouseRequestDto,
  ): Promise<ResponsePayload<any>>;
  getCountItemByItemType(): Promise<ResponsePayload<any>>;
  getCountTransferByDate(
    request: GetCountTransferByDateRequest,
  ): Promise<ResponsePayload<any>>;
  getItemByItemType(
    request: GetItemByItemTypeRequest,
  ): Promise<ResponsePayload<any>>;
  checkItemHasExistOnBlockItemDetail(
    request: GetByItemIdRequestDto,
  ): Promise<any>;
  checkItemHasExistOnPackageItem(request: GetByItemIdRequestDto): Promise<any>;
  countTotalItem(): Promise<any>;
  countTotalOtherItem(): Promise<any>;
  getItemStockForReport(request: GetListReportStockQueryDto): Promise<any>;
  itemStockByItemGroupSummary(
    request: ItemStockByItemGroupQueryDto,
  ): Promise<any>;
  getItemWarehouseStocks(request: ItemStockRequest): Promise<any>;
  getItemsByConditions(condition: any, sort?: any): Promise<any>;
  getItemsByRelations(relation: any): Promise<any>;
  updateColumnIsHasBomOfItem(
    request: UpdateIsHasBomItemDto,
  ): Promise<ResponsePayload<any>>;
  getItemWarehouseListByItemIdsAndWarehouseIds(request: any): Promise<any>;
  getItemsByItemUnitName(itemUnitName: string): Promise<any>;
  getListWarning(payload: any): Promise<any>;
  getItemByCodes(codes: string[]): Promise<ResponsePayload<any>>;
  getHistoriesItemStockMovements(
    request: GetHistoriesItemStockMovements,
  ): Promise<ResponsePayload<any>>;
  updateItemStockMovementWarehouseShelfFloor(
    request: UpdateItemStockMovementWarehouseShelfFloorRequestDto,
  ): Promise<ResponsePayload<any>>;
  getLotsByItem(request: GetLotsByItemRequestDto): Promise<any>;
  getStorageDatesByItem(
    request: GetListStorageDateByItemIdRequestDto,
  ): Promise<any>;
  getDetailByCode(request: GetDetailItemByCode): Promise<any>;
  getListLotNumberByItemId(
    request: GetLotNumberByItemIdRequestDto,
  ): Promise<ResponsePayload<any>>;
  getAllItemStockByCodes(
    params: GetAllItemStockByCodesRequestDto,
  ): Promise<any>;
  getItemStockQuantity(request: GetItemStockQuantityRequestDto): Promise<any>;
  updateItemWarehouseSource(
    request: UpdateItemWarehouseSourceRequestDto,
  ): Promise<any>;
  getItemWarehouseLocatorByDay(
    payload: GetItemStockMovementInWarehouseLocatorByDay,
  ): Promise<any>;
  getInfoItem(request: GetInfoItemRequestDto): Promise<any>;
  uploads(request: UploadImageItemRequestDto): Promise<any>;
  removeImages(request: RemoveImageItemRequestDto): Promise<any>;
  getQrCodeItems(request: GetQrCodeItemsRequestDto): Promise<any>;
  getItemStockWarehouseLocators(
    request: GetItemStockWarehouseLocatorRequestDto,
  ): Promise<any>;
  getListLotStorageDatesByItemIds(
    request: GetLotNumberByItemIdQueryDto,
  ): Promise<any>;
  pickUpItemStockWarehouseLocators(
    request: UpdateItemWarehouseLocatorRequestDto,
  ): Promise<any>;
  confirmExportReceiptItems(
    request: ConfirmExportReceiptItemsRequestDto,
  ): Promise<any>;
  getListItemStockWarehouseLocatorsByCondition(
    request: GetListItemStockWarehouseLocatorByCondition,
  ): Promise<any>;
  getPositionExistItem(request: GetPositionExistItemsRequestDto): Promise<any>;
  getItemStockInWarehouseLocators(
    request: GetItemStockInWarehouseLocatorRequestDto,
  ): Promise<any>;
  updateItemStockWarehouseLocators(
    request: UpdateItemStockWarehouseLocatorRequestDto,
  ): Promise<any>;
  getListItemStockWarehouse(
    request: GetListItemStockWarehouseLocatorsRequestDto,
  ): Promise<any>;
  checkExistStockInLocator(
    request: CheckExistStockInLocatorRequest,
  ): Promise<any>;
}
