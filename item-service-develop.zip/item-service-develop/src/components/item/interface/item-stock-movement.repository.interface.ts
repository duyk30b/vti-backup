import { ReportItemMovementRequestDto } from '@components/dashboard/dto/request/report-item-movement-request.dto';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ItemStockMovement } from '@entities/item/item-stock-movement.entity';
import { ItemStockMovementDto } from '../dto/request/create-item-stock-movement.request.dto';
import { GetCountTransferByDateRequest } from '../dto/request/get-count-transfer-by-date.request.dto';
import { GetHistoriesItemStockMovements } from '../dto/request/get-histories-item-stock-movements.request.dto';
import { GetItemStockQuantityRequestDto } from '../dto/request/get-item-stock-quantity.request.dto';

export interface ItemStockMovementRepositoryInterface
  extends BaseInterfaceRepository<ItemStockMovement> {
  createEntity(itemStockMovement: ItemStockMovementDto): ItemStockMovement;
  getListByWarehouseMovementIds(warehouseMovementIds: number[]): Promise<any>;
  getDataByWarehouseStockMovementId(
    warehouseStockMovementIds: number[],
  ): Promise<any[]>;
  getCountByDateIds(request: GetCountTransferByDateRequest): Promise<any[]>;
  getHistoriesItemStockMovements(
    request: GetHistoriesItemStockMovements,
  ): Promise<any[]>;
  getItemStockQuantity(request: GetItemStockQuantityRequestDto): Promise<any>;
  reportItemStockMovementImportByDateRange(
    startDate: Date,
    endDate: Date,
    warehouseId?: number,
    itemId?: number,
    warehouseStockMovementIds?: number[],
    defaultTimeZone?: string,
  ): Promise<any>;
  reportItemStockMovementExportByDateRange(
    startDate: Date,
    endDate: Date,
    warehouseId?: number,
    itemId?: number,
    defaultTimeZone?: string,
  ): Promise<any>;
  getDataByCondition(condition: any): Promise<any[]>;
}
