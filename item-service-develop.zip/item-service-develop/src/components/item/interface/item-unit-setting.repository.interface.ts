import { GetListItemUnitSettingRequestDto } from '@components/item-setting/dto/request/get-list-item-unit-setting.request.dto';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ItemUnitSetting } from '@entities/item/item-unit-setting.entity';

export interface ItemUnitSettingRepositoryInterface
  extends BaseInterfaceRepository<ItemUnitSetting> {
  createEntity(data: any): ItemUnitSetting;
  updateEntity(id: number, data: any): ItemUnitSetting;
  getList(request: GetListItemUnitSettingRequestDto): Promise<any>;
}
