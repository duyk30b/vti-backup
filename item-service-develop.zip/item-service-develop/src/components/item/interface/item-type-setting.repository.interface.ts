import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ItemTypeSetting } from '@entities/item/item-type-setting.entity';
import { GetListItemTypeSettingRequestDto } from '@components/item-setting/dto/request/get-list-item-type-setting.request.dto';

export interface ItemTypeSettingRepositoryInterface
  extends BaseInterfaceRepository<ItemTypeSetting> {
  getList(request: GetListItemTypeSettingRequestDto): Promise<any>;
  getCountItem(): Promise<any[]>;

  createEntity(data: any): ItemTypeSetting;
  updateEntity(id: number, data: any): ItemTypeSetting;
  getCount(): Promise<any>;
  checkItemTypeUsed(id): Promise<any>;
  getDetailItemTypeSubGroup(subGroupId: number): Promise<any>;
}
