import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ItemStockMovementHistory } from '@entities/item/item-stock-movement-history.entity';
import { ItemStockMovementHistoryDto } from '../dto/request/create-item-stock-movement-history.request.dto';

export interface ItemStockMovementHistoryRepositoryInterface
  extends BaseInterfaceRepository<ItemStockMovementHistory> {
  createEntity(
    itemStockMovementHistory: ItemStockMovementHistoryDto,
  ): ItemStockMovementHistory;
}
