import { BlockItemDetailRepositoryInterface } from '@components/block/interface/block-item-detail.repository.interface';
import { ReportItemStockRequestDto } from '@components/dashboard/dto/request/report-item-stock.request.dto';
import { FileResource } from '@components/file/constant/file-upload.constant';
import { FileServiceInterface } from '@components/file/interface/file.service.interface';
import { IsGetAllEnum } from '@components/inventory-quantity-norm/inventory-quantity-norm.constant';
import { ItemQualityRepositoryInterface } from '@components/item-quanlity/interface/item-quality.repository.interface';
import { GetItemStockAvailableSwiftLocatorRequestDto } from '@components/item-warehouse/dto/request/get-item-stock-available-swift-locator.request.dto';
import { ItemWarehouseServiceInterface } from '@components/item-warehouse/interface/item-warehouse.service.interface';
import { ItemStockMovementTypeEnum } from '@components/item-warehouse/item-warehouse.constant';
import { CheckStockAvailableRequest } from '@components/item/dto/request/check-stock-available-request.dto';
import { ItemStockMovementHistoryDto } from '@components/item/dto/request/create-item-stock-movement-history.request.dto';
import { ItemRepositoryInterface } from '@components/item/interface/item.repository.interface';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import {
  IsSameWarehouse,
  ITEM_RULES,
  QrCodeItemTypeEnum,
  TypeTransaction,
} from '@components/item/item.constant';
import { ManufacturingCountryRepositoryInterface } from '@components/manufacturing-country/interface/manufacturing-country.repository.interface';
import { ObjectCategoryRepositoryInterface } from '@components/object-category/interface/object-category.repository.interface';
import { PackageItemRepositoryInterface } from '@components/package/interface/package-item.repository.interface';
import { GetListBomRequestDto } from '@components/produce/dto/request/get-list-bom.request.dto';
import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { PrintQrcodeRequestDto } from '@components/qr-code/dto/request/print.request.dto';
import { QrCodeServiceInterface } from '@components/qr-code/interface/qr-code.service.interface';
import { GetByItemIdRequestDto } from '@components/sale/dto/request/get-by-item-id.request.dto';
import { SaleServiceInterface } from '@components/sale/interface/sale.service.interface';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { FileUploadRequestDto } from '@core/dto/file-upload.request';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ItemDetailSetting } from '@entities/item/item-detail-setting.entity';
import { ItemDetail } from '@entities/item/item-detail.entity';
import { ItemGroupSetting } from '@entities/item/item-group-setting.entity';
import { ItemStockMovementHistory } from '@entities/item/item-stock-movement-history.entity';
import { ItemUnitSetting } from '@entities/item/item-unit-setting.entity';
import { Item } from '@entities/item/item.entity';
import { Inject, Injectable } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { InjectDataSource } from '@nestjs/typeorm';
import { ItemWarehouseRepository } from '@repositories/item-warehouse.repository';
import { ApiError } from '@utils/api.error';
import { div, plus, mul } from '@utils/helper';
import { stringFormat } from '@utils/object.util';
import { PaginationQuery } from '@utils/pagination.query';
import {
  CREATE_ITEM_WAREHOUSE_SOURCE_PERMISSION,
  UPDATE_ITEM_WAREHOUSE_SOURCE_PERMISSION,
} from '@utils/permissions/item';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToClass, plainToInstance } from 'class-transformer';
import {
  compact,
  find,
  first,
  flatMap,
  groupBy,
  has,
  isArray,
  isEmpty,
  keyBy,
  map,
  uniq,
  values,
} from 'lodash';
import * as moment from 'moment';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, ILike, In, IsNull, MoreThan, Not } from 'typeorm';
import { ItemGroupSettingRepositoryInterface } from '../item-setting/interface/item-group-setting.repository.interface';
import {
  COMPANY_DEFAULT,
  DATA_ITEM_CAN_NOT_UPDATE_AND_DELETE,
  DEFAULT_ITEM_GROUP,
  DEFAULT_ITEM_TYPES,
  DEFAULT_ITEM_UNIT,
  OrderTypeEnum,
} from './../../constant/common';
import { ItemTypeSetting } from './../../entities/item/item-type-setting.entity';
import { PagingResponse } from './../../utils/paging.response';
import { SettingServiceInterface } from './../setting/interface/setting.service.interface';
import { WarehouseLayoutServiceInterface } from './../warehouse-layout/interface/warehouse-layout.service.interface';
import { FileRepositoryInterface } from '././../file/interface/file.repository.interface';
import { CreateItemDetailSettingDto } from './dto/request/create-item-detail-setting.dto';
import { CreateItemStockMovementDto } from './dto/request/create-item-stock-movement.request.dto';
import { CreateItemDto } from './dto/request/create-item.dto';
import { DeleteItemDto } from './dto/request/delete-item.dto';
import { GetAllItemStockByCodesRequestDto } from './dto/request/get-all-item-stock-by-codes.request.dto';
import { GetAllItemStockRequestDto } from './dto/request/get-all-item-stock.request.dto';
import { GetCountTransferByDateRequest } from './dto/request/get-count-transfer-by-date.request.dto';
import { GetDetailItemByCode } from './dto/request/get-detail-item-by-code.dto';
import { GetDetailRequestDto } from './dto/request/get-detail.request.dto';
import { GetHistoriesItemStockMovements } from './dto/request/get-histories-item-stock-movements.request.dto';
import { GetInfoItemRequestDto } from './dto/request/get-info-item.request.dto';
import { GetItemByItemTypeRequest } from './dto/request/get-item-by-item_type.request.dto';
import { GetItemDetailSettingRequestDto } from './dto/request/get-item-detail-setitng.request.dto';
import { GetItemStockMovementWarehouseShelfFloorByItemIdsDto } from './dto/request/get-item-stock-movement-warehouse-shelf-floor-item-ids.request.dto';
import { GetItemStockMovementWarehouseShelfFloorDto } from './dto/request/get-item-stock-movement-warehouse-shelf-floor.request.dto';
import { GetItemStockQuantityRequestDto } from './dto/request/get-item-stock-quantity.request.dto';
import { GetItemStockMovementInWarehouseLocatorByDay } from './dto/request/get-item-stock-warehouse-locator-by-day.request.dto';
import {
  GetItemStockRequestDto,
  GetItemWarehouseStockRequestDto,
} from './dto/request/get-item-stock.dto';
import { GetItemWarehouseWithLocationRequestDto } from './dto/request/get-item-warehouse-with-location.dto';
import { GetItemWarehouseDto } from './dto/request/get-item-warehouse.dto';
import { GetListDetailRequestDto } from './dto/request/get-list-detail.request.dto';
import {
  GetListItemStockMovementByLotNumberRequestDto,
  GetListItemStockMovementByWarehouseStockMovementIdsRequestDto,
  GetListItemStockMovementRequestDto,
} from './dto/request/get-list-item-stock-movements.request.dto';
import { GetListItemRequestDto } from './dto/request/get-list-item.request.dto';
import { GetListReportStockQueryDto } from './dto/request/get-list-report-stock.query.dto';
import { GetLotsByItemRequestDto } from './dto/request/get-lots-by-item.request.dto';
import { GetPositionExistItemsRequestDto } from './dto/request/get-position-exits-items.request.dto';
import { GetQrCodeItemsRequestDto } from './dto/request/get-qr-code-items.request.dto';
import { GetQuantityItemWarehouseRequestDto } from './dto/request/get-quantity-item-warehouse-request.dto';
import { GetReportDailyDto } from './dto/request/get-report-daily.dto';
import { GetStorageDateByItemIdsRequestDto } from './dto/request/get-storage-date-item-ids.request.dto';
import { GetListStorageDateByItemIdRequestDto } from './dto/request/get-storage-dates-by-item-id.request.dto';
import { ItemStockAvailable } from './dto/request/item-stock-available-request.dto';
import { ItemStockByItemGroupQueryDto } from './dto/request/item-stock-by-item-group.query.dto';
import { ItemStockRequest } from './dto/request/item-stock.request.dto';
import { GetLotNumberByItemIdRequestDto } from './dto/request/list-lot-number.request.dto';
import { RemoveImageItemRequestDto } from './dto/request/remove-image-item.request.dto';
import { UpdateIsHasBomItemDto } from './dto/request/update-is-has-bom-item.dto';
import { UpdateItemDetailSettingDto } from './dto/request/update-item-detail-setting.dto';
import { UpdateItemStockMovementWarehouseShelfFloorRequestDto } from './dto/request/update-item-stock-movement-warehouse-shelf-floor.request.dto';
import { UpdateItemWarehouseSourceRequestDto } from './dto/request/update-item-warehouse-source.request.dto';
import { UpdateItemDto } from './dto/request/update-item.dto';
import { UploadImageItemRequestDto } from './dto/request/upload-image-item.request.dto';
import { GetAllItemstockByCodesResponseDto } from './dto/response/get-all-item-stock-by-codes.response.dto';
import { GetDetailItemByCodeResponse } from './dto/response/get-detail-item-by-code.response.dto';
import { GetInfoItemResponseDto } from './dto/response/get-info-item.response.dto';
import { GetItemByFilterItemUnitNameResponseDto } from './dto/response/get-item-by-filter-item-unit-name.response.dto';
import { GetItemStockQuantityResponseDto } from './dto/response/get-item-stock-quantity.response.dto';
import { GetItemStockWarehouseLocatorByDayResponseDto } from './dto/response/get-item-stock-warehouse-locator-by-day.response.dto';
import { GetWaringListResponseDto } from './dto/response/get-warning-list.response.dto';
import { ImportItemResponseDto } from './dto/response/import-item.response.dto';
import { ItemDetailSettingResponseDto } from './dto/response/item-detail-setting.response.dto';
import { ItemIdResponse } from './dto/response/item-id.response';
import { ItemInventoryResponse } from './dto/response/item-inventory.response.dto';
import { ItemStockAvailableResponse } from './dto/response/item-stock-available.response.dto';
import { ItemStockLocationResponseDto } from './dto/response/item-stock-location.response.dto';
import { ItemStockMovementResponseDto } from './dto/response/item-stock-movement.response.dto';
import { ItemStockResponse } from './dto/response/item-stock.response.dto';
import { ItemTypeCountItemResponse } from './dto/response/item-type-count-item.response';
import { ItemWarehouseResponse } from './dto/response/item-warehouse.response.dto';
import { ItemResponseDto } from './dto/response/item.response.dto';
import { ListLotByItemResponseDto } from './dto/response/list-lot-by-item.request.dto';
import {
  GetListItemLotStorageDatesResponseDto,
  LotNumberOfItemResponseDto,
} from './dto/response/list-lot-number.response.dto';
import { GetListStorageDateByItemIdResponseDto } from './dto/response/list-storage-date-by-item.response.dto';
import { QrCodeItemResponseDto } from './dto/response/qr-code-item.response.dto';
import { TotalItemStockByItemGroupResponse } from './dto/response/total-item-stock-by-item-group.response.dto';
import { TransferByDateResponse } from './dto/response/transfer-by-date.response';
import { WarehouseStockDailyRespone } from './dto/response/warehouse-stock-daily.response';
import { ItemDetailSettingImport } from './import/item-detail-setting.import.helper';
import { ItemDetailsImport } from './import/item-details.import.helper';
import { ItemsImport } from './import/items.import.helper';
import { ItemDetailSettingRepositoryInterface } from './interface/item-detail-setting.repository.interface';
import { ItemDetailRepositoryInterface } from './interface/item-detail.repository.interface';
import { ItemStockMovementHistoryRepositoryInterface } from './interface/item-stock-movement-history.interface';
import { ItemStockMovementRepositoryInterface } from './interface/item-stock-movement.repository.interface';
import { ItemStockWarehouseLocatorRepositoryInterface } from './interface/item-stock-warehouse-locator.repository.interface';
import { ItemTypeSettingRepositoryInterface } from './interface/item-type-setting.repository.interface';
import { ItemUnitSettingRepositoryInterface } from './interface/item-unit-setting.repository.interface';
import { ItemWarehouseSourceRepositoryInterface } from './interface/item-warehouse-source.repository.interface';
import {
  CAN_DELETE_ITEM_DETAIL_SETTING_STATUS,
  CAN_DELETE_ITEM_STATUS,
  CAN_UPDATE_ITEM_DETAIL_SETTING_STATUS,
  CAN_UPDATE_ITEM_STATUS,
  ItemStatusEnum,
} from './item.constant';
import { minus, plusBigNumber } from '@utils/common';
import { ItemConvertUnitEntity } from '@entities/item/item-convert-unit.entity';
import { ItemConvertUnitRepositoryInterface } from './interface/item-convert-unit.repository.interface';
import { BomStatusEnum } from '@components/produce/produce.constant';
import { UpdateItemWarehouseLocatorRequestDto } from './dto/request/update-item-stock-warehouse-locator.request.dto';
import * as Moment from 'moment';
import { ItemStockWarehouseLocatorEntity } from '@entities/item/item-stock-warehouse-locator.entity';
import { ItemStockWarehouseLocatorHistoryEntity } from '@entities/item/item-stock-warehouse-locator-history.entity';
import { ItemStockWarehouseLocatorHistoryRepositoryInterface } from './interface/item-stock-warehouse-locator-history.interface';
import { CreateItemStockWarehouseLocatorHistoryRequestDto } from './dto/request/create-item-stock-warehouse-locator-history.request.dto';
import { ConfirmExportReceiptItemsRequestDto } from './dto/request/confirm-export-receipt-items.request.dto';
import { MovementRepositoryInterface } from '@components/item-movement/interfaces/item-movement.repository.interface';
import { TYPE_ENUM_MOVEMENT } from '@components/item-movement/item-movement.constants';
import { MovementEntity } from '@entities/item-movement/movement.entity';
import { ItemWarehouseEntity } from '@entities/item/item-warehouse.entity';
import { GetListItemStockWarehouseLocatorByCondition } from './dto/request/item-stock-warehouse-locator/get-list-item-stock-warehouse-locator.request.dto';
import { GetListItemStockWarehouseLocatorResponse } from './dto/response/item-warehouse-stock-locator/item-warehouse-stock-locator.response.dto';
import { TicketServiceInterface } from '@components/ticket/interface/ticket.service.interface';
import { GetItemStockInWarehouseLocatorRequestDto } from './dto/request/get-items-stock-in-warehouse-locator.request.dto';
import { ItemStockWarehouseLocatorResponseDto } from './dto/response/get-item-stock-warehouse-locator.response.dto';
import { UpdateItemStockWarehouseLocatorRequestDto } from './dto/request/update-item-stock-in-warehouse-locator.request.dto';
import { GetListItemStockWarehouseLocatorsRequestDto } from './dto/request/item-stock-warehouse-locator/get-item-stock-warehouse-locator-by-condition.requets.dto';
import { CheckExistStockInLocatorRequest } from './dto/request/check-exist-stock-in-locator.request';

@Injectable()
export class ItemService implements ItemServiceInterface {
  constructor(
    @Inject('SaleServiceInterface')
    private readonly saleService: SaleServiceInterface,
    @Inject('PackageItemRepositoryInterface')
    private readonly packageItemRepository: PackageItemRepositoryInterface,
    @Inject('ItemRepositoryInterface')
    private readonly itemRepository: ItemRepositoryInterface,
    @Inject('BlockItemDetailRepositoryInterface')
    private readonly blockItemDetailRepository: BlockItemDetailRepositoryInterface,
    @Inject('ItemUnitSettingRepositoryInterface')
    private readonly itemUnitSettingRepository: ItemUnitSettingRepositoryInterface,
    @Inject('ItemGroupSettingRepositoryInterface')
    private readonly itemGroupSettingRepository: ItemGroupSettingRepositoryInterface,
    @Inject('ItemDetailSettingRepositoryInterface')
    private readonly itemDetailSettingRepository: ItemDetailSettingRepositoryInterface,
    @Inject('ItemTypeSettingRepositoryInterface')
    private readonly itemTypeSettingRepository: ItemTypeSettingRepositoryInterface,
    @Inject('ItemDetailRepositoryInterface')
    private readonly itemDetailRepository: ItemDetailRepositoryInterface,
    @Inject('FileRepositoryInterface')
    private readonly fileRepository: FileRepositoryInterface,
    @Inject('ItemWarehouseRepositoryInterface')
    private readonly itemWarehouseRepository: ItemWarehouseRepository,
    @Inject('ItemStockMovementRepositoryInterface')
    private readonly itemStockMovementRepository: ItemStockMovementRepositoryInterface,
    @Inject('ItemStockMovementHistoryRepositoryInterface')
    private readonly itemStockMovementHistoryRepository: ItemStockMovementHistoryRepositoryInterface,
    @Inject('ItemStockWarehouseLocatorRepositoryInterface')
    private readonly itemStockMovementWarehouseShelfFloorRepository: ItemStockWarehouseLocatorRepositoryInterface,
    @Inject('ObjectCategoryRepositoryInterface')
    private readonly objectCategoryRepository: ObjectCategoryRepositoryInterface,
    @Inject('ItemQualityRepositoryInterface')
    private readonly itemQualityRepository: ItemQualityRepositoryInterface,
    @Inject('ManufacturingCountryRepositoryInterface')
    private readonly manufacturingCountryRepository: ManufacturingCountryRepositoryInterface,
    @Inject('QrCodeServiceInterface')
    private readonly qrcodeService: QrCodeServiceInterface,
    @Inject('ItemDetailSettingImport')
    private readonly itemUnitSettingImport: ItemDetailSettingImport,
    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,
    @Inject('ProduceServiceInterface')
    private readonly produceService: ProduceServiceInterface,
    @Inject('WarehouseLayoutServiceInterface')
    private readonly warehouseLayoutService: WarehouseLayoutServiceInterface,
    @Inject('FileServiceInterface')
    private readonly fileService: FileServiceInterface,
    @Inject('ItemsImport')
    private readonly itemsImport: ItemsImport,
    @Inject('ItemDetailsImport')
    private readonly itemDetailsImport: ItemDetailsImport,
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,
    @Inject('ItemWarehouseSourceRepositoryInterface')
    private readonly itemWarehouseSourceRepository: ItemWarehouseSourceRepositoryInterface,
    @Inject('ItemWarehouseServiceInterface')
    private readonly itemWarehouseService: ItemWarehouseServiceInterface,

    @Inject('SettingServiceInterface')
    private readonly settingService: SettingServiceInterface,

    @Inject('ItemStockWarehouseLocatorRepositoryInterface')
    private readonly itemStockWarehouseLocatorRepository: ItemStockWarehouseLocatorRepositoryInterface,

    @Inject('ItemStockWarehouseLocatorHistoryRepositoryInterface')
    private readonly itemStockWarehouseLocatorHistoryRepository: ItemStockWarehouseLocatorHistoryRepositoryInterface,

    @Inject('MovementRepositoryInterface')
    private readonly movementRepository: MovementRepositoryInterface,

    @Inject('ItemConvertUnitRepositoryInterface')
    private readonly itemConvertUnitRepository: ItemConvertUnitRepositoryInterface,

    @Inject('TicketServiceInterface')
    protected readonly ticketService: TicketServiceInterface,

    private readonly i18n: I18nRequestScopeService,
    private eventEmitter: EventEmitter2,

    @InjectDataSource()
    private readonly connection: DataSource,
  ) {}

  public async getAllItemStock(
    request: GetAllItemStockRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id } = request;
    const item = await this.itemRepository.findOneById(id);

    if (!item) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const result = await this.itemRepository.getAllStock(id);

    const dataReturn = plainToInstance(
      ItemResponseDto,
      {
        ...item,
        quantity: result?.totalQuantity,
      },
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getItemsByRelations(relation: any): Promise<any> {
    const items = await this.itemRepository.findWithRelations(relation);
    return new ResponseBuilder(items)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async getItemStockForReport(
    request: GetListReportStockQueryDto,
  ): Promise<any> {
    const filterWarehouseId = request.filter?.find(
      (item) => item.column === 'warehouseId',
    );
    const filterWarehouseName = request.filter?.find(
      (item) => item.column === 'warehouseName',
    );
    let filterWarehouseIds = [];

    if (!isEmpty(filterWarehouseName)) {
      filterWarehouseIds =
        await this.warehouseService.getWarehouseByNameKeyword(
          filterWarehouseName,
          true,
        );
      if (isEmpty(filterWarehouseIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }

    if (!isEmpty(filterWarehouseId)) {
      filterWarehouseIds.push(+filterWarehouseId.text);
      if (isEmpty(filterWarehouseIds)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .build();
      }
    }
    const [data, count] =
      await this.itemRepository.getItemStockWarehouseShelfFloorForReport(
        request,
        filterWarehouseIds,
      );

    const locatorIds = map(data, 'locatorId');
    const serializeLocator = await this.warehouseLayoutService.getLocatorByIds(
      locatorIds,
      true,
    );
    data.forEach((e) => {
      e.locator = serializeLocator[e.locatorId];
    });

    return new ResponseBuilder<PagingResponse>({
      items: data,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async printQrCode(
    request: PrintQrcodeRequestDto,
  ): Promise<ResponsePayload<any>> {
    return await this.qrcodeService.print(request);
  }

  async getItemsDetailSetting(
    request: GetItemDetailSettingRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { id } = request;
    const itemDetailSetting =
      await this.itemDetailSettingRepository.findOneById(id);
    if (!itemDetailSetting) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const dataReturn = plainToInstance(
      ItemDetailSettingResponseDto,
      itemDetailSetting,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getList(
    payload: GetListItemRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { bomCheck, getByBomConditions, filter, isGetBom, isGetInWarehouse } =
      payload;
    let bomItemIds = [];
    let bomItems = [];
    let notInItemIds = [];
    const itemIdsByQcStageId = [];
    const filterItemIds = [];
    let checkFilterMaterialRequestWarningId = false;

    const stageFilter = filter?.find((item) => item.column === 'qcStageId');
    const materialRequestWarningFilter = filter?.find(
      (item) => item.column === 'materialRequestWarningId',
    );
    const moFilter = filter?.find((item) => item.column === 'moId');
    if (!isEmpty(stageFilter)) {
      const qcStageId = stageFilter.text;
      const saleServiceResponse =
        await this.saleService.getListItemIdByQcStageId(Number(qcStageId));

      if (saleServiceResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(saleServiceResponse.message)
          .build();
      }

      saleServiceResponse.data.forEach((item) => {
        itemIdsByQcStageId.push(item.itemId);
      });
    }

    if (bomCheck === '1' || getByBomConditions === '1') {
      const itemsResponse = await this.produceService.getBomItem(
        new GetListBomRequestDto(),
      );
      bomItems = itemsResponse.data.items;
    }
    if (bomCheck === '1') {
      bomItemIds = bomItems.map((e) => e.itemId);
    }

    if (getByBomConditions === '1') {
      notInItemIds = map(
        bomItems.filter((e) => e.parentId),
        'itemId',
      );
    }
    if (!isEmpty(materialRequestWarningFilter)) {
      const materialRequestWarningDetail =
        await this.produceService.getMaterialRequestWarningDetail(
          +materialRequestWarningFilter.text,
        );
      if (!isEmpty(materialRequestWarningDetail)) {
        materialRequestWarningDetail.itemDetails.forEach((item) => {
          filterItemIds.push(item.id);
          checkFilterMaterialRequestWarningId = true;
        });
      }
    }
    if (!isEmpty(moFilter)) {
      const listMo = await this.produceService.getMoById(+moFilter.text);
      if (!isEmpty(listMo)) {
        listMo.manufacturingOrderDetails.forEach((item) => {
          filterItemIds.push(item.itemId);
        });
      } else if (!checkFilterMaterialRequestWarningId) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: payload.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
      }
    }
    const { data, count } = await this.itemRepository.getList(
      payload,
      bomItemIds,
      notInItemIds,
      itemIdsByQcStageId,
      compact(filterItemIds),
    );

    if (+isGetInWarehouse && data.length === 0) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.ITEM_DO_NOT_EXIST_IN_WAREHOUSE'),
      ).toResponse();
    }

    const manufacturingCountryIds = map(data, 'manufacturingCountryId');
    const objectCategoryIds = map(data, 'objectCategoryId');
    const itemQualityIds = map(data, 'itemQualityId');
    const manufacturingCountries =
      await this.manufacturingCountryRepository.findAllByCondition({
        id: In(manufacturingCountryIds),
      });
    const objectCategories =
      await this.objectCategoryRepository.findAllByCondition({
        id: In(objectCategoryIds),
      });
    const itemQuanlities = await this.itemQualityRepository.findAllByCondition({
      id: In(itemQualityIds),
    });
    const itemQuanlityMap = keyBy(itemQuanlities, 'id');
    const objectCategoryMap = keyBy(objectCategories, 'id');
    const manufacturingCountryMap = keyBy(manufacturingCountries, 'id');
    data.forEach((item) => {
      item.manufacturingCountry =
        manufacturingCountryMap[item.manufacturingCountryId];
      item.objectCategory = objectCategoryMap[item.objectCategoryId];
      item.itemQuality = itemQuanlityMap[item.itemQualityId];
    });
    if (isGetBom) {
      const itemIds = data.map((item) => item.id);
      const boms = await this.produceService.getBomsByItemIds(itemIds);
      const serializedBom = keyBy(boms, 'itemId');

      data.forEach((item, index) => {
        if (serializedBom[item.id]) {
          data[index].bomId = serializedBom[item.id]?.id;
          data[index].bom = serializedBom[item.id];
          data[index].isConfirmedBom = item.status === BomStatusEnum.CONFIRMED;
        }
      });
    }

    const dataReturn = plainToInstance(ItemResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: payload.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getDetailList(
    payload: GetListDetailRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { data, count } = await this.itemDetailSettingRepository.getList(
      payload,
    );
    const dataReturn = plainToInstance(ItemDetailSettingResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: payload.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async importItems(
    request: FileUploadRequestDto,
  ): Promise<ResponsePayload<any>> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
      userIdCreated: request.userIdCreated,
    } as ImportRequestDto;
    let result = {};
    const responseImportItem = await this.itemsImport.importUtil(
      importRequestDto,
    );

    if (responseImportItem.statusCode === ResponseCodeEnum.SUCCESS) {
      const responseImportItemDetail = await this.itemDetailsImport.importUtil(
        importRequestDto,
      );
      result = {
        item: responseImportItem.data,
        itemDetail:
          responseImportItemDetail.statusCode === ResponseCodeEnum.SUCCESS
            ? responseImportItemDetail.data
            : {},
      };
    } else {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const response = plainToInstance(ImportItemResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  importItemDetailSetting(request: FileUploadRequestDto): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
    } as ImportRequestDto;
    return this.itemUnitSettingImport.importUtil(importRequestDto);
  }

  /**
   * createItemsDetailSetting
   * request: CreateItemDetailSettingDto
   */
  async createItemsDetailSetting(
    request: CreateItemDetailSettingDto,
  ): Promise<ResponsePayload<any>> {
    try {
      const detailCodeExist =
        await this.itemDetailSettingRepository.findByCondition({
          code: ILike(request.code),
        });

      if (detailCodeExist) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.ITEM_DETAIL_EXIST'),
        ).toResponse();
      }

      const itemDetailSettingEntity =
        this.itemDetailSettingRepository.createEntity(request);
      const itemDetailSetting = await this.itemDetailSettingRepository.create(
        itemDetailSettingEntity,
      );
      return new ResponseBuilder(itemDetailSetting)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  async updateItemsDetailSetting(
    request: UpdateItemDetailSettingDto,
  ): Promise<ResponsePayload<any>> {
    try {
      let itemDetailSetting =
        await this.itemDetailSettingRepository.findOneById(request.id);
      if (!itemDetailSetting) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }
      if (itemDetailSetting.code !== request.code) {
        const detailExistCode =
          await this.itemDetailSettingRepository.findByCondition({
            code: request.code,
          });
        if (detailExistCode) {
          return new ApiError(
            ResponseCodeEnum.BAD_REQUEST,
            await this.i18n.translate('error.ITEM_DETAIL_EXIST'),
          ).toResponse();
        }
      }

      if (
        !CAN_UPDATE_ITEM_DETAIL_SETTING_STATUS.includes(
          itemDetailSetting.status,
        )
      ) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.ITEM_DETAIL_SETTING_WAS_CONFIRMED'),
        ).toResponse();
      }

      itemDetailSetting = this.itemDetailSettingRepository.updateEntity(
        itemDetailSetting,
        request,
      );

      itemDetailSetting = await this.itemDetailSettingRepository.create(
        itemDetailSetting,
      );
      return new ResponseBuilder(itemDetailSetting)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  async deleteItemDetailSetting(
    request: DeleteItemDto,
  ): Promise<ResponsePayload<any>> {
    const itemDetailSetting =
      await this.itemDetailSettingRepository.findByCondition({
        id: request.id,
        deletedAt: null,
      });

    if (!itemDetailSetting) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const itemDetails = await this.itemDetailRepository.findWithRelations({
      where: {
        detailSetting: request.id,
      },
    });

    if (
      !CAN_DELETE_ITEM_DETAIL_SETTING_STATUS.includes(itemDetailSetting.status)
    ) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.ITEM_DETAIL_SETTING_WAS_CONFIRMED'),
      ).toResponse();
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();

    try {
      //soft delete
      await queryRunner.manager.remove(itemDetails);
      await queryRunner.manager.remove(itemDetailSetting);
      await queryRunner.commitTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  async deleteMultipleItemDetailSetting(
    request: DeleteMultipleDto,
  ): Promise<ResponsePayload<any>> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const itemDetailSettings =
      await this.itemDetailSettingRepository.findAllByCondition({
        id: In(ids),
        deletedAt: null,
      });

    const itemDetailSettingIds = itemDetailSettings.map(
      (itemDetailSetting) => itemDetailSetting.id,
    );
    if (itemDetailSettings.length !== ids.length) {
      ids.forEach((id) => {
        if (!itemDetailSettingIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let index = 0; index < itemDetailSettings.length; index++) {
      const itemDetailSetting = itemDetailSettings[index];
      if (
        !CAN_DELETE_ITEM_DETAIL_SETTING_STATUS.includes(
          itemDetailSetting.status,
        )
      )
        failIdsList.push(itemDetailSetting.id);
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();

    const validIds = itemDetailSettings
      .filter((itemDetail) => !failIdsList.includes(itemDetail.id))
      .map((itemDetail) => itemDetail.id);

    try {
      if (!isEmpty(validIds)) {
        await queryRunner.manager.delete(ItemDetail, {
          itemDetailSettingId: In(validIds),
        });
        await queryRunner.manager.delete(ItemDetailSetting, validIds);
        await queryRunner.commitTransaction();
      }
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    } finally {
      await queryRunner.release();
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  async confirmItemDetailSetting(
    request: any,
  ): Promise<ResponsePayload<ItemDetailSettingResponseDto | any>> {
    const { id, userId } = request;
    const item = await this.itemDetailSettingRepository.findOneById(id);

    if (!item) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ITEM_NOT_FOUND'))
        .build();
    }

    item.approverId = userId;
    item.approvedAt = new Date(Date.now());
    item.status = ItemStatusEnum.CONFIRMED;
    const result = await this.itemDetailSettingRepository.create(item);
    const response = plainToInstance(ItemResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  async rejectItemDetailSetting(
    request: any,
  ): Promise<ResponsePayload<ItemDetailSettingResponseDto | any>> {
    const { id, userId } = request;
    const item = await this.itemDetailSettingRepository.findOneById(id);

    if (!item) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ITEM_NOT_FOUND'))
        .build();
    }

    item.approverId = userId;
    item.approvedAt = new Date(Date.now());
    item.status = ItemStatusEnum.REJECT;
    const result = await this.itemDetailSettingRepository.create(item);
    const response = plainToInstance(ItemResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  async confirmItem(
    request: any,
  ): Promise<ResponsePayload<ItemResponseDto | any>> {
    const { id, userId } = request;
    const item = await this.itemRepository.findOneById(id);

    if (!item) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ITEM_NOT_FOUND'))
        .build();
    }

    item.approverId = userId;
    item.approvedAt = new Date(Date.now());
    item.status = ItemStatusEnum.CONFIRMED;
    const result = await this.itemRepository.create(item);
    const response = plainToInstance(ItemResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  async rejectItem(
    request: any,
  ): Promise<ResponsePayload<ItemResponseDto | any>> {
    const { userId, id } = request;
    const item = await this.itemRepository.findOneById(id);

    if (!item) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ITEM_NOT_FOUND'))
        .build();
    }

    item.approverId = userId;
    item.approvedAt = new Date(Date.now());
    item.status = ItemStatusEnum.REJECT;
    const result = await this.itemRepository.create(item);
    const response = plainToInstance(ItemResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  async createItem(request: CreateItemDto): Promise<ResponsePayload<any>> {
    const { itemConvertUnits, isConvertUnit } = request;

    const itemConvertUnitEntities: ItemConvertUnitEntity[] = [];
    if (isConvertUnit)
      for (let i = 0; i < itemConvertUnits.length; i++) {
        itemConvertUnitEntities.push(
          this.itemConvertUnitRepository.createEntity(itemConvertUnits[i]),
        );
      }
    const newItemEntity = this.itemRepository.createEntity(
      request,
      itemConvertUnitEntities,
    );

    return await this.save(newItemEntity, request);
  }

  async updateItem(request: UpdateItemDto): Promise<ResponsePayload<any>> {
    const item = await this.itemRepository.findOneWithRelations({
      where: {
        id: request.id,
      },
      relations: ['itemType', 'itemConvertUnits'],
    });
    if (!item) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    // if (
    //   DATA_ITEM_CAN_NOT_UPDATE_AND_DELETE.ITEMS.code.includes(
    //     item.itemType.code,
    //   )
    // ) {
    //   return new ApiError(
    //     ResponseCodeEnum.BAD_REQUEST,
    //     await this.i18n.translate('error.CAN_NOT_UPDATE'),
    //   ).toResponse();
    // }
    return await this.save(item, request);
  }

  async deleteItem(request: DeleteItemDto): Promise<ResponsePayload<any>> {
    const item = await this.itemRepository.findOneWithRelations({
      where: {
        id: request.id,
        deletedAt: null,
      },
      relations: ['itemType'],
    });
    if (!item) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    if (
      !request.isMmsRequest &&
      DATA_ITEM_CAN_NOT_UPDATE_AND_DELETE.ITEMS.code.includes(
        item.itemType.code,
      )
    ) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_DELETE'),
      ).toResponse();
    }
    const condition = new GetByItemIdRequestDto();
    condition.itemId = request.id;

    const purchasedOrderIds =
      await this.saleService.checkItemHasExistOnPurchaseOrder(condition);
    if (purchasedOrderIds) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.ITEM_IN_ORDER'))
        .build();
    }
    // if (!CAN_DELETE_ITEM_STATUS.includes(item.status)) {
    //   return new ApiError(
    //     ResponseCodeEnum.BAD_REQUEST,
    //     await this.i18n.translate('error.ITEM_WAS_CONFIRMED'),
    //   ).toResponse();
    // }

    const salesOrderIds = await this.saleService.checkItemHasExistOnSaleOrder(
      condition,
    );
    if (salesOrderIds) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.ITEM_IN_ORDER'))
        .build();
    }

    const productionsOrderIds =
      await this.saleService.checkItemHasExistOnProductionOrder(condition);
    if (productionsOrderIds) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.ITEM_IN_ORDER'))
        .build();
    }

    const blockItemDetails = await this.checkItemHasExistOnBlockItemDetail(
      condition,
    );
    if (blockItemDetails) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.ITEM_DETAIL_AVAILABLE'))
        .build();
    }

    const packageItems = await this.checkItemHasExistOnPackageItem(condition);
    if (packageItems) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.ITEM_DETAIL_AVAILABLE'))
        .build();
    }

    try {
      item.deletedAt = new Date();
      await this.itemRepository.create(item);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async deleteMultipleItem(
    request: DeleteMultipleDto,
  ): Promise<ResponsePayload<any>> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const items = await this.itemRepository.findWithRelations({
      where: {
        id: In(ids),
      },
      relations: ['itemType'],
    });

    const itemIds = items.map((item) => item.id);
    if (items.length !== ids.length) {
      ids.forEach((id) => {
        if (!itemIds.includes(id)) failIdsList.push(id);
      });
    }

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (
        DATA_ITEM_CAN_NOT_UPDATE_AND_DELETE.ITEMS.code.includes(
          item.itemType.code,
        ) ||
        !CAN_DELETE_ITEM_STATUS.includes(item.status)
      )
        failIdsList.push(item.id);
    }

    const condition = new GetByItemIdRequestDto();
    condition.itemId = ids;

    let purchasedOrders,
      salesOrders,
      productionsOrders,
      blockItemDetails,
      packageItems;

    await Promise.all([
      (purchasedOrders =
        await this.saleService.checkItemHasExistOnPurchaseOrder(condition)),
      (salesOrders = await this.saleService.checkItemHasExistOnSaleOrder(
        condition,
      )),
      (productionsOrders =
        await this.saleService.checkItemHasExistOnProductionOrder(condition)),
      (blockItemDetails = await this.checkItemHasExistOnBlockItemDetail(
        condition,
      )),
      (packageItems = await this.checkItemHasExistOnPackageItem(condition)),
    ]);

    purchasedOrders.forEach((purchasedOrder) => {
      if (ids.includes(purchasedOrder.itemId))
        failIdsList.push(purchasedOrder.itemId);
    });

    salesOrders.forEach((saleOrder) => {
      if (ids.includes(saleOrder.itemId)) failIdsList.push(saleOrder.itemId);
    });

    productionsOrders.forEach((productionOrder) => {
      if (ids.includes(productionOrder.itemId))
        failIdsList.push(productionOrder.itemId);
    });

    blockItemDetails.forEach((productionOrder) => {
      if (ids.includes(productionOrder.itemId))
        failIdsList.push(productionOrder.itemId);
    });

    packageItems.forEach((productionOrder) => {
      if (ids.includes(productionOrder.itemId))
        failIdsList.push(productionOrder.itemId);
    });

    const validIds = ids.filter((id) => !failIdsList.includes(id));

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (!isEmpty(validIds)) {
        await queryRunner.manager.delete(ItemDetail, {
          itemId: In(validIds),
        });
        await queryRunner.manager.delete(Item, validIds);
        await queryRunner.commitTransaction();
      }
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    } finally {
      await queryRunner.release();
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  private async save(
    itemEntity: Item,
    request: CreateItemDto | UpdateItemDto,
  ): Promise<ResponsePayload<any> | any> {
    const {
      code,
      itemTypeId,
      itemUnitId,
      objectCategoryId,
      itemQualityId,
      manufacturingCountryId,
      itemConvertUnits,
      isConvertUnit,
      itemGroupId,
      file,
    } = request;

    const isUpdate = itemEntity.id !== undefined;
    //Check Updated
    if (isUpdate && !CAN_UPDATE_ITEM_STATUS.includes(itemEntity.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.ITEM_WAS_CONFIRMED'),
      ).toResponse();
    }

    //Validate
    if (!isUpdate || itemEntity.code !== code) {
      const itemCode = await this.itemRepository.findByCondition({
        code: code,
      });
      if (itemCode)
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.CODE_EXIST'),
        ).toResponse();
    }

    if (!isUpdate || itemTypeId) {
      const itemType = await this.itemTypeSettingRepository.findByCondition({
        id: request.itemTypeId,
        //level: 1,
      });
      if (!itemType)
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.ITEM_TYPE_NOT_FOUND'))
          .build();
      itemEntity.itemType = itemType;
    }

    if (!isUpdate || itemUnitId) {
      const itemUnit = await this.itemUnitSettingRepository.findOneById(
        request.itemUnitId,
      );
      if (!itemUnit)
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.ITEM_UNIT_NOT_FOUND'))
          .build();

      itemEntity.itemUnit = itemUnit;
    }

    if (!isUpdate || itemGroupId) {
      const itemGroup = await this.itemUnitSettingRepository.findOneById(
        request.itemGroupId,
      );
      if (!itemGroup)
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.ITEM_UNIT_NOT_FOUND'))
          .build();

      itemEntity.itemGroup = itemGroup;
    }

    const objectCategory = await this.objectCategoryRepository.findOneById(
      objectCategoryId,
    );
    //if (!objectCategory) {
    //  return new ResponseBuilder()
    //    .withCode(ResponseCodeEnum.NOT_FOUND)
    //    .withMessage(
    //      await this.i18n.translate('error.OBJECT_CATEGORY_NOT_FOUND'),
    //    )
    //    .build();
    //}

    const itemQuality = await this.itemQualityRepository.findOneById(
      itemQualityId,
    );
    //if (!itemQuality) {
    //  return new ResponseBuilder()
    //    .withCode(ResponseCodeEnum.NOT_FOUND)
    //    .withMessage(await this.i18n.translate('error.ITEM_QUALITY_NOT_FOUND'))
    //    .build();
    //}

    const manufacturingCountry =
      await this.manufacturingCountryRepository.findOneById(
        manufacturingCountryId,
      );
    //if (!manufacturingCountry) {
    //  return new ResponseBuilder()
    //    .withCode(ResponseCodeEnum.NOT_FOUND)
    //    .withMessage(
    //      await this.i18n.translate('error.MANUFACTURING_COUNTRY_NOT_FOUND'),
    //    )
    //    .build();
    //}

    const itemConvertUnitIds = map(itemConvertUnits, 'itemUnitId');
    const itemUnitExist =
      await this.itemUnitSettingRepository.findAllByCondition({
        id: In(itemConvertUnitIds),
      });
    if (itemUnitExist.length !== itemConvertUnits.length) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.ITEM_UNIT_NOT_FOUND'),
      ).toResponse();
    }

    let deleteICUnit;
    const itemConvertUnitEntities: ItemConvertUnitEntity[] = [];
    if (isUpdate) {
      const itemConvertUnitExist = itemEntity.itemConvertUnits;

      // item convert unit
      if (isConvertUnit) {
        const newICUnit = itemConvertUnits.filter(
          (icu) => !itemConvertUnitExist.some((icue) => icu.id === icue.id),
        );
        const oldICUnit = itemConvertUnits.filter((icu) =>
          itemConvertUnitExist.some((icue) => icu.id === icue.id),
        );
        deleteICUnit = itemConvertUnitExist.filter(
          (icu) => !oldICUnit.some((icue) => icu.id === icue.id),
        );
        const tempICUnit = [...newICUnit, ...oldICUnit];
        for (let i = 0; i < tempICUnit.length; i++) {
          itemConvertUnitEntities.push(
            this.itemConvertUnitRepository.createEntity(
              tempICUnit[i],
              itemEntity,
            ),
          );
        }
      }
    }

    let fileId;
    if (file) {
      const fileResponse = await this.fileService.uploadFile(
        file,
        FileResource.ITEM,
      );

      if (fileResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(fileResponse?.message);
      }
      fileId = fileResponse?.data?.fileUrl;
    }
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (isUpdate) {
        await queryRunner.manager.delete(ItemDetail, {
          itemId: itemEntity.id,
        });
        if (!isEmpty(deleteICUnit))
          await queryRunner.manager.delete(ItemConvertUnitEntity, deleteICUnit);

        itemEntity = this.itemRepository.updateEntity(
          itemEntity,
          request,
          itemConvertUnitEntities,
        );

        delete itemEntity.itemType;
      }

      const saveItem = await queryRunner.manager.save(itemEntity);
      if (fileId) {
        const fileEntity = this.fileRepository.createEntity({
          resourceId: saveItem.id,
          resource: FileResource.ITEM,
          fileId,
        });
        await queryRunner.manager.save(fileEntity);
      }

      await queryRunner.commitTransaction();
      return new ResponseBuilder(saveItem)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  async createItemsStockMovement(
    itemsStockMovement: CreateItemStockMovementDto,
  ): Promise<ResponsePayload<any>> {
    const listItemStockMovementEntity = itemsStockMovement.items.map((e) => {
      return this.itemStockMovementRepository.createEntity(e);
    });
    const queryRunner = this.connection.createQueryRunner();
    let itemStockMovements;
    await queryRunner.startTransaction();
    try {
      itemStockMovements = await queryRunner.manager.save(
        listItemStockMovementEntity,
      );
      const itemStockMovementHistoryEntities = [] as ItemStockMovementHistory[];
      itemsStockMovement.items.map((itemStock, index) => {
        itemStock.itemsStockMovementHistories.map(
          (itemsStockMovementHistory) => {
            itemStockMovementHistoryEntities.push(
              this.itemStockMovementHistoryRepository.createEntity({
                itemId: itemsStockMovementHistory.itemId,
                locatorId: itemsStockMovementHistory.locatorId,
                lotNumber: itemsStockMovementHistory.lotNumber,
                quantity: itemsStockMovementHistory.quantity,
                amount: itemsStockMovementHistory.amount,
                totalAmount: itemsStockMovementHistory.totalAmount,
                itemStockMovementId: itemStockMovements[index].id,
              } as ItemStockMovementHistoryDto),
            );
          },
        );
      });
      await queryRunner.manager.save(itemStockMovementHistoryEntities);
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }

    return new ResponseBuilder(itemStockMovements)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getItemStock(
    request: GetItemStockRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { data, count } = await this.itemRepository.getItemStock(request);

    const dataReturn = plainToInstance(ItemStockAvailableResponse, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getItemWarehouseStock(
    request: GetItemWarehouseStockRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { warehouseId } = request;
    let dataFormatted = [];

    const locatorIdsRequest = request?.locatorIds
      ? request?.locatorIds.split(',').map((locatorId) => Number(locatorId))
      : [];
    const itemIdsRequest = request?.itemIds
      ? request?.itemIds.split(',').map((itemId) => Number(itemId))
      : [];
    const { data, count } = await this.itemRepository.getItemWarehouseStock(
      request,
      locatorIdsRequest,
      itemIdsRequest,
    );

    if (isEmpty(data)) {
      return new ResponseBuilder<PagingResponse>({
        items: [],
        meta: { total: 0, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const locatorIds = uniq(map(flatMap(data, 'locations'), 'locatorId'));
    const warehouseIds = uniq(map(flatMap(data, 'locations'), 'warehouseId'));
    const [locators, warehouses] = await Promise.all([
      this.warehouseLayoutService.getLocatorByIds(locatorIds, true),
      this.warehouseService.getListByIDs(warehouseIds, true),
    ]);

    if (!warehouseId && !isEmpty(data)) {
      const warehouseSheflfFloorIds = [];
      data.forEach((item) => {
        item.locations.forEach((location) => {
          warehouseSheflfFloorIds.push(location.warehouseShelfFloorId);
        });
      });
      dataFormatted = data.map((item) => {
        const locations = item.locations.map((location) => {
          const locator = locators[location.locatorId];
          const warehouse = warehouses[location.warehouseId];

          return {
            ...location,
            quantity: location.lots?.reduce(
              (acc, cur) => acc + cur.quantity,
              0,
            ),
            warehouse: warehouse,
            locator: locator,
          };
        });

        return {
          ...item,
          quantity: locations.reduce((acc, cur) => acc + cur.quantity, 0),
          locations: locations,
        };
      });
    } else {
      dataFormatted = data.map((item) => {
        const locations = item.locations.map((location) => {
          const locator = locators[location.locatorId] || {
            id: location.locatorId,
          };
          const warehouse = has(warehouses, location.warehouseId)
            ? warehouses[location.warehouseId]
            : {};
          return {
            ...location,
            quantity: location?.lots?.reduce(
              (acc, cur) =>
                cur.quantity ? plusBigNumber(acc, cur.quantity) : acc,
              0,
            ),
            warehouse: {
              id: warehouse?.id,
              code: warehouse?.code,
              name: warehouse?.name,
            },
            locator: locator,
          };
        });

        return {
          ...item,
          quantity: locations?.reduce(
            (acc, cur) =>
              cur.quantity ? plusBigNumber(acc, cur.quantity) : acc,
            0,
          ),
          locations: locations,
        };
      });
    }

    const reponse = plainToInstance(
      ItemStockLocationResponseDto,
      dataFormatted,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PagingResponse>({
      items: reponse,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getItemWarehouse(
    itemDto: GetItemWarehouseDto,
  ): Promise<ResponsePayload<any>> {
    const listItemId = itemDto.items.map((item) => item.itemId);

    const item = await this.itemRepository.getItemWarehouseQuantity(
      listItemId,
      itemDto.warehouseId,
    );

    if (!item.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const data = plainToInstance(ItemInventoryResponse, item, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getItemWarehouseWithLocation(
    request: GetItemWarehouseWithLocationRequestDto,
  ): Promise<ResponsePayload<any>> {
    const {
      warehouseSectorId,
      warehouseShelfFloorId,
      warehouseShelfId,
      items,
    } = request;
    const listItemIds = items.map((item) => item.itemId);
    const lotNumbers = map(flatMap(items, 'lots'), 'lotNumber');

    const item: any =
      await this.itemRepository.getItemWarehouseQuantityWithLocation(
        listItemIds,
        null,
        warehouseSectorId,
        warehouseShelfFloorId,
        warehouseShelfId,
        lotNumbers,
      );

    if (!item.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const data = plainToInstance(ItemInventoryResponse, item, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async checkStockAvaiable(
    request: CheckStockAvailableRequest,
  ): Promise<any> {
    try {
      const stockAvaiable = await this.itemRepository.getItemStockQuantity(
        request.items.map(
          (e) => new ItemStockAvailable(e.itemId, e.warehouseId),
        ),
      );

      const dataStockAvaiable = plainToInstance(
        ItemStockAvailableResponse,
        stockAvaiable,
        {
          excludeExtraneousValues: true,
        },
      );

      const dataStockMapping = request.items.map((e) => {
        const item = dataStockAvaiable.find(
          (e2) => e.itemId === e2.itemId && e.warehouseId == e2.warehouseId,
        );
        return {
          ...e,
          availableQuantity: item?.quantity ? item.quantity : 0,
        };
      });

      const invalidItems = dataStockMapping.filter(
        (e) => e.quantity > e.availableQuantity,
      );

      return new ResponseBuilder({ invalidItems: invalidItems })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  public async getItemsById(
    items: any,
    factoryId?: number,
    filter?: any,
    basicInfor?: boolean,
    forceFilterByFactoryId?: boolean,
  ): Promise<ResponsePayload<any>> {
    let warehouseIds;
    if (factoryId) {
      const warehouse = await this.warehouseService.getWarehousesByFactory(
        factoryId,
      );
      warehouseIds = warehouse?.map((i) => i.id) || [];
    }

    const data = await this.itemRepository.getByIds(
      items,
      warehouseIds,
      filter,
      basicInfor,
      forceFilterByFactoryId,
    );
    if (!data.length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async runSeeders(): Promise<any> {
    const canRunSeeder = await this.itemTypeSettingRepository.findByCondition({
      code: DEFAULT_ITEM_TYPES.MATERIAL.code,
    });
    if (canRunSeeder) {
      return;
    }
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();

    try {
      const materialItemType = new ItemTypeSetting();
      materialItemType.name = DEFAULT_ITEM_TYPES.MATERIAL.name;
      materialItemType.code = DEFAULT_ITEM_TYPES.MATERIAL.code;

      const productItemType = new ItemTypeSetting();
      productItemType.name = DEFAULT_ITEM_TYPES.PRODUCT.name;
      productItemType.code = DEFAULT_ITEM_TYPES.PRODUCT.code;

      const deviceItemType = new ItemTypeSetting();
      deviceItemType.name = DEFAULT_ITEM_TYPES.DEVICE.name;
      deviceItemType.code = DEFAULT_ITEM_TYPES.DEVICE.code;

      const supplyItemType = new ItemTypeSetting();
      supplyItemType.name = DEFAULT_ITEM_TYPES.SUPPLY.name;
      supplyItemType.code = DEFAULT_ITEM_TYPES.SUPPLY.code;

      const accessoryItemType = new ItemTypeSetting();
      accessoryItemType.name = DEFAULT_ITEM_TYPES.ACCESSORY.name;
      accessoryItemType.code = DEFAULT_ITEM_TYPES.ACCESSORY.code;

      const mmsItemGroup = new ItemGroupSetting();
      mmsItemGroup.code = DEFAULT_ITEM_GROUP.MMS.code;
      mmsItemGroup.name = DEFAULT_ITEM_GROUP.MMS.name;

      const mmsItemUnit = new ItemUnitSetting();
      mmsItemUnit.code = DEFAULT_ITEM_UNIT.CA.code;
      mmsItemUnit.name = DEFAULT_ITEM_UNIT.CA.name;

      const itemGroup = new ItemGroupSetting();
      itemGroup.code = process.env.OTHER_CODE_GROUP;
      itemGroup.name = process.env.OTHER_NAME_GROUP;
      itemGroup.description = process.env.OTHER_DESCRIPTION_GROUP;

      await queryRunner.manager.save([
        materialItemType,
        productItemType,
        deviceItemType,
        supplyItemType,
        accessoryItemType,
        mmsItemGroup,
        mmsItemUnit,
        itemGroup,
      ]);

      await queryRunner.commitTransaction();

      return;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  public async getEnv(): Promise<any> {
    const [itemTypes, itemGroups, itemUnits] = await Promise.all([
      this.itemTypeSettingRepository.findAll(),
      this.itemGroupSettingRepository.findAll(),
      this.itemUnitSettingRepository.findAll(),
    ]);
    return new ResponseBuilder({
      itemTypes: itemTypes,
      itemGroups: itemGroups,
      itemUnits: itemUnits,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param payload
   * @returns
   */
  public async getDetail(
    payload: GetDetailRequestDto,
    isGetAllWarehouse = IsGetAllEnum.NO,
  ) {
    const { id } = payload;
    const item = await this.itemRepository.getDetail(id);

    if (isEmpty(item)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.ITEM_NOT_FOUND'),
      ).toResponse();
    }
    const manufacturingCountryIds = [item.manufacturingCountryId];
    const objectCategoryIds = [item.objectCategoryId];
    const itemQualityIds = [item.itemQualityId];
    const itemUnitIds = map(item.itemConvertUnits, 'itemUnitId');

    const [
      manufacturingCountries,
      //objectCategories,
      //itemQuanlities,
      itemWarehouseSources,
      itemType,
      //settingQr,
      itemUnits,
    ] = await Promise.all([
      this.manufacturingCountryRepository.findAllByCondition({
        id: In(manufacturingCountryIds),
      }),
      //this.objectCategoryRepository.findAllByCondition({
      //  id: In(objectCategoryIds),
      //}),
      //this.itemQualityRepository.findAllByCondition({
      //  id: In(itemQualityIds),
      //}),
      this.itemWarehouseSourceRepository.findAllByCondition({
        itemId: id,
      }),
      this.itemTypeSettingRepository.getDetailItemTypeSubGroup(item.itemTypeId),
      //this.settingService.getSettingQrCode(),
      this.itemUnitSettingRepository.findAllByCondition({
        id: In(itemUnitIds),
      }),
    ]);

    //const itemQuanlityMap = keyBy(itemQuanlities, 'id');
    //const objectCategoryMap = keyBy(objectCategories, 'id');
    const manufacturingCountryMap = keyBy(manufacturingCountries, 'id');
    const itemUnitMap = keyBy(itemUnits, 'id');

    item.manufacturingCountry =
      manufacturingCountryMap[item.manufacturingCountryId];
    //item.objectCategory = objectCategoryMap[item.objectCategoryId];
    //item.itemQuality = itemQuanlityMap[item.itemQualityId];

    //item.qrCode = this.qrcodeService.generateQrCode(
    //  QrCodeItemTypeEnum.NEW,
    //  item.code,
    //  item.objectCategoryId,
    //  COMPANY_DEFAULT,
    //  null,
    //  settingQr,
    //);

    if (item.createdByUser) {
      const responseUserService = await this.userService.getUserById(
        item.createdByUser,
      );
      item.createdByUser = responseUserService;
    }
    const warehouseIds = uniq(map(itemWarehouseSources, 'warehouseId'));
    const [warehouses, itemWarehouseStockAvaiables] = await Promise.all([
      warehouseIds
        ? this.warehouseService.getListByIDs(warehouseIds, true)
        : {},
      warehouseIds
        ? this.itemWarehouseService.getItemStockAvaiableGroupLocation({
            items: warehouseIds?.map((warehouseId: number) => ({
              warehouseId,
              itemId: id,
            })),
          } as GetItemStockAvailableSwiftLocatorRequestDto)
        : {},
    ]);
    const itemWarehouseStockAvaiableByWarehouse = keyBy(
      (itemWarehouseStockAvaiables as any)?.data,
      'warehouseId',
    );

    const response = plainToInstance(
      ItemResponseDto,
      {
        ...item,
        //itemType: itemType,
        itemWarehouseSources: itemWarehouseSources
          ?.filter((iws) =>
            isGetAllWarehouse.toString() === IsGetAllEnum.YES
              ? true
              : itemWarehouseStockAvaiableByWarehouse[iws.warehouseId]
                  ?.quantity > 0,
          )
          ?.map((iws) => ({
            warehouse: warehouses[iws.warehouseId],
            accounting: iws.accounting,
          })),
        itemConvertUnits: item.itemConvertUnits?.map((i) => {
          return {
            ...i,
            itemUnit: itemUnitMap[i.itemUnitId],
          };
        }),
      },
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  async getItemsStockMovements(
    request: GetListItemStockMovementRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { warehouseStockMovementId } = request;
    const data =
      await this.itemStockMovementRepository.getListByWarehouseMovementIds([
        warehouseStockMovementId,
      ]);

    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getItemStockMovementsByWarehouseStockMovementIds(
    request: GetListItemStockMovementByWarehouseStockMovementIdsRequestDto,
  ): Promise<any> {
    const { warehouseStockMovementIds } = request;
    const data =
      await this.itemStockMovementRepository.getListByWarehouseMovementIds(
        warehouseStockMovementIds,
      );

    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param request
   * @returns
   */
  async getItemStockMovementByLotNumbers(
    request: GetListItemStockMovementByLotNumberRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { lotNumbers, warehouseFloorId } = request;
    const data =
      await this.itemStockMovementWarehouseShelfFloorRepository.getListByLotNumber(
        warehouseFloorId,
        lotNumbers,
      );

    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getDailyReport(
    request: GetReportDailyDto,
  ): Promise<ResponsePayload<any>> {
    const data = await this.itemWarehouseRepository.getStockDaily(request);
    const stockDailyReturn = plainToInstance(
      WarehouseStockDailyRespone,
      <any[]>data,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(stockDailyReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getQuantityItemWarehouse(
    request: GetQuantityItemWarehouseRequestDto,
  ): Promise<ResponsePayload<any>> {
    const data = await this.itemWarehouseRepository.getQuantityItemWarehouse(
      request,
    );
    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getCountItemByItemType(): Promise<ResponsePayload<any>> {
    const data = await this.itemTypeSettingRepository.getCountItem();
    const countItemReturn = plainToInstance(ItemTypeCountItemResponse, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(countItemReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getCountTransferByDate(
    request: GetCountTransferByDateRequest,
  ): Promise<ResponsePayload<any>> {
    const data = await this.itemStockMovementRepository.getCountByDateIds(
      request,
    );
    const dataReturn = plainToInstance(TransferByDateResponse, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getItemByItemType(
    request: GetItemByItemTypeRequest,
  ): Promise<ResponsePayload<any>> {
    const data = await this.itemRepository.getItemByItemType(request);
    const dataReturn = plainToInstance(ItemIdResponse, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn.map((e) => e.itemId))
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async checkItemHasExistOnBlockItemDetail(
    request: GetByItemIdRequestDto,
  ): Promise<any> {
    const condition = { itemId: request.itemId };
    if (isArray(request.itemId))
      return await this.blockItemDetailRepository.findAllByCondition({
        itemId: In(request.itemId),
      });

    return await this.blockItemDetailRepository.findByCondition(condition);
  }

  async checkItemHasExistOnPackageItem(
    request: GetByItemIdRequestDto,
  ): Promise<any> {
    const condition = { itemId: request.itemId };
    if (isArray(request.itemId))
      return await this.packageItemRepository.findAllByCondition({
        itemId: In(request.itemId),
      });

    return await this.packageItemRepository.findByCondition(condition);
  }

  async countTotalItem(): Promise<any> {
    const data = await this.itemRepository.countTotalItem();

    return new ResponseBuilder()
      .withData({
        total: data,
      })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async countTotalOtherItem(): Promise<any> {
    const data = await this.itemRepository.countTotalOtherItem();

    return new ResponseBuilder()
      .withData({
        total: data,
      })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async itemStockByItemGroupSummary(
    request: ItemStockByItemGroupQueryDto,
  ): Promise<any> {
    const data =
      await this.itemGroupSettingRepository.itemStockByItemGroupSummary(
        request,
      );

    const total = data.reduce((a, b) => {
      return plus(a, b.value);
    }, 0);

    const dataReturn = plainToInstance(
      TotalItemStockByItemGroupResponse,
      {
        total,
        groups: data,
      },
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder()
      .withData(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getItemWarehouseStocks(request: ItemStockRequest): Promise<any> {
    const { filter, isAllLots } = request;
    let data, count, warehouseIds;
    const warehouseFilter = find(filter, (f) => f.column === 'warehouseIds');
    const warehouseFloorFilter = find(
      filter,
      (f) => f.column === 'warehouseShelfFloorId',
    );
    const warehouseShelfFilter = find(
      filter,
      (f) => f.column === 'warehouseShelfIds',
    );
    const warehouseSectorFilter = find(
      filter,
      (f) => f.column === 'warehouseSectorIds',
    );
    let floorIds;

    if (warehouseFilter) {
      const requestFilterFloor = new PaginationQuery();
      requestFilterFloor.filter = [
        {
          column: 'warehouseIds',
          text: warehouseFilter.text,
        },
      ];
      const floors = await this.warehouseService.getListFloor(
        requestFilterFloor,
      );

      if (isEmpty(floors)) {
        return new ResponseBuilder<PagingResponse>({
          items: [],
          meta: { total: 0, page: request.page },
        })
          .withCode(ResponseCodeEnum.SUCCESS)
          .withMessage(await this.i18n.translate('error.SUCCESS'))
          .build();
      }

      floorIds = map(floors, 'id');
    }
    if (warehouseFloorFilter) {
      floorIds = warehouseFloorFilter?.text
        .split(',')
        .map((floorId) => +floorId);
    }

    if (
      !isEmpty(warehouseFloorFilter) ||
      !isEmpty(warehouseShelfFilter) ||
      !isEmpty(warehouseSectorFilter) ||
      !isEmpty(warehouseFilter) ||
      isAllLots
    ) {
      [data, count] = await this.itemRepository.getItemWarehousesByFloorId(
        request,
        floorIds,
        warehouseShelfFilter?.text?.split(',')?.map((shelfId) => +shelfId),
        warehouseSectorFilter?.text?.split(',')?.map((sectorId) => +sectorId),
      );
    } else {
      [data, count] = await this.itemWarehouseRepository.getItemWarehouses(
        request,
      );

      warehouseIds = uniq(data.map((warehouse) => warehouse.warehouseId));
    }
    const warehouses = await this.warehouseService.getListByIDs(
      warehouseIds,
      true,
    );

    const items = data.map((e) => {
      return {
        ...e,
        warehouse: warehouses[e.warehouseId],
      };
    });

    const dataReturn = plainToInstance(ItemStockResponse, items, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async scanQrCode(params) {
    return await this.qrcodeService.scanQrCode(params);
  }

  public async getItemsByConditions(condition: any, sort?: any): Promise<any> {
    const items = await this.itemRepository.findItemsByCondition(
      condition,
      sort,
    );
    return new ResponseBuilder(items)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  public async updateColumnIsHasBomOfItem(
    request: UpdateIsHasBomItemDto,
  ): Promise<ResponsePayload<any>> {
    const item = await this.itemRepository.create(request);
    return new ResponseBuilder(item).withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async getItemWarehouseListByItemIdsAndWarehouseIds(
    request: any,
  ): Promise<any> {
    const { itemIds, warehouseIds } = request;
    try {
      const itemWarehouses =
        await this.itemWarehouseRepository.findAllByCondition({
          itemId: In(itemIds),
          warehouseId: In(warehouseIds),
        });
      const response = plainToInstance(ItemWarehouseResponse, itemWarehouses, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  async getItemsByItemUnitName(itemUnitName: string): Promise<any> {
    try {
      const items = await this.itemRepository.getItemsByItemUnitName(
        itemUnitName,
      );
      const response = plainToInstance(
        GetItemByFilterItemUnitNameResponseDto,
        items,
        {
          excludeExtraneousValues: true,
        },
      );

      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  async getItemStockMovementWarehouseShelfFloor(
    request: GetItemStockMovementWarehouseShelfFloorDto[],
  ): Promise<any> {
    const conditions = request.map((req) => {
      const condition = {
        warehouseShelfFloorId: req.floorId,
        itemId: req.itemId,
      };
      if (req?.lotNumber && req?.lotNumber?.length > 0) {
        condition['lotNumber'] = ILike(req.lotNumber);
      } else {
        condition['lotNumber'] = IsNull();
      }
      return condition;
    });
    const result =
      await this.itemStockMovementWarehouseShelfFloorRepository.findAllByCondition(
        conditions,
      );
    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async getItemStockMovementWarehouseShelfFloorByItemIds(
    request: GetItemStockMovementWarehouseShelfFloorByItemIdsDto,
  ): Promise<any> {
    const result =
      await this.itemStockMovementWarehouseShelfFloorRepository.suggestItemSameType(
        request,
      );
    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async getListWarning(payload: any): Promise<any> {
    const filterWarehouseName = payload.filter?.find(
      (item) => item.column === 'warehouseName',
    );
    let filterWarehouseIds = [];
    if (!isEmpty(filterWarehouseName)) {
      try {
        filterWarehouseIds =
          await this.warehouseService.getWarehouseByNameKeyword(
            filterWarehouseName,
            true,
          );
        if (isEmpty(filterWarehouseIds)) {
          return new ResponseBuilder<PagingResponse>({
            items: [],
            meta: { total: 0, page: payload.page },
          })
            .withCode(ResponseCodeEnum.SUCCESS)
            .build();
        }
      } catch (error) {
        return new ResponseBuilder({ error })
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .build();
      }
    }

    const { total, result } =
      await this.itemStockMovementWarehouseShelfFloorRepository.getListWarning(
        payload,
        filterWarehouseIds,
      );

    const resData = plainToClass(GetWaringListResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: resData,
      meta: { total, page: payload.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getItemByCodes(codes: string[]): Promise<ResponsePayload<any>> {
    const items = await this.itemRepository.findAllByCondition({
      code: In(codes),
    });
    const response = plainToInstance(ItemResponseDto, items, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async getHistoriesItemStockMovements(
    request: GetHistoriesItemStockMovements,
  ): Promise<ResponsePayload<any>> {
    const result =
      await this.itemStockMovementRepository.getHistoriesItemStockMovements(
        request,
      );
    const response = plainToInstance(ItemStockMovementResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  async updateItemStockMovementWarehouseShelfFloor(
    request: UpdateItemStockMovementWarehouseShelfFloorRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { itemStockMovementWarehouseShelfFloors } = request;
    const itemIds: any[] = [];
    const lotNumbers: any[] = [];
    const warehouseShelfFloorIds: any[] = [];
    const itemStockMWSFMap: any = new Map();
    const itemStockMovementWarehouseShelfFloorEntitys: any[] = [];
    const keyNotExists: any[] = [];

    itemStockMovementWarehouseShelfFloors.forEach(
      (itemStockMovementWarehouseShelfFloor) => {
        const key =
          itemStockMovementWarehouseShelfFloor.itemId +
          '-' +
          itemStockMovementWarehouseShelfFloor.lotNumber +
          '-' +
          itemStockMovementWarehouseShelfFloor.warehouseShelfFloorId;
        itemIds.push(itemStockMovementWarehouseShelfFloor.itemId);
        lotNumbers.push(itemStockMovementWarehouseShelfFloor.lotNumber);
        warehouseShelfFloorIds.push(
          itemStockMovementWarehouseShelfFloor.warehouseShelfFloorId,
        );
        itemStockMWSFMap.set(key, {
          itemId: itemStockMovementWarehouseShelfFloor.itemId,
          lotNumber: itemStockMovementWarehouseShelfFloor.lotNumber,
          quantity: itemStockMovementWarehouseShelfFloor.actualQuantity,
          warehouseSectorId:
            itemStockMovementWarehouseShelfFloor.warehouseSectorId,
          warehouseShelfId:
            itemStockMovementWarehouseShelfFloor.warehouseShelfId,
          warehouseShelfFloorId:
            itemStockMovementWarehouseShelfFloor.warehouseShelfFloorId,
        });
      },
    );

    const itemStockMovementWarehouseShelfFloorExists =
      await this.itemStockMovementWarehouseShelfFloorRepository.findByItemIdsLotNumbersWarehouseShelfFloorIds(
        itemIds,
        lotNumbers,
        warehouseShelfFloorIds,
      );

    itemStockMovementWarehouseShelfFloorExists.forEach((itemStockMWSFExits) => {
      const keyExist =
        itemStockMWSFExits.itemId +
        '-' +
        itemStockMWSFExits.lotNumber +
        '-' +
        itemStockMWSFExits.warehouseShelfFloorId;
      itemStockMovementWarehouseShelfFloors.forEach((itemStockMWSF) => {
        const key =
          itemStockMWSF.itemId +
          '-' +
          itemStockMWSF.lotNumber +
          '-' +
          itemStockMWSF.warehouseShelfFloorId;
        if (keyExist != key) {
          keyNotExists.push(key);
        }
      });
      itemStockMWSFExits.quantity = itemStockMWSFMap.get(keyExist).quantity;
      const itemStockMovementWarehouseShelfFloorEntity =
        this.itemStockMovementWarehouseShelfFloorRepository.updateEntity(
          itemStockMWSFExits,
        );
      itemStockMovementWarehouseShelfFloorEntitys.push(
        itemStockMovementWarehouseShelfFloorEntity,
      );
    });

    keyNotExists.forEach((key) => {
      const itemStockMovementWarehouseShelfFloorEntity =
        this.itemStockMovementWarehouseShelfFloorRepository.createEntity(
          itemStockMWSFMap.get(key),
        );
      itemStockMovementWarehouseShelfFloorEntitys.push(
        itemStockMovementWarehouseShelfFloorEntity,
      );
    });

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(
        itemStockMovementWarehouseShelfFloorEntitys,
      );

      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();

      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.UPDATE_FAILED'))
        .build();
    } finally {
      await queryRunner.release();
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  async getLotsByItem(request: GetLotsByItemRequestDto): Promise<any> {
    const item =
      await this.itemStockMovementWarehouseShelfFloorRepository.getLotsByItem(
        request,
      );

    const response = plainToInstance(ListLotByItemResponseDto, item, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder({
      lots: response,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  async getStorageDatesByItem(
    request: GetListStorageDateByItemIdRequestDto,
  ): Promise<any> {
    const item =
      await this.itemStockMovementWarehouseShelfFloorRepository.getStorageDatesByItem(
        request,
      );

    let response = plainToInstance(
      GetListStorageDateByItemIdResponseDto,
      <any[]>item.filter((e) => e.storageDate !== null),
      {
        excludeExtraneousValues: true,
      },
    );

    if (request.warehouseId) {
      const inventoryTimeLimit =
        await this.warehouseService.getInventoryTimeLimitByWarehouseId(
          request.warehouseId,
        );

      if (inventoryTimeLimit) {
        response = response.filter(
          (e) =>
            moment().diff(moment(e.storageDate), 'day') >
              inventoryTimeLimit?.expiryWarehouse || 0,
        );
      }
    }

    return new ResponseBuilder({
      storageDates: response,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  async getDetailByCode(request: GetDetailItemByCode): Promise<any> {
    const { code } = request;
    const item = await this.itemRepository.findOneWithRelations({
      relations: ['inventoryNorms'],
      where: { code },
    });
    const data = plainToInstance(GetDetailItemByCodeResponse, item, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async getListLotNumberByItemId(
    request: GetLotNumberByItemIdRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { warehouseIds, locatorIds } = request;

    if (!isEmpty(warehouseIds)) {
      const warehouseShelfFloorIds =
        await this.warehouseService.getWarehouseShelfFloorByWarehouseIds(
          warehouseIds,
          true,
        );
      request.warehouseShelfFloorIds = warehouseShelfFloorIds;
    }

    if (!isEmpty(locatorIds)) {
      const locatorIds = await this.warehouseLayoutService.getLocatorsByRootIds(
        warehouseIds,
      );
      request.locatorIds = locatorIds;
    }

    const lotNumberOfItemStock =
      await this.itemStockMovementWarehouseShelfFloorRepository.getListLotNumber(
        request,
      );

    const result = lotNumberOfItemStock.reduce((record, item) => {
      const temp = record.find((x) => x.itemId === item.itemId);
      if (!temp) {
        record.push({
          itemId: item.itemId,
          lotNumbers: [item],
        });
      } else {
        temp.lotNumbers.push(item);
      }
      return record;
    }, []);
    const dataReturn = plainToInstance(LotNumberOfItemResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getAllItemStockByCodes(
    request: GetAllItemStockByCodesRequestDto,
  ): Promise<any> {
    const result = await this.itemRepository.getAllStockByCode(request.codes);
    const dataReturn = plainToInstance(
      GetAllItemstockByCodesResponseDto,
      result,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getItemStockQuantity(
    request: GetItemStockQuantityRequestDto,
  ): Promise<any> {
    const result = await this.itemStockMovementRepository.getItemStockQuantity(
      request,
    );

    const dataReturn = plainToInstance(
      GetItemStockQuantityResponseDto,
      result,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder()
      .withData(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async updateItemWarehouseSource(
    request: UpdateItemWarehouseSourceRequestDto,
  ): Promise<any> {
    const { data, permission } = request;
    const itemIds = [];
    const itemWarehouseSourceConditions = data.map((iws) => {
      itemIds.push(iws.itemId);
      return {
        itemId: iws.itemId,
        warehouseId: iws.warehouseId,
      };
    });
    const itemWarehouseSourcesExisted =
      await this.itemWarehouseSourceRepository.findAllByCondition(
        itemWarehouseSourceConditions,
      );

    const itemWarehouseToDeletes =
      await this.itemWarehouseSourceRepository.findAllByCondition({
        itemId: In(itemIds),
      });

    const newItemWarehouseSources = data.filter(
      (iws) =>
        !itemWarehouseSourcesExisted.some(
          (item) =>
            item.itemId === iws.itemId && item.warehouseId === iws.warehouseId,
        ),
    );

    const itemWarehouseSourceEntities = [];
    if (
      permission === CREATE_ITEM_WAREHOUSE_SOURCE_PERMISSION.code &&
      !isEmpty(newItemWarehouseSources)
    ) {
      newItemWarehouseSources.forEach((iws) => {
        const entity = this.itemWarehouseSourceRepository.createEntity(iws);
        itemWarehouseSourceEntities.push(entity);
      });
    }

    if (!isEmpty(itemWarehouseSourcesExisted)) {
      itemWarehouseSourcesExisted.forEach((iws) => {
        const updatedData = data.find(
          (item) =>
            item.itemId === iws.itemId && item.warehouseId === iws.warehouseId,
        );
        const entity = this.itemWarehouseSourceRepository.updateEntity(
          iws,
          updatedData,
        );
        itemWarehouseSourceEntities.push(entity);
      });
    }

    if (!isEmpty(itemWarehouseSourceEntities)) {
      const queryRunner = await this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        if (!isEmpty(itemWarehouseToDeletes))
          await queryRunner.manager.remove(itemWarehouseToDeletes);
        await queryRunner.manager.save(itemWarehouseSourceEntities);

        await queryRunner.commitTransaction();
      } catch (error) {
        await queryRunner.rollbackTransaction();

        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.NOT_FOUND)
          .withMessage(await this.i18n.translate('error.UPDATE_FAILED'))
          .build();
      } finally {
        await queryRunner.release();
      }
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  async getItemWarehouseLocatorByDay(
    payload: GetItemStockMovementInWarehouseLocatorByDay,
  ): Promise<any> {
    const result =
      await this.itemStockMovementWarehouseShelfFloorRepository.getItemWarehouseLocatorByDay(
        payload,
      );

    const response = plainToInstance(
      GetItemStockWarehouseLocatorByDayResponseDto,
      result,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getInfoItem(request: GetInfoItemRequestDto): Promise<any> {
    const { warehouseId, id } = request;
    const item = await this.itemRepository.getDetail(id);
    if (isEmpty(item)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    item.stockQuantity = 0;
    const stockQuantity = await this.itemWarehouseRepository.getTotalItemStock({
      itemId: item.id,
      warehouseId,
    } as ReportItemStockRequestDto);
    const files = await this.fileRepository.findAllByCondition({
      resourceId: item.id,
      resource: FileResource.ITEM_INFO,
    });
    if (!isEmpty(files)) {
      const fileIds = files.map((e) => e.fileId);
      const fileInfor = await this.fileService.getFilesByIds(fileIds);
      item.files = fileInfor?.data;
    }
    item.stockQuantity = stockQuantity?.quantity || 0;
    const response = plainToInstance(GetInfoItemResponseDto, item, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async uploads(request: UploadImageItemRequestDto): Promise<any> {
    const { files, id } = request;
    const item = await this.itemRepository.getDetail(id);
    if (isEmpty(item)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    const fileDetails = await this.fileRepository.findAllByCondition({
      resourceId: item.id,
      resource: FileResource.ITEM_INFO,
    });
    if (
      plus(fileDetails.length, files.length) > ITEM_RULES.FILE.MAX_IMAGE_UPLOAD
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.ITEM_IMAGE_QUANTITY_EXCEEDS_THE_ALLOWED_AMOUNT',
          ),
        )
        .build();
    }
    try {
      const fileResponse = await this.fileService.uploadFiles(
        files,
        FileResource.ITEM_INFO,
      );

      if (fileResponse.statusCode !== ResponseCodeEnum.SUCCESS) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(fileResponse?.message);
      }

      const fileUploadEntities = fileResponse.data.map((fileId) =>
        this.fileRepository.createEntity({
          resourceId: item.id,
          resource: FileResource.ITEM_INFO,
          fileId,
        }),
      );
      await this.fileRepository.create(fileUploadEntities);
      const response = await this.fileService.getFilesByIds(fileResponse.data);
      return new ResponseBuilder(response.data)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async removeImages(request: RemoveImageItemRequestDto): Promise<any> {
    const { fileIds, id } = request;
    const item = await this.itemRepository.getDetail(id);
    if (isEmpty(item)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const files = await this.fileRepository.findAllByCondition({
      resourceId: item.id,
      resource: FileResource.ITEM_INFO,
      fileId: In(fileIds),
    });
    if (files.length !== uniq(fileIds).length) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    try {
      await this.fileRepository.multipleRemove(map(files, 'id'));
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.log(error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  async getQrCodeItems(request: GetQrCodeItemsRequestDto): Promise<any> {
    const { itemIds, warehouseCodes } = request;
    let type = request.type;
    if (type === undefined) {
      type = QrCodeItemTypeEnum.NEW;
    }
    if (
      type === QrCodeItemTypeEnum.OLD &&
      warehouseCodes?.length !== itemIds?.length
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }
    const items = await this.itemRepository.findAllByCondition({
      id: In(itemIds),
    });
    const settingQr = await this.settingService.getSettingQrCode();
    items.forEach((item, index) => {
      let warehouseCode = null;
      if (!isEmpty(warehouseCodes) && warehouseCodes[index]) {
        warehouseCode = warehouseCodes[index];
      }
      item['qrCode'] = this.qrcodeService.generateQrCode(
        type,
        item.code,
        item.objectCategoryId,
        COMPANY_DEFAULT,
        warehouseCode,
        settingQr,
      );
    });
    const response = plainToInstance(QrCodeItemResponseDto, items, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getItemLotWarehouseStock(
    request: GetItemWarehouseStockRequestDto,
  ): Promise<ResponsePayload<any>> {
    let dataFormatted = [];
    const { data, count } =
      await this.itemRepository.getItemLotWarehouseStockReport(request);

    if (isEmpty(data)) {
      return new ResponseBuilder<PagingResponse>({
        items: [],
        meta: { total: 0, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const locatorIds = uniq(map(flatMap(data, 'locations'), 'locatorId'));
    const warehouseIds = uniq(map(flatMap(data, 'locations'), 'warehouseId'));
    const [locators, warehouses] = await Promise.all([
      this.warehouseLayoutService.getLocatorByIds(locatorIds, true),
      this.warehouseService.getListByIDs(warehouseIds, true),
    ]);

    dataFormatted = data.map((item) => {
      const groupLocation = groupBy(item.locations, 'locatorId');
      const locations = [];
      Object.keys(groupLocation).forEach((locatorId) => {
        const stockBylocation = groupLocation[locatorId];
        const locator = locators[locatorId];
        const warehouse = has(warehouses, locator?.rootId)
          ? warehouses[locator?.rootId]
          : {};
        let quantity = 0;
        let totalAmount = 0;
        stockBylocation?.forEach((lot) => {
          quantity = plus(quantity, lot.quantity);
          totalAmount = plus(totalAmount, lot.totalAmount);
        });
        locations.push({
          locatorId: locatorId,
          itemId: item.id,
          quantity: quantity,
          totalAmount: totalAmount,
          lots: stockBylocation,
          accounting: first(stockBylocation)?.accounting,
          warehouse: {
            id: warehouse?.id,
            code: warehouse?.code,
            name: warehouse?.name,
          },
          locator: locator,
        });
      });
      return {
        ...item,
        locations: locations,
      };
    });

    const reponse = plainToInstance(
      ItemStockLocationResponseDto,
      dataFormatted,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<PagingResponse>({
      items: reponse,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getItemStockWarehouseLocators(
    request: any,
  ): Promise<ResponsePayload<any>> {
    const { locatorIds, warehouseId } = request;
    const result =
      await this.itemStockWarehouseLocatorRepository.findAllByCondition({
        locatorId: In(locatorIds),
        warehouseId: warehouseId,
      });

    const response = plainToInstance(
      ItemStockWarehouseLocatorResponseDto,
      result,
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getListLotStorageDatesByItemIds(
    request: GetLotNumberByItemIdRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { warehouseIds, isFlatLots } = request;
    let locators = [];
    if (!isEmpty(warehouseIds)) {
      locators = await this.warehouseLayoutService.getLocatorsByRootIds(
        warehouseIds,
      );
    }

    const lotNumberOfItemStock =
      await this.itemStockMovementWarehouseShelfFloorRepository.getListLotStorageDatesByItemIds(
        request,
      );

    const flatItemStocks = lotNumberOfItemStock?.map((itemStock) => ({
      ...itemStock,
      locators: locators?.filter(
        (locator) => locator?.rootId === itemStock.warehouseId,
      ),
    }));

    const result = lotNumberOfItemStock.reduce((record, item) => {
      const temp = record.find((x) => x.itemId === item.itemId);
      if (!temp) {
        record.push({
          itemId: item.itemId,
          id: item.itemId,
          name: item.itemName,
          code: item.itemCode,
          itemUnitId: item.itemUnitId,
          itemUnit: item.itemUnit,
          lotNumbers: [item],
        });
      } else {
        temp.lotNumbers.push(item);
      }
      return record;
    }, []);
    const dataReturn =
      isFlatLots === '1'
        ? flatItemStocks
        : plainToInstance(GetListItemLotStorageDatesResponseDto, result, {
            excludeExtraneousValues: true,
          });

    return new ResponseBuilder<PagingResponse>({
      items: dataReturn,
      meta: { total: result.length, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async pickUpItemStockWarehouseLocators(
    request: UpdateItemWarehouseLocatorRequestDto,
  ): Promise<any> {
    const { itemWarehouseLocators } = request;
    const characterSeparator = '_';

    const warehouseIds = uniq(map(itemWarehouseLocators, 'warehouseId'));
    const itemIds = uniq(map(itemWarehouseLocators, 'itemId'));
    const lotNumbers = uniq(map(itemWarehouseLocators, 'lotNumber'));

    let locators = [];
    if (!isEmpty(warehouseIds)) {
      locators = await this.warehouseLayoutService.getLocatorsByRootIds(
        warehouseIds,
        1,
      );
    }

    const rootLocatorIds = map(locators, 'id');
    //Find item existed locator
    const existItemStockLocators =
      await this.itemStockMovementWarehouseShelfFloorRepository.findItemStockLocatorsByConditions(
        itemIds,
        lotNumbers,
        warehouseIds,
      );
    //Filter item has locator same warehouse
    const rootWarehouseItemStockLocators = existItemStockLocators?.filter(
      (itemStock) => rootLocatorIds?.includes(itemStock.locatorId),
    );

    const itemStockWarehouseLocatorHistoryEntities: ItemStockWarehouseLocatorHistoryEntity[] =
      [];
    const newItemStockWarehouseLocatorEntities: ItemStockWarehouseLocatorEntity[] =
      [];
    if (!isEmpty(itemWarehouseLocators)) {
      for (const warehouseLocator of itemWarehouseLocators) {
        const {
          itemId,
          lotNumber,
          warehouseId,
          quantity,
          importDate,
          mfg,
          ticketId,
          locatorId,
        } = warehouseLocator;

        const matchingKey = [
          itemId,
          warehouseId,
          lotNumber || '',
          Moment(mfg).format('DD/MM/YYYY'),
          Moment(importDate).format('DD/MM/YYYY-HH:MM:SS'),
          locatorId,
        ].join(characterSeparator);

        const matchingItem = existItemStockLocators.find((item) => {
          const key = [
            item.itemId,
            item.warehouseId,
            item.lotNumber || '',
            Moment(item.mfg).format('DD/MM/YYYY'),
            Moment(item.storageDate).format('DD/MM/YYYY-HH:MM:SS'),
            item.ticketLocatorId,
          ].join(characterSeparator);
          return key === matchingKey;
        });

        const existRootItemWarehouseLocator =
          rootWarehouseItemStockLocators.find((item) => {
            const key = [
              item.itemId,
              item.warehouseId,
              item.lotNumber || '',
              Moment(item.mfg).format('DD/MM/YYYY'),
              Moment(item.storageDate).format('DD/MM/YYYY'),
              item.ticketLocatorId,
            ].join(characterSeparator);
            return key === matchingKey;
          });
        //Tăng tồn kho tai vị trí = mã kho
        if (existRootItemWarehouseLocator) {
          matchingItem.quantity = plus(
            +existRootItemWarehouseLocator.quantity || 0,
            +quantity || 0,
          );
          matchingItem.keepQuantity = quantity;
          if (existRootItemWarehouseLocator.ticketLocatorId === locatorId) {
            matchingItem.quantity = minus(
              +matchingItem.quantity || 0,
              +quantity || 0,
            );
            matchingItem.keepQuantity = quantity;
          }
        } else {
          const itemStockWarehouseLocatorEntity =
            this.itemStockWarehouseLocatorRepository.createEntity({
              itemId: itemId,
              locatorId: null,
              ticketLocatorId: locatorId || null,
              warehouseId: warehouseId,
              lotNumber: lotNumber || null,
              quantity: quantity,
              keepQuantity: quantity,
              mfg: mfg,
            } as any);

          newItemStockWarehouseLocatorEntities.push(
            itemStockWarehouseLocatorEntity,
          );
        }

        //GIảm  tồn kho tai vị trí lấy
        if (matchingItem) {
          matchingItem.quantity = minus(
            +matchingItem.quantity || 0,
            +quantity || 0,
          );
          const itemStockWarehouseLocatorHistoryEntity =
            this.itemStockWarehouseLocatorHistoryRepository.createEntity({
              itemStockMovementHistoryId: matchingItem.id,
              quantity,
              orderId: null,
              ticketId,
              orderType: OrderTypeEnum.Export,
              itemStockWarehouseLocatorId: matchingItem.id,
              purpose: '',
            });

          itemStockWarehouseLocatorHistoryEntities.push(
            itemStockWarehouseLocatorHistoryEntity,
          );
        }
      }
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const itemStockWarehouseLocators = [
        ...existItemStockLocators,
        ...rootWarehouseItemStockLocators,
        ...newItemStockWarehouseLocatorEntities,
      ];

      await queryRunner.manager.save(
        ItemStockWarehouseLocatorEntity,
        itemStockWarehouseLocators,
      );

      await queryRunner.manager.save(
        ItemStockWarehouseLocatorHistoryEntity,
        itemStockWarehouseLocatorHistoryEntities,
      );

      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder(error)
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    } finally {
      await queryRunner.release();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async confirmExportReceiptItems(
    request: ConfirmExportReceiptItemsRequestDto,
  ): Promise<any> {
    const { ticketId, items } = request;

    if (isEmpty(items)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.EMPTY_ITEMS'),
      ).toResponse();
    }

    const itemIds = uniq(compact(map(items, 'itemId')));
    const warehouseIds = uniq(compact(map(items, 'warehouseId')));

    const existItemWarehouses =
      await this.itemWarehouseRepository.findAllByCondition({
        itemId: In(itemIds),
        warehouseId: In(warehouseIds),
      });

    if (isEmpty(existItemWarehouses) || !existItemWarehouses) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const groupedItemWarehouses = Object.values(
      items.reduce((acc, { itemId, warehouseId, quantity }) => {
        const key = `${itemId}-${warehouseId}`;
        acc[key] = acc[key] || { itemId, warehouseId, quantity: 0 };
        acc[key].quantity += quantity;
        return acc;
      }, {}),
    );

    if (!isEmpty(groupedItemWarehouses)) {
      for (const itemWarehouse of groupedItemWarehouses) {
        const { itemId, warehouseId, quantity } = itemWarehouse as {
          itemId: number;
          warehouseId: number;
          quantity: number;
        };

        const matchingKey = [itemId, warehouseId].join('_');

        const matchingItem = existItemWarehouses.find((item) => {
          const key = [item.itemId, item.warehouseId].join('_');
          return key === matchingKey;
        });

        if (matchingItem) {
          matchingItem.itemQuantity = minus(
            +matchingItem.itemQuantity || 0,
            +quantity || 0,
          );
          matchingItem.exportedQuantity = plus(
            +matchingItem.exportedQuantity || 0,
            +quantity || 0,
          );
        }
      }
    }

    const listItemMovementEntities = items.map((e) => {
      return this.movementRepository.createEntity({
        itemId: e.itemId,
        warehouseId: e.warehouseId,
        ticketId: ticketId,
        locatorId: e.locatorId,
        type: TYPE_ENUM_MOVEMENT.CONFIRM_EXPORT,
        lotNumber: e.lotNumber,
        quantity: e.quantity,
        mfg: e.mfg,
        importDate: e.importDate,
      });
    });

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(MovementEntity, listItemMovementEntities);

      await queryRunner.manager.save(ItemWarehouseEntity, existItemWarehouses);

      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder(error)
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    } finally {
      await queryRunner.release();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public optimizeData(
    request,
    listItemStockWarehouseLocators,
    serilizedWarehouse,
    serializeLocator,
    serilizeTicket,
    listLocatorRoot,
  ) {
    const groupedData = {};
    for (const item of listItemStockWarehouseLocators) {
      const key = [
        item.itemId,
        item.locatorId,
        item.warehouseId,
        item.lotNumber || '',
        Moment(item.mfg).format('DD/MM/YYYY') || '',
      ].join('_');
      const listLocatorWithRootId = compact(
        listLocatorRoot
          .filter((e) => e.rootId !== null)
          .map((locator) => {
            if (item.warehouseId === locator.rootId) {
              return locator;
            }
          }),
      );
      if (!groupedData[key]) {
        groupedData[key] = {
          ...item,
          warehouse: serilizedWarehouse[item.warehouseId] || {},
          locator: serializeLocator[item.ticketLocatorId?.toString()] || {},
          locations: listLocatorWithRootId,
          uniqKey: key,
          histories: [...item.histories],
        };
      } else {
        groupedData[key].histories.push(...item.histories);
      }
    }

    Object.values<any>(groupedData).forEach((groupItem) => {
      let sumQuantity = 0;
      groupItem.histories.forEach((history) => {
        sumQuantity = plus(sumQuantity || 0, history.quantity || 0);
        history.ticket = serilizeTicket[history.ticketId];
      });
      groupItem.sumQuantity = sumQuantity;
    });
    return Object.values(groupedData);
  }
  async getListItemStockWarehouseLocatorsByCondition(
    request: GetListItemStockWarehouseLocatorByCondition,
  ): Promise<any> {
    const { data, count } =
      await this.itemStockWarehouseLocatorRepository.getItemStockWarehouseLocators(
        request,
      );
    if (isEmpty(data)) {
      return new ResponseBuilder<PagingResponse>({
        items: [],
        meta: { total: count, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    const listItemStockWarehouseLocators = data.filter(
      (e) => e.locatorId === e.warehouseId,
    );
    const listItemStockPutAway = data.filter((item) => {
      const hasOrderTypePoi = item.histories.some(
        (history) => history.orderType === 0,
      );
      return item.locatorId !== item.warehouseId && hasOrderTypePoi;
    });
    const warehouseIds = uniq(compact(map(data, 'warehouseId')));
    const ticketLocatorIds = uniq(compact(map(data, 'ticketLocatorId')));
    const ticketIds = data.map((e) => e.histories.map((i) => i.ticketId));
    const [
      serilizedWarehouse,
      serializeLocator,
      serilizeTicket,
      listLocatorRoot,
    ] = await Promise.all([
      this.warehouseService.getListByIDs(warehouseIds, true),
      this.warehouseLayoutService.getListLocatorByIds(ticketLocatorIds, true),
      this.ticketService.getTicketReceiptByIds(flatMap(ticketIds), true),
      this.warehouseLayoutService.getLocatorsByRootIds(warehouseIds, 0),
    ]);
    let dataReturn;
    if (request.isSameWarehouse === '0') {
      dataReturn = this.optimizeData(
        request,
        listItemStockWarehouseLocators,
        serilizedWarehouse,
        serializeLocator,
        serilizeTicket,
        listLocatorRoot,
      );
    } else if (request.isSameWarehouse === '1') {
      dataReturn = this.optimizeData(
        request,
        listItemStockPutAway,
        serilizedWarehouse,
        serializeLocator,
        serilizeTicket,
        listLocatorRoot,
      );
    }
    const result = plainToInstance(
      GetListItemStockWarehouseLocatorResponse,
      dataReturn,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder<PagingResponse>({
      items: result,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getPositionExistItem(
    request: GetPositionExistItemsRequestDto,
  ): Promise<any> {
    const condition: any = {
      itemId: In(request?.itemIds),
      quantity: MoreThan(0),
    };
    if (request?.warehouseId) {
      condition.warehouseId = request?.warehouseId;
    }
    const result =
      await this.itemStockWarehouseLocatorRepository.findAllByCondition(
        condition,
      );
    const response = plainToInstance(
      ItemStockWarehouseLocatorResponseDto,
      result,
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  async getItemStockInWarehouseLocators(
    request: GetItemStockInWarehouseLocatorRequestDto,
  ): Promise<any> {
    const { items: payload } = request;
    const result =
      await this.itemStockWarehouseLocatorRepository.findAllByCondition(
        payload,
      );
    const response = plainToInstance(
      ItemStockWarehouseLocatorResponseDto,
      result,
      { excludeExtraneousValues: true },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateItemStockWarehouseLocators(
    request: UpdateItemStockWarehouseLocatorRequestDto,
  ): Promise<any> {
    const { items } = request;
    const itemStockWarehouseLocatorEntities = [];
    const itemStockWarehouseLocatorHistoryEntities = [];
    items.forEach((item) => {
      const {
        id,
        itemId,
        warehouseId,
        ticketId,
        ticketLocatorId,
        lotNumber,
        mfg,
        quantity,
      } = item;
      const itemStockWarehouseLocatorEntity =
        this.itemStockWarehouseLocatorRepository.createEntity({
          id,
          itemId,
          ticketLocatorId: ticketLocatorId,
          warehouseId,
          lotNumber,
          quantity,
          mfg,
        } as any);
      const itemStockWarehouseLocatorHistoryEntity =
        this.itemStockWarehouseLocatorHistoryRepository.createEntity({
          itemStockMovementHistoryId: id,
          quantity,
          ticketId,
          orderType: OrderTypeEnum.Store,
          itemStockWarehouseLocatorId: id,
          purpose: '',
        });
      itemStockWarehouseLocatorEntities.push(itemStockWarehouseLocatorEntity);
      itemStockWarehouseLocatorHistoryEntities.push(
        itemStockWarehouseLocatorHistoryEntity,
      );
    });

    //start: update data
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      await queryRunner.manager.save(
        ItemStockWarehouseLocatorEntity,
        itemStockWarehouseLocatorEntities,
      );

      await queryRunner.manager.save(
        ItemStockWarehouseLocatorHistoryEntity,
        itemStockWarehouseLocatorHistoryEntities,
      );

      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    } finally {
      await queryRunner.release();
    }
    //end: update data
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
  async getListItemStockWarehouse(
    request: GetListItemStockWarehouseLocatorsRequestDto,
  ): Promise<any> {
    const data =
      await this.itemStockWarehouseLocatorRepository.getListItemWarehouseStock(
        request,
      );
    if (isEmpty(data)) {
      return new ResponseBuilder<PagingResponse>({
        items: [],
        meta: { total: 0 },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    const warehouseIds = uniq(map(data, 'warehouseId'));
    const [locatorRoot] = await Promise.all([
      this.warehouseLayoutService.getLocatorsByRootIds(warehouseIds, 1),
    ]);

    const listItemPutAway = data.filter((e) => {
      const findRoot = locatorRoot.find(
        (locator) => e?.quantity > 0 && locator.id === e.ticketLocatorId,
      );
      return findRoot;
    });
    const ticketPutAwayLocatorIds = uniq(
      map(listItemPutAway, 'ticketLocatorId'),
    );
    const ticketPickAwayLocatorIds = uniq(map(data, 'ticketLocatorId'));
    const ticketLocatorIds = [
      ...ticketPickAwayLocatorIds,
      ...ticketPutAwayLocatorIds,
    ];
    const [serilizedWarehouse, serializeLocator, listLocationRoot] =
      await Promise.all([
        this.warehouseService.getListByIDs(warehouseIds, true),
        this.warehouseLayoutService.getListLocatorByIds(ticketLocatorIds, true),
        this.warehouseLayoutService.getLocatorsByRootIds(warehouseIds, 0),
      ]);
    const groupedData = {};
    if (request.typeTransaction === TypeTransaction.PUT_AWAY) {
      listItemPutAway.forEach((item) => {
        const key = [
          item.itemId,
          item.ticketLocatorId,
          item.warehouseId,
          item.lotNumber ? item.lotNumber?.toUpperCase() : '',
          Moment(item.mfg).format('DD/MM/YYYY') || '',
        ].join('_');
        if (!groupedData[key]) {
          groupedData[key] = {
            uniqKey: key,
            item: {
              id: item.itemId,
              name: item.itemName,
              code: item.itemCode,
            },
            itemUnitName: item.itemUnitName,
            quantity: item.quantity,
            lotNumber: item.lotNumber,
            warehouseId: item.warehouseId,
            ticketLocatorId: item.ticketLocatorId,
            warehouse: serilizedWarehouse[item.warehouseId],
            locator: serializeLocator[item.ticketLocatorId],
            mfg: item.mfg,
            storageDate: item.storageDate,
          };
        } else {
          groupedData[key].quantity = plus(
            groupedData[key].quantity,
            item.quantity,
          );
        }
      });
    } else if (request.typeTransaction === TypeTransaction.PICK_AWAY) {
      data.forEach((item) => {
        const key = [
          item.itemId,
          item.ticketLocatorId,
          item.warehouseId,
          item.lotNumber ? item.lotNumber?.toUpperCase() : '',
          Moment(item.mfg).format('DD/MM/YYYY') || '',
          Moment(item.storageDate).format('DD/MM/YYYY') || '',
        ].join('_');
        if (!groupedData[key]) {
          groupedData[key] = {
            item: {
              id: item.itemId,
              name: item.itemName,
              code: item.itemCode,
            },
            uniqKey: key,
            quantity: item.quantity,
            itemUnitName: item.itemUnitName,
            lotNumber: item.lotNumber,
            ticketLocatorId: item.ticketLocatorId,
            locator: serializeLocator[item.ticketLocatorId],
            warehouseId: item.warehouseId,
            warehouse: serilizedWarehouse[item.warehouseId],
            mfg: item.mfg,
            storageDate: item.storageDate,
          };
        } else {
          groupedData[key].quantity = plus(
            groupedData[key].quantity,
            item.quantity,
          );
        }
      });
    } else {
      data.forEach((item) => {
        const key = [
          item.itemId,
          item.ticketLocatorId,
          item.warehouseId,
          item.lotNumber ? item.lotNumber?.toUpperCase() : '',
          Moment(item.mfg).format('DD/MM/YYYY') || '',
          Moment(item.storageDate).format('DD/MM/YYYY') || '',
        ].join('_');
        if (!groupedData[key]) {
          groupedData[key] = {
            item: {
              id: item.itemId,
              name: item.itemName,
              code: item.itemCode,
            },
            uniqKey: key,
            quantity: item.quantity,
            itemUnitName: item.itemUnitName,
            lotNumber: item.lotNumber,
            ticketLocatorId: item.ticketLocatorId,
            locator: serializeLocator[item.ticketLocatorId],
            warehouseId: item.warehouseId,
            warehouse: serilizedWarehouse[item.warehouseId],
            mfg: item.mfg,
            storageDate: item.storageDate,
          };
        } else {
          groupedData[key].quantity = plus(
            groupedData[key].quantity,
            item.quantity,
          );
        }
      });
    }

    const result = plainToInstance(
      GetListItemStockWarehouseLocatorResponse,
      Object.values(groupedData),
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder({
      items: result,
      meta: { total: result?.length, page: request?.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async checkExistStockInLocator(
    request: CheckExistStockInLocatorRequest,
  ): Promise<any> {
    const { locatorIds } = request;
    const res =
      await this.itemStockWarehouseLocatorRepository.findAllByCondition({
        ticketLocatorId: In(locatorIds),
      });
    return new ResponseBuilder(res)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
