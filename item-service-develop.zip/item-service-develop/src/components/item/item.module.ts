import { SettingService } from './../setting/setting.service';
import { FileRepository } from '@repositories/file/file.repository';
import { FileEntity } from '@entities/file/file.entity';
import { ObjectCategoryEntity } from '@entities/object-category/object-category.entity';
import { ManufacturingCountryEntity } from '@entities/manufacturing-country/manufacturing-country.entity';
import { ManufacturingCountryRepository } from '@repositories/manufacturing-country.repository';
import { ItemQualityRepository } from '@repositories/item-quality.repository';
import { ObjectCategoryRepository } from '@repositories/object-category.repository';
import { WarehouseLayoutService } from './../warehouse-layout/warehouse-layout.service';
import { WarehouseLayoutModule } from './../warehouse-layout/warehouse-layout.module';
import { QrCodeService } from './../qr-code/qr-code.service';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Item } from '@entities/item/item.entity';
import { ItemController } from '@components/item/item.controller';
import { ItemRepository } from '@repositories/item.repository';
import { ItemService } from '@components/item/item.service';
import { ItemStockMovement } from '@entities/item/item-stock-movement.entity';
import { ItemStockMovementRepository } from '@repositories/item-stock-movement.repository';
import { ItemDetail } from '@entities/item/item-detail.entity';
import { ItemDetailSetting } from '@entities/item/item-detail-setting.entity';
import { ItemUnitSetting } from '@entities/item/item-unit-setting.entity';
import { ItemTypeSetting } from '@entities/item/item-type-setting.entity';
import { ItemGroupSetting } from '@entities/item/item-group-setting.entity';
import { ItemDetailSettingRepository } from '@repositories/item-detail-setting.repository';
import { ItemDetailRepository } from '@repositories/item-detail.repository';
import { ItemUnitSettingRepository } from '@repositories/item-unit-setting.repository';
import { ItemGroupSettingRepository } from '@repositories/item-group-setting.repository';
import { ItemTypeSettingRepository } from '@repositories/item-type-setting.repository';
import { ItemWarehouseEntity } from '@entities/item/item-warehouse.entity';
import { ItemWarehouseRepository } from '@repositories/item-warehouse.repository';
import { SaleService } from '@components/sale/sale.service';
import { SaleModule } from '@components/sale/sale.module';
import { QrCodeModule } from '@components/qr-code/qr-code.module';
import { BlockItemDetailRepository } from '@repositories/block-item-detail.repository';
import { PackageItemRepository } from '@repositories/package-item.repository';
import { PackageItem } from '@entities/package/package-item.entity';
import { BlockItemDetail } from '@entities/block/block-item-detail.entity';
import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { WarehouseService } from '@components/warehouse/warehouse.service';
import { ProduceService } from '@components/produce/produce.service';
import { ProduceModule } from '@components/produce/produce.module';
import { ItemDetailSettingImport } from './import/item-detail-setting.import.helper';
import { ItemsImport } from './import/items.import.helper';
import { ItemWarehouseLocationRepository } from '@repositories/item-warehouse-locations.repository';
import { ItemWarehouseLocation } from '@entities/item/item-warehouse-locations.entity';
import { ItemDetailsImport } from './import/item-details.import.helper';
import { ItemStockMovementHistory } from '@entities/item/item-stock-movement-history.entity';
import { ItemStockMovementHistoryRepository } from '@repositories/item-stock-movement-history.repository';
import { ItemStockWarehouseLocatorEntity } from '@entities/item/item-stock-warehouse-locator.entity';
import { ItemStockWarehouseLocatorRepository } from '@repositories/item-stock-warehouse-locator.repository';
import { BullModule } from '@nestjs/bull';
import { QUEUES_NAME_ENUM } from '@constant/common';
import { ItemQualityEntity } from '@entities/item-quality/item-quality.entity';
import { ItemWarehouseSourceEntity } from '@entities/item/item-warehouse-source.entity';
import { ItemWarehouseSourceRepository } from '@repositories/item-warehouse-source.repository';
import { DatasyncService } from '../datasync/datasync.service';
import { DatasyncModule } from '@components/datasync/datasync.module';
import { ItemStockWarehousePriceRepository } from '@repositories/item-stock-warehouse-price.repository';
import { ItemStockWarehousePriceEntity } from '@entities/item/item-stock-warehouse-price.entity';
import { ItemWarehouseModule } from '@components/item-warehouse/item-warehouse.module';
import { ItemConvertUnitRepository } from '@repositories/item-convert-unit.repository';
import { ItemConvertUnitEntity } from '@entities/item/item-convert-unit.entity';
import { ConfigService } from '@config/config.service';
import { ItemStockWarehouseLocatorHistoryRepository } from '@repositories/item-stock-warehouse-locator-history.repository';
import { ItemStockWarehouseLocatorHistoryEntity } from '@entities/item/item-stock-warehouse-locator-history.entity';
import { MovementRepository } from '@repositories/item-movement.repository';
import { MovementEntity } from '@entities/item-movement/movement.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Item,
      ItemStockMovement,
      ItemDetail,
      ItemDetailSetting,
      ItemUnitSetting,
      ItemTypeSetting,
      ItemGroupSetting,
      ItemWarehouseEntity,
      PackageItem,
      BlockItemDetail,
      ItemStockWarehouseLocatorEntity,
      ItemWarehouseLocation,
      ItemStockMovementHistory,
      ItemQualityEntity,
      ManufacturingCountryEntity,
      ObjectCategoryEntity,
      FileEntity,
      ItemWarehouseSourceEntity,
      ItemStockWarehousePriceEntity,
      ItemConvertUnitEntity,
      ItemStockWarehouseLocatorHistoryEntity,
      MovementEntity,
    ]),
    BullModule.registerQueue({
      name: QUEUES_NAME_ENUM.SYNC_DATA_QUEUE,
    }),
    SaleModule,
    ProduceModule,
    QrCodeModule,
    WarehouseModule,
    WarehouseLayoutModule,
    DatasyncModule,
    ItemWarehouseModule,
  ],
  providers: [
    {
      provide: 'PackageItemRepositoryInterface',
      useClass: PackageItemRepository,
    },
    {
      provide: 'BlockItemDetailRepositoryInterface',
      useClass: BlockItemDetailRepository,
    },
    {
      provide: 'ItemRepositoryInterface',
      useClass: ItemRepository,
    },
    {
      provide: 'ItemStockMovementRepositoryInterface',
      useClass: ItemStockMovementRepository,
    },
    {
      provide: 'ItemStockMovementHistoryRepositoryInterface',
      useClass: ItemStockMovementHistoryRepository,
    },
    {
      provide: 'ItemUnitSettingRepositoryInterface',
      useClass: ItemUnitSettingRepository,
    },
    {
      provide: 'ItemWarehouseLocationRepositoryInterface',
      useClass: ItemWarehouseLocationRepository,
    },
    {
      provide: 'ItemGroupSettingRepositoryInterface',
      useClass: ItemGroupSettingRepository,
    },
    {
      provide: 'ItemDetailSettingRepositoryInterface',
      useClass: ItemDetailSettingRepository,
    },
    {
      provide: 'ItemTypeSettingRepositoryInterface',
      useClass: ItemTypeSettingRepository,
    },
    {
      provide: 'ItemDetailRepositoryInterface',
      useClass: ItemDetailRepository,
    },
    {
      provide: 'ItemWarehouseRepositoryInterface',
      useClass: ItemWarehouseRepository,
    },
    {
      provide: 'ItemStockWarehouseLocatorRepositoryInterface',
      useClass: ItemStockWarehouseLocatorRepository,
    },

    {
      provide: 'ObjectCategoryRepositoryInterface',
      useClass: ObjectCategoryRepository,
    },
    {
      provide: 'ItemQualityRepositoryInterface',
      useClass: ItemQualityRepository,
    },
    {
      provide: 'ManufacturingCountryRepositoryInterface',
      useClass: ManufacturingCountryRepository,
    },
    {
      provide: 'QrCodeServiceInterface',
      useClass: QrCodeService,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'ProduceServiceInterface',
      useClass: ProduceService,
    },
    {
      provide: 'SettingServiceInterface',
      useClass: SettingService,
    },
    {
      provide: 'DatasyncServiceInterface',
      useClass: DatasyncService,
    },
    {
      provide: 'WarehouseLayoutServiceInterface',
      useClass: WarehouseLayoutService,
    },
    {
      provide: 'FileRepositoryInterface',
      useClass: FileRepository,
    },
    {
      provide: 'ItemDetailSettingImport',
      useClass: ItemDetailSettingImport,
    },
    {
      provide: 'ItemsImport',
      useClass: ItemsImport,
    },
    {
      provide: 'ConfigServiceInterface',
      useClass: ConfigService,
    },
    {
      provide: 'ItemDetailsImport',
      useClass: ItemDetailsImport,
    },
    {
      provide: 'ItemWarehouseSourceRepositoryInterface',
      useClass: ItemWarehouseSourceRepository,
    },
    {
      provide: 'ItemStockWarehousePriceRepositoryInterface',
      useClass: ItemStockWarehousePriceRepository,
    },
    {
      provide: 'ItemConvertUnitRepositoryInterface',
      useClass: ItemConvertUnitRepository,
    },
    {
      provide: 'ItemStockWarehouseLocatorHistoryRepositoryInterface',
      useClass: ItemStockWarehouseLocatorHistoryRepository,
    },
    {
      provide: 'MovementRepositoryInterface',
      useClass: MovementRepository,
    },
  ],
  controllers: [ItemController],
  exports: [
    {
      provide: 'ItemRepositoryInterface',
      useClass: ItemRepository,
    },
    {
      provide: 'ItemServiceInterface',
      useClass: ItemService,
    },
  ],
})
export class ItemModule {}
