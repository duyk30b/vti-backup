import {
  SetStatusRequestDto,
  StatusRequestDto,
} from '@components/item-setting/dto/request/set-status.request.dto';
import { CheckStockAvaliableRequest } from '@components/item/dto/request/check-stock-available-request.dto';
import { ItemResponseDto } from '@components/item/dto/response/item.response.dto';
import { ItemServiceInterface } from '@components/item/interface/item.service.interface';
import { PrintQrcodeRequestDto } from '@components/qr-code/dto/request/print.request.dto';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Req,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ApiConsumes, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { GetListDataByCodes } from '@utils/common.request.dto';
import { PaginationQuery } from '@utils/pagination.query';
import {
  CREATE_ITEM_PERMISSION,
  CREATE_ITEM_WAREHOUSE_SOURCE_PERMISSION,
  DELETE_ITEM_PERMISSION,
  DETAIL_ITEM_PERMISSION,
  IMPORT_ITEM_PERMISSION,
  LIST_ITEM_PERMISSION,
  QR_CODE_ITEM_PERMISSION,
  UPDATE_ITEM_PERMISSION,
  UPDATE_ITEM_WAREHOUSE_SOURCE_PERMISSION,
} from '@utils/permissions/item';
import {
  CREATE_ITEM_DETAIL_PERMISSION,
  DELETE_ITEM_DETAIL_PERMISSION,
  DETAIL_ITEM_DETAIL_PERMISSION,
  LIST_ITEM_DETAIL_PERMISSION,
  UPDATE_ITEM_DETAIL_PERMISSION,
} from '@utils/permissions/item-detail';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty } from 'lodash';
import { CreateItemDetailSettingDto } from './dto/request/create-item-detail-setting.dto';
import { CreateItemStockMovementDto } from './dto/request/create-item-stock-movement.request.dto';
import {
  CreateItemBodyDto,
  CreateItemDto,
} from './dto/request/create-item.dto';
import {
  DeleteItemBodyRequestDto,
  DeleteItemDto,
} from './dto/request/delete-item.dto';
import { GetPositionItemsByConditionsRequestDto } from './dto/request/filter-position-items-by-conditions.request.dto';
import { GetAllItemStockByCodesRequestDto } from './dto/request/get-all-item-stock-by-codes.request.dto';
import { GetAllItemstockRequestDto } from './dto/request/get-all-item-stock.request.dto';
import { GetCountTransferByDateRequest } from './dto/request/get-count-transfer-by-date.request.dto';
import { GetDetailItemByCode } from './dto/request/get-detail-item-by-code.dto';
import { GetDetailQueryDto } from './dto/request/get-detail.query.dto';
import { GetDetailRequestDto } from './dto/request/get-detail.request.dto';
import { GetFloorExistItemRequestDto } from './dto/request/get-floor-exist-item.request.dto';
import { GetHistoriesItemStockMovements } from './dto/request/get-histories-item-stock-movements.request.dto';
import { GetInfoItemQueryDto } from './dto/request/get-info-item.request.dto';
import { GetItemByItemTypeRequest } from './dto/request/get-item-by-item_type.request.dto';
import { GetItemDetailSettingRequestDto } from './dto/request/get-item-detail-setitng.request.dto';
import { GetPositionItemInWarehouseFloorDto } from './dto/request/get-item-in-warehouse-floor.request.dto';
import { GetItemStockMovementByWarehouseLocatorIds } from './dto/request/get-item-stock-movement-by-warehouse-locator-ids.dto ';
import { getItemStockMovementByWarehouseShelfFloorIds } from './dto/request/get-item-stock-movement-by-warehouse-shelf-floor-ids.dto';
import { GetItemStockMovementWarehouseShelfFloorByIdsDto } from './dto/request/get-item-stock-movement-warehouse-shelf-floor-by-ids-request.dto';
import { GetItemStockMovementWarehouseShelfFloorByItemIdsDto } from './dto/request/get-item-stock-movement-warehouse-shelf-floor-item-ids.request.dto';
import { GetItemStockMovementWarehouseShelfFloorDto } from './dto/request/get-item-stock-movement-warehouse-shelf-floor.request.dto';
import { GetItemStockQuantityRequestDto } from './dto/request/get-item-stock-quantity.request.dto';
import { GetItemStockMovementInWarehouseLocatorByDay } from './dto/request/get-item-stock-warehouse-locator-by-day.request.dto';
import {
  GetItemStockRequestDto,
  GetItemWarehouseStockRequestDto,
} from './dto/request/get-item-stock.dto';
import { GetItemWarehouseWithLocationRequestDto } from './dto/request/get-item-warehouse-with-location.dto';
import { GetItemWarehouseDto } from './dto/request/get-item-warehouse.dto';
import { GetItemDto } from './dto/request/get-item.dto';
import { GetListDetailRequestDto } from './dto/request/get-list-detail.request.dto';
import {
  GetListItemstockMovementByLotNumberRequestDto,
  GetListItemstockMovementByWarehouseStockMovementIdsRequestDto,
  GetListItemstockMovementRequestDto,
} from './dto/request/get-list-item-stock-movements.request.dto';
import { GetListItemRequestDto } from './dto/request/get-list-item.request.dto';
import { GetListReportStockQueryDto } from './dto/request/get-list-report-stock.query.dto';
import { GetLotsByItemQueryDto } from './dto/request/get-lots-by-item.request.dto';
import { GetPositionExistItemsRequestDto } from './dto/request/get-position-exits-items.request.dto';
import { GetQrCodeItemsRequestDto } from './dto/request/get-qr-code-items.request.dto';
import { GetQuantityItemWarehouseRequestDto } from './dto/request/get-quantity-item-warehouse-request.dto';
import { GetReportDailyDto } from './dto/request/get-report-daily.dto';
import { GetStorageDateByItemIdsRequestDto } from './dto/request/get-storage-date-item-ids.request.dto';
import { GetListStorageDateByItemIdQueryDto } from './dto/request/get-storage-dates-by-item-id.request.dto';
import { ItemStockByItemGroupQueryDto } from './dto/request/item-stock-by-item-group.query.dto';
import { ItemStockRequest } from './dto/request/item-stock.request.dto';
import {
  GetLotNumberByItemIdQueryDto,
  GetLotNumberByItemIdRequestDto,
} from './dto/request/list-lot-number.request.dto';
import { RemoveImageItemBodyDto } from './dto/request/remove-image-item.request.dto';
import { UpdateIsHasBomItemDto } from './dto/request/update-is-has-bom-item.dto';
import { UpdateItemDetailBodyRequestDto } from './dto/request/update-item-detail-setting.dto';
import { UpdateItemStockMovementWarehouseShelfFloorRequestDto } from './dto/request/update-item-stock-movement-warehouse-shelf-floor.request.dto';
import { UpdateItemWarehouseSourceRequestDto } from './dto/request/update-item-warehouse-source.request.dto';
import {
  UpdateItemBodyRequestDto,
  UpdateItemDto,
} from './dto/request/update-item.dto';
import { UploadImageItemBodyDto } from './dto/request/upload-image-item.request.dto';
import { GetListItemResponseDto } from './dto/response/get-list-item.response.dto';
import { ItemDetailSettingResponseDto } from './dto/response/item-detail-setting.response.dto';
import { ItemStockResponse } from './dto/response/item-stock.response.dto';
import { GetListLotNumberResponseDto } from './dto/response/list-lot-number.response.dto';
import { barcodeScanValidator } from './middlewares/validators/qr-code.validator';
import { GetItemStockWarehouseLocatorRequestDto } from './dto/request/get-items-stock-warehouse-locator.request.dto';

@Controller('/')
export class ItemController {
  constructor(
    @Inject('ItemServiceInterface')
    private readonly itemService: ItemServiceInterface,
  ) {}

  @MessagePattern('ping')
  public async get(): Promise<any> {
    return new ResponseBuilder('ITEM: PONG')
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  @PermissionCode(CREATE_ITEM_PERMISSION.code)
  // @MessagePattern('create_item')
  @Post('/create')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Create new item',
    description: 'Tạo 1 item mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: null,
  })
  @ApiConsumes('multipart/form-data')
  public async createItem(@Body() body: CreateItemBodyDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    request.createdByUserId = request.userId;
    return await this.itemService.createItem(request);
  }

  @PermissionCode(UPDATE_ITEM_PERMISSION.code)
  // @MessagePattern('update_item')
  @Put('/:id')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Update item',
    description: 'Cập nhật thông tin item',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: null,
  })
  public async updateItem(
    @Param('id', new ParseIntPipe()) id,
    @Body() body: UpdateItemBodyRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.updateItem({
      id,
      ...request,
    });
  }

  @PermissionCode(DELETE_ITEM_PERMISSION.code)
  // @MessagePattern('delete_item')
  @Delete('/:id')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Delete item (soft delete)',
    description: 'Xóa item',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deleteItem(
    @Param('id', new ParseIntPipe()) id,
    @Req() body: DeleteItemBodyRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.deleteItem({
      id,
      ...request,
    });
  }

  @PermissionCode(DELETE_ITEM_PERMISSION.code)
  @MessagePattern('delete_item_multiple')
  @Delete('/multiple')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Delete multiple item',
    description: 'Xóa nhiều item',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deleteMultipleItem(
    @Query() body: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.deleteMultipleItem(request);
  }

  // @PermissionCode(LIST_ITEM_PERMISSION.code)
  // @MessagePattern('get_item_list')
  @Get('list')
  @ApiOperation({
    tags: ['Item', 'Items'],
    summary: 'List Item',
    description: 'Danh sách item',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: GetListItemResponseDto,
  })
  public async getList(@Query() body: GetListItemRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getList(request);
  }

  @PermissionCode(DETAIL_ITEM_PERMISSION.code)
  // @MessagePattern('get_item_detail')
  @Get('/:id')
  @ApiOperation({
    tags: ['Item', 'Items'],
    summary: 'Item Detail',
    description: 'Chi tiết item',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ItemResponseDto,
  })
  public async getDetail(
    @Param('id', new ParseIntPipe()) id,
    @Req() body: GetDetailRequestDto,
    @Query() query: GetDetailQueryDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getDetail(
      {
        id,
        ...request,
      },
      query.request.isGetAllWarehouse,
    );
  }

  @PermissionCode(LIST_ITEM_DETAIL_PERMISSION.code)
  @MessagePattern('get_item_detail_list')
  @Get('item-details/list')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Get list item detail',
    description: 'Danh sách chi tiết',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ItemDetailSettingResponseDto,
  })
  public async getDetailList(
    @Query() body: GetListDetailRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getDetailList(request);
  }

  @MessagePattern('confirm_item')
  @Put(':id/confirm')
  @ApiOperation({
    tags: ['Item Confirm'],
    summary: 'Confirmed data ',
    description: 'Confirm data',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ItemDetailSettingResponseDto,
  })
  public async confirmItem(
    @Param('id', new ParseIntPipe()) id,
    @Req() payload: StatusRequestDto,
  ): Promise<ResponsePayload<ItemResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.confirmItem({
      id,
      ...request,
    });
  }

  @MessagePattern('reject_item')
  @Put(':id/reject')
  @ApiOperation({
    tags: ['Item Reject'],
    summary: 'Reject data ',
    description: 'Reject data',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ItemDetailSettingResponseDto,
  })
  public async rejectItem(
    @Param('id', new ParseIntPipe()) id,
    @Req() payload: StatusRequestDto,
  ): Promise<ResponsePayload<ItemResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.rejectItem({
      id,
      ...request,
    });
  }

  // End Item

  // @MessagePattern('get_item_warehouses')
  public async getItemWarehouse(
    @Body() body: GetItemWarehouseDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getItemWarehouse(request);
  }

  @MessagePattern('get_item_warehouse_with_locations')
  public async getItemWarehouseWithLocation(
    @Body() body: GetItemWarehouseWithLocationRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getItemWarehouseWithLocation(request);
  }

  @MessagePattern('get_item_stock')
  @Get('/item-stock')
  @ApiOperation({
    tags: ['Items'],
    summary: 'Item Stock',
    description: 'Số lượng tồn kho của item',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: ItemStockResponse,
  })
  public async getItemStock(
    @Query() body: GetItemStockRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getItemStock(request);
  }

  @Get('/warehouse-stock')
  @ApiOperation({
    tags: ['Items'],
    summary: 'Item Stock',
    description: 'Số lượng tồn kho của item kèm theo chi tiết location',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: null,
  })
  public async getItemWarehouseStock(
    @Query() body: GetItemWarehouseStockRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getItemWarehouseStock(request);
  }

  @MessagePattern('get_item_warehouse_stock')
  public async getItemWarehouseStockTcp(
    @Body() body: GetItemWarehouseStockRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getItemWarehouseStock(request);
  }

  @MessagePattern('get_item_lot_warehouse_stock_report')
  public async getItemLotWarehouseStockTcp(
    @Body() body: GetItemWarehouseStockRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getItemLotWarehouseStock(request);
  }

  @MessagePattern('create_items_stock_movement')
  public async createItemStockMovement(
    @Body() payload: CreateItemStockMovementDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.createItemsStockMovement(request);
  }

  // @MessagePattern('get_item_stock_movement_by_warehouse_stock_movement_id')?
  public async getItemStockMovements(
    @Body() payload: GetListItemstockMovementRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getItemsStockMovements(request);
  }

  // @MessagePattern('get_item_stock_movement_by_warehouse_stock_movement_ids')
  public async getItemStockMovementsByWarehouseStockMovementIds(
    @Body()
    payload: GetListItemstockMovementByWarehouseStockMovementIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getItemStockMovementsByWarehouseStockMovementIds(
      request,
    );
  }

  // @MessagePattern('get_all_item_stock')
  @Get('/:id/stock')
  @ApiResponse({
    status: 200,
    type: ItemResponseDto,
  })
  public async getAllItemStock(
    @Param('id', new ParseIntPipe()) id,
    @Req() payload: GetAllItemstockRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getAllItemStock({
      id,
      ...request,
    });
  }
  // @MessagePattern('get_item_stock_movement_by_lot_number')
  public async getItemStockMovementByLotNumbers(
    @Body() payload: GetListItemstockMovementByLotNumberRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getItemStockMovementByLotNumbers(request);
  }

  @PermissionCode(IMPORT_ITEM_PERMISSION.code)
  @MessagePattern('import_items')
  public async importItems(@Body() body: FileUpdloadRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.importItems(request);
  }

  @MessagePattern('import_item_detail_setting')
  public async importItemDetailSetting(
    @Body() body: FileUpdloadRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.importItemDetailSetting(request);
  }

  @PermissionCode(CREATE_ITEM_DETAIL_PERMISSION.code)
  @MessagePattern('create_item_detail_setting')
  @Post('item-details/create')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Create new item detail',
    description: 'Tạo 1 chi tiết mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ItemDetailSettingResponseDto,
  })
  public async createItemDetailSetting(
    @Body() payload: CreateItemDetailSettingDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.createItemsDetailSetting(request);
  }

  @PermissionCode(UPDATE_ITEM_DETAIL_PERMISSION.code)
  @MessagePattern('update_item_detail_setting')
  @Put('item-details/:id')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Update item detail',
    description: 'Cập nhật thông tin chi tiết',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: ItemDetailSettingResponseDto,
  })
  public async updateItemDetailSetting(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateItemDetailBodyRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.updateItemsDetailSetting({
      id,
      ...request,
    });
  }

  @PermissionCode(DETAIL_ITEM_DETAIL_PERMISSION.code)
  @MessagePattern('get_item_detail_setting')
  @Get('item-details/:id')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Get item detail',
    description: 'Lấy thông tin chi tiết',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: ItemDetailSettingResponseDto,
  })
  public async getItemDetailSetting(
    @Param('id', new ParseIntPipe()) id,
    @Req() payload: GetItemDetailSettingRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getItemsDetailSetting({
      id,
      ...request,
    });
  }

  @PermissionCode(DELETE_ITEM_DETAIL_PERMISSION.code)
  @MessagePattern('delete_item_detail_setting')
  @Delete('item-details/:id')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Delete item detail (soft delete)',
    description: 'Xóa chi tiết',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deleteItemDetailSetting(
    @Param('id', new ParseIntPipe()) id,
    @Req() body: DeleteItemBodyRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.deleteItemDetailSetting({
      id,
      ...request,
    });
  }

  @PermissionCode(DELETE_ITEM_DETAIL_PERMISSION.code)
  @MessagePattern('delete_item_detail_setting_multiple')
  @Delete('item-details/multiple')
  @ApiOperation({
    tags: ['Item'],
    summary: 'Delete multiple item detail (soft delete)',
    description: 'Xóa nhiều chi tiết',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async deleteMultipleItemDetailSetting(
    @Query() body: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.deleteMultipleItemDetailSetting(request);
  }

  @MessagePattern('confirm_item_detail_setting')
  @Put('item-details/:id/confirm')
  @ApiOperation({
    tags: ['ItemDetails'],
    summary: 'Confirmed data details',
    description: 'Confirm data',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ItemDetailSettingResponseDto,
  })
  public async confirmItemDetailSetting(
    @Param('id', new ParseIntPipe()) id,
    @Req() payload: SetStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.confirmItemDetailSetting({
      id,
      ...request,
    });
  }

  @MessagePattern('reject_item_detail_setting')
  @Put('item-details/:id/reject')
  @ApiOperation({
    tags: ['ItemDetails'],
    summary: 'Reject data details setting',
    description: 'Reject data',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: ItemDetailSettingResponseDto,
  })
  public async rejectItemDetailSetting(
    @Param('id', new ParseIntPipe()) id,
    @Req() payload: SetStatusRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.rejectItemDetailSetting({
      id,
      ...request,
    });
  }

  // @MessagePattern('check_stock_available')
  public async checkStockAvailable(
    @Body() body: CheckStockAvaliableRequest,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.checkStockAvaiable(request);
  }

  // @MessagePattern('get_items_by_ids')
  public async getItems(@Body() payload: GetItemDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getItemsById(
      request.itemIds,
      request.factoryId,
      request.filter,
      request.basicInfor || false,
      request.forceFilterByFactoryId,
    );
  }

  @MessagePattern('get_items_by_conditions')
  public async getItemByConditions(@Body() payload: any): Promise<any> {
    const { condition, sort } = payload;
    return await this.itemService.getItemsByConditions(condition, sort);
  }

  @MessagePattern('get_items_by_relations')
  public async getItemByRelations(@Body() payload: any): Promise<any> {
    return await this.itemService.getItemsByRelations(payload.relation);
  }

  // @MessagePattern('run_seeders')
  @Get('/seeders/nagf8gCudw=2313ndnkfjy24091u30932gsjknkjn2i3y1293820k,cn,')
  public async runSeeders(): Promise<any> {
    return await this.itemService.runSeeders();
  }

  @MessagePattern('get_env')
  public async getEnv(): Promise<any> {
    return await this.itemService.getEnv();
  }

  // @MessagePattern('get_report_daily')
  public async getReportDaily(
    @Body() payload: GetReportDailyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getDailyReport(request);
  }

  // @MessagePattern('get_quantity_item_warehouse')
  public async getQuantityItemWarehouse(
    @Body() payload: GetQuantityItemWarehouseRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getQuantityItemWarehouse(request);
  }
  // @MessagePattern('print_qr_code')
  @Post('qr-code/print')
  @ApiOperation({
    tags: ['Item', 'QR Code', 'Mobile'],
    summary: 'Print Item, Block, Package qr code',
    description: 'In Qr code',
  })
  @ApiResponse({
    status: 200,
    description: 'Print successfully',
    type: null,
  })
  public async printQrCode(
    @Body() payload: PrintQrcodeRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.printQrCode(request);
  }

  // @MessagePattern('scan_qr_code')
  @Get('qr-code/scan')
  @ApiOperation({
    tags: ['Item', 'QR Code', 'Scan', 'Mobile'],
    summary: 'Scan Item, Block, Package qr code',
    description: 'Scan Qr code',
  })
  @ApiResponse({
    status: 200,
    description: 'Scan successfully',
    type: null,
  })
  public async scanQrCode(@Query() payload: any): Promise<any> {
    const [request, responseError] = await barcodeScanValidator(payload);
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.scanQrCode(request);
  }

  // @MessagePattern('get_count_item_by_item_type')
  @Get('/reports/count-by-type')
  public async getCountItemByItemType(): Promise<any> {
    return await this.itemService.getCountItemByItemType();
  }
  //TODO remove when refactor done
  @MessagePattern('get_count_item_by_item_type')
  public async getCountItemByItemTypeTcp(): Promise<any> {
    return await this.itemService.getCountItemByItemType();
  }

  // @MessagePattern('get_transfer_count_by_date')
  public async getCountTransferByDate(
    @Body() payload: GetCountTransferByDateRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getCountTransferByDate(request);
  }

  @MessagePattern('get_item_by_item_type')
  @Get('/:id/item-types')
  public async getItemByItemType(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: GetItemByItemTypeRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getItemByItemType({
      itemTypeId: id,
      ...request,
    });
  }

  //TODO remove when refactor done
  @MessagePattern('get_item_by_item_type')
  public async getItemByItemTypeTcp(
    @Body() payload: GetItemByItemTypeRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getItemByItemType(request);
  }

  @MessagePattern('count_total_item')
  @Get('reports/item-types/summary')
  @ApiOperation({
    tags: ['Item', 'Count total item'],
    summary: 'Item, Count Item',
    description: 'Count Item',
  })
  @ApiResponse({
    status: 200,
    description: 'Count successfully',
    type: null,
  })
  public async countTotalItem(): Promise<any> {
    return this.itemService.countTotalItem();
  }

  @MessagePattern('count_total_other_item')
  @Get('reports/item-types/others/summary')
  @ApiOperation({
    tags: ['Item', 'Count total item without TP, NVL'],
    summary: 'Item, Count Item without TP, NVL',
    description: 'Count total item without TP, NVL',
  })
  @ApiResponse({
    status: 200,
    description: 'Count successfully',
    type: null,
  })
  public async countTotalItemOther(): Promise<any> {
    return this.itemService.countTotalOtherItem();
  }

  // @MessagePattern('get_item_stock_for_report')
  public async getItemStockForReport(
    @Body() payload: GetListReportStockQueryDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getItemStockForReport(request);
  }

  @MessagePattern('item_stock_by_item_group_summary')
  @Get('reports/item-group/stocks')
  @ApiOperation({
    tags: ['Item', 'item statistics', 'item-stock', 'item-group'],
    summary: 'Item, item statistics',
    description: 'Trả về stock theo item_type và group by theo item-group',
  })
  @ApiResponse({
    status: 200,
    description: 'Statistics successfully',
    type: null,
  })
  public async itemStockByItemGroupSummary(
    @Query() payload: ItemStockByItemGroupQueryDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.itemService.itemStockByItemGroupSummary(request);
  }

  @MessagePattern('items_report')
  @Get('warehouses/stocks/list')
  @ApiOperation({
    tags: ['Item', 'item warehouse stock', 'item stock'],
    summary: 'Item, item warehouse stock',
    description: 'Trả về item và số lượng tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: null,
  })
  public async itemsReport(@Query() payload: ItemStockRequest): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return this.itemService.getItemWarehouseStocks(request);
  }

  @MessagePattern('update_is_has_bom_items')
  public async updateColumnIsHasBomOfItem(
    @Body() body: UpdateIsHasBomItemDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.updateColumnIsHasBomOfItem(request);
  }

  //TODO remove when refactor done
  @MessagePattern('update_is_has_bom_items')
  public async updateColumnIsHasBomOfItemTcp(
    @Body() body: UpdateIsHasBomItemDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.updateColumnIsHasBomOfItem(request);
  }

  @MessagePattern('get_item_warehouses_by_itemIds_warehouseIds')
  public async getItemWarehouseListByItemIdsAndWarehouseIds(
    condition: any,
  ): Promise<any> {
    return await this.itemService.getItemWarehouseListByItemIdsAndWarehouseIds(
      condition,
    );
  }

  @MessagePattern('get_items_by_item_unit_name')
  @Get('/item-unit/:itemUnitName')
  public async getItemsByItemUnitName(
    @Param('itemUnitName') itemUnitName: string,
  ): Promise<any> {
    return await this.itemService.getItemsByItemUnitName(itemUnitName);
  }

  //TODO remove when refactor done
  @MessagePattern('get_items_by_item_unit_name')
  public async getItemsByItemUnitNameTcp(request: any): Promise<any> {
    return await this.itemService.getItemsByItemUnitName(request.itemUnitName);
  }

  // @MessagePattern('get_item_stock_movement_warehouse_shelf_floor')
  public async getItemStockMovementWarehouseShelfFloor(
    @Body() body: GetItemStockMovementWarehouseShelfFloorDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getItemStockMovementWarehouseShelfFloor(
      request,
    );
  }

  // @MessagePattern('get_item_stock_movement_warehouse_shelf_floor_by_item_ids')
  public async getItemStockMovementWarehouseShelfFloorByItemIds(
    @Body() body: GetItemStockMovementWarehouseShelfFloorByItemIdsDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getItemStockMovementWarehouseShelfFloorByItemIds(
      request,
    );
  }

  // @MessagePattern('get_item_stock_movement_warehouse_shelf_floor_by_ids')
  public async getItemStockMovementWarehouseShelfFloorByIds(
    @Body() body: GetItemStockMovementWarehouseShelfFloorByIdsDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getItemStockMovementWarehouseShelfFloorByIds(
      request,
    );
  }

  // @MessagePattern('get_position_item_in_warehouse_floor')
  public async getPositionItemInWarehouseFloor(
    @Body() body: GetPositionItemInWarehouseFloorDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getPositionItemInWarehouseFloor(request);
  }

  // @MessagePattern('get_inventory_warning')
  @Get('inventory-warnings')
  public async getInventoriesWarning(
    @Query() query: PaginationQuery,
  ): Promise<any> {
    const { request, responseError } = query;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getListWarning(request);
  }

  @MessagePattern('get_item_by_codes')
  @Get('/code')
  public async getItemByCodes(
    @Query() payload: GetListDataByCodes,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getItemByCodes(request.codes);
  }

  //TODO remove when refactor done
  @MessagePattern('get_item_by_codes')
  public async getItemByCodesTcp(
    @Body() payload: GetListDataByCodes,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getItemByCodes(request.codes);
  }

  // @MessagePattern('get_histories_item_stock_movements')
  public async getHistoriesItemStockMovements(
    @Body() payload: GetHistoriesItemStockMovements,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getHistoriesItemStockMovements(request);
  }

  @MessagePattern('update_item_stock_movement_warehouse_shelf_floor')
  public async updateItemStockMovementWarehouseShelfFloor(
    @Body() payload: UpdateItemStockMovementWarehouseShelfFloorRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.updateItemStockMovementWarehouseShelfFloor(
      request,
    );
  }

  //TODO remoev when refactor done
  @MessagePattern('update_item_stock_movement_warehouse_shelf_floor')
  public async updateItemStockMovementWarehouseShelfFloorTcp(
    @Body() payload: UpdateItemStockMovementWarehouseShelfFloorRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.updateItemStockMovementWarehouseShelfFloor(
      request,
    );
  }

  @Get('/:id/lots')
  @ApiOperation({
    tags: ['Item', 'Lot Number'],
    summary: 'Item, lot number',
    description: 'Trả về số lô của item',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: null,
  })
  public async getLotsByItem(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: GetLotsByItemQueryDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getLotsByItem({
      itemId: Number(id),
      ...request,
    });
  }

  @Get('/:id/storage-dates')
  @ApiOperation({
    tags: ['Item', 'Storage Date'],
    summary: 'Item, storage date',
    description: 'Trả về ngày nhập kho của item',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
    type: null,
  })
  public async getStorageDatesByItem(
    @Param('id', new ParseIntPipe()) id,
    @Query() payload: GetListStorageDateByItemIdQueryDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getStorageDatesByItem({
      itemId: Number(id),
      ...request,
    });
  }

  @MessagePattern('get_storage_date_by_item_ids')
  public async getStorageDatesByItemIds(
    @Body() payload: GetStorageDateByItemIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getStorageDatesByItemIds(request);
  }

  // @MessagePattern('get_position_items')
  public async getPositionExistItem(
    @Body() payload: GetPositionExistItemsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getPositionExistItem(request);
  }

  @MessagePattern('get_item_detail_by_code')
  public async getItemDetailByCode(payload: GetDetailItemByCode): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getDetailByCode(request);
  }

  // @MessagePattern('get_list_lot_number_of_item_stock')
  @Get('/item-stocks/lots')
  @ApiOperation({
    tags: ['Items'],
    summary: 'List Lot Number',
    description: 'Danh sách số lô theo sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListLotNumberResponseDto,
  })
  public async getListLotNumberByItemId(
    @Query() payload: GetLotNumberByItemIdQueryDto,
  ): Promise<any> {
    const { request, responseError } = payload;

    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getListLotNumberByItemId({
      ...request,
      itemIds: request.itemIds ? request.itemIds.split(',') : [],
      warehouseIds: request.warehouseIds ? request.warehouseIds.split(',') : [],
    });
  }

  // @MessagePattern('get_position_items_by_conditions')
  public async getPositionItemsByConditions(
    @Body() payload: GetPositionItemsByConditionsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getPositionItemsByConditions(request);
  }

  @MessagePattern(
    'get_item_stock_movement_warehouse_shelf_floor_by_warehouse_shelf_floor_ids',
  )
  public async getItemStockMovementInWarehouseFloorByWarehouseFloorIds(
    @Body() payload: getItemStockMovementByWarehouseShelfFloorIds,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getItemStockMovementInWarehouseFloorByWarehouseFloorIds(
      request.warehouseShelfFloorIds,
    );
  }
  // @MessagePattern('get_all_item_stock_by_codes')
  @Get('/item-stock/codes')
  public async getAllItemStockByCodes(
    @Query() payload: GetAllItemStockByCodesRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getAllItemStockByCodes(request);
  }

  //TODO:  remove when refactor done
  @MessagePattern('get_all_item_stock_by_codes')
  public async getAllItemStockByCodesTcp(
    @Body() payload: GetAllItemStockByCodesRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getAllItemStockByCodes(request);
  }

  // @MessagePattern('get_floor_exist_item')
  public async getFloorExistItem(
    @Body() payload: GetFloorExistItemRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getFloorExistItem(request);
  }
  // TODO: Remove dupplicated TCP after refactor done
  @MessagePattern('get_items_by_ids')
  public async getItemsTcp(@Body() payload: GetItemDto): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getItemsById(
      request.itemIds,
      request.factoryId,
      request.filter,
      request.basicInfor || false,
      request.forceFilterByFactoryId,
    );
  }

  @MessagePattern('get_item_warehouses')
  public async getItemWarehouseTcp(
    @Body() body: GetItemWarehouseDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getItemWarehouse(request);
  }

  @MessagePattern('get_item_warehouse_with_locations')
  public async getItemWarehouseWithLocationTcp(
    @Body() body: GetItemWarehouseWithLocationRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getItemWarehouseWithLocation(request);
  }

  @MessagePattern(
    'get_item_stock_movement_warehouse_shelf_floor_by_warehouse_shelf_floor_ids',
  )
  public async getItemStockMovementInWarehouseFloorByWarehouseFloorIdsTcp(
    @Body() payload: getItemStockMovementByWarehouseShelfFloorIds,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getItemStockMovementInWarehouseFloorByWarehouseFloorIds(
      request.warehouseShelfFloorIds,
    );
  }

  @MessagePattern(
    'get_item_stock_movement_warehouse_locator_by_warehouse_locator_ids',
  )
  public async getItemStockMovementInWarehouseLocatorByWarehouseLocatorIdsTcp(
    @Body() payload: GetItemStockMovementByWarehouseLocatorIds,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getItemStockMovementInWarehouseLocatorByLocatorIds(
      request.locatorIds,
    );
  }

  //TODO REMOVE WHEN REFACTOR DONE
  @MessagePattern('get_list_lot_number_of_item_stock')
  public async getListLotNumberByItemIdTcp(
    @Body() payload: GetLotNumberByItemIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getListLotNumberByItemId(request);
  }

  @MessagePattern('get_item_stock_for_report')
  public async getItemStockForReportTcp(
    @Body() payload: GetListReportStockQueryDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getItemStockForReport(request);
  }

  @MessagePattern('get_inventory_warning')
  public async getInventoriesWarningTcp(
    @Body() param: PaginationQuery,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getListWarning(request);
  }

  @MessagePattern('get_transfer_count_by_date')
  public async getCountTransferByDateTcp(
    @Body() payload: GetCountTransferByDateRequest,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getCountTransferByDate(request);
  }

  @MessagePattern('get_report_daily')
  public async getReportDailyTcp(
    @Body() payload: GetReportDailyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getDailyReport(request);
  }

  @MessagePattern('get_quantity_item_warehouse')
  public async getQuantityItemWarehouseTcp(
    @Body() payload: GetQuantityItemWarehouseRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getQuantityItemWarehouse(request);
  }

  @MessagePattern('get_item_stock_movement_by_warehouse_stock_movement_id')
  public async getItemStockMovementsTcp(
    @Body() payload: GetListItemstockMovementRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getItemsStockMovements(request);
  }

  @MessagePattern('get_item_stock_movement_by_warehouse_stock_movement_ids')
  public async getItemStockMovementsByWarehouseStockMovementIdsTcp(
    @Body()
    payload: GetListItemstockMovementByWarehouseStockMovementIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getItemStockMovementsByWarehouseStockMovementIds(
      request,
    );
  }

  @MessagePattern('check_stock_available')
  public async checkStockAvailableTcp(
    @Body() body: CheckStockAvaliableRequest,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.checkStockAvaiable(request);
  }

  @MessagePattern('get_item_stock_movement_warehouse_shelf_floor')
  public async getItemStockMovementWarehouseShelfFloorTcp(
    @Body() body: GetItemStockMovementWarehouseShelfFloorDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getItemStockMovementWarehouseShelfFloor(
      request,
    );
  }

  @MessagePattern('get_item_stock_movement_warehouse_shelf_floor_by_item_ids')
  public async getItemStockMovementWarehouseShelfFloorByItemIdsTcp(
    @Body() body: GetItemStockMovementWarehouseShelfFloorByItemIdsDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getItemStockMovementWarehouseShelfFloorByItemIds(
      request,
    );
  }

  @MessagePattern('get_position_item_in_warehouse_floor')
  public async getPositionItemInWarehouseFloorTcp(
    @Body() body: GetPositionItemInWarehouseFloorDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getPositionItemInWarehouseFloor(request);
  }

  @MessagePattern('get_item_stock_movement_warehouse_shelf_floor_by_ids')
  public async getItemStockMovementWarehouseShelfFloorByIdsTcp(
    @Body() body: GetItemStockMovementWarehouseShelfFloorByIdsDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getItemStockMovementWarehouseShelfFloorByIds(
      request,
    );
  }

  @MessagePattern('get_histories_item_stock_movements')
  public async getHistoriesItemStockMovementsTcp(
    @Body() payload: GetHistoriesItemStockMovements,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getHistoriesItemStockMovements(request);
  }

  @MessagePattern('get_position_items')
  public async getPositionExistItemTcp(
    @Body() payload: GetPositionExistItemsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getPositionExistItem(request);
  }

  @MessagePattern('get_position_items_by_conditions')
  public async getPositionItemsByConditionsTcp(
    @Body() payload: GetPositionItemsByConditionsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getPositionItemsByConditions(request);
  }
  @MessagePattern('get_floor_exist_item')
  public async getFloorExistItemTcp(
    @Body() payload: GetFloorExistItemRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getFloorExistItem(request);
  }
  @PermissionCode(LIST_ITEM_PERMISSION.code)
  @MessagePattern('get_item_list')
  public async getListTcp(@Body() body: GetListItemRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getList(request);
  }
  @MessagePattern('get_item_stock_movement_by_lot_number')
  public async getItemStockMovementByLotNumbersTcp(
    @Body() payload: GetListItemstockMovementByLotNumberRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getItemStockMovementByLotNumbers(request);
  }

  @MessagePattern('get_all_item_stock')
  public async getAllItemStockTcp(
    @Body() payload: GetAllItemstockRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getAllItemStock(request);
  }
  @PermissionCode(CREATE_ITEM_PERMISSION.code)
  @MessagePattern('create_item')
  public async createItemTcp(@Body() body: CreateItemDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.createItem(request);
  }

  @PermissionCode(UPDATE_ITEM_PERMISSION.code)
  @MessagePattern('update_item')
  public async updateItemTcp(@Body() body: UpdateItemDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.updateItem(request);
  }

  @PermissionCode(DELETE_ITEM_PERMISSION.code)
  @MessagePattern('delete_item')
  public async deleteItemTcp(@Body() body: DeleteItemDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.deleteItem(request);
  }

  @MessagePattern('get_item_detail')
  public async getDetailTcp(@Body() body: GetDetailRequestDto): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemService.getDetail({
      ...request,
    });
  }

  @MessagePattern('scan_qr_code')
  public async scanQrCodeTcp(@Body() payload: any): Promise<any> {
    const [request, responseError] = await barcodeScanValidator(payload);
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.scanQrCode(request);
  }

  @MessagePattern('print_qr_code')
  public async printQrCodeTcp(
    @Body() payload: PrintQrcodeRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.printQrCode(request);
  }

  @MessagePattern('get_item_stock_quantity')
  public async getItemStockQuantity(
    @Body() payload: GetItemStockQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getItemStockQuantity(request);
  }

  @PermissionCode(CREATE_ITEM_WAREHOUSE_SOURCE_PERMISSION.code)
  @Post('item-warehouse-sources/create-warehouse')
  @ApiOperation({
    tags: ['ItemDetails'],
    summary: 'Create item warehouse source',
    description: 'Create item warehouse source',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
  })
  public async createItemWarehouseSource(
    @Body() payload: UpdateItemWarehouseSourceRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.permission = CREATE_ITEM_WAREHOUSE_SOURCE_PERMISSION.code;
    return await this.itemService.updateItemWarehouseSource(request);
  }

  @PermissionCode(UPDATE_ITEM_WAREHOUSE_SOURCE_PERMISSION.code)
  @Put('item-warehouse-sources/update-source')
  @ApiOperation({
    tags: ['ItemDetails'],
    summary: 'Update item warehouse source',
    description: 'Update item warehouse source',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  public async updateItemWarehouseSource(
    @Body() payload: UpdateItemWarehouseSourceRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.permission = UPDATE_ITEM_WAREHOUSE_SOURCE_PERMISSION.code;
    return await this.itemService.updateItemWarehouseSource(request);
  }

  @MessagePattern('get_item_stock_warehouse_locator_by_day')
  public async getItemStockWarehouseLocatorByDay(
    @Body() payload: GetItemStockMovementInWarehouseLocatorByDay,
  ) {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getItemWarehouseLocatorByDay(request);
  }

  @Get(':id/info')
  @ApiOperation({
    tags: ['Item', 'Info'],
    summary: 'Get item info',
    description: 'Get item info',
  })
  @ApiResponse({
    status: 200,
    description: 'Success',
  })
  public async getInfoItem(
    @Param('id', new ParseIntPipe()) id,
    @Query() query: GetInfoItemQueryDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.itemService.getInfoItem(request);
  }

  @Post(':id/uploads')
  @ApiOperation({
    tags: ['Item', 'Info'],
    summary: 'Upload image item',
    description: 'Upload image item',
  })
  @ApiResponse({
    status: 200,
    description: 'Upload successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async uploads(
    @Param('id', new ParseIntPipe()) id,
    @Body() body: UploadImageItemBodyDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.itemService.uploads(request);
  }

  @Delete(':id/images')
  @ApiOperation({
    tags: ['Item', 'Info'],
    summary: 'Upload image item',
    description: 'Upload image item',
  })
  @ApiResponse({
    status: 200,
    description: 'Upload successfully',
  })
  @ApiConsumes('multipart/form-data')
  public async removeImages(
    @Param('id', new ParseIntPipe()) id,
    @Body() body: RemoveImageItemBodyDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.itemService.removeImages(request);
  }

  @PermissionCode(QR_CODE_ITEM_PERMISSION.code)
  @Get('/qr-code')
  @ApiOperation({
    tags: ['Item', 'Info'],
    summary: 'Upload image item',
    description: 'Upload image item',
  })
  @ApiResponse({
    status: 200,
    description: 'Upload successfully',
  })
  public async GetQrCodeItems(
    @Query() query: GetQrCodeItemsRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemService.getQrCodeItems(request);
  }

  @MessagePattern(
    'get_item_stock_warehouse_locator_by_locator_ids',
  )
  public async getItemStockWarehouseLocators(
    @Body() payload: GetItemStockWarehouseLocatorRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    
    return await this.itemService.getItemStockWarehouseLocators(
      request,
    );
  }
}
