import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class GetItemByFilterItemUnitNameResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  itemUnitId: number;

  @ApiProperty()
  @Expose()
  itemUnitCode: number;

  @ApiProperty()
  @Expose()
  itemUnitName: string;
}
