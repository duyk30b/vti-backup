import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class ItemStockMovementHistoryResponseDto {
  @ApiProperty({ example: 1 })
  @Expose()
  id: number;

  @ApiProperty({ example: 1 })
  @Expose()
  itemId: number;

  @ApiProperty({ example: 1 })
  @Expose()
  warehouseShelfFloorId: number;

  @ApiProperty({ example: 1 })
  @Expose()
  warehouseShelfId: number;

  @ApiProperty({ example: 1 })
  @Expose()
  warehouseSectorId: number;

  @ApiProperty({ example: 1 })
  @Expose()
  quantity: number;

  @ApiProperty({ example: 'Lô 1' })
  @Expose()
  lotNumber: string;
}
