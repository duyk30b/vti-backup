import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class ItemStockWarehouseLocatorResponseDto {
  @ApiProperty({ example: 1 })
  @Expose()
  id: number;

  @ApiProperty({ example: 1 })
  @Expose()
  itemId: number;

  @ApiProperty({ example: 1 })
  @Expose()
  quantity: number;

  @ApiProperty({ example: 1 })
  @Expose()
  warehouseId: number;

  @ApiProperty({ example: 1 })
  @Expose()
  locatorId: number;

  @ApiProperty()
  @Expose()
  ticketLocatorId: string;

  @ApiProperty({ example: 1 })
  @Expose()
  lotNumber: string;

  @ApiProperty({ example: '2022-01-04T03:11:06.151Z' })
  @Expose()
  mfg: string;

  @ApiProperty({ example: '2022-01-04T03:11:06.151Z' })
  @Expose()
  storageDate: string;

  @Expose()
  createdAt: Date;

  @Expose()
  updatedAt: Date;
}
