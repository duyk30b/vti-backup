import { Expose } from "class-transformer";

export class GetItemStockWarehouseLocatorByDayResponseDto {
  @Expose()
  itemId: number;
  
  @Expose()
  itemCode: string;

  @Expose()
  itemName: string;

  @Expose()
  warehouseId: number;

  @Expose()
  locatorId: number;

  @Expose()
  lotNumber: string;

  @Expose()
  stockQuantity: number;
}