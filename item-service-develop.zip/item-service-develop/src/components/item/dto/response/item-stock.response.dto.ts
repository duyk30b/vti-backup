import { Expose, Transform, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class WarehouseResponse {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;
}
class Lot {
  @Expose()
  lotNumber: string;

  @Expose()
  @Transform((data) => data.value || 0)
  quantity: number;

  @Expose()
  @Transform((data) => {
    return data.value ? new Date(data.value).toISOString() : null;
  })
  date: string;
}

export class ItemStockResponse {
  @Expose()
  id: number;

  @Expose()
  @Transform((data) => data.value || 0)
  quantity: number;

  @Expose()
  name: string;

  @Expose()
  code: string;

  @Expose()
  @Type(() => WarehouseResponse)
  warehouse: WarehouseResponse;

  @Expose()
  @IsArray()
  @Type(() => Lot)
  lots: Lot[];
}
