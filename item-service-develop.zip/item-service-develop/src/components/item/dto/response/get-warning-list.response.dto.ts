import { BaseDto } from '@core/dto/base.dto';
import { Expose, Type } from 'class-transformer';

export class GetWaringListResponseDto extends BaseDto {
  @Expose()
  id: number;

  @Expose()
  itemId: number;

  @Expose()
  itemCode: string;

  @Expose()
  itemName: string;

  @Expose()
  itemUnitName: string;

  @Expose()
  warehouseId: number;

  @Expose()
  locatorId: number;

  @Expose()
  lotNumber: string;

  @Expose()
  quantity: number;

  @Expose()
  storageDate: Date;

  @Expose()
  expireDate: Date;
}
