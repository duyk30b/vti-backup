import { ItemUnit } from './item-unit.response.dto';
import { ItemGroup } from './item-type.response.dto';
import { ItemType } from './item-group.response.dto';
import { IsArray } from 'class-validator';
import { PagingResponse } from './../../../../utils/paging.response';
import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { MeaseuresUnitAbstractResponse } from './measures-unit-abstract.response.dto';
import { WeightUnitAbstractResponse } from './weight-unit-abstract.response.dto';

class Item {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty({ type: ItemType })
  @Expose()
  @Type(() => ItemType)
  itemType: ItemType;

  @ApiProperty({ type: ItemGroup })
  @Expose()
  @Type(() => ItemGroup)
  itemGroup: ItemGroup;

  @ApiProperty({ type: ItemUnit })
  @Expose()
  @Type(() => ItemUnit)
  itemUnit: ItemUnit;

  @ApiProperty()
  @Expose()
  isHasDetail: boolean;

  @ApiProperty()
  @Expose()
  isHasBom: boolean;

  @ApiProperty()
  @Expose()
  updatedAt: string;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty()
  @Expose()
  @Type(() => MeaseuresUnitAbstractResponse)
  width: MeaseuresUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => MeaseuresUnitAbstractResponse)
  height: MeaseuresUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => MeaseuresUnitAbstractResponse)
  long: MeaseuresUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => WeightUnitAbstractResponse)
  weight: WeightUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  dayExpire: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  status: number;
}

export class DataList extends PagingResponse {
  @ApiProperty({ type: Item, isArray: true })
  @Type(() => Item)
  @Expose()
  @IsArray()
  items: Item[];
}

export class GetListItemResponseDto {
  @ApiProperty({ example: 200, description: '' })
  @Expose()
  statusCode: number;

  @ApiProperty({ example: 'Success', description: '' })
  @Expose()
  message: string;

  @ApiProperty({
    type: DataList,
  })
  @Expose()
  @Type(() => DataList)
  data: DataList;
}
