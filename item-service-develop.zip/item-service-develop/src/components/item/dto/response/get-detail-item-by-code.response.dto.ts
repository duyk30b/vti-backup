import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { ItemType } from './item-group.response.dto';
import { ItemGroup } from './item-type.response.dto';
import { ItemUnit } from './item-unit.response.dto';
import { MeaseuresUnitAbstractResponse } from './measures-unit-abstract.response.dto';
import { WeightUnitAbstractResponse } from './weight-unit-abstract.response.dto';

class InventoryNorm {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  itemId: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  inventoryLimit: string;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  minInventoryLimit: string;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  maxInventoryLimit: string;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  expiryWarehouse: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  expiryWarningWarehouse: number;
}

export class GetDetailItemByCodeResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty({ type: ItemType })
  @Expose()
  @Type(() => ItemType)
  itemType: ItemType;

  @ApiProperty({ type: ItemGroup })
  @Expose()
  @Type(() => ItemGroup)
  itemGroup: ItemGroup;

  @ApiProperty({ type: ItemUnit })
  @Expose()
  @Type(() => ItemUnit)
  itemUnit: ItemUnit;

  @ApiProperty()
  @Expose()
  isHasDetail: boolean;

  @ApiProperty()
  @Expose()
  isHasBom: boolean;

  @ApiProperty()
  @Expose()
  updatedAt: string;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty()
  @Expose()
  @Type(() => MeaseuresUnitAbstractResponse)
  width: MeaseuresUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => MeaseuresUnitAbstractResponse)
  height: MeaseuresUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => MeaseuresUnitAbstractResponse)
  long: MeaseuresUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => WeightUnitAbstractResponse)
  weight: WeightUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  dayExpire: number;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  status: number;

  @ApiProperty({ example: 1, description: '', type: InventoryNorm })
  @Expose()
  @Type(() => InventoryNorm)
  inventoryNorms: InventoryNorm[];
}
