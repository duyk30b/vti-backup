import { SuccessResponse } from '@components/item-setting/dto/response/success.response.dto';
import { Expose } from 'class-transformer';

export class ListLotByItemResponseDto extends SuccessResponse {
  @Expose()
  warehouseId: number;

  @Expose()
  itemId: number;

  @Expose()
  mfg: string;

  @Expose()
  lotNumber: string;

  @Expose()
  quantity: number;
}
