import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
export class GetAllItemstockByCodesResponseDto extends BaseDto {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'code', description: '' })
  @Expose()
  code: string;

  @ApiProperty({ example: 'code', description: '' })
  @Expose()
  totalQuantity: string;
}
