import { Expose } from 'class-transformer';

export class ItemWarehouseResponse {
  @Expose()
  itemId: number;

  @Expose()
  itemQuantity: number;

  @Expose()
  warehouseId: number;
}
