import { Expose } from 'class-transformer';

export class GetListStorageDateByItemIdResponseDto {
  @Expose()
  itemId: number;

  @Expose()
  locatorId: number;

  @Expose()
  storageDate: string;
}
