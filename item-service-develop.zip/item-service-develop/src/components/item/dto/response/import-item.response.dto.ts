import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

export class ImportItemResponseDto {
  @ApiProperty({ type: ImportResponseDto })
  @Expose()
  @Type(() => ImportResponseDto)
  item: ImportResponseDto;

  @ApiProperty({ type: ImportResponseDto })
  @Expose()
  @Type(() => ImportResponseDto)
  itemDetail: ImportResponseDto;
}
