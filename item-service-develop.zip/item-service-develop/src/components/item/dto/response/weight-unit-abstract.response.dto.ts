import { ApiProperty } from '@nestjs/swagger';
import { decimal } from '@utils/common';
import { Expose } from 'class-transformer';
import { Max, Min } from 'class-validator';

export class WeightUnitAbstractResponse {
  @ApiProperty()
  @Expose()
  @Min(0)
  @Max(decimal(10, 2))
  value: number;

  @ApiProperty()
  @Expose()
  unit: number;
}
