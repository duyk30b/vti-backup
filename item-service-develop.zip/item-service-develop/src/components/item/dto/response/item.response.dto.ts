import { ItemUnit } from './item-unit.response.dto';
import { ItemGroup } from './item-type.response.dto';
import { ItemType } from './item-group.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';
import { IsArray } from 'class-validator';
import { ItemDetail } from './item-detail.response.dto';
import { MeaseuresUnitAbstractResponse } from './measures-unit-abstract.response.dto';
import { WeightUnitAbstractResponse } from './weight-unit-abstract.response.dto';
import { has } from 'lodash';
import { BasicResponseDto } from '@components/user/dto/response/basic-response.dto';

class UserResponse {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  username: string;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  fullName: string;
}

class ResponseAbstract {
  @ApiProperty({ example: 1, description: '' })
  @Expose()
  id: number;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  name: string;

  @ApiProperty({ example: 'admin', description: '' })
  @Expose()
  code: string;
}

class BomResponseDto extends BasicResponseDto {}

class ItemWarehouseLocation {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  warehouseSectorId: number;

  @ApiProperty()
  @Expose()
  warehouseShelfId: number;
}

class Package {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: number;
}

class Warehouse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: number;

  @ApiProperty()
  @Expose()
  manageByLot: number;
}

class Source {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: number;
}

class ItemStockWarehouseLocator {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  locatorId: number;

  @ApiProperty()
  @Expose()
  warehouseId: number;
}

class ItemWarehouseSource {
  @ApiProperty({ type: Warehouse })
  @Expose()
  @Type(() => Warehouse)
  warehouse: Warehouse;

  @Expose()
  warehouseId: number;

  @ApiProperty({})
  @Expose()
  accounting: string;
}

class ItemConvertUnit {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  name: number;

  @ApiProperty()
  @Expose()
  itemUnitId: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty({ type: ItemType })
  @Expose()
  @Type(() => ItemType)
  itemUnit: ItemUnit;
}

export class ItemResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  code: number;

  //@ApiProperty()
  //@Expose()
  //qrCode: string;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  normalizeCode: string;

  @ApiProperty()
  @Expose()
  quantity: number;

  //@ApiProperty()
  //@Expose()
  //manufacturingCountryId: number;

  //@ApiProperty()
  //@Expose()
  //itemQualityId: number;

  //@ApiProperty()
  //@Expose()
  //objectCategoryId: number;

  @ApiProperty()
  @Expose()
  price: number;

  @ApiProperty({ type: ItemType })
  @Expose()
  @Type(() => ItemType)
  itemType: ItemType;

  @ApiProperty()
  @Expose()
  @Type(() => ResponseAbstract)
  manufacturingCountry: ResponseAbstract;

  @ApiProperty()
  @Expose()
  @Type(() => ResponseAbstract)
  objectCategory: ResponseAbstract;

  @ApiProperty()
  @Expose()
  @Type(() => ResponseAbstract)
  itemQuality: ResponseAbstract;

  @ApiProperty({ type: ItemDetail, isArray: true })
  @Expose()
  @Type(() => ItemDetail)
  @IsArray()
  itemDetails: ItemDetail[];

  @ApiProperty()
  @Expose()
  @Type(() => ItemGroup)
  itemGroup: ItemGroup;

  @ApiProperty({ type: ItemUnit })
  @Expose()
  @Type(() => ItemUnit)
  itemUnit: ItemUnit;

  @ApiProperty({ type: BomResponseDto })
  @Expose()
  @Type(() => BomResponseDto)
  bom: BomResponseDto;

  @Expose()
  bomId: number;

  @Expose()
  isConfirmedBom: number;

  @ApiProperty()
  @Expose()
  isHasDetail: boolean;

  @ApiProperty()
  @Expose()
  isProductionObject: boolean;

  @ApiProperty()
  @Expose()
  isHasBom: boolean;

  @ApiProperty()
  @Expose()
  updatedAt: string;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty({ type: UserResponse })
  @Expose()
  @Type(() => UserResponse)
  createdByUser: UserResponse;

  @ApiProperty({ example: 1, description: '' })
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  @Type(() => UserResponse)
  apporve: UserResponse;

  @ApiProperty()
  @Expose()
  @Type(() => MeaseuresUnitAbstractResponse)
  width: MeaseuresUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => MeaseuresUnitAbstractResponse)
  height: MeaseuresUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => MeaseuresUnitAbstractResponse)
  long: MeaseuresUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => WeightUnitAbstractResponse)
  weight: WeightUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  hasItemDetail: boolean;

  @ApiProperty()
  @Expose()
  @Transform(
    (data) => has(data, 'obj.width.value') && data?.obj.width?.value !== 0,
  )
  hasStorageSpace: boolean;

  @ApiProperty()
  @Expose()
  dayExpire: number;

  @ApiProperty()
  @Expose()
  isConvertUnit: boolean;

  @ApiProperty({ type: ItemWarehouseLocation })
  @Expose()
  @Type(() => ItemWarehouseLocation)
  itemWarehouseLocation: ItemWarehouseLocation;

  @ApiProperty({ type: Package })
  @Expose()
  @Type(() => Package)
  packages: Package;

  @ApiProperty({ type: ItemStockWarehouseLocator })
  @Expose()
  @Type(() => ItemStockWarehouseLocator)
  itemStockWarehouseLocators: ItemStockWarehouseLocator[];

  @ApiProperty({ type: ItemWarehouseSource })
  @Expose()
  @Type(() => ItemWarehouseSource)
  itemWarehouseSources: ItemWarehouseSource[];

  @ApiProperty({ type: ItemConvertUnit })
  @Expose()
  @Type(() => ItemConvertUnit)
  itemConvertUnits: ItemConvertUnit[];
}
