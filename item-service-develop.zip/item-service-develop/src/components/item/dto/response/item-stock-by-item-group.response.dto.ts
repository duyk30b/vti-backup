import { Expose, Transform } from 'class-transformer';

export class ItemStockByItemGroupResponse {
  @Expose()
  name: string;

  @Expose()
  @Transform((value) => Number(value.value))
  value: number;
}
