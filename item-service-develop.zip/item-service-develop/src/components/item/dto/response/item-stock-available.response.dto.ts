import { Expose } from 'class-transformer';

export class ItemStockAvailableResponse {
  @Expose()
  itemId: number;

  @Expose()
  quantity: number;

  @Expose()
  warehouseId: number;
}
