import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class ItemDetail {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose({ name: 'itemDetailSettingId' })
  itemDetailId: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose({ name: 'itemDetailQuantity' })
  quantity: number;
}
