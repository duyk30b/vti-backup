import { Expose, Type } from 'class-transformer';
import { ItemStockByItemGroupResponse } from './item-stock-by-item-group.response.dto';

export class TotalItemStockByItemGroupResponse {
  @Expose()
  total: number;

  @Expose()
  @Type(() => ItemStockByItemGroupResponse)
  groups: ItemStockByItemGroupResponse[];
}
