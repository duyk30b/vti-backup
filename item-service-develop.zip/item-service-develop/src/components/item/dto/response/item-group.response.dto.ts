import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class ItemType {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  mainGroupName: string;

  @ApiProperty()
  @Expose()
  mainGroupCode: string;

  @ApiProperty()
  @Expose()
  subGroupName: string;

  @ApiProperty()
  @Expose()
  subGroupCode: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  hasItemDetail: boolean;
}
