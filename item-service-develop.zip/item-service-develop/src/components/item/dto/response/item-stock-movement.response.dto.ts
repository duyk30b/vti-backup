import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { ItemStockMovementHistoryResponseDto } from './item-stock-movement-history.response.dto';

export class ItemStockMovementResponseDto {
  @ApiProperty({ example: 1 })
  @Expose()
  id: number;

  @ApiProperty({ example: 1 })
  @Expose()
  warehouseStockMovementId: number;

  @ApiProperty({ example: 1 })
  @Expose()
  itemId: number;

  @ApiProperty({ example: 1 })
  @Expose()
  quantity: number;

  @ApiProperty({ type: ItemStockMovementHistoryResponseDto, isArray: true })
  @Expose()
  @Type(() => ItemStockMovementHistoryResponseDto)
  itemStockMovementHistories: ItemStockMovementHistoryResponseDto[];
}
