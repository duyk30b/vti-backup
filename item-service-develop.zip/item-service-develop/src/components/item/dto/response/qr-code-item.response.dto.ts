import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class QrCodeItemResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: number;

  @ApiProperty()
  @Expose()
  code: number;

  @ApiProperty()
  @Expose()
  qrCode: string;
}
