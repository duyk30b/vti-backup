import { Expose, Type } from 'class-transformer';
class ItemUnit {
  @Expose()
  id: number;

  @Expose()
  name: number;

  @Expose()
  code: number;
}
export class GetInfoItemResponseDto {
  @Expose()
  id: number;

  @Expose()
  name: number;

  @Expose()
  code: number;

  @Expose()
  stockQuantity: number;

  @Expose()
  @Type(() => ItemUnit)
  itemUnit: ItemUnit;

  @Expose()
  files: any[];
}
