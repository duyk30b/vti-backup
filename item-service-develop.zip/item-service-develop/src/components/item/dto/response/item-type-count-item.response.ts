import { Expose } from 'class-transformer';

export class ItemTypeCountItemResponse {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  description: string;

  @Expose()
  code: string;

  @Expose()
  itemCount: number;
}
