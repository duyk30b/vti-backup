import { Expose } from 'class-transformer';

export class WarehouseStockDailyRespone {
  @Expose()
  itemId: number;

  @Expose()
  itemName: string;

  @Expose()
  itemCode: string;

  @Expose()
  quantity: number;

  @Expose()
  quantityIn: number;

  @Expose()
  quantityOut: number;

  @Expose()
  itemTypeId: number;

  @Expose()
  itemTypeName: string;

  @Expose()
  itemGroupId: number;

  @Expose()
  itemGroupName: string;

  @Expose()
  itemUnitId: number;

  @Expose()
  itemUnitName: string;
}
