import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';
import { IsArray } from 'class-validator';

class WarehouseSector {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;
}

class WarehouseShelf {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;
}
class WarehouseShelfFloor {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;
}
class Warehouse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ItemUnit {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class Locator {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  locatorId: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ItemStockLocation {
  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => Locator)
  locator: Locator;

  @ApiProperty()
  @Expose()
  @Type(() => Warehouse)
  warehouse: Warehouse;

  @ApiProperty()
  @Expose()
  accounting: string;

  @ApiProperty()
  @Expose()
  @Type(() => WarehouseSector)
  warehouseSector: WarehouseSector;

  @ApiProperty()
  @Expose()
  @Type(() => WarehouseShelf)
  warehouseShelf: WarehouseShelf;

  @ApiProperty()
  @Expose()
  @Type(() => WarehouseShelfFloor)
  warehouseShelfFloor: WarehouseShelfFloor;

  @ApiProperty()
  @Expose()
  @IsArray()
  @Type(() => ItemWarehouseLocationLot)
  lots: ItemWarehouseLocationLot[];
}
class ItemWarehouseSource {
  @ApiProperty({ type: Warehouse })
  @Expose()
  @Type(() => Warehouse)
  warehouse: Warehouse;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty({})
  @Expose()
  accounting: string;
}

export class ItemStockLocationResponseDto {
  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  @Type(() => ItemUnit)
  itemUnit: ItemUnit;

  @ApiProperty({ type: ItemWarehouseSource })
  @Expose()
  @Type(() => ItemWarehouseSource)
  itemWarehouseSources: ItemWarehouseSource[];

  @ApiProperty()
  @Expose()
  @IsArray()
  @Type(() => ItemStockLocation)
  locations: ItemStockLocation[];
}

class ItemWarehouseLocationLot {
  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  @Expose()
  @Transform((value) => {
    return value.value ? new Date(value.value).toISOString() : null;
  })
  mfg: string;

  @ApiProperty()
  @Expose()
  storageDate: Date;

  @ApiProperty()
  @Expose()
  amount: number;

  @ApiProperty()
  @Expose()
  totalAmount: number;

  @ApiProperty()
  @Expose()
  origin: string;
}
export class ItemStockLocationGroupByLotNumberResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  @Type(() => ItemWarehouseLocationLot)
  lots: ItemWarehouseLocationLot[];
}
