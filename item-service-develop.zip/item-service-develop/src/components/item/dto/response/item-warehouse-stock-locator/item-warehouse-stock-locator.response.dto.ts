import { LocatorResponseDto } from '@components/warehouse-layout/dto/response/locator.response.dto';
import { Expose, Type } from 'class-transformer';
class BaseResponse {
  @Expose()
  _id: string;

  @Expose()
  code: string;

  @Expose()
  name: string;
}

class WarehouseResponse extends BaseResponse {
  @Expose()
  id: number;
  @Expose()
  manageByLot: number;
}

class ItemResponse extends BaseResponse {
  @Expose()
  id: number;
}
class LocatorResponse extends BaseResponse {
  @Expose()
  id: string;

  @Expose()
  locatorId: number;

  @Expose()
  rootId: number;

  @Expose()
  warehouseId: number;

  @Expose()
  lotNumber: string;

  @Expose()
  mfg: Date;

  @Expose()
  storageDate: Date;

  @Expose()
  quantity: number;

  @Expose()
  @Type(() => LocatorResponse)
  locator: LocatorResponse;
}

export class ItemStockWarehouseLocatorHistoryResponseDto {
  @Expose()
  id: number;

  @Expose()
  itemMovementId: number;

  @Expose()
  orderType: number;

  @Expose()
  ticketId: number;

  @Expose()
  @Type(() => WarehouseResponse)
  ticket: WarehouseResponse;

  @Expose()
  quantity: number;
}
export class GetListItemStockWarehouseLocatorResponse {
  @Expose()
  uniqKey: string;

  @Expose()
  itemId: number;

  @Expose()
  @Type(() => ItemResponse)
  item: ItemResponse;

  @Expose()
  itemName: string;

  @Expose()
  itemCode: string;

  @Expose()
  itemTypeName: string;

  @Expose()
  itemUnitName: string;

  @Expose()
  lotNumber: string;

  @Expose()
  mfg: Date;

  @Expose()
  storageDate: Date;

  @Expose()
  quantity: number;

  @Expose()
  sumQuantity: number;

  @Expose()
  stockAvailable: number;

  @Expose()
  warehouseId: number;

  @Expose()
  @Type(() => WarehouseResponse)
  warehouse: WarehouseResponse;

  @Expose()
  locatorId: string;

  @Expose()
  @Type(() => LocatorResponse)
  locator: LocatorResponse;

  @Expose()
  @Type(() => LocatorResponse)
  locations: LocatorResponse[];

  @Expose()
  @Type(() => ItemStockWarehouseLocatorHistoryResponseDto)
  histories: ItemStockWarehouseLocatorHistoryResponseDto[];
}
