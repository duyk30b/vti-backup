export class CreateItemStockWarehouseLocatorHistoryTicketRequestDto {
  itemStockWarehouseLocatorId?: number;
  itemMovementId: number;
  quantity: number;
  ticketId: string;
  orderType: number;

  constructor(
    itemMovementId: number,
    quantity: number,
    ticketId: string,
    orderType: number,
    itemStockWarehouseLocatorId?: number,
  ) {
    this.itemStockWarehouseLocatorId = itemStockWarehouseLocatorId;
    this.itemMovementId = itemMovementId;
    this.quantity = quantity;
    this.ticketId = ticketId;
    this.orderType = orderType;
  }
}
