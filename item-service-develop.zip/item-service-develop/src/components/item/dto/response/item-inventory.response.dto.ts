import { Expose } from 'class-transformer';

export class ItemInventoryResponse {
  @Expose()
  itemId: number;

  @Expose()
  quantity: number;

  @Expose()
  warehouseId: number;

  @Expose()
  warehouseSectorId: number;

  @Expose()
  warehouseShelfId: number;

  @Expose()
  warehouseShelfFloorId: number;

  @Expose()
  lotNumber: string;

  @Expose()
  lots: any[];
}
