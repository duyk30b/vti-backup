import { BaseDto } from '@core/dto/base.dto';
import { Expose, Transform } from 'class-transformer';
import { IsNotEmpty, IsArray } from 'class-validator';

export class GetAllItemStockByCodesRequestDto extends BaseDto {
  @Expose()
  @IsNotEmpty()
  @Transform(({ value }) => {
    if (typeof value === 'string') {
      if (value) value = value.replace(/\\/g, '');
      return value.split(',');
    }
    return value;
  })
  @IsArray()
  codes: string[];
}
