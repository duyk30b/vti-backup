import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsInt, IsNotEmpty, ValidateNested } from 'class-validator';

class ItemStockMovementWarehouseShelfFloor {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  lotNumber: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  warehouseShelfFloorId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  warehouseSectorId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  warehouseShelfId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  actualQuantity: number;
}

export class UpdateItemStockMovementWarehouseShelfFloorRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  @ValidateNested()
  itemStockMovementWarehouseShelfFloors: ItemStockMovementWarehouseShelfFloor[];
}
