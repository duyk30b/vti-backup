import { ITEM_RULES } from '@components/item/item.constant';
import { BaseDto } from '@core/dto/base.dto';
import { FileAbtractDto } from '@core/dto/file-upload.request';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, ValidateNested, IsEnum } from 'class-validator';

class File extends FileAbtractDto {
  @IsEnum(ITEM_RULES.FILE.IMAGE_MIME_TYPES)
  mimetype: string;
}

export class UploadImageItemBodyDto extends BaseDto {
  @ApiProperty()
  @ValidateNested({ each: true })
  files: File[];
}

export class UploadImageItemRequestDto extends UploadImageItemBodyDto {
  @ApiProperty()
  @IsInt()
  id: number;
}
