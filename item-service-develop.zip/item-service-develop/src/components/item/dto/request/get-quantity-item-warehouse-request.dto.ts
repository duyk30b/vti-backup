import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsOptional } from 'class-validator';

export class GetQuantityItemWarehouseRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @IsInt()
  itemTypeId: number;
}
