import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { ItemGroupSettingRequestDto } from '@components/item/dto/request/item-group-setting-request.dto';

export class UpdateItemGroupSettingBodyDto extends ItemGroupSettingRequestDto {}

export class UpdateItemGroupSettingRequestDto extends UpdateItemGroupSettingBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;
}
