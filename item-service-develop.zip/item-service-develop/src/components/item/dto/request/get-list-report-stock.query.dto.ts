import { PaginationQuery } from '@utils/pagination.query';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsOptional,
  IsString,
  IsArray,
  IsIn,
  IsNotEmpty,
  IsDateString,
  IsEnum,
} from 'class-validator';
import { Type } from 'class-transformer';

class Sort {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  column: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  @IsIn(['ASC', 'DESC'])
  order: any;
}

class Filter {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  column: string;

  @IsString()
  @ApiProperty()
  @IsNotEmpty()
  text: string;
}

export class GetListReportStockQueryDto extends PaginationQuery {
  @ApiProperty({ example: '2021-06-07T00:00:00.000Z' })
  @IsDateString()
  @IsOptional()
  reportDate: Date;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll: string;
}
