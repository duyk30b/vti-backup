import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsInt, IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class GetLotsByItemQueryDto extends PaginationQuery {
  @ApiProperty()
  @IsOptional()
  @IsString()
  keyword: string;
}
export class GetLotsByItemRequestDto extends GetLotsByItemQueryDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;
}
