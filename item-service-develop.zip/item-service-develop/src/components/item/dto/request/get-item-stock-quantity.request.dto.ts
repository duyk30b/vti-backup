import { ItemStockMovementTypeEnum } from '@components/item-warehouse/item-warehouse.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsArray, IsDateString, IsEnum } from 'class-validator';

export class GetItemStockQuantityRequestDto extends BaseDto {
  @ApiProperty()
  @IsDateString()
  from: Date;

  @ApiProperty()
  @IsDateString()
  to: Date;

  @ApiProperty()
  @IsEnum(ItemStockMovementTypeEnum)
  orderType: number;

  @ApiProperty()
  @IsArray()
  warehouseIds: number[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  itemIds?: number[];
}
