import { BaseDto } from '@core/dto/base.dto';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsArray,
  IsInt,
  IsNotEmpty,
  IsOptional,
} from 'class-validator';

export class GetCountTransferByDateRequest extends BaseDto {
  @ArrayNotEmpty()
  @Type(() => DateIds)
  dateIds: DateIds[];

  @IsOptional()
  itemTypeId: number;
}

class DateIds {
  @IsNotEmpty()
  date: string;

  @IsInt({ each: true })
  @IsArray()
  ids: number[];
}
