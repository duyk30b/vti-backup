import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsInt, IsOptional, IsArray, IsString } from 'class-validator';

export class ItemWarehouseSourceDto {
  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsInt()
  warehouseId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  accounting: string;
}

export class UpdateItemWarehouseSourceRequestDto extends BaseDto {
  @ApiProperty()
  @IsArray()
  @Type(() => ItemWarehouseSourceDto)
  data: ItemWarehouseSourceDto[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  permission: string;
}
