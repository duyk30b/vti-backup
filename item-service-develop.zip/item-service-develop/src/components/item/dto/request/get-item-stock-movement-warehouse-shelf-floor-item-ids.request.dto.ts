import { BaseDto } from '@core/dto/base.dto';
import { Type } from 'class-transformer';
import { ArrayNotEmpty } from 'class-validator';

export class GetItemStockMovementWarehouseShelfFloorByItemIdsDto extends BaseDto {
  @Type(() => Number)
  @ArrayNotEmpty()
  itemIds: number[];

  @Type(() => Number)
  @ArrayNotEmpty()
  warehoureShelfFloorIds: number[];
}
