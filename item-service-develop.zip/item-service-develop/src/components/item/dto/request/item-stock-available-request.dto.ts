import { BaseDto } from '@core/dto/base.dto';
import { Expose } from 'class-transformer';

export class ItemStockAvailable {
  @Expose()
  itemId: number;

  @Expose()
  warehouseId: number;

  constructor(itemId: number, warehouseId: number) {
    this.itemId = itemId;
    this.warehouseId = warehouseId;
  }
}
