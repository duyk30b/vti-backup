import { BaseDto } from '@core/dto/base.dto';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

export class GetItemWarehouseWithLocationRequestDto extends BaseDto {
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => Item)
  items: Item[];

  @IsInt()
  @IsNotEmpty()
  warehouseId: number;

  @IsInt()
  @IsNotEmpty()
  warehouseSectorId: number;

  @IsInt()
  @IsNotEmpty()
  warehouseShelfId: number;

  @IsInt()
  @IsNotEmpty()
  warehouseShelfFloorId: number;
}

class Item {
  @IsInt()
  @IsNotEmpty()
  itemId: number;

  @IsOptional()
  @IsString()
  lotNumber: string;
}
