import { BaseDto } from '@core/dto/base.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsArray, IsOptional } from 'class-validator';

export class GetFloorExistItemRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  floorIds: number[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  itemIds: number[];
}
