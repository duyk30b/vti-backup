import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsArray, IsInt, IsNotEmpty, IsOptional } from 'class-validator';

export class GetLotNumberByItemIdQueryDto extends PaginationQuery {}
export class GetLotNumberByItemIdRequestDto extends GetLotNumberByItemIdQueryDto {
  @ApiProperty()
  @IsOptional()
  @IsArray()
  itemIds: number[];

  @ApiProperty()
  @IsOptional()
  @IsArray()
  warehouseShelfFloorIds: number[];

  @ApiProperty()
  @IsOptional()
  @IsArray()
  warehouseIds: number[];

  @ApiProperty()
  @IsOptional()
  @IsArray()
  locatorIds: number[];

  @ApiProperty()
  @IsOptional()
  isFlatLots: string;
}
