import { ItemStockMovementTypeEnum } from '@components/item-warehouse/item-warehouse.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ValidateNested,
  IsArray,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsPositive,
  IsOptional,
  IsString,
  IsEnum,
  IsDateString,
} from 'class-validator';

class ItemsStockMovementHistory {
  @ApiProperty({ example: 1 })
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty({ example: 1 })
  @IsNumber()
  @IsPositive()
  quantity: number;

  @ApiPropertyOptional({ example: 1 })
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiPropertyOptional({ example: 1 })
  @IsOptional()
  @IsInt()
  locatorId: number;

  @ApiPropertyOptional({ example: 1 })
  @IsOptional()
  @IsDateString()
  mfg: Date;

  @ApiProperty({ example: 2.2 })
  @IsOptional()
  amount: number;

  @ApiProperty({ example: 2.2 })
  @IsOptional()
  totalAmount: number;
}
export class ItemStockMovementDto {
  @ApiProperty({ example: 1 })
  @IsNotEmpty()
  @IsInt()
  warehouseStockMovementId: number;

  @ApiProperty({ example: 1 })
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty({ example: 1 })
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @ApiProperty({ example: 1 })
  @IsNotEmpty()
  @IsInt()
  userId: number;

  @ApiProperty({ example: 1 })
  @IsInt()
  orderId: number;

  @ApiProperty({ example: 1 })
  @IsInt()
  orderType: number;

  @ApiProperty({ example: 1 })
  @IsString()
  orderCode: string;

  @ApiProperty({ example: 1 })
  @IsNotEmpty()
  @IsInt()
  movementOrderDetailId: number;

  @ApiProperty({ example: 1 })
  @IsNotEmpty()
  @IsInt()
  movementOrderWarehouseDetailId: number;

  @ApiProperty({ example: 2.2 })
  @Transform(({ value }) => Number(value))
  @IsPositive()
  @IsNumber()
  quantity: number;

  @ApiProperty({ example: 2.2 })
  @IsOptional()
  @IsDateString()
  storageDate: Date;

  @ApiProperty({ type: ItemsStockMovementHistory })
  @IsOptional()
  @ValidateNested()
  @IsArray()
  @Type(() => ItemsStockMovementHistory)
  itemsStockMovementHistories: ItemsStockMovementHistory[];

  @ApiProperty({ example: true })
  @IsOptional()
  @IsEnum(ItemStockMovementTypeEnum)
  type: number;

  @ApiProperty({ example: 2.2 })
  @IsOptional()
  amount: number;
}

export class CreateItemStockMovementDto extends BaseDto {
  @ApiProperty({ type: ItemStockMovementDto })
  @ArrayNotEmpty()
  @ValidateNested()
  @IsArray()
  @Type(() => ItemStockMovementDto)
  items: ItemStockMovementDto[];
}
