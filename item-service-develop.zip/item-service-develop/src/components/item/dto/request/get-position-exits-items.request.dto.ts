import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsOptional } from 'class-validator';

export class GetPositionExistItemsRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @IsArray()
  itemIds: number[];

  @ApiProperty()
  @IsOptional()
  @IsArray()
  floorIds: number[];

  @ApiProperty()
  @IsOptional()
  @IsArray()
  locatorIds: number[];
}
