import { IsNull } from 'typeorm';
import { isEmpty } from 'lodash';
import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { Transform, Type } from 'class-transformer';
import { IsArray, IsOptional } from 'class-validator';

export class GetListItemStockWarehousePriceRequest extends PaginationQuery {
  @ApiProperty()
  @Type(() => GetListItemStockWarehousePriceCondition)
  @IsArray()
  @IsOptional()
  conditions: GetListItemStockWarehousePriceCondition[];
}

class GetListItemStockWarehousePriceCondition {
  @ApiProperty()
  @IsOptional()
  @Transform((v) => (!isEmpty(v.value) ? v.value : IsNull()))
  lotNumber: any;

  @ApiProperty()
  @IsOptional()
  itemId: number;

  @ApiProperty()
  @IsOptional()
  warehouseId: number;
}
