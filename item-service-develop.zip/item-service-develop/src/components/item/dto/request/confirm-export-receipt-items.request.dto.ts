import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsArray,
  IsDateString,
  IsInt,
  IsMongoId,
  IsNotEmpty,
  IsOptional,
  IsPositive,
  IsString,
  ValidateNested,
} from 'class-validator';

class ConfirmExportReceiptItemRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiProperty()
  @IsPositive()
  @IsInt()
  quantity: number;

  @ApiProperty()
  @IsOptional()
  locatorId: string;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  mfg: Date;

  @ApiProperty()
  @IsOptional()
  @IsDateString()
  importDate: Date;
}

export class ConfirmExportReceiptItemsRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  ticketId: string;

  @ApiProperty()
  @IsArray()
  @ArrayNotEmpty()
  @ValidateNested({ each: true })
  @Type(() => ConfirmExportReceiptItemRequestDto)
  items: ConfirmExportReceiptItemRequestDto[];
}
