import { BaseDto } from '@core/dto/base.dto';
import { Expose } from 'class-transformer';
import { IsInt, IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class GetItemStockMovementWarehouseShelfFloorDto extends BaseDto {
  @Expose()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @Expose()
  @IsOptional()
  @IsString()
  lotNumber: string;

  @Expose()
  @IsNotEmpty()
  @IsInt()
  floorId: number;
}
