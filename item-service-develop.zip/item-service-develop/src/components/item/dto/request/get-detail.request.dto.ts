import { BaseDto } from '@core/dto/base.dto';
import { IsNotEmpty, IsInt } from 'class-validator';

export class GetDetailRequestDto extends BaseDto {
  @IsNotEmpty()
  @IsInt()
  id: number;
}
