import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsArray, IsOptional } from 'class-validator';

export class GetStorageDateByItemIdsRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @IsArray()
  itemIds: number[];

  @ApiPropertyOptional()
  @IsOptional()
  locatorIds?: string;
}
