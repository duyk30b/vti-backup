import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsInt, IsNotEmpty, IsString } from 'class-validator';

export class UpdateIsHasBomItemDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'Mã id của item cần update' })
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiPropertyOptional({ example: '1', description: 'isHasBom' })
  @IsNotEmpty()
  @IsString()
  @IsEnum(['0', '1'])
  isHasBom: string;
}
