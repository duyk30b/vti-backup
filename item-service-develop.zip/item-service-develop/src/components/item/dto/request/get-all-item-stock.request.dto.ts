import { BaseDto } from '@core/dto/base.dto';
import { Expose, Transform } from 'class-transformer';
import { IsNotEmpty, IsInt } from 'class-validator';
export class GetAllItemstockRequestDto extends BaseDto {
  @Expose()
  @IsNotEmpty()
  @IsInt()
  @Transform(({ value }) => Number(value))
  id: number;
}
