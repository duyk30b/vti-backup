import { BaseDto } from '@core/dto/base.dto';
import { IsArray, IsInt, IsNotEmpty } from 'class-validator';

export class GetReportDailyDto extends BaseDto {
  @IsInt()
  @IsNotEmpty()
  warehouseId: number;

  @IsArray()
  warehouseStockMovementInIds: number[];

  @IsArray()
  warehouseStockMovementOutIds: number[];
}
