import { ApiProperty } from '@nestjs/swagger';
import { UNIT_MEASURES } from '@utils/constant';
import { IsEnum, IsNotEmpty, IsNumber, IsPositive } from 'class-validator';

export class UnitMeasuresRequest {
  @ApiProperty({ example: '10.00', description: 'Giá trị' })
  @IsNotEmpty()
  @IsPositive()
  @IsNumber()
  value: number;

  @ApiProperty({ example: 1, description: 'Đơn vị đo' })
  @IsNotEmpty()
  @IsPositive()
  @IsEnum(UNIT_MEASURES)
  unit: number;
}
