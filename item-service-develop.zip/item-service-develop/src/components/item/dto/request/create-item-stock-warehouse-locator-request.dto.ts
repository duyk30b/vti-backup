import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
} from 'class-validator';

export class CreateItemStockWarehouseLocatorRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  locatorId: number;

  @ApiProperty()
  @IsOptional()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @IsPositive()
  quantity: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiProperty()
  @IsOptional()
  mfg: Date;

  @ApiProperty()
  @IsOptional()
  storageDate: Date;
}
