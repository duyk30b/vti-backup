import { ApiProperty } from '@nestjs/swagger';
import { BaseDto } from '../../../../core/dto/base.dto';
import { ArrayNotEmpty, IsEnum, IsOptional } from 'class-validator';
import { Transform } from 'class-transformer';
import { QrCodeItemTypeEnum } from '@components/item/item.constant';
export class GetQrCodeItemsRequestDto extends BaseDto {
  @ApiProperty()
  @ArrayNotEmpty()
  @Transform(({ value }) => value.split(',').map((v) => Number(v)))
  itemIds: number[];

  @ApiProperty()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  @IsEnum(QrCodeItemTypeEnum)
  type: number;

  @ApiProperty()
  @IsOptional()
  @ArrayNotEmpty()
  @Transform(({ value }) => value.split(','))
  warehouseCodes: string[];
}
