import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsNotEmpty } from 'class-validator';

export class GetItemStockMovementByWarehouseLocatorIds extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  locatorIds: number[];
}
