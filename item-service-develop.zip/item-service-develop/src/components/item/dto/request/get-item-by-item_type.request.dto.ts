import { BaseDto } from '@core/dto/base.dto';
import { Transform } from 'class-transformer';
import { IsArray, IsInt, IsOptional } from 'class-validator';
import { isJson } from 'src/helper/string.helper';

export class GetItemByItemTypeRequest extends BaseDto {
  @IsOptional()
  @IsInt({ each: true })
  @IsArray()
  @Transform(({ value }) => {
    if (value && typeof value === 'string') value = value.replace(/\\/g, '');

    if (isJson(value)) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    }

    return value;
  })
  itemIds: number[];

  @IsOptional()
  itemTypeId: number;
}
