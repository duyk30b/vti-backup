export class CreateItemStockWarehouseLocatorHistoryRequestDto {
  itemStockWarehouseLocatorId: number;
  itemStockMovementHistoryId: number;
  quantity: number;
  orderId: number;
  orderType: number;
  purpose: string;

  constructor(
    itemStockMovementHistoryId: number,
    quantity: number,
    orderId: number,
    orderType: number,
    itemStockWarehouseLocatorId?: number,
    purpose?: string,
  ) {
    this.itemStockWarehouseLocatorId = itemStockWarehouseLocatorId;
    this.itemStockMovementHistoryId = itemStockMovementHistoryId;
    this.quantity = quantity;
    this.orderId = orderId;
    this.orderType = orderType;
    this.purpose = purpose;
  }
}
