import { Transform } from 'class-transformer';
import { IsNotEmpty } from 'class-validator';
import { ItemBarcodeQuery } from './item-barcode.query';

export class TransitItemBarcodeQuery extends ItemBarcodeQuery {
  @IsNotEmpty()
  @Transform((value) => {
    return Number(value.value) || 1;
  })
  transferId: string;

  @IsNotEmpty()
  @Transform((value) => {
    return Number(value.value) || 0;
  })
  transferType: string;
}
