import { Transform } from 'class-transformer';
import { IsNotEmpty, IsInt } from 'class-validator';
import { ItemBarcodeQuery } from './item-barcode.query';

export class InventoryItemBarcodeQuery extends ItemBarcodeQuery {
  @IsNotEmpty()
  @IsInt()
  @Transform(({ value }) => Number(value))
  locatorId: number;

  @IsNotEmpty()
  @IsInt()
  @Transform(({ value }) => Number(value))
  inventoryId: number;
}
