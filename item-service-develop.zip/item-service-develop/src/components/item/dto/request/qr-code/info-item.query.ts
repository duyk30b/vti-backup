import { ItemBarcodeQuery } from './item-barcode.query';
import { IsInt, IsOptional } from 'class-validator';
import { Transform } from 'class-transformer';

export class InfoItemBarcodeQuery extends ItemBarcodeQuery {
  @IsOptional()
  @IsInt()
  @Transform(({ value }) => +value)
  warehouseId?: number;

  @IsOptional()
  @IsInt()
  @Transform(({ value }) => +value)
  locatorId?: number;
}
