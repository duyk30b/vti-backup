import { IsNotEmpty } from 'class-validator';
import { ItemBarcodeQuery } from './item-barcode.query';

export class SuggestCollectedByPoExportIdBarcodeQuery extends ItemBarcodeQuery {
  @IsNotEmpty()
  soId: string;
}
