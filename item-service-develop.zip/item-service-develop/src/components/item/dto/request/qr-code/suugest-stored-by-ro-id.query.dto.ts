import { IsNotEmpty } from 'class-validator';
import { ItemBarcodeQuery } from './item-barcode.query';
export class SuggestStoredByRoIdBarcodeQuery extends ItemBarcodeQuery {
  @IsNotEmpty()
  roId: string;
}
