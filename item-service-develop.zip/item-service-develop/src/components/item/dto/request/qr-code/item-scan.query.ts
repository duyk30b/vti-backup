export interface ItemBarcodeScanQuery {}
