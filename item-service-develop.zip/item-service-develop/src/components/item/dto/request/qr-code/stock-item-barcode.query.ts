import { IsNotEmpty } from 'class-validator';
import { ItemBarcodeQuery } from './item-barcode.query';

export class StockItemBarcodeQuery extends ItemBarcodeQuery {
  @IsNotEmpty()
  warehouseId: string;
}
