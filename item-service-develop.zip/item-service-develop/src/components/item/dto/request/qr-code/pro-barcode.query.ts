import { Transform } from 'class-transformer';
import { IsNotEmpty } from 'class-validator';
import { ItemBarcodeQuery } from './item-barcode.query';

export class PrOBarcodeQuery extends ItemBarcodeQuery {
  @IsNotEmpty()
  @Transform((value) => {
    return Number(value.value) || 1;
  })
  proId: string;

  @IsNotEmpty()
  @Transform((value) => {
    return Number(value.value) || 1;
  })
  warehouseId: string;
}
