import { Transform } from 'class-transformer';
import { IsNotEmpty } from 'class-validator';
import { ItemBarcodeQuery } from './item-barcode.query';

export class ExoBarcodeQuery extends ItemBarcodeQuery {
  @IsNotEmpty()
  @Transform((value) => {
    return Number(value.value) || 1;
  })
  eoId: string;

  @IsNotEmpty()
  @Transform((value) => {
    return Number(value.value) || 1;
  })
  warehouseId: string;
}
