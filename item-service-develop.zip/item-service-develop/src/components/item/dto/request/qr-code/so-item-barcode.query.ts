import { Transform } from 'class-transformer';
import { IsNotEmpty } from 'class-validator';
import { ItemBarcodeQuery } from './item-barcode.query';

export class SOItemBarcodeQuery extends ItemBarcodeQuery {
  @IsNotEmpty()
  @Transform((value) => {
    return Number(value.value) || 1;
  })
  soId: string;

  @IsNotEmpty()
  @Transform((value) => {
    return Number(value.value) || 1;
  })
  warehouseId: string;
}
