import { Transform } from 'class-transformer';
import { IsNotEmpty } from 'class-validator';
import { ItemBarcodeQuery } from './item-barcode.query';
export class POBarcodeQuery extends ItemBarcodeQuery {
  @IsNotEmpty()
  @Transform((value) => {
    return Number(value.value) || 1;
  })
  poId: number;

  @IsNotEmpty()
  @Transform((value) => {
    return Number(value.value) || 1;
  })
  warehouseId: string; 
}
