import { ItemBarcodeTypeEnum } from '@components/item/item.constant';
import { IsEnum, IsNotEmpty, IsOptional } from 'class-validator';
import { ItemBarcodeScanQuery } from './item-scan.query';
import { Transform } from 'class-transformer';

export class ItemBarcodeQuery implements ItemBarcodeScanQuery {
  @IsNotEmpty()
  qrCode: string;

  @IsNotEmpty()
  user: any;

  @IsNotEmpty()
  @IsEnum(ItemBarcodeTypeEnum)
  type: ItemBarcodeTypeEnum;

  @IsOptional()
  @Transform((value) => {
    return Number(value.value) || 1;
  })
  warehouseShelfFloorId: string;
}
