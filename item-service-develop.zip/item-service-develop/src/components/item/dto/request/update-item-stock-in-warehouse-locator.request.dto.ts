import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsDateString,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

class ItemStockWarehouseLocator {
  id: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  lotNumber: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  locatorId: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  ticketLocatorId: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  mfg: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsDateString()
  importDate: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  quantity: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  ticketId: string;
}

export class UpdateItemStockWarehouseLocatorRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  @ValidateNested()
  items: ItemStockWarehouseLocator[];
}
