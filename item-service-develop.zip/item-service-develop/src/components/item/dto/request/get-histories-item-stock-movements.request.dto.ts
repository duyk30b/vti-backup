import { BaseDto } from '@core/dto/base.dto';
import { IsArray, IsNotEmpty } from 'class-validator';

export class GetHistoriesItemStockMovements extends BaseDto {
  @IsNotEmpty()
  @IsArray()
  warehouseStockMovementIds: number[];
}
