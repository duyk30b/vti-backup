import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsNotEmpty, IsOptional } from 'class-validator';

export class GetItemStockMovementWarehouseShelfFloorByIdsDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  ids: number[];
}
