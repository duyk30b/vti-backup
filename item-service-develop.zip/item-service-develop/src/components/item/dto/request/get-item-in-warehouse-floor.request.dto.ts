import { BaseDto } from '@core/dto/base.dto';
import { Expose } from 'class-transformer';
import { IsArray, IsNotEmpty } from 'class-validator';

export class GetPositionItemInWarehouseFloorDto extends BaseDto {
  @Expose()
  @IsNotEmpty()
  @IsArray()
  itemIds: number[];

  @Expose()
  @IsNotEmpty()
  @IsArray()
  floorIds: number[];
}
