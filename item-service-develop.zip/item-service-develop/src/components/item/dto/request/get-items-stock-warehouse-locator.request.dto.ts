import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsNotEmpty } from 'class-validator';

export class GetItemStockWarehouseLocatorRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  locatorIds: number[];

  @ApiProperty()
  @IsNotEmpty()
  warehouseId: number;
}
