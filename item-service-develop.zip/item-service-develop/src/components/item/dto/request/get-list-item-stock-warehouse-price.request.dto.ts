import { ApiProperty } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsOptional } from 'class-validator';

export class GetListItemStockWarehousePriceRequestDto extends PaginationQuery {
  @ApiProperty()
  @IsOptional()
  lotNumbers: string[];

  @ApiProperty()
  @IsOptional()
  itemIds: number[];

  @ApiProperty()
  @IsOptional()
  warehouseIds: number[];
}
