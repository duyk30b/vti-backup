import { BaseDto } from '@core/dto/base.dto';
import { ArrayNotEmpty, IsOptional } from 'class-validator';

export class GetItemDto extends BaseDto {
  @ArrayNotEmpty()
  itemIds: number[];

  @IsOptional()
  factoryId: number;

  @IsOptional()
  filter: any;

  @IsOptional()
  basicInfor: boolean;

  @IsOptional()
  forceFilterByFactoryId: boolean;
}
