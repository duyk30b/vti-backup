import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';

export class CreateItemDetailSettingDto extends BaseDto {
  @ApiProperty({ example: 'PK_GO_XXX', description: 'Mã code của  chi tiết' })
  @MaxLength(12)
  @IsString()
  @IsNotEmpty()
  code: string;

  @ApiProperty({ example: 'Chi tiết cái bàn', description: 'Tên chi tiết' })
  @IsNotEmpty()
  @MaxLength(255)
  @IsString()
  name: string;

  @ApiProperty({
    example: 'Đây là chi tiết cái bàn',
    description: 'Mô tả thông tin chi tiết',
  })
  @MaxLength(255)
  @IsOptional()
  description: string;
}
