import { CreateItemBodyDto } from './create-item.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class UpdateItemBodyRequestDto extends CreateItemBodyDto {}
export class UpdateItemDto extends UpdateItemBodyRequestDto {
  @ApiProperty({ example: 1, description: 'Mã id của item cần update' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
