import { BaseDto } from '@core/dto/base.dto';
import { Expose } from 'class-transformer';
import { IsNotEmpty, IsInt, IsArray } from 'class-validator';
export class GetListItemstockMovementRequestDto extends BaseDto {
  @Expose()
  @IsNotEmpty()
  @IsInt()
  warehouseStockMovementId: number;
}
export class GetListItemstockMovementByWarehouseStockMovementIdsRequestDto extends BaseDto {
  @Expose()
  @IsNotEmpty()
  @IsArray()
  warehouseStockMovementIds: number[];
}
export class GetListItemstockMovementByLotNumberRequestDto extends BaseDto {
  @Expose()
  @IsNotEmpty()
  @IsArray()
  lotNumbers: string[];

  @Expose()
  @IsNotEmpty()
  @IsInt()
  warehouseFloorId: number;
}
