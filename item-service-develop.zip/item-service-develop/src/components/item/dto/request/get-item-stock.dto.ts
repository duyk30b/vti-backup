import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { Transform } from 'class-transformer';
import { ArrayNotEmpty, IsEnum, IsOptional, IsInt } from 'class-validator';

export class GetItemStockRequestDto extends PaginationQuery {
  @ApiProperty({
    example: '1,2,3,4,5,6',
    description: 'Danh sách kho cần lấy số lượng tồn kho',
  })
  @ArrayNotEmpty()
  @Transform((data) => {
    return data.value
      .split(',')
      .map((e) => Number(e))
      .filter((e) => Number.isInteger(e));
  })
  warehouseIds: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll: string;
}
export class GetItemWarehouseStockRequestDto extends PaginationQuery {
  @ApiProperty({})
  @IsOptional()
  @Transform((data) => {
    return +data.value;
  })
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsOptional()
  locatorIds: string;

  @ApiProperty()
  @IsOptional()
  itemIds: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['0', '1'])
  isGetAll: string;
}
