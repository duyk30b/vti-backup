import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { Transform, Type } from 'class-transformer';
import { IsArray, IsNumber, IsOptional } from 'class-validator';
import { isJson } from 'src/helper/string.helper';

export class GetListItemStockWarehouseLocatorByCondition extends PaginationQuery {
  @ApiProperty()
  @IsOptional()
  @IsArray()
  @Transform(({ value }) => {
    if (value instanceof Array) {
      return value;
    }

    if (value && value.includes('\\"')) value = value.replace(/\\/g, '');

    if (isJson(value) && JSON.parse(value) instanceof Array) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    } else {
      return value?.split(',')?.map((item) => +item);
    }
  })
  @IsNumber({}, { each: true })
  itemIds: number[];

  @ApiProperty()
  @IsOptional()
  @Transform(({ value }) => {
    if (isJson(value)) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    }
  })
  @IsArray()
  locatorIds: number[];

  @ApiProperty()
  @IsOptional()
  @Transform(({ value }) => {
    if (value instanceof Array) {
      return value;
    }

    if (value && value.includes('\\"')) value = value.replace(/\\/g, '');

    if (isJson(value) && JSON.parse(value) instanceof Array) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    } else {
      return value.split(',');
    }
  })
  @IsArray()
  ticketLocatorIds: string[];

  @ApiProperty()
  @IsOptional()
  @Transform(({ value }) => {
    if (isJson(value)) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    }
  })
  @IsArray()
  warehouseIds: number[];

  @ApiProperty()
  @IsOptional()
  @Transform(({ value }) => {
    if (value instanceof Array) {
      return value;
    }

    if (value && value.includes('\\"')) value = value.replace(/\\/g, '');

    if (isJson(value) && JSON.parse(value) instanceof Array) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    } else {
      return value.split(',');
    }
  })
  ticketIds: string[];

  @ApiProperty()
  @IsOptional()
  lotNumbers: string[];

  @ApiProperty()
  @IsOptional()
  isSameWarehouse: string;

  @ApiProperty()
  @IsOptional()
  itemId: number;

  @ApiProperty()
  @IsOptional()
  lotNumber: string;

  @ApiPropertyOptional()
  @IsOptional()
  storageDate?: Date;

  @ApiPropertyOptional()
  @IsOptional()
  mfg?: Date;
}
