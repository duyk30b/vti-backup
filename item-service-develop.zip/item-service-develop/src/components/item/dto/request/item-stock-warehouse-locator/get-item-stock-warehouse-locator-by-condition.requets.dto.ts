import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { BaseDto } from '@core/dto/base.dto';
import { IsInt, IsString, IsOptional } from 'class-validator';
import { Transform } from 'class-transformer';
import { PaginationQuery } from '@utils/pagination.query';

export class GetItemStockWarehouseLocatorByConditionRequestDto extends BaseDto {
  @ApiProperty()
  @IsOptional()
  typeTransaction: string;

  @ApiProperty()
  @IsOptional()
  warehouseIds: number[];

  @ApiProperty()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  @IsInt()
  itemId: number;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  lotNumber: string;

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  @IsInt()
  warehouseId: number;

  @ApiPropertyOptional()
  @IsOptional()
  locatorIds?: number[];

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  locatorId?: number;

  @ApiPropertyOptional()
  @IsOptional()
  storageDate?: Date;

  @ApiPropertyOptional()
  @IsOptional()
  mfg?: Date;

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  ticketType?: number;
}

export class GetListItemStockWarehouseLocatorsRequestDto extends PaginationQuery {
  @ApiProperty()
  @IsOptional()
  typeTransaction: string;

  @ApiProperty()
  @IsOptional()
  warehouseIds: number[];

  @ApiProperty()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  @IsInt()
  itemId: number;

  @ApiPropertyOptional()
  @IsString()
  @IsOptional()
  lotNumber: string;

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  @IsInt()
  warehouseId: number;

  @ApiPropertyOptional()
  @IsOptional()
  locatorIds?: number[];

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  locatorId?: number;

  @ApiPropertyOptional()
  @IsOptional()
  storageDate?: Date;

  @ApiPropertyOptional()
  @IsOptional()
  mfg?: Date;

  @ApiPropertyOptional()
  @IsOptional()
  @Transform(({ value }) => Number(value))
  ticketType?: number;
}
