import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsInt,
  IsMongoId,
  IsNotEmpty,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

export class ItemStockInWarehouseLocatorRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsMongoId()
  locatorId: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiProperty()
  @IsOptional()
  @IsArray()
  mfg: Date;

  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  warehouseId: number;
}

export class GetItemStockInWarehouseLocatorRequestDto extends BaseDto {
  @IsArray()
  @ValidateNested({ each: true })
  items: ItemStockInWarehouseLocatorRequestDto;
}
