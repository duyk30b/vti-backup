import { Expose } from 'class-transformer';

export class FilterItemDetail {
  @Expose()
  itemId: number;

  @Expose()
  itemDetailSettingId: number;

  constructor(itemId: number, itemDetailSettingId: number) {
    this.itemId = itemId;
    this.itemDetailSettingId = itemDetailSettingId;
  }
}
