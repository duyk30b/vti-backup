import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsInt, IsOptional, IsString } from 'class-validator';

export class GetListStorageDateByItemIdQueryDto extends PaginationQuery {
  @ApiProperty()
  @IsOptional()
  @IsString()
  keyword: string;
}
export class GetListStorageDateByItemIdRequestDto extends GetListStorageDateByItemIdQueryDto {
  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  warehouseId: number;

  @ApiPropertyOptional()
  @IsOptional()
  locatorIds: string;
}
