import { ITEM_RULES } from '@components/item/item.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsOptional,
  Matches,
  IsString,
  MinLength,
  MaxLength,
  ValidateNested,
  ValidateIf,
  ArrayUnique,
  IsArray,
  NotEquals,
  IsNumber,
  IsBoolean,
} from 'class-validator';
import { FileAbtractDto } from '@core/dto/file-upload.request';

export class LocationWarehouse {
  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  id: number;

  @ApiPropertyOptional()
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  itemId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  warehouseSectorId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  warehouseShelfId: number;
}
export class File extends FileAbtractDto {
  @IsEnum(ITEM_RULES.FILE.MIME_TYPES)
  mimetype: string;
}

export class ItemConvertUnit {
  @ApiProperty()
  @IsOptional()
  @IsInt()
  id: number;

  @ApiProperty()
  @MaxLength(225)
  @IsString()
  @NotEquals(null)
  @ValidateIf((_object, value) => value !== undefined)
  name: string;

  @ApiProperty()
  @IsInt()
  itemUnitId: number;

  @ApiProperty()
  @IsNumber()
  @NotEquals(null)
  @ValidateIf((_object, value) => value !== undefined)
  quantity: number;
}
export class CreateItemBodyDto extends BaseDto {
  @ApiProperty({ example: 'Cái bàn', description: 'Tên item' })
  @MaxLength(ITEM_RULES.NAME.MAX_LENGTH)
  @IsString()
  name: string;

  @ApiPropertyOptional()
  @IsOptional()
  //@ValidateIf((_object, value) => value !== undefined && value !== '')
  //@MaxLength(ITEM_RULES.NORMALIZE_CODE.MAX_LENGTH)
  //@MinLength(ITEM_RULES.NORMALIZE_CODE.MIN_LENGTH)
  @IsString()
  normalizeCode: string;

  @ApiProperty()
  @IsOptional()
  @IsBoolean()
  isProductionObject: boolean;

  @ApiProperty({ example: 'BAN_GO_XXX', description: 'Mã code của item' })
  @MaxLength(ITEM_RULES.CODE.MAX_LENGTH)
  @MinLength(ITEM_RULES.CODE.MIN_LENGTH)
  @Matches(ITEM_RULES.CODE.REGEX)
  @IsString()
  code: string;

  @ApiProperty({
    example: 'Đây là cái bàn',
    description: 'Mô tả thông tin item',
  })
  @MaxLength(ITEM_RULES.DESCRIPTION.MAX_LENGTH)
  @IsOptional()
  description: string;

  @ApiProperty({
    example: 1,
    description: 'Mã Id đơn vị của item',
  })
  @IsNotEmpty()
  @Transform((obj) => Number(obj.value))
  @IsInt()
  itemUnitId: number;

  @ApiProperty({
    example: 1,
    description: 'Mã loại item',
  })
  @Transform((obj) => Number(obj.value))
  @IsInt()
  itemTypeId: number;

  @ApiProperty({
    example: 1,
    description: 'Mã loại item',
  })
  @Transform((obj) => Number(obj.value))
  @IsInt()
  itemGroupId: number;

  @ApiProperty({
    example: 1,
    description: 'Xuất xứ item',
  })
  //@Transform((obj) => Number(obj.value))
  @IsOptional()
  @IsNumber()
  manufacturingCountryId: number;

  @ApiProperty({
    example: 1,
    description: 'Chất lượng item',
  })
  @Transform((obj) => Number(obj.value))
  @IsOptional()
  @IsInt()
  itemQualityId: number;

  @ApiProperty({
    example: 1,
    description: 'Danh mục đối tượng',
  })
  @Transform((obj) => Number(obj.value))
  @IsOptional()
  @IsInt()
  objectCategoryId: number;

  @ApiProperty()
  @IsBoolean()
  isConvertUnit: boolean;

  @ApiProperty()
  @IsOptional()
  @ArrayUnique((e: ItemConvertUnit) => e.name)
  @IsArray()
  @Type(() => ItemConvertUnit)
  itemConvertUnits: ItemConvertUnit[];

  @ApiPropertyOptional()
  @IsOptional()
  @ValidateNested()
  @Type(() => File)
  file: File;
}

export class ItemDetailDto {
  @ApiProperty({
    example: 1,
    description: 'Mã chi tiết cấu thành thành phẩm',
  })
  @IsNotEmpty()
  @IsInt()
  detailId: number;

  @ApiProperty({
    example: 1,
    description: 'Số lượng chi tiết cấu thành thành phẩm',
  })
  @IsNotEmpty()
  @IsInt()
  quantity: number;
}

export class CreateItemDto extends CreateItemBodyDto { }
