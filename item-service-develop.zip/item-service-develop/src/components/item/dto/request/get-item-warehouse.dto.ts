import { BaseDto } from '@core/dto/base.dto';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsInt,
  IsNotEmpty,
  ValidateNested,
} from 'class-validator';

export class GetItemWarehouseDto extends BaseDto {
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => Item)
  items: Item[];

  @IsInt()
  @IsNotEmpty()
  warehouseId: number;
}

class Item {
  @IsInt()
  @IsNotEmpty()
  itemId: number;
}
