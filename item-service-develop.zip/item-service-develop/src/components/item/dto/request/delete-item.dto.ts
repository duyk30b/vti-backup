import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsInt, IsNotEmpty, IsOptional } from 'class-validator';

export class DeleteItemBodyRequestDto extends BaseDto {}
export class DeleteItemDto extends DeleteItemBodyRequestDto {
  @ApiProperty({ example: 1, description: 'Mã id item cần xóa' })
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsOptional()
  @IsBoolean()
  isMmsRequest: boolean;
}
