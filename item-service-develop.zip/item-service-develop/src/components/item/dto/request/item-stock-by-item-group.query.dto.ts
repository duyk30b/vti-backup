import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsString } from 'class-validator';

export class ItemStockByItemGroupQueryDto extends BaseDto {
  @ApiProperty({
    example: '00',
    description: 'Mã kiểu item',
  })
  @IsString()
  itemTypeCode: string;
}
