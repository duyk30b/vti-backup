import { BaseDto } from '@core/dto/base.dto';
import { IsArray, IsNotEmpty } from 'class-validator';

export class CheckExistStockInLocatorRequest extends BaseDto {
  @IsArray()
  @IsNotEmpty()
  locatorIds: string[];
}
