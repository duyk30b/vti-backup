import { ApiProperty } from "@nestjs/swagger";
import { PaginationQuery } from "@utils/pagination.query";
import { IsDateString } from "class-validator";

export class GetItemStockMovementInWarehouseLocatorByDay extends PaginationQuery {
  @ApiProperty()
  @IsDateString()
  startDate: Date;

  @ApiProperty()
  @IsDateString()
  endDate: Date;
}