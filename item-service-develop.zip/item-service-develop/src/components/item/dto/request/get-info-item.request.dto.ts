import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsOptional } from 'class-validator';
export class GetInfoItemQueryDto extends BaseDto {
  @ApiPropertyOptional()
  @IsInt()
  @Transform(({ value }) => Number(value))
  @IsOptional()
  warehouseId: number;
}
export class GetInfoItemRequestDto extends GetInfoItemQueryDto {
  @ApiProperty()
  @IsInt()
  @IsOptional()
  id: number;
}
