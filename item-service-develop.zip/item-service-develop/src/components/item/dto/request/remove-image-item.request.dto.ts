import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { ArrayNotEmpty, IsInt } from 'class-validator';
export class RemoveImageItemBodyDto extends BaseDto {
  @ApiProperty()
  @ArrayNotEmpty()
  fileIds: number[];
}
export class RemoveImageItemRequestDto extends RemoveImageItemBodyDto {
  @ApiProperty()
  @IsInt()
  id: number;
}
