import { BaseDto } from '@core/dto/base.dto';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsInt,
  IsNotEmpty,
  IsNumber,
  ValidateNested,
} from 'class-validator';

export class CheckStockAvailableRequest extends BaseDto {
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => Item)
  items: Item[];
}

class Item {
  @IsInt()
  @IsNotEmpty()
  itemId: number;

  @IsNumber()
  @IsNotEmpty()
  quantity: number;

  @IsInt()
  @IsNotEmpty()
  warehouseId: number;
}
