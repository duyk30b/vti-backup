import { MIME_TYPES } from '@constant/common';

export enum ItemTypeCodeEnum {
  MATERIAL = '00',
  PRODUCT = '01',
}

export const ITEM_TYPE_CODES_DEFAULT: string[] = [
  ItemTypeCodeEnum.MATERIAL,
  ItemTypeCodeEnum.PRODUCT,
];

export enum ItemBarcodeTypeEnum {
  PO = '1',
  PRO = '2',
  SO = '3',
  TRANSFER = '4',
  INVENTORY = '5',
  STOCK = '6',
  IMO = '7',
  EMO = '8',
  POI = '9',
  SOE = '10',
  RO = '11',
  INFO_ITEM = '12',
}
export const IsSameWarehouse = {
  SameWarehouse: '0',
  NotSameWarehouse: '1',
};

export enum ItemStatusEnum {
  REJECT = 0,
  CONFIRMED = 1,
}

export enum ItemDetailSettingStatusEnum {
  CREATED = 0,
  CONFIRMED = 1,
  REJECT = 2,
}

export const CAN_UPDATE_ITEM_STATUS: number[] = [
  ItemStatusEnum.REJECT,
  ItemStatusEnum.CONFIRMED,
];

export const CAN_DELETE_ITEM_STATUS: number[] = [ItemStatusEnum.REJECT];

export const CAN_UPDATE_ITEM_DETAIL_SETTING_STATUS: number[] = [
  ItemDetailSettingStatusEnum.CREATED,
  ItemDetailSettingStatusEnum.REJECT,
];

export const CAN_DELETE_ITEM_DETAIL_SETTING_STATUS: number[] = [
  ItemDetailSettingStatusEnum.CREATED,
  ItemDetailSettingStatusEnum.REJECT,
];

//export const REGEX_ITEM_CODE = /^(?=.*.{6})[a-zA-Z\d.]{22}$/;
export const REGEX_ITEM_CODE = /^(02)[a-zA-Z\d]{5}$/;

export const QC_STAGE_ID = {
  INPUT_WAREHOUSE_BY_PO: '0',
  INPUT_WAREHOUSE_BY_PRO: '2',
  OUTPUT_WAREHOUSE_BY_PRO: '3',
  OUTPUT_WAREHOUSE_BY_SO: '5',
};

export enum EventSyncItemEnum {
  Create = 'event.syncItem.create',
  Update = 'event.syncItem.update',
  Confirm = 'event.syncItem.confirm',
  Reject = 'event.syncItem.reject',
  Delete = 'event.syncItem.delete',
}

export enum EventSyncTransactionEnum {
  SyncTransaction = 'item.event.syncTransaction',
}

export enum EventSyncInventoryNormEnum {
  Update = 'item.event.updateInventoryNorm',
}

export const ITEM_RULES = {
  NAME: {
    MAX_LENGTH: 255,
  },
  CODE: {
    MAX_LENGTH: 7,
    MIN_LENGTH: 7,
    REGEX: REGEX_ITEM_CODE,
  },
  NORMALIZE_CODE: {
    MAX_LENGTH: 11,
    MIN_LENGTH: 11,
  },
  DESCRIPTION: {
    MAX_LENGTH: 22,
  },
  FILE: {
    MIME_TYPES: MIME_TYPES.PDF,
    IMAGE_MIME_TYPES: MIME_TYPES.IMAGE,
    MAX_IMAGE_UPLOAD: 10,
  },
  ACCOUNTING: {
    MAX_LENGTH: 50,
  },
};

export enum QrCodeItemTypeEnum {
  NEW = 1,
  OLD = 0,
}
export enum TypeTransaction {
  PUT_AWAY = '1',
  PICK_AWAY = '2',
}
