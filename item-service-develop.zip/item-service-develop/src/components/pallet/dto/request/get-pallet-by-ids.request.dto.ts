import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsOptional } from 'class-validator';

export class GetPalletByIdsRequestDto extends BaseDto {
  @ApiProperty()
  @IsArray()
  ids: number[];

  @ApiProperty()
  @IsArray()
  @IsOptional()
  packagePalletCondition: any[];
}
