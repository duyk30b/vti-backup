import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';
import { CreatePalletRequestDto } from './create-pallet.request.dto';

export class UpdatePalletBodyRequestDto extends CreatePalletRequestDto {}
export class UpdatePalletRequestDto extends UpdatePalletBodyRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;
}
