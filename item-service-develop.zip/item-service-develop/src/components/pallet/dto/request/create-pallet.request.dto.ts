import { UnitMeasuresRequest } from '@components/item/dto/request/unit-measures.request.dto';
import { UnitWeightRequest } from '@components/item/dto/request/unit-weight.request.dto';
import { PalletTypeEnum } from '@components/pallet/pallet.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { decimal } from '@utils/common';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  ArrayUnique,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Length,
  Max,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';

class PalletDetailRequest {
  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  itemId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  packageId: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  blockId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  @Max(decimal(10, 2))
  quantity: number;
}

export class CreatePalletRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  name: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  @Length(1, 50)
  code: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(PalletTypeEnum)
  type: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(255)
  description: string;

  @ApiProperty()
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  width: UnitMeasuresRequest;

  @ApiProperty()
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  height: UnitMeasuresRequest;

  @ApiProperty()
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitMeasuresRequest)
  long: UnitMeasuresRequest;

  @ApiProperty()
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => UnitWeightRequest)
  weightLoad: UnitWeightRequest;

  @ApiProperty({ type: PalletDetailRequest, isArray: true })
  @ArrayNotEmpty()
  @ValidateNested()
  @ArrayUnique()
  @Type(() => PalletDetailRequest)
  palletDetails: PalletDetailRequest[];
}
