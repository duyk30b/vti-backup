import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsNotEmpty, IsNumber } from 'class-validator';

export class PalletEvenlyParamDto extends BaseDto {}
export class GetPalletEvenlyByItemDto extends PalletEvenlyParamDto {
  @ApiProperty({ example: '1', description: 'item id' })
  @IsNotEmpty()
  @Transform((obj) => Number(obj.value))
  @IsNumber()
  itemId: number;
}
