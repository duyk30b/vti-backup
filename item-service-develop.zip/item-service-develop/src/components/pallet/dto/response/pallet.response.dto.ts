import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { SuccessResponse } from '@utils/success.response.dto';
import { IsArray } from 'class-validator';
import { WeightUnitAbstractResponse } from '@components/item/dto/response/weight-unit-abstract.response.dto';
import { MeaseuresUnitAbstractResponse } from '@components/item/dto/response/measures-unit-abstract.response.dto';

class PackageResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}
class BlockResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class ItemResponseDto {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;
}

class PalletDetailResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Type(() => ItemResponseDto)
  @Expose()
  item: ItemResponseDto;

  @ApiProperty()
  @Type(() => PackageResponseDto)
  @Expose()
  package: PackageResponseDto;

  @ApiProperty()
  @Type(() => BlockResponseDto)
  @Expose()
  block: BlockResponseDto;
}

export class PalletResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  type: number;

  @ApiProperty()
  @Expose()
  @Type(() => MeaseuresUnitAbstractResponse)
  width: MeaseuresUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => MeaseuresUnitAbstractResponse)
  height: MeaseuresUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => MeaseuresUnitAbstractResponse)
  long: MeaseuresUnitAbstractResponse;

  @ApiProperty()
  @Expose()
  @Type(() => WeightUnitAbstractResponse)
  weightLoad: WeightUnitAbstractResponse;

  @ApiProperty({ type: PalletDetailResponse, isArray: true })
  @Type(() => PalletDetailResponse)
  @IsArray()
  @Expose()
  palletDetails: PalletDetailResponse[];

  @ApiProperty()
  @Expose()
  updatedAt: string;

  @ApiProperty()
  @Expose()
  createdAt: string;
}

export class PalletResponseDto extends SuccessResponse {
  @ApiProperty()
  @Type(() => PalletResponse)
  @Expose()
  data: PalletResponse;
}
