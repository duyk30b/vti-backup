import { Expose } from 'class-transformer';

export class PalletResponse {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;
}
