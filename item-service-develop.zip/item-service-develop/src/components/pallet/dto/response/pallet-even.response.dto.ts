import { Expose, Type } from 'class-transformer';

class BaseResponse {
  @Expose()
  id: number;

  @Expose()
  name: string;

  @Expose()
  code: string;
}

export class PalletEvenResponse extends BaseResponse {
  @Type(() => BaseResponse)
  @Expose()
  packages: BaseResponse[];
}
