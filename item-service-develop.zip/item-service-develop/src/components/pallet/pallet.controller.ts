import {
  Controller,
  Inject,
  Body,
  Post,
  Delete,
  Get,
  Put,
  Query,
  Param,
  ParseIntPipe,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { isEmpty } from 'lodash';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { PalletServiceInterface } from './interface/pallet.service.interface';
import { PalletResponseDto } from './dto/response/pallet.response.dto';
import { CreatePalletRequestDto } from './dto/request/create-pallet.request.dto';
import { UpdatePalletBodyRequestDto } from './dto/request/update-pallet.request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { ChangeStatusRequestDto } from '@utils/common.request.dto';
import { GetListPalletResponseDto } from './dto/response/get-list-pallet.response.dto';
import { GetListPalletRequestDto } from './dto/request/get-list-pallet.request.dto';
import {
  CONFIRM_PALLET_PERMISSION,
  CREATE_PALLET_PERMISSION,
  DELETE_PALLET_PERMISSION,
  DETAIL_PALLET_PERMISSION,
  LIST_PALLET_PERMISSION,
  REJECT_PALLET_PERMISSION,
  UPDATE_PALLET_PERMISSION,
} from '@utils/permissions/pallet';
import { GetPalletByIdsRequestDto } from './dto/request/get-pallet-by-ids.request.dto';

@Controller('pallets')
export class PalletController {
  constructor(
    @Inject('PalletServiceInterface')
    private readonly palletService: PalletServiceInterface,
  ) {}

  @PermissionCode(CREATE_PALLET_PERMISSION.code)
  @Post('/create')
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: PalletResponseDto,
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: PalletResponseDto,
  })
  @MessagePattern('create_pallet')
  public async createPallet(
    @Body() body: CreatePalletRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.palletService.createPallet(request);
  }

  @PermissionCode(UPDATE_PALLET_PERMISSION.code)
  @Put('/:id')
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: PalletResponseDto,
  })
  @MessagePattern('update_pallet')
  public async updatePallet(
    @Param('id', new ParseIntPipe()) id,
    @Body() body: UpdatePalletBodyRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.palletService.updatePallet({
      id,
      ...request,
    });
  }

  @PermissionCode(DELETE_PALLET_PERMISSION.code)
  @Delete('/:id')
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  @MessagePattern('delete_pallet')
  public async deletePallet(@Param('id', new ParseIntPipe()) id): Promise<any> {
    return await this.palletService.deletePallet(id);
  }

  @PermissionCode(DETAIL_PALLET_PERMISSION.code)
  @Get('/:id')
  @ApiResponse({
    status: 200,
    description: 'Detail successfully',
    type: PalletResponseDto,
  })
  @MessagePattern('detail_pallet')
  public async getPallet(@Param('id', new ParseIntPipe()) id): Promise<any> {
    return await this.palletService.getDetail(id);
  }

  @PermissionCode(LIST_PALLET_PERMISSION.code)
  @Get('/list')
  @ApiResponse({
    status: 200,
    description: 'List successfully',
    type: GetListPalletResponseDto,
  })
  @MessagePattern('list_pallet')
  public async getPallets(
    @Query() body: GetListPalletRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.palletService.getList(request);
  }

  @PermissionCode(CONFIRM_PALLET_PERMISSION.code)
  @Put('/:id/confirm')
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: PalletResponseDto,
  })
  @MessagePattern('confirm_pallet')
  public async confirmPallet(
    @Param() param: ChangeStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.palletService.confirmPallet(request);
  }

  @PermissionCode(REJECT_PALLET_PERMISSION.code)
  @Put(':id/reject')
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: PalletResponseDto,
  })
  @MessagePattern('reject_pallet')
  public async rejectPallet(
    @Param() param: ChangeStatusRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.palletService.rejectPallet(request);
  }

  // @MessagePattern('get_pallet_evenly')
  @Get('/:id/evenly')
  @ApiOperation({
    tags: ['Items'],
    summary: 'list pallet evenly',
    description: 'danh sách pallet chẵn theo item',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: PalletResponseDto,
  })
  public async getPalletEvenly(
    @Param('id', new ParseIntPipe()) itemId,
  ): Promise<any> {
    return await this.palletService.getPalletEvenly(itemId);
  }

  //TODO @manhlethe check new APIs
  /**
   *
   * @param body
   * @returns
   */
  @MessagePattern('get_pallet_by_ids')
  public async getPalletByIds(
    @Body() body: GetPalletByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.palletService.getPalletByIds(request.ids);
  }
}
