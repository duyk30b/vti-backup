export enum PalletStatusEnum {
  CREATED = 0,
  CONFIRM = 1,
  REJECT = 2,
}

export enum PalletTypeEnum {
  EVEN = 0,
  ODD = 1,
}

export const CAN_UPDATE_PALLET_STATUS: number[] = [
  PalletStatusEnum.CREATED,
  PalletStatusEnum.REJECT,
];

export const CAN_REJECT_PALLET_STATUS: number[] = [PalletStatusEnum.CREATED];

export const CAN_CONFIRM_PALLET_STATUS: number[] = [
  PalletStatusEnum.CREATED,
  PalletStatusEnum.REJECT,
];

export const CAN_DELETE_PALLET_STATUS: number[] = [
  PalletStatusEnum.CREATED,
  PalletStatusEnum.REJECT,
];
