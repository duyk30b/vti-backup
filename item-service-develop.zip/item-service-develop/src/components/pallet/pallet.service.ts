import { PagingResponse } from './../../utils/paging.response';
import { plainToInstance } from 'class-transformer';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Injectable, Inject } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { DataSource, ILike, In, Not } from 'typeorm';
import { compact, isEmpty, map, uniq } from 'lodash';
import { PalletServiceInterface } from './interface/pallet.service.interface';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { PalletRepositoryInterface } from './interface/pallet.repository.interface';
import { PalletDetailRepositoryInterface } from './interface/pallet-detail.repository.interface';
import { CreatePalletRequestDto } from './dto/request/create-pallet.request.dto';
import { UpdatePalletRequestDto } from './dto/request/update-pallet.request.dto';
import { GetListPalletRequestDto } from './dto/request/get-list-pallet.request.dto';
import {
  PalletResponse,
  PalletResponseDto,
} from './dto/response/pallet.response.dto';
import { GetListSuspendItemResponseDto } from '@components/suspend-item/dto/response/get-list-suspend-item.response.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { ChangeStatusRequestDto } from '@utils/common.request.dto';
import {
  CAN_CONFIRM_PALLET_STATUS,
  CAN_DELETE_PALLET_STATUS,
  CAN_REJECT_PALLET_STATUS,
  PalletStatusEnum,
  PalletTypeEnum,
} from './pallet.constant';
import { PackageRepositoryInterface } from '@components/package/interface/package.repository.interface';
import { BlockRepositoryInterface } from '@components/block/interface/block.repository.interface';
import { formatUnitMeasures, formatUnitWeight, plus } from '@utils/common';
import { ItemRepositoryInterface } from '@components/item/interface/item.repository.interface';
import { PalletEntity } from '@entities/pallet/pallet.entity';
import { PalletDetailEntity } from '@entities/pallet/pallet-detail.entity';
import { PalletEvenResponse } from './dto/response/pallet-even.response.dto';
import { GetPalletByIdsRequestDto } from './dto/request/get-pallet-by-ids.request.dto';

@Injectable()
export class PalletService implements PalletServiceInterface {
  constructor(
    @Inject('PalletRepositoryInterface')
    private readonly palletRepository: PalletRepositoryInterface,

    @Inject('PalletDetailRepositoryInterface')
    private readonly palletDetailRepository: PalletDetailRepositoryInterface,

    @Inject('PackageRepositoryInterface')
    private readonly packageRepository: PackageRepositoryInterface,

    @Inject('BlockRepositoryInterface')
    private readonly blockRepository: BlockRepositoryInterface,

    @Inject('ItemRepositoryInterface')
    private readonly itemRepository: ItemRepositoryInterface,

    private readonly i18n: I18nRequestScopeService,

    @InjectDataSource()
    private readonly connection: DataSource,
  ) {}

  async createPallet(
    request: CreatePalletRequestDto,
  ): Promise<ResponsePayload<any | PalletResponseDto>> {
    const { code } = request;
    const palletCodeExist = await this.palletRepository.findByCondition({
      code: ILike(code),
    });
    if (palletCodeExist) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_ALREADY_EXISTS'))
        .build();
    }

    return await this.save(request);
  }

  async updatePallet(
    request: UpdatePalletRequestDto,
  ): Promise<ResponsePayload<any | PalletResponseDto>> {
    const { code, id } = request;
    const pallet = await this.palletRepository.findOneById(id);
    if (!pallet) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PALLET_NOT_FOUND'))
        .build();
    }

    const palletCodeExist = await this.palletRepository.findByCondition({
      code: ILike(code),
      id: Not(id),
    });
    if (palletCodeExist) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CODE_ALREADY_EXISTS'))
        .build();
    }

    return await this.save(request, pallet);
  }

  async getDetail(
    id: number,
  ): Promise<ResponsePayload<any | PalletResponseDto>> {
    const pallet = await this.palletRepository.getDetail(id);
    if (!pallet) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PALLET_NOT_FOUND'))
        .build();
    }
    const dataReturn = plainToInstance(PalletResponse, pallet, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getList(
    request: GetListPalletRequestDto,
  ): Promise<ResponsePayload<any | GetListSuspendItemResponseDto>> {
    try {
      const { data, count } = await this.palletRepository.getList(request);
      const dataReturn = plainToInstance(PalletResponse, data, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder<PagingResponse>({
        items: dataReturn,
        meta: { total: count, page: request.page },
      })
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  async deletePallet(
    id: number,
  ): Promise<ResponsePayload<any | SuccessResponse>> {
    const pallet = await this.palletRepository.findOneById(id);
    if (!pallet) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PALLET_NOT_FOUND'))
        .build();
    }

    if (!CAN_DELETE_PALLET_STATUS.includes(pallet.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_INVALID'),
      ).toResponse();
    }

    try {
      await this.palletRepository.remove(id);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  async confirmPallet(
    request: ChangeStatusRequestDto,
  ): Promise<ResponsePayload<any | PalletResponseDto>> {
    const { id, userId } = request;
    const pallet = await this.palletRepository.findOneById(id);
    if (!pallet) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PALLET_NOT_FOUND'))
        .build();
    }

    if (!CAN_CONFIRM_PALLET_STATUS.includes(pallet.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_INVALID'),
      ).toResponse();
    }

    pallet.status = PalletStatusEnum.CONFIRM;
    pallet.approverId = userId;
    pallet.approvedAt = new Date(Date.now());

    try {
      const result = await this.palletRepository.create(pallet);

      const response = plainToInstance(PalletResponse, result, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  async rejectPallet(
    request: ChangeStatusRequestDto,
  ): Promise<ResponsePayload<any | PalletResponseDto>> {
    const { id, userId } = request;
    const pallet = await this.palletRepository.findOneById(id);
    if (!pallet) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.PALLET_NOT_FOUND'))
        .build();
    }

    if (!CAN_REJECT_PALLET_STATUS.includes(pallet.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.STATUS_INVALID'),
      ).toResponse();
    }

    pallet.status = PalletStatusEnum.REJECT;
    pallet.approverId = userId;
    pallet.approvedAt = new Date(Date.now());

    try {
      const result = await this.palletRepository.create(pallet);

      const response = plainToInstance(PalletResponse, result, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(response)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    }
  }

  private async save(request: any, pallet?: PalletEntity): Promise<any> {
    const isUpdate = request.id ? true : false;
    const { palletDetails, type } = request;

    const palletEntity = isUpdate
      ? await this.palletRepository.updateEntity(request, pallet)
      : await this.palletRepository.createEntity(request);

    const widthPallet = formatUnitMeasures(
      palletEntity.width.value,
      palletEntity.width.unit,
    );
    const heightPallet = formatUnitMeasures(
      palletEntity.height.value,
      palletEntity.height.unit,
    );
    const longPallet = formatUnitMeasures(
      palletEntity.long.value,
      palletEntity.long.unit,
    );
    const weightPallet = formatUnitWeight(
      palletEntity.weightLoad.value,
      palletEntity.weightLoad.unit,
    );

    if (type === PalletTypeEnum.EVEN) {
      const packageIds = compact(map(palletDetails, 'packageId'));
      const blockIds = compact(map(palletDetails, 'blockId'));

      if (
        !isEmpty(packageIds) &&
        packageIds.length !== uniq(packageIds).length
      ) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.DUPLICATE_PACKAGE'))
          .build();
      }

      if (!isEmpty(blockIds) && blockIds.length !== uniq(blockIds).length) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.DUPLICATE_BLOCK'))
          .build();
      }

      const [packages, blocks] = await Promise.all([
        this.packageRepository.findAllByCondition({
          id: In(packageIds),
        }),
        this.blockRepository.findAllByCondition({
          id: In(blockIds),
        }),
      ]);

      let totalPackageVolumn = 0;
      let totalPackageWeight = 0;
      let checkLongPackageExceedLongPallet = false;
      let checkWidthPackageExceedWidthPallet = false;
      let checkHeightPackageExceedHeightPallet = false;

      // validate long, width, height package
      if (!isEmpty(packages)) {
        for (let i = 0; i < packages.length; i++) {
          const record = packages[i];
          const widthPackage = formatUnitMeasures(
            record.width.value,
            record.width.unit,
          );
          const heightPackage = formatUnitMeasures(
            record.height.value,
            record.height.unit,
          );
          const longPackage = formatUnitMeasures(
            record.long.value,
            record.long.unit,
          );
          const weightPackage = formatUnitWeight(
            record.weight.value,
            record.weight.unit,
          );

          if (widthPackage > widthPallet) {
            checkWidthPackageExceedWidthPallet = true;
            break;
          }

          if (heightPackage > heightPallet) {
            checkHeightPackageExceedHeightPallet = true;
            break;
          }

          if (longPackage > longPallet) {
            checkLongPackageExceedLongPallet = true;
            break;
          }

          if (formatUnitMeasures(record.width.value, record.width.unit))
            totalPackageVolumn = plus(
              totalPackageVolumn,
              Number(record.volume.value),
            );
          totalPackageWeight = plus(totalPackageWeight, weightPackage);
        }
      }

      if (checkLongPackageExceedLongPallet)
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.PACKAGE_LONG_EXCEEDS_PALLET_LONG'),
          )
          .build();

      if (checkWidthPackageExceedWidthPallet)
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.PACKAGE_WIDTH_EXCEEDS_PALLET_WIDTH',
            ),
          )
          .build();

      if (checkHeightPackageExceedHeightPallet)
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.PACKAGE_HEIGHT_EXCEEDS_PALLET_HEIGHT',
            ),
          )
          .build();

      let totalBlockVolumn = 0;
      let totalBlockWeight = 0;
      let checkLongBlockExceedLongPallet = false;
      let checkWidthBlockExceedWidthPallet = false;
      let checkHeightBlockExceedHeightPallet = false;

      // validate long, width, height block
      if (!isEmpty(blocks)) {
        for (let i = 0; i < blocks.length; i++) {
          const record = blocks[i];

          const widthBlock = formatUnitMeasures(
            record.width.value,
            record.width.unit,
          );
          const heightBlock = formatUnitMeasures(
            record.height.value,
            record.height.unit,
          );
          const longBlock = formatUnitMeasures(
            record.long.value,
            record.long.unit,
          );
          const weightBlock = formatUnitWeight(
            record.weight.value,
            record.weight.unit,
          );

          if (widthBlock > widthPallet) {
            checkWidthBlockExceedWidthPallet = true;
            break;
          }

          if (heightBlock > heightPallet) {
            checkHeightBlockExceedHeightPallet = true;
            break;
          }

          if (longBlock > longPallet) {
            checkLongBlockExceedLongPallet = true;
            break;
          }

          totalBlockVolumn = plus(
            totalBlockVolumn,
            Number(record.volume.value),
          );
          totalBlockWeight = plus(totalBlockWeight, weightBlock);
        }
      }

      if (checkLongBlockExceedLongPallet)
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.BLOCK_LONG_EXCEEDS_PALLET_LONG'),
          )
          .build();

      if (checkWidthBlockExceedWidthPallet)
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.BLOCK_WIDTH_EXCEEDS_PALLET_WIDTH'),
          )
          .build();

      if (checkHeightBlockExceedHeightPallet)
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.BLOCK_HEIGHT_EXCEEDS_PALLET_HEIGHT',
            ),
          )
          .build();

      // validate total volume, total weight of block and package
      const totalVolumeRequest = plus(totalPackageVolumn, totalBlockVolumn);
      if (totalVolumeRequest > palletEntity.volume.value)
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.TOTAL_PACKAGE_BLOCK_VOLUME_EXCEEDS_PALLET_VOLUME',
            ),
          )
          .build();

      const totalWeightRequest = plus(totalPackageWeight, totalBlockWeight);
      if (totalWeightRequest > weightPallet)
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.TOTAL_PACKAGE_BLOCK_WEIGHT_EXCEEDS_PALLET_WEIGHT',
            ),
          )
          .build();
    } else {
      const itemIds = compact(map(palletDetails, 'itemId'));

      if (!isEmpty(itemIds) && itemIds.length !== uniq(itemIds).length) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(await this.i18n.translate('error.DUPLICATE_ITEM'))
          .build();
      }

      const items = await this.itemRepository.findAllByCondition({
        id: In(itemIds),
      });

      let totalItemVolumn = 0;
      let totalItemWeight = 0;
      let checkLongItemExceedLongPallet = false;
      let checkWidthItemExceedWidthPallet = false;
      let checkHeightItemExceedHeightPallet = false;

      // validate long, width, height item
      if (!isEmpty(items)) {
        for (let i = 0; i < items.length; i++) {
          const record = items[i];

          const widthItem = formatUnitMeasures(
            record.width.value,
            record.width.unit,
          );
          const heightItem = formatUnitMeasures(
            record.height.value,
            record.height.unit,
          );
          const longItem = formatUnitMeasures(
            record.long.value,
            record.long.unit,
          );
          const weightItem = formatUnitWeight(
            record.weight.value,
            record.weight.unit,
          );

          if (widthItem > widthPallet) {
            checkWidthItemExceedWidthPallet = true;
            break;
          }

          if (heightItem > heightPallet) {
            checkHeightItemExceedHeightPallet = true;
            break;
          }

          if (longItem > longPallet) {
            checkLongItemExceedLongPallet = true;
            break;
          }

          totalItemVolumn = plus(totalItemVolumn, Number(record.volume.value));
          totalItemWeight = plus(totalItemWeight, weightItem);
        }
      }

      if (checkLongItemExceedLongPallet)
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.ITEM_LONG_EXCEEDS_PALLET_LONG'),
          )
          .build();

      if (checkWidthItemExceedWidthPallet)
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('error.ITEM_WIDTH_EXCEEDS_PALLET_WIDTH'),
          )
          .build();

      if (checkHeightItemExceedHeightPallet)
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.ITEM_HEIGHT_EXCEEDS_PALLET_HEIGHT',
            ),
          )
          .build();

      // validate total volume, total weight of item
      if (totalItemVolumn > palletEntity.volume.value)
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.TOTAL_ITEM_VOLUME_EXCEEDS_PALLET_VOLUME',
            ),
          )
          .build();

      if (
        totalItemWeight >
        formatUnitWeight(
          palletEntity.weightLoad.value,
          palletEntity.weightLoad.unit,
        )
      )
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.TOTAL_ITEM_WEIGHT_EXCEEDS_PALLET_WEIGHT',
            ),
          )
          .build();
    }

    const queryRunner = await this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const pallet = await queryRunner.manager.save(palletEntity);

      if (isUpdate) {
        await queryRunner.manager.delete(PalletDetailEntity, {
          palletId: pallet.id,
        });
      }

      const palletDetailEntities = palletDetails.map((record) =>
        this.palletDetailRepository.createEntity({
          palletId: pallet.id,
          itemId: record.itemId ? record.itemId : null,
          packageId: record.packageId ? record.packageId : null,
          blockId: record.blockId ? record.blockId : null,
          quantity: record.quantity,
        }),
      );

      await queryRunner.manager.save(palletDetailEntities);

      await queryRunner.commitTransaction();
      return new ResponseBuilder(pallet)
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  async getPalletByIds(
    request: GetPalletByIdsRequestDto,
  ): Promise<ResponsePayload<any>> {
    const pallets = await this.palletRepository.getPalletByIds(request);
    return new ResponseBuilder(pallets)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async getPalletEvenly(itemId: number): Promise<any> {
    const packageEvens = await this.packageRepository.getPackageEvenlyByItem(
      itemId,
    );

    const packageIds = [];
    packageEvens.forEach((item) => {
      if (item.details.includes(itemId) && item.details.length === 1)
        packageIds.push(item.id);
    });

    const palletEvens = await this.palletRepository.getPalletEvenlyByItem(
      packageIds,
    );

    const dataReturn = plainToInstance(PalletEvenResponse, palletEvens, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
