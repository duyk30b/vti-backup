import { Block } from '@entities/block/block.entity';
import { Item } from '@entities/item/item.entity';
import { Package } from '@entities/package/package.entity';
import { PalletDetailEntity } from '@entities/pallet/pallet-detail.entity';
import { PalletEntity } from '@entities/pallet/pallet.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BlockRepository } from '@repositories/block.repository';
import { ItemRepository } from '@repositories/item.repository';
import { PackageRepository } from '@repositories/package.repository';
import { PalletDetailRepository } from '@repositories/pallet-detail.repository';
import { PalletRepository } from '@repositories/pallet.repository';
import { PalletController } from './pallet.controller';
import { PalletService } from './pallet.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      PalletEntity,
      PalletDetailEntity,
      Block,
      Package,
      Item,
    ]),
  ],
  exports: [],
  providers: [
    {
      provide: 'PalletRepositoryInterface',
      useClass: PalletRepository,
    },
    {
      provide: 'PalletDetailRepositoryInterface',
      useClass: PalletDetailRepository,
    },
    {
      provide: 'PackageRepositoryInterface',
      useClass: PackageRepository,
    },
    {
      provide: 'BlockRepositoryInterface',
      useClass: BlockRepository,
    },
    {
      provide: 'ItemRepositoryInterface',
      useClass: ItemRepository,
    },
    {
      provide: 'PalletServiceInterface',
      useClass: PalletService,
    },
  ],
  controllers: [PalletController],
})
export class PalletModule {}
