import { GetListSuspendItemResponseDto } from '@components/suspend-item/dto/response/get-list-suspend-item.response.dto';
import { ChangeStatusRequestDto } from '@utils/common.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { SuccessResponse } from '@utils/success.response.dto';
import { CreatePalletRequestDto } from '../dto/request/create-pallet.request.dto';
import { GetListPalletRequestDto } from '../dto/request/get-list-pallet.request.dto';
import { GetPalletByIdsRequestDto } from '../dto/request/get-pallet-by-ids.request.dto';
import { UpdatePalletRequestDto } from '../dto/request/update-pallet.request.dto';
import { PalletResponseDto } from '../dto/response/pallet.response.dto';

export interface PalletServiceInterface {
  createPallet(
    request: CreatePalletRequestDto,
  ): Promise<ResponsePayload<any | PalletResponseDto>>;

  updatePallet(
    request: UpdatePalletRequestDto,
  ): Promise<ResponsePayload<any | PalletResponseDto>>;

  getDetail(id: number): Promise<ResponsePayload<any | PalletResponseDto>>;

  getList(
    request: GetListPalletRequestDto,
  ): Promise<ResponsePayload<any | GetListSuspendItemResponseDto>>;

  deletePallet(id: number): Promise<ResponsePayload<any | SuccessResponse>>;

  confirmPallet(
    request: ChangeStatusRequestDto,
  ): Promise<ResponsePayload<any | PalletResponseDto>>;

  rejectPallet(
    request: ChangeStatusRequestDto,
  ): Promise<ResponsePayload<any | PalletResponseDto>>;

  getPalletByIds(
    request: GetPalletByIdsRequestDto,
  ): Promise<ResponsePayload<any>>;

  getPalletEvenly(itemId: number): Promise<any>;
}
