import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { PalletDetailEntity } from '@entities/pallet/pallet-detail.entity';

export interface PalletDetailRepositoryInterface
  extends BaseInterfaceRepository<PalletDetailEntity> {
  createEntity(request: any): PalletDetailEntity;
}
