import { GetPalletEvenlyByItemDto } from '@components/pallet/dto/request/get-pallet-evenly-by-item.dto';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { PalletEntity } from '@entities/pallet/pallet.entity';
import { CreatePalletRequestDto } from '../dto/request/create-pallet.request.dto';
import { GetListPalletRequestDto } from '../dto/request/get-list-pallet.request.dto';
import { GetPalletByIdsRequestDto } from '../dto/request/get-pallet-by-ids.request.dto';
import { UpdatePalletRequestDto } from '../dto/request/update-pallet.request.dto';

export interface PalletRepositoryInterface
  extends BaseInterfaceRepository<PalletEntity> {
  getDetail(id: number): Promise<any>;
  getList(request: GetListPalletRequestDto): Promise<any>;
  createEntity(request: CreatePalletRequestDto): Promise<PalletEntity>;
  updateEntity(
    request: UpdatePalletRequestDto,
    pallet: PalletEntity,
  ): Promise<PalletEntity>;
  getPalletEvenlyByItem(packageIds: number[]): Promise<any>;
  getPalletByIds(request: GetPalletByIdsRequestDto): Promise<any>;
}
