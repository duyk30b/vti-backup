import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Inject, Injectable } from '@nestjs/common';
import { ApiError } from '@utils/api.error';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { I18nService } from 'nestjs-i18n';
import { ILike, In, Not } from 'typeorm';
import { CreateManufacturingCountryRequestDto } from './dto/request/create-manufacturing-country.request.dto';
import { DetailManufacturingCountryRequestDto } from './dto/request/detail-manufacturing-country.request.dto';
import { GetListManufacturingCountryRequestDto } from './dto/request/get-list-manufacturing-country.request.dto';
import { UpdateManufacturingCountryRequestDto } from './dto/request/update-manufacturing-country.request.dto';
import { ManufacturingCountryResponseDto } from './dto/response/manufacturing-country,response';
import { ManufacturingCountryRepositoryInterface } from './interface/manufacturing-country.repository.interface';
import { ManufacturingCountryServiceInterface } from './interface/manufacturing-country.service.interface';
import { isEmpty, uniq, map } from 'lodash';
import { UserResponseDto } from '@components/object-category/dto/response/user.response.dto';
import { ResponsePayload } from '@utils/response-payload';
import {
  CONFIRMABLE_MANUFACTURING_COUNTRY_STATUSES,
  REJECTABLE_MANUFACTURING_COUNTRY_STATUSES,
  StatusManufacturingCountryEnum,
} from './manufacturing-country.constants';
import { GetManufacturingCountryByIdsRequestDto } from './dto/request/get-manufacturing-country-by-ids.request.dto';
@Injectable()
export class ManufacturingCountryService
  implements ManufacturingCountryServiceInterface
{
  constructor(
    @Inject('ManufacturingCountryRepositoryInterface')
    private readonly manufacturingCountryRepository: ManufacturingCountryRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    private readonly i18n: I18nService,
  ) {}

  async create(request: CreateManufacturingCountryRequestDto): Promise<any> {
    const { code, name } = request;
    const manufacturingCountryExist =
      await this.manufacturingCountryRepository.findByCondition([
        {
          code: ILike(code),
        },
      ]);
    if (manufacturingCountryExist) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate(
          'message.defineManufacturingCountry.codeAlreadyExists',
        ),
      ).toResponse();
    }
    const manufacturingCountryEntity =
      this.manufacturingCountryRepository.createEntity(request);

    const data = await this.manufacturingCountryRepository.create(
      manufacturingCountryEntity,
    );

    const response = plainToInstance(ManufacturingCountryResponseDto, data, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withMessage(
        await this.i18n.translate(
          'message.defineManufacturingCountry.createSuccess',
        ),
      )
      .build();
  }

  public async update(
    request: UpdateManufacturingCountryRequestDto,
  ): Promise<any> {
    const objectCategory =
      await this.manufacturingCountryRepository.findOneById(request.id);
    if (!objectCategory) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const isExistObjectCategory =
      await this.manufacturingCountryRepository.findByCondition([
        {
          name: request.name,
          id: Not(request.id),
        },
      ]);
    if (isExistObjectCategory) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.NAME_IS_EXISTED'),
      ).toResponse();
    }

    const result = this.manufacturingCountryRepository.updateEntity(
      objectCategory,
      request,
    );
    const dataReturn = await this.manufacturingCountryRepository.create(result);

    const response = plainToInstance(
      ManufacturingCountryResponseDto,
      dataReturn,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(
        await this.i18n.translate(
          'message.defineManufacturingCountry.updateSuccess',
        ),
      )
      .build();
  }

  public async getList(
    request: GetListManufacturingCountryRequestDto,
  ): Promise<any> {
    const { result, count } = await this.manufacturingCountryRepository.getList(
      request,
    );
    const userIds = uniq(map(result, 'createdBy'));
    if (!isEmpty(userIds)) {
      const userResponse = await this.userService.getUsers(userIds, true);
      result.forEach((user) => {
        user.createdBy = userResponse[user.createdBy];
      });
    }
    const response = plainToInstance(ManufacturingCountryResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async detail(
    request: DetailManufacturingCountryRequestDto,
  ): Promise<any> {
    const objectCategory = await this.manufacturingCountryRepository.detail(
      request,
    );
    if (!objectCategory) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const userIds = [objectCategory.createdBy, objectCategory.updatedBy];
    if (!isEmpty(userIds)) {
      const userResponse = await this.userService.getUsers(userIds, true);
      (objectCategory.createdBy = userResponse[objectCategory.createdBy]
        ? userResponse[objectCategory.createdBy]
        : {}),
        (objectCategory.updatedBy = userResponse[objectCategory.updatedBy]
          ? userResponse[objectCategory.updatedBy]
          : {});
    }
    const response = plainToInstance(
      ManufacturingCountryResponseDto,
      objectCategory,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  public async delete(
    request: DetailManufacturingCountryRequestDto,
  ): Promise<ResponsePayload<any>> {
    const objectCategory =
      await this.manufacturingCountryRepository.findByCondition({
        id: request.id,
        deletedAt: null,
      });
    if (!objectCategory) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    try {
      objectCategory.deletedAt = new Date();
      objectCategory.deletedBy = request.userId;
      await this.manufacturingCountryRepository.create(objectCategory);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(
          await this.i18n.translate(
            'message.defineManufacturingCountry.deleteSuccess',
          ),
        )
        .build();
    } catch (error) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_DELETE'),
      ).toResponse();
    }
  }

  public async confirm(
    request: DetailManufacturingCountryRequestDto,
  ): Promise<ResponsePayload<any>> {
    const manufactoringCountry =
      await this.manufacturingCountryRepository.findByCondition({
        id: request.id,
        deletedAt: null,
      });
    if (!manufactoringCountry) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (
      !CONFIRMABLE_MANUFACTURING_COUNTRY_STATUSES.includes(
        manufactoringCountry.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_CONFIRM'))
        .build();
    }

    try {
      manufactoringCountry.status = StatusManufacturingCountryEnum.ACTIVE;
      await this.manufacturingCountryRepository.create(manufactoringCountry);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('message.changeStatusSuccess'))
        .build();
    } catch (error) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_CONFIRM'),
      ).toResponse();
    }
  }

  public async reject(
    request: DetailManufacturingCountryRequestDto,
  ): Promise<ResponsePayload<any>> {
    const manufactoringCountry =
      await this.manufacturingCountryRepository.findByCondition({
        id: request.id,
        deletedAt: null,
      });
    if (!manufactoringCountry) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }

    if (
      !REJECTABLE_MANUFACTURING_COUNTRY_STATUSES.includes(
        manufactoringCountry.status,
      )
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_REJECT'))
        .build();
    }

    try {
      manufactoringCountry.status = StatusManufacturingCountryEnum.INACTIVE;
      await this.manufacturingCountryRepository.create(manufactoringCountry);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('message.changeStatusSuccess'))
        .build();
    } catch (error) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_REJECT'),
      ).toResponse();
    }
  }

  public async getManufacturingCountryByIds(
    request: GetManufacturingCountryByIdsRequestDto,
  ): Promise<ManufacturingCountryResponseDto[] | ResponsePayload<any>> {
    const result = await this.manufacturingCountryRepository.findAllByCondition(
      {
        id: In(request.manufacturingCountryIds),
      },
    );
    const response = plainToInstance(ManufacturingCountryResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }
}
