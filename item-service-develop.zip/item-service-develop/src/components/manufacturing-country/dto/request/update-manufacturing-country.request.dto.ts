import { ApiProperty } from '@nestjs/swagger';
import { IsInt } from 'class-validator';
import { Transform } from 'class-transformer';
import { CreateManufacturingCountryRequestDto } from './create-manufacturing-country.request.dto';
export class UpdateManufacturingCountryBodyDto extends CreateManufacturingCountryRequestDto {}
export class UpdateManufacturingCountryRequestDto extends UpdateManufacturingCountryBodyDto {
  @ApiProperty({ example: 1, description: 'Mã id manufacturing country' })
  @Transform((obj) => Number(obj.value))
  @IsInt()
  id: number;
}
