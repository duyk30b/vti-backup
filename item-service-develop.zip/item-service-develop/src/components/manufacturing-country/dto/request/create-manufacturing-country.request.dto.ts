import { IsString, MaxLength, IsOptional } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {} from 'class-transformer';
import { RULES_MANUFACTURING_COUNTRY_CONSTANTS } from '@components/manufacturing-country/manufacturing-country.constants';

export class CreateManufacturingCountryRequestDto extends BaseDto {
  @ApiProperty({ example: 'name: Euro' })
  @IsString()
  @MaxLength(RULES_MANUFACTURING_COUNTRY_CONSTANTS.NAME.MAX_LENGTH)
  name: string;

  @ApiProperty({ example: 'code:1111' })
  @IsString()
  @MaxLength(RULES_MANUFACTURING_COUNTRY_CONSTANTS.CODE.MAX_LENGTH)
  code: string;

  @ApiPropertyOptional({ example: 'description:abc' })
  @IsString()
  @IsOptional()
  @MaxLength(RULES_MANUFACTURING_COUNTRY_CONSTANTS.DESCRIPTION.MAX_LENGTH)
  description: string;
}
