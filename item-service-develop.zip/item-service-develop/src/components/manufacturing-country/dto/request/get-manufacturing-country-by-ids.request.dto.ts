import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { ArrayNotEmpty } from 'class-validator';

export class GetManufacturingCountryByIdsRequestDto extends BaseDto {
  @ApiProperty({ example: '1', description: '' })
  @ArrayNotEmpty()
  manufacturingCountryIds: number[];
}
