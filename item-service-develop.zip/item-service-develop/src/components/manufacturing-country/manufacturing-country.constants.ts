export const RULES_MANUFACTURING_COUNTRY_CONSTANTS = {
  NAME: {
    MAX_LENGTH: 50,
  },
  CODE: {
    MAX_LENGTH: 3,
  },
  DESCRIPTION: {
    MAX_LENGTH: 255,
  },
};
export enum StatusManufacturingCountryEnum {
  INACTIVE = 0,
  ACTIVE = 1,
}

export const CONFIRMABLE_MANUFACTURING_COUNTRY_STATUSES = [
  StatusManufacturingCountryEnum.INACTIVE,
];

export const REJECTABLE_MANUFACTURING_COUNTRY_STATUSES = [
  StatusManufacturingCountryEnum.ACTIVE,
];
