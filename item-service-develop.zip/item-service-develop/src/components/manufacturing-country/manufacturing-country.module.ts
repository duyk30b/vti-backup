import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { ManufacturingCountryEntity } from '@entities/manufacturing-country/manufacturing-country.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ManufacturingCountryRepository } from '@repositories/manufacturing-country.repository';
import { ManufacturingCountryController } from './manufacturing-country.controller';
import { ManufacturingCountryService } from './manufacturing-country.service';

@Module({
  imports: [TypeOrmModule.forFeature([ManufacturingCountryEntity]), UserModule],
  providers: [
    {
      provide: 'ManufacturingCountryServiceInterface',
      useClass: ManufacturingCountryService,
    },
    {
      provide: 'ManufacturingCountryRepositoryInterface',
      useClass: ManufacturingCountryRepository,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
  ],
  controllers: [ManufacturingCountryController],
})
export class ManufacturingCountryModule {}
