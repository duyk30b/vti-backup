import { BaseAbstractRepository } from '@core/repository/base.abstract.repository';
import { ManufacturingCountryEntity } from '@entities/manufacturing-country/manufacturing-country.entity';
import { CreateManufacturingCountryRequestDto } from '../dto/request/create-manufacturing-country.request.dto';
import { DetailManufacturingCountryRequestDto } from '../dto/request/detail-manufacturing-country.request.dto';
import { GetListManufacturingCountryRequestDto } from '../dto/request/get-list-manufacturing-country.request.dto';
import { UpdateManufacturingCountryRequestDto } from '../dto/request/update-manufacturing-country.request.dto';

export interface ManufacturingCountryRepositoryInterface
  extends BaseAbstractRepository<ManufacturingCountryEntity> {
  createEntity(
    request: CreateManufacturingCountryRequestDto,
  ): ManufacturingCountryEntity;
  getList(request: GetListManufacturingCountryRequestDto): Promise<any>;
  detail(request: DetailManufacturingCountryRequestDto): Promise<any>;
  updateEntity(
    manufacturingCountry: ManufacturingCountryEntity,
    request: UpdateManufacturingCountryRequestDto,
  ): ManufacturingCountryEntity;
}
