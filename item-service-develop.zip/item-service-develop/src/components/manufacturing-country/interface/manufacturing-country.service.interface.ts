import { ResponsePayload } from '@utils/response-payload';
import { CreateManufacturingCountryRequestDto } from '../dto/request/create-manufacturing-country.request.dto';
import { DetailManufacturingCountryRequestDto } from '../dto/request/detail-manufacturing-country.request.dto';
import { GetListManufacturingCountryRequestDto } from '../dto/request/get-list-manufacturing-country.request.dto';
import { GetManufacturingCountryByIdsRequestDto } from '../dto/request/get-manufacturing-country-by-ids.request.dto';
import { UpdateManufacturingCountryRequestDto } from '../dto/request/update-manufacturing-country.request.dto';
import { ManufacturingCountryResponseDto } from '../dto/response/manufacturing-country,response';

export interface ManufacturingCountryServiceInterface {
  create(request: CreateManufacturingCountryRequestDto): Promise<any>;
  update(request: UpdateManufacturingCountryRequestDto): Promise<any>;
  getList(request: GetListManufacturingCountryRequestDto): Promise<any>;
  detail(request: DetailManufacturingCountryRequestDto): Promise<any>;
  delete(
    request: DetailManufacturingCountryRequestDto,
  ): Promise<ResponsePayload<any>>;
  confirm(request: DetailManufacturingCountryRequestDto): Promise<any>;
  reject(request: DetailManufacturingCountryRequestDto): Promise<any>;
  getManufacturingCountryByIds(
    request: GetManufacturingCountryByIdsRequestDto,
  ): Promise<ManufacturingCountryResponseDto[] | ResponsePayload<any>>;
}
