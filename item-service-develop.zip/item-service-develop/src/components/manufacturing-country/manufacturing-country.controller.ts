import { GetManufacturingCountryByIdsRequestDto } from './dto/request/get-manufacturing-country-by-ids.request.dto';
import {
  LIST_MANUFACTURING_COUNTRY_PERMISSION,
  CREATE_MANUFACTURING_COUNTRY_PERMISSION,
  DETAIL_MANUFACTURING_COUNTRY_PERMISSION,
  UPDATE_MANUFACTURING_COUNTRY_PERMISSION,
  DELETE_MANUFACTURING_COUNTRY_PERMISSION,
  CONFIRM_MANUFACTURING_COUNTRY_PERMISSION,
  REJECT_MANUFACTURING_COUNTRY_PERMISSION,
} from '@utils/permissions/manufacturing-country';
import { DetailManufacturingCountryRequestDto } from './dto/request/detail-manufacturing-country.request.dto';
import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { CreateManufacturingCountryRequestDto } from './dto/request/create-manufacturing-country.request.dto';
import { ManufacturingCountryResponseDto } from './dto/response/manufacturing-country,response';
import { ManufacturingCountryServiceInterface } from './interface/manufacturing-country.service.interface';
import { isEmpty } from 'lodash';
import { GetListManufacturingCountryRequestDto } from './dto/request/get-list-manufacturing-country.request.dto';
import { UpdateManufacturingCountryBodyDto } from './dto/request/update-manufacturing-country.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { MessagePattern } from '@nestjs/microservices';
@Controller('manufacturing-countries')
export class ManufacturingCountryController {
  constructor(
    @Inject('ManufacturingCountryServiceInterface')
    private readonly manufacturingCountryService: ManufacturingCountryServiceInterface,
  ) {}

  @PermissionCode(CREATE_MANUFACTURING_COUNTRY_PERMISSION.code)
  @Post('/create')
  @ApiOperation({
    tags: ['[Items],[Manufacturing Country]'],
    summary: 'Create manufacturing country',
    description: 'Định nghĩa nước sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ManufacturingCountryResponseDto,
  })
  public async create(
    @Body() body: CreateManufacturingCountryRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.manufacturingCountryService.create(request);
  }

  // @PermissionCode(LIST_MANUFACTURING_COUNTRY_PERMISSION.code)
  @Get('/list')
  @ApiOperation({
    tags: ['[Items],[Manufacturing Country]'],
    summary: 'Get List Manufacturing Country',
    description: 'Danh sách nước sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ManufacturingCountryResponseDto,
  })
  async getList(
    @Query() payload: GetListManufacturingCountryRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingCountryService.getList(request);
  }

  @PermissionCode(DETAIL_MANUFACTURING_COUNTRY_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['[Items],[Manufacturing Country]'],
    summary: 'Get Detail Manufacturing ',
    description: 'Chi tiết nước sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ManufacturingCountryResponseDto,
  })
  async detail(
    @Param() param: DetailManufacturingCountryRequestDto,
  ): Promise<any> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingCountryService.detail(request);
  }

  @PermissionCode(UPDATE_MANUFACTURING_COUNTRY_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['[Items],[Manufacturing Country]'],
    summary: 'Update manufacturing country',
    description: 'Sửa thông tin quốcgia sản suất',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ManufacturingCountryResponseDto,
  })
  async update(
    @Body() body: UpdateManufacturingCountryBodyDto,
    @Param('id', new ParseIntPipe()) id: number,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    request.id = id;
    return await this.manufacturingCountryService.update(request);
  }

  @PermissionCode(DELETE_MANUFACTURING_COUNTRY_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['[Items],[Manufacturing Country]'],
    summary: 'Delete manufacturing country',
    description: 'Xóa nước sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: ManufacturingCountryResponseDto,
  })
  public async delete(
    @Param() param: DetailManufacturingCountryRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingCountryService.delete(request);
  }

  @PermissionCode(CONFIRM_MANUFACTURING_COUNTRY_PERMISSION.code)
  @Put('/:id/confirm')
  @ApiOperation({
    tags: ['[Items],[Manufacturing Country]'],
    summary: 'Confirm manufacturing country',
    description: 'Xác nhận nước sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ManufacturingCountryResponseDto,
  })
  public async confirm(
    @Param() param: DetailManufacturingCountryRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingCountryService.confirm(request);
  }

  @PermissionCode(REJECT_MANUFACTURING_COUNTRY_PERMISSION.code)
  @Put('/:id/reject')
  @ApiOperation({
    tags: ['[Items],[Manufacturing Country]'],
    summary: 'Reject manufacturing country',
    description: 'Xóa nước sản xuất',
  })
  @ApiResponse({
    status: 200,
    description: 'Reject successfully',
    type: ManufacturingCountryResponseDto,
  })
  public async reject(
    @Param() param: DetailManufacturingCountryRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingCountryService.reject(request);
  }

  @MessagePattern('get_manufacturing_country_by_ids')
  public async getManufacturingCountryByIds(
    @Body() payload: GetManufacturingCountryByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.manufacturingCountryService.getManufacturingCountryByIds(
      request,
    );
  }
}
