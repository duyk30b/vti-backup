import { CompanyDefaultResponseDto } from '../dto/response/company-default.response.dto';

export interface UserServiceInterface {
  getUsers(userIds: number[], serilize?: boolean): Promise<any>;
  getDepartmentIds(request): Promise<any>;
  getUserRoleDepartment(request): Promise<any>;
  checkUserPermission(request): Promise<any>;
  insertPermission(permissions): Promise<any>;
  deletePermissionNotActive(): Promise<any>;
  getUserById(id: number): Promise<any>;
  getCompanyDefault(): Promise<CompanyDefaultResponseDto | any>;
}
