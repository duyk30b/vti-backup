import { Inject, Injectable } from '@nestjs/common';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { ClientProxy } from '@nestjs/microservices';
import { GetDepartmentIdsRequestDto } from '@components/user/dto/request/check-user-permission.request.dto';
import { GetUserRoleDepartmentRequestDto } from '@components/user/dto/request/get-department-ids.request.dto';
import { CheckUserPermissionRequestDto } from '@components/user/dto/request/get-user-role-department.request.dto';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { UserResponseDto } from './dto/response/user.response.dto';
import { plainToInstance } from 'class-transformer';
import { CompanyDefaultResponseDto } from './dto/response/company-default.response.dto';

@Injectable()
export class UserService implements UserServiceInterface {
  constructor(
    @Inject('USER_SERVICE_CLIENT')
    private readonly userServiceClient: ClientProxy,
  ) {}

  async getDepartmentIds(request: GetDepartmentIdsRequestDto): Promise<any> {
    const idResponse = await this.userServiceClient
      .send('get_department_ids', request)
      .toPromise();
    return idResponse.data;
  }

  async getUserRoleDepartment(
    request: GetUserRoleDepartmentRequestDto,
  ): Promise<any> {
    const response = await this.userServiceClient
      .send('get_user_role_department', request)
      .toPromise();
    return response.data;
  }

  async checkUserPermission(
    request: CheckUserPermissionRequestDto,
  ): Promise<any> {
    const response = await this.userServiceClient
      .send('check_user_permission', request)
      .toPromise();
    return response.data;
  }

  public async insertPermission(permissions): Promise<any> {
    return await this.userServiceClient
      .send('insert_permission', permissions)
      .toPromise();
  }

  public async deletePermissionNotActive(): Promise<any> {
    return await this.userServiceClient
      .send('delete_permission_not_active', {})
      .toPromise();
  }

  public async getUserById(id: number): Promise<any> {
    const result = await this.userServiceClient
      .send('detail', { id: id })
      .toPromise();
    if (result.statusCode !== ResponseCodeEnum.SUCCESS) return {};
    return result.data;
  }

  async getUsers(userIds: number[], serilize?: boolean): Promise<any> {
    const response = await this.userServiceClient
      .send('get_users_by_ids', {
        userIds: userIds,
      })
      .toPromise();
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return [];

    const dataReturn = plainToInstance(UserResponseDto, <any[]>response.data, {
      excludeExtraneousValues: true,
    });
    const serilizeUsers = {};
    if (serilize) {
      response.data.forEach((user) => {
        serilizeUsers[user.id] = user;
      });

      return serilizeUsers;
    }
    return dataReturn;
  }

  public async getCompanyDefault(): Promise<CompanyDefaultResponseDto | any> {
    const result = await this.userServiceClient
      .send('get_company_default', {})
      .toPromise();
    if (result.statusCode !== ResponseCodeEnum.SUCCESS) return {};

    const dataReturn = plainToInstance(CompanyDefaultResponseDto, result.data);
    return dataReturn;
  }
}
