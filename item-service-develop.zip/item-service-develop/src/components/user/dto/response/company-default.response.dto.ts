import { Expose } from 'class-transformer';
import { BasicResponseDto } from './basic-response.dto';

export class CompanyDefaultResponseDto extends BasicResponseDto {
  @Expose()
  address: string;
}
