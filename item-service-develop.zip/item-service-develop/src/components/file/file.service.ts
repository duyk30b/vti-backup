import { ConfigService } from '@config/config.service';
import { APIPrefix } from '@constant/common';
import { HttpClientService } from '@core/components/http-client/http-client.service';
import { Inject, Injectable } from '@nestjs/common';
import * as FormData from 'form-data';
import {
  SERVICE_UPLOAD,
  UPLOAD_FILE_ENPOINT,
} from './constant/file-upload.constant';
import { FileServiceInterface } from './interface/file.service.interface';

@Injectable()
export class FileService implements FileServiceInterface {
  protected readonly urlConfig: any;
  protected readonly url: string;

  constructor(
    @Inject('ConfigServiceInterface')
    private readonly configService: ConfigService,
    private readonly httpClientService: HttpClientService,
  ) {
    this.configService = new ConfigService();
    this.urlConfig = this.configService.get('fileService');
    this.url = `http://${
      this.urlConfig?.options?.host + ':' + this.urlConfig?.options?.port
    }`;
  }

  async uploadFiles(files: any[], resource: string): Promise<any> {
    const form = new FormData();
    form.append('service', SERVICE_UPLOAD);
    form.append('resource', resource);
    files.forEach((file) => {
      form.append('files', Buffer.from(file.data), {
        filename: file.filename,
      });
    });

    return await this.httpClientService.post(
      this.generateUrlFileService(UPLOAD_FILE_ENPOINT.MULTIPLE),
      form,
      {
        ...form.getHeaders(),
      },
    );
  }

  async uploadFile(file: any, resource: string): Promise<any> {
    const form = new FormData();
    form.append('service', 'item');
    form.append('resource', resource);
    form.append('files', Buffer.from(file.data), {
      filename: file.filename,
    });

    return await this.httpClientService.post(
      this.generateUrlFileService(UPLOAD_FILE_ENPOINT.SINGLE),
      form,
      {
        ...form.getHeaders(),
      },
    );
  }

  async getFilesByIds(ids: string[]): Promise<any> {
    const fileIds = ids.toString();
    return await this.httpClientService.get(
      this.generateUrlFileService(UPLOAD_FILE_ENPOINT.INFO),
      {
        ids: fileIds,
      },
    );
  }

  private generateUrlFileService(type: string): string {
    return `${this.url}/${APIPrefix.Version}/${type}`;
  }
}
