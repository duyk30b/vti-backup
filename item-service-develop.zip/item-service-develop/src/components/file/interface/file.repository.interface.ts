import { FileEntity } from '@entities/file/file.entity';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';

export interface FileRepositoryInterface
  extends BaseInterfaceRepository<FileEntity> {
  createEntity(data: any): FileEntity;
}
