import { APIPrefix } from '@constant/common';

export const FileResource = {
  POI: 'POI',
  ITEM: 'ITEM',
  ITEM_INFO: 'ITEM_INFO',
};

export const SERVICE_UPLOAD = 'items';

export const UPLOAD_FILE_ENPOINT = {
  MULTIPLE: 'files/multiple-files',
  SINGLE: 'files/single-file',
  INFO: 'files/info',
};
