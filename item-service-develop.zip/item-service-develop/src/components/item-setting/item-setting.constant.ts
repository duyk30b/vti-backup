export enum ItemUnitStatusEnum {
  CREATED = 0,
  CONFIRMED = 1,
  REJECT = 2,
}

export enum ItemTypeStatusEnum {
  CREATED = 0,
  CONFIRMED = 1,
  REJECT = 2,
}

export enum ItemGroupStatusEnum {
  CREATED = 0,
  CONFIRMED = 1,
  REJECT = 2,
}

export const CAN_UPDATE_ITEM_GROUP_STATUS: number[] = [
  ItemGroupStatusEnum.CREATED,
  ItemGroupStatusEnum.REJECT,
];

export const CAN_DELETE_ITEM_GROUP_STATUS: number[] = [
  ItemGroupStatusEnum.CREATED,
  ItemGroupStatusEnum.REJECT,
];

export const CAN_UPDATE_ITEM_UNIT_STATUS: number[] = [
  ItemUnitStatusEnum.CREATED,
  ItemUnitStatusEnum.REJECT,
];

export const CAN_DELETE_ITEM_UNIT_STATUS: number[] = [
  ItemUnitStatusEnum.CREATED,
  ItemUnitStatusEnum.REJECT,
];

export const CAN_UPDATE_ITEM_TYPE_STATUS: number[] = [
  ItemTypeStatusEnum.CREATED,
  ItemTypeStatusEnum.REJECT,
];

export const CAN_DELETE_ITEM_TYPE_STATUS: number[] = [
  ItemTypeStatusEnum.CREATED,
  ItemTypeStatusEnum.REJECT,
];
