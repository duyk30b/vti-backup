import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { ArrayNotEmpty } from 'class-validator';

export class GetListItemUnitByIdsRequestDto extends BaseDto {
  @ApiProperty({ example: 'unitIds:1' })
  @ArrayNotEmpty()
  unitIds: number[];
}
