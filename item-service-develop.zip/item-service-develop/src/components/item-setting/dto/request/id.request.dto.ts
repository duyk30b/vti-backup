import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsNotEmpty } from 'class-validator';
import { BaseDto } from '@core/dto/base.dto';
import { Type } from 'class-transformer';

export class DeleteItemGroupSettingRequest extends BaseDto {}
export class IdRequestDto extends DeleteItemGroupSettingRequest {
  @ApiProperty({ example: 'item unit', description: '' })
  @IsNotEmpty()
  @Type(() => Number)
  @IsNumber()
  id: number;
}
