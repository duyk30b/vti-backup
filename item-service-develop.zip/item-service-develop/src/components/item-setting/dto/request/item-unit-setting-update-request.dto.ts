import { ApiProperty } from '@nestjs/swagger';
import { ItemUnitSettingRequestDto } from '@components/item-setting/dto/request/item-unit-setting-request.dto';
import { IsInt, IsNotEmpty } from 'class-validator';

export class ItemUnitSettingUpdateBodyDto extends ItemUnitSettingRequestDto {}
export class ItemUnitSettingUpdateRequestDto extends ItemUnitSettingUpdateBodyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;
}
