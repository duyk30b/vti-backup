import { ItemTypeSettingRequestDto } from '@components/item-setting/dto/request/item-type-setting-request.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty } from 'class-validator';

export class ItemTypeSettingUpdateBodyRequestDto extends ItemTypeSettingRequestDto {}
export class ItemTypeSettingUpdateRequestDto extends ItemTypeSettingUpdateBodyRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;
}
