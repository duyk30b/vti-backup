import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { ArrayNotEmpty } from 'class-validator';
import { isJson } from 'src/helper/string.helper';

export class GetItemTypeSettiingByIdsRequestDto extends BaseDto {
  @ApiProperty({ example: 'ids:[1,2,4' })
  @ArrayNotEmpty()
  @Transform(({ value }) => {
    if (typeof value !== 'string') return value;
    if (value) value = value.replace(/\\/g, '');

    if (isJson(value)) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    }
  })
  itemTypeSettingIds: number[];
}
