import { SuccessResponse } from '@components/item-setting/dto/response/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { ItemTypeSettingResponseDto } from '@components/item-setting/dto/response/item-type-setting-response.dto';

class Meta {
  @Expose()
  total: number;
}

class MetaData {
  @Expose()
  data: ItemTypeSettingResponseDto[];

  @Expose()
  meta: Meta;
}

export class GetListItemTypeSettingResponseDto extends SuccessResponse {
  @ApiProperty({
    example: {
      items: [
        {
          id: 1,
          name: 'Item type 1',
          description: 'Item type 1',
          createdAt: '2021-07-14T02:48:36.864Z',
          updatedAt: '2021-07-14T02:48:36.864Z',
        },
        {
          id: 2,
          name: 'Item type 2',
          description: 'Item type 2',
          createdAt: '2021-07-14T02:48:36.864Z',
          updatedAt: '2021-07-14T02:48:36.864Z',
        },
      ],
      meta: {
        total: 3,
      },
    },
  })
  @Expose()
  data: MetaData;
}
