import { SuccessResponse } from '@components/item-setting/dto/response/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { ItemTypeSettingResponseDto } from '@components/item-setting/dto/response/item-type-setting-response.dto';

class Meta {
  @Expose()
  total: number;
}

class MetaData {
  @Expose()
  data: ItemTypeSettingResponseDto[];

  @Expose()
  meta: Meta;
}

export class GetListItemUnitSettingResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: MetaData;
}
