import { Expose } from 'class-transformer';

export class DeleteSuccessResponseDto {
  @Expose()
  id: number;
}
