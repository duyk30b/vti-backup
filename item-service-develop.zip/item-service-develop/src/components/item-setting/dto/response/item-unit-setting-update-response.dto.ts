import { Expose } from 'class-transformer';
import { ItemUnitSettingResponseDto } from '@components/item-setting/dto/response/item-unit-setting-response.dto';

export class ItemUnitSettingUpdateResponseDto extends ItemUnitSettingResponseDto {
  @Expose()
  createdAt: Date;

  @Expose()
  updatedAt: Date;
}
