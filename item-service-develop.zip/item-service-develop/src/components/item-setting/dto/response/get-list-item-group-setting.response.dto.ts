import { SuccessResponse } from '@components/item-setting/dto/response/success.response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { ItemGroupSettingResponseDto } from '@components/item/dto/response/item-group-setting.response.dto';

class Meta {
  @Expose()
  total: number;
}

class MetaData {
  @Expose()
  data: ItemGroupSettingResponseDto[];

  @Expose()
  meta: Meta;
}

export class GetListItemGroupSettingResponseDto extends SuccessResponse {
  @ApiProperty()
  @Expose()
  data: MetaData;
}
