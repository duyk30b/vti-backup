import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ItemUnitSetting } from '@entities/item/item-unit-setting.entity';
import { ItemUnitSettingRepository } from '@repositories/item-unit-setting.repository';
import { ItemSettingController } from '@components/item-setting/item-setting.controller';
import { ItemSettingService } from '@components/item-setting/item-setting.service';
import { ItemTypeSettingRepository } from '@repositories/item-type-setting.repository';
import { ItemTypeSetting } from '@entities/item/item-type-setting.entity';
import { ItemGroupSettingRepository } from '@repositories/item-group-setting.repository';
import { ItemGroupSetting } from '@entities/item/item-group-setting.entity';
import { ItemRepository } from '@repositories/item.repository';
import { Item } from '@entities/item/item.entity';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { ItemTypeSettingImport } from './import/item-type-setting.import.helper';
import { ItemGroupSettingImport } from './import/item-group-setting.import.helper';
import { ItemUnitSettingImport } from './import/item-unit-setting.import.helper';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      // ProfileItem,
      ItemUnitSetting,
      ItemTypeSetting,
      ItemGroupSetting,
      Item,
    ]),
    UserModule,
  ],
  providers: [
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'ItemTypeSettingImport',
      useClass: ItemTypeSettingImport,
    },
    {
      provide: 'ItemUnitSettingImport',
      useClass: ItemUnitSettingImport,
    },
    {
      provide: 'ItemGroupSettingImport',
      useClass: ItemGroupSettingImport,
    },
    {
      provide: 'ItemUnitSettingRepositoryInterface',
      useClass: ItemUnitSettingRepository,
    },
    {
      provide: 'ItemGroupSettingRepositoryInterface',
      useClass: ItemGroupSettingRepository,
    },
    // {
    //   provide: 'ProfileItemRepositoryInterface',
    //   useClass: ProfileItemRepository,
    // },
    {
      provide: 'ItemTypeSettingRepositoryInterface',
      useClass: ItemTypeSettingRepository,
    },
    {
      provide: 'ItemRepositoryInterface',
      useClass: ItemRepository,
    },
    {
      provide: 'ItemSettingServiceInterface',
      useClass: ItemSettingService,
    },
  ],
  controllers: [ItemSettingController],
})
export class ItemSettingModule {}
