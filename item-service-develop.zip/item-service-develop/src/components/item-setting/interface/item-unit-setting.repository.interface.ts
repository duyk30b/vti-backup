import { ItemUnitSetting } from '@entities/item/item-unit-setting.entity';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { GetListItemUnitSettingRequestDto } from '@components/item-setting/dto/request/get-list-item-unit-setting.request.dto';

export interface ItemUnitSettingRepositoryInterface
  extends BaseInterfaceRepository<ItemUnitSetting> {
  getAllItemUnitSetting(request: any): Promise<any>;
  getItemUnitDetail(request: any): Promise<any>;
  getList(request: GetListItemUnitSettingRequestDto): Promise<any>;
  createEntity(data: any): ItemUnitSetting;
  updateEntity(id: number, data: any): ItemUnitSetting;
  getCount(): Promise<any>;
}
