import { ItemUnitSettingRequestDto } from '@components/item-setting/dto/request/item-unit-setting-request.dto';
import { ItemUnitSettingUpdateRequestDto } from '@components/item-setting/dto/request/item-unit-setting-update-request.dto';
import { ItemTypeSettingRequestDto } from '@components/item-setting/dto/request/item-type-setting-request.dto';
import { ItemTypeSettingUpdateRequestDto } from '@components/item-setting/dto/request/item-type-setting-update-request.dto';
import { ItemGroupSettingRequestDto } from '@components/item/dto/request/item-group-setting-request.dto';
import { UpdateItemGroupSettingRequestDto } from '@components/item/dto/request/update-item-group-setting-request.dto';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { SetStatusRequestDto } from '../dto/request/set-status.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { ItemGroupSettingResponseDto } from '@components/item/dto/response/item-group-setting.response.dto';
import { ItemTypeSettingResponseDto } from '../dto/response/item-type-setting-response.dto';
import { ItemUnitSettingResponseDto } from '../dto/response/item-unit-setting-response.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { IdRequestDto } from '../dto/request/id.request.dto';
import { GetItemTypeSettiingByIdsRequestDto } from '../dto/request/get-item-type-setting-by-ids.request.dto';
import { GetListItemUnitByIdsRequestDto } from '../dto/request/get-list-item-unit-by-ids.request.dto';

export interface ItemSettingServiceInterface {
  importItemUnitSetting(request: FileUpdloadRequestDto): Promise<any>;
  createItemUnitSetting(request: ItemUnitSettingRequestDto): Promise<any>;
  updateItemUnitSetting(request: ItemUnitSettingUpdateRequestDto): Promise<any>;
  getListItemUnitSetting(request: any): Promise<any>;
  deleteItemUnitSetting(id: number): Promise<any>;
  deleteMultipleItemUnitSetting(request: DeleteMultipleDto): Promise<any>;
  getItemUnitSettingDetail(id: number): Promise<any>;

  importItemTypeSetting(request: FileUpdloadRequestDto): Promise<any>;
  createItemTypeSetting(request: ItemTypeSettingRequestDto): Promise<any>;
  updateItemTypeSetting(request: ItemTypeSettingUpdateRequestDto): Promise<any>;
  deleteItemTypeSetting(id: number): Promise<any>;
  deleteMultipleItemTypeSetting(request: DeleteMultipleDto): Promise<any>;
  getListItemTypeSetting(request: any): Promise<any>;
  getItemTypeSettingDetail(
    request: ItemTypeSettingUpdateRequestDto,
  ): Promise<any>;

  importItemGroupSetting(request: FileUpdloadRequestDto): Promise<any>;
  createItemGroupSetting(request: ItemGroupSettingRequestDto): Promise<any>;
  updateItemGroupSetting(
    request: UpdateItemGroupSettingRequestDto,
  ): Promise<any>;
  getListItemGroupSetting(request: any): Promise<any>;
  deleteItemGroupSetting(id: number): Promise<any>;
  deleteMultipleItemGroupSetting(request: DeleteMultipleDto): Promise<any>;
  getItemGroupSettingDetail(request: IdRequestDto): Promise<any>;
  confirmItemGroup(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<ItemGroupSettingResponseDto | any>>;
  rejectItemGroup(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<ItemGroupSettingResponseDto | any>>;
  confirmItemType(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<ItemTypeSettingResponseDto | any>>;
  rejectItemType(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<ItemTypeSettingResponseDto | any>>;
  confirmItemUnit(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<ItemUnitSettingResponseDto | any>>;
  rejectItemUnit(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<ItemUnitSettingResponseDto | any>>;
  getItemUnitSettingByIds(
    request: GetListItemUnitByIdsRequestDto,
  ): Promise<ItemUnitSettingResponseDto[] | ResponsePayload<any>>;
  getItemTypeSettingByIds(
    request: GetItemTypeSettiingByIdsRequestDto,
  ): Promise<ItemTypeSettingResponseDto[] | ResponsePayload<any>>;
}
