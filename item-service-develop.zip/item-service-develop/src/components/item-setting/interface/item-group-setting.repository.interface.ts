import { ItemGroupSetting } from '@entities/item/item-group-setting.entity';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { GetListItemGroupSettingRequestDto } from '@components/item/dto/request/get-list-item-group-setting.request.dto';
import { ItemStockByItemGroupQueryDto } from '@components/item/dto/request/item-stock-by-item-group.query.dto';
import { ItemStockByItemGroupResponse } from '@components/item/dto/response/item-stock-by-item-group.response.dto';

export interface ItemGroupSettingRepositoryInterface
  extends BaseInterfaceRepository<ItemGroupSetting> {
  checkUniqueItem(name: string, code: number): Promise<any>;
  getAllItemGroupSetting(request: any): Promise<any>;
  checkCode(input: any): Promise<any>;
  getList(input: GetListItemGroupSettingRequestDto): Promise<any>;
  itemStockByItemGroupSummary(
    request: ItemStockByItemGroupQueryDto,
  ): Promise<ItemStockByItemGroupResponse[]>;

  createEntity(data: any): ItemGroupSetting;
  updateEntity(id: number, data: any): ItemGroupSetting;
  getCount(): Promise<any>;
}
