import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Req,
} from '@nestjs/common';
import { ItemSettingServiceInterface } from '@components/item-setting/interface/item-setting.service.interface';
import { MessagePattern } from '@nestjs/microservices';
import { ItemUnitSettingRequestDto } from '@components/item-setting/dto/request/item-unit-setting-request.dto';
import { isEmpty } from 'lodash';
import {
  ItemUnitSettingUpdateBodyDto,
  ItemUnitSettingUpdateRequestDto,
} from '@components/item-setting/dto/request/item-unit-setting-update-request.dto';
import { ItemTypeSettingRequestDto } from '@components/item-setting/dto/request/item-type-setting-request.dto';
import { GetListItemTypeSettingRequestDto } from '@components/item-setting/dto/request/get-list-item-type-setting.request.dto';
import { GetListItemTypeSettingResponseDto } from '@components/item-setting/dto/response/get-list-item-type-setting.response.dto';
import { GetListItemUnitSettingRequestDto } from '@components/item-setting/dto/request/get-list-item-unit-setting.request.dto';
import { GetListItemUnitSettingResponseDto } from '@components/item-setting/dto/response/get-list-item-unit-setting.response.dto';
import {
  UpdateItemGroupSettingBodyDto,
  UpdateItemGroupSettingRequestDto,
} from '@components/item/dto/request/update-item-group-setting-request.dto';
import {
  DeleteItemGroupSettingRequest,
  IdRequestDto,
} from '@components/item-setting/dto/request/id.request.dto';
import { GetListItemGroupSettingRequestDto } from '@components/item/dto/request/get-list-item-group-setting.request.dto';
import { GetListItemGroupSettingResponseDto } from '@components/item-setting/dto/response/get-list-item-group-setting.response.dto';
import { PermissionCode } from '@core/decorator/get-code.decorator';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import {
  CREATE_ITEM_UNIT_PERMISSION,
  UPDATE_ITEM_UNIT_PERMISSION,
  DELETE_ITEM_UNIT_PERMISSION,
  DETAIL_ITEM_UNIT_PERMISSION,
  LIST_ITEM_UNIT_PERMISSION,
  IMPORT_ITEM_UNIT_PERMISSION,
} from '@utils/permissions/item-unit';

import {
  CREATE_ITEM_TYPE_PERMISSION,
  UPDATE_ITEM_TYPE_PERMISSION,
  DELETE_ITEM_TYPE_PERMISSION,
  DETAIL_ITEM_TYPE_PERMISSION,
  LIST_ITEM_TYPE_PERMISSION,
  IMPORT_ITEM_TYPE_PERMISSION,
} from '@utils/permissions/item-type';

import {
  CREATE_ITEM_GROUP_PERMISSION,
  UPDATE_ITEM_GROUP_PERMISSION,
  DELETE_ITEM_GROUP_PERMISSION,
  DETAIL_ITEM_GROUP_PERMISSION,
  LIST_ITEM_GROUP_PERMISSION,
  IMPORT_ITEM_GROUP_PERMISSION,
} from '@utils/permissions/item-group';
import {
  SetStatusRequestDto,
  StatusRequestDto,
} from './dto/request/set-status.request.dto';
import { ItemUnitSettingResponseDto } from './dto/response/item-unit-setting-response.dto';
import { ResponsePayload } from '@utils/response-payload';
import { ItemTypeSettingResponseDto } from './dto/response/item-type-setting-response.dto';
import { ItemGroupSettingResponseDto } from './dto/response/item-group-setting-response.dto';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { ItemGroupSettingRequestDto } from '@components/item/dto/request/item-group-setting-request.dto';
import { SuccessResponse } from '@utils/success.response.dto';
import { ItemTypeSettingUpdateBodyRequestDto } from './dto/request/item-type-setting-update-request.dto';
import { GetListItemUnitByIdsRequestDto } from './dto/request/get-list-item-unit-by-ids.request.dto';
import { GetItemTypeSettiingByIdsRequestDto } from './dto/request/get-item-type-setting-by-ids.request.dto';

@Controller('')
export class ItemSettingController {
  constructor(
    @Inject('ItemSettingServiceInterface')
    private readonly itemSettingService: ItemSettingServiceInterface,
  ) {}

  @PermissionCode(IMPORT_ITEM_UNIT_PERMISSION.code)
  @Post('item-unit-settings/import')
  @MessagePattern('import_item_unit_setting')
  public async importItemUnitSetting(
    @Body() body: FileUpdloadRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.importItemUnitSetting(request);
  }

  @PermissionCode(CREATE_ITEM_UNIT_PERMISSION.code)
  @MessagePattern('create_item_unit_setting')
  @Post('item-unit-settings/create')
  @ApiOperation({
    tags: ['Item Unit'],
    summary: 'Create new item unit setting',
    description: 'Cài đặt một item unit setting mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ItemUnitSettingResponseDto,
  })
  public async createItemUnitSetting(
    @Body() body: ItemUnitSettingRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.createItemUnitSetting(request);
  }

  @PermissionCode(UPDATE_ITEM_UNIT_PERMISSION.code)
  @MessagePattern('update_item_unit_setting')
  @Put('item-unit-settings/:id')
  @ApiOperation({
    tags: ['Item Unit'],
    summary: 'Create new item unit setting',
    description: 'Cài đặt một item unit setting mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ItemUnitSettingResponseDto,
  })
  public async updateItemUnitSetting(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: ItemUnitSettingUpdateBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.updateItemUnitSetting({
      ...request,
      id: id,
    });
  }

  @PermissionCode(LIST_ITEM_UNIT_PERMISSION.code)
  // @MessagePattern('get_list_item_unit_setting')
  @Get('item-unit-settings/list')
  @ApiOperation({
    tags: ['Item Unit'],
    summary: 'Get item unit setting list',
    description: 'Get list item unit setting',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListItemUnitSettingResponseDto,
  })
  public async getListItemUnitSetting(
    @Query() payload: GetListItemUnitSettingRequestDto,
  ): Promise<GetListItemUnitSettingResponseDto | any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.getListItemUnitSetting(request);
  }

  @PermissionCode(DELETE_ITEM_UNIT_PERMISSION.code)
  @MessagePattern('delete_item_unit_setting')
  @Delete('item-unit-settings/:id')
  @ApiOperation({
    tags: ['Item Unit'],
    summary: 'Delete item unit setting',
    description: 'Delete item unit setting',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteItemUnitSetting(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<any> {
    return await this.itemSettingService.deleteItemUnitSetting(id);
  }

  @PermissionCode(DELETE_ITEM_UNIT_PERMISSION.code)
  @MessagePattern('delete_item_unit_setting_multiple')
  @Delete('item-unit-settings/multiple')
  @ApiOperation({
    tags: ['Item Unit'],
    summary: 'Delete multiple item unit setting',
    description: 'Delete multiple item unit setting',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteMultipleItemUnitSetting(
    @Query() body: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.deleteMultipleItemUnitSetting(request);
  }

  @PermissionCode(DETAIL_ITEM_UNIT_PERMISSION.code)
  // @MessagePattern('get_item_unit_setting_detail')
  @Get('item-unit-settings/:id')
  @ApiOperation({
    tags: ['Item Unit'],
    summary: 'Get item unit setting detail',
    description: 'Get information of an item unit setting',
  })
  @ApiResponse({
    status: 200,
    description: 'Get information successfully',
    type: ItemUnitSettingResponseDto,
  })
  public async getItemUnitSettingDetail(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<any> {
    return await this.itemSettingService.getItemUnitSettingDetail(id);
  }

  @MessagePattern('confirm_item_unit')
  @Put('/item-unit-settings/:id/confirm')
  @ApiOperation({
    tags: ['Item Unit'],
    summary: 'confirm item unit setting',
    description: 'xác nhận đơn vị sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ItemUnitSettingResponseDto,
  })
  public async confirmItemUnit(
    @Param('id', new ParseIntPipe()) id,

    @Req() payload: StatusRequestDto,
  ): Promise<ResponsePayload<ItemUnitSettingResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemSettingService.confirmItemUnit({
      id,
      ...request,
    });
  }

  @MessagePattern('reject_item_unit')
  @Put('/item-unit-settings/:id/reject')
  @ApiOperation({
    tags: ['Item Unit'],
    summary: 'reject item unit setting',
    description: 'từ chối đơn vị sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ItemUnitSettingResponseDto,
  })
  public async rejectItemUnit(
    @Param('id', new ParseIntPipe()) id,
    @Req() payload: SetStatusRequestDto,
  ): Promise<ResponsePayload<ItemUnitSettingResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemSettingService.rejectItemUnit({
      id,
      ...request,
    });
  }

  // item type

  @PermissionCode(IMPORT_ITEM_TYPE_PERMISSION.code)
  @MessagePattern('import_item_type_setting')
  public async importItemTypeSetting(
    @Body() body: FileUpdloadRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.importItemTypeSetting(request);
  }

  @PermissionCode(CREATE_ITEM_TYPE_PERMISSION.code)
  @MessagePattern('create_item_type_setting')
  @Post('item-type-settings/create')
  @ApiOperation({
    tags: ['Item Type'],
    summary: 'Create new item type setting',
    description: 'Cài đặt một item type setting mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ItemTypeSettingResponseDto,
  })
  public async createItemTypeSetting(
    @Body() body: ItemTypeSettingRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.createItemTypeSetting(request);
  }

  @PermissionCode(UPDATE_ITEM_TYPE_PERMISSION.code)
  @MessagePattern('update_item_type_setting')
  @Put('item-type-settings/:id')
  @ApiOperation({
    tags: ['Item Type'],
    summary: 'Update an item type setting',
    description: 'Cập nhật một item type setting mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: ItemTypeSettingResponseDto,
  })
  public async updateItemTypeSetting(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: ItemTypeSettingUpdateBodyRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.updateItemTypeSetting({
      ...request,
      id: id,
    });
  }

  @PermissionCode(DELETE_ITEM_TYPE_PERMISSION.code)
  @MessagePattern('delete_item_type_setting')
  //TODO
  @Delete('item-type-settings/:id')
  @ApiOperation({
    tags: ['Item Type'],
    summary: 'Delete an item type setting',
    description: 'Xóa một item type setting mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteItemTypeSetting(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<any> {
    return await this.itemSettingService.deleteItemTypeSetting(id);
  }

  @PermissionCode(DELETE_ITEM_TYPE_PERMISSION.code)
  @MessagePattern('delete_item_type_setting_multiple')
  @Delete('item-type-settings/multiple')
  @ApiOperation({
    tags: ['Item Type'],
    summary: 'Delete multiple item type setting',
    description: 'Xóa multiple item type setting mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteMultipleItemTypeSetting(
    @Query() body: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.deleteMultipleItemTypeSetting(request);
  }

  @PermissionCode(LIST_ITEM_TYPE_PERMISSION.code)
  // @MessagePattern('item_type_setting_list')
  @Get('item-type-settings/list')
  @ApiOperation({
    tags: ['ItemType'],
    summary: 'List Item Type',
    description: 'Danh sách kiểu item',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListItemTypeSettingResponseDto,
  })
  public async getListItemTypeSetting(
    @Query() payload: GetListItemTypeSettingRequestDto,
  ): Promise<GetListItemTypeSettingResponseDto | any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.getListItemTypeSetting(request);
  }

  @PermissionCode(DETAIL_ITEM_TYPE_PERMISSION.code)
  @MessagePattern('get_item_type_setting_detail')
  @Get('item-type-settings/:id')
  @ApiOperation({
    tags: ['Item Type'],
    summary: 'Get item type setting detail',
    description: 'Get information of an item type setting',
  })
  @ApiResponse({
    status: 200,
    description: 'Get information successfully',
    type: ItemTypeSettingResponseDto,
  })
  public async getItemTypeSettingDetail(
    @Req() body: IdRequestDto,
    @Param('id', new ParseIntPipe()) id,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.getItemTypeSettingDetail({
      id,
      ...request,
    });
  }

  @MessagePattern('confirm_item_type')
  @Put('/item-type-settings/:id/confirm')
  @ApiOperation({
    tags: ['Item Type'],
    summary: 'confirm item type setting',
    description: 'xác nhận kiểu sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ItemTypeSettingResponseDto,
  })
  public async confirmItemType(
    @Param('id', new ParseIntPipe()) id,
    @Req() payload: StatusRequestDto,
  ): Promise<ResponsePayload<ItemTypeSettingResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemSettingService.confirmItemType({
      id,
      ...request,
    });
  }

  @MessagePattern('reject_item_type')
  @Put('/item-type-settings/:id/reject')
  @ApiOperation({
    tags: ['Item Type'],
    summary: 'reject item type setting',
    description: 'từ chối kiểu sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ItemTypeSettingResponseDto,
  })
  public async rejectItemType(
    @Param('id', new ParseIntPipe()) id,
    @Req() payload: StatusRequestDto,
  ): Promise<ResponsePayload<ItemTypeSettingResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemSettingService.rejectItemType({
      id,
      ...request,
    });
  }

  // item group

  @PermissionCode(IMPORT_ITEM_GROUP_PERMISSION.code)
  @MessagePattern('import_item_group_setting')
  @Post('item-group-settings/import')
  public async importItemGroupSetting(
    @Body() body: FileUpdloadRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.importItemGroupSetting(request);
  }

  @PermissionCode(CREATE_ITEM_GROUP_PERMISSION.code)
  @MessagePattern('create_item_group_setting')
  @Post('item-group-settings/create')
  @ApiOperation({
    tags: ['Item Group'],
    summary: 'Create new item group setting',
    description: 'Cài đặt một item group setting mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ItemGroupSettingResponseDto,
  })
  public async createItemGroupSetting(
    @Body() body: ItemGroupSettingRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.createItemGroupSetting(request);
  }

  @PermissionCode(UPDATE_ITEM_GROUP_PERMISSION.code)
  @MessagePattern('update_item_group_setting')
  @Put('item-group-settings/:id')
  @ApiOperation({
    tags: ['Item Group'],
    summary: 'Update new item group setting',
    description: 'Update một item group setting mới',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: ItemGroupSettingResponseDto,
  })
  public async updateItemGroupSetting(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateItemGroupSettingBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.updateItemGroupSetting({
      ...request,
      id: Number(id),
    });
  }

  @PermissionCode(LIST_ITEM_GROUP_PERMISSION.code)
  // @MessagePattern('get_list_item_group_setting')
  @Get('item-group-settings/list')
  @ApiOperation({
    tags: ['Item Group'],
    summary: 'Get item group setting list',
    description: 'Get list item group setting',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: GetListItemGroupSettingResponseDto,
  })
  public async getListItemGroupSetting(
    @Query() body: GetListItemGroupSettingRequestDto,
  ): Promise<GetListItemGroupSettingResponseDto> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.getListItemGroupSetting(request);
  }

  @PermissionCode(DELETE_ITEM_GROUP_PERMISSION.code)
  @MessagePattern('delete_item_group_setting')
  @Delete('item-group-settings/:id')
  @ApiOperation({
    tags: ['Item Group'],
    summary: 'Delete item group setting',
    description: 'Delete item group setting',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteItemGroupSetting(
    @Param('id', new ParseIntPipe()) id,
  ): Promise<any> {
    return await this.itemSettingService.deleteItemGroupSetting(id);
  }

  @PermissionCode(DELETE_ITEM_GROUP_PERMISSION.code)
  @MessagePattern('delete_item_group_setting_multiple')
  @Delete('item-group-settings/multiple')
  @ApiOperation({
    tags: ['Item Group'],
    summary: 'Delete multiple item group setting',
    description: 'Delete multiple item group setting',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: SuccessResponse,
  })
  public async deleteMultipleItemGroupSetting(
    @Query() body: DeleteMultipleDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.deleteMultipleItemGroupSetting(
      request,
    );
  }

  @PermissionCode(DETAIL_ITEM_GROUP_PERMISSION.code)
  @MessagePattern('get_item_group_setting_detail')
  @Get('item-group-settings/:id')
  @ApiOperation({
    tags: ['Item Group'],
    summary: 'Get item group setting detail',
    description: 'Get information of an item group setting',
  })
  @ApiResponse({
    status: 200,
    description: 'Get information successfully',
    type: ItemGroupSettingResponseDto,
  })
  public async getItemGroupSettingDetail(
    @Req() body: IdRequestDto,
    @Param('id', new ParseIntPipe()) id,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.getItemGroupSettingDetail({
      id,
      ...request,
    });
  }

  @MessagePattern('confirm_item_group')
  @Put('/item-group-settings/:id/confirm')
  @ApiOperation({
    tags: ['Item Group'],
    summary: 'confirm item group setting',
    description: 'xác nhận nhóm sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Confirm successfully',
    type: ItemGroupSettingResponseDto,
  })
  public async confirmItemGroup(
    @Param('id', new ParseIntPipe()) id,
    @Req() payload: StatusRequestDto,
  ): Promise<ResponsePayload<ItemGroupSettingResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemSettingService.confirmItemGroup({ id, ...request });
  }

  @MessagePattern('reject_item_group')
  @Put('/item-group-settings/:id/reject')
  @ApiOperation({
    tags: ['Item Group'],
    summary: 'reject item group setting',
    description: 'từ chối nhóm sản phẩm',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: ItemGroupSettingResponseDto,
  })
  public async rejectItemGroup(
    @Param('id', new ParseIntPipe()) id,
    @Req() payload: StatusRequestDto,
  ): Promise<ResponsePayload<ItemGroupSettingResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemSettingService.rejectItemGroup({ id, ...request });
  }

  //todo remove when refactor done
  @PermissionCode(DETAIL_ITEM_UNIT_PERMISSION.code)
  @MessagePattern('get_item_unit_setting_detail')
  public async getItemUnitSettingDetailTcp(
    @Body() body: IdRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.getItemUnitSettingDetail(request);
  }

  @PermissionCode(LIST_ITEM_UNIT_PERMISSION.code)
  @MessagePattern('get_list_item_unit_setting')
  public async getListItemUnitSettingTcp(
    @Body() payload: GetListItemUnitSettingRequestDto,
  ): Promise<GetListItemUnitSettingResponseDto | any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.getListItemUnitSetting(request);
  }

  @PermissionCode(LIST_ITEM_GROUP_PERMISSION.code)
  @MessagePattern('get_list_item_group_setting')
  public async getListItemGroupSettingTcp(
    @Body() body: GetListItemGroupSettingRequestDto,
  ): Promise<GetListItemGroupSettingResponseDto> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.getListItemGroupSetting(request);
  }

  @PermissionCode(LIST_ITEM_TYPE_PERMISSION.code)
  @MessagePattern('item_type_setting_list')
  public async getListItemTypeSettingTcp(
    @Body() payload: GetListItemTypeSettingRequestDto,
  ): Promise<GetListItemTypeSettingResponseDto | any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.getListItemTypeSetting(request);
  }

  @MessagePattern('get_item_unit_setting_by_ids')
  public async getItemUnitSettingByIds(
    @Body() payload: GetListItemUnitByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.getItemUnitSettingByIds(request);
  }

  @MessagePattern('get_item_type_setting_by_ids')
  async getItemTypeSettingByIds(
    @Body() body: GetItemTypeSettiingByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemSettingService.getItemTypeSettingByIds(request);
  }
}
