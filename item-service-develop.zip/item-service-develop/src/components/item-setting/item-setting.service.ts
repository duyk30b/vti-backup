import { Inject, Injectable } from '@nestjs/common';
import { ItemSettingServiceInterface } from '@components/item-setting/interface/item-setting.service.interface';
import { ILike, In, Not, Connection } from 'typeorm';
import { InjectConnection } from '@nestjs/typeorm';
import { ItemUnitSettingRequestDto } from '@components/item-setting/dto/request/item-unit-setting-request.dto';
import { ItemUnitSettingUpdateRequestDto } from '@components/item-setting/dto/request/item-unit-setting-update-request.dto';
import { ApiError } from '@utils/api.error';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ItemUnitSettingRepositoryInterface } from '@components/item-setting/interface/item-unit-setting.repository.interface';
import { plainToClass, plainToInstance } from 'class-transformer';
import { ResponseBuilder } from '@utils/response-builder';
import { ItemUnitSettingResponseDto } from '@components/item-setting/dto/response/item-unit-setting-response.dto';
import { ItemUnitSettingUpdateResponseDto } from '@components/item-setting/dto/response/item-unit-setting-update-response.dto';
import { DeleteSuccessResponseDto } from '@components/item-setting/dto/response/delete-success-response.dto';
import { ItemTypeSettingResponseDto } from '@components/item-setting/dto/response/item-type-setting-response.dto';
import { ItemTypeSettingRepositoryInterface } from '@components/item/interface/item-type-setting.repository.interface';
import { GetListItemTypeSettingResponseDto } from '@components/item-setting/dto/response/get-list-item-type-setting.response.dto';
import { ResponsePayload } from '@utils/response-payload';
import { PagingResponse } from '@utils/paging.response';
import { GetListItemUnitSettingResponseDto } from '@components/item-setting/dto/response/get-list-item-unit-setting.response.dto';
import { ItemGroupSettingRequestDto } from '@components/item/dto/request/item-group-setting-request.dto';
import { UpdateItemGroupSettingRequestDto } from '@components/item/dto/request/update-item-group-setting-request.dto';
import { ItemGroupSettingRepositoryInterface } from '@components/item-setting/interface/item-group-setting.repository.interface';
import { ItemRepositoryInterface } from '@components/item/interface/item.repository.interface';
import { ConfigService } from '@config/config.service';
import { DATA_NOT_CHANGE } from '@constant/common';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { ItemTypeSettingImport } from './import/item-type-setting.import.helper';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ItemUnitSettingImport } from './import/item-unit-setting.import.helper';
import { ItemGroupSettingImport } from './import/item-group-setting.import.helper';
import { SetStatusRequestDto } from './dto/request/set-status.request.dto';
import {
  CAN_DELETE_ITEM_GROUP_STATUS,
  CAN_DELETE_ITEM_TYPE_STATUS,
  CAN_DELETE_ITEM_UNIT_STATUS,
  CAN_UPDATE_ITEM_GROUP_STATUS,
  CAN_UPDATE_ITEM_TYPE_STATUS,
  CAN_UPDATE_ITEM_UNIT_STATUS,
  ItemGroupStatusEnum,
  ItemTypeStatusEnum,
  ItemUnitStatusEnum,
} from './item-setting.constant';
import { ItemGroupSettingResponseDto } from './dto/response/item-group-setting-response.dto';
import { isEmpty } from 'lodash';
import { stringFormat } from '@utils/object.util';
import { DeleteMultipleDto } from '@core/dto/multiple/delete-multiple.dto';
import { IdRequestDto } from './dto/request/id.request.dto';
import {
  ItemTypeSettingUpdateBodyRequestDto,
  ItemTypeSettingUpdateRequestDto,
} from './dto/request/item-type-setting-update-request.dto';
import { ItemGroupSetting } from '@entities/item/item-group-setting.entity';
import { GetListItemUnitByIdsRequestDto } from './dto/request/get-list-item-unit-by-ids.request.dto';
import { GetItemTypeSettiingByIdsRequestDto } from './dto/request/get-item-type-setting-by-ids.request.dto';

@Injectable()
export class ItemSettingService implements ItemSettingServiceInterface {
  constructor(
    @Inject('ItemRepositoryInterface')
    private readonly itemRepository: ItemRepositoryInterface,

    @Inject('ItemGroupSettingRepositoryInterface')
    private readonly itemGroupSettingRepository: ItemGroupSettingRepositoryInterface,

    @Inject('ItemUnitSettingRepositoryInterface')
    private readonly itemUnitSettingRepository: ItemUnitSettingRepositoryInterface,

    @Inject('ItemTypeSettingRepositoryInterface')
    private readonly itemTypeSettingRepository: ItemTypeSettingRepositoryInterface,

    // @Inject('ProfileItemRepositoryInterface')
    // private readonly profileItemRepository: ProfileItemRepositoryInterface,

    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,

    @Inject('ItemTypeSettingImport')
    private readonly itemTypeSettingImport: ItemTypeSettingImport,

    @Inject('ItemUnitSettingImport')
    private readonly itemUnitSettingImport: ItemUnitSettingImport,

    @Inject('ItemGroupSettingImport')
    private readonly itemGroupSettingImport: ItemGroupSettingImport,
    private readonly i18n: I18nRequestScopeService,

    @InjectConnection()
    private readonly connection: Connection,
  ) {}

  importItemUnitSetting(request: FileUpdloadRequestDto): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
    } as ImportRequestDto;
    return this.itemUnitSettingImport.importUtil(importRequestDto);
  }

  public async createItemUnitSetting(
    request: ItemUnitSettingRequestDto,
  ): Promise<any> {
    try {
      const itemUnit = await this.itemUnitSettingRepository.findByCondition([
        {
          code: ILike(request.code),
        },
      ]);
      if (itemUnit) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.CODE_EXIST'),
        ).toResponse();
      }
      const itemUnitSetting = {
        name: request.name,
        code: request.code,
        description: request.description,
        createdBy: request.userId,
      };
      const itemUnitSettingEntity =
        this.itemUnitSettingRepository.createEntity(itemUnitSetting);
      const data = await this.itemUnitSettingRepository.create(
        itemUnitSettingEntity,
      );

      const response = plainToClass(ItemUnitSettingUpdateResponseDto, data, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(response)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  public async updateItemUnitSetting(
    request: ItemUnitSettingUpdateRequestDto,
  ): Promise<any> {
    try {
      const { id, name, code, description } = request;
      const checkUniqueDataDefault = DATA_NOT_CHANGE.ITEM_UNIT.code.filter(
        (item) => item === code,
      );

      if (checkUniqueDataDefault.length > 0) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.CAN_NOT_UPDATE'),
        ).toResponse();
      }
      const itemUnit = await this.itemUnitSettingRepository.findOneById(id);
      if (!itemUnit) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      if (!CAN_UPDATE_ITEM_UNIT_STATUS.includes(itemUnit.status)) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.ITEM_UNIT_WAS_CONFIRMED'),
        ).toResponse();
      }

      const itemUnitSetting =
        await this.itemUnitSettingRepository.findByCondition([
          {
            code: code,
            id: Not(id),
          },
          {
            name: name,
            id: Not(id),
          },
        ]);

      if (itemUnitSetting) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      itemUnit.name = name;
      itemUnit.code = code;
      itemUnit.description = description;
      await this.itemUnitSettingRepository.create(itemUnit);
      const response = plainToClass(
        ItemUnitSettingUpdateResponseDto,
        itemUnit,
        {
          excludeExtraneousValues: true,
        },
      );
      return new ResponseBuilder(response)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  public async getListItemUnitSetting(
    request: any,
  ): Promise<ResponsePayload<GetListItemUnitSettingResponseDto | any>> {
    const { result, count } = await this.itemUnitSettingRepository.getList(
      request,
    );

    const response = plainToClass(ItemUnitSettingResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async deleteItemUnitSetting(id: number): Promise<any> {
    const itemUnitSetting = await this.itemUnitSettingRepository.findOneById(
      id,
    );
    if (!itemUnitSetting) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const checkUniqueDataDefault = DATA_NOT_CHANGE.ITEM_UNIT.code.filter(
      (item) => item === itemUnitSetting.code,
    );

    if (checkUniqueDataDefault.length > 0) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_DELETE'),
      ).toResponse();
    }

    if (!CAN_DELETE_ITEM_UNIT_STATUS.includes(itemUnitSetting.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.ITEM_TYPE_WAS_CONFIRMED'),
      ).toResponse();
    }

    try {
      await this.itemUnitSettingRepository.remove(id);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    const response = plainToClass(
      DeleteSuccessResponseDto,
      { id: id },
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async deleteMultipleItemUnitSetting(
    request: DeleteMultipleDto,
  ): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const itemUnitSettings =
      await this.itemUnitSettingRepository.findAllByCondition({
        id: In(ids),
      });

    const checkUniqueDataDefault = itemUnitSettings.filter((itemUnitSetting) =>
      DATA_NOT_CHANGE.ITEM_UNIT.code.includes(itemUnitSetting.code),
    );

    const itemUnitSettingIds = itemUnitSettings.map(
      (itemUnitSetting) => itemUnitSetting.id,
    );
    if (itemUnitSettings.length !== ids.length) {
      ids.forEach((id) => {
        if (!itemUnitSettingIds.includes(id)) failIdsList.push(id);
      });
    }

    if (checkUniqueDataDefault.length > 0) {
      checkUniqueDataDefault.forEach((itemUnitSetting) => {
        failIdsList.push(itemUnitSetting.id);
      });
    }

    for (let index = 0; index < itemUnitSettings.length; index++) {
      const itemUnitSetting = itemUnitSettings[index];
      if (!CAN_DELETE_ITEM_UNIT_STATUS.includes(itemUnitSetting.status)) {
        failIdsList.push(itemUnitSetting.id);
      }
    }

    const validIds = itemUnitSettings
      .filter((itemUnitSetting) => !failIdsList.includes(itemUnitSetting.id))
      .map((itemUnitSetting) => itemUnitSetting.id);

    try {
      if (!isEmpty(validIds)) {
        await this.itemUnitSettingRepository.multipleRemove(validIds);
      }
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async getItemUnitSettingDetail(id: number): Promise<any> {
    const itemUnitSetting = await this.itemUnitSettingRepository.findOneById(
      id,
    );
    if (!itemUnitSetting) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    if (itemUnitSetting.createdBy) {
      const responseUserService = await this.userService.getUserById(
        itemUnitSetting.createdBy,
      );
      itemUnitSetting.createdBy = responseUserService;
    }
    const response = plainToClass(ItemUnitSettingResponseDto, itemUnitSetting, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  //End Item Unit Setting Service

  public async importItemTypeSetting(
    request: FileUpdloadRequestDto,
  ): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
    } as ImportRequestDto;
    return this.itemTypeSettingImport.importUtil(importRequestDto);
  }

  public async createItemTypeSetting(request: any): Promise<any> {
    try {
      const checkUniqueCode =
        await this.itemTypeSettingRepository.findByCondition([
          {
            code: ILike(request.code),
          },
        ]);
      if (checkUniqueCode) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.CODE_EXIST'),
        ).toResponse();
      }

      const itemTypeSetting = {
        name: request.name,
        description: request.description,
        code: request.code,
        hasItemDetail: request.hasItemDetail,
        createdBy: request.userId,
        status: ItemTypeStatusEnum.CREATED,
      };
      const itemTypeSettingEntity =
        this.itemTypeSettingRepository.createEntity(itemTypeSetting);
      const data = await this.itemTypeSettingRepository.create(
        itemTypeSettingEntity,
      );

      const response = plainToClass(ItemTypeSettingResponseDto, data, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(response)
        .withMessage(
          await this.i18n.translate('error.CREATE_ITEM_TYPE_SETTING_SUCCESS'),
        )
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  public async updateItemTypeSetting(
    request: ItemTypeSettingUpdateRequestDto,
  ): Promise<any> {
    // return request;
    try {
      const { id } = request;
      const itemType = await this.itemTypeSettingRepository.findOneById(id);
      if (!itemType) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }
      if (!CAN_UPDATE_ITEM_TYPE_STATUS.includes(itemType.status)) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.ITEM_TYPE_WAS_CONFIRMED'),
        ).toResponse();
      }

      // const checkUniqueDataDefault =
      //   DATA_NOT_CHANGE.ITEM_TYPE_SETTINGS.code.filter(
      //     (item) => item === itemType.code,
      //   );

      // if (checkUniqueDataDefault.length > 0) {
      //   return new ApiError(
      //     ResponseCodeEnum.BAD_REQUEST,
      //     await this.i18n.translate('error.CAN_NOT_UPDATE'),
      //   ).toResponse();
      // }

      const checkUniqueCode =
        await this.itemTypeSettingRepository.findByCondition([
          {
            code: request.code,
            id: Not(request.id),
          },
        ]);
      if (checkUniqueCode) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.CODE_ALREADY_EXISTS'),
        ).toResponse();
      }

      const checkUniqueName =
        await this.itemTypeSettingRepository.findByCondition([
          { name: request.name, id: Not(request.id) },
        ]);
      if (checkUniqueName) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.NAME_ALREADY_EXISTS'),
        ).toResponse();
      }

      itemType.code = request.code;
      itemType.name = request.name;
      itemType.description = request.description;
      // itemType.hasItemDetail = request.hasItemDetail;

      const data = await this.itemTypeSettingRepository.create(itemType);

      const response = plainToClass(ItemTypeSettingResponseDto, data, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(response)
        .withMessage(
          await this.i18n.translate('error.UPDATE_ITEM_TYPE_SETTING_SUCCESS'),
        )
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  public async deleteItemTypeSetting(id: number): Promise<any> {
    const itemTypeSetting = await this.itemTypeSettingRepository.findOneById(
      id,
    );
    if (!itemTypeSetting) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    // if (!CAN_DELETE_ITEM_TYPE_STATUS.includes(itemTypeSetting.status)) {
    //   return new ApiError(
    //     ResponseCodeEnum.BAD_REQUEST,
    //     await this.i18n.translate('error.ITEM_TYPE_WAS_CONFIRMED'),
    //   ).toResponse();
    // }

    const itemTypeExist =
      await this.itemTypeSettingRepository.checkItemTypeUsed(id);

    if (itemTypeExist.itemId) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.ITEM_TYPE_USED'),
      ).toResponse();
    }

    const checkUniqueDataDefault =
      DATA_NOT_CHANGE.ITEM_TYPE_SETTINGS.code.filter(
        (item) => item === itemTypeSetting.code,
      );

    if (checkUniqueDataDefault.length > 0) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_DELETE'),
      ).toResponse();
    }

    try {
      await this.itemTypeSettingRepository.remove(id);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }
    const response = plainToClass(
      DeleteSuccessResponseDto,
      { id: id },
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withMessage(
        await this.i18n.translate('error.DELETE_ITEM_TYPE_SETTING_SUCCESS'),
      )
      .build();
  }

  public async deleteMultipleItemTypeSetting(
    request: DeleteMultipleDto,
  ): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));
    const itemTypeSettings =
      await this.itemTypeSettingRepository.findAllByCondition({
        id: In(ids),
      });

    const checkUniqueDataDefault = itemTypeSettings.filter((itemTypeSetting) =>
      DATA_NOT_CHANGE.ITEM_TYPE_SETTINGS.code.includes(itemTypeSetting.code),
    );

    const itemTypeSettingIds = itemTypeSettings.map(
      (itemTypeSetting) => itemTypeSetting.id,
    );
    if (itemTypeSettings.length !== ids.length) {
      ids.forEach((id) => {
        if (!itemTypeSettingIds.includes(id)) failIdsList.push(id);
      });
    }

    if (checkUniqueDataDefault.length > 0) {
      checkUniqueDataDefault.forEach((itemTypeSetting) => {
        failIdsList.push(itemTypeSetting.id);
      });
    }

    for (let index = 0; index < itemTypeSettings.length; index++) {
      const itemTypeSetting = itemTypeSettings[index];
      if (!CAN_DELETE_ITEM_TYPE_STATUS.includes(itemTypeSetting.status)) {
        failIdsList.push(itemTypeSetting.id);
      }
    }

    const validIds = itemTypeSettings
      .filter((itemTypeSetting) => !failIdsList.includes(itemTypeSetting.id))
      .map((itemTypeSetting) => itemTypeSetting.id);

    try {
      if (!isEmpty(validIds)) {
        await this.itemTypeSettingRepository.multipleRemove(validIds);
      }
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async getListItemTypeSetting(
    request: any,
  ): Promise<ResponsePayload<GetListItemTypeSettingResponseDto | any>> {
    const { result, count } = await this.itemTypeSettingRepository.getList(
      request,
    );

    const response = plainToClass(ItemTypeSettingResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getItemTypeSettingDetail(
    request: ItemTypeSettingUpdateRequestDto,
  ): Promise<any> {
    const itemTypeSetting = await this.itemTypeSettingRepository.findOneById(
      request.id,
    );
    if (!itemTypeSetting) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    if (itemTypeSetting.createdBy) {
      const responseUserService = await this.userService.getUserById(
        itemTypeSetting.createdBy,
      );
      itemTypeSetting.createdBy = responseUserService;
    }
    const response = plainToClass(ItemTypeSettingResponseDto, itemTypeSetting, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  // End Item Type Setting Service

  importItemGroupSetting(request: FileUpdloadRequestDto): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
    } as ImportRequestDto;
    return this.itemGroupSettingImport.importUtil(importRequestDto);
  }

  public async createItemGroupSetting(
    request: ItemGroupSettingRequestDto,
  ): Promise<any> {
    try {
      const itemGroupSetting = {
        code: request.code,
        name: request.name,
        description: request.description,
        createdBy: request.userId,
      };

      const condition = [{ code: ILike(request.code.toLowerCase()) }];
      const itemGroup = await this.itemGroupSettingRepository.findByCondition(
        condition,
      );
      if (itemGroup) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.CODE_OR_NAME_IS_EXISTED'),
        ).toResponse();
      }
      const itemGroupSettingEntity =
        await this.itemGroupSettingRepository.createEntity(itemGroupSetting);
      const data = await this.itemGroupSettingRepository.create(
        itemGroupSettingEntity,
      );

      const response = plainToClass(ItemGroupSettingResponseDto, data, {
        excludeExtraneousValues: true,
      });
      return new ResponseBuilder(response)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  public async updateItemGroupSetting(
    request: UpdateItemGroupSettingRequestDto,
  ): Promise<any> {
    try {
      const { id, code, name, description, userId } = request;

      const itemGroup = await this.itemGroupSettingRepository.findOneById(
        request.id,
      );
      if (!itemGroup) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.NOT_FOUND'),
        ).toResponse();
      }

      const checkUniqueDataDefault = DATA_NOT_CHANGE.ITEM_GROUP.code.filter(
        (item) => item === itemGroup.code,
      );

      if (checkUniqueDataDefault.length > 0) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.CAN_NOT_UPDATE'),
        ).toResponse();
      }

      if (!CAN_UPDATE_ITEM_GROUP_STATUS.includes(itemGroup.status)) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.ITEM_GROUP_WAS_CONFIRMED'),
        ).toResponse();
      }

      const isExistItemGroup =
        await this.itemGroupSettingRepository.findByCondition([
          {
            code: code,
            id: Not(id),
          },
          { name: name, id: Not(id) },
        ]);
      if (isExistItemGroup) {
        return new ApiError(
          ResponseCodeEnum.BAD_REQUEST,
          await this.i18n.translate('error.CODE_OR_NAME_IS_EXISTED'),
        ).toResponse();
      }

      itemGroup.code = code;
      itemGroup.name = name;
      itemGroup.description = description;
      itemGroup.createdBy = userId;
      const data = await this.itemGroupSettingRepository.create(itemGroup);

      const response = plainToClass(ItemGroupSettingResponseDto, data, {
        excludeExtraneousValues: true,
      });

      return new ResponseBuilder(response)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  /**
   * getListItemGroupSetting
   */
  public async getListItemGroupSetting(request: any): Promise<any> {
    const { result, count } = await this.itemGroupSettingRepository.getList(
      request,
    );
    const response = plainToClass(ItemGroupSettingResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: count, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async deleteItemGroupSetting(id: number): Promise<any> {
    const itemGroupSetting = await this.itemGroupSettingRepository.findOneById(
      id,
    );
    if (!itemGroupSetting) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const checkUniqueDataDefault = DATA_NOT_CHANGE.ITEM_GROUP.code.filter(
      (item) => item === itemGroupSetting.code,
    );

    if (checkUniqueDataDefault.length > 0) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.CAN_NOT_UPDATE'),
      ).toResponse();
    }

    if (!CAN_DELETE_ITEM_GROUP_STATUS.includes(itemGroupSetting.status)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.ITEM_GROUP_WAS_CONFIRMED'),
      ).toResponse();
    }
    const itemDocInUse = [];
    const [itemInUse] = await Promise.all([
      this.itemRepository.findOneWithRelations({
        where: {
          itemGroupId: id,
        },
      }),
      // this.profileItemRepository.findOneWithRelations({
      //   where: {
      //     itemGroupSettingId: id,
      //   },
      // }),
    ]);
    if (!isEmpty(itemInUse) || !isEmpty(itemDocInUse)) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.ITEM_GROUP_USED'),
      ).toResponse();
    }
    const code = new ConfigService().get('otherGroupId');
    const otherGroup =
      await this.itemGroupSettingRepository.findOneWithRelations({
        where: { code },
      });

    const itemsByGroupId = await this.itemRepository.findAllByCondition({
      itemGroupId: id,
    });
    const itemEntities = itemsByGroupId?.map((item) =>
      this.itemRepository.updateItemGroupIdByItemId(item, otherGroup?.id),
    );

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (!isEmpty(itemEntities)) {
        await queryRunner.manager.save(itemEntities);
      }
      await queryRunner.manager.delete(ItemGroupSetting, { id });
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    } finally {
      await queryRunner.release();
    }

    const response = plainToClass(DeleteSuccessResponseDto, id, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder(response)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async deleteMultipleItemGroupSetting(
    request: DeleteMultipleDto,
  ): Promise<any> {
    const failIdsList = [];
    const ids = request.ids.split(',').map((id) => parseInt(id));

    const itemGroupSettings =
      await this.itemGroupSettingRepository.findAllByCondition({
        id: In(ids),
      });

    const checkUniqueDataDefault = itemGroupSettings.filter(
      (itemGroupSetting) =>
        DATA_NOT_CHANGE.ITEM_GROUP.code.includes(itemGroupSetting.code),
    );

    const itemGroupSettingIds = itemGroupSettings.map(
      (itemGroupSetting) => itemGroupSetting.id,
    );
    if (itemGroupSettings.length !== ids.length) {
      ids.forEach((id) => {
        if (!itemGroupSettingIds.includes(id)) failIdsList.push(id);
      });
    }

    if (checkUniqueDataDefault.length > 0) {
      checkUniqueDataDefault.forEach((itemGroupSetting) => {
        failIdsList.push(itemGroupSetting.id);
      });
    }

    for (let index = 0; index < itemGroupSettings.length; index++) {
      const itemGroupSetting = itemGroupSettings[index];
      if (!CAN_DELETE_ITEM_GROUP_STATUS.includes(itemGroupSetting.status)) {
        failIdsList.push(itemGroupSetting.id);
      }
    }

    const code = new ConfigService().get('otherGroupId');
    const otherGroup =
      await this.itemGroupSettingRepository.findOneWithRelations({
        where: { code },
      });

    const validIds = itemGroupSettings
      .filter((itemGroupSetting) => !failIdsList.includes(itemGroupSetting.id))
      .map((itemGroupSetting) => itemGroupSetting.id);

    try {
      if (!isEmpty(validIds)) {
        await this.itemRepository.updateItemsByIds(validIds, otherGroup.id);
        await this.itemGroupSettingRepository.multipleRemove(validIds);
      }
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.CAN_NOT_DELETE'))
        .build();
    }

    if (isEmpty(failIdsList))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.BAD_REQUEST)
      .withMessage(
        stringFormat(
          await this.i18n.t('error.DELETE_MULTIPLE_FAIL'),
          validIds.length,
          ids.length,
        ),
      )
      .build();
  }

  public async getItemGroupSettingDetail(request: IdRequestDto): Promise<any> {
    const itemGroupSetting = await this.itemGroupSettingRepository.findOneById(
      request.id,
    );
    if (!itemGroupSetting) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    if (itemGroupSetting.createdBy) {
      const responseUserService = await this.userService.getUserById(
        itemGroupSetting.createdBy,
      );
      itemGroupSetting.createdBy = responseUserService;
    }
    const response = plainToClass(
      ItemGroupSettingResponseDto,
      itemGroupSetting,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(response)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async confirmItemGroup(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<ItemGroupSettingResponseDto | any>> {
    const { userId, id } = request;
    const itemGroup = await this.itemGroupSettingRepository.findOneById(id);

    if (!itemGroup) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ITEM_GROUP_NOT_FOUND'))
        .build();
    }

    itemGroup.approverId = userId;
    itemGroup.approvedAt = new Date(Date.now());
    itemGroup.status = ItemGroupStatusEnum.CONFIRMED;
    const result = await this.itemGroupSettingRepository.create(itemGroup);
    const response = plainToClass(ItemGroupSettingResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async rejectItemGroup(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<ItemGroupSettingResponseDto | any>> {
    const { userId, id } = request;
    const itemGroup = await this.itemGroupSettingRepository.findOneById(id);

    if (!itemGroup) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ITEM_GROUP_NOT_FOUND'))
        .build();
    }

    if (itemGroup.status === ItemGroupStatusEnum.CONFIRMED) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.ITEM_GROUP_WAS_CONFIRMED'),
      ).toResponse();
    }

    itemGroup.approverId = userId;
    itemGroup.approvedAt = new Date(Date.now());
    itemGroup.status = ItemGroupStatusEnum.REJECT;
    const result = await this.itemGroupSettingRepository.create(itemGroup);
    const response = plainToClass(ItemGroupSettingResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async confirmItemType(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<ItemTypeSettingResponseDto | any>> {
    const { userId, id } = request;
    const itemType = await this.itemTypeSettingRepository.findOneById(id);

    if (!itemType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ITEM_TYPE_NOT_FOUND'))
        .build();
    }

    itemType.approverId = userId;
    itemType.approvedAt = new Date(Date.now());
    itemType.status = ItemTypeStatusEnum.CONFIRMED;
    const result = await this.itemTypeSettingRepository.create(itemType);
    const response = plainToClass(ItemTypeSettingResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async rejectItemType(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<ItemTypeSettingResponseDto | any>> {
    const { userId, id } = request;
    const itemType = await this.itemTypeSettingRepository.findOneById(id);

    if (!itemType) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ITEM_TYPE_NOT_FOUND'))
        .build();
    }

    if (itemType.status === ItemTypeStatusEnum.CONFIRMED) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.ITEM_TYPE_WAS_CONFIRMED'),
      ).toResponse();
    }

    itemType.approverId = userId;
    itemType.approvedAt = new Date(Date.now());
    itemType.status = ItemTypeStatusEnum.REJECT;
    const result = await this.itemTypeSettingRepository.create(itemType);
    const response = plainToClass(ItemTypeSettingResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async confirmItemUnit(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<ItemUnitSettingResponseDto | any>> {
    const { userId, id } = request;
    const itemUnit = await this.itemUnitSettingRepository.findOneById(id);

    if (!itemUnit) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ITEM_UNIT_NOT_FOUND'))
        .build();
    }

    itemUnit.approverId = userId;
    itemUnit.approvedAt = new Date(Date.now());
    itemUnit.status = ItemUnitStatusEnum.CONFIRMED;
    const result = await this.itemUnitSettingRepository.create(itemUnit);
    const response = plainToClass(ItemUnitSettingResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async rejectItemUnit(
    request: SetStatusRequestDto,
  ): Promise<ResponsePayload<ItemUnitSettingResponseDto | any>> {
    const { userId, id } = request;
    const itemUnit = await this.itemUnitSettingRepository.findOneById(id);

    if (!itemUnit) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ITEM_UNIT_NOT_FOUND'))
        .build();
    }

    if (itemUnit.status === ItemUnitStatusEnum.CONFIRMED) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.ITEM_UNIT_WAS_CONFIRMED'),
      ).toResponse();
    }

    itemUnit.approverId = userId;
    itemUnit.approvedAt = new Date(Date.now());
    itemUnit.status = ItemUnitStatusEnum.REJECT;
    const result = await this.itemUnitSettingRepository.create(itemUnit);
    const response = plainToClass(ItemUnitSettingResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async getItemUnitSettingByIds(
    request: GetListItemUnitByIdsRequestDto,
  ): Promise<ItemUnitSettingResponseDto[] | ResponsePayload<any>> {
    const result = await this.itemUnitSettingRepository.findAllByCondition({
      id: In(request.unitIds),
    });
    const response = plainToInstance(ItemUnitSettingResponseDto, result, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }

  async getItemTypeSettingByIds(
    request: GetItemTypeSettiingByIdsRequestDto,
  ): Promise<ItemTypeSettingResponseDto[] | ResponsePayload<any>> {
    const { itemTypeSettingIds } = request;
    const result = await this.itemTypeSettingRepository.findAllByCondition({
      id: In(itemTypeSettingIds),
    });
    const response = plainToInstance(ItemTypeSettingResponseDto, result, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(response)
      .build();
  }
}
