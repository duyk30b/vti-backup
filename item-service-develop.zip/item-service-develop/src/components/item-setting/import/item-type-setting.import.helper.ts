import { ItemTypeSettingRepositoryInterface } from '@components/item/interface/item-type-setting.repository.interface';
import { ImportDataAbstract } from '@core/abstracts/import-data.abstract';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectDataSource } from '@nestjs/typeorm';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty, keyBy } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, In } from 'typeorm';
import { ItemTypeSetting } from '@entities/item/item-type-setting.entity';

@Injectable()
export class ItemTypeSettingImport extends ImportDataAbstract {
  private readonly FIELD_TEMPLATE_CONST = {
    CODE: {
      DB_COL_NAME: 'itemTypeCode',
      COL_NAME: ['Item type code', 'タイプコード', 'Mã kiểu'],
      MAX_LENGTH: 2,
      ALLOW_NULL: false,
      REGEX: /^([a-zA-Z0-9]+)$/,
    },
    NAME: {
      DB_COL_NAME: 'itemTypeName',
      COL_NAME: ['Item type name', 'タイプ名', 'Tên kiểu'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    DESCRIPTION: {
      DB_COL_NAME: 'descriptionType',
      COL_NAME: ['Description', '説明', 'Mô tả'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    REQUIRED_COL_NUM: 4,
  };

  constructor(
    @Inject('ItemTypeSettingRepositoryInterface')
    private readonly itemTypeSettingRepository: ItemTypeSettingRepositoryInterface,
    @InjectDataSource()
    private readonly connection: DataSource,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    this.fieldsMap.groupSet(
      [2, 3, 4],
      [
        this.FIELD_TEMPLATE_CONST.CODE,
        this.FIELD_TEMPLATE_CONST.NAME,
        this.FIELD_TEMPLATE_CONST.DESCRIPTION,
      ],
    );
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
    error: number,
    total: number,
    userIdCreated: number,
  ): Promise<ImportResponseDto> {
    const findByCode = await this.itemTypeSettingRepository.findWithRelations({
      where: {
        code: In(dataDto.map((i) => i.itemTypeCode)),
      },
    });
    const findByName = await this.itemTypeSettingRepository.findWithRelations({
      where: {
        name: In(dataDto.map((i) => i.itemTypeName)),
      },
    });

    findByCode.forEach((i) => Object.assign(i, { type: 'old' }));
    findByName.forEach((i) => Object.assign(i, { type: 'old' }));

    const findByCodeMap = keyBy(findByCode, 'code');
    const findByNameMap = keyBy(findByName, 'name');
    const entities = [];
    const valid = [];
    const {
      duplicateCodeOrNameMsg,
      codeNotExistMsg,
      successMsg,
      unsuccessMsg,
      addText,
      updateText,
    } = await this.getMessage();
    dataDto.forEach((data) => {
      const { i, action, itemTypeCode, itemTypeName, descriptionType } = data;
      const logRow = {
        id: i,
        row: i,
        action: action,
      } as ImportResultDto;
      const msgLogs = [];

      const formatedData = new ItemTypeSetting();
      formatedData.code = itemTypeCode;
      formatedData.name = itemTypeName;
      formatedData.createdBy = userIdCreated;
      formatedData.description = descriptionType;

      if (action.toLowerCase() === addText) {
        if (findByCodeMap[itemTypeCode] || findByNameMap[itemTypeName]) {
          msgLogs.push(duplicateCodeOrNameMsg);
        } else {
          const entity =
            this.itemTypeSettingRepository.createEntity(formatedData);
          entities.push(entity);
          Object.assign(entity, { type: 'new' });
          findByCodeMap[itemTypeCode] = entity;
          findByNameMap[itemTypeName] = entity;
        }
      } else if (action.toLowerCase() === updateText) {
        if (
          findByCodeMap[itemTypeCode] &&
          findByCodeMap[itemTypeCode]?.['type'] === 'old'
        ) {
          if (
            findByNameMap[itemTypeName] &&
            findByNameMap[itemTypeName].id != findByCodeMap[itemTypeCode].id
          ) {
            msgLogs.push(duplicateCodeOrNameMsg);
          } else {
            const entity = this.itemTypeSettingRepository.updateEntity(
              findByCodeMap[itemTypeCode].id,
              formatedData,
            );
            entities.push(entity);
            Object.assign(entity, { type: 'new' });
            findByCodeMap[itemTypeCode] = entity;
            findByNameMap[itemTypeName] = entity;
          }
        } else {
          msgLogs.push(codeNotExistMsg);
        }
      }
      if (isEmpty(msgLogs)) {
        logRow.log = [successMsg];
        valid.push(logRow);
      } else {
        logRow.log = msgLogs;
        logs.push(logRow);
      }
    });
    const response = new ImportResponseDto();
    if (!isEmpty(entities)) {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(entities);
        await queryRunner.commitTransaction();
        response.successCount = valid.length;
      } catch (error) {
        queryRunner.rollbackTransaction();
        response.successCount = 0;
        valid.forEach((l) => (l.log = [unsuccessMsg]));
      } finally {
        await queryRunner.release();
        logs.push(...valid);
      }
    }
    response.result = logs;
    response.totalCount = total;
    response.result;
    return response;
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<ImportResponseDto | any>> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_CONST.REQUIRED_COL_NUM,
    );
  }
}
