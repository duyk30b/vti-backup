import { ImportDataAbstract } from '@core/abstracts/import-data.abstract';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { ImportResponseDto } from '@core/dto/import/response/import.response.dto';
import { ImportResultDto } from '@core/dto/import/response/import.result.dto';
import { Inject, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectDataSource } from '@nestjs/typeorm';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty, keyBy } from 'lodash';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, In } from 'typeorm';
import { ItemUnitSettingRepositoryInterface } from '../interface/item-unit-setting.repository.interface';
import { ItemUnitSetting } from '@entities/item/item-unit-setting.entity';
import { Alignment, Borders, Font, Workbook } from 'exceljs';
import { IMPORT_CONST } from '@constant/import.constant';
import { EXCEL_STYLE } from '@components/export/export.constant';

@Injectable()
export class ItemUnitSettingImport extends ImportDataAbstract {
  private readonly FIELD_TEMPLATE_CONST = {
    CODE: {
      DB_COL_NAME: 'itemUnitCode',
      COL_NAME: ['Item unit code', '単位コード', 'Mã đơn vị'],
      MAX_LENGTH: 20,
      ALLOW_NULL: false,
      REGEX: /^([a-zA-Z0-9]+)$/,
    },
    NAME: {
      DB_COL_NAME: 'itemUnitName',
      COL_NAME: ['Item unit name', '単位名', 'Tên đơn vị'],
      MAX_LENGTH: 255,
      ALLOW_NULL: false,
    },
    DESCRIPTION: {
      DB_COL_NAME: 'descriptionUnit',
      COL_NAME: ['Description', '説明', 'Mô tả'],
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    REQUIRED_COL_NUM: 3,
  };

  constructor(
    @Inject('ItemUnitSettingRepositoryInterface')
    private readonly itemUnitSettingRepository: ItemUnitSettingRepositoryInterface,
    @InjectDataSource()
    private readonly connection: DataSource,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    this.fieldsMap.groupSet(
      [2, 3, 4],
      [
        this.FIELD_TEMPLATE_CONST.CODE,
        this.FIELD_TEMPLATE_CONST.NAME,
        this.FIELD_TEMPLATE_CONST.DESCRIPTION,
      ],
    );
  }

  protected async saveImportDataDto(
    dataDto: any[],
    logs: ImportResultDto[],
    error: number,
    total: number,
    userId?: number,
    workbook?: Workbook,
    sheetName?: string,
  ): Promise<ImportResponseDto> {
    const findByCode = await this.itemUnitSettingRepository.findWithRelations({
      where: {
        code: In(dataDto.map((i) => i.itemUnitCode)),
      },
    });
    const findByName = await this.itemUnitSettingRepository.findWithRelations({
      where: {
        name: In(dataDto.map((i) => i.itemUnitName)),
      },
    });

    findByCode.forEach((i) => Object.assign(i, { type: 'old' }));
    findByName.forEach((i) => Object.assign(i, { type: 'old' }));

    const findByCodeMap = keyBy(findByCode, 'code');
    const findByNameMap = keyBy(findByName, 'name');
    const entities = [];
    const valid = [];
    const {
      duplicateCodeOrNameMsg,
      codeNotExistMsg,
      successMsg,
      unsuccessMsg,
      addText,
      updateText,
    } = await this.getMessage();
    let worksheet;
    let headerRow;
    if (!isEmpty(workbook) && !isEmpty(sheetName)) {
      worksheet = workbook.getWorksheet(sheetName);
      headerRow = worksheet.getRow(IMPORT_CONST.SHEET.HEADER_ROW);
      headerRow.values = headerRow.values.concat([
        await this.i18n.translate('export.importResult.result'),
      ]);
      headerRow.eachCell(function (cell) {
        cell.font = <Font>EXCEL_STYLE.TITLE_FONT;
        cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_CENTER;
        cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
      });
    }
    for (const data of dataDto) {
      const {
        i,
        action,
        itemUnitCode,
        itemUnitName,
        descriptionUnit,
        errorMsg,
      } = data;
      // if (!isEmpty(workbook) && !isEmpty(sheetName) && !isEmpty(errorMsg)) {
      //   const values = worksheet.getRow(
      //     i + IMPORT_CONST.ROW_OFFSET.DEFAULT + 2,
      //   ).values;
      //   values[this.FIELD_TEMPLATE_CONST.REQUIRED_COL_NUM + 1] = errorMsg;
      //   worksheet.getRow(i + IMPORT_CONST.ROW_OFFSET.DEFAULT + 2).values =
      //     values;
      //   continue;
      // }
      const logRow = {
        id: i,
        row: i,
        action: action,
      } as ImportResultDto;
      const msgLogs = [];

      const formatedData = new ItemUnitSetting();
      formatedData.code = itemUnitCode;
      formatedData.name = itemUnitName;
      formatedData.description = descriptionUnit;

      if (action.toLowerCase() === addText) {
        if (findByCodeMap[itemUnitCode] || findByNameMap[itemUnitName]) {
          msgLogs.push(duplicateCodeOrNameMsg);
        } else {
          const entity =
            this.itemUnitSettingRepository.createEntity(formatedData);
          entities.push(entity);
          Object.assign(entity, { type: 'new' });
          findByCodeMap[itemUnitCode] = entity;
          findByNameMap[itemUnitName] = entity;
        }
      } else if (action.toLowerCase() === updateText) {
        if (
          findByCodeMap[itemUnitCode] &&
          findByCodeMap[itemUnitCode]?.['type'] === 'old'
        ) {
          if (
            findByNameMap[itemUnitName] &&
            findByNameMap[itemUnitName].id != findByCodeMap[itemUnitCode].id
          ) {
            msgLogs.push(duplicateCodeOrNameMsg);
          } else {
            const entity = this.itemUnitSettingRepository.updateEntity(
              findByCodeMap[itemUnitCode].id,
              formatedData,
            );
            entities.push(entity);
            Object.assign(entity, { type: 'new' });
            findByCodeMap[itemUnitCode] = entity;
            findByNameMap[itemUnitName] = entity;
          }
        } else {
          msgLogs.push(codeNotExistMsg);
        }
      }
      if (isEmpty(msgLogs)) {
        logRow.log = [successMsg];
        valid.push(logRow);
      } else {
        logRow.log = msgLogs;
        logs.push(logRow);
      }
      // if (!isEmpty(workbook) && !isEmpty(sheetName)) {
      //   const values = worksheet.getRow(
      //     i + IMPORT_CONST.ROW_OFFSET.DEFAULT + 2,
      //   ).values;
      //   values[this.FIELD_TEMPLATE_CONST.REQUIRED_COL_NUM + 1] = logRow.log[0];
      //   worksheet.getRow(i + IMPORT_CONST.ROW_OFFSET.DEFAULT + 2).values =
      //     values;
      // }
    }
    const response = new ImportResponseDto();
    response.successCount = 0;
    if (!isEmpty(entities)) {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(entities);
        await queryRunner.commitTransaction();
        response.successCount = valid.length;
      } catch (error) {
        queryRunner.rollbackTransaction();
        response.successCount = 0;
        valid.forEach((l) => (l.log = [unsuccessMsg]));
      } finally {
        await queryRunner.release();
        logs.push(...valid);
      }
    }
    // response.result = await workbook.xlsx.writeBuffer();
    response.totalCount = dataDto.length;
    return response;
  }

  public async importUtil(
    request: ImportRequestDto,
  ): Promise<ResponsePayload<ImportResponseDto | any>> {
    return super.importUtil(
      request,
      this.FIELD_TEMPLATE_CONST.REQUIRED_COL_NUM,
    );
  }
}
