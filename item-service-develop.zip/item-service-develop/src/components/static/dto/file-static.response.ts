import { SuccessResponse } from '@components/item-setting/dto/response/success.response.dto';

export class FileStaticResponse extends SuccessResponse {
  file: Buffer;
}
