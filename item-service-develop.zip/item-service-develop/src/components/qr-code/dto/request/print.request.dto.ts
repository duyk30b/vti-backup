import { QrcCodeType } from '@components/qr-code/qr-code.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsNotEmpty,
  IsEnum,
  ValidateNested,
  IsInt,
  Min,
  ArrayUnique,
  ArrayNotEmpty,
} from 'class-validator';

class Item {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  id: number;

  @ApiProperty()
  @IsNotEmpty()
  @Min(1, {
    message: 'Số lượng phải lớn hơn 0'
  })
  @IsInt({
    message: 'Số lượng là 1 số dương'
  })
  quantity: number;
}

export class PrintQrcodeRequestDto extends BaseDto {
  @ApiProperty({ description: 'Kiểu của tem cần tem: item, block, package' })
  @IsNotEmpty()
  @IsEnum(QrcCodeType)
  type: string;

  @ApiProperty({
    description: 'Danh sách item cần in',
    type: Item,
    isArray: true,
  })
  @ArrayNotEmpty()
  @ValidateNested()
  @ArrayUnique<Item>((i) => i.id)
  @Type(() => Item)
  items: Item[];
}
