import { SettingService } from './../setting/setting.service';
import { WarehouseService } from '@components/warehouse/warehouse.service';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Package } from '@entities/package/package.entity';
import { PackageRepository } from '@repositories/package.repository';
import { PackageItem } from '@entities/package/package-item.entity';
import { Item } from '@entities/item/item.entity';
import { ItemRepository } from '@repositories/item.repository';
import { BlockRepository } from '@repositories/block.repository';
import { QrCodeService } from './qr-code.service';
import { Block } from '@entities/block/block.entity';
import { SaleService } from '@components/sale/sale.service';
import { SaleModule } from '@components/sale/sale.module';
import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { NotificationService } from '@components/notification/notification.service';
import { NotificationModule } from '@components/notification/notification.module';
import { ConfigService } from '@config/config.service';
import { ItemStockWarehouseLocatorEntity } from '@entities/item/item-stock-warehouse-locator.entity';
import { ItemStockWarehouseLocatorRepository } from '@repositories/item-stock-warehouse-locator.repository';
import { WarehouseLayoutModule } from '@components/warehouse-layout/warehouse-layout.module';
import { WarehouseLayoutService } from '@components/warehouse-layout/warehouse-layout.service';
import { ItemPlanningQuantityEntity } from '@entities/item/item-planning-quantity.entity';
import { ItemPlanningQuantityRepository } from '@repositories/item-planning-quantity.repository';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Package,
      PackageItem,
      Item,
      Block,
      ItemStockWarehouseLocatorEntity,
      ItemPlanningQuantityEntity,
    ]),
    SaleModule,
    WarehouseModule,
    NotificationModule,
    WarehouseLayoutModule,
  ],
  providers: [
    ConfigService,
    {
      provide: 'PackageRepositoryInterface',
      useClass: PackageRepository,
    },
    {
      provide: 'ItemStockWarehouseLocatorRepositoryInterface',
      useClass: ItemStockWarehouseLocatorRepository,
    },
    {
      provide: 'ItemPlanningQuantityRepositoryInterface',
      useClass: ItemPlanningQuantityRepository,
    },
    {
      provide: 'ItemRepositoryInterface',
      useClass: ItemRepository,
    },
    {
      provide: 'BlockRepositoryInterface',
      useClass: BlockRepository,
    },
    {
      provide: 'QrcodeServiceInterface',
      useClass: QrCodeService,
    },
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
    {
      provide: 'WarehouseLayoutServiceInterface',
      useClass: WarehouseLayoutService,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'NotificationServiceInterface',
      useClass: NotificationService,
    },
    {
      provide: 'SettingServiceInterface',
      useClass: SettingService,
    },
    {
      provide: 'ConfigServiceInterface',
      useClass: ConfigService,
    },
  ],
  controllers: [],
  exports: [
    'PackageRepositoryInterface',
    'ItemRepositoryInterface',
    'BlockRepositoryInterface',
    {
      provide: 'ItemPlanningQuantityRepositoryInterface',
      useClass: ItemPlanningQuantityRepository,
    },
    {
      provide: 'QrcodeServiceInterface',
      useClass: QrCodeService,
    },
  ],
})
export class QrCodeModule {}
