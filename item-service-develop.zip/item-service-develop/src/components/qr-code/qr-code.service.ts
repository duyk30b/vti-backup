import { COMPANY_DEFAULT } from './../../constant/common';
import { SettingServiceInterface } from './../setting/interface/setting.service.interface';
import { QrCodeItemTypeEnum } from './../item/item.constant';
import { SettingQrCodeResponseDto } from './../setting/dto/response/setting-qr.response.dto';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { minus } from '@utils/helper';
import { SaleServiceInterface } from './../sale/interface/sale.service.interface';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ApiError } from '@utils/api.error';
import { PrintQrcodeRequestDto } from '@components/qr-code/dto/request/print.request.dto';
import { ItemRepositoryInterface } from '@components/item/interface/item.repository.interface';
import { Injectable, Inject } from '@nestjs/common';
import { In } from 'typeorm';
import { QrCodeServiceInterface } from './interface/qr-code.service.interface';
import { ResponsePayload } from '@utils/response-payload';
import { PackageRepositoryInterface } from '@components/package/interface/package.repository.interface';
import { BlockRepositoryInterface } from '@components/block/interface/block.repository.interface';
import { QrcCodeType, PREFIX_QR_ITEM_CODE_NEW } from './qr-code.constant';
import { map, isEmpty, first, values, groupBy, uniq } from 'lodash';
import { I18nRequestScopeService, I18nService } from 'nestjs-i18n';
import { ItemBarcodeTypeEnum } from '@components/item/item.constant';
import { SaleOrderTypeEnum } from '@components/sale/sale.constant';
import { isNotEmpty } from 'class-validator';
import { GetWarehouseLocationRequest } from '../warehouse/dto/request/get-warehouse-location.request.dto';
import { plainToInstance } from 'class-transformer';
import { OrderTypeEnum as WarehouseOrderTypeEnum } from '@components/warehouse/warehouse.constant';
import {
  ItemStockLocationGroupByLotNumberResponseDto,
  ItemStockLocationResponseDto,
} from '@components/item/dto/response/item-stock-location.response.dto';
import { NotificationServiceInterface } from '@components/notification/interface/notification.service.interface';
import { PushSocketRequestDto } from '@components/notification/dto/request/push-socket.request.dto';
import { ChannelSocketItemEnum } from '@constant/common';
import { ItemStockWarehouseLocatorRepositoryInterface } from '@components/item/interface/item-stock-warehouse-locator.repository.interface';
import { WarehouseLayoutServiceInterface } from '@components/warehouse-layout/interface/warehouse-layout.service.interface';
import { GetListItemInventoryRequestDto } from '@components/warehouse/dto/request/get-list-item-inventory.request.dto';
import { InfoItemBarcodeQuery } from '@components/item/dto/request/qr-code/info-item.query';
import { ItemPlanningQuantityRepositoryInterface } from '@components/item-planning-quantity/interface/item-planning-quantity.repository.interface';
import { ReportItemStockRequestDto } from '@components/dashboard/dto/request/report-item-stock.request.dto';

const startCommandChars = '^XA';
const endCommandChars = '^XZ';

@Injectable()
export class QrCodeService implements QrCodeServiceInterface {
  constructor(
    @Inject('PackageRepositoryInterface')
    private readonly packageRepository: PackageRepositoryInterface,

    @Inject('ItemStockWarehouseLocatorRepositoryInterface')
    private readonly itemStockWarehouseLocatorRepository: ItemStockWarehouseLocatorRepositoryInterface,

    @Inject('ItemRepositoryInterface')
    private readonly itemRepository: ItemRepositoryInterface,

    @Inject('BlockRepositoryInterface')
    private readonly blockRepository: BlockRepositoryInterface,

    @Inject('SaleServiceInterface')
    private readonly saleService: SaleServiceInterface,

    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,

    @Inject('SettingServiceInterface')
    private readonly settingService: SettingServiceInterface,

    @Inject('ItemPlanningQuantityRepositoryInterface')
    private readonly itemPlanningQuantityRepository: ItemPlanningQuantityRepositoryInterface,

    @Inject('NotificationServiceInterface')
    private readonly notificationService: NotificationServiceInterface,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  async scanQrCode(params: any): Promise<ResponsePayload<any>> {
    let order;
    const serilizeItems = {};
    const { qrCode, inventoryId, locatorId } = params;
    const { code, type } = await this.extractItemCodeFromQrCode(qrCode);

    if (params.type === ItemBarcodeTypeEnum.INVENTORY) {
      const item = await this.warehouseService.getListItemInventory({
        id: inventoryId,
        filter: [
          { column: 'itemCode', text: qrCode },
          { column: 'locatorId', text: locatorId },
        ],
      } as GetListItemInventoryRequestDto);
      return new ResponseBuilder()
        .withData(first(item) || {})
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const data = await this.getItemsByQrCode(type, code);
    console.log(data);
    if (isEmpty(data) || isEmpty(data.items))
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();

    if (params.type === ItemBarcodeTypeEnum.INFO_ITEM) {
      return await this.getInfoItem(data, params);
    }

    if (params.type === ItemBarcodeTypeEnum.POI) {
      return await this.getSuggestStoredByPoImportId(
        params,
        data.items.map((item) => item.id),
      );
    }

    if (params.type === ItemBarcodeTypeEnum.STOCK) {
      return await this.getItemStockByQrcode(first(data.items), params);
    }

    if (params.type === ItemBarcodeTypeEnum.SOE) {
      return await this.getSuggestCollectedBySoExportId(
        params,
        data.items.map((item) => item.id),
      );
    }

    if (params.type === ItemBarcodeTypeEnum.RO) {
      return await this.getSuggestByRoId(
        params,
        data.items.map((item) => item.id),
      );
    }

    switch (params.type) {
      case ItemBarcodeTypeEnum.PO: {
        order = await this.getPoItemByQrCode(params);
        break;
      }
      case ItemBarcodeTypeEnum.PRO: {
        order = await this.getProItemByQrCode(params);
        break;
      }
      case ItemBarcodeTypeEnum.SO: {
        order = await this.getSoItemByQrCode(params);
        break;
      }
      case ItemBarcodeTypeEnum.IMO: {
        order = await this.getImoItemByQrCode(params);
        break;
      }
      case ItemBarcodeTypeEnum.EMO: {
        order = await this.getExoItemByQrCode(params);
        break;
      }
      case ItemBarcodeTypeEnum.TRANSFER: {
        return await this.getTransferItemByQrCode(params, data);
        break;
      }
    }
    if (params.type === ItemBarcodeTypeEnum.TRANSFER && !params.transferId) {
      return new ResponseBuilder(first(data.items))
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }
    if (!order)
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    data.items.forEach((item) => {
      serilizeItems[item.id] = item;
    });
    let orderItems = null;
    if (params.type === ItemBarcodeTypeEnum.TRANSFER) {
      const itemsTransfer = !isEmpty(order.itemsExport)
        ? order.itemsExport
        : order.items;
      orderItems = itemsTransfer
        .map((item) => {
          if (params.transferType === WarehouseOrderTypeEnum.EXPORT) {
            return isNotEmpty(serilizeItems[item.id]) &&
              minus(item.planQuantity || 0, item.exportedQuantity || 0)
              ? {
                  ...item,
                  ...serilizeItems[item.id],
                }
              : null;
          }
          return isNotEmpty(serilizeItems[item.id]) &&
            minus(item.exportedQuantity || 0, item.actualQuantity || 0)
            ? {
                ...item,
                ...serilizeItems[item.id],
              }
            : null;
        })
        .filter((item) => isNotEmpty(item));
    } else {
      orderItems = order.items
        .map((item) => {
          return isNotEmpty(serilizeItems[item.id]) &&
            minus(item.planQuantity || 0, item.actualQuantity || 0)
            ? {
                ...item,
                ...serilizeItems[item.id],
              }
            : null;
        })
        .filter((item) => isNotEmpty(item));
    }
    if (isEmpty(orderItems)) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    if (params.type === ItemBarcodeTypeEnum.TRANSFER) {
      return new ResponseBuilder(first(orderItems))
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    return new ResponseBuilder({
      ...order,
      ...data,
      items: orderItems,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param item
   * @param params
   * @returns
   */
  private async getItemStockByQrcode(item: any, params: any): Promise<any> {
    const warehouseRequest = new GetWarehouseLocationRequest();
    warehouseRequest.warehouseId = +params.warehouseId;

    const warehouseStructureDesign =
      await this.warehouseService.getWarehouseLocationByWarehouseId(
        warehouseRequest,
      );

    if (isEmpty(warehouseStructureDesign)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const sectorIds = map(warehouseStructureDesign.warehouseSectors, 'id');
    if (isEmpty(sectorIds)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();
    }
    const itemStock = await this.itemRepository.getItemWarehouseStockByQrCode(
      item.id,
      sectorIds,
    );

    if (isEmpty(itemStock))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.NOT_FOUND'))
        .build();

    const warehouseSectors = warehouseStructureDesign.warehouseSectors;

    itemStock.locations = itemStock.locations.map((itemLocation) => {
      const warehouseSector = warehouseSectors[itemLocation.warehouseSectorId];
      const warehouseShelf = isEmpty(warehouseSector)
        ? {}
        : warehouseSector?.warehouseShelfs[itemLocation.warehouseShelfId];
      const warehouseShelfFloor = isEmpty(warehouseShelf)
        ? {}
        : warehouseShelf?.warehouseShelfFloors[
            itemLocation.warehouseShelfFloorId
          ];

      return {
        warehouse: {
          id: warehouseStructureDesign.id,
          code: warehouseStructureDesign.code,
          name: warehouseStructureDesign.name,
        },
        ...itemLocation,
        warehouseSector: warehouseSector,
        warehouseShelf: warehouseShelf,
        warehouseShelfFloor: warehouseShelfFloor,
      };
    });

    const response = plainToInstance(ItemStockLocationResponseDto, itemStock, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async getInfoItem(
    data: any,
    request: InfoItemBarcodeQuery,
  ): Promise<any> {
    const { warehouseId, locatorId } = request;
    const item = first(data?.items) || {};
    if (!isEmpty(item) && (warehouseId || locatorId)) {
      const itemPlanning =
        await this.itemPlanningQuantityRepository.getTotalItemPlanning({
          warehouseId,
          locatorId,
          itemId: item.id,
        } as ReportItemStockRequestDto);
      const quantityItemPlanning = itemPlanning?.planningQuantity || 0;
      const itemStock =
        await this.itemStockWarehouseLocatorRepository.getTotalItemStock(
          item.id,
          warehouseId,
          locatorId,
        );
      if (
        Number(itemStock) <= 0 ||
        Number(quantityItemPlanning) > Number(itemStock)
      ) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.ITEM_DO_NOT_EXIST_IN_WAREHOUSE'),
        ).toResponse();
      }
    }
    return new ResponseBuilder()
      .withData(item)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param item
   * @param params
   * @returns
   */
  private async getItemStockInventoryByQrcode(
    item: any,
    params: any,
  ): Promise<any> {
    const {
      warehouseId,
      warehouseSectorId,
      warehouseShelfId,
      warehouseShelfFloorId,
    } = params;
    const warehouseRequest = new GetWarehouseLocationRequest();
    warehouseRequest.warehouseId = +params.warehouseId;

    const warehouseStructureDesign =
      await this.warehouseService.getWarehouseLocationByWarehouseId(
        warehouseRequest,
      );

    if (isEmpty(warehouseStructureDesign)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    }

    const itemLocations =
      await this.itemRepository.getItemWarehouseStockGroupByLotNumber(
        item.id,
        warehouseId,
        null,
        null,
        warehouseShelfFloorId,
      );

    if (isEmpty(itemLocations))
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.NOT_FOUND)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();

    const response = plainToInstance(
      ItemStockLocationGroupByLotNumberResponseDto,
      itemLocations,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  /**
   *
   * @param type
   * @param qrCode
   * @returns
   */
  private async getItemsByQrCode(type: string, qrCode: string) {
    let data, item;
    switch (type) {
      case QrcCodeType.ITEM: {
        item = await this.itemRepository.getDetailByQrcode(qrCode);

        if (item) {
          data = {
            items: [item],
          };
        }
        break;
      }
      case QrcCodeType.BLOCK: {
        data = await this.blockRepository.getDetailByCode(qrCode);

        if (data) {
          const sItems = {};
          data.items.forEach((item) => {
            if (sItems[item.item_id]) {
              sItems[item.item_id].details.push({
                id: item.detail_id,
                name: item.detail_name,
                code: item.detail_cdoe,
                quantity: item.detail_quantity,
              });
            } else {
              sItems[item.item_id] = {
                id: item.item_id,
                name: item.item_name,
                code: item.item_code,
                details: [
                  {
                    id: item.detail_id,
                    name: item.detail_name,
                    code: item.detail_code,
                    quantity: item.detail_quantity,
                  },
                ],
              };
            }
          });
          data.items = values(sItems);
        }

        break;
      }

      case QrcCodeType.PACKAGE: {
        data = await this.packageRepository.getDetailByCode(qrCode);
        if (data) {
          data.items = data.items.map((item) => {
            return {
              id: item.item_id,
              name: item.name,
              code: item.code,
              itemPackageQuantity: item.itemQuantity,
              details: item.list_detail,
            };
          });
        }
        break;
      }

      default: {
        item = await this.itemRepository.getDetailByQrcode(qrCode);

        if (item) {
          data = {
            items: [item],
          };
        }
        break;
      }
    }

    return data;
  }

  private async getPoItemByQrCode(payload) {
    const { poId, warehouseId, user, warehouseShelfFloorId } = payload;
    const purchasedOrder = await this.saleService.getOrderByWarehouse(
      SaleOrderTypeEnum.PO,
      poId,
      warehouseId,
      user,
      warehouseShelfFloorId,
    );

    return purchasedOrder;
  }

  private async getImoItemByQrCode(payload) {
    const { ioId, warehouseId, user, warehouseShelfFloorId } = payload;
    const importOrder = await this.saleService.getOrderByWarehouse(
      SaleOrderTypeEnum.IO,
      ioId,
      warehouseId,
      user,
      warehouseShelfFloorId,
    );

    return importOrder;
  }

  private async getExoItemByQrCode(payload) {
    const { eoId, warehouseId, user, warehouseShelfFloorId } = payload;
    const exportOrder = await this.saleService.getOrderByWarehouse(
      SaleOrderTypeEnum.IO,
      eoId,
      warehouseId,
      user,
      warehouseShelfFloorId,
    );

    return exportOrder;
  }

  /**
   *
   * @param payload
   * @returns
   */
  private async getProItemByQrCode(payload) {
    const { proId, warehouseId, user, warehouseShelfFloorId } = payload;
    const productionOrder = await this.saleService.getOrderByWarehouse(
      SaleOrderTypeEnum.PRO,
      proId,
      warehouseId,
      user,
      warehouseShelfFloorId,
    );

    return productionOrder;
  }

  /**
   *
   * @param payload
   * @returns
   */
  private async getSoItemByQrCode(payload) {
    const { soId, warehouseId, user, warehouseShelfFloorId } = payload;
    const saleOrder = await this.saleService.getOrderByWarehouse(
      SaleOrderTypeEnum.SO,
      soId,
      warehouseId,
      user,
      warehouseShelfFloorId,
    );
    if (saleOrder) {
      saleOrder.warehouse = [saleOrder?.warehouse];
    }

    return saleOrder;
  }

  /**
   *
   * @param payload
   * @returns
   */
  private async getTransferItemByQrCode(payload, data) {
    const item = first(data?.items);
    const warehouseTransfer =
      await this.warehouseService.suggestTransferDetaild(
        payload.transferId,
        payload.transferType,
        item.id,
      );

    return warehouseTransfer;
  }

  /**
   *
   * @param payload
   * @returns
   */
  private async getSuggestStoredByPoImportId(payload, itemIds) {
    const result = await this.saleService.getSuggestStoredByPoImportId(
      +payload.poId,
      itemIds,
    );

    return result;
  }

  /**
   *
   * @param payload
   * @returns
   */
  private async getSuggestCollectedBySoExportId(payload, itemIds) {
    const result = await this.saleService.getSuggestCollectedBySoExportId(
      +payload.soId,
      itemIds,
    );

    return result;
  }

  /**
   *
   * @param payload
   * @returns
   */
  private async getSuggestByRoId(payload, itemIds) {
    const result = await this.saleService.getSuggestByRoId(
      +payload.roId,
      itemIds,
    );

    return result;
  }

  /**
   *
   * @param request
   * @returns
   */
  public async print(
    request: PrintQrcodeRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { type, items } = request;
    let raw;
    const filter = {
      select: ['id', 'code', 'name'],
      where: {
        id: In(map(items, 'id')),
      },
    };

    switch (type) {
      case QrcCodeType.ITEM:
        raw = await this.itemRepository.findWithRelations({
          ...filter,
          relations: ['itemType'],
        });
        break;
      case QrcCodeType.BLOCK:
        raw = await this.blockRepository.findWithRelations(filter);
        break;

      default:
      case QrcCodeType.BLOCK:
        raw = await this.packageRepository.findWithRelations(filter);
        break;
    }

    if (isEmpty(raw)) {
      return new ApiError(ResponseCodeEnum.NOT_FOUND).toResponse();
    }
    const serilizeItems = {};
    items.forEach((item) => {
      serilizeItems[item.id] = item;
    });
    const formatItems = raw.map((item) => {
      return {
        ...item,
        ...serilizeItems[item.id],
      };
    });
    const data = this.formatQrCodeData(type, formatItems);
    const response = new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();

    const requestPushSocket = new PushSocketRequestDto();
    requestPushSocket.channel = ChannelSocketItemEnum.PRINT_QR;
    requestPushSocket.payload = response;
    await this.notificationService.pushSocket(requestPushSocket);
    return response;
  }

  formatQrCodeData = (type, items) => {
    let responseString = '';
    items.forEach((item) => {
      let title;
      if (type === QrcCodeType.BLOCK) {
        title = 'KIỆN';
      } else if (type === QrcCodeType.PACKAGE) {
        title = 'PACKAGE';
      } else {
        title = item.itemType.name;
      }

      responseString +=
        `${startCommandChars}^FT27,365^BQN,2,9^FH\^FDLA,${item.code}^FS^CI27^FO0,25^FB750,0,0,c,0^A@N,34,34,E:TIM000.TTF^FH^CI28^FD${title}^FS^CI27^FO250,150^FB450,100^A@N,34,34,E:TIM000.TTF^FH^CI28^FDMã: ${item.code}\\&Tên: ${item.name}${endCommandChars}`.repeat(
          item.quantity,
        );
    });
    return responseString;
  };

  private extractItemCodeFromQrCode = async (
    qrCode: string,
  ): Promise<{ code: string; type: string }> => {
    if (!qrCode) throw new Error('qr_code incorrect!');
    let itemCode = await this.scanQrCodeNew(qrCode);
    if (!itemCode) {
      itemCode = this.scanQrCodeOld(qrCode);
    }
    return { code: itemCode, type: QrcCodeType.ITEM };
  };

  private scanQrCodeOld(qrCode: string): string {
    return qrCode.slice(0, 22);
  }

  private async scanQrCodeNew(qrCode: string): Promise<string | null> {
    const setting = await this.settingService.getSettingQrCode();
    const headQrCodeSetting = [
      this.generateVersion(setting),
      this.generateInitializationMethod(setting),
      this.generateHeadObjectCategory(),
      `+([0-9\\d.]{3})+`,
      `${this.generateUnique(setting)}`,
      `${PREFIX_QR_ITEM_CODE_NEW}`,
    ].join('');
    const company = `-${COMPANY_DEFAULT}`;
    const pattern = `(^${headQrCodeSetting})+((?=.*.{6})[a-zA-Z\\d.]{22})+(${company}$)`;
    if (!new RegExp(pattern).test(qrCode)) {
      return null;
    }
    return qrCode.match(pattern)?.[3];
  }

  public generateQrCode(
    type: QrCodeItemTypeEnum,
    itemCode: string,
    objectCategoryId: number,
    companyCode: string,
    warehouseCode?: string,
    setting?: SettingQrCodeResponseDto,
  ): string {
    let qrCode = itemCode;
    if (type === QrCodeItemTypeEnum.NEW) {
      qrCode = [
        this.generateVersion(setting),
        this.generateInitializationMethod(setting),
        this.generateObjectCategory(objectCategoryId),
        this.generateUnique(setting),
        this.generateRuleItem(itemCode, companyCode),
      ].join('');
    } else {
      qrCode = [
        itemCode,
        '0001',
        warehouseCode,
        warehouseCode,
        '***************',
      ].join('');
    }
    return qrCode;
  }

  private generateRuleItem(itemCode: string, companyCode: string): string {
    return `${PREFIX_QR_ITEM_CODE_NEW}${itemCode}-${companyCode}`;
  }

  private generateVersion(setting?: SettingQrCodeResponseDto): string {
    return [
      setting.version.id,
      this.formatLengthQR(setting.version.length),
      setting.version.value,
    ].join('');
  }

  private generateHeadObjectCategory(): string {
    return ['02', '03'].join('');
  }

  private generateObjectCategory(objectCategoryId: number): string {
    return [
      this.generateHeadObjectCategory(),
      this.formatLengthQR(objectCategoryId, 3, '0'),
    ].join('');
  }

  private generateUnique(setting?: SettingQrCodeResponseDto): string {
    return [
      setting.uniqueId.id,
      this.formatLengthQR(setting.uniqueId.length),
      setting.uniqueId.value,
    ].join('');
  }

  private generateHeadInitializationMethod(
    setting?: SettingQrCodeResponseDto,
  ): string {
    const length =
      this.generateInitializationMethodSub1(setting).length +
      this.generateInitializationMethodSub2(setting).length +
      this.generateInitializationMethodSub3(setting).length;
    return [
      setting.initializationMethod.id.id,
      this.formatLengthQR(length),
    ].join('');
  }

  private generateInitializationMethod(
    setting?: SettingQrCodeResponseDto,
  ): string {
    return [
      this.generateHeadInitializationMethod(setting),
      this.generateInitializationMethodSub1(setting),
      this.generateInitializationMethodSub2(setting),
      this.generateInitializationMethodSub3(setting),
    ].join('');
  }

  private generateInitializationMethodSub1(
    setting?: SettingQrCodeResponseDto,
  ): string {
    return [
      setting.initializationMethod.subId1.id,
      this.formatLengthQR(setting.initializationMethod.subId1.length),
      setting.initializationMethod.subId1.value,
    ].join('');
  }

  private generateInitializationMethodSub2(
    setting?: SettingQrCodeResponseDto,
  ): string {
    return [
      setting.initializationMethod.subId2.id,
      this.formatLengthQR(setting.initializationMethod.subId2.length),
      setting.initializationMethod.subId2.value,
    ].join('');
  }

  private generateInitializationMethodSub3(
    setting?: SettingQrCodeResponseDto,
  ): string {
    return [
      setting.initializationMethod.subId3.id,
      this.formatLengthQR(setting.initializationMethod.subId3.length),
      setting.initializationMethod.subId3.value,
    ].join('');
  }

  private formatLengthQR(value: number, length = 2, prefix = '0'): string {
    return value.toString().padStart(length, prefix);
  }
}
