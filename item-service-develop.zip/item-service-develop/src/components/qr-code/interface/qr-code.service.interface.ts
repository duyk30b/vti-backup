import { SettingQrCodeResponseDto } from './../../setting/dto/response/setting-qr.response.dto';
import { ResponsePayload } from '@utils/response-payload';
import { PrintQrcodeRequestDto } from '../dto/request/print.request.dto';
import { QrCodeItemTypeEnum } from '@components/item/item.constant';

export interface QrCodeServiceInterface {
  print(request: PrintQrcodeRequestDto): Promise<ResponsePayload<any>>;
  scanQrCode(params: any): Promise<ResponsePayload<any>>;
  generateQrCode(
    type: QrCodeItemTypeEnum,
    itemCode: string,
    objectCategoryId: number,
    companyCode: string,
    warehouseCode?: string,
    setting?: SettingQrCodeResponseDto,
  ): string;
}
