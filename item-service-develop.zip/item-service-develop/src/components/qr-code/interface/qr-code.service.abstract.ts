export class AbstractItemBarcodeService {
  extractItemCodeFromQrCode = (
    qr_code: string,
  ): { code: string; type: string } => {
    if (!qr_code) throw new Error('qr_code incorrect!');
    const type = qr_code.slice(0, 2);

    return { code: qr_code, type };
  };
}
