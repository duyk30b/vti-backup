export enum QrcCodeType {
  ITEM = '02',
  BLOCK = '03',
  PACKAGE = '04',
}

export const PREFIX_QR_ITEM_CODE_NEW = '0429';
