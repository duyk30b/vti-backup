import { GetListBomRequestDto } from '@components/produce/dto/request/get-list-bom.request.dto';

export interface ProduceServiceInterface {
  getBomItem(request: GetListBomRequestDto): Promise<any>;
  getMaterialRequestWarningDetail(id: number): Promise<any>;
  getMoById(id: number): Promise<any>;
  getBomsByItemIds(itemIds: number[]): Promise<any>
}
