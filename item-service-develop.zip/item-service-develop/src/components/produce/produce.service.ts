import { Inject, Injectable } from '@nestjs/common';
import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { ClientProxy } from '@nestjs/microservices';
import { GetListBomRequestDto } from '@components/produce/dto/request/get-list-bom.request.dto';
import { REQUEST } from '@nestjs/core';
import { Request } from 'express';
import { ResponseCodeEnum } from '@constant/response-code.enum';

@Injectable()
export class ProduceService implements ProduceServiceInterface {
  constructor(
    @Inject('PRODUCE_SERVICE_CLIENT')
    private readonly produceServiceClient: ClientProxy,

    @Inject(REQUEST) private readonly req: Request,
  ) {}

  async getBomItem(request: GetListBomRequestDto): Promise<any> {
    const userId = await this.req['user']?.id;
    const payload = {
      ...request,
      userId: userId,
    };
    return await this.produceServiceClient
      .send('get_bom_list', payload)
      .toPromise();
  }

  async getMaterialRequestWarningDetail(id: number): Promise<any> {
    const response = await this.produceServiceClient
      .send('material_request_warning_detail', { id })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return null;
    }

    return response.data;
  }

  public async getMoById(id: number): Promise<any> {
    const response = await this.produceServiceClient
      .send('get_mo_detail', { id })
      .toPromise();
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return {};
    return response.data;
  }

  public async getBomsByItemIds(itemIds: number[]): Promise<any> {
    const response = await this.produceServiceClient
      .send('get_bom_by_item_ids', { itemIds })
      .toPromise();

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return null;
    }

    return response.data;
  }
}
