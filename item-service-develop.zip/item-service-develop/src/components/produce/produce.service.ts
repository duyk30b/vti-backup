import { Inject, Injectable } from '@nestjs/common';
import { ProduceServiceInterface } from '@components/produce/interface/produce.service.interface';
import { GetListBomRequestDto } from '@components/produce/dto/request/get-list-bom.request.dto';
import { REQUEST } from '@nestjs/core';
import { Request } from 'express';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { NatsClientService } from '@core/transporter/nats-transporter/nats-client.service';
import { NATS_PRODUCE } from '@config/nats.config';

@Injectable()
export class ProduceService implements ProduceServiceInterface {
  constructor(
    private readonly natsClientService: NatsClientService,
    @Inject(REQUEST) private readonly req: Request,
  ) {}

  async getBomItem(request: GetListBomRequestDto): Promise<any> {
    const userId = await this.req['user']?.id;
    const payload = {
      ...request,
      userId: userId,
    };
    return await this.natsClientService.send(
      `${NATS_PRODUCE}.get_bom_list`,
      payload,
    );
  }

  async getMaterialRequestWarningDetail(id: number): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.material_request_warning_detail`,
      { id },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return null;
    }

    return response.data;
  }

  public async getMoById(id: number): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_mo_detail`,
      { id },
    );
    if (response.statusCode !== ResponseCodeEnum.SUCCESS) return {};
    return response.data;
  }

  async getBomsByItemIds(itemIds: number[]): Promise<any> {
    const response = await this.natsClientService.send(
      `${NATS_PRODUCE}.get_bom_by_item_ids`,
      {
        itemIds,
      },
    );

    if (response.statusCode !== ResponseCodeEnum.SUCCESS) {
      return null;
    }

    return response.data;
  }
}
