export enum UrlSettingServiceEnum {
  GET_SETTING_QR_CODE = 'setting-qr',
}
