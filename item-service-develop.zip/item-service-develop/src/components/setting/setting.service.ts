import { SettingQrCodeResponseDto } from './dto/response/setting-qr.response.dto';
import { plainToInstance } from 'class-transformer';
import { UrlSettingServiceEnum } from './setting.constant';
import { APIPrefix } from '@constant/common';
import { HttpClientService } from '@core/components/http-client/http-client.service';
import { ConfigService } from '@config/config.service';
import { SettingServiceInterface } from './interface/setting.service.interface';
import { Inject, Injectable } from '@nestjs/common';
import { HttpClientCronService } from '@core/components/http-client/http-client.cron.service';

@Injectable()
export class SettingService implements SettingServiceInterface {
  protected readonly urlConfig: any;
  protected readonly url: string;
  constructor(
    @Inject('ConfigServiceInterface')
    private readonly configService: ConfigService,
    private readonly httpClientService: HttpClientService,
  ) {
    this.configService = new ConfigService();
    this.urlConfig = this.configService.get('settingService');
    this.url = `http://${
      this.urlConfig?.options?.host + ':' + this.urlConfig?.options?.port
    }`;
  }

  public async getSettingQrCode(): Promise<SettingQrCodeResponseDto | any> {
    try {
      const data = await this.httpClientService.get(
        this.generateUrlFileService(UrlSettingServiceEnum.GET_SETTING_QR_CODE),
      );
      const response = plainToInstance(SettingQrCodeResponseDto, data.data);
      return response;
    } catch (err) {
      console.log(err);
      return {};
    }
  }

  private generateUrlFileService(type: string): string {
    return `${this.url}/${APIPrefix.Version}/settings/${type}`;
  }
}
