import { Expose, Type } from 'class-transformer';
class Unique {
  @Expose()
  id: string;

  @Expose()
  value: string;

  @Expose()
  length: number;
}

class IdInitializationMethod {
  @Expose()
  id: string;

  @Expose()
  value: string;

  @Expose()
  length: number;
}

class Version {
  @Expose()
  id: string;

  @Expose()
  value: string;

  @Expose()
  length: number;
}
class SubIdInitializationMethod {
  @Expose()
  id: string;

  @Expose()
  value: string;

  @Expose()
  length: number;
}

class InitializationMethod {
  @Expose()
  @Type(() => IdInitializationMethod)
  id: IdInitializationMethod;

  @Expose()
  @Type(() => SubIdInitializationMethod)
  subId1: SubIdInitializationMethod;

  @Expose()
  @Type(() => SubIdInitializationMethod)
  subId2: SubIdInitializationMethod;

  @Expose()
  @Type(() => SubIdInitializationMethod)
  subId3: SubIdInitializationMethod;
}

export class SettingQrCodeResponseDto {
  @Expose()
  @Type(() => Version)
  version: Version;

  @Expose()
  @Type(() => InitializationMethod)
  initializationMethod: InitializationMethod;

  @Expose()
  @Type(() => Unique)
  uniqueId: Unique;
}
