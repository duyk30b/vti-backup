import { SettingQrCodeResponseDto } from '../dto/response/setting-qr.response.dto';

export interface SettingServiceInterface {
  getSettingQrCode(): Promise<SettingQrCodeResponseDto | any>;
}
