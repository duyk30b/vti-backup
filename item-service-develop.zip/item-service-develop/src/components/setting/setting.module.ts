import { SettingService } from './setting.service';
import { Global, Module } from '@nestjs/common';

@Global()
@Module({
  providers: [
    {
      provide: 'SettingServiceInterface',
      useClass: SettingService,
    },
  ],
})
export class SettingModule {}
