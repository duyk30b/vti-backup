import { CreateInventoryTimeNormRequestDto } from '../dto/request/create-inventory-time-norm.request.dto';
import { GetInventoryTimeNormRequestDto } from '../dto/request/get-inventory-time-norm-detail.request.dto';
import { GetListInventoryNormRequestDto } from '../dto/request/get-list-inventory-time-norm.request.dto';
import { UpdateInventoryTimeNormRequestDto } from '../dto/request/update-inventory-time-norm.request.dto';

export interface InventoryTimeNormServiceInterface {
  create(request: CreateInventoryTimeNormRequestDto): Promise<any>;
  update(request: UpdateInventoryTimeNormRequestDto): Promise<any>;
  delete(request: GetInventoryTimeNormRequestDto): Promise<any>;
  detail(request: GetInventoryTimeNormRequestDto): Promise<any>;
  getList(request: GetListInventoryNormRequestDto): Promise<any>;
}
