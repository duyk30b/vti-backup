import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { InventoryTimeNorm } from '@entities/inventory-norm/inventory-time-norm.entity';
import { GetListInventoryNormRequestDto } from '../dto/request/get-list-inventory-time-norm.request.dto';

export interface InventoryTimeNormRepositoryInterface
  extends BaseInterfaceRepository<InventoryTimeNorm> {
  getList(request: GetListInventoryNormRequestDto): Promise<any>;
}
