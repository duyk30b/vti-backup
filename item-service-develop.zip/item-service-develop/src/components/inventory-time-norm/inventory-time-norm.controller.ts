import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty } from 'lodash';
import { GetListInventoryNormRequestDto } from './dto/request/get-list-inventory-time-norm.request.dto';
import { InventoryTimeNormServiceInterface } from './interface/inventory-time-norm.service.interface';
import { PermissionCode } from '@core/decorator/get-code.decorator';

import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { InventoryTimeNormResponseDto } from './dto/response/inventory-time-norm.response.dto';
import { CreateInventoryTimeNormRequestDto } from './dto/request/create-inventory-time-norm.request.dto';
import { UpdateInventoryTimeNormBodyDto } from './dto/request/update-inventory-time-norm.request.dto';
import {
  CREATE_INVENTORY_TIME_NORM_PERMISSION,
  UPDATE_INVENTORY_TIME_NORM_PERMISSION,
  DELETE_INVENTORY_TIME_NORM_PERMISSION,
  DETAIL_INVENTORY_TIME_NORM_PERMISSION,
  LIST_INVENTORY_TIME_NORM_PERMISSION,
} from '@utils/permissions/inventory-time-norm';
import { GetInventoryTimeNormRequestDto } from './dto/request/get-inventory-time-norm-detail.request.dto';

@Controller('inventory-time-norms')
export class InventoryTimeNormController {
  constructor(
    @Inject('InventoryTimeNormServiceInterface')
    private readonly inventoryTimeNormService: InventoryTimeNormServiceInterface,
  ) {}

  @PermissionCode(CREATE_INVENTORY_TIME_NORM_PERMISSION.code)
  @Post('/create')
  @ApiOperation({
    tags: ['Inventory time norm'],
    summary: 'Create new inventory time norm',
    description: 'Tạo giới hạn lưu kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: InventoryTimeNormResponseDto,
  })
  public async create(
    @Body() payload: CreateInventoryTimeNormRequestDto,
  ): Promise<ResponsePayload<InventoryTimeNormResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryTimeNormService.create(request);
  }

  @PermissionCode(UPDATE_INVENTORY_TIME_NORM_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Inventory time norm'],
    summary: 'Update inventory time norm',
    description: 'Cập nhật thông tin giới hạn lưu kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: InventoryTimeNormResponseDto,
  })
  public async update(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateInventoryTimeNormBodyDto,
  ): Promise<ResponsePayload<InventoryTimeNormResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryTimeNormService.update({
      id,
      ...request,
    });
  }

  @PermissionCode(DELETE_INVENTORY_TIME_NORM_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Inventory time norm'],
    summary: 'Delete inventory time norm',
    description: 'Xóa giới hạn lưu kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async delete(
    @Param() param: GetInventoryTimeNormRequestDto,
  ): Promise<ResponsePayload<InventoryTimeNormResponseDto | any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryTimeNormService.delete(request);
  }

  @PermissionCode(DETAIL_INVENTORY_TIME_NORM_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Inventory time norm'],
    summary: 'Detail Inventory time norm',
    description: 'Chi tiết giới hạn lưu kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: InventoryTimeNormResponseDto,
  })
  public async detail(
    @Param() param: GetInventoryTimeNormRequestDto,
  ): Promise<ResponsePayload<InventoryTimeNormResponseDto | any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryTimeNormService.detail(request);
  }

  @PermissionCode(LIST_INVENTORY_TIME_NORM_PERMISSION.code)
  @Get('/list')
  @ApiOperation({
    tags: ['Inventory time norm'],
    summary: 'List Inventory time norm',
    description: 'Danh sách giới hạn tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: null,
  })
  public async getList(
    @Query() payload: GetListInventoryNormRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryTimeNormService.getList(request);
  }

  @MessagePattern('inventory_time_norm_list')
  public async getListTcp(
    @Body() payload: GetListInventoryNormRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryTimeNormService.getList(request);
  }
}
