import { ItemRepositoryInterface } from '@components/item/interface/item.repository.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Injectable, Inject } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource } from 'typeorm';
import { CreateInventoryTimeNormRequestDto } from './dto/request/create-inventory-time-norm.request.dto';
import { GetListInventoryNormRequestDto } from './dto/request/get-list-inventory-time-norm.request.dto';
import { InventoryTimeNormResponseDto } from './dto/response/inventory-time-norm.response.dto';
import { InventoryTimeNormServiceInterface } from './interface/inventory-time-norm.service.interface';
import { InventoryTimeNormRepositoryInterface } from './interface/inventory-time-norm.repository.interface';
import { GetInventoryTimeNormRequestDto } from './dto/request/get-inventory-time-norm-detail.request.dto';
import { UpdateInventoryTimeNormRequestDto } from './dto/request/update-inventory-time-norm.request.dto';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { InventoryNormRepositoryInterface } from '@components/inventory-norm/interface/inventory-norm.repository.interface';
import { InventoryTimeNorm } from '@entities/inventory-norm/inventory-time-norm.entity';
import { Item } from '@entities/item/item.entity';
import { uniq } from 'lodash';

@Injectable()
export class InventoryTimeNormService
  implements InventoryTimeNormServiceInterface
{
  constructor(
    @Inject('InventoryTimeNormRepositoryInterface')
    private readonly inventoryTimeNormRepository: InventoryTimeNormRepositoryInterface,

    @Inject('InventoryNormRepositoryInterface')
    private readonly inventoryNormRepository: InventoryNormRepositoryInterface,

    @Inject('ItemRepositoryInterface')
    private readonly itemRepository: ItemRepositoryInterface,

    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nRequestScopeService,
  ) {}

  public async create(
    request: CreateInventoryTimeNormRequestDto,
  ): Promise<any> {
    const { itemId, warehouseId, expiryWarehouse, expiryWarningWarehouse } =
      request;

    const item = await this.itemRepository.findOneById(itemId);
    if (!item) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const warehouse = await this.warehouseService.getWarehouseDetail(
      warehouseId,
      request.userId,
    );
    if (!warehouse) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const existedNorm =
      await this.inventoryTimeNormRepository.findOneWithRelations({
        where: { itemId: request.itemId, warehouseId: request.warehouseId },
        withDeleted: true,
      });

    if (
      existedNorm &&
      existedNorm.expiryWarehouse !== null &&
      existedNorm.timeNormDeletedAt == null
    ) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.INVENTORY_TIME_NORM_EXIST'),
      ).toResponse();
    }

    if (expiryWarehouse < expiryWarningWarehouse) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.INVALID_EXPIRY_ERROR'),
      ).toResponse();
    }
    if (item.dayExpire < expiryWarningWarehouse) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.INVALID_EXPIRY_WAREHOUSE'),
      ).toResponse();
    }
    const inventoryTimeNorm = await this.inventoryTimeNormRepository.create({
      ...request,
      id: existedNorm?.id,
      timeNormDeletedAt: null,
    });
    return this.generateResponse(inventoryTimeNorm, item, warehouse);
  }

  public async update(
    request: UpdateInventoryTimeNormRequestDto,
  ): Promise<any> {
    const existNorm = await this.inventoryTimeNormRepository.findOneById(
      request.id,
    );
    if (!existNorm) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const item = await this.itemRepository.findOneById(existNorm.itemId);
    if (!item) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const warehouse = await this.warehouseService.getWarehouseDetail(
      existNorm.warehouseId,
      request.userId,
    );
    const { expiryWarehouse, expiryWarningWarehouse } = request;

    if (expiryWarehouse < expiryWarningWarehouse) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.INVALID_EXPIRY_ERROR'),
      ).toResponse();
    }

    if (item.dayExpire < expiryWarningWarehouse) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.INVALID_EXPIRY_WAREHOUSE'),
      ).toResponse();
    }

    const updatedInventoryTimeNorm = await this.inventoryNormRepository.create({
      ...request,
      id: request.id,
    });
    return this.generateResponse(updatedInventoryTimeNorm, item, warehouse);
  }

  public async delete(request: GetInventoryTimeNormRequestDto): Promise<any> {
    const inventoryNorm = await this.inventoryTimeNormRepository.findOneById(
      request.id,
    );

    if (!inventoryNorm) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    try {
      await this.inventoryTimeNormRepository.softRemove(request.id);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    return new ResponseBuilder()
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async detail(request: GetInventoryTimeNormRequestDto): Promise<any> {
    const inventoryNorm = await this.inventoryTimeNormRepository.findOneById(
      request.id,
    );

    if (!inventoryNorm) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const item = await this.itemRepository.findOneWithRelations({
      where: {
        id: inventoryNorm.itemId,
      },
      relations: ['itemType', 'itemUnit'],
    });
    if (item) {
      inventoryNorm.item = item;
    }
    const warehouse = await this.warehouseService.getWarehouseDetail(
      inventoryNorm.warehouseId,
      request.userId,
    );
    return this.generateResponse(inventoryNorm, item, warehouse);
  }

  public async getList(request: GetListInventoryNormRequestDto): Promise<any> {
    const { data, total } = await this.inventoryTimeNormRepository.getList(
      request,
    );
    const warehouseIds = data.map((item) => item.warehouseId);
    const warehouses = await this.warehouseService.getListByIDs(
      uniq(warehouseIds),
      true,
    );
    data.forEach((item) => {
      const warehouse = warehouses[item.warehouseId];
      if (warehouse) {
        item.warehouse = warehouse;
      }
    });
    const response = plainToInstance(InventoryTimeNormResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: total, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async generateResponse(
    inventoryNorm: InventoryTimeNorm,
    item: Item,
    warehouse: any,
  ): Promise<any> {
    const response = plainToInstance(
      InventoryTimeNormResponseDto,
      {
        ...inventoryNorm,
        item,
        warehouse,
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<InventoryTimeNormResponseDto>(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
