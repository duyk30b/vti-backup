import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsInt, IsOptional } from 'class-validator';

export class CreateInventoryTimeNormRequestDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'mã vật tư' })
  @IsInt()
  itemId: number;

  @ApiProperty({ example: 1, description: 'mã kho' })
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @ApiPropertyOptional({
    example: 1,
    description: 'Thời hạn lưu kho',
    default: 0,
  })
  @IsOptional()
  @IsInt()
  expiryWarehouse: number;

  @ApiPropertyOptional({
    example: 1,
    description: 'Thời hạn cảnh báo lưu kho',
    default: 0,
  })
  @IsOptional()
  @IsInt()
  expiryWarningWarehouse: number;
}
