import { IsGetAllEnum } from '@components/inventory-time-norm/inventory-time-norm.constant';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsEnum, IsOptional } from 'class-validator';

export class GetListInventoryNormRequestDto extends PaginationQuery {
  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(IsGetAllEnum)
  isGetAll: string;
}
