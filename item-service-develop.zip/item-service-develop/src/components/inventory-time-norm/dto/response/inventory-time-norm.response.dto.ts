import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

export class WarehouseResponseDto {
  @ApiProperty({ example: 1, description: 'id của kho' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: 'tên của kho' })
  @Expose()
  name: string;

  @ApiProperty({ example: 1, description: 'mã của kho' })
  @Expose()
  code: string;
}

export class ItemResponseDto {
  @ApiProperty({ example: 1, description: 'id của kho' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: 'tên của kho' })
  @Expose()
  name: string;

  @ApiProperty({ example: 1, description: 'mã của kho' })
  @Expose()
  code: string;
}

export class InventoryTimeNormResponseDto {
  @ApiProperty({ example: 1, description: 'id của giới hạn tồn kho/ lưu kho' })
  @Expose()
  id: number;

  @ApiProperty({ type: ItemResponseDto })
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty({ type: WarehouseResponseDto })
  @Expose()
  @Type(() => WarehouseResponseDto)
  warehouse: WarehouseResponseDto;

  @ApiProperty({ example: 1, description: 'Thời hạn lưu kho' })
  @Expose()
  expiryWarehouse: number;

  @ApiProperty({ example: 1, description: 'Thời hạn cảnh báo lưu kho' })
  @Expose()
  expiryWarningWarehouse: number;
}
