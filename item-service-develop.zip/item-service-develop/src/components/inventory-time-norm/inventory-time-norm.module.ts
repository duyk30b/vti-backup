import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { WarehouseService } from '@components/warehouse/warehouse.service';
import { InventoryNorm } from '@entities/inventory-norm/inventory-norm.entity';
import { InventoryTimeNorm } from '@entities/inventory-norm/inventory-time-norm.entity';
import { Item } from '@entities/item/item.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InventoryNormRepository } from '@repositories/inventory-norm.repository';
import { InventoryTimeNormRepository } from '@repositories/inventory-time-norm.repository';
import { ItemRepository } from '@repositories/item.repository';
import { InventoryTimeNormController } from './inventory-time-norm.controller';
import { InventoryTimeNormService } from './inventory-time-norm.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([InventoryNorm, InventoryTimeNorm, Item]),
    WarehouseModule,
  ],
  providers: [
    {
      provide: 'InventoryTimeNormRepositoryInterface',
      useClass: InventoryTimeNormRepository,
    },
    {
      provide: 'InventoryNormRepositoryInterface',
      useClass: InventoryNormRepository,
    },
    {
      provide: 'InventoryTimeNormServiceInterface',
      useClass: InventoryTimeNormService,
    },
    {
      provide: 'ItemRepositoryInterface',
      useClass: ItemRepository,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
  ],
  controllers: [InventoryTimeNormController],
})
export class InventoryTimeNormModule {}
