import { ItemPlanningQuantityEntity } from './../../entities/item/item-planning-quantity.entity';
import { keyBy, isEmpty, has } from 'lodash';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ResponseBuilder } from '@utils/response-builder';
import { CreateItemPlanningQuantitiesRequestDto } from './dto/request/create-item-planning-quantity.request.dto';
import { ItemPlanningQuantityRepositoryInterface } from './interface/item-planning-quantity.repository.interface';
import { ItemPlanningQuantityServiceInterface } from './interface/item-planning-quantity.service.interface';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, In } from 'typeorm';
import { Inject, Injectable } from '@nestjs/common';
import { GetItemPlanningQuantityByOrder } from './dto/request/get-item-planning-quantity-by-order.request.dto';
import { GetItemPlanningQuantityByOrderIdRequestDto } from './dto/request/get-item-planning-quantity-by-order-id.request.dto';
import { SaleOrderTypeEnum } from '@components/sale/sale.constant';
import { RemoveItemPlanningQuantityRequestDto } from './dto/request/remove-item-planning-quantity.request.dto';
import { RollbackItemPlanningQuantityRequestDto } from './dto/request/rollback-item-planning-quantity.request.dto copy';
import { plus } from '@utils/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { EventItemPlanningQuantityEnum } from './item-planning-quantity.constant';
import { SyncItemPlanningQuantityEventDto } from './events/sync-item-planning-quantity.event';

@Injectable()
export class ItemPlanningQuantityService
  implements ItemPlanningQuantityServiceInterface
{
  constructor(
    @Inject('ItemPlanningQuantityRepositoryInterface')
    private readonly itemPlanningQuantityRepository: ItemPlanningQuantityRepositoryInterface,

    private readonly eventEmitter: EventEmitter2,

    private readonly i18n: I18nRequestScopeService,

    @InjectDataSource()
    private readonly connection: DataSource,
  ) {}

  async createMultiple(
    request: CreateItemPlanningQuantitiesRequestDto,
  ): Promise<any> {
    const { items } = request;
    const orderType = items[0].orderType;
    const conditionFilterItemPlanning = items.map((item) => {
      return {
        orderId: item.orderId,
        orderType: item.orderType,
      };
    });

    const itemPlanningByOrderId =
      await this.itemPlanningQuantityRepository.findAllByCondition(
        conditionFilterItemPlanning,
      );
    const idsRemove = [];
    const idOlds = [];
    const deleteItemPlanning = [];
    let itemPlanningEntites = items.map((itemPlanningQuantityRequest) => {
      const itemPlanning = itemPlanningByOrderId.find(
        (item) =>
          item.itemId === itemPlanningQuantityRequest.itemId &&
          item.warehouseId === itemPlanningQuantityRequest.warehouseId &&
          item.orderId === itemPlanningQuantityRequest.orderId &&
          item.orderType === itemPlanningQuantityRequest.orderType &&
          (item?.lotNumber?.toUpperCase() || null) ===
            (itemPlanningQuantityRequest?.lotNumber?.toUpperCase() || null) &&
          (item?.locatorId || null) ===
            (itemPlanningQuantityRequest?.locatorId || null),
      );

      const entity = itemPlanning
        ? this.itemPlanningQuantityRepository.updateEntity(
            itemPlanningQuantityRequest,
            itemPlanning,
          )
        : this.itemPlanningQuantityRepository.createEntity(
            itemPlanningQuantityRequest,
          );
      if (itemPlanning && entity.quantity == 0 && entity.planQuantity == 0) {
        idsRemove.push(itemPlanning.id);
        deleteItemPlanning.push(itemPlanning);
      } else if (orderType === SaleOrderTypeEnum.TRANSFER) {
        idOlds.push(itemPlanning?.id);
      }
      return entity;
    });

    if (orderType === SaleOrderTypeEnum.TRANSFER)
      itemPlanningByOrderId.forEach((itemPlanning) => {
        if (!idOlds.includes(itemPlanning.id)) {
          idsRemove.push(itemPlanning.id);
        }
      });

    const invalidQuantityPlanning = itemPlanningEntites.some(
      (itemPlanningEntity) =>
        itemPlanningEntity.quantity > itemPlanningEntity.planQuantity,
    );

    if (invalidQuantityPlanning) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }

    itemPlanningEntites = itemPlanningEntites.filter(
      (item) => item.quantity != 0 || item.planQuantity != 0,
    );
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (!isEmpty(idsRemove)) {
        await queryRunner.manager.delete(ItemPlanningQuantityEntity, idsRemove);
      }
      if (!isEmpty(itemPlanningEntites)) {
        await queryRunner.manager.save(
          ItemPlanningQuantityEntity,
          itemPlanningEntites,
        );
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
    if (!isEmpty(deleteItemPlanning)) {
      const event = new SyncItemPlanningQuantityEventDto(deleteItemPlanning, 3);
      this.eventEmitter.emit(EventItemPlanningQuantityEnum.Delete, event);
    }
    if (!isEmpty(itemPlanningEntites)) {
      const event = new SyncItemPlanningQuantityEventDto(
        itemPlanningEntites,
        2,
      );
      this.eventEmitter.emit(EventItemPlanningQuantityEnum.Update, event);
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async removeMultiple(
    request: RemoveItemPlanningQuantityRequestDto,
  ): Promise<any> {
    const itemPlanningQuantities =
      await this.itemPlanningQuantityRepository.findAllByCondition({
        orderId: request.orderId,
        orderType: request.orderType,
      });

    const itemPlanningQuantityIds = itemPlanningQuantities.map((e) => e.id);

    if (!isEmpty(itemPlanningQuantityIds)) {
      await this.itemPlanningQuantityRepository.multipleRemove(
        itemPlanningQuantityIds,
      );
    }

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async rollbackItemPlan(
    request: RollbackItemPlanningQuantityRequestDto,
  ): Promise<any> {
    const itemPlanningQuantities =
      await this.itemPlanningQuantityRepository.findAllByCondition({
        orderId: request.orderId,
        orderType: request.orderType,
      });

    const itemMap = keyBy(
      request.items,
      (item) => `${item.itemId}_${item.lotNumber || ''}`,
    );

    itemPlanningQuantities.forEach((item) => {
      const key = `${item.itemId}_${item.lotNumber || ''}`;
      if (has(itemMap, key)) {
        item.planQuantity = plus(
          item.planQuantity,
          itemMap[key]?.quantity || 0,
        );
      }
    });

    await this.itemPlanningQuantityRepository.create(itemPlanningQuantities);

    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getItemPlanningQuantityByOrder(
    payload: GetItemPlanningQuantityByOrder,
  ): Promise<any> {
    const result =
      await this.itemPlanningQuantityRepository.getItemPlanningQuantityByOrder(
        payload,
      );

    return new ResponseBuilder()
      .withData(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getItemPlanningQuantityByLocatorIds(
    locatorIds: number[],
  ): Promise<any> {
    const result =
      await this.itemPlanningQuantityRepository.getItemPlanningQuantityByLocatorIds(
        locatorIds,
      );
    return new ResponseBuilder()
      .withData(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getItemPlanningQuantityByOrderId(
    request: GetItemPlanningQuantityByOrderIdRequestDto,
  ): Promise<any> {
    const { orderId, orderType } = request;
    const itemPlanning =
      await this.itemPlanningQuantityRepository.findAllByCondition({
        orderId: orderId,
        orderType: orderType,
      });

    return new ResponseBuilder()
      .withData(itemPlanning)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
