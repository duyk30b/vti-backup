export enum EventItemPlanningQuantityEnum {
  Update = 'event.ItemPlanningQuantity.update',
  Delete = 'event.ItemPlanningQuantity.delete',
}

export enum OrderTypeEnum {
  PO = 1,
  PRO = 2,
  SO = 3,
  TRANSFER = 4,
  IMO = 5,
  EXO = 6,
  RO = 7,
  PROPOSAL = 8,
}
