import { ItemPlanningQuantityService } from './item-planning-quantity.service';
import { ItemPlanningQuantityRepository } from '../../repositories/item-planning-quantity.repository';
import { ItemPlanningQuantityController } from './item-planning-quantity.controller';
import { ItemPlanningQuantityEntity } from '../../entities/item/item-planning-quantity.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { QUEUES_NAME_ENUM } from '@constant/common';
import { BullModule } from '@nestjs/bull';
import { SaleModule } from '@components/sale/sale.module';
import { SaleService } from '@components/sale/sale.service';
import { WarehouseLayoutModule } from '@components/warehouse-layout/warehouse-layout.module';
import { WarehouseLayoutService } from '@components/warehouse-layout/warehouse-layout.service';
import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { WarehouseService } from '@components/warehouse/warehouse.service';
import { ItemRepository } from '@repositories/item.repository';
import { UserService } from '@components/user/user.service';
import { UserModule } from '@components/user/user.module';
import { Item } from '@entities/item/item.entity';
import { DatasyncModule } from '@components/datasync/datasync.module';
import { WarehouseCronService } from '@components/warehouse/warehouse-cron.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([ItemPlanningQuantityEntity, Item]),
    BullModule.registerQueue({
      name: QUEUES_NAME_ENUM.SYNC_DATA_QUEUE,
    }),
    SaleModule,
    WarehouseLayoutModule,
    WarehouseModule,
    UserModule,
    DatasyncModule,
  ],
  exports: [],
  providers: [
    {
      provide: 'ItemPlanningQuantityRepositoryInterface',
      useClass: ItemPlanningQuantityRepository,
    },
    {
      provide: 'ItemPlanningQuantityServiceInterface',
      useClass: ItemPlanningQuantityService,
    },
    {
      provide: 'SaleServiceInterface',
      useClass: SaleService,
    },
    {
      provide: 'WarehouseLayoutServiceInterface',
      useClass: WarehouseLayoutService,
    },

    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'ItemRepositoryInterface',
      useClass: ItemRepository,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    WarehouseCronService,
  ],
  controllers: [ItemPlanningQuantityController],
})
export class ItemPlanningQuantityModule {}
