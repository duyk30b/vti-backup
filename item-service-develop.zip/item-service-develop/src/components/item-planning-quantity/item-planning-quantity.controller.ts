import { isEmpty } from 'lodash';
import { CreateItemPlanningQuantitiesRequestDto } from './dto/request/create-item-planning-quantity.request.dto';
import { ItemPlanningQuantityServiceInterface } from './interface/item-planning-quantity.service.interface';
import { Body, Controller, Inject, Post } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { GetItemPlanningQuantityByOrder } from './dto/request/get-item-planning-quantity-by-order.request.dto';
import { GetItemPlanningQuantityByLocatorIdsRequestDto } from './dto/request/get-item-planning-quantity-by-locator-ids.request.dto';
import { GetItemPlanningQuantityByOrderIdRequestDto } from './dto/request/get-item-planning-quantity-by-order-id.request.dto';
import { RemoveItemPlanningQuantityRequestDto } from './dto/request/remove-item-planning-quantity.request.dto';
import { RollbackItemPlanningQuantityRequestDto } from './dto/request/rollback-item-planning-quantity.request.dto copy';

@Controller('item-planning-quantities')
export class ItemPlanningQuantityController {
  constructor(
    @Inject('ItemPlanningQuantityServiceInterface')
    private readonly itemPlanningQuantityService: ItemPlanningQuantityServiceInterface,
  ) {}

  @MessagePattern('create_item_planning_quantitites')
  @Post('/create-planning')
  async createMultiple(
    @Body() body: CreateItemPlanningQuantitiesRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemPlanningQuantityService.createMultiple(request);
  }

  @MessagePattern('remove_item_planning_quantitites')
  async removeMultiple(
    @Body() body: RemoveItemPlanningQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemPlanningQuantityService.removeMultiple(request);
  }

  @MessagePattern('rollback_item_planning_quantitites')
  async rollbackItemPlan(
    @Body() body: RollbackItemPlanningQuantityRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemPlanningQuantityService.rollbackItemPlan(request);
  }

  @MessagePattern('get_item_planning_quantity_by_order_id')
  async getItemPlanningQuantityByOrderId(
    @Body() body: GetItemPlanningQuantityByOrderIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemPlanningQuantityService.getItemPlanningQuantityByOrderId(
      request,
    );
  }

  @MessagePattern('get_item_planning_quantity_by_order')
  async getItemPlanningQuantityByOrder(
    @Body() body: GetItemPlanningQuantityByOrder,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemPlanningQuantityService.getItemPlanningQuantityByOrder(
      request,
    );
  }
  @MessagePattern('get_item_planning_quantity_by_locator_ids')
  async getItemPlanningQuantityByLocatorIds(
    @Body() body: GetItemPlanningQuantityByLocatorIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemPlanningQuantityService.getItemPlanningQuantityByLocatorIds(
      request.locatorIds,
    );
  }
}
