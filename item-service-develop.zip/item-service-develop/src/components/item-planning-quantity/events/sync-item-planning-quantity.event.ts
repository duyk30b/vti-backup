export class SyncItemPlanningQuantityEventDto {
  dataUpdate: any;
  actionType: any;

  constructor(dataUpdate: any, actionType: any) {
    this.dataUpdate = dataUpdate;
    this.actionType = actionType;
  }
}
