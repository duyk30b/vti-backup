import { ReportItemStockRequestDto } from '@components/dashboard/dto/request/report-item-stock.request.dto';
import {
  ConditionOrder,
  FilterItemByCondition,
} from './../../item-warehouse/dto/request/get-item-stock-available.request.dto';
import { ItemPlanningQuantityEntity } from './../../../entities/item/item-planning-quantity.entity';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { GetItemPlanningQuantityByOrder } from '../dto/request/get-item-planning-quantity-by-order.request.dto';
import { CreateItemPlanningQuantityRequestDto } from '../dto/request/create-item-planning-quantity.request.dto';
import { FilterItemAllWarehouseByCondition } from '@components/item-warehouse/dto/request/get-item-stock-available-all-warehouse.request.dto';

export interface ItemPlanningQuantityRepositoryInterface
  extends BaseInterfaceRepository<ItemPlanningQuantityEntity> {
  createEntity(
    request: CreateItemPlanningQuantityRequestDto,
  ): ItemPlanningQuantityEntity;
  updateEntity(
    request: any,
    entity: ItemPlanningQuantityEntity,
  ): ItemPlanningQuantityEntity;
  getItemPlanningQuantityByOrder(
    payload: GetItemPlanningQuantityByOrder,
  ): Promise<any>;
  getTotalQuantityItemPlanningByCondition(
    conditions: FilterItemByCondition[],
    order?: ConditionOrder,
  ): Promise<any>;
  getItemPlanningQuantityByLocatorIds(locatorIds: number[]): Promise<any>;
  getTotalItemPlanning(request: ReportItemStockRequestDto): Promise<any>;
  getTotalQuantityAllItemPlanningByCondition(
    conditions: FilterItemAllWarehouseByCondition[],
    order?: ConditionOrder,
  ): Promise<any>;
}
