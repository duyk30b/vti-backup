import { GetItemPlanningQuantityByOrderIdRequestDto } from '../dto/request/get-item-planning-quantity-by-order-id.request.dto';
import { GetItemPlanningQuantityByOrder } from '../dto/request/get-item-planning-quantity-by-order.request.dto';
import { RemoveItemPlanningQuantityRequestDto } from '../dto/request/remove-item-planning-quantity.request.dto';
import { RollbackItemPlanningQuantityRequestDto } from '../dto/request/rollback-item-planning-quantity.request.dto copy';
import { CreateItemPlanningQuantitiesRequestDto } from './../dto/request/create-item-planning-quantity.request.dto';

export interface ItemPlanningQuantityServiceInterface {
  createMultiple(request: CreateItemPlanningQuantitiesRequestDto): Promise<any>;
  removeMultiple(request: RemoveItemPlanningQuantityRequestDto): Promise<any>;
  rollbackItemPlan(
    request: RollbackItemPlanningQuantityRequestDto,
  ): Promise<any>;
  getItemPlanningQuantityByOrder(
    payload: GetItemPlanningQuantityByOrder,
  ): Promise<any>;
  getItemPlanningQuantityByOrderId(
    payload: GetItemPlanningQuantityByOrderIdRequestDto,
  ): Promise<any>;
  getItemPlanningQuantityByLocatorIds(locatorIds: number[]): Promise<any>;
}
