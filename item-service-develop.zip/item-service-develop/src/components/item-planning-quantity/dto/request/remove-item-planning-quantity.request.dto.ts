import { SaleOrderTypeEnum } from '@components/sale/sale.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsInt, IsEnum } from 'class-validator';

export class RemoveItemPlanningQuantityRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsInt()
  orderId: number;

  @ApiPropertyOptional()
  @IsEnum(SaleOrderTypeEnum)
  orderType: number;
}
