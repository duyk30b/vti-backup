import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsArray } from 'class-validator';
import { isJson } from 'src/helper/string.helper';
export class GetItemPlanningQuantityByLocatorIdsRequestDto extends BaseDto {
  @ApiProperty()
  @Transform(({ value }) => {
    if (typeof value !== 'string') return value;

    if (value) value = value.replace(/\\/g, '');

    if (isJson(value)) {
      const decodedData = decodeURIComponent(value);
      return JSON.parse(decodedData);
    }
  })
  @IsArray()
  locatorIds: number[];
}
