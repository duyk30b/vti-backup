import { SaleOrderTypeEnum } from '@components/sale/sale.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsInt,
  IsEnum,
  IsNumber,
  IsArray,
  IsOptional,
  IsString,
} from 'class-validator';

class ItemRequest {
  @IsNumber()
  itemId: number;

  @IsString()
  lotNumber: string;

  @IsNumber()
  quantity: number;
}

export class RollbackItemPlanningQuantityRequestDto extends BaseDto {
  @ApiPropertyOptional()
  @IsInt()
  orderId: number;

  @ApiPropertyOptional()
  @IsEnum(SaleOrderTypeEnum)
  orderType: number;

  @ApiPropertyOptional()
  @IsArray()
  @Type(() => ItemRequest)
  @IsOptional()
  items: ItemRequest[];
}
