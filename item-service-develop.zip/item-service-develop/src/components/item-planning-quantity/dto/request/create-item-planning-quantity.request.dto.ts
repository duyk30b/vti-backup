import { SaleOrderTypeEnum } from '@components/sale/sale.constant';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsInt,
  IsString,
  IsEnum,
  ArrayNotEmpty,
  ValidateNested,
  IsOptional,
} from 'class-validator';

export class CreateItemPlanningQuantityRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  planQuantity: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsInt()
  locatorId: number;

  @ApiPropertyOptional()
  @IsInt()
  orderId: number;

  @ApiPropertyOptional()
  @IsEnum(SaleOrderTypeEnum)
  orderType: number;
}

export class CreateItemPlanningQuantitiesRequestDto extends BaseDto {
  @ApiProperty()
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => CreateItemPlanningQuantityRequestDto)
  items: CreateItemPlanningQuantityRequestDto[];
}
