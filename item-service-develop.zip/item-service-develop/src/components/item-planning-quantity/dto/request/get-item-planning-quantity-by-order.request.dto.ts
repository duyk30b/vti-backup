import { BaseDto } from "@core/dto/base.dto";
import { ApiProperty } from "@nestjs/swagger";
import { IsArray, IsInt } from 'class-validator';

export class GetItemPlanningQuantityByOrder extends BaseDto {
  @ApiProperty()
  @IsArray()
  itemIds: number[];

  @ApiProperty()
  @IsInt()
  warehouseId: number;
}