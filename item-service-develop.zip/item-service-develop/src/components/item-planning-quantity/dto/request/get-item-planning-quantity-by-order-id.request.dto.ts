import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsEnum } from 'class-validator';
import { SaleOrderTypeEnum } from '@components/sale/sale.constant';

export class GetItemPlanningQuantityByOrderIdRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  orderId: number;

  @ApiProperty()
  @IsEnum(SaleOrderTypeEnum)
  orderType: number;
}
