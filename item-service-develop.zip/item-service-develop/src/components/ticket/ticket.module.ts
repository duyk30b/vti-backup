import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ClientProxyFactory } from '@nestjs/microservices';
import { ConfigService } from '@config/config.service';
import { TicketService } from './ticket.service';

@Global()
@Module({
  imports: [ConfigModule],
  exports: [
    {
      provide: 'TicketServiceInterface',
      useClass: TicketService,
    },
  ],
  providers: [
    ConfigService,
    {
      provide: 'TicketServiceInterface',
      useClass: TicketService,
    },
  ],
})
export class TicketModule {}
