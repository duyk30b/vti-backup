export interface TicketServiceInterface {
  getTicketsByRequestIds(
    requestIds: string[],
    serialize?: boolean,
  ): Promise<any>;
  getTicketReceiptByCondition(
    requestIds: string[],
    serialize?: boolean,
  ): Promise<any>;
  getTicketReceiptByIds(ticketIds: string[], serialize?: boolean): Promise<any>;
}
