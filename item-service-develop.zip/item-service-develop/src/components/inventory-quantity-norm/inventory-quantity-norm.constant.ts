export enum IsGetAllEnum {
  NO = '0',
  YES = '1',
}
