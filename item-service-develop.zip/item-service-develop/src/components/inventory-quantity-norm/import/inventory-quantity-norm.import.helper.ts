import { ImportResponseDto } from "@core/dto/import/response/import.response.dto";
import { ImportResultDto } from "@core/dto/import/response/import.result.dto";
import { Inject } from '@nestjs/common'
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, In } from 'typeorm';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { ConfigService } from '@nestjs/config';
import { ImportRequestDto } from "@core/dto/import/request/import.request.dto";
import { ResponsePayload } from "@utils/response-payload";
import { InventoryQuantityNormRepositoryInterface } from "../interface/inventory-quantity-norm.repository.interface";
import { ImportDataAbstract } from "@core/abstracts/import-data.abstract";
import { WarehouseServiceInterface } from "@components/warehouse/interface/warehouse.service.interface";
import {
  keyBy,
  uniq,
  isEmpty,
} from 'lodash';
import { ItemRepositoryInterface } from "@components/item/interface/item.repository.interface";
import { ResponseCodeEnum } from "@constant/response-code.enum";
import { Alignment, Borders, CellValue, FillPattern, Font, Row, Workbook } from 'exceljs';
import { EXCEL_STYLE, HEADER_IN } from "@components/export/export.constant";
export class InventoryQuantityNormImport extends ImportDataAbstract {

  private readonly ROW_NUMBER_START_DATA = 0;

  private readonly FIELD_TEMPLATE_ITEM_CONST = {
    WAREHOUSE_CODE: {
      DB_COL_NAME: 'warehouseCode',
      COL_NAME: 'Mã kho',
      MAX_LENGTH: 20,
      ALLOW_NULL: false,
    },
    ITEM_CODE: {
      DB_COL_NAME: 'itemCode',
      COL_NAME: 'Mã vật tư',
      MAX_LENGTH: 22,
      ALLOW_NULL: false,
    },
    ITEM_NAME: {
      DB_COL_NAME: 'itemName',
      COL_NAME: 'Tên vật tư',
      MAX_LENGTH: 22,
      ALLOW_NULL: true,
    },
    ITEM_UNIT: {
      DB_COL_NAME: 'itemUnit',
      COL_NAME: 'Đơn vị tính',
      MAX_LENGTH: 255,
      ALLOW_NULL: true,
    },
    MIN_INVENTORY_LIMIT: {
      DB_COL_NAME: 'minInventoryLimit',
      COL_NAME: 'SL tồn kho tối thiểu',
      MAX_LENGTH: 10,
      ALLOW_NULL: true,
    },
    INVENTORY_LIMIT: {
      DB_COL_NAME: 'maxInventoryLimit',
      COL_NAME: 'SL tồn kho tối đa',
      MAX_LENGTH: 10,
      ALLOW_NULL: true,
    },
    MAX_INVENTORY_LIMIT: {
      DB_COL_NAME: 'inventoryLimit',
      COL_NAME: 'SL tồn kho an toàn',
      MAX_LENGTH: 10,
      ALLOW_NULL: false,
    },
    REOERDER_POINT: {
      DB_COL_NAME: 'reorderPoint',
      COL_NAME: 'Điểm đặt hàng lại',
      MAX_LENGTH: 10,
      ALLOW_NULL: true,
    },
    EOQ: {
      DB_COL_NAME: 'eoq',
      COL_NAME: 'EOQ',
      MAX_LENGTH: 10,
      ALLOW_NULL: true,
    },
    LEAD_TIME: {
      DB_COL_NAME: 'leadTime',
      COL_NAME: 'Thời gian chờ (ngày)',
      MAX_LENGTH: 10,
      ALLOW_NULL: true,
    },
    REQUIRED_COL_NUM: 11,
  };

  private readonly SHEET_NAME = this.i18n.translate('file-header.SHEET_NAME_FILE_IMPORT_CONSTRUCTION');

  constructor(
    @Inject('InventoryQuantityNormRepositoryInterface')
    private readonly inventoryQuantityNormRepository: InventoryQuantityNormRepositoryInterface,

    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,

    @Inject('ItemRepositoryInterface')
    private readonly itemRepository: ItemRepositoryInterface,

    @InjectDataSource()
    private readonly connection: DataSource,
    protected readonly i18n: I18nRequestScopeService,
    protected readonly configService: ConfigService,
  ) {
    super(i18n);
    this.init();
  }

  private init() {
    const arrayField = [];
    for (const [key, value] of Object.entries(
      this.FIELD_TEMPLATE_ITEM_CONST,
    )) {
      arrayField.push(value);
    }

    this.fieldsMap.groupSet(
      [2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
      [
        this.FIELD_TEMPLATE_ITEM_CONST.WAREHOUSE_CODE,
        this.FIELD_TEMPLATE_ITEM_CONST.ITEM_CODE,
        this.FIELD_TEMPLATE_ITEM_CONST.ITEM_NAME,
        this.FIELD_TEMPLATE_ITEM_CONST.ITEM_UNIT,
        this.FIELD_TEMPLATE_ITEM_CONST.MIN_INVENTORY_LIMIT,
        this.FIELD_TEMPLATE_ITEM_CONST.INVENTORY_LIMIT,
        this.FIELD_TEMPLATE_ITEM_CONST.MAX_INVENTORY_LIMIT,
        this.FIELD_TEMPLATE_ITEM_CONST.REOERDER_POINT,
        this.FIELD_TEMPLATE_ITEM_CONST.EOQ,
        this.FIELD_TEMPLATE_ITEM_CONST.LEAD_TIME,
      ],
    );
  }

  protected async saveImportDataDto(dataDto: any[], logs: ImportResultDto[], error: number, total: number, userId?: number): Promise<ImportResponseDto> {
    const codeNotExist = await this.i18n.translate('error.CODE_IN_NOT_EXIST');
    const codeWarehouse = uniq(dataDto.map((i) => i.warehouseCode));
    const itemCodes = uniq(dataDto.map((i) => i.itemCode));
    const warehouses = await this.warehouseService.getListByCodes(codeWarehouse);
    const items = await this.itemRepository.getItemByCodes(itemCodes);
    const findByWarehouseId = await this.inventoryQuantityNormRepository.findWithRelations(
      {
        where: {
          warehouseId: In(warehouses.map((i) => i.id)),
        }
      }
    );
    const findByItemId = await this.inventoryQuantityNormRepository.findWithRelations(
      {
        where: {
          itemId: In(items.map((i) => i.id)),
        }
      }
    );
    findByWarehouseId.forEach((i) => Object.assign(i, { type: 'old' }));
    findByItemId.forEach((i) => Object.assign(i, { type: 'old' }));
    const warehouseMap = keyBy(warehouses, 'code');
    const itemMap = keyBy(items, 'code');
    const findByWarehouseIdMap = keyBy(findByWarehouseId, 'warehouseId');
    const findByItemIdMap = keyBy(findByItemId, 'itemId');

    const entities = [];
    const valid = [];
    const {
      duplicateCodeOrNameMsg,
      codeNotExistMsg,
      successMsg,
      unsuccessMsg,
      addText,
      updateText,
    } = await this.getMessage();
    dataDto.forEach((data) => {
      const { i, action, itemCode, warehouseCode } = data;
      const logRow = {
        id: i,
        row: i,
        action: action,
      } as ImportResultDto;
      const msgLogs = [];
      if (action.toLowerCase() === addText) {
        if (findByWarehouseIdMap[warehouseMap[warehouseCode]?.id] || findByItemIdMap[itemMap[itemCode]?.id]) {
          msgLogs.push(duplicateCodeOrNameMsg);
        } else {
          data.itemId = itemMap[itemCode].id;
          data.warehouseId = warehouseMap[warehouseCode].id;
          const entity = this.inventoryQuantityNormRepository.createEntity(data);
          entities.push(entity);
          Object.assign(entity, { type: 'new' });
          findByWarehouseIdMap[warehouseMap[warehouseCode]?.id] = entity;
          findByItemIdMap[itemMap[itemCode]?.id] = entity;
        }
      } else if (action.toLowerCase() === updateText) {
        if (findByWarehouseIdMap[warehouseMap[warehouseCode]?.id] && findByWarehouseIdMap[warehouseMap[warehouseCode]?.id]?.['type'] === 'old' &&
          findByItemIdMap[itemMap[itemCode]?.id] && findByItemIdMap[itemMap[itemCode]?.id]?.['type'] === 'old'
        ) {
          const entity = this.inventoryQuantityNormRepository.updateEntity(
            findByItemIdMap[itemMap[itemCode]?.id],
            data,
          )
          entities.push(entity);
          Object.assign(entity, { type: 'new' });
          findByWarehouseIdMap[warehouseMap[warehouseCode]?.id] = entity;
          findByItemIdMap[itemMap[itemCode]?.id] = entity;
        } else {
          msgLogs.push(codeNotExist);
        }
      }
      if (isEmpty(msgLogs)) {
        logRow.log = [successMsg];
        valid.push(logRow);
      } else {
        logRow.log = msgLogs;
        logs.push(logRow);
      }
    });
    const response = new ImportResponseDto();
    if (!isEmpty(entities)) {
      const queryRunner = this.connection.createQueryRunner();
      await queryRunner.startTransaction();
      try {
        await queryRunner.manager.save(entities);
        await queryRunner.commitTransaction();
        response.successCount = valid.length;
      } catch (error) {
        await queryRunner.rollbackTransaction();
        response.successCount = 0;
        valid.forEach((l) => (l.log = [unsuccessMsg]));
      } finally {
        await queryRunner.release();
        logs.push(...valid);
      }
    }
    response.result = logs;
    response.totalCount = total;
    response.result;
    return response;
  }

  public async importUtil(request: ImportRequestDto): Promise<any> {
    const result = await super.importUtil(
      request,
      this.FIELD_TEMPLATE_ITEM_CONST.REQUIRED_COL_NUM,
      this.SHEET_NAME,
    )
    const data = result?.data.result || [];
    if (result.statusCode == ResponseCodeEnum.SUCCESS) {
      const res = await this.exportResultImport(
        request,
        this.FIELD_TEMPLATE_ITEM_CONST.REQUIRED_COL_NUM,
        this.SHEET_NAME,
        data,
      );
      return {
        check: 1,
        data: res,
      }
    }
    return result;
  }

  protected async exportResultImport(
    request: ImportRequestDto,
    requiredFieldNum: number,
    sheetName: string,
    data: any[],
  ) {
    const dataMap = keyBy(data, 'row');
    const { buffer, mimeType, userIdCreated } = request;
    let workbook = new Workbook();
    let wsExport = new Workbook();
    let dataRows: Row[] | string[][];
    workbook = await workbook.xlsx.load(Buffer.from(buffer));
    const ws = workbook.getWorksheet(sheetName);
    let ws1 = wsExport.addWorksheet('sheet2');
    dataRows = ws.getRows(
      1,
      ws.rowCount - 1,
    );
    const messSucc = await this.i18n.translate('error.SUCCESS');
    const unSucc = await this.i18n.translate('error.UNSUCCESS');
    const resultImport = await this.i18n.translate('export.inventoryQuantityNorm.result');
    const reasonImport = await this.i18n.translate('export.inventoryQuantityNorm.reason');
    const headers = HEADER_IN;
    ws1.columns = headers;
    for (let j = 0; j < dataRows.length; j++) {
      const row = dataRows[j];
      const cells = this.getCells(row, mimeType);
      if (!cells[0]) {
        cells.splice(0, 1);
      }
      if (j == 0) {
        cells.push(resultImport);
        cells.push(reasonImport);
        const row = ws1.getRow(j + 1);
        row.values = cells;
        row.eachCell(function (cell) {
          cell.font = <Font>EXCEL_STYLE.TITLE_FONT_IN;
          cell.alignment = <Partial<Alignment>>EXCEL_STYLE.ALIGN_LEFT_MIDDLE;
          cell.border = <Partial<Borders>>EXCEL_STYLE.BORDER_ALL;
          cell.fill = <FillPattern>EXCEL_STYLE.HEADER_FILL_IN;
        });
      } else {
        let mess = dataMap[j - 1]?.log[0];
        if (mess !== messSucc && cells.length > 0) {
          cells.push(unSucc);
          cells.push(mess);
        } else {
          cells.push(mess);
          cells.push('');
        }
        const row = ws1.getRow(j + 1);
        row.values = cells;
      }
    }
    const file = await wsExport.xlsx.writeBuffer();
    return file;
  }

  protected async formatCell(cells: any[]) {
    let result = [];
    cells.forEach((item) => {
      if (isEmpty(item)) result.push('');
      else result.push(item.toString());
    })
    return result;
  }
}