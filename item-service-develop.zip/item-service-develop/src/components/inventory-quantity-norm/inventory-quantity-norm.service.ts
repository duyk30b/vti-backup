import { ItemRepositoryInterface } from '@components/item/interface/item.repository.interface';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { Injectable, Inject } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { ApiError } from '@utils/api.error';
import { PagingResponse } from '@utils/paging.response';
import { ResponseBuilder } from '@utils/response-builder';
import { plainToInstance } from 'class-transformer';
import { I18nRequestScopeService } from 'nestjs-i18n';
import { DataSource, In } from 'typeorm';
import { CreateInventoryQuantityNormRequestDto } from './dto/request/create-inventory-quantity-norm.request.dto';
import { GetListInventoryNormRequestDto } from './dto/request/get-list-inventory-quantity-norm.request.dto';
import { InventoryQuantityNormResponseDto } from './dto/response/inventory-quantity-norm.response.dto';
import { InventoryQuantityNormServiceInterface } from './interface/inventory-quantity-norm.service.interface';
import { InventoryQuantityNormRepositoryInterface } from './interface/inventory-quantity-norm.repository.interface';
import { GetInventoryQuantityNormRequestDto } from './dto/request/get-inventory-quanity-norm-detail.request.dto';
import { UpdateInventoryQuantityNormRequestDto } from './dto/request/update-inventory-quantity-norm.request.dto';
import { WarehouseServiceInterface } from '@components/warehouse/interface/warehouse.service.interface';
import { InventoryNormRepositoryInterface } from '@components/inventory-norm/interface/inventory-norm.repository.interface';
import { InventoryQuantityNorm } from '@entities/inventory-norm/inventory-quantity-norm.entity';
import { Item } from '@entities/item/item.entity';
import { uniq, map, keyBy, isEmpty } from 'lodash';
import { ItemUnitSettingRepositoryInterface } from '@components/item-setting/interface/item-unit-setting.repository.interface';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { ImportRequestDto } from '@core/dto/import/request/import.request.dto';
import { InventoryQuantityNormImport } from './import/inventory-quantity-norm.import.helper';
import { ExportRequestDto } from '@components/export/dto/request/export.request.dto';
import { ExportServiceInterface } from '@components/export/interface/export.service.interface';
import * as moment from 'moment';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { EventSyncInventoryNormEnum } from '@components/item/item.constant';
import { SyncInventoryNormEventDto } from './event/sync-inventory-norm.event';

@Injectable()
export class InventoryQuantityNormService
  implements InventoryQuantityNormServiceInterface
{
  constructor(
    @Inject('InventoryQuantityNormRepositoryInterface')
    private readonly inventoryQuantityNormRepository: InventoryQuantityNormRepositoryInterface,

    @Inject('InventoryNormRepositoryInterface')
    private readonly inventoryNormRepository: InventoryNormRepositoryInterface,

    @Inject('ItemRepositoryInterface')
    private readonly itemRepository: ItemRepositoryInterface,

    @Inject('ItemUnitSettingRepositoryInterface')
    private readonly itemUnitSettingRepository: ItemUnitSettingRepositoryInterface,

    @Inject('WarehouseServiceInterface')
    private readonly warehouseService: WarehouseServiceInterface,

    @Inject('InventoryQuantityNormImport')
    private readonly inventoryQuantityNormImport: InventoryQuantityNormImport,

    @Inject('ExportServiceInterface')
    private readonly exportService: ExportServiceInterface,

    @InjectDataSource()
    private readonly connection: DataSource,

    private readonly i18n: I18nRequestScopeService,

    private readonly eventEmitter: EventEmitter2,
  ) {}

  public async create(
    request: CreateInventoryQuantityNormRequestDto,
  ): Promise<any> {
    const {
      itemId,
      warehouseId,
      inventoryLimit,
      minInventoryLimit,
      maxInventoryLimit,
    } = request;

    const item = await this.itemRepository.findOneById(itemId);
    if (!item) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }
    const validItemExistedInventoryQuantityNorm =
      await this.inventoryQuantityNormRepository.findByCondition({
        itemId: itemId,
        warehouseId: warehouseId,
      });
    if (!isEmpty(validItemExistedInventoryQuantityNorm)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate('error.ITEM_HAS_SET_UP_INVENTORY'),
        )
        .build();
    }
    const warehouse = await this.warehouseService.getWarehouseDetail(
      warehouseId,
      request.userId,
    );
    if (!warehouse) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const existedNorm =
      await this.inventoryQuantityNormRepository.findOneWithRelations({
        where: { itemId: request.itemId, warehouseId: request.warehouseId },
        withDeleted: true,
      });

    if (
      existedNorm &&
      existedNorm.inventoryLimit !== null &&
      existedNorm.quantityNormDeletedAt == null
    ) {
      return new ApiError(
        ResponseCodeEnum.BAD_REQUEST,
        await this.i18n.translate('error.INVENTORY_QUANTITY_NORM_EXIST'),
      ).toResponse();
    }

    if (
      minInventoryLimit &&
      maxInventoryLimit &&
      minInventoryLimit > maxInventoryLimit
    ) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.INVALID_INVENTORY_LIMIT'),
      ).toResponse();
    }
    if (inventoryLimit) {
      if (minInventoryLimit && inventoryLimit < minInventoryLimit) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.INVALID_INVENTORY_LIMIT'),
        ).toResponse();
      }

      if (maxInventoryLimit && inventoryLimit > maxInventoryLimit) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.INVALID_INVENTORY_LIMIT'),
        ).toResponse();
      }
    }
    const inventoryQuantityNorm =
      await this.inventoryQuantityNormRepository.create({
        id: existedNorm?.id,
        ...request,
        quantityNormDeletedAt: null,
      });
    const event = new SyncInventoryNormEventDto(
      inventoryQuantityNorm.id,
      1,
    ) as any;
    this.eventEmitter.emit(EventSyncInventoryNormEnum.Update, event);
    return this.generateResponse(inventoryQuantityNorm, item, warehouse);
  }

  public async update(
    request: UpdateInventoryQuantityNormRequestDto,
  ): Promise<any> {
    const existNorm = await this.inventoryQuantityNormRepository.findOneById(
      request.id,
    );
    if (!existNorm) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const { minInventoryLimit, maxInventoryLimit, inventoryLimit } = request;

    if (
      minInventoryLimit &&
      maxInventoryLimit &&
      minInventoryLimit > maxInventoryLimit
    ) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.INVALID_INVENTORY_LIMIT'),
      ).toResponse();
    }
    if (inventoryLimit) {
      if (minInventoryLimit && inventoryLimit < minInventoryLimit) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.INVALID_INVENTORY_LIMIT'),
        ).toResponse();
      }

      if (maxInventoryLimit && inventoryLimit > maxInventoryLimit) {
        return new ApiError(
          ResponseCodeEnum.NOT_FOUND,
          await this.i18n.translate('error.INVALID_INVENTORY_LIMIT'),
        ).toResponse();
      }
    }

    const updatedInventoryQuantityNorm =
      await this.inventoryQuantityNormRepository.create({
        id: existNorm.id,
        ...request,
      });
    const item = await this.itemRepository.findOneById(existNorm.itemId);

    const warehouse = await this.warehouseService.getWarehouseDetail(
      existNorm.warehouseId,
      request.userId,
    );

    const event = new SyncInventoryNormEventDto(
      updatedInventoryQuantityNorm.id,
      2,
    );
    this.eventEmitter.emit(EventSyncInventoryNormEnum.Update, event);
    return this.generateResponse(updatedInventoryQuantityNorm, item, warehouse);
  }

  public async delete(
    request: GetInventoryQuantityNormRequestDto,
  ): Promise<any> {
    const inventoryNorm =
      await this.inventoryQuantityNormRepository.findOneById(request.id);

    if (!inventoryNorm) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    try {
      await this.inventoryQuantityNormRepository.softRemove(request.id);
    } catch (error) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.BAD_REQUEST'))
        .build();
    }
    const event = new SyncInventoryNormEventDto(request.id, 3);
    this.eventEmitter.emit(EventSyncInventoryNormEnum.Update, event);

    return new ResponseBuilder()
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async detail(
    request: GetInventoryQuantityNormRequestDto,
  ): Promise<any> {
    const inventoryNorm =
      await this.inventoryQuantityNormRepository.findOneById(request.id);

    if (!inventoryNorm) {
      return new ApiError(
        ResponseCodeEnum.NOT_FOUND,
        await this.i18n.translate('error.NOT_FOUND'),
      ).toResponse();
    }

    const item = await this.itemRepository.findOneWithRelations({
      where: {
        id: inventoryNorm.itemId,
      },
      relations: ['itemType', 'itemUnit'],
    });
    if (item) {
      inventoryNorm.item = item;
    }
    const warehouse = await this.warehouseService.getWarehouseDetail(
      inventoryNorm.warehouseId,
      request.userId,
    );
    return this.generateResponse(inventoryNorm, item, warehouse);
  }

  public async getList(request: GetListInventoryNormRequestDto): Promise<any> {
    const { keyword } = request;
    let warehouseIdsSearch = [];
    let ids = [];
    if (!isEmpty(keyword)) {
      warehouseIdsSearch = await this.warehouseService.getWarehouseByCode(
        keyword,
      );
    }
    if (!isEmpty(warehouseIdsSearch)) {
      ids = uniq(warehouseIdsSearch.map((w) => w.id));
      request.ids = ids;
    }
    const { data, total } = await this.inventoryQuantityNormRepository.getList(
      request,
    );
    const warehouseIds = data.map((item) => item.warehouseId);
    const warehouses = await this.warehouseService.getListByIDs(
      uniq(warehouseIds),
      true,
    );
    const itemUnitIds = map(data, 'item.itemUnitId');

    const itemUnitSettings =
      await this.itemUnitSettingRepository.findAllByCondition({
        id: In(itemUnitIds),
      });
    const itemUnitMap = keyBy(itemUnitSettings, 'id');

    data.forEach((item) => {
      const warehouse = warehouses[item.warehouseId];
      const itemUnit = itemUnitMap[item.item.itemUnitId];

      if (warehouse) {
        item.warehouse = warehouse;
      }
      if (itemUnit) {
        item.item.itemUnit = itemUnit;
      }
    });
    const response = plainToInstance(InventoryQuantityNormResponseDto, data, {
      excludeExtraneousValues: true,
    });

    return new ResponseBuilder<PagingResponse>({
      items: response,
      meta: { total: total, page: request.page },
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async generateResponse(
    inventoryNorm: InventoryQuantityNorm,
    item: Item,
    warehouse: any,
  ): Promise<any> {
    const response = plainToInstance(
      InventoryQuantityNormResponseDto,
      {
        ...inventoryNorm,
        item,
        warehouse,
      },
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder<InventoryQuantityNormResponseDto>(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async importFile(request: FileUpdloadRequestDto): Promise<any> {
    const file = request.file[0];
    const importRequestDto = {
      buffer: file.data,
      fileName: file.filename,
      mimeType: file.mimetype,
      userId: request.userId,
    } as ImportRequestDto;
    const result = await this.inventoryQuantityNormImport.importUtil(
      importRequestDto,
    );
    const mess =
      result?.message ||
      (await this.i18n.translate('error.INTERNAL_SERVER_ERROR'));
    if (result.check) {
      const name = await this.i18n.translate(
        'export.inventoryQuantityNorm.resultImport',
      );
      const date = moment(new Date()).format('DDMMYYYHHmmss');
      const nameFile = `${name}_${date}.xlsx`;
      return {
        nameFile: nameFile,
        result: result.data,
      };
    }
    if (result.statusCode != ResponseCodeEnum.SUCCESS) {
      return new ResponseBuilder()
        .withCode(result?.statusCode || ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(mess)
        .build();
    }

    return result;
  }

  async export(request: ExportRequestDto): Promise<any> {
    const name = await this.i18n.translate(
      'export.inventoryQuantityNorm.nameObject',
    );
    const date = moment(new Date()).format('DDMMYYYHHmmss');
    const nameFile = `${name}_${date}.xlsx`;
    console.log('check name file', nameFile);
    const result = await this.exportService.export(request);
    if (result.statusCode != ResponseCodeEnum.SUCCESS) {
      return result;
    }
    return {
      nameFile: nameFile,
      result: result.data,
    };
  }
}
