import { DatasyncModule } from '@components/datasync/datasync.module';
import { ItemWarehouseModule } from '@components/item-warehouse/item-warehouse.module';
import { ItemWarehouseService } from '@components/item-warehouse/item-warehouse.service';
import { UserModule } from '@components/user/user.module';
import { UserService } from '@components/user/user.service';
import { WarehouseCronService } from '@components/warehouse/warehouse-cron.service';
import { WarehouseModule } from '@components/warehouse/warehouse.module';
import { WarehouseService } from '@components/warehouse/warehouse.service';
import { QUEUES_NAME_ENUM } from '@constant/common';
import { InventoryNorm } from '@entities/inventory-norm/inventory-norm.entity';
import { InventoryQuantityNorm } from '@entities/inventory-norm/inventory-quantity-norm.entity';
import { ItemUnitSetting } from '@entities/item/item-unit-setting.entity';
import { ItemWarehouseEntity } from '@entities/item/item-warehouse.entity';
import { Item } from '@entities/item/item.entity';
import { BullModule } from '@nestjs/bull';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InventoryNormRepository } from '@repositories/inventory-norm.repository';
import { InventoryQuantityNormRepository } from '@repositories/inventory-quantity-norm.repository';
import { ItemUnitSettingRepository } from '@repositories/item-unit-setting.repository';
import { ItemRepository } from '@repositories/item.repository';
import { InventoryQuantityNormImport } from './import/inventory-quantity-norm.import.helper';
import { InventoryQuantityNormController } from './inventory-quantity-norm.controller';
import { InventoryQuantityNormService } from './inventory-quantity-norm.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      InventoryNorm,
      InventoryQuantityNorm,
      Item,
      ItemUnitSetting,
      ItemWarehouseEntity,
    ]),
    BullModule.registerQueue({
      name: QUEUES_NAME_ENUM.SYNC_DATA_QUEUE,
    }),
    WarehouseModule,
    UserModule,
    DatasyncModule,
  ],
  providers: [
    {
      provide: 'InventoryQuantityNormRepositoryInterface',
      useClass: InventoryQuantityNormRepository,
    },
    {
      provide: 'InventoryNormRepositoryInterface',
      useClass: InventoryNormRepository,
    },
    {
      provide: 'InventoryQuantityNormServiceInterface',
      useClass: InventoryQuantityNormService,
    },
    {
      provide: 'ItemRepositoryInterface',
      useClass: ItemRepository,
    },
    {
      provide: 'ItemUnitSettingRepositoryInterface',
      useClass: ItemUnitSettingRepository,
    },
    {
      provide: 'WarehouseServiceInterface',
      useClass: WarehouseService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'InventoryQuantityNormImport',
      useClass: InventoryQuantityNormImport,
    },
    WarehouseCronService,
  ],
  controllers: [InventoryQuantityNormController],
})
export class InventoryQuantityNormModule {}
