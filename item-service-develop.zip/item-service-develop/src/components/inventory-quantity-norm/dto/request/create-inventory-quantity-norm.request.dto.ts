import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsInt, IsNumber, IsOptional } from 'class-validator';

export class CreateInventoryQuantityNormRequestDto extends BaseDto {
  @ApiProperty({ example: 1, description: 'mã vật tư' })
  @IsInt()
  itemId: number;

  @ApiProperty({ example: 1, description: 'mã kho' })
  @IsInt()
  warehouseId: number;

  @ApiProperty({
    example: 100,
    description: 'Giới hạn tồn kho an toàn',
    default: 0,
  })
  @IsNumber()
  inventoryLimit: number;

  @ApiPropertyOptional({
    example: 50,
    description: 'Giới hạn tồn kho tối thiểu',
    default: 0,
  })
  @IsOptional()
  @IsNumber()
  minInventoryLimit: number;

  @ApiPropertyOptional({
    example: 150,
    description: 'Giới hạn tồn kho tối đa',
    default: 0,
  })
  @IsOptional()
  @IsNumber()
  maxInventoryLimit: number;

  @ApiPropertyOptional({
    example: 150,
    description: 'Điểm đặt hàng lại',
    default: 0,
  })
  @IsOptional()
  @IsNumber()
  reorderPoint: number;

  @ApiPropertyOptional({
    example: 150,
    description: 'Thời gian chờ',
    default: 0,
  })
  @IsOptional()
  @IsInt()
  leadtime: number;

  @ApiPropertyOptional({
    example: 150,
    description: 'Sl đặt hàng kinh tế',
    default: 0,
  })
  @IsOptional()
  @IsNumber()
  eoq: number;
}
