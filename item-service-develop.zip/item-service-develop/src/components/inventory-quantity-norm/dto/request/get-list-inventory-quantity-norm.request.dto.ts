import { IsGetAllEnum } from '@components/inventory-quantity-norm/inventory-quantity-norm.constant';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationQuery } from '@utils/pagination.query';
import { IsEnum, IsOptional } from 'class-validator';

export class GetListInventoryNormRequestDto extends PaginationQuery {
  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(IsGetAllEnum)
  isGetAll: string;

  @ApiPropertyOptional()
  @IsOptional()
  ids: number[];
}
