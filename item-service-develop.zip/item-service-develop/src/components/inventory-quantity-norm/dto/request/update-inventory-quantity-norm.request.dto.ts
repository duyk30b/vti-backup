import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsInt, IsNotEmpty, IsNumber, IsOptional } from 'class-validator';

export class UpdateInventoryQuantityNormBodyDto extends BaseDto {
  @ApiProperty({
    example: 100,
    description: 'Giới hạn tồn kho an toàn',
    default: 0,
  })
  @IsNumber()
  @IsOptional()
  inventoryLimit: number;

  @ApiPropertyOptional({
    example: 50,
    description: 'Giới hạn tồn kho tối thiểu',
    default: 0,
  })
  @IsNumber()
  @IsOptional()
  minInventoryLimit: number;

  @ApiPropertyOptional({
    example: 150,
    description: 'Giới hạn tồn kho tối đa',
    default: 0,
  })
  @IsNumber()
  @IsOptional()
  maxInventoryLimit: number;

  @ApiPropertyOptional({
    example: 150,
    description: 'Điểm đặt hàng lại',
    default: 0,
  })
  @IsNumber()
  @IsOptional()
  reorderPoint: number;

  @ApiPropertyOptional({
    example: 150,
    description: 'Thời gian chờ',
    default: 0,
  })
  @IsOptional()
  @IsInt()
  leadtime: number;

  @ApiPropertyOptional({
    example: 150,
    description: 'Sl đặt hàng kinh tế',
    default: 0,
  })
  @IsNumber()
  @IsOptional()
  eoq: number;
}
export class UpdateInventoryQuantityNormRequestDto extends UpdateInventoryQuantityNormBodyDto {
  @ApiProperty({ example: 1, description: 'id' })
  @IsNotEmpty()
  @IsInt()
  id: number;
}
