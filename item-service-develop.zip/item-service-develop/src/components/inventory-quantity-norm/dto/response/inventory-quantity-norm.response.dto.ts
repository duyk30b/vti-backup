import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

export class WarehouseResponseDto {
  @ApiProperty({ example: 1, description: 'id của kho' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: 'tên của kho' })
  @Expose()
  name: string;

  @ApiProperty({ example: 1, description: 'mã của kho' })
  @Expose()
  code: string;
}
class ItemUnitResponse {
  @ApiProperty({ example: 1, description: 'id của kho' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: 'tên của kho' })
  @Expose()
  name: string;

  @ApiProperty({ example: 1, description: 'mã của kho' })
  @Expose()
  code: string;
}
export class ItemResponseDto {
  @ApiProperty({ example: 1, description: 'id của kho' })
  @Expose()
  id: number;

  @ApiProperty({ example: 1, description: 'tên của kho' })
  @Expose()
  name: string;

  @ApiProperty({ example: 1, description: 'mã của kho' })
  @Expose()
  code: string;

  @ApiProperty({ example: {} })
  @Expose()
  itemUnitId: number;

  @ApiProperty({ example: {} })
  @Expose()
  @Type(() => ItemUnitResponse)
  itemUnit: ItemUnitResponse;
}

export class InventoryQuantityNormResponseDto {
  @ApiProperty({ example: 1, description: 'id của giới hạn tồn kho/ lưu kho' })
  @Expose()
  id: number;

  @ApiProperty({ type: ItemResponseDto })
  @Expose()
  @Type(() => ItemResponseDto)
  item: ItemResponseDto;

  @ApiProperty({ type: WarehouseResponseDto })
  @Expose()
  @Type(() => WarehouseResponseDto)
  warehouse: WarehouseResponseDto;

  @ApiProperty({ example: 90, description: 'giới hạn tồn kho' })
  @Expose()
  inventoryLimit: number;

  @ApiProperty({ example: 75, description: 'giới hạn tồn kho(cận dưới)' })
  @Expose()
  minInventoryLimit: number;

  @ApiProperty({ example: 115, description: 'giới hạn tồn kho(cận trên)' })
  @Expose()
  maxInventoryLimit: number;

  @ApiProperty({ example: 115, description: 'điểm đặt hàng lại' })
  @Expose()
  reorderPoint: number;

  @ApiProperty({ example: 115, description: 'thời gian chờ' })
  @Expose()
  leadtime: number;

  @ApiProperty({ example: 115, description: 'SL đặt hàng kinh tế' })
  @Expose()
  eoq: number;
}
