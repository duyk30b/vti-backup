import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
  Res,
} from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { ResponsePayload } from '@utils/response-payload';
import { isEmpty } from 'lodash';
import { GetListInventoryNormRequestDto } from './dto/request/get-list-inventory-quantity-norm.request.dto';
import { InventoryQuantityNormServiceInterface } from './interface/inventory-quantity-norm.service.interface';
import { PermissionCode } from '@core/decorator/get-code.decorator';

import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { InventoryQuantityNormResponseDto } from './dto/response/inventory-quantity-norm.response.dto';
import { CreateInventoryQuantityNormRequestDto } from './dto/request/create-inventory-quantity-norm.request.dto';
import { UpdateInventoryQuantityNormBodyDto } from './dto/request/update-inventory-quantity-norm.request.dto';
import {
  CREATE_INVENTORY_QUANTITY_NORM_PERMISSION,
  UPDATE_INVENTORY_QUANTITY_NORM_PERMISSION,
  DELETE_INVENTORY_QUANTITY_NORM_PERMISSION,
  DETAIL_INVENTORY_QUANTITY_NORM_PERMISSION,
  LIST_INVENTORY_QUANTITY_NORM_PERMISSION,
  EXPORT_INVENTORY_QUANTITY_NORM_PERMISSION,
  IMPORT_INVENTORY_QUANTITY_NORM_PERMISSION,
} from '@utils/permissions/inventory-quantity-norm';
import { GetInventoryQuantityNormRequestDto } from './dto/request/get-inventory-quanity-norm-detail.request.dto';
import { FileUpdloadRequestDto } from '@core/dto/file-upload.request';
import { ExportRequestDto } from '@components/export/dto/request/export.request.dto';
import * as contentDisposition from 'content-disposition';
import { Response } from 'express';

@Controller('inventory-quantity-norms')
export class InventoryQuantityNormController {
  constructor(
    @Inject('InventoryQuantityNormServiceInterface')
    private readonly inventoryQuantityNormService: InventoryQuantityNormServiceInterface,
  ) {}

  @PermissionCode(CREATE_INVENTORY_QUANTITY_NORM_PERMISSION.code)
  @Post('/create')
  @ApiOperation({
    tags: ['Inventory quantity norm'],
    summary: 'Create new inventory quantity norm',
    description: 'Tạo giới hạn tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
    type: InventoryQuantityNormResponseDto,
  })
  public async create(
    @Body() payload: CreateInventoryQuantityNormRequestDto,
  ): Promise<ResponsePayload<InventoryQuantityNormResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryQuantityNormService.create(request);
  }

  @PermissionCode(UPDATE_INVENTORY_QUANTITY_NORM_PERMISSION.code)
  @Put('/:id')
  @ApiOperation({
    tags: ['Inventory quantity norm'],
    summary: 'Update inventory quantity norm',
    description: 'Cập nhật thông tin giới hạn tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
    type: InventoryQuantityNormResponseDto,
  })
  public async update(
    @Param('id', new ParseIntPipe()) id,
    @Body() payload: UpdateInventoryQuantityNormBodyDto,
  ): Promise<ResponsePayload<InventoryQuantityNormResponseDto | any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryQuantityNormService.update({
      id,
      ...request,
    });
  }

  @PermissionCode(DELETE_INVENTORY_QUANTITY_NORM_PERMISSION.code)
  @Delete('/:id')
  @ApiOperation({
    tags: ['Inventory quantity norm'],
    summary: 'Delete inventory quantity norm',
    description: 'Xóa giới hạn tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
    type: null,
  })
  public async delete(
    @Param() param: GetInventoryQuantityNormRequestDto,
  ): Promise<ResponsePayload<InventoryQuantityNormResponseDto | any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryQuantityNormService.delete(request);
  }

  @PermissionCode(DETAIL_INVENTORY_QUANTITY_NORM_PERMISSION.code)
  @Get('/:id')
  @ApiOperation({
    tags: ['Inventory quantity norm'],
    summary: 'Detail Inventory quantity norm',
    description: 'Chi tiết giới hạn tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Get Detail successfully',
    type: InventoryQuantityNormResponseDto,
  })
  public async detail(
    @Param() param: GetInventoryQuantityNormRequestDto,
  ): Promise<ResponsePayload<InventoryQuantityNormResponseDto | any>> {
    const { request, responseError } = param;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.inventoryQuantityNormService.detail(request);
  }

  @PermissionCode(LIST_INVENTORY_QUANTITY_NORM_PERMISSION.code)
  @MessagePattern('inventory_norm_list')
  @Get('/list')
  @ApiOperation({
    tags: ['Inventory quantity norm'],
    summary: 'List Inventory quantity norm',
    description: 'Danh sách giới hạn tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Get List successfully',
    type: null,
  })
  public async getList(
    @Query() payload: GetListInventoryNormRequestDto,
  ): Promise<ResponsePayload<any>> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.inventoryQuantityNormService.getList(request);
  }

  @PermissionCode(IMPORT_INVENTORY_QUANTITY_NORM_PERMISSION.code)
  @Post('/import')
  @ApiOperation({
    tags: ['Inventory quantity norm'],
    summary: 'Import Inventory quantity norm',
    description: 'Import danh sách giới hạn tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'import successfully',
  })
  public async importContructions(
    @Res({ passthrough: true }) res: Response,
    @Body() body: FileUpdloadRequestDto,
  ) {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    const response = await this.inventoryQuantityNormService.importFile(
      request,
    );
    if (!response.nameFile) {
      return response;
    }
    res.header('Content-Disposition', contentDisposition(response.nameFile));
    res.header('Access-Control-Expose-Headers', '*');
    return response.result;
  }

  @PermissionCode(EXPORT_INVENTORY_QUANTITY_NORM_PERMISSION.code)
  @Get('/export')
  @ApiOperation({
    tags: ['Inventory quantity norm'],
    summary: 'Export Inventory quantity norm',
    description: 'Export danh sách giới hạn tồn kho',
  })
  @ApiResponse({
    status: 200,
    description: 'Export successfully',
    type: null,
  })
  public async export(
    @Res({ passthrough: true }) res: Response,
    @Query() payload: ExportRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    const response = await this.inventoryQuantityNormService.export(request);
    if (!response.nameFile) {
      return response;
    }
    res.header('Content-Disposition', contentDisposition(response.nameFile));
    res.header('Access-Control-Expose-Headers', '*');
    return response.result;
  }
}
