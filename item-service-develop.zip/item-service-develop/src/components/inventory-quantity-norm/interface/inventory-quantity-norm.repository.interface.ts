import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { InventoryQuantityNorm } from '@entities/inventory-norm/inventory-quantity-norm.entity';
import { CreateInventoryQuantityNormRequestDto } from '../dto/request/create-inventory-quantity-norm.request.dto';
import { GetListInventoryQuantityNormExportRequestDto } from '../dto/request/get-list-inventory-norm-export.request.dto';
import { GetListInventoryNormRequestDto } from '../dto/request/get-list-inventory-quantity-norm.request.dto';
import { UpdateInventoryQuantityNormRequestDto } from '../dto/request/update-inventory-quantity-norm.request.dto';

export interface InventoryQuantityNormRepositoryInterface
  extends BaseInterfaceRepository<InventoryQuantityNorm> {
  getList(request: GetListInventoryNormRequestDto): Promise<any>;
  createEntity(request: CreateInventoryQuantityNormRequestDto): InventoryQuantityNorm
  updateEntity(
    updateEntity: InventoryQuantityNorm,
    request: UpdateInventoryQuantityNormRequestDto,
  ): InventoryQuantityNorm;
  getListExport(request: GetListInventoryQuantityNormExportRequestDto): Promise<any>;
}
