import { ExportRequestDto } from '@components/export/dto/request/export.request.dto';
import { FileUploadRequestDto } from '@core/dto/file-upload.request';
import { CreateInventoryQuantityNormRequestDto } from '../dto/request/create-inventory-quantity-norm.request.dto';
import { GetInventoryQuantityNormRequestDto } from '../dto/request/get-inventory-quanity-norm-detail.request.dto';
import { GetListInventoryNormRequestDto } from '../dto/request/get-list-inventory-quantity-norm.request.dto';
import { UpdateInventoryQuantityNormRequestDto } from '../dto/request/update-inventory-quantity-norm.request.dto';

export interface InventoryQuantityNormServiceInterface {
  create(request: CreateInventoryQuantityNormRequestDto): Promise<any>;
  update(request: UpdateInventoryQuantityNormRequestDto): Promise<any>;
  delete(request: GetInventoryQuantityNormRequestDto): Promise<any>;
  detail(request: GetInventoryQuantityNormRequestDto): Promise<any>;
  getList(request: GetListInventoryNormRequestDto): Promise<any>;
  importFile(request: FileUploadRequestDto): Promise<any>;
  export(request: ExportRequestDto): Promise<any>;
}
