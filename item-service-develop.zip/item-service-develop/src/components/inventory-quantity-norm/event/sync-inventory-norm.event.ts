export class SyncInventoryNormEventDto {
  id: number;
  actionType: any;

  constructor(id: number, actionType: any) {
    this.id = id;
    this.actionType = actionType;
  }
}
