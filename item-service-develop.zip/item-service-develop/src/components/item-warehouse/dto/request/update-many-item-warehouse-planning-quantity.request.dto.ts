import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsInt, IsNotEmpty, IsNumber } from 'class-validator';

export class ItemWarehousesRequestDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  planningQuantity: number;
}

export class UpdateManyItemWarehousePlanningQuantityRequestDto extends BaseDto {
  @ApiProperty()
  @IsNotEmpty()
  @Type(() => ItemWarehousesRequestDto)
  itemWarehouses: ItemWarehousesRequestDto[]
}
