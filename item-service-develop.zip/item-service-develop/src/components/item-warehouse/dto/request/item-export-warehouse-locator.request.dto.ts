import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class ItemExportWarehouseLocatorRequestDto {
  constructor(
    itemId: number,
    warehouseId: number,
    lotNumber?: string,
    locatorId?: number,
  ) {
    this.itemId = itemId;
    this.warehouseId = warehouseId;
    this.lotNumber = lotNumber?.toUpperCase() ?? null;
    this.locatorId = locatorId ?? null;
  }
  @ApiProperty()
  itemId: number;

  @ApiProperty()
  warehouseId: number;

  @ApiPropertyOptional()
  lotNumber: string;

  @ApiPropertyOptional()
  locatorId: number;
}
