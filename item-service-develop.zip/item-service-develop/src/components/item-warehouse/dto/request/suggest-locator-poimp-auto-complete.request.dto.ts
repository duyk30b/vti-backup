import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsString } from 'class-validator';
import { IsNull } from 'typeorm';

export class SuggestLocatorPoimpAutoCompleteRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @Transform((v) => (v.value ? v.value : IsNull()))
  @IsString()
  lotNumber: string;

  @ApiProperty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsInt()
  locatorVirtualId: number;
}
