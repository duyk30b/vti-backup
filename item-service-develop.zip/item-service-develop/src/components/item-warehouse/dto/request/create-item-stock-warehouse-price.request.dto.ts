import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsArray,
  IsInt,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  ValidateNested,
} from 'class-validator';

export class ItemStockWarehousePriceDto {
  @ApiProperty({ example: 1 })
  @IsInt()
  itemId: number;

  @ApiProperty({ example: 1 })
  @IsInt()
  warehouseId: number;

  @ApiProperty({ example: 1 })
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiProperty({ example: 2.2 })
  @Transform(({ value }) => Number(value))
  @IsPositive()
  @IsNumber()
  quantity: number;

  @ApiProperty({ example: 2.2 })
  @IsPositive()
  @IsNumber()
  price: number;

  @ApiProperty({ example: 2.2 })
  @IsPositive()
  @IsNumber()
  totalPrice: number;

  @ApiProperty({ example: 2.2 })
  @IsOptional()
  diffPrice: number;
}

export class CreateItemStockWarehousePriceDto extends BaseDto {
  @ApiProperty({ type: ItemStockWarehousePriceDto })
  @ArrayNotEmpty()
  @ValidateNested()
  @IsArray()
  @Type(() => ItemStockWarehousePriceDto)
  items: ItemStockWarehousePriceDto[];
}
