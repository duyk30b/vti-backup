import { OrderTypeEnum } from '@constant/common';
import { BaseDto } from '@core/dto/base.dto';
import { Transform, Type } from 'class-transformer';
import { IsEnum, IsInt, IsOptional, IsString, IsArray } from 'class-validator';
import { SaleOrderTypeEnum } from '@components/sale/sale.constant';
import { WarehouseByLotManagementEnum } from '@components/item-warehouse/item-warehouse.constant';

class ItemStockWarehousePrice {
  @IsInt()
  itemId: number;

  @IsOptional()
  @IsString()
  lotNumber: string;

  @IsInt()
  warehouseId: number;

  @IsInt()
  quantity: number;

  @IsOptional()
  @IsInt()
  price: number;

  @IsOptional()
  @IsInt()
  totalPrice: number;
}

export class UpdateStockFromOrderRequest extends BaseDto {
  @IsOptional()
  @IsInt()
  @Transform(({ value }) => +value)
  warehouseStockMovementId: number;

  @IsOptional()
  @Transform(({ value }) => value?.map((e) => Number(e)))
  warehouseStockMovementIds: number[];

  @IsEnum(OrderTypeEnum)
  orderType: OrderTypeEnum;

  @IsInt()
  orderId: number;

  @IsOptional()
  @IsString()
  purpose: string;

  @IsEnum(SaleOrderTypeEnum)
  saleOrderType: SaleOrderTypeEnum;

  @IsOptional()
  @IsArray()
  @Type(() => ItemStockWarehousePrice)
  itemStockWarehousePrices: ItemStockWarehousePrice[];

  @IsOptional()
  @IsEnum(WarehouseByLotManagementEnum)
  manageByLot: WarehouseByLotManagementEnum;

  @IsOptional()
  @IsArray()
  conditions?: any[];
}
