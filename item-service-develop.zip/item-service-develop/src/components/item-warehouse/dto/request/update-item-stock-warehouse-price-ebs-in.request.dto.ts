import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsArray,
  IsInt,
  IsNumber,
  IsNumberString,
  IsOptional,
  IsPositive,
  IsString,
  ValidateNested,
} from 'class-validator';

class ItemStockWarehousePriceDto {
  @ApiProperty({ example: 1 })
  @IsInt()
  itemId: number;

  @ApiProperty({ example: 1 })
  @IsInt()
  warehouseId: number;

  @ApiProperty({ example: 1 })
  @IsOptional()
  @IsString()
  lotNumber: string;

  @ApiProperty({ example: 1 })
  @IsOptional()
  @IsString()
  lotEBS: string;

  @ApiProperty({ example: 2.2 })
  @Transform(({ value }) => Number(value))
  @IsPositive()
  @IsNumber()
  quantity: number;

  @ApiProperty({ example: 2.2 })
  @IsOptional()
  @Transform(({ value }) => Number(value))
  @IsPositive()
  @IsNumber()
  totalAmount: number;

  @ApiProperty({ example: 2.2 })
  @IsOptional()
  diffPrice: number;
}

export class UpdateItemStockWarehousePriceEbsInDto extends BaseDto {
  @ApiProperty({ type: ItemStockWarehousePriceDto })
  @ArrayNotEmpty()
  @ValidateNested()
  @IsArray()
  @Type(() => ItemStockWarehousePriceDto)
  items: ItemStockWarehousePriceDto[];

  @ApiProperty({ example: 1 })
  @IsInt()
  orderType: number;

  @ApiProperty({ example: 1 })
  @IsOptional()
  @IsInt()
  orderId: number;

  @ApiProperty({ example: 1 })
  @IsOptional()
  @IsInt()
  saleOrderType: number;
}
