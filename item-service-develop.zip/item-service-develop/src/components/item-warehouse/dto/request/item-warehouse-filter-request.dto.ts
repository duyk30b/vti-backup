import { Expose } from 'class-transformer';

export class ItemWarehouseFilter {
  @Expose()
  itemId: number;

  @Expose()
  warehouseId: number;

  constructor(itemId: number, warehouseId: number) {
    this.itemId = itemId;
    this.warehouseId = warehouseId;
  }
}
