export class DataItemWarehousePriceRequestDto {
  itemCode: string;
  reportDate: string;
  warehouseCode: string;
  lotNumber: string;
  quantity: number;
  totalAmount: number;
  amount: number;
  manufacturingCountry: string;

  constructor(
    itemCode: string,
    reportDate: string,
    warehouseCode: string,
    lotNumber: string,
    quantity: number,
    totalAmount: number,
    amount: number,
    manufacturingCountry: string,
  ) {
    this.itemCode = itemCode;
    this.reportDate = reportDate;
    this.warehouseCode = warehouseCode;
    this.lotNumber = lotNumber;
    this.quantity = quantity;
    this.totalAmount = totalAmount;
    this.amount = amount;
    this.manufacturingCountry = manufacturingCountry;
  }
}

export class SyncItemWarehouseStockPriceRequestDto {
  companyCode: string;
  data: DataItemWarehousePriceRequestDto[];

  constructor(companyCode, data) {
    this.companyCode = companyCode;
    this.data = data;
  }
}
