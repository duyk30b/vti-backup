import { BaseDto } from '@core/dto/base.dto';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

export class WarehouseInventoryItem extends BaseDto {
  @ArrayNotEmpty()
  @ValidateNested()
  @Type(() => WarehouseItem)
  items: WarehouseItem[];
}

class WarehouseItem {
  @IsNotEmpty()
  @IsInt()
  inventoryId: number;

  @IsNotEmpty()
  @IsInt()
  warehouseId: number;

  @IsNotEmpty()
  @IsInt()
  locatorId: number;

  @IsOptional()
  @IsString()
  lotNumber: string;

  @IsNotEmpty()
  @IsInt()
  itemId: number;

  @IsNotEmpty()
  @IsNumber()
  actualQuantity: number;
}
