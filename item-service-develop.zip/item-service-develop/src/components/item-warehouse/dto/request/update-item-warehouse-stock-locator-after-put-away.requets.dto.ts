import { WarehouseByLotManagementEnum } from '@components/item-warehouse/item-warehouse.constant';
import { OrderTypeEnum } from '@constant/common';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  IsArray,
  IsEnum,
  IsInt,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';
class ItemPutAwayTickets {
  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsString()
  locatorId: string;

  @ApiProperty()
  @IsOptional()
  mfg: Date;

  @ApiProperty()
  @IsString()
  ticketId: string;

  @ApiProperty()
  @IsInt()
  quantityStored: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  lotNumber: string;
}

export class CreateItemPutAwayTicketRequestDto extends BaseDto {
  @IsOptional()
  @Transform(({ value }) => value?.map((e) => Number(e)))
  movementIds: number[];

  @IsEnum(OrderTypeEnum)
  orderType: OrderTypeEnum;

  @IsOptional()
  @IsArray()
  conditions?: any[];

  @ApiProperty()
  @ValidateNested()
  @IsArray()
  @Type(() => ItemPutAwayTickets)
  items: ItemPutAwayTickets[];
}
