import { ApiProperty } from '@nestjs/swagger';
import { BaseDto } from '@core/dto/base.dto';
import { IsArray, IsInt, IsNumber, ValidateNested } from 'class-validator';
import { SaleOrderTypeEnum } from '@components/sale/sale.constant';
import { Type } from 'class-transformer';
export class CreateItemStockMovementSwiftLocatorDto {
  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsInt()
  movementOrderDetailId: number;

  @ApiProperty()
  @IsInt()
  movementOrderWarehouseDetailId: number;

  @ApiProperty()
  @IsNumber()
  quantity: number;

  // @ApiProperty()
  // @ValidateNested()
  // @Type(() => CreateItemStockSwiftLocatorHistoryDto)
  // itemsStockMovementHistories: CreateItemStockSwiftLocatorHistoryDto[];
}
export class CreateItemSwiftLocatorRequestDto extends BaseDto {
  @ApiProperty()
  movementIds: number[];

  @ApiProperty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsInt()
  orderId: number;

  @ApiProperty()
  @IsInt()
  ticketId: string;

  @ApiProperty()
  @IsInt()
  // @IsEnum(SaleOrderTypeEnum)
  orderType: number;

  @ApiProperty()
  @ValidateNested()
  @IsArray()
  @Type(() => CreateItemStockMovementSwiftLocatorDto)
  items: CreateItemStockMovementSwiftLocatorDto[];
}
