import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsInt,
  IsString,
  ValidateNested,
  IsOptional,
  IsEnum,
  IsNumber,
} from 'class-validator';
import { SaleOrderTypeEnum } from '@components/sale/sale.constant';

export class CreateItemStockSwiftLocatorHistoryDto {
  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  // @IsNumber()
  quantity: number;

  @ApiProperty()
  @IsString()
  @IsOptional()
  lotNumber: string;

  @ApiProperty()
  @IsInt()
  sourceLocatorId: number;

  @ApiProperty()
  @IsInt()
  destinationLocatorId: number;
}
export class CreateItemStockMovementSwiftLocatorDto {
  @ApiProperty()
  @IsInt()
  itemId: number;

  @ApiProperty()
  @IsInt()
  movementOrderDetailId: number;

  @ApiProperty()
  @IsInt()
  movementOrderWarehouseDetailId: number;

  @ApiProperty()
  // @IsNumber()
  quantity: number;

  @ApiProperty()
  @ValidateNested()
  @Type(() => CreateItemStockSwiftLocatorHistoryDto)
  itemsStockMovementHistories: CreateItemStockSwiftLocatorHistoryDto[];
}

export class CreateItemSwiftLocatorRequestDto extends BaseDto {
  @ApiProperty()
  @IsInt()
  warehouseStockMovementExportId: number;

  @ApiProperty()
  @IsInt()
  warehouseStockMovementImportId: number;

  @ApiProperty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsInt()
  destinationWarehouseId: number;

  @ApiProperty()
  @IsInt()
  userId: number;

  @ApiProperty()
  @IsInt()
  orderId: number;

  @ApiProperty()
  @IsString()
  orderCode: string;

  @ApiProperty()
  @IsString()
  @IsOptional()
  purpose: string;

  @ApiProperty()
  @IsInt()
  @IsEnum(SaleOrderTypeEnum)
  saleOrderType: number;

  @ApiProperty()
  @ValidateNested()
  @IsArray()
  @Type(() => CreateItemStockMovementSwiftLocatorDto)
  items: CreateItemStockMovementSwiftLocatorDto[];
}
