import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, IsOptional } from 'class-validator';

export class GetByItemIdRequestDto extends BaseDto {
  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsInt()
  itemId: number;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  warehouseId: number;

  @ApiProperty()
  @Transform(({ value }) => Number(value))
  @IsOptional()
  locatorId: number;
}
