import { BaseDto } from '@core/dto/base.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsArray, IsOptional } from 'class-validator';

export class GetItemWarehouseByMultipleItemAndWarehouseRequestDto extends BaseDto {
  @ApiPropertyOptional({ example: [1, 2] })
  @IsOptional()
  @IsArray()
  itemIds: number[];

  @ApiPropertyOptional({ example: [1, 2] })
  @IsOptional()
  @IsArray()
  warehouseIds: number[];
}
