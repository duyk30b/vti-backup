import { BaseDto } from '@core/dto/base.dto';
import { FileAbstractDto } from '@core/dto/file-upload.request';
import { Type } from 'class-transformer';
import { IsNotEmpty, ValidateNested } from 'class-validator';

export class ImportItemPriceInitialRequestDto extends BaseDto {
  @IsNotEmpty()
  @ValidateNested()
  @Type(() => FileAbstractDto)
  file: FileAbstractDto;
}
