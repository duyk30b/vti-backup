import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator';

class GetItemsPriceCondition {
  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  itemId: number;

  @ApiProperty()
  @IsString()
  @IsOptional()
  lotNumber: string;

  @ApiProperty()
  @IsNumber()
  @IsOptional()
  warehouseId: number;
}

export class GetItemsPrice extends BaseDto {
  @ApiProperty()
  @Type(() => GetItemsPriceCondition)
  @ArrayNotEmpty()
  conditions: GetItemsPriceCondition[];
}
