import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber } from 'class-validator';

export class GetWarehouseStockByItemId extends BaseDto {
  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  itemId: number;
}
