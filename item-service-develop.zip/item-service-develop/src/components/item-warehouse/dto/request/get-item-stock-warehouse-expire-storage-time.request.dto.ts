import { BaseDto } from "@core/dto/base.dto";
import { ApiProperty } from "@nestjs/swagger";
import { Type } from "class-transformer";
import { IsInt, IsArray } from "class-validator";

export class GetItemStockWarehouseExpireStorageTimeRequestDto {
  @ApiProperty()
  @IsInt()
  warehouseId: number;

  @ApiProperty()
  @IsInt()
  expiredTime: number;
}

export class GetItemStockWarehouseExpireStorageTimeBodyDto extends BaseDto {
  @ApiProperty()
  @IsArray()
  @Type(() => GetItemStockWarehouseExpireStorageTimeRequestDto)
  data: GetItemStockWarehouseExpireStorageTimeRequestDto[];
}