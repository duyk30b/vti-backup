import { BaseDto } from './../../../../core/dto/base.dto';
import { FileAbstractDto } from '@core/dto/file-upload.request';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { ValidateNested } from 'class-validator';

export class DailyImportItemPriceEbsRequestDto extends BaseDto {
  @ApiProperty()
  @ValidateNested()
  @Type(() => FileAbstractDto)
  file: FileAbstractDto;
}
