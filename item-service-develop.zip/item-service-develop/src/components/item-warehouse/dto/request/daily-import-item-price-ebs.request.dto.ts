import { BaseDto } from './../../../../core/dto/base.dto';
import { FileAbtractDto } from '@core/dto/file-upload.request';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { ValidateNested } from 'class-validator';

export class DailyImportItemPriceEbsRequestDto extends BaseDto {
  @ApiProperty()
  @ValidateNested()
  @Type(() => FileAbtractDto)
  file: FileAbtractDto;
}
