import { WarehouseByLotManagementEnum } from '@components/item-warehouse/item-warehouse.constant';
import { OrderTypeEnum } from '@constant/common';
import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import { IsArray, IsEnum, IsInt, IsOptional, IsString } from 'class-validator';
class ItemStockWarehousePrice {
  @IsInt()
  itemId: number;

  @IsOptional()
  @IsString()
  lotNumber: string;

  @IsInt()
  warehouseId: number;

  @IsInt()
  quantity: number;

  @IsOptional()
  @IsInt()
  price: number;

  @IsOptional()
  @IsInt()
  totalPrice: number;
}
export class UpdateStockFromTicketRequestDto extends BaseDto {
  @IsOptional()
  @Transform(({ value }) => value?.map((e) => Number(e)))
  movementIds: number[];

  @IsEnum(OrderTypeEnum)
  orderType: OrderTypeEnum;

  @ApiProperty()
  @IsString()
  ticketId: string;

  @IsOptional()
  @IsEnum(WarehouseByLotManagementEnum)
  manageByLot: WarehouseByLotManagementEnum;

  @IsOptional()
  @IsArray()
  @Type(() => ItemStockWarehousePrice)
  itemStockWarehousePrices: ItemStockWarehousePrice[];

  @IsOptional()
  @IsArray()
  conditions?: any[];
}
