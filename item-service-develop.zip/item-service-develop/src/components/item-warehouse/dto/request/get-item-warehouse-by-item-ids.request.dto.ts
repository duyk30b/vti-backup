import { BaseDto } from '@core/dto/base.dto';
import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsInt, IsNotEmpty } from 'class-validator';

export class GetItemWarehouseByItemIdsRequestDto extends BaseDto {
  @ApiProperty({ example: [1, 2] })
  @IsNotEmpty()
  @IsArray()
  itemIds: number[];

  @ApiProperty({example: 1})
  @IsNotEmpty()
  @IsInt()
  warehouseId: number;
}
