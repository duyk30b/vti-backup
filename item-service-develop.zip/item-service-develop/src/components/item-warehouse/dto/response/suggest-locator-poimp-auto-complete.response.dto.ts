import { Expose } from 'class-transformer';

export class SuggestLocatorPoimpAutoCompleteResponseDto {
  @Expose()
  id: number;

  @Expose()
  itemId: number;

  @Expose()
  lotNumber: string;

  @Expose()
  warehouseId: number;

  @Expose()
  locatorId: number;

  @Expose()
  quantity: number;

  @Expose()
  amount: number;

  @Expose()
  totalAmount: number;

  @Expose()
  storageDate: Date;
}
