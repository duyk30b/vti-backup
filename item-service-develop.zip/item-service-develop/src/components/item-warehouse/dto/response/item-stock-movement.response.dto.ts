import { Expose, Transform, Type } from 'class-transformer';
class ItemStockMovementHistoryResponse {
  @Expose()
  id: number;

  @Expose()
  itemId: number;

  @Expose()
  quantity: number;

  @Expose()
  warehouseId: number;

  @Expose()
  lotNumber: string;

  @Expose()
  locatorId: number;

  @Expose()
  amount: number;

  @Expose()
  totalAmount: number;

  @Expose()
  mfg: Date;

  @Expose()
  storageDate: Date;

  @Expose()
  createdAt: string;
}
export class ItemStockMovementResponse {
  @Expose()
  itemId: number;

  @Expose()
  warehouseStockMovementId: number;

  @Expose()
  orderId: number;

  @Expose()
  orderCode: string;

  @Expose()
  orderType: number;

  @Expose()
  @Transform((v) => +v.value)
  quantity: number;

  @Expose()
  warehouseId: number;

  @Expose()
  mfg: Date;

  @Expose()
  storageDate: Date;

  @Expose()
  createdAt: string;

  @Expose()
  @Type(() => ItemStockMovementHistoryResponse)
  histories: ItemStockMovementHistoryResponse[];
}
