import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class DataResponse {
  @ApiProperty()
  @Expose()
  id: number;

  @ApiProperty()
  @Expose()
  name: string;

  @ApiProperty()
  @Expose()
  code: string;

  @ApiProperty()
  @Expose()
  manageByLot: number;
}
class ItemAvailable {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  @Type(() => DataResponse)
  warehouse: DataResponse;

  @ApiProperty()
  @Expose()
  locatorId: number;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => DataResponse)
  locator: DataResponse;
}

export class ItemStockAvailableResponseDto {
  @ApiProperty()
  @Expose()
  itemId: number;

  @ApiProperty()
  @Expose()
  @Type(() => DataResponse)
  item: DataResponse;

  @ApiProperty()
  @Expose()
  lotNumber: string;

  @ApiProperty()
  @Expose()
  warehouseId: number;

  @ApiProperty()
  @Expose()
  locatorId?: number;

  @ApiProperty()
  @Expose()
  @Type(() => DataResponse)
  locator: DataResponse;

  @ApiProperty()
  @Expose()
  quantity: number;

  @ApiProperty()
  @Expose()
  @Type(() => ItemAvailable)
  itemAvailables: ItemAvailable[];
}
