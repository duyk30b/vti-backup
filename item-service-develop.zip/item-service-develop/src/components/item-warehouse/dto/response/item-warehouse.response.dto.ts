import { Expose } from 'class-transformer';

export class ItemWarehouseResponseDto {
  @Expose()
  itemId: number;

  @Expose()
  warehouseId: number;

  @Expose()
  itemQuantity: number;

  @Expose()
  itemPlanningQuantity: number;
}
