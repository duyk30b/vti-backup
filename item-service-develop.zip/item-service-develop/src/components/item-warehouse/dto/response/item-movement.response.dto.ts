import { Expose, Type } from 'class-transformer';

class ItemStockMovementHistoryResponse {
  @Expose()
  id: number;

  @Expose()
  itemId: number;

  @Expose()
  quantity: number;

  @Expose()
  warehouseId: number;

  @Expose()
  lotNumber: string;

  @Expose()
  locatorId: number;

  @Expose()
  ticketLocatorId: string;

  @Expose()
  amount: number;

  @Expose()
  totalAmount: number;

  @Expose()
  mfg: Date;

  @Expose()
  storageDate: Date;

  @Expose()
  createdAt: string;
}

export class MovementResponseDto {
  @Expose()
  id: number;

  @Expose()
  itemId: number;

  @Expose()
  warehouseId: number;

  @Expose()
  ticketId: string;

  @Expose()
  type: number;

  @Expose()
  locatorId: string;

  @Expose()
  warehouseLocatorId: number;

  @Expose()
  lotNumber: string;

  @Expose()
  quantity: number;

  @Expose()
  storedQuantity: number;

  @Expose()
  exportedQuantity: number;

  @Expose()
  mfg: Date;

  @Expose()
  importDate: Date;

  @Expose()
  @Type(() => ItemStockMovementHistoryResponse)
  histories: ItemStockMovementHistoryResponse[];
}
