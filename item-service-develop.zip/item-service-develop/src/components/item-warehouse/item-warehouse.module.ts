import { ImportItemPriceService } from './import-item-price-ebs.service';
import { TmpItemPriceEbsRepository } from './../../repositories/tmp-item-price-ebs.repository';
import { TmpItemPriceEbsEntity } from './../../entities/item/tmp-item-price-ebs.entity';
import { SaleService } from './../sale/sale.service';
import { ItemRepository } from './../../repositories/item.repository';
import { Item } from './../../entities/item/item.entity';
import { ItemStockMovementHistory } from '@entities/item/item-stock-movement-history.entity';
import { ItemStockMovementHistoryRepository } from '@repositories/item-stock-movement-history.repository';
import { ItemStockWarehouseLocatorHistoryRepository } from './../../repositories/item-stock-warehouse-locator-history.repository';
import { ItemStockWarehouseLocatorHistoryEntity } from '@entities/item/item-stock-warehouse-locator-history.entity';
import { ItemPlanningQuantityRepository } from './../../repositories/item-planning-quantity.repository';
import { ItemPlanningQuantityEntity } from './../../entities/item/item-planning-quantity.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ItemWarehouseRepository } from '@repositories/item-warehouse.repository';
import { ItemWarehouseEntity } from '@entities/item/item-warehouse.entity';
import { ItemStockMovementRepository } from '@repositories/item-stock-movement.repository';
import { ConfigService } from '@config/config.service';
import {
  ClientKafka,
  ClientProxyFactory,
  ClientsModule,
  Transport,
} from '@nestjs/microservices';
import { ConfigModule } from '@nestjs/config';
import { ItemStockWarehouseLocatorEntity } from '@entities/item/item-stock-warehouse-locator.entity';
import { ItemWarehouseService } from './item-warehouse.service';
import { ItemWarehouseController } from './item-warehouse.controller';
import { ItemStockMovement } from '@entities/item/item-stock-movement.entity';
import { ItemStockWarehouseLocatorRepository } from '@repositories/item-stock-warehouse-locator.repository';
import { WarehouseLayoutService } from '@components/warehouse-layout/warehouse-layout.service';
import { BullModule } from '@nestjs/bull';
import { QUEUES_NAME_ENUM } from '@constant/common';
import { DatasyncModule } from '@components/datasync/datasync.module';
import { WarehouseCronService } from '@components/warehouse/warehouse-cron.service';
import { ItemStockWarehousePriceRepository } from '@repositories/item-stock-warehouse-price.repository';
import { ItemStockWarehousePriceEntity } from '@entities/item/item-stock-warehouse-price.entity';
import { ScheduleModule } from '@nestjs/schedule';
import { CalculateItemPriceEbsConsumer } from './import-item-price-ebs.consumer';
import * as fs from 'fs';
import * as path from 'path';
import { MovementEntity } from '@entities/item-movement/movement.entity';
import { MovementRepository } from '@repositories/item-movement.repository';

@Module({
  imports: [
    ConfigModule,
    TypeOrmModule.forFeature([
      ItemWarehouseEntity,
      ItemStockMovement,
      ItemStockWarehouseLocatorEntity,
      ItemPlanningQuantityEntity,
      ItemStockWarehouseLocatorHistoryEntity,
      ItemStockMovementHistory,
      Item,
      ItemStockWarehousePriceEntity,
      TmpItemPriceEbsEntity,
      MovementEntity,
    ]),
    // ClientsModule.register([
    //   {
    //     name: 'CLIENT_KAFKA',
    //     transport: Transport.KAFKA,
    //     options: {
    //       client: {
    //         clientId: 'item_sync_report',
    //         brokers: process.env.KAFKA_BROKERS.split(','),
    //         ssl: {
    //           rejectUnauthorized: false,
    //           ca: [
    //             fs.readFileSync(
    //               path.join(__dirname, '/../../cert/kafka.crt'),
    //               'utf-8',
    //             ),
    //           ],
    //           key: fs.readFileSync(
    //             path.join(__dirname, '/../../cert/kafka.key'),
    //             'utf-8',
    //           ),
    //           cert: fs.readFileSync(
    //             path.join(__dirname, '/../../cert/kafka.pem'),
    //             'utf-8',
    //           ),
    //         },
    //       },
    //     },
    //   },
    // ]),
    BullModule.registerQueue(
      {
        name: QUEUES_NAME_ENUM.SYNC_DATA_QUEUE,
      },
      {
        name: QUEUES_NAME_ENUM.CALCULATE_ITEM_PRICE_EBS,
      },
    ),
    DatasyncModule,
    ScheduleModule.forRoot(),
  ],
  exports: [
    {
      provide: 'ItemWarehouseServiceInterface',
      useClass: ItemWarehouseService,
    },
    'ItemStockMovementRepositoryInterface',
    'ItemWarehouseRepositoryInterface',
  ],
  providers: [
    ConfigService,
    {
      provide: 'WAREHOUSE_SERVICE_CLIENT',
      useFactory: (configService: ConfigService) => {
        const warehouseServiceOptions = configService.get('warehouseService');
        return ClientProxyFactory.create(warehouseServiceOptions);
      },
      inject: [ConfigService],
    },
    {
      provide: 'ItemWarehouseServiceInterface',
      useClass: ItemWarehouseService,
    },
    {
      provide: 'ItemWarehouseRepositoryInterface',
      useClass: ItemWarehouseRepository,
    },
    {
      provide: 'ItemStockMovementRepositoryInterface',
      useClass: ItemStockMovementRepository,
    },
    {
      provide: 'MovementRepositoryInterface',
      useClass: MovementRepository,
    },
    {
      provide: 'ItemStockWarehouseLocatorRepositoryInterface',
      useClass: ItemStockWarehouseLocatorRepository,
    },
    {
      provide: 'ItemStockMovementHistoryRepositoryInterface',
      useClass: ItemStockMovementHistoryRepository,
    },
    {
      provide: 'ItemPlanningQuantityRepositoryInterface',
      useClass: ItemPlanningQuantityRepository,
    },
    {
      provide: 'ItemStockWarehouseLocatorHistoryRepositoryInterface',
      useClass: ItemStockWarehouseLocatorHistoryRepository,
    },
    {
      provide: 'WarehouseLayoutServiceInterface',
      useClass: WarehouseLayoutService,
    },
    {
      provide: 'ItemRepositoryInterface',
      useClass: ItemRepository,
    },
    {
      provide: 'ItemStockWarehousePriceRepositoryInterface',
      useClass: ItemStockWarehousePriceRepository,
    },
    {
      provide: 'TmpItemPriceEbsRepositoryInterface',
      useClass: TmpItemPriceEbsRepository,
    },
    {
      provide: 'ImportItemPriceService',
      useClass: ImportItemPriceService,
    },
    {
      provide: 'WarehouseCronService',
      useClass: WarehouseCronService,
    },
    ConfigService,
    WarehouseCronService,
    SaleService,
    CalculateItemPriceEbsConsumer,
    // {
    //   provide: 'KAFKA_PRODUCER',
    //   useFactory: async (kafkaClient: ClientKafka) => {
    //     return kafkaClient.connect();
    //   },
    //   inject: ['CLIENT_KAFKA'],
    // },
  ],
  controllers: [ItemWarehouseController],
})
export class ItemWarehouseModule {}
