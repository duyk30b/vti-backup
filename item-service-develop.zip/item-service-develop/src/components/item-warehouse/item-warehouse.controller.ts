import { ResponseBuilder } from '@utils/response-builder';
import { GetListItemStockWarehousePriceRequest } from '@components/item/dto/request/get-list-item-stock-warehouse-price.request';
import { GetListItemStockWarehousePriceRequestDto } from '@components/item/dto/request/get-list-item-stock-warehouse-price.request.dto';
import { Body, Controller, Get, Inject, Post, Query } from '@nestjs/common';
import { MessagePattern } from '@nestjs/microservices';
import { isEmpty } from 'lodash';
import { CreateItemSwiftLocatorRequestDto } from './dto/request/create-item-swift-locator.request.dto';
import { GetByItemIdRequestDto } from './dto/request/get-by-item-id.request.dto';
import { GetItemStockAvailableSwiftLocatorRequestDto } from './dto/request/get-item-stock-available-swift-locator.request.dto';
import { GetItemStockAvailableRequestDto } from './dto/request/get-item-stock-available.request.dto';
import { GetItemStockWarehouseExpireStorageTimeBodyDto } from './dto/request/get-item-stock-warehouse-expire-storage-time.request.dto';
import { GetItemWarehouseByItemIdsRequestDto } from './dto/request/get-item-warehouse-by-item-ids.request.dto';
import { GetItemWarehouseByMultipleItemAndWarehouseRequestDto } from './dto/request/get-item-warehouse-by-multiple-item-and-warehouse.request.dto';
import { GetItemsPrice } from './dto/request/get-items-price.request';
import { ImportItemPriceInitialRequestDto } from './dto/request/import-item-price-initial.request.dto';
import { UpdateItemStockWarehousePriceEbsInDto } from './dto/request/update-item-stock-warehouse-price-ebs-in.request.dto';
import { UpdateStockFromOrderRequest } from './dto/request/update-stock-from-order-request.dto';
import { ItemWarehouseServiceInterface } from './interface/item-warehouse.service.interface';
import { GetItemAllStockAvailableRequestDto } from './dto/request/get-item-stock-available-all-warehouse.request.dto';
import { GetWarehouseStockByItemId } from './dto/request/get-warehouse-stock-by-item-id.request.dto';
import { SuggestLocatorPoimpAutoCompleteRequestDto } from './dto/request/suggest-locator-poimp-auto-complete.request.dto';
import { SuggestLocatorWithItemQuantityRequest } from './dto/request/suggest-locator-with-item-quantity.request.dto';
import { Public } from '@core/decorator/set-public.decorator';
import { DailyImportItemPriceEbsRequestDto } from './dto/request/daily-import-item-price-ebs.request.dto';
import { ImportItemPriceService } from './import-item-price-ebs.service';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { UpdateStockFromTicketRequestDto } from './dto/request/update-stock-from-ticket-request.request.dto';
import { CreateSwiftLocatorTicketRequestDto } from './dto/request/update-item-warehouse-stock-locator-after-stored.requets.dto';
import { NATS_ITEM } from '@config/nats.config';
import { CreateItemPutAwayTicketRequestDto } from './dto/request/update-item-warehouse-stock-locator-after-put-away.requets.dto';

@Controller('item-warehouses')
export class ItemWarehouseController {
  constructor(
    @Inject('ItemWarehouseServiceInterface')
    private readonly itemWarehouseService: ItemWarehouseServiceInterface,

    @Inject('ImportItemPriceService')
    private readonly importItemPriceService: ImportItemPriceService,
  ) {}

  // @MessagePattern('get_item_warehouse_by_item_ids')
  public async getItemWarehouseByItemIds(
    @Body() body: GetItemWarehouseByItemIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemWarehouseService.getItemWarehouseByItemIds(request);
  }

  @MessagePattern(`${NATS_ITEM}.update_stock_from_order`)
  public async updateStockFromOrderTcp(
    @Body() body: UpdateStockFromOrderRequest,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemWarehouseService.updateStockQuantityFromOrderRequest(
      request,
    );
  }

  // @Post('/update-stock')
  @MessagePattern(`${NATS_ITEM}.update_stock_from_ticket`)
  public async updateStockFromTicketTcp(
    @Body() body: UpdateStockFromTicketRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemWarehouseService.updateStockFromTicketRequest(
      request,
    );
  }

  @MessagePattern(`${NATS_ITEM}.get_item_warehouse_by_item_ids`)
  public async getItemWarehouseByItemIdsTcp(
    @Body() body: GetItemWarehouseByItemIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemWarehouseService.getItemWarehouseByItemIds(request);
  }

  @MessagePattern(
    `${NATS_ITEM}.get_item_warehouse_by_multiple_item_and_warehouse`,
  )
  public async getItemWarehouseByMultipleItemAndWarehouseTcp(
    @Body() body: GetItemWarehouseByMultipleItemAndWarehouseRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemWarehouseService.getItemWarehouseByMultipleItemAndWarehouse(
      request,
    );
  }

  @MessagePattern(`${NATS_ITEM}.get_item_stock_available_by_conditions`)
  public async getItemStockAvailableTcp(
    @Body() body: GetItemStockAvailableRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemWarehouseService.getItemStockAvailable(request);
  }

  @MessagePattern(`${NATS_ITEM}.get_all_item_stock_available_by_conditions`)
  public async getAllItemStockAvailableTcp(
    @Body() body: GetItemAllStockAvailableRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemWarehouseService.getItemAllStockAvailable(request);
  }
  @Post('/all-stock-available')
  public async getAllItemStockAvailable(
    @Body() body: GetItemAllStockAvailableRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemWarehouseService.getItemAllStockAvailable(request);
  }

  @Post('/stock-available')
  public async getItemStockAvailable(
    @Body() body: GetItemStockAvailableRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemWarehouseService.getItemStockAvaiableGroupLocation(
      request,
    );
  }

  @MessagePattern(`${NATS_ITEM}.get_warehouse_stock_by_item_id`)
  public async getWarehouseStockByItemId(
    @Body() body: GetWarehouseStockByItemId,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemWarehouseService.getWarehouseStockByItemId(request);
  }

  @Post('/stock-available/swift-locator')
  @MessagePattern(`${NATS_ITEM}.get_item_stock_available_swift_floor`)
  public async getItemStockAvailableSwiftLocator(
    @Body() body: GetItemStockAvailableSwiftLocatorRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemWarehouseService.getItemStockAvailableSwiftLocator(
      request,
    );
  }

  @MessagePattern(`${NATS_ITEM}.create_item_stock_swift_locator`)
  public async createItemSwiftLocator(
    @Body() body: CreateItemSwiftLocatorRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemWarehouseService.createItemSwiftLocator(request);
  }

  @MessagePattern(`${NATS_ITEM}.create_item_stock_swift_locator_ticket`)
  public async createItemSwiftLocatorTicket(
    @Body() body: CreateItemPutAwayTicketRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemWarehouseService.createItemSwiftLocatorTicket(
      request,
    );
  }

  @MessagePattern(`${NATS_ITEM}.get_item_stock_warehouse_expire_storage_time`)
  public async getItemStockWarehouseExpireStorageTime(
    @Body() payload: GetItemStockWarehouseExpireStorageTimeBodyDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemWarehouseService.getItemStockWarehouseExpireStorageTime(
      request.data,
    );
  }

  @MessagePattern(`${NATS_ITEM}.get_items_price`)
  public async getItemPriceByIds(@Body() payload: GetItemsPrice): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemWarehouseService.getItemsPrice(request);
  }

  @Get('get-item-destination-warehouse')
  async checkItemHasExistDestinationWarehouse(
    @Query() body: GetByItemIdRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemWarehouseService.checkItemHasExistDestinationWarehouse(
      request,
    );
  }

  @Post('import/initial/item-price')
  async importItemPriceInitial(
    @Body() body: ImportItemPriceInitialRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemWarehouseService.importItemPriceInitial(request);
  }

  @Post('import/item-price')
  async importItemPrice(
    @Body() body: ImportItemPriceInitialRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }
    return await this.itemWarehouseService.importItemPrice(request);
  }

  @Post('report/sync-item-price')
  async syncItemPrice(): Promise<any> {
    return await this.itemWarehouseService.syncDailyItemStockWarehousePriceToReport();
  }

  @MessagePattern(`${NATS_ITEM}.update_item_stock_warehouse_price_ebs_in`)
  public async updateItemStockWarehousePriceEbsInTCP(
    @Body() body: UpdateItemStockWarehousePriceEbsInDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemWarehouseService.updateItemStockWarehousePriceEbsIn(
      request,
    );
  }

  @MessagePattern(`${NATS_ITEM}.get_item_stock_warehouse_prices`)
  public async getItemStockWarehousePrices(
    @Body() body: GetListItemStockWarehousePriceRequest,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemWarehouseService.getItemStockWarehousePrices(request);
  }

  @MessagePattern(`${NATS_ITEM}.suggest_locator_poimp_auto_complete`)
  public async suggestLocatorPoimpAutoComplete(
    @Body() body: SuggestLocatorPoimpAutoCompleteRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemWarehouseService.suggestLocatorPoimpAutoComplete(
      request,
    );
  }

  @MessagePattern(`${NATS_ITEM}.suggest_locator_with_item_quantity`)
  public async suggestLocatorWithItemQuantity(
    @Body() body: SuggestLocatorWithItemQuantityRequest,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.itemWarehouseService.suggestLocatorWithItemQuantity(
      request,
    );
  }

  @Public()
  @Post('import/daily/item-price')
  public async importItemPriceEbs(
    @Body() body: DailyImportItemPriceEbsRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.importItemPriceService.importItemPriceEbs(request);
  }
}
