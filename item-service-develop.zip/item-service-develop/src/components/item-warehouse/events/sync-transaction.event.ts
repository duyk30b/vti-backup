export class SyncItemTransaction {
  warehouseMovementId: number;
  itemId: number;
  lotNumber: string | null;
  warehouseId: number;
  locatorId: number;
  quantity: number;
  amount?: number;
  totalAmount?: number;
  transactionDate?: Date;
  constructor(
    itemId: number,
    lotNumber: string | null,
    warehouseId: number,
    locatorId: number,
    quantity: number,
    warehouseMovementId: number,
    amount?: number,
    totalAmount?: number,
    transactionDate?: Date,
  ) {
    this.itemId = itemId;
    this.lotNumber = lotNumber;
    this.warehouseId = warehouseId;
    this.locatorId = locatorId;
    this.quantity = quantity;
    this.amount = amount;
    this.totalAmount = totalAmount;
    this.transactionDate = transactionDate;
    this.warehouseMovementId = warehouseMovementId;
  }
}

export class SyncTransactionEvent {
  orderId: number;
  orderCode: string;
  orderType: number;
  actionType: number;
  items: SyncItemTransaction[];
  constructor(
    orderId: number,
    orderCode: string,
    orderType: number,
    actionType: number,
    items: SyncItemTransaction[],
  ) {
    this.orderId = orderId;
    this.orderCode = orderCode;
    this.orderType = orderType;
    this.actionType = actionType;
    this.items = items;
  }
}
