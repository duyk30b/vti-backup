import { Inject, Logger } from '@nestjs/common';
import { QUEUES_NAME_ENUM } from '@constant/common';
import { Process, Processor } from '@nestjs/bull';
import { ImportItemPriceService } from './import-item-price-ebs.service';
import { ProcessConsumerEnum } from './item-warehouse.constant';

@Processor(QUEUES_NAME_ENUM.CALCULATE_ITEM_PRICE_EBS)
export class CalculateItemPriceEbsConsumer {
  private logger = new Logger(CalculateItemPriceEbsConsumer.name);

  constructor(
    @Inject('ImportItemPriceService')
    private readonly importItemPriceService: ImportItemPriceService,
  ) {}
  @Process(ProcessConsumerEnum.CalculateItemPriceEbs)
  async calculateItemPriceEbs(data) {
    await this.logger.debug('Start calculate item price ebs: ' + new Date());
    await this.importItemPriceService.calculateItemPriceEbs(data.data.ids);
    await this.logger.debug('End calculate item price ebs: ' + new Date());
  }
}
