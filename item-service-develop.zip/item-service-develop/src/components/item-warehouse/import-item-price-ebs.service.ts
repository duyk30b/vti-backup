import { ItemStockWarehousePriceEntity } from '@entities/item/item-stock-warehouse-price.entity';
import { TmpItemPriceEbsEntity } from '@entities/item/tmp-item-price-ebs.entity';
import { ItemStockWarehousePriceRepositoryInterface } from '@components/item/interface/item-stock-warehouse-price.repository.interface';
import { minusBigNumber } from '@utils/common';
import {
  divBigNumber,
  mulBigNumber,
  plusBigNumber,
} from './../../utils/common';
import { SaleServiceInterface } from '@components/sale/interface/sale.service.interface';
import { isJson } from 'src/helper/string.helper';
import { DataSource, In, IsNull } from 'typeorm';
import { WarehouseCronService } from '@components/warehouse/warehouse-cron.service';
import { ItemRepositoryInterface } from '@components/item/interface/item.repository.interface';
import { I18nService } from 'nestjs-i18n';
import { Cell, Workbook, CellValue, CellFormulaValue } from 'exceljs';
import { FILE_TYPE, IMPORT_CONST } from '@constant/import.constant';
import { Inject, Logger } from '@nestjs/common';
import { DailyImportItemPriceEbsRequestDto } from './dto/request/daily-import-item-price-ebs.request.dto';
import { TmpItemPriceEbsRepositoryInterface } from './interface/tmp-item-price-ebs.repository.interface';
import {
  first,
  isEmpty,
  has,
  uniq,
  keyBy,
  map,
  compact,
  groupBy,
  values,
} from 'lodash';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import * as moment from 'moment';
import { InjectQueue } from '@nestjs/bull';
import { QUEUES_NAME_ENUM } from '@constant/common';
import Queue from 'bull';
import {
  ProcessConsumerEnum,
  StatusImportItemPriceEbsEnum,
} from './item-warehouse.constant';
import { InjectDataSource } from '@nestjs/typeorm';
import { isNumberString } from 'class-validator';
import { Buffer } from 'buffer';
import * as Papa from 'papaparse';

export class ImportItemPriceService {
  private logger = new Logger(ImportItemPriceService.name);
  constructor(
    @Inject('TmpItemPriceEbsRepositoryInterface')
    private readonly tmpItemPriceEbsRepository: TmpItemPriceEbsRepositoryInterface,

    @Inject('ItemRepositoryInterface')
    private readonly itemRepository: ItemRepositoryInterface,

    @Inject('WarehouseCronService')
    private readonly warehouseService: WarehouseCronService,

    @Inject('SaleServiceInterface')
    private readonly saleService: SaleServiceInterface,

    @Inject('ItemStockWarehousePriceRepositoryInterface')
    private readonly itemStockWarehousePriceRepository: ItemStockWarehousePriceRepositoryInterface,

    @InjectQueue(QUEUES_NAME_ENUM.CALCULATE_ITEM_PRICE_EBS)
    protected queue: Queue,

    private readonly i18n: I18nService,

    @InjectDataSource()
    private readonly connection: DataSource,
  ) {}
  async importItemPriceEbs(
    request: DailyImportItemPriceEbsRequestDto,
  ): Promise<any> {
    const file = first(request.file);
    const { data: buffer, mimetype: mimeType } = file;

    if (!FILE_TYPE.CSV.MIME_TYPE.includes(mimeType)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withData(await this.i18n.translate('error.IMPORT_INVALID_FILE_TYPE'))
        .build();
    }
    const dataExcels = [];
    let warehouseCodes = [];
    try {
      const colWarehouseCode = 0;
      const fileHeaders = [
        {
          field: 'itemCode',
          required: true,
          type: 'string',
          col: 'B',
          attribute: 'Mã vật tư',
        },
        {
          field: 'lotNumber',
          required: false,
          type: 'string',
          col: 'E',
          default: null,
          attribute: 'Số lô',
        },
        {
          field: 'quantity',
          required: true,
          type: 'number',
          default: 0,
          col: 'H',
          attribute: 'Số lượng',
        },
        {
          field: 'amount',
          required: true,
          type: 'number',
          default: 0,
          col: 'I',
          attribute: 'Đơn giá',
        },
        {
          field: 'totalAmount',
          required: true,
          type: 'number',
          default: 0,
          col: 'J',
          attribute: 'Thành tiền',
        },
      ];

      const content = Buffer.from(buffer).toString(
        IMPORT_CONST.DEFAULT_ENCODING.TEXT as unknown as BufferEncoding,
      );

      const dataRows = Papa.parse(content).data;
      const rowDataStart = 7;
      const invalidData = [] as any;

      let warehouseCodeCurrent: string | null = null;
      loopRow: for (
        let indexRow = rowDataStart;
        indexRow <= dataRows.length;
        indexRow++
      ) {
        const cells = dataRows[indexRow];
        let warehouseCode;
        if (!isEmpty(cells) && cells[colWarehouseCode]) {
          warehouseCode = this.getWarehouseCodeByCell(cells[colWarehouseCode]);
        }
        if (warehouseCode) {
          warehouseCodes.push(warehouseCode);
          warehouseCodeCurrent = warehouseCode;
          continue loopRow;
        }
        if (!warehouseCodeCurrent) {
          continue loopRow;
        }
        const dataRow = {
          row: indexRow,
          warehouseCode: warehouseCodeCurrent,
        } as any;
        if (!cells.length) continue loopRow;
        loopCol: for (
          let indexColHeader = 0;
          indexColHeader < fileHeaders.length;
          indexColHeader++
        ) {
          const property = fileHeaders[indexColHeader];
          const positionCell = `${property.col}${indexRow}`;
          dataRow[property.field] = this.getValueCell(
            cells[this.convertColToIndexArr(property.col)],
            property,
          );
          dataRow.cell = positionCell;
          const messageError = this.validateDataItemPrice(
            dataRow[property.field],
            property,
          );
          if (messageError) {
            invalidData[positionCell] = messageError;
            if (!has(dataRow, messageError)) {
              dataRow.messageError = messageError;
            }
          }
        }
        if (!dataRow?.itemCode) {
          warehouseCodeCurrent = '';
        } else {
          dataExcels.push(dataRow);
        }
      }
    } catch (error) {
      console.error(`Format Data Import Item Price EBS Error:`, error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .build();
    }

    let dataDB = [];
    warehouseCodes = uniq(compact(warehouseCodes));
    const warehouses = await this.warehouseService.getWarehousesByCodes(
      warehouseCodes,
    );
    const serializeWarehouse = keyBy(warehouses, 'code');
    while (dataExcels.length > 0) {
      try {
        const data = dataExcels.splice(0, 200);
        let itemCodes: string[] = map(data, 'itemCode');
        itemCodes = uniq(compact(itemCodes));
        const items = await this.itemRepository.findAllByCondition({
          code: In(uniq(itemCodes)),
        });
        const serializeItem = keyBy(items, 'code');

        const entities = data.map((record) => {
          let messageError = record.messageError;
          if (!messageError && !has(serializeItem, record.itemCode)) {
            messageError = 'Mã vật tư không tồn tại';
          }
          if (!messageError && !has(serializeWarehouse, record.warehouseCode)) {
            messageError = 'Mã kho không tồn tại';
          }
          return this.tmpItemPriceEbsRepository.createEntity({
            itemId: serializeItem[record.itemCode]?.id || null,
            warehouseId: serializeWarehouse[record.warehouseCode]?.id || null,
            ebsTotalAmount: record.totalAmount,
            ebsAmount: record.amount,
            ebsQuantity: record.quantity,
            lotNumber: record.lotNumber,
            warehouseCode: record.warehouseCode,
            itemCode: record.itemCode,
            cell: record.cell,
            messageError: messageError,
          });
        });
        const saveEntities = await this.tmpItemPriceEbsRepository.create(
          entities,
        );
        dataDB = dataDB.concat(saveEntities);
      } catch (error) {
        this.logger.error(
          `Import Price EBS Error - Save data to DB error: ${
            isJson(error) ? JSON.stringify(error) : error
          }`,
        );
      }
    }

    try {
      const dataDbGroupByWarehouse = groupBy(
        dataDB.filter((data) => data.messageError === null),
        'warehouseId',
      );
      const numberDataInQueue = 200;
      loopWarehouse: for (const warehouseId in dataDbGroupByWarehouse) {
        const data = dataDbGroupByWarehouse[warehouseId];
        loopData: for (
          let index = 0;
          index < data.length;
          index = index + numberDataInQueue
        ) {
          await this.queue.add(
            ProcessConsumerEnum.CalculateItemPriceEbs,
            {
              ids: map(data.slice(index, index + numberDataInQueue), 'id'),
            },
            {
              attempts: 1,
              removeOnComplete: true,
              removeOnFail: true,
            },
          );
        }
      }
      return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
    } catch (error) {
      this.logger.error(
        `Import Price EBS Error - Save data to DB error: ${
          isJson(error) ? JSON.stringify(error) : error
        }`,
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .build();
    }
  }

  private convertColToIndexArr(val) {
    const base = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let i,
      j,
      result = 0;
    for (i = 0, j = val.length - 1; i < val.length; i += 1, j -= 1) {
      result += Math.pow(base.length, j) * (base.indexOf(val[i]) + 1);
    }

    return result - 1;
  }

  private getWarehouseCodeByCell(cell): string | null {
    const value = this.getValueCell(cell) as any;
    const prefixWarehouseCode = 'Kho:';
    if (value && `${value}`.indexOf(prefixWarehouseCode) != -1) {
      const [warehouseCode] = value.replace(prefixWarehouseCode, '').split('-');
      return warehouseCode.trim();
    }
    return null;
  }

  private getValueCell(cell, config?) {
    let value = cell;
    if (!value && has(config, 'default')) {
      return config.default;
    }
    if (!value) {
      return value;
    }
    if (config && has(config, 'type') && config.type === 'number') {
      value = `${value}`;
      return value.replaceAll(' ', '').replaceAll(',', '.');
    }
    return value;
  }

  private validateDataItemPrice(value, config?): string | null {
    if (config?.required && value?.length < 0) {
      return `${config.attribute} không được trống`;
    }
    if (config?.type) {
      return this.validateTypeDataImportItemPrice(value, config);
    }
    return null;
  }

  private validateTypeDataImportItemPrice(value, config): string | null {
    switch (config.type) {
      case 'int':
        return !isNumberString(value)
          ? `${config.attribute} = ${value} phải là số nguyên`
          : null;
      case 'number':
        return !isNumberString(value)
          ? `${config.attribute} = ${value} phải là số`
          : null;
      default:
        return null;
    }
  }

  public async calculateItemPriceEbs(ids: number[]): Promise<any> {
    const keyPrefix = '_';
    const dataItemEbs = await this.tmpItemPriceEbsRepository.findAllByCondition(
      {
        id: In(ids),
      },
    );

    const serializeOpenTransactionImport = {};
    const serializeOpenTransactionExport = {};

    const conditionItemPriceWms = dataItemEbs.map((record) => {
      return {
        itemId: record.itemId,
        warehouseId: record.warehouseId,
        lotNumber: record.lotNumber ? record.lotNumber : IsNull(),
      };
    });
    const dataItemPriceWms =
      await this.itemStockWarehousePriceRepository.findAllByCondition(
        conditionItemPriceWms,
      );
    const serializeItemPriceWms = keyBy(dataItemPriceWms, (record) => {
      return [record.warehouseId, record.itemId, record.lotNumber || ''].join(
        keyPrefix,
      );
    });

    try {
      const conditionGetOpenTransaction = {
        dateFrom: moment().subtract(7, 'day').format('YYYY-MM-DD'),
        dateTo: moment().format('YYYY-MM-DD'),
        itemIds: map(dataItemEbs, 'itemId'),
        warehouseId: first(dataItemEbs)?.warehouseId,
      };
      const [
        warehousTransfers,
        inventoryAdjustments,
        saleOrderExports,
        purchasedOrderImports,
      ] = await Promise.all([
        this.warehouseService.getListWarehouseTransferOpenTransaction(
          conditionGetOpenTransaction,
        ),
        this.warehouseService.getListInventoryAdjustmentOpenTransaction(
          conditionGetOpenTransaction,
        ),
        this.saleService.getListSaleOrderExportOpenTransaction(
          conditionGetOpenTransaction,
        ),
        this.saleService.getListPurchasedOrderImportOpenTransaction(
          conditionGetOpenTransaction,
        ),
      ]);

      warehousTransfers?.forEach((warehouseTransfer) => {
        warehouseTransfer?.items?.forEach((item) => {
          if (warehouseTransfer.type === 1) {
            const key = [
              warehouseTransfer.sourceWarehouseId,
              item.itemId,
              item.lotNumber || '',
            ].join(keyPrefix);
            if (!has(serializeOpenTransactionExport, key)) {
              serializeOpenTransactionExport[key] = [];
            }
            serializeOpenTransactionExport[key].push(item);
          } else {
            const key = [
              warehouseTransfer.destinationWarehouseId,
              item.itemId,
              item.lotNumber || '',
            ].join(keyPrefix);
            if (!has(serializeOpenTransactionImport, key)) {
              serializeOpenTransactionImport[key] = [];
            }
            serializeOpenTransactionImport[key].push(item);
          }
        });
      });

      inventoryAdjustments?.forEach((inventoryAdjustment) => {
        inventoryAdjustment?.items?.forEach((item) => {
          const key = [
            inventoryAdjustment.warehouseId,
            item.itemId,
            item.lotNumber || '',
          ].join(keyPrefix);
          if (inventoryAdjustment.type === 1) {
            if (!has(serializeOpenTransactionExport, key)) {
              serializeOpenTransactionExport[key] = [];
            }
            serializeOpenTransactionExport[key].push(item);
          } else {
            if (!has(serializeOpenTransactionImport, key)) {
              serializeOpenTransactionImport[key] = [];
            }
            serializeOpenTransactionImport[key].push(item);
          }
        });
      });

      saleOrderExports?.forEach((saleOrderExport) => {
        saleOrderExport?.items?.forEach((item) => {
          const key = [
            saleOrderExport.warehouseId,
            item.itemId,
            item.lotNumber || '',
          ].join(keyPrefix);
          if (!has(serializeOpenTransactionExport, key)) {
            serializeOpenTransactionExport[key] = [];
          }
          serializeOpenTransactionExport[key].push(item);
        });
      });

      purchasedOrderImports?.forEach((purchasedOrderImport) => {
        purchasedOrderImport?.items?.forEach((item) => {
          const key = [
            purchasedOrderImport.warehouseId,
            item.itemId,
            item.lotNumber || '',
          ].join(keyPrefix);
          if (!has(serializeOpenTransactionImport, key)) {
            serializeOpenTransactionImport[key] = [];
          }
          serializeOpenTransactionImport[key].push(item);
        });
      });
    } catch (error) {
      console.error('Get Open transaction error: ', error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
    dataItemEbs.map((itemEbs) => {
      try {
        const key = [
          itemEbs.warehouseId,
          itemEbs.itemId,
          itemEbs.lotNumber || '',
        ].join(keyPrefix);
        if (!has(serializeItemPriceWms, key)) {
          itemEbs.messageError = 'Chưa tồn tại giá trong kho';
          itemEbs.status = StatusImportItemPriceEbsEnum.Error;
          return itemEbs;
        }
        const itemWms = serializeItemPriceWms[key];
        let data = {
          amount: itemEbs.amount,
          totalAmount: itemEbs.totalAmount,
        };
        if (
          !has(serializeOpenTransactionExport, key) &&
          !has(serializeOpenTransactionImport, key)
        ) {
          data = this.calculateItemPriceCase1(itemEbs, itemWms);
        } else if (
          has(serializeOpenTransactionExport, key) &&
          !has(serializeOpenTransactionImport, key)
        ) {
          data = this.calculateItemPriceCase2(itemEbs, itemWms);
        } else if (
          !has(serializeOpenTransactionExport, key) &&
          has(serializeOpenTransactionImport, key)
        ) {
          data = this.calculateItemPriceCase3(
            itemEbs,
            itemWms,
            serializeOpenTransactionImport[key],
          );
        } else {
          data = this.calculateItemPriceCase4(
            itemEbs,
            itemWms,
            serializeOpenTransactionImport[key],
            serializeOpenTransactionExport[key],
          );
        }
        itemEbs.wmsAmount = itemWms.amount || 0;
        itemEbs.wmsTotalAmount = itemWms.totalAmount || 0;
        if (data.amount >= 0 && data.totalAmount >= 0) {
          itemEbs.status = StatusImportItemPriceEbsEnum.Success;
          itemEbs.amount = this.toFixedBigNumber(data.amount, 5);
          itemEbs.totalAmount = this.toFixedBigNumber(data.totalAmount, 5);
          itemEbs.quantity = this.toFixedBigNumber(itemWms.quantity, 5);
          itemWms.amount = this.toFixedBigNumber(data.totalAmount, 2);
          itemWms.totalAmount = this.toFixedBigNumber(data.totalAmount, 5);
          serializeItemPriceWms[key] = itemWms;
        } else {
          itemEbs.messageError = `amount = ${data.amount}, totalAmount = ${data.totalAmount} không hợp lệ`;
          itemEbs.status = StatusImportItemPriceEbsEnum.Error;
        }
        return itemEbs;
      } catch (error) {
        console.error('Calculate item price error: ', error);
        itemEbs.status = StatusImportItemPriceEbsEnum.Error;
        itemEbs.messageError = isJson(error)
          ? JSON.stringify(error)
          : typeof error === 'string'
          ? error
          : 'Lỗi không xác định';
        return itemEbs;
      }
    });

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();

    try {
      await queryRunner.manager.save(TmpItemPriceEbsEntity, dataItemEbs);
      await queryRunner.manager.save(
        ItemStockWarehousePriceEntity,
        values(serializeItemPriceWms),
      );
      await queryRunner.commitTransaction();
      console.info('Save calculate item price ebs success');
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('success.SUCCESS'))
        .build();
    } catch (error) {
      console.error('Save calculate item price ebs error: ', error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    } finally {
      await queryRunner.release();
    }
  }

  // Case 1
  private calculateItemPriceCase1(
    itemEbs: TmpItemPriceEbsEntity,
    itemWms: ItemStockWarehousePriceEntity,
  ): any {
    const amount = divBigNumber(
      itemEbs.ebsTotalAmount,
      itemEbs.ebsQuantity || 1,
    );
    const totalAmount = mulBigNumber(
      divBigNumber(itemEbs.ebsTotalAmount, itemEbs.ebsQuantity),
      itemWms.quantity,
    );
    return { amount, totalAmount };
  }

  // Case 2
  private calculateItemPriceCase2(
    itemEbs: TmpItemPriceEbsEntity,
    itemWms: ItemStockWarehousePriceEntity,
  ): any {
    const amount = divBigNumber(
      itemEbs.ebsTotalAmount,
      itemEbs.ebsQuantity || 1,
    );
    const totalAmount = mulBigNumber(
      divBigNumber(itemEbs.ebsTotalAmount, itemEbs.ebsQuantity),
      itemWms.quantity,
    );
    return { amount, totalAmount };
  }

  // Case 3
  private calculateItemPriceCase3(
    itemEbs: TmpItemPriceEbsEntity,
    itemWms: ItemStockWarehousePriceEntity,
    openTransactionImport,
  ): any {
    // Tổng giá trị phiếu nhập lệnh open transaction
    let totalAmountOpenTransactionImport = 0;

    // Tổng số lượng phiếu nhập lệnh open transaction
    let totalQuantityOpenTransaction = 0;
    openTransactionImport.forEach((data) => {
      // Tính tổng giá trị phiếu nhập lệnh open transaction
      totalAmountOpenTransactionImport = plusBigNumber(
        mulBigNumber(data.amount, data.quantity),
        totalAmountOpenTransactionImport,
      );

      // Tính tổng số lượng phiếu nhập lệnh open transaction
      totalQuantityOpenTransaction = plusBigNumber(
        data.quantity,
        totalQuantityOpenTransaction,
      );
    });

    const totalAmount = mulBigNumber(
      divBigNumber(
        plusBigNumber(itemEbs.ebsTotalAmount, totalAmountOpenTransactionImport),
        plusBigNumber(itemEbs.ebsQuantity, totalQuantityOpenTransaction),
      ),
      itemWms.quantity,
    );
    const amount = divBigNumber(totalAmount, itemWms.quantity || 1);
    return { amount, totalAmount };
  }

  // Case 4
  private calculateItemPriceCase4(
    itemEbs: TmpItemPriceEbsEntity,
    itemWms: ItemStockWarehousePriceEntity,
    openTransactionImport,
    openTransactionExport,
  ): any {
    let amount = 0,
      totalAmount = 0;
    // Case 4.4.1
    if (itemWms.quantity >= itemEbs.ebsQuantity) {
      totalAmount = minusBigNumber(
        itemWms.totalAmount,
        mulBigNumber(
          itemEbs.ebsQuantity,
          minusBigNumber(itemWms.amount, itemEbs.ebsAmount),
        ),
      );
    } else {
      // Case 4.4.2
      // Tổng gía trị phiếu nhập lệnh open transaction
      let totalAmountOpenTransactionImport = 0;
      openTransactionImport.forEach((data) => {
        // Tính tổng giá trị phiếu nhập lệnh open transaction
        totalAmountOpenTransactionImport = plusBigNumber(
          mulBigNumber(data.amount, data.quantity),
          totalAmountOpenTransactionImport,
        );
      });

      // Tổng gía trị phiếu xuất lệnh open transaction
      let totalAmountOpenTransactionExport = 0;
      openTransactionExport.forEach((data) => {
        // Tính tổng giá trị phiếu xuất lệnh open transaction
        totalAmountOpenTransactionExport = plusBigNumber(
          mulBigNumber(data.amount, data.quantity),
          totalAmountOpenTransactionExport,
        );
      });
      totalAmount = plusBigNumber(
        itemEbs.ebsTotalAmount,
        minusBigNumber(
          totalAmountOpenTransactionImport,
          totalAmountOpenTransactionExport,
        ),
      );
    }
    amount = divBigNumber(totalAmount, itemWms.quantity || 1);
    return { amount, totalAmount };
  }

  private toFixedBigNumber(number: string | number, scale = 5): any {
    const [leftNumber, rightNumber] = `${number}`.split('.');
    return [
      leftNumber,
      rightNumber?.slice(0, scale) || '00'.slice(0, scale),
    ].join('.');
  }
}
