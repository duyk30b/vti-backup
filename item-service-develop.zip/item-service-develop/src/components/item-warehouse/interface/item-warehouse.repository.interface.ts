import { ReportItemStockRequestDto } from '@components/dashboard/dto/request/report-item-stock.request.dto';
import { GetQuantityItemWarehouseRequestDto } from '@components/item/dto/request/get-quantity-item-warehouse-request.dto';
import { GetReportDailyDto } from '@components/item/dto/request/get-report-daily.dto';
import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { ItemWarehouseEntity } from '@entities/item/item-warehouse.entity';
import { ItemWarehouseFilter } from '../dto/request/item-warehouse-filter-request.dto';

export interface ItemWarehouseRepositoryInterface
  extends BaseInterfaceRepository<ItemWarehouseEntity> {
  getItemStockExist(
    items: ItemWarehouseFilter[],
  ): Promise<ItemWarehouseEntity[]>;
  getStockDaily(request: GetReportDailyDto): Promise<any[]>;
  getQuantityItemWarehouse(
    request: GetQuantityItemWarehouseRequestDto,
  ): Promise<any[]>;
  getTotalItemStock(request: ReportItemStockRequestDto): Promise<any>;
}
