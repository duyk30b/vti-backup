import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { TmpItemPriceEbsEntity } from '@entities/item/tmp-item-price-ebs.entity';
export interface TmpItemPriceEbsRepositoryInterface
  extends BaseInterfaceRepository<TmpItemPriceEbsEntity> {
  createEntity(request: any): TmpItemPriceEbsEntity;
  getListByIds(ids: number[]): Promise<any>;
}
