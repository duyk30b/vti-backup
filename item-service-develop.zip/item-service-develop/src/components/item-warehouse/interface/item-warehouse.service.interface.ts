import { DailyImportItemPriceEbsRequestDto } from './../dto/request/daily-import-item-price-ebs.request.dto';
import { GetListItemStockWarehousePriceRequest } from '@components/item/dto/request/get-list-item-stock-warehouse-price.request';
import { GetListItemStockWarehousePriceRequestDto } from '@components/item/dto/request/get-list-item-stock-warehouse-price.request.dto';
import { ResponsePayload } from '@utils/response-payload';
import { CreateItemSwiftLocatorRequestDto } from '../dto/request/create-item-swift-locator.request.dto';
import { GetByItemIdRequestDto } from '../dto/request/get-by-item-id.request.dto';
import { GetItemStockAvailableSwiftLocatorRequestDto } from '../dto/request/get-item-stock-available-swift-locator.request.dto';
import { GetItemStockWarehouseExpireStorageTimeRequestDto } from '../dto/request/get-item-stock-warehouse-expire-storage-time.request.dto';
import { GetItemWarehouseByItemIdsRequestDto } from '../dto/request/get-item-warehouse-by-item-ids.request.dto';
import { GetItemWarehouseByMultipleItemAndWarehouseRequestDto } from '../dto/request/get-item-warehouse-by-multiple-item-and-warehouse.request.dto';
import { GetItemsPrice } from '../dto/request/get-items-price.request';
import { ImportItemPriceInitialRequestDto } from '../dto/request/import-item-price-initial.request.dto';
import { UpdateItemStockWarehousePriceEbsInDto } from '../dto/request/update-item-stock-warehouse-price-ebs-in.request.dto';
import { UpdateStockFromOrderRequest } from '../dto/request/update-stock-from-order-request.dto';
import { GetItemStockAvailableRequestDto } from './../dto/request/get-item-stock-available.request.dto';
import { GetItemAllStockAvailableRequestDto } from '../dto/request/get-item-stock-available-all-warehouse.request.dto';
import { GetWarehouseStockByItemId } from '../dto/request/get-warehouse-stock-by-item-id.request.dto';
import { SuggestLocatorPoimpAutoCompleteRequestDto } from '../dto/request/suggest-locator-poimp-auto-complete.request.dto';
import { SuggestLocatorWithItemQuantityRequest } from '../dto/request/suggest-locator-with-item-quantity.request.dto';

export interface ItemWarehouseServiceInterface {
  updateStockQuantityFromOrderRequest(
    dataUpdate: UpdateStockFromOrderRequest,
  ): Promise<any>;
  getItemWarehouseByItemIds(
    request: GetItemWarehouseByItemIdsRequestDto,
  ): Promise<any>;
  getItemWarehouseByMultipleItemAndWarehouse(
    request: GetItemWarehouseByMultipleItemAndWarehouseRequestDto,
  ): Promise<any>;
  getItemStockAvailable(request: GetItemStockAvailableRequestDto): Promise<any>;
  getItemAllStockAvailable(
    request: GetItemAllStockAvailableRequestDto,
  ): Promise<any>;
  getItemStockAvaiableGroupLocation(
    request: GetItemStockAvailableSwiftLocatorRequestDto,
  ): Promise<any>;
  getItemStockAvailableSwiftLocator(
    request: GetItemStockAvailableRequestDto,
  ): Promise<any>;
  createItemSwiftLocator(
    request: CreateItemSwiftLocatorRequestDto,
  ): Promise<any>;
  getItemStockWarehouseExpireStorageTime(
    payload: GetItemStockWarehouseExpireStorageTimeRequestDto[],
  ): Promise<any>;
  checkItemHasExistDestinationWarehouse(
    request: GetByItemIdRequestDto,
  ): Promise<any>;
  importItemPriceInitial(
    request: ImportItemPriceInitialRequestDto,
  ): Promise<any>;
  importItemPrice(request: ImportItemPriceInitialRequestDto): Promise<any>;
  syncDailyItemStockWarehousePriceToReport(): Promise<any>;
  updateItemStockWarehousePriceEbsIn(
    request: UpdateItemStockWarehousePriceEbsInDto,
  ): Promise<any>;
  getItemsPrice(request: GetItemsPrice): Promise<ResponsePayload<any>>;
  getItemStockWarehousePrices(
    request: GetListItemStockWarehousePriceRequest,
  ): Promise<any>;
  getWarehouseStockByItemId(request: GetWarehouseStockByItemId): Promise<any>;
  suggestLocatorPoimpAutoComplete(
    request: SuggestLocatorPoimpAutoCompleteRequestDto[],
  ): Promise<any>;
  suggestLocatorWithItemQuantity(
    request: SuggestLocatorWithItemQuantityRequest,
  ): Promise<any>;
}
