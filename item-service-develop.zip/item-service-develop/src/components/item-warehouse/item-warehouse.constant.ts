export enum WarehouseMovementTypeEnum {
  PO_IMPORT = 0,
  PO_EXPORT = 1,
  PRO_IMPORT = 2,
  PRO_EXPORT = 3,
  SO_IMPORT = 4,
  SO_EXPORT = 5,
  TRANFER_IMPORT = 6,
  TRANFER_EXPORT = 7,
  IMO_IMPORT = 8,
  EXO_EXPORT = 9,
  PO_IMPORT_RETURN = 10,
  SO_EXPORT_RETURN = 11,
  RETURN_IMPORT = 12,
  RETURN_EXPORT = 13,
  RETURN_PO_ERROR = 14,
  RETURN_SO_ERROR = 15,
  SWIFT_FLOOR_IMPORT = 16,
  SWIFT_FLOOR_EXPORT = 17,
  PO_IMPORT_RECEIVE = 18,
  PO_EXPORT_RECEIVE = 19,
}

export enum WarehouseMovementStatusEnum {
  CREATED = 0,
  APPROVED = 1,
}

export enum WarehouseMovementOrderStatusEnum {
  IN_PROGRESS = 2,
  COMPLETED = 4,
}

export enum WarehouseTransferStatusEnum {
  CREATED = 0,
  PENDING = 1,
  COMPLETED = 2,
  REJECTED = 3,
  CONFIRMED = 4,
  EXPORTING = 5,
}

export const CAN_UPDATE_TRANSFER_STATUS: number[] = [
  WarehouseTransferStatusEnum.CREATED,
  WarehouseTransferStatusEnum.PENDING,
];

export const CAN_EXPORT_TRANSFER_STATUS: number[] = [
  WarehouseTransferStatusEnum.CONFIRMED,
  WarehouseTransferStatusEnum.PENDING,
  WarehouseTransferStatusEnum.EXPORTING,
];

export const CAN_IMPORT_TRANSFER_STATUS: number[] = [
  WarehouseTransferStatusEnum.EXPORTING,
];

export const CAN_DELETE_WAREHOUSE_TRANSFER_STATUS: number[] = [
  WarehouseTransferStatusEnum.CREATED,
  WarehouseTransferStatusEnum.REJECTED,
];

export enum WarehouseTransferTypeEnum {
  ONE_STEP = 0,
  TWO_STEP = 1,
}

export const WAREHOUSE_MOVEMENT_TYPES: number[] = [
  WarehouseMovementTypeEnum.PO_IMPORT,
  WarehouseMovementTypeEnum.PO_EXPORT,
  WarehouseMovementTypeEnum.PRO_IMPORT,
  WarehouseMovementTypeEnum.SO_IMPORT,
  WarehouseMovementTypeEnum.SO_EXPORT,
];

export const WAREHOUSE_IMPORT_MOVEMENT_TYPES: number[] = [
  WarehouseMovementTypeEnum.PO_IMPORT,
  WarehouseMovementTypeEnum.PRO_IMPORT,
  WarehouseMovementTypeEnum.SO_IMPORT,
];

export const WAREHOUSE_EXPORT_MOVEMENT_TYPES: number[] = [
  WarehouseMovementTypeEnum.PO_EXPORT,
  WarehouseMovementTypeEnum.PRO_EXPORT,
  WarehouseMovementTypeEnum.SO_EXPORT,
];

export enum ItemStockMovementTypeEnum {
  Import = 0,
  Export = 1,
}

export enum WarehouseByLotManagementEnum {
  NOLOT = 0,
  LOT = 1,
}
export const ORDER_TYPE_PO = 1;

export enum StatusImportItemPriceEbsEnum {
  Created = 0,
  Success = 2,
  Error = 3,
}

export enum ProcessConsumerEnum {
  CalculateItemPriceEbs = 'CalculateItemPriceEbs',
}
