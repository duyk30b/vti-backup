import { GetListItemStockWarehouseLocatorByCondition } from './../item/dto/request/item-stock-warehouse-locator/get-list-item-stock-warehouse-locator.request.dto';
import { SaleOrderTypeEnum } from './../sale/sale.constant';
import { TmpItemPriceEbsRepositoryInterface } from './interface/tmp-item-price-ebs.repository.interface';
import { ItemPlanningQuantityRepositoryInterface } from '@components/item-planning-quantity/interface/item-planning-quantity.repository.interface';
import {
  ItemStockMovementTypeEnum,
  WarehouseByLotManagementEnum,
} from '@components/item-warehouse/item-warehouse.constant';
import { ItemStockMovementHistoryDto } from '@components/item/dto/request/create-item-stock-movement-history.request.dto';
import { CreateItemStockWarehouseLocatorHistoryRequestDto } from '@components/item/dto/request/create-item-stock-warehouse-locator-history.request.dto';
import { CreateItemStockWarehouseLocatorRequestDto } from '@components/item/dto/request/create-item-stock-warehouse-locator-request.dto';
import { GetListItemStockWarehousePriceRequest } from '@components/item/dto/request/get-list-item-stock-warehouse-price.request';
import { GetListItemStockWarehousePriceRequestDto } from '@components/item/dto/request/get-list-item-stock-warehouse-price.request.dto';
import { ItemStockMovementHistoryRepositoryInterface } from '@components/item/interface/item-stock-movement-history.interface';
import { ItemStockMovementRepositoryInterface } from '@components/item/interface/item-stock-movement.repository.interface';
import { ItemStockWarehouseLocatorHistoryRepositoryInterface } from '@components/item/interface/item-stock-warehouse-locator-history.interface';
import { ItemStockWarehouseLocatorRepositoryInterface } from '@components/item/interface/item-stock-warehouse-locator.repository.interface';
import { ItemStockWarehousePriceRepositoryInterface } from '@components/item/interface/item-stock-warehouse-price.repository.interface';
import { ItemRepositoryInterface } from '@components/item/interface/item.repository.interface';
import { EventSyncTransactionEnum } from '@components/item/item.constant';
import { UserServiceInterface } from '@components/user/interface/user.service.interface';
import { WarehouseLayoutServiceInterface } from '@components/warehouse-layout/interface/warehouse-layout.service.interface';
import { WarehouseCronService } from '@components/warehouse/warehouse-cron.service';
import { OrderTypeEnum } from '@constant/common';
import { FILE_TYPE } from '@constant/import.constant';
import { ResponseCodeEnum } from '@constant/response-code.enum';
import { ItemStockMovementHistory } from '@entities/item/item-stock-movement-history.entity';
import { ItemStockWarehouseLocatorHistoryEntity } from '@entities/item/item-stock-warehouse-locator-history.entity';
import { ItemStockWarehouseLocatorEntity } from '@entities/item/item-stock-warehouse-locator.entity';
import { ItemStockWarehousePriceEntity } from '@entities/item/item-stock-warehouse-price.entity';
import { ItemWarehouseEntity } from '@entities/item/item-warehouse.entity';
import { Inject, Injectable, Logger } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Cron } from '@nestjs/schedule';
import { InjectDataSource } from '@nestjs/typeorm';
import * as Moment from 'moment';
import * as moment from 'moment';
import {
  divBigNumber,
  minusBigNumber,
  mulBigNumber,
  plusBigNumber,
} from '@utils/common';
import { div, minus, plus } from '@utils/helper';
import { ResponseBuilder } from '@utils/response-builder';
import { ResponsePayload } from '@utils/response-payload';
import { plainToInstance } from 'class-transformer';
import { Row, Workbook } from 'exceljs';
import {
  cloneDeep,
  compact,
  first,
  flatMap,
  groupBy,
  has,
  isEmpty,
  isUndefined,
  keyBy,
  map,
  min,
  orderBy,
  sumBy,
  uniq,
  values,
} from 'lodash';
import { I18nService } from 'nestjs-i18n';
import { DataSource, ILike, In, IsNull, MoreThan, Not } from 'typeorm';
import { ItemPlanningQuantityEntity } from './../../entities/item/item-planning-quantity.entity';
import { ItemStockMovement } from './../../entities/item/item-stock-movement.entity';
import { ItemStockMovementDto } from './../item/dto/request/create-item-stock-movement.request.dto';
import { CreateItemStockWarehousePriceDto } from './dto/request/create-item-stock-warehouse-price.request.dto';
import { CreateItemSwiftLocatorRequestDto } from './dto/request/create-item-swift-locator.request.dto';
import { GetByItemIdRequestDto } from './dto/request/get-by-item-id.request.dto';
import { GetItemStockAvailableSwiftLocatorRequestDto } from './dto/request/get-item-stock-available-swift-locator.request.dto';
import {
  FilterItemByCondition,
  GetItemStockAvailableRequestDto,
} from './dto/request/get-item-stock-available.request.dto';
import { GetItemStockWarehouseExpireStorageTimeRequestDto } from './dto/request/get-item-stock-warehouse-expire-storage-time.request.dto';
import { GetItemWarehouseByItemIdsRequestDto } from './dto/request/get-item-warehouse-by-item-ids.request.dto';
import { GetItemWarehouseByMultipleItemAndWarehouseRequestDto } from './dto/request/get-item-warehouse-by-multiple-item-and-warehouse.request.dto';
import { GetItemsPrice } from './dto/request/get-items-price.request';
import { ImportItemPriceInitialRequestDto } from './dto/request/import-item-price-initial.request.dto';
import { ItemExportWarehouseLocatorRequestDto } from './dto/request/item-export-warehouse-locator.request.dto';
import { ItemWarehouseFilter } from './dto/request/item-warehouse-filter-request.dto';
import {
  DataItemWarehousePriceRequestDto,
  SyncItemWarehouseStockPriceRequestDto,
} from './dto/request/sync-item-warehouse-stock-price.request.dto';
import { UpdateItemStockWarehousePriceEbsInDto } from './dto/request/update-item-stock-warehouse-price-ebs-in.request.dto';
import { UpdateItemStockWarehousePriceDto } from './dto/request/update-item-stock-warehouse-price.request.dto';
import { UpdateStockFromOrderRequest } from './dto/request/update-stock-from-order-request.dto';
import { ItemStockAvailableSwiftFloorResponseDto } from './dto/response/item-stock-available-swift-floor.response.dto';
import { ItemStockAvailableResponseDto } from './dto/response/item-stock-available.response.dto';
import { ItemStockMovementResponse } from './dto/response/item-stock-movement.response.dto';
import { ItemWarehouseResponseDto } from './dto/response/item-warehouse.response.dto';
import {
  SyncItemTransaction,
  SyncTransactionEvent,
} from './events/sync-transaction.event';
import { ItemWarehouseRepositoryInterface } from './interface/item-warehouse.repository.interface';
import { ItemWarehouseServiceInterface } from './interface/item-warehouse.service.interface';
import {
  FilterItemAllWarehouseByCondition,
  GetItemAllStockAvailableRequestDto,
} from './dto/request/get-item-stock-available-all-warehouse.request.dto';
import { GetWarehouseStockByItemId } from './dto/request/get-warehouse-stock-by-item-id.request.dto';
import { SuggestLocatorPoimpAutoCompleteRequestDto } from './dto/request/suggest-locator-poimp-auto-complete.request.dto';
import { SuggestLocatorPoimpAutoCompleteResponseDto } from './dto/response/suggest-locator-poimp-auto-complete.response.dto';
import { SuggestLocatorWithItemQuantityRequest } from './dto/request/suggest-locator-with-item-quantity.request.dto';
import { SaleServiceInterface } from '@components/sale/interface/sale.service.interface';
import { MovementRepositoryInterface } from '@components/item-movement/interfaces/item-movement.repository.interface';
import { UpdateStockFromTicketRequestDto } from './dto/request/update-stock-from-ticket-request.request.dto';
import { MovementResponseDto } from './dto/response/item-movement.response.dto';
import { CreateItemStockWarehouseLocatorHistoryTicketRequestDto } from '@components/item/dto/response/item-warehouse-stock-locator/create-item-stock-warehouse-locator-history-ticket.request.dto';
import { CreateItemPutAwayTicketRequestDto } from './dto/request/update-item-warehouse-stock-locator-after-put-away.requets.dto';

@Injectable()
export class ItemWarehouseService implements ItemWarehouseServiceInterface {
  private readonly logger = new Logger(ItemWarehouseService.name);

  constructor(
    @Inject('ItemStockMovementRepositoryInterface')
    private readonly itemStockMovementRepository: ItemStockMovementRepositoryInterface,
    @Inject('ItemWarehouseRepositoryInterface')
    private readonly itemWarehouseRepository: ItemWarehouseRepositoryInterface,
    @Inject('ItemStockWarehouseLocatorRepositoryInterface')
    private readonly itemStockWarehouseLocatorRepository: ItemStockWarehouseLocatorRepositoryInterface,
    @Inject('ItemStockWarehouseLocatorHistoryRepositoryInterface')
    private readonly itemStockWarehouseLocatorHistoryRepository: ItemStockWarehouseLocatorHistoryRepositoryInterface,
    @Inject('MovementRepositoryInterface')
    private readonly movementRepository: MovementRepositoryInterface,
    @Inject('ItemPlanningQuantityRepositoryInterface')
    private readonly itemPlanningQuantityRepository: ItemPlanningQuantityRepositoryInterface,
    @Inject('ItemStockMovementHistoryRepositoryInterface')
    private readonly itemStockMovementHistoryRepository: ItemStockMovementHistoryRepositoryInterface,
    @Inject('ItemRepositoryInterface')
    private readonly itemRepository: ItemRepositoryInterface,
    @Inject('ItemStockWarehousePriceRepositoryInterface')
    private readonly itemStockWarehousePriceRepository: ItemStockWarehousePriceRepositoryInterface,
    @Inject('TmpItemPriceEbsRepositoryInterface')
    private readonly tmpItemPriceEbsRepository: TmpItemPriceEbsRepositoryInterface,
    @Inject(WarehouseCronService)
    private readonly warehouseService: WarehouseCronService,
    @Inject('UserServiceInterface')
    private readonly userService: UserServiceInterface,
    @Inject('SaleServiceInterface')
    private readonly saleService: SaleServiceInterface,
    private readonly i18n: I18nService,
    @Inject('WarehouseLayoutServiceInterface')
    private readonly warehouseLayoutService: WarehouseLayoutServiceInterface,
    // @Inject('KAFKA_PRODUCER')
    // private kafkaProducer: Producer,

    @InjectDataSource()
    private readonly connection: DataSource,
    private readonly eventEmitter: EventEmitter2,
  ) {}

  async updateStockQuantityFromOrderRequest(
    dataUpdate: UpdateStockFromOrderRequest,
  ): Promise<any> {
    const {
      warehouseStockMovementId,
      warehouseStockMovementIds,
      itemStockWarehousePrices,
      saleOrderType,
    } = dataUpdate;
    const itemsStockMovementDataRaw =
      await this.itemStockMovementRepository.getDataByWarehouseStockMovementId(
        !isEmpty(warehouseStockMovementIds)
          ? warehouseStockMovementIds
          : [warehouseStockMovementId],
      );

    const itemsStockMovementData = plainToInstance(
      ItemStockMovementResponse,
      itemsStockMovementDataRaw,
      {
        excludeExtraneousValues: true,
      },
    );

    const characterPrefix = '_';
    const groupItemStockByItemWarehouse = groupBy(
      itemsStockMovementData,
      (itemStock) =>
        [itemStock.itemId, itemStock.warehouseId].join(characterPrefix),
    );

    const conditionQueryItemStockExist = Object.keys(
      groupItemStockByItemWarehouse,
    ).map((keyItemStock) => {
      const [itemId, warehouseId] = keyItemStock.split(characterPrefix);
      return new ItemWarehouseFilter(+itemId, +warehouseId);
    });

    const warehouses = await this.warehouseService.getListByIDs([
      itemsStockMovementData[0].warehouseId,
    ]);
    const warehouse = warehouses[0];

    const dataItemsWarehouseExist =
      await this.itemWarehouseRepository.getItemStockExist(
        conditionQueryItemStockExist,
      );
    let itemWarehouseEntities: ItemWarehouseEntity[] = [];
    let itemStockWarehouseLocatorEntities: ItemStockWarehouseLocatorEntity[] =
      [];
    let itemPlanningEntities: ItemPlanningQuantityEntity[] = [];
    let itemStockWarehouseLocatorHistoryEntities: ItemStockWarehouseLocatorHistoryEntity[] =
      [];

    const isPoimpHasLot =
      warehouse.manageByLot === WarehouseByLotManagementEnum.LOT &&
      saleOrderType === SaleOrderTypeEnum.PO;
    switch (dataUpdate.orderType) {
      case OrderTypeEnum.Import:
        itemWarehouseEntities = this.createItemWarehouseEntitiesByImport(
          itemsStockMovementData,
          dataItemsWarehouseExist,
        );
        [
          itemStockWarehouseLocatorEntities,
          itemStockWarehouseLocatorHistoryEntities,
        ] = this.createItemStockWarehouseLocatorEntitiesByImport(
          itemsStockMovementData,
        );

        break;
      default:
        itemWarehouseEntities = this.createItemWarehouseEntitiesByExport(
          itemsStockMovementData,
          dataItemsWarehouseExist,
        );

        // phiếu nhập kho có lô, giữ hàng đến khi đồng bộ EBS thành công
        if (!isPoimpHasLot)
          itemPlanningEntities = await this.updateItemPlanningAfterExport(
            itemsStockMovementData,
            dataUpdate.orderId,
            dataUpdate.saleOrderType,
          );
        itemStockWarehouseLocatorEntities =
          await this.createItemStockWarehouseLocatorEntitiesByExport(
            itemsStockMovementData,
          );
        break;
    }
    const itemStockMovementExist =
      await this.itemStockMovementRepository.findAllByCondition({
        id: In(map(itemsStockMovementDataRaw, 'id')),
      });
    const timestamp = new Date();
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      let itemStockWarehousePrice;
      let dataItemStockWarehousePrice = [];
      if (!isEmpty(itemStockWarehousePrices)) {
        itemStockWarehousePrice =
          dataUpdate.orderType == OrderTypeEnum.Import
            ? await this.createItemStockWarehousePrice({
                items: itemStockWarehousePrices,
              })
            : await this.updateItemStockWarehousePrice({
                items: itemStockWarehousePrices,
              });
        dataItemStockWarehousePrice = itemStockWarehousePrice?.data;
      }

      if (
        !isEmpty(itemStockWarehousePrice) &&
        itemStockWarehousePrice?.statusCode !== ResponseCodeEnum.SUCCESS
      ) {
        throw itemStockWarehousePrice.message;
      } else if (!isEmpty(dataUpdate.conditions)) {
        dataItemStockWarehousePrice =
          await this.itemStockWarehousePriceRepository.findAllByCondition(
            dataUpdate.conditions,
          );
      }
      const itemMap = {};
      dataItemStockWarehousePrice?.forEach((item) => {
        if (!itemMap[item.itemId]) {
          itemMap[item.itemId] = { ...item, quantity: 0, totalAmount: 0 };
        }
        itemMap[item.itemId].quantity += +item.quantity;
        itemMap[item.itemId].totalAmount += +item.totalAmount;
      });
      itemStockMovementExist.forEach((item) => {
        const amount = div(
          itemMap[item.itemId]?.totalAmount || 0,
          +itemMap[item.itemId]?.quantity || 1,
        );
        item.amount = amount;
        item.confirmedAt = timestamp;
      });

      await queryRunner.manager.save(ItemStockMovement, itemStockMovementExist);
      await queryRunner.manager.save(
        ItemWarehouseEntity,
        itemWarehouseEntities,
      );
      const dataItemStockWarehouseLocators = await queryRunner.manager.save(
        ItemStockWarehouseLocatorEntity,
        itemStockWarehouseLocatorEntities,
      );
      if (!isEmpty(itemPlanningEntities)) {
        await queryRunner.manager.save(
          ItemPlanningQuantityEntity,
          itemPlanningEntities,
        );
      }
      if (dataUpdate.orderType === OrderTypeEnum.Import) {
        itemStockWarehouseLocatorHistoryEntities.forEach(
          (itemStockHistory, index) => {
            const itemStock = dataItemStockWarehouseLocators[index];
            if (!isEmpty(itemStock)) {
              itemStockHistory.itemStockWarehouseLocatorId = itemStock.id;
              itemStockHistory.purpose = dataUpdate.purpose;
            }
          },
        );
        itemStockWarehouseLocatorHistoryEntities =
          itemStockWarehouseLocatorHistoryEntities.filter(
            (itemStockHistory) => itemStockHistory.itemStockWarehouseLocatorId,
          );
      }

      if (!isEmpty(itemStockWarehouseLocatorHistoryEntities)) {
        itemStockWarehouseLocatorHistoryEntities =
          await queryRunner.manager.save(
            ItemStockWarehouseLocatorHistoryEntity,
            itemStockWarehouseLocatorHistoryEntities,
          );
      }

      if (!isEmpty(itemStockWarehousePrice?.data)) {
        await queryRunner.manager.save(
          ItemStockWarehousePriceEntity,
          itemStockWarehousePrice?.data,
        );
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      this.logger.error(
        'UPDATE ITEM STOCK ERROR: ' + JSON.stringify(error?.message || error),
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
    const itemIds = !isEmpty(itemStockWarehousePrices)
      ? map(itemStockWarehousePrices, 'itemId')
      : map(dataUpdate.conditions, 'itemId');
    const lotNumbers = !isEmpty(itemStockWarehousePrices)
      ? map(itemStockWarehousePrices, 'lotNumber')
      : map(dataUpdate.conditions, 'lotNumber');

    if (!isEmpty(itemIds)) {
      console.log('--callSyncItemStockWarehousePriceToReport--');
      await this.callSyncItemStockWarehousePriceToReport(itemIds, lotNumbers);
    }
    try {
      const itemsEvent: SyncItemTransaction[] = [];
      itemsStockMovementData.forEach((itemStock) => {
        itemStock.histories.forEach((history) => {
          itemsEvent.push(
            new SyncItemTransaction(
              history.itemId,
              history.lotNumber,
              itemStock.warehouseId,
              history.locatorId,
              history.quantity,
              itemStock.warehouseStockMovementId,
              history.amount,
              history.totalAmount,
              timestamp,
            ),
          );
        });
      });
      const stockMovement = first(
        itemsStockMovementData,
      ) as ItemStockMovementResponse;
      const event = new SyncTransactionEvent(
        dataUpdate.orderId,
        stockMovement?.orderCode,
        dataUpdate.saleOrderType,
        dataUpdate.orderType,
        itemsEvent,
      );
      this.eventEmitter.emit(EventSyncTransactionEnum.SyncTransaction, event);
    } catch (error) {
      console.log(error);
      this.logger.error(
        'SYNC TRANSACTION ITEM STOCK ERROR: ' +
          JSON.stringify(error?.message || error),
      );
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async updateStockFromTicketRequest(
    dataUpdate: UpdateStockFromTicketRequestDto,
  ): Promise<any> {
    const { movementIds, orderType, itemStockWarehousePrices } = dataUpdate;
    const movementDataRaw = await this.movementRepository.findAllByCondition({
      id: In(movementIds),
    });
    const itemsStockMovementData = plainToInstance(
      MovementResponseDto,
      movementDataRaw,
      {
        excludeExtraneousValues: true,
      },
    );
    const characterPrefix = '_';
    const groupItemStockByItemWarehouse = groupBy(
      movementDataRaw,
      (itemStock) =>
        [itemStock.itemId, itemStock.warehouseId].join(characterPrefix),
    );
    const conditionQueryItemStockExist = Object.keys(
      groupItemStockByItemWarehouse,
    ).map((keyItemStock) => {
      const [itemId, warehouseId] = keyItemStock.split(characterPrefix);
      return new ItemWarehouseFilter(+itemId, +warehouseId);
    });
    const dataItemsWarehouseExist =
      await this.itemWarehouseRepository.getItemStockExist(
        conditionQueryItemStockExist,
      );
    let itemWarehouseEntities: ItemWarehouseEntity[] = [];
    let itemStockWarehouseLocatorEntities: ItemStockWarehouseLocatorEntity[] =
      [];
    const itemPlanningEntities: ItemPlanningQuantityEntity[] = [];
    let itemStockWarehouseLocatorHistoryEntities: ItemStockWarehouseLocatorHistoryEntity[] =
      [];
    switch (orderType) {
      case OrderTypeEnum.Import:
        itemWarehouseEntities = this.createItemWarehouseEntitiesByTicketImport(
          itemsStockMovementData,
          dataItemsWarehouseExist,
        );
        [
          itemStockWarehouseLocatorEntities,
          itemStockWarehouseLocatorHistoryEntities,
        ] = this.createItemStockWarehouseLocatorEntitiesByTicketImport(
          itemsStockMovementData,
        );
        break;

      case OrderTypeEnum.Transfer:
        itemWarehouseEntities = this.createItemWarehouseEntitiesByTicketImport(
          itemsStockMovementData,
          dataItemsWarehouseExist,
        );
        [
          itemStockWarehouseLocatorEntities,
          itemStockWarehouseLocatorHistoryEntities,
        ] = this.createItemStockWarehouseLocatorEntitiesByTicketImport(
          itemsStockMovementData,
        );
        break;

      default:
        break;
    }
    const itemMovementExist = await this.movementRepository.findAllByCondition({
      id: In(map(movementDataRaw, 'id')),
    });
    const timestamp = new Date();
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      //TODO làm sau
      let itemStockWarehousePrice;
      let dataItemStockWarehousePrice = [];
      if (!isEmpty(itemStockWarehousePrices)) {
        itemStockWarehousePrice = [OrderTypeEnum.Import].includes(
          dataUpdate.orderType,
        )
          ? await this.createItemStockWarehousePrice({
              items: itemStockWarehousePrices,
            })
          : await this.updateItemStockWarehousePrice({
              items: itemStockWarehousePrices,
            });
        dataItemStockWarehousePrice = itemStockWarehousePrice?.data;
      }
      if (
        !isEmpty(itemStockWarehousePrice) &&
        itemStockWarehousePrice?.statusCode !== ResponseCodeEnum.SUCCESS
      ) {
        throw itemStockWarehousePrice.message;
      } else if (!isEmpty(dataUpdate.conditions)) {
        dataItemStockWarehousePrice =
          await this.itemStockWarehousePriceRepository.findAllByCondition(
            dataUpdate.conditions,
          );
      }
      const itemMap = {};
      dataItemStockWarehousePrice?.forEach((item) => {
        if (!itemMap[item.itemId]) {
          itemMap[item.itemId] = { ...item, quantity: 0, totalAmount: 0 };
        }
        itemMap[item.itemId].quantity += +item.quantity;
        itemMap[item.itemId].totalAmount += +item.totalAmount;
      });
      itemMovementExist.forEach((item) => {
        const amount = div(
          itemMap[item.itemId]?.totalAmount || 0,
          +itemMap[item.itemId]?.quantity || 1,
        );
        // item.amount = amount;
        // item.confirmedAt = timestamp;
      });
      await queryRunner.manager.save(
        ItemWarehouseEntity,
        itemWarehouseEntities,
      );
      const dataItemStockWarehouseLocators = await queryRunner.manager.save(
        ItemStockWarehouseLocatorEntity,
        itemStockWarehouseLocatorEntities,
      );
      if (!isEmpty(itemPlanningEntities)) {
        await queryRunner.manager.save(
          ItemPlanningQuantityEntity,
          itemPlanningEntities,
        );
      }
      if ([OrderTypeEnum.Import].includes(dataUpdate.orderType)) {
        itemStockWarehouseLocatorHistoryEntities.forEach(
          (itemStockHistory, index) => {
            const itemStock = dataItemStockWarehouseLocators[index];
            if (!isEmpty(itemStock)) {
              itemStockHistory.itemStockWarehouseLocatorId = itemStock.id;
              // itemStockHistory.purpose = dataUpdate.purpose;
            }
          },
        );
        itemStockWarehouseLocatorHistoryEntities =
          itemStockWarehouseLocatorHistoryEntities.filter(
            (itemStockHistory) => itemStockHistory.itemStockWarehouseLocatorId,
          );
      }

      if (!isEmpty(itemStockWarehouseLocatorHistoryEntities)) {
        itemStockWarehouseLocatorHistoryEntities =
          await queryRunner.manager.save(
            ItemStockWarehouseLocatorHistoryEntity,
            itemStockWarehouseLocatorHistoryEntities,
          );
      }
      if (!isEmpty(itemStockWarehousePrice?.data)) {
        await queryRunner.manager.save(
          ItemStockWarehousePriceEntity,
          itemStockWarehousePrice?.data,
        );
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      this.logger.error(
        'UPDATE ITEM STOCK ERROR: ' + JSON.stringify(error?.message || error),
      );
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async createItemSwiftLocatorTicket(
    request: CreateItemPutAwayTicketRequestDto,
  ): Promise<any> {
    const { orderType, movementIds, items } = request;
    const characterSeparator = '_';
    const movementDataRaw = await this.movementRepository.findAllByCondition({
      id: In(movementIds),
    });
    const itemsStockMovementData = plainToInstance(
      MovementResponseDto,
      movementDataRaw,
      {
        excludeExtraneousValues: true,
      },
    );
    const itemStockWarehouseLocatorEntities: ItemStockWarehouseLocatorEntity[] =
      [];
    const itemStockWarehouseLocatorHistoryEntities: ItemStockWarehouseLocatorHistoryEntity[] =
      [];

    let locators = [];
    const warehouseIds = uniq(map(itemsStockMovementData, 'warehouseId'));
    if (!isEmpty(warehouseIds)) {
      locators = await this.warehouseLayoutService.getLocatorsByRootIds(
        warehouseIds,
        1,
      );
    }
    //gen

    const itemIds = uniq(map(itemsStockMovementData, 'itemId'));
    const lotNumbers = uniq(map(itemsStockMovementData, 'lotNumber'));
    const ticketPutAwayIds = map(itemsStockMovementData, 'ticketId');
    const loctorPutAwayIds = uniq(map(itemsStockMovementData, 'locatorId'));
    //root
    const ticketIds = map(items, 'ticketId');
    const rootLocatorIds = map(locators, 'id');

    const existedRootWarehouseItemStockLocators =
      await this.itemStockWarehouseLocatorRepository.getItemStockWarehouseLocators(
        {
          itemIds,
          ticketIds,
          lotNumbers,
          ticketLocatorIds: rootLocatorIds,
        } as GetListItemStockWarehouseLocatorByCondition,
      );
    const existedItemPutAways =
      await this.itemStockWarehouseLocatorRepository.getItemStockWarehouseLocators(
        {
          itemIds,
          ticketIds: ticketPutAwayIds,
          lotNumbers,
          ticketLocatorIds: loctorPutAwayIds,
        } as GetListItemStockWarehouseLocatorByCondition,
      );
    const groupItemLocatorSameWarehouses = groupBy(items, (item) =>
      [
        item.itemId,
        item.warehouseId,
        item.lotNumber ? item.lotNumber : '',
        Moment(item.mfg).format('DD/MM/YYYY'),
        item.locatorId,
        item.ticketId,
      ].join(characterSeparator),
    );
    const groupItemLocators = groupBy(itemsStockMovementData, (item) =>
      [
        item.itemId,
        item.warehouseId,
        item.lotNumber ? item.lotNumber : '',
        Moment(item.mfg).format('DD/MM/YYYY'),
        item.locatorId,
        item.ticketId,
      ].join(characterSeparator),
    );

    const itemsMap = keyBy(itemsStockMovementData, (item) =>
      [
        item.itemId,
        item.warehouseId,
        item.lotNumber ? item.lotNumber : '',
        Moment(item.mfg).format('DD/MM/YYYY'),
        item.locatorId,
        item.ticketId,
      ].join(characterSeparator),
    );
    const toUpdateRootWarehouseLocator = [];
    const toUpdatePutAwayWarehouseLocator = [];
    if (!isEmpty(existedRootWarehouseItemStockLocators)) {
      const rootWarehouses = existedRootWarehouseItemStockLocators?.data;
      for (let i = 0; i < rootWarehouses.length; i++) {
        const rootWarehouseLocator = rootWarehouses[i];
        for (let j = 0; j < rootWarehouseLocator.histories.length; j++) {
          const rootHistory = rootWarehouseLocator.histories[j];
          const {
            itemId,
            warehouseId,
            lotNumber,
            mfg,
            ticketLocatorId,
            quantityStored,
          } = rootWarehouseLocator;
          const { ticketId } = rootHistory;
          const key = [
            itemId,
            warehouseId,
            lotNumber ? lotNumber : '',
            Moment(mfg).format('DD/MM/YYYY'),
            ticketLocatorId,
            ticketId,
          ].join(characterSeparator);
          if (has(groupItemLocatorSameWarehouses, key)) {
            const quantityStoredSum = sumBy(
              groupItemLocatorSameWarehouses[key],
              (item) => +item.quantityStored,
            );
            toUpdateRootWarehouseLocator.push({
              ...rootWarehouseLocator,
              quantity: minus(rootWarehouseLocator.quantity, quantityStoredSum),
              histories: {
                ...rootHistory,
                quantity: minus(
                  rootWarehouseLocator.quantity,
                  quantityStoredSum,
                ),
              },
            });
          }
        }
      }
    }

    if (!isEmpty(existedItemPutAways)) {
      const putAwayItems = existedItemPutAways?.data;
      for (let i = 0; i < putAwayItems.length; i++) {
        const putAwayItem = putAwayItems[i];
        for (let j = 0; j < putAwayItem.histories.length; j++) {
          const putAwayItemHistory = putAwayItem.histories[j];
          const { itemId, warehouseId, lotNumber, mfg, ticketLocatorId } =
            putAwayItem;
          const { ticketId } = putAwayItemHistory;
          const key = [
            itemId,
            warehouseId,
            lotNumber ? lotNumber : '',
            Moment(mfg).format('DD/MM/YYYY'),
            ticketLocatorId,
            ticketId,
          ].join(characterSeparator);
          if (!isEmpty(existedItemPutAways)) {
            if (has(groupItemLocators, key)) {
              const sumItemPutAway = sumBy(
                groupItemLocators[key],
                (item) => +item.storedQuantity,
              );
              toUpdatePutAwayWarehouseLocator.push({
                ...putAwayItem,
                quantity: plus(putAwayItem.quantity, sumItemPutAway),
              });
              const itemStockWarehouseLocatorHistoryEntity =
                this.itemStockWarehouseLocatorHistoryRepository.createEntityLocatorWarehouse(
                  {
                    itemMovementId: itemsMap[key]?.id,
                    quantity: itemsMap[key]?.storedQuantity,
                    orderId: null,
                    ticketId,
                    orderType: OrderTypeEnum.Import,
                    itemStockWarehouseLocatorId: putAwayItem.id,
                    purpose: '',
                  } as any,
                );
              itemStockWarehouseLocatorHistoryEntities.push(
                itemStockWarehouseLocatorHistoryEntity,
              );
            }
          }
        }
      }
    }
    let itemStockWarehouseLocator: ItemStockWarehouseLocatorEntity[] = [];
    const itemIdsExist = flatMap(
      existedItemPutAways?.data.map((item) =>
        item.histories.map((history) =>
          [
            item.itemId,
            item.warehouseId,
            item.lotNumber ? item.lotNumber : '',
            Moment(item.mfg).format('DD/MM/YYYY'),
            item.ticketLocatorId,
            history.ticketId,
          ].join(characterSeparator),
        ),
      ),
    );
    itemStockWarehouseLocator = itemsStockMovementData
      .filter((e) => {
        return !itemIdsExist.includes(
          [
            e.itemId,
            e.warehouseId,
            e.lotNumber ? e.lotNumber : '',
            Moment(e.mfg).format('DD/MM/YYYY'),
            e.locatorId,
            e.ticketId,
          ].join(characterSeparator),
        );
      })
      .map((e) => {
        const newItemStockWarehouseLocator =
          this.itemStockWarehouseLocatorRepository.createEntity({
            itemId: e.itemId,
            locatorId: null,
            ticketLocatorId: e.locatorId || null,
            warehouseId: e.warehouseId,
            lotNumber: e.lotNumber || '',
            quantity: e.storedQuantity,
            mfg: e.mfg,
          } as any);
        itemStockWarehouseLocatorHistoryEntities.push(
          this.itemStockWarehouseLocatorHistoryRepository.createEntityLocatorWarehouse(
            {
              itemMovementId: e.id,
              quantity: e.storedQuantity,
              orderId: null,
              ticketId: e.ticketId,
              orderType: OrderTypeEnum.Import,
              itemStockWarehouseLocatorId: newItemStockWarehouseLocator.id,
              purpose: '',
            } as any,
          ),
        );
        itemStockWarehouseLocatorEntities.push(newItemStockWarehouseLocator);
        return newItemStockWarehouseLocator;
      });
    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const uniqPutAwayWarehouseLocator = new Set();
      const uniqueData = toUpdatePutAwayWarehouseLocator.filter((item) => {
        if (!uniqPutAwayWarehouseLocator.has(item.id)) {
          uniqPutAwayWarehouseLocator.add(item.id);
          return true;
        }
        return false;
      });
      const itemStockWarehouseLocators = [
        ...itemStockWarehouseLocator,
        ...toUpdateRootWarehouseLocator,
        ...uniqueData,
      ];
      const dataItemStockWarehouseLocators = await queryRunner.manager.save(
        ItemStockWarehouseLocatorEntity,
        itemStockWarehouseLocators,
      );
      if (!isEmpty(toUpdateRootWarehouseLocator)) {
        const updateRootHistories = compact(
          toUpdateRootWarehouseLocator.map((i) => i.histories),
        );
        await queryRunner.manager.save(
          ItemStockWarehouseLocatorHistoryEntity,
          updateRootHistories,
        );
      }
      if (isEmpty(toUpdatePutAwayWarehouseLocator)) {
        itemStockWarehouseLocatorHistoryEntities.forEach(
          (itemStockHistory, index) => {
            const itemStock = dataItemStockWarehouseLocators[index];
            if (!isEmpty(itemStock)) {
              itemStockHistory.itemStockWarehouseLocatorId = itemStock.id;
              // itemStockHistory.purpose = dataUpdate.purpose;
            }
          },
        );
      } else {
        const idSet = new Set(
          toUpdatePutAwayWarehouseLocator.map((item) => item.id),
        );
        itemStockWarehouseLocatorHistoryEntities.forEach((itemStockHistory) => {
          if (idSet.has(itemStockHistory.itemStockWarehouseLocatorId)) {
            const matchingItemStock = dataItemStockWarehouseLocators.find(
              (e) => e.id === itemStockHistory.itemStockWarehouseLocatorId,
            );

            if (matchingItemStock) {
              itemStockHistory.itemStockWarehouseLocatorId =
                matchingItemStock.id;
            }
          }
        });
      }
      await queryRunner.manager.save(
        ItemStockWarehouseLocatorHistoryEntity,
        itemStockWarehouseLocatorHistoryEntities,
      );
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      this.logger.error(
        'UPDATE ITEM STOCK ERROR: ' + JSON.stringify(error?.message || error),
      );
      return new ResponseBuilder(itemsStockMovementData)
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private async updateItemPlanningAfterExport(
    itemsStockMovements,
    orderId,
    orderType,
  ): Promise<any> {
    const itemStocks = [];
    itemsStockMovements.forEach((itemStock) => {
      itemStock.histories.forEach((history) => {
        itemStocks.push({
          ...history,
          warehouseId: itemStock.warehouseId,
          movementOrderWarehouseDetail:
            itemStock.movementOrderWarehouseDetailId,
        });
      });
    });
    const itemPlanningEntities = orderBy(
      await this.itemPlanningQuantityRepository.findAllByCondition({
        orderId: orderId,
        orderType: orderType,
      }),
      'locatorId',
    );
    itemPlanningEntities.forEach(
      (itemPlanningEntity: ItemPlanningQuantityEntity) => {
        let itemStockHistories = itemStocks.filter(
          (itemStock) =>
            itemStock.itemId === itemPlanningEntity.itemId &&
            itemStock.warehouseId === itemPlanningEntity.warehouseId &&
            orderId === itemPlanningEntity.orderId &&
            orderType === itemPlanningEntity.orderType &&
            (itemStock?.lotNumber?.toUpperCase() || null) ===
              (itemPlanningEntity?.lotNumber?.toUpperCase() || null),
        );
        if (itemPlanningEntity.locatorId) {
          itemStockHistories = itemStockHistories.filter(
            (itemStock) => itemStock.locatorId === itemPlanningEntity.locatorId,
          );
        }
        const quantityExport = itemStockHistories.reduce(
          (prev, curr) => plus(prev, curr.quantity),
          0,
        );
        itemPlanningEntity.quantity = plus(
          quantityExport,
          itemPlanningEntity.quantity,
        );
      },
    );
    return itemPlanningEntities;
  }

  // Kiểm tra xem có đủ số lượng xuất kho không. Điều kiện đáp ứng item xuất + item plan <= item tồn kho
  private validateItemExportWarehouse(
    itemStockWarehouses: ItemStockWarehouseLocatorEntity[],
    itemExportWarehouses: ItemExportWarehouseLocatorRequestDto[],
    itemPlanningQuantites?: ItemPlanningQuantityEntity[],
  ): boolean {
    const conditionByItemWarehouseLot = ['itemId', 'warehouseId', 'lotNumber'];
    const validQuantityItemWarehouseLot = this.validateItemExportByCondition(
      conditionByItemWarehouseLot,
      itemStockWarehouses,
      itemExportWarehouses,
      itemPlanningQuantites,
    );
    if (!validQuantityItemWarehouseLot) return false;
    const conditionByItemWarehouseLocator = [
      'itemId',
      'warehouseId',
      'lotNumber',
      'locatorId',
    ];
    const validQuantityItemWarehouseLocator =
      this.validateItemExportByCondition(
        conditionByItemWarehouseLocator,
        itemStockWarehouses,
        itemExportWarehouses,
        itemPlanningQuantites,
      );
    return validQuantityItemWarehouseLocator;
  }

  // Kiểm tra số lượng xuất theo cặp điều kiện
  private validateItemExportByCondition(
    keyConditions: string[], // cặp key cần so sánh số lượng
    itemStockWarehouses: ItemStockWarehouseLocatorEntity[],
    itemExportWarehouses: ItemExportWarehouseLocatorRequestDto[],
    itemPlanningQuantites: ItemPlanningQuantityEntity[],
  ): boolean {
    itemPlanningQuantites.forEach((itemPlan) => {
      itemPlan['remainingQuantity'] = minus(
        itemPlan.planQuantity,
        itemPlan.quantity,
      );
    });
    const characterPrefix = '_';
    const groupByItemExportByItemWarehouse = groupBy(
      itemExportWarehouses,
      (itemExport) =>
        keyConditions.map((key) => itemExport[key]).join(characterPrefix),
    );
    const groupByItemPlanningByItemWarehouse = groupBy(
      itemPlanningQuantites,
      (itemPlan) =>
        keyConditions.map((key) => itemPlan[key]).join(characterPrefix),
    );
    const groupByItemStockByItemWarehouse = groupBy(
      itemStockWarehouses,
      (itemStock) =>
        keyConditions.map((key) => itemStock[key]).join(characterPrefix),
    );
    const invalidQuantityItemWarehouse = Object.keys(
      groupByItemExportByItemWarehouse,
    ).some((keyItemWarehouse) => {
      // Nếu ko có tồn kho thì invalid
      if (!has(groupByItemStockByItemWarehouse, keyItemWarehouse)) {
        return true;
      }
      const itemStockByItemWarehouse =
        groupByItemStockByItemWarehouse[keyItemWarehouse];
      let quantityItemExport = sumBy(
        groupByItemExportByItemWarehouse[keyItemWarehouse],
        'quantity',
      );
      let itemPlanningByItemWarehouse = [];
      // Nếu cặp điền kiện có lên plan thì cộng thêm số lượng plan còn lại vào số lượng xuất
      if (has(groupByItemPlanningByItemWarehouse, keyItemWarehouse)) {
        itemPlanningByItemWarehouse =
          groupByItemPlanningByItemWarehouse[keyItemWarehouse];
        quantityItemExport = plus(
          quantityItemExport,
          sumBy(itemPlanningByItemWarehouse, 'remainingQuantity'),
        );
      }
      return quantityItemExport > itemStockByItemWarehouse.quantity;
    });
    return !invalidQuantityItemWarehouse;
  }

  private createItemStockWarehouseLocatorEntitiesByImport(
    itemsStockMovementData: ItemStockMovementResponse[],
  ): [
    ItemStockWarehouseLocatorEntity[],
    ItemStockWarehouseLocatorHistoryEntity[],
  ] {
    const itemStockWarehouseLocatorEntities: ItemStockWarehouseLocatorEntity[] =
      [];
    const itemStockWarehouseLocatorHistoryEntities: ItemStockWarehouseLocatorHistoryEntity[] =
      [];

    for (let i = 0; i < itemsStockMovementData.length; i++) {
      const itemStock = itemsStockMovementData[i];
      for (let j = 0; j < itemStock.histories.length; j++) {
        const history = itemStock.histories[j];
        const itemStockWarehouseLocatorEntity =
          this.itemStockWarehouseLocatorRepository.createEntity({
            itemId: history.itemId,
            locatorId: history?.locatorId || null,
            warehouseId: itemStock.warehouseId,
            lotNumber: history?.lotNumber || null,
            quantity: history.quantity,
            mfg: history.mfg,
            storageDate: itemStock.storageDate,
          } as CreateItemStockWarehouseLocatorRequestDto);
        itemStockWarehouseLocatorEntities.push(itemStockWarehouseLocatorEntity);
        itemStockWarehouseLocatorHistoryEntities.push(
          this.itemStockWarehouseLocatorHistoryRepository.createEntity(
            new CreateItemStockWarehouseLocatorHistoryRequestDto(
              history.id,
              history.quantity,
              itemStock?.orderType,
              itemStock?.orderId,
            ),
          ),
        );
      }
    }
    return [
      itemStockWarehouseLocatorEntities,
      itemStockWarehouseLocatorHistoryEntities,
    ];
  }

  private createItemStockWarehouseLocatorEntitiesByTicketImport(
    itemsStockMovementData: MovementResponseDto[],
  ): [
    ItemStockWarehouseLocatorEntity[],
    ItemStockWarehouseLocatorHistoryEntity[],
  ] {
    const itemStockWarehouseLocatorEntities: ItemStockWarehouseLocatorEntity[] =
      [];
    const itemStockWarehouseLocatorHistoryEntities: ItemStockWarehouseLocatorHistoryEntity[] =
      [];
    for (let i = 0; i < itemsStockMovementData.length; i++) {
      const itemStock = itemsStockMovementData[i];
      const itemStockWarehouseLocatorEntity =
        this.itemStockWarehouseLocatorRepository.createEntity({
          itemId: itemStock.itemId,
          locatorId: itemStock.warehouseLocatorId || null,
          ticketLocatorId: itemStock?.locatorId,
          warehouseId: itemStock.warehouseId,
          lotNumber: itemStock?.lotNumber || null,
          quantity: itemStock.quantity,
          mfg: itemStock.mfg ? itemStock.mfg : null,
          storageDate: itemStock.importDate,
        } as any);
      itemStockWarehouseLocatorEntities.push(itemStockWarehouseLocatorEntity);
      itemStockWarehouseLocatorHistoryEntities.push(
        this.itemStockWarehouseLocatorHistoryRepository.createEntityLocatorWarehouse(
          new CreateItemStockWarehouseLocatorHistoryTicketRequestDto(
            itemStock.id,
            itemStock.quantity,
            itemStock.ticketId,
            itemStock.type,
          ) as any,
        ),
      );
    }
    return [
      itemStockWarehouseLocatorEntities,
      itemStockWarehouseLocatorHistoryEntities,
    ];
  }

  private async createItemStockWarehouseLocatorEntitiesByExport(
    itemsStockMovementSource: ItemStockMovementResponse[],
  ): Promise<ItemStockWarehouseLocatorEntity[]> {
    const itemsStockMovements = cloneDeep(itemsStockMovementSource);
    const conditionFilterPositionItems = [];
    itemsStockMovements.forEach((itemStock) => {
      itemStock.histories.forEach((history) => {
        const condition = {
          itemId: history.itemId,
          warehouseId: history.warehouseId,
        } as any;
        condition.lotNumber = history.lotNumber
          ? ILike(history.lotNumber)
          : IsNull();
        condition.locatorId = history.locatorId;
        condition.quantity = Not(0);
        conditionFilterPositionItems.push(condition);
      });
    });
    const positionItems =
      await this.itemStockWarehouseLocatorRepository.findWithRelations(
        conditionFilterPositionItems,
      );
    const keyConditions = ['itemId', 'warehouseId', 'locatorId', 'lotNumber'];
    const characterPrefix = '_';
    const groupPositionByKeys = groupBy(positionItems, (positionItem) =>
      keyConditions
        .map((keyCondition) => positionItem[keyCondition] || '')
        .join(characterPrefix),
    );
    const toUpdateItems = {};
    itemsStockMovements.forEach((itemStock) => {
      itemStock.histories.forEach((itemStockHistory) => {
        itemStockHistory['warehouseId'] = itemStock.warehouseId;
        const key = keyConditions
          .map((keyCondition) => itemStockHistory[keyCondition] || '')
          .join(characterPrefix);
        const items: ItemStockWarehouseLocatorEntity[] =
          groupPositionByKeys[key];

        if (!isEmpty(items)) {
          items.forEach((item: ItemStockWarehouseLocatorEntity | any) => {
            if (!has(item, 'remainQuantity')) {
              item['remainQuantity'] = item.quantity;
            }
            if (itemStockHistory.quantity > 0) {
              const minQuantity = min([
                itemStockHistory.quantity,
                item['remainQuantity'],
              ]);
              itemStockHistory.quantity = minus(
                itemStockHistory.quantity,
                minQuantity,
              );
              item['remainQuantity'] = minus(item.remainQuantity, minQuantity);
            }
          });
          groupPositionByKeys[key] = items;
          toUpdateItems[key] = items;
        }
      });
    });
    return flatMap(values(toUpdateItems))
      .filter((item) => has(item, 'remainQuantity'))
      .map((item) => {
        const itemExport = {
          ...item,
          quantity: item.remainQuantity,
        };
        delete itemExport.remainQuantity;
        return itemExport;
      });
  }

  private createItemWarehouseEntitiesByExport(
    itemsStockMovementData: ItemStockMovementResponse[],
    dataItemsWarehouseExist: ItemWarehouseEntity[],
  ): ItemWarehouseEntity[] {
    const characterPrefix = '_';
    const groupItemStockByItemWarehouse = groupBy(
      itemsStockMovementData,
      (itemStock) =>
        [itemStock.itemId, itemStock.warehouseId].join(characterPrefix),
    );
    dataItemsWarehouseExist = dataItemsWarehouseExist.map((itemWarehouse) => {
      const keyItemStock = [
        itemWarehouse.itemId,
        itemWarehouse.warehouseId,
      ].join(characterPrefix);
      if (has(groupItemStockByItemWarehouse, keyItemStock)) {
        itemWarehouse.itemQuantity = minus(
          itemWarehouse.itemQuantity,
          groupItemStockByItemWarehouse[keyItemStock].reduce(
            (quantity, prev) => plus(quantity, prev.quantity),
            0,
          ),
        );
      }
      return itemWarehouse;
    });
    return dataItemsWarehouseExist;
  }

  private createItemWarehouseEntitiesByImport(
    itemsStockMovements: ItemStockMovementResponse[],
    dataItemsWarehouseExist: ItemWarehouseEntity[],
  ): ItemWarehouseEntity[] {
    const characterPrefix = '_';
    const groupItemStockByItemWarehouse = groupBy(
      itemsStockMovements,
      (itemStock) =>
        [itemStock.itemId, itemStock.warehouseId].join(characterPrefix),
    );
    let newItemsWarehouse: ItemWarehouseEntity[] = [];
    dataItemsWarehouseExist = dataItemsWarehouseExist.map((itemWarehouse) => {
      const keyItemStock = [
        itemWarehouse.itemId,
        itemWarehouse.warehouseId,
      ].join(characterPrefix);
      if (has(groupItemStockByItemWarehouse, keyItemStock)) {
        itemWarehouse.itemQuantity = plus(
          itemWarehouse.itemQuantity,
          sumBy(groupItemStockByItemWarehouse[keyItemStock], 'quantity'),
        );
      }
      return itemWarehouse;
    });
    const itemIdsExist = dataItemsWarehouseExist.map((e) =>
      [e.itemId, e.warehouseId].join(characterPrefix),
    );
    newItemsWarehouse = itemsStockMovements
      .filter(
        (e) =>
          !itemIdsExist.includes(
            [e.itemId, e.warehouseId].join(characterPrefix),
          ),
      )
      .map((e) => {
        const newItemWarehouse = new ItemWarehouseEntity();
        newItemWarehouse.itemId = e.itemId;
        newItemWarehouse.warehouseId = e.warehouseId;
        newItemWarehouse.itemQuantity = e.quantity;
        return newItemWarehouse;
      });
    return [...dataItemsWarehouseExist, ...newItemsWarehouse];
  }

  private createItemWarehouseEntitiesByTicketImport(
    itemMovements: MovementResponseDto[],
    dataItemsWarehouseExist: ItemWarehouseEntity[],
  ): ItemWarehouseEntity[] {
    const characterPrefix = '_';
    const groupItemStockByItemWarehouse = groupBy(itemMovements, (itemStock) =>
      [itemStock.itemId, itemStock.warehouseId].join(characterPrefix),
    );
    let newItemsWarehouse: ItemWarehouseEntity[] = [];

    dataItemsWarehouseExist = dataItemsWarehouseExist.map((itemWarehouse) => {
      const keyItemStock = [
        itemWarehouse.itemId,
        itemWarehouse.warehouseId,
      ].join(characterPrefix);
      if (has(groupItemStockByItemWarehouse, keyItemStock)) {
        //Tính tổng sl thực nhập
        itemWarehouse.itemQuantity = plus(
          itemWarehouse.itemQuantity,
          sumBy(
            groupItemStockByItemWarehouse[keyItemStock],
            (item) => +item.quantity,
          ),
        );
        itemWarehouse.storedQuantity = plus(
          itemWarehouse.storedQuantity,
          sumBy(
            groupItemStockByItemWarehouse[keyItemStock],
            (item) => +item.storedQuantity,
          ),
        );
      }
      return itemWarehouse;
    });
    const itemIdsExisted = dataItemsWarehouseExist.map((e) =>
      [e.itemId, e.warehouseId].join(characterPrefix),
    );

    newItemsWarehouse = itemMovements
      .filter(
        (e) =>
          !itemIdsExisted.includes(
            [e.itemId, e.warehouseId].join(characterPrefix),
          ),
      )
      .map((e) => {
        const newItemWarehouse = new ItemWarehouseEntity();
        newItemWarehouse.itemId = e.itemId;
        newItemWarehouse.warehouseId = e.warehouseId;
        newItemWarehouse.itemQuantity = e.quantity;
        newItemWarehouse.storedQuantity = e.storedQuantity;
        newItemWarehouse.exportedQuantity = e.exportedQuantity;
        return newItemWarehouse;
      });
    return [...dataItemsWarehouseExist, ...newItemsWarehouse];
  }

  /**
   * getItemWarehouseByItemIds
   * @param request
   * @returns
   */
  public async getItemWarehouseByItemIds(
    request: GetItemWarehouseByItemIdsRequestDto,
  ): Promise<any> {
    const itemWarehouses =
      await this.itemWarehouseRepository.findAllByCondition({
        itemId: In(request.itemIds),
        warehouseId: request.warehouseId,
      });
    if (isEmpty(itemWarehouses)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ITEM_NOT_FOUND'))
        .build();
    }
    const response = plainToInstance(ItemWarehouseResponseDto, itemWarehouses, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  /**
   * getItemWarehouseByMultipleItemAndWarehouse
   * @param request
   * @returns
   */
  public async getItemWarehouseByMultipleItemAndWarehouse(
    request: GetItemWarehouseByMultipleItemAndWarehouseRequestDto,
  ): Promise<any> {
    const { itemIds, warehouseIds } = request;
    const condition: any = {};
    if (!isEmpty(itemIds)) {
      condition.itemId = In(itemIds);
    }
    if (!isEmpty(warehouseIds)) {
      condition.warehouseId = In(warehouseIds);
    }
    if (isEmpty(condition)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.ITEM_IDS_OR_WAREHOUSE_IDS_MUST_BE_PROVIDED',
          ),
        )
        .build();
    }

    const itemWarehouses =
      await this.itemWarehouseRepository.findAllByCondition(condition);
    if (
      isEmpty(itemWarehouses) ||
      itemIds.length * warehouseIds.length > itemWarehouses.length
    ) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(await this.i18n.translate('error.ITEM_NOT_FOUND'))
        .build();
    }
    const response = plainToInstance(ItemWarehouseResponseDto, itemWarehouses, {
      excludeExtraneousValues: true,
    });
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('success.SUCCESS'))
      .build();
  }

  public async getItemStockAvailable(
    request: GetItemStockAvailableRequestDto,
  ): Promise<any> {
    const { order, items } = request;
    let storageDate = false;
    const conditionFilterItemStock = items.map((item) => {
      const condition = {} as any;
      if (item.lotNumber) {
        condition.lotNumber = item?.lotNumber?.toUpperCase() || IsNull();
      }
      if (item.warehouseId) {
        condition.warehouseId = item.warehouseId;
      }
      if (item.itemId) {
        condition.itemId = item.itemId;
      }
      if (item.storageDate) {
        storageDate = true;
        condition.storageDate = item.storageDate;
      }
      return condition;
    });
    const itemStockMap = {};
    if (storageDate) {
      const itemStocks =
        await this.itemStockWarehouseLocatorRepository.findAllByCondition(
          conditionFilterItemStock,
        );
      itemStocks.forEach((item) => {
        const key = `${item.itemId}_${item.lotNumber || ''}_${item.locatorId}`;
        itemStockMap[key] = has(itemStockMap, key)
          ? plus(itemStockMap[key], item.quantity || 0)
          : item.quantity || 0;
      });
    }

    conditionFilterItemStock.forEach((condition) => {
      delete condition.storageDate;
    });

    const itemStocks =
      await this.itemStockWarehouseLocatorRepository.getTotalQuantityItemStockByCondition(
        conditionFilterItemStock,
      );

    const conditionFilterItemPlanning = items.map((item) => ({
      itemId: item.itemId,
      warehouseId: item.warehouseId,
      lotNumber: item?.lotNumber?.toUpperCase() || IsNull(),
    })) as FilterItemByCondition[];
    const itemPlanning =
      await this.itemPlanningQuantityRepository.getTotalQuantityItemPlanningByCondition(
        conditionFilterItemPlanning,
        order,
      );
    const response = this.calculateItemStockAvailable(
      items,
      itemStocks,
      itemPlanning,
    );

    response.forEach((e) => {
      if (!isEmpty(e.itemAvailables)) {
        e.itemAvailables.forEach((item) => {
          const key = `${item.itemId}_${item.lotNumber || ''}_${
            item.locatorId
          }`;
          if (has(itemStockMap, key)) {
            const quantity = itemStockMap[key] || 0;
            item.quantity =
              item.quantity > +quantity ? quantity : item.quantity;
          }
        });
      }
    });

    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getItemAllStockAvailable(
    request: GetItemAllStockAvailableRequestDto,
  ): Promise<any> {
    const { order, items } = request;
    const conditionFilterItemStock = items.map((item) => {
      const condition = {} as any;
      if (item.itemId) {
        condition.itemId = item.itemId;
      }
      return condition;
    });
    const itemStocks =
      await this.itemStockWarehouseLocatorRepository.getTotalQuantityAllItemStockByCondition(
        conditionFilterItemStock,
      );
    const conditionFilterItemPlanning = items.map((item) => ({
      itemId: item.itemId,
    })) as FilterItemAllWarehouseByCondition[];
    const itemPlanning =
      await this.itemPlanningQuantityRepository.getTotalQuantityAllItemPlanningByCondition(
        conditionFilterItemPlanning,
        order,
      );
    const response = await this.calculateItemStockAvailableAllWarehouse(
      items,
      itemStocks,
      itemPlanning,
    );
    const locatorIds = map(flatMap(response, 'itemAvailables'), 'locatorId');
    const warehouseIds = map(
      flatMap(response, 'itemAvailables'),
      'warehouseId',
    );
    const itemIds = map(response, 'itemId');
    let locators = [];
    let warehouses = [];
    let itemList = [];
    if (!isEmpty(locatorIds) || !isEmpty(warehouseIds) || !isEmpty(itemIds)) {
      [locators, warehouses, itemList] = await Promise.all([
        this.warehouseLayoutService.getLocatorByIds(locatorIds, true),
        this.warehouseService.getListByIDs(warehouseIds, true),
        this.itemRepository.findAllByCondition({
          id: In(itemIds),
        }),
      ]);
    }
    const serializeItem = keyBy(itemList, 'id');
    response.forEach((item) => {
      item.item = serializeItem[item.itemId];
      item['itemAvailables'].forEach((itemAvailable) => {
        itemAvailable.locator = locators[itemAvailable.locatorId];
        itemAvailable.warehouse = warehouses[itemAvailable.warehouseId];
      });
    });
    const dataReturn = plainToInstance(
      ItemStockAvailableResponseDto,
      response,
      {
        excludeExtraneousValues: true,
      },
    );
    return new ResponseBuilder(dataReturn)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  private calculateItemStockAvailable(
    items: FilterItemByCondition[],
    itemStocks: ItemStockWarehouseLocatorEntity[],
    itemPlans: ItemPlanningQuantityEntity[],
  ): ItemStockAvailableResponseDto[] {
    const attributes = ['itemId', 'warehouseId', 'lotNumber'];
    const attributeLocator = [
      'itemId',
      'warehouseId',
      'lotNumber',
      'locatorId',
    ];
    const joinCharacter = '_';
    const serializeItemStock = keyBy(itemStocks, (itemStock) =>
      attributeLocator
        .map((attribute) => itemStock[attribute] || '')
        .join(joinCharacter),
    );
    const locatorIdsByAttribute = {};
    items.forEach((item) => {
      const key = attributes
        .map((attribute) => item[attribute])
        .join(joinCharacter);
      if (!isEmpty(item?.locatorIds)) {
        locatorIdsByAttribute[key] = item?.locatorIds;
      }
    });
    const itemPlanningByLocator = [];
    const itemPlanningNotLocator = [];
    const itemPlanningStillKeep = [];
    itemPlans.forEach((itemPlan) => {
      if (itemPlan.locatorId) {
        itemPlanningByLocator.push(itemPlan);
      } else {
        itemPlanningNotLocator.push(itemPlan);
      }
    });
    loopItemPlanningByLocator: for (
      let indexItemPlanning = 0;
      indexItemPlanning < itemPlanningByLocator.length;
      indexItemPlanning++
    ) {
      const itemPlanning = itemPlanningByLocator[indexItemPlanning];
      const keyItemStock = attributeLocator
        .map((attribute) => itemPlanning[attribute] || '')
        .join(joinCharacter);
      if (!has(serializeItemStock, keyItemStock)) {
        itemPlanningStillKeep.push(itemPlanning);
        continue loopItemPlanningByLocator;
      }
      const itemStock = serializeItemStock[keyItemStock];
      const itemPlanQuantity = min([
        +itemStock.quantity,
        +itemPlanning.remainQuantity,
      ]);

      itemPlanning.remainQuantity = minus(
        itemPlanning.remainQuantity,
        itemPlanQuantity,
      );
      if (+itemPlanning.remainQuantity > 0) {
        itemPlanningStillKeep.push(itemPlanning);
      }
      itemStock.quantity = minus(itemStock.quantity, itemPlanQuantity);
      serializeItemStock[keyItemStock] = itemStock;
    }
    const itemPlanningStillKeepMap = keyBy(itemPlanningStillKeep, (item) =>
      attributes.map((attribute) => item[attribute] || '').join(joinCharacter),
    );

    const groupItemStockByAttribute = groupBy(
      values(serializeItemStock).filter((itemStock) => itemStock.quantity > 0),
      (itemStock) =>
        attributes
          .map((attribute) => itemStock[attribute] || '')
          .join(joinCharacter),
    );

    const serializeItemPlanNotLocator = keyBy(
      itemPlanningNotLocator,
      (itemPlan) =>
        attributes
          .map((attribute) => itemPlan[attribute] || '')
          .join(joinCharacter),
    );

    items.forEach((item) => {
      const keyItem = attributes
        .map((attribute) => item[attribute] || '')
        .join(joinCharacter);
      let itemStockByAttribute = has(groupItemStockByAttribute, keyItem)
        ? groupItemStockByAttribute[keyItem]
        : [];
      if (has(serializeItemPlanNotLocator, keyItem)) {
        const itemPlan = serializeItemPlanNotLocator[keyItem];
        if (!isEmpty(item?.locatorIds)) {
          itemStockByAttribute.forEach((itemStock) => {
            if (
              !item.locatorIds.includes(itemStock.locatorId) &&
              itemPlan.remainQuantity >= 0
            ) {
              const itemPlanQuantity = min([
                Number(itemPlan.remainQuantity),
                Number(itemStock.quantity),
              ]);
              itemStock.quantity = minus(itemStock.quantity, itemPlanQuantity);
              itemPlan.remainQuantity = minus(
                itemPlan.remainQuantity,
                itemPlanQuantity,
              );
            }
          });
        }
        itemStockByAttribute.forEach((itemStock) => {
          if (itemPlan.remainQuantity >= 0) {
            const itemPlanQuantity = min([
              Number(itemPlan.remainQuantity),
              Number(itemStock.quantity),
            ]);
            itemStock.quantity = minus(itemStock.quantity, itemPlanQuantity);
            itemPlan.remainQuantity = minus(
              itemPlan.remainQuantity,
              itemPlanQuantity,
            );
          }
        });
      }
      if (!isEmpty(item?.locatorIds)) {
        itemStockByAttribute = itemStockByAttribute.filter((itemStock) =>
          item.locatorIds.includes(itemStock.locatorId),
        );
      }
      itemStockByAttribute = itemStockByAttribute.map((i) => {
        const key = attributes
          .map((attribute) => i[attribute] || '')
          .join(joinCharacter);
        let quantity = i.quantity;
        if (itemPlanningStillKeepMap[key]) {
          quantity = minus(
            i.quantity,
            itemPlanningStillKeepMap[key].remainQuantity,
          );
        }
        return {
          ...i,
          quantity: quantity,
        };
      });
      item['quantity'] = itemStockByAttribute.reduce(
        (pre, curr) => plus(pre, curr.quantity),
        0,
      );
      item['itemAvailables'] = itemStockByAttribute.filter(
        (item) => item.quantity > 0,
      );
    });

    return plainToInstance(ItemStockAvailableResponseDto, items, {
      excludeExtraneousValues: true,
    });
  }

  async calculateItemStockAvailableAllWarehouse(
    items: FilterItemAllWarehouseByCondition[],
    itemStocks: ItemStockWarehouseLocatorEntity[],
    itemPlans: ItemPlanningQuantityEntity[],
  ): Promise<FilterItemAllWarehouseByCondition[] | any> {
    const attributes = ['itemId', 'lotNumber'];
    const attributeLocator = [
      'itemId',
      'warehouseId',
      'lotNumber',
      'locatorId',
    ];
    const joinCharacter = '_';
    const serializeItemStock = keyBy(itemStocks, (itemStock) =>
      attributeLocator
        .map((attribute) => itemStock[attribute] || '')
        .join(joinCharacter),
    );
    const itemPlanningByLocator = [];
    const itemPlanningNotLocator = [];
    itemPlans.forEach((itemPlan) => {
      if (itemPlan.locatorId) {
        itemPlanningByLocator.push(itemPlan);
      } else {
        itemPlanningNotLocator.push(itemPlan);
      }
    });
    loopItemPlanningByLocator: for (
      let indexItemPlanning = 0;
      indexItemPlanning < itemPlanningByLocator.length;
      indexItemPlanning++
    ) {
      const itemPlanning = itemPlanningByLocator[indexItemPlanning];
      const keyItemStock = attributeLocator
        .map((attribute) => itemPlanning[attribute] || '')
        .join(joinCharacter);
      if (!has(serializeItemStock, keyItemStock)) {
        continue loopItemPlanningByLocator;
      }
      const itemStock = serializeItemStock[keyItemStock];
      const itemPlanQuantity = min([
        +itemStock.quantity,
        +itemPlanning.remainQuantity,
      ]);
      itemPlanning.remainQuantity = minus(itemStock.quantity, itemPlanQuantity);
      itemStock.quantity = minus(itemStock.quantity, itemPlanQuantity);
      serializeItemStock[keyItemStock] = itemStock;
    }
    const groupItemStockByAttribute = groupBy(
      values(serializeItemStock).filter((itemStock) => itemStock.quantity > 0),
      (itemStock) =>
        attributes
          .map((attribute) => itemStock[attribute] || '')
          .join(joinCharacter),
    );
    const groupSerializeItemPlanNotLocator = groupBy(
      itemPlanningNotLocator,
      (itemPlan) =>
        attributes
          .map((attribute) => itemPlan[attribute] || '')
          .join(joinCharacter),
    );
    items.forEach((item) => {
      const keyItem = attributes
        .map((attribute) => item[attribute] || '')
        .join(joinCharacter);
      let itemStockByAttribute = has(groupItemStockByAttribute, keyItem)
        ? groupItemStockByAttribute[keyItem]
        : [];
      if (has(groupSerializeItemPlanNotLocator, keyItem)) {
        const itemPlan = groupSerializeItemPlanNotLocator[keyItem];
        if (!isEmpty(item?.locatorIds)) {
          itemStockByAttribute.forEach((itemStock) => {
            itemPlan.forEach((itemPlaningDetail) => {
              if (
                !item.locatorIds.includes(itemStock.locatorId) &&
                itemPlaningDetail.remainQuantity >= 0
              ) {
                const itemPlanQuantity = min([
                  Number(itemPlaningDetail.remainQuantity),
                  Number(itemStock.quantity),
                ]);
                itemStock.quantity = minus(
                  itemStock.quantity,
                  itemPlanQuantity,
                );
                itemPlaningDetail.remainQuantity = minus(
                  itemPlaningDetail.remainQuantity,
                  itemPlanQuantity,
                );
              }
            });
          });
        }

        itemStockByAttribute.forEach((itemStock) => {
          itemPlan.forEach((itemPlaningDetail) => {
            if (itemPlaningDetail.remainQuantity >= 0) {
              const itemPlanQuantity = min([
                Number(itemPlaningDetail.remainQuantity),
                Number(itemStock.quantity),
              ]);
              itemStock.quantity = minus(itemStock.quantity, itemPlanQuantity);
              itemPlaningDetail.remainQuantity = minus(
                itemPlaningDetail.remainQuantity,
                itemPlanQuantity,
              );
            }
          });
        });
      }
      if (!isEmpty(item?.locatorIds)) {
        itemStockByAttribute = itemStockByAttribute.filter((itemStock) =>
          item.locatorIds.includes(itemStock.locatorId),
        );
      }
      item['quantity'] = itemStockByAttribute.reduce(
        (pre, curr) => plus(pre, curr.quantity),
        0,
      );
      item['itemAvailables'] = itemStockByAttribute.filter(
        (item) => item.quantity > 0,
      );
    });
    return plainToInstance(ItemStockAvailableResponseDto, items, {
      excludeExtraneousValues: true,
    });
  }

  async createItemSwiftLocator(
    request: CreateItemSwiftLocatorRequestDto,
  ): Promise<any> {
    const {
      warehouseStockMovementExportId,
      warehouseStockMovementImportId,
      warehouseId,
      destinationWarehouseId,
      userId,
      items,
      orderId,
      orderCode,
      saleOrderType,
      purpose,
    } = request;
    const itemStockMovementExportEntities = items.map((e) => {
      return this.itemStockMovementRepository.createEntity({
        itemId: e.itemId,
        quantity: e.quantity,
        warehouseStockMovementId: warehouseStockMovementExportId,
        warehouseId: warehouseId,
        userId,
        orderId: orderId,
        orderCode: orderCode,
        orderType: saleOrderType,
        movementOrderDetailId: e.movementOrderDetailId,
        movementOrderWarehouseDetailId: e.movementOrderWarehouseDetailId,
        type: ItemStockMovementTypeEnum.Export,
      } as ItemStockMovementDto);
    });

    const itemStockMovementImportEntities = items.map((e) => {
      return this.itemStockMovementRepository.createEntity({
        itemId: e.itemId,
        quantity: e.quantity,
        warehouseStockMovementId: warehouseStockMovementImportId,
        warehouseId: destinationWarehouseId,
        userId,
        orderId: orderId,
        orderCode: orderCode,
        orderType: saleOrderType,
        movementOrderDetailId: e.movementOrderDetailId,
        movementOrderWarehouseDetailId: e.movementOrderWarehouseDetailId,
        type: ItemStockMovementTypeEnum.Import,
      } as ItemStockMovementDto);
    });
    const queryRunner = this.connection.createQueryRunner();
    let itemStockMovements;
    const conditions = [];
    await queryRunner.startTransaction();
    try {
      const itemStockMovementExport = await queryRunner.manager.save(
        itemStockMovementExportEntities,
      );

      const itemStockMovementHistoryExportEntities =
        [] as ItemStockMovementHistory[];
      items.map((itemStock, index) => {
        itemStock.itemsStockMovementHistories.map(
          (itemsStockMovementHistory) => {
            conditions.push({
              itemId: itemsStockMovementHistory.itemId,
              lotNumber: itemsStockMovementHistory.lotNumber,
              warehouseId: destinationWarehouseId,
            });
            itemStockMovementHistoryExportEntities.push(
              this.itemStockMovementHistoryRepository.createEntity({
                itemId: itemsStockMovementHistory.itemId,
                locatorId: itemsStockMovementHistory.sourceLocatorId,
                lotNumber: itemsStockMovementHistory.lotNumber,
                quantity: itemsStockMovementHistory.quantity,
                itemStockMovementId: itemStockMovementExport[index].id,
              } as ItemStockMovementHistoryDto),
            );
          },
        );
      });
      await queryRunner.manager.save(itemStockMovementHistoryExportEntities);

      const itemStockMovementImport = await queryRunner.manager.save(
        itemStockMovementImportEntities,
      );
      const itemStockMovementHistoryImportEntities =
        [] as ItemStockMovementHistory[];
      items.map((itemStock, index) => {
        itemStock.itemsStockMovementHistories.map(
          (itemsStockMovementHistory) => {
            itemStockMovementHistoryImportEntities.push(
              this.itemStockMovementHistoryRepository.createEntity({
                itemId: itemsStockMovementHistory.itemId,
                locatorId: itemsStockMovementHistory.destinationLocatorId,
                lotNumber: itemsStockMovementHistory.lotNumber,
                quantity: itemsStockMovementHistory.quantity,
                itemStockMovementId: itemStockMovementImport[index].id,
              } as ItemStockMovementHistoryDto),
            );
          },
        );
      });

      await queryRunner.manager.save(itemStockMovementHistoryImportEntities);
      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }
    await this.updateStockQuantityFromOrderRequest({
      orderId: orderId,
      orderType: OrderTypeEnum.Export,
      warehouseStockMovementId: warehouseStockMovementExportId,
      saleOrderType: saleOrderType,
      conditions,
    } as UpdateStockFromOrderRequest);

    await this.updateStockQuantityFromOrderRequest({
      orderId: orderId,
      orderType: OrderTypeEnum.Import,
      warehouseStockMovementId: warehouseStockMovementImportId,
      saleOrderType: saleOrderType,
      purpose: purpose,
      conditions,
    } as UpdateStockFromOrderRequest);

    return new ResponseBuilder(itemStockMovements)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getItemStockAvaiableGroupLocation(
    request: GetItemStockAvailableRequestDto,
  ): Promise<any> {
    const result = await this.getItemStockAvailable(request);
    const items = result.data;
    const locatorIds = map(flatMap(items, 'itemAvailables'), 'locatorId');

    if (!isEmpty(locatorIds)) {
      const locators = await this.warehouseLayoutService.getLocatorByIds(
        locatorIds,
        true,
      );
      items.forEach((item) => {
        const itemByLocator = {};
        item?.itemAvailables.forEach((itemLocator) => {
          if (!has(itemByLocator, itemLocator.locatorId)) {
            itemByLocator[itemLocator.locatorId] = {
              ...itemLocator,
              quantity: 0,
              locator: locators[itemLocator.locatorId],
            };
          }
          itemByLocator[itemLocator.locatorId].quantity = plus(
            itemByLocator[itemLocator.locatorId].quantity,
            itemLocator.quantity,
          );
        });
        item.itemAvailables = values(itemByLocator);
      });
    }
    return new ResponseBuilder(items)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getItemStockAvailableSwiftLocator(
    request: GetItemStockAvailableSwiftLocatorRequestDto,
  ): Promise<any> {
    const { order, items } = request;
    const conditionFilterItemStock = items.map((item) => {
      const condition = {} as any;
      if (item.lotNumber) {
        condition.lotNumber = item?.lotNumber?.toUpperCase() || IsNull();
      }
      condition.warehouseId = item.warehouseId;
      condition.itemId = item.itemId;
      if (item.locatorId) {
        condition.locatorId = item.locatorId;
      }
      return condition;
    });
    const itemStocks =
      await this.itemStockWarehouseLocatorRepository.getTotalQuantityItemStockByCondition(
        conditionFilterItemStock,
      );

    const conditionFilterItemPlanning = items.map((item) => {
      const itemStockLocators = itemStocks.filter(
        (itemStock) =>
          item.itemId === itemStock.itemId &&
          item.warehouseId === itemStock.warehouseId &&
          item?.lotNumber?.toUpperCase() ===
            itemStock?.lotNumber?.toUpperCase(),
      );
      const condition = {
        itemId: item.itemId,
        warehouseId: item.warehouseId,
        lotNumber: item?.lotNumber?.toUpperCase() || IsNull(),
      } as any;
      if (!isEmpty(itemStockLocators)) {
        condition.locatorId = In(uniq(map(itemStockLocators, 'locatorId')));
      }
      return condition;
    }) as FilterItemByCondition[];
    const itemPlanning =
      await this.itemPlanningQuantityRepository.getTotalQuantityItemPlanningByCondition(
        conditionFilterItemPlanning,
        order,
      );
    let itemStockAvaiables = this.calculateItemStockAvailable(
      items,
      itemStocks,
      itemPlanning,
    );
    const locatorIds = map(
      flatMap(itemStockAvaiables, 'itemAvailables'),
      'locatorId',
    );
    const itemIds = map(items, 'itemId');
    const itemDetails = await this.itemRepository.findAllByCondition({
      id: In(uniq(itemIds)),
    });
    const serializeItem = keyBy(itemDetails, 'id');
    let locators = {};
    if (!isEmpty(locatorIds)) {
      locators = await this.warehouseLayoutService.getLocatorByIds(
        locatorIds,
        true,
      );
    }

    itemStockAvaiables = itemStockAvaiables.map((item) => {
      const itemByLocator = {};
      item?.itemAvailables.forEach((itemLocator) => {
        if (!has(itemByLocator, itemLocator.locatorId)) {
          itemByLocator[itemLocator.locatorId] = {
            ...itemLocator,
            quantity: 0,
            locator: locators[itemLocator.locatorId],
          };
        }
        itemByLocator[itemLocator.locatorId].quantity = plus(
          itemByLocator[itemLocator.locatorId].quantity,
          itemLocator.quantity,
        );
      });
      return {
        ...item,
        item: serializeItem[item.itemId],
        itemAvailables: values(itemByLocator),
      };
    });
    const response = plainToInstance(
      ItemStockAvailableSwiftFloorResponseDto,
      itemStockAvaiables,
      { excludeExtraneousValues: true },
    );
    return new ResponseBuilder(response)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  public async getItemStockWarehouseExpireStorageTime(
    payload: GetItemStockWarehouseExpireStorageTimeRequestDto[],
  ): Promise<any> {
    const result =
      await this.itemStockWarehouseLocatorRepository.getItemStockWarehouseExpireStorageTime(
        payload,
      );
    return new ResponseBuilder(result)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async checkItemHasExistDestinationWarehouse(
    request: GetByItemIdRequestDto,
  ): Promise<any> {
    const condition = {
      itemId: request?.itemId,
      warehouseId: request?.warehouseId,
      locatorId: request?.locatorId,
    };
    const result =
      await this.itemStockWarehouseLocatorRepository.findAllByCondition(
        condition,
      );
    return new ResponseBuilder()
      .withCode(ResponseCodeEnum.SUCCESS)
      .withData(result)
      .withMessage(await this.i18n.translate('message.SUCCESS'))
      .build();
  }

  async importItemPriceInitial(
    request: ImportItemPriceInitialRequestDto,
  ): Promise<any> {
    const file = first(request.file);
    const { data: buffer, mimetype: mimeType } = file;

    if (!FILE_TYPE.XLSX.MIME_TYPE.includes(mimeType)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withData(await this.i18n.translate('error.IMPORT_INVALID_FILE_TYPE'))
        .build();
    }
    const dataItemStock =
      await this.itemStockWarehouseLocatorRepository.findByCondition({});
    if (!isEmpty(dataItemStock)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .build();
    }
    let dataRows: Row[] | string[][];
    const dataExcels = [];
    try {
      let workbook = new Workbook();
      workbook = await workbook.xlsx.load(Buffer.from(buffer));
      const worksheet = await workbook.getWorksheet(1);
      if (isEmpty(worksheet)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('validation.IMPORT_INVALID_TEMPLATE'),
          )
          .build();
      }

      const fileHeaders = {
        item_id: {
          field: 'itemId',
          required: true,
          type: 'int',
        },
        lot_number: {
          field: 'lotNumber',
          required: false,
          type: 'string',
        },
        quantity: {
          field: 'quantity',
          required: true,
          type: 'number',
          default: 0,
        },
        warehouse_id: {
          field: 'warehouseId',
          required: true,
          type: 'int',
        },
        locator_id: {
          field: 'locatorId',
          required: true,
          type: 'int',
        },
        storage_date: {
          field: 'storageDate',
          required: true,
          type: 'date',
        },
        amount: {
          field: 'amount',
          required: true,
          type: 'number',
          default: 0,
        },
        total_amount: {
          field: 'totalAmount',
          required: true,
          type: 'number',
          default: 0,
        },
      };

      const fileMapDataAndHeader = {};

      const positionByHeader = worksheet.getRow(1) as any;

      const invalidData = [] as any;

      let itemIds = [];
      let warehouseIds = [];
      let locatorIds = [];

      for (
        let indexHeader = 1;
        indexHeader < positionByHeader.values.length;
        indexHeader++
      ) {
        const header = positionByHeader?.values[indexHeader]?.trim();
        if (header && has(fileHeaders, header)) {
          fileMapDataAndHeader[indexHeader] = fileHeaders[header];
        }
      }

      dataRows = worksheet.getRows(2, worksheet.rowCount - 1);
      loopRow: for (let indexRow = 0; indexRow < dataRows.length; indexRow++) {
        const row = dataRows[indexRow] as Row | any;
        const cells = row?.values?.map((v) => (v.text ? v.text : v));
        if (isEmpty(cells)) {
          continue loopRow;
        }
        const dataRow = {} as any;
        loopCell: for (
          let indexCell = 0;
          indexCell < cells.length;
          indexCell++
        ) {
          if (!has(fileMapDataAndHeader, indexCell)) {
            continue loopCell;
          }
          const cell = this.getValueCell(
            cells[indexCell],
            fileMapDataAndHeader[indexCell],
          );
          if (
            !this.validateDataItemPrice(cell, fileMapDataAndHeader[indexCell])
          ) {
            invalidData.push({
              row: indexRow,
              cell: indexCell,
              value: cell,
            });
            break loopRow;
          }
          dataRow[fileMapDataAndHeader[indexCell].field] = cell;
        }
        if (!isEmpty(dataRow)) {
          itemIds.push(dataRow.itemId);
          warehouseIds.push(dataRow.warehouseId);
          locatorIds.push(dataRow.locatorId);
          dataExcels.push(dataRow);
        }
      }
      if (!isEmpty(invalidData)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withData(invalidData)
          .build();
      }

      itemIds = uniq(itemIds);
      warehouseIds = uniq(warehouseIds);
      locatorIds = uniq(locatorIds);

      const [items, warehouses, locators] = await Promise.all([
        this.itemRepository.findAllByCondition({
          id: In(itemIds),
        }),
        this.warehouseService.getListByIDs(warehouseIds),
        this.warehouseLayoutService.getLocatorByIds(locatorIds),
      ]);

      // if (items.length !== itemIds.length) {
      //   return new ResponseBuilder()
      //     .withCode(ResponseCodeEnum.BAD_REQUEST)
      //     .withMessage(this.i18n.translate('error.ITEM_NOT_FOUND'))
      //     .build();
      // }

      // if (warehouses.length !== warehouseIds.length) {
      //   return new ResponseBuilder()
      //     .withCode(ResponseCodeEnum.BAD_REQUEST)
      //     .withMessage(this.i18n.translate('error.WAREHOUSE_NOT_FOUND'))
      //     .build();
      // }

      // if (locators.length !== locatorIds.length) {
      //   return new ResponseBuilder()
      //     .withCode(ResponseCodeEnum.BAD_REQUEST)
      //     .withMessage(this.i18n.translate('error.LOCATOR_NOT_FOUND'))
      //     .build();
      // }
    } catch (error) {
      console.error(`Format Data Import Item Price Initial Error:`, error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .build();
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      const itemStockWarehouseLocatorEntities: ItemStockWarehouseLocatorEntity[] =
        dataExcels.map((data) => {
          return this.itemStockWarehouseLocatorRepository.createEntity({
            itemId: data.itemId,
            warehouseId: data.warehouseId,
            locatorId: data.locatorId,
            lotNumber: data.lotNumber,
            quantity: data.quantity,
            storageDate: data.storageDate,
          } as CreateItemStockWarehouseLocatorRequestDto);
        });
      const groupItemPrice = groupBy(dataExcels, (data) =>
        [data.itemId, data.warehouseId, data.lotNumber || ''].join('_'),
      );
      while (itemStockWarehouseLocatorEntities.length) {
        await queryRunner.manager.save(
          ItemStockWarehouseLocatorEntity,
          itemStockWarehouseLocatorEntities.splice(0, 1000),
        );
      }

      const itemStockWarehousePriceEntities: ItemStockWarehousePriceEntity[] =
        Object.keys(groupItemPrice).map((keyGroup) => {
          const [itemId, warehouseId, lotNumber] = keyGroup.split('_');
          const dataGroup = groupItemPrice[keyGroup];
          let quantity = 0;
          let totalAmount = 0;
          dataGroup.forEach((data) => {
            quantity = plus(data.quantity, quantity);
            totalAmount = plus(data.totalAmount, totalAmount);
          });
          let amount = (
            quantity == 0 ? 0 : div(totalAmount, +quantity || 1)
          ) as any;
          if (amount != 0) {
            amount = amount.toFixed(2);
          }
          return this.itemStockWarehousePriceRepository.createEntity({
            itemId,
            warehouseId,
            lotNumber,
            quantity,
            totalAmount,
            amount,
          });
        });

      while (itemStockWarehousePriceEntities.length) {
        await queryRunner.manager.save(
          ItemStockWarehousePriceEntity,
          itemStockWarehousePriceEntities.splice(0, 1000),
        );
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      console.error(`Save Data Import Item Price Initial Error:`, error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }

    return new ResponseBuilder({
      total: dataExcels.length,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  public async importItemPrice(
    request: ImportItemPriceInitialRequestDto,
  ): Promise<any> {
    const file = first(request.file);
    const { data: buffer, mimetype: mimeType } = file;

    if (!FILE_TYPE.XLSX.MIME_TYPE.includes(mimeType)) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withData(await this.i18n.translate('error.IMPORT_INVALID_FILE_TYPE'))
        .build();
    }
    let dataRows: Row[] | string[][];
    const dataExcels = [];
    try {
      let workbook = new Workbook();
      workbook = await workbook.xlsx.load(Buffer.from(buffer));
      const worksheet = await workbook.getWorksheet(1);
      if (isEmpty(worksheet)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate('validation.IMPORT_INVALID_TEMPLATE'),
          )
          .build();
      }

      const fileHeaders = {
        item_id: {
          field: 'itemId',
          required: true,
          type: 'int',
        },
        lot_number: {
          field: 'lotNumber',
          required: false,
          type: 'string',
        },
        quantity: {
          field: 'quantity',
          required: true,
          type: 'number',
          default: 0,
        },
        warehouse_id: {
          field: 'warehouseId',
          required: true,
          type: 'int',
        },
        locator_id: {
          field: 'locatorId',
          required: true,
          type: 'int',
        },
        storage_date: {
          field: 'storageDate',
          required: true,
          type: 'date',
        },
        amount: {
          field: 'amount',
          required: true,
          type: 'number',
          default: 0,
        },
        total_amount: {
          field: 'totalAmount',
          required: true,
          type: 'number',
          default: 0,
        },
      };

      const fileMapDataAndHeader = {};

      const positionByHeader = worksheet.getRow(1) as any;

      const invalidData = [] as any;

      for (
        let indexHeader = 1;
        indexHeader < positionByHeader.values.length;
        indexHeader++
      ) {
        const header = positionByHeader?.values[indexHeader]?.trim();
        if (header && has(fileHeaders, header)) {
          fileMapDataAndHeader[indexHeader] = fileHeaders[header];
        }
      }

      dataRows = worksheet.getRows(2, worksheet.rowCount - 1);
      loopRow: for (let indexRow = 0; indexRow < dataRows.length; indexRow++) {
        const row = dataRows[indexRow] as Row | any;
        const cells = row?.values?.map((v) => (v.text ? v.text : v));
        if (isEmpty(cells)) {
          continue loopRow;
        }
        const dataRow = {} as any;
        loopCell: for (
          let indexCell = 0;
          indexCell < cells.length;
          indexCell++
        ) {
          if (!has(fileMapDataAndHeader, indexCell)) {
            continue loopCell;
          }
          const cell = this.getValueCell(
            cells[indexCell],
            fileMapDataAndHeader[indexCell],
          );
          if (
            !this.validateDataItemPrice(cell, fileMapDataAndHeader[indexCell])
          ) {
            invalidData.push({
              row: indexRow,
              cell: indexCell,
              value: cell,
            });
            break loopRow;
          }
          dataRow[fileMapDataAndHeader[indexCell].field] = cell;
        }
        if (!isEmpty(dataRow)) {
          dataExcels.push(dataRow);
        }
      }
      if (!isEmpty(invalidData)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withData(invalidData)
          .build();
      }
    } catch (error) {
      console.error(`Format Data Import Item Price Initial Error:`, error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .build();
    }

    const groupItemPrice = groupBy(dataExcels, (data) =>
      [data.itemId, data.warehouseId, data.lotNumber || ''].join('_'),
    );

    const conditionFilterItemPrice = [];

    const itemStockWarehousePriceEntities: Map<
      string,
      ItemStockWarehousePriceEntity
    > = new Map();
    Object.keys(groupItemPrice).forEach((keyGroup) => {
      const [itemId, warehouseId, lotNumber] = keyGroup.split('_');
      const dataGroup = groupItemPrice[keyGroup];
      let quantity = 0;
      let totalAmount = 0;
      dataGroup.forEach((data) => {
        quantity = plusBigNumber(data.quantity, quantity);
        totalAmount = plusBigNumber(data.totalAmount, totalAmount);
      });
      const amount = (
        quantity == 0 ? 0 : divBigNumber(totalAmount, quantity || 1)
      ) as any;
      conditionFilterItemPrice.push({
        itemId: itemId,
        warehouseId: warehouseId,
        lotNumber: lotNumber ? lotNumber : IsNull(),
      });
      const key = [itemId, warehouseId, lotNumber || ''].join('_');
      itemStockWarehousePriceEntities.set(
        key,
        this.itemStockWarehousePriceRepository.createEntity({
          itemId,
          warehouseId,
          lotNumber,
          quantity,
          totalAmount,
          amount,
        }),
      );
    });

    const dataItemPriceDB =
      await this.itemStockWarehousePriceRepository.findAllByCondition(
        conditionFilterItemPrice,
      );
    if (dataItemPriceDB.length !== itemStockWarehousePriceEntities.size) {
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.QUANTITY_STOCK_NOT_EQUAL_QUANTITY_ITEM_IMPORT',
          ),
        )
        .build();
    }
    const invalidItemStock = [];
    dataItemPriceDB.forEach((dataItemPrice) => {
      const key = [
        dataItemPrice.itemId,
        dataItemPrice.warehouseId,
        dataItemPrice.lotNumber || '',
      ].join('_');
      if (
        itemStockWarehousePriceEntities.has(key) &&
        minusBigNumber(
          itemStockWarehousePriceEntities.get(key).quantity,
          dataItemPrice.quantity,
        ) == 0
      ) {
        dataItemPrice.amount = itemStockWarehousePriceEntities.get(key)?.amount;
        dataItemPrice.totalAmount =
          itemStockWarehousePriceEntities.get(key)?.totalAmount;
      } else {
        invalidItemStock.push(dataItemPrice);
      }
    });

    if (!isEmpty(invalidItemStock)) {
      return new ResponseBuilder(invalidItemStock)
        .withCode(ResponseCodeEnum.BAD_REQUEST)
        .withMessage(
          await this.i18n.translate(
            'error.QUANTITY_STOCK_NOT_EQUAL_QUANTITY_ITEM_IMPORT',
          ),
        )
        .build();
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      while (dataItemPriceDB.length) {
        await queryRunner.manager.save(
          ItemStockWarehousePriceEntity,
          dataItemPriceDB.splice(0, 1000),
        );
      }
      await queryRunner.commitTransaction();
    } catch (error) {
      console.error(`Save Data Import Item Price Initial Error:`, error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }

    return new ResponseBuilder({
      total: dataExcels.length,
    })
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  private getValueCell(cell, config?) {
    if (!cell && has(config, 'default')) {
      return config.default;
    }
    return cell;
  }

  private validateDataItemPrice(value, config?): boolean {
    if (config?.required && value?.length < 0) {
      return false;
    }
    if (config?.type) {
      return this.validateTypeDataImportItemPrice(value, config.type);
    }
    return true;
  }

  private validateTypeDataImportItemPrice(value, type): boolean {
    switch (type) {
      case 'int':
        return (
          !isNaN(value) &&
          parseInt(value) == value &&
          !isNaN(parseInt(value, 10))
        );
      case 'number':
        return !isNaN(value - parseFloat(value));
      case 'date':
        return moment(value).isValid();
      default:
        return true;
    }
  }

  @Cron('00 30 00 * * *', {
    name: 'daily_report',
    timeZone: 'UTC',
  })
  async syncDailyItemStockWarehousePriceToReport(): Promise<any> {
    const date = moment()
      .subtract(1, 'day')
      .set({ minute: 0, hour: 0, second: 0, millisecond: 0 })
      .format('YYYY-MM-DD');
    this.logger.debug(
      `CRON JOB SYNC ITEM PRICE RUNNING AT 30 00 * * * ${date}`,
    );
    let page = 1;
    const limit = 200;

    const company = await this.userService.getCompanyDefault();
    let flagSync = true;
    try {
      while (flagSync) {
        const requestGetListItemPrice =
          new GetListItemStockWarehousePriceRequestDto();
        requestGetListItemPrice.page = page;
        requestGetListItemPrice.limit = limit;
        const [data] = await this.itemStockWarehousePriceRepository.getList(
          requestGetListItemPrice,
        );
        if (!isEmpty(data)) {
          const warehouseSerialize = await this.warehouseService.getListByIDs(
            uniq(map(data, 'warehouseId')),
            true,
          );
          const dataSyncItemPrice = data.map(
            (item) =>
              new DataItemWarehousePriceRequestDto(
                item.itemCode,
                date,
                warehouseSerialize[item.warehouseId]?.code,
                item.lotNumber,
                item.quantity,
                item.amount,
                item.totalAmount,
                item.manufacturingCountry,
              ),
          );
          const requestSyncItemPrice =
            new SyncItemWarehouseStockPriceRequestDto(
              company.code,
              dataSyncItemPrice,
            );
          await this.syncItemStockWarehousePriceToReport(requestSyncItemPrice);
        }
        if (isEmpty(data) || data?.length < limit) {
          flagSync = false;
        }
        page++;
      }
      this.logger.debug(`CRON JOB SYNC ITEM PRICE SUCCESS ${date}`);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.SUCCESS)
        .withMessage(await this.i18n.translate('error.SUCCESS'))
        .build();
    } catch (error) {
      console.error(`CRON JOB SYNC ITEM PRICE ERROR ${date}`, error);
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        .build();
    }
  }

  private async syncItemStockWarehousePriceToReport(
    data: SyncItemWarehouseStockPriceRequestDto,
  ): Promise<any> {
    // await this.kafkaProducer.send({
    //   topic: 'SYNC_REPORT_DAILY_ITEM_PRICE_TOPIC',
    //   messages: [
    //     {
    //       key: 'data',
    //       value: JSON.stringify(data),
    //     },
    //   ],
    // });
  }

  async createItemStockWarehousePrice(
    request: CreateItemStockWarehousePriceDto | any,
    syncEbsIn?: boolean,
  ): Promise<any> {
    const { items } = request;

    const itemMap = {};
    const keys = [];
    const condition = [];

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const key = `${item.itemId}_${item.lotNumber || ''}_${item.warehouseId}`;
      itemMap[key] = item;
      keys.push(key);
      condition.push({
        itemId: item.itemId,
        lotNumber: item.lotNumber ? item.lotNumber : IsNull(),
        warehouseId: item.warehouseId,
      });
    }
    const itemStockWarehousePrices =
      await this.itemStockWarehousePriceRepository.findAllByCondition(
        condition,
      );
    const itemStockWarehousePriceMap = keyBy(
      itemStockWarehousePrices,
      (item) => `${item.itemId}_${item.lotNumber || ''}_${item.warehouseId}`,
    );

    const itemStockWarehousePriceEntities: ItemStockWarehousePriceEntity[] = [];
    for (let i = 0; i < keys.length; i++) {
      const key = keys[i];
      const itemStockWarehousePrice = itemStockWarehousePriceMap[key];
      if (syncEbsIn && isEmpty(itemStockWarehousePrice)) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
          .withMessage(
            await this.i18n.translate(
              'error.ITEM_STOCK_WAREHOUSE_PRICE_INVALID',
            ),
          )
          .build();
      }

      // số lượng = tổng sl trong kho + sl nhập
      const quantity = syncEbsIn
        ? itemStockWarehousePrice.quantity || 0
        : plusBigNumber(
            itemStockWarehousePrice?.quantity || 0,
            itemMap[key].quantity,
          );
      // tổng giá = tổng giá trong kho + tổng giá nhập
      const totalAmount = syncEbsIn
        ? plusBigNumber(
            itemStockWarehousePrice?.totalAmount || 0,
            +itemMap[key].diffPrice ? itemMap[key].diffPrice : 0,
          )
        : plusBigNumber(
            itemStockWarehousePrice?.totalAmount || 0,
            itemMap[key].totalPrice,
          );

      const itemStockWarehousePriceEntity =
        this.itemStockWarehousePriceRepository.createEntity({
          ...itemStockWarehousePrice,
          itemId: itemMap[key].itemId,
          warehouseId: itemMap[key].warehouseId,
          lotNumber: itemMap[key]?.lotEBS
            ? itemMap[key]?.lotEBS
            : itemMap[key]?.lotNumber,
          quantity: quantity,
          totalAmount: totalAmount,
          amount: divBigNumber(totalAmount, quantity),
        });
      itemStockWarehousePriceEntities.push(itemStockWarehousePriceEntity);
    }

    return new ResponseBuilder(itemStockWarehousePriceEntities)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async updateItemStockWarehousePrice(
    request: UpdateItemStockWarehousePriceDto | any,
    syncEbsIn?: boolean,
  ): Promise<any> {
    const { items } = request;

    const itemMap = keyBy(
      items,
      (item) => `${item.itemId}_${item.lotWMS || item.lotNumber || ''}`,
    );
    const condition = [];
    items.forEach((item) => {
      condition.push({
        itemId: item.itemId,
        lotNumber:
          !item.lotNumber && !item.lotWMS
            ? IsNull()
            : item.lotNumber || item.lotWMS,
        warehouseId: item.warehouseId,
      });
    });

    const itemStockWarehousePrices =
      await this.itemStockWarehousePriceRepository.findAllByCondition(
        condition,
      );

    const itemStockWarehousePriceEntities: ItemStockWarehousePriceEntity[] = [];

    for (let i = 0; i < itemStockWarehousePrices.length; i++) {
      const itemStockWarehousePrice = itemStockWarehousePrices[i];
      const key = `${itemStockWarehousePrice.itemId}_${
        itemStockWarehousePrice.lotNumber || ''
      }`;
      let quantity, price, totalAmount;
      if (syncEbsIn) {
        // đồng bộ EBS
        quantity = itemStockWarehousePrice.quantity;
        totalAmount = plusBigNumber(
          itemStockWarehousePrice.totalAmount,
          itemMap[key].diffPrice,
        );
        totalAmount = +totalAmount > 0 ? totalAmount : 0;
      } else {
        // xuất kho
        // số lượng còn lại = sl trong kho - sl xuất
        quantity = minusBigNumber(
          itemStockWarehousePrice?.quantity || 0,
          itemMap[key].quantity,
        );
        // giá hiện tại = tổng giá trong kho / số lượng
        price = divBigNumber(
          itemStockWarehousePrice.totalAmount || 0,
          itemStockWarehousePrice.quantity || 1,
        );

        // tổng giá xuất = số lượng xuât * giá hiện tại
        const totalAmoutExport = mulBigNumber(itemMap[key].quantity, price);

        // tổng giá còn lại = tổng giá hiện tại - tổng giá xuất
        totalAmount =
          +quantity === 0
            ? 0
            : minusBigNumber(
                itemStockWarehousePrice.totalAmount || 0,
                totalAmoutExport,
              );
      }

      // kiểm tra item trong kho
      if (!itemStockWarehousePrice.quantity || quantity < 0) {
        return new ResponseBuilder()
          .withCode(ResponseCodeEnum.BAD_REQUEST)
          .withMessage(
            await this.i18n.translate(
              'error.ITEM_STOCK_WAREHOUSE_PRICE_INVALID',
            ),
          )
          .build();
      }

      const itemStockWarehousePriceEntity =
        this.itemStockWarehousePriceRepository.createEntity({
          ...itemStockWarehousePrice,
          itemId: itemStockWarehousePrice.itemId,
          warehouseId: itemMap[key].warehouseId,
          quantity: quantity,
          totalAmount: +totalAmount > 0 ? totalAmount : 0,
          amount: divBigNumber(totalAmount, quantity || 1),
        });
      itemStockWarehousePriceEntities.push(itemStockWarehousePriceEntity);
    }

    return new ResponseBuilder(itemStockWarehousePriceEntities)
      .withCode(ResponseCodeEnum.SUCCESS)
      .build();
  }

  async updateItemStockWarehousePriceEbsIn(
    request: UpdateItemStockWarehousePriceEbsInDto,
  ): Promise<any> {
    const { orderType, items, orderId, saleOrderType } = request;

    const itemIds = map(items, 'itemId');
    const lotNumbers = compact(uniq(map(items, 'lotNumber')));

    let res;
    switch (orderType) {
      case ItemStockMovementTypeEnum.Import:
        res = await this.createItemStockWarehousePrice(request, true);
        break;

      case ItemStockMovementTypeEnum.Export:
        res = await this.updateItemStockWarehousePrice(request, true);
        break;

      default:
        break;
    }

    let itemPlanningQuantityExist,
      itemStockMovementHistoryExist,
      itemStockWarehouseLocatorExist;
    const conditionItemStockWarehouseLocatorExist = [];
    const itemMap = keyBy(
      items,
      (item) => `${item.itemId}-${item.lotNumber || ''}-${item.warehouseId}`,
    );
    let order;
    if (!isEmpty(lotNumbers)) {
      const condition = [];
      const conditionStock = [];
      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        condition.push({
          itemId: item.itemId,
          lotNumber: item.lotNumber ? item.lotNumber : IsNull(),
          warehouseId: item.warehouseId,
        });
        conditionStock.push({
          itemId: item.itemId,
          lotNumber: item.lotNumber ? item.lotNumber : IsNull(),
        });
      }

      itemPlanningQuantityExist =
        await this.itemPlanningQuantityRepository.findAllByCondition(condition);
      const itemStockMovementExist =
        await this.itemStockMovementRepository.findAllByCondition({
          orderId: orderId,
          orderType: saleOrderType,
        });
      const itemStockMovementIds = map(itemStockMovementExist, 'id');
      itemStockMovementHistoryExist =
        await this.itemStockMovementHistoryRepository.findAllByCondition({
          itemStockMovementId: In(itemStockMovementIds),
        });
      itemStockWarehouseLocatorExist =
        await this.itemStockWarehouseLocatorRepository.findAllByCondition(
          condition,
        );
      const itemStockMap = keyBy(
        items,
        (item) => `${item.itemId}-${item.lotNumber || ''}`,
      );
      itemPlanningQuantityExist.forEach((item) => {
        item.lotNumber =
          itemMap[`${item.itemId}-${item.lotNumber || ''}-${item.warehouseId}`]
            ?.lotEBS || item.lotNumber;
      });
      itemStockMovementHistoryExist.forEach((item) => {
        item.lotNumber =
          itemStockMap[`${item.itemId}-${item.lotNumber || ''}`]?.lotEBS ||
          item.lotNumber;
      });
      itemStockWarehouseLocatorExist.forEach((item) => {
        conditionItemStockWarehouseLocatorExist.push({
          itemId: item.itemId,
          lotNumber: `${item.lotNumber}`,
          locatorId: item.locatorId,
        });
        item.lotNumber =
          itemMap[`${item.itemId}-${item.lotNumber || ''}-${item.warehouseId}`]
            ?.lotEBS || item.lotNumber;
      });
    }
    let itemPlanningEntities;
    if (orderId && saleOrderType) {
      order = await this.saleService.getPurchasedOrderImportDetail(orderId);
      itemPlanningEntities =
        await this.itemPlanningQuantityRepository.findAllByCondition({
          orderId: orderId,
          orderType: saleOrderType,
        });
      itemPlanningEntities.forEach((itemPlanning) => {
        itemPlanning.quantity = itemPlanning.planQuantity;
      });
    }

    const queryRunner = this.connection.createQueryRunner();
    await queryRunner.startTransaction();
    try {
      if (!isEmpty(res) && res?.statusCode !== ResponseCodeEnum.SUCCESS)
        throw (
          res.message ||
          (await this.i18n.translate('error.INTERNAL_SERVER_ERROR'))
        );

      if (!isEmpty(res?.data))
        await queryRunner.manager.save(ItemStockWarehousePriceEntity, res.data);
      if (!isEmpty(itemPlanningQuantityExist))
        await queryRunner.manager.save(
          ItemPlanningQuantityEntity,
          itemPlanningQuantityExist,
        );
      if (!isEmpty(itemPlanningEntities))
        await queryRunner.manager.save(
          ItemPlanningQuantityEntity,
          itemPlanningEntities,
        );
      if (!isEmpty(itemStockMovementHistoryExist))
        await queryRunner.manager.save(
          ItemStockMovementHistory,
          itemStockMovementHistoryExist,
        );
      if (!isEmpty(itemStockWarehouseLocatorExist))
        await queryRunner.manager.save(
          ItemStockWarehouseLocatorEntity,
          itemStockWarehouseLocatorExist,
        );

      await queryRunner.commitTransaction();
    } catch (error) {
      console.log(error);
      await queryRunner.rollbackTransaction();
      return new ResponseBuilder()
        .withCode(ResponseCodeEnum.INTERNAL_SERVER_ERROR)
        .withMessage(error?.message || error)
        .build();
    } finally {
      await queryRunner.release();
    }

    // gọi sang SYNC_REPORT_DAILY_ITEM_PRICE_TOPIC
    await this.callSyncItemStockWarehousePriceToReport(itemIds, lotNumbers);

    return new ResponseBuilder().withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async callSyncItemStockWarehousePriceToReport(itemIds, lotNumbers) {
    const date = moment()
      .set({ minute: 0, hour: 0, second: 0, millisecond: 0 })
      .format('YYYY-MM-DD');
    const company = await this.userService.getCompanyDefault();

    const requestGetListItemPrice =
      new GetListItemStockWarehousePriceRequestDto();
    requestGetListItemPrice.itemIds = itemIds;
    requestGetListItemPrice.lotNumbers = compact(lotNumbers);
    const [data] = await this.itemStockWarehousePriceRepository.getList(
      requestGetListItemPrice,
    );
    if (!isEmpty(data)) {
      const warehouseSerialize = await this.warehouseService.getListByIDs(
        uniq(map(data, 'warehouseId')),
        true,
      );
      const dataSyncItemPrice = data.map(
        (item) =>
          new DataItemWarehousePriceRequestDto(
            item.itemCode,
            date,
            warehouseSerialize[item.warehouseId]?.code,
            item.lotNumber,
            item.quantity,
            item.amount,
            item.totalAmount,
            item.manufacturingCountry,
          ),
      );
      const requestSyncItemPrice = new SyncItemWarehouseStockPriceRequestDto(
        company?.code,
        dataSyncItemPrice,
      );
      await this.syncItemStockWarehousePriceToReport(requestSyncItemPrice);
    }
  }

  async getItemsPrice(request: GetItemsPrice): Promise<ResponsePayload<any>> {
    const { conditions } = request;

    const items =
      await this.itemStockWarehousePriceRepository.findAllByCondition(
        conditions.map((e) => ({
          itemId: e.itemId,
          lotNumber: e.lotNumber,
          warehouseId: e.warehouseId,
        })),
      );

    return new ResponseBuilder(items)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async getItemStockWarehousePrices(
    request: GetListItemStockWarehousePriceRequest,
  ): Promise<any> {
    let data = [];

    if (!isEmpty(request.conditions))
      data = await this.itemStockWarehousePriceRepository.findAllByCondition(
        request.conditions,
      );

    return new ResponseBuilder(data).withCode(ResponseCodeEnum.SUCCESS).build();
  }

  async getWarehouseStockByItemId(
    request: GetWarehouseStockByItemId,
  ): Promise<any> {
    const warehouses =
      await this.itemStockWarehouseLocatorRepository.getWarehouseAvailableByItemId(
        request.itemId,
      );
    const warehouseIds = warehouses.map((e) => e.warehouseId);

    return new ResponseBuilder(warehouseIds)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async suggestLocatorPoimpAutoComplete(
    request: SuggestLocatorPoimpAutoCompleteRequestDto[],
  ): Promise<any> {
    const itemStockWarehouseLocators =
      await this.itemStockWarehouseLocatorRepository.findAllByCondition(
        request.map((i) => ({
          itemId: i.itemId,
          lotNumber: i.lotNumber,
          warehouseId: i.warehouseId,
          locatorId: Not(i.locatorVirtualId),
        })),
        { storageDate: 'DESC', quantity: 'DESC' },
      );

    const data = plainToInstance(
      SuggestLocatorPoimpAutoCompleteResponseDto,
      itemStockWarehouseLocators,
      {
        excludeExtraneousValues: true,
      },
    );

    return new ResponseBuilder(data)
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }

  async suggestLocatorWithItemQuantity(
    request: SuggestLocatorWithItemQuantityRequest,
  ): Promise<any> {
    const stockConditions = request.items.map((item) => ({
      itemId: item.itemId,
      lotNumber: item.lotNumber || IsNull(),
      warehouseId: request.warehouseId,
      quantity: MoreThan(0),
    }));
    const itemRequestMap = keyBy(
      request.items,
      (item) => `${item.itemId}_${item.lotNumber || ''}`,
    );

    const itemStocks =
      await this.itemStockWarehouseLocatorRepository.findWithRelations({
        where: stockConditions,
        order: {
          storageDate: 'ASC',
        },
      });

    const itemPlans =
      await this.itemPlanningQuantityRepository.findAllByCondition(
        stockConditions,
      );

    const itemKeepInWarehouse = {};
    const itemKeepInLocator = {};

    itemPlans.forEach((item) => {
      if (item.locatorId) {
        itemKeepInLocator[
          `${item.itemId}_${item.locatorId}_${item.lotNumber || ''}`
        ] = item;
      } else {
        itemKeepInWarehouse[`${item.itemId}_${item.lotNumber || ''}`] = item;
      }
    });

    // calculate available stock quantity
    for (let index = itemStocks.length - 1; index >= 0; index--) {
      const item = itemStocks[index];
      const keyItemLocator = `${item.itemId}_${item.locatorId}_${
        item.lotNumber || ''
      }`;
      const keyItem = `${item.itemId}_${item.lotNumber || ''}`;
      if (item.quantity > 0)
        if (
          has(itemKeepInLocator, keyItemLocator) &&
          (isUndefined(itemKeepInLocator[keyItemLocator].keepQuantity) ||
            itemKeepInLocator[keyItemLocator].keepQuantity !== 0)
        ) {
          if (isUndefined(itemKeepInLocator[keyItemLocator].keepQuantity))
            itemKeepInLocator[keyItemLocator].keepQuantity = minusBigNumber(
              itemKeepInLocator[keyItemLocator].planQuantity,
              itemKeepInLocator[keyItemLocator].quantity,
            );

          if (
            +item.quantity >= +itemKeepInLocator[keyItemLocator].keepQuantity
          ) {
            item.quantity = minusBigNumber(
              item.quantity,
              itemKeepInLocator[keyItemLocator].keepQuantity,
            );
            itemKeepInLocator[keyItemLocator].keepQuantity = 0;
            index++;
          } else {
            itemKeepInLocator[keyItemLocator].keepQuantity = minusBigNumber(
              itemKeepInLocator[keyItemLocator].keepQuantity,
              item.quantity,
            );
            item.quantity = 0;
          }
        } else if (
          has(itemKeepInWarehouse, keyItem) &&
          (isUndefined(itemKeepInWarehouse[keyItem].keepQuantity) ||
            itemKeepInWarehouse[keyItem].keepQuantity !== 0)
        ) {
          if (isUndefined(itemKeepInWarehouse[keyItem].keepQuantity))
            itemKeepInWarehouse[keyItem].keepQuantity = minusBigNumber(
              itemKeepInWarehouse[keyItem].planQuantity,
              itemKeepInWarehouse[keyItem].quantity,
            );

          if (+item.quantity >= +itemKeepInWarehouse[keyItem].keepQuantity) {
            item.quantity = minusBigNumber(
              item.quantity,
              itemKeepInWarehouse[keyItem].keepQuantity,
            );
            itemKeepInWarehouse[keyItem].keepQuantity = 0;
          } else {
            itemKeepInWarehouse[keyItem].keepQuantity = minusBigNumber(
              itemKeepInWarehouse[keyItem].keepQuantity,
              item.quantity,
            );
            item.quantity = 0;
          }
        }
    }

    const dataResponse = {};
    for (let index = 0; index < itemStocks.length; index++) {
      const item = itemStocks[index];

      const key = `${item.itemId}_${item.lotNumber || ''}`;
      const itemRequest = itemRequestMap[key];

      if (
        !isEmpty(itemRequest) &&
        itemRequest.actualQuantity > 0 &&
        +item.quantity > 0
      ) {
        const keyItem = `${item.itemId}_${item.locatorId}_${
          item.lotNumber || ''
        }`;
        if (itemRequest.actualQuantity <= +item.quantity) {
          if (has(dataResponse, keyItem)) {
            dataResponse[keyItem].quantity = plusBigNumber(
              itemRequest.actualQuantity,
              dataResponse[keyItem].quantity,
            );
          } else {
            dataResponse[keyItem] = {
              id: item.itemId,
              quantity: itemRequest.actualQuantity,
              locatorId: item.locatorId,
              lotNumber: item.lotNumber,
            };
          }
          itemRequest.actualQuantity = 0;
        } else {
          if (has(dataResponse, keyItem)) {
            dataResponse[keyItem].quantity = plusBigNumber(
              item.quantity,
              dataResponse[keyItem].quantity,
            );
          } else {
            dataResponse[keyItem] = {
              id: item.itemId,
              quantity: item.quantity,
              locatorId: item.locatorId,
              lotNumber: item.lotNumber,
            };
          }

          itemRequest.actualQuantity = minusBigNumber(
            itemRequest.actualQuantity,
            item.quantity,
          );
        }
      }
    }

    return new ResponseBuilder(values(dataResponse))
      .withCode(ResponseCodeEnum.SUCCESS)
      .withMessage(await this.i18n.translate('error.SUCCESS'))
      .build();
  }
}
