import { CreateCurrencyUnitRequestDto } from '../dto/request/create-currency-unit.request.dto';
import { DeleteMultipleCurrencyUnitRequestDto } from '../dto/request/delete-multiple-currency-unit.request.dto';
import { GetCurrencyUnitsByIdsRequestDto } from '../dto/request/get-currency-unit-by-ids.request.dto';
import { GetCurrencyUnitListRequestDto } from '../dto/request/get-currency-unit-list.request.dto';
import { UpdateCurrencyUnitRequestDto } from '../dto/request/update-currency-unit.request.dto';

export interface CurrencyUnitServiceInterface {
  create(request: CreateCurrencyUnitRequestDto): Promise<any>;
  update(request: UpdateCurrencyUnitRequestDto): Promise<any>;
  updateStatus(id: number, isActive?: boolean): Promise<any>;
  getList(request: GetCurrencyUnitListRequestDto): Promise<any>;
  getDetail(id: number): Promise<any>;
  getMainCurrencyUnit(): Promise<any>;
  delete(id: number): Promise<any>;
  getCurrencyUnitsByIds(request: GetCurrencyUnitsByIdsRequestDto): Promise<any>;
  deleteMultiple(request: DeleteMultipleCurrencyUnitRequestDto): Promise<any>;
}
