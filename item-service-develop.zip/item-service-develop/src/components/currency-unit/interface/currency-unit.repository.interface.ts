import { BaseInterfaceRepository } from '@core/repository/base.interface.repository';
import { CurrencyUnitEntity } from '@entities/currency-unit/currency-unit.entity';
import { GetCurrencyUnitListRequestDto } from '../dto/request/get-currency-unit-list.request.dto';
import { GetCurrencyUnitsByIdsRequestDto } from '../dto/request/get-currency-unit-by-ids.request.dto';

export interface CurrencyUnitRepositoryInterface
  extends BaseInterfaceRepository<any> {
  createEntity(request: any, id?: number): CurrencyUnitEntity;
  getList(request: GetCurrencyUnitListRequestDto): Promise<any>;
  getCurrencyUnitsByIds(request: GetCurrencyUnitsByIdsRequestDto): Promise<any>;
}
