import { BasicResponseDto } from '@components/user/dto/response/basic-response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';

class ExchangeRateResponseDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  rate: number;
}
export class CurrencyUnitResponseDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  status: number;

  @ApiProperty()
  @Expose()
  description: string;

  @ApiProperty()
  @Expose()
  createdByUserId: number;

  @ApiProperty()
  @Expose()
  createdAt: string;

  @ApiProperty()
  @Expose()
  updatedAt: string;

  @ApiProperty()
  @Type(() => ExchangeRateResponseDto)
  @Expose()
  exchangeRate: ExchangeRateResponseDto;
}

class UserReposneDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  fullName: string;
}

export class GetCurrencyUnitDetailResponseDto extends CurrencyUnitResponseDto {
  @ApiProperty()
  @Type(() => UserReposneDto)
  @Expose()
  user: UserReposneDto;
}
