import { BasicResponseDto } from '@components/user/dto/response/basic-response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { CurrencyUnitResponseDto } from './get-currency-unit-detail.response.dto';

class UserReposneDto extends BasicResponseDto {
  @ApiProperty()
  @Expose()
  fullName: string;
}

export class GetCurrencyUnitListResponseDto extends CurrencyUnitResponseDto {
  @ApiProperty()
  @Type(() => UserReposneDto)
  @Expose()
  user: UserReposneDto;
}
