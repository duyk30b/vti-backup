import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  ParseIntPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { CreateCurrencyUnitRequestDto } from './dto/request/create-currency-unit.request.dto';
import { CurrencyUnitServiceInterface } from './interface/currency-unit.service.interface';
import { isEmpty } from 'lodash';
import { GetCurrencyUnitListRequestDto } from './dto/request/get-currency-unit-list.request.dto';
import { UpdateCurrencyUnitRequestDto } from './dto/request/update-currency-unit.request.dto';
import { MessagePattern } from '@nestjs/microservices';
import { GetCurrencyUnitsByIdsRequestDto } from './dto/request/get-currency-unit-by-ids.request.dto';
import { DeleteMultipleCurrencyUnitRequestDto } from './dto/request/delete-multiple-currency-unit.request.dto';
import { NATS_ITEM } from '@config/nats.config';

@Controller('currency-units')
export class CurrencyUnitController {
  constructor(
    @Inject('CurrencyUnitServiceInterface')
    private readonly currencyUnitService: CurrencyUnitServiceInterface,
  ) {}

  @Post('/create')
  @ApiOperation({
    tags: ['Currency unit'],
    summary: 'Create currency unit',
  })
  @ApiResponse({
    status: 200,
    description: 'Create successfully',
  })
  public async create(
    @Body() body: CreateCurrencyUnitRequestDto,
  ): Promise<any> {
    const { request, responseError } = body;
    if (!isEmpty(responseError)) {
      return responseError;
    }

    request.createdByUserId = request.userId;
    return await this.currencyUnitService.create(request);
  }

  @Put('/:id')
  @ApiOperation({
    tags: ['Currency unit'],
    summary: 'Update currency unit',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  public async update(
    @Body() body: UpdateCurrencyUnitRequestDto,
    @Param('id', new ParseIntPipe()) id,
  ): Promise<any> {
    const { request, responseError } = body;
    if (!isEmpty(responseError)) {
      return responseError;
    }

    request.id = id;
    return await this.currencyUnitService.update(request);
  }

  @Put('/:id/inactive')
  @ApiOperation({
    tags: ['Currency unit'],
    summary: 'Update currency unit',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  public async lock(@Param('id', new ParseIntPipe()) id): Promise<any> {
    return await this.currencyUnitService.updateStatus(id);
  }

  @Put('/:id/active')
  @ApiOperation({
    tags: ['Currency unit'],
    summary: 'Update currency unit',
  })
  @ApiResponse({
    status: 200,
    description: 'Update successfully',
  })
  public async unlock(@Param('id', new ParseIntPipe()) id): Promise<any> {
    return await this.currencyUnitService.updateStatus(id, true);
  }

  @Get('/:id')
  @ApiOperation({
    tags: ['Currency unit'],
    summary: 'Get currency unit',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  public async getDetail(@Param('id', new ParseIntPipe()) id): Promise<any> {
    return await this.currencyUnitService.getDetail(id);
  }

  @Get('/main')
  @ApiOperation({
    tags: ['Currency unit'],
    summary: 'Get main currency unit',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  public async getMainCurrencyUnit(): Promise<any> {
    return await this.currencyUnitService.getMainCurrencyUnit();
  }

  @Get('/list')
  @ApiOperation({
    tags: ['Currency unit'],
    summary: 'Get currency unit List',
  })
  @ApiResponse({
    status: 200,
    description: 'Get successfully',
  })
  public async getList(
    @Query() query: GetCurrencyUnitListRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (!isEmpty(responseError)) {
      return responseError;
    }

    request.createdByUserId = request.userId;
    return await this.currencyUnitService.getList(request);
  }

  @Delete('/:id')
  @ApiOperation({
    tags: ['Currency unit'],
    summary: 'Delete currency unit',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
  })
  public async delete(@Param('id', new ParseIntPipe()) id): Promise<any> {
    return await this.currencyUnitService.delete(id);
  }

  @Delete('/multiple')
  @ApiOperation({
    tags: ['Currency unit'],
    summary: 'Delete currency unit',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete successfully',
  })
  public async deleteMultiple(
    @Query() query: DeleteMultipleCurrencyUnitRequestDto,
  ): Promise<any> {
    const { request, responseError } = query;
    if (!isEmpty(responseError)) {
      return responseError;
    }
    return await this.currencyUnitService.deleteMultiple(request);
  }

  @MessagePattern(`${NATS_ITEM}.get_currency_units_by_ids`)
  public async getCurrencyUnitsByIds(
    @Body() payload: GetCurrencyUnitsByIdsRequestDto,
  ): Promise<any> {
    const { request, responseError } = payload;
    if (responseError && !isEmpty(responseError)) {
      return responseError;
    }

    return await this.currencyUnitService.getCurrencyUnitsByIds(request);
  }
}
