import { UserService } from '@components/user/user.service';
import { CurrencyUnitEntity } from '@entities/currency-unit/currency-unit.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CurrencyUnitRepository } from '@repositories/currency-unit.repository';
import { CurrencyUnitController } from './currency-unit.controller';
import { CurrencyUnitService } from './currency-unit.service';

@Module({
  imports: [TypeOrmModule.forFeature([CurrencyUnitEntity])],
  exports: [
    {
      provide: 'CurrencyUnitRepositoryInterface',
      useClass: CurrencyUnitRepository,
    },
  ],
  providers: [
    {
      provide: 'CurrencyUnitServiceInterface',
      useClass: CurrencyUnitService,
    },
    {
      provide: 'UserServiceInterface',
      useClass: UserService,
    },
    {
      provide: 'CurrencyUnitRepositoryInterface',
      useClass: CurrencyUnitRepository,
    },
  ],
  controllers: [CurrencyUnitController],
})
export class CurrencyUnitModule {}
