export enum CurrencyUnitStatusEnum {
  INACTIVE = 0,
  ACTIVE = 1,
}

export const CAN_NOT_UPDATE_CURRENCY_UNIT_STATUS: number[] = [];

export const CAN_DELETE_CURRENCY_UNIT_STATUS: number[] = [
  CurrencyUnitStatusEnum.INACTIVE,
];

export const CAN_CONFIRM_CURRENCY_UNIT_STATUS: number[] = [
  CurrencyUnitStatusEnum.INACTIVE,
];

export const CAN_REJECT_CURRENCY_UNIT_STATUS: number[] = [
  CurrencyUnitStatusEnum.INACTIVE,
];
